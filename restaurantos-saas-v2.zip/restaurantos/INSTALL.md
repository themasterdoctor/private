# RestaurantOS — Installation Guide

## ⚡ Quick Setup (Recommended)

From the `restaurantos/` directory:

```bash
bash setup.sh
```

This installs Docker, Node, configures .env, migrates the DB, seeds data, and starts everything.

---

## Manual Setup (No Docker)

### 1. Install PostgreSQL

```bash
apt-get update
apt-get install -y postgresql postgresql-contrib

# Start PostgreSQL
systemctl start postgresql
systemctl enable postgresql

# Create database and user
sudo -u postgres psql << SQL
CREATE USER restaurantos WITH PASSWORD 'restaurantos_dev';
CREATE DATABASE restaurantos OWNER restaurantos;
GRANT ALL PRIVILEGES ON DATABASE restaurantos TO restaurantos;
SQL
```

### 2. Install Node.js 20

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs
node --version  # should be v20.x
```

### 3. Configure environment

```bash
cd ~/private/private/restaurantos
cp .env.example .env
nano .env
```

**Minimum required values for local dev:**
```env
DATABASE_URL=postgresql://restaurantos:restaurantos_dev@localhost:5432/restaurantos
JWT_SECRET=any_long_random_string_64_chars
JWT_REFRESH_SECRET=different_long_random_string_64_chars
NODE_ENV=development
PORT=4000
NEXT_PUBLIC_API_URL=http://YOUR_SERVER_IP:4000
FRONTEND_URL=http://YOUR_SERVER_IP:3000
```

Generate secure JWT secrets:
```bash
openssl rand -base64 48
```

### 4. Install backend & run migrations

```bash
cd backend

# IMPORTANT: Install local Prisma 5 (do NOT use global npx prisma)
npm install

# Use the LOCAL prisma binary to avoid version conflicts
./node_modules/.bin/prisma generate
./node_modules/.bin/prisma migrate dev --name init

# Seed demo data
./node_modules/.bin/ts-node src/seed.ts
```

### 5. Start backend

```bash
# Development (with auto-reload)
npm run dev

# Production
npm run build
npm start
```

### 6. Install & start frontend

```bash
cd ../frontend
npm install
npm run dev    # development
# OR
npm run build && npm start   # production
```

---

## ⚠️ Common Errors & Fixes

### Error: `datasource property url is no longer supported`
**Cause:** You ran `npx prisma` which downloaded Prisma 7. Prisma 7 changed the config format.

**Fix:** Always use the LOCAL prisma installed in `node_modules`:
```bash
cd backend
npm install                             # installs prisma@5.12.0 locally
./node_modules/.bin/prisma migrate dev  # uses local v5, not global v7
```

**Never run:** `npx prisma` (downloads latest = v7)

---

### Error: `docker-compose: command not found`
Docker Compose v2 uses `docker compose` (with a space), not `docker-compose`.

```bash
# Install Docker + Compose plugin
curl -fsSL https://get.docker.com | sh
apt-get install -y docker-compose-plugin

# Use:
docker compose up -d        ✓
docker-compose up -d        ✗ (old v1 syntax)
```

---

### Error: `cannot stat '.env.example': No such file or directory`
You ran the command from the wrong directory.

```bash
# Wrong:
cd ~/private/private
cp .env.example .env     # ✗ — .env.example is one level deeper

# Correct:
cd ~/private/private/restaurantos
cp .env.example .env     # ✓
```

---

### Error: `P1001: Can't reach database server`
PostgreSQL isn't running or DATABASE_URL is wrong.

```bash
# Check if postgres is running
systemctl status postgresql
# OR (if using Docker)
docker compose ps

# Test connection
psql postgresql://restaurantos:restaurantos_dev@localhost:5432/restaurantos -c "SELECT 1"
```

---

### Error: `relation does not exist`
Migrations haven't been run yet.

```bash
cd backend
./node_modules/.bin/prisma migrate dev
```

---

## Production Deployment

### Using PM2 (no Docker)

```bash
npm install -g pm2

# Backend
cd backend
npm run build
pm2 start dist/index.js --name "restaurantos-api" --env production

# Frontend
cd ../frontend
npm run build
pm2 start "npm start" --name "restaurantos-web"

pm2 save
pm2 startup
```

### Using Docker Compose (recommended)

```bash
cd ~/private/private/restaurantos

# Build and start all services
docker compose up -d --build

# View logs
docker compose logs -f backend
docker compose logs -f frontend

# Restart a service
docker compose restart backend
```

---

## Verify Everything Works

```bash
# Health check
curl http://localhost:4000/health

# Expected response:
# {"status":"ok","timestamp":"...","version":"1.0.0"}

# Test login
curl -X POST http://localhost:4000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"owner@kazunori.com","password":"demo1234"}'
```
