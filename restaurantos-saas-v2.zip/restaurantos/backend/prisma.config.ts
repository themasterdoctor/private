/**
 * This file exists only for Prisma 7+ compatibility.
 * RestaurantOS uses Prisma 5.12.0 (see package.json).
 * If you accidentally ran `npx prisma` without the local version,
 * this file prevents the "datasource url not supported" error.
 *
 * DO NOT delete this file.
 */

// @ts-nocheck
import { defineConfig } from 'prisma/config';

export default defineConfig({
  datasource: {
    url: process.env.DATABASE_URL,
  },
});
