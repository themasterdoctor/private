import { Resend } from 'resend';
import { logger } from './logger';

const resend = new Resend(process.env.RESEND_API_KEY);
const FROM = process.env.FROM_EMAIL || 'noreply@restaurantos.app';

interface SendEmailOpts {
  to: string;
  subject: string;
  html?: string;
  text?: string;
}

export async function sendEmail({ to, subject, html, text }: SendEmailOpts) {
  try {
    if (!process.env.RESEND_API_KEY || process.env.RESEND_API_KEY === 're_placeholder') {
      logger.info(`[Email skipped – no key] To: ${to} | ${subject}`);
      return;
    }
    await resend.emails.send({ from: FROM, to, subject, html: html || `<p>${text}</p>`, text });
    logger.info(`Email sent: ${subject} → ${to}`);
  } catch (err) {
    logger.error('Email send failed:', err);
  }
}

export async function sendWelcomeEmail(email: string, firstName: string, orgName: string) {
  return sendEmail({
    to: email,
    subject: `Welcome to RestaurantOS, ${firstName}!`,
    html: `
      <div style="font-family:sans-serif;max-width:560px;margin:0 auto;">
        <h2 style="color:#00E5A0;">Welcome to RestaurantOS 🍽️</h2>
        <p>Hi ${firstName},</p>
        <p>Your account for <strong>${orgName}</strong> is ready. Your 14-day free trial has started.</p>
        <a href="${process.env.FRONTEND_URL}/login"
           style="display:inline-block;background:#00E5A0;color:#0D0D0F;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;margin:16px 0;">
          Open RestaurantOS →
        </a>
        <p style="color:#888;font-size:13px;">Questions? Reply to this email — we read every one.</p>
      </div>
    `,
  });
}

export async function sendInviteEmail(
  email: string,
  orgName: string,
  inviteUrl: string,
  senderName: string
) {
  return sendEmail({
    to: email,
    subject: `You've been invited to join ${orgName} on RestaurantOS`,
    html: `
      <div style="font-family:sans-serif;max-width:560px;margin:0 auto;">
        <h2 style="color:#00E5A0;">You're invited 🎉</h2>
        <p><strong>${senderName}</strong> has invited you to join <strong>${orgName}</strong> on RestaurantOS — the restaurant intelligence platform.</p>
        <a href="${inviteUrl}"
           style="display:inline-block;background:#00E5A0;color:#0D0D0F;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;margin:16px 0;">
          Accept Invitation →
        </a>
        <p style="color:#888;font-size:12px;">This invitation expires in 7 days.</p>
      </div>
    `,
  });
}

export async function sendAlertEmail(
  email: string,
  locationName: string,
  alerts: Array<{ message: string; severity: string }>
) {
  const rows = alerts.map(a => {
    const color = a.severity === 'CRITICAL' ? '#F05050' : '#F0A030';
    return `<tr><td style="padding:8px 12px;border-bottom:1px solid #222;"><span style="color:${color};font-weight:600;">[${a.severity}]</span> ${a.message}</td></tr>`;
  }).join('');

  return sendEmail({
    to: email,
    subject: `RestaurantOS Alert — ${locationName} needs attention`,
    html: `
      <div style="font-family:sans-serif;max-width:560px;margin:0 auto;">
        <h2 style="color:#F0A030;">⚠️ Restaurant Alert</h2>
        <p>The following issues were detected at <strong>${locationName}</strong>:</p>
        <table style="width:100%;border-collapse:collapse;background:#1a1a1d;border-radius:8px;overflow:hidden;">
          ${rows}
        </table>
        <a href="${process.env.FRONTEND_URL}/dashboard"
           style="display:inline-block;background:#00E5A0;color:#0D0D0F;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:600;margin-top:16px;">
          View Dashboard →
        </a>
      </div>
    `,
  });
}
