import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';

import { authRouter } from './routes/auth';
import { orgsRouter } from './routes/organizations';
import { locationsRouter } from './routes/locations';
import { salesRouter } from './routes/sales';
import { inventoryRouter } from './routes/inventory';
import { invoicesRouter } from './routes/invoices';
import { laborRouter } from './routes/labor';
import { recipesRouter } from './routes/recipes';
import { financeRouter } from './routes/finance';
import { valuationRouter } from './routes/valuation';
import { billingRouter } from './routes/billing';
import { alertsRouter } from './routes/alerts';
import { adminRouter } from './routes/admin';
import { webhookRouter } from './routes/webhooks';
import { errorHandler } from './middleware/errorHandler';
import { logger } from './utils/logger';

const app = express();
const PORT = process.env.PORT || 4000;

// ── Security ──
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
}));

// ── Stripe webhook needs raw body ──
app.use('/api/webhooks/stripe', express.raw({ type: 'application/json' }));
app.use(webhookRouter);

// ── Body parsing ──
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Logging ──
app.use(morgan('combined', {
  stream: { write: (msg) => logger.info(msg.trim()) },
}));

// ── Rate limiting ──
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 500,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

// ── Health check ──
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), version: '1.0.0' });
});

// ── API Routes ──
app.use('/api/auth',       authRouter);
app.use('/api/orgs',       orgsRouter);
app.use('/api/locations',  locationsRouter);
app.use('/api/sales',      salesRouter);
app.use('/api/inventory',  inventoryRouter);
app.use('/api/invoices',   invoicesRouter);
app.use('/api/labor',      laborRouter);
app.use('/api/recipes',    recipesRouter);
app.use('/api/finance',    financeRouter);
app.use('/api/valuation',  valuationRouter);
app.use('/api/billing',    billingRouter);
app.use('/api/alerts',     alertsRouter);
app.use('/api/admin',      adminRouter);

// ── Error handler ──
app.use(errorHandler);

app.listen(PORT, () => {
  logger.info(`🚀 RestaurantOS API running on port ${PORT}`);
  logger.info(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
});

export default app;
