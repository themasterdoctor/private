# RestaurantOS — Production SaaS

Restaurant intelligence platform for operators, chefs, managers, and consultants.

## Stack
- **Frontend**: Next.js 14 App Router + TypeScript + Tailwind CSS + Recharts
- **Backend**: Node.js + Express + TypeScript
- **Database**: PostgreSQL + Prisma ORM
- **Auth**: JWT (access + refresh tokens) + bcrypt
- **Billing**: Stripe Subscriptions
- **Storage**: AWS S3 (invoices/files)
- **Email**: Resend
- **AI Parsing**: Anthropic Claude Vision API
- **Deploy**: Docker Compose

## Quick Start

```bash
# 1. Clone and install
git clone https://github.com/your-org/restaurantos
cd restaurantos

# 2. Set environment variables
cp .env.example .env
# Edit .env with your keys

# 3. Start with Docker
docker-compose up -d

# 4. Run migrations
cd backend && npx prisma migrate dev

# 5. Seed demo data
npx ts-node src/seed.ts

# 6. Open app
open http://localhost:3000
```

## Env Variables

```
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/restaurantos

# Auth
JWT_SECRET=your-super-secret-jwt-key
JWT_REFRESH_SECRET=your-refresh-secret

# Stripe
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_STARTER_PRICE_ID=price_...
STRIPE_PRO_PRICE_ID=price_...
STRIPE_ENTERPRISE_PRICE_ID=price_...

# AWS S3
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
AWS_BUCKET=restaurantos-uploads
AWS_REGION=us-east-1

# Anthropic (AI invoice parsing)
ANTHROPIC_API_KEY=sk-ant-...

# Resend (email)
RESEND_API_KEY=re_...
FROM_EMAIL=noreply@restaurantos.app

# App
NEXT_PUBLIC_API_URL=http://localhost:4000
FRONTEND_URL=http://localhost:3000
```

## Plans
| Feature | Starter $49 | Pro $149 | Enterprise $399 |
|---------|-------------|----------|-----------------|
| Locations | 1 | 5 | Unlimited |
| Staff accounts | 3 | Unlimited | Unlimited |
| AI invoice parsing | 10/mo | 100/mo | Unlimited |
| API access | ✗ | ✗ | ✓ |
| White-label | ✗ | ✗ | ✓ |
