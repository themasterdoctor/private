#!/bin/bash
# ════════════════════════════════════════════════
# RestaurantOS — Quick Fix for Prisma 7 Error
# Run from: ~/private/private/restaurantos/
# Usage: bash fix.sh
# ════════════════════════════════════════════════

set -e
cd "$(dirname "$0")"
ROOT=$(pwd)

echo "🔧 RestaurantOS Fix Script"
echo "📁 $ROOT"
echo ""

# ── Fix 1: Pin Prisma to 5.x in package.json ──
echo "── Fix 1: Pinning Prisma to 5.12.0 ──"
cat > backend/package.json << 'PKGJSON'
{
  "name": "restaurantos-backend",
  "version": "1.0.0",
  "engines": { "node": ">=18.0.0" },
  "scripts": {
    "dev":         "ts-node-dev --respawn --transpile-only src/index.ts",
    "build":       "tsc",
    "start":       "node dist/index.js",
    "db:generate": "prisma generate",
    "db:migrate":  "prisma migrate dev",
    "db:push":     "prisma db push",
    "seed":        "ts-node --transpile-only src/seed.ts"
  },
  "dependencies": {
    "@anthropic-ai/sdk":     "^0.24.0",
    "@prisma/client":        "5.12.0",
    "bcryptjs":              "^2.4.3",
    "cors":                  "^2.8.5",
    "dotenv":                "^16.4.5",
    "express":               "^4.18.3",
    "express-rate-limit":    "^7.2.0",
    "helmet":                "^7.1.0",
    "jsonwebtoken":          "^9.0.2",
    "morgan":                "^1.10.0",
    "multer":                "^1.4.5-lts.1",
    "resend":                "^3.2.0",
    "stripe":                "^14.21.0",
    "uuid":                  "^9.0.1",
    "winston":               "^3.12.0",
    "zod":                   "^3.22.4"
  },
  "devDependencies": {
    "@types/bcryptjs":       "^2.4.6",
    "@types/cors":           "^2.8.17",
    "@types/express":        "^4.17.21",
    "@types/jsonwebtoken":   "^9.0.6",
    "@types/morgan":         "^1.9.9",
    "@types/multer":         "^1.4.11",
    "@types/node":           "^20.12.4",
    "@types/uuid":           "^9.0.8",
    "prisma":                "5.12.0",
    "ts-node":               "^10.9.2",
    "ts-node-dev":           "^2.0.0",
    "typescript":            "^5.4.4"
  }
}
PKGJSON
echo "✓ package.json pinned to Prisma 5.12.0"

# ── Fix 2: Prisma schema (Prisma 5 format) ────
echo ""
echo "── Fix 2: Updating Prisma schema ──"
# Check if schema already has correct format
if grep -q 'url.*=.*env("DATABASE_URL")' backend/prisma/schema.prisma; then
  echo "✓ Schema already in Prisma 5 format"
else
  # Fix the datasource block
  sed -i 's/datasource db {/datasource db {\n  provider = "postgresql"\n  url      = env("DATABASE_URL")\n}/g' backend/prisma/schema.prisma
  echo "✓ Schema updated"
fi

# ── Fix 3: Create .env ────────────────────────
echo ""
echo "── Fix 3: Environment file ──"
if [ ! -f "$ROOT/.env" ]; then
  cat > "$ROOT/.env" << 'ENVEOF'
DATABASE_URL=postgresql://restaurantos:restaurantos_dev@localhost:5432/restaurantos
JWT_SECRET=dev_jwt_secret_change_in_production_at_least_64_chars_long_random_string
JWT_REFRESH_SECRET=dev_refresh_secret_also_change_64_chars_completely_different_string
STRIPE_SECRET_KEY=sk_test_placeholder
STRIPE_PUBLISHABLE_KEY=pk_test_placeholder
STRIPE_WEBHOOK_SECRET=whsec_placeholder
STRIPE_STARTER_PRICE_ID=price_placeholder
STRIPE_PRO_PRICE_ID=price_placeholder
STRIPE_ENTERPRISE_PRICE_ID=price_placeholder
ANTHROPIC_API_KEY=sk-ant-placeholder
AWS_ACCESS_KEY_ID=placeholder
AWS_SECRET_ACCESS_KEY=placeholder
AWS_BUCKET=restaurantos-uploads
AWS_REGION=us-east-1
RESEND_API_KEY=re_placeholder
FROM_EMAIL=noreply@restaurantos.app
NEXT_PUBLIC_API_URL=http://localhost:4000
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_placeholder
FRONTEND_URL=http://localhost:3000
NODE_ENV=development
LOG_LEVEL=info
PORT=4000
ENVEOF
  echo "✓ Created .env"
else
  echo "✓ .env already exists"
fi

# Always propagate .env to both services
cp "$ROOT/.env" "$ROOT/backend/.env"
cp "$ROOT/.env" "$ROOT/frontend/.env.local" 2>/dev/null || true
echo "✓ .env copied to backend/ and frontend/"

# ── Fix 4: Install Docker ──────────────────────
echo ""
echo "── Fix 4: Docker ──"
if ! command -v docker &>/dev/null; then
  echo "Installing Docker..."
  apt-get update -qq
  apt-get install -y docker.io docker-compose 2>/dev/null || \
    (curl -fsSL https://get.docker.com | sh)
  systemctl enable docker && systemctl start docker 2>/dev/null || true
  echo "✓ Docker installed"
else
  echo "✓ Docker: $(docker --version | cut -d' ' -f3 | tr -d ',')"
fi

# ── Fix 5: Start PostgreSQL ────────────────────
echo ""
echo "── Fix 5: PostgreSQL ──"
if docker ps --format '{{.Names}}' 2>/dev/null | grep -q "restaurantos-postgres"; then
  echo "✓ Postgres container already running"
elif pg_isready -h localhost -p 5432 -q 2>/dev/null; then
  echo "✓ Postgres already running"
else
  echo "Starting Postgres container..."
  docker rm -f restaurantos-postgres 2>/dev/null || true
  docker run -d \
    --name restaurantos-postgres \
    --restart unless-stopped \
    -e POSTGRES_USER=restaurantos \
    -e POSTGRES_PASSWORD=restaurantos_dev \
    -e POSTGRES_DB=restaurantos \
    -p 5432:5432 \
    postgres:16-alpine
  echo -n "Waiting"
  for i in {1..30}; do
    sleep 1; echo -n "."
    docker exec restaurantos-postgres pg_isready -U restaurantos -q 2>/dev/null && break
  done
  echo " ✓"
fi

# ── Fix 6: Install backend deps (correct versions) ──
echo ""
echo "── Fix 6: Backend dependencies ──"
cd "$ROOT/backend"
# Remove any cached prisma 7 from npx
rm -rf ~/.npm/_npx 2>/dev/null || true

echo "Removing any bad node_modules..."
rm -rf node_modules package-lock.json 2>/dev/null || true

echo "Installing (this takes ~60s)..."
npm install --legacy-peer-deps 2>&1 | tail -3

echo "Generating Prisma client (v5)..."
./node_modules/.bin/prisma generate

# ── Fix 7: Run migrations ──────────────────────
echo ""
echo "── Fix 7: Database migrations ──"
./node_modules/.bin/prisma migrate dev --name init --skip-seed 2>/dev/null || \
./node_modules/.bin/prisma db push

# ── Fix 8: Seed data ──────────────────────────
echo ""
echo "── Fix 8: Seeding demo data ──"
./node_modules/.bin/ts-node --transpile-only src/seed.ts

# ── Fix 9: Start backend ──────────────────────
echo ""
echo "── Fix 9: Starting backend ──"
fuser -k 4000/tcp 2>/dev/null || true
sleep 1
nohup npm run dev > /tmp/ros-backend.log 2>&1 &
echo $! > /tmp/ros-backend.pid
echo -n "Waiting for backend"
for i in {1..20}; do
  sleep 1; echo -n "."
  curl -sf http://localhost:4000/health > /dev/null 2>&1 && break
done
if curl -sf http://localhost:4000/health > /dev/null 2>&1; then
  echo " ✓  http://localhost:4000"
else
  echo " ⚠️  Backend may still be starting. Check: tail -f /tmp/ros-backend.log"
fi

# ── Fix 10: Frontend ──────────────────────────
echo ""
echo "── Fix 10: Frontend ──"
cd "$ROOT/frontend"
if [ ! -d node_modules ]; then
  echo "Installing frontend deps..."
  npm install --legacy-peer-deps 2>&1 | tail -3
fi

fuser -k 3000/tcp 2>/dev/null || true
sleep 1

# Dev mode is faster to start than build
nohup npm run dev > /tmp/ros-frontend.log 2>&1 &
echo $! > /tmp/ros-frontend.pid
echo -n "Waiting for frontend"
for i in {1..30}; do
  sleep 2; echo -n "."
  curl -sf http://localhost:3000 > /dev/null 2>&1 && break
done
if curl -sf http://localhost:3000 > /dev/null 2>&1; then
  echo " ✓  http://localhost:3000"
else
  echo " ⚠️  Frontend may still be building. Check: tail -f /tmp/ros-frontend.log"
fi

# ── Summary ───────────────────────────────────
echo ""
SERVER_IP=$(curl -sf --max-time 3 ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')
echo "════════════════════════════════════════════"
echo "✅  RestaurantOS is LIVE!"
echo "════════════════════════════════════════════"
echo ""
echo "  🌐  http://$SERVER_IP:3000     ← App"
echo "  🔧  http://$SERVER_IP:4000/health ← API"
echo ""
echo "  Demo accounts (password: demo1234)"
echo "  👑  owner@kazunori.com"
echo "  👔  manager@kazunori.com"
echo "  👨‍🍳  chef@kazunori.com"
echo ""
echo "  Useful commands:"
echo "  tail -f /tmp/ros-backend.log"
echo "  tail -f /tmp/ros-frontend.log"
echo "  curl http://localhost:4000/health"
echo "════════════════════════════════════════════"
