/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ['Syne', 'sans-serif'],
        body:    ['Instrument Sans', 'sans-serif'],
        mono:    ['JetBrains Mono', 'monospace'],
      },
      colors: {
        bg: {
          DEFAULT: '#0D0D0F',
          1: '#131316',
          2: '#1A1A1E',
          3: '#222228',
          4: '#2C2C34',
        },
        border: {
          DEFAULT: 'rgba(255,255,255,0.06)',
          2:       'rgba(255,255,255,0.10)',
          jade:    'rgba(0,229,160,0.25)',
        },
        text: {
          DEFAULT: '#EEEAE3',
          2: '#8A8680',
          3: '#4A4845',
        },
        jade: {
          DEFAULT: '#00E5A0',
          dark:    '#00C98A',
          dim:     'rgba(0,229,160,0.08)',
        },
        amber:  '#F0A030',
        danger: '#F05050',
        blue:   '#4090F0',
        purple: '#9878F0',
        teal:   '#40B8A0',
        cream:  '#F0EBE2',
      },
      borderRadius: {
        sm:  '4px',
        md:  '8px',
        lg:  '12px',
        xl:  '16px',
        '2xl': '20px',
      },
      boxShadow: {
        jade:  '0 0 20px rgba(0,229,160,0.15)',
        card:  '0 1px 3px rgba(0,0,0,0.4)',
        glow:  '0 0 40px rgba(0,229,160,0.08)',
      },
      backgroundImage: {
        'jade-gradient': 'linear-gradient(135deg, rgba(0,229,160,0.06), rgba(0,229,160,0.02))',
        'grid-pattern': `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='60'%3E%3Cpath d='M 60 0 L 0 0 0 60' fill='none' stroke='rgba(255,255,255,0.03)' stroke-width='1'/%3E%3C/svg%3E")`,
      },
      animation: {
        'fade-up':   'fadeUp 0.18s ease forwards',
        'fade-in':   'fadeIn 0.15s ease forwards',
        'pulse-jade': 'pulseJade 2s ease-in-out infinite',
        'spin-slow':  'spin 3s linear infinite',
      },
      keyframes: {
        fadeUp:    { from: { opacity: '0', transform: 'translateY(6px)' }, to: { opacity: '1', transform: 'none' } },
        fadeIn:    { from: { opacity: '0' }, to: { opacity: '1' } },
        pulseJade: { '0%, 100%': { boxShadow: '0 0 0 0 rgba(0,229,160,0.4)' }, '50%': { boxShadow: '0 0 0 8px rgba(0,229,160,0)' } },
      },
    },
  },
  plugins: [],
};
