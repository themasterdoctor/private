import axios, { AxiosInstance, AxiosError } from 'axios';

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

// ── Create axios instance ──
const api: AxiosInstance = axios.create({
  baseURL: `${BASE_URL}/api`,
  withCredentials: true,
  timeout: 30000,
});

// ── Request interceptor — attach JWT ──
api.interceptors.request.use((config) => {
  const tokens = getTokens();
  if (tokens?.access) {
    config.headers.Authorization = `Bearer ${tokens.access}`;
  }
  return config;
});

// ── Response interceptor — refresh on 401 ──
let isRefreshing = false;
let failedQueue: Array<{ resolve: (v: any) => void; reject: (e: any) => void }> = [];

api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as any;

    if (error.response?.status === 401 && !originalRequest._retry) {
      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        }).then(token => {
          originalRequest.headers.Authorization = `Bearer ${token}`;
          return api(originalRequest);
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        const tokens = getTokens();
        if (!tokens?.refresh) throw new Error('No refresh token');

        const response = await axios.post(`${BASE_URL}/api/auth/refresh`, {
          refreshToken: tokens.refresh,
        });

        const newTokens = response.data.tokens;
        saveTokens(newTokens);

        failedQueue.forEach(q => q.resolve(newTokens.access));
        failedQueue = [];

        originalRequest.headers.Authorization = `Bearer ${newTokens.access}`;
        return api(originalRequest);
      } catch (refreshError) {
        failedQueue.forEach(q => q.reject(refreshError));
        failedQueue = [];
        clearTokens();
        window.location.href = '/login';
        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(error);
  }
);

// ── Token management ──
function getTokens(): { access: string; refresh: string } | null {
  if (typeof window === 'undefined') return null;
  try {
    const stored = localStorage.getItem('ros_tokens');
    return stored ? JSON.parse(stored) : null;
  } catch {
    return null;
  }
}

function saveTokens(tokens: { access: string; refresh: string }) {
  if (typeof window === 'undefined') return;
  localStorage.setItem('ros_tokens', JSON.stringify(tokens));
}

function clearTokens() {
  if (typeof window === 'undefined') return;
  localStorage.removeItem('ros_tokens');
  localStorage.removeItem('ros_org');
  localStorage.removeItem('ros_user');
}

export { api, saveTokens, clearTokens, getTokens };

// ════════════════════════════════════════════════
// API SERVICE METHODS
// ════════════════════════════════════════════════

// ── Auth ──
export const authApi = {
  login:         (data: any)   => api.post('/auth/login', data),
  register:      (data: any)   => api.post('/auth/register', data),
  logout:        (refresh: string) => api.post('/auth/logout', { refreshToken: refresh }),
  me:            ()            => api.get('/auth/me'),
  acceptInvite:  (token: string, data: any) => api.post(`/auth/accept-invite/${token}`, data),
};

// ── Locations ──
export const locationsApi = {
  list:   (orgId: string)        => api.get(`/locations/${orgId}`),
  create: (orgId: string, data: any) => api.post(`/locations/${orgId}`, data),
  update: (locId: string, data: any) => api.patch(`/locations/${locId}`, data),
  delete: (locId: string)        => api.delete(`/locations/${locId}`),
};

// ── Sales ──
export const salesApi = {
  list:   (locId: string, params?: any) => api.get(`/sales/${locId}`, { params }),
  create: (locId: string, data: any)    => api.post(`/sales/${locId}`, data),
  update: (locId: string, entryId: string, data: any) => api.patch(`/sales/${locId}/${entryId}`, data),
  delete: (locId: string, entryId: string) => api.delete(`/sales/${locId}/${entryId}`),
  summary:(locId: string, params?: any) => api.get(`/sales/${locId}/summary`, { params }),
};

// ── Inventory ──
export const inventoryApi = {
  list:       (locId: string, params?: any) => api.get(`/inventory/${locId}`, { params }),
  create:     (locId: string, data: any)    => api.post(`/inventory/${locId}`, data),
  update:     (locId: string, itemId: string, data: any) => api.patch(`/inventory/${locId}/${itemId}`, data),
  delete:     (locId: string, itemId: string) => api.delete(`/inventory/${locId}/${itemId}`),
  adjust:     (locId: string, itemId: string, data: any) => api.post(`/inventory/${locId}/${itemId}/adjust`, data),
  lowStock:   (locId: string)               => api.get(`/inventory/${locId}/low-stock`),
};

// ── Invoices ──
export const invoicesApi = {
  list:       (locId: string, params?: any) => api.get(`/invoices/${locId}`, { params }),
  get:        (locId: string, invId: string) => api.get(`/invoices/${locId}/${invId}`),
  upload:     (locId: string, formData: FormData) => api.post(`/invoices/${locId}/upload`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    timeout: 120000, // 2 min for large files
  }),
  updateLines:(locId: string, invId: string, lineItems: any[]) => api.patch(`/invoices/${locId}/${invId}/line-items`, { lineItems }),
  apply:      (locId: string, invId: string) => api.post(`/invoices/${locId}/${invId}/apply`),
  delete:     (locId: string, invId: string) => api.delete(`/invoices/${locId}/${invId}`),
};

// ── Labor ──
export const laborApi = {
  staff:      { list: (locId: string) => api.get(`/labor/${locId}/staff`), create: (locId: string, d: any) => api.post(`/labor/${locId}/staff`, d), update: (locId: string, id: string, d: any) => api.patch(`/labor/${locId}/staff/${id}`, d), delete: (locId: string, id: string) => api.delete(`/labor/${locId}/staff/${id}`) },
  shifts:     { list: (locId: string, p?: any) => api.get(`/labor/${locId}/shifts`, { params: p }), upsert: (locId: string, d: any) => api.post(`/labor/${locId}/shifts`, d) },
  summary:    (locId: string, p?: any) => api.get(`/labor/${locId}/summary`, { params: p }),
};

// ── Recipes ──
export const recipesApi = {
  list:   (locId: string) => api.get(`/recipes/${locId}`),
  get:    (locId: string, id: string) => api.get(`/recipes/${locId}/${id}`),
  create: (locId: string, d: any) => api.post(`/recipes/${locId}`, d),
  update: (locId: string, id: string, d: any) => api.patch(`/recipes/${locId}/${id}`, d),
  delete: (locId: string, id: string) => api.delete(`/recipes/${locId}/${id}`),
};

// ── Finance ──
export const financeApi = {
  entries: { list: (locId: string, p?: any) => api.get(`/finance/${locId}/entries`, { params: p }), upsert: (locId: string, d: any) => api.post(`/finance/${locId}/entries`, d) },
  calc:    (locId: string, d: any) => api.post(`/finance/${locId}/calculate`, d),
  summary: (locId: string, p?: any) => api.get(`/finance/${locId}/summary`, { params: p }),
};

// ── Valuation ──
export const valuationApi = {
  list:    (locId: string) => api.get(`/valuation/${locId}`),
  calc:    (locId: string, d: any) => api.post(`/valuation/${locId}/calculate`, d),
  save:    (locId: string, d: any) => api.post(`/valuation/${locId}/snapshots`, d),
};

// ── Billing ──
export const billingApi = {
  status:   () => api.get('/billing/status'),
  checkout: (plan: string) => api.post('/billing/checkout', { plan }),
  portal:   () => api.get('/billing/portal'),
};

// ── Alerts ──
export const alertsApi = {
  list:     (locId: string) => api.get(`/alerts/${locId}`),
  markRead: (alertId: string) => api.patch(`/alerts/${alertId}/read`),
};
