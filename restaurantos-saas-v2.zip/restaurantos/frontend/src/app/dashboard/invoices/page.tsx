'use client';

import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Upload, FileText, Check, X, AlertCircle, RefreshCw, ChevronRight, Eye } from 'lucide-react';
import { invoicesApi } from '@/lib/api';
import { useCurrentLocation } from '@/store/appStore';
import { formatCurrency } from '@/lib/utils';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';

type InvoiceStatus = 'PENDING' | 'PROCESSING' | 'REVIEW' | 'APPLIED' | 'REJECTED';

const STATUS_CONFIG: Record<InvoiceStatus, { label: string; color: string; icon: any }> = {
  PENDING:    { label: 'Pending',    color: 'text-text-3 bg-bg-3', icon: RefreshCw },
  PROCESSING: { label: 'Parsing…',  color: 'text-amber bg-amber/10', icon: RefreshCw },
  REVIEW:     { label: 'Review',    color: 'text-blue bg-blue/10', icon: Eye },
  APPLIED:    { label: 'Applied',   color: 'text-jade bg-jade-dim', icon: Check },
  REJECTED:   { label: 'Rejected',  color: 'text-danger bg-danger/10', icon: X },
};

const MAPPING_OPTIONS = [
  { value: 'INVENTORY', label: 'Update Inventory',  desc: 'Add to stock & update cost' },
  { value: 'PURCHASES', label: 'Purchases Only',    desc: 'Count as COGS purchase' },
  { value: 'OVERHEAD',  label: 'Overhead Expense',  desc: 'Delivery, fees, etc.' },
  { value: 'IGNORE',    label: 'Ignore',            desc: 'Skip this line item' },
];

export default function InvoicesPage() {
  const currentLocation = useCurrentLocation();
  const locationId = currentLocation?.id;
  const qc = useQueryClient();

  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);
  const [pollingId, setPollingId] = useState<string | null>(null);

  // ── Fetch invoice list ──
  const { data, isLoading } = useQuery({
    queryKey: ['invoices', locationId],
    queryFn:  () => invoicesApi.list(locationId!).then(r => r.data),
    enabled:  !!locationId,
    refetchInterval: pollingId ? 2000 : false, // poll while processing
  });

  // ── Fetch single invoice for review ──
  const { data: invoiceDetail, isLoading: detailLoading } = useQuery({
    queryKey: ['invoice', locationId, selectedInvoice?.id],
    queryFn:  () => invoicesApi.get(locationId!, selectedInvoice.id).then(r => r.data),
    enabled:  !!selectedInvoice?.id && !!locationId,
  });

  // ── Upload mutation ──
  const uploadMutation = useMutation({
    mutationFn: (file: File) => {
      const fd = new FormData();
      fd.append('file', file);
      return invoicesApi.upload(locationId!, fd).then(r => r.data);
    },
    onSuccess: (data) => {
      toast.success('Invoice uploaded! Parsing in progress…');
      setPollingId(data.invoice.id);
      qc.invalidateQueries({ queryKey: ['invoices', locationId] });
    },
    onError: (err: any) => {
      toast.error(err.response?.data?.error || 'Upload failed');
    },
  });

  // ── Apply mutation ──
  const applyMutation = useMutation({
    mutationFn: (invoiceId: string) => invoicesApi.apply(locationId!, invoiceId).then(r => r.data),
    onSuccess: (data) => {
      toast.success(data.message);
      setSelectedInvoice(null);
      qc.invalidateQueries({ queryKey: ['invoices', locationId] });
      qc.invalidateQueries({ queryKey: ['inventory', locationId] });
    },
    onError: (err: any) => toast.error(err.response?.data?.error || 'Apply failed'),
  });

  // ── Update line items ──
  const updateLinesMutation = useMutation({
    mutationFn: (lineItems: any[]) => invoicesApi.updateLines(locationId!, selectedInvoice.id, lineItems).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['invoice', locationId, selectedInvoice?.id] });
      toast.success('Line items saved');
    },
  });

  // ── Dropzone ──
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles[0]) uploadMutation.mutate(acceptedFiles[0]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': [], 'image/png': [], 'image/webp': [],
      'application/pdf': [], 'text/csv': [],
    },
    maxSize: 20 * 1024 * 1024,
    maxFiles: 1,
  });

  // Poll until REVIEW or REJECTED
  if (pollingId && data?.invoices) {
    const inv = data.invoices.find((i: any) => i.id === pollingId);
    if (inv && ['REVIEW', 'APPLIED', 'REJECTED'].includes(inv.status)) {
      setPollingId(null);
      if (inv.status === 'REVIEW') setSelectedInvoice(inv);
    }
  }

  const invoices = data?.invoices || [];

  if (selectedInvoice && invoiceDetail) {
    return <ReviewPanel invoice={invoiceDetail} onClose={() => setSelectedInvoice(null)}
      onApply={() => applyMutation.mutate(selectedInvoice.id)}
      onSaveLines={updateLinesMutation.mutate}
      applying={applyMutation.isPending}
      saving={updateLinesMutation.isPending} />;
  }

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Upload zone */}
      <div className="card">
        <div className="card-header mb-3">
          <h3 className="card-title">Upload Supplier Invoice</h3>
          <span className="text-xs text-text-3">PDF, JPG, PNG, CSV · max 20MB · AI-powered extraction</span>
        </div>

        <div
          {...getRootProps()}
          className={cn(
            'border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition-all duration-200',
            isDragActive
              ? 'border-jade bg-jade-dim'
              : 'border-border-2 hover:border-jade hover:bg-jade-dim/50',
            uploadMutation.isPending && 'pointer-events-none opacity-60',
          )}
        >
          <input {...getInputProps()} />
          {uploadMutation.isPending ? (
            <div className="flex flex-col items-center gap-3">
              <div className="w-10 h-10 border-2 border-jade border-t-transparent rounded-full animate-spin" />
              <p className="text-sm text-jade font-medium">Uploading & parsing invoice…</p>
              <p className="text-xs text-text-3">This may take 15–30 seconds</p>
            </div>
          ) : pollingId ? (
            <div className="flex flex-col items-center gap-3">
              <div className="w-10 h-10 border-2 border-amber border-t-transparent rounded-full animate-spin" />
              <p className="text-sm text-amber font-medium">AI is reading your invoice…</p>
              <p className="text-xs text-text-3">Extracting line items, quantities, and prices</p>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-jade-dim border border-border-jade flex items-center justify-center">
                <Upload size={22} className="text-jade" />
              </div>
              <div>
                <p className="text-sm font-medium text-cream mb-1">
                  {isDragActive ? 'Drop your invoice here' : 'Drop invoice here or click to upload'}
                </p>
                <p className="text-xs text-text-3">
                  AI will extract vendor, date, items, quantities, and prices automatically
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Feature chips */}
        <div className="flex flex-wrap gap-2 mt-3">
          {['Extracts all line items', 'Detects vendor & date', 'Categorizes products', 'You review before applying'].map(f => (
            <span key={f} className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full bg-bg-2 text-text-3 border border-border">
              <Check size={10} className="text-jade" /> {f}
            </span>
          ))}
        </div>
      </div>

      {/* Invoice list */}
      <div className="card">
        <div className="card-header mb-3">
          <h3 className="card-title">Invoice History</h3>
          <span className="text-xs text-text-3">{invoices.length} invoices</span>
        </div>

        {isLoading ? (
          <div className="py-8 text-center text-text-3 text-sm">Loading…</div>
        ) : invoices.length === 0 ? (
          <div className="py-12 text-center">
            <FileText size={32} className="mx-auto text-text-3 mb-3" />
            <p className="text-sm text-text-2">No invoices yet</p>
            <p className="text-xs text-text-3 mt-1">Upload your first supplier invoice above</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="th-cell">Vendor</th>
                  <th className="th-cell">Invoice #</th>
                  <th className="th-cell">Date</th>
                  <th className="th-cell">Total</th>
                  <th className="th-cell">Items</th>
                  <th className="th-cell">Status</th>
                  <th className="th-cell"></th>
                </tr>
              </thead>
              <tbody>
                {invoices.map((inv: any) => {
                  const cfg = STATUS_CONFIG[inv.status as InvoiceStatus];
                  const Icon = cfg.icon;
                  return (
                    <tr key={inv.id} className="border-b border-border hover:bg-bg-2 transition-colors">
                      <td className="td-cell font-medium text-cream">
                        {inv.vendorName || <span className="text-text-3">Unknown vendor</span>}
                      </td>
                      <td className="td-cell font-mono text-xs text-text-2">
                        {inv.invoiceNumber || '—'}
                      </td>
                      <td className="td-cell text-text-2 text-xs">
                        {inv.invoiceDate ? new Date(inv.invoiceDate).toLocaleDateString() : inv.createdAt ? new Date(inv.createdAt).toLocaleDateString() : '—'}
                      </td>
                      <td className="td-cell font-mono">
                        {inv.totalAmount ? formatCurrency(inv.totalAmount) : '—'}
                      </td>
                      <td className="td-cell text-text-3">
                        {inv._count?.lineItems || 0} items
                      </td>
                      <td className="td-cell">
                        <span className={cn('inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium', cfg.color)}>
                          <Icon size={10} className={inv.status === 'PROCESSING' ? 'animate-spin' : ''} />
                          {cfg.label}
                        </span>
                      </td>
                      <td className="td-cell">
                        {inv.status === 'REVIEW' && (
                          <button
                            onClick={() => setSelectedInvoice(inv)}
                            className="btn-jade text-xs px-3 py-1 rounded-lg flex items-center gap-1"
                          >
                            Review <ChevronRight size={12} />
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Review Panel ──────────────────────────────────
function ReviewPanel({ invoice, onClose, onApply, onSaveLines, applying, saving }: any) {
  const [lineItems, setLineItems] = useState<any[]>(invoice.lineItems || []);

  const totalApplied = lineItems
    .filter(li => li.mapping !== 'IGNORE')
    .reduce((a: number, li: any) => a + (li.totalPrice || 0), 0);

  const updateItem = (index: number, field: string, value: any) => {
    const updated = [...lineItems];
    updated[index] = { ...updated[index], [field]: value };
    if (field === 'quantity' || field === 'unitPrice') {
      updated[index].totalPrice = updated[index].quantity * updated[index].unitPrice;
    }
    setLineItems(updated);
  };

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="font-display text-xl font-bold text-cream">Review Invoice</h2>
          <p className="text-sm text-text-2 mt-1">
            {invoice.vendorName || 'Unknown vendor'} · {invoice.invoiceNumber || 'No invoice #'} · {formatCurrency(invoice.totalAmount || 0)}
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={onClose} className="btn-ghost btn-sm">← Back</button>
          <button
            onClick={() => onSaveLines(lineItems.map(li => ({ id: li.id, mapping: li.mapping, inventoryItemId: li.inventoryItemId, quantity: li.quantity, unitPrice: li.unitPrice })))}
            disabled={saving}
            className="btn btn-sm"
          >
            {saving ? 'Saving…' : 'Save Changes'}
          </button>
          <button
            onClick={onApply}
            disabled={applying}
            className="btn-jade btn-sm flex items-center gap-1.5"
          >
            {applying ? 'Applying…' : <>Apply to Inventory <Check size={13} /></>}
          </button>
        </div>
      </div>

      {/* Invoice summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Vendor',         value: invoice.vendorName || 'Unknown' },
          { label: 'Invoice #',      value: invoice.invoiceNumber || '—' },
          { label: 'Invoice Date',   value: invoice.invoiceDate ? new Date(invoice.invoiceDate).toLocaleDateString() : '—' },
          { label: 'Invoice Total',  value: formatCurrency(invoice.totalAmount || 0) },
        ].map(item => (
          <div key={item.label} className="bg-bg-2 rounded-lg p-3 border border-border">
            <div className="text-[10px] text-text-3 uppercase tracking-wider mb-1">{item.label}</div>
            <div className="text-sm font-medium text-cream">{item.value}</div>
          </div>
        ))}
      </div>

      {/* Line items */}
      <div className="card">
        <div className="card-header mb-3">
          <h3 className="card-title">Line Items — Review & Map</h3>
          <div className="text-xs text-text-3">
            <span className="text-jade font-mono">{formatCurrency(totalApplied)}</span> will be applied
          </div>
        </div>

        <div className="bg-jade-dim border border-border-jade rounded-lg p-3 mb-4 text-xs text-jade flex items-start gap-2">
          <AlertCircle size={14} className="flex-shrink-0 mt-0.5" />
          <span>Review each line item before applying. Set mapping to "Update Inventory" to add stock, "Purchases Only" to count as COGS, or "Ignore" to skip.</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="th-cell">Description</th>
                <th className="th-cell">Category</th>
                <th className="th-cell">Unit</th>
                <th className="th-cell">Qty</th>
                <th className="th-cell">$/Unit</th>
                <th className="th-cell">Total</th>
                <th className="th-cell">Map To</th>
              </tr>
            </thead>
            <tbody>
              {lineItems.map((item: any, i: number) => (
                <tr key={item.id} className={cn(
                  'border-b border-border transition-colors',
                  item.mapping === 'IGNORE' ? 'opacity-40' : 'hover:bg-bg-2'
                )}>
                  <td className="td-cell font-medium">{item.description}</td>
                  <td className="td-cell">
                    <span className="text-xs text-text-3 bg-bg-3 px-2 py-0.5 rounded">
                      {item.inventoryItem?.category || '—'}
                    </span>
                  </td>
                  <td className="td-cell text-text-3 text-xs">{item.unit || '—'}</td>
                  <td className="td-cell">
                    <input
                      type="number"
                      value={item.quantity}
                      onChange={e => updateItem(i, 'quantity', parseFloat(e.target.value))}
                      className="w-16 bg-bg-3 border border-border rounded px-2 py-1 font-mono text-xs text-center"
                    />
                  </td>
                  <td className="td-cell">
                    <input
                      type="number"
                      value={item.unitPrice}
                      onChange={e => updateItem(i, 'unitPrice', parseFloat(e.target.value))}
                      className="w-20 bg-bg-3 border border-border rounded px-2 py-1 font-mono text-xs text-right"
                      step="0.01"
                    />
                  </td>
                  <td className="td-cell font-mono text-jade">
                    {formatCurrency(item.totalPrice || 0)}
                  </td>
                  <td className="td-cell">
                    <select
                      value={item.mapping}
                      onChange={e => updateItem(i, 'mapping', e.target.value)}
                      className="bg-bg-3 border border-border rounded px-2 py-1 text-xs text-text-2 w-36"
                    >
                      {MAPPING_OPTIONS.map(opt => (
                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                      ))}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-border-2">
                <td className="td-cell font-semibold text-cream" colSpan={5}>Invoice Total</td>
                <td className="td-cell font-mono font-bold text-jade">{formatCurrency(invoice.totalAmount || 0)}</td>
                <td />
              </tr>
              <tr>
                <td className="td-cell text-text-3 text-xs" colSpan={5}>Will be applied to COGS/Inventory</td>
                <td className="td-cell font-mono text-xs text-text-2">{formatCurrency(totalApplied)}</td>
                <td />
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
}
