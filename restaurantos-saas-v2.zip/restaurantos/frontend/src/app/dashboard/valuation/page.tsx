'use client';

import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { BarChart, Bar, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Save, TrendingUp } from 'lucide-react';
import { valuationApi } from '@/lib/api';
import { useCurrentLocation } from '@/store/appStore';
import { formatCurrency, cn } from '@/lib/utils';
import toast from 'react-hot-toast';

const defaults = {
  netProfit: 6200, periodMultiplier: 12,
  ownerSalary: 72000, interest: 6000, depreciation: 8400,
  annualRevenue: 1020000, ebitda: 98400, ebitdaMultiple: 3.5,
};

export default function ValuationPage() {
  const currentLocation = useCurrentLocation();
  const locationId = currentLocation?.id;
  const [inp, setInp] = useState(defaults);

  const annualNP    = inp.netProfit * inp.periodMultiplier;
  const sde         = annualNP + inp.ownerSalary + inp.interest + inp.depreciation;
  const sdeLow      = sde * 2;
  const sdeHigh     = sde * 3;
  const revLow      = inp.annualRevenue * 0.5;
  const revHigh     = inp.annualRevenue * 0.7;
  const ebitdaVal   = inp.ebitda * inp.ebitdaMultiple;
  const allVals     = [sdeLow, sdeHigh, revLow, revHigh, ebitdaVal].filter(v => v > 0);
  const consLow     = allVals.length ? Math.min(...allVals) : 0;
  const consHigh    = allVals.length ? Math.max(...allVals) : 0;
  const midpoint    = (consLow + consHigh) / 2;

  const s = (k: keyof typeof defaults) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setInp(p => ({ ...p, [k]: parseFloat(e.target.value) || 0 }));

  const saveMutation = useMutation({
    mutationFn: () => valuationApi.save(locationId!, { ...inp, sdeLow, sdeHigh, revMultipleLow: revLow, revMultipleHigh: revHigh, ebitdaValue: ebitdaVal, consensusLow: consLow, consensusHigh: consHigh, sde, annualNetProfit: annualNP }),
    onSuccess: () => toast.success('Valuation snapshot saved'),
    onError:   () => toast.error('Failed to save'),
  });

  const chartData = [
    { name: 'SDE Low',  value: Math.round(sdeLow),    color: 'rgba(0,229,160,0.4)' },
    { name: 'SDE High', value: Math.round(sdeHigh),   color: '#00E5A0' },
    { name: 'Rev Low',  value: Math.round(revLow),     color: 'rgba(64,144,240,0.4)' },
    { name: 'Rev High', value: Math.round(revHigh),    color: '#4090F0' },
    { name: 'EBITDA',   value: Math.round(ebitdaVal),  color: '#9878F0' },
  ];

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Consensus banner */}
      <div className="bg-jade-gradient border border-border-jade rounded-2xl p-6">
        <div className="text-[10px] font-semibold text-jade uppercase tracking-widest mb-2">Estimated Business Value</div>
        <div className="font-display text-4xl font-black text-jade mb-1">
          {formatCurrency(consLow)} – {formatCurrency(consHigh)}
        </div>
        <div className="text-sm text-text-2">
          Midpoint: <span className="font-mono text-cream">{formatCurrency(midpoint)}</span>
          &nbsp;·&nbsp; SDE: <span className="font-mono text-text">{formatCurrency(sde)}</span>
          &nbsp;·&nbsp; Annual Net Profit: <span className="font-mono text-text">{formatCurrency(annualNP)}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Inputs */}
        <div className="space-y-4">
          <div className="card">
            <h3 className="card-title mb-4">Net Profit Inputs</h3>
            <div className="field mb-3">
              <label className="block text-[11px] text-text-3 mb-1">Annualize from</label>
              <select value={inp.periodMultiplier}
                onChange={e => setInp(p => ({ ...p, periodMultiplier: parseInt(e.target.value) }))}
                className="w-full bg-bg-2 border border-border rounded-lg px-3 py-2 text-sm text-cream outline-none focus:border-jade">
                <option value={12}>Monthly × 12</option>
                <option value={4}>Quarterly × 4</option>
                <option value={1}>Already Annual</option>
              </select>
            </div>
            <VInput label={`Net Profit (${inp.periodMultiplier===12?'monthly':inp.periodMultiplier===4?'quarterly':'annual'} $)`}
              value={inp.netProfit} onChange={s('netProfit')} note={`→ Annual: ${formatCurrency(annualNP)}`} />
          </div>

          <div className="card">
            <h3 className="card-title mb-4">SDE Add-Backs</h3>
            <p className="text-xs text-text-3 mb-4">
              Seller's Discretionary Earnings adds back non-cash and owner-specific costs to show true earning power.
            </p>
            <div className="space-y-3">
              <VInput label="Owner Salary ($)" value={inp.ownerSalary} onChange={s('ownerSalary')} />
              <VInput label="Interest Expense ($)" value={inp.interest} onChange={s('interest')} />
              <VInput label="Depreciation ($)" value={inp.depreciation} onChange={s('depreciation')} />
            </div>
            <div className="mt-4 pt-3 border-t border-border flex justify-between text-sm">
              <span className="text-text-2">SDE = Annual NP + Add-Backs</span>
              <span className="font-mono font-bold text-jade">{formatCurrency(sde)}</span>
            </div>
          </div>

          <div className="card">
            <h3 className="card-title mb-4">Revenue & EBITDA</h3>
            <div className="space-y-3">
              <VInput label="Annual Revenue ($)" value={inp.annualRevenue} onChange={s('annualRevenue')} />
              <VInput label="EBITDA ($)" value={inp.ebitda} onChange={s('ebitda')} />
              <div>
                <div className="flex justify-between mb-1">
                  <label className="text-[11px] text-text-3">EBITDA Multiple: <span className="text-cream font-mono">{inp.ebitdaMultiple}×</span></label>
                </div>
                <input type="range" min="1.5" max="6" step="0.5"
                  value={inp.ebitdaMultiple}
                  onChange={e => setInp(p => ({ ...p, ebitdaMultiple: parseFloat(e.target.value) }))}
                  className="w-full accent-jade" />
                <div className="flex justify-between text-[10px] text-text-3 mt-1">
                  <span>1.5× (distressed)</span><span>3.5× (typical)</span><span>6× (premium)</span>
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={() => saveMutation.mutate()}
            disabled={saveMutation.isPending || !locationId}
            className="btn-jade w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold"
          >
            <Save size={15} />
            {saveMutation.isPending ? 'Saving…' : 'Save Valuation Snapshot'}
          </button>
        </div>

        {/* Results */}
        <div className="space-y-4">
          {/* Method cards */}
          {[
            { method: 'SDE Multiple (2×–3×)', low: sdeLow, high: sdeHigh, color: '#00E5A0',
              note: `SDE ${formatCurrency(sde)} × 2 to 3` },
            { method: 'Revenue Multiple (0.5×–0.7×)', low: revLow, high: revHigh, color: '#4090F0',
              note: `Revenue ${formatCurrency(inp.annualRevenue)} × 0.5 to 0.7` },
            { method: `EBITDA Multiple (${inp.ebitdaMultiple}×)`, low: ebitdaVal, high: ebitdaVal, color: '#9878F0',
              note: `EBITDA ${formatCurrency(inp.ebitda)} × ${inp.ebitdaMultiple}` },
          ].map(m => (
            <div key={m.method} className="bg-bg-1 border border-border rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="text-xs font-semibold text-text-2">{m.method}</div>
                <div className="text-[11px] text-text-3">{m.note}</div>
              </div>
              <div className="flex items-end gap-4">
                <div>
                  <div className="text-[10px] text-text-3 mb-1">Low</div>
                  <div className="font-display text-xl font-bold" style={{ color: m.color }}>{formatCurrency(m.low)}</div>
                </div>
                {m.low !== m.high && (
                  <div>
                    <div className="text-[10px] text-text-3 mb-1">High</div>
                    <div className="font-display text-xl font-bold" style={{ color: m.color }}>{formatCurrency(m.high)}</div>
                  </div>
                )}
              </div>
              <div className="mt-3 h-1.5 bg-bg-3 rounded-full overflow-hidden">
                <div className="h-full rounded-full" style={{ width: `${(m.high / (consHigh || 1)) * 100}%`, background: m.color, opacity: 0.7 }} />
              </div>
            </div>
          ))}

          {/* Chart */}
          <div className="card">
            <h3 className="card-title mb-4">Method Comparison</h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={chartData} barSize={32}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#4A4845' }} axisLine={false} tickLine={false} />
                <YAxis tickFormatter={v => `$${Math.round(v/1000)}k`} tick={{ fontSize: 10, fill: '#4A4845' }} axisLine={false} tickLine={false} />
                <Tooltip formatter={(v: any) => [formatCurrency(v), 'Value']} />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {chartData.map((d, i) => <Cell key={i} fill={d.color} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Disclaimer */}
          <div className="bg-bg-2 border border-border rounded-xl p-4 text-xs text-text-3">
            <strong className="text-text-2">Disclaimer:</strong> This is an estimated range based on common restaurant valuation methods.
            Actual value depends on lease terms, equipment, brand, staff retention, and market conditions.
            Consult a business broker or M&A advisor for a formal valuation.
          </div>
        </div>
      </div>
    </div>
  );
}

function VInput({ label, value, onChange, note }: { label: string; value: number; onChange: any; note?: string }) {
  return (
    <div>
      <div className="flex justify-between mb-1">
        <label className="text-[11px] text-text-3">{label}</label>
        {note && <span className="text-[11px] text-jade">{note}</span>}
      </div>
      <input type="number" value={value} onChange={onChange}
        className="w-full bg-bg-2 border border-border rounded-lg px-3 py-2 text-sm text-cream outline-none focus:border-jade transition-colors" />
    </div>
  );
}
