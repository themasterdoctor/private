'use client';

import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { BarChart, Bar, Cell, ResponsiveContainer, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import { Calculator, BookOpen, Plus, Trash2, AlertTriangle, CheckCircle } from 'lucide-react';
import { financeApi, recipesApi } from '@/lib/api';
import { useCurrentLocation } from '@/store/appStore';
import { formatCurrency, formatPct, cn } from '@/lib/utils';
import toast from 'react-hot-toast';

interface COGSState {
  grossSales:          number;
  discounts:           number;
  comps:               number;
  otherIncome:         number;
  beginningInventory:  number;
  purchases:           number;
  endingInventory:     number;
}

export default function FoodCostPage() {
  const currentLocation = useCurrentLocation();
  const locationId = currentLocation?.id;

  const [cogs, setCogs] = useState<COGSState>({
    grossSales: 87500, discounts: 2000, comps: 500, otherIncome: 0,
    beginningInventory: 12000, purchases: 22500, endingInventory: 10530,
  });

  // Computed
  const netSales     = Math.max(0, cogs.grossSales - cogs.discounts - cogs.comps);
  const totalRevenue = netSales + cogs.otherIncome;
  const cogsValue    = Math.max(0, cogs.beginningInventory + cogs.purchases - cogs.endingInventory);
  const foodCostPct  = totalRevenue > 0 ? (cogsValue / totalRevenue) * 100 : 0;
  const grossProfit  = totalRevenue - cogsValue;
  const gpPct        = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;

  const { data: recipes, isLoading: recipesLoading } = useQuery({
    queryKey: ['recipes', locationId],
    queryFn:  () => recipesApi.list(locationId!).then(r => r.data),
    enabled:  !!locationId,
  });

  const recipeList = recipes?.recipes || DEMO_RECIPES;

  const fcColor = foodCostPct <= 30 ? '#00E5A0' : foodCostPct <= 35 ? '#F0A030' : '#F05050';

  return (
    <div className="space-y-5 animate-fade-in">
      {/* KPI row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <MetricCard label="Net Sales"    value={formatCurrency(netSales)}  color="jade"   note={`from $${(cogs.grossSales/1000).toFixed(0)}k gross`} />
        <MetricCard label="COGS"         value={formatCurrency(cogsValue)} color="default" note="Begin + Purch − End" />
        <MetricCard label="Food Cost %"  value={formatPct(foodCostPct)}    color={foodCostPct<=30?'jade':foodCostPct<=35?'amber':'danger'} note={foodCostPct<=30?'✓ Healthy':foodCostPct<=35?'⚠ Watch':'✗ High Risk'} />
        <MetricCard label="Gross Profit" value={formatCurrency(grossProfit)} color="jade"   note={formatPct(gpPct) + ' margin'} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* COGS Calculator */}
        <div className="card">
          <div className="card-header mb-4">
            <h3 className="card-title flex items-center gap-2"><Calculator size={14} />COGS Calculator</h3>
          </div>

          {/* Net Sales block */}
          <div className="bg-jade-gradient border border-border-jade rounded-xl p-4 mb-5">
            <div className="text-[10px] font-semibold text-jade uppercase tracking-widest mb-3">Net Sales</div>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <InputField label="Gross Sales ($)" value={cogs.grossSales}
                onChange={v => setCogs(p => ({ ...p, grossSales: v }))} />
              <InputField label="Discounts ($)" value={cogs.discounts}
                onChange={v => setCogs(p => ({ ...p, discounts: v }))} />
              <InputField label="Comps ($)" value={cogs.comps}
                onChange={v => setCogs(p => ({ ...p, comps: v }))} />
              <InputField label="Other Income ($)" value={cogs.otherIncome}
                onChange={v => setCogs(p => ({ ...p, otherIncome: v }))} />
            </div>
            <div className="flex items-center justify-between pt-3 border-t border-border-jade">
              <div className="text-xs text-text-2">Net Sales = Gross − Discounts − Comps</div>
              <div className="font-display text-xl font-bold text-jade">{formatCurrency(netSales)}</div>
            </div>
          </div>

          {/* Inventory period */}
          <div className="mb-4">
            <div className="text-[10px] font-semibold text-text-3 uppercase tracking-widest mb-3">Inventory Period</div>
            <div className="grid grid-cols-3 gap-3 mb-3">
              <div className="bg-bg-2 border border-border rounded-xl p-3">
                <div className="text-[10px] text-text-3 uppercase tracking-wider mb-2">Beginning Inv.</div>
                <input
                  type="number"
                  value={cogs.beginningInventory}
                  onChange={e => setCogs(p => ({ ...p, beginningInventory: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-transparent border-none outline-none font-display text-lg font-bold text-cream p-0"
                />
                <div className="text-[10px] text-text-3 mt-1">Opening stock</div>
              </div>
              <div className="bg-bg-2 border border-border rounded-xl p-3">
                <div className="text-[10px] text-text-3 uppercase tracking-wider mb-2">Purchases</div>
                <input
                  type="number"
                  value={cogs.purchases}
                  onChange={e => setCogs(p => ({ ...p, purchases: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-transparent border-none outline-none font-display text-lg font-bold text-cream p-0"
                />
                <div className="text-[10px] text-text-3 mt-1">From invoices</div>
              </div>
              <div className="bg-bg-2 border border-border rounded-xl p-3">
                <div className="text-[10px] text-text-3 uppercase tracking-wider mb-2">Ending Inv.</div>
                <input
                  type="number"
                  value={cogs.endingInventory}
                  onChange={e => setCogs(p => ({ ...p, endingInventory: parseFloat(e.target.value) || 0 }))}
                  className="w-full bg-transparent border-none outline-none font-display text-lg font-bold text-cream p-0"
                />
                <div className="text-[10px] text-text-3 mt-1">Closing stock</div>
              </div>
            </div>
          </div>

          {/* Result card */}
          <div className="bg-bg-2 rounded-xl p-4 flex items-center justify-between border border-border">
            <div>
              <div className="text-[10px] text-text-3 uppercase tracking-widest mb-1">
                COGS = Begin + Purchases − Ending
              </div>
              <div className="font-display text-3xl font-bold" style={{ color: fcColor }}>
                {formatCurrency(cogsValue)}
              </div>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-text-3 mb-1">Food Cost %</div>
              <div className="font-display text-2xl font-bold" style={{ color: fcColor }}>
                {formatPct(foodCostPct)}
              </div>
              <div className="text-xs mt-1" style={{ color: fcColor }}>
                {foodCostPct <= 30 ? '✓ Healthy' : foodCostPct <= 35 ? '⚠ Watch' : '✗ High Risk'}
              </div>
            </div>
          </div>
        </div>

        {/* Recipe Library */}
        <div className="card">
          <div className="card-header mb-4">
            <h3 className="card-title flex items-center gap-2"><BookOpen size={14} />Recipe Library</h3>
            <span className="text-xs text-text-3">{recipeList.length} items</span>
          </div>
          <div className="grid grid-cols-2 gap-2.5 mb-4 max-h-72 overflow-y-auto pr-1">
            {recipeList.map((r: any) => {
              const pct = r.totalIngredientCost && r.menuPrice
                ? (r.totalIngredientCost / r.menuPrice) * 100
                : r.foodCostPct || 0;
              const col = pct <= 30 ? '#00E5A0' : pct <= 35 ? '#F0A030' : '#F05050';
              return (
                <div key={r.id || r.name} className="bg-bg-2 border border-border rounded-xl p-3 hover:border-border-2 transition-colors cursor-pointer">
                  <div className="text-xl mb-1">{r.emoji || '🍱'}</div>
                  <div className="text-xs font-semibold text-cream mb-1 truncate">{r.name}</div>
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-text-3">{formatCurrency(r.menuPrice || r.sell || 0)}</span>
                    <span className="font-mono font-bold" style={{ color: col }}>{formatPct(pct)}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Chart */}
          <div>
            <div className="text-[10px] text-text-3 uppercase tracking-widest mb-3">Food Cost % by Item</div>
            <ResponsiveContainer width="100%" height={140}>
              <BarChart data={recipeList.map((r: any) => ({
                name: (r.name || '').split(' ').slice(0,2).join(' '),
                pct:  r.foodCostPct || (r.totalIngredientCost && r.menuPrice ? (r.totalIngredientCost/r.menuPrice)*100 : 0),
              }))} barSize={18}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#4A4845' }} axisLine={false} tickLine={false} angle={-35} textAnchor="end" height={40} />
                <YAxis domain={[0, 45]} tickFormatter={v => `${v}%`} tick={{ fontSize: 10, fill: '#4A4845' }} axisLine={false} tickLine={false} />
                <Tooltip formatter={(v: any) => [formatPct(v), 'Food Cost']} />
                <Bar dataKey="pct" radius={[3, 3, 0, 0]}>
                  {recipeList.map((r: any, i: number) => {
                    const p = r.foodCostPct || 0;
                    return <Cell key={i} fill={p <= 30 ? '#00E5A0' : p <= 35 ? '#F0A030' : '#F05050'} />;
                  })}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Helpers ──
function MetricCard({ label, value, color, note }: any) {
  const colorMap: Record<string, string> = { jade: 'text-jade', amber: 'text-amber', danger: 'text-danger', default: 'text-cream' };
  return (
    <div className="bg-bg-1 border border-border rounded-xl p-4">
      <div className="text-[11px] text-text-3 mb-2">{label}</div>
      <div className={cn('font-display text-xl font-bold mb-1', colorMap[color] || 'text-cream')}>{value}</div>
      {note && <div className={cn('text-[11px]', colorMap[color] || 'text-text-3')}>{note}</div>}
    </div>
  );
}

function InputField({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div>
      <label className="block text-[11px] text-text-3 mb-1">{label}</label>
      <input
        type="number"
        value={value}
        onChange={e => onChange(parseFloat(e.target.value) || 0)}
        className="w-full bg-bg-2 border border-border rounded-lg px-3 py-2 text-sm text-cream outline-none focus:border-jade transition-colors"
      />
    </div>
  );
}

// ── Demo data ──
const DEMO_RECIPES = [
  { name: 'Cucumber Roll',  emoji: '🥒', menuPrice: 6.50,  totalIngredientCost: 0.55,  foodCostPct: 8.5  },
  { name: 'Bay Scallop',    emoji: '🦪', menuPrice: 7.00,  totalIngredientCost: 1.96,  foodCostPct: 28.0 },
  { name: 'Shrimp Roll',    emoji: '🍤', menuPrice: 7.25,  totalIngredientCost: 0.91,  foodCostPct: 12.6 },
  { name: 'Albacore Roll',  emoji: '🐟', menuPrice: 7.75,  totalIngredientCost: 1.33,  foodCostPct: 17.2 },
  { name: 'Toro Roll',      emoji: '🐟', menuPrice: 7.75,  totalIngredientCost: 1.33,  foodCostPct: 17.2 },
  { name: 'NZ Sea Bream',   emoji: '🐠', menuPrice: 7.75,  totalIngredientCost: 1.40,  foodCostPct: 18.1 },
  { name: 'Yellowtail',     emoji: '🐡', menuPrice: 7.75,  totalIngredientCost: 1.08,  foodCostPct: 13.9 },
  { name: 'Crab Roll',      emoji: '🦀', menuPrice: 8.00,  totalIngredientCost: 1.21,  foodCostPct: 15.1 },
  { name: 'Lobster Roll',   emoji: '🦞', menuPrice: 11.00, totalIngredientCost: 1.75,  foodCostPct: 15.9 },
];
