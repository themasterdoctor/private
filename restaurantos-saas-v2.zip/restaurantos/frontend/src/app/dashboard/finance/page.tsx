'use client';

import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { Save, TrendingUp, TrendingDown } from 'lucide-react';
import { financeApi } from '@/lib/api';
import { useCurrentLocation } from '@/store/appStore';
import { formatCurrency, formatPct, getPctColor, cn } from '@/lib/utils';
import toast from 'react-hot-toast';

const defaultInputs = {
  grossSales: 87500, discounts: 2000, comps: 500, otherIncome: 0,
  beginningInventory: 12000, purchases: 22500, endingInventory: 10530,
  hourlyWages: 18000, salaryWages: 7500, payrollTax: 3800, benefits: 0,
  rent: 8500, utilities: 2200, insurance: 900, marketing: 1200,
  repairs: 400, softwarePos: 300, licenses: 200, creditCardFees: 850,
  deliveryFees: 600, otherExpenses: 300,
};

export default function FinancePage() {
  const currentLocation = useCurrentLocation();
  const locationId = currentLocation?.id;
  const [inputs, setInputs] = useState(defaultInputs);

  // ── Computed (live, no API call needed) ──
  const netSales   = Math.max(0, inputs.grossSales - inputs.discounts - inputs.comps);
  const totalRev   = netSales + inputs.otherIncome;
  const cogs       = Math.max(0, inputs.beginningInventory + inputs.purchases - inputs.endingInventory);
  const totalLabor = inputs.hourlyWages + inputs.salaryWages + inputs.payrollTax + inputs.benefits;
  const totalOpex  = inputs.rent + inputs.utilities + inputs.insurance + inputs.marketing +
                     inputs.repairs + inputs.softwarePos + inputs.licenses +
                     inputs.creditCardFees + inputs.deliveryFees + inputs.otherExpenses;
  const grossProfit  = totalRev - cogs;
  const ebitda       = grossProfit - totalLabor - totalOpex;
  const netProfit    = ebitda;
  const foodCostPct  = totalRev > 0 ? cogs / totalRev * 100 : 0;
  const laborCostPct = totalRev > 0 ? totalLabor / totalRev * 100 : 0;
  const primeCost    = cogs + totalLabor;
  const primeCostPct = totalRev > 0 ? primeCost / totalRev * 100 : 0;
  const netMarginPct = totalRev > 0 ? netProfit / totalRev * 100 : 0;
  const gpPct        = totalRev > 0 ? grossProfit / totalRev * 100 : 0;
  const fixedCosts   = inputs.rent + inputs.utilities + inputs.insurance + inputs.softwarePos + inputs.licenses;
  const varPct       = totalRev > 0 ? (cogs + totalLabor) / totalRev : 0;
  const breakEven    = varPct < 1 ? fixedCosts / (1 - varPct) : 0;
  const breakEvenGap = netSales - breakEven;

  const set = (key: keyof typeof defaultInputs) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setInputs(p => ({ ...p, [key]: parseFloat(e.target.value) || 0 }));

  const saveMutation = useMutation({
    mutationFn: () => financeApi.entries.upsert(locationId!, {
      periodStart: new Date(new Date().setDate(1)).toISOString().slice(0, 10),
      periodEnd:   new Date().toISOString().slice(0, 10),
      periodType:  'MONTHLY',
      ...inputs,
    }).then(r => r.data),
    onSuccess: () => toast.success('P&L saved successfully'),
    onError:   () => toast.error('Failed to save'),
  });

  const pieData = [
    { name: 'Food Cost',   value: Math.round(cogs),       color: '#F05050' },
    { name: 'Labor',       value: Math.round(totalLabor), color: '#4090F0' },
    { name: 'Rent',        value: inputs.rent,             color: '#9878F0' },
    { name: 'Utilities',   value: inputs.utilities,        color: '#F0A030' },
    { name: 'Insurance',   value: inputs.insurance,        color: '#40B8A0' },
    { name: 'Marketing',   value: inputs.marketing,        color: '#00E5A0' },
    { name: 'Other',       value: inputs.creditCardFees + inputs.deliveryFees + inputs.otherExpenses + inputs.repairs + inputs.softwarePos + inputs.licenses, color: '#666' },
  ].filter(d => d.value > 0);

  return (
    <div className="space-y-5 animate-fade-in">
      {/* KPI band */}
      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-px bg-border rounded-xl overflow-hidden border border-border">
        {[
          { l: 'Net Sales',     v: formatCurrency(netSales),   c: 'jade'   },
          { l: 'COGS',          v: formatCurrency(cogs),        c: 'default' },
          { l: 'Food Cost %',   v: formatPct(foodCostPct),      c: foodCostPct<=30?'jade':foodCostPct<=35?'amber':'danger' },
          { l: 'Labor %',       v: formatPct(laborCostPct),     c: laborCostPct<=30?'jade':'amber' },
          { l: 'Prime Cost %',  v: formatPct(primeCostPct),     c: primeCostPct<=60?'jade':'amber' },
          { l: 'Gross Profit',  v: formatCurrency(grossProfit), c: 'jade'   },
          { l: 'Net Profit',    v: formatCurrency(netProfit),   c: netProfit>=0?'jade':'danger' },
          { l: 'Net Margin %',  v: formatPct(netMarginPct),     c: netMarginPct>=8?'jade':'amber' },
        ].map(k => (
          <div key={k.l} className="bg-bg-1 p-4">
            <div className="text-[11px] text-text-3 mb-2">{k.l}</div>
            <div className={cn('font-display text-lg font-bold leading-none',
              k.c==='jade'?'text-jade': k.c==='amber'?'text-amber': k.c==='danger'?'text-danger':'text-cream'
            )}>{k.v}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Input panel */}
        <div className="space-y-4">

          {/* Net Sales */}
          <div className="card">
            <div className="card-header mb-3">
              <h3 className="card-title">Net Sales</h3>
              <div className="font-display text-lg font-bold text-jade">{formatCurrency(netSales)}</div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <FInput label="Gross Sales ($)" value={inputs.grossSales} onChange={set('grossSales')} />
              <FInput label="Discounts ($)"   value={inputs.discounts}  onChange={set('discounts')}  />
              <FInput label="Comps ($)"        value={inputs.comps}      onChange={set('comps')}      />
              <FInput label="Other Income ($)" value={inputs.otherIncome} onChange={set('otherIncome')} />
            </div>
          </div>

          {/* Inventory / COGS */}
          <div className="card">
            <div className="card-header mb-3">
              <h3 className="card-title">Inventory & COGS</h3>
              <div className="text-jade font-mono text-sm">{formatCurrency(cogs)} <span className="text-text-3 text-xs">({formatPct(foodCostPct)} FC)</span></div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <FInput label="Beginning Inv. ($)"  value={inputs.beginningInventory} onChange={set('beginningInventory')} />
              <FInput label="Purchases ($)"        value={inputs.purchases}          onChange={set('purchases')}          />
              <FInput label="Ending Inv. ($)"      value={inputs.endingInventory}    onChange={set('endingInventory')}    />
            </div>
            <div className="mt-3 text-xs text-text-3 bg-bg-2 rounded-lg px-3 py-2">
              COGS = {formatCurrency(inputs.beginningInventory)} + {formatCurrency(inputs.purchases)} − {formatCurrency(inputs.endingInventory)} = <span className="text-jade font-mono">{formatCurrency(cogs)}</span>
            </div>
          </div>

          {/* Labor */}
          <div className="card">
            <div className="card-header mb-3">
              <h3 className="card-title">Labor</h3>
              <div className="text-blue font-mono text-sm">{formatCurrency(totalLabor)} <span className="text-text-3 text-xs">({formatPct(laborCostPct)})</span></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <FInput label="Hourly Wages ($)"  value={inputs.hourlyWages}  onChange={set('hourlyWages')}  />
              <FInput label="Salary / Mgmt ($)" value={inputs.salaryWages}  onChange={set('salaryWages')}  />
              <FInput label="Payroll Tax ($)"   value={inputs.payrollTax}   onChange={set('payrollTax')}   />
              <FInput label="Benefits ($)"      value={inputs.benefits}     onChange={set('benefits')}     />
            </div>
          </div>

          {/* Opex */}
          <div className="card">
            <div className="card-header mb-3">
              <h3 className="card-title">Operating Expenses</h3>
              <div className="text-purple font-mono text-sm">{formatCurrency(totalOpex)}</div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <FInput label="Rent ($)"          value={inputs.rent}           onChange={set('rent')}           />
              <FInput label="Utilities ($)"     value={inputs.utilities}      onChange={set('utilities')}      />
              <FInput label="Insurance ($)"     value={inputs.insurance}      onChange={set('insurance')}      />
              <FInput label="Marketing ($)"     value={inputs.marketing}      onChange={set('marketing')}      />
              <FInput label="Credit Card Fees"  value={inputs.creditCardFees} onChange={set('creditCardFees')} />
              <FInput label="Delivery Fees ($)" value={inputs.deliveryFees}   onChange={set('deliveryFees')}   />
              <FInput label="Repairs ($)"       value={inputs.repairs}        onChange={set('repairs')}        />
              <FInput label="Other ($)"         value={inputs.otherExpenses}  onChange={set('otherExpenses')}  />
            </div>
          </div>

          <button
            onClick={() => saveMutation.mutate()}
            disabled={saveMutation.isPending || !locationId}
            className="btn-jade w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold"
          >
            <Save size={15} />
            {saveMutation.isPending ? 'Saving…' : 'Save Monthly P&L'}
          </button>
        </div>

        {/* Results panel */}
        <div className="space-y-4">
          {/* P&L statement */}
          <div className="card">
            <h3 className="card-title mb-4">Profit & Loss Statement</h3>
            <PLLine label="Total Revenue"     value={totalRev}    bold highlight="jade" />
            <PLLine label="  Food Cost (COGS)" value={-cogs}       pct={foodCostPct}  indent color={getPctColor(foodCostPct,30,35)} />
            <PLLine label="Gross Profit"       value={grossProfit} pct={gpPct}        bold highlight="jade" />
            <div className="my-2 border-t border-border" />
            <PLLine label="  Hourly Wages"     value={-inputs.hourlyWages}  indent />
            <PLLine label="  Salary / Mgmt"    value={-inputs.salaryWages}  indent />
            <PLLine label="  Payroll Tax"       value={-inputs.payrollTax}   indent />
            <PLLine label="Total Labor"         value={-totalLabor} pct={laborCostPct} bold color={getPctColor(laborCostPct,30,38)} />
            <div className="my-2 border-t border-border" />
            <PLLine label="Prime Cost"          value={-primeCost}  pct={primeCostPct} bold color={getPctColor(primeCostPct,60,70)} />
            <div className="my-2 border-t border-border" />
            <PLLine label="  Rent"             value={-inputs.rent}        indent />
            <PLLine label="  Utilities"        value={-inputs.utilities}   indent />
            <PLLine label="  Insurance"        value={-inputs.insurance}   indent />
            <PLLine label="  Marketing"        value={-inputs.marketing}   indent />
            <PLLine label="  Other Opex"       value={-(inputs.repairs+inputs.softwarePos+inputs.licenses+inputs.creditCardFees+inputs.deliveryFees+inputs.otherExpenses)} indent />
            <PLLine label="Total Opex"         value={-totalOpex}  bold />
            <div className="my-2 border-t-2 border-border-2" />
            <PLLine label="Net Profit / Loss"   value={netProfit}   pct={netMarginPct} bold highlight={netProfit>=0?'jade':'danger'} />
          </div>

          {/* Expense pie */}
          <div className="card">
            <h3 className="card-title mb-3">Expense Breakdown</h3>
            <div className="flex flex-wrap gap-2 mb-3">
              {pieData.map(d => (
                <span key={d.name} className="flex items-center gap-1 text-[11px] text-text-3">
                  <span className="w-2 h-2 rounded-sm flex-shrink-0" style={{ background: d.color }} />
                  {d.name}
                </span>
              ))}
            </div>
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={72} dataKey="value" paddingAngle={2}>
                  {pieData.map((d, i) => <Cell key={i} fill={d.color} stroke="transparent" />)}
                </Pie>
                <Tooltip formatter={(v: any) => [formatCurrency(v), '']} />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Break-even */}
          <div className="card">
            <h3 className="card-title mb-4">Break-Even Analysis</h3>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="bg-bg-2 rounded-xl p-3">
                <div className="text-[10px] text-text-3 uppercase tracking-wider mb-1">Fixed Costs</div>
                <div className="font-display text-lg font-bold text-cream">{formatCurrency(fixedCosts)}</div>
              </div>
              <div className="bg-bg-2 rounded-xl p-3">
                <div className="text-[10px] text-text-3 uppercase tracking-wider mb-1">Break-Even Sales</div>
                <div className="font-display text-lg font-bold text-jade">{formatCurrency(breakEven)}</div>
              </div>
            </div>
            <div className={cn(
              'rounded-xl p-3 border text-sm',
              breakEvenGap >= 0
                ? 'bg-jade/5 border-jade/20 text-jade'
                : 'bg-danger/5 border-danger/20 text-danger'
            )}>
              {breakEvenGap >= 0
                ? <>✓ <strong>{formatCurrency(breakEvenGap)}</strong> above break-even. Operations are profitable.</>
                : <>✗ <strong>{formatCurrency(Math.abs(breakEvenGap))}</strong> below break-even. Reduce costs or increase sales.</>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FInput({ label, value, onChange }: { label: string; value: number; onChange: (e: any) => void }) {
  return (
    <div>
      <label className="block text-[11px] text-text-3 mb-1">{label}</label>
      <input
        type="number"
        value={value}
        onChange={onChange}
        className="w-full bg-bg-2 border border-border rounded-lg px-3 py-2 text-sm text-cream outline-none focus:border-jade transition-colors"
      />
    </div>
  );
}

function PLLine({ label, value, pct, bold, indent, highlight, color }: {
  label: string; value: number; pct?: number;
  bold?: boolean; indent?: boolean; highlight?: string; color?: string;
}) {
  const valColor = highlight === 'jade' ? 'text-jade' : highlight === 'danger' ? 'text-danger' : value < 0 ? 'text-text-2' : 'text-text';
  return (
    <div className={cn('flex items-center justify-between py-1.5', bold && 'font-semibold', indent && 'border-b border-border/50')}>
      <span className={cn('text-sm', indent ? 'text-text-3 pl-4' : bold ? 'text-cream' : 'text-text-2')}>
        {label}
      </span>
      <div className="flex items-center gap-3">
        {pct != null && (
          <span className="font-mono text-xs" style={{ color: color || '#8a8680' }}>{formatPct(pct)}</span>
        )}
        <span className={cn('font-mono text-sm', valColor)}>
          {value >= 0 ? formatCurrency(value) : `(${formatCurrency(Math.abs(value))})`}
        </span>
      </div>
    </div>
  );
}
