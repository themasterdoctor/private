'use client';

import { useQuery } from '@tanstack/react-query';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid
} from 'recharts';
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Minus } from 'lucide-react';
import { useAppStore, useCurrentLocation } from '@/store/appStore';
import { financeApi, salesApi, alertsApi } from '@/lib/api';
import { formatCurrency, formatPct } from '@/lib/utils';
import { HealthScoreRing } from '@/components/HealthScoreRing';
import { KPICard } from '@/components/KPICard';
import { AlertList } from '@/components/AlertList';
import { cn } from '@/lib/utils';

const CHART_COLORS = {
  jade:   '#00E5A0',
  blue:   '#4090F0',
  amber:  '#F0A030',
  danger: '#F05050',
  purple: '#9878F0',
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-bg-2 border border-border rounded-lg p-3 shadow-card text-xs">
      <p className="text-text-3 mb-2">{label}</p>
      {payload.map((entry: any) => (
        <p key={entry.name} style={{ color: entry.color }} className="flex justify-between gap-4">
          <span>{entry.name}</span>
          <span className="font-mono font-medium">
            {entry.name?.includes('%') ? formatPct(entry.value) : formatCurrency(entry.value)}
          </span>
        </p>
      ))}
    </div>
  );
};

export default function DashboardPage() {
  const currentLocation = useCurrentLocation();
  const locationId = currentLocation?.id;

  const { data: salesSummary, isLoading: salesLoading } = useQuery({
    queryKey: ['sales-summary', locationId],
    queryFn:  () => salesApi.summary(locationId!, { days: 30 }).then(r => r.data),
    enabled:  !!locationId,
  });

  const { data: financeSummary } = useQuery({
    queryKey: ['finance-summary', locationId],
    queryFn:  () => financeApi.summary(locationId!, { period: 'MONTHLY' }).then(r => r.data),
    enabled:  !!locationId,
  });

  const { data: alerts } = useQuery({
    queryKey: ['alerts', locationId],
    queryFn:  () => alertsApi.list(locationId!).then(r => r.data),
    enabled:  !!locationId,
  });

  // Use finance data or fallback demo
  const f = financeSummary || DEMO_FINANCE;
  const s = salesSummary   || DEMO_SALES;

  const kpis = [
    { label: 'Monthly Revenue',  value: formatCurrency(f.totalRevenue),  change: '+8.2%', trend: 'up',   tag: f.totalRevenue >= (f.targetRevenue || 0) ? 'On Target' : 'Below Target', tagColor: 'jade' },
    { label: 'Food Cost %',      value: formatPct(f.foodCostPct),        change: '-0.4%', trend: 'down', tag: f.foodCostPct <= 30 ? 'Healthy' : f.foodCostPct <= 35 ? 'Watch' : 'High Risk', tagColor: f.foodCostPct <= 30 ? 'jade' : f.foodCostPct <= 35 ? 'amber' : 'danger' },
    { label: 'Labor Cost %',     value: formatPct(f.laborCostPct),       change: '+1.1%', trend: 'up',   tag: f.laborCostPct <= 30 ? 'On Target' : 'Watch', tagColor: f.laborCostPct <= 30 ? 'jade' : 'amber' },
    { label: 'Prime Cost %',     value: formatPct(f.primeCostPct),       change: '+0.7%', trend: 'up',   tag: f.primeCostPct <= 60 ? 'Target' : 'Review', tagColor: f.primeCostPct <= 60 ? 'jade' : 'amber' },
    { label: 'Net Profit',       value: formatCurrency(f.netProfit),     change: '+5.3%', trend: 'up',   tag: formatPct(f.netMarginPct) + ' margin', tagColor: f.netMarginPct >= 8 ? 'jade' : f.netMarginPct >= 5 ? 'amber' : 'danger' },
    { label: 'Net Margin %',     value: formatPct(f.netMarginPct),       change: '+0.3%', trend: 'up',   tag: f.netMarginPct >= 10 ? 'Excellent' : f.netMarginPct >= 5 ? 'Healthy' : 'Below Target', tagColor: f.netMarginPct >= 8 ? 'jade' : 'amber' },
    { label: "Today's Sales",    value: formatCurrency(s.todaySales),    change: null,    trend: 'flat', tag: `${s.todayCovers} covers`, tagColor: 'blue' },
    { label: 'Break-Even Gap',   value: formatCurrency(f.breakEvenGap),  change: null,    trend: f.breakEvenGap >= 0 ? 'up' : 'down', tag: f.breakEvenGap >= 0 ? 'Above' : 'Below', tagColor: f.breakEvenGap >= 0 ? 'jade' : 'danger' },
  ];

  const pieData = [
    { name: 'Dine-in',  value: s.dineIn  || 60 },
    { name: 'Delivery', value: s.delivery || 25 },
    { name: 'Takeout',  value: s.takeout  || 15 },
  ];

  return (
    <div className="space-y-5 animate-fade-in">
      {/* KPI Band */}
      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-px bg-border rounded-xl overflow-hidden border border-border">
        {kpis.map((kpi) => (
          <KPICard key={kpi.label} {...kpi} />
        ))}
      </div>

      {/* Main charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Revenue vs Costs bar chart */}
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Revenue vs Costs — This Month</h3>
            <ChartLegend items={[
              { color: CHART_COLORS.jade,   label: 'Revenue' },
              { color: CHART_COLORS.danger, label: 'Food Cost' },
              { color: CHART_COLORS.blue,   label: 'Labor' },
              { color: CHART_COLORS.purple, label: 'Overhead' },
            ]} />
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={[
              { name: 'Revenue',   value: f.totalRevenue },
              { name: 'Food Cost', value: f.cogs },
              { name: 'Labor',     value: f.totalLaborCost },
              { name: 'Overhead',  value: f.totalOpex },
              { name: 'Net Profit',value: Math.max(0, f.netProfit) },
            ]} barSize={36}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#4A4845' }} axisLine={false} tickLine={false} />
              <YAxis tickFormatter={v => `$${Math.round(v/1000)}k`} tick={{ fontSize: 11, fill: '#4A4845' }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {[CHART_COLORS.jade, CHART_COLORS.danger, CHART_COLORS.blue, CHART_COLORS.purple, '#52c07a'].map((color, i) => (
                  <Cell key={i} fill={color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Health + alerts */}
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Performance Health</h3>
            <HealthScoreRing score={f.healthScore || 72} size={48} />
          </div>
          <div className="space-y-3 mb-4">
            {[
              { label: 'Food Cost %',  value: f.foodCostPct,  good: 30, warn: 35, max: 50 },
              { label: 'Labor Cost %', value: f.laborCostPct, good: 30, warn: 38, max: 50 },
              { label: 'Prime Cost %', value: f.primeCostPct, good: 60, warn: 70, max: 100 },
              { label: 'Net Margin %', value: f.netMarginPct, good: 10, warn: 5,  max: 20, invert: true },
            ].map(bar => (
              <HealthBar key={bar.label} {...bar} />
            ))}
          </div>
          <div className="border-t border-border pt-3">
            <AlertList alerts={(alerts?.alerts || DEMO_ALERTS).slice(0, 3)} compact />
          </div>
        </div>
      </div>

      {/* Bottom charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Channel split */}
        <div className="card">
          <h3 className="card-title mb-4">Revenue Channels</h3>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={70}
                dataKey="value" paddingAngle={2}>
                {pieData.map((_, i) => (
                  <Cell key={i} fill={[CHART_COLORS.jade, CHART_COLORS.blue, CHART_COLORS.amber][i]}
                    stroke="transparent" />
                ))}
              </Pie>
              <Tooltip formatter={(v: any) => [`${v}%`, '']} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-3 justify-center mt-1">
            {pieData.map((d, i) => (
              <div key={d.name} className="flex items-center gap-1.5 text-xs text-text-2">
                <div className="w-2 h-2 rounded-sm" style={{ background: [CHART_COLORS.jade, CHART_COLORS.blue, CHART_COLORS.amber][i] }} />
                {d.name} {d.value}%
              </div>
            ))}
          </div>
        </div>

        {/* 7-day trend */}
        <div className="card lg:col-span-2">
          <h3 className="card-title mb-4">7-Day Sales Trend</h3>
          <ResponsiveContainer width="100%" height={160}>
            <AreaChart data={s.dailyTrend || DEMO_TREND}>
              <defs>
                <linearGradient id="jadeGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%"   stopColor="#00E5A0" stopOpacity={0.15} />
                  <stop offset="100%" stopColor="#00E5A0" stopOpacity={0}    />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#4A4845' }} axisLine={false} tickLine={false} />
              <YAxis tickFormatter={v => `$${Math.round(v/1000)}k`} tick={{ fontSize: 11, fill: '#4A4845' }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="sales" name="Sales" stroke="#00E5A0" fill="url(#jadeGrad)"
                strokeWidth={2} dot={{ r: 3, fill: '#00E5A0' }} activeDot={{ r: 5 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

// ── Sub-components ──

function HealthBar({ label, value, good, warn, max, invert }: any) {
  const pct = Math.min((value / max) * 100, 100);
  const color = invert
    ? (value >= good ? '#00E5A0' : value >= warn ? '#F0A030' : '#F05050')
    : (value <= good ? '#00E5A0' : value <= warn ? '#F0A030' : '#F05050');

  return (
    <div>
      <div className="flex justify-between mb-1">
        <span className="text-xs text-text-2">{label}</span>
        <span className="font-mono text-xs" style={{ color }}>{formatPct(value)}</span>
      </div>
      <div className="h-1 bg-bg-3 rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-500"
          style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}

function ChartLegend({ items }: { items: Array<{ color: string; label: string }> }) {
  return (
    <div className="flex flex-wrap gap-3">
      {items.map(item => (
        <div key={item.label} className="flex items-center gap-1.5 text-xs text-text-3">
          <div className="w-2 h-2 rounded-sm" style={{ background: item.color }} />
          {item.label}
        </div>
      ))}
    </div>
  );
}

// ── Demo data (used when API not available) ──
const DEMO_FINANCE = {
  totalRevenue: 85000, cogs: 23970, foodCostPct: 28.2,
  totalLaborCost: 29325, laborCostPct: 34.5,
  primeCost: 53295, primeCostPct: 62.7,
  totalOpex: 14450, netProfit: 17255, netMarginPct: 20.3,
  grossProfit: 61030, grossMarginPct: 71.8,
  healthScore: 74, breakEvenGap: 9800, targetRevenue: 95000,
};
const DEMO_SALES = {
  todaySales: 3240, todayCovers: 77, dineIn: 60, delivery: 25, takeout: 15,
  dailyTrend: [
    { date: '05/11', sales: 3800 }, { date: '05/12', sales: 4350 }, { date: '05/13', sales: 4060 },
    { date: '05/14', sales: 4820 }, { date: '05/15', sales: 5350 }, { date: '05/16', sales: 5860 },
    { date: '05/17', sales: 3240 },
  ],
};
const DEMO_ALERTS = [
  { type: 'LOW_STOCK', severity: 'WARNING', message: 'Yellowtail running low: 3 LB remaining (min 4 LB)' },
  { type: 'OUT_OF_STOCK', severity: 'CRITICAL', message: 'Argentine Red Shrimp is out of stock' },
  { type: 'FOOD_COST_OK', severity: 'INFO', message: 'Food cost 28.2% is healthy and on target' },
];
