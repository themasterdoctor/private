'use client';

import { useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, TrendingUp, Package, Users, Clock,
  Receipt, DollarSign, BarChart3, Settings, CreditCard,
  MapPin, Shield, Bell, LogOut, ChevronDown
} from 'lucide-react';
import { useAppStore, useCurrentLocation } from '@/store/appStore';
import { LocationSwitcher } from '@/components/LocationSwitcher';
import { cn } from '@/lib/utils';

const NAV_ITEMS = [
  { section: 'Overview', items: [
    { href: '/dashboard',           label: 'Dashboard',     icon: LayoutDashboard },
    { href: '/dashboard/locations', label: 'All Locations', icon: MapPin, ownerOnly: true },
  ]},
  { section: 'Operations', items: [
    { href: '/dashboard/sales',     label: 'Sales',         icon: TrendingUp },
    { href: '/dashboard/inventory', label: 'Inventory',     icon: Package, badge: 'invAlerts' },
    { href: '/dashboard/staff',     label: 'Staff & Labor', icon: Users },
  ]},
  { section: 'Finance', items: [
    { href: '/dashboard/food-cost', label: 'Food Cost',     icon: Clock },
    { href: '/dashboard/invoices',  label: 'Invoices',      icon: Receipt },
    { href: '/dashboard/finance',   label: 'P&L / Finance', icon: DollarSign },
    { href: '/dashboard/valuation', label: 'Valuation',     icon: BarChart3 },
  ]},
  { section: 'Account', items: [
    { href: '/dashboard/admin',     label: 'Admin',         icon: Shield, ownerOnly: true },
    { href: '/dashboard/billing',   label: 'Billing',       icon: CreditCard, ownerOnly: true },
    { href: '/dashboard/settings',  label: 'Settings',      icon: Settings },
  ]},
];

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const router = useRouter();
  const pathname = usePathname();
  const { user, organization, role, isAuthenticated, logout } = useAppStore();
  const currentLocation = useCurrentLocation();

  useEffect(() => {
    if (!isAuthenticated) router.push('/login');
  }, [isAuthenticated, router]);

  if (!isAuthenticated || !user) return null;

  const isOwner = role === 'OWNER' || role === 'SUPER_ADMIN';
  const userInitials = `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();

  const handleLogout = async () => {
    await logout();
    router.push('/login');
  };

  return (
    <div className="flex min-h-screen bg-bg font-body text-text">
      {/* ── Sidebar ── */}
      <aside className="fixed inset-y-0 left-0 w-60 flex flex-col bg-bg-1 border-r border-border z-40">
        {/* Logo */}
        <div className="px-4 pt-5 pb-4 border-b border-border">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-2 h-2 rounded-full bg-jade shadow-jade animate-pulse-jade" />
            <span className="font-display font-bold text-base text-cream tracking-wide">
              Restaurant<span className="text-jade">OS</span>
            </span>
          </div>
          <LocationSwitcher />
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-3 px-2 scrollbar-thin">
          {NAV_ITEMS.map((section) => (
            <div key={section.section} className="mb-1">
              <div className="px-2 py-2 text-[10px] font-semibold tracking-[0.12em] uppercase text-text-3">
                {section.section}
              </div>
              {section.items
                .filter(item => !item.ownerOnly || isOwner)
                .map((item) => {
                  const Icon = item.icon;
                  const active = pathname === item.href || pathname.startsWith(item.href + '/');
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={cn(
                        'flex items-center gap-2.5 px-2.5 py-2 rounded-lg mb-0.5 text-sm transition-all duration-150',
                        active
                          ? 'bg-jade-dim text-jade font-medium'
                          : 'text-text-2 hover:bg-bg-2 hover:text-text'
                      )}
                    >
                      <Icon size={15} strokeWidth={active ? 2 : 1.8} />
                      <span className="flex-1">{item.label}</span>
                    </Link>
                  );
                })}
            </div>
          ))}
        </nav>

        {/* User footer */}
        <div className="p-3 border-t border-border">
          <div className="flex items-center gap-2.5 px-2 py-2 rounded-lg hover:bg-bg-2 cursor-pointer transition-colors group">
            <div className="w-7 h-7 rounded-full bg-jade-dim border border-border-jade flex items-center justify-center text-jade font-display font-bold text-xs flex-shrink-0">
              {userInitials}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-cream truncate">
                {user.firstName} {user.lastName}
              </div>
              <div className="text-[11px] text-text-3 capitalize">{role?.toLowerCase()}</div>
            </div>
            <button
              onClick={handleLogout}
              className="opacity-0 group-hover:opacity-100 transition-opacity text-text-3 hover:text-danger"
              title="Sign out"
            >
              <LogOut size={14} />
            </button>
          </div>
          {/* Plan badge */}
          <div className="mt-2 px-2">
            <span className={cn(
              'inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full',
              organization?.subscription?.plan === 'ENTERPRISE' ? 'bg-purple/10 text-purple' :
              organization?.subscription?.plan === 'PRO'        ? 'bg-jade-dim text-jade' :
              'bg-bg-3 text-text-3'
            )}>
              {organization?.subscription?.plan || 'STARTER'} Plan
            </span>
          </div>
        </div>
      </aside>

      {/* ── Main Content ── */}
      <main className="ml-60 flex-1 min-h-screen flex flex-col">
        {/* Topbar */}
        <header className="sticky top-0 z-30 h-12 flex items-center justify-between px-6 bg-bg-1 border-b border-border">
          <div className="flex items-center gap-3">
            <h1 className="font-display font-semibold text-sm text-cream" id="page-title">
              {getPageTitle(pathname)}
            </h1>
            {currentLocation && (
              <span className="text-text-3 text-xs">
                · {currentLocation.name}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-[11px] text-text-3 hidden md:block">
              {new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
            </span>
            <NotificationBell />
            <Link href="/dashboard/settings" className="btn-ghost btn-sm text-xs">
              Settings
            </Link>
          </div>
        </header>

        {/* Page content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={pathname}
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="flex-1 p-6"
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}

function getPageTitle(pathname: string): string {
  const map: Record<string, string> = {
    '/dashboard':            'Dashboard',
    '/dashboard/locations':  'All Locations',
    '/dashboard/sales':      'Sales',
    '/dashboard/inventory':  'Inventory',
    '/dashboard/staff':      'Staff & Labor',
    '/dashboard/food-cost':  'Food Cost',
    '/dashboard/invoices':   'Invoices',
    '/dashboard/finance':    'P&L / Finance',
    '/dashboard/valuation':  'Valuation',
    '/dashboard/admin':      'Admin',
    '/dashboard/billing':    'Billing',
    '/dashboard/settings':   'Settings',
  };
  // Exact match first
  if (map[pathname]) return map[pathname];
  // Prefix match
  for (const [key, val] of Object.entries(map)) {
    if (pathname.startsWith(key + '/')) return val;
  }
  return 'RestaurantOS';
}

function NotificationBell() {
  return (
    <button className="relative w-8 h-8 flex items-center justify-center rounded-lg border border-border hover:border-border-2 text-text-2 hover:text-text transition-colors">
      <Bell size={14} />
      <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-danger" />
    </button>
  );
}
