'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAppStore } from '@/store/appStore';

const DEMO_ACCOUNTS = [
  { email: 'owner@kazunori.com',   role: 'Owner',      desc: 'Full access + billing' },
  { email: 'manager@kazunori.com', role: 'Manager',    desc: 'Ops + finance, no billing' },
  { email: 'chef@kazunori.com',    role: 'Chef',       desc: 'Food cost + inventory' },
];

export default function LoginPage() {
  const router = useRouter();
  const { login, isLoading } = useAppStore();
  const [email, setEmail] = useState('owner@kazunori.com');
  const [password, setPassword] = useState('demo1234');
  const [error, setError] = useState('');

  const handleLogin = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setError('');
    try {
      await login(email, password);
      router.push('/dashboard');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Invalid email or password');
    }
  };

  return (
    <div className="min-h-screen bg-bg flex items-center justify-center p-4"
      style={{ backgroundImage: 'radial-gradient(ellipse at 50% 0%, rgba(0,229,160,0.04) 0%, transparent 60%)' }}>
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="font-display text-2xl font-black text-cream mb-1">
            Restaurant<span className="text-jade">OS</span>
          </div>
          <div className="text-sm text-text-3">Restaurant Intelligence Platform</div>
        </div>

        <div className="bg-bg-1 border border-border-2 rounded-2xl p-7">
          <h1 className="font-display text-xl font-bold text-cream mb-1">Welcome back</h1>
          <p className="text-sm text-text-2 mb-6">Sign in to your account</p>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs text-text-3 mb-1.5">Email address</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                className="w-full bg-bg-2 border border-border rounded-xl px-4 py-2.5 text-sm text-cream outline-none focus:border-jade transition-colors"
                placeholder="you@restaurant.com" required />
            </div>
            <div>
              <label className="block text-xs text-text-3 mb-1.5">Password</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)}
                className="w-full bg-bg-2 border border-border rounded-xl px-4 py-2.5 text-sm text-cream outline-none focus:border-jade transition-colors"
                placeholder="••••••••" required />
            </div>

            {error && (
              <div className="text-xs text-danger bg-danger/10 border border-danger/20 rounded-lg px-3 py-2">
                {error}
              </div>
            )}

            <button type="submit" disabled={isLoading}
              className="w-full bg-jade text-bg font-semibold text-sm py-2.5 rounded-xl hover:bg-jade-dark transition-colors disabled:opacity-60">
              {isLoading ? 'Signing in…' : 'Sign in →'}
            </button>
          </form>

          {/* Demo accounts */}
          <div className="mt-5 pt-5 border-t border-border">
            <div className="text-[10px] font-semibold uppercase tracking-widest text-text-3 mb-3">
              Demo Accounts — click to use
            </div>
            <div className="space-y-2">
              {DEMO_ACCOUNTS.map(a => (
                <button key={a.email}
                  onClick={() => { setEmail(a.email); setPassword('demo1234'); }}
                  className="w-full flex items-center justify-between px-3 py-2 bg-bg-2 hover:bg-bg-3 rounded-lg transition-colors text-left">
                  <div>
                    <div className="text-xs font-medium text-text">{a.role}</div>
                    <div className="text-[11px] font-mono text-text-3">{a.email}</div>
                  </div>
                  <span className="text-[11px] text-jade">Use →</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <p className="text-center text-sm text-text-3 mt-5">
          Don't have an account?{' '}
          <Link href="/register" className="text-jade hover:text-jade-dark transition-colors">
            Start free trial
          </Link>
        </p>
      </div>
    </div>
  );
}
