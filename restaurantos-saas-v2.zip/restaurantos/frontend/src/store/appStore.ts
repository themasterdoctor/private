import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { authApi, saveTokens, clearTokens } from '../lib/api';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  avatarUrl?: string;
}

interface Organization {
  id: string;
  name: string;
  slug: string;
  subscription?: {
    plan: 'STARTER' | 'PRO' | 'ENTERPRISE';
    status: string;
    trialEnd?: string;
  };
  locations: Array<{
    id: string;
    name: string;
    type: string;
  }>;
}

interface AppState {
  user: User | null;
  organization: Organization | null;
  role: string | null;
  locationIds: string[];
  currentLocationId: string | null;
  tokens: { access: string; refresh: string } | null;
  isAuthenticated: boolean;
  isLoading: boolean;

  // Actions
  login:           (email: string, password: string) => Promise<void>;
  logout:          () => Promise<void>;
  setCurrentLocation: (locationId: string) => void;
  refreshUser:     () => Promise<void>;
  setOrganization: (org: Organization) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      user:              null,
      organization:      null,
      role:              null,
      locationIds:       [],
      currentLocationId: null,
      tokens:            null,
      isAuthenticated:   false,
      isLoading:         false,

      login: async (email, password) => {
        set({ isLoading: true });
        try {
          const res = await authApi.login({ email, password });
          const { user, organization, role, locationIds, tokens } = res.data;

          saveTokens(tokens);

          const currentLocationId = organization.locations[0]?.id || null;

          set({
            user,
            organization,
            role,
            locationIds,
            tokens,
            currentLocationId,
            isAuthenticated: true,
            isLoading: false,
          });
        } catch (err) {
          set({ isLoading: false });
          throw err;
        }
      },

      logout: async () => {
        try {
          const tokens = get().tokens;
          if (tokens?.refresh) await authApi.logout(tokens.refresh);
        } catch {/* ignore */}
        clearTokens();
        set({
          user: null, organization: null, role: null,
          locationIds: [], currentLocationId: null,
          tokens: null, isAuthenticated: false,
        });
      },

      setCurrentLocation: (locationId) => {
        set({ currentLocationId: locationId });
      },

      refreshUser: async () => {
        try {
          const res = await authApi.me();
          const { user, organization, role, locationIds } = res.data;
          set({ user, organization, role, locationIds });
        } catch {/* token expired — handled by interceptor */}
      },

      setOrganization: (org) => {
        set({ organization: org });
      },
    }),
    {
      name:    'ros-app-state',
      partialize: (state) => ({
        user:              state.user,
        organization:      state.organization,
        role:              state.role,
        locationIds:       state.locationIds,
        currentLocationId: state.currentLocationId,
        tokens:            state.tokens,
        isAuthenticated:   state.isAuthenticated,
      }),
    }
  )
);

// ── Derived helpers ──
export const useCurrentLocation = () => {
  const { organization, currentLocationId } = useAppStore();
  return organization?.locations.find(l => l.id === currentLocationId) || organization?.locations[0] || null;
};

export const useIsOwner = () => useAppStore(s => s.role === 'OWNER' || s.role === 'SUPER_ADMIN');
export const useIsManager = () => useAppStore(s => ['OWNER', 'MANAGER', 'SUPER_ADMIN'].includes(s.role || ''));
export const useCanEditFinance = () => useAppStore(s => ['OWNER', 'MANAGER', 'SUPER_ADMIN'].includes(s.role || ''));
export const useCanEditMenu = () => useAppStore(s => ['OWNER', 'MANAGER', 'CHEF', 'SUPER_ADMIN'].includes(s.role || ''));
