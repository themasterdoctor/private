'use client';

import { getHealthColor, getHealthLabel } from '@/lib/utils';

interface HealthScoreRingProps {
  score: number;
  size?: number;
  showLabel?: boolean;
}

export function HealthScoreRing({ score, size = 80, showLabel = true }: HealthScoreRingProps) {
  const color  = getHealthColor(score);
  const label  = getHealthLabel(score);
  const r      = size * 0.38;
  const sw     = size * 0.09;
  const cx     = size / 2;
  const cy     = size * 0.62;
  // Semi-circle: goes from π to 2π (left to right across bottom)
  const angle  = (score / 100) * Math.PI;
  const x      = cx + r * Math.cos(Math.PI + angle);
  const y      = cy + r * Math.sin(Math.PI + angle);
  const large  = angle > Math.PI ? 1 : 0;

  return (
    <div className="flex flex-col items-center">
      <div style={{ width: size, height: size * 0.65, position: 'relative' }}>
        <svg width={size} height={size * 0.65} viewBox={`0 0 ${size} ${size * 0.65}`}>
          {/* Track */}
          <path
            d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
            fill="none"
            stroke="rgba(255,255,255,0.06)"
            strokeWidth={sw}
            strokeLinecap="round"
          />
          {/* Progress */}
          {score > 0 && (
            <path
              d={`M ${cx - r} ${cy} A ${r} ${r} 0 ${large} 1 ${x} ${y}`}
              fill="none"
              stroke={color}
              strokeWidth={sw}
              strokeLinecap="round"
              style={{ transition: 'all 0.6s ease' }}
            />
          )}
          {/* Score number */}
          <text
            x={cx}
            y={cy - size * 0.04}
            textAnchor="middle"
            fill={color}
            fontFamily="Syne, sans-serif"
            fontWeight="800"
            fontSize={size * 0.28}
          >
            {score}
          </text>
        </svg>
      </div>
      {showLabel && (
        <div className="text-[11px] mt-0.5" style={{ color }}>
          {label}
        </div>
      )}
    </div>
  );
}
