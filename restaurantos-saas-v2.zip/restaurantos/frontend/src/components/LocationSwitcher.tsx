'use client';

import { useState, useRef, useEffect } from 'react';
import { ChevronDown, MapPin, Plus } from 'lucide-react';
import { useAppStore, useCurrentLocation } from '@/store/appStore';
import { cn } from '@/lib/utils';

export function LocationSwitcher() {
  const { organization, setCurrentLocation } = useAppStore();
  const currentLocation = useCurrentLocation();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const locations = organization?.locations || [];

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  if (locations.length === 0) return null;

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center gap-2 px-3 py-2.5 bg-bg-2 border border-border rounded-xl hover:border-border-2 transition-colors text-left"
      >
        <MapPin size={12} className="text-jade flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <div className="text-xs font-semibold text-cream truncate">{currentLocation?.name || 'Select location'}</div>
          <div className="text-[10px] text-text-3 capitalize">{currentLocation?.type?.replace('_', ' ').toLowerCase()}</div>
        </div>
        <ChevronDown size={12} className={cn('text-text-3 transition-transform flex-shrink-0', open && 'rotate-180')} />
      </button>

      {open && (
        <div className="absolute top-full left-0 right-0 mt-1.5 bg-bg-3 border border-border-2 rounded-xl z-50 overflow-hidden shadow-card">
          {locations.map(loc => (
            <button
              key={loc.id}
              onClick={() => { setCurrentLocation(loc.id); setOpen(false); }}
              className={cn(
                'w-full flex items-center gap-2 px-3 py-2.5 text-left transition-colors hover:bg-bg-4',
                loc.id === currentLocation?.id ? 'text-jade' : 'text-text-2'
              )}
            >
              <div className={cn('w-1.5 h-1.5 rounded-full flex-shrink-0', loc.id === currentLocation?.id ? 'bg-jade' : 'bg-text-3')} />
              <span className="text-xs">{loc.name}</span>
            </button>
          ))}
          <div className="border-t border-border">
            <button className="w-full flex items-center gap-2 px-3 py-2 text-[11px] text-text-3 hover:text-jade transition-colors">
              <Plus size={11} /> Add location
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
