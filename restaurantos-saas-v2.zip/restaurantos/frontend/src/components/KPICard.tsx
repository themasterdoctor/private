'use client';

import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';

interface KPICardProps {
  label:      string;
  value:      string;
  change?:    string | null;
  trend?:     'up' | 'down' | 'flat';
  tag?:       string;
  tagColor?:  'jade' | 'amber' | 'danger' | 'blue' | 'purple';
  onClick?:   () => void;
}

const TAG_STYLES: Record<string, string> = {
  jade:   'bg-jade/10 text-jade',
  amber:  'bg-amber/10 text-amber',
  danger: 'bg-danger/10 text-danger',
  blue:   'bg-blue/10 text-blue',
  purple: 'bg-purple/10 text-purple',
};

export function KPICard({ label, value, change, trend = 'flat', tag, tagColor = 'jade', onClick }: KPICardProps) {
  const TrendIcon = trend === 'up' ? TrendingUp : trend === 'down' ? TrendingDown : Minus;
  const trendColor = trend === 'up' ? 'text-jade' : trend === 'down' ? 'text-danger' : 'text-text-3';

  return (
    <div
      className={cn(
        'bg-bg-1 p-4 hover:bg-bg-2 transition-colors',
        onClick && 'cursor-pointer'
      )}
      onClick={onClick}
    >
      <div className="text-[11px] text-text-3 mb-2 truncate">{label}</div>
      <div className="font-display text-xl font-bold text-cream leading-none mb-2">{value}</div>
      <div className="flex items-center gap-2 flex-wrap">
        {change && (
          <div className={cn('flex items-center gap-1 text-[11px] font-mono', trendColor)}>
            <TrendIcon size={10} />
            {change}
          </div>
        )}
        {tag && (
          <span className={cn('text-[10px] px-1.5 py-0.5 rounded-full font-semibold', TAG_STYLES[tagColor])}>
            {tag}
          </span>
        )}
      </div>
    </div>
  );
}
