'use client';

import { AlertTriangle, CheckCircle, Info, X } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Alert {
  type:     string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  message:  string;
}

interface AlertListProps {
  alerts:  Alert[];
  compact?: boolean;
  onDismiss?: (index: number) => void;
}

const SEVERITY_CONFIG = {
  CRITICAL: { icon: AlertTriangle, class: 'text-danger bg-danger/8 border-danger/20', iconClass: 'text-danger' },
  WARNING:  { icon: AlertTriangle, class: 'text-amber  bg-amber/8  border-amber/20',  iconClass: 'text-amber'  },
  INFO:     { icon: CheckCircle,   class: 'text-jade   bg-jade/8   border-jade/20',   iconClass: 'text-jade'   },
};

export function AlertList({ alerts, compact = false, onDismiss }: AlertListProps) {
  if (!alerts || alerts.length === 0) return null;

  return (
    <div className="space-y-2">
      {alerts.map((alert, i) => {
        const cfg = SEVERITY_CONFIG[alert.severity] || SEVERITY_CONFIG.INFO;
        const Icon = cfg.icon;
        return (
          <div key={i} className={cn(
            'flex items-start gap-2 rounded-lg border text-xs',
            compact ? 'px-3 py-2' : 'px-4 py-3',
            cfg.class
          )}>
            <Icon size={compact ? 12 : 14} className={cn('flex-shrink-0 mt-0.5', cfg.iconClass)} />
            <span className="flex-1 leading-relaxed">{alert.message}</span>
            {onDismiss && (
              <button onClick={() => onDismiss(i)} className="flex-shrink-0 opacity-50 hover:opacity-100">
                <X size={12} />
              </button>
            )}
          </div>
        );
      })}
    </div>
  );
}
