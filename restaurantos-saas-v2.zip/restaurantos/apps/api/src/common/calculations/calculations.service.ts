/**
 * RestaurantOS — Calculation Service
 * All restaurant finance formulas in one place.
 * Pure functions, fully tested, no side effects.
 */

export interface COGSInputs {
  beginningInventory: number;
  purchases: number;
  endingInventory: number;
}

export interface NetSalesInputs {
  grossSales: number;
  discounts: number;
  comps: number;
  otherIncome?: number;
}

export interface LaborInputs {
  hourlyWages: number;
  salaryWages: number;
  payrollTax: number;
  benefits?: number;
}

export interface OperatingExpenses {
  rent: number;
  utilities: number;
  insurance: number;
  marketing: number;
  repairs: number;
  software: number;
  licenses: number;
  depreciation?: number;
  other: number;
}

export interface FinancialSummary {
  // Revenue
  grossSales: number;
  discounts: number;
  netSales: number;
  otherIncome: number;
  totalRevenue: number;

  // COGS
  beginningInventory: number;
  purchases: number;
  endingInventory: number;
  cogs: number;
  grossProfit: number;
  grossMarginPct: number;

  // Labor
  totalLabor: number;

  // Prime Cost
  primeCost: number;
  primeCostPct: number;

  // KPIs (%)
  foodCostPct: number;
  laborCostPct: number;

  // P&L
  totalOpex: number;
  ebitda: number;
  netProfit: number;
  netMarginPct: number;

  // Break-even
  fixedCosts: number;
  variableCostPct: number;
  breakEvenSales: number;
  breakEvenGap: number;

  // Score
  healthScore: number;
  healthLabel: 'Healthy' | 'Needs Attention' | 'High Risk';
}

export interface SDEValuation {
  annualNetProfit: number;
  ownerSalary: number;
  interest: number;
  depreciation: number;
  sde: number;
  sdeLow: number;  // 2×
  sdeHigh: number; // 3×
}

export interface RevenueValuation {
  annualRevenue: number;
  revLow: number;  // 0.6×
  revHigh: number; // 0.7×
}

export interface EBITDAValuation {
  ebitda: number;
  multiple: number;
  value: number;
}

export interface ValuationResult {
  sde: SDEValuation;
  revenue: RevenueValuation;
  ebitda: EBITDAValuation;
  consensusLow: number;
  consensusHigh: number;
}

// ─────────────────────────────────────────────────────────────
// CORE CALCULATIONS
// ─────────────────────────────────────────────────────────────

export function calcNetSales(inputs: NetSalesInputs): number {
  return Math.max(0, inputs.grossSales - inputs.discounts - inputs.comps + (inputs.otherIncome ?? 0));
}

export function calcCOGS(inputs: COGSInputs): number {
  return Math.max(0, inputs.beginningInventory + inputs.purchases - inputs.endingInventory);
}

export function calcFoodCostPct(cogs: number, netSales: number): number {
  if (netSales <= 0) return 0;
  return (cogs / netSales) * 100;
}

export function calcLaborCost(inputs: LaborInputs): number {
  return inputs.hourlyWages + inputs.salaryWages + inputs.payrollTax + (inputs.benefits ?? 0);
}

export function calcLaborCostPct(laborCost: number, netSales: number): number {
  if (netSales <= 0) return 0;
  return (laborCost / netSales) * 100;
}

export function calcPrimeCost(cogs: number, laborCost: number): number {
  return cogs + laborCost;
}

export function calcPrimeCostPct(primeCost: number, netSales: number): number {
  if (netSales <= 0) return 0;
  return (primeCost / netSales) * 100;
}

export function calcGrossProfit(netSales: number, cogs: number): number {
  return netSales - cogs;
}

export function calcGrossMarginPct(grossProfit: number, netSales: number): number {
  if (netSales <= 0) return 0;
  return (grossProfit / netSales) * 100;
}

export function calcTotalOpex(opex: OperatingExpenses): number {
  return opex.rent + opex.utilities + opex.insurance + opex.marketing +
    opex.repairs + opex.software + opex.licenses + opex.other + (opex.depreciation ?? 0);
}

export function calcEBITDA(grossProfit: number, laborCost: number, opex: number, depreciation: number = 0): number {
  // EBITDA = Net profit + Interest + Tax + Depreciation + Amortization
  // Simplified: Gross Profit - Labor - Opex (excl. depreciation) + Depreciation
  return grossProfit - laborCost - opex + depreciation;
}

export function calcNetProfit(totalRevenue: number, cogs: number, laborCost: number, totalOpex: number): number {
  return totalRevenue - cogs - laborCost - totalOpex;
}

export function calcNetMarginPct(netProfit: number, netSales: number): number {
  if (netSales <= 0) return 0;
  return (netProfit / netSales) * 100;
}

export function calcBreakEven(fixedCosts: number, variableCostPct: number): number {
  // Break-Even = Fixed Costs / (1 - Variable Cost %)
  const contribution = 1 - variableCostPct / 100;
  if (contribution <= 0) return Infinity;
  return fixedCosts / contribution;
}

// ─────────────────────────────────────────────────────────────
// HEALTH SCORE (0–100)
// ─────────────────────────────────────────────────────────────

export interface HealthScoreInputs {
  foodCostPct: number;
  laborCostPct: number;
  primeCostPct: number;
  netMarginPct: number;
  breakEvenGap: number;
  netSales: number;
  targets?: {
    foodCost?: number;
    laborCost?: number;
    primeCost?: number;
    netMargin?: number;
  };
}

export function calcHealthScore(inputs: HealthScoreInputs): {
  score: number;
  label: 'Healthy' | 'Needs Attention' | 'High Risk';
  breakdown: Record<string, number>;
} {
  const t = {
    foodCost: inputs.targets?.foodCost ?? 30,
    laborCost: inputs.targets?.laborCost ?? 30,
    primeCost: inputs.targets?.primeCost ?? 60,
    netMargin: inputs.targets?.netMargin ?? 10,
  };

  let score = 100;
  const breakdown: Record<string, number> = {};

  // Food cost (25 pts)
  if (inputs.foodCostPct > t.foodCost + 10) { score -= 25; breakdown.foodCost = -25; }
  else if (inputs.foodCostPct > t.foodCost + 5) { score -= 15; breakdown.foodCost = -15; }
  else if (inputs.foodCostPct > t.foodCost) { score -= 8; breakdown.foodCost = -8; }
  else breakdown.foodCost = 0;

  // Labor cost (20 pts)
  if (inputs.laborCostPct > t.laborCost + 10) { score -= 20; breakdown.laborCost = -20; }
  else if (inputs.laborCostPct > t.laborCost + 5) { score -= 12; breakdown.laborCost = -12; }
  else if (inputs.laborCostPct > t.laborCost) { score -= 6; breakdown.laborCost = -6; }
  else breakdown.laborCost = 0;

  // Prime cost (25 pts)
  if (inputs.primeCostPct > 75) { score -= 25; breakdown.primeCost = -25; }
  else if (inputs.primeCostPct > 65) { score -= 15; breakdown.primeCost = -15; }
  else if (inputs.primeCostPct > t.primeCost) { score -= 8; breakdown.primeCost = -8; }
  else breakdown.primeCost = 0;

  // Net margin (20 pts)
  if (inputs.netMarginPct < 0) { score -= 20; breakdown.netMargin = -20; }
  else if (inputs.netMarginPct < 5) { score -= 15; breakdown.netMargin = -15; }
  else if (inputs.netMarginPct < t.netMargin) { score -= 6; breakdown.netMargin = -6; }
  else breakdown.netMargin = 0;

  // Break-even gap (10 pts)
  if (inputs.breakEvenGap < 0) { score -= 10; breakdown.breakEven = -10; }
  else if (inputs.breakEvenGap < inputs.netSales * 0.05) { score -= 5; breakdown.breakEven = -5; }
  else breakdown.breakEven = 0;

  score = Math.max(0, Math.min(100, Math.round(score)));
  const label = score >= 80 ? 'Healthy' : score >= 60 ? 'Needs Attention' : 'High Risk';

  return { score, label, breakdown };
}

// ─────────────────────────────────────────────────────────────
// FULL P&L SUMMARY
// ─────────────────────────────────────────────────────────────

export function calcFullSummary(params: {
  salesInputs: NetSalesInputs;
  cogsInputs: COGSInputs;
  laborInputs: LaborInputs;
  opexInputs: OperatingExpenses;
  targets?: HealthScoreInputs['targets'];
}): FinancialSummary {
  const { salesInputs, cogsInputs, laborInputs, opexInputs, targets } = params;

  const netSales = calcNetSales(salesInputs);
  const otherIncome = salesInputs.otherIncome ?? 0;
  const totalRevenue = netSales + otherIncome;
  const cogs = calcCOGS(cogsInputs);
  const grossProfit = calcGrossProfit(netSales, cogs);
  const grossMarginPct = calcGrossMarginPct(grossProfit, netSales);
  const totalLabor = calcLaborCost(laborInputs);
  const primeCost = calcPrimeCost(cogs, totalLabor);
  const primeCostPct = calcPrimeCostPct(primeCost, netSales);
  const foodCostPct = calcFoodCostPct(cogs, netSales);
  const laborCostPct = calcLaborCostPct(totalLabor, netSales);
  const totalOpex = calcTotalOpex(opexInputs);
  const ebitda = calcEBITDA(grossProfit, totalLabor, totalOpex, opexInputs.depreciation);
  const netProfit = calcNetProfit(totalRevenue, cogs, totalLabor, totalOpex);
  const netMarginPct = calcNetMarginPct(netProfit, netSales);

  // Break-even: fixed = rent+util+ins+sw+lic, variable = cogs+labor
  const fixedCosts = opexInputs.rent + opexInputs.utilities + opexInputs.insurance + opexInputs.software + opexInputs.licenses;
  const variableCostPct = netSales > 0 ? ((cogs + totalLabor) / netSales) * 100 : 0;
  const breakEvenSales = calcBreakEven(fixedCosts, variableCostPct);
  const breakEvenGap = netSales - breakEvenSales;

  const { score, label } = calcHealthScore({
    foodCostPct, laborCostPct, primeCostPct, netMarginPct,
    breakEvenGap, netSales, targets,
  });

  return {
    grossSales: salesInputs.grossSales,
    discounts: salesInputs.discounts + salesInputs.comps,
    netSales, otherIncome, totalRevenue,
    beginningInventory: cogsInputs.beginningInventory,
    purchases: cogsInputs.purchases,
    endingInventory: cogsInputs.endingInventory,
    cogs, grossProfit, grossMarginPct,
    totalLabor, primeCost, primeCostPct,
    foodCostPct, laborCostPct,
    totalOpex, ebitda, netProfit, netMarginPct,
    fixedCosts, variableCostPct, breakEvenSales, breakEvenGap,
    healthScore: score,
    healthLabel: label,
  };
}

// ─────────────────────────────────────────────────────────────
// RECIPE FOOD COST
// ─────────────────────────────────────────────────────────────

export function calcIngredientCost(qty: number, costPerUnit: number, wastePct: number): number {
  return qty * costPerUnit * (1 + wastePct);
}

export function calcRecipeFoodCostPct(totalCost: number, sellingPrice: number): number {
  if (sellingPrice <= 0) return 0;
  return (totalCost / sellingPrice) * 100;
}

export function calcRecipeMarkup(sellingPrice: number, totalCost: number): number {
  if (totalCost <= 0) return 0;
  return ((sellingPrice - totalCost) / totalCost) * 100;
}

// ─────────────────────────────────────────────────────────────
// VALUATION
// ─────────────────────────────────────────────────────────────

export function calcValuation(params: {
  annualNetProfit: number;
  ownerSalary: number;
  interest: number;
  depreciation: number;
  annualRevenue: number;
  ebitda: number;
  ebitdaMultiple?: number;
}): ValuationResult {
  const {
    annualNetProfit, ownerSalary, interest, depreciation,
    annualRevenue, ebitda, ebitdaMultiple = 3.5,
  } = params;

  // SDE
  const sde = annualNetProfit + ownerSalary + interest + depreciation;
  const sdeLow = sde * 2;
  const sdeHigh = sde * 3;

  // Revenue multiple
  const revLow = annualRevenue * 0.6;
  const revHigh = annualRevenue * 0.7;

  // EBITDA multiple
  const ebitdaValue = ebitda * ebitdaMultiple;

  // Consensus
  const allLows = [sdeLow, revLow, ebitdaValue * 0.85].filter(v => v > 0);
  const allHighs = [sdeHigh, revHigh, ebitdaValue * 1.1].filter(v => v > 0);
  const consensusLow = allLows.length ? Math.min(...allLows) : 0;
  const consensusHigh = allHighs.length ? Math.max(...allHighs) : 0;

  return {
    sde: { annualNetProfit, ownerSalary, interest, depreciation, sde, sdeLow, sdeHigh },
    revenue: { annualRevenue, revLow, revHigh },
    ebitda: { ebitda, multiple: ebitdaMultiple, value: ebitdaValue },
    consensusLow,
    consensusHigh,
  };
}

// ─────────────────────────────────────────────────────────────
// PERIOD ANNUALIZER
// ─────────────────────────────────────────────────────────────

export function annualize(value: number, periodType: 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'ANNUAL'): number {
  const multipliers = { DAILY: 365, WEEKLY: 52, MONTHLY: 12, ANNUAL: 1 };
  return value * multipliers[periodType];
}
