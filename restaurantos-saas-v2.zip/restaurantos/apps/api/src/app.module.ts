import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { BullModule } from '@nestjs/bull';

import { PrismaModule } from './common/prisma/prisma.module';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { OrganizationsModule } from './modules/organizations/organizations.module';
import { LocationsModule } from './modules/locations/locations.module';
import { SalesModule } from './modules/sales/sales.module';
import { InventoryModule } from './modules/inventory/inventory.module';
import { InvoicesModule } from './modules/invoices/invoices.module';
import { LaborModule } from './modules/labor/labor.module';
import { RecipesModule } from './modules/recipes/recipes.module';
import { FinanceModule } from './modules/finance/finance.module';
import { ValuationModule } from './modules/valuation/valuation.module';
import { BillingModule } from './modules/billing/billing.module';
import { AiParserModule } from './modules/ai-parser/ai-parser.module';
import { SettingsModule } from './modules/settings/settings.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, envFilePath: '.env' }),

    ThrottlerModule.forRoot([{
      ttl: 60000,
      limit: 100,
    }]),

    BullModule.forRoot({
      redis: { host: 'localhost', port: 6379 },
    }),

    PrismaModule,
    AuthModule,
    UsersModule,
    OrganizationsModule,
    LocationsModule,
    SalesModule,
    InventoryModule,
    InvoicesModule,
    LaborModule,
    RecipesModule,
    FinanceModule,
    ValuationModule,
    BillingModule,
    AiParserModule,
    SettingsModule,
  ],
})
export class AppModule {}
