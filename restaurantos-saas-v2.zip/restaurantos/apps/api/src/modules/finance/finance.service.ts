// ─── finance.controller.ts ──────────────────────────────────
import {
  Controller, Get, Post, Put, Body, Param, Query,
  UseGuards, Req, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { FinanceService } from './finance.service';

@ApiTags('Finance')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('locations/:locationId/finance')
export class FinanceController {
  constructor(private readonly financeService: FinanceService) {}

  // Get P&L entries for a location
  @Get()
  getEntries(
    @Param('locationId') locationId: string,
    @Query('from') from: string,
    @Query('to') to: string,
    @Query('periodType') periodType: string = 'MONTHLY',
  ) {
    return this.financeService.getEntries(locationId, { from, to, periodType });
  }

  // Get or create entry for a specific period
  @Get(':period')
  getEntry(
    @Param('locationId') locationId: string,
    @Param('period') period: string, // "2026-05" for monthly
  ) {
    return this.financeService.getOrCreateEntry(locationId, period);
  }

  // Upsert a finance entry (full P&L inputs)
  @Put(':period')
  upsertEntry(
    @Param('locationId') locationId: string,
    @Param('period') period: string,
    @Body() dto: any,
    @Req() req: any,
  ) {
    return this.financeService.upsertEntry(locationId, period, dto, req.user.sub);
  }

  // Get calculated summary for a period
  @Get(':period/summary')
  getSummary(
    @Param('locationId') locationId: string,
    @Param('period') period: string,
  ) {
    return this.financeService.getSummary(locationId, period);
  }

  // Get trailing 12 months trend
  @Get('trend/ttm')
  getTTM(@Param('locationId') locationId: string) {
    return this.financeService.getTTMTrend(locationId);
  }

  // Export P&L as CSV
  @Get('export/csv')
  exportCSV(
    @Param('locationId') locationId: string,
    @Query('from') from: string,
    @Query('to') to: string,
  ) {
    return this.financeService.exportCSV(locationId, from, to);
  }
}

// ─── finance.service.ts ──────────────────────────────────────
import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../common/prisma/prisma.service';
import {
  calcFullSummary,
  calcNetSales,
  calcCOGS,
  calcLaborCost,
  calcTotalOpex,
  calcBreakEven,
  calcHealthScore,
} from '../../common/calculations/calculations.service';
import { startOfMonth, format, subMonths, parseISO } from 'date-fns';

@Injectable()
export class FinanceService {
  constructor(private prisma: PrismaService) {}

  async getEntries(locationId: string, filters: { from?: string; to?: string; periodType?: string }) {
    const where: any = { locationId };
    if (filters.from) where.period = { gte: new Date(filters.from) };
    if (filters.to)   where.period = { ...where.period, lte: new Date(filters.to) };
    if (filters.periodType) where.periodType = filters.periodType;

    return this.prisma.financeEntry.findMany({
      where,
      orderBy: { period: 'desc' },
      take: 36,
    });
  }

  async getOrCreateEntry(locationId: string, periodStr: string) {
    const period = new Date(periodStr + '-01');
    let entry = await this.prisma.financeEntry.findUnique({
      where: { locationId_period_periodType: { locationId, period, periodType: 'MONTHLY' } },
    });

    if (!entry) {
      // Bootstrap from sales data
      entry = await this.bootstrapFromSales(locationId, period);
    }

    return entry;
  }

  async upsertEntry(locationId: string, periodStr: string, dto: any, userId: string) {
    const period = new Date(periodStr + '-01');

    // Calculate derived fields
    const netSales = calcNetSales({
      grossSales: dto.grossSales ?? 0,
      discounts: dto.discounts ?? 0,
      comps: dto.comps ?? 0,
      otherIncome: dto.otherIncome ?? 0,
    });

    const cogs = calcCOGS({
      beginningInventory: dto.beginningInventory ?? 0,
      purchases: dto.purchases ?? 0,
      endingInventory: dto.endingInventory ?? 0,
    });

    const totalLabor = calcLaborCost({
      hourlyWages: dto.hourlyWages ?? 0,
      salaryWages: dto.salaryWages ?? 0,
      payrollTax: dto.payrollTax ?? 0,
      benefits: dto.benefits ?? 0,
    });

    const primeCost = cogs + totalLabor;
    const totalRevenue = netSales + (dto.otherIncome ?? 0);
    const grossProfit = netSales - cogs;
    const totalOpex = calcTotalOpex({
      rent: dto.rent ?? 0,
      utilities: dto.utilities ?? 0,
      insurance: dto.insurance ?? 0,
      marketing: dto.marketing ?? 0,
      repairs: dto.repairs ?? 0,
      software: dto.software ?? 0,
      licenses: dto.licenses ?? 0,
      depreciation: dto.depreciation ?? 0,
      other: dto.otherOpex ?? 0,
    });

    const netProfit = totalRevenue - cogs - totalLabor - totalOpex;
    const foodCostPct = netSales > 0 ? (cogs / netSales) * 100 : 0;
    const laborCostPct = netSales > 0 ? (totalLabor / netSales) * 100 : 0;
    const primeCostPct = netSales > 0 ? (primeCost / netSales) * 100 : 0;
    const netMarginPct = netSales > 0 ? (netProfit / netSales) * 100 : 0;
    const grossMarginPct = netSales > 0 ? (grossProfit / netSales) * 100 : 0;
    const ebitda = grossProfit - totalLabor - (totalOpex - (dto.depreciation ?? 0));

    const fixedCosts = (dto.rent ?? 0) + (dto.utilities ?? 0) + (dto.insurance ?? 0) + (dto.software ?? 0) + (dto.licenses ?? 0);
    const variableCostPct = netSales > 0 ? ((cogs + totalLabor) / netSales) * 100 : 0;
    const breakEvenSales = calcBreakEven(fixedCosts, variableCostPct);

    const { score } = calcHealthScore({
      foodCostPct, laborCostPct, primeCostPct, netMarginPct,
      breakEvenGap: netSales - breakEvenSales, netSales,
    });

    return this.prisma.financeEntry.upsert({
      where: { locationId_period_periodType: { locationId, period, periodType: 'MONTHLY' } },
      create: {
        locationId, period, periodType: 'MONTHLY',
        ...this.buildEntryData(dto, {
          netSales, totalRevenue, cogs, grossProfit, grossMarginPct,
          totalLabor, primeCost, primeCostPct, totalOpex, ebitda,
          netProfit, netMarginPct, foodCostPct, laborCostPct,
          fixedCosts, variableCostPct, breakEvenSales, healthScore: score,
        }),
        updatedBy: userId,
      },
      update: {
        ...this.buildEntryData(dto, {
          netSales, totalRevenue, cogs, grossProfit, grossMarginPct,
          totalLabor, primeCost, primeCostPct, totalOpex, ebitda,
          netProfit, netMarginPct, foodCostPct, laborCostPct,
          fixedCosts, variableCostPct, breakEvenSales, healthScore: score,
        }),
        updatedBy: userId,
      },
    });
  }

  async getSummary(locationId: string, periodStr: string) {
    const entry = await this.getOrCreateEntry(locationId, periodStr);
    if (!entry) throw new NotFoundException('Finance entry not found');
    return entry;
  }

  async getTTMTrend(locationId: string) {
    const periods = Array.from({ length: 12 }, (_, i) => {
      const d = subMonths(new Date(), 11 - i);
      return startOfMonth(d);
    });

    return Promise.all(periods.map(period =>
      this.prisma.financeEntry.findUnique({
        where: { locationId_period_periodType: { locationId, period, periodType: 'MONTHLY' } },
      })
    ));
  }

  async exportCSV(locationId: string, from: string, to: string): Promise<string> {
    const entries = await this.getEntries(locationId, { from, to, periodType: 'MONTHLY' });
    const headers = ['Period','Net Sales','COGS','Food Cost %','Labor','Labor %','Prime Cost','Prime Cost %','Net Profit','Net Margin %','Health Score'];
    const rows = entries.map(e => [
      format(e.period, 'yyyy-MM'),
      e.netSales, e.cogs, e.foodCostPct.toFixed(1)+'%',
      e.totalLabor, e.laborCostPct.toFixed(1)+'%',
      e.primeCost, e.primeCostPct.toFixed(1)+'%',
      e.netProfit, e.netMarginPct.toFixed(1)+'%',
      e.healthScore,
    ]);
    return [headers, ...rows].map(r => r.join(',')).join('\n');
  }

  private async bootstrapFromSales(locationId: string, period: Date) {
    // Aggregate actual sales data for the period
    const from = period;
    const to = new Date(period.getFullYear(), period.getMonth() + 1, 0);
    const sales = await this.prisma.salesEntry.aggregate({
      where: { locationId, date: { gte: from, lte: to } },
      _sum: { netSales: true, grossSales: true, discounts: true },
    });

    const netSales = sales._sum.netSales ?? 0;
    return this.prisma.financeEntry.create({
      data: {
        locationId,
        period,
        periodType: 'MONTHLY',
        grossSales: sales._sum.grossSales ?? 0,
        discounts: sales._sum.discounts ?? 0,
        netSales,
        totalRevenue: netSales,
      },
    });
  }

  private buildEntryData(dto: any, calc: any) {
    return {
      grossSales: dto.grossSales ?? 0,
      discounts: dto.discounts ?? 0,
      comps: dto.comps ?? 0,
      netSales: calc.netSales,
      otherIncome: dto.otherIncome ?? 0,
      totalRevenue: calc.totalRevenue,
      beginningInventory: dto.beginningInventory ?? 0,
      purchases: dto.purchases ?? 0,
      endingInventory: dto.endingInventory ?? 0,
      cogs: calc.cogs,
      grossProfit: calc.grossProfit,
      grossMarginPct: calc.grossMarginPct,
      hourlyWages: dto.hourlyWages ?? 0,
      salaryWages: dto.salaryWages ?? 0,
      payrollTax: dto.payrollTax ?? 0,
      benefits: dto.benefits ?? 0,
      totalLabor: calc.totalLabor,
      primeCost: calc.primeCost,
      primeCostPct: calc.primeCostPct,
      rent: dto.rent ?? 0,
      utilities: dto.utilities ?? 0,
      insurance: dto.insurance ?? 0,
      marketing: dto.marketing ?? 0,
      repairs: dto.repairs ?? 0,
      software: dto.software ?? 0,
      licenses: dto.licenses ?? 0,
      depreciation: dto.depreciation ?? 0,
      otherOpex: dto.otherOpex ?? 0,
      totalOpex: calc.totalOpex,
      ebitda: calc.ebitda,
      netProfit: calc.netProfit,
      netMarginPct: calc.netMarginPct,
      foodCostPct: calc.foodCostPct,
      laborCostPct: calc.laborCostPct,
      healthScore: calc.healthScore,
      fixedCosts: calc.fixedCosts,
      variableCostPct: calc.variableCostPct,
      breakEvenSales: calc.breakEvenSales,
      notes: dto.notes,
    };
  }
}
