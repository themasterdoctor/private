import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import * as pdfParse from 'pdf-parse';
import sharp from 'sharp';

export interface ParsedInvoiceItem {
  productName: string;
  description?: string;
  unit: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  category?: string;
}

export interface ParsedInvoice {
  vendorName?: string;
  invoiceNumber?: string;
  invoiceDate?: string;
  dueDate?: string;
  subtotal?: number;
  tax?: number;
  totalAmount?: number;
  currency: string;
  lineItems: ParsedInvoiceItem[];
  rawText?: string;
  confidence: number; // 0–1
  parseMethod: 'AI_OCR' | 'CSV' | 'STRUCTURED_PDF';
}

@Injectable()
export class AiParserService {
  private readonly logger = new Logger(AiParserService.name);
  private openai: OpenAI;

  constructor(private config: ConfigService) {
    this.openai = new OpenAI({
      apiKey: config.get('OPENAI_API_KEY'),
    });
  }

  async parseInvoice(fileBuffer: Buffer, mimeType: string, fileName: string): Promise<ParsedInvoice> {
    this.logger.log(`Parsing invoice: ${fileName} (${mimeType})`);

    if (mimeType === 'text/csv' || fileName.endsWith('.csv')) {
      return this.parseCSV(fileBuffer);
    }

    if (mimeType === 'application/pdf') {
      return this.parsePDF(fileBuffer);
    }

    if (mimeType.startsWith('image/')) {
      return this.parseImage(fileBuffer, mimeType);
    }

    throw new Error(`Unsupported file type: ${mimeType}`);
  }

  // ─── PDF Parser ────────────────────────────────────────────
  private async parsePDF(buffer: Buffer): Promise<ParsedInvoice> {
    const pdfData = await pdfParse(buffer);
    const text = pdfData.text;

    if (text.length > 100) {
      // Has extractable text — send to AI
      return this.parseWithAI(text, 'STRUCTURED_PDF');
    }

    // Scanned PDF — convert to image and use vision
    return this.parseWithAI(text || 'Unable to extract text', 'AI_OCR');
  }

  // ─── Image Parser (vision) ──────────────────────────────────
  private async parseImage(buffer: Buffer, mimeType: string): Promise<ParsedInvoice> {
    // Resize to max 2000px for efficiency
    const resized = await sharp(buffer)
      .resize(2000, 2000, { fit: 'inside', withoutEnlargement: true })
      .jpeg({ quality: 90 })
      .toBuffer();

    const base64 = resized.toString('base64');

    const response = await this.openai.chat.completions.create({
      model: 'gpt-4o',
      max_tokens: 2000,
      messages: [{
        role: 'user',
        content: [
          {
            type: 'image_url',
            image_url: { url: `data:image/jpeg;base64,${base64}`, detail: 'high' },
          },
          {
            type: 'text',
            text: INVOICE_EXTRACTION_PROMPT,
          },
        ],
      }],
    });

    return this.parseAIResponse(response.choices[0].message.content ?? '', 'AI_OCR');
  }

  // ─── Text AI Parser ─────────────────────────────────────────
  private async parseWithAI(text: string, method: ParsedInvoice['parseMethod']): Promise<ParsedInvoice> {
    const response = await this.openai.chat.completions.create({
      model: 'gpt-4o-mini',
      max_tokens: 2000,
      messages: [
        {
          role: 'system',
          content: 'You are an expert restaurant invoice parser. Extract invoice data precisely and return valid JSON only.',
        },
        {
          role: 'user',
          content: `${INVOICE_EXTRACTION_PROMPT}\n\nINVOICE TEXT:\n${text.slice(0, 8000)}`,
        },
      ],
    });

    return this.parseAIResponse(response.choices[0].message.content ?? '', method);
  }

  // ─── CSV Parser ─────────────────────────────────────────────
  private parseCSV(buffer: Buffer): ParsedInvoice {
    const text = buffer.toString('utf-8');
    const lines = text.split('\n').map(l => l.split(',').map(c => c.trim().replace(/"/g, '')));
    const headers = lines[0].map(h => h.toLowerCase());

    const nameIdx   = headers.findIndex(h => h.includes('product') || h.includes('item') || h.includes('description'));
    const qtyIdx    = headers.findIndex(h => h.includes('qty') || h.includes('quantity'));
    const unitIdx   = headers.findIndex(h => h.includes('unit') || h.includes('uom'));
    const priceIdx  = headers.findIndex(h => h.includes('price') || h.includes('rate') || h.includes('unit price'));
    const totalIdx  = headers.findIndex(h => h.includes('total') || h.includes('amount') || h.includes('ext'));

    const lineItems: ParsedInvoiceItem[] = lines.slice(1)
      .filter(row => row.length > 1 && row[nameIdx])
      .map(row => {
        const qty   = parseFloat(row[qtyIdx]?.replace(/[^0-9.]/g, ''))   || 1;
        const price = parseFloat(row[priceIdx]?.replace(/[^0-9.]/g, '')) || 0;
        const total = parseFloat(row[totalIdx]?.replace(/[^0-9.]/g, '')) || qty * price;
        return {
          productName: row[nameIdx] || 'Unknown',
          unit: row[unitIdx] || 'EA',
          quantity: qty,
          unitPrice: price,
          totalPrice: total,
        };
      });

    const totalAmount = lineItems.reduce((a, i) => a + i.totalPrice, 0);

    return {
      currency: 'USD',
      lineItems,
      totalAmount,
      confidence: 0.9,
      parseMethod: 'CSV',
    };
  }

  // ─── AI Response Parser ──────────────────────────────────────
  private parseAIResponse(content: string, method: ParsedInvoice['parseMethod']): ParsedInvoice {
    try {
      // Strip markdown code fences if present
      const cleaned = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const parsed = JSON.parse(cleaned);

      return {
        vendorName: parsed.vendor_name || parsed.vendorName,
        invoiceNumber: parsed.invoice_number || parsed.invoiceNumber,
        invoiceDate: parsed.invoice_date || parsed.invoiceDate,
        dueDate: parsed.due_date || parsed.dueDate,
        subtotal: parseFloat(parsed.subtotal) || undefined,
        tax: parseFloat(parsed.tax) || undefined,
        totalAmount: parseFloat(parsed.total_amount || parsed.totalAmount) || undefined,
        currency: parsed.currency || 'USD',
        lineItems: (parsed.line_items || parsed.lineItems || []).map((item: any) => ({
          productName: item.product_name || item.productName || item.description || 'Unknown',
          description: item.description,
          unit: item.unit || 'EA',
          quantity: parseFloat(item.quantity || item.qty) || 1,
          unitPrice: parseFloat(item.unit_price || item.unitPrice || item.price) || 0,
          totalPrice: parseFloat(item.total_price || item.totalPrice || item.total || item.amount) || 0,
          category: item.category,
        })),
        confidence: parsed.confidence || 0.85,
        parseMethod: method,
      };
    } catch (e) {
      this.logger.error('Failed to parse AI response', e);
      return {
        currency: 'USD',
        lineItems: [],
        confidence: 0,
        parseMethod: method,
        rawText: content,
      };
    }
  }
}

// ─── Prompt ───────────────────────────────────────────────────
const INVOICE_EXTRACTION_PROMPT = `
Extract all data from this restaurant supplier invoice and return ONLY valid JSON with this exact structure:

{
  "vendor_name": "string",
  "invoice_number": "string or null",
  "invoice_date": "YYYY-MM-DD or null",
  "due_date": "YYYY-MM-DD or null",
  "subtotal": number or null,
  "tax": number or null,
  "total_amount": number,
  "currency": "USD",
  "confidence": 0.0-1.0,
  "line_items": [
    {
      "product_name": "exact product name",
      "description": "any additional description",
      "unit": "LB | EA | CS | GAL | OZ | PKT | BOX",
      "quantity": number,
      "unit_price": number,
      "total_price": number,
      "category": "Fish | Shellfish | Produce | Meat | Dairy | Dry Goods | Beverages | Supplies | Other"
    }
  ]
}

Rules:
- Extract EVERY line item, even if price is 0
- For unit prices, use per-pound/per-unit pricing
- Clean product names (remove codes/SKUs from the name field)
- Set confidence based on how clearly you can read the invoice
- Return ONLY the JSON object, no other text
`;
