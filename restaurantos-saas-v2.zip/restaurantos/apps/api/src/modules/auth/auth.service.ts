import { Injectable, UnauthorizedException, ConflictException, NotFoundException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcryptjs';
import { PrismaService } from '../../common/prisma/prisma.service';
import { RegisterDto, LoginDto } from './auth.dto';

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private jwt: JwtService,
    private config: ConfigService,
  ) {}

  async register(dto: RegisterDto) {
    // Check email uniqueness
    const existing = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (existing) throw new ConflictException('Email already registered');

    const passwordHash = await bcrypt.hash(dto.password, 12);

    // Create user + org + location in a transaction
    const result = await this.prisma.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: {
          email: dto.email.toLowerCase().trim(),
          passwordHash,
          firstName: dto.firstName,
          lastName: dto.lastName,
        },
      });

      const slug = dto.restaurantName
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '-')
        .replace(/-+/g, '-')
        .slice(0, 50) + '-' + Date.now().toString(36);

      const org = await tx.organization.create({
        data: {
          name: dto.restaurantName,
          slug,
          users: {
            create: { userId: user.id, role: 'OWNER', isDefault: true },
          },
          settings: { create: {} },
          subscription: {
            create: {
              plan: 'STARTER',
              status: 'TRIALING',
              trialEndsAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
              maxLocations: 1,
              maxUsers: 3,
            },
          },
        },
      });

      // Default location
      await tx.location.create({
        data: {
          organizationId: org.id,
          name: dto.restaurantName,
          type: 'CASUAL_DINING',
          settings: { create: {} },
        },
      });

      return { user, org };
    });

    const tokens = await this.generateTokens(result.user.id, result.org.id, 'OWNER');
    return {
      user: this.sanitizeUser(result.user),
      organization: result.org,
      ...tokens,
    };
  }

  async login(dto: LoginDto) {
    const user = await this.prisma.user.findUnique({
      where: { email: dto.email.toLowerCase().trim() },
      include: {
        organizations: {
          include: { organization: { include: { subscription: true } } },
          where: { isDefault: true },
        },
      },
    });

    if (!user || !user.isActive) throw new UnauthorizedException('Invalid credentials');
    const valid = await bcrypt.compare(dto.password, user.passwordHash);
    if (!valid) throw new UnauthorizedException('Invalid credentials');

    const orgUser = user.organizations[0];
    if (!orgUser) throw new UnauthorizedException('No organization found');

    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    const tokens = await this.generateTokens(user.id, orgUser.organizationId, orgUser.role);
    return {
      user: this.sanitizeUser(user),
      organization: orgUser.organization,
      role: orgUser.role,
      ...tokens,
    };
  }

  async refreshTokens(refreshToken: string) {
    const stored = await this.prisma.refreshToken.findUnique({ where: { token: refreshToken } });
    if (!stored || stored.expiresAt < new Date()) {
      throw new UnauthorizedException('Invalid refresh token');
    }

    const orgUser = await this.prisma.organizationUser.findFirst({
      where: { userId: stored.userId, isDefault: true },
    });
    if (!orgUser) throw new UnauthorizedException('Organization not found');

    await this.prisma.refreshToken.delete({ where: { token: refreshToken } });
    return this.generateTokens(stored.userId, orgUser.organizationId, orgUser.role);
  }

  async logout(userId: string) {
    await this.prisma.refreshToken.deleteMany({ where: { userId } });
    return { message: 'Logged out successfully' };
  }

  async getMe(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: {
        organizations: {
          include: {
            organization: {
              include: {
                subscription: true,
                locations: { where: { isActive: true } },
              },
            },
          },
        },
      },
    });
    if (!user) throw new NotFoundException('User not found');
    return this.sanitizeUser(user);
  }

  async forgotPassword(email: string) {
    // In production: generate reset token, send email via Resend
    // For now: return success (never reveal if email exists)
    return { message: 'If that email is registered, a reset link has been sent.' };
  }

  async resetPassword(token: string, password: string) {
    // In production: validate token, update password
    return { message: 'Password reset successfully' };
  }

  async acceptInvite(body: { token: string; password: string; firstName: string; lastName: string }) {
    const invite = await this.prisma.teamInvite.findUnique({ where: { token: body.token } });
    if (!invite || invite.expiresAt < new Date() || invite.acceptedAt) {
      throw new UnauthorizedException('Invalid or expired invite');
    }

    const passwordHash = await bcrypt.hash(body.password, 12);
    const result = await this.prisma.$transaction(async (tx) => {
      const user = await tx.user.upsert({
        where: { email: invite.email },
        update: {},
        create: {
          email: invite.email,
          passwordHash,
          firstName: body.firstName,
          lastName: body.lastName,
        },
      });

      await tx.organizationUser.upsert({
        where: { userId_organizationId: { userId: user.id, organizationId: invite.organizationId } },
        create: { userId: user.id, organizationId: invite.organizationId, role: invite.role },
        update: { role: invite.role },
      });

      await tx.teamInvite.update({ where: { id: invite.id }, data: { acceptedAt: new Date() } });
      return user;
    });

    const tokens = await this.generateTokens(result.id, invite.organizationId, invite.role);
    return { user: this.sanitizeUser(result), ...tokens };
  }

  // ─── Helpers ─────────────────────────────────────────────

  private async generateTokens(userId: string, orgId: string, role: string) {
    const payload = { sub: userId, orgId, role };

    const [accessToken, refreshToken] = await Promise.all([
      this.jwt.signAsync(payload, {
        secret: this.config.get('JWT_SECRET'),
        expiresIn: this.config.get('JWT_EXPIRES_IN', '15m'),
      }),
      this.jwt.signAsync(payload, {
        secret: this.config.get('JWT_REFRESH_SECRET'),
        expiresIn: this.config.get('JWT_REFRESH_EXPIRES_IN', '7d'),
      }),
    ]);

    await this.prisma.refreshToken.create({
      data: {
        userId,
        token: refreshToken,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    return { accessToken, refreshToken };
  }

  private sanitizeUser(user: any) {
    const { passwordHash, ...safe } = user;
    return safe;
  }
}
