#!/bin/bash
# RestaurantOS — Complete Server Setup Script
# Run: bash setup.sh from ~/private/private/restaurantos/

set -e
cd "$(dirname "$0")"
ROOT=$(pwd)
echo "🚀 RestaurantOS Setup"
echo "📁 Working from: $ROOT"
echo ""

# ── 1. Install Docker ──────────────────────────
echo "── Step 1: Docker ──"
if ! command -v docker &>/dev/null; then
  apt-get update -qq
  apt-get install -y ca-certificates curl gnupg lsb-release
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker.gpg
  echo "deb [arch=amd64 signed-by=/usr/share/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" > /etc/apt/sources.list.d/docker.list
  apt-get update -qq && apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
  echo "✓ Docker installed"
else
  echo "✓ Docker: $(docker --version)"
fi

# ── 2. Install Node 20 if missing ─────────────
echo ""
echo "── Step 2: Node.js ──"
if ! command -v node &>/dev/null || [[ "$(node --version)" < "v20" ]]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
echo "✓ Node: $(node --version)"

# ── 3. Environment ────────────────────────────
echo ""
echo "── Step 3: Environment ──"
if [ ! -f "$ROOT/.env" ]; then
  cp "$ROOT/.env.example" "$ROOT/.env" 2>/dev/null || cat > "$ROOT/.env" << 'ENVEOF'
DATABASE_URL=postgresql://restaurantos:restaurantos_dev@localhost:5432/restaurantos
JWT_SECRET=dev_jwt_secret_change_in_production_at_least_64_chars_long_random_string
JWT_REFRESH_SECRET=dev_refresh_secret_also_change_64_chars_completely_different_string
STRIPE_SECRET_KEY=sk_test_placeholder
STRIPE_PUBLISHABLE_KEY=pk_test_placeholder
STRIPE_WEBHOOK_SECRET=whsec_placeholder
STRIPE_STARTER_PRICE_ID=price_placeholder
STRIPE_PRO_PRICE_ID=price_placeholder
STRIPE_ENTERPRISE_PRICE_ID=price_placeholder
ANTHROPIC_API_KEY=sk-ant-placeholder
AWS_ACCESS_KEY_ID=placeholder
AWS_SECRET_ACCESS_KEY=placeholder
AWS_BUCKET=restaurantos-uploads
AWS_REGION=us-east-1
RESEND_API_KEY=re_placeholder
FROM_EMAIL=noreply@restaurantos.app
NEXT_PUBLIC_API_URL=http://localhost:4000
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_placeholder
FRONTEND_URL=http://localhost:3000
NODE_ENV=development
LOG_LEVEL=info
PORT=4000
ENVEOF
  echo "✓ Created .env"
else
  echo "✓ .env exists"
fi
cp "$ROOT/.env" "$ROOT/backend/.env"
cp "$ROOT/.env" "$ROOT/frontend/.env.local"

# ── 4. PostgreSQL ─────────────────────────────
echo ""
echo "── Step 4: PostgreSQL ──"
if docker ps --format '{{.Names}}' | grep -q "restaurantos-postgres"; then
  echo "✓ PostgreSQL container already running"
elif pg_isready -h localhost -p 5432 -q 2>/dev/null; then
  echo "✓ PostgreSQL already running on localhost:5432"
else
  docker run -d \
    --name restaurantos-postgres \
    --restart unless-stopped \
    -e POSTGRES_USER=restaurantos \
    -e POSTGRES_PASSWORD=restaurantos_dev \
    -e POSTGRES_DB=restaurantos \
    -p 5432:5432 \
    postgres:16-alpine
  echo -n "Waiting for Postgres"
  for i in {1..30}; do
    sleep 1; echo -n "."
    docker exec restaurantos-postgres pg_isready -U restaurantos -q 2>/dev/null && break
  done
  echo " ✓"
fi

# ── 5. Backend ────────────────────────────────
echo ""
echo "── Step 5: Backend ──"
cd "$ROOT/backend"
echo "Installing npm packages..."
npm install --legacy-peer-deps --loglevel error 2>/dev/null

echo "Generating Prisma client..."
npx prisma generate

echo "Running migrations..."
npx prisma migrate dev --name init --skip-seed 2>/dev/null || npx prisma db push

echo "Seeding demo data..."
npx ts-node --transpile-only src/seed.ts

# Kill any existing backend
fuser -k 4000/tcp 2>/dev/null || true
sleep 1

echo "Starting backend..."
nohup npm run dev > /tmp/ros-backend.log 2>&1 &
echo $! > /tmp/ros-backend.pid

for i in {1..20}; do
  sleep 1
  curl -sf http://localhost:4000/health > /dev/null && echo "✓ Backend up at http://localhost:4000" && break
done

# ── 6. Frontend ───────────────────────────────
echo ""
echo "── Step 6: Frontend ──"
cd "$ROOT/frontend"
echo "Installing npm packages..."
npm install --legacy-peer-deps --loglevel error 2>/dev/null

echo "Building Next.js app..."
npm run build

# Kill any existing frontend
fuser -k 3000/tcp 2>/dev/null || true
sleep 1

echo "Starting frontend..."
nohup npm start > /tmp/ros-frontend.log 2>&1 &
echo $! > /tmp/ros-frontend.pid

for i in {1..30}; do
  sleep 2
  curl -sf http://localhost:3000 > /dev/null && echo "✓ Frontend up at http://localhost:3000" && break
done

# ── Done ──────────────────────────────────────
echo ""
echo "════════════════════════════════════════════"
echo "✅  RestaurantOS is LIVE!"
echo "════════════════════════════════════════════"
SERVER_IP=$(curl -sf ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')
echo ""
echo "  🌐  http://$SERVER_IP:3000"
echo "  🔧  http://$SERVER_IP:4000/health"
echo ""
echo "  Demo accounts (password: demo1234)"
echo "  👑  owner@kazunori.com    (Owner)"
echo "  👔  manager@kazunori.com  (Manager)"
echo "  👨‍🍳  chef@kazunori.com     (Chef)"
echo ""
echo "  Logs:"
echo "  tail -f /tmp/ros-backend.log"
echo "  tail -f /tmp/ros-frontend.log"
echo "════════════════════════════════════════════"
