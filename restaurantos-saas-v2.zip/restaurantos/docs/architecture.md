# RestaurantOS — Production Architecture & Deployment Guide

## Complete File Structure

```
restaurantos/
├── README.md
├── docker-compose.yml
├── .env.example
│
├── backend/
│   ├── Dockerfile
│   ├── package.json
│   ├── tsconfig.json
│   ├── prisma/
│   │   └── schema.prisma          ← 19 tables, full PostgreSQL schema
│   └── src/
│       ├── index.ts               ← Express server
│       ├── middleware/
│       │   ├── auth.ts            ← JWT + RBAC + plan limits
│       │   └── errorHandler.ts
│       ├── routes/
│       │   ├── auth.ts            ← Register, login, refresh, invite
│       │   ├── organizations.ts   ← Org management
│       │   ├── locations.ts       ← Location CRUD
│       │   ├── sales.ts           ← Sales entries + summary
│       │   ├── inventory.ts       ← Inventory + low-stock
│       │   ├── invoices.ts        ← Upload, parse, review, apply
│       │   ├── labor.ts           ← Staff + shifts + summary
│       │   ├── recipes.ts         ← Recipe + ingredients
│       │   ├── finance.ts         ← P&L calculation + entries
│       │   ├── valuation.ts       ← Valuation snapshots
│       │   ├── billing.ts         ← Stripe checkout + portal
│       │   ├── alerts.ts          ← Alert CRUD
│       │   ├── admin.ts           ← Super-admin panel
│       │   └── webhooks.ts        ← Stripe webhook handler
│       ├── services/
│       │   ├── calculations.ts    ← All financial formulas
│       │   └── invoiceParser.ts   ← Claude Vision AI parsing
│       └── utils/
│           ├── prisma.ts          ← Prisma client singleton
│           ├── logger.ts          ← Winston logger
│           ├── email.ts           ← Resend email service
│           └── audit.ts           ← Audit log helper
│
└── frontend/
    ├── Dockerfile
    ├── package.json
    ├── tailwind.config.js
    ├── tsconfig.json
    ├── next.config.js
    └── src/
        ├── app/
        │   ├── layout.tsx          ← Root layout + providers
        │   ├── (auth)/
        │   │   ├── login/page.tsx
        │   │   ├── register/page.tsx
        │   │   └── invite/[token]/page.tsx
        │   └── dashboard/
        │       ├── layout.tsx      ← Sidebar + topbar
        │       ├── page.tsx        ← Dashboard (KPIs, charts, health)
        │       ├── locations/page.tsx
        │       ├── sales/page.tsx
        │       ├── inventory/page.tsx
        │       ├── staff/page.tsx
        │       ├── food-cost/page.tsx
        │       ├── invoices/page.tsx
        │       ├── finance/page.tsx
        │       ├── valuation/page.tsx
        │       ├── admin/page.tsx
        │       ├── billing/page.tsx
        │       └── settings/page.tsx
        ├── components/
        │   ├── HealthScoreRing.tsx
        │   ├── KPICard.tsx
        │   ├── AlertList.tsx
        │   ├── LocationSwitcher.tsx
        │   ├── DataTable.tsx
        │   ├── InvoiceDropzone.tsx
        │   └── ui/                 ← Button, Input, Card, Badge, etc.
        ├── lib/
        │   ├── api.ts             ← Axios client + all API methods
        │   └── utils.ts           ← formatCurrency, formatPct, etc.
        └── store/
            └── appStore.ts        ← Zustand global state
```

---

## Database Schema (19 Tables)

| Table                   | Purpose                                    |
|-------------------------|--------------------------------------------|
| users                   | User accounts                              |
| organizations           | Multi-tenant root (restaurants/groups)     |
| organization_users      | User ↔ Org membership + role              |
| refresh_tokens          | JWT refresh token store (rotated)          |
| team_invites            | Email-based team invitations               |
| subscriptions           | Stripe subscription per org                |
| locations               | Restaurant locations (multi-location)      |
| location_settings       | Per-location overrides                     |
| sales_entries           | Daily sales records                        |
| inventory_items         | Stock items with par levels                |
| inventory_transactions  | All stock movements (purchase/usage/waste) |
| suppliers               | Supplier directory                         |
| invoices                | Uploaded supplier invoices                 |
| invoice_line_items      | Parsed line items with mapping             |
| labor_staff             | Employee roster                            |
| labor_shifts            | Scheduled/actual shifts                    |
| recipes                 | Recipe cards                               |
| recipe_ingredients      | Recipe component costs                     |
| finance_entries         | Monthly P&L records                        |
| valuation_snapshots     | Business valuation history                 |
| alerts                  | System alerts (low stock, high costs)      |
| audit_logs              | All data changes tracked                   |

---

## API Routes (All Protected with JWT)

### Auth
| Method | Route                        | Description              |
|--------|------------------------------|--------------------------|
| POST   | /api/auth/register           | Create account + org     |
| POST   | /api/auth/login              | Login → access+refresh   |
| POST   | /api/auth/refresh            | Rotate refresh token     |
| POST   | /api/auth/logout             | Revoke refresh token     |
| GET    | /api/auth/me                 | Current user + org       |
| POST   | /api/auth/accept-invite/:tk  | Accept team invitation   |

### Finance Calculations
| Method | Route                           | Description              |
|--------|---------------------------------|--------------------------|
| POST   | /api/finance/:locId/calculate   | Run full P&L calc        |
| POST   | /api/finance/:locId/entries     | Save monthly entry       |
| GET    | /api/finance/:locId/summary     | Period summary           |
| GET    | /api/finance/:locId/entries     | Entry history            |

### Invoice Flow
| Method | Route                                  | Description              |
|--------|----------------------------------------|--------------------------|
| POST   | /api/invoices/:locId/upload            | Upload + trigger AI parse|
| GET    | /api/invoices/:locId/:invId            | Get with line items      |
| PATCH  | /api/invoices/:locId/:invId/line-items | Update mappings          |
| POST   | /api/invoices/:locId/:invId/apply      | Apply to inventory       |

---

## Key Business Logic

### Net Sales
```
Net Sales = Gross Sales - Discounts - Comps - Refunds
```

### COGS
```
COGS = Beginning Inventory + Purchases - Ending Inventory
```

### Food Cost %
```
Food Cost % = COGS / Net Sales × 100
Target: ≤ 30%   Warning: > 30%   Critical: > 35%
```

### Labor Cost %
```
Labor Cost % = Total Labor / Net Sales × 100
Target: ≤ 30%   Warning: > 30%   Critical: > 38%
```

### Prime Cost
```
Prime Cost = COGS + Total Labor
Prime Cost % = Prime Cost / Net Sales × 100
Target: ≤ 60%   Warning: > 60%   Critical: > 70%
```

### Break-Even
```
Fixed Costs = Rent + Utilities + Insurance + SaaS + Licenses
Variable Cost % = (COGS + Labor) / Net Sales
Break-Even Sales = Fixed Costs / (1 - Variable Cost %)
```

### Health Score (0–100)
```
Start: 100
- Food cost   > 35%: -18   > 30%: -8
- Labor cost  > 38%: -18   > 30%: -8
- Prime cost  > 70%: -22   > 60%: -10
- Net margin  < 0%:  -25   < 5%: -22   < 10%: -6
- Below break-even: -15
```

### Valuation
```
SDE = Annual Net Profit + Owner Salary + Interest + Depreciation
SDE Range   = SDE × 2   to SDE × 3
Rev Range   = Revenue × 0.5 to Revenue × 0.7
EBITDA      = EBITDA × multiple (2.5–4.5×)
Consensus   = min(all) to max(all)
```

---

## AI Invoice Parsing Flow

```
1. User uploads PDF/JPG/PNG/CSV
2. File stored in /uploads/invoices/ (or S3 in production)
3. Invoice record created with status=PROCESSING
4. Claude Vision API called asynchronously with system prompt:
   - Extract vendor name, address, invoice #, date, due date
   - Extract ALL line items: description, unit, qty, unit price, total
   - Hint category (Fish/Shellfish/Produce/Dry Goods/Overhead)
   - Return JSON only, no markdown
5. Response parsed, invoice_line_items created
6. Status → REVIEW
7. Frontend polls until REVIEW status
8. User reviews: edit quantities/prices, set mapping per line item
   - INVENTORY = add to stock + update cost
   - PURCHASES = count as COGS purchase only
   - OVERHEAD  = expense, no inventory update
   - IGNORE    = skip
9. User clicks "Apply"
10. Backend creates inventory_transactions for INVENTORY items
11. Increments quantity_on_hand, updates unit_cost
12. Status → APPLIED (immutable)
```

---

## User Roles & Permissions

| Permission              | Owner | Manager | Chef | Staff | Consultant |
|-------------------------|-------|---------|------|-------|------------|
| View all data           | ✓     | ✓       | ✓    | —     | ✓ (read)   |
| Edit sales              | ✓     | ✓       | —    | —     | —          |
| Edit inventory          | ✓     | ✓       | ✓    | —     | —          |
| Apply invoices          | ✓     | ✓       | ✓    | —     | —          |
| Edit labor/schedules    | ✓     | ✓       | —    | —     | —          |
| Edit recipes            | ✓     | ✓       | ✓    | —     | —          |
| View finance/P&L        | ✓     | ✓       | —    | —     | ✓          |
| Edit finance entries    | ✓     | ✓       | —    | —     | —          |
| Manage team             | ✓     | ✓       | —    | —     | —          |
| Billing                 | ✓     | —       | —    | —     | —          |
| Admin panel             | ✓     | —       | —    | —     | —          |

---

## Plans & Limits

| Feature                   | Starter $49 | Pro $149      | Enterprise $399  |
|---------------------------|-------------|---------------|------------------|
| Locations                 | 1           | 5             | Unlimited        |
| Staff accounts            | 3           | Unlimited     | Unlimited        |
| AI invoice parses/mo      | 10          | 100           | Unlimited        |
| Multi-location comparisons| —           | ✓             | ✓                |
| P&L & Finance             | Basic       | Full          | Full             |
| Valuation engine          | —           | ✓             | ✓                |
| API access                | —           | —             | ✓                |
| White-label reports       | —           | —             | ✓                |
| PDF export                | ✓           | ✓             | ✓                |
| Priority support          | —           | ✓             | ✓ + Dedicated    |

---

## Deployment

### Docker (local/self-hosted)
```bash
docker-compose up -d
cd backend && npx prisma migrate dev && npx ts-node src/seed.ts
```

### Railway (recommended for fast launch)
```bash
# Connect GitHub repo to Railway
# Add environment variables in Railway dashboard
# Set root directory to /backend for backend service
# Set root directory to /frontend for frontend service
# Railway auto-detects Dockerfile and builds
```

### Environment Variables Required
```
DATABASE_URL              PostgreSQL connection string
JWT_SECRET                Random 64-char string
JWT_REFRESH_SECRET        Different random 64-char string
STRIPE_SECRET_KEY         sk_live_... or sk_test_...
STRIPE_WEBHOOK_SECRET     whsec_...
STRIPE_STARTER_PRICE_ID   price_...
STRIPE_PRO_PRICE_ID       price_...
STRIPE_ENTERPRISE_PRICE_ID price_...
ANTHROPIC_API_KEY         sk-ant-...
AWS_ACCESS_KEY_ID         For S3 file storage
AWS_SECRET_ACCESS_KEY     For S3 file storage
AWS_BUCKET                restaurantos-uploads
AWS_REGION                us-east-1
RESEND_API_KEY            re_...
FROM_EMAIL                noreply@restaurantos.app
FRONTEND_URL              https://app.restaurantos.com
NEXT_PUBLIC_API_URL       https://api.restaurantos.com
```

---

## Production Checklist

### Security
- [ ] JWT secrets are 64+ random characters
- [ ] HTTPS enforced (Cloudflare / load balancer)
- [ ] Rate limiting on all API routes
- [ ] File upload size/type validation
- [ ] SQL injection prevented (Prisma parameterized queries)
- [ ] CORS restricted to frontend domain
- [ ] Helmet.js security headers
- [ ] Audit logs for all data mutations

### Database
- [ ] Connection pooling (PgBouncer or Prisma Data Proxy)
- [ ] Regular backups enabled
- [ ] Indexes on: userId, organizationId, locationId, date columns
- [ ] RLS (Row Level Security) in Supabase if used

### Payments
- [ ] Stripe webhook endpoint registered + tested
- [ ] Webhook signature verification enabled
- [ ] Test all plan upgrade/downgrade flows
- [ ] Test cancellation + reactivation

### AI Invoice Parsing
- [ ] Anthropic API key in production
- [ ] Token usage monitoring set up
- [ ] Fallback error message for failed parses
- [ ] Manual entry always available as fallback

### Observability
- [ ] Winston logging to file + console
- [ ] Error tracking (Sentry recommended)
- [ ] Uptime monitoring (Better Uptime / UptimeRobot)
- [ ] Database query performance monitoring

### Performance
- [ ] Next.js image optimization enabled
- [ ] API response caching for expensive queries
- [ ] Database query N+1s audited
- [ ] CDN for static assets

---

## $1M SaaS Roadmap

### Phase 1 — Launch (Month 1-3)
- Ship core platform (this codebase)
- 50 paying restaurants
- Focus: single-location, food cost, invoices

### Phase 2 — Growth (Month 4-6)
- POS integrations (Square, Toast, Clover)
- Mobile app (React Native)
- Advanced analytics + cohort comparison
- Supplier portal
- 200 paying restaurants

### Phase 3 — Enterprise (Month 7-12)
- Franchise management module
- Benchmark data (anonymous industry averages)
- Automated purchasing recommendations
- Accounting integrations (QuickBooks, Xero)
- Custom branded reports
- White-label for consultants
- 500+ paying restaurants → $1M ARR
