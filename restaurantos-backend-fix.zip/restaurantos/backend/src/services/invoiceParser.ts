import Anthropic from '@anthropic-ai/sdk';
import { readFile } from 'fs/promises';
import { extname } from 'path';
import { logger } from '../utils/logger';

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export interface ParsedInvoice {
  vendorName: string | null;
  vendorAddress: string | null;
  invoiceNumber: string | null;
  invoiceDate: string | null;
  dueDate: string | null;
  subtotal: number;
  taxAmount: number;
  shippingAmount: number;
  totalAmount: number;
  currency: string;
  lineItems: ParsedLineItem[];
  confidence: number; // 0-1
  rawText: string;
}

export interface ParsedLineItem {
  description: string;
  unit: string | null;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  category: string | null; // hinted category
}

// ── Parse invoice using Claude Vision ──────────
export async function parseInvoiceWithAI(
  filePath: string,
  fileType: string,
): Promise<ParsedInvoice> {
  try {
    const ext = extname(filePath).toLowerCase().replace('.', '');
    const isImage = ['jpg', 'jpeg', 'png', 'webp'].includes(ext);
    const isPdf = ext === 'pdf';
    const isCsv = ['csv', 'txt'].includes(ext);

    if (isCsv) {
      return await parseCSVInvoice(filePath);
    }

    // For images and PDFs, use Claude Vision
    const fileBuffer = await readFile(filePath);
    const base64Data = fileBuffer.toString('base64');

    let mediaType: 'image/jpeg' | 'image/png' | 'image/webp' | 'application/pdf';
    if (isPdf) mediaType = 'application/pdf';
    else if (ext === 'png') mediaType = 'image/png';
    else if (ext === 'webp') mediaType = 'image/webp';
    else mediaType = 'image/jpeg';

    const systemPrompt = `You are an expert at extracting structured data from supplier invoices for restaurants.
Extract ALL line items exactly as they appear. Be precise with quantities, units, and prices.
Always respond with valid JSON only — no markdown, no explanation.`;

    const userPrompt = `Extract all data from this supplier invoice and return JSON in exactly this structure:
{
  "vendorName": "string or null",
  "vendorAddress": "string or null", 
  "invoiceNumber": "string or null",
  "invoiceDate": "YYYY-MM-DD or null",
  "dueDate": "YYYY-MM-DD or null",
  "subtotal": number,
  "taxAmount": number,
  "shippingAmount": number,
  "totalAmount": number,
  "currency": "USD",
  "confidence": number between 0 and 1,
  "lineItems": [
    {
      "description": "exact product name",
      "unit": "LB/EA/CS/etc or null",
      "quantity": number,
      "unitPrice": number,
      "totalPrice": number,
      "category": "Fish/Shellfish/Produce/Dry Goods/Beverage/Other or null"
    }
  ]
}

Rules:
- Extract EVERY line item, even delivery/handling charges
- Use 0 for any monetary values you cannot determine
- For quantities: if per-unit (e.g. "10 LB"), use 10 and LB as unit
- For fish/seafood category: Fish for finfish, Shellfish for shellfish/crustaceans
- confidence: 0.9+ if all data clear, 0.6-0.9 if some uncertainty, <0.6 if poor quality`;

    const message = await anthropic.messages.create({
      model: 'claude-opus-4-5',
      max_tokens: 4000,
      system: systemPrompt,
      messages: [
        {
          role: 'user',
          content: [
            {
              type: isPdf ? 'document' : 'image',
              source: {
                type: 'base64',
                media_type: mediaType,
                data: base64Data,
              },
            } as any,
            { type: 'text', text: userPrompt },
          ],
        },
      ],
    });

    const responseText = message.content[0].type === 'text' ? message.content[0].text : '';

    // Parse JSON response
    const cleanJson = responseText.replace(/```json\n?|```\n?/g, '').trim();
    const parsed = JSON.parse(cleanJson);

    return {
      ...parsed,
      rawText: responseText,
    };
  } catch (err) {
    logger.error('Invoice parsing failed:', err);
    throw new Error('Failed to parse invoice. Please try again or enter data manually.');
  }
}

// ── Parse CSV invoices ──────────────────────────
async function parseCSVInvoice(filePath: string): Promise<ParsedInvoice> {
  const content = await readFile(filePath, 'utf-8');
  const lines = content.split('\n').filter(l => l.trim());

  const lineItems: ParsedLineItem[] = [];
  let totalAmount = 0;

  // Try to detect header row
  const headerLine = lines[0]?.toLowerCase() || '';
  const hasHeader = headerLine.includes('description') || headerLine.includes('product') || headerLine.includes('item');
  const dataLines = hasHeader ? lines.slice(1) : lines;

  for (const line of dataLines) {
    const cols = line.split(',').map(c => c.trim().replace(/^"|"$/g, ''));
    if (cols.length < 2) continue;

    // Try to extract numeric values from columns
    const nums = cols.map(c => parseFloat(c.replace(/[$,]/g, ''))).filter(n => !isNaN(n));
    if (nums.length === 0) continue;

    const description = cols[0] || 'Unknown item';
    const quantity = nums[0] || 1;
    const unitPrice = nums[1] || 0;
    const totalPrice = nums[nums.length - 1] || quantity * unitPrice;

    lineItems.push({
      description,
      unit: cols[1] && isNaN(parseFloat(cols[1])) ? cols[1] : null,
      quantity,
      unitPrice,
      totalPrice,
      category: guessCategoryFromName(description),
    });

    totalAmount += totalPrice;
  }

  return {
    vendorName: null,
    vendorAddress: null,
    invoiceNumber: null,
    invoiceDate: null,
    dueDate: null,
    subtotal: totalAmount,
    taxAmount: 0,
    shippingAmount: 0,
    totalAmount,
    currency: 'USD',
    lineItems,
    confidence: 0.7,
    rawText: content,
  };
}

// ── Category guesser ────────────────────────────
function guessCategoryFromName(name: string): string | null {
  const lower = name.toLowerCase();
  if (/salmon|tuna|halibut|mahi|albacore|snapper|sea bass|branzino|fluke|sole|cod|tilapia|swordfish|yellowtail|toro/.test(lower)) return 'Fish';
  if (/shrimp|lobster|crab|scallop|oyster|clam|squid|octopus|mussel/.test(lower)) return 'Shellfish';
  if (/avocado|cucumber|lettuce|tomato|onion|garlic|pepper|lemon|lime|herb|cilantro|jalapeño/.test(lower)) return 'Produce';
  if (/rice|nori|soy|sesame|vinegar|sugar|salt|flour|oil|sauce|mayo|ponzu|furikake/.test(lower)) return 'Dry Goods';
  if (/beer|wine|sake|juice|soda|water|drink|beverage/.test(lower)) return 'Beverages';
  if (/delivery|freight|handling|shipping/.test(lower)) return 'Overhead';
  return 'Other';
}
