/**
 * RestaurantOS — Finance Calculation Service
 * All financial formulas live here, testable and reusable.
 */

export interface NetSalesInput {
  grossSales: number;
  discounts: number;
  comps: number;
  refunds: number;
  otherIncome: number;
}

export interface COGSInput {
  beginningInventory: number;
  purchases: number;
  endingInventory: number;
}

export interface LaborInput {
  hourlyWages: number;
  salaryWages: number;
  payrollTax: number;
  benefits: number;
}

export interface OpexInput {
  rent: number;
  utilities: number;
  insurance: number;
  marketing: number;
  repairs: number;
  softwarePos: number;
  licenses: number;
  creditCardFees: number;
  deliveryFees: number;
  otherExpenses: number;
}

export interface FinanceInput {
  sales: NetSalesInput;
  cogs: COGSInput;
  labor: LaborInput;
  opex: OpexInput;
}

export interface FinancialResults {
  // Revenue
  grossSales: number;
  totalDiscounts: number;
  netSales: number;
  totalRevenue: number;

  // COGS
  cogs: number;
  foodCostPct: number;

  // Labor
  totalLaborCost: number;
  laborCostPct: number;

  // Prime Cost
  primeCost: number;
  primeCostPct: number;

  // Profit
  grossProfit: number;
  grossMarginPct: number;
  totalOpex: number;
  ebitda: number;
  netProfit: number;
  netMarginPct: number;

  // Break-even
  fixedCosts: number;
  variableCostPct: number;
  breakEvenSales: number;
  breakEvenGap: number;

  // Health score (0-100)
  healthScore: number;
  healthStatus: 'HEALTHY' | 'WATCH' | 'HIGH_RISK';

  // Alerts
  alerts: HealthAlert[];
}

export interface HealthAlert {
  type: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  message: string;
  value: number;
  target: number;
}

export interface ValuationInput {
  netProfit: number;         // period net profit
  periodMultiplier: number;  // 12 for monthly, 1 for annual
  ownerSalary: number;       // annual add-back
  interest: number;          // annual add-back
  depreciation: number;      // annual add-back
  annualRevenue: number;
  ebitda: number;
  ebitdaMultiple: number;    // typically 2.5–4.5 for restaurants
}

export interface ValuationResults {
  annualNetProfit: number;
  sde: number;
  sdeLow: number;     // SDE × 2
  sdeHigh: number;    // SDE × 3
  revMultipleLow: number;  // Revenue × 0.5
  revMultipleHigh: number; // Revenue × 0.7
  ebitdaValue: number;     // EBITDA × multiple
  consensusLow: number;
  consensusHigh: number;
}

// ════════════════════════════════════════════════
// NET SALES
// ════════════════════════════════════════════════
export function calcNetSales(input: NetSalesInput): number {
  return Math.max(0, input.grossSales - input.discounts - input.comps - input.refunds);
}

// ════════════════════════════════════════════════
// COGS = Beginning + Purchases - Ending
// ════════════════════════════════════════════════
export function calcCOGS(input: COGSInput): number {
  return Math.max(0, input.beginningInventory + input.purchases - input.endingInventory);
}

// ════════════════════════════════════════════════
// FULL P&L CALCULATION
// ════════════════════════════════════════════════
export function calcFinancials(input: FinanceInput): FinancialResults {
  const netSales = calcNetSales(input.sales);
  const totalRevenue = netSales + input.sales.otherIncome;
  const grossSales = input.sales.grossSales;
  const totalDiscounts = input.sales.discounts + input.sales.comps + input.sales.refunds;

  // COGS
  const cogs = calcCOGS(input.cogs);
  const foodCostPct = totalRevenue > 0 ? (cogs / totalRevenue) * 100 : 0;

  // Labor
  const totalLaborCost = input.labor.hourlyWages + input.labor.salaryWages
    + input.labor.payrollTax + input.labor.benefits;
  const laborCostPct = totalRevenue > 0 ? (totalLaborCost / totalRevenue) * 100 : 0;

  // Prime Cost = COGS + Labor
  const primeCost = cogs + totalLaborCost;
  const primeCostPct = totalRevenue > 0 ? (primeCost / totalRevenue) * 100 : 0;

  // Gross Profit = Revenue - COGS
  const grossProfit = totalRevenue - cogs;
  const grossMarginPct = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;

  // Operating Expenses
  const totalOpex = input.opex.rent + input.opex.utilities + input.opex.insurance
    + input.opex.marketing + input.opex.repairs + input.opex.softwarePos
    + input.opex.licenses + input.opex.creditCardFees + input.opex.deliveryFees
    + input.opex.otherExpenses;

  // EBITDA = Gross Profit - Labor - Opex + D&A (simplified, no D&A here)
  const ebitda = grossProfit - totalLaborCost - totalOpex;

  // Net Profit
  const netProfit = totalRevenue - cogs - totalLaborCost - totalOpex;
  const netMarginPct = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

  // Break-even: Fixed Costs / (1 - Variable Cost %)
  const fixedCosts = input.opex.rent + input.opex.utilities + input.opex.insurance
    + input.opex.softwarePos + input.opex.licenses;
  const variableCostPct = totalRevenue > 0 ? (cogs + totalLaborCost) / totalRevenue : 0;
  const breakEvenSales = variableCostPct < 1 ? fixedCosts / (1 - variableCostPct) : 0;
  const breakEvenGap = netSales - breakEvenSales;

  // Health Score (0–100)
  const { score, alerts } = calcHealthScore({
    foodCostPct,
    laborCostPct,
    primeCostPct,
    netMarginPct,
    breakEvenGap,
    netSales,
  });

  const healthStatus = score >= 80 ? 'HEALTHY' : score >= 60 ? 'WATCH' : 'HIGH_RISK';

  return {
    grossSales,
    totalDiscounts,
    netSales,
    totalRevenue,
    cogs,
    foodCostPct,
    totalLaborCost,
    laborCostPct,
    primeCost,
    primeCostPct,
    grossProfit,
    grossMarginPct,
    totalOpex,
    ebitda,
    netProfit,
    netMarginPct,
    fixedCosts,
    variableCostPct: variableCostPct * 100,
    breakEvenSales,
    breakEvenGap,
    healthScore: score,
    healthStatus,
    alerts,
  };
}

// ════════════════════════════════════════════════
// HEALTH SCORE ENGINE
// ════════════════════════════════════════════════
interface HealthInput {
  foodCostPct: number;
  laborCostPct: number;
  primeCostPct: number;
  netMarginPct: number;
  breakEvenGap: number;
  netSales: number;
}

function calcHealthScore(input: HealthInput): { score: number; alerts: HealthAlert[] } {
  let score = 100;
  const alerts: HealthAlert[] = [];

  // Food Cost (target: ≤30%, warning: >35%)
  if (input.foodCostPct > 35) {
    score -= 18;
    alerts.push({
      type: 'HIGH_FOOD_COST',
      severity: 'CRITICAL',
      message: `Food cost ${input.foodCostPct.toFixed(1)}% is critically above the 35% threshold. Audit portions, waste, and pricing immediately.`,
      value: input.foodCostPct,
      target: 30,
    });
  } else if (input.foodCostPct > 30) {
    score -= 8;
    alerts.push({
      type: 'HIGH_FOOD_COST',
      severity: 'WARNING',
      message: `Food cost ${input.foodCostPct.toFixed(1)}% is above the 30% target. Monitor inventory and purchasing closely.`,
      value: input.foodCostPct,
      target: 30,
    });
  } else {
    alerts.push({
      type: 'FOOD_COST_OK',
      severity: 'INFO',
      message: `Food cost ${input.foodCostPct.toFixed(1)}% is healthy and on target.`,
      value: input.foodCostPct,
      target: 30,
    });
  }

  // Labor Cost (target: ≤30%, warning: >38%)
  if (input.laborCostPct > 38) {
    score -= 18;
    alerts.push({
      type: 'HIGH_LABOR_COST',
      severity: 'CRITICAL',
      message: `Labor cost ${input.laborCostPct.toFixed(1)}% is too high. Review scheduling, overtime, and staffing levels.`,
      value: input.laborCostPct,
      target: 30,
    });
  } else if (input.laborCostPct > 30) {
    score -= 8;
    alerts.push({
      type: 'HIGH_LABOR_COST',
      severity: 'WARNING',
      message: `Labor cost ${input.laborCostPct.toFixed(1)}% is slightly elevated. Watch slow-day staffing.`,
      value: input.laborCostPct,
      target: 30,
    });
  }

  // Prime Cost (target: ≤60%)
  if (input.primeCostPct > 70) {
    score -= 22;
    alerts.push({
      type: 'HIGH_PRIME_COST',
      severity: 'CRITICAL',
      message: `Prime cost ${input.primeCostPct.toFixed(1)}% leaves almost no room for overhead and profit. Reduce food or labor immediately.`,
      value: input.primeCostPct,
      target: 60,
    });
  } else if (input.primeCostPct > 60) {
    score -= 10;
    alerts.push({
      type: 'HIGH_PRIME_COST',
      severity: 'WARNING',
      message: `Prime cost ${input.primeCostPct.toFixed(1)}% is just above the 60% target. Tighten purchasing and labor.`,
      value: input.primeCostPct,
      target: 60,
    });
  }

  // Net Margin (target: ≥10%, minimum: 5%)
  if (input.netMarginPct < 0) {
    score -= 25;
    alerts.push({
      type: 'NEGATIVE_MARGIN',
      severity: 'CRITICAL',
      message: `Net margin is negative (${input.netMarginPct.toFixed(1)}%). The restaurant is operating at a loss.`,
      value: input.netMarginPct,
      target: 10,
    });
  } else if (input.netMarginPct < 5) {
    score -= 22;
    alerts.push({
      type: 'LOW_NET_MARGIN',
      severity: 'CRITICAL',
      message: `Net margin ${input.netMarginPct.toFixed(1)}% is below the minimum healthy 5%. Review all overhead categories.`,
      value: input.netMarginPct,
      target: 5,
    });
  } else if (input.netMarginPct < 10) {
    score -= 6;
    alerts.push({
      type: 'LOW_NET_MARGIN',
      severity: 'WARNING',
      message: `Net margin ${input.netMarginPct.toFixed(1)}% is in range but below the 10% ideal. Look for efficiency gains.`,
      value: input.netMarginPct,
      target: 10,
    });
  } else {
    alerts.push({
      type: 'NET_MARGIN_OK',
      severity: 'INFO',
      message: `Net margin ${input.netMarginPct.toFixed(1)}% is strong. Excellent financial health.`,
      value: input.netMarginPct,
      target: 10,
    });
  }

  // Break-even
  if (input.breakEvenGap < 0) {
    score -= 15;
    alerts.push({
      type: 'BELOW_BREAKEVEN',
      severity: 'CRITICAL',
      message: `Sales are $${Math.abs(input.breakEvenGap).toLocaleString()} below break-even. Costs must be reduced or sales increased.`,
      value: input.breakEvenGap,
      target: 0,
    });
  } else if (input.breakEvenGap < input.netSales * 0.1) {
    score -= 5;
    alerts.push({
      type: 'LOW_BREAKEVEN_MARGIN',
      severity: 'WARNING',
      message: `Only $${input.breakEvenGap.toLocaleString()} above break-even. Limited safety margin.`,
      value: input.breakEvenGap,
      target: input.netSales * 0.15,
    });
  }

  return { score: Math.max(0, Math.min(100, Math.round(score))), alerts };
}

// ════════════════════════════════════════════════
// VALUATION
// ════════════════════════════════════════════════
export function calcValuation(input: ValuationInput): ValuationResults {
  const annualNetProfit = input.netProfit * input.periodMultiplier;

  // SDE = Annual Net Profit + Owner Salary + Interest + Depreciation
  const sde = annualNetProfit + input.ownerSalary + input.interest + input.depreciation;
  const sdeLow = sde * 2;
  const sdeHigh = sde * 3;

  // Revenue Multiple: 0.5× – 0.7× for restaurants
  const revMultipleLow  = input.annualRevenue * 0.5;
  const revMultipleHigh = input.annualRevenue * 0.7;

  // EBITDA Multiple
  const ebitdaValue = input.ebitda * input.ebitdaMultiple;

  // Consensus: average across methods
  const allValues = [sdeLow, sdeHigh, revMultipleLow, revMultipleHigh, ebitdaValue].filter(v => v > 0);
  const consensusLow  = Math.min(...allValues);
  const consensusHigh = Math.max(...allValues);

  return {
    annualNetProfit,
    sde,
    sdeLow,
    sdeHigh,
    revMultipleLow,
    revMultipleHigh,
    ebitdaValue,
    consensusLow,
    consensusHigh,
  };
}

// ════════════════════════════════════════════════
// RECIPE FOOD COST
// ════════════════════════════════════════════════
export interface RecipeIngredientCost {
  quantity: number;
  unitCost: number;
  wastePercent: number;
}

export function calcRecipeIngredientCost(ing: RecipeIngredientCost): number {
  const effectiveCost = ing.unitCost * (1 + ing.wastePercent / 100);
  return effectiveCost * ing.quantity;
}

export function calcRecipeFoodCostPct(totalIngredientCost: number, menuPrice: number): number {
  if (menuPrice <= 0) return 0;
  return (totalIngredientCost / menuPrice) * 100;
}

export function calcMenuPriceForTarget(totalIngredientCost: number, targetFcPct: number): number {
  if (targetFcPct <= 0) return 0;
  return totalIngredientCost / (targetFcPct / 100);
}
