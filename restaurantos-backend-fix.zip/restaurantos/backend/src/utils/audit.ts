import { prisma } from './prisma';
import { logger } from './logger';

interface AuditLogInput {
  organizationId: string;
  userId?: string;
  action: string;
  resource: string;
  resourceId?: string;
  oldValues?: any;
  newValues?: any;
  ipAddress?: string;
  userAgent?: string;
}

export async function auditLog(input: AuditLogInput): Promise<void> {
  try {
    await prisma.auditLog.create({ data: input });
  } catch (err) {
    // Non-fatal — never let audit failure break the main flow
    logger.error('Audit log write failed:', err);
  }
}
