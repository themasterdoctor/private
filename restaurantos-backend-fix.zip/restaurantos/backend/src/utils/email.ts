import { logger } from './logger';

interface SendEmailOpts { to: string; subject: string; html?: string; text?: string; }

export async function sendEmail({ to, subject, html, text }: SendEmailOpts): Promise<void> {
  try {
    const key = process.env.RESEND_API_KEY;
    if (!key || key === 're_placeholder' || key.startsWith('re_placeholder')) {
      logger.info(`[Email skipped] To: ${to} | ${subject}`);
      return;
    }
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: process.env.FROM_EMAIL || 'noreply@restaurantos.app',
        to, subject,
        html: html || `<p>${text || ''}</p>`,
        text,
      }),
    });
    if (!res.ok) logger.error(`Email failed (${res.status}): ${await res.text()}`);
    else logger.info(`Email sent → ${to}`);
  } catch (err) { logger.error('Email error:', err); }
}

export async function sendWelcomeEmail(email: string, firstName: string, orgName: string) {
  return sendEmail({ to: email, subject: `Welcome to RestaurantOS, ${firstName}!`,
    html: `<h2 style="color:#00E5A0">Welcome 🍽️</h2><p>Hi ${firstName}, your <strong>${orgName}</strong> account is ready.</p><a href="${process.env.FRONTEND_URL}/login" style="display:inline-block;background:#00E5A0;color:#000;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;margin:16px 0">Open RestaurantOS →</a>` });
}

export async function sendInviteEmail(email: string, orgName: string, inviteUrl: string, senderName: string) {
  return sendEmail({ to: email, subject: `Invited to join ${orgName} on RestaurantOS`,
    html: `<p><strong>${senderName}</strong> invited you to <strong>${orgName}</strong>.</p><a href="${inviteUrl}" style="display:inline-block;background:#00E5A0;color:#000;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600">Accept Invite →</a>` });
}

export async function sendAlertEmail(email: string, locationName: string, alerts: Array<{message: string; severity: string}>) {
  return sendEmail({ to: email, subject: `RestaurantOS Alert — ${locationName}`,
    html: `<h3>⚠️ ${locationName}</h3>${alerts.map(a => `<p><strong style="color:${a.severity==='CRITICAL'?'#F05050':'#F0A030'}">[${a.severity}]</strong> ${a.message}</p>`).join('')}` });
}
