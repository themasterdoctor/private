import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { prisma } from '../utils/prisma';
import { UserRole } from '@prisma/client';

export interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
    organizationId: string;
    role: UserRole;
    locationIds: string[];
  };
}

// ── Verify JWT ──────────────────────────────────
export const authenticate = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    const header = req.headers.authorization;
    if (!header?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token provided' });
    }
    const token = header.slice(7);
    const payload = jwt.verify(token, process.env.JWT_SECRET!) as any;

    // Load org membership
    const orgUser = await prisma.organizationUser.findUnique({
      where: {
        userId_organizationId: {
          userId: payload.userId,
          organizationId: payload.organizationId,
        },
      },
    });
    if (!orgUser) {
      return res.status(401).json({ error: 'Organization access revoked' });
    }

    req.user = {
      id: payload.userId,
      email: payload.email,
      organizationId: payload.organizationId,
      role: orgUser.role,
      locationIds: orgUser.locationIds,
    };
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
};

// ── Require specific roles ──────────────────────
export const requireRole = (...roles: UserRole[]) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        error: `Insufficient permissions. Required: ${roles.join(' or ')}`,
      });
    }
    next();
  };
};

// ── Check location access ───────────────────────
export const requireLocationAccess = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  if (!req.user) return res.status(401).json({ error: 'Not authenticated' });

  const locationId = req.params.locationId || req.body.locationId || req.query.locationId as string;
  if (!locationId) return next(); // No location param, skip

  // Owners/Managers see all locations
  if ([UserRole.OWNER, UserRole.SUPER_ADMIN].includes(req.user.role)) {
    return next();
  }

  // Empty array = access all locations
  if (req.user.locationIds.length === 0) return next();

  // Check specific access
  if (!req.user.locationIds.includes(locationId)) {
    return res.status(403).json({ error: 'No access to this location' });
  }

  // Also verify location belongs to the user's org
  const location = await prisma.location.findFirst({
    where: { id: locationId, organizationId: req.user.organizationId },
  });
  if (!location) {
    return res.status(404).json({ error: 'Location not found' });
  }

  next();
};

// ── Plan limits middleware ──────────────────────
export const checkPlanLimit = (feature: 'locations' | 'users' | 'aiParses') => {
  return async (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) return res.status(401).json({ error: 'Not authenticated' });

    const sub = await prisma.subscription.findUnique({
      where: { organizationId: req.user.organizationId },
    });
    if (!sub) return next(); // No sub = trial, allow

    const limits = {
      STARTER: { locations: 1, users: 3, aiParses: 10 },
      PRO:     { locations: 5, users: Infinity, aiParses: 100 },
      ENTERPRISE: { locations: Infinity, users: Infinity, aiParses: Infinity },
    };

    const planLimits = limits[sub.plan];

    if (feature === 'locations') {
      const count = await prisma.location.count({
        where: { organizationId: req.user.organizationId, isActive: true },
      });
      if (count >= planLimits.locations) {
        return res.status(402).json({
          error: `Your ${sub.plan} plan allows ${planLimits.locations} location(s). Upgrade to add more.`,
          upgradeRequired: true,
        });
      }
    }

    if (feature === 'users') {
      const count = await prisma.organizationUser.count({
        where: { organizationId: req.user.organizationId },
      });
      if (count >= planLimits.users) {
        return res.status(402).json({
          error: `Your ${sub.plan} plan allows ${planLimits.users} user(s). Upgrade to add more.`,
          upgradeRequired: true,
        });
      }
    }

    next();
  };
};
