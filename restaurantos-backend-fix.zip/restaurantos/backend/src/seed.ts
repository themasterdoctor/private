/**
 * RestaurantOS — Demo Seed
 * Run: npx ts-node src/seed.ts
 */

import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding RestaurantOS demo data…');

  // ── Users ──
  const pw = await bcrypt.hash('demo1234', 12);

  const owner = await prisma.user.upsert({
    where: { email: 'owner@kazunori.com' },
    update: {},
    create: { email: 'owner@kazunori.com', passwordHash: pw, firstName: 'Kenji', lastName: 'Nozawa' },
  });

  const manager = await prisma.user.upsert({
    where: { email: 'manager@kazunori.com' },
    update: {},
    create: { email: 'manager@kazunori.com', passwordHash: pw, firstName: 'Yuki', lastName: 'Tanaka' },
  });

  const chef = await prisma.user.upsert({
    where: { email: 'chef@kazunori.com' },
    update: {},
    create: { email: 'chef@kazunori.com', passwordHash: pw, firstName: 'Luis', lastName: 'Reyes' },
  });

  // ── Organization ──
  const org = await prisma.organization.upsert({
    where: { slug: 'kazunori-by-sushi-nozawa' },
    update: {},
    create: { name: 'Kazunori by Sushi Nozawa', slug: 'kazunori-by-sushi-nozawa' },
  });

  // ── Org users ──
  for (const [userId, role] of [[owner.id, 'OWNER'], [manager.id, 'MANAGER'], [chef.id, 'CHEF']] as const) {
    await prisma.organizationUser.upsert({
      where: { userId_organizationId: { userId, organizationId: org.id } },
      update: {},
      create: { userId, organizationId: org.id, role, locationIds: [], isDefault: true },
    });
  }

  // ── Subscription ──
  await prisma.subscription.upsert({
    where: { organizationId: org.id },
    update: {},
    create: {
      organizationId: org.id,
      stripeCustomerId: `cus_demo_${org.id}`,
      plan: 'PRO',
      status: 'ACTIVE',
      currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    },
  });

  // ── Locations ──
  const locations = [
    { name: 'West Hollywood',  type: 'CASUAL_DINING', city: 'West Hollywood', state: 'CA' },
    { name: 'Studio City',     type: 'CASUAL_DINING', city: 'Studio City',    state: 'CA' },
    { name: 'Century City',    type: 'FINE_DINING',   city: 'Los Angeles',    state: 'CA' },
  ];

  const createdLocations = [];
  for (const loc of locations) {
    const l = await prisma.location.upsert({
      where: { id: `loc_${org.id}_${loc.name.replace(/\s/g,'_').toLowerCase()}` },
      update: {},
      create: {
        id: `loc_${org.id}_${loc.name.replace(/\s/g,'_').toLowerCase()}`,
        organizationId: org.id,
        name: loc.name,
        type: loc.type as any,
        city: loc.city,
        state: loc.state,
        targetFoodCostPct: 30,
        targetLaborCostPct: 30,
        targetPrimeCostPct: 60,
        targetMonthlySales: 90000,
      },
    });
    createdLocations.push(l);
  }

  const loc = createdLocations[0]; // West Hollywood as primary

  // ── Supplier ──
  const supplier = await prisma.supplier.upsert({
    where: { id: `sup_${loc.id}_ocean` },
    update: {},
    create: {
      id: `sup_${loc.id}_ocean`,
      locationId: loc.id,
      name: 'Ocean Seafood Depot',
      contactName: 'Helia Miranda',
      phone: '973-418-3802',
      paymentTerms: 'Net 30',
    },
  });

  // ── Inventory ──
  const inventoryItems = [
    { name: 'Salmon 12-14 (Whole)',     category: 'Fish',      unit: 'LB',  qty: 18, min: 5,  cost: 5.50  },
    { name: 'Tuna #2+',                 category: 'Fish',      unit: 'LB',  qty: 12, min: 4,  cost: 12.99 },
    { name: 'Madai Japanese Snapper',   category: 'Fish',      unit: 'LB',  qty: 8,  min: 3,  cost: 13.95 },
    { name: 'Yellowtail (Hamachi)',      category: 'Fish',      unit: 'LB',  qty: 3,  min: 4,  cost: 9.50  },
    { name: 'Lump Crabmeat',            category: 'Shellfish', unit: 'LB',  qty: 10, min: 3,  cost: 12.95 },
    { name: 'Bay Scallop 10-20 dry',    category: 'Shellfish', unit: 'LB',  qty: 6,  min: 2,  cost: 24.95 },
    { name: 'Argentine Red Shrimp',     category: 'Shellfish', unit: 'LB',  qty: 0,  min: 5,  cost: 7.40  },
    { name: 'Avocado',                  category: 'Produce',   unit: 'EA',  qty: 40, min: 15, cost: 0.82  },
    { name: 'Cucumber',                 category: 'Produce',   unit: 'EA',  qty: 25, min: 10, cost: 0.35  },
    { name: 'Nori Sheet',               category: 'Dry Goods', unit: 'PKT', qty: 12, min: 5,  cost: 2.75  },
    { name: 'Furikake',                 category: 'Dry Goods', unit: 'LB',  qty: 4,  min: 2,  cost: 66.65 },
    { name: 'Spicy Mayo (house)',        category: 'Sauces',    unit: 'LB',  qty: 8,  min: 3,  cost: 1.90  },
  ];

  for (const item of inventoryItems) {
    await prisma.inventoryItem.upsert({
      where: { id: `inv_${loc.id}_${item.name.replace(/\s/g,'_').toLowerCase().slice(0,20)}` },
      update: { quantityOnHand: item.qty, unitCost: item.cost },
      create: {
        id: `inv_${loc.id}_${item.name.replace(/\s/g,'_').toLowerCase().slice(0,20)}`,
        locationId: loc.id,
        name: item.name,
        category: item.category,
        unit: item.unit,
        quantityOnHand: item.qty,
        parLevel: item.min,
        reorderPoint: item.min,
        unitCost: item.cost,
        supplierId: supplier.id,
      },
    });
  }

  // ── Staff ──
  const staff = [
    { first: 'Kenji',  last: 'T.',   role: 'Head Chef',   type: 'SALARY', rate: 5500, hrs: 45 },
    { first: 'Ana',    last: 'L.',   role: 'Sous Chef',   type: 'HOURLY', rate: 22,   hrs: 40 },
    { first: 'Marcus', last: 'R.',   role: 'Line Cook',   type: 'HOURLY', rate: 18,   hrs: 38 },
    { first: 'Sofia',  last: 'M.',   role: 'Server',      type: 'HOURLY', rate: 15,   hrs: 35 },
    { first: 'Liam',   last: 'K.',   role: 'Server',      type: 'HOURLY', rate: 15,   hrs: 30 },
    { first: 'Priya',  last: 'N.',   role: 'Host',        type: 'HOURLY', rate: 16,   hrs: 32 },
    { first: 'Carlos', last: 'V.',   role: 'Dishwasher',  type: 'HOURLY', rate: 16,   hrs: 40 },
  ];

  for (const s of staff) {
    await prisma.laborStaff.upsert({
      where: { id: `staff_${loc.id}_${s.first.toLowerCase()}` },
      update: {},
      create: {
        id: `staff_${loc.id}_${s.first.toLowerCase()}`,
        locationId: loc.id,
        firstName: s.first,
        lastName: s.last,
        role: s.role,
        employmentType: s.type,
        hourlyRate:    s.type === 'HOURLY' ? s.rate  : null,
        annualSalary:  s.type === 'SALARY' ? s.rate * 12 : null,
        weeklyHours: s.hrs,
      },
    });
  }

  // ── Recipes ──
  const recipes = [
    { name: 'Cucumber Hand Roll',    emoji: '🥒', price: 6.50,  cost: 0.55 },
    { name: 'Bay Scallop Hand Roll', emoji: '🦪', price: 7.00,  cost: 1.96 },
    { name: 'Shrimp Hand Roll',      emoji: '🍤', price: 7.25,  cost: 0.91 },
    { name: 'Albacore Hand Roll',    emoji: '🐟', price: 7.75,  cost: 1.33 },
    { name: 'Toro Hand Roll',        emoji: '🐟', price: 7.75,  cost: 1.33 },
    { name: 'NZ Sea Bream Hand Roll',emoji: '🐠', price: 7.75,  cost: 1.40 },
    { name: 'Yellowtail Hand Roll',  emoji: '🐡', price: 7.75,  cost: 1.08 },
    { name: 'Crab Hand Roll',        emoji: '🦀', price: 8.00,  cost: 1.21 },
    { name: 'Lobster Hand Roll',     emoji: '🦞', price: 11.00, cost: 1.75 },
  ];

  for (const r of recipes) {
    await prisma.recipe.upsert({
      where: { id: `rec_${loc.id}_${r.name.replace(/\s/g,'_').toLowerCase().slice(0,20)}` },
      update: {},
      create: {
        id: `rec_${loc.id}_${r.name.replace(/\s/g,'_').toLowerCase().slice(0,20)}`,
        locationId: loc.id,
        name: r.name,
        emoji: r.emoji,
        category: 'Hand Roll',
        menuPrice: r.price,
        targetFoodCostPct: 30,
      },
    });
  }

  // ── Sales entries (last 30 days) ──
  const today = new Date();
  for (let i = 30; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    const dateStr = date.toISOString().split('T')[0];
    const isWeekend = [0, 6].includes(date.getDay());
    const base = isWeekend ? 5200 : 3800;
    const variance = (Math.random() - 0.5) * 800;
    const gross = Math.round(base + variance);
    const disc = Math.round(gross * 0.03);
    const net = gross - disc;
    const di = Math.round(net * 0.65);
    const dv = Math.round(net * 0.25);
    const tk = net - di - dv;
    const covers = Math.round(net / 42);

    await prisma.salesEntry.upsert({
      where: { locationId_date: { locationId: loc.id, date: new Date(dateStr) } },
      update: {},
      create: {
        locationId: loc.id,
        date: new Date(dateStr),
        grossSales: gross,
        discounts: disc,
        netSales: net,
        dineInSales: di,
        deliverySales: dv,
        takeoutSales: tk,
        covers,
        avgCheck: covers > 0 ? net / covers : 42,
      },
    });
  }

  console.log('✅ Seed complete!');
  console.log('');
  console.log('Demo accounts:');
  console.log('  Owner:   owner@kazunori.com   / demo1234');
  console.log('  Manager: manager@kazunori.com / demo1234');
  console.log('  Chef:    chef@kazunori.com    / demo1234');
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
