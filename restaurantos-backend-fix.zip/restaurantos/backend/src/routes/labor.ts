import { Router, Response } from 'express';
import { z } from 'zod';
import { prisma } from '../utils/prisma';
import { authenticate, requireLocationAccess, AuthRequest } from '../middleware/auth';
import { logger } from '../utils/logger';

export const laborRouter = Router();
laborRouter.use(authenticate);

// ════════════════════════════════════════════════
// STAFF
// ════════════════════════════════════════════════

const staffSchema = z.object({
  firstName:      z.string().min(1),
  lastName:       z.string().min(1),
  email:          z.string().email().optional(),
  phone:          z.string().optional(),
  role:           z.string().min(1),
  employmentType: z.enum(['HOURLY', 'SALARY', 'CONTRACT']).default('HOURLY'),
  hourlyRate:     z.number().min(0).optional(),
  annualSalary:   z.number().min(0).optional(),
  weeklyHours:    z.number().min(0).max(80).default(40),
  hireDate:       z.string().optional(),
  notes:          z.string().optional(),
});

// GET /api/labor/:locationId/staff
laborRouter.get('/:locationId/staff', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const staff = await prisma.laborStaff.findMany({
      where: { locationId: req.params.locationId, isActive: true },
      orderBy: { firstName: 'asc' },
    });

    // Compute costs
    const enriched = staff.map(s => {
      const weeklyCost = s.employmentType === 'SALARY'
        ? (s.annualSalary || 0) / 52
        : (s.hourlyRate || 0) * s.weeklyHours;
      return { ...s, weeklyCost, monthlyCost: weeklyCost * 4.33 };
    });

    const totalWeekly  = enriched.reduce((a, s) => a + s.weeklyCost, 0);
    const totalMonthly = enriched.reduce((a, s) => a + s.monthlyCost, 0);

    return res.json({ staff: enriched, totalWeekly, totalMonthly });
  } catch (err) {
    logger.error('Get staff error:', err);
    return res.status(500).json({ error: 'Failed to fetch staff' });
  }
});

// POST /api/labor/:locationId/staff
laborRouter.post('/:locationId/staff', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const body = staffSchema.parse(req.body);
    const member = await prisma.laborStaff.create({
      data: {
        locationId: req.params.locationId,
        ...body,
        hireDate: body.hireDate ? new Date(body.hireDate) : null,
      },
    });
    return res.status(201).json(member);
  } catch (err: any) {
    if (err.name === 'ZodError') return res.status(400).json({ error: err.errors });
    return res.status(500).json({ error: 'Failed to create staff member' });
  }
});

// PATCH /api/labor/:locationId/staff/:staffId
laborRouter.patch('/:locationId/staff/:staffId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const member = await prisma.laborStaff.updateMany({
      where: { id: req.params.staffId, locationId: req.params.locationId },
      data: req.body,
    });
    if (member.count === 0) return res.status(404).json({ error: 'Staff member not found' });
    const updated = await prisma.laborStaff.findUnique({ where: { id: req.params.staffId } });
    return res.json(updated);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to update staff member' });
  }
});

// DELETE /api/labor/:locationId/staff/:staffId
laborRouter.delete('/:locationId/staff/:staffId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    await prisma.laborStaff.updateMany({
      where: { id: req.params.staffId, locationId: req.params.locationId },
      data: { isActive: false, terminationDate: new Date() },
    });
    return res.json({ message: 'Staff member deactivated' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to deactivate staff member' });
  }
});

// ════════════════════════════════════════════════
// SHIFTS
// ════════════════════════════════════════════════

const shiftSchema = z.object({
  staffId:     z.string(),
  date:        z.string(),
  dayOfWeek:   z.number().int().min(0).max(6),
  startTime:   z.string().optional(),
  endTime:     z.string().optional(),
  hoursWorked: z.number().min(0).default(0),
  isScheduled: z.boolean().default(true),
  notes:       z.string().optional(),
});

// GET /api/labor/:locationId/shifts
laborRouter.get('/:locationId/shifts', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const { startDate, endDate, staffId } = req.query;

    const where: any = { locationId: req.params.locationId };
    if (staffId)   where.staffId = staffId;
    if (startDate) where.date = { gte: new Date(startDate as string) };
    if (endDate)   where.date = { ...where.date, lte: new Date(endDate as string) };

    const shifts = await prisma.laborShift.findMany({
      where,
      include: { staff: { select: { id: true, firstName: true, lastName: true, role: true } } },
      orderBy: [{ date: 'asc' }, { staff: { firstName: 'asc' } }],
    });

    return res.json({ shifts });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch shifts' });
  }
});

// POST /api/labor/:locationId/shifts (upsert)
laborRouter.post('/:locationId/shifts', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const body = shiftSchema.parse(req.body);

    // Look up staff pay rate
    const staff = await prisma.laborStaff.findFirst({
      where: { id: body.staffId, locationId: req.params.locationId },
    });
    if (!staff) return res.status(404).json({ error: 'Staff member not found' });

    const regularPay = staff.employmentType === 'SALARY'
      ? (staff.annualSalary || 0) / 52 / 5  // per day
      : (staff.hourlyRate || 0) * Math.min(body.hoursWorked, 8);
    const overtimePay = staff.employmentType === 'HOURLY' && body.hoursWorked > 8
      ? (staff.hourlyRate || 0) * 1.5 * (body.hoursWorked - 8)
      : 0;

    const shift = await prisma.laborShift.upsert({
      where: {
        // Composite unique: staff + date
        id: `${body.staffId}_${body.date}`.replace(/[^a-z0-9_]/gi, ''),
      },
      update: {
        ...body,
        regularPay,
        overtimePay,
        totalPay: regularPay + overtimePay,
        date: new Date(body.date),
      },
      create: {
        id: `${body.staffId}_${body.date}`.replace(/[^a-z0-9_]/gi, ''),
        locationId: req.params.locationId,
        ...body,
        date: new Date(body.date),
        regularPay,
        overtimePay,
        totalPay: regularPay + overtimePay,
      },
    });

    return res.status(201).json(shift);
  } catch (err: any) {
    if (err.name === 'ZodError') return res.status(400).json({ error: err.errors });
    logger.error('Create shift error:', err);
    return res.status(500).json({ error: 'Failed to save shift' });
  }
});

// ════════════════════════════════════════════════
// LABOR SUMMARY
// ════════════════════════════════════════════════

// GET /api/labor/:locationId/summary
laborRouter.get('/:locationId/summary', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const { period = 'MONTHLY', netSales = '0' } = req.query;

    // Use staff roster to estimate costs (scheduled)
    const staff = await prisma.laborStaff.findMany({
      where: { locationId: req.params.locationId, isActive: true },
    });

    const weekly = staff.map(s => ({
      id:         s.id,
      name:       `${s.firstName} ${s.lastName}`,
      role:       s.role,
      type:       s.employmentType,
      weeklyCost: s.employmentType === 'SALARY'
        ? (s.annualSalary || 0) / 52
        : (s.hourlyRate || 0) * s.weeklyHours,
    }));

    const totalWeekly  = weekly.reduce((a, s) => a + s.weeklyCost, 0);
    const totalMonthly = totalWeekly * 4.33;
    const ns           = parseFloat(netSales as string) || 0;
    const laborCostPct = ns > 0 ? (totalMonthly / ns) * 100 : 0;

    return res.json({
      staff:         weekly,
      totalWeekly:   Math.round(totalWeekly),
      totalMonthly:  Math.round(totalMonthly),
      laborCostPct:  Math.round(laborCostPct * 10) / 10,
      staffCount:    staff.length,
      ftCount:       staff.filter(s => s.weeklyHours >= 35).length,
      ptCount:       staff.filter(s => s.weeklyHours < 35).length,
    });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to compute labor summary' });
  }
});
