import { Router, Response } from 'express';
import { z } from 'zod';
import { prisma } from '../utils/prisma';
import { authenticate, requireLocationAccess, AuthRequest } from '../middleware/auth';
import { calcFinancials, FinanceInput } from '../services/calculations';
import { auditLog } from '../utils/audit';
import { sendAlertEmail } from '../utils/email';
import { logger } from '../utils/logger';

export const financeRouter = Router();
financeRouter.use(authenticate);

// ── POST /api/finance/:locationId/calculate ── (live calculation, no save)
financeRouter.post('/:locationId/calculate', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const input = req.body as FinanceInput;
    const results = calcFinancials(input);
    return res.json(results);
  } catch (err: any) {
    return res.status(400).json({ error: 'Calculation failed: ' + err.message });
  }
});

const entrySchema = z.object({
  periodStart:        z.string(),
  periodEnd:          z.string(),
  periodType:         z.enum(['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY']).default('MONTHLY'),
  // Revenue
  grossSales:         z.number().min(0).default(0),
  discounts:          z.number().min(0).default(0),
  otherIncome:        z.number().min(0).default(0),
  // Inventory / COGS
  beginningInventory: z.number().min(0).default(0),
  purchases:          z.number().min(0).default(0),
  endingInventory:    z.number().min(0).default(0),
  // Labor
  hourlyWages:        z.number().min(0).default(0),
  salaryWages:        z.number().min(0).default(0),
  payrollTax:         z.number().min(0).default(0),
  benefits:           z.number().min(0).default(0),
  // Opex
  rent:               z.number().min(0).default(0),
  utilities:          z.number().min(0).default(0),
  insurance:          z.number().min(0).default(0),
  marketing:          z.number().min(0).default(0),
  repairs:            z.number().min(0).default(0),
  softwarePos:        z.number().min(0).default(0),
  licenses:           z.number().min(0).default(0),
  creditCardFees:     z.number().min(0).default(0),
  deliveryFees:       z.number().min(0).default(0),
  otherExpenses:      z.number().min(0).default(0),
  notes:              z.string().optional(),
});

// ── POST /api/finance/:locationId/entries ── (save P&L entry)
financeRouter.post('/:locationId/entries', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const body = entrySchema.parse(req.body);

    // Run full calculation
    const calc = calcFinancials({
      sales: {
        grossSales:  body.grossSales,
        discounts:   body.discounts,
        comps:       0,
        refunds:     0,
        otherIncome: body.otherIncome,
      },
      cogs: {
        beginningInventory: body.beginningInventory,
        purchases:          body.purchases,
        endingInventory:    body.endingInventory,
      },
      labor: {
        hourlyWages:  body.hourlyWages,
        salaryWages:  body.salaryWages,
        payrollTax:   body.payrollTax,
        benefits:     body.benefits,
      },
      opex: {
        rent:           body.rent,
        utilities:      body.utilities,
        insurance:      body.insurance,
        marketing:      body.marketing,
        repairs:        body.repairs,
        softwarePos:    body.softwarePos,
        licenses:       body.licenses,
        creditCardFees: body.creditCardFees,
        deliveryFees:   body.deliveryFees,
        otherExpenses:  body.otherExpenses,
      },
    });

    const entry = await prisma.financeEntry.upsert({
      where: {
        locationId_periodStart_periodType: {
          locationId: req.params.locationId,
          periodStart: new Date(body.periodStart),
          periodType:  body.periodType,
        },
      },
      update: {
        ...body,
        periodStart:     new Date(body.periodStart),
        periodEnd:       new Date(body.periodEnd),
        // Computed fields
        netSales:        calc.netSales,
        totalRevenue:    calc.totalRevenue,
        cogs:            calc.cogs,
        foodCostPct:     calc.foodCostPct,
        totalLaborCost:  calc.totalLaborCost,
        laborCostPct:    calc.laborCostPct,
        primeCost:       calc.primeCost,
        primeCostPct:    calc.primeCostPct,
        grossProfit:     calc.grossProfit,
        grossMarginPct:  calc.grossMarginPct,
        totalOpex:       calc.totalOpex,
        ebitda:          calc.ebitda,
        netProfit:       calc.netProfit,
        netMarginPct:    calc.netMarginPct,
        fixedCosts:      calc.fixedCosts,
        variableCostPct: calc.variableCostPct,
        breakEvenSales:  calc.breakEvenSales,
        breakEvenGap:    calc.breakEvenGap,
        healthScore:     calc.healthScore,
      },
      create: {
        locationId:      req.params.locationId,
        ...body,
        periodStart:     new Date(body.periodStart),
        periodEnd:       new Date(body.periodEnd),
        netSales:        calc.netSales,
        totalRevenue:    calc.totalRevenue,
        cogs:            calc.cogs,
        foodCostPct:     calc.foodCostPct,
        totalLaborCost:  calc.totalLaborCost,
        laborCostPct:    calc.laborCostPct,
        primeCost:       calc.primeCost,
        primeCostPct:    calc.primeCostPct,
        grossProfit:     calc.grossProfit,
        grossMarginPct:  calc.grossMarginPct,
        totalOpex:       calc.totalOpex,
        ebitda:          calc.ebitda,
        netProfit:       calc.netProfit,
        netMarginPct:    calc.netMarginPct,
        fixedCosts:      calc.fixedCosts,
        variableCostPct: calc.variableCostPct,
        breakEvenSales:  calc.breakEvenSales,
        breakEvenGap:    calc.breakEvenGap,
        healthScore:     calc.healthScore,
      },
    });

    // Fire alerts for critical issues
    const criticalAlerts = calc.alerts.filter(a => a.severity === 'CRITICAL');
    if (criticalAlerts.length > 0) {
      await createFinanceAlerts(req.params.locationId, criticalAlerts);
    }

    await auditLog({
      organizationId: req.user!.organizationId,
      userId:         req.user!.id,
      action:         'UPSERT_FINANCE_ENTRY',
      resource:       'finance_entries',
      resourceId:     entry.id,
      newValues:      {
        period:       body.periodStart,
        netSales:     calc.netSales,
        netProfit:    calc.netProfit,
        healthScore:  calc.healthScore,
      },
    });

    return res.status(201).json({ entry, calculations: calc });
  } catch (err: any) {
    if (err.name === 'ZodError') return res.status(400).json({ error: err.errors });
    logger.error('Finance entry error:', err);
    return res.status(500).json({ error: 'Failed to save finance entry' });
  }
});

// ── GET /api/finance/:locationId/entries ──
financeRouter.get('/:locationId/entries', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const { periodType = 'MONTHLY', limit = '12' } = req.query;

    const entries = await prisma.financeEntry.findMany({
      where: { locationId: req.params.locationId, periodType: periodType as string },
      orderBy: { periodStart: 'desc' },
      take: parseInt(limit as string),
    });

    return res.json({ entries });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch finance entries' });
  }
});

// ── GET /api/finance/:locationId/summary ──
financeRouter.get('/:locationId/summary', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const latest = await prisma.financeEntry.findFirst({
      where: { locationId: req.params.locationId, periodType: 'MONTHLY' },
      orderBy: { periodStart: 'desc' },
    });

    if (!latest) {
      // Return empty summary if no entries yet
      return res.json({
        totalRevenue: 0, cogs: 0, foodCostPct: 0,
        totalLaborCost: 0, laborCostPct: 0,
        primeCost: 0, primeCostPct: 0,
        netProfit: 0, netMarginPct: 0,
        breakEvenGap: 0, healthScore: 0,
      });
    }

    return res.json(latest);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to get finance summary' });
  }
});

// ── Helper: create DB alerts from finance calculation ──
async function createFinanceAlerts(locationId: string, alerts: any[]) {
  try {
    await prisma.alert.createMany({
      data: alerts.map(a => ({
        locationId,
        type:    a.type as any,
        message: a.message,
        metadata: { value: a.value, target: a.target },
      })),
      skipDuplicates: true,
    });
  } catch (err) {
    logger.error('Create finance alerts error:', err);
  }
}
