import { Router, Response } from 'express';
import { prisma } from '../utils/prisma';
import { authenticate, requireLocationAccess, requireRole, AuthRequest } from '../middleware/auth';
import { calcValuation } from '../services/calculations';
import { logger } from '../utils/logger';

// ════════════════════════════════════════════════
// VALUATION
// ════════════════════════════════════════════════
export const valuationRouter = Router();
valuationRouter.use(authenticate);

valuationRouter.post('/:locationId/calculate', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const results = calcValuation(req.body);
    return res.json(results);
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

valuationRouter.post('/:locationId/snapshots', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const calc = calcValuation(req.body);
    const snapshot = await prisma.valuationSnapshot.create({
      data: {
        locationId:      req.params.locationId,
        snapshotDate:    new Date(),
        periodType:      req.body.periodType || 'MONTHLY',
        netProfit:       req.body.netProfit,
        periodMultiplier: req.body.periodMultiplier || 12,
        ownerSalary:     req.body.ownerSalary,
        interest:        req.body.interest,
        depreciation:    req.body.depreciation,
        annualRevenue:   req.body.annualRevenue,
        ebitda:          req.body.ebitda,
        ebitdaMultiple:  req.body.ebitdaMultiple,
        ...calc,
      },
    });
    return res.status(201).json({ snapshot, calculation: calc });
  } catch (err) {
    logger.error('Valuation snapshot error:', err);
    return res.status(500).json({ error: 'Failed to save snapshot' });
  }
});

valuationRouter.get('/:locationId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  const snapshots = await prisma.valuationSnapshot.findMany({
    where: { locationId: req.params.locationId },
    orderBy: { snapshotDate: 'desc' },
    take: 12,
  });
  return res.json({ snapshots });
});

// ════════════════════════════════════════════════
// RECIPES
// ════════════════════════════════════════════════
export const recipesRouter = Router();
recipesRouter.use(authenticate);

recipesRouter.get('/:locationId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  const recipes = await prisma.recipe.findMany({
    where: { locationId: req.params.locationId, isActive: true },
    include: { ingredients: true },
    orderBy: [{ category: 'asc' }, { name: 'asc' }],
  });

  const enriched = recipes.map(r => {
    const totalCost = r.ingredients.reduce((a, i) => a + i.totalCost * (1 + i.wastePercent / 100), 0);
    const foodCostPct = r.menuPrice > 0 ? (totalCost / r.menuPrice) * 100 : 0;
    const markup = totalCost > 0 ? (r.menuPrice - totalCost) / totalCost * 100 : 0;
    return { ...r, totalIngredientCost: totalCost, foodCostPct, markup };
  });

  return res.json({ recipes: enriched });
});

recipesRouter.post('/:locationId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const { ingredients, ...recipeData } = req.body;
    const recipe = await prisma.recipe.create({
      data: {
        locationId: req.params.locationId,
        ...recipeData,
        ingredients: ingredients?.length ? {
          create: ingredients.map((i: any) => ({
            name:       i.name,
            quantity:   i.quantity,
            unit:       i.unit,
            unitCost:   i.unitCost || 0,
            totalCost:  (i.quantity || 0) * (i.unitCost || 0),
            wastePercent: i.wastePercent || 0,
            inventoryItemId: i.inventoryItemId || null,
          })),
        } : undefined,
      },
      include: { ingredients: true },
    });
    return res.status(201).json(recipe);
  } catch (err: any) {
    logger.error('Create recipe error:', err);
    return res.status(500).json({ error: 'Failed to create recipe' });
  }
});

recipesRouter.patch('/:locationId/:recipeId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const { ingredients, ...recipeData } = req.body;
    const recipe = await prisma.recipe.update({
      where: { id: req.params.recipeId },
      data: {
        ...recipeData,
        ...(ingredients && {
          ingredients: {
            deleteMany: {},
            create: ingredients.map((i: any) => ({
              name: i.name, quantity: i.quantity, unit: i.unit,
              unitCost: i.unitCost || 0, totalCost: i.quantity * (i.unitCost || 0),
              wastePercent: i.wastePercent || 0,
            })),
          },
        }),
      },
      include: { ingredients: true },
    });
    return res.json(recipe);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to update recipe' });
  }
});

recipesRouter.delete('/:locationId/:recipeId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  await prisma.recipe.update({ where: { id: req.params.recipeId }, data: { isActive: false } });
  return res.json({ message: 'Recipe archived' });
});

// ════════════════════════════════════════════════
// LOCATIONS
// ════════════════════════════════════════════════
export const locationsRouter = Router();
locationsRouter.use(authenticate);

locationsRouter.get('/:orgId', async (req: AuthRequest, res: Response) => {
  try {
    if (req.user!.organizationId !== req.params.orgId && req.user!.role !== 'SUPER_ADMIN') {
      return res.status(403).json({ error: 'Forbidden' });
    }
    const locations = await prisma.location.findMany({
      where: { organizationId: req.params.orgId, isActive: true },
      orderBy: { name: 'asc' },
    });
    return res.json({ locations });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch locations' });
  }
});

locationsRouter.post('/:orgId', requireRole('OWNER', 'SUPER_ADMIN'), async (req: AuthRequest, res: Response) => {
  try {
    const location = await prisma.location.create({
      data: { organizationId: req.params.orgId, ...req.body },
    });
    return res.status(201).json(location);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to create location' });
  }
});

locationsRouter.patch('/:locationId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const updated = await prisma.location.update({
      where: { id: req.params.locationId },
      data: req.body,
    });
    return res.json(updated);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to update location' });
  }
});

// ════════════════════════════════════════════════
// ALERTS
// ════════════════════════════════════════════════
export const alertsRouter = Router();
alertsRouter.use(authenticate);

alertsRouter.get('/:locationId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  const { unread } = req.query;
  const alerts = await prisma.alert.findMany({
    where: {
      locationId: req.params.locationId,
      ...(unread === 'true' ? { isRead: false } : {}),
    },
    orderBy: { createdAt: 'desc' },
    take: 50,
  });
  return res.json({ alerts });
});

alertsRouter.patch('/:alertId/read', authenticate, async (req: AuthRequest, res: Response) => {
  await prisma.alert.update({ where: { id: req.params.alertId }, data: { isRead: true } });
  return res.json({ message: 'Marked as read' });
});

// ════════════════════════════════════════════════
// ORGANIZATIONS
// ════════════════════════════════════════════════
export const orgsRouter = Router();
orgsRouter.use(authenticate);

orgsRouter.get('/me', async (req: AuthRequest, res: Response) => {
  const org = await prisma.organization.findUnique({
    where: { id: req.user!.organizationId },
    include: {
      subscription: true,
      locations: { where: { isActive: true }, select: { id: true, name: true, type: true } },
      users: {
        include: { user: { select: { id: true, firstName: true, lastName: true, email: true } } },
      },
    },
  });
  return res.json(org);
});

orgsRouter.patch('/me', requireRole('OWNER', 'SUPER_ADMIN'), async (req: AuthRequest, res: Response) => {
  const org = await prisma.organization.update({
    where: { id: req.user!.organizationId },
    data: req.body,
  });
  return res.json(org);
});

// Team invite
orgsRouter.post('/me/invite', requireRole('OWNER', 'MANAGER', 'SUPER_ADMIN'), async (req: AuthRequest, res: Response) => {
  try {
    const { email, role } = req.body;
    if (!email || !role) return res.status(400).json({ error: 'email and role required' });

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    const invite = await prisma.teamInvite.create({
      data: {
        organizationId: req.user!.organizationId,
        email,
        role,
        invitedById: req.user!.id,
        expiresAt,
      },
    });

    const inviteUrl = `${process.env.FRONTEND_URL}/invite/${invite.token}`;
    const sender    = await prisma.user.findUnique({ where: { id: req.user!.id } });
    const org       = await prisma.organization.findUnique({ where: { id: req.user!.organizationId } });

    const { sendInviteEmail } = await import('../utils/email');
    await sendInviteEmail(email, org!.name, inviteUrl, `${sender!.firstName} ${sender!.lastName}`);

    return res.status(201).json({ message: `Invitation sent to ${email}`, inviteUrl });
  } catch (err) {
    logger.error('Invite error:', err);
    return res.status(500).json({ error: 'Failed to send invitation' });
  }
});

// ════════════════════════════════════════════════
// ADMIN (SUPER_ADMIN only)
// ════════════════════════════════════════════════
export const adminRouter = Router();
adminRouter.use(authenticate);
adminRouter.use(requireRole('SUPER_ADMIN'));

adminRouter.get('/stats', async (_req: AuthRequest, res: Response) => {
  const [orgCount, userCount, locationCount, subCount] = await Promise.all([
    prisma.organization.count(),
    prisma.user.count(),
    prisma.location.count({ where: { isActive: true } }),
    prisma.subscription.count({ where: { status: 'ACTIVE' } }),
  ]);
  return res.json({ orgCount, userCount, locationCount, subCount });
});

adminRouter.get('/orgs', async (_req: AuthRequest, res: Response) => {
  const orgs = await prisma.organization.findMany({
    include: {
      subscription: true,
      _count: { select: { locations: true, users: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });
  return res.json({ orgs });
});

adminRouter.get('/audit-logs', async (req: AuthRequest, res: Response) => {
  const logs = await prisma.auditLog.findMany({
    where: req.query.orgId ? { organizationId: req.query.orgId as string } : {},
    include: { user: { select: { firstName: true, lastName: true, email: true } } },
    orderBy: { createdAt: 'desc' },
    take: 200,
  });
  return res.json({ logs });
});
