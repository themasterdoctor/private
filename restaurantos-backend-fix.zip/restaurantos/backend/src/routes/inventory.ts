import { Router, Response } from 'express';
import { z } from 'zod';
import { prisma } from '../utils/prisma';
import { authenticate, requireLocationAccess, AuthRequest } from '../middleware/auth';
import { auditLog } from '../utils/audit';
import { logger } from '../utils/logger';

export const inventoryRouter = Router();
inventoryRouter.use(authenticate);

const itemSchema = z.object({
  name:           z.string().min(1).max(200),
  sku:            z.string().optional(),
  category:       z.string().default('General'),
  unit:           z.string().default('EA'),
  quantityOnHand: z.number().min(0).default(0),
  parLevel:       z.number().min(0).default(0),
  reorderPoint:   z.number().min(0).default(0),
  reorderQty:     z.number().min(0).default(0),
  unitCost:       z.number().min(0).default(0),
  supplierId:     z.string().optional(),
  notes:          z.string().optional(),
});

// ── GET /api/inventory/:locationId ──
inventoryRouter.get('/:locationId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const { search, category, lowStock } = req.query;

    const where: any = { locationId: req.params.locationId, isActive: true };
    if (search)   where.name = { contains: search as string, mode: 'insensitive' };
    if (category) where.category = category as string;
    if (lowStock === 'true') where.quantityOnHand = { lte: prisma.inventoryItem.fields.parLevel };

    const items = await prisma.inventoryItem.findMany({
      where,
      include: { supplier: { select: { id: true, name: true } } },
      orderBy: [{ category: 'asc' }, { name: 'asc' }],
    });

    // Annotate with status
    const annotated = items.map(item => ({
      ...item,
      status: item.quantityOnHand === 0 ? 'OUT_OF_STOCK'
            : item.quantityOnHand <= item.parLevel ? 'LOW_STOCK'
            : 'OK',
      totalValue: item.quantityOnHand * item.unitCost,
    }));

    const totalValue      = annotated.reduce((a, i) => a + i.totalValue, 0);
    const lowStockCount   = annotated.filter(i => i.status === 'LOW_STOCK').length;
    const outOfStockCount = annotated.filter(i => i.status === 'OUT_OF_STOCK').length;

    return res.json({ items: annotated, totalValue, lowStockCount, outOfStockCount });
  } catch (err) {
    logger.error('Get inventory error:', err);
    return res.status(500).json({ error: 'Failed to fetch inventory' });
  }
});

// ── GET /api/inventory/:locationId/low-stock ──
inventoryRouter.get('/:locationId/low-stock', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const items = await prisma.inventoryItem.findMany({
      where: {
        locationId: req.params.locationId,
        isActive: true,
        OR: [
          { quantityOnHand: { lte: 0 } },
          // raw query workaround: can't compare two fields directly in Prisma
          // instead use a threshold approach
        ],
      },
      include: { supplier: { select: { name: true, phone: true } } },
    });

    // Filter in JS for items at or below par
    const lowStock = items.filter(i => i.quantityOnHand <= i.parLevel);

    return res.json({ items: lowStock, count: lowStock.length });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch low-stock items' });
  }
});

// ── POST /api/inventory/:locationId ──
inventoryRouter.post('/:locationId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const body = itemSchema.parse(req.body);

    const item = await prisma.inventoryItem.create({
      data: { locationId: req.params.locationId, ...body },
    });

    await auditLog({
      organizationId: req.user!.organizationId,
      userId:     req.user!.id,
      action:     'CREATE_INVENTORY_ITEM',
      resource:   'inventory_items',
      resourceId: item.id,
      newValues:  { name: item.name, category: item.category, unitCost: item.unitCost },
    });

    return res.status(201).json(item);
  } catch (err: any) {
    if (err.name === 'ZodError') return res.status(400).json({ error: err.errors });
    return res.status(500).json({ error: 'Failed to create item' });
  }
});

// ── PATCH /api/inventory/:locationId/:itemId ──
inventoryRouter.patch('/:locationId/:itemId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const existing = await prisma.inventoryItem.findFirst({
      where: { id: req.params.itemId, locationId: req.params.locationId },
    });
    if (!existing) return res.status(404).json({ error: 'Item not found' });

    const updated = await prisma.inventoryItem.update({
      where: { id: req.params.itemId },
      data: req.body,
    });

    await auditLog({
      organizationId: req.user!.organizationId,
      userId:     req.user!.id,
      action:     'UPDATE_INVENTORY_ITEM',
      resource:   'inventory_items',
      resourceId: updated.id,
      oldValues:  { qty: existing.quantityOnHand, cost: existing.unitCost },
      newValues:  { qty: updated.quantityOnHand, cost: updated.unitCost },
    });

    return res.json(updated);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to update item' });
  }
});

// ── POST /api/inventory/:locationId/:itemId/adjust ── (manual count / waste / usage)
inventoryRouter.post('/:locationId/:itemId/adjust', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const { type, quantity, notes, unitCost } = req.body;
    if (!type || quantity == null) return res.status(400).json({ error: 'type and quantity required' });

    const item = await prisma.inventoryItem.findFirst({
      where: { id: req.params.itemId, locationId: req.params.locationId },
    });
    if (!item) return res.status(404).json({ error: 'Item not found' });

    // PURCHASE = add, WASTE/USAGE = subtract, COUNT = set absolute
    let newQty: number;
    if (type === 'COUNT')    newQty = quantity;
    else if (type === 'PURCHASE') newQty = item.quantityOnHand + quantity;
    else                     newQty = Math.max(0, item.quantityOnHand - quantity);

    const [updatedItem, txn] = await prisma.$transaction([
      prisma.inventoryItem.update({
        where: { id: item.id },
        data: {
          quantityOnHand: newQty,
          ...(unitCost && type === 'PURCHASE' ? { unitCost } : {}),
          ...(type === 'COUNT' ? { lastCountDate: new Date() } : {}),
        },
      }),
      prisma.inventoryTransaction.create({
        data: {
          inventoryItemId: item.id,
          type,
          quantity:  type === 'COUNT' ? quantity - item.quantityOnHand : quantity,
          unitCost:  unitCost || item.unitCost,
          totalCost: (unitCost || item.unitCost) * quantity,
          notes,
          createdById: req.user!.id,
        },
      }),
    ]);

    return res.json({ item: updatedItem, transaction: txn });
  } catch (err) {
    logger.error('Inventory adjust error:', err);
    return res.status(500).json({ error: 'Adjustment failed' });
  }
});

// ── DELETE /api/inventory/:locationId/:itemId ──
inventoryRouter.delete('/:locationId/:itemId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    await prisma.inventoryItem.updateMany({
      where: { id: req.params.itemId, locationId: req.params.locationId },
      data: { isActive: false },
    });
    return res.json({ message: 'Item deactivated' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to delete item' });
  }
});
