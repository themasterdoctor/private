import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { prisma } from '../utils/prisma';
import { authenticate, AuthRequest } from '../middleware/auth';
import { sendWelcomeEmail, sendInviteEmail } from '../utils/email';
import { auditLog } from '../utils/audit';

export const authRouter = Router();

// ── Validation schemas ──
const registerSchema = z.object({
  firstName: z.string().min(1).max(50),
  lastName: z.string().min(1).max(50),
  email: z.string().email(),
  password: z.string().min(8).max(100),
  organizationName: z.string().min(2).max(100),
  restaurantType: z.string().optional(),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  organizationId: z.string().optional(), // for users in multiple orgs
});

// ── Generate tokens ──
function generateTokens(userId: string, organizationId: string, email: string) {
  const access = jwt.sign(
    { userId, organizationId, email },
    process.env.JWT_SECRET!,
    { expiresIn: '15m' }
  );
  const refresh = jwt.sign(
    { userId, organizationId, email },
    process.env.JWT_REFRESH_SECRET!,
    { expiresIn: '30d' }
  );
  return { access, refresh };
}

// ── POST /api/auth/register ──
authRouter.post('/register', async (req: Request, res: Response) => {
  try {
    const body = registerSchema.parse(req.body);

    // Check email exists
    const existing = await prisma.user.findUnique({ where: { email: body.email } });
    if (existing) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    const passwordHash = await bcrypt.hash(body.password, 12);
    const slug = body.organizationName
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '-')
      .replace(/-+/g, '-')
      .slice(0, 50) + '-' + Date.now().toString(36);

    // Create user + org + subscription + default location in a transaction
    const result = await prisma.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: {
          email: body.email,
          passwordHash,
          firstName: body.firstName,
          lastName: body.lastName,
        },
      });

      const org = await tx.organization.create({
        data: {
          name: body.organizationName,
          slug,
        },
      });

      await tx.organizationUser.create({
        data: {
          userId: user.id,
          organizationId: org.id,
          role: 'OWNER',
          isDefault: true,
          locationIds: [],
        },
      });

      // Stripe customer + subscription trial
      const trialEnd = new Date();
      trialEnd.setDate(trialEnd.getDate() + 14);

      await tx.subscription.create({
        data: {
          organizationId: org.id,
          stripeCustomerId: `cus_temp_${org.id}`, // replaced when Stripe webhook fires
          plan: 'STARTER',
          status: 'TRIALING',
          trialEnd,
        },
      });

      // Default location
      const location = await tx.location.create({
        data: {
          organizationId: org.id,
          name: body.organizationName,
          type: (body.restaurantType as any) || 'CASUAL_DINING',
        },
      });

      return { user, org, location };
    });

    const tokens = generateTokens(result.user.id, result.org.id, result.user.email);

    // Store refresh token
    await prisma.refreshToken.create({
      data: {
        token: tokens.refresh,
        userId: result.user.id,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      },
    });

    await sendWelcomeEmail(body.email, body.firstName, body.organizationName);

    return res.status(201).json({
      user: {
        id: result.user.id,
        email: result.user.email,
        firstName: result.user.firstName,
        lastName: result.user.lastName,
      },
      organization: {
        id: result.org.id,
        name: result.org.name,
        slug: result.org.slug,
      },
      location: result.location,
      tokens,
    });
  } catch (err: any) {
    if (err.name === 'ZodError') return res.status(400).json({ error: err.errors });
    console.error('Register error:', err);
    return res.status(500).json({ error: 'Registration failed' });
  }
});

// ── POST /api/auth/login ──
authRouter.post('/login', async (req: Request, res: Response) => {
  try {
    const body = loginSchema.parse(req.body);

    const user = await prisma.user.findUnique({
      where: { email: body.email },
      include: {
        organizations: {
          include: { organization: true },
          orderBy: { joinedAt: 'asc' },
        },
      },
    });

    if (!user || !await bcrypt.compare(body.password, user.passwordHash)) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    if (!user.isActive) {
      return res.status(403).json({ error: 'Account is disabled' });
    }

    if (user.organizations.length === 0) {
      return res.status(403).json({ error: 'No organization access' });
    }

    // Pick org: specified or default or first
    let orgUser = user.organizations.find(o => o.isDefault);
    if (body.organizationId) {
      orgUser = user.organizations.find(o => o.organizationId === body.organizationId) || orgUser;
    }
    if (!orgUser) orgUser = user.organizations[0];

    const tokens = generateTokens(user.id, orgUser.organizationId, user.email);

    await prisma.refreshToken.create({
      data: {
        token: tokens.refresh,
        userId: user.id,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      },
    });

    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    // If user is in multiple orgs, return them all
    const otherOrgs = user.organizations.filter(o => o.organizationId !== orgUser!.organizationId);

    return res.json({
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        avatarUrl: user.avatarUrl,
      },
      organization: orgUser.organization,
      role: orgUser.role,
      locationIds: orgUser.locationIds,
      tokens,
      otherOrganizations: otherOrgs.length > 0 ? otherOrgs.map(o => ({
        id: o.organization.id,
        name: o.organization.name,
        role: o.role,
      })) : undefined,
    });
  } catch (err: any) {
    if (err.name === 'ZodError') return res.status(400).json({ error: err.errors });
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Login failed' });
  }
});

// ── POST /api/auth/refresh ──
authRouter.post('/refresh', async (req: Request, res: Response) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(400).json({ error: 'Refresh token required' });

    const stored = await prisma.refreshToken.findUnique({ where: { token: refreshToken } });
    if (!stored || stored.expiresAt < new Date()) {
      return res.status(401).json({ error: 'Invalid or expired refresh token' });
    }

    const payload = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET!) as any;
    const tokens = generateTokens(payload.userId, payload.organizationId, payload.email);

    // Rotate refresh token
    await prisma.$transaction([
      prisma.refreshToken.delete({ where: { token: refreshToken } }),
      prisma.refreshToken.create({
        data: {
          token: tokens.refresh,
          userId: payload.userId,
          expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        },
      }),
    ]);

    return res.json({ tokens });
  } catch {
    return res.status(401).json({ error: 'Token rotation failed' });
  }
});

// ── POST /api/auth/logout ──
authRouter.post('/logout', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { refreshToken } = req.body;
    if (refreshToken) {
      await prisma.refreshToken.deleteMany({ where: { token: refreshToken } });
    }
    return res.json({ message: 'Logged out' });
  } catch {
    return res.status(500).json({ error: 'Logout failed' });
  }
});

// ── GET /api/auth/me ──
authRouter.get('/me', authenticate, async (req: AuthRequest, res: Response) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user!.id },
    select: { id: true, email: true, firstName: true, lastName: true, avatarUrl: true, lastLoginAt: true },
  });
  const org = await prisma.organization.findUnique({
    where: { id: req.user!.organizationId },
    include: {
      subscription: true,
      locations: { where: { isActive: true }, select: { id: true, name: true, type: true } },
    },
  });
  return res.json({ user, organization: org, role: req.user!.role, locationIds: req.user!.locationIds });
});

// ── POST /api/auth/accept-invite/:token ──
authRouter.post('/accept-invite/:token', async (req: Request, res: Response) => {
  try {
    const invite = await prisma.teamInvite.findUnique({
      where: { token: req.params.token },
      include: { organization: true },
    });

    if (!invite || invite.expiresAt < new Date()) {
      return res.status(400).json({ error: 'Invalid or expired invitation' });
    }
    if (invite.acceptedAt) {
      return res.status(400).json({ error: 'Invitation already accepted' });
    }

    const { password, firstName, lastName } = req.body;
    if (!password || !firstName || !lastName) {
      return res.status(400).json({ error: 'Name and password required' });
    }

    let user = await prisma.user.findUnique({ where: { email: invite.email } });
    const passwordHash = await bcrypt.hash(password, 12);

    if (!user) {
      user = await prisma.user.create({
        data: { email: invite.email, passwordHash, firstName, lastName },
      });
    }

    await prisma.$transaction([
      prisma.organizationUser.upsert({
        where: { userId_organizationId: { userId: user.id, organizationId: invite.organizationId } },
        create: { userId: user.id, organizationId: invite.organizationId, role: invite.role, locationIds: [] },
        update: { role: invite.role },
      }),
      prisma.teamInvite.update({
        where: { id: invite.id },
        data: { acceptedAt: new Date() },
      }),
    ]);

    const tokens = generateTokens(user.id, invite.organizationId, user.email);
    return res.json({ tokens, organization: invite.organization });
  } catch (err) {
    console.error('Accept invite error:', err);
    return res.status(500).json({ error: 'Failed to accept invitation' });
  }
});
