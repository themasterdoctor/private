import { Router, Request, Response } from 'express';
import Stripe from 'stripe';
import { prisma } from '../utils/prisma';
import { authenticate, AuthRequest } from '../middleware/auth';
import { sendEmail } from '../utils/email';
import { logger } from '../utils/logger';

export const billingRouter  = Router();
export const webhookRouter  = Router();

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-04-10' });

const PLAN_PRICES: Record<string, string> = {
  STARTER:    process.env.STRIPE_STARTER_PRICE_ID    || 'price_starter',
  PRO:        process.env.STRIPE_PRO_PRICE_ID        || 'price_pro',
  ENTERPRISE: process.env.STRIPE_ENTERPRISE_PRICE_ID || 'price_enterprise',
};

// ── GET /api/billing/portal ── (Customer portal link)
billingRouter.get('/portal', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const sub = await prisma.subscription.findUnique({
      where: { organizationId: req.user!.organizationId },
    });
    if (!sub?.stripeCustomerId || sub.stripeCustomerId.startsWith('cus_temp')) {
      return res.status(400).json({ error: 'No billing account found. Please subscribe first.' });
    }

    const session = await stripe.billingPortal.sessions.create({
      customer: sub.stripeCustomerId,
      return_url: `${process.env.FRONTEND_URL}/dashboard/billing`,
    });
    return res.json({ url: session.url });
  } catch (err) {
    logger.error('Portal session error:', err);
    return res.status(500).json({ error: 'Failed to create billing portal session' });
  }
});

// ── POST /api/billing/checkout ── (Create checkout session)
billingRouter.post('/checkout', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const { plan } = req.body;
    if (!PLAN_PRICES[plan]) return res.status(400).json({ error: 'Invalid plan' });

    let sub = await prisma.subscription.findUnique({
      where: { organizationId: req.user!.organizationId },
    });

    // Create or get Stripe customer
    let customerId = sub?.stripeCustomerId;
    if (!customerId || customerId.startsWith('cus_temp')) {
      const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
      const org  = await prisma.organization.findUnique({ where: { id: req.user!.organizationId } });

      const customer = await stripe.customers.create({
        email: user!.email,
        name: `${user!.firstName} ${user!.lastName}`,
        metadata: { organizationId: req.user!.organizationId, orgName: org!.name },
      });
      customerId = customer.id;

      await prisma.subscription.update({
        where: { organizationId: req.user!.organizationId },
        data: { stripeCustomerId: customerId },
      });
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      line_items: [{ price: PLAN_PRICES[plan], quantity: 1 }],
      mode: 'subscription',
      success_url: `${process.env.FRONTEND_URL}/dashboard/billing?success=true`,
      cancel_url:  `${process.env.FRONTEND_URL}/dashboard/billing?canceled=true`,
      metadata: { organizationId: req.user!.organizationId, plan },
      subscription_data: {
        metadata: { organizationId: req.user!.organizationId, plan },
      },
    });

    return res.json({ url: session.url });
  } catch (err) {
    logger.error('Checkout session error:', err);
    return res.status(500).json({ error: 'Failed to create checkout session' });
  }
});

// ── GET /api/billing/status ──
billingRouter.get('/status', authenticate, async (req: AuthRequest, res: Response) => {
  const sub = await prisma.subscription.findUnique({
    where: { organizationId: req.user!.organizationId },
  });
  return res.json(sub || { plan: 'STARTER', status: 'TRIALING' });
});

// ── POST /api/webhooks/stripe ── (Stripe webhook)
webhookRouter.post('/api/webhooks/stripe', async (req: Request, res: Response) => {
  const sig = req.headers['stripe-signature'];
  if (!sig) return res.status(400).json({ error: 'Missing signature' });

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (err: any) {
    logger.error('Webhook signature error:', err.message);
    return res.status(400).json({ error: `Webhook error: ${err.message}` });
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        if (session.mode !== 'subscription') break;
        const orgId = session.metadata?.organizationId;
        const plan  = session.metadata?.plan as any;
        if (!orgId || !plan) break;

        await prisma.subscription.update({
          where: { organizationId: orgId },
          data: {
            stripeCustomerId:     session.customer as string,
            stripeSubscriptionId: session.subscription as string,
            plan,
            status: 'ACTIVE',
          },
        });
        logger.info(`✅ Subscription activated: org=${orgId} plan=${plan}`);
        break;
      }

      case 'customer.subscription.updated': {
        const sub = event.data.object as Stripe.Subscription;
        const orgId = sub.metadata?.organizationId;
        if (!orgId) break;

        const plan = determinePlan(sub.items.data[0]?.price.id);
        await prisma.subscription.update({
          where: { organizationId: orgId },
          data: {
            plan,
            status: mapStripeStatus(sub.status),
            currentPeriodStart: new Date(sub.current_period_start * 1000),
            currentPeriodEnd:   new Date(sub.current_period_end   * 1000),
            cancelAtPeriodEnd:  sub.cancel_at_period_end,
          },
        });
        break;
      }

      case 'customer.subscription.deleted': {
        const sub = event.data.object as Stripe.Subscription;
        const orgId = sub.metadata?.organizationId;
        if (!orgId) break;

        await prisma.subscription.update({
          where: { organizationId: orgId },
          data: { status: 'CANCELED', plan: 'STARTER' },
        });

        // Send cancellation email
        const org = await prisma.organization.findUnique({ where: { id: orgId }, include: { users: { include: { user: true }, take: 1 } } });
        if (org?.users[0]?.user.email) {
          await sendEmail({
            to: org.users[0].user.email,
            subject: 'Your RestaurantOS subscription has been canceled',
            text: `Your subscription has been canceled. You can resubscribe at any time at ${process.env.FRONTEND_URL}/billing.`,
          });
        }
        break;
      }

      case 'invoice.payment_failed': {
        const inv = event.data.object as Stripe.Invoice;
        const customerId = inv.customer as string;
        const sub = await prisma.subscription.findUnique({ where: { stripeCustomerId: customerId } });
        if (sub) {
          await prisma.subscription.update({
            where: { id: sub.id },
            data: { status: 'PAST_DUE' },
          });
        }
        break;
      }
    }

    return res.json({ received: true });
  } catch (err) {
    logger.error('Webhook processing error:', err);
    return res.status(500).json({ error: 'Webhook processing failed' });
  }
});

function determinePlan(priceId: string | undefined): any {
  if (!priceId) return 'STARTER';
  if (priceId === PLAN_PRICES.ENTERPRISE) return 'ENTERPRISE';
  if (priceId === PLAN_PRICES.PRO) return 'PRO';
  return 'STARTER';
}

function mapStripeStatus(status: string): any {
  const map: Record<string, string> = {
    active: 'ACTIVE', trialing: 'TRIALING', past_due: 'PAST_DUE',
    canceled: 'CANCELED', unpaid: 'UNPAID', incomplete: 'PAST_DUE',
  };
  return map[status] || 'ACTIVE';
}
