import { Router, Response } from 'express';
import multer from 'multer';
import { join } from 'path';
import { mkdirSync } from 'fs';
import { z } from 'zod';
import { prisma } from '../utils/prisma';
import { authenticate, requireLocationAccess, AuthRequest } from '../middleware/auth';
import { parseInvoiceWithAI } from '../services/invoiceParser';
import { auditLog } from '../utils/audit';
import { logger } from '../utils/logger';

export const invoicesRouter = Router();
invoicesRouter.use(authenticate);

// ── File upload setup ──
const uploadDir = join(process.cwd(), 'uploads', 'invoices');
mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: uploadDir,
  filename: (_req, file, cb) => {
    const unique = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const ext = file.originalname.split('.').pop();
    cb(null, `invoice-${unique}.${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
  fileFilter: (_req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf', 'text/csv', 'text/plain'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Unsupported file type. Use PDF, JPG, PNG, or CSV.'));
  },
});

// ── GET /api/invoices/:locationId ──
invoicesRouter.get('/:locationId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const { status, page = '1', limit = '20' } = req.query;
    const skip = (parseInt(page as string) - 1) * parseInt(limit as string);

    const where: any = {
      locationId: req.params.locationId,
      ...(status && { status: status as any }),
    };

    const [invoices, total] = await Promise.all([
      prisma.invoice.findMany({
        where,
        include: {
          supplier: { select: { id: true, name: true } },
          lineItems: true,
          _count: { select: { lineItems: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: parseInt(limit as string),
      }),
      prisma.invoice.count({ where }),
    ]);

    return res.json({ invoices, total, page: parseInt(page as string), limit: parseInt(limit as string) });
  } catch (err) {
    logger.error('Get invoices error:', err);
    return res.status(500).json({ error: 'Failed to fetch invoices' });
  }
});

// ── POST /api/invoices/:locationId/upload ── (Upload + Parse)
invoicesRouter.post('/:locationId/upload', requireLocationAccess, upload.single('file'), async (req: AuthRequest, res: Response) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

    // Create pending invoice record
    const invoice = await prisma.invoice.create({
      data: {
        locationId: req.params.locationId,
        fileName: req.file.originalname,
        fileType: req.file.mimetype,
        fileKey: req.file.filename,
        fileUrl: `/uploads/invoices/${req.file.filename}`,
        status: 'PROCESSING',
        createdById: req.user!.id,
      },
    });

    // Parse async (don't block the response)
    parseAndUpdateInvoice(invoice.id, req.file.path, req.file.mimetype)
      .catch(err => logger.error(`Failed to parse invoice ${invoice.id}:`, err));

    return res.status(201).json({
      invoice: { id: invoice.id, status: 'PROCESSING', fileName: invoice.fileName },
      message: 'Invoice uploaded. Parsing in progress — check back in a few seconds.',
    });
  } catch (err: any) {
    logger.error('Upload error:', err);
    return res.status(500).json({ error: err.message || 'Upload failed' });
  }
});

async function parseAndUpdateInvoice(invoiceId: string, filePath: string, mimeType: string) {
  try {
    const ext = mimeType === 'application/pdf' ? 'pdf' :
                mimeType === 'text/csv' ? 'csv' : 'jpg';
    const parsed = await parseInvoiceWithAI(filePath, ext);

    await prisma.$transaction(async (tx) => {
      await tx.invoice.update({
        where: { id: invoiceId },
        data: {
          vendorName:    parsed.vendorName,
          vendorAddress: parsed.vendorAddress,
          invoiceNumber: parsed.invoiceNumber,
          invoiceDate:   parsed.invoiceDate ? new Date(parsed.invoiceDate) : null,
          dueDate:       parsed.dueDate     ? new Date(parsed.dueDate)     : null,
          subtotal:      parsed.subtotal,
          taxAmount:     parsed.taxAmount,
          shippingAmount: parsed.shippingAmount,
          totalAmount:   parsed.totalAmount,
          currency:      parsed.currency,
          aiRawResponse: parsed as any,
          parsedAt:      new Date(),
          status:        'REVIEW',
        },
      });

      // Create line items
      if (parsed.lineItems.length > 0) {
        await tx.invoiceLineItem.createMany({
          data: parsed.lineItems.map(item => ({
            invoiceId,
            description: item.description,
            unit:        item.unit,
            quantity:    item.quantity,
            unitPrice:   item.unitPrice,
            totalPrice:  item.totalPrice,
            mapping:     item.category === 'Overhead' ? 'OVERHEAD' : 'INVENTORY',
          })),
        });
      }
    });

    logger.info(`Invoice ${invoiceId} parsed successfully: ${parsed.lineItems.length} items`);
  } catch (err) {
    await prisma.invoice.update({
      where: { id: invoiceId },
      data: { status: 'REJECTED', notes: 'Parsing failed. Please review manually.' },
    });
    logger.error(`Invoice ${invoiceId} parsing failed:`, err);
  }
}

// ── GET /api/invoices/:locationId/:invoiceId ── (Get single with line items)
invoicesRouter.get('/:locationId/:invoiceId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const invoice = await prisma.invoice.findFirst({
      where: { id: req.params.invoiceId, locationId: req.params.locationId },
      include: {
        supplier: true,
        lineItems: {
          include: { inventoryItem: { select: { id: true, name: true, unit: true, unitCost: true } } },
        },
      },
    });
    if (!invoice) return res.status(404).json({ error: 'Invoice not found' });
    return res.json(invoice);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch invoice' });
  }
});

// ── PATCH /api/invoices/:locationId/:invoiceId/line-items ── (Update mappings before applying)
invoicesRouter.patch('/:locationId/:invoiceId/line-items', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const { lineItems } = req.body; // [{id, mapping, inventoryItemId, quantity, unitPrice}]
    if (!Array.isArray(lineItems)) return res.status(400).json({ error: 'lineItems array required' });

    await Promise.all(lineItems.map(item =>
      prisma.invoiceLineItem.update({
        where: { id: item.id },
        data: {
          mapping: item.mapping,
          inventoryItemId: item.inventoryItemId || null,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          totalPrice: item.quantity * item.unitPrice,
        },
      })
    ));

    return res.json({ message: 'Line items updated' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to update line items' });
  }
});

// ── POST /api/invoices/:locationId/:invoiceId/apply ── (Apply reviewed invoice)
invoicesRouter.post('/:locationId/:invoiceId/apply', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const invoice = await prisma.invoice.findFirst({
      where: { id: req.params.invoiceId, locationId: req.params.locationId },
      include: { lineItems: true },
    });
    if (!invoice) return res.status(404).json({ error: 'Invoice not found' });
    if (invoice.status === 'APPLIED') return res.status(400).json({ error: 'Invoice already applied' });
    if (invoice.status !== 'REVIEW') return res.status(400).json({ error: 'Invoice must be in REVIEW status to apply' });

    const inventoryItems = invoice.lineItems.filter(li => li.mapping === 'INVENTORY' || li.mapping === 'PURCHASES');
    let appliedCount = 0;
    let totalPurchases = 0;

    await prisma.$transaction(async (tx) => {
      for (const lineItem of inventoryItems) {
        totalPurchases += lineItem.totalPrice;

        if (lineItem.inventoryItemId) {
          // Update existing inventory item
          await tx.inventoryItem.update({
            where: { id: lineItem.inventoryItemId },
            data: {
              quantityOnHand: { increment: lineItem.quantity },
              unitCost: lineItem.unitPrice,
            },
          });

          // Create transaction record
          await tx.inventoryTransaction.create({
            data: {
              inventoryItemId: lineItem.inventoryItemId,
              type: 'PURCHASE',
              quantity: lineItem.quantity,
              unitCost: lineItem.unitPrice,
              totalCost: lineItem.totalPrice,
              reference: invoice.invoiceNumber || invoice.id,
              invoiceId: invoice.id,
            },
          });
          appliedCount++;
        }

        await tx.invoiceLineItem.update({
          where: { id: lineItem.id },
          data: { isApplied: true },
        });
      }

      await tx.invoice.update({
        where: { id: invoice.id },
        data: { status: 'APPLIED', appliedAt: new Date(), appliedById: req.user!.id },
      });
    });

    await auditLog({
      organizationId: req.user!.organizationId,
      userId: req.user!.id,
      action: 'APPLY_INVOICE',
      resource: 'invoices',
      resourceId: invoice.id,
      newValues: { appliedCount, totalPurchases },
    });

    return res.json({
      message: `Invoice applied. Updated ${appliedCount} inventory items. Total purchases: $${totalPurchases.toFixed(2)}`,
      appliedCount,
      totalPurchases,
    });
  } catch (err) {
    logger.error('Apply invoice error:', err);
    return res.status(500).json({ error: 'Failed to apply invoice' });
  }
});

// ── DELETE /api/invoices/:locationId/:invoiceId ──
invoicesRouter.delete('/:locationId/:invoiceId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    await prisma.invoice.deleteMany({
      where: { id: req.params.invoiceId, locationId: req.params.locationId, status: { not: 'APPLIED' } },
    });
    return res.json({ message: 'Invoice deleted' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to delete invoice' });
  }
});
