import { Router, Response } from 'express';
import { z } from 'zod';
import { prisma } from '../utils/prisma';
import { authenticate, requireLocationAccess, AuthRequest } from '../middleware/auth';
import { auditLog } from '../utils/audit';
import { logger } from '../utils/logger';

export const salesRouter = Router();
salesRouter.use(authenticate);

const salesSchema = z.object({
  date:           z.string().regex(/^\d{4}-\d{2}-\d{2}/),
  grossSales:     z.number().min(0),
  discounts:      z.number().min(0).default(0),
  comps:          z.number().min(0).default(0),
  refunds:        z.number().min(0).default(0),
  dineInSales:    z.number().min(0).default(0),
  deliverySales:  z.number().min(0).default(0),
  takeoutSales:   z.number().min(0).default(0),
  cateringsSales: z.number().min(0).default(0),
  covers:         z.number().int().min(0).default(0),
  transactions:   z.number().int().min(0).default(0),
  notes:          z.string().optional(),
});

// ── GET /api/sales/:locationId ──
salesRouter.get('/:locationId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const { startDate, endDate, page = '1', limit = '30' } = req.query;
    const skip = (parseInt(page as string) - 1) * parseInt(limit as string);

    const where: any = { locationId: req.params.locationId };
    if (startDate) where.date = { gte: new Date(startDate as string) };
    if (endDate)   where.date = { ...where.date, lte: new Date(endDate as string) };

    const [entries, total] = await Promise.all([
      prisma.salesEntry.findMany({
        where,
        orderBy: { date: 'desc' },
        skip,
        take: parseInt(limit as string),
      }),
      prisma.salesEntry.count({ where }),
    ]);

    return res.json({ entries, total, page: parseInt(page as string) });
  } catch (err) {
    logger.error('Get sales error:', err);
    return res.status(500).json({ error: 'Failed to fetch sales' });
  }
});

// ── GET /api/sales/:locationId/summary ──
salesRouter.get('/:locationId/summary', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const { days = '30' } = req.query;
    const since = new Date();
    since.setDate(since.getDate() - parseInt(days as string));

    const entries = await prisma.salesEntry.findMany({
      where: { locationId: req.params.locationId, date: { gte: since } },
      orderBy: { date: 'asc' },
    });

    if (entries.length === 0) {
      return res.json({ totalSales: 0, totalCovers: 0, avgCheck: 0, todaySales: 0, dailyTrend: [] });
    }

    const totalSales  = entries.reduce((a, e) => a + e.netSales, 0);
    const totalCovers = entries.reduce((a, e) => a + e.covers, 0);
    const totalGross  = entries.reduce((a, e) => a + e.grossSales, 0);
    const dineIn      = entries.reduce((a, e) => a + e.dineInSales, 0);
    const delivery    = entries.reduce((a, e) => a + e.deliverySales, 0);
    const takeout     = entries.reduce((a, e) => a + e.takeoutSales, 0);

    const today = entries[entries.length - 1];

    const dineInPct   = totalSales > 0 ? Math.round(dineIn / totalSales * 100) : 0;
    const deliveryPct = totalSales > 0 ? Math.round(delivery / totalSales * 100) : 0;
    const takeoutPct  = 100 - dineInPct - deliveryPct;

    const dailyTrend = entries.map(e => ({
      date:  e.date.toISOString().slice(5, 10), // MM-DD
      sales: Math.round(e.netSales),
      covers: e.covers,
    }));

    return res.json({
      totalSales:   Math.round(totalSales),
      totalGross:   Math.round(totalGross),
      totalCovers,
      avgCheck:     totalCovers > 0 ? Math.round(totalSales / totalCovers) : 0,
      todaySales:   Math.round(today?.netSales || 0),
      todayCovers:  today?.covers || 0,
      dineIn:       dineInPct,
      delivery:     deliveryPct,
      takeout:      takeoutPct,
      dailyTrend,
      entryCount:   entries.length,
    });
  } catch (err) {
    logger.error('Sales summary error:', err);
    return res.status(500).json({ error: 'Failed to compute summary' });
  }
});

// ── POST /api/sales/:locationId ──
salesRouter.post('/:locationId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const body = salesSchema.parse(req.body);
    const netSales = Math.max(0, body.grossSales - body.discounts - body.comps - body.refunds);
    const avgCheck = body.covers > 0 ? netSales / body.covers : 0;

    const entry = await prisma.salesEntry.upsert({
      where: {
        locationId_date: {
          locationId: req.params.locationId,
          date: new Date(body.date),
        },
      },
      update: { ...body, netSales, avgCheck, createdById: req.user!.id },
      create: {
        locationId: req.params.locationId,
        date:       new Date(body.date),
        netSales,
        avgCheck,
        createdById: req.user!.id,
        ...body,
      },
    });

    await auditLog({
      organizationId: req.user!.organizationId,
      userId:         req.user!.id,
      action:         'UPSERT_SALE',
      resource:       'sales_entries',
      resourceId:     entry.id,
      newValues:      { date: body.date, netSales, grossSales: body.grossSales },
    });

    return res.status(201).json(entry);
  } catch (err: any) {
    if (err.name === 'ZodError') return res.status(400).json({ error: err.errors });
    logger.error('Create sale error:', err);
    return res.status(500).json({ error: 'Failed to save sales entry' });
  }
});

// ── PATCH /api/sales/:locationId/:entryId ──
salesRouter.patch('/:locationId/:entryId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    const existing = await prisma.salesEntry.findFirst({
      where: { id: req.params.entryId, locationId: req.params.locationId },
    });
    if (!existing) return res.status(404).json({ error: 'Entry not found' });

    const updated = await prisma.salesEntry.update({
      where: { id: req.params.entryId },
      data: {
        ...req.body,
        netSales: req.body.grossSales != null
          ? Math.max(0, req.body.grossSales - (req.body.discounts ?? existing.discounts) - (req.body.comps ?? existing.comps))
          : undefined,
      },
    });

    return res.json(updated);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to update sale' });
  }
});

// ── DELETE /api/sales/:locationId/:entryId ──
salesRouter.delete('/:locationId/:entryId', requireLocationAccess, async (req: AuthRequest, res: Response) => {
  try {
    await prisma.salesEntry.deleteMany({
      where: { id: req.params.entryId, locationId: req.params.locationId },
    });
    return res.json({ message: 'Deleted' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to delete' });
  }
});
