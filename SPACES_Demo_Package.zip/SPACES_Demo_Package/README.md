# Mock SPACES - Vulnerability Demonstration System

All data is FAKE for demonstration purposes only.

## Quick Start (3 minutes)

### Step 1: Install Python packages
```bash
pip install fastapi uvicorn
```

### Step 2: Start the backend (Terminal 1)
```bash
python mock_backend.py
```

You should see:
```
============================================================
MOCK SPACES API STARTING
============================================================
Running on: http://localhost:8000
Total customers: 1000
============================================================
```

### Step 3: Run the demo (Terminal 2)
```bash
bash demo.sh
```

The automated demo will show all vulnerabilities!

## Alternative: Web Interface (5 minutes)

### Step 1: Install dependencies
```bash
pip install fastapi uvicorn
npm install
```

### Step 2: Start backend (Terminal 1)
```bash
python mock_backend.py
```

### Step 3: Start frontend (Terminal 2)
```bash
npm start
```

Browser will open at http://localhost:3000
Click buttons to trigger vulnerabilities!

## Manual Testing with curl (Terminal 2)

After starting backend:

```bash
# Check if API is working
curl http://localhost:8000/health

# Access customer 1001
curl http://localhost:8000/customer-api/v1/user/profile/1001

# Access customer 1002 (without permission - IDOR!)
curl http://localhost:8000/customer-api/v1/user/profile/1002

# Get all customers (no auth required)
curl http://localhost:8000/customer-api/v1/all-customers?limit=10

# Get exposed keys
curl http://localhost:8000/config/keys

# Get vehicle info
curl http://localhost:8000/customer-api/v1/user/vehicle/1001

# Get payment methods
curl http://localhost:8000/customer-api/v1/user/payment/1001

# Charge customer (CSRF - no token required)
curl -X POST "http://localhost:8000/customer-api/v1/charge?customer_id=1001&amount=99.99"
```

## Files Included

- `mock_backend.py` - FastAPI backend with intentional vulnerabilities
- `demo.sh` - Automated demonstration script
- `App.jsx` - React web interface
- `App.css` - Styling
- `index.js` - React entry point
- `index.html` - HTML page
- `package.json` - Node dependencies
- `README.md` - This file

## Vulnerabilities Demonstrated

✗ IDOR - Access any customer's data without authentication
✗ Missing Authentication - No login required for any endpoint
✗ Exposed API Keys - HMAC and Stripe keys publicly accessible
✗ CSRF - No CSRF token validation on state-changing requests
✗ Data Exposure - Vehicle locations and payment methods exposed
✗ Admin Access - Complete database accessible without authentication

## Troubleshooting

**"python: command not found"**
- Download Python from https://www.python.org/downloads/

**"pip install failed"**
- Try: python -m pip install fastapi uvicorn

**"Port 8000 already in use"**
- Mac/Linux: lsof -ti:8000 | xargs kill -9
- Windows: netstat -ano | findstr :8000

**"npm install failed"**
- Try: npm install -g npm (upgrade npm first)

## Support

This is a demonstration system for educational purposes.
All customer data is randomly generated and fake.
No real systems or data are harmed.
