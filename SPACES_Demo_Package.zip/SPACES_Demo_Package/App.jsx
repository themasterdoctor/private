import React, { useState } from 'react';
import './App.css';

export default function App() {
  const [response, setResponse] = useState(null);
  const [loading, setLoading] = useState(false);

  const API = 'http://localhost:8000';

  const test = async (url, title) => {
    setLoading(true);
    try {
      const res = await fetch(url);
      const data = await res.json();
      setResponse({ title, data: JSON.stringify(data, null, 2) });
    } catch (e) {
      setResponse({ title, data: 'Error: ' + e.message });
    }
    setLoading(false);
  };

  const buttonStyle = {
    padding: '12px 20px',
    margin: '5px',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    color: 'white',
    transition: 'all 0.3s ease',
    minWidth: '200px'
  };

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '20px', fontFamily: 'Arial, sans-serif', background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', minHeight: '100vh' }}>
      <div style={{ background: 'white', padding: '30px', borderRadius: '10px', marginBottom: '20px' }}>
        <h1 style={{ color: '#d32f2f', margin: '0 0 10px 0' }}>🚨 Mock SPACES - Vulnerability Demo</h1>
        <p style={{ background: '#ff9800', color: 'white', padding: '10px', borderRadius: '5px', margin: '10px 0', fontWeight: 'bold' }}>
          ⚠️ All data is FAKE for demonstration only
        </p>
      </div>

      <div style={{ background: 'white', padding: '20px', borderRadius: '10px', marginBottom: '20px' }}>
        <h2 style={{ color: '#333', marginTop: 0 }}>Vulnerability Demonstrations</h2>
        
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '10px' }}>
          <button 
            onClick={() => test(`${API}/customer-api/v1/user/profile/1001`, 'Customer 1001 Profile')} 
            disabled={loading}
            style={{ ...buttonStyle, background: '#667eea' }}
          >
            Access Customer 1001
          </button>
          
          <button 
            onClick={() => test(`${API}/customer-api/v1/user/profile/1002`, 'Customer 1002 (IDOR!)')} 
            disabled={loading}
            style={{ ...buttonStyle, background: '#f44336' }}
          >
            Access Customer 1002 (IDOR)
          </button>
          
          <button 
            onClick={() => test(`${API}/customer-api/v1/all-customers?limit=10`, 'All Customers (NO AUTH)')} 
            disabled={loading}
            style={{ ...buttonStyle, background: '#f44336' }}
          >
            Get All Customers
          </button>
          
          <button 
            onClick={() => test(`${API}/config/keys`, 'Exposed Keys')} 
            disabled={loading}
            style={{ ...buttonStyle, background: '#c62828' }}
          >
            Get Exposed Keys
          </button>
          
          <button 
            onClick={() => test(`${API}/customer-api/v1/user/vehicle/1001`, 'Vehicle Info')} 
            disabled={loading}
            style={{ ...buttonStyle, background: '#667eea' }}
          >
            Get Vehicle Info
          </button>
          
          <button 
            onClick={() => test(`${API}/customer-api/v1/user/payment/1001`, 'Payment Methods')} 
            disabled={loading}
            style={{ ...buttonStyle, background: '#667eea' }}
          >
            Get Payment Methods
          </button>

          <button 
            onClick={() => test(`${API}/admin/all-data`, 'Admin Data')} 
            disabled={loading}
            style={{ ...buttonStyle, background: '#c62828' }}
          >
            Get Admin Data
          </button>

          <button 
            onClick={() => test(`${API}/system-info`, 'System Info')} 
            disabled={loading}
            style={{ ...buttonStyle, background: '#ff9800' }}
          >
            Get System Info
          </button>
        </div>
      </div>

      {response && (
        <div style={{ background: 'white', padding: '20px', borderRadius: '10px' }}>
          <h3 style={{ color: '#333', marginTop: 0 }}>{response.title}</h3>
          <pre style={{ background: '#f5f5f5', padding: '15px', borderRadius: '5px', overflow: 'auto', fontSize: '12px', border: '1px solid #ddd' }}>
            {response.data}
          </pre>
        </div>
      )}
    </div>
  );
}
