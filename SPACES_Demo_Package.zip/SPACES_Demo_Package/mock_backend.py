from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="Mock SPACES API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

EXPOSED_HMAC_KEY = "gVcqJ49yEg39L9w2S8kQ6RrVWj39J2"
EXPOSED_STRIPE_KEY = "pk_live_HjXDh73JhSsHNOL30NGwNPcn00iuoWw9at"

FAKE_CUSTOMERS = {}
for i in range(1001, 2001):
    FAKE_CUSTOMERS[str(i)] = {
        "id": str(i),
        "name": f"Customer {i}",
        "email": f"customer{i}@example.com",
        "phone": f"555-{i:04d}",
        "vehicle": {
            "make": ["Honda", "Ford", "Tesla", "BMW", "Toyota"][i % 5],
            "model": "Model",
            "color": ["Red", "Blue", "White", "Black"][i % 4],
            "license": f"LIC-{i:05d}"
        },
        "payment_methods": [
            {
                "type": "credit_card",
                "last_four": str((i * 13) % 10000).zfill(4),
                "brand": ["Visa", "Mastercard", "Amex"][i % 3],
                "exp": f"{(i % 12) + 1:02d}/27"
            }
        ],
        "parking_history": [
            {
                "id": f"park_{i:05d}",
                "location": "Airport Terminal",
                "start": "2026-06-28 08:00",
                "end": "2026-06-28 16:00",
                "cost": 40.00 + (i % 30),
                "status": "completed"
            }
        ]
    }

@app.get("/health")
def health():
    return {"status": "online", "system": "Mock SPACES API"}

@app.get("/customer-api/v1/user/profile/{customer_id}")
def get_profile(customer_id: str):
    if customer_id not in FAKE_CUSTOMERS:
        raise HTTPException(status_code=404, detail="Not found")
    c = FAKE_CUSTOMERS[customer_id]
    return {
        "id": c["id"],
        "name": c["name"],
        "email": c["email"],
        "phone": c["phone"],
        "vehicle": c["vehicle"],
        "payment_methods": c["payment_methods"]
    }

@app.get("/customer-api/v1/user/vehicle/{customer_id}")
def get_vehicle(customer_id: str):
    if customer_id not in FAKE_CUSTOMERS:
        raise HTTPException(status_code=404, detail="Not found")
    return {"vehicle": FAKE_CUSTOMERS[customer_id]["vehicle"]}

@app.get("/customer-api/v1/user/payment/{customer_id}")
def get_payment(customer_id: str):
    if customer_id not in FAKE_CUSTOMERS:
        raise HTTPException(status_code=404, detail="Not found")
    return {"payment_methods": FAKE_CUSTOMERS[customer_id]["payment_methods"]}

@app.get("/customer-api/v1/park/{customer_id}")
def get_parking(customer_id: str):
    if customer_id not in FAKE_CUSTOMERS:
        raise HTTPException(status_code=404, detail="Not found")
    return {"parking_history": FAKE_CUSTOMERS[customer_id]["parking_history"]}

@app.get("/customer-api/v1/all-customers")
def get_all(limit: int = 10):
    customers = []
    count = 0
    for cid, c in FAKE_CUSTOMERS.items():
        if count >= limit:
            break
        customers.append({"id": c["id"], "name": c["name"], "email": c["email"]})
        count += 1
    return {"total": len(FAKE_CUSTOMERS), "customers": customers}

@app.get("/admin/all-data")
def admin_data():
    return {"total": len(FAKE_CUSTOMERS), "data": FAKE_CUSTOMERS}

@app.get("/config/keys")
def get_keys():
    return {"hmac_key": EXPOSED_HMAC_KEY, "stripe_key": EXPOSED_STRIPE_KEY}

@app.post("/customer-api/v1/charge")
def charge(customer_id: str, amount: float):
    if customer_id not in FAKE_CUSTOMERS:
        raise HTTPException(status_code=404, detail="Not found")
    return {"status": "charged", "customer_id": customer_id, "amount": amount}

@app.get("/system-info")
def info():
    return {"system": "Mock SPACES API", "note": "DEMO ONLY"}

if __name__ == "__main__":
    import uvicorn
    print("\n" + "="*60)
    print("MOCK SPACES API STARTING")
    print("="*60)
    print("Running on: http://localhost:8000")
    print("Total customers: " + str(len(FAKE_CUSTOMERS)))
    print("="*60 + "\n")
    uvicorn.run(app, host="127.0.0.1", port=8000)
