import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { useStore } from './store';
import { CVSS_VECTORS, MITRE_MAP } from './data';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { downloadEliteReports } from './pdf';

// ─── THEME ────────────────────────────────────────────────────────────────────
const C = {
  bg:'#060809',bg2:'#0C0E12',bg3:'#111419',bg4:'#171B22',bg5:'#1D2229',
  border:'#1E2530',border2:'#263040',border3:'#2E3A4A',
  accent:'#00C8F0',accent2:'#0099BB',
  purple:'#8B5CF6',purple2:'#6D28D9',
  green:'#10B981',green2:'#059669',
  amber:'#F59E0B',amber2:'#D97706',
  red:'#EF4444',red2:'#DC2626',
  pink:'#EC4899',
  text:'#E2E8F0',text2:'#94A3B8',text3:'#64748B',text4:'#3E4F63',
  mono:"'SF Mono','Fira Code','Consolas',monospace",
};

const SEV = {
  critical:{label:'CRITICAL',color:'#FF5555',bg:'rgba(239,68,68,.12)',border:'rgba(239,68,68,.3)',glow:'rgba(239,68,68,.2)'},
  high:    {label:'HIGH',    color:'#F59E0B',bg:'rgba(245,158,11,.12)',border:'rgba(245,158,11,.3)',glow:'rgba(245,158,11,.2)'},
  medium:  {label:'MEDIUM',  color:'#00C8F0',bg:'rgba(0,200,240,.1)', border:'rgba(0,200,240,.28)',glow:'rgba(0,200,240,.15)'},
  low:     {label:'LOW',     color:'#10B981',bg:'rgba(16,185,129,.1)', border:'rgba(16,185,129,.28)',glow:'rgba(16,185,129,.15)'},
  info:    {label:'INFO',    color:'#64748B',bg:'rgba(100,116,139,.1)',border:'rgba(100,116,139,.2)',glow:'none'},
};
const AREA_C = {aws:'#FF9900',dns:C.accent,web:C.purple,rep:C.green,gen:C.text3};
const STATUS_C = {complete:C.green,wip:C.accent,finding:C.red,queued:C.text3,escalated:C.red};
const STATUS_L = {complete:'Complete',wip:'In Progress',finding:'Finding',queued:'Queued',escalated:'Escalated'};

// ─── MICRO UI ─────────────────────────────────────────────────────────────────
const m = (color,size=7) => {
  const [op,setOp] = useState(1);
  useEffect(()=>{const t=setInterval(()=>setOp(o=>o>.25?.25:1),900);return()=>clearInterval(t);},[]);
  return <span style={{display:'inline-block',width:size,height:size,borderRadius:'50%',background:color,opacity:op,transition:'opacity .6s',flexShrink:0}}/>;
};
const Pulse = m;

const Badge = ({sev}) => { const s=SEV[sev]||SEV.info; return <span style={{display:'inline-flex',alignItems:'center',borderRadius:3,padding:'2px 8px',fontSize:'9.5px',fontWeight:700,fontFamily:C.mono,color:s.color,background:s.bg,border:`1px solid ${s.border}`,letterSpacing:'.5px'}}>{s.label}</span>; };
const AreaBadge = ({area}) => <span style={{display:'inline-flex',alignItems:'center',borderRadius:3,padding:'1px 6px',fontSize:'9px',fontFamily:C.mono,color:AREA_C[area]||C.text3,background:`${AREA_C[area]||C.text3}15`,border:`1px solid ${AREA_C[area]||C.text3}30`}}>{(area||'').toUpperCase()}</span>;

const Inp = ({value,onChange,placeholder,onKey,style,mono,type='text'}) => (
  <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} onKeyDown={onKey}
    style={{background:C.bg4,border:`1px solid ${C.border2}`,borderRadius:5,padding:'7px 11px',color:C.text,fontSize:'11.5px',outline:'none',fontFamily:mono?C.mono:'inherit',width:'100%',...style}}/>
);
const Txt = ({value,onChange,placeholder,rows=3}) => (
  <textarea value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} rows={rows}
    style={{background:C.bg4,border:`1px solid ${C.border2}`,borderRadius:5,padding:'7px 11px',color:C.text,fontSize:'11.5px',outline:'none',fontFamily:'inherit',width:'100%',resize:'vertical'}}/>
);
const Sel = ({value,onChange,options,style}) => (
  <select value={value} onChange={e=>onChange(e.target.value)} style={{background:C.bg4,border:`1px solid ${C.border2}`,borderRadius:5,padding:'6px 10px',color:C.text,fontSize:'11px',outline:'none',...style}}>
    {options.map(o=><option key={o.v||o} value={o.v||o}>{o.l||o}</option>)}
  </select>
);
const Btn = ({children,onClick,color,outline,danger,small,full,disabled}) => (
  <button onClick={disabled?undefined:onClick} disabled={disabled} style={{background:danger?'rgba(239,68,68,.1)':outline||!color?'transparent':(color||C.accent)+'18',border:`1px solid ${danger?'rgba(239,68,68,.4)':outline?C.border2:color||C.accent}`,borderRadius:5,padding:small?'4px 10px':'6px 14px',color:danger?C.red:color||C.accent,fontSize:small?10:11,fontWeight:600,cursor:disabled?'not-allowed':onClick?'pointer':'default',fontFamily:C.mono,whiteSpace:'nowrap',width:full?'100%':undefined,opacity:disabled?.5:1,transition:'.12s'}}>
    {children}
  </button>
);
const Card = ({children,style,glow}) => (
  <div style={{background:C.bg2,border:`1px solid ${C.border}`,borderRadius:10,overflow:'hidden',marginBottom:14,...(glow?{boxShadow:`0 0 20px ${glow}`}:{}),...style}}>{children}</div>
);
const CHead = ({title,dot,sub,right,accent}) => (
  <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 16px',borderBottom:`1px solid ${C.border}`,borderLeft:accent?`3px solid ${accent}`:undefined}}>
    <div>
      <div style={{display:'flex',alignItems:'center',gap:7,fontSize:'12px',fontWeight:600,color:C.text}}>
        {dot&&<span style={{width:5,height:5,borderRadius:'50%',background:dot,display:'inline-block'}}/>}
        {title}
      </div>
      {sub&&<div style={{fontSize:'10px',color:C.text3,marginTop:2}}>{sub}</div>}
    </div>
    {right}
  </div>
);
const CB = ({children,p}) => <div style={{padding:p??14}}>{children}</div>;

const G2 = ({c,g=14,children}) => <div style={{display:'grid',gridTemplateColumns:c||'1fr 1fr',gap:g}}>{children}</div>;
const Grid = ({cols,gap=10,children}) => <div style={{display:'grid',gridTemplateColumns:cols,gap}}>{children}</div>;

const PH = ({title,sub,right}) => (
  <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:16}}>
    <div>
      <div style={{fontSize:18,fontWeight:700,color:C.text,letterSpacing:'-.3px'}}>{title}</div>
      {sub&&<div style={{fontSize:'11.5px',color:C.text3,marginTop:3}}>{sub}</div>}
    </div>
    {right}
  </div>
);

const StatCard = ({label,val,sub,color,trend,icon}) => (
  <div style={{background:C.bg2,border:`1px solid ${C.border}`,borderRadius:10,padding:16,position:'relative',overflow:'hidden'}}>
    <div style={{position:'absolute',top:0,left:0,right:0,height:2,background:color}}/>
    <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
      <div>
        <div style={{fontSize:'9.5px',letterSpacing:'1.2px',color:C.text3,textTransform:'uppercase',fontFamily:C.mono,marginBottom:6}}>{label}</div>
        <div style={{fontSize:28,fontWeight:700,fontFamily:C.mono,lineHeight:1,color}}>{val}</div>
        {sub&&<div style={{fontSize:'10px',color:C.text3,marginTop:4}}>{sub}</div>}
      </div>
      {icon&&<span style={{fontSize:22,opacity:.35}}>{icon}</span>}
    </div>
    {trend&&<div style={{fontSize:'10px',color:trend>0?C.green:C.red,marginTop:6,fontFamily:C.mono}}>{trend>0?'↑':'↓'} {Math.abs(trend)}% vs last week</div>}
  </div>
);

const THead = ({cols}) => <thead><tr>{cols.map((c,i)=><th key={i} style={{textAlign:'left',padding:'7px 12px',color:C.text3,fontWeight:500,fontFamily:C.mono,fontSize:'9.5px',letterSpacing:'.5px',borderBottom:`1px solid ${C.border}`,background:C.bg3,whiteSpace:'nowrap'}}>{c}</th>)}</tr></thead>;
const Td = ({children,style}) => <td style={{padding:'8px 12px',borderBottom:`1px solid ${C.bg5}`,color:C.text2,verticalAlign:'top',fontSize:'11.5px',...style}}>{children}</td>;
const Tbl = ({cols,children,style}) => <table style={{width:'100%',borderCollapse:'collapse',fontSize:'11.5px',...style}}><THead cols={cols}/><tbody>{children}</tbody></table>;

const Toast = ({msg,type}) => <div style={{position:'fixed',bottom:24,right:24,background:type==='error'?C.red2:type==='warn'?C.amber2:C.green2,color:'#fff',padding:'10px 20px',borderRadius:8,fontSize:'12px',fontWeight:500,zIndex:9999,boxShadow:'0 8px 32px rgba(0,0,0,.5)',display:'flex',alignItems:'center',gap:8}}><span>{type==='error'?'✕':type==='warn'?'⚠':'✓'}</span>{msg}</div>;

const Modal = ({title,onClose,children,width=560}) => (
  <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.75)',zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center',padding:20}} onClick={onClose}>
    <div style={{background:C.bg2,border:`1px solid ${C.border2}`,borderRadius:12,width,maxWidth:'95vw',maxHeight:'85vh',overflow:'auto',padding:22}} onClick={e=>e.stopPropagation()}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:18}}>
        <span style={{fontSize:14,fontWeight:600,color:C.text}}>{title}</span>
        <button onClick={onClose} style={{background:'none',border:'none',color:C.text3,fontSize:20,cursor:'pointer',lineHeight:1}}>✕</button>
      </div>
      {children}
    </div>
  </div>
);

const Field = ({label,children,required}) => (
  <div style={{marginBottom:12}}>
    <div style={{fontSize:'9.5px',color:required?C.amber:C.text3,fontFamily:C.mono,marginBottom:4,letterSpacing:'.5px'}}>{label.toUpperCase()}{required&&' *'}</div>
    {children}
  </div>
);

// ─── AI ENGINE ────────────────────────────────────────────────────────────────
const buildSystem = (eng, findings, scope, targets) => `You are SecureNet Elite AI — an elite offensive security and threat intelligence engine embedded in a professional penetration testing management platform.

OPERATOR: ${eng?.consultant||'Christian'} — Independent Security Consultant
CLIENT: ${eng?.client} (${eng?.address})
ENGAGEMENT: ${eng?.type} | $${eng?.investment} | Week ${eng?.currentWeek}/${eng?.totalWeeks}
CONTACTS: ${eng?.contacts?.map(c=>`${c.name} (${c.role})${c.emergency?' [EMERGENCY]':''}`).join(' | ')}

IN-SCOPE TARGETS:
${(targets||[]).filter(t=>t.value&&t.inScope).map(t=>`  ${t.type.toUpperCase()}: ${t.value} — ${t.notes}`).join('\n')}

ACTIVE FINDINGS (${findings.length} total):
${findings.map(f=>`  ${f.id} [${f.sev.toUpperCase()} CVSS:${f.cvss}] ${f.title} — ${f.status.toUpperCase()}${f.affectedAsset?' | Asset: '+f.affectedAsset:''}`).join('\n')}

SCOPE STATUS: ${scope.filter(s=>s.status==='complete').length} complete, ${scope.filter(s=>s.status==='wip').length} in progress, ${scope.filter(s=>s.status==='finding').length} with findings, ${scope.filter(s=>s.status==='queued').length} queued

METHODOLOGY: Gray-box authorized, non-destructive, evidence-based. OWASP WSTG v4.2 + Top 10 2021. CVSS v3.1. MITRE ATT&CK mapped. No weaponized exploits.

CAPABILITIES: You can generate professional finding narratives, CVSS scores, MITRE ATT&CK mappings, client-ready explanations, escalation messages, remediation scripts, compliance mappings (SOC2/PCI/ISO27001), attack chain analysis, and executive summaries. Be precise, technical when needed, and always security-expert accurate.`;

// ─── VIEWS ────────────────────────────────────────────────────────────────────

// DASHBOARD
function Dashboard({ store, nav }) {
  const { findings, eng, state } = store;
  const crit = findings.filter(f=>f.sev==='critical').length;
  const high = findings.filter(f=>f.sev==='high').length;
  const med  = findings.filter(f=>f.sev==='medium').length;
  const comp = state.scopeItems.filter(s=>s.status==='complete').length;
  const wip  = state.scopeItems.filter(s=>s.status==='wip'||s.status==='finding').length;

  const sevData = [
    {name:'Critical',val:crit,color:C.red},{name:'High',val:high,color:C.amber},
    {name:'Medium',val:med,color:C.accent},{name:'Low',val:findings.filter(f=>f.sev==='low').length,color:C.green},
  ];
  const areaData = [
    {name:'AWS',val:findings.filter(f=>f.area==='aws').length,color:'#FF9900'},
    {name:'DNS',val:findings.filter(f=>f.area==='dns').length,color:C.accent},
    {name:'Web',val:findings.filter(f=>f.area==='web').length,color:C.purple},
  ];
  const progressData = [
    {name:'Complete',val:comp,color:C.green},{name:'In Progress',val:wip,color:C.accent},
    {name:'Queued',val:27-comp-wip,color:C.text4},
  ];

  return (
    <div>
      <PH title="Mission Control" sub={`${eng?.client} · Week ${eng?.currentWeek}/${eng?.totalWeeks} · Phase ${eng?.currentPhase}/11 · ${new Date().toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'})}`}
        right={<div style={{display:'flex',gap:8}}><Btn onClick={()=>nav('reports')} color={C.purple}>📋 Generate Reports</Btn><Btn onClick={()=>nav('ai')} color={C.accent}>⟡ AI Assistant</Btn></div>}/>

      {/* Alert banner for criticals */}
      {crit > 0 && (
        <div style={{background:'rgba(239,68,68,.08)',border:'1px solid rgba(239,68,68,.35)',borderRadius:8,padding:'10px 16px',marginBottom:16,display:'flex',alignItems:'center',gap:12,cursor:'pointer'}} onClick={()=>nav('findings')}>
          <Pulse color={C.red} size={8}/>
          <span style={{fontSize:'12px',color:C.red,fontWeight:600}}>⚡ {crit} CRITICAL finding{crit>1?'s':''} require{crit===1?'s':''} immediate action</span>
          <span style={{marginLeft:'auto',fontSize:'11px',color:C.red,opacity:.7}}>Click to view →</span>
        </div>
      )}

      {/* Stats */}
      <Grid cols="repeat(5,1fr)" gap={10} style={{marginBottom:16}}>
        <StatCard label="Critical" val={crit} color={C.red} sub="Escalated" icon="🔴"/>
        <StatCard label="High" val={high} color={C.amber} sub="Open" icon="🟠"/>
        <StatCard label="Medium" val={med} color={C.accent} sub="Open" icon="🔵"/>
        <StatCard label="Scope Items" val={`${comp}/27`} color={C.green} sub={`${wip} active`} icon="✅"/>
        <StatCard label="Progress" val={`${eng?.progress||0}%`} color={C.purple} sub="On schedule" icon="📊"/>
      </Grid>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:14}}>
        {/* Finding breakdown chart */}
        <Card>
          <CHead title="Finding Severity Distribution" dot={C.red}/>
          <CB>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={sevData} barSize={32}>
                <XAxis dataKey="name" tick={{fill:C.text3,fontSize:10}} axisLine={false} tickLine={false}/>
                <YAxis tick={{fill:C.text3,fontSize:10}} axisLine={false} tickLine={false}/>
                <Tooltip contentStyle={{background:C.bg3,border:`1px solid ${C.border2}`,borderRadius:6,fontSize:11}}/>
                <Bar dataKey="val" radius={[4,4,0,0]}>
                  {sevData.map((e,i)=><Cell key={i} fill={e.color}/>)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CB>
        </Card>

        {/* Scope progress chart */}
        <Card>
          <CHead title="Scope Coverage" dot={C.green}/>
          <CB>
            <ResponsiveContainer width="100%" height={180}>
              <PieChart>
                <Pie data={progressData} dataKey="val" cx="50%" cy="50%" innerRadius={45} outerRadius={75} paddingAngle={3}>
                  {progressData.map((e,i)=><Cell key={i} fill={e.color}/>)}
                </Pie>
                <Tooltip contentStyle={{background:C.bg3,border:`1px solid ${C.border2}`,borderRadius:6,fontSize:11}}/>
              </PieChart>
            </ResponsiveContainer>
            <div style={{display:'flex',justifyContent:'center',gap:14,marginTop:6}}>
              {progressData.map(p=>(
                <div key={p.name} style={{display:'flex',alignItems:'center',gap:5,fontSize:'10px',color:C.text3}}>
                  <span style={{width:8,height:8,borderRadius:'50%',background:p.color,display:'inline-block'}}/>
                  {p.name}: {p.val}
                </div>
              ))}
            </div>
          </CB>
        </Card>

        {/* Area breakdown */}
        <Card>
          <CHead title="Findings by Area" dot={C.accent}/>
          <CB>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={areaData} layout="vertical" barSize={18}>
                <XAxis type="number" tick={{fill:C.text3,fontSize:10}} axisLine={false} tickLine={false}/>
                <YAxis dataKey="name" type="category" tick={{fill:C.text3,fontSize:10}} axisLine={false} tickLine={false} width={35}/>
                <Tooltip contentStyle={{background:C.bg3,border:`1px solid ${C.border2}`,borderRadius:6,fontSize:11}}/>
                <Bar dataKey="val" radius={[0,4,4,0]}>
                  {areaData.map((e,i)=><Cell key={i} fill={e.color}/>)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CB>
        </Card>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'2fr 1fr',gap:14}}>
        {/* Critical findings fast view */}
        <Card>
          <CHead title="Active Findings — Priority Order" dot={C.red} right={<Btn small onClick={()=>nav('findings')}>View All →</Btn>}/>
          <Tbl cols={['ID','Finding','Sev','CVSS','Area','Status']}>
            {[...findings].sort((a,b)=>b.cvss-a.cvss).slice(0,7).map(f=>(
              <tr key={f.id} style={{cursor:'pointer'}} onClick={()=>nav('findings')}>
                <Td style={{fontFamily:C.mono,color:{critical:C.red,high:C.amber,medium:C.accent}[f.sev]||C.text3,fontWeight:600}}>{f.id}</Td>
                <Td style={{color:C.text,maxWidth:260}}>{f.title}</Td>
                <Td><Badge sev={f.sev}/></Td>
                <Td style={{fontFamily:C.mono,color:{critical:C.red,high:C.amber,medium:C.accent}[f.sev]||C.text3}}>{f.cvss}</Td>
                <Td><AreaBadge area={f.area}/></Td>
                <Td style={{fontSize:'9.5px',fontFamily:C.mono,color:f.status==='escalated'?C.red:C.text3}}>{f.status.toUpperCase()}</Td>
              </tr>
            ))}
          </Tbl>
        </Card>

        {/* Activity timeline */}
        <Card>
          <CHead title="Activity Timeline" dot={C.accent}/>
          <CB p={0}>
            {[...state.timeline].sort((a,b)=>new Date(b.ts)-new Date(a.ts)).slice(0,8).map((t,i)=>(
              <div key={i} style={{display:'flex',gap:10,padding:'9px 14px',borderBottom:`1px solid ${C.border}`,alignItems:'flex-start'}}>
                <span style={{fontSize:14,flexShrink:0,marginTop:1}}>{t.type==='escalation'?'⚡':t.type==='finding'?'🔍':t.type==='phase'?'▶':'📌'}</span>
                <div style={{flex:1}}>
                  <div style={{fontSize:'11px',color:t.sev==='critical'?C.red:t.sev==='high'?C.amber:C.text,lineHeight:1.3}}>{t.title}</div>
                  <div style={{fontSize:'9.5px',color:C.text3,marginTop:2}}>{new Date(t.ts).toLocaleString()}</div>
                </div>
              </div>
            ))}
          </CB>
        </Card>
      </div>

      {/* Scope progress bars */}
      <Card>
        <CHead title="Phase Progress" dot={C.purple}/>
        <CB>
          <Grid cols="repeat(4,1fr)" gap={12}>
            {[
              {l:'AWS Cloud (1–11)',pct:72,c:C.accent,v:'8/11',active:true},
              {l:'DNS & Domain (2–4)',pct:100,c:C.green,v:'3/3',active:true},
              {l:'Web App & API (12–26)',pct:0,c:C.purple,v:'0/15',active:false},
              {l:'Reporting (27)',pct:0,c:C.amber,v:'0/1',active:false},
            ].map(r=>(
              <div key={r.l}>
                <div style={{display:'flex',justifyContent:'space-between',fontSize:'10.5px',color:C.text2,marginBottom:5}}>
                  <span>{r.l}</span><span style={{fontFamily:C.mono,color:r.c}}>{r.v}</span>
                </div>
                <div style={{height:5,background:C.bg4,borderRadius:3,overflow:'hidden'}}>
                  <div style={{height:'100%',width:`${r.pct}%`,background:r.c,borderRadius:3,transition:'width 1.2s ease'}}/>
                </div>
                {r.active&&<div style={{fontSize:'9px',color:r.c,marginTop:3,fontFamily:C.mono}}>● ACTIVE</div>}
              </div>
            ))}
          </Grid>
        </CB>
      </Card>
    </div>
  );
}

// FINDINGS REGISTER — full elite version
function Findings({ store, showToast, nav }) {
  const { findings, addFinding, updateFinding, deleteFinding, escalateFinding } = store;
  const [sel, setSel] = useState(null);
  const [adding, setAdding] = useState(false);
  const [filter, setFilter] = useState('all');
  const [sortBy, setSortBy] = useState('cvss');
  const [search, setSearch] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [tab, setTab] = useState('detail');

  const [form, setForm] = useState({
    title:'',sev:'high',cvss:'',area:'aws',scopeItemId:'',
    evidence:'',impact:'',remedy:'',proofOfConcept:'',
    affectedAsset:'',cweId:'',cweTitle:'',owaspId:'',owaspTitle:'',
    remediationOwner:'',remediationDue:'',notes:''
  });

  const filtered = useMemo(()=>{
    let f = [...findings];
    if(filter!=='all') f=f.filter(x=>x.sev===filter||x.status===filter||x.area===filter);
    if(search) f=f.filter(x=>x.title.toLowerCase().includes(search.toLowerCase())||x.id.toLowerCase().includes(search.toLowerCase()));
    if(sortBy==='cvss') f.sort((a,b)=>b.cvss-a.cvss);
    else if(sortBy==='id') f.sort((a,b)=>a.id.localeCompare(b.id));
    else if(sortBy==='sev'){const w={'critical':0,'high':1,'medium':2,'low':3,'info':4};f.sort((a,b)=>w[a.sev]-w[b.sev]);}
    return f;
  },[findings,filter,search,sortBy]);

  const f = sel ? findings.find(x=>x.id===sel) : null;

  const TABS = ['detail','evidence','mitre','remediation'];

  return (
    <div>
      <PH title="Findings Register" sub={`${findings.length} findings · CVSS scored · Evidence validated · MITRE ATT&CK mapped`}
        right={<Btn onClick={()=>{setAdding(true);}} color={C.accent}>+ Add Finding</Btn>}/>

      {adding&&(
        <Modal title="Add New Finding" onClose={()=>setAdding(false)} width={680}>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
            <div style={{gridColumn:'1/-1'}}><Field label="Title" required><Inp value={form.title} onChange={v=>setForm(p=>({...p,title:v}))} placeholder="Describe the vulnerability concisely"/></Field></div>
            <Field label="Severity" required><Sel value={form.sev} onChange={v=>setForm(p=>({...p,sev:v}))} options={['critical','high','medium','low','info'].map(s=>({v:s,l:s.toUpperCase()}))}/></Field>
            <Field label="CVSS Score"><Inp value={form.cvss} onChange={v=>setForm(p=>({...p,cvss:v}))} placeholder="0.0 – 10.0" mono/></Field>
            <Field label="Area"><Sel value={form.area} onChange={v=>setForm(p=>({...p,area:v}))} options={['aws','dns','web','rep','gen'].map(a=>({v:a,l:a.toUpperCase()}))}/></Field>
            <Field label="Scope Item #"><Inp value={form.scopeItemId} onChange={v=>setForm(p=>({...p,scopeItemId:v}))} placeholder="1–27" mono/></Field>
            <div style={{gridColumn:'1/-1'}}><Field label="Affected Asset"><Inp value={form.affectedAsset} onChange={v=>setForm(p=>({...p,affectedAsset:v}))} placeholder="e.g. s3://bucket-name, iam:svc-account"/></Field></div>
            <Field label="CWE ID"><Inp value={form.cweId} onChange={v=>setForm(p=>({...p,cweId:v}))} placeholder="CWE-284" mono/></Field>
            <Field label="CWE Title"><Inp value={form.cweTitle} onChange={v=>setForm(p=>({...p,cweTitle:v}))} placeholder="Improper Access Control"/></Field>
            <Field label="OWASP ID"><Inp value={form.owaspId} onChange={v=>setForm(p=>({...p,owaspId:v}))} placeholder="A01:2021"/></Field>
            <Field label="OWASP Title"><Inp value={form.owaspTitle} onChange={v=>setForm(p=>({...p,owaspTitle:v}))} placeholder="Broken Access Control"/></Field>
            <div style={{gridColumn:'1/-1'}}><Field label="Evidence" required><Txt value={form.evidence} onChange={v=>setForm(p=>({...p,evidence:v}))} placeholder="Tool output, screenshots, HTTP request/response..." rows={2}/></Field></div>
            <div style={{gridColumn:'1/-1'}}><Field label="Proof of Concept"><Txt value={form.proofOfConcept} onChange={v=>setForm(p=>({...p,proofOfConcept:v}))} placeholder="Exact commands or steps to reproduce..." rows={2}/></Field></div>
            <div style={{gridColumn:'1/-1'}}><Field label="Business Impact" required><Txt value={form.impact} onChange={v=>setForm(p=>({...p,impact:v}))} placeholder="What can an attacker actually do? What is the business consequence?" rows={2}/></Field></div>
            <div style={{gridColumn:'1/-1'}}><Field label="Remediation" required><Txt value={form.remedy} onChange={v=>setForm(p=>({...p,remedy:v}))} placeholder="Step-by-step fix guidance..." rows={3}/></Field></div>
            <Field label="Remediation Owner"><Inp value={form.remediationOwner} onChange={v=>setForm(p=>({...p,remediationOwner:v}))} placeholder="e.g. DevOps Team"/></Field>
            <Field label="Due Date"><Inp value={form.remediationDue} onChange={v=>setForm(p=>({...p,remediationDue:v}))} placeholder="YYYY-MM-DD" mono/></Field>
          </div>
          <div style={{display:'flex',gap:8,justifyContent:'flex-end',marginTop:14}}>
            <Btn outline onClick={()=>setAdding(false)}>Cancel</Btn>
            <Btn color={C.accent} onClick={()=>{
              if(!form.title||!form.sev){showToast('Title and severity required','error');return;}
              addFinding(form);setAdding(false);
              setForm({title:'',sev:'high',cvss:'',area:'aws',scopeItemId:'',evidence:'',impact:'',remedy:'',proofOfConcept:'',affectedAsset:'',cweId:'',cweTitle:'',owaspId:'',owaspTitle:'',remediationOwner:'',remediationDue:'',notes:''});
              showToast('Finding added');
            }}>Add Finding</Btn>
          </div>
        </Modal>
      )}

      {/* Stats row */}
      <Grid cols="repeat(5,1fr)" gap={10} style={{marginBottom:14}}>
        <StatCard label="Critical" val={findings.filter(f=>f.sev==='critical').length} color={C.red}/>
        <StatCard label="High" val={findings.filter(f=>f.sev==='high').length} color={C.amber}/>
        <StatCard label="Medium" val={findings.filter(f=>f.sev==='medium').length} color={C.accent}/>
        <StatCard label="Escalated" val={findings.filter(f=>f.status==='escalated').length} color={C.red}/>
        <StatCard label="Avg CVSS" val={findings.length?( findings.reduce((a,f)=>a+(parseFloat(f.cvss)||0),0)/findings.length).toFixed(1):'—'} color={C.purple}/>
      </Grid>

      {/* Filters + search */}
      <div style={{display:'flex',gap:8,marginBottom:12,flexWrap:'wrap',alignItems:'center'}}>
        <Inp value={search} onChange={setSearch} placeholder="Search findings..." style={{width:200}}/>
        {['all','critical','high','medium','aws','dns','web','escalated','open'].map(f2=>(
          <button key={f2} onClick={()=>setFilter(f2)} style={{background:filter===f2?C.bg4:'transparent',border:`1px solid ${filter===f2?C.border3:C.border}`,borderRadius:5,padding:'4px 10px',color:filter===f2?C.text:C.text3,fontSize:'10px',cursor:'pointer',fontFamily:C.mono}}>
            {f2.toUpperCase()}
          </button>
        ))}
        <div style={{marginLeft:'auto',display:'flex',gap:6,alignItems:'center'}}>
          <span style={{fontSize:'10px',color:C.text3}}>Sort:</span>
          <Sel value={sortBy} onChange={setSortBy} options={[{v:'cvss',l:'CVSS Score'},{v:'sev',l:'Severity'},{v:'id',l:'ID'}]} style={{fontSize:10}}/>
        </div>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1.4fr',gap:14}}>
        {/* List */}
        <Card>
          <CHead title={`Findings (${filtered.length})`}/>
          <div style={{maxHeight:580,overflowY:'auto'}}>
            {filtered.map(f2=>(
              <div key={f2.id} onClick={()=>{setSel(f2.id===sel?null:f2.id);setEditNotes(f2.notes||'');setTab('detail');}}
                style={{display:'flex',alignItems:'flex-start',gap:10,padding:'10px 14px',borderBottom:`1px solid ${C.border}`,cursor:'pointer',background:sel===f2.id?`${SEV[f2.sev]?.bg||'rgba(0,0,0,.1)'}`:'transparent',borderLeft:sel===f2.id?`3px solid ${SEV[f2.sev]?.color||C.accent}`:'3px solid transparent',transition:'.1s'}}>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{display:'flex',gap:6,alignItems:'center',marginBottom:3,flexWrap:'wrap'}}>
                    <span style={{fontFamily:C.mono,fontSize:'9.5px',color:SEV[f2.sev]?.color||C.text3,fontWeight:700}}>{f2.id}</span>
                    <Badge sev={f2.sev}/>
                    <AreaBadge area={f2.area}/>
                    <span style={{fontFamily:C.mono,fontSize:'9.5px',color:SEV[f2.sev]?.color||C.text3}}>CVSS {f2.cvss}</span>
                  </div>
                  <div style={{fontSize:'11.5px',color:C.text,lineHeight:1.35,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{f2.title}</div>
                  <div style={{fontSize:'9.5px',color:C.text3,marginTop:2,display:'flex',gap:8}}>
                    <span style={{color:f2.status==='escalated'?C.red:C.text3}}>{f2.status.toUpperCase()}</span>
                    {f2.affectedAsset&&<span style={{fontFamily:C.mono}}>{f2.affectedAsset.slice(0,30)}</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Detail panel */}
        {f ? (
          <Card style={{borderLeft:`3px solid ${SEV[f.sev]?.color||C.accent}`}} glow={SEV[f.sev]?.glow}>
            <div style={{padding:'12px 16px',borderBottom:`1px solid ${C.border}`}}>
              <div style={{display:'flex',gap:8,marginBottom:6,flexWrap:'wrap'}}>
                <Badge sev={f.sev}/><AreaBadge area={f.area}/>
                <span style={{fontFamily:C.mono,fontSize:'9.5px',color:C.text3}}>{f.id}</span>
                <span style={{fontFamily:C.mono,fontSize:'9.5px',color:SEV[f.sev]?.color}}>{CVSS_VECTORS[f.id]||`CVSS:3.1 Score:${f.cvss}`}</span>
              </div>
              <div style={{fontSize:13,color:C.text,fontWeight:600,lineHeight:1.3,marginBottom:8}}>{f.title}</div>
              <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                {f.status!=='escalated'&&<Btn small danger onClick={()=>{escalateFinding(f.id);showToast('Finding escalated!');setSel(null);}}>⚡ Escalate</Btn>}
                <Btn small color={C.green} onClick={()=>{updateFinding(f.id,{remediationStatus:'resolved'});showToast('Marked resolved');}}>✓ Mark Resolved</Btn>
                <Btn small outline danger onClick={()=>{if(window.confirm('Delete?')){deleteFinding(f.id);setSel(null);showToast('Deleted','warn');}}}>Delete</Btn>
                <Btn small outline color={C.accent} onClick={()=>nav('ai')}>Ask AI →</Btn>
              </div>
            </div>

            {/* Tabs */}
            <div style={{display:'flex',borderBottom:`1px solid ${C.border}`,background:C.bg3}}>
              {TABS.map(t=>(
                <button key={t} onClick={()=>setTab(t)} style={{padding:'8px 16px',fontSize:'10.5px',fontFamily:C.mono,cursor:'pointer',background:'none',border:'none',color:tab===t?C.accent:C.text3,borderBottom:tab===t?`2px solid ${C.accent}`:'2px solid transparent',letterSpacing:'.5px',textTransform:'uppercase'}}>
                  {t}
                </button>
              ))}
            </div>

            <div style={{padding:14,maxHeight:400,overflowY:'auto'}}>
              {tab==='detail'&&(
                <div>
                  {[
                    {l:'Affected Asset', v:f.affectedAsset},
                    {l:'CWE', v:f.cweId?`${f.cweId} — ${f.cweTitle}`:''},
                    {l:'OWASP', v:f.owaspId?`${f.owaspId} — ${f.owaspTitle}`:''},
                    {l:'Scope Item', v:`#${f.scopeItemId}`},
                    {l:'Discovered', v:f.createdAt?new Date(f.createdAt).toLocaleString():''},
                    {l:'Status', v:f.status.toUpperCase()},
                    {l:'Remediation Owner', v:f.remediationOwner},
                    {l:'Remediation Due', v:f.remediationDue},
                  ].filter(r=>r.v).map(r=>(
                    <div key={r.l} style={{display:'flex',justifyContent:'space-between',padding:'4px 0',borderBottom:`1px solid ${C.border}`,fontSize:'10.5px'}}>
                      <span style={{color:C.text3}}>{r.l}</span>
                      <span style={{color:C.text2,fontFamily:C.mono,fontSize:'10px',textAlign:'right',maxWidth:200}}>{r.v}</span>
                    </div>
                  ))}
                  <div style={{marginTop:10}}>
                    <div style={{fontSize:'9px',color:C.text3,fontFamily:C.mono,marginBottom:5,letterSpacing:'.5px'}}>BUSINESS IMPACT</div>
                    <div style={{fontSize:'11.5px',color:C.text2,lineHeight:1.65,background:C.bg3,padding:10,borderRadius:6,borderLeft:`2px solid ${C.amber}`}}>{f.impact}</div>
                  </div>
                  <div style={{marginTop:10}}>
                    <div style={{fontSize:'9px',color:C.text3,fontFamily:C.mono,marginBottom:5,letterSpacing:'.5px'}}>NOTES (live edit)</div>
                    <Txt value={editNotes} onChange={v=>{setEditNotes(v);updateFinding(f.id,{notes:v});}} placeholder="Investigation notes..." rows={2}/>
                  </div>
                </div>
              )}
              {tab==='evidence'&&(
                <div>
                  <div style={{fontSize:'9px',color:C.text3,fontFamily:C.mono,marginBottom:5,letterSpacing:'.5px'}}>EVIDENCE</div>
                  <div style={{fontSize:'11.5px',color:C.text2,lineHeight:1.65,background:C.bg3,padding:10,borderRadius:6,borderLeft:`2px solid ${C.accent}`,marginBottom:10,whiteSpace:'pre-wrap'}}>{f.evidence||'No evidence recorded.'}</div>
                  {f.proofOfConcept&&(
                    <>
                      <div style={{fontSize:'9px',color:C.text3,fontFamily:C.mono,marginBottom:5,letterSpacing:'.5px'}}>PROOF OF CONCEPT</div>
                      <div style={{fontSize:'11.5px',color:C.green,lineHeight:1.65,background:C.bg3,padding:10,borderRadius:6,borderLeft:`2px solid ${C.green}`,fontFamily:C.mono,whiteSpace:'pre-wrap'}}>{f.proofOfConcept}</div>
                    </>
                  )}
                </div>
              )}
              {tab==='mitre'&&(
                <div>
                  <div style={{fontSize:'9px',color:C.text3,fontFamily:C.mono,marginBottom:8,letterSpacing:'.5px'}}>MITRE ATT&CK MAPPING</div>
                  {(MITRE_MAP[f.id]||['No mapping available — add manually']).map((t,i)=>(
                    <div key={i} style={{display:'flex',gap:10,padding:'8px 10px',background:C.bg3,borderRadius:6,marginBottom:6,border:`1px solid ${C.border}`}}>
                      <span style={{fontSize:16}}>🎯</span>
                      <div>
                        <div style={{fontSize:'11.5px',color:C.text,fontFamily:C.mono}}>{t.split(' - ')[0]}</div>
                        <div style={{fontSize:'10.5px',color:C.text3}}>{t.split(' - ')[1]}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {tab==='remediation'&&(
                <div>
                  <div style={{fontSize:'9px',color:C.text3,fontFamily:C.mono,marginBottom:5,letterSpacing:'.5px'}}>REMEDIATION STEPS</div>
                  <div style={{fontSize:'11.5px',color:C.text2,lineHeight:1.8,background:C.bg3,padding:10,borderRadius:6,borderLeft:`2px solid ${C.green}`,whiteSpace:'pre-wrap'}}>{f.remedy}</div>
                  <div style={{marginTop:10,display:'flex',gap:8}}>
                    <div style={{flex:1}}>
                      <div style={{fontSize:'9px',color:C.text3,fontFamily:C.mono,marginBottom:4}}>OWNER</div>
                      <Inp value={f.remediationOwner||''} onChange={v=>updateFinding(f.id,{remediationOwner:v})} placeholder="Assign owner"/>
                    </div>
                    <div>
                      <div style={{fontSize:'9px',color:C.text3,fontFamily:C.mono,marginBottom:4}}>DUE DATE</div>
                      <Inp value={f.remediationDue||''} onChange={v=>updateFinding(f.id,{remediationDue:v})} placeholder="YYYY-MM-DD" mono style={{width:130}}/>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </Card>
        ) : (
          <Card style={{display:'flex',alignItems:'center',justifyContent:'center',minHeight:300}}>
            <div style={{textAlign:'center',color:C.text3}}>
              <div style={{fontSize:32,marginBottom:8}}>◎</div>
              <div style={{fontSize:'12px'}}>Select a finding to view full detail</div>
              <div style={{fontSize:'10.5px',marginTop:4,color:C.text4}}>Evidence · MITRE ATT&CK · Remediation</div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}

// AI ASSISTANT — elite version
function AIView({ store, showToast }) {
  const { findings, eng, state, addChat, clearChat, setApiKey } = store;
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [proxyOk, setProxyOk] = useState(null);
  const [showKey, setShowKey] = useState(false);
  const [keyDraft, setKeyDraft] = useState('');
  const [mode, setMode] = useState('chat');
  const chatRef = useRef(null);

  useEffect(()=>{ if(chatRef.current) chatRef.current.scrollTop=chatRef.current.scrollHeight; },[state.chatHistory,loading]);
  useEffect(()=>{
    fetch('http://localhost:3001/health').then(r=>r.json()).then(()=>setProxyOk(true)).catch(()=>setProxyOk(false));
  },[]);

  const msgs = state.chatHistory.length>0 ? state.chatHistory : [{role:'ai',text:`SecureNet Elite AI online.\n\nI have full context on the ${eng?.client} engagement:\n→ ${state.scopeItems.length} scope items | ${findings.length} findings | ${findings.filter(f=>f.sev==='critical').length} criticals\n→ ${(eng?.targets||[]).filter(t=>t.value&&t.inScope).length} in-scope targets\n→ Phase ${eng?.currentPhase}/11 | Week ${eng?.currentWeek}/${eng?.totalWeeks}\n\nI can generate CVSS vectors, MITRE ATT&CK mappings, client-ready narratives, PoC analysis, compliance mappings (SOC2/PCI/ISO27001), escalation messages, attack chain analysis, and executive summaries.\n\nWhat do you need?`}];

  const send = useCallback(async(msg)=>{
    if(!msg.trim()||loading) return;
    if(!state.apiKey){setShowKey(true);return;}
    if(!proxyOk){showToast('Start the proxy server first: cd server && node proxy.js','error');return;}
    addChat({role:'user',text:msg});
    setInput('');
    setLoading(true);
    try{
      const res = await fetch('http://localhost:3001/api/chat',{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
          apiKey:state.apiKey,
          model:'claude-sonnet-4-20250514',max_tokens:1500,
          system:buildSystem(eng,findings,state.scopeItems,eng?.targets),
          messages:[...state.chatHistory.slice(-8).map(m=>({role:m.role==='ai'?'assistant':'user',content:m.text})),{role:'user',content:msg}]
        })
      });
      if(!res.ok){const e=await res.json().catch(()=>({}));throw new Error(e.error||`HTTP ${res.status}`);}
      const d=await res.json();
      addChat({role:'ai',text:d.content?.find(c=>c.type==='text')?.text||'No response.'});
    }catch(e){
      const isConn=e.message.includes('fetch')||e.message.includes('NetworkError')||e.message.includes('Failed');
      addChat({role:'ai',text:isConn?'⚠ Proxy not running.\n\nRun in a new terminal:\ncd securenet_elite/server\nnode proxy.js':'Error: '+e.message});
    }
    setLoading(false);
  },[loading,state.apiKey,state.chatHistory,proxyOk,addChat,eng,findings,state.scopeItems,showToast]);

  const PRESETS = [
    {label:'🔴 Escalation message for F-001',msg:'Write a professional critical escalation message for F-001 S3 public bucket finding to send to Sourabh Sen right now. Include exact risk, evidence summary, and immediate actions needed.'},
    {label:'📊 Full CVSS breakdown for all findings',msg:'Provide a detailed CVSS v3.1 breakdown for every finding, including the full vector string and score justification for each metric.'},
    {label:'🎯 MITRE ATT&CK full mapping',msg:'Map all current findings to MITRE ATT&CK framework. Include technique ID, tactic, and how this specific engagement finding demonstrates the technique.'},
    {label:'📋 Executive summary paragraph',msg:'Write a one-paragraph executive summary of the current security posture for the SPACES board. Plain English, business impact focused, no jargon.'},
    {label:'🔧 Remediation priority order',msg:'Give me a strict remediation priority order for all 7 findings with justification, estimated fix time, and recommended fix owner for each.'},
    {label:'⚖️ Compliance impact analysis',msg:'Analyze which compliance frameworks are impacted by the current findings: SOC 2 Type II, GDPR, CCPA, PCI DSS. Which controls are failing?'},
    {label:'🏗️ Attack chain analysis',msg:'Build a realistic attack chain showing how a real threat actor could chain the current findings (F-001, F-002, F-003) to achieve maximum damage.'},
    {label:'📄 Technical finding narrative for F-002',msg:'Write the full technical narrative for F-002 IAM wildcard policy, as it would appear in the final penetration test report. Include vulnerability description, risk rating justification, technical detail, and remediation.'},
    {label:'🌐 DNS attack scenario',msg:'Explain in detail how a threat actor could exploit F-005 DNSSEC and F-006 DMARC together for a combined phishing + credential harvesting campaign against SPACES customers.'},
    {label:'💬 Client meeting talking points',msg:'Give me 5 talking points I can use when presenting these findings to Sourabh and Jacob on Tuesday. Each should be clear, non-technical, and business-risk focused.'},
  ];

  return (
    <div>
      <PH title="AI Security Assistant" sub="Claude Sonnet · Full engagement context · MITRE ATT&CK · CVSS · Compliance aware"/>

      {/* Status bar */}
      <div style={{display:'flex',gap:10,marginBottom:14,alignItems:'center',flexWrap:'wrap'}}>
        <div style={{display:'flex',alignItems:'center',gap:7,padding:'6px 12px',background:proxyOk?'rgba(16,185,129,.08)':'rgba(239,68,68,.08)',border:`1px solid ${proxyOk?'rgba(16,185,129,.3)':'rgba(239,68,68,.3)'}`,borderRadius:6,fontSize:'10.5px',color:proxyOk?C.green:C.red}}>
          <Pulse color={proxyOk?C.green:C.red} size={6}/>
          {proxyOk?'Proxy online':'Proxy offline — run: cd server && node proxy.js'}
        </div>
        <div style={{display:'flex',alignItems:'center',gap:7,padding:'6px 12px',background:state.apiKey?'rgba(16,185,129,.08)':'rgba(245,158,11,.08)',border:`1px solid ${state.apiKey?'rgba(16,185,129,.3)':'rgba(245,158,11,.3)'}`,borderRadius:6,fontSize:'10.5px',color:state.apiKey?C.green:C.amber}}>
          {state.apiKey?`✓ API Key: ${state.apiKey.slice(0,14)}...`:'⚠ No API key set'}
        </div>
        <Btn small outline onClick={()=>setShowKey(true)}>Set API Key</Btn>
        <Btn small outline danger onClick={clearChat}>Clear Chat</Btn>
        <div style={{marginLeft:'auto',display:'flex',gap:6}}>
          {['chat','presets'].map(m2=>(
            <button key={m2} onClick={()=>setMode(m2)} style={{padding:'4px 12px',fontSize:'10px',fontFamily:C.mono,cursor:'pointer',background:mode===m2?C.bg4:'transparent',border:`1px solid ${mode===m2?C.border3:C.border}`,borderRadius:5,color:mode===m2?C.text:C.text3}}>
              {m2.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {showKey&&(
        <Modal title="Set Anthropic API Key" onClose={()=>setShowKey(false)}>
          <Field label="API Key (sk-ant-...)">
            <Inp value={keyDraft} onChange={setKeyDraft} placeholder="sk-ant-api03-..." mono/>
          </Field>
          <div style={{fontSize:'10.5px',color:C.text3,marginBottom:12}}>Stored in localStorage only. Get your key at console.anthropic.com → API Keys.</div>
          <div style={{display:'flex',gap:8,justifyContent:'flex-end'}}>
            <Btn outline onClick={()=>setShowKey(false)}>Cancel</Btn>
            <Btn color={C.accent} onClick={()=>{setApiKey(keyDraft);setShowKey(false);showToast('API key saved');}}>Save Key</Btn>
          </div>
        </Modal>
      )}

      {mode==='chat'&&(
        <Card>
          <div style={{display:'flex',alignItems:'center',gap:8,padding:'10px 16px',borderBottom:`1px solid ${C.border}`,background:C.bg3}}>
            <Pulse color={C.purple} size={6}/>
            <span style={{fontSize:'12px',color:C.text,fontWeight:500}}>SecureNet Elite AI</span>
            <span style={{fontSize:'9px',fontFamily:C.mono,background:'rgba(139,92,246,.15)',color:C.purple,border:`1px solid rgba(139,92,246,.3)`,borderRadius:3,padding:'2px 7px'}}>CLAUDE SONNET · ELITE MODE</span>
            <span style={{marginLeft:'auto',fontSize:'9.5px',color:C.text3}}>{findings.length} findings · {state.scopeItems.length} scope items · {(eng?.targets||[]).filter(t=>t.value&&t.inScope).length} targets in context</span>
          </div>
          <div ref={chatRef} style={{padding:14,minHeight:240,maxHeight:400,overflowY:'auto',display:'flex',flexDirection:'column',gap:10}}>
            {msgs.map((msg,i)=>(
              <div key={i} style={{maxWidth:'88%',alignSelf:msg.role==='ai'?'flex-start':'flex-end'}}>
                <div style={{fontSize:'8.5px',fontFamily:C.mono,color:C.text3,marginBottom:2}}>{msg.role==='ai'?'SECURENET AI':'CHRISTIAN'}</div>
                <div style={{padding:'10px 14px',borderRadius:8,fontSize:'11.5px',lineHeight:1.7,background:msg.role==='ai'?C.bg3:'rgba(0,200,240,.07)',border:msg.role==='ai'?`1px solid ${C.border}`:'1px solid rgba(0,200,240,.2)',borderLeft:msg.role==='ai'?`2px solid ${C.purple}`:undefined,color:msg.role==='ai'?C.text2:C.text,whiteSpace:'pre-wrap'}}>
                  {msg.text}
                </div>
              </div>
            ))}
            {loading&&(
              <div style={{alignSelf:'flex-start'}}>
                <div style={{fontSize:'8.5px',fontFamily:C.mono,color:C.text3,marginBottom:2}}>SECURENET AI</div>
                <div style={{padding:'10px 14px',borderRadius:8,background:C.bg3,border:`1px solid ${C.border}`,borderLeft:`2px solid ${C.purple}`,color:C.text3,fontFamily:C.mono,fontSize:'11.5px'}}>
                  ■ ANALYZING...
                </div>
              </div>
            )}
          </div>
          <div style={{display:'flex',gap:8,padding:'10px 14px',borderTop:`1px solid ${C.border}`,background:C.bg3}}>
            <Inp value={input} onChange={setInput} placeholder="Ask anything — findings, CVSS, MITRE, client comms, compliance, attack chains..." onKey={e=>e.key==='Enter'&&!e.shiftKey&&send(input)} style={{flex:1}}/>
            <Btn color={C.accent} onClick={()=>send(input)} disabled={loading}>SEND ↗</Btn>
          </div>
        </Card>
      )}

      {mode==='presets'&&(
        <div>
          <div style={{fontSize:'11.5px',color:C.text2,marginBottom:12}}>Pre-built prompts tuned for the SPACES engagement. Click any to send immediately.</div>
          <Grid cols="repeat(2,1fr)" gap={8}>
            {PRESETS.map((p,i)=>(
              <button key={i} onClick={()=>{setMode('chat');setTimeout(()=>send(p.msg),100);}} style={{background:C.bg2,border:`1px solid ${C.border}`,borderRadius:8,padding:'12px 14px',textAlign:'left',cursor:'pointer',color:C.text2,fontSize:'11.5px',lineHeight:1.45,transition:'.12s',display:'flex',alignItems:'flex-start',gap:8}}>
                <span style={{flexShrink:0,fontSize:14}}>{p.label.split(' ')[0]}</span>
                <span>{p.label.slice(p.label.indexOf(' ')+1)}</span>
              </button>
            ))}
          </Grid>
        </div>
      )}
    </div>
  );
}

// RECON & TARGETS
function ReconView({ store, showToast }) {
  const { eng, updateEngagement } = store;
  const targets = eng?.targets || [];
  const [form, setForm] = useState({type:'domain',value:'',notes:'',inScope:true});
  const TYPE_C = {domain:C.accent,subdomain:C.amber,ip:C.purple,url:C.green,aws:'#FF9900',cidr:C.text2};

  const add = () => {
    if(!form.value.trim()){showToast('Enter a target value','error');return;}
    updateEngagement({targets:[...targets,{...form,id:Date.now()}]});
    setForm({type:'domain',value:'',notes:'',inScope:true});
    showToast('Target added');
  };
  const remove = id => { updateEngagement({targets:targets.filter(t=>t.id!==id)}); showToast('Target removed','warn'); };
  const toggle = id => { updateEngagement({targets:targets.map(t=>t.id===id?{...t,inScope:!t.inScope}:t)}); };

  const byType = ['domain','subdomain','url','ip','cidr','aws'].reduce((a,t)=>({...a,[t]:targets.filter(x=>x.type===t&&x.value)}),{});

  return (
    <div>
      <PH title="Recon & Target Scope" sub="All in-scope and out-of-scope targets · Toggle scope status · Feeds directly into AI context"/>
      <div style={{display:'grid',gridTemplateColumns:'repeat(6,1fr)',gap:8,marginBottom:14}}>
        {Object.entries(byType).map(([t,items])=>(
          <div key={t} style={{background:C.bg2,border:`1px solid ${C.border}`,borderRadius:8,padding:'10px 12px',textAlign:'center'}}>
            <div style={{fontSize:'9px',fontFamily:C.mono,color:TYPE_C[t]||C.text3,marginBottom:4}}>{t.toUpperCase()}</div>
            <div style={{fontSize:22,fontWeight:700,fontFamily:C.mono,color:TYPE_C[t]||C.text3}}>{items.length}</div>
          </div>
        ))}
      </div>
      <div style={{display:'grid',gridTemplateColumns:'320px 1fr',gap:14}}>
        <div>
          <Card>
            <CHead title="Add Target" dot={C.accent}/>
            <CB>
              <Field label="Type"><Sel value={form.type} onChange={v=>setForm(p=>({...p,type:v}))} options={[{v:'domain',l:'Domain'},{v:'subdomain',l:'Subdomain'},{v:'ip',l:'IP Address'},{v:'cidr',l:'CIDR Range'},{v:'url',l:'URL / Endpoint'},{v:'aws',l:'AWS Region'}]}/></Field>
              <Field label="Value" required><Inp value={form.value} onChange={v=>setForm(p=>({...p,value:v}))} placeholder={{domain:'spacesusa.com',subdomain:'api.spacesusa.com',ip:'203.0.113.5',cidr:'10.0.0.0/24',url:'https://app.spacesusa.com',aws:'us-east-1'}[form.type]||'Enter value'} mono onKey={e=>e.key==='Enter'&&add()}/></Field>
              <Field label="Notes"><Inp value={form.notes} onChange={v=>setForm(p=>({...p,notes:v}))} placeholder="Context or scope notes" onKey={e=>e.key==='Enter'&&add()}/></Field>
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:12}}>
                <input type="checkbox" checked={form.inScope} onChange={e=>setForm(p=>({...p,inScope:e.target.checked}))} id="inscope"/>
                <label htmlFor="inscope" style={{fontSize:'11.5px',color:C.text2,cursor:'pointer'}}>In Scope</label>
              </div>
              <Btn full color={C.accent} onClick={add}>+ Add Target</Btn>
            </CB>
          </Card>
        </div>

        <Card>
          <CHead title={`All Targets (${targets.filter(t=>t.value).length})`} dot={C.accent}/>
          <div style={{maxHeight:500,overflowY:'auto'}}>
            {targets.filter(t=>t.value).length===0&&<div style={{padding:40,textAlign:'center',color:C.text3,fontSize:'12px'}}>No targets yet. Add domains, IPs, and AWS regions.</div>}
            {['domain','subdomain','url','ip','cidr','aws'].map(type=>{
              const group=targets.filter(t=>t.type===type&&t.value);
              if(!group.length) return null;
              return(
                <div key={type}>
                  <div style={{padding:'6px 16px',background:C.bg3,fontSize:'9.5px',fontFamily:C.mono,color:TYPE_C[type]||C.text3,letterSpacing:'1px',borderBottom:`1px solid ${C.border}`,borderTop:`1px solid ${C.border}`}}>{type.toUpperCase()} ({group.length})</div>
                  {group.map((t,i)=>(
                    <div key={t.id||i} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 16px',borderBottom:`1px solid ${C.border}`,opacity:t.inScope?1:.5}}>
                      <div style={{flex:1}}>
                        <div style={{fontSize:'12px',color:C.text,fontFamily:C.mono,fontWeight:500}}>{t.value}</div>
                        {t.notes&&<div style={{fontSize:'10.5px',color:C.text3,marginTop:2}}>{t.notes}</div>}
                      </div>
                      <button onClick={()=>toggle(t.id||i)} style={{background:t.inScope?'rgba(16,185,129,.1)':'rgba(100,116,139,.1)',border:`1px solid ${t.inScope?'rgba(16,185,129,.3)':C.border}`,borderRadius:4,padding:'3px 8px',color:t.inScope?C.green:C.text3,fontSize:'9.5px',cursor:'pointer',fontFamily:C.mono}}>
                        {t.inScope?'IN SCOPE':'OUT'}
                      </button>
                      <button onClick={()=>remove(t.id||i)} style={{background:'none',border:`1px solid ${C.border}`,borderRadius:4,padding:'3px 8px',color:C.text3,cursor:'pointer',fontSize:12}}>✕</button>
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </div>
  );
}

// REPORTS VIEW
function ReportsView({ store, showToast }) {
  const { findings, eng, state } = store;
  const [generating, setGenerating] = useState(null);

  const generate = async(type) => {
    setGenerating(type);
    showToast(`Generating ${type} report...`,'info');
    try {
      await downloadEliteReports(eng, findings, state.scopeItems, type);
      showToast(`${type} report downloaded`);
    } catch(e) {
      showToast('PDF error: '+e.message,'error');
    }
    setGenerating(null);
  };

  const crit=findings.filter(f=>f.sev==='critical').length;
  const high=findings.filter(f=>f.sev==='high').length;

  return (
    <div>
      <PH title="Reports & Deliverables" sub="One-click professional PDF generation from live finding data"/>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14,marginBottom:14}}>
        {[
          {id:'executive',title:'Executive Summary Report',icon:'📋',desc:'Board-ready PDF. Overall posture, finding counts, top risks with business impact, strategic recommendations. No technical jargon.',color:C.purple},
          {id:'technical',title:'Technical Findings Report',icon:'🔬',desc:'Full technical PDF. Every finding with CVSS vector, MITRE mapping, evidence, PoC, reproduction steps, and remediation guidance.',color:C.accent},
          {id:'remediation',title:'Remediation Roadmap',icon:'🗺️',desc:'Prioritized fix guide grouped into 3 tiers. Includes owner, due date, estimated effort, and compliance impact per finding.',color:C.green},
          {id:'compliance',title:'Compliance Impact Report',icon:'⚖️',desc:'Maps each finding to SOC 2, PCI DSS, GDPR, CCPA, and ISO 27001 controls. Identifies failing controls and remediation path.',color:C.amber},
        ].map(r=>(
          <Card key={r.id} style={{borderTop:`2px solid ${r.color}`}}>
            <CB>
              <div style={{display:'flex',alignItems:'flex-start',gap:12,marginBottom:12}}>
                <span style={{fontSize:24}}>{r.icon}</span>
                <div>
                  <div style={{fontSize:'13px',color:C.text,fontWeight:600,marginBottom:4}}>{r.title}</div>
                  <div style={{fontSize:'11px',color:C.text3,lineHeight:1.6}}>{r.desc}</div>
                </div>
              </div>
              <Btn full color={r.color} onClick={()=>generate(r.id)} disabled={generating===r.id}>
                {generating===r.id?'Generating...':'⬇ Download PDF'}
              </Btn>
            </CB>
          </Card>
        ))}
      </div>

      <Card>
        <CHead title="Report Data Preview" dot={C.accent}/>
        <CB>
          <Grid cols="repeat(4,1fr)" gap={10} style={{marginBottom:14}}>
            <StatCard label="Total Findings" val={findings.length} color={C.text2}/>
            <StatCard label="Critical + High" val={crit+high} color={C.red}/>
            <StatCard label="Avg CVSS" val={findings.length?(findings.reduce((a,f)=>a+(parseFloat(f.cvss)||0),0)/findings.length).toFixed(1):'—'} color={C.amber}/>
            <StatCard label="Items Tested" val={state.scopeItems.filter(s=>s.status!=='queued').length+'/27'} color={C.green}/>
          </Grid>
          <div style={{fontSize:'11px',color:C.text3,lineHeight:1.7}}>
            Reports are generated from your live finding data. Any findings you add, edit, or escalate will appear in the next report you generate.
            The Executive Summary and Technical Report cover all {findings.length} current findings. Remediation Roadmap groups them into priority tiers.
          </div>
        </CB>
      </Card>

      {/* Deliverables checklist */}
      <Card>
        <CHead title="11 Deliverables — Status" dot={C.green}/>
        <CB p={0}>
          {[
            {n:'01',icon:'📋',title:'Executive Summary Report',ready:true},
            {n:'02',icon:'🔬',title:'Technical Findings Report',ready:true},
            {n:'03',icon:'⚠️',title:'Risk Register',ready:true},
            {n:'04',icon:'📸',title:'Evidence Package',ready:false,note:'Manual: collect screenshots from each finding'},
            {n:'05',icon:'🎯',title:'CVSS v3.1 Scoring Sheet',ready:true},
            {n:'06',icon:'💼',title:'Business Impact Report',ready:true},
            {n:'07',icon:'🗺️',title:'Remediation Roadmap',ready:true},
            {n:'08',icon:'📊',title:'OWASP Top 10 Coverage Matrix',ready:false,note:'Phase 5 not started yet'},
            {n:'09',icon:'📋',title:'OWASP WSTG v4.2 Matrix',ready:false,note:'Phase 5 not started yet'},
            {n:'10',icon:'☁️',title:'AWS CIS Benchmark Summary',ready:true},
            {n:'11',icon:'🎤',title:'Debrief Presentation Deck',ready:false,note:'Generate after all phases complete'},
          ].map((d,i)=>(
            <div key={i} style={{display:'flex',alignItems:'center',gap:12,padding:'9px 16px',borderBottom:`1px solid ${C.border}`}}>
              <span style={{fontSize:16}}>{d.icon}</span>
              <div style={{flex:1}}>
                <div style={{fontSize:'11.5px',color:C.text}}>{d.n}. {d.title}</div>
                {d.note&&<div style={{fontSize:'10px',color:C.text3,marginTop:1}}>{d.note}</div>}
              </div>
              <span style={{fontSize:'9.5px',fontFamily:C.mono,color:d.ready?C.green:C.text3,background:d.ready?'rgba(16,185,129,.1)':'rgba(100,116,139,.1)',border:`1px solid ${d.ready?'rgba(16,185,129,.3)':C.border}`,borderRadius:4,padding:'2px 8px'}}>
                {d.ready?'READY':'PENDING'}
              </span>
            </div>
          ))}
        </CB>
      </Card>
    </div>
  );
}

// SETTINGS
function SettingsView({ store, showToast }) {
  const { eng, state, updateEngagement, setApiKey, reset, exportJSON, importJSON } = store;
  const [keyDraft, setKeyDraft] = useState(state.apiKey||'');
  const [form, setForm] = useState(eng||{});
  const [proxyOk, setProxyOk] = useState(null);

  useEffect(()=>{
    fetch('http://localhost:3001/health').then(r=>r.json()).then(()=>setProxyOk(true)).catch(()=>setProxyOk(false));
  },[]);

  return (
    <div>
      <PH title="Settings" sub="Proxy · API key · Engagement details · Data management"/>

      {/* Proxy status */}
      <Card style={{borderTop:`2px solid ${proxyOk?C.green:C.red}`,marginBottom:14}}>
        <CHead title="Proxy Server" dot={proxyOk?C.green:C.red} sub="Required for AI assistant" right={<Btn small outline onClick={()=>{setProxyOk(null);fetch('http://localhost:3001/health').then(r=>r.json()).then(()=>setProxyOk(true)).catch(()=>setProxyOk(false));}}>Recheck</Btn>}/>
        <CB>
          {proxyOk?
            <div style={{background:'rgba(16,185,129,.07)',border:'1px solid rgba(16,185,129,.25)',borderRadius:7,padding:'10px 14px',display:'flex',alignItems:'center',gap:10}}>
              <Pulse color={C.green}/><span style={{color:C.green,fontSize:'12px',fontWeight:500}}>Proxy running on localhost:3001 — AI is ready</span>
            </div>:
            <div style={{background:'rgba(239,68,68,.07)',border:'1px solid rgba(239,68,68,.3)',borderRadius:7,padding:'12px 14px'}}>
              <div style={{color:C.red,fontSize:'12px',fontWeight:600,marginBottom:8}}>✗ Proxy not running</div>
              <div style={{color:C.text2,fontSize:'11.5px',lineHeight:1.7,marginBottom:8}}>Open a new terminal and run:</div>
              <code style={{display:'block',background:C.bg4,padding:'8px 12px',borderRadius:5,fontSize:'11.5px',color:C.accent,fontFamily:C.mono,marginBottom:6}}>cd securenet_elite/server && node proxy.js</code>
              <div style={{color:C.text3,fontSize:'10px'}}>Keep that terminal open. Proxy runs on port 3001.</div>
            </div>
          }
        </CB>
      </Card>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
        <div>
          <Card>
            <CHead title="API Configuration" dot={C.purple}/>
            <CB>
              <Field label="Anthropic API Key">
                <Inp value={keyDraft} onChange={setKeyDraft} placeholder="sk-ant-api03-..." mono type="password"/>
              </Field>
              <Btn full color={C.purple} onClick={()=>{setApiKey(keyDraft);showToast('API key saved');}}>Save API Key</Btn>
              {state.apiKey&&<div style={{fontSize:'10.5px',color:C.green,marginTop:8,display:'flex',gap:6,alignItems:'center'}}><Pulse color={C.green} size={5}/>Key configured: {state.apiKey.slice(0,16)}...</div>}
              <div style={{fontSize:'10.5px',color:C.text3,marginTop:8}}>Get your key at <span style={{color:C.accent}}>console.anthropic.com</span> → API Keys</div>
            </CB>
          </Card>
          <Card>
            <CHead title="Data Management" dot={C.red}/>
            <CB>
              <div style={{display:'flex',flexDirection:'column',gap:8}}>
                <Btn full outline onClick={()=>{exportJSON();showToast('Data exported');}}>📤 Export All Data (JSON)</Btn>
                <label style={{display:'block',background:C.bg3,border:`1px solid ${C.border2}`,borderRadius:5,padding:'6px 14px',color:C.text2,fontSize:11,cursor:'pointer',textAlign:'center',fontFamily:C.mono}}>
                  📥 Import Backup
                  <input type="file" accept=".json" style={{display:'none'}} onChange={e=>{const f=e.target.files[0];if(f)importJSON(f).then(()=>showToast('Imported')).catch(()=>showToast('Invalid file','error'));}}/>
                </label>
                <Btn full danger onClick={()=>{if(window.confirm('Reset ALL data?')){reset();showToast('Reset','warn');}}}>🗑 Reset All Data</Btn>
              </div>
            </CB>
          </Card>
        </div>

        <Card>
          <CHead title="Engagement Details" dot={C.green}/>
          <CB>
            {[
              {l:'Client Name',k:'client'},{l:'Address',k:'address'},{l:'Consultant',k:'consultant'},
              {l:'Email',k:'email'},{l:'Phone',k:'phone'},{l:'Investment',k:'investment'},
              {l:'Start Date',k:'startDate'},{l:'End Date',k:'endDate'},
            ].map(f=>(
              <Field key={f.k} label={f.l}><Inp value={form[f.k]||''} onChange={v=>setForm(p=>({...p,[f.k]:v}))}/></Field>
            ))}
            <Btn full color={C.green} onClick={()=>{updateEngagement(form);showToast('Saved');}}>Save Changes</Btn>
          </CB>
        </Card>
      </div>
    </div>
  );
}

// SCOPE TRACKER
function ScopeView({ store }) {
  const { state, updateScope } = store;
  const [filter, setFilter] = useState('all');
  const [editing, setEditing] = useState(null);
  const [editForm, setEditForm] = useState({});

  const items = filter==='all'?state.scopeItems:state.scopeItems.filter(s=>s.status===filter||s.area===filter);
  const counts = {all:27,complete:state.scopeItems.filter(s=>s.status==='complete').length,wip:state.scopeItems.filter(s=>s.status==='wip').length,finding:state.scopeItems.filter(s=>s.status==='finding').length,queued:state.scopeItems.filter(s=>s.status==='queued').length};

  return (
    <div>
      <PH title="Scope Tracker — All 27 Items" sub="Click any item to edit notes, status, and assignee"/>
      {editing&&(
        <Modal title={`Edit Item ${editing.id}: ${editing.name}`} onClose={()=>setEditing(null)}>
          <Field label="Status"><Sel value={editForm.status} onChange={v=>setEditForm(p=>({...p,status:v}))} options={[{v:'queued',l:'Queued'},{v:'wip',l:'In Progress'},{v:'complete',l:'Complete'},{v:'finding',l:'Finding Identified'}]}/></Field>
          <Field label="Notes"><Txt value={editForm.notes||''} onChange={v=>setEditForm(p=>({...p,notes:v}))} rows={3} placeholder="Testing notes, findings, evidence location..."/></Field>
          <Field label="Assignee"><Inp value={editForm.assignee||''} onChange={v=>setEditForm(p=>({...p,assignee:v}))}/></Field>
          <div style={{display:'flex',gap:8,justifyContent:'flex-end',marginTop:12}}>
            <Btn outline onClick={()=>setEditing(null)}>Cancel</Btn>
            <Btn color={C.accent} onClick={()=>{updateScope(editing.id,editForm);setEditing(null);}}>Save</Btn>
          </div>
        </Modal>
      )}

      <div style={{display:'flex',gap:7,marginBottom:12,flexWrap:'wrap'}}>
        {['all','complete','wip','finding','queued','aws','dns','web'].map(f=>(
          <button key={f} onClick={()=>setFilter(f)} style={{background:filter===f?C.bg4:'transparent',border:`1px solid ${filter===f?C.border3:C.border}`,borderRadius:5,padding:'4px 10px',color:filter===f?C.text:C.text3,fontSize:'10px',cursor:'pointer',fontFamily:C.mono}}>
            {f.toUpperCase()} {f==='all'?`(${counts.all})`:f in counts?`(${counts[f]})`:f in AREA_C?`(${state.scopeItems.filter(s=>s.area===f).length})`:''} 
          </button>
        ))}
      </div>

      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8}}>
        {items.map(item=>{
          const bc={complete:'rgba(16,185,129,.3)',wip:'rgba(0,200,240,.3)',finding:'rgba(239,68,68,.4)',queued:C.border}[item.status];
          const bg={complete:'rgba(16,185,129,.04)',wip:'rgba(0,200,240,.04)',finding:'rgba(239,68,68,.06)',queued:'transparent'}[item.status];
          return(
            <div key={item.id} onClick={()=>{setEditing(item);setEditForm({status:item.status,notes:item.notes||'',assignee:item.assignee||'Christian'});}}
              style={{background:C.bg2,border:`1px solid ${bc}`,borderRadius:8,padding:'10px 12px',cursor:'pointer',backgroundColor:bg,transition:'.12s'}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:5}}>
                <div style={{display:'flex',gap:6,alignItems:'center'}}>
                  <span style={{fontSize:'8.5px',fontFamily:C.mono,color:C.text3}}>#{String(item.id).padStart(2,'0')}</span>
                  <AreaBadge area={item.area}/>
                </div>
                <div style={{width:7,height:7,borderRadius:'50%',background:STATUS_C[item.status]||C.text3}}/>
              </div>
              <div style={{fontSize:'11px',color:C.text,fontWeight:500,lineHeight:1.35,marginBottom:5}}>{item.name}</div>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <Sel value={item.status} onChange={v=>{updateScope(item.id,{status:v});}} options={[{v:'queued',l:'Queued'},{v:'wip',l:'In Progress'},{v:'complete',l:'Complete'},{v:'finding',l:'Finding'}]} style={{fontSize:'9.5px'}} />
                {item.lastUpdated&&<span style={{fontSize:'9px',color:C.text4,fontFamily:C.mono}}>{item.lastUpdated}</span>}
              </div>
              {item.notes&&<div style={{fontSize:'9.5px',color:C.text3,marginTop:5,borderTop:`1px solid ${C.border}`,paddingTop:4,fontStyle:'italic'}}>{item.notes.slice(0,70)}{item.notes.length>70?'…':''}</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// NOTES
function NotesView({ store, showToast }) {
  const { state, addNote, deleteNote, findings } = store;
  const [text, setText] = useState('');
  const [tag, setTag] = useState('general');
  const [ref, setRef] = useState('');
  const [filterTag, setFilterTag] = useState('all');
  const TAGS = ['general','aws','dns','web','critical','client','follow-up','evidence'];
  const TC = {general:C.text3,aws:'#FF9900',dns:C.accent,web:C.purple,critical:C.red,client:C.green,'follow-up':C.amber,evidence:C.pink};
  const filtered = filterTag==='all'?state.notes:state.notes.filter(n=>n.tag===filterTag);

  return (
    <div>
      <PH title="Investigation Notes" sub={`${state.notes.length} notes · Persistent · Tagged and linked to findings`}/>
      <div style={{display:'grid',gridTemplateColumns:'340px 1fr',gap:14}}>
        <Card>
          <CHead title="Add Note"/>
          <CB>
            <Field label="Note"><Txt value={text} onChange={setText} placeholder="Testing observation, evidence log, client communication, follow-up..." rows={4}/></Field>
            <Field label="Tag"><Sel value={tag} onChange={setTag} options={TAGS.map(t=>({v:t,l:t.toUpperCase()}))}/></Field>
            <Field label="Link to Finding (optional)"><Sel value={ref} onChange={setRef} options={[{v:'',l:'— None —'},...findings.map(f=>({v:f.id,l:`${f.id}: ${f.title.slice(0,35)}...`}))]}/></Field>
            <Btn full color={C.accent} onClick={()=>{if(text.trim()){addNote(text,tag,ref);setText('');setRef('');showToast('Note saved');}}}>Save Note</Btn>
          </CB>
        </Card>

        <div>
          <div style={{display:'flex',gap:6,marginBottom:10,flexWrap:'wrap'}}>
            <button onClick={()=>setFilterTag('all')} style={{background:filterTag==='all'?C.bg4:'transparent',border:`1px solid ${filterTag==='all'?C.border3:C.border}`,borderRadius:5,padding:'4px 10px',color:filterTag==='all'?C.text:C.text3,fontSize:'10px',cursor:'pointer',fontFamily:C.mono}}>ALL ({state.notes.length})</button>
            {TAGS.map(t=>{const n=state.notes.filter(x=>x.tag===t).length;return n>0&&<button key={t} onClick={()=>setFilterTag(t)} style={{background:filterTag===t?C.bg4:'transparent',border:`1px solid ${filterTag===t?(TC[t]||C.border3):C.border}`,borderRadius:5,padding:'4px 10px',color:TC[t]||C.text3,fontSize:'10px',cursor:'pointer',fontFamily:C.mono}}>{t.toUpperCase()} ({n})</button>;})}
          </div>
          {filtered.length===0&&<div style={{textAlign:'center',color:C.text3,fontSize:'12px',padding:40}}>No notes yet. Add your first above.</div>}
          {filtered.map(n=>(
            <div key={n.id} style={{background:C.bg2,border:`1px solid ${C.border}`,borderRadius:8,padding:'10px 14px',marginBottom:8}}>
              <div style={{display:'flex',gap:8,alignItems:'center',marginBottom:7}}>
                <span style={{fontSize:'9px',fontFamily:C.mono,color:TC[n.tag]||C.text3,background:`${TC[n.tag]||C.text3}18`,border:`1px solid ${TC[n.tag]||C.text3}35`,borderRadius:3,padding:'1px 7px'}}>{n.tag.toUpperCase()}</span>
                {n.findingRef&&<span style={{fontSize:'9.5px',fontFamily:C.mono,color:C.amber}}>→ {n.findingRef}</span>}
                <span style={{fontSize:'9.5px',color:C.text3,marginLeft:'auto'}}>{new Date(n.createdAt).toLocaleString()}</span>
                <button onClick={()=>deleteNote(n.id)} style={{background:'none',border:'none',color:C.text3,cursor:'pointer',fontSize:13}}>✕</button>
              </div>
              <div style={{fontSize:'11.5px',color:C.text2,lineHeight:1.65,whiteSpace:'pre-wrap'}}>{n.text}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── NAV + APP ROOT ───────────────────────────────────────────────────────────
const NAV = [
  {s:'Mission'},
  {id:'dashboard',label:'Mission Control',icon:'◈'},
  {id:'ai',label:'Elite AI',icon:'⟡',badge:'AI',bc:C.purple,bt:'#fff'},
  {s:'Testing'},
  {id:'scope',label:'Scope Tracker',icon:'⊞'},
  {id:'recon',label:'Recon & Targets',icon:'⊕'},
  {id:'findings',label:'Findings Register',icon:'◎',badge:'7',bc:C.red,bt:'#fff'},
  {id:'notes',label:'Investigation Notes',icon:'📝'},
  {s:'Reporting'},
  {id:'reports',label:'Reports & Deliverables',icon:'📋'},
  {s:'System'},
  {id:'settings',label:'Settings',icon:'⚙'},
];

export default function App() {
  const store = useStore();
  const [view, setView] = useState('dashboard');
  const [toast, setToast] = useState(null);

  const showToast = useCallback((msg,type='success')=>{
    setToast({msg,type});
    setTimeout(()=>setToast(null),3000);
  },[]);

  const nav = useCallback((v)=>setView(v),[]);
  const { findings, eng } = store;
  const crit = findings.filter(f=>f.sev==='critical').length;
  const high = findings.filter(f=>f.sev==='high').length;

  const VIEWS = {
    dashboard: <Dashboard store={store} nav={nav}/>,
    ai:        <AIView store={store} showToast={showToast}/>,
    scope:     <ScopeView store={store}/>,
    recon:     <ReconView store={store} showToast={showToast}/>,
    findings:  <Findings store={store} showToast={showToast} nav={nav}/>,
    notes:     <NotesView store={store} showToast={showToast}/>,
    reports:   <ReportsView store={store} showToast={showToast}/>,
    settings:  <SettingsView store={store} showToast={showToast}/>,
  };

  return (
    <div style={{display:'grid',gridTemplateColumns:'210px 1fr',gridTemplateRows:'48px 1fr',height:'100vh',background:C.bg,color:C.text,fontFamily:"-apple-system,BlinkMacSystemFont,'Inter',sans-serif",fontSize:13,lineHeight:1.5,overflow:'hidden'}}>

      {/* TOPBAR */}
      <div style={{gridColumn:'1/-1',background:C.bg2,borderBottom:`1px solid ${C.border}`,display:'flex',alignItems:'center',padding:'0 14px',gap:12,zIndex:10}}>
        <div style={{fontFamily:C.mono,fontSize:'13px',fontWeight:700,color:C.accent,letterSpacing:'3px',display:'flex',alignItems:'center',gap:8,flexShrink:0}}>
          <Pulse color={C.accent} size={7}/>
          SECURENET<span style={{color:C.text4}}>.AI</span>
          <span style={{fontSize:'8px',color:C.text4,fontWeight:400,letterSpacing:1,background:C.bg3,border:`1px solid ${C.border}`,borderRadius:3,padding:'1px 5px'}}>ELITE</span>
        </div>
        <div style={{width:1,height:20,background:C.border}}/>
        <div style={{background:C.bg3,border:`1px solid ${C.border2}`,borderRadius:5,padding:'2px 10px',fontSize:'10px',color:C.text2,fontFamily:C.mono,whiteSpace:'nowrap'}}>{eng?.client} · #{eng?.id}</div>
        <div style={{display:'flex',alignItems:'center',gap:6,background:'rgba(16,185,129,.08)',border:'1px solid rgba(16,185,129,.25)',borderRadius:20,padding:'2px 10px',fontSize:'10px',color:C.green}}>
          <Pulse color={C.green} size={5}/>ACTIVE
        </div>
        <div style={{marginLeft:'auto',display:'flex',gap:7,alignItems:'center'}}>
          <span style={{fontSize:'10px',color:C.text3,fontFamily:C.mono}}>Ph.{eng?.currentPhase}/11</span>
          <span style={{fontSize:'10px',color:C.text3,fontFamily:C.mono}}>Wk.{eng?.currentWeek}/{eng?.totalWeeks}</span>
          {(crit+high)>0&&(
            <button onClick={()=>nav('findings')} style={{background:'rgba(239,68,68,.1)',border:'1px solid rgba(239,68,68,.3)',borderRadius:5,padding:'3px 10px',color:C.red,fontSize:'10px',fontFamily:C.mono,cursor:'pointer',display:'flex',alignItems:'center',gap:6}}>
              <Pulse color={C.red} size={5}/>⚡ {crit+high} PRIORITY
            </button>
          )}
          {!store.state.apiKey&&(
            <button onClick={()=>nav('settings')} style={{background:'rgba(139,92,246,.1)',border:'1px solid rgba(139,92,246,.3)',borderRadius:5,padding:'3px 10px',color:C.purple,fontSize:'10px',fontFamily:C.mono,cursor:'pointer'}}>
              ⚙ Set API Key
            </button>
          )}
        </div>
      </div>

      {/* SIDEBAR */}
      <div style={{background:C.bg2,borderRight:`1px solid ${C.border}`,overflowY:'auto',overflowX:'hidden',display:'flex',flexDirection:'column'}}>
        <div style={{padding:'10px 14px 8px',borderBottom:`1px solid ${C.border}`}}>
          <div style={{fontSize:'9px',color:C.text4,fontFamily:C.mono,letterSpacing:'1px'}}>ACTIVE ENGAGEMENT</div>
          <div style={{fontSize:'11.5px',color:C.text,marginTop:2,fontWeight:600}}>{eng?.client}</div>
          <div style={{fontSize:'9.5px',color:C.text3,marginTop:1}}>{eng?.type?.slice(0,28)}...</div>
        </div>

        {NAV.map((n,i)=>n.s
          ?<div key={i} style={{padding:'12px 12px 3px',fontSize:'8.5px',letterSpacing:'1.5px',color:C.text4,textTransform:'uppercase',fontFamily:C.mono}}>{n.s}</div>
          :<div key={i} onClick={()=>nav(n.id)} style={{display:'flex',alignItems:'center',gap:9,padding:'6px 14px',cursor:'pointer',color:view===n.id?C.accent:C.text2,background:view===n.id?`rgba(0,200,240,.07)`:'transparent',borderLeft:view===n.id?`2px solid ${C.accent}`:'2px solid transparent',transition:'.1s'}}>
            <span style={{fontSize:11,width:14,textAlign:'center',flexShrink:0}}>{n.icon}</span>
            <span style={{fontSize:'11.5px'}}>{n.label}</span>
            {n.badge&&<span style={{marginLeft:'auto',background:n.bc,color:n.bt||'#fff',borderRadius:9,padding:'1px 6px',fontSize:'9px',fontFamily:C.mono}}>{n.badge}</span>}
          </div>
        )}

        {/* Health widget */}
        <div style={{margin:'auto 12px 12px',padding:'10px 12px',background:C.bg3,border:`1px solid ${C.border}`,borderRadius:8}}>
          <div style={{fontSize:'8.5px',fontFamily:C.mono,color:C.text4,letterSpacing:'1px',marginBottom:4}}>ENGAGEMENT HEALTH</div>
          {[
            {l:'Progress',v:`${eng?.progress||0}%`,c:C.accent},
            {l:'Findings',v:findings.length,c:findings.some(f=>f.sev==='critical')?C.red:C.amber},
            {l:'Critical',v:crit,c:C.red},
            {l:'Days left',v:Math.max(0,Math.ceil((new Date(eng?.endDate)-new Date())/86400000)),c:C.amber},
            {l:'Budget',v:eng?.investment,c:C.green},
          ].map(r=>(
            <div key={r.l} style={{display:'flex',justifyContent:'space-between',marginTop:4,fontSize:'10.5px'}}>
              <span style={{color:C.text3}}>{r.l}</span>
              <span style={{color:r.c,fontFamily:C.mono}}>{r.v}</span>
            </div>
          ))}
          <div style={{height:2,background:C.bg4,borderRadius:1,marginTop:8,overflow:'hidden'}}>
            <div style={{height:'100%',width:`${eng?.progress||0}%`,background:C.accent,borderRadius:1}}/>
          </div>
        </div>
      </div>

      {/* MAIN */}
      <div style={{overflowY:'auto',background:C.bg,padding:'18px 20px'}}>
        {VIEWS[view]||VIEWS.dashboard}
      </div>

      {toast&&<Toast msg={toast.msg} type={toast.type}/>}
    </div>
  );
}
