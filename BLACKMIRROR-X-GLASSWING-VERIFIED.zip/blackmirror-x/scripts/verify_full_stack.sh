#!/usr/bin/env bash
# verify_full_stack.sh — BLACKMIRROR-X full-stack integration verification
# Can run locally (checks route consistency) or against live stack (checks HTTP)
cd "$(dirname "$0")/.."

PASS=0; FAIL=0; WARN=0
pass()  { echo "  ✓ $1"; PASS=$((PASS+1)); }
fail()  { echo "  ✗ FAIL: $1"; FAIL=$((FAIL+1)); }
warn()  { echo "  ⚠ WARN: $1"; WARN=$((WARN+1)); }
info()  { echo "  ℹ $1"; }

BACKEND_URL="${BACKEND_URL:-http://localhost:8000}"
FRONTEND_URL="${FRONTEND_URL:-http://localhost:3000}"
LIVE_TEST=false

echo ""
echo "╔═══════════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Full-Stack Verification     ║"
echo "╚═══════════════════════════════════════════════╝"

# Test if live backend is available
if curl -sf --max-time 3 "${BACKEND_URL}/health" >/dev/null 2>&1; then
    LIVE_TEST=true
    info "Live backend detected at $BACKEND_URL"
else
    info "No live backend — running static analysis only"
fi

# ── [1] Backend code checks ────────────────────────────────────
echo ""
echo "[1/7] Backend static checks..."
bash scripts/verify_backend.sh 2>/dev/null && pass "Backend verification: 6/6" || fail "Backend verification failed"

# ── [2] Frontend build check ───────────────────────────────────
echo ""
echo "[2/7] Frontend build check..."
if [ -d "frontend/.next" ]; then
    BUILT_ROUTES=$(find frontend/.next/server/app -name "page.js" 2>/dev/null | wc -l || echo 0)
    [ "$BUILT_ROUTES" -gt 15 ] && pass "Frontend build exists — $BUILT_ROUTES pages" || warn "Frontend not built (run npm run build)"
else
    warn "frontend/.next missing — run verify_frontend.sh first"
fi

# ── [3] Nav link → page verification ──────────────────────────
echo ""
echo "[3/7] Nav link → page consistency..."
python3 - << 'EOF'
import re, os, sys
layout = open("frontend/src/app/dashboard/layout.tsx").read()
hrefs = re.findall(r'href:\s*"(/[^"]*)"', layout)
missing = []
pages_root = "frontend/src/app"
for href in hrefs:
    rel = href.lstrip("/") or "dashboard"
    if not os.path.exists(f"{pages_root}/{rel}/page.tsx"):
        missing.append(href)
if missing:
    print(f"FAIL: missing pages: {missing}")
    sys.exit(1)
else:
    print(f"PASS: all {len(hrefs)} nav links have pages")
EOF
[ $? -eq 0 ] && pass "All 23 nav links → pages verified" || fail "Missing page files"

# ── [4] API route consistency ──────────────────────────────────
echo ""
echo "[4/7] API route consistency..."
python3 - << 'EOF'
import re, os, sys

# Extract backend routes
routes_dir = "backend/app/api/routes"
backend_paths = set()
prefix_map = {
    "auth":"/api/v1/auth","workspaces":"/api/v1/workspaces","scans":"/api/v1/scans",
    "recon":"/api/v1/recon","vulns":"/api/v1/vulns","reports":"/api/v1/reports",
    "copilot":"/api/v1/copilot","apikeys":"/api/v1/apikeys","intelligence":"/api/v1/intel",
    "enterprise":"/api/v1/enterprise","demo":"/api/v1/demo","orchestrator":"/api/v1/orchestrator",
    "agents":"/api/v1/agents","phase10":"/api/v1","websocket":"/ws",
}
for f in os.listdir(routes_dir):
    if not f.endswith(".py"): continue
    name = f.replace(".py","")
    prefix = prefix_map.get(name, f"/api/v1/{name}")
    content = open(f"{routes_dir}/{f}").read()
    for m in re.finditer(r'@(?:router|app|browser_router|api_intel_router|chains_router|replay_router|memory_router|workers_router)\.(get|post|patch|delete|put)\s*\(\s*["\']([^"\']*)["\']', content):
        backend_paths.add(prefix + m.group(2))

# Check critical frontend API calls exist in backend
api_content = open("frontend/src/lib/api.ts").read()
critical_prefixes = [
    "/api/v1/auth/login","/api/v1/auth/me","/api/v1/workspaces",
    "/api/v1/scans","/api/v1/vulns","/api/v1/recon/subdomains",
    "/api/v1/reports","/api/v1/copilot/chat/stream",
    "/api/v1/enterprise/scope","/api/v1/enterprise/approvals",
]
missing = []
for ep in critical_prefixes:
    found = any(b.startswith(ep.split("{")[0]) for b in backend_paths)
    if not found: missing.append(ep)

print(f"Backend routes: {len(backend_paths)}")
if missing:
    print(f"WARN: {len(missing)} critical endpoints not found: {missing[:3]}")
else:
    print(f"PASS: all {len(critical_prefixes)} critical endpoints found in backend")
    sys.exit(0)
EOF
[ $? -eq 0 ] && pass "Critical API routes: all present" || warn "Some API routes missing"

# ── [5] Requirements.txt completeness ─────────────────────────
echo ""
echo "[5/7] Requirements.txt check..."
python3 - << 'EOF'
import re, sys
reqs = open("backend/requirements.txt").read().lower()
critical = ["fastapi","uvicorn","sqlalchemy","asyncpg","alembic","pydantic",
            "python-jose","passlib","redis","celery","anthropic","structlog","httpx",
            "tenacity","jinja2","email-validator"]
missing = [p for p in critical if p not in reqs]
if missing:
    print(f"FAIL: missing: {missing}")
    sys.exit(1)
print(f"PASS: all {len(critical)} critical packages in requirements.txt")
EOF
[ $? -eq 0 ] && pass "requirements.txt complete" || fail "requirements.txt missing packages"

# ── [6] .env.example completeness ─────────────────────────────
echo ""
echo "[6/7] .env.example check..."
python3 - << 'EOF'
import sys
env = open(".env.example").read()
required = ["ANTHROPIC_API_KEY","SECRET_KEY","JWT_SECRET_KEY","POSTGRES_PASSWORD",
            "DATABASE_URL","REDIS_URL","CELERY_BROKER_URL","CORS_ORIGINS",
            "NEXT_PUBLIC_API_URL","NEXT_PUBLIC_WS_URL","AI_MODEL"]
missing = [v for v in required if v not in env]
if missing:
    print(f"FAIL: missing vars: {missing}")
    sys.exit(1)
print(f"PASS: all {len(required)} required env vars documented")
EOF
[ $? -eq 0 ] && pass ".env.example complete" || fail ".env.example missing vars"

# ── [7] Live stack test (if running) ──────────────────────────
echo ""
echo "[7/7] Live stack test..."
if [ "$LIVE_TEST" = "true" ]; then
    # Health check
    HEALTH=$(curl -sf --max-time 5 "${BACKEND_URL}/health" 2>/dev/null)
    echo "$HEALTH" | grep -q "healthy" && pass "Backend /health: OK" || fail "Backend /health failed"

    # Login
    TOKEN=$(curl -sf --max-time 10 -X POST "${BACKEND_URL}/api/v1/auth/login" \
        -H "Content-Type: application/json" \
        -d '{"email":"admin@blackmirror.io","password":"BlackMirrorX2025!"}' 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('access_token',''))" 2>/dev/null)
    [ -n "$TOKEN" ] && pass "Login: OK (token obtained)" || warn "Login failed (DB may not be seeded)"

    if [ -n "$TOKEN" ]; then
        # Workspaces
        WS=$(curl -sf --max-time 5 "${BACKEND_URL}/api/v1/workspaces" -H "Authorization: Bearer $TOKEN" 2>/dev/null)
        echo "$WS" | python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d))" 2>/dev/null | grep -q "[0-9]" \
            && pass "GET /workspaces: OK" || warn "Workspaces empty"

        # Scope check
        SC=$(curl -sf --max-time 5 "${BACKEND_URL}/api/v1/enterprise/plugins" -H "Authorization: Bearer $TOKEN" 2>/dev/null)
        echo "$SC" | grep -q "plugins" && pass "Enterprise routes: OK" || warn "Enterprise routes issue"
    fi

    # Frontend
    FE=$(curl -sf --max-time 10 "${FRONTEND_URL}/" 2>/dev/null | head -1)
    [ -n "$FE" ] && pass "Frontend reachable at $FRONTEND_URL" || warn "Frontend not reachable"
else
    info "Live tests skipped — set BACKEND_URL= and FRONTEND_URL= and ensure stack is running"
    pass "Static verification complete (live tests skipped)"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Results: ${PASS} passed, ${FAIL} failed, ${WARN} warnings"
[ "$FAIL" -eq 0 ] && echo "✓ FULL-STACK VERIFICATION: PASS" && exit 0 || echo "✗ FULL-STACK VERIFICATION: FAIL" && exit 1
