#!/usr/bin/env bash
# verify_frontend.sh — BLACKMIRROR-X frontend verification
set -e
cd "$(dirname "$0")/../frontend"

PASS=0; FAIL=0
pass() { echo "  ✓ $1"; PASS=$((PASS+1)); }
fail() { echo "  ✗ FAIL: $1"; FAIL=$((FAIL+1)); }

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Frontend Verification  ║"
echo "╚══════════════════════════════════════════╝"

# 1. Node version
echo "[1/5] Node/npm..."
NODE_VER=$(node --version 2>/dev/null || echo "missing")
NPM_VER=$(npm --version 2>/dev/null || echo "missing")
[[ "$NODE_VER" != "missing" ]] && pass "Node $NODE_VER, npm $NPM_VER" || fail "Node not found"

# 2. Dependencies
echo "[2/5] npm install..."
npm install --prefer-offline --silent 2>/dev/null
MODS=$(ls node_modules | wc -l)
[ "$MODS" -gt 100 ] && pass "Dependencies installed ($MODS packages)" || fail "npm install failed"

# 3. Lint
echo "[3/5] ESLint..."
LINT_OUT=$(npm run lint 2>&1)
LINT_EXIT=$?
ERRORS=$(echo "$LINT_OUT" | grep -c "^.*Error:" || true)
WARNINGS=$(echo "$LINT_OUT" | grep -c "Warning:" || true)
[ "$LINT_EXIT" -eq 0 ] && pass "Lint passed ($WARNINGS warnings, 0 errors)" || fail "Lint errors: $ERRORS"

# 4. TypeScript
echo "[4/5] TypeScript type check..."
TSC_OUT=$(npx tsc --noEmit 2>&1)
TSC_EXIT=$?
TS_ERRORS=$(echo "$TSC_OUT" | grep -c "error TS" || true)
[ "$TSC_EXIT" -eq 0 ] && pass "TypeScript: 0 type errors" || fail "TypeScript: $TS_ERRORS errors"

# 5. Build
echo "[5/5] Next.js build..."
BUILD_OUT=$(NEXT_PUBLIC_API_URL=http://localhost:8000 NEXT_PUBLIC_WS_URL=ws://localhost:8000 npm run build 2>&1)
BUILD_EXIT=$?
ROUTES=$(echo "$BUILD_OUT" | grep -c "^├ \|^└ " || true)
[ "$BUILD_EXIT" -eq 0 ] && pass "Build succeeded — $ROUTES routes compiled" || {
    fail "Build failed"
    echo "$BUILD_OUT" | grep -i "error" | head -10
}

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Results: ${PASS} passed, ${FAIL} failed"
[ "$FAIL" -eq 0 ] && echo "✓ FRONTEND: PASS" && exit 0 || echo "✗ FRONTEND: FAIL" && exit 1
