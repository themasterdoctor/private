#!/usr/bin/env bash
# verify_backend.sh — BLACKMIRROR-X backend verification
set -e
cd "$(dirname "$0")/.."

PASS=0; FAIL=0
pass() { echo "  ✓ $1"; PASS=$((PASS+1)); }
fail() { echo "  ✗ FAIL: $1"; FAIL=$((FAIL+1)); }

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Backend Verification   ║"
echo "╚══════════════════════════════════════════╝"

cd backend

# 1. Python compile
echo "[1/6] Python compile..."
python3 -m compileall app -q 2>/dev/null && pass "All 130+ Python files compile" || fail "Python compile error"

# 2. App import
echo "[2/6] App import + routes..."
ROUTES=$(python3 -c "
import sys,os; sys.path.insert(0,'.')
os.environ.update({'DATABASE_URL':'postgresql+asyncpg://x:x@localhost/x','REDIS_URL':'redis://localhost:6379/0',
'CELERY_BROKER_URL':'redis://localhost:6379/1','CELERY_RESULT_BACKEND':'redis://localhost:6379/2',
'ANTHROPIC_API_KEY':'test','SECRET_KEY':'test32chars_aaaaaaaaaaaaaaaaaaaaaa',
'JWT_SECRET_KEY':'test32chars_aaaaaaaaaaaaaaaaaaaaaa'})
from app.main import app
print(len([r for r in app.routes if hasattr(r,'path')]))" 2>/dev/null)
[ "$ROUTES" -gt 100 ] 2>/dev/null && pass "App imports OK — $ROUTES routes" || fail "Import failed (routes=$ROUTES)"

# 3. Models
echo "[3/6] SQLAlchemy models..."
python3 -c "
import sys,os; sys.path.insert(0,'.')
os.environ['DATABASE_URL']='postgresql+asyncpg://x:x@localhost/x'
from app.models.models import User,Workspace,ScanJob,Vulnerability,Subdomain,DiscoveredURL,Report
print('OK')" 2>/dev/null | grep -q OK && pass "All ORM models import" || fail "Model import failed"

# 4. Migration chain
echo "[4/6] Alembic migration chain..."
MIGS=$(ls alembic/versions/*.py 2>/dev/null | wc -l)
CHAIN=$(python3 -c "
import sys,os; sys.path.insert(0,'.')
os.environ['DATABASE_URL']='x'
from alembic.config import Config
from alembic.script import ScriptDirectory
s=ScriptDirectory.from_config(Config('alembic.ini'))
revs=list(s.walk_revisions())
print(len(revs))" 2>/dev/null)
[ "$MIGS" -ge 4 ] && [ "$CHAIN" -ge 4 ] && pass "$MIGS migration files, $CHAIN-revision chain valid" || fail "Migration chain issue (files=$MIGS, chain=$CHAIN)"

# 5. Security module
echo "[5/6] Security module..."
python3 -c "
import sys,os; sys.path.insert(0,'.')
os.environ['JWT_SECRET_KEY']='test32chars_aaaaaaaaaaaaaaaaaaaaaa'
from app.core.security import hash_password,verify_password,create_access_token,decode_token
assert verify_password('test', hash_password('test'))
assert decode_token(create_access_token('uid'))['sub']=='uid'
print('OK')" 2>/dev/null | grep -q OK && pass "JWT + bcrypt functional" || fail "Security module broken"

# 6. Enterprise modules
echo "[6/6] Enterprise modules..."
python3 -c "
import sys,os; sys.path.insert(0,'.')
from app.enterprise.scope_engine import ScopeEngine
from app.enterprise.confidence_scoring import score_finding
from app.enterprise.approval_gates import ApprovalGate, list_pending_approvals
from app.enterprise.payload_library import get_auto_safe_payloads, PAYLOAD_LIBRARY
from app.enterprise.plugin_sdk import registry, PluginType
from app.enterprise.team_features import ReportQualityChecker, SLAPolicy, check_permission
from app.enterprise.evidence_engine import HttpEvidence, EvidencePackage

e=ScopeEngine('w1'); e.add_scope('*.example.com')
assert e.check_target('api.example.com').allowed
assert not e.check_target('google.com').allowed  # not in scope when rules defined

p=score_finding('xss','high',evidence_count=2,has_request_response=True)
assert 0<p.overall_score<=1, f'bad score {p.overall_score}'

pls=get_auto_safe_payloads('xss'); assert len(pls)>0
assert len(PAYLOAD_LIBRARY)>=5  # xss,sqli,ssrf,ssti,idor

assert len(registry.list_plugins())>=2
assert check_permission('admin','scan:create')
assert not check_permission('viewer','scan:create')

ev=HttpEvidence(method='POST',url='https://t.com/api',status_code=200,payload_used='test',indicator_found='alert(1)')
curl=ev.to_curl(); assert 'curl' in curl
proof=ev.to_proof_section(); assert '## Proof' in proof

print('ALL_PASS')" 2>/dev/null | grep -q ALL_PASS && pass "All enterprise modules functional" || fail "Enterprise module error"

cd ..

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Results: ${PASS} passed, ${FAIL} failed"
[ "$FAIL" -eq 0 ] && echo "✓ BACKEND: PASS" && exit 0 || echo "✗ BACKEND: FAIL" && exit 1
