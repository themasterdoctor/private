#!/usr/bin/env bash
# fix_now.sh — BLACKMIRROR-X Complete Runtime Stabilization + Rebuild
# Run from: ~/private/blackmirror-x
# What this does:
#   1. Fixes .env (CORS, API URLs)
#   2. Applies Python patches to 5 backend files (already in this zip)
#   3. Stops all containers
#   4. Rebuilds backend + worker images with --no-cache
#   5. Starts all services
#   6. Runs end-to-end verification
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR/.."
[ -f docker-compose.yml ] || { echo "ERROR: run from ~/private/blackmirror-x"; exit 1; }

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Stabilization + Rebuild    ║"
echo "╚══════════════════════════════════════════════╝"

# ── [1] Fix .env ─────────────────────────────────────────────
echo "[1/7] Configuring .env..."
[ -f .env ] || cp .env.vps .env
sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://76.13.30.226:3000,http://localhost:3000,http://127.0.0.1:3000|" .env
sed -i "s|^NEXT_PUBLIC_API_URL=.*|NEXT_PUBLIC_API_URL=http://76.13.30.226:8000|" .env
sed -i "s|^NEXT_PUBLIC_WS_URL=.*|NEXT_PUBLIC_WS_URL=ws://76.13.30.226:8000|" .env
echo "  ✓ CORS: $(grep ^CORS_ORIGINS .env | cut -d= -f2)"
echo "  ✓ API:  $(grep ^NEXT_PUBLIC_API_URL .env | cut -d= -f2)"

# ── [2] Apply all backend patches ────────────────────────────
echo "[2/7] Applying backend patches..."
python3 - << 'PYEOF'
import os, sys

def write(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(content)
    print(f"  ✓ {path}")

# ── schemas/scans.py ─────────────────────────────────────────────────────────
write("backend/app/schemas/scans.py", """
from typing import Optional, Dict, Any
from pydantic import BaseModel, model_validator
from datetime import datetime


def _ev(v):
    return v.value if hasattr(v, "value") else str(v or "")


class ScanCreateRequest(BaseModel):
    workspace_id: str
    target_id: Optional[str] = None
    name: str
    scan_type: str = "full"
    config: Optional[Dict[str, Any]] = None
    target: Optional[str] = None  # frontend sends this; injected into config.domain

    @model_validator(mode="after")
    def inject_target(self) -> "ScanCreateRequest":
        if self.target:
            if self.config is None:
                self.config = {}
            if not self.config.get("domain"):
                domain = self.target.replace("https://","").replace("http://","").split("/")[0].split("?")[0]
                self.config["domain"] = domain
        return self


class ScanListOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    name: str
    scan_type: str
    status: str
    progress: int
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    target: Optional[str] = None
    subdomain_count: int = 0
    url_count: int = 0
    vuln_count: int = 0

    @model_validator(mode="before")
    @classmethod
    def normalize(cls, obj):
        if not hasattr(obj, "status"): return obj
        cfg = getattr(obj, "config", {}) or {}
        name = getattr(obj, "name", "") or ""
        return {"id": str(getattr(obj, "id", "")), "name": name,
                "scan_type": _ev(getattr(obj, "scan_type", "full")),
                "status": _ev(getattr(obj, "status", "queued")),
                "progress": getattr(obj, "progress", 0) or 0,
                "created_at": getattr(obj, "created_at", datetime.utcnow()),
                "started_at": getattr(obj, "started_at", None),
                "completed_at": getattr(obj, "completed_at", None),
                "target": cfg.get("domain") or cfg.get("target") or name,
                "subdomain_count": 0, "url_count": 0, "vuln_count": 0}


class ScanOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    name: str
    scan_type: str
    status: str
    progress: int
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    target: Optional[str] = None
    subdomain_count: int = 0
    url_count: int = 0
    vuln_count: int = 0
    workspace_id: str
    target_id: Optional[str] = None
    created_by: str
    config: Dict[str, Any] = {}
    celery_task_id: Optional[str] = None
    error_message: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def normalize(cls, obj):
        if not hasattr(obj, "status"): return obj
        cfg = getattr(obj, "config", {}) or {}
        name = getattr(obj, "name", "") or ""
        return {"id": str(getattr(obj, "id", "")), "name": name,
                "scan_type": _ev(getattr(obj, "scan_type", "full")),
                "status": _ev(getattr(obj, "status", "queued")),
                "progress": getattr(obj, "progress", 0) or 0,
                "created_at": getattr(obj, "created_at", datetime.utcnow()),
                "started_at": getattr(obj, "started_at", None),
                "completed_at": getattr(obj, "completed_at", None),
                "target": cfg.get("domain") or cfg.get("target") or name,
                "subdomain_count": 0, "url_count": 0, "vuln_count": 0,
                "workspace_id": str(getattr(obj, "workspace_id", "")),
                "target_id": getattr(obj, "target_id", None),
                "created_by": str(getattr(obj, "created_by", "")),
                "config": cfg,
                "celery_task_id": getattr(obj, "celery_task_id", None),
                "error_message": getattr(obj, "error_message", None)}


class ScanLogOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    level: str
    module: str
    message: str
    data: Optional[Dict[str, Any]] = None
    timestamp: datetime
""".lstrip())

# ── routes/scans.py ──────────────────────────────────────────────────────────
write("backend/app/api/routes/scans.py", """
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import func, select, desc
import json, asyncio, structlog
from app.db.session import get_db
from app.models.models import ScanJob, ScanLog, User, ScanStatus, ScanType, Subdomain, DiscoveredURL, Vulnerability
from app.api.deps.auth import get_current_user
from app.schemas.scans import ScanCreateRequest, ScanOut, ScanLogOut, ScanListOut
from app.workers.tasks import run_scan_task

router = APIRouter()
logger = structlog.get_logger(__name__)


@router.post("", response_model=ScanOut, status_code=201)
async def create_scan(data: ScanCreateRequest, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    try: scan_type = ScanType(data.scan_type)
    except ValueError: scan_type = ScanType.FULL
    scan = ScanJob(workspace_id=data.workspace_id, target_id=data.target_id, created_by=current_user.id,
                   name=data.name, scan_type=scan_type, config=data.config or {}, status=ScanStatus.QUEUED)
    db.add(scan)
    await db.commit()  # COMMIT FIRST so worker can find scan
    await db.refresh(scan)
    scan_id = str(scan.id)
    try:
        task = run_scan_task.apply_async(args=[scan_id], task_id=f"scan_{scan_id}")
        scan.celery_task_id = task.id
        await db.commit()
    except Exception as e:
        logger.warning("celery_queue_failed", error=str(e), scan_id=scan_id)
    logger.info("scan_created", scan_id=scan_id)
    return ScanOut.model_validate(scan)


@router.get("", response_model=List[ScanListOut])
async def list_scans(workspace_id: str = Query(...), status: Optional[str] = Query(None),
                     limit: int = Query(50, le=200), offset: int = Query(0),
                     db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    q = select(ScanJob).where(ScanJob.workspace_id == workspace_id)
    if status:
        try: q = q.where(ScanJob.status == ScanStatus(status))
        except ValueError: pass
    q = q.order_by(desc(ScanJob.created_at)).limit(limit).offset(offset)
    scans = (await db.execute(q)).scalars().all()
    out = []
    for s in scans:
        d = ScanListOut.model_validate(s)
        d.subdomain_count = (await db.execute(select(func.count()).where(Subdomain.scan_id == s.id))).scalar() or 0
        d.url_count = (await db.execute(select(func.count()).where(DiscoveredURL.scan_id == s.id))).scalar() or 0
        d.vuln_count = (await db.execute(select(func.count()).where(Vulnerability.scan_id == s.id))).scalar() or 0
        out.append(d)
    return out


@router.get("/{scan_id}", response_model=ScanOut)
async def get_scan(scan_id: str, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    scan = (await db.execute(select(ScanJob).where(ScanJob.id == scan_id))).scalar_one_or_none()
    if not scan: raise HTTPException(404, "Scan not found")
    return ScanOut.model_validate(scan)


@router.post("/{scan_id}/cancel")
async def cancel_scan(scan_id: str, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    scan = (await db.execute(select(ScanJob).where(ScanJob.id == scan_id))).scalar_one_or_none()
    if not scan: raise HTTPException(404, "Scan not found")
    if scan.status not in (ScanStatus.QUEUED, ScanStatus.RUNNING): raise HTTPException(400, "Cannot cancel")
    if scan.celery_task_id:
        try:
            from app.workers.celery_app import celery_app
            celery_app.control.revoke(scan.celery_task_id, terminate=True)
        except Exception: pass
    scan.status = ScanStatus.CANCELLED
    await db.commit()
    return {"status": "cancelled"}


@router.get("/{scan_id}/logs", response_model=List[ScanLogOut])
async def get_scan_logs(scan_id: str, limit: int = Query(200, le=1000),
                        db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    q = select(ScanLog).where(ScanLog.scan_id == scan_id).order_by(ScanLog.timestamp).limit(limit)
    return [ScanLogOut.model_validate(l) for l in (await db.execute(q)).scalars().all()]


@router.get("/{scan_id}/stream")
async def stream_scan_logs(scan_id: str, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    async def gen():
        last_id = None
        while True:
            async with AsyncSession(db.bind) as s:
                q = select(ScanLog).where(ScanLog.scan_id == scan_id)
                if last_id: q = q.where(ScanLog.id > last_id)
                logs = (await s.execute(q.order_by(ScanLog.timestamp).limit(50))).scalars().all()
            for log in logs:
                last_id = log.id
                yield f"data: {json.dumps({'id': log.id, 'level': log.level, 'module': log.module, 'message': log.message, 'timestamp': log.timestamp.isoformat()})}\\n\\n"
            async with AsyncSession(db.bind) as s:
                scan = (await s.execute(select(ScanJob).where(ScanJob.id == scan_id))).scalar_one_or_none()
                if scan and scan.status in (ScanStatus.COMPLETED, ScanStatus.FAILED, ScanStatus.CANCELLED):
                    sv = scan.status.value if hasattr(scan.status, "value") else str(scan.status)
                    yield f"data: {json.dumps({'type': 'done', 'status': sv})}\\n\\n"
                    break
            await asyncio.sleep(1)
    return StreamingResponse(gen(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
""".lstrip())

# ── routes/recon.py ──────────────────────────────────────────────────────────
write("backend/app/api/routes/recon.py", """
from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from pydantic import BaseModel, model_validator
from datetime import datetime
from app.db.session import get_db
from app.models.models import Subdomain, DiscoveredURL, User
from app.api.deps.auth import get_current_user

router = APIRouter()


class SubdomainOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    subdomain: str = ""
    ip_address: Optional[str] = None
    status_code: Optional[int] = None
    title: Optional[str] = None
    technologies: List[str] = []
    ports: List[int] = []
    created_at: datetime
    source: str = ""
    is_alive: bool = False

    @model_validator(mode="before")
    @classmethod
    def map_orm(cls, obj):
        if not hasattr(obj, "host"): return obj
        ip_list = getattr(obj, "ip_addresses", []) or []
        return {"id": str(getattr(obj, "id", "")),
                "subdomain": getattr(obj, "host", "") or "",
                "ip_address": ip_list[0] if ip_list else None,
                "status_code": getattr(obj, "status_code", None),
                "title": getattr(obj, "title", None),
                "technologies": getattr(obj, "tech_stack", []) or [],
                "ports": getattr(obj, "ports", []) or [],
                "created_at": getattr(obj, "discovered_at", datetime.utcnow()),
                "source": getattr(obj, "source", "") or "",
                "is_alive": getattr(obj, "is_alive", False)}


class URLOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    url: str
    method: str = "GET"
    status_code: Optional[int] = None
    content_type: Optional[str] = None
    parameters: List[str] = []
    is_interesting: bool = False
    interest_reasons: List[str] = []
    source: str = ""
    discovered_at: datetime


@router.get("/subdomains", response_model=List[SubdomainOut])
async def list_subdomains(workspace_id: str = Query(...), scan_id: Optional[str] = Query(None),
                          alive_only: bool = Query(False), limit: int = Query(200, le=1000),
                          offset: int = Query(0), db: AsyncSession = Depends(get_db),
                          current_user: User = Depends(get_current_user)):
    q = select(Subdomain).where(Subdomain.workspace_id == workspace_id)
    if scan_id: q = q.where(Subdomain.scan_id == scan_id)
    if alive_only: q = q.where(Subdomain.is_alive == True)
    return [SubdomainOut.model_validate(s) for s in (await db.execute(q.order_by(desc(Subdomain.discovered_at)).limit(limit).offset(offset))).scalars().all()]


@router.get("/urls", response_model=List[URLOut])
async def list_urls(workspace_id: str = Query(...), scan_id: Optional[str] = Query(None),
                    interesting_only: bool = Query(False), limit: int = Query(200, le=1000),
                    offset: int = Query(0), db: AsyncSession = Depends(get_db),
                    current_user: User = Depends(get_current_user)):
    q = select(DiscoveredURL).where(DiscoveredURL.workspace_id == workspace_id)
    if scan_id: q = q.where(DiscoveredURL.scan_id == scan_id)
    if interesting_only: q = q.where(DiscoveredURL.is_interesting == True)
    return [URLOut.model_validate(u) for u in (await db.execute(q.order_by(desc(DiscoveredURL.discovered_at)).limit(limit).offset(offset))).scalars().all()]
""".lstrip())

# ── routes/vulns.py ──────────────────────────────────────────────────────────
write("backend/app/api/routes/vulns.py", """
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from pydantic import BaseModel, model_validator
from datetime import datetime
from app.db.session import get_db
from app.models.models import Vulnerability, User, VulnStatus, Severity
from app.api.deps.auth import get_current_user

router = APIRouter()


class VulnOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    scan_id: str
    workspace_id: Optional[str] = None
    title: str
    vuln_type: str
    severity: str
    status: str
    cvss_score: Optional[float] = None
    cwe_id: Optional[str] = None
    url: Optional[str] = None
    parameter: Optional[str] = None
    payload: Optional[str] = None
    evidence: Optional[str] = None
    description: Optional[str] = None
    remediation: Optional[str] = None
    tags: List[str] = []
    source: str = ""
    created_at: datetime  # mapped from discovered_at
    court_confidence: Optional[float] = None
    exploitability_score: Optional[float] = None
    bounty_likelihood: Optional[float] = None
    evidence_score: Optional[float] = None
    reproduction_steps: Optional[str] = None
    reflection_context: Optional[str] = None
    simulation_narrative: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def map_orm(cls, obj):
        if not hasattr(obj, "discovered_at"): return obj
        sev = getattr(obj, "severity", None)
        st = getattr(obj, "status", None)
        return {"id": str(getattr(obj, "id", "")), "scan_id": str(getattr(obj, "scan_id", "")),
                "workspace_id": str(getattr(obj, "workspace_id", "") or ""),
                "title": getattr(obj, "title", "") or "", "vuln_type": getattr(obj, "vuln_type", "") or "",
                "severity": sev.value if hasattr(sev, "value") else str(sev or "info"),
                "status": st.value if hasattr(st, "value") else str(st or "open"),
                "cvss_score": getattr(obj, "cvss_score", None), "cwe_id": getattr(obj, "cwe_id", None),
                "url": getattr(obj, "url", None) or "", "parameter": getattr(obj, "parameter", None),
                "payload": getattr(obj, "payload", None), "evidence": getattr(obj, "evidence", None),
                "description": getattr(obj, "description", None), "remediation": getattr(obj, "remediation", None),
                "tags": getattr(obj, "tags", []) or [], "source": getattr(obj, "source", "") or "",
                "created_at": getattr(obj, "discovered_at", datetime.utcnow()),
                "court_confidence": getattr(obj, "court_confidence", None),
                "exploitability_score": getattr(obj, "exploitability_score", None),
                "bounty_likelihood": getattr(obj, "bounty_likelihood", None),
                "evidence_score": getattr(obj, "evidence_score", None),
                "reproduction_steps": getattr(obj, "reproduction_steps", None),
                "reflection_context": getattr(obj, "reflection_context", None),
                "simulation_narrative": getattr(obj, "simulation_narrative", None)}


class VulnUpdate(BaseModel):
    status: Optional[str] = None
    description: Optional[str] = None
    remediation: Optional[str] = None
    cvss_score: Optional[float] = None
    tags: Optional[list] = None


@router.get("", response_model=List[VulnOut])
async def list_vulns(workspace_id: str = Query(...), scan_id: Optional[str] = Query(None),
                     severity: Optional[str] = Query(None), vuln_type: Optional[str] = Query(None),
                     status: Optional[str] = Query(None), limit: int = Query(100, le=500),
                     offset: int = Query(0), db: AsyncSession = Depends(get_db),
                     current_user: User = Depends(get_current_user)):
    q = select(Vulnerability).where(Vulnerability.workspace_id == workspace_id)
    if scan_id: q = q.where(Vulnerability.scan_id == scan_id)
    if severity:
        try: q = q.where(Vulnerability.severity == Severity(severity))
        except ValueError: pass
    if vuln_type: q = q.where(Vulnerability.vuln_type == vuln_type)
    if status:
        try: q = q.where(Vulnerability.status == VulnStatus(status))
        except ValueError: pass
    return [VulnOut.model_validate(v) for v in (await db.execute(q.order_by(desc(Vulnerability.discovered_at)).limit(limit).offset(offset))).scalars().all()]


@router.get("/{vuln_id}", response_model=VulnOut)
async def get_vuln(vuln_id: str, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    v = (await db.execute(select(Vulnerability).where(Vulnerability.id == vuln_id))).scalar_one_or_none()
    if not v: raise HTTPException(404, "Vulnerability not found")
    return VulnOut.model_validate(v)


@router.patch("/{vuln_id}", response_model=VulnOut)
async def update_vuln(vuln_id: str, data: VulnUpdate, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    v = (await db.execute(select(Vulnerability).where(Vulnerability.id == vuln_id))).scalar_one_or_none()
    if not v: raise HTTPException(404, "Vulnerability not found")
    if data.status:
        try: v.status = VulnStatus(data.status)
        except ValueError: raise HTTPException(400, f"Invalid status: {data.status}")
    if data.description is not None: v.description = data.description
    if data.remediation is not None: v.remediation = data.remediation
    if data.cvss_score is not None: v.cvss_score = data.cvss_score
    if data.tags is not None: v.tags = data.tags
    await db.flush(); await db.commit(); await db.refresh(v)
    return VulnOut.model_validate(v)


@router.get("/{vuln_id}/hackerone-report")
async def get_hackerone_report(vuln_id: str, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    v = (await db.execute(select(Vulnerability).where(Vulnerability.id == vuln_id))).scalar_one_or_none()
    if not v: raise HTTPException(404, "Vulnerability not found")
    from app.agents.report_writer.agent import ReportWriterAgent
    sev = v.severity.value if hasattr(v.severity, "value") else str(v.severity)
    report = ReportWriterAgent().generate_hackerone_report({"title": v.title, "vuln_type": v.vuln_type, "severity": sev, "cvss_score": v.cvss_score, "url": v.url, "parameter": v.parameter, "payload": v.payload, "evidence": v.evidence, "description": v.description, "remediation": v.remediation})
    return {"content": report, "format": "markdown"}
""".lstrip())

# ── routes/workspaces.py ─────────────────────────────────────────────────────
write("backend/app/api/routes/workspaces.py", """
from typing import List, Optional
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import re
from app.db.session import get_db
from app.models.models import Workspace, WorkspaceMember, User, UserRole
from app.api.deps.auth import get_current_user
from pydantic import BaseModel

router = APIRouter()


class WorkspaceCreate(BaseModel):
    name: str
    description: Optional[str] = None


class WorkspaceOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    name: str
    slug: str
    description: Optional[str] = None
    is_active: bool
    created_at: datetime  # was missing — frontend interface requires it


@router.post("", response_model=WorkspaceOut, status_code=201)
async def create_workspace(data: WorkspaceCreate, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    slug = re.sub(r"-+", "-", re.sub(r"[^a-z0-9-]", "-", data.name.lower().strip()).strip("-"))
    if (await db.execute(select(Workspace).where(Workspace.slug == slug))).scalar_one_or_none():
        slug = f"{slug}-{current_user.id[:6]}"
    ws = Workspace(name=data.name, slug=slug, description=data.description)
    db.add(ws)
    await db.flush()
    db.add(WorkspaceMember(workspace_id=ws.id, user_id=current_user.id, role=UserRole.ADMIN))
    await db.commit()
    await db.refresh(ws)
    return WorkspaceOut.model_validate(ws)


@router.get("", response_model=List[WorkspaceOut])
async def list_workspaces(db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    q = select(Workspace).join(WorkspaceMember, Workspace.id == WorkspaceMember.workspace_id).where(WorkspaceMember.user_id == current_user.id, Workspace.is_active == True)
    return [WorkspaceOut.model_validate(ws) for ws in (await db.execute(q)).scalars().all()]


@router.get("/{workspace_id}", response_model=WorkspaceOut)
async def get_workspace(workspace_id: str, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    ws = (await db.execute(select(Workspace).where(Workspace.id == workspace_id))).scalar_one_or_none()
    if not ws: raise HTTPException(404, "Workspace not found")
    return WorkspaceOut.model_validate(ws)
""".lstrip())

print("All patches written.")
PYEOF
echo "  ✓ All 5 backend files patched"

# ── [3] Stop all containers ───────────────────────────────────
echo "[3/7] Stopping containers..."
docker compose down --remove-orphans 2>/dev/null || true

# ── [4] Rebuild backend + worker (BOTH must be rebuilt — separate images) ─────
echo "[4/7] Rebuilding backend + worker images (--no-cache)..."
echo "  This takes 3-8 minutes — installing Go tools..."
docker compose build --no-cache backend worker 2>&1 | tail -5
echo "  ✓ Images rebuilt"

# ── [5] Start all services ────────────────────────────────────
echo "[5/7] Starting services..."
docker compose up -d
echo "  ✓ Services started"

# ── [6] Wait for backend health ───────────────────────────────
echo "[6/7] Waiting for backend health (max 120s)..."
for i in $(seq 1 40); do
  sleep 3
  if curl -sf http://localhost:8000/health >/dev/null 2>&1; then
    echo "  ✓ Backend healthy after $((i*3))s"
    break
  fi
  [ $((i % 5)) -eq 0 ] && echo "  Still waiting... ($((i*3))s)"
  if [ $i -eq 40 ]; then
    echo "  ✗ Backend failed to start"
    docker compose logs backend --tail=30
    exit 1
  fi
done

# ── [7] End-to-end verification ───────────────────────────────
echo "[7/7] Running end-to-end verification..."

# CORS
echo -n "  CORS: "
CORS=$(curl -si -X OPTIONS http://localhost:8000/api/v1/workspaces \
  -H "Origin: http://76.13.30.226:3000" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: authorization,content-type" 2>/dev/null | \
  grep -i "access-control-allow-origin" | head -1 | tr -d '\r')
[ -n "$CORS" ] && echo "✓ $CORS" || echo "✗ MISSING — check BroadCORSMiddleware"

# Login
TOKEN=$(curl -sf -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" 2>/dev/null | \
  python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))" 2>/dev/null || echo "")
echo "  Login: $([ -n "$TOKEN" ] && echo '✓ Token obtained' || echo '✗ FAILED')"

# Workspace
WS=""
if [ -n "$TOKEN" ]; then
  WS_RESP=$(curl -sf -H "Authorization: Bearer $TOKEN" http://localhost:8000/api/v1/workspaces 2>/dev/null || echo "[]")
  WS=$(echo "$WS_RESP" | python3 -c "import sys,json; ws=json.load(sys.stdin); print(ws[0]['id'] if ws else '')" 2>/dev/null || echo "")
  echo "  Workspace: $([ -n "$WS" ] && echo "✓ ${WS:0:8}..." || echo '✗ None found — seed failed?')"
fi

# Launch scan
SCAN_ID=""
if [ -n "$TOKEN" ] && [ -n "$WS" ]; then
  SCAN_RESP=$(curl -sf -X POST http://localhost:8000/api/v1/scans \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"name\":\"VerifyScan\",\"workspace_id\":\"$WS\",\"scan_type\":\"recon\",\"target\":\"testphp.vulnweb.com\",\"config\":{\"domain\":\"testphp.vulnweb.com\"}}" 2>/dev/null || echo "{}")
  SCAN_ID=$(echo "$SCAN_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null || echo "")
  SCAN_ST=$(echo "$SCAN_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin).get('status','error'))" 2>/dev/null || echo "error")
  if [ -n "$SCAN_ID" ]; then
    echo "  Launch scan: ✓ id=${SCAN_ID:0:8}... status=$SCAN_ST"
  else
    echo "  Launch scan: ✗ FAILED"
    echo "  Response: $SCAN_RESP"
  fi
fi

# Worker check
FINAL_STATUS="not_tested"
if [ -n "$SCAN_ID" ]; then
  echo "  Waiting 25s for worker..."
  sleep 25
  FINAL_STATUS=$(curl -sf -H "Authorization: Bearer $TOKEN" \
    "http://localhost:8000/api/v1/scans/$SCAN_ID" 2>/dev/null | \
    python3 -c "import sys,json; print(json.load(sys.stdin).get('status','unknown'))" 2>/dev/null || echo "unknown")
  echo "  Scan status: $FINAL_STATUS"
fi

echo ""
docker compose ps
echo ""
echo "╔══════════════════════════════════════════════════════╗"
if echo "$FINAL_STATUS" | grep -qiE "^(running|completed)$"; then
  echo "║  ✓ SUCCESS — Platform is fully operational!          ║"
else
  echo "║  ⚠ Scan not yet running (status: $FINAL_STATUS)     ║"
  echo "║  Check: docker compose logs worker --tail=40         ║"
fi
echo "╠══════════════════════════════════════════════════════╣"
echo "║  URL:   http://76.13.30.226:3000                     ║"
echo "║  Login: admin@blackmirror.io                         ║"
echo "║  Pass:  BlackMirrorX2025!                            ║"
echo "╚══════════════════════════════════════════════════════╝"

if ! echo "$FINAL_STATUS" | grep -qiE "^(running|completed)$"; then
  echo ""
  echo "=== Worker logs ==="
  docker compose logs worker --tail=40
fi
