#!/usr/bin/env ruby

require 'socket'
require 'colorize'
require 'public_suffix' 
require 'optparse'
require 'uri/http'
require 'etc'

require_relative 'scripts/functions'

project = ""
domain = ""
workflow = ""
root_domain = ""
org_name = ""
all = ""

aws_path = ""
cors_path = ""
directory_path = ""
dns_path = ""
flash_path = ""
github_path = ""
info_path = ""
ip_path = ""
patterns_path = ""
portscan_path = ""
screenshot_path = ""
spf_path = ""
url_path = ""
js_path = ""
swf_path = ""
vhost_path = ""
waf_path = ""
asn_path = ""
wordlist_path = ""
sub_path = ""
scanners_path = ""

final_js = ""
final_swf = ""
final_urls = ""
final_params = ""
final_subdomains = ""
final_ips = ""
final_vhosts = ""
final_takeover = ""
final_cors = ""
final_directories = ""
final_dns = ""
final_waf = ""
final_masscan = ""
final_nmap = ""

burp_collaborator = ""
username = Etc.getlogin
home = "/home/"+username
banner = "logo.txt"

wordlist = ""
wordlist_vhost = ""
wordlist_dir_fuzz = ""
wordlist_passwd = ""
wordlist_aws = ""
github_wordlist = ""

threads = 1
known = ""

findomain_config =  ""
amass_config = ""

github_token = "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"
git_config = "#{home}/Desktop/recon/git-hound/config.yml"

wp_api_key = "DLla6sJd0aQ8hKiHPbcVdfOZxaMCsrw2H6LtMTEefuI"

censys_api_key = "c53f1bc7-2fe5-4468-b90c-952b22dc9a79"
censys_api_secret = "OhSIMBhQgjWrrfSilm7HKvxsCBSs9eJK"

cloudflare_token = "2e793f683bb26aabc067bb4132dba172c3b27"
cloudflare_email = "test@gmail.com"

nuclei_templates = "#{home}/Desktop/recon/nuclei-templates"

subjack_fingerprints = "#{home}/Desktop/recon/subjack/fingerprints.json"
tko_providers = "#{home}/Desktop/recon/tko-subs/providers-data.csv"

help_banner = "Vigilant 2.0 ( https://vigilant.com )\nUsage: vigilant [Options] -c [Company] -d <domain>\nvigilant.rb: error: the following arguments are required: -c/--company,-d/--domain"

class Parser
  def self.parse(args)
    options = {}
    help_banner = "Vigilant 2.0 ( https://vigilant.com )\nUsage: vigilant [Options] -c [Company] -d <domain>\n[Options]:\nNote: If no -w tag supplied will default to /usr/share/vigilant/subs.txt or\nthe subs.txt file in the same directory as vigilant.rb\nGENERAL OPTIONS"
    opts = OptionParser.new do |opts|
      opts.banner = "#{help_banner}"

      opts.on('-c', '--company string', 'Target company') do |company|
        options[:company] = company
      end

      opts.on('-d', '--domain string', 'Target domain/subdomain') do |domain|
        options[:domain] = domain
      end
      
      opts.on('-t','--threads int', 'Number of threads (default 25)') do |threads|
        options[:threads] = threads
      end 
      
      opts.on('--all', 'Do massive scans on all subdomains') do |all|
        options[:all] = all
      end 
      
      opts.separator "WORDLISTS"
      
      opts.on('--w-aws string', 'Wordlist for AWS S3 enumeration') do |wordlist_aws|
        options[:word_aws] = wordlist_aws
      end 
      
      opts.on('--w-github string', 'Wordlist for Github keywords') do |word_github|
        options[:word_github] = word_github
      end 
      
      opts.on('--w-vhost string', 'Wordlist for vhost bruteforce') do |word_vhost|
        options[:word_vhost] = word_vhost
      end 
      
      opts.on('--w-fuzz string', 'Wordlist for directory fuzzing') do |word_fuzz|
        options[:word_fuzz] = word_fuzz
      end 
      
      opts.on('--w-passwd string', 'Wordlist for password cracking') do |wordlist_passwd|
        options[:word_passwd] = wordlist_passwd
      end 
      
      opts.separator "DEFAULT RECON"
      
      opts.on('--enum', 'Full domain workflow') do |full_subenum|
        options[:full_subenum] = full_subenum
      end
      
      opts.on('--web-host', 'Full web host workflow') do |full_webhosts|
        options[:full_webhosts] = full_webhosts
      end
      
      opts.on('--endpoint', 'Full endpoint workflow') do |full_endpoints|
        options[:full_endpoints] = full_endpoints
      end
      
      opts.on('--exploit', 'Full exploit workflow') do |full_exploits|
        options[:full_exploits] = full_exploits
      end
      
      opts.on('--full', 'All workflows') do |all_workflow|
        options[:full] = all_workflow
      end
      
      opts.separator "SUBDOMAIN ENUMERATION"
      
      opts.on('-i','--info', 'WHOIS, ASN and DNS information') do |info|
        options[:info] = info
      end
      
      opts.on('-b','--brt', 'Subdomain bruteforce') do |bruteforce|
        options[:bruteforce] = bruteforce
      end
      
      opts.on('-g','--generate', 'Generate similar hosts using AltDNS') do |gen|
        options[:gen] = gen
      end
      
      opts.on('-v','--vhost', 'VHOST enumeration') do |vhost|
        options[:vhost] = vhost
      end
      
      opts.on('-p','--ports', 'Ports/Services scanning on hosts') do |ports|
        options[:ports] = ports
      end
      
      opts.on('-r','--resolve', 'Resolve IPs') do |resolve|
        options[:resolve] = resolve
      end
      
      #opts.on('--amass', 'Amass subdomains(slow)') do |amass|
      #  options[:amass] = amass
      #end
      
      opts.on('--dns', 'DNS enumeration') do |dns|
        options[:dns] = dns
      end
      
      opts.on('--takeover', 'Make subdomain takeover attempts') do |takeover|
        options[:takeover] = takeover
      end
      
      opts.on('--passive', 'Passive enumeration + Nuclei templates') do |passive|
        options[:passive] = passive
      end
      
      opts.separator "WEB SCANS"
      
      opts.on('--cors', 'CORS Scanner') do |cors|
        options[:cors] = cors
      end
      
      opts.on('--crlf', 'CRLF Scanner') do |crlf|
        options[:crlf] = crlf
      end
      
      opts.on('--visual', 'Web screenshot using Selenium/Aquatone') do |visual|
        options[:visual] = visual
      end
      
      opts.on('--ssrf', 'SSRF Scanner') do |ssrf|
        options[:ssrf] = ssrf
      end
      
      opts.on('--xss', 'XSS Scanner') do |xss|
        options[:xss] = xss
      end
      
      opts.on('--waf', 'WAF Scanner') do |waf|
        options[:waf] = waf
      end
      
      opts.on('--wapiti', 'Wapiti Automated Scanner') do |wapiti|
        options[:wapiti] = wapiti
      end
      
      #opts.on('--web', 'HTTP Scanner') do |http|
      #  options[:http] = http
      #end
     
      opts.separator "WEB EXPLOITS"
      
      #opts.on('-s','--shocker', 'Exploit servers vulnerable to Shellshock') do |shocker|
      #  options[:shocker] = shocker
      #end
      
      #opts.on('-y','--yasuo', 'Find vulnerable web applications') do |yasuo|
      #  options[:yasuo] = yasuo
      #end
      
      opts.on('--apache', 'Apache Struts CVE-2017-5638') do |apache|
        options[:apache] = apache
      end 
      
      opts.on('--changeme', 'Default credential scanner') do |changeme|
        options[:changeme] = changeme
      end 
      
      opts.on('--cmsmap', 'CMS scanner') do |cmsmap|
        options[:cmsmap] = cmsmap
      end
      
      opts.on('--wpscan', 'WordPress security scanner') do |wpscan|
        options[:wpscan] = wpscan
      end
      
      opts.on('--joom', 'Joom vulnerability scanner') do |joom|
        options[:joom] = joom
      end
      
      #opts.on('--zigoo', 'Exploit URL parameters') do |zigoo|
      #  options[:zigoo] = zigoo
      #end
      
      opts.separator "URL AND PARAMETER DISCOVERY"
      
      opts.on('--known', 'Gather URLs from known sources') do |known|
        options[:known] = known
      end
      
      opts.on('--broken', 'Find broken links') do |broken|
        options[:broken] = broken
      end
      
      opts.on('--spider', 'Web spider on endpoints') do |spider|
        options[:spider] = spider
      end
      
      opts.on('--params', 'Parameter discovery using Arjun') do |params|
        options[:params] = params
      end
      
      opts.separator "CONTENT DISCOVERY"
      
      opts.on('--aws', 'AWS S3 buckets enumeration') do |aws|
        options[:aws] = aws
      end
      
      opts.on('--dir', 'Directory fuzzing') do |dir|
        options[:dir] = dir
      end
      
      #opts.on('--file', 'File fuzzing') do |file|
      #  options[:file] = file
      #end
      
      opts.on('--github', 'Github secrets') do |github|
        options[:github] = github
      end
      
      opts.on('--js', 'Javascript research') do |js|
        options[:js] = js
      end
      
      #opts.on('--swf', 'SWF research') do |swf|
      #  options[:swf] = swf
      #end
      
      opts.separator "ENDPOINTS"
      
      opts.on('--backups', 'Backup file artifacts checker') do |backups|
        options[:backups] = backups
      end
      
      opts.on('--crossdomain', 'Find and exploit crossdomain.xml') do |crossdomain|
        options[:crossdomain] = crossdomain
      end
      
      opts.on('--denied', 'Access denied misconfigs') do |denied|
        options[:denied] = denied
      end
      
      opts.on('--nuclei', 'Nuclei full vulnerability scanner') do |nuclei|
        options[:nuclei] = nuclei
      end
      
    end

    begin
      opts.parse(args)
    rescue Exception => e
      exit 1
    end

    options
  end
end

options = Parser.parse(ARGV)

define_method :default_scan do 
  puts "#{'[i] Workflow: Default Scan'.magenta}"
  get_info()
  bruteforce_scan()
  exit
end

define_method :full_sub_enum do
  puts "#{'[i] Workflow: Domain'.magenta}"
  
  if all == true
    if File.file?("#{final_subdomains}")
    else
      #Silent scan for first time hosts
      system("sudo -u #{username} subfinder -d #{domain} -t #{threads} >> #{final_subdomains}")
    end
  end
  all = true
  get_info()
  bruteforce_scan()
  gau_scan()
  dir_fuzz_scan()
  dns_scan()
  visual_scan()
  subs_takeover()
  all = false
  patterns_scan()
  resolve_hosts()
  vhost_scan()
  ports_scan()
  github_scan()
  aws_scan()
  nuclei_scan()
  #zigoo_scan()
  waf_scan()
  cors_scan()
  crlf_scan()
  js_scan()
  #swf_scan()
  links_scan()
  spider_scan()
  xss_scan()
  ssrf_scan()
  access_denied_scan()
  crossdomain_scan()
  backups_scan()
  wapiti_scan()
  exit
end

define_method :full_web_hosts do
  puts "#{'[i] Workflow: Web Hosts'.magenta}"
  visual_scan()
  subs_takeover()
  waf_scan()
  cors_scan()
  gau_scan()
  js_scan()
  swf_scan()
  spider_scan()
  links_scan()
  dir_fuzz_scan()
  #files_fuzz_scan()
  xss_scan()
  ssrf_scan()
  crlf_scan()
  wapiti_scan()
  changeme_scan()
  wpscan_scan()
  cmsmap_scan()
  joom_scan()
end

define_method :full_endpoints do
  puts "#{'[i] Workflow: Endpoints'.magenta}"
  gau_scan()
  waf_scan()
  cors_scan()
  crlf_scan()
  js_scan()
  #swf_scan()
  links_scan()
  spider_scan()
  xss_scan()
  ssrf_scan()
  params_scan()
  apache_scan()
  access_denied_scan()
  crossdomain_scan()
  backups_scan()
  nuclei_scan()
end

define_method :full_exploits do
  puts "#{'[i] Workflow: Exploits'.magenta}"
  apache_scan()
  changeme_scan()
  wpscan_scan()
  cmsmap_scan()
  joom_scan()
end

define_method :all_workflows do
  puts "#{'[+] All Workflows Selected'.yellow}"
  full_sub_enum()
  full_exploits()
end

define_method :cron_save do
  puts "#{'[>] Cron Job'.green}"
  vigilant_path = "#{home}/Desktop/own_scripts/vigilant/vigilant.rb"
  cron_output = "/root/vigilant/cron_job"
  Cron.new.cron_save(vigilant_path,project,domain,cron_output,username,final_subdomains,home,github_wordlist)
  puts("#{'[*] Saved'.yellow}")
  puts
end

define_method :get_info do
  puts "#{'[>] General Research'.green}"
  sub_list = final_subdomains
  Get_Info.new.start(home,all,sub_list,info_path,spf_path,threads,final_js,final_swf,final_urls,domain,root_domain)
  puts("#{'[*] Final Report on '.yellow}#{info_path}".yellow)
  puts
end

define_method :amass_scan do
  output = "#{sub_path}/raw"
  sub_list = final_subdomains
  puts "#{'[>] Amass'.green}"
  Subdomain_Bruteforce.new.amass(username,domain,threads,workflow,root_domain,output,amass_config,wordlist,all)
  puts("#{'[*] Final Report on '.yellow}#{final_subdomains}".yellow)
  puts
end

define_method :bruteforce_scan do
  output = "#{sub_path}/raw"
  sub_list = "#{final_subdomains}" 
  resolvers = "#{home}/Desktop/recon/subbrute/resolvers.txt"
  puts "#{'[>] Subdomains Enumeration'.green}"
   Subdomain_Bruteforce.new.start(spf_path,final_subdomains,final_ips,sub_list,sub_path,username,domain,threads,workflow,root_domain,output,findomain_config,cloudflare_token,cloudflare_email,censys_api_key,censys_api_secret,wordlist,all,home,resolvers,amass_config)
  
  system("cat #{output}/*/subfinder.txt | anew -q #{final_subdomains}")
  
  puts("#{'[*] Final Report on '.yellow}#{final_subdomains}".yellow)
  puts
end

define_method :gau_scan do
  sub_list = "#{final_subdomains}" 
  puts "#{'[>] Known Sources'.green}"
  Known_URLs.new.start(aws_path,home,username,domain,threads,workflow,root_domain,all,sub_path,url_path,final_urls,final_js,final_swf,spf_path,final_subdomains,final_ips)
  puts("#{'[*] Final Report on '.yellow}#{final_urls}".yellow)
  puts
end

define_method:subs_takeover do
  puts "#{'[>] Subdomain Takeover'.green}"
  tko_result = "#{sub_path}/final-tko.txt"
  tmp = "#{sub_path}/final-takeover.tmp"
  Subdomain_Takeover.new.start(workflow,root_domain,threads,subjack_fingerprints,final_subdomains,tko_providers,final_takeover,tko_result,tmp)
  puts("#{'[*] Final Report on '.yellow}#{final_takeover}".yellow)
  puts
end

define_method:patterns_scan do
  altdns_location = "#{home}/Desktop/recon/altdns/altdns"
  puts "#{'[>] Subdomains Generation'.green}"
  Patterns.new.start(all,final_subdomains,domain,wordlist_path,altdns_location,wordlist,sub_path,threads)
  puts("#{'[*] Final Report on '.yellow}#{sub_path}/wl-subdomains.txt".yellow)
  puts
end

define_method:github_scan do
  puts "#{'[>] Github Workflow'.green}"
  secrets = "#{github_path}/secrets.txt"
  graber = "#{github_path}/graber.txt"
  session = "#{github_path}/gitrob.tmp"
  Github.new.start(github_token,org_name,secrets,threads,session,root_domain,graber,github_wordlist,home,all,final_subdomains,git_config,github_path,domain)
  
  puts("#{'[*] Final Report on '.yellow}#{github_path}".yellow)
  puts
end

define_method:aws_scan do
  puts "#{'[>] AWS S3 Enumeration'.green}"
  S3_Recon.new.start(org_name,wordlist_aws,final_subdomains,aws_path,threads,home)
  puts
end

define_method:dns_scan do
  puts "#{'[>] DNS Enumeration'.green}"
  Passive_DNS.new.start(all,final_subdomains,root_domain,wordlist,domain,threads,dns_path,final_ips,final_dns,workflow,aws_path)
  puts("#{'[*] Final Report on '.yellow}#{final_dns}".yellow)
  puts
end

define_method:vhost_scan do
  puts "#{'[>] VHOST Enumeration'.green}"
  VHost_Enumeration.new.start(all,final_subdomains,root_domain,threads,vhost_path,wordlist_vhost,final_vhosts,final_ips,domain)
  puts("#{'[*] Final Report on '.yellow}#{final_vhosts}".yellow)
  puts
end

define_method:ports_scan do
  puts "#{'[>] Ports/Services Enumeration'.green}"
  #Port_Scan.new.start(final_ips,final_masscan,portscan_path,home,final_subdomains,final_nmap)
  Port_Scan_New.new.start(portscan_path,home,final_subdomains,domain,all)
  puts("#{'[*] Final Report on '.yellow}#{portscan_path}/ports-scan.txt".yellow)
  puts
end

define_method:visual_scan do
  puts "#{'[>] Visual Recon'.green}"
  Visual.new.start(final_subdomains,final_urls,final_js,final_swf,threads,screenshot_path,org_name)
  puts("#{'[*] Final Report on '.yellow}#{screenshot_path}/aquatone/".yellow)
  puts
end

define_method:links_scan do
  puts "#{'[>] Broken Links'.green}"
  broken_links = "#{url_path}/links/broken-links.txt"
  Broken_Links.new.start(final_subdomains,final_urls,final_js,final_swf,broken_links,url_path,all,domain,root_domain,workflow,aws_path)
  puts("#{'[*] Final Report on '.yellow}#{broken_links}".yellow)
  puts
end

define_method:spider_scan do
  puts "#{'[>] Web Spider'.green}"
  Spider.new.start(final_urls,url_path,threads,root_domain,final_js,final_swf,final_subdomains)
  puts("#{'[*] Final Report on '.yellow}#{url_path}/spider".yellow)
  puts
end

define_method:params_scan do
  puts "#{'[>] Parameter Discovery'.green}"
  Params_Discovery.new.start(final_urls,threads,final_params)
  puts("#{'[*] Final Report on '.yellow}#{final_params}".yellow)
  puts
end

define_method:js_scan do
  puts "#{'[>] Filtering JS Files'.green}"
  secrets_output = "#{js_path}/js-secrets.txt"
  JS_Research.new.start(home,final_subdomains,final_js,secrets_output,js_path,final_urls,threads,root_domain,workflow)
  puts("#{'[*] Final Report on '.yellow}#{js_path}".yellow)
  puts
end

define_method:swf_scan do
  puts "#{'[>] Filtering SWF Files'.green}"
  SWF_Research.new.start(final_swf,swf_path,home,root_domain,final_urls,final_subdomains,workflow)
  puts("#{'[*] Final Report on '.yellow}#{swf_path}".yellow)
  puts
end

define_method:dir_fuzz_scan do
  puts "#{'[>] Web Fuzzing'.green}"
  sub_list = final_subdomains
  Directory_Fuzz.new.start(home,all,root_domain,sub_list,final_urls,final_directories,directory_path,wordlist_dir_fuzz,threads,domain)
  puts("#{'[*] Final Report on '.yellow}#{final_directories}".yellow)
  puts
end

define_method:files_fuzz_scan do
  puts "#{'[>] Web Fuzzing'.green}"
  sub_list = final_urls
  Files_Fuzz.new.start(all,root_domain,sub_list,final_urls,final_directories,directory_path,wordlist_dir_fuzz,threads,domain)
  puts("#{'[*] Final Report on '.yellow}#{final_directories}".yellow)
  puts
end

define_method:cors_scan do
  puts "#{'[>] CORS Enumeration'.green}"
  Cors.new.start(home,final_subdomains,threads,cors_path,final_cors,all,domain)
  puts("#{'[*] Final Report on '.yellow}#{final_cors}".yellow)
  puts
end

define_method :waf_scan do
  puts "#{'[>] WAF Scanner'.green}"
  Wafw00f.new.start(all,final_subdomains,waf_path,domain,final_waf)
  puts("#{'[*] Final Report on '.yellow}#{final_waf}".yellow)
  puts
end

define_method:http_scan do
  puts "#{'[>] HTTP Enumeration'.green}"
  raw = "#{sub_path}/online-subdomains.raw"
  Httprobe.new.start(final_subdomains,final_ips,final_vhosts,final_urls,workflow,root_domain,raw)
  puts("#{'[*] Final Report on '.yellow}#{final_urls}".yellow)
  puts
end

define_method :resolve_hosts do
  puts "#{'[>] Resolve IPs'.green}"
  resolvers = "#{home}/Desktop/recon/massdns/lists/resolvers.txt"
  Resolve_Hosts.new.start(resolvers,final_subdomains,final_ips,wordlist_path,sub_path,ip_path,home)
  puts("#{'[*] Final Report on '.yellow}#{final_ips}".yellow)
  puts
end

define_method :zigoo_scan do
  puts "#{'[>] Zigoo0 Scanner'.green}"
  Zigoo.new.start(home,scanners_path,final_urls)
  puts("#{'[*] Final Report on '.yellow}#{scanners_path}/zigoo".yellow)
  puts
end

define_method:shocker_scan do
  puts "#{'[>] Web Exploit: Shocker'.green}"
  Shocker.new.start(all,home,final_subdomains,threads,domain,scanners_path)
  puts("#{'[*] Final Report on '.yellow}#{scanners_path}/shocker/vulnerable.txt".yellow)
  puts
end

define_method:yasuo_scan do
  puts "#{'[>] Web Exploit: Yasuo'.green}"
  Yasuo.new.start(home,all,final_subdomains,threads,domain,scanners_path)
  puts("#{'[*] Final Report on '.yellow}#{scanners_path}/yasuo".yellow)
  puts
end

define_method:changeme_scan do
  puts "#{'[>] Web Exploit: Changeme'.green}"
  Changeme_Scan.new.start(home,all,domain,root_domain,final_subdomains,scanners_path,threads)
  puts("#{'[*] Final Report on '.yellow}#{scanners_path}/changeme".yellow)
  puts
end

define_method:apache_scan do
  puts "#{'[*] Web Exploit: Apache Struts CVE-2017-5638'.green}"
  output = "#{url_path}/apache/vulnerable.txt"
  Apache_Scan.new.start(all,home,url_path,final_directories,output,domain)
  puts("#{'[*] Final Report on '.yellow}#{output}".yellow)
  puts
end

define_method:wp_scan do
  puts "#{'[>] Web Exploit: WPScan'.green}"
  WPScan.new.start(all,final_subdomains,root_domain,scanners_path,wp_api_key,wordlist,threads,domain)
  puts("#{'[*] Final Report on '.yellow}#{scanners_path}/wpscan".yellow)
  puts
end

define_method:cmsmap_scan do
  puts "#{'[>] Web Exploit: CMSMap'.green}"
  output = "#{portscan_path}/web/cmsmap/all.txt"
  CMSMap.new.start(home,all,domain,root_domain,final_subdomains,sub_path,scanners_path,output,threads,scanners_path)
  puts("#{'[*] Final Report on '.yellow}#{scanners_path}/cmsmap".yellow)
  puts
end

define_method:joom_scan do
  puts "#{'[>] Web Exploit: JoomScan'.green}"
  output = "/usr/share/joomscan/reports"
  Joomla.new.start(home,all,domain,final_subdomains,root_domain,output,scanners_path,url_path)
  puts("#{'[*] Final Report on '.yellow}#{output}".yellow)
  puts
end

define_method:crlf_scan do
  puts "#{'[>] CRLF Scanner'.green}"
  final_crlf = "#{url_path}/crlf/final-crlf.txt"
  CRLFScanner.new.start(final_subdomains,final_crlf,all,root_domain,url_path,domain)
  puts("#{'[*] Final Report on '.yellow}#{final_crlf}".yellow)
  puts
end

define_method:ssrf_scan do
  puts "#{'[>] SSRF Scanner'.green}"
  urls = "#{url_path}/vulnerable/ssrf/urls.txt"
  SSRFScanner.new.start(home,threads,urls,url_path,burp_collaborator)
  puts("#{'[*] Final Report on '.yellow}#{urls}".yellow)
  puts
end

define_method:xss_scan do
  puts "#{'[>] XSS Scanner'.green}"
  output = "#{url_path}/xss.txt"
  urls = "#{url_path}/vulnerable/xss/urls.txt"
  XSScanner.new.start(urls,output)
  puts("#{'[*] Final Report on '.yellow}#{output}".yellow)
  puts
end

define_method:access_denied_scan do
  puts "#{'[>] Bypass Access Restriction'.green}"
  ip_ranges = "192.168.0.0-192.168.255.255"
  sub_list = "#{url_path}/access-denied/endpoints.txt"
  enumxff_out = "#{url_path}/access-denied/ip-bypass.txt"
  Access_Denied.new.start(home,workflow,root_domain,final_subdomains,url_path,ip_ranges,enumxff_out,threads,domain)
  puts("#{'[*] Final Report on '.yellow}#{url_path}/access-denied/".yellow)
  puts
end

define_method:wapiti_scan do
  puts "#{'[>] Web Automated Scanner'.green}"
  Wapiti.new.start(all,final_subdomains,scanners_path,domain)
  puts("#{'[*] Final Report on '.yellow}#{scanners_path}/wapiti".yellow)
  puts
end

define_method:passive_scan do
  puts "#{'[>] Passive Scan'.green}"
  Subdomain_Bruteforce.new.passive(domain,home)
  puts
end

define_method:nuclei_scan do
  puts "#{'[>] Nuclei'.green}"
  output = "#{scanners_path}/nuclei/all.txt"
  Nuclei.new.start(all,final_urls,nuclei_templates,output,scanners_path,domain)
  puts("#{'[*] Final Report on '.yellow}#{scanners_path}/nuclei/".yellow)
  puts
end

define_method:backups_scan do
  puts "#{'[>] Backup File Artifacts Checker'.green}"
  tmp = "#{url_path}/backups/scan.tmp"
  git_path = "#{url_path}/backups/git"
  svn_path = "#{url_path}/backups/svn"
  git_output = "#{url_path}/backups/git.txt"
  svn_output = "#{url_path}/backups/svn.txt"
  output = "#{url_path}/backups/final-backups.txt"
  git_endpoints = git_output
  svn_endpoints = svn_output

  system("touch #{git_endpoints}")
  system("touch #{svn_endpoints}")
  Backup_Checker.new.start(home,git_endpoints,svn_endpoints,git_path,svn_path,all,final_directories,root_domain,git_output,svn_output,output,domain,tmp,threads)
  puts("#{'[*] Final Report on '.yellow}#{output}".yellow)
  puts
end

define_method:crossdomain_scan do
  puts "#{'[>] Exploitation: crossdomain.xml'.green}"
  puts "#{'[*] Searching...'.light_blue}"
  
  urls = "#{url_path}/crossdomain/urls.txt"
  resolvers = "#{home}/Desktop/recon/subbrute/resolvers.txt"
  output = "#{sub_path}/crossdomain"
  
  final_takeover = "#{url_path}/crossdomain/final-takeover.txt"
  tko_result = "#{url_path}/crossdomain/final-tko.txt"
  tmp_takeover = "#{url_path}/crossdomain/final-takeover.tmp"
  Crossdomain.new.start(final_takeover,subjack_fingerprints,tko_providers,tko_result,tmp_takeover,spf_path,final_subdomains,final_ips,final_urls,urls,url_path,sub_path,username,domain,threads,workflow,root_domain,output,findomain_config,cloudflare_token,cloudflare_email,censys_api_key,censys_api_secret,wordlist,all,home,resolvers,amass_config)
  puts("#{'[*] Final Report on '.yellow}#{url_path}/crossdomain".yellow)
  puts
end

define_method :check_parameter do
  unless !options[:resolve] && !options[:brt] && !options[:gen] && !options[:ports] && !options[:dns] && !options[:takeover] && !options[:vhost] && !options[:github] && !options[:full_subenum] && !options[:spider] && !options[:visual] && !options[:params] && !options[:js] && !options[:known] && !options[:cors] && !options[:visual] && !options[:xss] && !options[:waf] && !options[:wapiti] && !options[:web] && !options[:shocker] && !options[:yasuo] && !options[:apache] && !options[:changeme] && !options[:cmsmap] && !options[:wpscan] && !options[:joom] && !options[:visual] && !options[:broken] && !options[:aws] && !options[:dir] && !options[:file] && !options[:swf] && !options[:backups] && !options[:crossdomain] && !options[:denied] && !options[:nuclei] && !options[:info]
  else
    default_scan()
  end
end

define_method :default_content do

  ##Default Content
  system("mkdir -p #{workflow} #{workflow}/#{root_domain} #{scanners_path}/nuclei #{scanners_path}/wpscan #{scanners_path}/cmsmap #{scanners_path}/joom #{scanners_path}/yasuo #{scanners_path}/zigoo #{scanners_path}/shocker #{scanners_path}/changeme #{scanners_path}/wapiti #{info_path}/dns #{info_path}/whois #{info_path}/asn #{dns_path} #{dns_path}/raw #{spf_path} #{waf_path} #{cors_path} #{github_path} #{aws_path} #{github_path}/repos #{info_path} #{vhost_path} #{vhost_path}/raw #{sub_path} #{sub_path}/raw #{sub_path}/raw/#{domain} #{sub_path}/patterns #{sub_path}/patterns/altdns #{sub_path}/patterns/dnsgen #{ip_path} #{js_path} #{js_path}/js_collector #{js_path} #{swf_path} #{swf_path}/decompress #{swf_path}/source #{js_path}/source #{js_path}/old-js #{url_path} #{url_path}/apache #{url_path}/crlf #{url_path}/links #{url_path}/vulnerable #{url_path}/backups #{url_path}/backups/git #{url_path}/backups/svn #{url_path}/access-denied #{url_path}/crossdomain #{url_path}/crossdomain/data #{portscan_path} #{screenshot_path} #{screenshot_path}/aquatone #{directory_path} #{directory_path}/dirsearch #{directory_path}/dirsearch/dir #{wordlist_path} #{wordlist_path}/patterns/altdns #{wordlist_path}/patterns/dnsgen #{wordlist_path}/subdomain #{wordlist_path}/aws #{sub_path}/crossdomain #{github_path}/secrets #{github_path}/dorks #{url_path}/vulnerable/ssrf #{url_path}/vulnerable/sqli #{url_path}/vulnerable/xss #{url_path}/vulnerable/lfi #{url_path}/vulnerable/idor #{url_path}/vulnerable/redirect #{url_path}/vulnerable/rce #{url_path}/wayback")

  system("echo \"#{domain}\" | sort -u | anew -q #{workflow}/subs.scanned && touch #{workflow}/out_of_scope")
end

define_method :start_job do
  unless options[:company] and options[:domain]
     help_banner()
     exit
  end
  
  project = "#{options[:company]}"
  domain = "#{options[:domain]}"
  
  root_domain = PublicSuffix.domain(domain)
  org_name = root_domain.split(/\s*\.\s*/)[0]
  workflow = "/root/vigilant/#{project}"
  wordlist_path = "#{workflow}/#{root_domain}/wordlist"
  sub_path = "#{workflow}/#{root_domain}/subdomain"
  aws_path = "#{workflow}/#{root_domain}/aws"
  cors_path = "#{workflow}/#{root_domain}/cors"
  directory_path = "#{workflow}/#{root_domain}/directory"
  dns_path = "#{workflow}/#{root_domain}/dns"
  flash_path = "#{workflow}/#{root_domain}/flash"
  github_path = "#{workflow}/#{root_domain}/github"
  info_path = "#{workflow}/#{root_domain}/info"
  ip_path = "#{workflow}/#{root_domain}/ip"
  patterns_path = "#{workflow}/#{root_domain}/patterns"
  portscan_path = "#{workflow}/#{root_domain}/portscan"
  screenshot_path = "#{workflow}/#{root_domain}/screenshot"
  spf_path = "#{workflow}/#{root_domain}/spf_record"
  url_path = "#{workflow}/#{root_domain}/url"
  js_path = "#{workflow}/#{root_domain}/js"
  swf_path = "#{workflow}/#{root_domain}/swf"
  vhost_path = "#{workflow}/#{root_domain}/vhost"
  waf_path = "#{workflow}/#{root_domain}/waf"
  asn_path = "#{workflow}/#{root_domain}/asn"
  scanners_path = "#{workflow}/#{root_domain}/automation_scanners"
  
  findomain_config = "#{home}/Desktop/workflows/api_keys.ini"
  amass_config = "/root/amass/config"
  
  final_urls = "#{url_path}/final-urls.txt"
  final_js = "#{js_path}/final-js.txt"
  final_swf = "#{swf_path}/final-swf.txt"
  final_params = "#{url_path}/final-params.txt"
  final_subdomains = "#{sub_path}/final-subdomains.txt"
  final_takeover = "#{sub_path}/final-takeover.txt"
  final_ips = "#{ip_path}/final-ips.txt"
  final_vhosts = "#{vhost_path}/final-vhosts.txt"
  final_cors = "#{cors_path}/final-cors.txt"
  final_directories = "#{directory_path}/final-directories.txt"
  final_dns = "#{dns_path}/final-dns.txt"
  final_waf = "#{waf_path}/final-wafs.txt"
  final_masscan = "#{portscan_path}/final-masscan.html"
  final_nmap = "#{portscan_path}/final-nmap.html"
  
  wordlist = options[:word]
  wordlist_vhost = options[:word_vhost]
  wordlist_passwd = options[:word_passwd]
  wordlist_dir_fuzz = options[:word_fuzz]
  wordlist_aws = options[:word_aws]
  github_wordlist = options[:word_github]
  
  threads = options[:threads]
  burp_collaborator = options[:burp]
  all = options[:all]
  
  default_content() 
  
  system("touch #{final_urls}")
  system("touch #{final_subdomains}")
  system("touch #{final_directories}")
  system("echo \"#{domain}\" | anew -q #{final_subdomains}")
  system("echo \"https://#{domain}\" | anew -q #{final_urls}")
  system("echo \"https://#{domain}/\" | anew -q #{final_directories}")
  if File.file?(final_subdomains)
    system("cat #{final_subdomains} | grep -v #{root_domain} | grep -v amazonaws.com | anew -q #{workflow}/root-domains.txt")
    system("cat #{final_subdomains} | grep amazonaws.com | sed 's/\\\.amazonaws.com//' | anew -q #{aws_path}/s3-buckets.txt")
  end
  
  unless options[:all]
    all = "false"
  end
  
  unless options[:burp]
    burp_collaborator = "8tr2ssgl9jefe7hekdfrnjoni.canarytokens.com" 
  end
  
  unless options[:word_vhost]
    wordlist_vhost = "#{home}/Desktop/recon/SecLists/Discovery/DNS/subdomains-top1million-5000.txt"
  end
  
  unless options[:word_fuzz]
    if options[:dir] == true
      wordlist_dir_fuzz = "#{home}/Desktop/recon/SecLists/Discovery/KaliLists/dirbuster/directory-list-2.3-small.txt"
      wordlist_dir_fuzz = "#{home}/Desktop/recon/SecLists/Discovery/Web-Content/raft-medium-directories.txt"
    else
      wordlist_dir_fuzz = "#{home}/Desktop/recon/SecLists/Discovery/Web-Content/raft-large-files.txt"
    end
  end
  
  unless options[:word_passwd]
    wordlist_passwd = "#{home}/Desktop/recon/SecLists/Passwords/Common-Credentials/10-million-password-list-top-1000.txt"
  end
  
  unless options[:word_aws]
    wordlist_aws = "#{home}/Desktop/recon/aws-s3-bucket-wordlist/list.txt"
  end
  
  unless options[:word_github]
    github_wordlist = "#{home}/Desktop/recon/gitGraber/wordlists/keywords.txt"
  end
  
  unless options[:word]
    wordlist = "#{home}/Desktop/recon/SecLists/Discovery/DNS/subdomains-top1million-110000.txt"
    #wordlist = "/usr/share/vigilant/subs.txt"
  end
  
  
  if File.file?(wordlist)
  else
      puts("#{'[!] Please insert a valid wordlist!'}".yellow)
      puts
      exit
  end
  
  if File.file?(wordlist_aws)
  else
        puts("#{'[!] Please insert a valid wordlist!'}".yellow)
        puts
        exit
  end
  
  if File.file?(wordlist_dir_fuzz)
  else
        puts("#{'[!] Please insert a valid wordlist!'}".yellow)
        puts
        exit
  end
  
  if File.file?(wordlist_passwd)
  else
        puts("#{'[!] Please insert a valid wordlist!'}".yellow)
        puts
        exit
  end
  
  unless options[:threads]
    threads = 25
  else
    check_parameter()
  end
  
  unless options[:word]
  else
    check_parameter()
  end 
  
  puts("#{'[+] Target : '.cyan}"+domain.cyan)
  
  if ARGV.length == 4
    default_scan()
  end
  
  if options[:full] == true
     all_workflows()
  end
  
  if options[:full_subenum] == true
     full_sub_enum()
  end
  
  if options[:full_webhosts] == true
     full_web_hosts()
  end
  
  if options[:full_endpoints] == true
     full_endpoints()
  end
  
  if options[:full_exploits] == true
     full_exploits()
  end
  
  if options[:cron] == true
     cron_save()
  end
  
  if options[:amass] == true
     amass_scan()
  end
  
  if options[:bruteforce] == true
     bruteforce_scan()
  end
  
  if options[:known] == true
     sub_list = "#{final_subdomains}"
     gau_scan()
  end
  
  if options[:info] == true
     get_info()
  end
  
  if options[:params] == true
     params_scan()
  end
  
  if options[:takeover] == true
     subs_takeover()
  end
  
  if options[:gen] == true
     patterns_scan()
  end
  
  if options[:resolve] == true
     resolve_hosts()
  end
  
  if options[:dns] == true
     dns_scan()
  end
  
  if options[:vhost] == true
     vhost_scan()
  end
  
  if options[:ports] == true
     ports_scan()
  end
  
  if options[:aws] == true
     aws_scan()
  end
  
  if options[:github] == true
     threads=10
     github_scan()
  end
  
  if options[:visual] == true
     visual_scan()
  end
  
  if options[:broken] == true
     links_scan()
  end
  
  if options[:spider] == true
     spider_scan()
  end
  
  if options[:js] == true
     js_scan()
  end
  
  #if options[:swf] == true
  #   swf_scan()
  #end
  
  if options[:dir] == true
     dir_fuzz_scan()
  end
  
  if options[:file] == true
     files_fuzz_scan()
  end
  
  if options[:cors] == true
     cors_scan()
  end
  
  if options[:http] == true
     http_scan()
  end
  
  if options[:waf] == true
     waf_scan()
  end
  
  if options[:yasuo] == true
     yasuo_scan()
  end
  
  if options[:shocker] == true
     shocker_scan()
  end
  
  if options[:changeme] == true
     changeme_scan()
  end
  
  if options[:nuclei] == true
     nuclei_scan()
  end
  
  if options[:apache] == true
     apache_scan()
  end
  
  if options[:wpscan] == true
     wp_scan()
  end
  
  if options[:cmsmap] == true
     cmsmap_scan()
  end
  
  if options[:joom] == true
     joom_scan()
  end
  
  #if options[:zigoo] == true
  #   zigoo_scan()
  #end
  
  if options[:crlf] == true
     crlf_scan()
  end
  
  if options[:xss] == true
     xss_scan()
  end
  
  if options[:ssrf] == true
     ssrf_scan()
  end
  
  if options[:denied] == true
     access_denied_scan()
  end
  
  if options[:wapiti] == true
     wapiti_scan()
  end
  
  if options[:crossdomain] == true
     crossdomain_scan()
  end
  
  if options[:backups] == true
     backups_scan()
  end
  
  if options[:passive] == true
     passive_scan()
  end
end

define_method :help_banner do
   puts "#{help_banner}"
end

begin
   
rescue
   help_banner()
   exit
end
  puts 
  puts
  system("cat #{banner} | lolcat") 
  puts("    #{'v2.0'.red} #{'by Santiago Lopez - AKA @try_to_hack'.red}")
  puts
  puts
  
  start_job()
