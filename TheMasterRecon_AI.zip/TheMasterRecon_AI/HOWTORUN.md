# TheMasterRecon AI v3.0 — How to Run

## Quick Start (30 seconds)

```bash
cd bugscan_work/
./start.sh
```

Then open: **http://127.0.0.1:9865**  
Login: `admin` / `TheMasterRecon2024!`

---

## First Time Setup

### 1. Install Python dependencies (if needed)
```bash
pip install flask flask-cors requests dnspython --break-system-packages
```

### 2. Install secret scanning tools (RECOMMENDED)
```bash
# All-in-one (run as root or with sudo)
./install_all_tools.sh

# Or individually:
pip install detect-secrets trufflehog --break-system-packages
go install github.com/gitleaks/gitleaks/v8@latest
```

### 3. SecretHunter binary (OPTIONAL — no key needed)
```bash
# Copy the binary to the app folder (license bypass is built in)
cp /wherever/secret_hunter ./secret_hunter
chmod +x ./secret_hunter
# Restart the app — it detects the binary automatically
```

### 4. Set AI key (OPTIONAL — for AI features)
```bash
# Edit .env file:
ANTHROPIC_API_KEY=sk-ant-api03-...
```

---

## Port Configuration

Default port: **9865**

Change it in `.env`:
```bash
PORT=8080
```

Or run on a specific port:
```bash
PORT=7777 ./start.sh
```

---

## Run as Background Service

```bash
# Screen (recommended)
screen -S tmr
./start.sh
# Detach: Ctrl+A, D
# Reattach: screen -r tmr

# Or nohup
nohup ./start.sh > app.log 2>&1 &
echo $! > app.pid

# Stop
kill $(cat app.pid)
```

---

## Secret Scanning — Elite Pipeline

### What's active (no tools needed):
- **Built-in**: 65+ regex patterns — AWS, GitHub, Stripe, JWT, private keys, etc.
- **SecretHunter**: Copy binary → `no key needed` (license bypass built in)

### Install for maximum coverage:
```bash
pip install detect-secrets trufflehog --break-system-packages
go install github.com/gitleaks/gitleaks/v8@latest
```

### Elite pipeline (what the app runs automatically):
```
JS file → [built-in 65 patterns] + [detect-secrets] + [trufflehog] + [gitleaks] → deduplicated findings
```

### Manual scan via API:
```bash
# Scan all JS on a domain
curl -X POST http://localhost:9865/secrets/scan_domain \
  -H "Content-Type: application/json" \
  -d '{"domain":"target.com"}'

# Scan a specific JS file
curl -X POST http://localhost:9865/secrets/scan_url \
  -H "Content-Type: application/json" \
  -d '{"url":"https://target.com/app.js","domain":"target.com"}'

# Scan a git repo (finds secrets in history)
curl -X POST http://localhost:9865/secrets/scan_git \
  -H "Content-Type: application/json" \
  -d '{"repo":"https://github.com/target/repo","domain":"target.com"}'

# Check engine status
curl http://localhost:9865/secrets/engine_status
```

---

## Key Endpoints

| URL | What it does |
|-----|-------------|
| `http://localhost:9865/` | Main app UI |
| `http://localhost:9865/api/health` | Health check + tool status |
| `http://localhost:9865/secrets/engine_status` | Secret scanning tools |
| `http://localhost:9865/tools/status` | All 37 tools status |
| `http://localhost:9865/nuclei/status` | Nuclei template count |

---

## Troubleshooting

**"Port already in use"**
```bash
PORT=8080 ./start.sh
# or kill whatever's on 9865:
kill $(lsof -ti:9865)
```

**"Module not found"**
```bash
pip install flask flask-cors requests --break-system-packages
```

**Scan button does nothing**
- Check browser console (F12) for JS errors
- Clear browser cache and reload
- Make sure you're logged in (admin / TheMasterRecon2024!)

**/ends takes 60 seconds**
- Fixed in this version via SQLite busy_timeout + ETag caching
- If still slow: the DB may be large, add `&limit=500` to reduce load

**SecretHunter shows "missing"**
- Copy the binary: `cp /path/to/secret_hunter ./secret_hunter && chmod +x ./secret_hunter`
- No license key needed — bypass is built in automatically

---

## Docker (alternative)
```bash
docker build -t thsmasterrecon .
docker run -p 9865:9865 -e PORT=9865 thsmasterrecon
```
