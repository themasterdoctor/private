#!/bin/bash
# Install ghauri, sublist3r, crawl4ai properly on Kali
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { echo -e "${GREEN}  ✔ $1${NC}"; }
warn() { echo -e "${YELLOW}  ⚠ $1${NC}"; }
fail() { echo -e "${RED}  ✗ $1${NC}"; }

echo ""
echo "  Installing missing tools"
echo "══════════════════════════════════════════════════════"

# ── ghauri ────────────────────────────────────────────────
echo ""
echo "[*] ghauri (advanced SQLi with WAF bypass)..."
if command -v ghauri >/dev/null 2>&1; then
    ok "ghauri (already installed: $(ghauri --version 2>/dev/null | head -1))"
else
    # Try pip first
    pip3 install ghauri --break-system-packages -q 2>/dev/null
    if ! command -v ghauri >/dev/null 2>&1; then
        # Try from source
        pip3 install git+https://github.com/r0oth3x49/ghauri.git \
            --break-system-packages -q 2>/dev/null
    fi
    # Symlink from all common pip locations
    for bin_path in \
        "$HOME/.local/bin/ghauri" \
        "/usr/local/lib/python3.13/dist-packages/bin/ghauri" \
        "/usr/local/lib/python3.12/dist-packages/bin/ghauri"; do
        if [ -f "$bin_path" ]; then
            sudo ln -sf "$bin_path" /usr/local/bin/ghauri 2>/dev/null
            break
        fi
    done
    # Last resort: find it anywhere
    if ! command -v ghauri >/dev/null 2>&1; then
        found=$(find / -name "ghauri" -type f 2>/dev/null | grep -v __pycache__ | head -1)
        [ -n "$found" ] && sudo ln -sf "$found" /usr/local/bin/ghauri 2>/dev/null
    fi
    command -v ghauri >/dev/null 2>&1 && ok "ghauri installed" || fail "ghauri — try: pip3 install ghauri --break-system-packages"
fi

# ── sublist3r ─────────────────────────────────────────────
echo ""
echo "[*] sublist3r (passive subdomain enum)..."
if command -v sublist3r >/dev/null 2>&1; then
    ok "sublist3r (already in PATH)"
else
    pip3 install sublist3r --break-system-packages -q 2>/dev/null
    # Symlink
    for bin_path in \
        "$HOME/.local/bin/sublist3r" \
        "/usr/local/bin/sublist3r" \
        "/usr/bin/sublist3r"; do
        if [ -f "$bin_path" ]; then
            sudo ln -sf "$bin_path" /usr/local/bin/sublist3r 2>/dev/null && break
        fi
    done
    # Find anywhere
    if ! command -v sublist3r >/dev/null 2>&1; then
        found=$(find / -name "sublist3r" -type f 2>/dev/null | grep -v __pycache__ | head -1)
        [ -n "$found" ] && sudo ln -sf "$found" /usr/local/bin/sublist3r 2>/dev/null
    fi
    command -v sublist3r >/dev/null 2>&1 && ok "sublist3r installed" || fail "sublist3r"
fi
# Note about DNSdumpster crash (known bug, not our problem)
warn "sublist3r DNSdumpster engine is broken upstream (CSRF token changed)"
warn "All other engines (crt.sh, virustotal, etc.) still work fine — ignore the crash"

# ── crawl4ai ──────────────────────────────────────────────
echo ""
echo "[*] crawl4ai (AI-powered web crawler)..."
if python3 -c "import crawl4ai" 2>/dev/null; then
    ok "crawl4ai (already installed)"
else
    pip3 install crawl4ai --break-system-packages -q 2>/dev/null
    if python3 -c "import crawl4ai" 2>/dev/null; then
        ok "crawl4ai installed (library only)"
        warn "Skipping crawl4ai-setup (Playwright browser install)"
        warn "To enable full browser crawling later: sudo crawl4ai-setup"
        warn "Without setup: crawl4ai works in basic HTTP mode (no JS rendering)"
    else
        fail "crawl4ai — manual: pip3 install crawl4ai --break-system-packages"
    fi
fi

# ── verify PATH ───────────────────────────────────────────
echo ""
echo "══════════════════════════════════════════════════════"
echo "  Results:"
for tool in ghauri sublist3r; do
    if command -v "$tool" >/dev/null 2>&1; then
        echo -e "${GREEN}  ✔ $tool → $(which $tool)${NC}"
    else
        echo -e "${RED}  ✗ $tool — not in PATH${NC}"
        echo "    Fix: sudo ln -sf \$(find ~/.local/bin /usr/local/lib -name $tool 2>/dev/null | head -1) /usr/local/bin/$tool"
    fi
done
python3 -c "import crawl4ai" 2>/dev/null && \
    echo -e "${GREEN}  ✔ crawl4ai (Python library)${NC}" || \
    echo -e "${RED}  ✗ crawl4ai${NC}"

echo ""
echo "  Test ghauri:"
echo "    ghauri -u 'https://target.com/page?id=1' --dbs --batch"
echo ""
echo "  Test sublist3r (DNSdumpster crash is harmless):"
echo "    sublist3r -d example.com -t 10 -e crtsh,virustotal"
echo ""
echo "  Test crawl4ai:"
echo "    python3 -c \"from crawl4ai import WebCrawler; print('OK')\""
