#!/usr/bin/env python3
"""
Migrate existing JSON storage to SQLite.
Run once: python3 migrate_to_sqlite.py
"""
import sys, os, json
from pathlib import Path

sys.path.insert(0, '.')

data_dir = os.environ.get("TMR_DATA_DIR", "./data")
print(f"Migrating {data_dir} to SQLite...")

from engine.storage_sqlite import StorageSQLite
sqlite_db = StorageSQLite(data_dir)

# Walk existing JSON data dirs
from storage import Storage
json_db = Storage(data_dir)

domains = json_db.list_domains()
print(f"Found {len(domains)} domains to migrate")

for domain in domains:
    print(f"\n  Migrating {domain}...")
    
    # Subdomains
    try:
        subs = json_db.get_subs(domain) if hasattr(json_db,'get_subs') else []
        for s in subs:
            sqlite_db.add_sub(domain, s)
        print(f"    Subs: {len(subs)}")
    except Exception as e:
        print(f"    Subs error: {e}")
    
    # Endpoints
    try:
        ends = json_db.get_endpoints(domain, limit=50000)
        for e in ends:
            sqlite_db.add_endpoint(domain, e)
        print(f"    Endpoints: {len(ends)}")
    except Exception as e:
        print(f"    Endpoints error: {e}")
    
    # Findings
    try:
        dd = json_db._dd(domain)
        fp = dd / "findings.json"
        if fp.exists():
            finds = json.loads(fp.read_text())
            for f in finds:
                sqlite_db.add_finding(domain, f)
            print(f"    Findings: {len(finds)}")
    except Exception as e:
        print(f"    Findings error: {e}")

print(f"\nMigration complete! SQLite: {data_dir}/bugscan.db")
print("To use SQLite, set USE_SQLITE=true in .env")
