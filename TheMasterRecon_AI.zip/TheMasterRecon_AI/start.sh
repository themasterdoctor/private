#!/usr/bin/env bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Load .env safely
if [ -f "$DIR/.env" ]; then
    while IFS='=' read -r key value; do
        [[ "$key" =~ ^[[:space:]]*# ]] && continue
        [[ -z "$key" ]] && continue
        value="${value%%#*}"
        key="${key// /}"
        value="${value# }"; value="${value% }"
        if [[ "$key" =~ ^[a-zA-Z_][a-zA-Z0-9_]*$ ]] && [[ -n "$value" ]]; then
            export "$key=$value"
        fi
    done < "$DIR/.env"
fi

export PATH="$PATH:$HOME/go/bin:/home/kali/go/bin:/root/go/bin:/usr/local/bin"

echo ""
echo "  ████████╗██╗  ██╗███████╗███╗   ███╗ █████╗ ███████╗████████╗███████╗██████╗ "
echo "     ██╔══╝██║  ██║██╔════╝████╗ ████║██╔══██╗██╔════╝╚══██╔══╝██╔════╝██╔══██╗"
echo "     ██║   ███████║█████╗  ██╔████╔██║███████║███████╗   ██║   █████╗  ██████╔╝"
echo "     ██║   ██╔══██║██╔══╝  ██║╚██╔╝██║██╔══██║╚════██║   ██║   ██╔══╝  ██╔══██╗"
echo "     ██║   ██║  ██║███████╗██║ ╚═╝ ██║██║  ██║███████║   ██║   ███████╗██║  ██║"
echo "     ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═╝"
echo ""
echo "  ██████╗ ███████╗ ██████╗ ██████╗ ███╗   ██╗    ⭐  AI Edition v3.0  ⭐"
echo "  ██╔══██╗██╔════╝██╔════╝██╔═══██╗████╗  ██║"
echo "  ██████╔╝█████╗  ██║     ██║   ██║██╔██╗ ██║"
echo "  ██╔══██╗██╔══╝  ██║     ██║   ██║██║╚██╗██║"
echo "  ██║  ██║███████╗╚██████╗╚██████╔╝██║ ╚████║"
echo "  ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝"
echo ""

# ── Dependency check ────────────────────────────────────────────────
echo "  Checking dependencies..."
MISSING=""
python3 -c "import flask"      2>/dev/null || MISSING="$MISSING flask"
python3 -c "import flask_cors" 2>/dev/null || MISSING="$MISSING flask-cors"
python3 -c "import requests"   2>/dev/null || MISSING="$MISSING requests"

if [ -n "$MISSING" ]; then
    echo "  Installing missing:$MISSING"
    pip install $MISSING --break-system-packages -q 2>/dev/null || \
    pip3 install $MISSING --break-system-packages -q 2>/dev/null
fi

if [ ! -f "$DIR/app.py" ] || [ ! -f "$DIR/scanner.py" ]; then
    echo "  ERROR: Run from the bugscan_work/ folder"
    exit 1
fi

REAL_IP=$(python3 -c "
import socket
try:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(('10.255.255.255', 1))
    print(s.getsockname()[0])
    s.close()
except:
    print('127.0.0.1')
" 2>/dev/null)

PORT="${PORT:-9865}"
if ! [[ "$PORT" =~ ^[0-9]+$ ]]; then PORT=9865; fi

# Count routes
ROUTES=$(python3 -c "
import re
try:
    n = len(re.findall('@app.route', open('$DIR/app.py').read()))
    print(n)
except:
    print(330)
" 2>/dev/null)

echo "  TheMasterRecon AI v3.0 -- ${ROUTES:-330} routes -- 89 bug types"
echo ""

# ── SecretHunter status ──────────────────────────────────────────────
if [ -f "$DIR/secret_hunter" ] && [ -x "$DIR/secret_hunter" ]; then
    echo "  SecretHunter: FOUND - running in safe mode (binary present)"
else
    echo "  SecretHunter: binary missing"
    echo "    Copy binary to $DIR/secret_hunter then chmod +x"
    echo "    See secret_hunter_setup.md for details"
fi

# ── AI status ────────────────────────────────────────────────────────
if grep -q "ANTHROPIC_API_KEY=sk-" "$DIR/.env" 2>/dev/null; then
    echo "  AI Claude: ENABLED"
else
    echo "  AI Claude: set ANTHROPIC_API_KEY in .env to enable"
fi

# ── Tool count ───────────────────────────────────────────────────────
# Count ALL installed tools
TOOLS_FOUND=0
ALL_TOOLS="subfinder amass assetfinder findomain chaos sublist3r knockpy altdns dnsgen alterx shuffledns puredns massdns dnsx tlsx cdncheck asnmap uncover mapcidr httpx httprobe naabu nmap masscan rustscan zmap katana gospider hakrawler gau gauplus waybackurls paramspider subjs anew gf qsreplace kr ffuf gobuster feroxbuster dirsearch wfuzz arjun nuclei nikto whatweb wpscan sqlmap ghauri dalfox kxss crlfuzz ssrfuzz byp4xx commix 403jump bypass-403 subjack tko-subs trufflehog gitleaks detect-secrets s3scanner cloudbrute pacu gowitness interactsh-client notify jxscout scoutsuite wkhtmltopdf kiterunner waymore uro urlfinder cariddi x8 mantra gxss jsluice github-subdomains pdtm cent secret_hunter"
TOTAL_TOOLS=0
for tool in $ALL_TOOLS; do
    TOTAL_TOOLS=$((TOTAL_TOOLS + 1))
    if command -v "$tool" >/dev/null 2>&1 ||        [ -f "$GOBIN/$tool" ] ||        [ -f "/usr/local/bin/$tool" ] ||        [ -f "$HOME/.local/bin/$tool" ]; then
        TOOLS_FOUND=$((TOOLS_FOUND + 1))
    fi
done
echo "  Tools: ${TOOLS_FOUND}/${TOTAL_TOOLS} installed  (run ./fix_failed_tools.sh for missing)"

echo ""
echo "  URL:   http://${REAL_IP:-localhost}:${PORT}"
echo "  Local: http://127.0.0.1:${PORT}"
echo "  Login: admin / TheMasterRecon2024!"
echo ""
echo "  Starting on port $PORT..."
echo ""

cd "$DIR"

# Auto-install gunicorn+gevent if missing
if ! python3 -c "import gunicorn, gevent" 2>/dev/null; then
    echo "  Installing gunicorn+gevent (production server)..."
    pip3 install gunicorn gevent --break-system-packages -q 2>/dev/null ||     pip install gunicorn gevent --break-system-packages -q 2>/dev/null || true
fi

if python3 -c "import gunicorn, gevent" 2>/dev/null; then
    echo "  Server: gunicorn + gevent (production)"
    exec python3 -m gunicorn -c gunicorn.conf.py app:app
else
    echo "  Server: Flask dev (gunicorn unavailable)"
    exec python3 app.py
fi
