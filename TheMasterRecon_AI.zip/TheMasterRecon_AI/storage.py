"""BugScan ELITE — Storage Layer"""
import json, threading, shutil
from pathlib import Path
from datetime import datetime

class Storage:
    def __init__(self, data_dir):
        self.root = Path(data_dir)
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._seen_ports  = {}   # {domain: set()} — per-instance, not class-level
        self._seen_ends   = {}   # {domain: set()} — dedup endpoints per instance
        self._seen_subs   = {}   # {domain: set()} — dedup subdomains per instance

    def _dd(self, domain):
        d = self.root / domain.replace("/","_").replace(":","_")
        d.mkdir(exist_ok=True)
        return d

    def _rj(self, p, default=None):
        p = Path(p)
        if not p.exists(): return default
        try: return json.loads(p.read_text())
        except: return default

    def _wj(self, p, data):
        import tempfile, os as _os
        p = Path(p)
        with self._lock:
            # Atomic write: temp file + rename prevents corruption on crash
            tmp = p.with_suffix('.tmp')
            try:
                tmp.write_text(json.dumps(data, indent=2))
                tmp.replace(p)
            except Exception:
                try: tmp.unlink()
                except: pass
                raise

    def _rl(self, p):
        p = Path(p)
        if not p.exists(): return []
        return [l.strip() for l in p.read_text().splitlines() if l.strip()]

    def _al(self, p, line):
        with self._lock:
            with open(p, "a") as f: f.write(str(line).strip()+"\n")

    def _cl(self, p):
        p = Path(p)
        if not p.exists(): return 0
        try: return sum(1 for l in p.read_text().splitlines() if l.strip())
        except: return 0

    # ── Domain management ────────────────────────────────────────────────────
    def domain_exists(self, d):
        dd = self._dd(d)
        return any(dd.iterdir()) if dd.exists() else False

    def list_domains(self):
        out = []
        for dd in sorted(self.root.iterdir()):
            if not dd.is_dir(): continue
            meta   = self._rj(dd/"meta.json", {})
            finds  = self._rj(dd/"findings.json", [])
            chains = self._rj(dd/"chains.json", [])
            bugs   = list({f.get("bug","") for f in finds if f.get("bug")})
            out.append({
                "domain":  dd.name,
                "subs":    self._cl(dd/"subs.txt"),
                "active":  self._cl(dd/"active.txt"),
                "ends":    self._cl(dd/"ends.txt"),
                "finds":   len(finds),
                "chains":  len(chains),
                "bugs":    bugs[:8],
                "ts":      meta.get("started",""),
                "waf":     meta.get("waf",{}).get("vendor",""),
                "asn":     meta.get("asn",{}).get("org",""),
            })
        return out

    def delete_domain(self, d):
        dd = self._dd(d)
        if dd.exists(): shutil.rmtree(dd)

    def delete_all(self):
        for dd in self.root.iterdir():
            if dd.is_dir(): shutil.rmtree(dd)

    # ── Meta ─────────────────────────────────────────────────────────────────
    def save_meta(self, d, extra):
        p = self._dd(d)/"meta.json"
        cur = self._rj(p, {})
        cur.update(extra)
        if "started" not in cur: cur["started"] = datetime.utcnow().isoformat()
        self._wj(p, cur)

    def get_meta(self, d): return self._rj(self._dd(d)/"meta.json", {})

    # ── Steps ────────────────────────────────────────────────────────────────
    def set_step(self, d, step, state):
        p = self._dd(d)/"steps.json"
        steps = self._rj(p, {})
        steps[step] = state
        self._wj(p, steps)

    def get_steps(self, d): return self._rj(self._dd(d)/"steps.json", {})

    # ── Subdomains / hosts ───────────────────────────────────────────────────
    # In-memory seen sets for fast dedup without file reads on every insert
    _seen_subs   = {}   # domain -> set
    _seen_active = {}
    _seen_ports  = {}
    _seen_ends   = {}

    def add_sub(self, d, host):
        p = self._dd(d)/"subs.txt"
        with self._lock:
            if d not in self._seen_subs:
                self._seen_subs[d] = set(self._rl(p))
            if host not in self._seen_subs[d]:
                self._seen_subs[d].add(host)
                with open(p, "a") as f: f.write(str(host).strip()+"\n")

    def add_active(self, d, host):
        p = self._dd(d)/"active.txt"
        with self._lock:
            if d not in self._seen_active:
                self._seen_active[d] = set(self._rl(p))
            if host not in self._seen_active[d]:
                self._seen_active[d].add(host)
                with open(p, "a") as f: f.write(str(host).strip()+"\n")

    def add_port(self, d, entry):
        p = self._dd(d)/"ports.txt"
        with self._lock:
            if d not in self._seen_ports:
                self._seen_ports[d] = set(self._rl(p))
            if entry not in self._seen_ports[d]:
                self._seen_ports[d].add(entry)
                with open(p, "a") as f: f.write(str(entry).strip()+"\n")

    def save_enrich(self, d, data):
        p = self._dd(d)/"enriched.json"
        cur = self._rj(p, {})
        cur[data.get("url","")] = data
        self._wj(p, cur)

    def get_hosts(self, d):
        dd = self._dd(d)
        return {
            "subs":         self._rl(dd/"subs.txt"),
            "active":       self._rl(dd/"active.txt"),
            "ports":        self._rl(dd/"ports.txt"),
            "enriched":     list(self._rj(dd/"enriched.json",{}).values()),
            "subs_count":   self._cl(dd/"subs.txt"),
            "active_count": self._cl(dd/"active.txt"),
        }

    # ── Endpoints ────────────────────────────────────────────────────────────
    def add_endpoint(self, d, url):
        p = self._dd(d)/"ends.txt"
        with self._lock:
            if d not in self._seen_ends:
                self._seen_ends[d] = set(self._rl(p))
            if url not in self._seen_ends[d]:
                self._seen_ends[d].add(url)
                with open(p, "a") as f: f.write(str(url).strip()+"\n")

    def get_endpoints(self, d, limit=5000):
        return self._rl(self._dd(d)/"ends.txt")[:limit]

    def count_endpoints(self, d): return self._cl(self._dd(d)/"ends.txt")

    # ── Tech ─────────────────────────────────────────────────────────────────
    def add_tech(self, d, tech):
        p = self._dd(d)/"tech.json"
        cur = set(self._rj(p, []))
        cur.update(tech if isinstance(tech, list) else [tech])
        self._wj(p, list(cur))

    def get_tech(self, d): return self._rj(self._dd(d)/"tech.json", [])

    # ── Findings ─────────────────────────────────────────────────────────────
    def add_finding(self, d, f):
        import hashlib, json as _json, tempfile, os as _os
        p = self._dd(d)/"findings.json"
        # Build dedupe key before acquiring lock
        bug   = f.get("bug","")
        url   = f.get("url","")
        param = f.get("param","")
        title = f.get("title",f.get("description",""))[:80]
        raw   = _json.dumps({"bug":bug,"url":url,"param":param,"title":title},
                            sort_keys=True)
        dedupe_key = hashlib.sha256(raw.encode()).hexdigest()[:16]
        f["dedupe_key"] = dedupe_key
        # Lock entire read-modify-write to prevent race conditions
        with self._lock:
            finds = self._rj(p, [])
            if any(x.get("dedupe_key","") == dedupe_key for x in finds):
                return  # duplicate — skip
            finds.append(f)
            tmp = p.with_suffix('.tmp')
            try:
                tmp.write_text(_json.dumps(finds, indent=2))
                tmp.replace(p)
            except Exception:
                try: tmp.unlink()
                except: pass

    def get_findings(self, d, min_confidence: int = 0,
                     severity: str = None, bug_type: str = None) -> list:
        """Return findings, optionally filtered by confidence and severity."""
        finds = self._rj(self._dd(d)/"findings.json", [])
        if min_confidence > 0:
            finds = [f for f in finds if f.get("confidence", 0) >= min_confidence]
        if severity:
            finds = [f for f in finds if f.get("severity","").lower() == severity.lower()]
        if bug_type:
            finds = [f for f in finds if f.get("bug","") == bug_type or f.get("type","") == bug_type]
        # Sort: critical → high → medium → low → info
        _sev_order = {"critical":0,"high":1,"medium":2,"low":3,"info":4}
        finds.sort(key=lambda x: (_sev_order.get(x.get("severity","info"),5),
                                  -x.get("confidence",0)))
        return finds

    # ── Chains ───────────────────────────────────────────────────────────────
    def save_chains(self, d, chains):
        self._wj(self._dd(d)/"chains.json", chains)

    def get_chains(self, d): return self._rj(self._dd(d)/"chains.json", [])

    # ── JS Analysis ──────────────────────────────────────────────────────────
    def save_js_analysis(self, d, results):
        self._wj(self._dd(d)/"js_analysis.json", results)

    def get_js_analysis(self, d): return self._rj(self._dd(d)/"js_analysis.json", [])

    # ── Reports ──────────────────────────────────────────────────────────────
    def save_report(self, d, report):
        (self._dd(d)/"report.md").write_text(report)

    def get_report(self, d):
        p = self._dd(d)/"report.md"
        return p.read_text() if p.exists() else None

    def save_screenshots(self, d, results):
        self._wj(self._dd(d)/"screenshots.json", results)

    def save_auth(self, d, data):
        """Save auth session for a domain."""
        self._wj(self._dd(d)/"auth_session.json", data)

    def get_auth(self, d):
        """Get saved auth session for a domain."""
        return self._rj(self._dd(d)/"auth_session.json", {})


    def get_screenshots(self, d):
        return self._rj(self._dd(d)/"screenshots.json", [])

    def save_findings(self, domain: str, findings: list) -> None:
        """Overwrite all findings for a domain (used by auto-submit to mark submitted)."""
        p = self._dd(domain) / "findings.json"
        self._wj(p, findings)

    def execute(self, query: str, params: tuple = ()) -> list:
        """No-op DB execute for compatibility (JSON backend)."""
        return []

