"""
BugScan PRO — Recon Pipeline v4
Every step verified to work. Crawl and endpoints fixed.
"""
import subprocess, queue, json, os, re, shutil, tempfile, time, logging
import threading, urllib.request, urllib.parse, urllib.error, socket, ssl
from typing import Optional, List, Set

log = logging.getLogger("bugscan.recon")

# ── Tool finder ───────────────────────────────────────────────────────────────
def _normalize_url(url: str) -> str:
    """Strip cache-busting query params from URL for deduplication.
    e.g. /app.js?rand=123 → /app.js?rand= (keep key, strip value)
    e.g. /page?v=1.2.3 → /page (strip known cache params entirely)
    """
    import urllib.parse as _up
    try:
        p = _up.urlparse(url)
        if not p.query:
            return url
        qs = _up.parse_qs(p.query, keep_blank_values=True)
        # Remove known cache-busting params
        CACHE_PARAMS = {'rand','_','v','ver','version','cb','cache','ts','t',
                        'nocache','nc','bust','rev','build','hash','etag'}
        qs_clean = {k: v for k, v in qs.items() if k.lower() not in CACHE_PARAMS}
        new_query = _up.urlencode(qs_clean, doseq=True)
        return _up.urlunparse(p._replace(query=new_query))
    except Exception:
        return url


def _which(name: str) -> Optional[str]:
    # ── ProjectDiscovery tools: check preferred paths FIRST, validate binary ──
    # These conflict with Python packages (httpx) or OS packages (notify, dnsx).
    # Preferred paths are checked before shutil.which() so venv/bin never wins.
    _PD_TOOLS = {"httpx", "dnsx", "tlsx", "notify", "naabu", "katana",
                 "nuclei", "subfinder", "alterx", "cdncheck", "asnmap",
                 "mapcidr", "uncover"}
    _PD_PREFERRED = [
        os.path.join(os.path.expanduser("~/go/bin"), name),
        f"/home/kali/go/bin/{name}",
        f"/root/go/bin/{name}",
        f"/usr/local/bin/{name}",
        f"/usr/bin/{name}",
        f"/snap/bin/{name}",
    ]
    # Venv/Python-package paths — always skip these for PD tools
    _SKIP_PATTERNS = ("venv", "site-packages", ".local/lib",
                      "dist-packages", "__pypackages__")
    # Markers that confirm ProjectDiscovery binary (not Python CLI)
    _PD_MARKERS = ("projectdiscovery", "current version", "v2.", "v1.",
                   "version:", "go version")

    def _validate_pd(path: str) -> bool:
        """True if binary is a ProjectDiscovery tool (not a Python package CLI)."""
        if not path or not os.path.isfile(path):
            return False
        try:
            import subprocess as _sp
            r = _sp.run([path, "-version"], capture_output=True, text=True, timeout=5)
            out = (r.stdout + r.stderr).lower()
            # Reject Python package CLIs (argparse usage lines)
            if "no such option" in out:
                return False
            if out[:50].lstrip().startswith("usage:") and "projectdiscovery" not in out:
                return False
            return any(m in out for m in _PD_MARKERS)
        except Exception:
            # Binary exists but can't run -version — still prefer it over venv
            return True

    if name in _PD_TOOLS:
        # Check preferred paths first
        for fp in _PD_PREFERRED:
            if not fp or not os.path.isfile(fp) or not os.access(fp, os.X_OK):
                continue
            if _validate_pd(fp):
                log.info(f"[tool-resolve] {name}={fp} validated=projectdiscovery")
                return fp
            else:
                log.debug(f"[tool-resolve] {name}={fp} skipped=failed_validation")

        # PATH fallback — but skip venv/site-packages
        p = shutil.which(name)
        if p and any(s in p for s in _SKIP_PATTERNS):
            log.debug(f"[tool-resolve] {name}={p} skipped=python_package")
            p = None
        if p:
            if _validate_pd(p):
                log.info(f"[tool-resolve] {name}={p} validated=projectdiscovery")
                return p
            else:
                log.debug(f"[tool-resolve] {name}={p} validation_failed")
                return None
        return None

    # ── Non-PD tools: original logic ──────────────────────────────────────────
    p = shutil.which(name)
    if p: return p
    for d in [
        os.path.expanduser("~/go/bin"),
        "/home/kali/go/bin", "/root/go/bin",
        "/usr/local/bin", "/usr/bin", "/snap/bin",
    ]:
        fp = os.path.join(d, name)
        if os.path.isfile(fp) and os.access(fp, os.X_OK): return fp
    return None

def _tools() -> dict:
    names = [
        # ── Subdomain Enumeration ──────────────────────────────────────
        "subfinder","amass","assetfinder","findomain","chaos",
        "sublist3r","knockpy","altdns","dnsgen",

        # ── Subdomain Brute/Permutation ────────────────────────────────
        "alterx","shuffledns","puredns","massdns","dnsx",

        # ── DNS / Network Intel ────────────────────────────────────────
        "tlsx","cdncheck","asnmap","uncover","mapcidr",

        # ── HTTP Probing ───────────────────────────────────────────────
        "httpx","httprobe",

        # ── Port Scanning ──────────────────────────────────────────────
        "naabu","nmap","masscan","rustscan","zmap",

        # ── Crawling / URL Collection ──────────────────────────────────
        "katana","gospider","hakrawler","gau","gauplus",
        "waybackurls","paramspider","subjs","anew","gf","qsreplace",

        # ── API Discovery ──────────────────────────────────────────────
        "kr","kiterunner",

        # ── Fuzzing / Dir Scan ─────────────────────────────────────────
        "ffuf","gobuster","feroxbuster","dirsearch","wfuzz","arjun",

        # ── Vulnerability Scanning ─────────────────────────────────────
        "nuclei","nikto","whatweb","wpscan",

        # ── SQL Injection ──────────────────────────────────────────────
        "sqlmap","ghauri",

        # ── XSS / Injection ───────────────────────────────────────────
        "dalfox","kxss","crlfuzz","ssrfuzz","byp4xx","commix",
        "403jump","bypass-403",

        # ── Subdomain Takeover ─────────────────────────────────────────
        "subjack","tko-subs",

        # ── Secrets / OSINT ────────────────────────────────────────────
        "trufflehog","gitleaks","detect-secrets",

        # ── Cloud / AWS ────────────────────────────────────────────────
        "s3scanner","cloudbrute","pacu","scoutsuite",

        # ── Screenshots ────────────────────────────────────────────────
        "gowitness",

        # ── OOB / Callbacks ────────────────────────────────────────────
        "interactsh-client",

        # ── Notifications ──────────────────────────────────────────────
        "notify",
    ]
    T = {n: _which(n) for n in names}
    found   = [n for n,p in T.items() if p]
    missing = [n for n,p in T.items() if not p]
    log.info(f"[tools] found {len(found)}: {', '.join(found)}")
    if missing: log.debug(f"[tools] missing: {', '.join(missing)}")
    return T

def _env() -> dict:
    e = os.environ.copy()
    e["PATH"] = ":".join([
        os.path.expanduser("~/go/bin"),
        "/home/kali/go/bin", "/root/go/bin",
        "/usr/local/bin", "/snap/bin", e.get("PATH",""),
    ])
    return e

def _run(cmd: list, **kwargs) -> subprocess.Popen:
    log.debug(f"[run] {' '.join(str(c) for c in cmd[:5])}")
    return subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, env=_env(), bufsize=1, start_new_session=True, **kwargs
    )

def _run_safe(cmd: list, timeout: int = 120,
              max_lines: int = 50000, log_tag: str = "") -> List[str]:
    """
    Safe alternative to _run(): returns list of stdout lines.
    Hard timeout + kill-tree on expiry. Never hangs.
    """
    try:
        from engine.safe_proc import safe_run_process
        r = safe_run_process(cmd, timeout=timeout,
                             max_stdout_lines=max_lines,
                             log_tag=log_tag or cmd[0].split("/")[-1])
        return r["stdout_lines"]
    except Exception:
        return _run_lines(cmd, timeout=timeout)

def _timed_stdout(proc: subprocess.Popen, budget_s: float,
                  callback=None) -> int:
    """
    Consume proc.stdout with a hard time budget.
    Calls callback(line) for each line if provided.
    Returns number of lines read. Kills proc on timeout.
    """
    t0 = time.monotonic()
    count = 0
    try:
        for line in proc.stdout:
            if (time.monotonic() - t0) > budget_s:
                log.warning(f"[timed_stdout] budget {budget_s}s exceeded after {count} lines — killing")
                try: proc.kill()
                except Exception: pass
                break
            line = line.rstrip() if isinstance(line, str) else line.decode(errors='replace').rstrip()
            if callback and line:
                try: callback(line)
                except Exception: pass
            count += 1
    except Exception:
        pass
    return count


def _run_lines(cmd: list, timeout: int = 120) -> List[str]:
    """Run command, return all stdout lines. Never raises — returns [] on any error."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                          env=_env(), timeout=timeout)
        return [l.strip() for l in r.stdout.splitlines() if l.strip()]
    except subprocess.TimeoutExpired as e:
        try: e.process.kill()
        except Exception: pass
        log.debug(f"[run_lines] {cmd[0]}: timed out after {timeout}s")
        return []
    except FileNotFoundError:
        log.debug(f"[run_lines] {cmd[0]}: not found")
        return []
    except Exception as e:
        log.debug(f"[run_lines] {cmd}: {e}")
        return []


def _tmp(lines: list) -> str:
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False)
    for l in lines:
        if l: f.write(str(l).strip()+"\n")
    f.close()
    return f.name

def _rm(p: str):
    try: os.unlink(p)
    except: pass

def _stopped(q: queue.Queue) -> bool:
    try:
        x = q.get_nowait()
        if x is None: return True
        q.put(x)
    except queue.Empty: pass
    return False

def _clean(host: str, domain: str) -> Optional[str]:
    h = host.strip().lower().lstrip("*.")
    if (h and h.endswith(domain) and " " not in h
            and "\n" not in h and len(h) < 253
            and re.match(r'^[a-z0-9._-]+$', h)):
        return h
    return None

# ── SSL context ───────────────────────────────────────────────────────────────
def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False
    c.verify_mode = ssl.CERT_NONE
    return c

def _get(url: str, timeout: int = 10) -> Optional[tuple]:
    try:
        hdrs = {
            "User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate",
            "Connection":      "keep-alive",
        }
        req = urllib.request.Request(url, headers=hdrs)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            raw = r.read(32768)
            # Handle gzip
            import gzip as _gz
            try:
                if r.headers.get("Content-Encoding","") == "gzip":
                    raw = _gz.decompress(raw)
            except: pass
            return r.status, dict(r.headers), raw.decode("utf-8","ignore")
    except urllib.error.HTTPError as e:
        try: return e.code, dict(e.headers), e.read(4096).decode("utf-8","ignore")
        except: return e.code, {}, ""
    except Exception: return None

def _fetch_json(url: str, timeout: int = 20) -> Optional[object]:
    r = _get(url, timeout)
    if not r: return None
    try: return json.loads(r[2])
    except: return None

# ════════════════════════════════════════════════════════════════════
# PASSIVE SUBDOMAIN SOURCES
# ════════════════════════════════════════════════════════════════════

def _passive_sources(domain: str, source_callback=None,
                      endpoint_callback=None) -> List[str]:
    """Run all passive sources in parallel, return combined unique list.
    endpoint_callback: optional callable(url, source) to save endpoints to DB.
    """
    results = []
    lock = threading.Lock()

    def add(subs):
        with lock:
            results.extend(subs)

    def asn_bgp():
        """BGP/ASN — find all IP ranges owned by the target company."""
        try:
            import socket as _sk
            try: ip = _sk.gethostbyname(domain)
            except: return
            import urllib.request as _ur, ssl as _ssl, json as _jso
            _ctx2 = _ssl.create_default_context()
            _ctx2.check_hostname=False; _ctx2.verify_mode=_ssl.CERT_NONE
            def _bgpget(url):
                try:
                    req = _ur.Request(url,headers={"User-Agent":"BugScanELITE/5.0","Accept":"application/json"})
                    with _ur.urlopen(req,timeout=10,context=_ctx2) as r:
                        return _jso.loads(r.read(65536).decode("utf-8","ignore"))
                except: return None
            d = _bgpget(f"https://api.bgpview.io/ip/{ip}")
            if not d or not d.get("data"): return
            prefixes = d["data"].get("prefixes",[])
            if not prefixes: return
            asn = str(prefixes[0].get("asn",{}).get("asn",""))
            org = prefixes[0].get("asn",{}).get("description_short","")
            if not asn: return
            log.info(f"[asn] {domain}→{ip} ASN:{asn} ({org})")
            log.info(f"[passive] ASN {asn} ({org}) — expanding ranges")
            d2 = _bgpget(f"https://api.bgpview.io/asn/{asn}/prefixes")
            if not d2 or not d2.get("data"): return
            for pfx in d2["data"].get("ipv4_prefixes",[])[:8]:
                cidr = pfx.get("prefix","")
                if cidr:
                    log.debug(f"[passive] asn_range asn={asn} cidr={cidr}")
                    add_sub(cidr)
        except Exception as e:
            log.debug(f"[asn] {e}")

    def crt_sh():
        """
        CRT.sh — JSON API. Max 2 retries, 30s cap total to avoid blocking recon.
        """
        subs = set()
        active_subs = set()
        import time as _time
        from datetime import datetime as _dt
        _crt_t0 = _time.monotonic()

        for q in [f"%.{domain}", domain]:
            if (_time.monotonic() - _crt_t0) > 30:  # hard 30s cap for crt.sh
                break
            url = f"https://crt.sh/?q={q}&output=json"
            for attempt in range(2):  # max 2 retries (was 5)
                if (_time.monotonic() - _crt_t0) > 28:
                    break
                d = _fetch_json(url, 12)  # 12s timeout per request
                if d:
                    for e in d:
                        for n in e.get("name_value","").splitlines():
                            s = _clean(n, domain)
                            if s: subs.add(s)
                        not_after = e.get("not_after","")
                        if not_after:
                            try:
                                exp = _dt.strptime(not_after[:19], "%Y-%m-%dT%H:%M:%S")
                                if exp > _dt.now():
                                    for n in e.get("name_value","").splitlines():
                                        s = _clean(n, domain)
                                        if s: active_subs.add(s)
                            except: pass
                        cn = _clean(e.get("common_name",""), domain)
                        if cn: subs.add(cn)
                    break
                if attempt < 1:
                    _time.sleep(5)  # one short retry (was 10/20/30/40/50s)

        log.info(f"[passive] crt_sh: {len(subs)} total, {len(active_subs)} active")
        add(list(subs))
        if active_subs:
            add(list(active_subs))

    def certspotter():
        d = _fetch_json(f"https://api.certspotter.com/v1/issuances?domain={domain}&expand=dns_names")
        subs = set()
        if d:
            for e in d:
                for n in e.get("dns_names",[]):
                    s = _clean(n, domain)
                    if s: subs.add(s)
        add(list(subs))

    def hackertarget():
        r = _get(f"https://api.hackertarget.com/hostsearch/?q={domain}")
        subs = set()
        if r:
            for line in r[2].splitlines():
                s = _clean(line.split(",")[0], domain)
                if s: subs.add(s)
        add(list(subs))

    def alienvault():
        """
        AlienVault OTX — two endpoints:
        1. passive_dns  → subdomains
        2. url_list     → full URLs with paths + params (feeds endpoint discovery)
        No API key needed. Limit 2400 per page.
        """
        subs = set()
        endpoints_found = set()

        # ── Endpoint 1: passive_dns (subdomains) ──────────────────────────
        for page in range(1, 6):
            d = _fetch_json(
                f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}"
                f"/passive_dns?page={page}&limit=500"
            )
            if not d or not d.get("passive_dns"): break
            for e in d["passive_dns"]:
                s = _clean(e.get("hostname",""), domain)
                if s: subs.add(s)
            if not d.get("has_next"): break

        # ── Endpoint 2: url_list (full URLs → endpoints + subs) ───────────
        # This is the key insight from jewelcars URL: limit=2400 gets WAY more
        for page in range(1, 10):
            d = _fetch_json(
                f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}"
                f"/url_list?limit=2400&page={page}"
            )
            if not d: break
            urls = d.get("url_list", [])
            if not urls: break
            for entry in urls:
                url = entry.get("url","")
                if not url: continue
                # Extract subdomain from URL
                try:
                    import urllib.parse as _up
                    parsed = _up.urlparse(url if url.startswith("http") else "http://"+url)
                    host = parsed.netloc.split(":")[0]
                    s = _clean(host, domain)
                    if s: subs.add(s)
                    # Store full URL as an endpoint for scanner
                    if parsed.query:  # only parameterized URLs are useful for scanning
                        endpoints_found.add(url)
                except: pass
            # If fewer than 100 results, no point paginating
            if len(urls) < 100: break
            if not d.get("has_next", True): break

        log.info(f"[passive] alienvault: {len(subs)} subs, {len(endpoints_found)} endpoints")
        add(list(subs))

        # Feed discovered endpoints into the endpoint store
        if endpoints_found:
            try:
                for ep in list(endpoints_found)[:2000]:
                    add_endpoint(ep)  # emits SSE + saves to DB
                log.info(f"[passive] alienvault: {len(endpoints_found)} parameterized URLs → endpoint DB")
            except: pass

    def urlscan():
        subs = set()
        d = _fetch_json(f"https://urlscan.io/api/v1/search/?q=domain:{domain}&size=200")
        if d:
            for r in d.get("results",[]):
                for f in ["domain","ptr"]:
                    s = _clean(r.get("page",{}).get(f,""), domain)
                    if s: subs.add(s)
        add(list(subs))

    def rapiddns():
        subs = set()
        r = _get(f"https://rapiddns.io/subdomain/{domain}?full=1#result")
        if r:
            for m in re.findall(r'([a-zA-Z0-9._-]+\.' + re.escape(domain) + r')', r[2]):
                s = _clean(m, domain)
                if s: subs.add(s)
        add(list(subs))

    def wayback():
        """
        Wayback Machine CDX — pulls both subdomains AND full parameterized URLs.
        URLs feed directly into the endpoint store for scanner use.
        """
        subs  = set()
        ep_urls = set()
        # Two passes: subs + all URLs with params
        # Wayback CDX — paginated, gets ALL historical URLs
        for url_template in [
            f"http://web.archive.org/cdx/search/cdx?url=*.{domain}/*&output=text&fl=original&collapse=urlkey&limit=100000",
            f"http://web.archive.org/cdx/search/cdx?url={domain}/*&output=text&fl=original&collapse=urlkey&limit=50000",
        ]:
            r = _get(url_template, 60)
            if not r: continue
            for line in r[2].splitlines():
                line = line.strip()
                if not line: continue
                try:
                    parsed = urllib.parse.urlparse(line)
                    h = parsed.netloc
                    s = _clean(h, domain)
                    if s: subs.add(s)
                    # Feed parameterized URLs into endpoint store
                    if parsed.query and (domain in h or h.endswith("."+domain)):
                        ep_urls.add(line)
                except: pass
        add(list(subs))
        # Endpoint URLs discovered via wayback — stored via callback if provided
        if ep_urls and source_callback:
            try: source_callback("_wayback_endpoints", len(ep_urls))
            except: pass
        # Note: full endpoint saving happens in _recon_waymore via add_endpoint()

    def threatminer():
        subs = set()
        d = _fetch_json(f"https://api.threatminer.org/v2/domain.php?q={domain}&rt=5")
        if d and d.get("status_code") == "200":
            for s in d.get("results",[]):
                c = _clean(s, domain)
                if c: subs.add(c)
        add(list(subs))

    def anubis():
        subs = set()
        d = _fetch_json(f"https://jldc.me/anubis/subdomains/{domain}")
        if d and isinstance(d, list):
            for s in d:
                c = _clean(s, domain)
                if c: subs.add(c)
        add(list(subs))

    def columbus():
        subs = set()
        d = _fetch_json(f"https://columbus.elmasy.com/api/lookup/{domain}")
        if d and isinstance(d, list):
            for s in d:
                full = f"{s}.{domain}" if not s.endswith(domain) else s
                c = _clean(full, domain)
                if c: subs.add(c)
        add(list(subs))

    def chaos_pd():
        subs = set()
        d = _fetch_json(f"https://dns.projectdiscovery.io/dns/{domain}/subdomains")
        if d:
            items = d if isinstance(d, list) else d.get("subdomains",[])
            for s in items:
                full = f"{s}.{domain}" if not s.endswith(domain) else s
                c = _clean(full, domain)
                if c: subs.add(c)
        add(list(subs))

    def bevigil():
        subs = set()
        d = _fetch_json(f"https://osint.bevigil.com/api/{domain}/subdomains/")
        if d:
            for s in d.get("subdomains",[]):
                c = _clean(s, domain)
                if c: subs.add(c)
        add(list(subs))

    def dns_resolve_common():
        """Resolve common prefixes directly."""
        subs = set()
        prefixes = [
            "www","mail","api","app","dev","staging","stage","admin","portal","login",
            "auth","sso","static","cdn","assets","media","blog","shop","support","docs",
            "git","jenkins","vpn","test","demo","beta","mobile","ws","internal",
            "v1","v2","v3","old","new","next","monitor","status","dashboard","console",
            "ftp","smtp","pop","imap","mx","mx1","mx2","ns1","ns2","autoconfig",
            "autodiscover","webmail","crm","erp","pay","billing","account","accounts",
            "id","oauth","openid","db","mysql","redis","elastic","backup","sandbox","uat",
            "qa","prod","production","preprod","preview","alpha","rc","cloud","remote",
            "office","exchange","partners","partner","reseller","affiliate","b2b","b2c",
            "idp","sp","saml","federation","trust","api2","api3","apidev","apistage",
            "graphql","rest","ws2","socket","events","push","webhook","webhooks",
            "stream","live","video","img","images","files","upload","download","assets2",
        ]
        for p in prefixes:
            hostname = f"{p}.{domain}"
            try:
                socket.setdefaulttimeout(2)
                socket.gethostbyname(hostname)
                subs.add(hostname)
            except: pass
        add(list(subs))

    def spf_extract():
        """Extract hosts from SPF records."""
        subs = set()
        try:
            lines = _run_lines(["dig", "+short", "+time=2", "+tries=1", "TXT", domain], timeout=5)
            for line in lines:
                for m in re.finditer(r'include:(\S+)', line):
                    s = _clean(m.group(1), domain)
                    if s: subs.add(s)
                for m in re.finditer(r'\ba:(\S+)', line):
                    s = _clean(m.group(1), domain)
                    if s: subs.add(s)
        except: pass
        add(list(subs))

    # ── NEW: THC API (ip.thc.org) — massive subdomain + CNAME DB ────────────
    def thc_api():
        """
        THC API by Tommy DeVoss (dawgyg).
        Pulls both A/AAAA records (/sb/) and CNAME records (/cn/).
        No API key required. Rate-limit aware.
        """
        subs = set()

        def _thc_strip_ansi(s):
            s = re.sub(r'\x1B\[[0-?]*[ -/]*[@-~]', '', s)
            s = re.sub(r'\x1B[@-Z\\-_][0-?]*[ -/]*[@-~]', '', s)
            return s.strip()

        def _thc_parse(text):
            rate_limit = None
            next_page  = None
            results    = []
            for raw in text.splitlines():
                line = _thc_strip_ansi(raw)
                if not line: continue
                if line.startswith(";;Rate Limit:"):
                    m = re.search(r'You can make (\d+)', line)
                    if m: rate_limit = int(m.group(1))
                elif line.startswith(";;Next Page:"):
                    cand = line.split(":", 1)[1].strip() if ":" in line else ""
                    cand = _thc_strip_ansi(cand)
                    if cand.startswith("https://ip.thc.org/"): next_page = cand
                elif not line.startswith(";;"):
                    clean = _thc_strip_ansi(raw).strip()
                    if clean: results.append(clean)
            return rate_limit, next_page, results

        def _thc_sleep(rl):
            if rl is None: return 2.1
            rl = int(rl)
            if rl >= 50:  return 0.1
            if rl >= 20:  return 0.5
            if rl >= 10:  return 1.0
            return max(0.5, 2.2 - rl * 0.1)

        def _thc_fetch(base_url):
            url = f"{base_url}?l=100"
            page = 0
            while url:
                r = _get(url, timeout=30)
                if not r: break
                status, hdrs, body = r
                if status == 404: break
                if status != 200:
                    time.sleep(10); break
                rl, next_page, results = _thc_parse(body)
                for s in results:
                    c = _clean(s, domain)
                    if c: subs.add(c)
                url = next_page
                time.sleep(_thc_sleep(rl))
                page += 1
                if page > 200: break  # safety cap

        try:
            _thc_fetch(f"https://ip.thc.org/sb/{domain}")  # A/AAAA records
            _thc_fetch(f"https://ip.thc.org/cn/{domain}")  # CNAME records
        except Exception as e:
            log.warning(f"thc_api: {e}")

        log.info(f"[passive] thc_api: {len(subs)} subs")
        add(list(subs))

    # ── SecurityTrails ────────────────────────────────────────────────────────
    def pugrecon():
        """
        PugRecon API — https://pugrecon.com
        Free + paid. Set PUGRECON_API_KEY in .env.
        High-quality unique subdomain source.
        """
        api_key = os.environ.get("PUGRECON_API_KEY","")
        if not api_key: return
        subs = set()
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type":  "application/json",
            "User-Agent":    "BugScanELITE/5.0",
        }
        endpoints = [
            f"https://api.pugrecon.com/api/v1/subdomains/{domain}",
            f"https://pugrecon.com/api/v1/subdomains/{domain}",
            "https://api.pugrecon.com/api/v1/subdomains",
        ]
        try:
            import requests as _req
            sess = _req.Session()
            sess.headers.update(headers)
            found = False
            for url in endpoints:
                if found: break
                try:
                    # Try GET first
                    r = sess.get(url, verify=False, timeout=15)
                    if r.status_code == 200:
                        d = r.json()
                        items = (d.get("subdomains") or d.get("data") or
                                 d.get("results") or d.get("domains") or
                                 (d if isinstance(d, list) else []))
                        for item in items:
                            raw = (item.get("domain") or item.get("subdomain") or
                                   item.get("name") or str(item)) if isinstance(item, dict) else str(item)
                            c = _clean(raw, domain)
                            if c: subs.add(c)
                        found = bool(subs)
                    elif r.status_code == 401:
                        log.warning("[passive] pugrecon: auth failed"); break
                    elif r.status_code == 429:
                        log.warning("[passive] pugrecon: rate limited"); break
                except Exception:
                    # Try POST fallback
                    try:
                        r2 = sess.post(url.rstrip(f"/{domain}"),
                                       json={"domain": domain}, verify=False, timeout=15)
                        if r2.status_code == 200:
                            d = r2.json()
                            items = (d.get("subdomains") or d.get("data") or
                                     (d if isinstance(d, list) else []))
                            for item in items:
                                raw = (item.get("domain") or str(item)) if isinstance(item, dict) else str(item)
                                c = _clean(raw, domain)
                                if c: subs.add(c)
                    except: pass
        except Exception as e:
            log.warning(f"pugrecon: {e}")
        log.info(f"[passive] pugrecon: {len(subs)} subs")
        add(list(subs))

    def securitytrails():
        """
        SecurityTrails API — needs SECURITYTRAILS_API_KEY env var.
        Free tier: 50 req/month. Returns hundreds of subdomains.
        """
        api_key = os.environ.get("SECURITYTRAILS_API_KEY","")
        if not api_key: return
        subs = set()
        try:
            # Subdomains endpoint
            req = urllib.request.Request(
                f"https://api.securitytrails.com/v1/domain/{domain}/subdomains?children_only=false&include_inactive=true",
                headers={"APIKEY": api_key, "Accept": "application/json",
                         "User-Agent": "BugScanPRO/4.0"}
            )
            with urllib.request.urlopen(req, timeout=20, context=_ctx()) as r:
                d = json.loads(r.read())
                for sub in d.get("subdomains", []):
                    full = f"{sub}.{domain}" if not sub.endswith(domain) else sub
                    c = _clean(full, domain)
                    if c: subs.add(c)
            # History endpoint - DNS records
            for rtype in ["a","aaaa","mx","cname","ns"]:
                req2 = urllib.request.Request(
                    f"https://api.securitytrails.com/v1/history/{domain}/dns/{rtype}",
                    headers={"APIKEY": api_key, "Accept": "application/json",
                             "User-Agent": "BugScanPRO/4.0"}
                )
                with urllib.request.urlopen(req2, timeout=20, context=_ctx()) as r:
                    d = json.loads(r.read())
                    for record in d.get("records", []):
                        for val in record.get("values", []):
                            for field in ["ip","ipv6","host","value","hostname"]:
                                v = val.get(field, "")
                                c = _clean(v, domain)
                                if c: subs.add(c)
        except urllib.error.HTTPError as e:
            code = e.code
            log.debug(f"[passive] securitytrails: HTTP {code}")
        except Exception as e:
            log.debug(f"[passive] securitytrails: {e}")
        # Also fetch associated domains (sibling domains owned by same company)
        try:
            req_assoc = urllib.request.Request(
                f"https://api.securitytrails.com/v1/domain/{domain}/associated",
                headers={"APIKEY": api_key, "Accept": "application/json",
                         "User-Agent": "BugScanELITE/5.0"}
            )
            with urllib.request.urlopen(req_assoc, timeout=20, context=_ctx()) as r:
                d = json.loads(r.read())
                for rec in d.get("records", []):
                    h = rec.get("hostname","")
                    c = _clean(h, domain)
                    if c: subs.add(c)
        except Exception:
            pass
        log.info(f"[passive] securitytrails: {len(subs)} subs")
        add(list(subs))

    # ── Shodan ────────────────────────────────────────────────────────────────
    def shodan():
        """Shodan subdomain search — needs SHODAN_API_KEY env var."""
        api_key = os.environ.get("SHODAN_API_KEY","")
        if not api_key: return
        subs = set()
        try:
            d = _fetch_json(f"https://api.shodan.io/dns/domain/{domain}?key={api_key}")
            if d:
                for sub in d.get("subdomains", []):
                    full = f"{sub}.{domain}"
                    c = _clean(full, domain)
                    if c: subs.add(c)
                # Also get historical data
                for entry in d.get("data", []):
                    h = entry.get("subdomain", "")
                    if h:
                        full = f"{h}.{domain}"
                        c = _clean(full, domain)
                        if c: subs.add(c)
        except Exception as e:
            log.warning(f"shodan: {e}")
        log.info(f"[passive] shodan: {len(subs)} subs")
        add(list(subs))

    # ── VirusTotal ────────────────────────────────────────────────────────────
    def virustotal():
        """VirusTotal subdomain search — needs VT_API_KEY env var."""
        api_key = os.environ.get("VT_API_KEY", os.environ.get("VIRUSTOTAL_API_KEY",""))
        subs = set()
        try:
            if api_key:
                req = urllib.request.Request(
                    f"https://www.virustotal.com/api/v3/domains/{domain}/subdomains?limit=40",
                    headers={"x-apikey": api_key, "User-Agent": "BugScanPRO/4.0"}
                )
                with urllib.request.urlopen(req, timeout=20, context=_ctx()) as r:
                    d = json.loads(r.read())
                    for item in d.get("data", []):
                        c = _clean(item.get("id",""), domain)
                        if c: subs.add(c)
            else:
                # Free UI endpoint (limited)
                r = _get(f"https://www.virustotal.com/ui/domains/{domain}/subdomains?limit=20")
                if r:
                    try:
                        d = json.loads(r[2])
                        for item in d.get("data", []):
                            c = _clean(item.get("id",""), domain)
                            if c: subs.add(c)
                    except: pass
        except Exception as e:
            log.debug(f"virustotal: {e}")
        log.info(f"[passive] virustotal: {len(subs)} subs")
        add(list(subs))

    # ── Censys ────────────────────────────────────────────────────────────────
    def censys():
        """Censys certificate search — needs CENSYS_API_ID + CENSYS_API_SECRET env vars."""
        api_id     = os.environ.get("CENSYS_API_ID","")
        api_secret = os.environ.get("CENSYS_API_SECRET","")
        if not api_id or not api_secret: return
        subs = set()
        try:
            import base64
            creds = base64.b64encode(f"{api_id}:{api_secret}".encode()).decode()
            query = {"q": f"parsed.names: {domain}", "fields": ["parsed.names"], "flatten": True}
            req = urllib.request.Request(
                "https://search.censys.io/api/v1/search/certificates",
                data=json.dumps(query).encode(),
                headers={
                    "Authorization": f"Basic {creds}",
                    "Content-Type": "application/json",
                    "User-Agent": "BugScanPRO/4.0",
                },
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=20, context=_ctx()) as r:
                d = json.loads(r.read())
                for result in d.get("results", []):
                    for name in result.get("parsed.names", []):
                        c = _clean(name, domain)
                        if c: subs.add(c)
        except Exception as e:
            log.debug(f"censys: {e}")
        log.info(f"[passive] censys: {len(subs)} subs")
        add(list(subs))

    # ── FOFA ──────────────────────────────────────────────────────────────────
    def fofa():
        """FOFA search engine — needs FOFA_EMAIL + FOFA_KEY env vars."""
        email = os.environ.get("FOFA_EMAIL","")
        key   = os.environ.get("FOFA_KEY","")
        if not email or not key: return
        subs = set()
        try:
            import base64
            query = base64.b64encode(f'domain="{domain}"'.encode()).decode()
            d = _fetch_json(
                f"https://fofa.info/api/v1/search/all?email={email}&key={key}"
                f"&qbase64={query}&fields=host,domain&size=100"
            )
            if d and d.get("results"):
                for row in d["results"]:
                    for val in row:
                        c = _clean(val, domain)
                        if c: subs.add(c)
        except Exception as e:
            log.warning(f"fofa: {e}")
        log.info(f"[passive] fofa: {len(subs)} subs")
        add(list(subs))

    # ── Hunter.io ─────────────────────────────────────────────────────────────
    def hunter_io():
        """Hunter.io domain search — needs HUNTER_API_KEY env var."""
        api_key = os.environ.get("HUNTER_API_KEY","")
        if not api_key: return
        subs = set()
        try:
            d = _fetch_json(
                f"https://api.hunter.io/v2/domain-search?domain={domain}&api_key={api_key}&limit=100"
            )
            if d and d.get("data"):
                for email in d["data"].get("emails", []):
                    # Extract subdomain from email domain
                    val = email.get("domain","")
                    c = _clean(val, domain)
                    if c: subs.add(c)
        except Exception as e:
            log.warning(f"hunter.io: {e}")
        log.info(f"[passive] hunter.io: {len(subs)} subs")
        add(list(subs))

    # ── PassiveTotal / RiskIQ ─────────────────────────────────────────────────
    def passivetotal():
        """PassiveTotal/RiskIQ — needs PT_USER + PT_KEY env vars."""
        user = os.environ.get("PT_USER","")
        key  = os.environ.get("PT_KEY","")
        if not user or not key: return
        subs = set()
        try:
            import base64
            creds = base64.b64encode(f"{user}:{key}".encode()).decode()
            req = urllib.request.Request(
                f"https://api.passivetotal.org/v2/enrichment/subdomains?query={domain}",
                headers={"Authorization": f"Basic {creds}",
                         "User-Agent": "BugScanPRO/4.0"}
            )
            with urllib.request.urlopen(req, timeout=20, context=_ctx()) as r:
                d = json.loads(r.read())
                for sub in d.get("subdomains", []):
                    full = f"{sub}.{domain}"
                    c = _clean(full, domain)
                    if c: subs.add(c)
        except Exception as e:
            log.warning(f"passivetotal: {e}")
        log.info(f"[passive] passivetotal: {len(subs)} subs")
        add(list(subs))

    # ── Chaos / ProjectDiscovery ──────────────────────────────────────────────
    def chaos_api():
        """ProjectDiscovery Chaos — needs CHAOS_API_KEY env var."""
        api_key = os.environ.get("CHAOS_API_KEY","")
        subs = set()
        try:
            if api_key:
                req = urllib.request.Request(
                    f"https://dns.projectdiscovery.io/dns/{domain}/subdomains",
                    headers={"Authorization": api_key,
                             "User-Agent": "BugScanPRO/4.0"}
                )
                with urllib.request.urlopen(req, timeout=20, context=_ctx()) as r:
                    d = json.loads(r.read())
                    for s in d.get("subdomains", []):
                        full = f"{s}.{domain}" if not s.endswith(domain) else s
                        c = _clean(full, domain)
                        if c: subs.add(c)
            else:
                # Free endpoint
                d = _fetch_json(f"https://dns.projectdiscovery.io/dns/{domain}/subdomains")
                if d:
                    items = d if isinstance(d, list) else (d.get("subdomains") or [])
                    for s in (items or []):
                        full = f"{s}.{domain}" if not s.endswith(domain) else s
                        c = _clean(full, domain)
                        if c: subs.add(c)
        except Exception as e:
            log.debug(f"chaos_api: {e}")
        log.info(f"[passive] chaos: {len(subs)} subs")
        add(list(subs))

    # ── Netlas.io ─────────────────────────────────────────────────────────────
    def netlas():
        """Netlas.io — needs NETLAS_API_KEY env var."""
        api_key = os.environ.get("NETLAS_API_KEY","")
        if not api_key: return
        subs = set()
        try:
            req = urllib.request.Request(
                f"https://app.netlas.io/api/domains/?q=domain:{domain}&source_type=include&start=0&fields=domain",
                headers={"X-Api-Key": api_key, "User-Agent": "BugScanPRO/4.0"}
            )
            with urllib.request.urlopen(req, timeout=20, context=_ctx()) as r:
                d = json.loads(r.read())
                for item in d.get("items", []):
                    c = _clean(item.get("data", {}).get("domain",""), domain)
                    if c: subs.add(c)
        except Exception as e:
            log.warning(f"netlas: {e}")
        log.info(f"[passive] netlas: {len(subs)} subs")
        add(list(subs))

    # ── ZoomEye ───────────────────────────────────────────────────────────────
    def zoomeye():
        """ZoomEye — needs ZOOMEYE_API_KEY env var."""
        api_key = os.environ.get("ZOOMEYE_API_KEY","")
        if not api_key: return
        subs = set()
        try:
            req = urllib.request.Request(
                f"https://api.zoomeye.org/web/search?query=hostname:{domain}&page=1",
                headers={"API-KEY": api_key, "User-Agent": "BugScanPRO/4.0"}
            )
            with urllib.request.urlopen(req, timeout=20, context=_ctx()) as r:
                d = json.loads(r.read())
                for match in d.get("matches", []):
                    c = _clean(match.get("site",""), domain)
                    if c: subs.add(c)
        except Exception as e:
            log.debug(f"zoomeye: {e}")
        log.info(f"[passive] zoomeye: {len(subs)} subs")
        add(list(subs))

    # ── GitHub Code Search ────────────────────────────────────────────────────
    def github_code():
        """GitHub code search for subdomains — needs GITHUB_TOKEN env var."""
        token = os.environ.get("GITHUB_TOKEN","")
        if not token: return
        subs = set()
        try:
            queries = [domain, domain.split(".")[0]]
            for q in queries:
                req = urllib.request.Request(
                    f"https://api.github.com/search/code?q={urllib.parse.quote(q)}&per_page=100",
                    headers={
                        "Authorization": f"token {token}",
                        "Accept": "application/vnd.github.v3+json",
                        "User-Agent": "BugScanPRO/4.0",
                    }
                )
                with urllib.request.urlopen(req, timeout=20, context=_ctx()) as r:
                    d = json.loads(r.read())
                    for item in d.get("items", []):
                        # Extract subdomains from file content snippets
                        text = item.get("text_matches","")
                        for match in re.findall(
                            r'([a-zA-Z0-9._-]+\.' + re.escape(domain) + r')',
                            str(text)
                        ):
                            c = _clean(match, domain)
                            if c: subs.add(c)
                time.sleep(2)  # GitHub rate limit
        except Exception as e:
            log.debug(f"github_code: {e} (set GITHUB_TOKEN env var)")
        log.info(f"[passive] github_code: {len(subs)} subs")
        add(list(subs))


    def bufferover():
        """BufferOver.run — passive DNS, no key needed."""
        subs = set()
        try:
            r = _get(f"https://tls.bufferover.run/dns?q=.{domain}", timeout=15)
            if r and r[0] == 200:
                d = json.loads(r[2])
                for entry in d.get("FDNS_A", []) + d.get("RDNS", []):
                    parts = entry.split(",")
                    for p in parts:
                        s = _clean(p.strip(), domain)
                        if s: subs.add(s)
        except Exception as e:
            log.debug(f"bufferover: {e}")
        log.info(f"[passive] bufferover: {len(subs)} subs")
        add(list(subs))

    def dnsdumpster():
        """DNSDumpster — scrapes HTML, no key needed."""
        subs = set()
        try:
            # Get CSRF token first
            r0 = _get("https://dnsdumpster.com/", timeout=15)
            if not r0: return
            csrf = re.search(r'csrfmiddlewaretoken["\s]+value="([^"]+)"', r0[2])
            if not csrf: return
            token = csrf.group(1)
            cookie = r0[1].get("Set-Cookie","").split(";")[0]
            import urllib.parse as _up
            body = _up.urlencode({"csrfmiddlewaretoken":token,"targetip":domain,"user":"free"})
            req = urllib.request.Request(
                "https://dnsdumpster.com/",
                data=body.encode(),
                headers={
                    "Content-Type":"application/x-www-form-urlencoded",
                    "Referer":"https://dnsdumpster.com/",
                    "Cookie":cookie,
                    "User-Agent":"Mozilla/5.0",
                }
            )
            import ssl as _ssl
            ctx = _ssl.create_default_context()
            ctx.check_hostname=False; ctx.verify_mode=_ssl.CERT_NONE
            with urllib.request.urlopen(req, timeout=20, context=ctx) as r:
                html = r.read().decode("utf-8","ignore")
            for m in re.finditer(r'([a-zA-Z0-9._-]+\.' + re.escape(domain) + r')', html):
                s = _clean(m.group(1), domain)
                if s: subs.add(s)
        except Exception as e:
            log.debug(f"dnsdumpster: {e}")
        log.info(f"[passive] dnsdumpster: {len(subs)} subs")
        add(list(subs))

    def sonar_fdns():
        """FDNS dataset search via crobat API."""
        subs = set()
        try:
            d = _fetch_json(f"https://sonar.omnisint.io/subdomains/{domain}")
            if d and isinstance(d, list):
                for s in d:
                    c = _clean(s, domain)
                    if c: subs.add(c)
        except Exception as e:
            log.debug(f"sonar_fdns: {e}")
        log.info(f"[passive] sonar_fdns: {len(subs)} subs")
        add(list(subs))

    def whoisxmlapi():
        """WhoisXML API — uses WHOISXML_API_KEY from .env, falls back to free tier."""
        subs = set()
        try:
            _wkey = os.environ.get("WHOISXML_API_KEY","") or os.environ.get("WHOISXMLAPI_KEY","at_free")
            d = _fetch_json(
                f"https://subdomains.whoisxmlapi.com/api/v1?"
                f"apiKey={_wkey}&domainName={domain}&outputFormat=json"
            )
            if d:
                for r in d.get("result",{}).get("records",[]):
                    s = _clean(r.get("domain",""), domain)
                    if s: subs.add(s)
        except Exception as e:
            log.debug(f"whoisxmlapi: {e}")
        log.info(f"[passive] whoisxmlapi: {len(subs)} subs")
        add(list(subs))

    def archive_urls():
        """Extract subdomains from Wayback Machine URL index."""
        subs = set()
        try:
            r = _get(
                f"http://web.archive.org/cdx/search/cdx?url=*.{domain}/*"
                f"&output=text&fl=original&collapse=urlkey&limit=10000&filter=statuscode:200",
                timeout=30
            )
            if r:
                for line in r[2].splitlines():
                    try:
                        h = urllib.parse.urlparse(line.strip()).netloc
                        s = _clean(h, domain)
                        if s: subs.add(s)
                    except: pass
        except Exception as e:
            log.debug(f"archive_urls: {e}")
        log.info(f"[passive] archive_urls: {len(subs)} subs")
        add(list(subs))

    # ── Run all in parallel ───────────────────────────────────────────────────
    def _recon_leakix():
        try:
            r = _get(f"https://leakix.net/api/subdomains/{domain}", timeout=12)
            if not r or r[0] != 200: return
            import json as _lj
            data = _lj.loads(r[2]) if r[2].startswith('[') else []
            new = [str(item.get("subdomain","") or item.get("host","")).strip()
                   for item in data[:500]]
            add([s for s in new if s and s.endswith(f".{domain}") and "*" not in s])
        except Exception as e:
            log.debug(f"[leakix] {e}")

    def _recon_fullhunt():
        try:
            r = _get(f"https://fullhunt.io/api/v1/domain/{domain}/subdomains", timeout=12)
            if not r or r[0] != 200: return
            import json as _fj
            data = _fj.loads(r[2])
            hosts = data.get("hosts",[]) if isinstance(data,dict) else []
            add([h for h in hosts if h.endswith(domain) and h != domain])
        except Exception as e:
            log.debug(f"[fullhunt] {e}")

    def _recon_trickest():
        try:
            import re as _tr2
            r = _get(f"https://inventory.trickest.com/api/v1/domains?search={domain}", timeout=10)
            if not r or r[0] != 200: return
            import re as _tre
            found = set(_tre.findall(r'[a-z0-9-]+(?:[.][a-z0-9-]+)*[.]' + re.escape(domain), r[2], re.I))
            add([s for s in found if s != domain])
        except Exception as e:
            log.debug(f"[trickest] {e}")

    def _recon_certstream():
        try:
            import json as _cj
            r = _get(f"https://crt.sh/?q=%25.{domain}&output=json&limit=10000", timeout=20)
            if not r or r[0] != 200: return
            certs = _cj.loads(r[2]) if r[2].startswith('[') else []
            found = set()
            for c in certs[:10000]:
                for name in (c.get("common_name","") + "\n" + c.get("name_value","")).split("\n"):
                    n = name.strip().lstrip("*.")
                    if n.endswith(domain) and n != domain and "\n" not in n:
                        found.add(n)
            add(list(found))
        except Exception as e:
            log.debug(f"[certstream_v2] {e}")


    def _recon_san():
        """SAN extraction from SSL + crt.sh."""
        try:
            from engine.hunter_tools import get_san_domains
            for s in get_san_domains(domain):
                add(s)
            log.info(f"[passive] san: done")
        except Exception as e:
            log.debug(f"[passive] san: {e}")

    def _recon_abuseip():
        """AbuseIP subdomain discovery."""
        try:
            from engine.hunter_tools import abuseip_subdomains
            for s in abuseip_subdomains(domain):
                add(s)
            log.info(f"[passive] abuseip: done")
        except Exception as e:
            log.debug(f"[passive] abuseip: {e}")




    def _recon_dnsdumpster():
        """DNSDumpster — free passive DNS subdomain enumeration."""
        try:
            import urllib.request, urllib.parse, re as _re2, ssl as _ssl2
            ctx = _ssl2.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=_ssl2.CERT_NONE
            # Get CSRF token first
            req0 = urllib.request.Request(
                "https://dnsdumpster.com/",
                headers={"User-Agent":"Mozilla/5.0","Referer":"https://dnsdumpster.com/"})
            with urllib.request.urlopen(req0, timeout=12, context=ctx) as r0:
                html0 = r0.read(65536).decode("utf-8","ignore")
                tok_m = _re2.search(r'name=["\']csrfmiddlewaretoken["\'].*?value=["\']([^"\']+)', html0)
                if not tok_m: return
                csrf = tok_m.group(1)
                cookies = r0.headers.get("Set-Cookie","")
                csrfcookie = _re2.search(r'csrftoken=([^;]+)', cookies)
                csrfcookie = csrfcookie.group(1) if csrfcookie else csrf
            body = urllib.parse.urlencode({"csrfmiddlewaretoken": csrf, "targetip": domain, "user": "free"}).encode()
            req = urllib.request.Request(
                "https://dnsdumpster.com/", data=body,
                headers={"User-Agent":"Mozilla/5.0","Referer":"https://dnsdumpster.com/",
                         "Content-Type":"application/x-www-form-urlencoded",
                         "Cookie":f"csrftoken={csrfcookie}","X-CSRFToken":csrf})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                html = r.read(500_000).decode("utf-8","ignore")
            found = set()
            for m in _re2.findall(rf'([a-zA-Z0-9._-]+\.{_re2.escape(domain)})', html):
                s = _clean(m, domain)
                if s: found.add(s)
            log.info(f"[passive] dnsdumpster: {len(found)} subs")
            add(list(found))
        except Exception as e:
            log.debug(f"[passive] dnsdumpster: {e}")

    def _recon_columbus():
        """Columbus Project — passive DNS sub finder (columbus.elmasy.com)."""
        try:
            import urllib.request, ssl as _ssl2, json as _j2
            ctx = _ssl2.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=_ssl2.CERT_NONE
            req = urllib.request.Request(
                f"https://columbus.elmasy.com/api/lookup/{domain}",
                headers={"User-Agent":"BugScanELITE/5.0","Accept":"application/json"})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                data = _j2.loads(r.read(1_000_000))
            found = set()
            # Returns array of subdomain prefixes
            if isinstance(data, list):
                for entry in data:
                    if isinstance(entry, str):
                        sub = f"{entry}.{domain}".lstrip(".")
                        s = _clean(sub, domain)
                        if s: found.add(s)
                    elif isinstance(entry, dict):
                        for key in ("subdomain","name","fqdn"):
                            sub = entry.get(key,"")
                            if sub:
                                s = _clean(sub if "." in sub else f"{sub}.{domain}", domain)
                                if s: found.add(s)
            log.info(f"[passive] columbus: {len(found)} subs")
            add(list(found))
        except Exception as e:
            log.debug(f"[passive] columbus: {e}")

    def _recon_digitorus():
        """Digitorus Certificate Transparency — passive cert-based enum."""
        try:
            import urllib.request, ssl as _ssl2, json as _j2
            ctx = _ssl2.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=_ssl2.CERT_NONE
            url = f"https://www.digitorus.com/api/v1/domains/{domain}/subdomains"
            req = urllib.request.Request(url, headers={"User-Agent":"BugScanELITE/5.0","Accept":"application/json"})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                data = _j2.loads(r.read(500_000))
            found = set()
            for item in data if isinstance(data, list) else data.get("subdomains", data.get("results", [])):
                sub = (item.get("name","") if isinstance(item, dict) else str(item)).strip()
                s = _clean(sub, domain)
                if s: found.add(s)
            log.info(f"[passive] digitorus: {len(found)} subs")
            add(list(found))
        except Exception as e:
            log.debug(f"[passive] digitorus: {e}")

    def _recon_merklemap():
        """Merklemap.com — certificate transparency search."""
        try:
            import urllib.request, ssl as _ssl2, json as _j2, re as _re2
            ctx = _ssl2.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=_ssl2.CERT_NONE
            url = f"https://api.merklemap.com/search?query=*.{domain}&page=0"
            req = urllib.request.Request(url, headers={"User-Agent":"BugScanELITE/5.0","Accept":"application/json"})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                data = _j2.loads(r.read(500_000))
            found = set()
            for item in data.get("results", []):
                for key in ("domain","cn","name","subdomain"):
                    sub = str(item.get(key,"")).strip()
                    if sub:
                        s = _clean(sub, domain)
                        if s: found.add(s)
            log.info(f"[passive] merklemap: {len(found)} subs")
            add(list(found))
        except Exception as e:
            log.debug(f"[passive] merklemap: {e}")

    def _recon_shrewdeye():
        """Shrewdeye passive DNS — subdomain discovery."""
        try:
            import urllib.request, ssl as _ssl2, json as _j2
            ctx = _ssl2.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=_ssl2.CERT_NONE
            url = f"https://shrewdeye.app/domains/{domain}.json"
            req = urllib.request.Request(url, headers={"User-Agent":"BugScanELITE/5.0","Accept":"application/json"})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                data = _j2.loads(r.read(500_000))
            found = set()
            for item in data if isinstance(data, list) else []:
                sub = str(item.get("domain", item.get("name",""))).strip()
                s = _clean(sub, domain)
                if s: found.add(s)
            log.info(f"[passive] shrewdeye: {len(found)} subs")
            add(list(found))
        except Exception as e:
            log.debug(f"[passive] shrewdeye: {e}")

    def _recon_crtsh_api2():
        """CRT.sh API v2 — identity search (complementary to main crt_sh)."""
        try:
            import urllib.request, ssl as _ssl2, json as _j2
            ctx = _ssl2.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=_ssl2.CERT_NONE
            # Use the identity endpoint which is faster and less rate-limited
            url = f"https://crt.sh/?q={domain}&output=json&deduplicate=Y"
            req = urllib.request.Request(url, headers={"User-Agent":"BugScanELITE/5.0","Accept":"application/json"})
            with urllib.request.urlopen(req, timeout=20, context=ctx) as r:
                data = _j2.loads(r.read(2_000_000))
            found = set()
            for entry in (data if isinstance(data,list) else []):
                for n in entry.get("name_value","").splitlines():
                    s = _clean(n.strip(), domain)
                    if s: found.add(s)
                cn = _clean(entry.get("common_name",""), domain)
                if cn: found.add(cn)
            log.info(f"[passive] crtsh_api2: {len(found)} subs")
            add(list(found))
        except Exception as e:
            log.debug(f"[passive] crtsh_api2: {e}")

    def _recon_jldc():
        """JLDC passive DNS — jldc.me certificate transparency aggregator."""
        try:
            import urllib.request, ssl as _ssl2, json as _j2
            ctx = _ssl2.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=_ssl2.CERT_NONE
            url = f"https://jldc.me/anubis/subdomains/{domain}"
            req = urllib.request.Request(url, headers={"User-Agent":"BugScanELITE/5.0","Accept":"application/json"})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                data = _j2.loads(r.read(500_000))
            found = set()
            for sub in (data if isinstance(data, list) else []):
                s = _clean(str(sub).strip(), domain)
                if s: found.add(s)
            log.info(f"[passive] jldc: {len(found)} subs")
            add(list(found))
        except Exception as e:
            log.debug(f"[passive] jldc: {e}")

    def _recon_shodandns():
        """Shodan DNS — subdomain search via Shodan domain API (no key needed)."""
        try:
            import urllib.request, ssl as _ssl2, json as _j2
            ctx = _ssl2.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=_ssl2.CERT_NONE
            url = f"https://api.shodan.io/dns/domain/{domain}?key=bgp&minify=true"
            req = urllib.request.Request(url, headers={"User-Agent":"BugScanELITE/5.0","Accept":"application/json"})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                data = _j2.loads(r.read(500_000))
            found = set()
            for sub_entry in data.get("subdomains", []):
                s = _clean(f"{sub_entry}.{domain}", domain)
                if s: found.add(s)
            log.info(f"[passive] shodandns: {len(found)} subs")
            add(list(found))
        except Exception as e:
            log.debug(f"[passive] shodandns: {e}")

    def _recon_bbot():
        """bbot: BlackLanternSecurity BBOT — 50+ passive subdomain sources in one tool."""
        try:
            import subprocess as _sp3
            _bin = T.get("bbot") if T else None
            if not _bin:
                return  # bbot not installed
            # Run bbot in subdomain enumeration mode (passive only — safe)
            result = _sp3.run(
                [_bin, "-t", domain, "-f", "subdomain-enum", "-y",
                 "--silent", "-om", "csv", "-o", "/dev/stdout",
                 "--config", "output_modules.csv.filename=/dev/stdout",
                 "--event-types", "DNS_NAME"],
                capture_output=True, text=True, timeout=300,
                env={**__import__("os").environ, "BBOT_LOGLEVEL": "ERROR"}
            )
            found = set()
            for line in result.stdout.splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "," not in line:
                    s = _clean(line, domain)
                    if s: found.add(s)
                else:
                    # CSV output: parse first column
                    parts = line.split(",")
                    if parts:
                        s = _clean(parts[0].strip().strip('"'), domain)
                        if s: found.add(s)
            log.info(f"[passive] bbot: {len(found)} subs")
            add(list(found))
        except Exception as e:
            log.debug(f"[passive] bbot: {e}")

    def _recon_csprecon():
        """csprecon: extract subdomains from Content-Security-Policy headers."""
        try:
            import subprocess as _sp2, json as _j2
            _bin = T.get("csprecon") if T else None
            if not _bin:
                # Python fallback: fetch a few pages and parse CSP header directly
                import urllib.request as _ur
                for _target_url in [f"https://{domain}", f"https://www.{domain}"]:
                    try:
                        _req = _ur.Request(_target_url, headers={"User-Agent": "Mozilla/5.0"})
                        _resp = _ur.urlopen(_req, timeout=8)
                        _csp = _resp.headers.get("Content-Security-Policy", "")
                        if not _csp:
                            _csp = _resp.headers.get("Content-Security-Policy-Report-Only", "")
                        if _csp:
                            # Extract all hostnames from CSP header
                            import re as _re2
                            _hosts = _re2.findall(
                                r'(?:https?://)?([a-z0-9](?:[a-z0-9\-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?)+)',
                                _csp, _re2.I
                            )
                            _subs_found = set()
                            for h in _hosts:
                                h = h.lower()
                                s = _clean(h, domain)
                                if s:
                                    _subs_found.add(s)
                            if _subs_found:
                                log.info(f"[passive] csprecon (fallback): {len(_subs_found)} subs from CSP")
                                add(list(_subs_found))
                    except Exception:
                        pass
                return
            # Use csprecon binary if installed
            result = _sp2.run([_bin, "-d", domain], capture_output=True, text=True, timeout=60)
            found = set()
            for line in result.stdout.splitlines():
                s = _clean(line.strip(), domain)
                if s: found.add(s)
            log.info(f"[passive] csprecon: {len(found)} subs")
            add(list(found))
        except Exception as e:
            log.debug(f"[passive] csprecon: {e}")

    def _recon_analyticsrelationships():
        """analyticsrelationships: find related domains via shared Google Analytics IDs."""
        try:
            import urllib.request as _ur, re as _re3, json as _j3
            # Fetch the homepage and extract GA tracking IDs
            for _target_url in [f"https://{domain}", f"https://www.{domain}"]:
                try:
                    _req = _ur.Request(_target_url, headers={"User-Agent": "Mozilla/5.0"})
                    _resp = _ur.urlopen(_req, timeout=10)
                    _body = _resp.read().decode("utf-8", errors="replace")
                    # Match Google Analytics IDs: UA-XXXXXXXX-X, G-XXXXXXXXXX, GTM-XXXXXXX
                    _ga_ids = set()
                    _ga_ids |= set(_re3.findall(r'UA-\d{4,}-\d+', _body))
                    _ga_ids |= set(_re3.findall(r'G-[A-Z0-9]{8,}', _body))
                    _ga_ids |= set(_re3.findall(r'GTM-[A-Z0-9]{5,}', _body))
                    if not _ga_ids:
                        continue
                    log.info(f"[passive] analyticsrelationships: found GA IDs: {_ga_ids}")
                    # Query relationships API (if available)
                    for _ga_id in list(_ga_ids)[:3]:
                        try:
                            _api_url = f"https://relationships.analyticsrelationships.com/?ua={_ga_id}"
                            _api_req = _ur.Request(_api_url, headers={"User-Agent": "Mozilla/5.0"})
                            _api_resp = _ur.urlopen(_api_req, timeout=10)
                            _api_data = _j3.loads(_api_resp.read())
                            _related = set()
                            for item in _api_data if isinstance(_api_data, list) else []:
                                _d = item.get("domain", "")
                                if _d:
                                    s = _clean(_d, domain)
                                    if s: _related.add(s)
                            if _related:
                                log.info(f"[passive] analyticsrelationships: {len(_related)} related subs via {_ga_id}")
                                add(list(_related))
                        except Exception:
                            pass
                except Exception:
                    pass
        except Exception as e:
            log.debug(f"[passive] analyticsrelationships: {e}")

    def _recon_github_subdomains():
        """github-subdomains: find subdomains via GitHub code search (needs GITHUB_TOKEN)."""
        try:
            _bin = T.get("github-subdomains") if T else None
            if not _bin:
                return   # binary not installed — skip silently
            import subprocess as _sp2
            _gh_token = os.environ.get("GITHUB_TOKEN", "") or os.environ.get("GITHUB_API_KEY", "")
            if not _gh_token:
                log.debug("[passive] github-subdomains: no GITHUB_TOKEN — skipping")
                return
            result = _sp2.run(
                [_bin, "-d", domain, "-t", _gh_token, "-o", "/dev/stdout"],
                capture_output=True, text=True, timeout=60
            )
            found = set()
            for line in result.stdout.splitlines():
                s = _clean(line.strip(), domain)
                if s: found.add(s)
            log.info(f"[passive] github-subdomains: {len(found)} subs")
            add(list(found))
        except Exception as e:
            log.debug(f"[passive] github-subdomains: {e}")

    def _recon_waymore():
        """Waymore: comprehensive URL collection via wayback+commoncrawl+urlscan+otx."""
        try:
            from engine.recon_extra import waymore_urls
            urls = waymore_urls(domain, limit=2000)
            added = 0
            ep_saved = 0
            for u in urls:
                try:
                    import re as _re
                    m = _re.search(r'https?://([^/]+)', u)
                    if m:
                        host = m.group(1).split(":")[0].lower()
                        if host.endswith("." + domain) or host == domain:
                            if add_sub(host): added += 1
                    # Use endpoint_callback if provided (from run_recon scope)
                    if endpoint_callback:
                        if endpoint_callback(u, source="waymore"): ep_saved += 1
                    elif add_endpoint and add_endpoint(u, source="waymore"): ep_saved += 1
                except: pass
            log.info(f"[endpoint] source=waymore saved={ep_saved} subs={added}")
            _emit("step","subdomains","run",f"waymore: +{added} hosts, {ep_saved} endpoints")
        except Exception as e:
            log.debug(f"[recon] waymore: {e}")

    def _recon_otx():
        """AlienVault OTX passive DNS + URL intelligence."""
        try:
            from engine.recon_extra import otx_domain_info
            info = otx_domain_info(domain)
            added = 0; ep_saved = 0
            for sub in info.get("subdomains", []):
                if add_sub(sub): added += 1
            for url in info.get("urls", []):
                _saved = (endpoint_callback(url, source="otx") if endpoint_callback
                          else (add_endpoint(url, source="otx") if add_endpoint else False))
                if _saved: ep_saved += 1
            if info.get("malicious"):
                _emit("ai_tip", None, None, f"OTX: {domain} flagged malicious ({info.get('pulses',0)} threat pulses)")
            log.info(f"[endpoint] source=otx saved={ep_saved} subs={added}")
            _emit("step","subdomains","run",f"OTX: +{added} subs, {ep_saved} endpoints")
        except Exception as e:
            log.debug(f"[recon] otx: {e}")


    def _recon_grep_app():
        """grep.app — code search for subdomains/endpoints."""
        try:
            import urllib.request, urllib.parse, ssl, json as _j
            ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            q   = urllib.parse.quote(f'.{domain}')
            url = f'https://grep.app/api/search?q={q}&regexp=false'
            req = urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0','Accept':'application/json'})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                data = _j.loads(r.read(500_000))
            added = 0
            for hit in data.get('hits',{}).get('hits',[]):
                content = hit.get('content',{}).get('snippet','')
                for m in re.finditer(r'[\w.-]+\.' + re.escape(domain), content):
                    if add_sub(m.group(0)): added += 1
            log.info(f'[passive] grep.app: +{added}')
        except Exception as e:
            log.debug(f'[passive] grep.app: {e}')

    def _recon_binaryedge():
        """BinaryEdge — host/subdomain intel (API key optional)."""
        try:
            key = os.environ.get('BINARYEDGE_API_KEY','')
            if not key: return
            import urllib.request, ssl, json as _j
            ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            url = f'https://api.binaryedge.io/v2/query/domains/subdomain/{domain}'
            req = urllib.request.Request(url, headers={'X-Key': key})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                data = _j.loads(r.read(500_000))
            added = 0
            for sub in data.get('events',[]):
                if add_sub(sub): added += 1
            log.info(f'[passive] binaryedge: +{added}')
        except Exception as e:
            log.debug(f'[passive] binaryedge: {e}')

    def _recon_onyphe():
        """ONYPHE — cyber threat intelligence (API key optional)."""
        try:
            key = os.environ.get('ONYPHE_API_KEY','')
            if not key: return
            import urllib.request, ssl, json as _j
            ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            url = f'https://www.onyphe.io/api/v2/simple/datascan/domain/{domain}'
            req = urllib.request.Request(url, headers={'Authorization': f'apikey {key}'})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                data = _j.loads(r.read(500_000))
            added = 0
            for item in data.get('results',[]):
                sub = item.get('domain','')
                if sub and add_sub(sub): added += 1
            log.info(f'[passive] onyphe: +{added}')
        except Exception as e:
            log.debug(f'[passive] onyphe: {e}')

    def _recon_greynoise():
        """GreyNoise — internet scanner intel (API key optional)."""
        try:
            key = os.environ.get('GREYNOISE_API_KEY','')
            if not key: return
            import urllib.request, ssl, json as _j
            ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            url = f'https://api.greynoise.io/v2/experimental/gnql?query=metadata.rdns%3A{domain}&size=100'
            req = urllib.request.Request(url, headers={'key': key})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                data = _j.loads(r.read(500_000))
            added = 0
            for item in data.get('data',[]):
                rdns = item.get('metadata',{}).get('rdns','')
                if rdns and domain in rdns and add_sub(rdns): added += 1
            log.info(f'[passive] greynoise: +{added}')
        except Exception as e:
            log.debug(f'[passive] greynoise: {e}')

    def _recon_searchcode():
        """searchcode.com — public code search for domain exposure."""
        try:
            import urllib.request, urllib.parse, ssl, json as _j
            ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            q   = urllib.parse.quote(domain)
            url = f'https://searchcode.com/api/codesearch_I/?q={q}&per_page=20'
            req = urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                data = _j.loads(r.read(500_000))
            added = 0
            for item in data.get('results',[]):
                lines = item.get('lines',{})
                for line in lines.values():
                    for m in re.finditer(r'[\w.-]+\.' + re.escape(domain), str(line)):
                        if add_sub(m.group(0)): added += 1
            log.info(f'[passive] searchcode: +{added}')
        except Exception as e:
            log.debug(f'[passive] searchcode: {e}')

    def _recon_publicwww():
        """PublicWWW — source code search (API key optional)."""
        try:
            key = os.environ.get('PUBLICWWW_API_KEY','')
            if not key: return
            import urllib.request, urllib.parse, ssl, json as _j
            ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            q   = urllib.parse.quote(f'site:{domain}')
            url = f'https://publicwww.com/websites/{q}/?export=urls&apikey={key}'
            req = urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=20, context=ctx) as r:
                raw = r.read(500_000).decode('utf-8','ignore')
            added = 0
            for line in raw.splitlines():
                line = line.strip()
                if line and domain in line and add_sub(line): added += 1
            log.info(f'[passive] publicwww: +{added}')
        except Exception as e:
            log.debug(f'[passive] publicwww: {e}')

    def _recon_pulsedive():
        """Pulsedive — threat intelligence (API key optional)."""
        try:
            key = os.environ.get('PULSEDIVE_API_KEY','')
            import urllib.request, urllib.parse, ssl, json as _j
            ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            url = f'https://pulsedive.com/api/explore.php?q=ioc%3D{urllib.parse.quote(domain)}&limit=100&pretty=1'
            if key: url += f'&key={key}'
            req = urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                data = _j.loads(r.read(500_000))
            added = 0
            for item in data.get('results',[]):
                ioc = item.get('ioc','')
                if domain in ioc and add_sub(ioc): added += 1
            log.info(f'[passive] pulsedive: +{added}')
        except Exception as e:
            log.debug(f'[passive] pulsedive: {e}')

    def _recon_socradar():
        """SOCRadar — threat intel (API key optional)."""
        try:
            key = os.environ.get('SOCRADAR_API_KEY','')
            if not key: return
            import urllib.request, ssl, json as _j
            ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            url = f'https://platform.socradar.com/api/threat/intelligence/domain?domain={domain}&apiKey={key}'
            req = urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
                data = _j.loads(r.read(500_000))
            added = 0
            for sub in data.get('subdomains',[]):
                if add_sub(sub): added += 1
            log.info(f'[passive] socradar: +{added}')
        except Exception as e:
            log.debug(f'[passive] socradar: {e}')


    # ── Robtex (free) ─────────────────────────────────────────────────────────
    def _recon_robtex():
        subs = set()
        try:
            d = _fetch_json(f"https://freeapi.robtex.com/pdns/forward/{domain}")
            if d:
                for e in (d if isinstance(d, list) else [d]):
                    rrname = e.get("rrname","")
                    c = _clean(rrname, domain)
                    if c: subs.add(c)
        except Exception as e:
            log.debug(f"[passive] robtex: {e}")
        log.info(f"[passive] robtex: {len(subs)} subs")
        add(list(subs))

    # ── DNSRepo (free) ────────────────────────────────────────────────────────
    def _recon_dnsrepo():
        subs = set()
        try:
            d = _fetch_json(f"https://dnsrepo.noc.org/?search={domain}&type=A&format=json")
            items = d if isinstance(d, list) else (d or {}).get("results",[])
            for item in (items or []):
                host = item.get("name","") or item.get("host","") or ""
                c = _clean(host, domain)
                if c: subs.add(c)
        except Exception as e:
            log.debug(f"[passive] dnsrepo: {e}")
        log.info(f"[passive] dnsrepo: {len(subs)} subs")
        add(list(subs))

    # ── Facebook Certificate Transparency (free) ──────────────────────────────
    def _recon_facebook_ct():
        subs = set()
        try:
            d = _fetch_json(f"https://crt.sh/?q=%.{domain}&output=json&limit=1000")
            for e in (d or []):
                for name in (e.get("name_value","") or "").split("\n"):
                    c = _clean(name.strip().lstrip("*."), domain)
                    if c: subs.add(c)
        except Exception as e:
            log.debug(f"[passive] facebook_ct: {e}")
        log.info(f"[passive] facebook_ct: {len(subs)} subs")
        add(list(subs))

    # ── C99.nl (needs C99_API_KEY) ────────────────────────────────────────────
    def _recon_c99():
        api_key = os.environ.get("C99_API_KEY","")
        if not api_key: return
        subs = set()
        try:
            d = _fetch_json(f"https://api.c99.nl/subdomainfinder?key={api_key}&domain={domain}&json")
            for s in (d or {}).get("subdomains",[]) or []:
                host = s.get("subdomain","") if isinstance(s,dict) else str(s)
                c = _clean(host, domain)
                if c: subs.add(c)
        except Exception as e:
            log.debug(f"[passive] c99: {e}")
        log.info(f"[passive] c99: {len(subs)} subs")
        add(list(subs))

    # ── IntelX (needs INTELX_API_KEY) ────────────────────────────────────────
    def _recon_intelx():
        api_key = os.environ.get("INTELX_API_KEY","")
        host    = os.environ.get("INTELX_HOST","2.intelx.io")
        if not api_key: return
        subs = set()
        try:
            req = urllib.request.Request(
                f"https://{host}/phonebook/search",
                data=json.dumps({"term":domain,"maxresults":10000,"media":0,"target":1}).encode(),
                headers={"X-Key":api_key,"Content-Type":"application/json"},method="POST")
            with urllib.request.urlopen(req,timeout=20,context=_ctx()) as r:
                d = json.loads(r.read())
            sid = d.get("id","")
            if sid:
                res = _fetch_json(f"https://{host}/phonebook/search/result?id={sid}&limit=10000&offset=0")
                for item in (res or {}).get("selectors",[]):
                    c = _clean(item.get("selectorvalue",""), domain)
                    if c: subs.add(c)
        except Exception as e:
            log.debug(f"[passive] intelx: {e}")
        log.info(f"[passive] intelx: {len(subs)} subs")
        add(list(subs))

    # ── Quake (needs QUAKE_TOKEN) ─────────────────────────────────────────────
    def _recon_quake():
        token = os.environ.get("QUAKE_TOKEN","")
        if not token: return
        subs = set()
        try:
            req = urllib.request.Request(
                "https://quake.360.net/api/v3/search/quake_service",
                data=json.dumps({"query":f"domain: *.{domain}","size":500,"start":0}).encode(),
                headers={"X-QuakeToken":token,"Content-Type":"application/json"},method="POST")
            with urllib.request.urlopen(req,timeout=20,context=_ctx()) as r:
                d = json.loads(r.read())
            for item in (d or {}).get("data",[]):
                for srv in item.get("service",[]):
                    c = _clean(srv.get("name",""), domain)
                    if c: subs.add(c)
        except Exception as e:
            log.debug(f"[passive] quake: {e}")
        log.info(f"[passive] quake: {len(subs)} subs")
        add(list(subs))

    # ── ThreatBook (needs THREATBOOK_API_KEY) ─────────────────────────────────
    def _recon_threatbook():
        api_key = os.environ.get("THREATBOOK_API_KEY","")
        if not api_key: return
        subs = set()
        try:
            d = _fetch_json(f"https://api.threatbook.cn/v3/domain/sub_domains?apikey={api_key}&resource={domain}&start=0&count=500")
            for s in (d or {}).get("data",{}).get("sub_domains",{}).get("data",[]):
                c = _clean(s, domain)
                if c: subs.add(c)
        except Exception as e:
            log.debug(f"[passive] threatbook: {e}")
        log.info(f"[passive] threatbook: {len(subs)} subs")
        add(list(subs))

    # ── DNSDB (needs DNSDB_API_KEY) ───────────────────────────────────────────
    def _recon_dnsdb():
        api_key = os.environ.get("DNSDB_API_KEY","")
        if not api_key: return
        subs = set()
        try:
            req = urllib.request.Request(
                f"https://api.dnsdb.info/dnsdb/v2/lookup/rrset/name/*.{domain}?limit=1000",
                headers={"X-API-Key":api_key,"Accept":"application/x-ndjson"})
            with urllib.request.urlopen(req,timeout=20,context=_ctx()) as r:
                for line in r.read().decode().splitlines():
                    if not line.strip(): continue
                    try:
                        obj = json.loads(line)
                        c = _clean(obj.get("obj",{}).get("rrname","").rstrip("."), domain)
                        if c: subs.add(c)
                    except: pass
        except Exception as e:
            log.debug(f"[passive] dnsdb: {e}")
        log.info(f"[passive] dnsdb: {len(subs)} subs")
        add(list(subs))

    # ── BuiltWith (needs BUILTWITH_API_KEY) ───────────────────────────────────
    def _recon_builtwith():
        api_key = os.environ.get("BUILTWITH_API_KEY","")
        if not api_key: return
        subs = set()
        try:
            d = _fetch_json(f"https://api.builtwith.com/rv3/api.json?KEY={api_key}&LOOKUP={domain}")
            for result in (d or {}).get("Results",[]):
                for path in result.get("Result",{}).get("Paths",[]):
                    c = _clean(path.get("Url",""), domain)
                    if c: subs.add(c)
        except Exception as e:
            log.debug(f"[passive] builtwith: {e}")
        log.info(f"[passive] builtwith: {len(subs)} subs")
        add(list(subs))

    # ── Sublist3r (Python library) ────────────────────────────────────────────
    def _recon_sublist3r():
        subs = set()
        try:
            import sublist3r as _sl3r
            import os as _os, sys as _sys
            # Suppress sublist3r stderr (DNSdumpster CSRF crash noise)
            _devnull = open(_os.devnull, 'w')
            _old_stderr = _sys.stderr
            _sys.stderr = _devnull
            try:
                results = _sl3r.main(domain, 40, savefile=None, ports=None,
                                     silent=True, verbose=False,
                                     enable_bruteforce=False, engines=None)
            finally:
                _sys.stderr = _old_stderr
                _devnull.close()
            for s in (results or []):
                c = _clean(s, domain)
                if c: subs.add(c)
        except ImportError:
            pass
        except Exception as e:
            log.debug(f"[passive] sublist3r: {e}")
        if subs:
            log.info(f"[passive] sublist3r: {len(subs)} subs")
            add(list(subs))


    funcs = [
        # No API key needed — primary sources
        crt_sh, certspotter, hackertarget, alienvault, urlscan,
        rapiddns, wayback, threatminer, anubis, columbus,
        chaos_pd, bevigil, dns_resolve_common, spf_extract,
        # Additional free sources
        bufferover, dnsdumpster, sonar_fdns, whoisxmlapi, archive_urls,
        # THC API (dawgyg) — no key needed, massive DB
        thc_api,
        # API-key enhanced (silently skipped if key not set)
        securitytrails, shodan, virustotal, censys, fofa,
        hunter_io, passivetotal, chaos_api, netlas, zoomeye,
        github_code,
        asn_bgp,
        pugrecon,
        _recon_leakix, _recon_fullhunt, _recon_trickest, _recon_certstream,
        _recon_grep_app, _recon_binaryedge, _recon_onyphe, _recon_greynoise,
        _recon_robtex, _recon_dnsrepo, _recon_facebook_ct,
        _recon_c99, _recon_intelx, _recon_quake, _recon_threatbook,
        _recon_dnsdb, _recon_builtwith, _recon_sublist3r,
        _recon_searchcode, _recon_publicwww, _recon_pulsedive, _recon_socradar,
        _recon_san, _recon_abuseip,
        _recon_waymore, _recon_otx,
        # 2025/2026 additions
        _recon_dnsdumpster, _recon_columbus, _recon_digitorus,
        _recon_merklemap, _recon_shrewdeye, _recon_crtsh_api2,
        _recon_jldc, _recon_shodandns,
        _recon_github_subdomains,
        _recon_csprecon,
        _recon_analyticsrelationships,
        _recon_bbot,
    ]
    # Wrap each target to suppress gevent+Python3.13 KeyError on thread cleanup
    def _safe_target(fn):
        def _wrapped():
            try:
                fn()
            except Exception as _te:
                log.debug(f"[passive] thread {fn.__name__} error: {_te}")
        return _wrapped
    # Source-aware tracking: each thread collects into its own set, then merges
    _source_snap: dict = {}
    _snap_lock = threading.Lock()

    def _wrap_source(fn):
        def _tracked():
            # Each thread appends to a LOCAL list, then bulk-adds to shared results
            _local: list = []
            _sname = getattr(fn, "__name__", str(fn))
            # Patch 'add' to capture per-source subs
            orig_add = add
            def _local_add(subs_list):
                _local.extend(subs_list or [])
                orig_add(subs_list)  # still goes to shared results
            # Replace add in the closure temporarily — not possible cleanly,
            # so use snapshot diff with a per-thread marker set
            _before_snap = set(results)
            _safe_target(fn)()
            _after_snap = set(results)
            delta = len(_after_snap - _before_snap)
            with _snap_lock:
                _source_snap[_sname] = delta
        return _tracked

    threads = [threading.Thread(target=_wrap_source(f), daemon=True, name=f.__name__) for f in funcs]
    for t in threads: t.start()

    # Wait — give THC and ST more time since they paginate
    for t in threads: t.join(timeout=45)

    unique = list(set(results))
    log.info(f"[passive] total from ALL sources: {len(unique)} subs")
    
    # Notify source_callback if provided
    if source_callback:
        for _sname, _cnt in _source_snap.items():
            try: source_callback(_sname, _cnt)
            except Exception: pass

    return unique

# ── DNS bruteforce ────────────────────────────────────────────────────────────
def _dns_bruteforce(domain: str, T: dict, add_sub, seclists_path: str = "") -> int:
    if not T["dnsx"]: return 0
    # Find wordlist
    wl = ""
    _home = os.path.expanduser("~")
    for candidate in [
        seclists_path,
        # Standard Kali SecLists locations
        "/usr/share/seclists/Discovery/DNS/subdomains-top1million-110000.txt",
        "/usr/share/seclists/Discovery/DNS/subdomains-top1million-20000.txt",
        "/usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt",
        "/usr/share/wordlists/seclists/Discovery/DNS/subdomains-top1million-110000.txt",
        "/usr/share/wordlists/seclists/Discovery/DNS/subdomains-top1million-20000.txt",
        # Kali user paths
        f"{_home}/Desktop/recon/SecLists/Discovery/DNS/subdomains-top1million-110000.txt",
        f"{_home}/Desktop/recon/SecLists/Discovery/DNS/subdomains-top1million-20000.txt",
        f"{_home}/Desktop/recon/SecLists/Discovery/DNS/bitquark-subdomains-top100000.txt",
        "/home/kali/Desktop/recon/SecLists/Discovery/DNS/subdomains-top1million-110000.txt",
        "/root/Desktop/recon/SecLists/Discovery/DNS/subdomains-top1million-110000.txt",
        # SecLists installed via apt
        "/opt/seclists/Discovery/DNS/subdomains-top1million-110000.txt",
        "/opt/SecLists/Discovery/DNS/subdomains-top1million-110000.txt",
    ]:
        if candidate and os.path.isfile(candidate):
            wl = candidate
            break

    if not wl:
        log.warning("No SecLists wordlist found for bruteforce")
        return 0

    log.info(f"[bruteforce] using wordlist: {wl}")
    count = 0
    # Generate full hostnames from wordlist
    words = [l.strip() for l in open(wl).readlines() if l.strip() and not l.startswith("#")][:50000]
    hostnames = [f"{w}.{domain}" for w in words]
    tmp = _tmp(hostnames)
    try:
        proc = _run([T["dnsx"], "-l", tmp, "-silent", "-a", "-resp", "-threads", "150"])
        _dnsx1_t0 = time.monotonic()
        for line in proc.stdout:
            if (time.monotonic()-_dnsx1_t0) > 175: proc.kill(); break
            # Output: "hostname [ip]" or just "hostname"
            h = line.strip().split()[0] if line.strip() else ""
            s = _clean(h, domain)
            if s and add_sub(s):
                count += 1
        proc.wait(timeout=180)
    except Exception as e:
        log.warning(f"dnsx bruteforce: {e}")
    finally:
        _rm(tmp)
    log.info(f"[bruteforce] found {count} new subs")
    return count

# ── Permutation engine ────────────────────────────────────────────────────────
def _permutations(domain: str, T: dict, subs: Set[str], add_sub) -> int:
    """
    Smart AI-powered permutation generator.
    Analyzes found subdomains to infer company naming patterns,
    then generates targeted permutations from those patterns.
    """
    if not T["dnsx"] or len(subs) < 2: return 0

    # ── Extract prefixes from known subs ────────────────────────────────────
    prefixes = set()
    company_words = set()
    for sub in list(subs)[:500]:
        prefix = sub[:-(len(domain)+1)] if sub.endswith("."+domain) else sub
        parts = [p for p in prefix.split(".") if p and len(p) > 1]
        prefixes.update(parts)
        # Extract meaningful words (skip generic infra terms)
        for p in parts:
            words = re.split(r'[-_]', p)
            for w in words:
                if len(w) > 2 and w not in {"www","mail","ftp","smtp","ns","mx",
                                              "cdn","api","app","dev","test"}:
                    company_words.add(w.lower())

    # ── Environment & function mutations ───────────────────────────────────
    env_mutations    = ["dev","stg","staging","test","qa","uat","sandbox",
                        "prod","production","preprod","beta","alpha","rc",
                        "demo","preview","internal","ext","external"]
    region_mutations = ["us","eu","uk","ap","asia","us-east","us-west",
                        "us1","us2","eu1","eu2","ap1","global","local"]
    version_mutations= ["v1","v2","v3","v4","old","new","2","3","next","legacy"]
    func_mutations   = ["api","app","admin","portal","dashboard","console",
                        "login","auth","sso","id","oauth","jwt","saml",
                        "ws","websocket","grpc","graphql","rest","rpc",
                        "cdn","assets","static","media","img","upload",
                        "git","jenkins","ci","build","deploy","k8s",
                        "monitor","metrics","logs","status","health",
                        "pay","payments","billing","checkout","shop",
                        "mobile","ios","android","web","support","help"]
    all_mutations = env_mutations + region_mutations + version_mutations + func_mutations

    # ── Generate permutations ───────────────────────────────────────────────
    perms = set()
    prefix_list = list(prefixes)[:100]

    for p in prefix_list:
        for m in all_mutations:
            perms.add(f"{p}-{m}.{domain}")
            perms.add(f"{m}-{p}.{domain}")
            perms.add(f"{p}.{m}.{domain}")
            perms.add(f"{m}.{p}.{domain}")

    # Company-word based permutations (smarter targeting)
    for w in list(company_words)[:30]:
        for m in func_mutations[:15]:
            perms.add(f"{w}-{m}.{domain}")
            perms.add(f"{m}-{w}.{domain}")
            perms.add(f"{w}{m}.{domain}")
        for e in env_mutations[:8]:
            perms.add(f"{w}-{e}.{domain}")

    # Number suffix variants (common in enterprise)
    for p in prefix_list[:40]:
        for n in range(1, 6):
            perms.add(f"{p}{n}.{domain}")
            perms.add(f"{p}-{n}.{domain}")

    # Tech-stack-aware mutations based on detected technologies
    TECH_PREFIXES = {
        "spring": ["api","app","spring","backend","svc","service","microservice"],
        "jenkins": ["jenkins","ci","cd","build","deploy","pipeline","automation"],
        "kubernetes": ["k8s","kube","cluster","infra","platform","orchestrator"],
        "docker": ["registry","hub","images","containers","docker","harbor"],
        "graphql": ["graphql","api","graph","gql","playground"],
        "wordpress": ["blog","wp","cms","news","www","media","content"],
        "node": ["node","api","backend","ws","socket","express"],
        "java": ["java","tomcat","jboss","wildfly","spring","app","api"],
        "php": ["php","laravel","symfony","backend","legacy"],
    }
    detected_tech = [t.lower() for t in getattr(_permutations, '_tech', [])]
    for tech, tprefixes in TECH_PREFIXES.items():
        if any(tech in dt for dt in detected_tech):
            for tp in tprefixes:
                perms.add(f"{tp}.{domain}")
                for e in env_mutations[:5]:
                    perms.add(f"{tp}-{e}.{domain}")
                    perms.add(f"{e}-{tp}.{domain}")

    # Root domain prefix permutations (very effective for subdomain targets)
    parts = domain.split(".")
    if len(parts) >= 3:
        root = ".".join(parts[-2:])
        # Use same prefixes on root domain too
        for p in list(prefix_list)[:20]:
            perms.add(f"{p}.{root}")
        for m in func_mutations[:20]:
            perms.add(f"{m}.{root}")

    # Remove already known subs
    perms -= subs
    perms.discard(domain)
    perms = {p for p in perms if p.endswith(f".{domain}")}

    if not perms:
        return 0

    log.info(f"[permutations] testing {len(perms)} mutations from {len(prefixes)} prefixes")

    tmp = _tmp(list(perms))
    count = 0
    try:
        proc = _run([T["dnsx"], "-l", tmp, "-silent", "-a", "-threads", "200", "-rate-limit", "500"])
        _dnsx2_t0 = time.monotonic()
        for line in proc.stdout:
            if (time.monotonic()-_dnsx2_t0) > 175: proc.kill(); break
            h = line.strip().split()[0] if line.strip() else ""
            s = _clean(h, domain)
            if s and add_sub(s): count += 1
        try: proc.wait(timeout=5)
        except: proc.kill()
    except Exception as e:
        log.warning(f"permutations: {e}")
    finally:
        _rm(tmp)
    log.info(f"[permutations] found {count} new subs from {len(perms)} tested")
    return count

# ════════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════════
# ── Scope Guard — Private IP / SSRF protection ───────────────────────────────
import ipaddress as _ipaddr

_PRIVATE_RANGES = [
    _ipaddr.ip_network("127.0.0.0/8"),
    _ipaddr.ip_network("10.0.0.0/8"),
    _ipaddr.ip_network("172.16.0.0/12"),
    _ipaddr.ip_network("192.168.0.0/16"),
    _ipaddr.ip_network("169.254.0.0/16"),  # link-local / cloud metadata
    _ipaddr.ip_network("100.64.0.0/10"),   # shared address space
    _ipaddr.ip_network("::1/128"),
    _ipaddr.ip_network("fc00::/7"),
    _ipaddr.ip_network("fe80::/10"),
    _ipaddr.ip_network("0.0.0.0/8"),
]
_LOCAL_ALIASES = {"localhost","localhost.localdomain","local","broadcasthost"}

def _is_private_ip(addr: str) -> bool:
    try:
        ip = _ipaddr.ip_address(addr)
        return any(ip in net for net in _PRIVATE_RANGES)
    except: return False

def _scope_guard_host(hostname: str) -> tuple:
    """
    Returns (allowed: bool, reason: str)
    Blocks private IPs, localhost aliases, cloud metadata endpoints.
    """
    if not hostname: return False, "empty hostname"
    hostname = hostname.lower().strip()
    if hostname in _LOCAL_ALIASES: return False, f"localhost alias blocked: {hostname}"
    if hostname == "169.254.169.254": return False, "cloud metadata endpoint blocked"
    # Resolve and check
    try:
        import socket as _sock
        addrs = [info[4][0] for info in _sock.getaddrinfo(hostname, None)]
        for addr in addrs:
            if _is_private_ip(addr):
                return False, f"private IP blocked: {addr}"
    except: pass  # DNS failure is handled elsewhere
    return True, None




# ── SECRET SCANNER ────────────────────────────────────────────────────────────
_SECRET_PATTERNS = [
    ("AKIA[0-9A-Z]{16}", "AWS Access Key ID", "critical"),
    ("sk_live_[A-Za-z0-9]{24,}", "Stripe Live Secret Key", "critical"),
    ("ghp_[A-Za-z0-9]{36}", "GitHub Personal Token", "critical"),
    ("gho_[A-Za-z0-9]{36}", "GitHub OAuth Token", "critical"),
    ("xox[baprs]-[A-Za-z0-9\\-]{10,}", "Slack Token", "high"),
    ("AIza[0-9A-Za-z\\-_]{35}", "Google API Key", "high"),
    ("eyJ[A-Za-z0-9_\\-]{10,}\\.[A-Za-z0-9_\\-]{10,}\\.[A-Za-z0-9_\\-]{10,}", "JWT Token", "high"),
    ("SG\\.[A-Za-z0-9_\\-]{22}\\.[A-Za-z0-9_\\-]{43}", "SendGrid API Key", "critical"),
    ("SK[0-9a-fA-F]{32}", "Twilio Auth Token", "high"),
    ("-----BEGIN (RSA |EC )?PRIVATE KEY-----", "Private Key Exposed", "critical"),
]

def _scan_js_secrets(js_url, content, emit_fn):
    import re as _re
    found = []
    for pat, name, sev in _SECRET_PATTERNS:
        try:
            for m in _re.findall(pat, content)[:2]:
                val = m if isinstance(m, str) else (m[0] if m else "")
                if len(val) > 6:
                    secret = {"type": name, "url": js_url,
                              "value": val[:30]+"..." if len(val)>30 else val,
                              "severity": sev}
                    found.append(secret)
                    emit_fn({"type": "secret_found", "secret": secret})
        except Exception:
            pass
    return found


def run_recon(domain: str, opts: dict, q: queue.Queue, db):
    T = _tools()

    # ── Full pre-recon tool validation (version-check, wrong-binary detection) ─
    # validate_for_recon() checks all recon tools and nullifies broken ones in T
    # so every `if T.get("tool"):` guard downstream correctly skips broken tools.
    try:
        from engine.tool_health import validate_for_recon as _vfr
        _tool_health = _vfr(T)
        _broken = [n for n, h in _tool_health.items() if not h.get("ok") and h.get("reason") != "not_found"]
        if _broken:
            log.warning(f"[tool-health] broken_tools={_broken} → those stages will be skipped")
    except Exception as _the:
        log.debug(f"[tool-health] validate_for_recon error: {_the}")
        _tool_health = {}

    _subs = set(); _lives = []; _ends = []  # refs for finally

    def emit(e):
        try: q.put(e)
        except: pass

    try:
        # Fire scan_started notification
        try:
            from engine.notify import get_notifier as _gn
            _gn().notify_event("scan_started", {"domain": domain})
        except Exception: pass
        _run_recon_inner(domain, opts, q, db, T, emit)
    except Exception as _top_err:
        log.error(f"[recon] fatal error: {_top_err}")
        try: q.put({"type":"error","msg":str(_top_err)})
        except: pass
        try:
            from engine.notify import get_notifier as _gne
            _gne().notify_event("scan_error", {"domain": domain, "error": str(_top_err)[:200]})
        except Exception: pass
    finally:
        # Ensure scan and nuclei stages are never left in 'run'
        try:
            _current_scan  = db.get_step(domain, "scan")
            _current_nuclei = db.get_step(domain, "nuclei")
            if _current_scan  and _current_scan.get("state")  == "run":
                step("scan",   "done", "scan complete")
            if _current_nuclei and _current_nuclei.get("state") == "run":
                step("nuclei", "done", "nuclei complete")
        except Exception: pass
        # GUARANTEE recon_done always fires so UI never hangs
        # Fire recon_done notification
        try:
            from engine.notify import get_notifier as _gn2
            _gn2().notify_event("recon_done", {
                "domain":    domain,
                "subs":      len(_subs)      if _subs else 0,
                "live":      len(_lives)     if _lives else 0,
                "endpoints": len(_ends)      if _ends else 0,
            })
        except Exception: pass
        try:
            _d = db.get_hosts(domain)
            _s = len(_d.get("subs",[]))
            _l = len(_d.get("live",[]))
            _e = db.count_endpoints(domain) if hasattr(db,"count_endpoints") else 0
        except: _s=_l=_e=0
        try: q.put({"type":"recon_done","subs":_s,"live":_l,"endpoints":_e})
        except: pass

def _run_recon_inner(domain: str, opts: dict, q: queue.Queue, db, T, emit):
    skip_subs      = opts.get("skip_subs", False)
    skip_crawl     = opts.get("skip_crawl", False)
    skip_port      = opts.get("skip_port", False)
    skip_endpoints = opts.get("skip_endpoints", False)
    skip_js        = opts.get("skip_js", False)
    port_mode      = opts.get("port_mode", "top100")

    # ── IMMEDIATE GUARD: block all-ports at the very first assignment ──────────
    # This runs before any conditional, before any tool selection,
    # before any log that could show profile=all or port_count=65535.
    if port_mode == "all":
        log.warning(
            f"[ports] FORCED DOWNGRADE → top100"
            f" (opts.port_mode=all rejected at source)"
        )
        port_mode = "top100"
    # Also kill stale saved-job keys that could sneak past
    for _stale_key in ("profile", "scan_profile", "port_profile"):
        if opts.get(_stale_key) == "all":
            log.warning(
                f"[ports] FORCED DOWNGRADE → top100"
                f" (stale opts.{_stale_key}=all removed)"
            )
            port_mode = "top100"

    custom_ports   = opts.get("custom_ports", "")

    # ── Hard limits — prevents infinite subdomain loops ──────────────────────
    MAX_SUBS       = int(opts.get("max_subs", 50000))    # hard cap on subdomains
    MAX_LIVE       = int(opts.get("max_live", 2000))    # hard cap on live hosts to probe
    MAX_ENDPOINTS  = int(opts.get("max_endpoints", 200000)) # hard cap on endpoints
    JS_MAX         = int(opts.get("js_max", 2000))           # max JS files to deep-analyse

    # Extract root/apex domain for passive sources
    # e.g. ftb.t-mobile.com → t-mobile.com, sub.example.co.uk → example.co.uk
    _parts = domain.split(".")
    if len(_parts) >= 3:
        # Detect common 2-part TLDs (co.uk, com.au, etc.)
        _tld2 = {
            "co.uk","com.au","co.nz","com.br","co.in","net.au","org.uk",
            "gov.uk","edu.au","com.mx","co.za","org.au","net.nz","co.jp",
        }
        last2 = ".".join(_parts[-2:])
        if last2 in _tld2:
            root_domain = ".".join(_parts[-3:])
        else:
            root_domain = ".".join(_parts[-2:])
    else:
        root_domain = domain

    if root_domain != domain:
        log.info(f"[recon] subdomain detected — also scanning root domain: {root_domain}")
    else:
        root_domain = domain
    SUBS_TIMEOUT   = int(opts.get("subs_timeout", 600)) # seconds for entire subs phase (passive collection)
    CRAWL_TIMEOUT  = int(opts.get("crawl_timeout", 900))

    subs       = set()
    endpoints  = set()
    live_hosts = []

    # ── Auto-resume: load previously discovered subdomains ───────────────
    _resume_file = None
    try:
        import pathlib as _pl
        _data_dir = _pl.Path(os.environ.get("BUGSCAN_DATA_DIR","data"))
        _safe_dom = re.sub(r"[^a-zA-Z0-9._-]","_", domain)
        _resume_file = _data_dir / _safe_dom / "subs_resume.txt"
        if _resume_file.exists():
            with open(_resume_file, "r", encoding="utf-8", errors="ignore") as _rf:
                _loaded = 0
                for _line in _rf:
                    _s = _line.strip()
                    if _s: subs.add(_s); _loaded += 1
            if _loaded:
                log.info(f"[recon] auto-resume: loaded {_loaded} subs from previous run")
                emit({"type":"step","name":"subdomains","state":"run",
                      "meta":f"Resumed — {_loaded} subs from previous run"})
    except Exception as _re:
        log.debug(f"[recon] resume load: {_re}")

    # ── Pre-load previously discovered hosts from DB ──────────────────────
    # This ensures crawl/ports/endpoints work even when HTTP probe fails
    try:
        _prev = db.get_hosts(domain)
        _prev_live = _prev.get("live", _prev.get("active", []))
        for _h in _prev_live[:500]:
            if _h not in live_hosts:
                live_hosts.append(_h)
        if live_hosts:
            log.info(f"[recon] pre-loaded {len(live_hosts)} known live hosts from DB")
        _prev_subs = _prev.get("subs", [])
        for _s in _prev_subs:  # no cap on resume load
            subs.add(_s)
        if _prev_subs:
            log.info(f"[recon] pre-loaded {len(_prev_subs)} known subs from DB")
    except Exception as _e:
        log.debug(f"[recon] pre-load: {_e}")

    def emit(e): q.put(e)
    _step_timers = {}  # {step_name: start_timestamp}

    def step(name, state, meta=""):
        import time as _t
        ts = _t.time()
        # Track timing per step
        if state == "run":
            _step_timers[name] = ts
        elapsed = ""
        if state in ("done", "error", "skip") and name in _step_timers:
            secs = ts - _step_timers[name]
            if secs >= 60:
                elapsed = f" ({secs/60:.1f}m)"
            elif secs >= 1:
                elapsed = f" ({secs:.0f}s)"
            else:
                elapsed = f" ({secs*1000:.0f}ms)"
        db.set_step(domain, name, state)
        emit({"type":"step","name":name,"state":state,
              "meta":meta,"elapsed":elapsed,
              "ts": int(ts)})

    # ── Export autosave state (shared mutable cells) ───────────────────────
    _last_export_ts:     list = [0.0]
    _last_export_count:  list = [0]
    _last_export_reason: list = ["none"]

    def _autosave_export(reason: str = "periodic") -> int:
        """Write current DB endpoints to export files. Returns URL count saved."""
        try:
            from engine.endpoint_export import export_endpoints as _eexp
            from pathlib import Path as _AEPath
            _db_eps   = db.get_endpoints(domain, limit=200000) or []
            _url_list = _db_eps if _db_eps else list(endpoints)
            if not _url_list:
                return 0
            _out_dir = str(_AEPath(__file__).parent / "data" / "exports" / domain)
            _written = _eexp(domain, _url_list, _out_dir, fmt="txt", min_count=1)
            n = len(_url_list)
            _last_export_ts[0]     = time.monotonic()
            _last_export_count[0]  = n
            _last_export_reason[0] = reason
            log.info(
                f"[export] autosave domain={domain} urls={n}"
                f" reason={reason} files={len(_written)}"
            )
            emit({"type":   "export_autosave",
                  "domain": domain,
                  "urls":   n,
                  "reason": reason,
                  "files":  len(_written)})
            return n
        except Exception as _ae:
            log.debug(f"[export] autosave error ({reason}): {_ae}")
            return 0

    # ── Subdomain source tracking + scoring ───────────────────────────────────
    _sub_sources:   dict = {}   # hostname → source string
    _sub_scores:    dict = {}   # hostname → int score
    _source_counts: dict = {}   # source   → int count
    _wildcard_ips:  set  = set()  # IPs that indicate wildcard DNS
    _wildcard_filtered: list = [0]  # mutable counter

    # Score keywords — higher = probe first
    _SCORE_RULES = [
        (10, ["payment","billing","checkout","stripe","pay","invoice"]),
        (9,  ["api","graphql","rest","grpc","rpc"]),
        (9,  ["admin","administrator","manage","management","cpanel","plesk"]),
        (8,  ["auth","login","sso","oauth","saml","oidc","idp","identity"]),
        (8,  ["vpn","internal","corp","intranet","private"]),
        (7,  ["dev","develop","developer","staging","stage","preprod","pre-prod","qa","test"]),
        (7,  ["dashboard","portal","panel","console"]),
        (6,  ["upload","files","file","cdn","assets","media","storage","s3"]),
        (5,  ["mail","smtp","mx","email","webmail","imap"]),
        (4,  ["app","web","service","srv","svc"]),
        (3,  ["www","www2","www3"]),
        (1,  [""]),  # default score = 1
    ]

    def _score_sub(host: str) -> int:
        hl = host.lower()
        prefix = hl.split(".")[0]
        for score, keywords in _SCORE_RULES:
            if any(k in prefix for k in keywords if k):
                return score
        return 1

    def add_sub(host: str, source: str = "") -> bool:
        if len(subs) >= MAX_SUBS:
            return False   # hard cap on collection
        s = _clean(host, domain) if host else None
        if not s or s in subs: return False
        # Wildcard filter
        if s in _wildcard_ips:
            _wildcard_filtered[0] += 1
            return False
        subs.add(s)
        # Track source (first-seen wins for primary source label)
        if s not in _sub_sources:
            _sub_sources[s] = source or "unknown"
        if source:
            _source_counts[source] = _source_counts.get(source, 0) + 1
        # Score for probe ordering
        _sub_scores[s] = _score_sub(s)
        db.add_sub(domain, s)
        emit({"type":"sub","host":s})
        return True

    def add_endpoint(url: str, crawled: bool = False,
                    source: str = "") -> bool:
        if len(endpoints) >= MAX_ENDPOINTS:
            return False
        url = url.strip()
        if not url or not url.startswith("http"): return False
        # Reject relative URLs — they have no hostname and break all scanners
        try:
            import urllib.parse as _up
            _parsed = _up.urlparse(url)
            if not _parsed.netloc or _parsed.scheme not in ("http","https"):
                return False
        except Exception:
            return False
        # ── Scope check: respect program include/exclude rules ────────────────
        try:
            _smeta = db.get_meta(domain) or {} if db else {}
            _sdict = _smeta.get("scope", {})
            if _sdict.get("includes") or _sdict.get("excludes"):
                from engine.scope_manager import ScopeManager as _SMr
                if not _SMr.from_dict(_sdict).is_in_scope(url):
                    return False  # silently drop out-of-scope
        except Exception:
            pass
        new = url not in endpoints
        if new:
            endpoints.add(url)
            _src = source or ("crawl" if crawled else "")
            # Always save under the requested scan domain (Phase 3 fix)
            saved = db.add_endpoint(domain, url, source=_src)
            if saved:
                log.debug(
                    f"[endpoint] requested_domain={domain}"
                    f" storage_domain={domain}"
                    f" source={_src} url={url[:80]}"
                )
            emit({"type":"endpoint","url":url})
        if crawled: emit({"type":"crawled","url":url})
        return new

    db.save_meta(domain, {"recon_opts":opts,"started":time.strftime("%Y-%m-%dT%H:%M:%SZ")})

    # ══════════════════════════════════════════════════
    # 1. SUBDOMAINS — with hard time limit
    # ══════════════════════════════════════════════════
    add_sub(domain)
    # ── Periodic autosave thread (every 60s) ──────────────────────────────────
    import threading as _exp_th
    _export_stop = _exp_th.Event()
    def _periodic_export():
        while not _export_stop.wait(60):
            if _stopped(q):
                break
            _autosave_export("periodic")
    _exp_th.Thread(target=_periodic_export, daemon=True, name="export-autosave").start()

    if skip_subs:
        step("subdomains","skip")
    else:
        step("subdomains","run")
        subs_deadline = time.time() + SUBS_TIMEOUT

        def _timed_out():
            return time.time() > subs_deadline or len(subs) >= MAX_SUBS

        # Passive sources — run in parallel with overall deadline
        passive_results = []
        passive_lock    = threading.Lock()

        def _collect_passive():
            try:
                def _on_source(src_name, count):
                    # Map internal function names to readable source names
                    _src_map = {
                        'crt_sh': 'crtsh', 'certspotter': 'certspotter',
                        'hackertarget': 'hackertarget', 'alienvault': 'alienvault',
                        'urlscan': 'urlscan', 'rapiddns': 'rapiddns',
                        'wayback': 'wayback', 'threatminer': 'threatminer',
                        'anubis': 'anubis', 'columbus': 'columbus',
                        'chaos_pd': 'chaos', 'bevigil': 'bevigil',
                        'dns_resolve_common': 'dns_resolve_common',
                        'spf_extract': 'spf_extract', 'bufferover': 'bufferover',
                        'dnsdumpster': 'dnsdumpster', 'sonar_fdns': 'sonar_fdns',
                        'whoisxmlapi': 'whoisxmlapi', 'archive_urls': 'archive_urls',
                        'thc_api': 'thc_api', 'securitytrails': 'securitytrails',
                        'shodan': 'shodan', 'virustotal': 'virustotal',
                        'censys': 'censys', 'fofa': 'fofa',
                        'hunter_io': 'hunter_io', 'passivetotal': 'passivetotal',
                        'chaos_api': 'chaos_api', 'netlas': 'netlas',
                        'zoomeye': 'zoomeye', 'github_code': 'github_code',
                        'asn_bgp': 'asn_bgp', 'pugrecon': 'pugrecon',
                        '_recon_leakix': 'leakix', '_recon_fullhunt': 'fullhunt',
                        '_recon_trickest': 'trickest', '_recon_certstream': 'certstream',
                        '_recon_grep_app': 'grepapp', '_recon_binaryedge': 'binaryedge',
                        '_recon_onyphe': 'onyphe', '_recon_greynoise': 'greynoise',
                        '_recon_robtex': 'robtex', '_recon_dnsrepo': 'dnsrepo',
                        '_recon_facebook_ct': 'facebook_ct',
                        '_recon_c99': 'c99', '_recon_intelx': 'intelx',
                        '_recon_quake': 'quake', '_recon_threatbook': 'threatbook',
                        '_recon_dnsdb': 'dnsdb', '_recon_builtwith': 'builtwith',
                        '_recon_sublist3r': 'sublist3r',
                        '_recon_waymore': 'waymore', '_recon_otx': 'otx',
                    }
                    readable = _src_map.get(src_name, src_name)
                    if count > 0:
                        log.info(f"[subdomains] source={readable} raw={count} saved={count}")
                    else:
                        log.debug(f"[subdomains] source={readable} raw=0 saved=0")

                for s in _passive_sources(domain, source_callback=_on_source,
                                           endpoint_callback=add_endpoint):
                    if _timed_out(): break
                    with passive_lock:
                        passive_results.append(s)
                # Also scan root domain if target is a subdomain
                if root_domain != domain:
                    log.info(f"[passive] also scanning root: {root_domain}")
                    for s in _passive_sources(root_domain, source_callback=_on_source,
                                           endpoint_callback=add_endpoint):
                        if _timed_out(): break
                        with passive_lock:
                            passive_results.append(s)
            except Exception as e:
                log.warning(f"passive sources: {e}")

        passive_t = threading.Thread(target=_collect_passive, daemon=True)
        passive_t.start()
        passive_t.join(timeout=SUBS_TIMEOUT - 10)

        _passive_added = 0
        for s in passive_results:
            if _timed_out(): break
            if add_sub(s, source="passive"): _passive_added += 1
        if _passive_added:
            log.info(f"[subdomains] source=passive count={_passive_added}")

        if _stopped(q): return

        step("subdomains","run",f"{len(subs)} passive — running active tools...")

        # Active subdomain tools — runs ALL installed tools in parallel
        if not _timed_out():
            import concurrent.futures as _cf

            def _run_tool(tool_args):
                tool_name, args = tool_args
                if not args or _timed_out(): return 0
                count = 0
                # Per-tool budget: subfinder/amass get 120s, others 60s
                _per_tool_budget = 120 if tool_name in ("subfinder","amass","chaos",
                    "uncover","uncover_ssl","uncover_http") else 60
                try:
                    proc = _run(args, env=_env())
                    _tool_t0 = time.monotonic()
                    for line in proc.stdout:
                        if (time.monotonic()-_tool_t0) > _per_tool_budget: proc.kill(); break
                        if _timed_out() or _stopped(q):
                            proc.kill(); break
                        s = line.strip()
                        if not s: continue
                        # For URL-returning tools, extract the hostname
                        if s.startswith("http"):
                            try:
                                from urllib.parse import urlparse as _up
                                s = _up(s).netloc.split(":")[0]
                            except Exception:
                                pass
                        if s and add_sub(s, source=tool_name): count += 1
                    try: proc.wait(timeout=3)
                    except: proc.kill()
                    _src_dur = round(time.monotonic() - _tool_t0, 1) if '_tool_t0' in dir() else 0
                    if count:
                        log.info(f"[subdomains] source={tool_name} raw={count} saved={count} duration={_src_dur}s")
                        step("subdomains","run",f"{tool_name}: +{count} subs")
                    elif args:
                        log.info(f"[subdomains] source={tool_name} raw=0 saved=0 duration={_src_dur}s")
                except Exception as e:
                    log.debug(f"[recon] {tool_name}: {e}")
                return count

            active_tools = [
                # Tier 1: fastest, most coverage
                ("subfinder",   __import__("engine.subfinder_config",fromlist=["get_subfinder_cmd"]).get_subfinder_cmd(domain,100,120) if T.get("subfinder") else None),
                ("assetfinder", [T["assetfinder"],"--subs-only",domain] if T.get("assetfinder") else None),
                ("findomain",   [T["findomain"],"-t",domain,"-q"] if T.get("findomain") else None),
                ("chaos",       [T["chaos"],"-d",domain,"-silent"] if T.get("chaos") else None),

                # Tier 2: deeper enumeration
                ("amass",       [T["amass"],"enum","-passive","-d",domain,"-timeout","120"] if T.get("amass") else None),
                ("tlsx",        [T["tlsx"],"-san","-cn","-silent","-d",domain] if T.get("tlsx") else None),
                ("asnmap",      [T["asnmap"],"-d",domain,"-silent"] if T.get("asnmap") else None),

                # Tier 3: URL-based sub extraction
                ("gau",         [T["gau"],"--subs","--threads","5",domain] if T.get("gau") else None),
                ("gauplus",     [T["gauplus"],"-t","5","-random-agent",domain] if T.get("gauplus") else None),
                ("waybackurls", [T["waybackurls"], domain] if T.get("waybackurls") else None),

                # Tier 4: uncover — run two queries for better coverage
                ("uncover_ssl", [T["uncover"],"-q",f"ssl:{domain}",
                                  "-e","shodan,censys,fofa,hunter,zoomeye,quake,netlas",
                                  "-silent","-f","host"] if T.get("uncover") else None),
                ("uncover_http",[T["uncover"],"-q",f"http.title:{domain}",
                                  "-e","shodan,censys,fofa","-silent","-f","host"]
                                  if T.get("uncover") else None),

                # Tier 5: additional free sources via direct binary calls
                ("hakrawler",   [T["hakrawler"],"-d","1","-subs","-insecure","-t","5",
                                  "-url",f"https://{domain}"]
                                  if T.get("hakrawler") else None),

                # Tier 6: puredns bruteforce (fastest DNS resolver — needs massdns)
                # Run in parallel with active tools — resolves top-5000 instantly
            ]

            # puredns quick brute (top 5000) — runs alongside active tools
            _puredns_added = [0]
            def _run_puredns_quick():
                if not T.get("puredns"): return
                _wl_quick = next((p for p in [
                    "/usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt",
                    "/usr/share/wordlists/seclists/Discovery/DNS/subdomains-top1million-5000.txt",
                    os.path.expanduser("~/Desktop/recon/SecLists/Discovery/DNS/subdomains-top1million-5000.txt"),
                ] if os.path.isfile(p)), None)
                if not _wl_quick: return
                import tempfile as _tf2, time as _pt
                try:
                    _ptmp = _tf2.NamedTemporaryFile(mode='w', suffix='.txt', delete=False)
                    _ptmp.write(domain + "\n"); _ptmp.close()
                    cmd = [T["puredns"], "brute", _wl_quick, domain, "-q"]
                    if T.get("massdns"): cmd += ["--resolvers-trusted", "/etc/resolv.conf"]
                    proc = _run(cmd)
                    _pt0 = time.monotonic()
                    for line in proc.stdout:
                        if (time.monotonic()-_pt0) > 90: proc.kill(); break
                        s = _clean(line.strip(), domain)
                        if s and add_sub(s): _puredns_added[0] += 1
                    proc.wait(timeout=5)
                    _rm(_ptmp.name)
                    log.info(f"[subdomains] source=puredns_quick found={_puredns_added[0]}")
                except Exception as _pe:
                    log.debug(f"[subdomains] puredns: {_pe}")

            active_tools = [
                # (sentinel to keep list non-empty)
                ("_puredns_bg", None),  # handled separately above
            ]

            # Run Tier 1+2 in parallel (fast tools)
            _exe1 = _cf.ThreadPoolExecutor(max_workers=6)
            try:
                futs = [_exe1.submit(_run_tool, (name, args))
                        for name, args in active_tools if args]
                _cf.wait(futs, timeout=360)  # 6min for all passive tools
            except Exception: pass
            finally:
                for _f in futs: _f.cancel()
                _exe1.shutdown(wait=False)

        if _stopped(q): return

        # ── Tier 5: DNS bruteforce — alterx permutation + common wordlist ──────
        if not _timed_out() and len(subs) < MAX_SUBS:
            step("subdomains","run","DNS permutation bruteforce...")
            try:
                _bf_found = 0

                # alterx permutation: generate mutations of known subs → dnsx resolve
                # dnsgen permutation (different algorithm from alterx — complementary)
                if T.get("dnsgen") and T.get("dnsx") and subs and not _timed_out():
                    try:
                        import tempfile as _dgtf
                        _dg_subs = [s for s in list(subs)[:300] if s.endswith("." + domain)]
                        _dg_in = _dgtf.NamedTemporaryFile(mode='w', suffix='.txt', delete=False)
                        _dg_in.write("\n".join(_dg_subs)); _dg_in.close()
                        _dg_out_file = _dg_in.name + "_gen.txt"
                        proc_dg = _run([T["dnsgen"], _dg_in.name])
                        _dg_t0 = time.monotonic(); _dg_lines = []
                        for line in proc_dg.stdout:
                            if (time.monotonic()-_dg_t0) > 45: proc_dg.kill(); break
                            _dg_lines.append(line.strip())
                        proc_dg.wait(timeout=5)
                        if _dg_lines:
                            _dg_tmp = _tmp(_dg_lines[:10000])
                            proc_dx_dg = _run([T["dnsx"], "-l", _dg_tmp, "-silent", "-a",
                                               "-threads", "200"])
                            _dgdx_t0 = time.monotonic(); _dg_added = 0
                            for line in proc_dx_dg.stdout:
                                if (time.monotonic()-_dgdx_t0) > 60: proc_dx_dg.kill(); break
                                s = _clean(line.strip().split()[0], domain)
                                if s and add_sub(s): _dg_added += 1
                            proc_dx_dg.wait(timeout=5); _rm(_dg_tmp); _rm(_dg_in.name)
                            log.info(f"[subdomains] source=dnsgen found={_dg_added}")
                    except Exception as _dge:
                        log.debug(f"[subdomains] dnsgen: {_dge}")

                if T.get("alterx") and T.get("dnsx") and subs:
                    import tempfile as _tf2, io as _io2
                    # Feed top 50 known subs into alterx for permutation
                    top_subs = list(subs)[:50]
                    with _tf2.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tf:
                        tf.write("\n".join(top_subs))
                        tf_name = tf.name
                    try:
                        # alterx -enrich generates permutations
                        proc_ax = _run([T["alterx"], "-enrich", "-silent"], stdin=open(tf_name))
                        with _tf2.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tf2:
                            mutations = proc_ax.stdout.read()
                            tf2.write(mutations)
                            tf2_name = tf2.name
                        # Resolve with dnsx
                        proc_dx = _run([T["dnsx"], "-l", tf2_name, "-silent", "-a", "-threads", "200"])
                        _dx_t0 = time.monotonic()
                        for line in proc_dx.stdout:
                            if (time.monotonic()-_dx_t0) > 55: proc_dx.kill(); break
                            line = line.strip()
                            if line:
                                c = _clean(line.split()[0] if ' ' in line else line, domain)
                                if c and c not in subs:
                                    subs.add(c); add([c]); _bf_found += 1
                        try: proc_dx.wait(timeout=60)
                        except: proc_dx.kill()
                        os.unlink(tf_name); os.unlink(tf2_name)
                    except Exception as e:
                        log.debug(f"[bruteforce] alterx+dnsx: {e}")

                # shuffledns with common subdomains wordlist (if installed + wordlist exists)
                if T.get("shuffledns") and not _timed_out():
                    # Look for common wordlists
                    import pathlib as _pl
                    wordlist_paths = [
                        _pl.Path.home() / "Desktop/recon/SecLists/Discovery/DNS/subdomains-top1million-5000.txt",
                        _pl.Path.home() / "Desktop/recon/SecLists/Discovery/DNS/subdomains-top1million-20000.txt",
                        _pl.Path("/usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt"),
                        _pl.Path("/usr/share/wordlists/seclists/Discovery/DNS/subdomains-top1million-5000.txt"),
                        _pl.Path("/opt/SecLists/Discovery/DNS/subdomains-top1million-5000.txt"),
                    ]
                    # resolvers file
                    resolvers_paths = [
                        _pl.Path.home() / "Desktop/recon/resolvers.txt",
                        _pl.Path("/opt/resolvers.txt"),
                        _pl.Path("/usr/share/seclists/Miscellaneous/dns-resolvers.txt"),
                        _pl.Path("/usr/share/wordlists/seclists/Miscellaneous/dns-resolvers.txt"),
                        _pl.Path.home() / "go/bin/resolvers.txt",
                    ]
                    wl = next((str(p) for p in wordlist_paths if p.exists()), None)
                    rs = next((str(p) for p in resolvers_paths if p.exists()), None)

                    if wl:
                        try:
                            step("subdomains","run",f"shuffledns bruteforce ({_pl.Path(wl).name})...")
                            cmd = [T["shuffledns"], "-d", domain, "-w", wl, "-silent"]
                            if rs: cmd += ["-r", rs]
                            proc_sh = _run(cmd)
                            _sh_t0 = time.monotonic()
                            for line in proc_sh.stdout:
                                if (time.monotonic()-_sh_t0) > 115: proc_sh.kill(); break
                                c = _clean(line.strip(), domain)
                                if c and c not in subs:
                                    subs.add(c); add([c]); _bf_found += 1
                            try: proc_sh.wait(timeout=5)
                            except Exception: proc_sh.kill()
                        except Exception as e:
                            log.debug(f"[bruteforce] shuffledns: {e}")

                # Built-in common-prefix DNS brute (no external tools needed)
                if not _timed_out() and len(subs) < MAX_SUBS // 2:
                    COMMON = ["www","api","mail","smtp","pop","imap","ftp","ssh","vpn",
                               "dev","staging","stage","test","uat","qa","prod","beta","alpha",
                               "admin","portal","dashboard","login","auth","sso","oauth",
                               "app","apps","mobile","m","static","cdn","media","assets","img",
                               "blog","shop","store","pay","payment","checkout","cart","billing",
                               "support","help","docs","wiki","kb","status","monitor",
                               "git","gitlab","github","jira","confluence","jenkins","ci","cd",
                               "ns1","ns2","mx","mx1","mx2","smtp1","smtp2",
                               "api2","api-v2","v2","v1","rest","graphql","ws","wss",
                               "intranet","internal","corp","vpn2","remote",
                               "db","database","mysql","postgres","redis","mongo",
                               "s3","bucket","storage","backup","archive",
                               "dev2","test2","demo","sandbox","lab",
                               "old","legacy","new","next","beta2","rc","release"]

                    import socket as _sock
                    import concurrent.futures as _cf2
                    def _resolve(prefix):
                        host = f"{prefix}.{domain}"
                        try:
                            _sock.getaddrinfo(host, None, timeout=2)
                            return host
                        except: return None

                    _exe2 = _cf2.ThreadPoolExecutor(max_workers=50)
                    try:
                        results = list(_exe2.map(_resolve, COMMON, timeout=60))
                    except Exception: results = []
                    finally: _exe2.shutdown(wait=False)
                    for host in results:
                        if host:
                            c = _clean(host, domain)
                            if c and c not in subs:
                                subs.add(c); add([c]); _bf_found += 1

                if _bf_found:
                    step("subdomains","run",f"bruteforce: +{_bf_found} new subs")
                    log.info(f"[bruteforce] total new: {_bf_found}")
            except Exception as e:
                log.debug(f"[bruteforce] outer: {e}")

        if _stopped(q): return

        # GAU subs — only if we haven't hit cap and have time
        # subjs — extract subdomains from JavaScript files (finds internal APIs)
        if T.get("subjs") and not _timed_out() and len(subs) > 5:
            try:
                import tempfile as _stf
                _urls = [f"https://{s}" for s in list(subs)[:200] if "." in s]
                _su_in = _stf.NamedTemporaryFile(mode='w', suffix='.txt', delete=False)
                _su_in.write("\n".join(_urls)); _su_in.close()
                proc_sj = _run([T["subjs"], "-i", _su_in.name, "-c", "20", "-silent"])
                _sj_t0 = time.monotonic(); _sj_added = 0
                for line in proc_sj.stdout:
                    if (time.monotonic()-_sj_t0) > 60: proc_sj.kill(); break
                    s = _clean(line.strip(), domain)
                    if s and add_sub(s): _sj_added += 1
                proc_sj.wait(timeout=5); _rm(_su_in.name)
                log.info(f"[subdomains] source=subjs found={_sj_added}")
                if _sj_added: _emit("step","subdomains","run",f"subjs: +{_sj_added} from JS files")
            except Exception as _sje:
                log.debug(f"[subdomains] subjs: {_sje}")

        if T.get("gau") and not _timed_out() and len(subs) < MAX_SUBS // 2:
            try:
                proc = _run([T["gau"],"--subs","--threads","3",domain])
                _gau_subs_t0 = time.monotonic()
                for line in proc.stdout:
                    if (time.monotonic()-_gau_subs_t0) > 55: proc.kill(); break
                    if _timed_out() or _stopped(q): proc.kill(); break
                    try:
                        h = urllib.parse.urlparse(line.strip()).netloc
                        add_sub(h)
                    except: pass
                try: proc.wait(timeout=5)
                except Exception: proc.kill()
            except Exception as e:
                log.warning(f"gau subs: {e}")

        # DNS bruteforce — only if well under cap and have time
        if not _timed_out() and len(subs) < MAX_SUBS // 2:
            _dns_bruteforce(domain, T, add_sub)

        if _stopped(q): return

        # Permutations — only on small-medium result sets
        if not _timed_out() and 5 < len(subs) <= 500:
            _permutations(domain, T, subs, add_sub)

        # AlterX — only if we haven't hit cap
        if T.get("alterx") and not _timed_out() and len(subs) < MAX_SUBS and len(subs) > 3:
            try:
                # Use top scored subs as alterx seed (higher value targets first)
                _ax_top = sorted(subs, key=lambda h: _sub_scores.get(h,1), reverse=True)[:500]
                tmp_subs_in = _tmp(_ax_top)
                proc = _run([T["alterx"], "-l", tmp_subs_in, "-enrich", "-silent"])
                _ax_count = 0
                _ax_t0 = time.monotonic()
                for line in proc.stdout:
                    if (time.monotonic()-_ax_t0) > 55: proc.kill(); break
                    if _timed_out() or _stopped(q): proc.kill(); break
                    if add_sub(line.strip(), source="alterx"): _ax_count += 1
                if _ax_count:
                    log.info(f"[subdomains] source=alterx count={_ax_count}")
                try: proc.wait(timeout=5)
                except Exception: proc.kill()
                _rm(tmp_subs_in)
            except Exception as e:
                log.warning(f"alterx: {e}")

        capped = len(subs) >= MAX_SUBS
        # ── DNS Brute Force (runs after passive sources) ─────────────────────
        if opts.get("dns_brute", True) and not _stopped(q):
            try:
                from engine.dns_brute import run_dns_brute
                _brute_wl = opts.get("brute_wordlist","")
                _brute_stop = threading.Event()
                step("subdomains","run","DNS brute force starting...")
                emit({"type":"step","name":"subdomains","state":"run",
                      "meta":"DNS brute forcing..."})
                _brute_found = run_dns_brute(
                    root_domain,
                    wordlist_path=_brute_wl,
                    emit_fn=emit,
                    add_fn=add_sub,
                    stop_event=_brute_stop,
                )
                for _bs in _brute_found:
                    subs.add(_bs)
                log.info(f"[recon] dns_brute: +{len(_brute_found)} new subs")
            except Exception as _be:
                log.warning(f"[recon] dns_brute: {_be}")

        # Save for resume
        try:
            if _resume_file:
                _resume_file.parent.mkdir(parents=True, exist_ok=True)
                with open(_resume_file, "w", encoding="utf-8") as _wf:
                    for _s in sorted(subs):
                        _wf.write(_s + "\n")
                log.debug(f"[recon] saved {len(subs)} subs for resume")
        except Exception as _we:
            log.debug(f"[recon] resume save: {_we}")
        step("subdomains","done",
             f"{len(subs)} subs{' (capped at '+str(MAX_SUBS)+')' if capped else ''}")
        # Export subdomains after passive collection
        try:
            from engine.subdomain_export import export_subdomains as _sub_exp
            _sub_exp(domain=domain, db=db,
                     subs=list(subs), sub_scores=_sub_scores,
                     sub_sources=_source_counts, reason="after_passive")
        except Exception as _se: log.debug(f"[subdomain-export] after_passive: {_se}")
        try:
            from engine.ai_recon import generate_recon_tip as _art
            _t = _art("subdomain_count", {"count": len(subs)})
            if _t: emit({"type":"ai_tip","msg":_t,"category":"recon"})
        except: pass
        if capped:
            emit({"type":"step","name":"subdomains","state":"warn",
                  "meta":f"Cap of {MAX_SUBS} reached — increase max_subs in settings if needed"})

    if _stopped(q): return

    # Always ensure root domain is included even if passive sources returned nothing
    if not subs or domain not in subs:
        for _d in [domain, f"www.{domain}"]:
            if _d not in subs:
                subs.add(_d)
                db.add_sub(domain, _d)
                emit({"type":"sub","host":_d})
        log.info(f"[recon] added root domain fallback — {len(subs)} total subs")

    log.info(f"[recon] subs done: {len(subs)}")
    # Log top scored subdomains for visibility
    _top_scored = sorted(_sub_scores.items(), key=lambda x: -x[1])[:10]
    if _top_scored:
        log.info(f"[subdomains] top_scored: {[h for h,s in _top_scored[:5]]}")

    # ══════════════════════════════════════════════════
    # 2. HOST PROBE — httpx with version-adaptive flags
    # ══════════════════════════════════════════════════
    step("active","run")

    # ── Wildcard DNS detection ────────────────────────────────────────────────
    # Query a random nonexistent subdomain — if it resolves, wildcard DNS is active.
    # Collect the wildcard IPs so we can filter them from results.
    try:
        import socket as _sock, random as _rand, string as _str
        _wc_probe = "".join(_rand.choices(_str.ascii_lowercase, k=12)) + "." + domain
        _wc_ips = set()
        try:
            _wc_res = _sock.getaddrinfo(_wc_probe, None, _sock.AF_INET)
            _wc_ips = {r[4][0] for r in _wc_res}
            if _wc_ips:
                _wildcard_ips.update(_wc_ips)
                log.info(f"[subdomains] wildcard_detected=true ips={_wc_ips} domain={domain}")
                # Remove already-collected subs that resolve to wildcard IPs
                _wc_removed = 0
                for _wc_sub in list(subs):
                    try:
                        _wc_sub_ips = {r[4][0] for r in
                                       _sock.getaddrinfo(_wc_sub, None, _sock.AF_INET, 0,
                                                         0, _sock.AI_TIMEOUT) if len(r)>=5}
                        if _wc_sub_ips and _wc_sub_ips.issubset(_wc_ips):
                            subs.discard(_wc_sub)
                            _wc_removed += 1
                    except Exception:
                        pass
                _wildcard_filtered[0] += _wc_removed
                log.info(f"[subdomains] wildcard_filtered={_wildcard_filtered[0]}")
        except (_sock.gaierror, _sock.herror):
            log.debug(f"[subdomains] wildcard_detected=false domain={domain}")
    except Exception as _wce:
        log.debug(f"[subdomains] wildcard check failed: {_wce}")

    # ── Score-based probe queue — highest value subdomains probed first ───────
    # Collection is uncapped. Expensive probe phase is capped at MAX_LIVE*4.
    # Sort all discovered subs by score descending so api., admin., dev. etc.
    # are probed before generic www2.*, mail.*, ftp.* entries.
    # Score-ordered probe queue: all subs stored, top MAX_LIVE probed first.
    # This means api.*, admin.*, auth.* are always probed regardless of total count.
    _all_subs_scored = sorted(subs, key=lambda h: _sub_scores.get(h, 1), reverse=True)
    subs_to_probe    = _all_subs_scored[:MAX_LIVE]   # cap at MAX_LIVE (score-ordered)
    log.info(
        f"[subdomains] raw_total={len(subs)}"
        f" unique_total={len(subs)}"
        f" probe_queue={len(subs_to_probe)}"
        f" max_live={MAX_LIVE}"
        f" wildcard_filtered={_wildcard_filtered[0]}"
        f" sources={list(_source_counts.keys())}"
    )
    # Log per-source counts (active tools — passive sources logged inline above)
    for _src, _cnt in sorted(_source_counts.items(), key=lambda x: -x[1]):
        if _src != "passive":  # passive sub-sources logged individually above
            log.info(f"[subdomains] source={_src} raw={_cnt} saved={_cnt}")
    tmp_subs = _tmp(subs_to_probe)
    try:
        if T.get("httpx"):
            # Probe httpx flags — they differ between versions
            try:
                htest = subprocess.run([T["httpx"],"-h"],
                    capture_output=True, text=True, env=_env(), timeout=10)
                ht = htest.stdout + htest.stderr
            except: ht = ""

            # Build command with version-correct flags
            cmd = [T["httpx"], "-l", tmp_subs, "-silent", "-json",
                   "-t", "100", "-timeout", "8", "-retries", "1"]
            # Status code flag
            if "-sc" in ht:          cmd += ["-sc"]
            elif "-status-code" in ht: cmd += ["-status-code"]
            # Title flag
            if "-title" in ht:       cmd += ["-title"]
            # Tech detection flag
            if "-td" in ht:          cmd += ["-td"]
            elif "-tech-detect" in ht: cmd += ["-tech-detect"]
            # IP flag
            if " -ip" in ht or "\n-ip" in ht: cmd += ["-ip"]
            # Follow redirects
            if "-fr" in ht:          cmd += ["-fr"]
            elif "-follow-redirects" in ht: cmd += ["-follow-redirects"]

            log.info(f"[httpx] cmd: {' '.join(cmd[:8])}...")
            _finger_t0 = time.monotonic()
            _FINGER_BUDGET = 300  # hard 5-min budget on httpx tech-detect read loop
            step("fingerprint","run","httpx tech-detect...")
            proc = _run(cmd)
            for line in proc.stdout:
                # Hard time budget — fingerprint must not run 501s
                _finger_elapsed = time.monotonic() - _finger_t0
                if _finger_elapsed > _FINGER_BUDGET:
                    log.warning(f"[fingerprint] timeout after {round(_finger_elapsed,1)}s → killing httpx")
                    proc.kill()
                    break
                if len(live_hosts) >= MAX_LIVE:
                    proc.kill(); break
                line = line.strip()
                if not line: continue
                try:
                    d      = json.loads(line)
                    # url field varies by version
                    url    = (d.get("url") or d.get("input","")).strip()
                    if not url: continue
                    # Ensure scheme
                    if not url.startswith("http"):
                        url = "https://" + url
                    status = (d.get("status-code") or d.get("status_code")
                              or d.get("sc") or 0)
                    title  = d.get("title","")
                    ip     = (d.get("host") or
                              (d.get("a",[""])[0] if d.get("a") else "") or "")
                    # Tech varies: list of str, list of dict, or dict
                    raw  = (d.get("tech") or d.get("technologies")
                            or d.get("technology") or d.get("td") or [])
                    if isinstance(raw, list):
                        tech = [t.get("name",t) if isinstance(t,dict)
                                else str(t) for t in raw]
                    elif isinstance(raw, dict):
                        tech = list(raw.keys())
                    else:
                        tech = [str(raw)] if raw else []

                    live_hosts.append(url)
                    db.add_active(domain, url)
                    db.save_enrich(domain, {"url":url,"status":status,
                                           "title":title,"tech":tech,"ip":ip})
                    if tech: db.add_tech(domain, tech)
                    emit({"type":"live","url":url})
                    emit({"type":"enrich","url":url,"status":status,
                          "title":title,"tech":tech,"ip":ip})
                except Exception as ex:
                    # httpx sometimes outputs plain URLs (non-JSON mode fallback)
                    line2 = line.strip()
                    if line2.startswith("http") and len(line2) < 300:
                        if line2 not in live_hosts and len(live_hosts) < MAX_LIVE:
                            live_hosts.append(line2)
                            db.add_active(domain, line2)
                            emit({"type":"live","url":line2})
                            emit({"type":"enrich","url":line2,"status":200,
                                  "title":"","tech":[],"ip":""})
                    log.debug(f"httpx parse: {ex} | {line[:80]}")
                if _stopped(q): proc.kill(); break
            try: proc.wait(timeout=5)   # process already killed or nearly done
            except: proc.kill()

        # Pure-Python HTTP probe (works even with zero tools installed)
        probed = set(live_hosts)
        import concurrent.futures as _pf_cf

        def _probe_sub(sub):
            # Scope guard — never probe private IPs
            _allowed, _reason = _scope_guard_host(sub)
            if not _allowed:
                log.debug(f"[scope] blocked {sub}: {_reason}")
                return None
            for scheme in ["https", "http"]:
                url = f"{scheme}://{sub}"
                if url in probed: continue
                try:
                    r = _get(url, 5)
                    if r and r[0] < 500:
                        # Try to extract title
                        title = ""
                        try:
                            import re as _re
                            tm = _re.search(r"<title[^>]*>([^<]{1,120})", r[2], _re.I)
                            if tm: title = tm.group(1).strip()
                        except: pass
                        # Detect basic tech
                        tech = []
                        hdr_str = str(r[1]).lower()
                        body_lo  = r[2][:2000].lower()
                        if "wp-content" in body_lo or "wordpress" in body_lo: tech.append("WordPress")
                        if "x-powered-by" in hdr_str:
                            import re as _re2
                            xp = _re2.search(r"x-powered-by[^:]*:\s*([^\s,;]{2,30})", hdr_str)
                            if xp: tech.append(xp.group(1).strip())
                        if "laravel" in body_lo: tech.append("Laravel")
                        if "django" in body_lo: tech.append("Django")
                        if "react" in body_lo or "__next_data__" in body_lo: tech.append("React")
                        if "nginx" in hdr_str: tech.append("Nginx")
                        if "apache" in hdr_str: tech.append("Apache")
                        return (url, r[0], title, tech)
                except: pass
            return None

        # Probe ALL remaining subs in parallel with dynamic timeout
        remaining = [s for s in subs_to_probe if
                     f"https://{s}" not in probed and f"http://{s}" not in probed]
        # Dynamic timeout: 0.6s per sub, min 60s, max 300s
        _probe_timeout = min(300, max(60, int(len(remaining) * 0.6)))
        _probe_workers = min(50, max(8, len(remaining) // 10))
        log.info(f"[probe] {len(remaining)} subs, {_probe_workers} workers, {_probe_timeout}s timeout")
        _pf_exe = _pf_cf.ThreadPoolExecutor(max_workers=_probe_workers)
        _pf_futs = {_pf_exe.submit(_probe_sub, s): s for s in remaining}
        try:
            for _pf_fut in _pf_cf.as_completed(_pf_futs, timeout=_probe_timeout):
                if _stopped(q): break
                try:
                    result = _pf_fut.result(timeout=2)
                except Exception:
                    result = None
                if result and len(live_hosts) < MAX_LIVE:
                    url, status, title, tech = result
                    probed.add(url)
                    live_hosts.append(url)
                    db.add_active(domain, url)
                    emit({"type":"live","url":url})
                    emit({"type":"enrich","url":url,"status":status,
                          "title":title,"tech":tech,"ip":""})
                    if tech:
                        for t in tech: db.add_tech(domain, t)
                    # Emit progress every 10 hosts
                    if len(live_hosts) % 10 == 0:
                        step("active","run",
                             f"Probing... ({len(live_hosts)} live)")
        except Exception as _pe:
            # TimeoutError or stop — cancel pending futures
            for _pff in _pf_futs:
                if not _pff.done(): _pff.cancel()
            log.debug(f"[probe] ended: {_pe}")
        finally:
            _pf_exe.shutdown(wait=False)  # never block waiting for futures

    finally:
        _rm(tmp_subs)

    _finger_dur = round(time.monotonic() - _finger_t0, 1) if '_finger_t0' in dir() else 0
    _tech_count = sum(len(h.get("tech",[])) for h in live_hosts) if isinstance(live_hosts[0] if live_hosts else None, dict) else 0
    step("fingerprint","done",f"fingerprint done hosts={len(live_hosts)}")
    log.info(f"[stage] fingerprint done hosts={len(live_hosts)} duration={_finger_dur}s")

    # Auto CVE correlation — runs in background after tech is detected
    try:
        import threading as _cvt
        def _run_cve_correlation():
            try:
                from engine.cve_engine import correlate_domain_cves
                cves = correlate_domain_cves(domain, db)
                crits = sum(1 for c in cves if c.get("severity") == "critical")
                highs = sum(1 for c in cves if c.get("severity") == "high")
                if cves:
                    log.info(f"[cve] auto-correlation domain={domain}"
                             f" total={len(cves)} critical={crits} high={highs}")
                    _emit("cve_correlation", None, None,
                          f"CVE correlation: {len(cves)} potential CVEs"
                          f" ({crits} critical, {highs} high) — see /cve/correlate?domain={domain}")
                    if crits > 0:
                        _emit("ai_tip", None, None,
                              f"🔴 {crits} critical CVE(s) matched for detected tech stack."
                              f" Run: nuclei -target {domain} -tags cve -severity critical")
            except Exception as _ce:
                log.debug(f"[cve] auto-correlation error: {_ce}")
        _cvt.Thread(target=_run_cve_correlation, daemon=True, name="cve-correlate").start()
    except Exception: pass
    step("active","done", f"{len(live_hosts)} live hosts")
    # Export subdomains after live probe (now we know which are live)
    try:
        from engine.subdomain_export import export_subdomains as _sub_exp2
        _sub_exp2(domain=domain, db=db,
                  subs=list(subs), live_hosts=live_hosts,
                  sub_scores=_sub_scores, sub_sources=_source_counts,
                  reason="after_probe")
    except Exception as _se2: log.debug(f"[subdomain-export] after_probe: {_se2}")
    if _stopped(q): return

    # OOB Setup step — check configured OOB host
    _oob_host_val = os.environ.get("OOB_HOST","") or os.environ.get("INTERACTSH_SERVER","")
    if _oob_host_val:
        step("oob_setup","done",f"OOB host={_oob_host_val}")
        step("oob","done",f"OOB configured host={_oob_host_val}")
        log.info(f"[stage] oob_setup done host={_oob_host_val}")
    else:
        step("oob_setup","skip","no OOB_HOST configured — set OOB_HOST in .env")
        step("oob","skip","no OOB_HOST configured")
        log.info("[stage] oob_setup skipped reason=no_oob_host")

    # Fingerprint — if no live hosts, mark skipped
    if not live_hosts and not any(step.__name__ if callable(step) else "" for _ in []):
        pass  # fingerprint step already set in active block

    # ══════════════════════════════════════════════════
    # 3. PORT SCAN
    # ══════════════════════════════════════════════════
    if skip_port:
        step("ports","skip")

    else:
        ports_found = []
        # ── Port mode safety ──────────────────────────────────────────────────
        # UNCONDITIONAL SERVER-SIDE GUARD — enforced before any tool runs.
        # No client param, saved job, or opt key can bypass this.
        _port_mode_requested = port_mode

        # Primary guard: opts.get("port_mode") already set at L1865.
        # Secondary override check: ensure no stale "profile" key sneaks through.
        if opts.get("profile") == "all" or opts.get("scan_profile") == "all":
            log.warning(
                f"[ports] FORCE DOWNGRADE: stale opts.profile/scan_profile=all"
                f" overridden → top100"
            )
            port_mode = "top100"

        if port_mode == "all":
            log.warning(
                f"[ports] FORCE DOWNGRADE → top100"
                f" (requested={_port_mode_requested}, blocked=all-ports)"
            )
            port_mode = "top100"

        # Explicit allow-list: full scan only if server admin sets env var.
        # No client-side flag can enable this.
        _allow_all = os.environ.get("TMR_ALLOW_ALL_PORTS", "").strip() == "1"
        if port_mode == "all" and not _allow_all:
            log.warning("[ports] TMR_ALLOW_ALL_PORTS not set — forced to top100")
            port_mode = "top100"

        log.info(f"[ports] FINAL MODE: {port_mode}")

        # Cap port-scan hosts to prevent blocking
        _port_host_limit = min(int(opts.get("max_port_hosts", 100)), 200)
        hosts_clean = list(set(
            re.sub(r'^https?://', '', h).split('/')[0].split(':')[0]
            for h in live_hosts[:_port_host_limit]
        ))

        # gowitness moved to AFTER endpoint phase — screenshots run last so they
        # don't block port scan or endpoint collection (see below section 4).

        if not hosts_clean:
            step("ports","skip","no live hosts — run Recon first for port data")
        else:
            _port_count_desc = {"all":"65535","top1000":"1000","top100":"100"}.get(port_mode, port_mode)
            # Select tool for logging
            _port_tool = ("rustscan" if port_mode == "all" and T.get("rustscan") else
                          "naabu"    if T.get("naabu") else
                          "nmap"     if T.get("nmap") else
                          "socket")
            log.info(f"[ports] target={domain} profile={port_mode} port_count={_port_count_desc} hosts={len(hosts_clean)} tool={_port_tool}")
            step("ports","run", f"scanning {len(hosts_clean)} host(s) — {port_mode} ({_port_count_desc} ports) via {_port_tool}")
            tmp_h = _tmp(hosts_clean)
            try:
                # ── rustscan (65535 ports — env-gated) ───────────────────────
                # rustscan only runs if: (a) port_mode survived as "all" AND
                # (b) TMR_ALLOW_ALL_PORTS=1 is set on the server.
                # After the guard above, port_mode is ALWAYS top100 in normal
                # operation. This branch is dead unless the admin explicitly
                # enables it via environment variable.
                if port_mode == "all" and T.get("rustscan") and _allow_all:
                    log.info(f"[ports] rustscan all-ports on {len(hosts_clean[:20])} hosts")
                    for host in hosts_clean[:100]:
                        if _stopped(q): break
                        try:
                            rcmd = [T["rustscan"],"-a",host,"--range","1-65535",
                                    "--ulimit","5000","-b","1500","-t","2000",
                                    "--no-nmap","--quiet"]
                            rproc = _run(rcmd)
                            _rproc_t0 = time.monotonic()
                            for rline in rproc.stdout:
                                if (time.monotonic()-_rproc_t0) > 115: rproc.kill(); break
                                rm = re.search(r'(\d+\.\d+\.\d+\.\d+|[\w.-]+):(\d+)', rline)
                                if rm:
                                    entry = f"{rm.group(1)}:{rm.group(2)}"
                                    if entry not in ports_found:
                                        ports_found.append(entry)
                                        db.add_port(domain, entry)
                                        emit({"type":"port","entry":entry})
                                if _stopped(q): rproc.kill(); break
                            try: rproc.wait(timeout=5)
                            except Exception: rproc.kill()
                        except Exception as re_e:
                            log.debug(f"rustscan {host}: {re_e}")

                # ── naabu (Go-based, fast) ────────────────────────────────────
                # Skip naabu if rustscan already ran — avoid redundant overlapping
                # scans on the same hosts. Even if rustscan found 0 ports, it ran
                # exhaustively and naabu adds nothing.
                _rustscan_ran = (port_mode == "all" and T.get("rustscan"))
                if _rustscan_ran:
                    log.info(f"[ports] skipped secondary scanner (naabu) — "
                             f"rustscan already completed ({len(ports_found)} ports found)")
                elif T.get("naabu"):
                    parg = (
                        ["-top-ports","100"]  if port_mode == "top100"  else
                        ["-top-ports","1000"] if port_mode == "top1000" else
                        ["-p","1-65535"]      if port_mode == "all"     else
                        ["-p", custom_ports]  if port_mode == "custom" and custom_ports else
                        ["-top-ports","1000"]  # default: top 1000 ports
                    )
                    # rate=1500: safer on shared VPS/bug-bounty targets; c=25: 25 concurrent hosts
                    # timeout=3: 3s per-connection (was 5 — reduced to fail fast on filtered ports)
                    # Wall-clock cap: top100→60s, top1000→120s, all→300s
                    _naabu_wall = 60 if port_mode == "top100" else 300 if port_mode == "all" else 120
                    cmd = [T["naabu"],"-l",tmp_h,"-silent","-json",
                           "-rate","1500","-c","25","-timeout","3","-retries","1",
                           ] + parg
                    log.info(f"[ports] naabu profile={port_mode} parg={parg} hosts={len(hosts_clean)} wall_cap={_naabu_wall}s")
                    proc = _run(cmd)
                    import time as _time_ns
                    _naabu_start = _time_ns.monotonic()
                    for line in proc.stdout:
                        # Hard wall-clock kill: don't block longer than _naabu_wall seconds
                        if _time_ns.monotonic() - _naabu_start > _naabu_wall:
                            log.warning(f"[ports] naabu wall-clock cap {_naabu_wall}s reached — killing")
                            proc.kill(); break
                        line = line.strip()
                        if not line: continue
                        try:
                            d = json.loads(line)
                            # naabu JSON: {"ip":"x","port":80} or {"host":"x","port":80}
                            h = (d.get("ip") or d.get("host") or "").strip()
                            p = d.get("port","")
                            if h and p:
                                entry = f"{h}:{p}"
                                if entry not in ports_found:
                                    ports_found.append(entry)
                                    db.add_port(domain, entry)
                                    emit({"type":"port","entry":entry})
                        except (json.JSONDecodeError, ValueError):
                            # Strip ANSI escape codes before parsing plain text
                            clean = re.sub(r'\x1b\[[0-9;]*m', '', line).strip()
                            m = re.search(r'([\w.-]+):(\d{1,5})$', clean)
                            if m:
                                entry = f"{m.group(1)}:{m.group(2)}"
                                if entry not in ports_found:
                                    ports_found.append(entry)
                                    db.add_port(domain, entry)
                                    emit({"type":"port","entry":entry})
                        if _stopped(q): proc.kill(); break
                    try: proc.wait(timeout=10)   # was 600 — process already killed or nearly done
                    except: proc.kill()

                # ── nmap (universal fallback) ─────────────────────────────────
                elif T.get("nmap"):
                    if port_mode == "all":
                        ports_arg, timing = "1-65535", "-T4"
                    elif port_mode == "custom" and custom_ports:
                        ports_arg, timing = custom_ports, "-T4"
                    elif port_mode == "top100":
                        ports_arg, timing = None, "-T4"   # handled below
                    else:
                        ports_arg, timing = None, "-T4"

                    # Cap nmap hosts to 20 — nmap scanning 100 hosts serially is the main hang cause
                    _nmap_hosts = hosts_clean[:20]
                    if ports_arg:
                        cmd = [T["nmap"],"-p",ports_arg,"--open",timing,
                               "-oG","-","--"] + _nmap_hosts
                    elif port_mode == "top100":
                        cmd = [T["nmap"],"--top-ports","100","--open",timing,
                               "-oG","-","--"] + _nmap_hosts
                    else:
                        cmd = [T["nmap"],"--top-ports","1000","--open",timing,
                               "-oG","-","--"] + _nmap_hosts

                    # Wall-clock cap: top100→90s, top1000→180s, all→300s
                    _nmap_wall = 90 if port_mode == "top100" else 300 if port_mode == "all" else 180
                    _nmap_desc = ports_arg or ("top100" if port_mode == "top100" else "top1000")
                    log.info(f"[ports] nmap profile={port_mode} ports={_nmap_desc} hosts={len(_nmap_hosts)} wall_cap={_nmap_wall}s")
                    import time as _time_nm
                    _nmap_start = _time_nm.monotonic()
                    proc = _run(cmd)
                    for line in proc.stdout:
                        if _time_nm.monotonic() - _nmap_start > _nmap_wall:
                            log.warning(f"[ports] nmap wall-clock cap {_nmap_wall}s reached — killing")
                            proc.kill(); break
                        if "Ports:" not in line: continue
                        hm = re.search(r'Host:\s+(\S+)', line)
                        hst = hm.group(1) if hm else ""
                        for pm in re.finditer(r'(\d+)/open', line):
                            entry = f"{hst}:{pm.group(1)}"
                            if entry not in ports_found:
                                ports_found.append(entry)
                                db.add_port(domain, entry)
                                emit({"type":"port","entry":entry})
                        if _stopped(q): proc.kill(); break
                    try: proc.wait(timeout=10)   # was 1200
                    except: proc.kill()

                # ── masscan (fast full-range fallback) ───────────────────────
                if port_mode == "all" and T.get("masscan") and not ports_found:
                    log.info(f"[ports] masscan 1-65535 on {len(hosts_clean[:10])} hosts")
                    for host in hosts_clean[:50]:
                        if _stopped(q): break
                        try:
                            mcmd = [T["masscan"], host, "-p1-65535",
                                    "--rate","5000","--output-format","list",
                                    "--output-filename","-"]
                            mproc = _run(mcmd)
                            _mproc_t0 = time.monotonic()
                            for mline in mproc.stdout:
                                if (time.monotonic()-_mproc_t0) > 115: mproc.kill(); break
                                mp = re.search(r'open\s+\w+\s+(\d+)\s+(\S+)', mline)
                                if mp:
                                    entry = f"{mp.group(2)}:{mp.group(1)}"
                                    if entry not in ports_found:
                                        ports_found.append(entry)
                                        db.add_port(domain, entry)
                                        emit({"type":"port","entry":entry})
                                if _stopped(q): mproc.kill(); break
                            try: mproc.wait(timeout=5)
                            except Exception: mproc.kill()
                        except Exception as me:
                            log.debug(f"masscan {host}: {me}")

                # ── Pure-Python socket scanner (ALWAYS runs as fallback) ──────
                if not ports_found:
                    log.info(f"[ports] socket scanning {len(hosts_clean[:10])} hosts (no tools installed)")
                    import concurrent.futures as _sockf
                    import socket as _sock

                    if port_mode == "all":
                        _sport_list = list(range(1, 65536))
                    elif port_mode == "top100":
                        _sport_list = [21,22,23,25,53,80,110,111,135,139,143,443,445,514,515,587,631,993,995,1080,1433,1521,2049,3306,3389,5432,5900,5984,6379,7001,7080,8000,8080,8443,8888,9000,9090,9200,9300,9443,10000,11211,27017,27018,50000,50070,61616]
                    elif port_mode == "custom" and custom_ports:
                        _sport_list = []
                        for _part in custom_ports.split(","):
                            _part = _part.strip()
                            if "-" in _part:
                                try:
                                    _a, _b = _part.split("-", 1)
                                    _sport_list.extend(range(int(_a), int(_b)+1))
                                except: pass
                            elif _part.isdigit():
                                _sport_list.append(int(_part))
                    else:
                        _sport_list = [
                            21,22,23,25,53,80,81,88,110,111,119,135,139,143,
                            161,389,443,445,465,514,515,587,631,636,993,995,
                            1080,1194,1433,1521,1723,2049,2082,2083,2086,2087,
                            2095,2096,2181,2222,2375,2376,2379,2380,3000,3001,
                            3128,3268,3269,3306,3389,3478,3690,4000,4040,4443,
                            4444,4567,4848,5000,5001,5432,5601,5900,5984,6379,
                            6443,6666,7001,7002,7070,7443,7474,7777,8000,8001,
                            8008,8009,8080,8081,8082,8083,8086,8087,8088,8089,
                            8090,8091,8092,8093,8094,8095,8096,8098,8099,8100,
                            8118,8123,8125,8161,8180,8181,8222,8243,8280,8281,
                            8333,8383,8443,8500,8530,8531,8888,8889,8983,9000,
                            9001,9002,9090,9091,9092,9093,9100,9200,9300,9418,
                            9443,9999,10000,10250,10255,11211,27017,27018,27019,
                            28017,50000,50070,50075,61616,
                        ]

                    def _sock_probe(args):
                        _h, _p = args
                        try:
                            _s = _sock.socket(_sock.AF_INET, _sock.SOCK_STREAM)
                            _s.settimeout(0.5)  # faster scan
                            _res = _s.connect_ex((_h, _p))
                            _s.close()
                            return f"{_h}:{_p}" if _res == 0 else None
                        except: return None

                    # Capped: max 10 hosts, 200 workers, 60s wall-clock for top100/top1000
                    # all-ports: still capped to 10 hosts, 500 workers, 300s
                    _sock_hosts = hosts_clean[:10]   # was 50 — avoid 500-host socket storms
                    _workers    = 500 if port_mode == "all" else 200   # was 1000/500
                    _tasks      = [(_h, _p) for _h in _sock_hosts for _p in _sport_list]
                    _tout       = 300 if port_mode == "all" else 60    # was 1800/120
                    step("ports","run",
                         f"socket: {len(_sport_list)} ports × {len(_sock_hosts)} hosts")
                    log.info(f"[ports] socket: {len(_tasks)} probes, {_workers} workers, wall_cap={_tout}s")
                    try:
                        _se = _sockf.ThreadPoolExecutor(max_workers=_workers)
                        try:
                            for _entry in _se.map(_sock_probe, _tasks, timeout=_tout):
                                if _stopped(q): break
                                if _entry:
                                    ports_found.append(_entry)
                                    db.add_port(domain, _entry)
                                    emit({"type":"port","entry":_entry})
                        except Exception as _spe:
                            log.debug(f"[ports] socket error: {_spe}")
                        finally:
                            _se.shutdown(wait=False)
                    except Exception:
                        pass
                    log.info(f"[ports] socket done: {len(ports_found)} open")

            finally:
                if tmp_h: _rm(tmp_h)

            port_count = len(set(ports_found))  # deduplicated count
            step("ports","done", f"{port_count} open ports found")
            emit({"type":"step","name":"ports","state":"done","meta":f"{port_count} open ports"})

    # ══════════════════════════════════════════════════
    # 4. ENDPOINTS — multiple sources
    # ══════════════════════════════════════════════════
    if skip_endpoints:
        step("endpoints","skip")
    else:
        step("endpoints","run")
        BL = "png,jpg,jpeg,gif,css,woff,woff2,ttf,svg,ico,mp4,mp3,webp,bmp,zip,gz,pdf"

        def _is_useful(u):
            return (u and u.startswith("http") and len(u) < 500 and
                    not re.search(r'\.(png|jpg|jpeg|gif|css|woff|svg|ico|mp4|mp3|bmp|ttf|pdf)(\?|$)',u,re.I))

        # ── gau (version adaptive) ────────────────────────────────────────────
        if T.get("gau"):
            try:
                gtest = subprocess.run([T["gau"],"--help"],
                    capture_output=True, text=True, env=_env(), timeout=10)
                gt = gtest.stdout + gtest.stderr
                # gau v1 uses --blacklist, gau v2 also supports it
                cmd = [T["gau"], domain]
                if "--subs" in gt:      cmd += ["--subs"]
                if "--threads" in gt:   cmd += ["--threads","20"]
                if "--providers" in gt: cmd += ["--providers","wayback,otx,commoncrawl,urlscan"]
                if "--retries" in gt:   cmd += ["--retries","3"]
                if "--blacklist" in gt: cmd += ["--blacklist", BL]
                elif "--filter-extensions" in gt: cmd += ["--filter-extensions", BL]
                proc = _run(cmd)
                _gau_count = 0
                _gau_saved = 0
                _gau_t0 = time.monotonic()
                for line in proc.stdout:
                    if (time.monotonic()-_gau_t0) > 290:  # 5min hard cap
                        proc.kill(); break
                    u = line.strip()
                    if _is_useful(u):
                        if add_endpoint(u, source="gau"): _gau_saved += 1
                        _gau_count += 1
                    if _stopped(q): proc.kill(); break
                try: proc.wait(timeout=300)  # 5min max (was 1hr)
                except: proc.kill()
                log.info(f"[endpoint] source=gau parsed={_gau_count} saved={_gau_saved}")
            except Exception as e:
                log.warning(f"[tool-health] gau broken reason={e} skipped")

        # ── gauplus ───────────────────────────────────────────────────────────
        if T.get("gauplus"):
            try:
                proc = _run([T["gauplus"], "-t", "20", "-subs", domain])
                _gp_t0 = time.monotonic()
                for line in proc.stdout:
                    if (time.monotonic()-_gp_t0) > 290: proc.kill(); break
                    u = line.strip()
                    if _is_useful(u): add_endpoint(u)
                    if _stopped(q): proc.kill(); break
                try: proc.wait(timeout=300)
                except: proc.kill()
            except Exception as e:
                log.warning(f"gauplus: {e}")

        if _stopped(q): return

        # ── waybackurls ───────────────────────────────────────────────────────
        if T.get("waybackurls"):
            try:
                proc = _run([T["waybackurls"], domain])
                _wb_count = 0
                _wb_saved = 0
                _wb_t0 = time.monotonic()
                for line in proc.stdout:
                    if (time.monotonic()-_wb_t0) > 290:
                        proc.kill(); break
                    u = line.strip()
                    if _is_useful(u):
                        if add_endpoint(u, source="waybackurls"): _wb_saved += 1
                        _wb_count += 1
                    if _stopped(q): proc.kill(); break
                log.info(f"[endpoint] source=waybackurls parsed={_wb_count} saved={_wb_saved}")
                try: proc.wait(timeout=5)   # loop already killed proc at 290s
                except: proc.kill()
            except Exception as e:
                log.warning(f"waybackurls: {e}")

        # ── paramspider (version adaptive) ────────────────────────────────────
        if T.get("paramspider"):
            try:
                # Detect version: v2+ uses -d, older uses --domain
                ptest = subprocess.run([T["paramspider"],"--help"],
                    capture_output=True, text=True, env=_env(), timeout=10)
                pt = ptest.stdout + ptest.stderr
                ps_out = tempfile.mktemp(suffix=".txt")
                if "-d " in pt or "--domain" in pt:
                    flag = "-d" if "-d " in pt else "--domain"
                    cmd = [T["paramspider"], flag, domain]
                    if "--quiet" in pt or "-q" in pt: cmd += ["--quiet"]
                    if "--output" in pt or "-o" in pt: cmd += ["-o", ps_out]
                    proc = _run(cmd)
                    try: proc.wait(timeout=120)
                    except: proc.kill()
                    # paramspider v2 writes to output/domain.txt
                    candidates = [
                        ps_out,
                        f"output/{domain}.txt",
                        f"{domain}.txt",
                    ]
                    for cand in candidates:
                        if os.path.isfile(cand):
                            for line in open(cand).readlines():
                                u = line.strip()
                                if _is_useful(u): add_endpoint(u)
                            break
                    _rm(ps_out)
            except Exception as e:
                log.warning(f"paramspider: {e}")

        # ── Subdomain Takeover checks ─────────────────────────────────────────
        if live_hosts and (T.get("subjack") or T.get("tko-subs")):
            step("endpoints","run","Checking subdomain takeover...")
            try:
                tmp_h = _tmp(list(subs)[:1000])
                if T.get("subjack"):
                    proc = _run([T["subjack"],"-w",tmp_h,"-t","50","-timeout","30",
                                 "-c","/root/go/src/github.com/haccer/subjack/fingerprints.json",
                                 "-ssl","-a"])
                    _subjack_t0 = time.monotonic()
                    for line in proc.stdout:
                        if (time.monotonic()-_subjack_t0) > 115: proc.kill(); break
                        line = line.strip()
                        if line and ('[VULNERABLE]' in line or 'vulnerable' in line.lower()):
                            add_finding_fn = getattr(db,'add_finding',None)
                            if add_finding_fn:
                                db.add_finding(domain,{
                                    'type':'takeover','bug':'takeover',
                                    'severity':'critical','url':line,
                                    'title':f'Subdomain Takeover: {line}',
                                    'description':'Subdomain vulnerable to takeover',
                                    'confidence':85
                                })
                            emit({'type':'finding','bug':'takeover','severity':'critical',
                                  'url':line,'title':f'Subdomain Takeover: {line}'})
                        if _stopped(q): proc.kill(); break
                    try: proc.wait(timeout=120)
                    except: proc.kill()
                if T.get("tko-subs"):
                    proc = _run([T["tko-subs"],"-domains",tmp_h,"-data",
                                 "/root/go/src/github.com/anshumanbh/tko-subs/providers-data.csv"])
                    _tko_t0 = time.monotonic()
                    for line in proc.stdout:
                        if (time.monotonic()-_tko_t0) > 115: proc.kill(); break
                        line = line.strip()
                        if line and 'vulnerable' in line.lower():
                            emit({'type':'log','msg':f'Takeover: {line}'})
                        if _stopped(q): proc.kill(); break
                    try: proc.wait(timeout=120)
                    except: proc.kill()
                _rm(tmp_h)
            except Exception as e:
                log.debug(f"takeover checks: {e}")

        # ── kiterunner ────────────────────────────────────────────────────────
        kr = T.get("kr") or T.get("kiterunner")
        if kr and live_hosts:
            _home = os.path.expanduser("~")
            # Check ALL possible wordlist locations
            _kite_search = [
                # Primary: Desktop/recon (where fix_failed_tools.sh installs)
                f"{_home}/Desktop/recon/kiterunner/routes-large.kite",
                f"{_home}/Desktop/recon/kiterunner/routes-small.kite",
                # Alternate: ~/wordlists (where setup_wordlists.sh installs)
                f"{_home}/wordlists/kiterunner/routes-large.kite",
                f"{_home}/wordlists/kiterunner/routes-small.kite",
                # System paths
                "/usr/share/kiterunner/routes-large.kite",
                "/opt/kiterunner/routes-large.kite",
                # Common Kali paths
                "/home/kali/Desktop/recon/kiterunner/routes-large.kite",
                "/root/Desktop/recon/kiterunner/routes-large.kite",
            ]
            # Text-based fallbacks (for --wordlist flag instead of --routes)
            _txt_search = [
                f"{_home}/Desktop/recon/kiterunner/apiroutes.txt",
                f"{_home}/Desktop/recon/kiterunner/swagger-wordlist.txt",
                f"{_home}/wordlists/kiterunner/apiroutes.txt",
                f"{_home}/wordlists/kiterunner/httparchive_apiroutes.txt",
                "/usr/share/seclists/Discovery/Web-Content/api/api-endpoints.txt",
                "/usr/share/wordlists/seclists/Discovery/Web-Content/api/api-endpoints.txt",
            ]

            kite_wl = next((p for p in _kite_search if os.path.isfile(p) and os.path.getsize(p) > 10000), None)
            txt_wl  = next((p for p in _txt_search  if os.path.isfile(p) and os.path.getsize(p) > 1000), None)

            _kr_wl = kite_wl or txt_wl
            if _kr_wl:
                log.info(f"[kiterunner] using wordlist: {_kr_wl} ({os.path.getsize(_kr_wl)//1024//1024}MB)")
                try:
                    tmp_h = _tmp(live_hosts[:50])
                    # Use --routes for .kite files, --wordlist for .txt files
                    _wl_flag = "--routes" if _kr_wl.endswith(".kite") else "--wordlist"
                    proc = _run([kr, "scan", "--input-list", tmp_h,
                                 _wl_flag, _kr_wl,
                                 "--output-format", "text",
                                 "--concurrency", "25",
                                 "--timeout", "3",
                                 "--max-connection-pool", "100"])
                    _ps_t0 = time.monotonic()
                    for line in proc.stdout:
                        if (time.monotonic()-_ps_t0) > 295: proc.kill(); break
                        m2 = re.search(r'https?://[^\s]+', line)
                        if m2:
                            add_endpoint(m2.group(0))
                        if _stopped(q): proc.kill(); break
                    try: proc.wait(timeout=300)
                    except: proc.kill()
                    _rm(tmp_h)
                except Exception as e:
                    log.warning(f"[kiterunner] error: {e}")
            else:
                log.info("[kiterunner] no wordlist found — run: ./fix_failed_tools.sh")
                log.info(f"  Expected: {_home}/Desktop/recon/kiterunner/routes-large.kite")

        # ── GAU per top-subdomain (massively increases endpoint count) ──────────
        if T.get("gau") and live_hosts and not opts.get("skip_gau_subs"):
            step("endpoints","run","GAU scanning top subdomains...")
            import concurrent.futures as _gcf2
            def _gau_sub(host):
                clean = host.replace("https://","").replace("http://","").split("/")[0]
                try:
                    _gcmd = [T["gau"], clean, "--threads", "10"]
                    if "--providers" in src: pass  # already detected above
                    _gproc = _run(_gcmd)
                    _gfound = []
                    _gproc_t0 = time.monotonic()
                    for _gl in _gproc.stdout:
                        if (time.monotonic()-_gproc_t0) > 90: _gproc.kill(); break
                        u = _gl.strip()
                        if _is_useful(u): _gfound.append(u)
                    try: _gproc.wait(timeout=5)
                    except Exception: _gproc.kill()
                    return _gfound
                except: return []

            _gexe2 = _gcf2.ThreadPoolExecutor(max_workers=20)
            _gfuts2 = {_gexe2.submit(_gau_sub, h): h for h in live_hosts[:200]}
            try:
                for _gf2 in _gcf2.as_completed(_gfuts2, timeout=300):
                    try:
                        for u in (_gf2.result(timeout=30) or []):
                            add_endpoint(u)
                    except: pass
            except Exception:
                for _gf2 in _gfuts2:
                    if not _gf2.done(): _gf2.cancel()
            finally:
                _gexe2.shutdown(wait=False)
            log.info(f"[endpoint] source=gau parsed={len(endpoints)} saved={len(endpoints)}")
            log.info(f"[gau-subs] done: {len(endpoints)} total endpoints")
            _autosave_export("after_gau")

        # ── Wayback CDX direct (always works, no tool needed) ─────────────────
        try:
            # CDX: query both http and https, massive limit for large targets
            for _cdx_scheme in ["http", "https"]:
                _cdx_url = (f"http://web.archive.org/cdx/search/cdx"
                            f"?url={_cdx_scheme}://*.{domain}/*"
                            f"&output=text&fl=original&collapse=urlkey&limit=100000")
                r = _get(_cdx_url, 60)
                if r:
                    for line in r[2].splitlines():
                        u = line.strip()
                        if _is_useful(u): add_endpoint(u)
            # Also query top 50 live subdomains individually for deep coverage
            for _sub_host in live_hosts[:100]:
                _sub = _sub_host.replace("https://","").replace("http://","").split("/")[0]
                for _scheme in ["http","https"]:
                    _cdx_sub = (f"http://web.archive.org/cdx/search/cdx"
                                f"?url={_scheme}://{_sub}/*"
                                f"&output=text&fl=original&collapse=urlkey&limit=50000")
                    r2 = _get(_cdx_sub, 30)
                    if r2:
                        for line in r2[2].splitlines():
                            u = line.strip()
                            if _is_useful(u): add_endpoint(u)
                if _stopped(q): break
        except Exception as e:
            log.warning(f"wayback CDX: {e}")

        # ── URLScan.io — great for finding API endpoints ──────────────────────
        try:
            r_us = _get(f"https://urlscan.io/api/v1/search/?q=domain:{domain}&size=10000", 30)
            if r_us and r_us[0] == 200:
                import json as _j3
                try:
                    _us_data = _j3.loads(r_us[2])
                    for _res in _us_data.get("results",[]):
                        _page = _res.get("page",{})
                        _u = _page.get("url","")
                        if _is_useful(_u): add_endpoint(_u)
                        # Also get all links from the scan
                        _links = _res.get("links",[])
                        for _lnk in (_links if isinstance(_links,list) else []):
                            _lu = _lnk.get("href","") if isinstance(_lnk,dict) else str(_lnk)
                            if _is_useful(_lu): add_endpoint(_lu)
                except: pass
        except Exception as e:
            log.debug(f"urlscan: {e}")

        # ── OTX AlienVault URLs ───────────────────────────────────────────────
        try:
            r_otx = _get(f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/url_list?limit=500&page=1", 20)
            if r_otx and r_otx[0] == 200:
                import json as _j4
                try:
                    _otx = _j4.loads(r_otx[2])
                    for _item in _otx.get("url_list",[]):
                        _u = _item.get("url","")
                        if _is_useful(_u): add_endpoint(_u)
                except: pass
        except Exception as e:
            log.debug(f"otx urls: {e}")

        # ── CommonCrawl index ─────────────────────────────────────────────────
        try:
            r_cc = _get(f"http://index.commoncrawl.org/CC-MAIN-2024-10-index?url=*.{domain}/*&output=json&limit=10000", 30)
            if r_cc and r_cc[0] == 200:
                for line in r_cc[2].splitlines()[:5000]:
                    try:
                        import json as _j5
                        d = _j5.loads(line)
                        u = d.get("url","")
                        if _is_useful(u): add_endpoint(u)
                    except: pass
        except Exception as e:
            log.debug(f"commoncrawl: {e}")


        # ── CommonCrawl Index — direct API (massive endpoint source) ─────────────
        try:
            import json as _json
            # Get latest CommonCrawl index
            cc_idx_r = _get("http://index.commoncrawl.org/collinfo.json", 15)
            if cc_idx_r and cc_idx_r[0] == 200:
                indices = _json.loads(cc_idx_r[2])
                # Use latest 3 indices for coverage
                for idx_info in indices[:3]:
                    api = idx_info.get("cdx-api","")
                    if not api: continue
                    cc_url = f"{api}?url=*.{domain}/*&output=text&fl=url&limit=50000&collapse=urlkey"
                    r = _get(cc_url, 60)
                    if r and r[0] == 200:
                        for line in r[2].splitlines():
                            u = line.strip()
                            if _is_useful(u): add_endpoint(u)
                    if _stopped(q): break
            log.info(f"[endpoint] source=commoncrawl saved={_cc_count if '_cc_count' in dir() else 0}")
            log.info("[endpoints] CommonCrawl done")
            _autosave_export("after_commoncrawl")
        except Exception as e:
            log.debug(f"commoncrawl direct: {e}")

        # ── URLScan.io bulk search ────────────────────────────────────────────────
        try:
            urlscan_url = f"https://urlscan.io/api/v1/search/?q=domain:{domain}&size=10000&fields=page.url"
            r = _get(urlscan_url, 30)
            if r and r[0] == 200:
                import json as _j2
                data = _j2.loads(r[2])
                for result in data.get("results",[]):
                    u = result.get("page",{}).get("url","")
                    if _is_useful(u): add_endpoint(u)
            log.info(f"[endpoint] source=urlscan saved={_urlscan_count if '_urlscan_count' in dir() else 0}")
            log.info("[endpoints] URLScan done")
        except Exception as e:
            log.debug(f"urlscan endpoints: {e}")

        # ── OTX AlienVault URL list ───────────────────────────────────────────────
        _otx_saved = 0
        try:
            for page in range(1, 6):  # up to 5 pages = 5000 URLs
                otx_url = f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/url_list?limit=1000&page={page}"
                r = _get(otx_url, 15)
                if not r or r[0] != 200: break
                import json as _j3
                data = _j3.loads(r[2])
                urls = data.get("url_list",[])
                if not urls: break
                for item in urls:
                    u = item.get("url","")
                    if _is_useful(u): add_endpoint(u, source="otx"); _otx_saved += 1
                if not data.get("has_next", False): break
            log.info(f"[endpoint] source=otx saved={_otx_saved}")
            log.info("[endpoints] OTX AlienVault done")
        except Exception as e:
            log.debug(f"otx urls: {e}")

        # ── Katana passive — without crawling, just extract from JS/HTML ──────────
        if T.get("katana"):
            try:
                tmp_live_k = _tmp(live_hosts[:200])
                # Check if passive mode is supported
                ktest2 = subprocess.run([T["katana"],"-h"],
                    capture_output=True, text=True, env=_env(), timeout=10)
                kt2 = ktest2.stdout + ktest2.stderr
                has_passive = "-passive" in kt2 or "--passive" in kt2
                
                cmd = [T["katana"], "-list", tmp_live_k, "-silent",
                       "-timeout", "10", "-c", "50"]
                if has_passive:
                    cmd.insert(3, "-passive")
                proc = _run(cmd)
                _katana_t0 = time.monotonic()
                for line in proc.stdout:
                    if (time.monotonic()-_katana_t0) > 115: proc.kill(); break
                    u = line.strip()
                    if _is_useful(u): add_endpoint(u, crawled=True)
                    if _stopped(q): proc.kill(); break
                try: proc.wait(timeout=5)
                except Exception: proc.kill()
                _rm(tmp_live_k)
            except Exception as e:
                log.debug(f"katana passive: {e}")

        # ── Common API/admin paths on live hosts (always runs) ────────────────
        common_paths = [
            "/api","/api/v1","/api/v2","/api/v3","/graphql","/admin",
            "/swagger","/swagger-ui","/swagger.json","/openapi.json",
            "/api-docs","/docs","/actuator","/health","/metrics",
            "/.env","/.git/config","/robots.txt","/sitemap.xml",
            "/wp-admin","/wp-login.php","/login","/signin",
        ]
        # Parallel common path probe
        import concurrent.futures as _cf
        _probes = [(h.rstrip("/")+p) for h in live_hosts[:30] for p in common_paths
                   if (h.rstrip("/")+p) not in endpoints]
        def _probe(u):
            try:
                r = _get(u, 3)
                return u if r and r[0] in (200,301,302,401,403) else None
            except: return None
        _ex_probe = _cf.ThreadPoolExecutor(max_workers=30)
        try:
            for u in _ex_probe.map(_probe, _probes, timeout=120):
                if u: add_endpoint(u)
        except Exception: pass
        finally: _ex_probe.shutdown(wait=False)


    # ── Auto-extract params from collected endpoints ───────────────────────────
    def _auto_extract_params():
        """
        Parse all collected endpoints for parameters.
        For endpoints WITHOUT params, inject common high-value params.
        """
        HIGH_VALUE_PARAMS = [
            "id", "user_id", "user", "username", "account", "account_id",
            "file", "filename", "path", "filepath", "dir", "directory",
            "url", "redirect", "redirect_url", "next", "return", "return_url",
            "goto", "forward", "dest", "destination", "target",
            "page", "p", "q", "query", "search", "s", "term", "keyword",
            "token", "access_token", "auth", "key", "api_key", "apikey",
            "lang", "language", "locale", "format", "output", "type",
            "callback", "jsonp", "ref", "referrer", "source", "src",
            "cat", "category", "tag", "section", "chapter", "module",
            "item", "product", "product_id", "item_id", "order", "order_id",
            "cmd", "command", "exec", "execute", "run", "action",
            "template", "view", "layout", "theme", "style", "skin",
            "load", "include", "require", "import", "data", "content",
        ]
        # Find endpoints without params
        no_param_ends = [e for e in list(endpoints) if "=" not in e and "?" not in e
                         and e.startswith("http")
                         and not e.endswith((".css",".js",".png",".jpg",".gif",
                                             ".ico",".woff",".woff2",".svg",".mp4"))]

        injected = 0
        for ep in no_param_ends[:200]:
            for param in HIGH_VALUE_PARAMS[:10]:  # top 10 per endpoint
                new_ep = f"{ep}?{param}=1"
                if new_ep not in endpoints:
                    add_endpoint(new_ep)
                    injected += 1
            if injected >= 2000: break

        log.info(f"[params] injected {injected} parameterized test URLs")

    _auto_extract_params()

    step("endpoints","done", f"{len(endpoints)} endpoints")
    if _stopped(q): return

    # ══════════════════════════════════════════════════
    # 4b. SCREENSHOTS — gowitness runs AFTER endpoints
    #     (moved from before port scan so it no longer
    #      blocks port scan or endpoint collection)
    # ══════════════════════════════════════════════════
    if T.get("gowitness") and live_hosts:
        step("screenshots", "run", f"capturing {min(len(live_hosts),200)} hosts")
        try:
            tmp_h = _tmp(live_hosts[:200])
            proc = _run([T["gowitness"],"file","-f",tmp_h,"--no-http"])
            proc.wait(timeout=300)
            _rm(tmp_h)
            log.info(f"[gowitness] screenshots done for {len(live_hosts[:200])} hosts")
            step("screenshots", "done", f"{len(live_hosts[:200])} hosts captured")
        except Exception as e:
            log.debug(f"gowitness: {e}")
            step("screenshots", "skip", "gowitness error or timeout")
    if _stopped(q): return

    # ══════════════════════════════════════════════════
    # 5. CRAWL — katana + gospider + hakrawler parallel
    # ══════════════════════════════════════════════════
    # Crawl tool fallback: katana → gospider → hakrawler
    _crawl_tool = None
    if T.get("katana"):
        _crawl_tool = "katana"
    elif T.get("gospider"):
        _crawl_tool = "gospider"
        log.info("[tool-health] katana not found → fallback to gospider")
    elif T.get("hakrawler"):
        _crawl_tool = "hakrawler"
        log.info("[tool-health] katana/gospider not found → fallback to hakrawler")
    else:
        log.info("[tool-health] no crawler available → skipping crawl")

    if skip_crawl or not live_hosts or not _crawl_tool:
        step("crawl","skip" if (skip_crawl or not live_hosts) else "skip",
             "no crawler available" if not _crawl_tool else "")
    else:
        step("crawl","run")
        crawled = 0
        _crawl_lock = threading.Lock()

        def _inc():
            nonlocal crawled
            with _crawl_lock: crawled += 1

        ctargets = live_hosts[:400]  # large domains need more crawl targets

        def run_katana():
            if not T.get("katana"): return
            try:
                # Probe katana flags — different versions have different flags
                test = subprocess.run(
                    [T["katana"],"-h"],
                    capture_output=True, text=True, env=_env(), timeout=10
                )
                ht = test.stdout + test.stderr
                has_list  = "-list" in ht or "-l " in ht
                has_jc    = "-jc" in ht or "-js-crawl" in ht
                has_duc   = "-duc" in ht or "-disable-update-check" in ht
                has_depth = "-depth" in ht or "-d " in ht

                tmp_t = _tmp(ctargets)
                try:
                    if has_list:
                        cmd = [T["katana"], "-list", tmp_t, "-silent",
                               "-timeout", "15", "-c", "50"]
                        if has_depth: cmd += ["-depth", "4"]
                        if has_jc:    cmd += ["-jc"]
                        if has_duc:   cmd += ["-duc"]
                        # -aff = automatic form filling (katana v1.1+)
                        if "-aff" in ht or "automatic-form-fill" in ht:
                            cmd += ["-aff"]
                        # Rate limit if supported
                        if "-rl" in ht or "--rate-limit" in ht:
                            cmd += ["-rl", "150"]
                        proc = _run(cmd)
                        _gs_t0 = time.monotonic()
                        for line in proc.stdout:
                            if (time.monotonic()-_gs_t0) > 180: proc.kill(); break
                            u = line.strip()
                            if u and u.startswith("http"):
                                if add_endpoint(u, crawled=True): _inc()
                            if _stopped(q): proc.kill(); break
                        try: proc.wait(timeout=120)
                        except: proc.kill()
                    else:
                        # older katana: one URL at a time with -u
                        for target in ctargets[:20]:
                            if _stopped(q): break
                            cmd = [T["katana"], "-u", target, "-silent", "-timeout", "8"]
                            if has_depth: cmd += ["-depth", "3"]
                            if has_jc:    cmd += ["-jc"]
                            try:
                                proc = _run(cmd)
                                _gs2_t0 = time.monotonic()
                                for line in proc.stdout:
                                    if (time.monotonic()-_gs2_t0) > 22: proc.kill(); break
                                    u = line.strip()
                                    if u and u.startswith("http"):
                                        if add_endpoint(u, crawled=True): _inc()
                                    if _stopped(q): proc.kill(); break
                                try: proc.wait(timeout=90)
                                except: proc.kill()
                            except Exception as e:
                                log.warning(f"katana {target}: {e}")
                finally:
                    _rm(tmp_t)
            except Exception as e:
                log.warning(f"katana: {e}")

        def run_gospider():
            if not T.get("gospider"): return
            import concurrent.futures as _gcf
            def _spider_one(target):
                if _stopped(q): return []
                try:
                    cmd = [T["gospider"], "-s", target, "-c", "5", "-d", "2", "-q"]
                    proc = _run(cmd)
                    _hak_t0 = time.monotonic()
                    urls = []
                    for line in proc.stdout:
                        if (time.monotonic()-_hak_t0) > 22: proc.kill(); break
                        m = re.search(r'https?://[^\s\]\[<>"\']+', line)
                        if m:
                            u = m.group(0).rstrip(".,);\"'")
                            urls.append(u)
                        if _stopped(q): proc.kill(); break
                    try: proc.wait(timeout=25)
                    except: proc.kill()
                    return urls
                except Exception as e:
                    log.debug(f"gospider {target}: {e}"); return []
            _gexe = _gcf.ThreadPoolExecutor(max_workers=5)
            _gfuts = {_gexe.submit(_spider_one, t): t for t in ctargets[:20]}
            try:
                for _gf in _gcf.as_completed(_gfuts, timeout=90):
                    try:
                        for u in (_gf.result(timeout=30) or []):
                            if add_endpoint(u, crawled=True): _inc()
                    except: pass
            except Exception:
                for _gf in _gfuts:
                    if not _gf.done(): _gf.cancel()
            finally:
                _gexe.shutdown(wait=False)

        def run_hakrawler():
            if not T.get("hakrawler"): return
            try:
                # Detect hakrawler version: new version uses stdin, old uses -url
                test = subprocess.run(
                    [T["hakrawler"], "-h"],
                    capture_output=True, text=True, env=_env(), timeout=10
                )
                ht = test.stdout + test.stderr
                uses_stdin = "stdin" in ht.lower() or "-url" not in ht

                import concurrent.futures as _hcf
                def _hak_one(target):
                    if _stopped(q): return []
                    try:
                        if uses_stdin:
                            proc = subprocess.Popen(
                                [T["hakrawler"], "-d", "2", "-insecure"],
                                stdin=subprocess.PIPE,
                                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                text=True, env=_env(), start_new_session=True
                            )
                            try:
                                out, _ = proc.communicate(input=target+"\n", timeout=25)
                                return [l.strip() for l in out.splitlines()
                                        if l.strip().startswith("http")]
                            except: proc.kill(); return []
                        else:
                            proc = _run([T["hakrawler"], "-url", target,
                                         "-depth", "2", "-plain", "-insecure"])
                            urls = []
                            _hak2_t0 = time.monotonic()
                            for line in proc.stdout:
                                if (time.monotonic()-_hak2_t0) > 22: proc.kill(); break
                                u = line.strip()
                                if u.startswith("http"): urls.append(u)
                                if _stopped(q): proc.kill(); break
                            try: proc.wait(timeout=5)
                            except Exception: proc.kill()
                            return urls
                    except Exception as e:
                        log.debug(f"hakrawler {target}: {e}"); return []
                _hexe = _hcf.ThreadPoolExecutor(max_workers=5)
                _hfuts = {_hexe.submit(_hak_one, t): t for t in ctargets[:20]}
                try:
                    for _hf in _hcf.as_completed(_hfuts, timeout=90):
                        try:
                            for u in (_hf.result(timeout=30) or []):
                                if add_endpoint(u, crawled=True): _inc()
                        except: pass
                except Exception:
                    for _hf in _hfuts:
                        if not _hf.done(): _hf.cancel()
                finally:
                    _hexe.shutdown(wait=False)
            except Exception as e:
                log.warning(f"hakrawler: {e}")

        def run_crawl4ai():
            """
            Crawl4AI — handles SPAs, React/Vue/Angular, lazy content,
            bot-detection bypass, authenticated crawl, network request capture.
            Install: pip install crawl4ai
            """
            try:
                from engine.crawl4ai_engine import run_crawl4ai, _is_available
                if not _is_available():
                    log.info("[crawl] crawl4ai not installed — pip install crawl4ai && playwright install chromium")
                    emit({"type":"step","name":"crawl","state":"run","meta":"crawl4ai: not installed, using other crawlers"})
                    return
                # Load saved auth session for this domain if available
                _c4ai_cookies = ""
                _c4ai_token   = ""
                try:
                    _auth = db.get_auth(root_domain) or {}
                    _c4ai_cookies = _auth.get("cookie","")
                    _c4ai_token   = _auth.get("token","")
                except: pass

                log.info(f"[crawl4ai] starting on {len(ctargets[:5])} targets"
                         + (" (authenticated)" if _c4ai_cookies or _c4ai_token else ""))
                emit({"type":"step","name":"crawl","state":"run",
                      "meta":"crawl4ai: SPA + stealth + auth crawl..."})

                result = run_crawl4ai(
                    targets=ctargets[:5],    # top 5 live hosts
                    domain=root_domain,
                    cookies=_c4ai_cookies,
                    token=_c4ai_token,
                    depth=2,
                    max_pages=30,
                    add_endpoint_fn=lambda u: add_endpoint(u, crawled=True),
                    emit_fn=emit,
                )
                ep_count = result.get("total_endpoints",0)
                xhr_count = result.get("total_network_calls",0)
                log.info(f"[crawl4ai] done: {ep_count} endpoints, {xhr_count} XHR")
                if ep_count or xhr_count:
                    emit({"type":"step","name":"crawl","state":"run",
                          "meta":f"crawl4ai: {ep_count} endpoints, {xhr_count} API calls"})
            except Exception as _c4e:
                log.warning(f"[crawl4ai] {_c4e}")

        def run_python_crawl():
            """Pure Python crawler — always works, no external tools needed."""
            nonlocal crawled
            import time as _pytime
            visited    = set()
            to_visit   = list(ctargets[:30])   # start from 30 live hosts
            limit      = 10000                  # raised from 3000
            _start     = _pytime.time()
            _timeout   = min(CRAWL_TIMEOUT, 180) # hard wall: 3 min

            while to_visit and crawled < limit:
                if _pytime.time() - _start > _timeout:
                    log.info(f"[crawl-py] timeout after {_timeout}s, {crawled} urls")
                    break
                if _stopped(q): break
                url = to_visit.pop(0)
                if url in visited: continue
                visited.add(url)
                try:
                    r = _get(url, 8)
                    if not r: continue
                    ct = r[1].get("Content-Type","")
                    # Accept html pages
                    if "text/html" not in ct and "xhtml" not in ct: continue
                    body = r[2]
                    # Extract all links
                    for m in re.finditer(
                        r'(?:href|src|action|data-url|data-href)=["\']([^"\'<>\s]{3,})["\']',
                        body, re.I
                    ):
                        raw = m.group(1).strip()
                        if not raw or raw.startswith(("#","javascript:","mailto:","tel:")): continue
                        try:
                            full = urllib.parse.urljoin(url, raw)
                            p    = urllib.parse.urlparse(full)
                            if not p.netloc: continue
                            # Accept same domain and subdomains
                            if not (p.netloc == domain or
                                    p.netloc.endswith("."+domain)): continue
                            if full not in visited and len(to_visit) < 2000:
                                to_visit.append(full)
                            if add_endpoint(full, crawled=True):
                                with _crawl_lock: crawled += 1
                                emit({"type":"crawled","url":full})
                        except: pass
                    # Also grab JS files referenced
                    for m in re.finditer(r'''["'](/[^"'<>\s]+\.js(?:[?][^"'<>\s]*)?)[\"']''', body):
                        try:
                            full = urllib.parse.urljoin(url, m.group(1))
                            add_endpoint(full, crawled=False)
                        except: pass

                    # Extract API endpoints from JS/HTML source
                    for m in re.finditer(
                        r'''["'](((?:https?://[^\s"'<>]{0,30})?/(?:api|v\d+|rest|graphql|service|endpoint)[^"'<>\s]{1,80}))["']''',
                        body
                    ):
                        try:
                            ep = m.group(1)
                            full = urllib.parse.urljoin(url, ep) if ep.startswith("/") else ep
                            if full.startswith("http"): add_endpoint(full, crawled=True)
                        except: pass

                    # Extract parameterized URLs — critical for vuln testing
                    for m in re.finditer(
                        r'''["']((?:https?://[^"'<>\s]+)?/[^"'<>\s]{2,}[?][a-zA-Z][^"'<>\s]{3,80})["']''',
                        body
                    ):
                        try:
                            full = m.group(1)
                            if not full.startswith("http"):
                                full = urllib.parse.urljoin(url, full)
                            if "?" in full and full.startswith("http"):
                                add_endpoint(full, crawled=True)
                        except: pass

                    # Extract form action URLs (POST endpoints = injectable)
                    for m in re.finditer(r'<form[^>]+action=["\']([^"\'<>\s]+)["\']', body, re.I):
                        try:
                            full = urllib.parse.urljoin(url, m.group(1))
                            if full.startswith("http"): add_endpoint(full, crawled=True)
                        except: pass

                except Exception as e:
                    log.debug(f"[crawl-py] {url}: {e}")

        # Run external crawlers if available
        available = []
        for f, name in [(run_katana,"katana"),
                        (run_gospider,"gospider"),
                        (run_hakrawler,"hakrawler")]:
            if T.get(name):
                available.append(f)
                log.info(f"[crawl] using external tool: {name}")
        
        if not available:
            log.info("[crawl] no external crawlers found — using Python crawler + crawl4ai only")
            emit({"type":"step","name":"crawl","state":"run",
                  "meta":"No katana/gospider/hakrawler found — using built-in crawler"})
        else:
            log.info(f"[crawl] {len(available)} external tools available")

        # Run ALL crawlers in parallel — external tools + crawl4ai + python fallback
        all_crawlers = available + [run_crawl4ai, run_python_crawl]
        log.info(f"[crawl] running {len(all_crawlers)} crawlers in parallel ({len(available)} external + python)")
        cthreads = [threading.Thread(target=f, daemon=True, name=getattr(f,"__name__",str(f)))
                    for f in all_crawlers]
        for t in cthreads: t.start()
        for t in cthreads: t.join(timeout=int(CRAWL_TIMEOUT))
        log.info(f"[crawl] total crawled: {crawled}")

        step("crawl","done",f"{crawled} urls crawled")
        _autosave_export("after_crawl")


    # ══════════════════════════════════════════════════
    # 5b. DIRECTORY BRUTE FORCE — ffuf / feroxbuster / gobuster
    # ══════════════════════════════════════════════════
    if not _stopped(q) and live_hosts and not opts.get("skip_dirbust"):
        step("dirbust","run", f"directory brute force on {min(10,len(live_hosts))} hosts")
        emit({"type":"step","name":"dirbust","state":"run","meta":"Brute forcing paths..."})

        # Wordlist priority
        DIRBUST_WORDLISTS = [
            os.path.expanduser("~/Desktop/recon/SecLists/Discovery/Web-Content/common.txt"),
            "/home/kali/Desktop/recon/SecLists/Discovery/Web-Content/common.txt",
            "/root/Desktop/recon/SecLists/Discovery/Web-Content/common.txt",
            "/usr/share/wordlists/seclists/Discovery/Web-Content/common.txt",
            "/usr/share/wordlists/dirb/common.txt",
            "/usr/share/seclists/Discovery/Web-Content/common.txt",
        ]
        _wl = next((w for w in DIRBUST_WORDLISTS if os.path.isfile(w)), None)

        if _wl:
            brute_targets = live_hosts[:10]  # top 10 live hosts
            import concurrent.futures as _dcf

            def _dirbust_host(target):
                found_paths = []
                base = target.rstrip("/")

                # Try ffuf first
                if T.get("ffuf"):
                    try:
                        cmd = [T["ffuf"], "-u", f"{base}/FUZZ",
                               "-w", _wl,
                               "-mc", "200,201,204,301,302,307,401,403",
                               "-t", "50",
                               "-timeout", "5",
                               "-s",  # silent
                               "-o", "/dev/stdout", "-of", "csv"]
                        proc = _run(cmd)
                        _ffuf_t0 = time.monotonic()
                        for line in proc.stdout:
                            if (time.monotonic()-_ffuf_t0) > 175: proc.kill(); break
                            line = line.strip()
                            if line and not line.startswith("url,"):
                                parts = line.split(",")
                                if parts and parts[0].startswith("http"):
                                    found_paths.append(parts[0])
                        try: proc.wait(timeout=5)
                        except Exception: proc.kill()
                    except Exception as e:
                        log.debug(f"ffuf {target}: {e}")

                # Fallback: gobuster
                if not found_paths and T.get("gobuster"):
                    try:
                        cmd = [T["gobuster"], "dir",
                               "-u", base,
                               "-w", _wl,
                               "-t", "30",
                               "-q",
                               "--no-error",
                               "-b", "404,429,500"]
                        proc = _run(cmd)
                        _gob_t0 = time.monotonic()
                        for line in proc.stdout:
                            if (time.monotonic()-_gob_t0) > 175: proc.kill(); break
                            line = line.strip()
                            if line.startswith("/"):
                                found_paths.append(base + line.split(" ")[0])
                            elif line.startswith("http"):
                                found_paths.append(line.split(" ")[0])
                        try: proc.wait(timeout=5)
                        except Exception: proc.kill()
                    except Exception as e:
                        log.debug(f"gobuster {target}: {e}")

                # Fallback: feroxbuster
                if not found_paths and T.get("feroxbuster"):
                    try:
                        cmd = [T["feroxbuster"], "--url", base,
                               "--wordlist", _wl,
                               "--threads", "30",
                               "--depth", "2",
                               "--quiet",
                               "--no-recursion",
                               "--status-codes", "200,201,204,301,302,307,401,403"]
                        proc = _run(cmd)
                        _ferox_t0 = time.monotonic()
                        for line in proc.stdout:
                            if (time.monotonic()-_ferox_t0) > 175: proc.kill(); break
                            line = line.strip()
                            if line.startswith("http") and " " in line:
                                found_paths.append(line.split()[0])
                        try: proc.wait(timeout=5)
                        except Exception: proc.kill()
                    except Exception as e:
                        log.debug(f"feroxbuster {target}: {e}")

                return found_paths

            # Run in parallel on multiple hosts
            _dex = _dcf.ThreadPoolExecutor(max_workers=3)
            _dfuts = {_dex.submit(_dirbust_host, t): t for t in brute_targets}
            try:
                for _df in _dcf.as_completed(_dfuts, timeout=600):
                    try:
                        for path_url in (_df.result(timeout=300) or []):
                            if path_url and path_url.startswith("http"):
                                add_endpoint(path_url)
                    except: pass
            except Exception:
                for _df in _dfuts:
                    if not _df.done(): _df.cancel()
            finally:
                _dex.shutdown(wait=False)

            step("dirbust","done", f"{len(endpoints)} total endpoints after dirbust")
            _autosave_export("after_dirbust")
        else:
            step("dirbust","skip","no wordlist found — install SecLists")
            log.debug("[dirbust] no wordlist found")

    # ══════════════════════════════════════════════════
    # 5c. ARJUN — parameter discovery on live endpoints
    # ══════════════════════════════════════════════════
    if not _stopped(q) and T.get("arjun") and endpoints and not opts.get("skip_params"):
        step("params","run","Arjun parameter discovery...")
        try:
            # Sample of interesting endpoints without params
            no_param_ends = [e for e in list(endpoints) if "?" not in e
                             and e.startswith("http")
                             and not re.search(r"\.(css|js|png|jpg|gif|svg|ico)$", e)][:20]
            if no_param_ends:
                tmp_ep = _tmp(no_param_ends)
                proc = _run([T["arjun"],
                             "-i", tmp_ep,
                             "--stable",
                             "-t", "10",
                             "-oJ", "/dev/stdout"])
                out = ""
                _arjun_t0 = time.monotonic()
                for line in proc.stdout:
                    if (time.monotonic()-_arjun_t0) > 295: proc.kill(); break
                    out += line
                try: proc.wait(timeout=5)
                except Exception: proc.kill()
                _rm(tmp_ep)
                # Parse Arjun JSON output
                try:
                    import json as _j2
                    arjun_data = _j2.loads(out)
                    for url, params_info in arjun_data.items():
                        params = params_info.get("params", []) if isinstance(params_info, dict) else []
                        for param in params:
                            new_ep = f"{url}?{param}=FUZZ"
                            add_endpoint(new_ep)
                except: pass
        except Exception as e:
            log.warning(f"arjun: {e}")
        step("params","done")

    # ══════════════════════════════════════════════════
    # 6. JS FILES
    # ══════════════════════════════════════════════════
    if not T.get("subjs"):
        log.info("[tool-health] subjs not found → skipping js_collect")
        step("js_collect","skip","subjs not installed")
        step("js_deep","skip","subjs not installed — no JS to analyse")
    elif skip_js or not live_hosts:
        step("js_collect","skip")
        step("js_deep","skip","no JS files to analyse")
    else:
        step("js_collect","run","collecting JS files...")
        js_count = 0

        def _emit_js_progress():
            step("js_collect","run",f"{js_count} JS files found...")

        # subjs — detect flag style (-i vs -l vs piped)
        if T.get("subjs"):
            tmp_live = _tmp(live_hosts)
            try:
                # Probe subjs for flag support
                test = subprocess.run(
                    [T["subjs"],"-h"],
                    capture_output=True, text=True, env=_env(), timeout=10
                )
                ht = test.stdout + test.stderr
                # Try -i flag first (older), then -l (newer), then stdin
                if "-i" in ht:
                    cmd = [T["subjs"], "-i", tmp_live, "-c", "20"]
                elif "-l" in ht:
                    cmd = [T["subjs"], "-l", tmp_live, "-c", "20"]
                else:
                    cmd = None  # will use stdin below

                if cmd:
                    proc = _run(cmd)
                    _subjs_start = time.monotonic()
                    for line in proc.stdout:
                        if _stopped(q) or (time.monotonic() - _subjs_start) > 90:
                            proc.kill(); break
                        u = line.strip()
                        if u and u.startswith("http") and re.search(r'\.js(\?|#|$)',u,re.I):
                            if add_endpoint(u): js_count += 1
                    if _stopped(q): proc.kill()
                    try: proc.wait(timeout=5)
                    except: proc.kill()
                else:
                    # stdin mode — use with block to close file handle properly
                    try:
                        with open(tmp_live) as _fin:
                            proc = subprocess.Popen(
                                [T["subjs"], "-c", "20"],
                                stdin=_fin, stdout=subprocess.PIPE,
                                stderr=subprocess.DEVNULL, text=True, env=_env(),
                                start_new_session=True
                            )
                        _subjs_stdin_start = time.monotonic()
                        for line in proc.stdout:
                            # Hard time limit on read loop — prevents indefinite hang
                            if (time.monotonic() - _subjs_stdin_start) > 90:
                                proc.kill()
                                log.info("[js] subjs stdin timeout after 90s")
                                break
                            if _stopped(q): proc.kill(); break
                            u = line.strip()
                            if u and u.startswith("http") and re.search(r'\.js(\?|#|$)',u,re.I):
                                if add_endpoint(u): js_count += 1
                        try: proc.wait(timeout=5)
                        except: proc.kill()
                    except Exception as e:
                        log.warning(f"subjs stdin: {e}")
            except Exception as e:
                log.warning(f"subjs: {e}")
            finally:
                _rm(tmp_live)

        # Extract JS from already-collected endpoints
        for url in list(endpoints):
            if re.search(r'\.js(\?|#|$)', url, re.I):
                js_count += 1

        # Check common JS paths on live hosts directly
        js_paths = [
            "/static/js/main.js", "/assets/js/app.js",
            "/js/app.js", "/js/main.js", "/bundle.js",
            "/app.js", "/main.js", "/vendor.js",
            "/static/js/chunk-vendors.js", "/dist/app.js",
            "/static/bundle.js", "/assets/bundle.js",
            "/js/bundle.js", "/dist/main.js", "/build/static/js/main.js",
        ]
        for host in live_hosts[:20]:
            if _stopped(q): break
            for path in js_paths:
                url = host.rstrip("/") + path
                if url not in endpoints:
                    r = _get(url, 5)
                    if r and r[0] == 200:
                        ct = r[1].get("Content-Type","")
                        if "javascript" in ct or url.endswith(".js"):
                            if add_endpoint(url): js_count += 1

        # ── JS Deep analysis — parallelized, capped, prioritized ─────────────
        _js_deep_t0 = time.monotonic()
        _JS_BUDGET  = 120  # hard time budget for entire JS deep phase (seconds)
        step("js_deep","run",f"deep JS analysis on {js_count} files...")

        # Collect all JS URLs, prioritize high-value paths
        _all_js = [e for e in list(endpoints)
                   if re.search(r'\.js(\?|#|$)', e, re.I)]
        _JS_PRIORITY = ["/api/","/auth/","/admin/","/app/","/login/",
                        "/dashboard/","/payment/","/sso/","/oauth/"]
        _js_priority = [u for u in _all_js
                        if any(p in u for p in _JS_PRIORITY)]
        _js_rest     = [u for u in _all_js if u not in set(_js_priority)]
        _js_urls     = (_js_priority + _js_rest)[:JS_MAX]   # cap at JS_MAX

        log.info(f"[js] total_js={len(_all_js)} selected={len(_js_urls)}"
                 f" priority={len(_js_priority)} cap={JS_MAX}")

        # LinkFinder path detection
        lf_path = ""
        for lf_dir in [os.path.expanduser("~/Desktop/recon/LinkFinder"),
                       "/home/kali/Desktop/recon/LinkFinder",
                       "/root/Desktop/recon/LinkFinder"]:
            if os.path.isfile(os.path.join(lf_dir, "linkfinder.py")):
                lf_path = os.path.join(lf_dir, "linkfinder.py")
                break

        # Worker function — fetch + scan_secrets + optional linkfinder
        def _analyse_one_js(js_url: str) -> int:
            """Fetch one JS URL, scan for secrets, run linkfinder. Returns count added."""
            if _stopped(q): return 0
            if (time.monotonic() - _js_deep_t0) > _JS_BUDGET: return 0
            added = 0
            try:
                _js_r = _get(js_url, timeout=8)
                if _js_r and _js_r[2]:
                    _secrets = _scan_js_secrets(js_url, _js_r[2], emit)
                    if _secrets:
                        log.info(f"[secrets] {js_url}: {len(_secrets)} secrets found")
            except Exception: pass
            if lf_path:
                try:
                    proc = _run(["python3", lf_path, "-i", js_url, "-o", "cli"])
                    for line in proc.stdout:
                        if (time.monotonic() - _js_deep_t0) > _JS_BUDGET:
                            proc.kill(); break
                        line = line.strip()
                        m = re.search(r'\[\*\]\s+(/[a-zA-Z0-9/_.\-?=&%#@]+)', line)
                        if m:
                            rel = m.group(1)
                            if any(s in rel for s in ["/home/","/root/","/usr/","/var/","/etc/","/opt/"]):
                                continue
                            if len(rel) > 1 and not rel.startswith("//"):
                                try:
                                    base = "/".join(js_url.split("/")[:3])
                                    full = base + rel
                                    if full.startswith("http"):
                                        if add_endpoint(full): added += 1
                                except: pass
                    try: proc.wait(timeout=5)
                    except: proc.kill()
                except Exception as e:
                    log.debug(f"linkfinder {js_url}: {e}")
            return added

        # Parallel execution with hard time budget
        _js_processed = 0
        _js_timeout_skipped = 0
        _js_new_endpoints = 0
        import concurrent.futures as _jcf
        _js_workers = min(8, len(_js_urls))
        if _js_urls and _js_workers > 0:
            _jexe = _jcf.ThreadPoolExecutor(max_workers=_js_workers)
            try:
                _jfuts = {_jexe.submit(_analyse_one_js, url): url
                          for url in _js_urls}
                try:
                    for _jfut in _jcf.as_completed(_jfuts, timeout=_JS_BUDGET):
                        try:
                            _js_new_endpoints += _jfut.result(timeout=2)
                            _js_processed += 1
                        except Exception:
                            _js_timeout_skipped += 1
                        if _stopped(q): break
                except _jcf.TimeoutError:
                    log.info(f"[js] deep_budget_exceeded elapsed={round(time.monotonic()-_js_deep_t0,1)}s")
                    _js_timeout_skipped += sum(1 for f in _jfuts if not f.done())
            finally:
                # Cancel any pending futures and shut down — never block forever
                for _jf in _jfuts:
                    _jf.cancel()
                _jexe.shutdown(wait=False)

        _js_elapsed = round(time.monotonic() - _js_deep_t0, 1)
        log.info(f"[js] processed={_js_processed}/{len(_js_urls)}"
                 f" timeout_skipped={_js_timeout_skipped}"
                 f" new_endpoints={_js_new_endpoints}"
                 f" elapsed={_js_elapsed}s")

        step("js_collect","done",f"{js_count} JS files")
        log.info(f"[js] collect_done total_js={js_count}")
        # JS Deep — already ran in parallel above with _JS_BUDGET time limit
        # Use locals() check to safely access vars that may not exist if block errored
        _js_out_count  = locals().get("_js_processed", 0)
        _js_skip_count = locals().get("_js_timeout_skipped", 0)
        _js_elapsed_s  = locals().get("_js_elapsed", 0)
        _js_deep_meta  = (f"{_js_out_count}/{js_count} files analysed"
                          f"{', '+str(_js_skip_count)+' timeout-skipped' if _js_skip_count else ''}")
        step("js_deep","done", _js_deep_meta)
        log.info(f"[stage] js_deep done files={js_count} processed={_js_out_count}"
                 f" skipped={_js_skip_count} elapsed={_js_elapsed_s}s")
        _autosave_export("after_js_collect")

    # ══════════════════════════════════════════════════
    # CLOUD SCANNING
    # ══════════════════════════════════════════════════
    # Auth Scan step — nuclei auth/login templates
    _auth_t0 = time.monotonic()
    if not live_hosts:
        step("auth_scan","skip","no live hosts")
        log.info("[auth_scan] skip reason=no_live_hosts")
    elif not T.get("nuclei"):
        step("auth_scan","skip","nuclei not installed")
        log.info("[auth_scan] skip reason=nuclei_not_found")
    else:
        step("auth_scan","run",f"scanning auth endpoints on {min(len(live_hosts),20)} hosts")
        log.info(f"[auth_scan] start targets={min(len(live_hosts),20)}")
        _auth_findings = 0
        try:
            _auth_hosts = live_hosts[:20]
            _auth_tmp   = _tmp(_auth_hosts)
            _auth_proc  = _run([
                T["nuclei"],"-l",_auth_tmp,
                "-tags","auth,login,panel,default-login",
                "-severity","medium,high,critical",
                "-silent","-timeout","8","-retries","1",
            ])
            _auth_loop_t0 = time.monotonic()
            try:
                for _al in _auth_proc.stdout:
                    _al = _al.strip()
                    if _al:
                        _auth_findings += 1
                        emit({"type":"log","msg":f"[auth] {_al}"})
                    # Hard time limit on read loop — prevents indefinite hang
                    if _stopped(q) or (time.monotonic()-_auth_loop_t0) > 180:
                        _auth_proc.kill()
                        if (time.monotonic()-_auth_loop_t0) > 180:
                            log.info("[auth_scan] timeout after 180s")
                            step("auth_scan","timeout","nuclei auth scan timed out after 180s")
                        break
                else:
                    try: _auth_proc.wait(timeout=5)
                    except: _auth_proc.kill()
            except Exception:
                _auth_proc.kill()
                step("auth_scan","timeout","nuclei auth scan timed out after 180s")
            _rm(_auth_tmp)
            _auth_dur = round(time.monotonic()-_auth_t0, 1)
            step("auth_scan","done",f"auth scan done findings={_auth_findings}")
            log.info(f"[auth_scan] done findings={_auth_findings} duration={_auth_dur}s")
        except Exception as _ae:
            step("auth_scan","error",str(_ae)[:80])
            log.debug(f"auth_scan: {_ae}")

    if not _stopped(q) and live_hosts:

        # s3scanner — find public S3 buckets related to domain
        if T.get("s3scanner"):
            step("endpoints","run","S3 bucket scanning...")
            try:
                proc = _run([T["s3scanner"],"scan","--bucket",root_domain.replace(".",""),
                             "--threads","10","--dump-all"])
                _s3_t0 = time.monotonic()
                for line in proc.stdout:
                    if (time.monotonic()-_s3_t0) > 115: proc.kill(); break
                    line = line.strip()
                    if line and ('s3' in line.lower() or 'bucket' in line.lower()):
                        emit({"type":"log","msg":f"S3: {line}"})
                    if _stopped(q): proc.kill(); break
                try: proc.wait(timeout=120)
                except: proc.kill()
            except Exception as e:
                log.debug(f"s3scanner: {e}")

        # cloudbrute — find cloud resources (S3, Azure Blob, GCP)
        if T.get("cloudbrute"):
            try:
                proc = _run([T["cloudbrute"],root_domain,
                             "--type","all","--threads","10","--randomagent"])
                _cb_t0 = time.monotonic()
                for line in proc.stdout:
                    if (time.monotonic()-_cb_t0) > 115: proc.kill(); break
                    line = line.strip()
                    if line and ("found" in line.lower() or "open" in line.lower()):
                        emit({"type":"log","msg":f"Cloud: {line}"})
                    if _stopped(q): proc.kill(); break
                try: proc.wait(timeout=180)
                except: proc.kill()
            except Exception as e:
                log.debug(f"cloudbrute: {e}")

        # gowitness — screenshot all live hosts
        _shots_t0 = time.monotonic()
        if T.get("gowitness") and len(live_hosts) > 0:
            _n_hosts = min(len(live_hosts), 100)
            step("screenshots","run",f"capturing {_n_hosts} hosts")
            try:
                tmp_h = _tmp(live_hosts[:100])
                screenshot_dir = f"data/{domain.replace('.','_')}/screenshots"
                os.makedirs(screenshot_dir, exist_ok=True)
                proc = _run([T["gowitness"],"file","-f",tmp_h,
                             "--output",screenshot_dir,
                             "--timeout","10","--threads","5"])
                try: proc.wait(timeout=180)
                except: proc.kill(); step("screenshots","timeout","gowitness timed out after 180s")
                _rm(tmp_h)
                _shots_dur = round(time.monotonic()-_shots_t0, 1)
                step("screenshots","done",f"{_n_hosts} hosts captured")
                log.info(f"[stage] screenshots done hosts={_n_hosts} duration={_shots_dur}s")
                emit({"type":"log","msg":f"Screenshots saved to {screenshot_dir}"})
            except Exception as e:
                step("screenshots","error",str(e)[:80])
                log.debug(f"gowitness: {e}")
        elif live_hosts:
            step("screenshots","skip","gowitness not installed")
        else:
            step("screenshots","skip","no live hosts")

    # ══════════════════════════════════════════════════
    # DONE
    # ══════════════════════════════════════════════════

    # Helper: write export files from current endpoint set.
    # Called here (recon complete) so intermediate writes can also call it.
    def _write_export_files(label: str = "recon_done"):
        try:
            from engine.endpoint_export import export_endpoints as _eexp
            from pathlib import Path as _EXPath
            # Pull from DB first (most authoritative), fall back to in-memory set
            _db_eps  = db.get_endpoints(domain, limit=200000) or []
            _url_list = _db_eps if _db_eps else list(endpoints)
            if not _url_list:
                log.info(f"[export] no URLs to write for {domain} ({label})")
                return {}
            _out_dir = str(_EXPath(__file__).parent / "data" / "exports" / domain)
            log.info(
                f"[export] writing domain={domain} urls={len(_url_list)}"
                f" out_dir={_out_dir} ({label})"
            )
            _written = _eexp(domain, _url_list, _out_dir, fmt="txt", min_count=1)
            log.info(
                f"[export] wrote"
                f" crawled={_written.get('crawled',0)}"
                f" params={_written.get('params',0)}"
                f" api={_written.get('api',0)}"
                f" xss={_written.get('xss',0)}"
                f" sqli={_written.get('sqli',0)}"
            )
            # Update shared export state for pipeline/debug
            _last_export_ts[0]     = time.monotonic()
            _last_export_count[0]  = len(_url_list)
            _last_export_reason[0] = label
            log.info(f"[export] autosave domain={domain} urls={len(_url_list)} reason={label} files={len(_written)}")
            return _written
        except Exception as _we:
            log.warning(f"[export] write failed ({label}): {_we}")
            return {}

    # AUTO-EXPORT: save categorized endpoint files when recon completes
    # ──────────────────────────────────────────────────────────────────────
    # Writes one .txt file per category to data/exports/<domain>/
    # Categories: xss, sqli, lfi, ssrf, redirect, admin, exposed, js,
    #             api, email, actuator, graphql, oauth, params, crawled
    # Stop periodic export thread
    try:
        _export_stop.set()
    except Exception:
        pass
    # Final subdomain export at recon_done
    try:
        from engine.subdomain_export import export_subdomains as _sub_exp3
        _sub_exp3(domain=domain, db=db,
                  subs=list(subs), live_hosts=live_hosts,
                  sub_scores=_sub_scores, sub_sources=_source_counts,
                  reason="recon_done")
    except Exception as _se3: log.debug(f"[subdomain-export] recon_done: {_se3}")
    _export_result = _write_export_files("recon_done")
    if _export_result:
        emit({
            "type":        "endpoint_files_saved",
            "domain":      domain,
            "total_urls":  len(db.get_endpoints(domain, limit=1) and
                              db.get_endpoints(domain, limit=200000) or list(endpoints)),
            "categories":  {k: f"data/exports/{domain}/{domain}_{k}.txt"
                            for k in _export_result},
        })
    log.info(
        f"[recon] endpoints_saved_db={db.count_endpoints(domain)}"
        f" endpoints_saved_files={len(_export_result)}"
    )
    # ──────────────────────────────────────────────────────────────────────

    db.set_step(domain,"done","done")
    emit({"type":"recon_done","subs":len(subs),
          "live":len(live_hosts),"endpoints":len(endpoints)})
    log.info(f"[recon] DONE — {len(subs)} subs | {len(live_hosts)} live | {len(endpoints)} endpoints")


# ── DNS Zone Transfer (AXFR) ──────────────────────────────────────────────────
def _check_zone_transfer(domain: str, emit) -> list:
    """Attempt AXFR zone transfer against all nameservers."""
    import socket as _sock, struct
    found_records = []

    try:
        # Get nameservers via DNS
        import subprocess as _sp
        ns_result = _sp.run(["dig","NS",domain,"+short"],
                            capture_output=True,text=True,timeout=10)
        nameservers = [l.strip().rstrip(".") for l in ns_result.stdout.strip().split()
                       if l.strip() and "." in l]
    except Exception:
        nameservers = []

    # Also try common NS patterns
    common_ns = [f"ns1.{domain}",f"ns2.{domain}",f"ns.{domain}"]
    for ns in common_ns:
        try:
            ip = _sock.gethostbyname(ns)
            if ns not in nameservers:
                nameservers.append(ns)
        except Exception:
            pass

    for ns in nameservers[:5]:
        try:
            ns_ip = _sock.gethostbyname(ns)
            # Build AXFR query
            # DNS message: ID + flags + QDCOUNT + ANCOUNT + NSCOUNT + ARCOUNT + QNAME + QTYPE + QCLASS
            qname = b""
            for part in domain.split("."):
                qname += bytes([len(part)]) + part.encode()
            qname += b"\x00"

            query = (
                b"\xab\xcd"   # ID
                b"\x00\x00"   # Flags (standard query)
                b"\x00\x01"   # QDCOUNT = 1
                b"\x00\x00"   # ANCOUNT
                b"\x00\x00"   # NSCOUNT
                b"\x00\x00"   # ARCOUNT
                + qname
                + b"\x00\xfc" # QTYPE = AXFR (252)
                + b"\x00\x01" # QCLASS = IN
            )

            # TCP for AXFR (DNS uses TCP for zone transfers)
            query_with_len = struct.pack("!H", len(query)) + query

            sock = _sock.socket(_sock.AF_INET, _sock.SOCK_STREAM)
            sock.settimeout(8)
            sock.connect((ns_ip, 53))
            sock.sendall(query_with_len)

            # Read response
            resp = b""
            while True:
                chunk = sock.recv(4096)
                if not chunk: break
                resp += chunk
                if len(resp) > 50000: break
            sock.close()

            if len(resp) > 12:
                # Got a response — zone transfer may have succeeded
                emit({"type":"log","msg":f"[axfr] Zone transfer response from {ns}: {len(resp)} bytes"})
                found_records.append({
                    "nameserver": ns,
                    "response_size": len(resp),
                    "raw_snippet": resp[2:200].hex(),
                })

        except ConnectionRefusedError:
            pass
        except Exception as e:
            log.debug(f"[axfr] {ns}: {e}")

    return found_records

