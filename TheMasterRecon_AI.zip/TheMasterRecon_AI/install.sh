#!/usr/bin/env bash
# BugScan ELITE — Installer for Kali Linux
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

ok()   { echo -e "  ${GREEN}✓${NC} $1"; }
warn() { echo -e "  ${YELLOW}~${NC} $1 (optional)"; }
fail() { echo -e "  ${RED}✗${NC} $1"; }
info() { echo -e "  ${CYAN}→${NC} $1"; }
section() { echo -e "\n${BOLD}━━━ $1 ━━━${NC}"; }

export PATH="$PATH:$HOME/go/bin:/root/go/bin:/home/kali/go/bin:/usr/local/bin"

section "Python Dependencies"
pip3 install flask flask-cors requests -q --break-system-packages 2>/dev/null && ok "Python deps" || \
pip3 install flask flask-cors requests -q 2>/dev/null && ok "Python deps" || fail "pip3 install failed"

section "Go Tools (ProjectDiscovery + others)"
if ! command -v go &>/dev/null; then
    warn "Go not found — install from https://go.dev/dl/ then re-run install.sh"
else
    info "Go: $(go version | cut -d' ' -f3)"
    install_go() {
        local n=$1 p=$2
        command -v "$n" &>/dev/null && { ok "$n"; return; }
        info "Installing $n..."
        go install "$p" &>/dev/null 2>&1 && ok "$n" || warn "$n"
    }
    install_go subfinder     "github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
    install_go httpx         "github.com/projectdiscovery/httpx/cmd/httpx@latest"
    install_go naabu         "github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"
    install_go katana        "github.com/projectdiscovery/katana/cmd/katana@latest"
    install_go nuclei        "github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"
    install_go dnsx          "github.com/projectdiscovery/dnsx/cmd/dnsx@latest"
    install_go alterx        "github.com/projectdiscovery/alterx/cmd/alterx@latest"
    install_go tlsx          "github.com/projectdiscovery/tlsx/cmd/tlsx@latest"
    install_go cdncheck      "github.com/projectdiscovery/cdncheck/cmd/cdncheck@latest"
    install_go asnmap        "github.com/projectdiscovery/asnmap/cmd/asnmap@latest"
    install_go uncover       "github.com/projectdiscovery/uncover/cmd/uncover@latest"
    install_go "interactsh-client" "github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest"
    install_go notify        "github.com/projectdiscovery/notify/cmd/notify@latest"
    install_go shuffledns    "github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest"
    install_go dalfox        "github.com/hahwul/dalfox/v2@latest"
    install_go gau           "github.com/lc/gau/v2/cmd/gau@latest"
    install_go waybackurls   "github.com/tomnomnom/waybackurls@latest"
    install_go anew          "github.com/tomnomnom/anew@latest"
    install_go qsreplace     "github.com/tomnomnom/qsreplace@latest"
    install_go gf            "github.com/tomnomnom/gf@latest"
    install_go assetfinder   "github.com/tomnomnom/assetfinder@latest"
    install_go gospider      "github.com/jaeles-project/gospider@latest"
    install_go hakrawler     "github.com/hakluke/hakrawler@latest"
    install_go subjs         "github.com/lc/subjs@latest"
    install_go gauplus       "github.com/bp0lr/gauplus@latest"
    install_go byp4xx        "github.com/lobuhi/byp4xx@latest"
    install_go crlfuzz       "github.com/dwisiswant0/crlfuzz/cmd/crlfuzz@latest"
    install_go ffuf          "github.com/ffuf/ffuf/v2@latest"
    install_go gobuster      "github.com/OJ/gobuster/v3@latest"
fi

section "Binary Downloads"
DL_DIR="/usr/local/bin"

dl_tar() {
    local n=$1 url=$2
    command -v "$n" &>/dev/null && { ok "$n"; return; }
    info "Downloading $n..."
    curl -fsSL "$url" -o /tmp/dl_$n.tar.gz 2>/dev/null \
        && tar -xzf /tmp/dl_$n.tar.gz -C /tmp "$n" 2>/dev/null \
        && sudo mv "/tmp/$n" "$DL_DIR/" && sudo chmod +x "$DL_DIR/$n" && ok "$n" \
        || warn "$n (download failed)"
    rm -f /tmp/dl_$n.tar.gz 2>/dev/null
}

dl_zip() {
    local n=$1 url=$2
    command -v "$n" &>/dev/null && { ok "$n"; return; }
    info "Downloading $n..."
    curl -fsSL "$url" -o /tmp/dl_$n.zip 2>/dev/null \
        && unzip -q -o /tmp/dl_$n.zip -d /tmp/dl_$n 2>/dev/null \
        && found=$(find /tmp/dl_$n -type f -name "$n" 2>/dev/null | head -1) \
        && [ -n "$found" ] \
        && sudo mv "$found" "$DL_DIR/$n" && sudo chmod +x "$DL_DIR/$n" && ok "$n" \
        || warn "$n (download failed)"
    rm -rf /tmp/dl_$n /tmp/dl_$n.zip 2>/dev/null
}

dl_tar "kr" "https://github.com/assetnote/kiterunner/releases/latest/download/kr-linux-amd64.tar.gz"
dl_zip "findomain" "https://github.com/findomain/findomain/releases/latest/download/findomain-linux.zip"

# Kiterunner routes
if command -v kr &>/dev/null; then
    KR_WL="$HOME/Desktop/recon/kiterunner/routes-large.kite"
    mkdir -p "$(dirname $KR_WL)"
    if [ ! -f "$KR_WL" ]; then
        info "Downloading kiterunner routes wordlist..."
        curl -fsSL "https://wordlists-cdn.assetnote.io/data/kiterunner/routes-large.kite.tar.gz" \
            -o /tmp/routes.tar.gz 2>/dev/null \
            && tar -xzf /tmp/routes.tar.gz -C "$(dirname $KR_WL)/" 2>/dev/null \
            && rm -f /tmp/routes.tar.gz && ok "routes-large.kite" || warn "kiterunner routes"
    else
        ok "kiterunner routes"
    fi
fi

# rustscan
if ! command -v rustscan &>/dev/null; then
    apt-get install -y rustscan -qq 2>/dev/null && ok "rustscan" || {
        curl -fsSL "https://github.com/RustScan/RustScan/releases/latest/download/rustscan_2.3.0_amd64.deb" \
            -o /tmp/rustscan.deb 2>/dev/null \
            && sudo dpkg -i /tmp/rustscan.deb 2>/dev/null && ok "rustscan" || warn "rustscan"
        rm -f /tmp/rustscan.deb
    }
else
    ok "rustscan"
fi

section "Apt Tools"
for pkg in nmap masscan nikto wfuzz whatweb wpscan sqlmap commix dirsearch; do
    command -v "$pkg" &>/dev/null && ok "$pkg" || {
        apt-get install -y "$pkg" -qq 2>/dev/null && ok "$pkg" || warn "$pkg"
    }
done

section "Pip Tools"
for pkg in paramspider ssrfuzz; do
    command -v "$pkg" &>/dev/null && ok "$pkg" || {
        pip3 install "$pkg" -q --break-system-packages 2>/dev/null && ok "$pkg" || warn "$pkg"
    }
done

section "SecLists"
SECLISTS="$HOME/Desktop/recon/SecLists"
if [ -d "$SECLISTS" ]; then
    ok "SecLists at $SECLISTS"
else
    info "Cloning SecLists (large download, ~500MB)..."
    mkdir -p "$HOME/Desktop/recon"
    git clone --depth=1 https://github.com/danielmiessler/SecLists.git "$SECLISTS" -q 2>/dev/null \
        && ok "SecLists" || warn "SecLists (clone manually: git clone --depth=1 https://github.com/danielmiessler/SecLists.git $SECLISTS)"
fi

section "LinkFinder"
LF_DIR="$HOME/Desktop/recon/LinkFinder"
[ -d "$LF_DIR" ] && ok "LinkFinder" || {
    git clone https://github.com/GerbenJavado/LinkFinder.git "$LF_DIR" -q 2>/dev/null \
        && pip3 install -r "$LF_DIR/requirements.txt" -q --break-system-packages 2>/dev/null \
        && ok "LinkFinder" || warn "LinkFinder"
}

section "Nuclei Templates"
command -v nuclei &>/dev/null && {
    nuclei -update-templates -silent 2>/dev/null && ok "nuclei templates" || warn "nuclei templates"
}

section "Permissions"
command -v naabu &>/dev/null && {
    sudo setcap cap_net_raw+ep "$(which naabu)" 2>/dev/null && ok "naabu raw socket" || warn "naabu setcap"
}

section "Final Check"
CRITICAL=(subfinder httpx naabu nuclei katana dnsx gau waybackurls anew ffuf)
OPTIONAL=(findomain kr assetfinder gospider hakrawler subjs gauplus alterx dalfox
          crlfuzz byp4xx rustscan masscan nmap nikto wfuzz whatweb wpscan
          sqlmap commix interactsh-client)

echo -e "\n${BOLD}Critical:${NC}"
FAIL=0
for t in "${CRITICAL[@]}"; do
    command -v "$t" &>/dev/null && ok "$t" || { fail "$t"; FAIL=$((FAIL+1)); }
done

echo -e "\n${BOLD}Optional:${NC}"
for t in "${OPTIONAL[@]}"; do
    command -v "$t" &>/dev/null && ok "$t" || warn "$t"
done

echo ""
[ "$FAIL" -eq 0 ] \
    && echo -e "${GREEN}${BOLD}All critical tools installed! Run ./start.sh${NC}" \
    || echo -e "${YELLOW}${BOLD}$FAIL critical tool(s) missing — ensure Go is in PATH and re-run${NC}"
echo ""
