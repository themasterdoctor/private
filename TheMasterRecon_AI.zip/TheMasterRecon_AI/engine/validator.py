"""
TheMasterRecon Finding Validator
Re-verifies findings with actual HTTP requests — like xbow.ai's verification engine.
Eliminates false positives before they're shown to the user.
"""
import re, time, logging, ssl, socket
from typing import Optional, Tuple, List
import urllib.request, urllib.parse

log = logging.getLogger("elite.validator")

def _http(url: str, method: str = "GET", data: bytes = None,
          headers: dict = None, timeout: int = 8) -> Tuple[int, str, dict]:
    """Make an HTTP request, return (status_code, body_sample, resp_headers)."""
    try:
        hdrs = {"User-Agent": "Mozilla/5.0 (compatible; TMR-Validator/1.0)"}
        hdrs.update(headers or {})
        req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
            body = r.read(4096).decode("utf-8", "ignore")
            return r.status, body, dict(r.headers)
    except urllib.error.HTTPError as e:
        try: body = e.read(2048).decode("utf-8", "ignore")
        except: body = ""
        return e.code, body, {}
    except Exception as e:
        return 0, str(e)[:100], {}


def validate(finding: dict, timeout: int = 8) -> Tuple[bool, str]:
    """
    Re-verify a finding with a live HTTP probe.
    Returns (is_confirmed, reason).
    """
    bug  = finding.get("bug", "").lower()
    url  = finding.get("url", "")
    poc  = finding.get("poc", "")
    payload = finding.get("payload", "")

    if not url:
        return True, "no URL to verify — accepted as-is"

    try:
        if bug == "misconfig":
            return _validate_misconfig(finding, timeout)
        elif bug in ("xss", "stored_xss", "bxss"):
            return _validate_xss(finding, timeout)
        elif bug in ("sqli", "sqli_blind", "sqli_time"):
            return _validate_sqli(finding, timeout)
        elif bug in ("ssrf", "ssrf_cloud", "ssrf_aws"):
            return _validate_ssrf(finding, timeout)
        elif bug in ("cors", "cors_deep", "cors_bypass"):
            return _validate_cors(finding, timeout)
        elif bug in ("redirect", "open_redirect"):
            return _validate_redirect(finding, timeout)
        elif bug == "lfi":
            return _validate_lfi(finding, timeout)
        elif bug in ("takeover", "takeover_deep"):
            return _validate_takeover(finding, timeout)
        elif bug == "actuator":
            return _validate_actuator(finding, timeout)
        elif bug == "host_header":
            return _validate_host_header(finding, timeout)
        else:
            # Generic: check URL still returns non-404
            status, body, hdrs = _http(url, timeout=timeout)
            return (status < 400, f"HTTP {status} — generic check passed" if status < 400 else f"HTTP {status}")
    except Exception as e:
        return True, f"validation error: {e} — accepted as-is"


def _validate_misconfig(finding: dict, timeout: int) -> Tuple[bool, str]:
    """Verify missing security headers."""
    url    = finding.get("url", "")
    status, body, hdrs = _http(url, timeout=timeout)
    if status == 0:
        return True, "unreachable — accepted as-is"
    hdrs_lower = {k.lower(): v for k,v in hdrs.items()}
    missing = []
    for h in ["x-frame-options","x-content-type-options","content-security-policy"]:
        if h not in hdrs_lower:
            missing.append(h)
    if missing:
        return True, f"confirmed: {len(missing)} headers missing"
    return False, "headers now present — likely FP or fixed"


def _validate_xss(finding: dict, timeout: int) -> Tuple[bool, str]:
    """Verify XSS by checking if payload is reflected unescaped."""
    url     = finding.get("url", "")
    payload = finding.get("payload", "") or finding.get("value", "")
    poc     = finding.get("poc", "")

    # Extract the injected parameter from URL or PoC
    test_url = poc.split(" ")[0] if poc.startswith("http") else url
    if not test_url:
        return True, "no test URL"

    status, body, hdrs = _http(test_url, timeout=timeout)
    if status == 0:
        return True, "unreachable"

    # Check if dangerous chars are unescaped in response
    danger_chars = ["<script", "onerror=", "onload=", "alert(", "javascript:"]
    for ch in danger_chars:
        if ch.lower() in body.lower():
            return True, f"XSS confirmed: '{ch}' reflected unescaped in response"

    # Check if just the payload marker is reflected (even escaped)
    if payload and payload[:10].lower() in body.lower():
        if "&lt;" in body or "&#" in body:
            return False, f"payload reflected but HTML-escaped — likely FP"
        return True, "payload reflected in response"

    return True, "could not reverify — accepted as-is"


def _validate_sqli(finding: dict, timeout: int) -> Tuple[bool, str]:
    """Verify SQLi by checking for error signatures or timing."""
    url  = finding.get("url", "")
    poc  = finding.get("poc", "")

    test_url = poc.split(" ")[0] if poc.startswith("http") else url
    if not test_url:
        return True, "no test URL"

    status, body, hdrs = _http(test_url, timeout=timeout)
    if status == 0:
        return True, "unreachable"

    # Check for SQL error messages
    sql_errors = [
        "sql syntax", "mysql_fetch", "ora-", "pg_query", "sqlstate",
        "sqlite_", "microsoft sql", "unclosed quotation", "quoted string",
        "syntax error", "invalid query", "mysql error", "division by zero"
    ]
    body_lower = body.lower()
    for err in sql_errors:
        if err in body_lower:
            return True, f"SQLi confirmed: SQL error '{err}' in response"

    # Time-based: check if sleep payload was in PoC
    if "sleep" in poc.lower() or "waitfor" in poc.lower():
        start = time.time()
        _http(test_url, timeout=10)
        elapsed = time.time() - start
        if elapsed >= 4.0:
            return True, f"SQLi confirmed: {elapsed:.1f}s response delay"

    return True, "SQLi — accepted as-is (error-based check inconclusive)"


def _validate_ssrf(finding: dict, timeout: int) -> Tuple[bool, str]:
    """SSRF validation — check if metadata service returned in response."""
    url  = finding.get("url", "")
    poc  = finding.get("poc", "")
    body_preview = finding.get("response_preview", "")

    if body_preview:
        # Check if metadata was in the original response
        meta_signals = ["ami-id","instance-id","iam/security-credentials",
                        "computeMetadata","169.254","meta-data/"]
        for sig in meta_signals:
            if sig in body_preview:
                return True, f"SSRF confirmed: metadata signal '{sig}' in response"

    # Re-check for OOB indicator
    if "oob" in poc.lower() or "interact.sh" in poc.lower():
        return True, "SSRF with OOB — accepted (cannot re-verify OOB callback)"

    return True, "SSRF — accepted as-is"


def _validate_cors(finding: dict, timeout: int) -> Tuple[bool, str]:
    """Verify CORS misconfiguration."""
    url = finding.get("url", "")
    if not url:
        return True, "no URL"

    # Send request with attacker Origin
    status, body, hdrs = _http(url, headers={"Origin": "https://evil.attacker.com"}, timeout=timeout)
    acao = hdrs.get("Access-Control-Allow-Origin","") or hdrs.get("access-control-allow-origin","")
    acac = hdrs.get("Access-Control-Allow-Credentials","") or hdrs.get("access-control-allow-credentials","")

    if acao in ("*", "https://evil.attacker.com"):
        if acac and "true" in acac.lower():
            return True, f"CORS confirmed: ACAO={acao} ACAC={acac} — critical!"
        return True, f"CORS confirmed: ACAO={acao}"
    if acao and acao != "null":
        return True, f"CORS: reflected origin {acao}"
    return False, f"CORS not confirmed: ACAO='{acao}'"


def _validate_redirect(finding: dict, timeout: int) -> Tuple[bool, str]:
    """Verify open redirect."""
    poc = finding.get("poc","")
    url = finding.get("url","")

    test_url = poc.split(" ")[0] if poc.startswith("http") else url
    if not test_url or "evil" not in test_url.lower():
        return True, "redirect — accepted as-is"

    try:
        req = urllib.request.Request(test_url,
            headers={"User-Agent": "TMR-Validator/1.0"})
        ctx = ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        # Don't follow redirects — check Location header
        opener = urllib.request.build_opener(urllib.request.HTTPRedirectHandler())
        with opener.open(req, timeout=timeout) as r:
            return False, "redirect followed but landed on same origin"
    except urllib.error.HTTPError as e:
        loc = e.headers.get("Location","")
        if loc and ("evil" in loc.lower() or "attacker" in loc.lower()):
            return True, f"Redirect confirmed: Location: {loc}"
    except Exception:
        pass
    return True, "redirect — accepted as-is"


def _validate_lfi(finding: dict, timeout: int) -> Tuple[bool, str]:
    """Verify LFI by checking for /etc/passwd content."""
    url = finding.get("url","")
    poc = finding.get("poc","")

    test_url = poc.split(" ")[0] if poc.startswith("http") else url
    status, body, hdrs = _http(test_url, timeout=timeout)
    if "root:x:0:0" in body or "root:/root" in body:
        return True, "LFI confirmed: /etc/passwd content in response"
    if "[boot loader]" in body.lower() or "windows\\system32" in body.lower():
        return True, "LFI confirmed: Windows file content in response"
    if "php" in poc.lower() and "base64" in poc.lower():
        import base64
        # Try to decode base64 in response
        b64_match = re.search(r'[A-Za-z0-9+/]{40,}={0,2}', body)
        if b64_match:
            try:
                decoded = base64.b64decode(b64_match.group()).decode('utf-8','ignore')
                if "<?php" in decoded or "root:x:" in decoded:
                    return True, "LFI confirmed: PHP source or /etc/passwd in base64 response"
            except Exception:
                pass
    return True, "LFI — accepted as-is"


def _validate_takeover(finding: dict, timeout: int) -> Tuple[bool, str]:
    """Verify subdomain takeover."""
    url = finding.get("url","")
    status, body, hdrs = _http(url, timeout=timeout)
    takeover_sigs = [
        "there isn't a github pages site here",
        "herokucdn.com/error-pages/no-such-app",
        "fastly error: unknown domain",
        "this domain is for sale",
        "this shopify store is unavailable",
        "noSuchBucket", "nosuchbucket",
        "unregistered domain",
    ]
    body_lower = body.lower()
    for sig in takeover_sigs:
        if sig.lower() in body_lower:
            return True, f"Takeover confirmed: '{sig}' in response"
    return True, "Takeover — accepted as-is (could not verify takeover signature)"


def _validate_actuator(finding: dict, timeout: int) -> Tuple[bool, str]:
    """Verify Spring Actuator exposure."""
    url = finding.get("url","")
    status, body, hdrs = _http(url, timeout=timeout)
    if status in (200,) and ('"_links"' in body or '"beans"' in body or
                              '"env"' in body or '"mappings"' in body):
        return True, f"Actuator confirmed: HTTP {status} with actuator data"
    return status < 400, f"HTTP {status}"


def _validate_host_header(finding: dict, timeout: int) -> Tuple[bool, str]:
    """Verify host header injection."""
    url = finding.get("url","")
    status, body, hdrs = _http(url,
        headers={"Host": "evil.attacker.com", "X-Forwarded-Host": "evil.attacker.com"},
        timeout=timeout)
    if "evil.attacker.com" in body:
        return True, "Host header injection confirmed: attacker domain reflected in response"
    return True, "Host header — accepted as-is"


def filter_fps(findings: list, min_confidence: int = 30) -> list:
    """
    Filter a list of findings, removing obvious false positives.
    Runs quick_validate heuristics + optional HTTP reverification.
    """
    result = []
    for f in findings:
        conf = f.get("confidence", 50)
        if conf < min_confidence:
            log.debug(f"[validator] FP filtered (low conf {conf}%): {f.get('bug','')} @ {f.get('url','')[:50]}")
            continue
        if f.get("likely_fp") and conf < 40:
            log.debug(f"[validator] FP filtered (flagged): {f.get('bug','')} @ {f.get('url','')[:50]}")
            continue
        result.append(f)
    return result
