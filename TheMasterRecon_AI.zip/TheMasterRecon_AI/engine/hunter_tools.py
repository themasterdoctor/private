"""
TheMasterRecon AI — Hunter Tools
https://github.com/atxiii/small-tools-for-hunters
SAN, AbuseIP, Favicon hash, API key finder, PDF URLs, Combos, Reverse WHOIS.
"""
import re, ssl, json, logging, hashlib, urllib.request, urllib.parse, socket
from typing import List, Dict, Optional

log = logging.getLogger("elite.hunter_tools")

def _get(url, timeout=10):
    try:
        ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
        req = urllib.request.Request(url, headers={"User-Agent":"Mozilla/5.0 (TheMasterRecon-AI/2.0)","Accept":"application/json,*/*"})
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
            return r.status, r.read()
    except Exception as e:
        log.debug(f"[hunter] GET {url}: {e}"); return None

def get_san_domains(domain: str) -> List[str]:
    """Extract subdomains from SSL SANs + crt.sh."""
    subs = set()
    for target in [domain, f"www.{domain}"]:
        try:
            import ssl as ssl_mod
            ctx = ssl_mod.create_default_context()
            with socket.create_connection((target, 443), timeout=8) as sock:
                with ctx.wrap_socket(sock, server_hostname=target) as ssock:
                    cert = ssock.getpeercert()
                    for san_type, san_val in cert.get("subjectAltName", []):
                        if san_type == "DNS":
                            v = san_val.lstrip("*.").lower()
                            if domain in v: subs.add(v)
        except Exception as e: log.debug(f"[san] {target}: {e}")
    try:
        result = _get(f"https://crt.sh/?q=%.{domain}&output=json", timeout=15)
        if result and result[0] == 200:
            for cert in json.loads(result[1].decode())[:300]:
                for name in cert.get("name_value","").split("\n"):
                    v = name.strip().lstrip("*.").lower()
                    if v and domain in v: subs.add(v)
    except Exception as e: log.debug(f"[san] crt.sh: {e}")
    return sorted(subs)

def _mmh3(data: bytes) -> int:
    l=len(data); c1=0xcc9e2d51; c2=0x1b873593; h1=0
    for i in range(0, l-3, 4):
        k=int.from_bytes(data[i:i+4],'little'); k=(k*c1)&0xFFFFFFFF
        k=((k<<15)|(k>>17))&0xFFFFFFFF; k=(k*c2)&0xFFFFFFFF
        h1^=k; h1=((h1<<13)|(h1>>19))&0xFFFFFFFF; h1=((h1*5)+0xe6546b64)&0xFFFFFFFF
    t=l&3
    if t:
        k=int.from_bytes(data[l-t:]+b'\x00'*(4-t),'little'); k=(k*c1)&0xFFFFFFFF
        k=((k<<15)|(k>>17))&0xFFFFFFFF; k=(k*c2)&0xFFFFFFFF; h1^=k
    h1^=l; h1^=h1>>16; h1=(h1*0x85ebca6b)&0xFFFFFFFF
    h1^=h1>>13; h1=(h1*0xc2b2ae35)&0xFFFFFFFF; h1^=h1>>16
    return h1

def get_favicon_hash(url: str) -> Dict:
    """Compute favicon hash for Shodan/FOFA."""
    import base64
    for path in ["/favicon.ico","/favicon.png","/apple-touch-icon.png"]:
        try:
            r = _get(url.rstrip("/")+path, timeout=8)
            if not r or r[0]!=200 or not r[1] or len(r[1])<10: continue
            b64 = base64.encodebytes(r[1]).decode()
            fhash = _mmh3(b64.encode())
            signed = fhash if fhash < 2**31 else fhash - 2**32
            return {"url":url+path,"hash":fhash,"hash_signed":signed,
                    "shodan_query":f"http.favicon.hash:{signed}",
                    "fofa_query":f'icon_hash="{signed}"',
                    "md5":hashlib.md5(r[1]).hexdigest()}
        except: pass
    return {"error":"No favicon","url":url}

AKEYF_PATTERNS = [
    (r'AIza[0-9A-Za-z\-_]{35}',                    "Google API Key",    "critical"),
    (r'AKIA[0-9A-Z]{16}',                           "AWS Access Key ID", "critical"),
    (r'sk-[a-zA-Z0-9]{20,50}',                     "OpenAI API Key",    "critical"),
    (r'sk-proj-[a-zA-Z0-9]{20,80}',                "OpenAI Proj Key",   "critical"),
    (r'ghp_[a-zA-Z0-9]{36}',                       "GitHub Token",      "critical"),
    (r'xox[baprs]-[0-9a-zA-Z\-]{10,}',            "Slack Token",       "critical"),
    (r'sk_live_[a-zA-Z0-9]{24,}',                  "Stripe Live Key",   "critical"),
    (r'SG\.[a-zA-Z0-9\._\-]{22}\.[a-zA-Z0-9\._\-]{43}', "SendGrid",  "critical"),
    (r'-----BEGIN (?:RSA )?PRIVATE KEY-----',       "Private Key",       "critical"),
    (r'mongodb(?:\+srv)?://[^\s"\'`]{10,}',         "MongoDB URI",       "critical"),
    (r'postgres://[^\s"\'`]{10,}',                  "PostgreSQL URI",    "critical"),
    (r'(?:api[_\-]?key|secret|access_token)[^"\'=\n]{0,20}[=:]\s*["\']([a-zA-Z0-9_\-\.]{20,})["\']', "API Key", "high"),
    (r'"apiKey":\s*"AIza[0-9A-Za-z\-_]{35}"',      "Firebase Key",      "high"),
    (r'jwt_secret\s*[:=]\s*["\']([^"\']{8,})["\']',"JWT Secret",        "critical"),
]

def akeyf_scan(content: str, source_url="") -> List[Dict]:
    """API Key Finder - akeyf from small-tools-for-hunters."""
    findings = []
    for pat, ktype, sev in AKEYF_PATTERNS:
        for m in re.finditer(pat, content, re.I|re.M):
            val = (m.group(1) if m.lastindex else m.group(0)).strip("\"'`")
            if any(x in val.lower() for x in ['example','xxxx','your_','placeholder','changeme','test123']): continue
            if len(val) < 8: continue
            findings.append({"type":ktype,"severity":sev,"value":val[:80],"source":source_url,
                            "line":content[:m.start()].count('\n')+1,
                            "context":content[max(0,m.start()-30):m.end()+40].strip()[:100]})
    return findings[:50]

def extract_urls_from_pdf(pdf_url: str) -> List[str]:
    """Extract URLs from PDF — extract-url-pdf tool."""
    result = _get(pdf_url, timeout=20)
    if not result or result[0] != 200: return []
    text = result[1].decode("latin-1", errors="ignore")
    found = re.findall(r'https?://[^\s\x00-\x1f\x7f-\xff"\'<>]{5,200}', text)
    return sorted(set(u.rstrip('.,;:)>]}') for u in found if len(u)>10))

def generate_combos(words: List[str], mode="all", seps=None, suffixes=None) -> List[str]:
    """Wordlist combo maker."""
    if seps is None: seps = ["","_","-","."]
    if suffixes is None: suffixes = ["","api","dev","test","staging","prod","app","admin","v1","v2","beta","old"]
    combos = set()
    for w in words:
        w = w.lower().strip()
        if not w: continue
        combos.add(w)
        if mode in ("all","suffix"):
            for s in suffixes:
                if s:
                    for sep in seps:
                        combos.add(f"{w}{sep}{s}"); combos.add(f"{s}{sep}{w}")
        if mode in ("all","combo") and len(words)>1:
            for o in words:
                o=o.lower().strip()
                if o!=w:
                    for sep in seps: combos.add(f"{w}{sep}{o}")
    return sorted(combos)[:5000]

def reverse_whois(query: str) -> Dict:
    """Reverse WHOIS / inetnum lookup."""
    results = {"query":query,"networks":[],"emails":[]}
    try:
        r = _get(f"https://api.bgpview.io/search?query_term={urllib.parse.quote(query)}", timeout=10)
        if r and r[0]==200:
            for asn in json.loads(r[1]).get("data",{}).get("asns",[])[:5]:
                results["networks"].append({"asn":asn.get("asn"),"name":asn.get("name",""),"country":asn.get("country_code","")})
    except: pass
    return results

def abuseip_subdomains(domain: str, api_key="") -> List[str]:
    """AbuseIP subdomain discovery."""
    subs = set()
    try:
        r = _get(f"https://www.abuseipdb.com/check-block/{domain}/24?page=1", timeout=10)
        if r and r[0]==200:
            found = re.findall(rf'([\w\-]+\.{re.escape(domain)})', r[1].decode("utf-8","ignore"), re.I)
            subs.update(f.lower() for f in found)
    except: pass
    return sorted(subs)
