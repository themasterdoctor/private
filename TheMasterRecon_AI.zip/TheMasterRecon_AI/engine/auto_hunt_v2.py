"""
engine/auto_hunt_v2.py — AUTO-HUNT ENGINE v2

Production-grade autonomous bug bounty engine.
Wires existing TMR infrastructure into a continuous hunt loop.

Architecture:
  INGEST → QUEUE → WORKERS → TOOL EXECUTION → PARSING → STORAGE → API

HARD RULES:
  - No blocking in API routes
  - All I/O runs in worker threads
  - All results read from DB
  - Tools validated before use
  - No fake outputs
  - No auto-submission
"""

import json
import logging
import os
import queue
import re
import subprocess
import tempfile
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

log = logging.getLogger("elite.auto_hunt_v2")

# ── Constants ─────────────────────────────────────────────────────────────────
MAX_WORKERS       = int(os.environ.get("AH_MAX_WORKERS", "3"))
JOB_TIMEOUT_S     = int(os.environ.get("AH_JOB_TIMEOUT", "3600"))   # 1hr per domain
TOOL_TIMEOUT_S    = int(os.environ.get("AH_TOOL_TIMEOUT", "300"))    # 5min per tool
NUCLEI_RATE_LIMIT = int(os.environ.get("AH_NUCLEI_RATE", "100"))
RESCAN_INTERVAL_H = float(os.environ.get("AH_RESCAN_H", "24"))       # re-scan every 24h

_PD_DIRS = [
    os.path.expanduser("~/go/bin"),
    "/home/kali/go/bin", "/root/go/bin",
    "/usr/local/bin", "/usr/bin",
]


# ── Job dataclass ─────────────────────────────────────────────────────────────

@dataclass
class HuntJob:
    domain:     str
    job_id:     str
    priority:   int   = 5          # 1 (highest) – 10 (lowest)
    bugs:       List[str] = field(default_factory=list)
    phases:     List[str] = field(default_factory=lambda: [
        "surface", "endpoints", "intelligence", "vuln"
    ])
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    done_at:    Optional[float] = None
    status:     str   = "pending"  # pending|running|done|error|timeout
    error:      Optional[str] = None
    results:    Dict  = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return {
            "domain":     self.domain,
            "job_id":     self.job_id,
            "priority":   self.priority,
            "bugs":       self.bugs,
            "phases":     self.phases,
            "status":     self.status,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "done_at":    self.done_at,
            "error":      self.error,
            "elapsed_s":  round((self.done_at or time.time()) - (self.started_at or self.created_at), 1),
        }


# ── Tool execution layer ──────────────────────────────────────────────────────

def _which(name: str) -> Optional[str]:
    """Resolve binary path — PD tools must come from Go bin, not venv."""
    for d in _PD_DIRS:
        fp = os.path.join(d, name)
        if os.path.isfile(fp) and os.access(fp, os.X_OK):
            return fp
    import shutil
    p = shutil.which(name)
    if p and any(s in p for s in ("venv", "site-packages", ".local/lib")):
        return None
    return p


def _run_tool(cmd: List[str], timeout: int = TOOL_TIMEOUT_S,
              stdin_data: Optional[str] = None) -> Dict:
    """
    Execute a tool subprocess with hard timeout.
    Returns: {ok, returncode, stdout, stderr, elapsed_s}
    """
    t0 = time.monotonic()
    try:
        inp = stdin_data.encode() if stdin_data else None
        r   = subprocess.run(
            cmd, input=inp, capture_output=True,
            timeout=timeout
        )
        ela = round(time.monotonic() - t0, 2)
        return {
            "ok":         r.returncode in (0, 1),
            "returncode": r.returncode,
            "stdout":     r.stdout.decode(errors="replace"),
            "stderr":     r.stderr.decode(errors="replace"),
            "elapsed_s":  ela,
            "cmd":        " ".join(cmd[:5]),
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "returncode": -1, "stdout": "",
                "stderr": f"timeout after {timeout}s", "elapsed_s": timeout,
                "cmd": " ".join(cmd[:5])}
    except Exception as e:
        return {"ok": False, "returncode": -2, "stdout": "",
                "stderr": str(e), "elapsed_s": round(time.monotonic()-t0, 2),
                "cmd": " ".join(cmd[:5])}


def _tmp_file(lines: List[str], suffix: str = ".txt") -> str:
    """Write lines to a temp file and return its path."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=suffix,
                                     delete=False) as f:
        f.write("\n".join(lines))
        return f.name


def _rm(path: str):
    try: os.unlink(path)
    except Exception: pass


# ── Phase 1: Surface Discovery ────────────────────────────────────────────────

class SurfacePhase:
    """Subdomain enumeration → live host probing → port scan."""

    def run(self, domain: str, db, emit: Callable) -> Dict:
        subs:   Set[str] = set()
        live:   List[str] = []
        ports:  List[Dict] = []

        emit({"phase": "surface", "step": "subfinder", "status": "start"})
        subs.update(self._subfinder(domain))
        emit({"phase": "surface", "step": "subfinder",
              "status": "done", "count": len(subs)})

        subs.update(self._passive_dns(domain))

        # Always include root
        subs.add(domain)
        subs.add(f"www.{domain}")

        emit({"phase": "surface", "step": "httpx", "status": "start",
              "targets": len(subs)})
        live = self._httpx(list(subs))
        emit({"phase": "surface", "step": "httpx",
              "status": "done", "live": len(live)})

        if live:
            emit({"phase": "surface", "step": "naabu", "status": "start"})
            ports = self._naabu(live[:50])  # cap port scan targets
            emit({"phase": "surface", "step": "naabu",
                  "status": "done", "open_ports": len(ports)})

        # Persist
        for s in subs:
            try: db.add_sub(domain, s)
            except Exception: pass
        for h in live:
            try: db.add_active(domain, h, 200, "", [])
            except Exception: pass

        log.info(f"[hunt] surface domain={domain} subs={len(subs)}"
                 f" live={len(live)} ports={len(ports)}")
        return {"subs": list(subs), "live": live, "ports": ports}

    def _subfinder(self, domain: str) -> List[str]:
        binary = _which("subfinder")
        if not binary: return []
        r = _run_tool([binary, "-d", domain, "-silent", "-timeout", "60"], timeout=120)
        if not r["ok"]: return []
        return [l.strip() for l in r["stdout"].splitlines() if l.strip()]

    def _passive_dns(self, domain: str) -> List[str]:
        """crt.sh certificate transparency — no binary needed."""
        subs: List[str] = []
        try:
            import urllib.request, urllib.error, json as _j, ssl as _ssl
            ctx = _ssl.create_default_context(); ctx.check_hostname = False
            ctx.verify_mode = _ssl.CERT_NONE
            url = f"https://crt.sh/?q=%.{domain}&output=json&limit=500"
            with urllib.request.urlopen(url, timeout=15, context=ctx) as resp:
                data = _j.loads(resp.read())
                for entry in data:
                    name = entry.get("name_value","")
                    for n in name.split("\n"):
                        n = n.strip().lstrip("*.")
                        if n and domain in n and " " not in n:
                            subs.append(n)
        except Exception:
            pass
        return subs

    def _httpx(self, hosts: List[str]) -> List[str]:
        binary = _which("httpx")
        if not binary: return []
        urls = [f"https://{h}" if not h.startswith("http") else h
                for h in hosts]
        tmp = _tmp_file(urls)
        r = _run_tool([binary, "-l", tmp, "-silent", "-no-color",
                       "-timeout", "8", "-threads", "50"], timeout=180)
        _rm(tmp)
        if not r["ok"]: return []
        return [l.strip() for l in r["stdout"].splitlines() if l.strip()]

    def _naabu(self, live_hosts: List[str]) -> List[Dict]:
        binary = _which("naabu")
        if not binary: return []
        hosts_clean = [re.sub(r"^https?://","",h).split("/")[0] for h in live_hosts]
        tmp = _tmp_file(hosts_clean)
        r = _run_tool([binary, "-l", tmp, "-silent", "-top-ports", "100",
                       "-timeout", "5"], timeout=120)
        _rm(tmp)
        if not r["ok"]: return []
        results = []
        for line in r["stdout"].splitlines():
            line = line.strip()
            if ":" in line:
                parts = line.split(":")
                results.append({"host": parts[0], "port": int(parts[1])
                                 if parts[1].isdigit() else 0})
        return results


# ── Phase 2: Endpoint Discovery ───────────────────────────────────────────────

class EndpointPhase:
    """Web crawl + historical URL collection + parameter extraction."""

    def run(self, domain: str, live_hosts: List[str], db, emit: Callable) -> Dict:
        endpoints: Set[str] = set()

        emit({"phase": "endpoints", "step": "katana", "status": "start"})
        endpoints.update(self._katana(live_hosts[:20]))
        emit({"phase": "endpoints", "step": "katana",
              "status": "done", "count": len(endpoints)})

        emit({"phase": "endpoints", "step": "gau", "status": "start"})
        endpoints.update(self._gau(domain))
        emit({"phase": "endpoints", "step": "gau",
              "status": "done", "count": len(endpoints)})

        emit({"phase": "endpoints", "step": "waybackurls", "status": "start"})
        endpoints.update(self._wayback(domain))
        emit({"phase": "endpoints", "step": "waybackurls",
              "status": "done", "count": len(endpoints)})

        # Persist
        for url in endpoints:
            try: db.add_endpoint(domain, url, source="auto_hunt")
            except Exception: pass

        log.info(f"[hunt] endpoints domain={domain} total={len(endpoints)}")
        return {"endpoints": list(endpoints), "count": len(endpoints)}

    def _katana(self, live_hosts: List[str]) -> List[str]:
        binary = _which("katana")
        if not binary: return []
        urls: List[str] = []
        for host in live_hosts[:10]:
            r = _run_tool([binary, "-u", host, "-d", "3", "-silent",
                           "-timeout", "10", "-no-color",
                           "-jsl", "-kf", "all"], timeout=60)
            if r["ok"]:
                urls.extend(l.strip() for l in r["stdout"].splitlines() if l.strip())
        return urls

    def _gau(self, domain: str) -> List[str]:
        binary = _which("gau")
        if not binary: return []
        r = _run_tool([binary, domain, "--threads", "5",
                       "--timeout", "30"], timeout=90)
        if not r["ok"]: return []
        return [l.strip() for l in r["stdout"].splitlines()
                if l.strip() and domain in l]

    def _wayback(self, domain: str) -> List[str]:
        binary = _which("waybackurls")
        if not binary: return []
        r = _run_tool([binary, domain], timeout=60,
                      stdin_data=f"{domain}\n")
        if not r["ok"]: return []
        return [l.strip() for l in r["stdout"].splitlines()
                if l.strip() and domain in l]


# ── Phase 3: Intelligence Enrichment ─────────────────────────────────────────

class IntelPhase:
    """Tech detection, cloud/provider ID, high-value target classification."""

    # Surface classification — mirrors surface_intel but self-contained
    _SURFACE_PATS = [
        ("payment",  re.compile(r"(payment|billing|invoice|stripe|checkout)", re.I)),
        ("api",      re.compile(r"(/api/|/v\d+/|/rest/|/graphql|\.json$)", re.I)),
        ("auth",     re.compile(r"(login|signin|auth|oauth|sso|token|session)", re.I)),
        ("admin",    re.compile(r"(admin|dashboard|console|panel|manage)", re.I)),
        ("upload",   re.compile(r"(upload|import|file|attachment|media)", re.I)),
        ("graphql",  re.compile(r"(graphql|graphiql|gql)", re.I)),
        ("webhook",  re.compile(r"(webhook|callback|notify|hook)", re.I)),
    ]
    _HIGH_VALUE = {"payment","api","auth","admin","graphql"}

    def run(self, domain: str, endpoints: List[str], db, emit: Callable) -> Dict:
        emit({"phase": "intel", "step": "classify", "status": "start"})

        scored: List[Dict] = []
        for url in endpoints[:5000]:  # cap
            surfaces = [tag for tag, pat in self._SURFACE_PATS if pat.search(url)]
            if not surfaces:
                continue
            score = max(
                10 if "payment" in surfaces else
                9  if any(s in surfaces for s in ["api","auth","admin","graphql"]) else
                7  if any(s in surfaces for s in ["upload","webhook"]) else 5,
                1
            )
            scored.append({
                "url":      url,
                "surfaces": surfaces,
                "score":    score,
                "hv":       any(s in self._HIGH_VALUE for s in surfaces),
            })

        scored.sort(key=lambda x: -x["score"])
        high_value = [t for t in scored if t["hv"]][:200]

        emit({"phase": "intel", "step": "classify", "status": "done",
              "high_value": len(high_value), "total_scored": len(scored)})

        log.info(f"[hunt] intel domain={domain}"
                 f" scored={len(scored)} high_value={len(high_value)}")
        return {"high_value_targets": high_value, "total_scored": len(scored)}


# ── Phase 4: Vulnerability Pipeline ──────────────────────────────────────────

class VulnPhase:
    """Nuclei + custom IDOR/redirect/token checks. No auto-exploit."""

    # Surface → nuclei tag mapping
    _TAGS = {
        "api":     ["api","sqli","ssrf","auth-bypass","idor","exposure"],
        "auth":    ["auth-bypass","default-login","token","session"],
        "admin":   ["panel","auth-bypass","default-login","exposure"],
        "upload":  ["file-upload","ssrf","exposure"],
        "graphql": ["graphql","misconfiguration"],
        "webhook": ["ssrf","exposure"],
        "payment": ["exposure","misconfiguration","idor"],
    }

    def run(self, domain: str, high_value_targets: List[Dict],
            db, emit: Callable) -> List[Dict]:
        findings: List[Dict] = []

        if not high_value_targets:
            emit({"phase": "vuln", "step": "nuclei", "status": "skip",
                  "reason": "no_high_value_targets"})
            return []

        # Group targets by surface → run nuclei per group
        groups: Dict[str, List[str]] = {}
        for t in high_value_targets:
            for surf in t.get("surfaces", []):
                if surf in self._TAGS:
                    groups.setdefault(surf, [])
                    if t["url"] not in groups[surf]:
                        groups[surf].append(t["url"])

        for surf, urls in groups.items():
            urls = urls[:100]  # cap per group
            tags = self._TAGS.get(surf, ["exposure"])
            emit({"phase": "vuln", "step": f"nuclei_{surf}",
                  "status": "start", "targets": len(urls)})
            group_findings = self._nuclei(urls, tags, domain)
            findings.extend(group_findings)
            emit({"phase": "vuln", "step": f"nuclei_{surf}",
                  "status": "done", "findings": len(group_findings)})

        # Custom IDOR candidates
        idor_candidates = self._idor_candidates(high_value_targets)
        if idor_candidates:
            emit({"phase": "vuln", "step": "idor_analysis",
                  "count": len(idor_candidates)})
            findings.extend(idor_candidates)

        # Persist findings (medium/high/critical only — no fake info findings)
        real_findings = [f for f in findings
                         if f.get("severity","").lower() not in ("info","low","")]
        for f in real_findings:
            try: db.add_finding(domain, f)
            except Exception: pass

        log.info(f"[hunt] vuln domain={domain}"
                 f" raw={len(findings)} real={len(real_findings)}")
        return real_findings

    def _nuclei(self, targets: List[str], tags: List[str],
                domain: str) -> List[Dict]:
        binary = _which("nuclei")
        if not binary: return []

        tmp = _tmp_file(targets)
        cmd = [
            binary, "-l", tmp,
            "-tags", ",".join(tags),
            "-severity", "medium,high,critical",
            "-rate-limit", str(NUCLEI_RATE_LIMIT),
            "-timeout", "8", "-retries", "1",
            "-jsonl", "-silent", "-no-color",
        ]
        r = _run_tool(cmd, timeout=min(TOOL_TIMEOUT_S, 600))
        _rm(tmp)
        if not r["ok"]: return []

        findings = []
        for line in r["stdout"].splitlines():
            line = line.strip()
            if not line: continue
            try:
                j = json.loads(line)
                sev = j.get("info", {}).get("severity", "").lower()
                url = j.get("matched-at", j.get("host", ""))
                if sev in ("medium","high","critical") and url:
                    findings.append({
                        "bug":      j.get("template-id","nuclei"),
                        "severity": sev,
                        "url":      url,
                        "title":    j.get("info",{}).get("name",""),
                        "source":   "nuclei",
                        "tags":     tags,
                        "domain":   domain,
                        "raw":      j,
                    })
            except Exception:
                pass
        return findings

    def _idor_candidates(self, targets: List[Dict]) -> List[Dict]:
        """Flag endpoints with ID params as IDOR candidates — no active testing."""
        import re as _re
        candidates = []
        _id_re = _re.compile(r"[?&](id|user_?id|account_?id|uid)=", _re.I)
        for t in targets:
            if _id_re.search(t["url"]):
                candidates.append({
                    "bug":      "idor_candidate",
                    "severity": "medium",
                    "url":      t["url"],
                    "title":    "IDOR Candidate — ID parameter detected",
                    "source":   "auto_hunt_v2",
                    "note":     "Manual verification required. Not auto-tested.",
                    "safe":     True,
                    "auto_exploit": False,
                })
        return candidates[:50]


# ── Job runner ────────────────────────────────────────────────────────────────

def _run_job(job: HuntJob, db, job_registry: Dict,
             status_cb: Callable = None) -> HuntJob:
    """
    Execute one HuntJob through all phases.
    Runs in a worker thread — never blocks the API.
    """
    job.started_at = time.time()
    job.status     = "running"
    log.info(f"[hunt] job_start id={job.job_id} domain={job.domain}"
             f" phases={job.phases}")

    events: List[Dict] = []

    def emit(event: Dict):
        event["ts"]     = time.time()
        event["domain"] = job.domain
        events.append(event)
        if status_cb:
            try: status_cb(job.job_id, event)
            except Exception: pass

    try:
        surface_result   = {}
        endpoint_result  = {}
        intel_result     = {}
        vuln_result      = []

        if "surface" in job.phases:
            surface_result = SurfacePhase().run(job.domain, db, emit)

        live = surface_result.get("live", [])

        if "endpoints" in job.phases:
            endpoint_result = EndpointPhase().run(job.domain, live, db, emit)

        all_endpoints = endpoint_result.get("endpoints", [])

        if "intelligence" in job.phases:
            intel_result = IntelPhase().run(job.domain, all_endpoints, db, emit)

        hv_targets = intel_result.get("high_value_targets", [])

        if "vuln" in job.phases:
            vuln_result = VulnPhase().run(job.domain, hv_targets, db, emit)

        job.results = {
            "subs":            len(surface_result.get("subs",[])),
            "live_hosts":      len(live),
            "open_ports":      len(surface_result.get("ports",[])),
            "endpoints":       len(all_endpoints),
            "high_value":      len(hv_targets),
            "findings":        len(vuln_result),
            "critical":        sum(1 for f in vuln_result if f.get("severity")=="critical"),
            "high":            sum(1 for f in vuln_result if f.get("severity")=="high"),
            "events":          events[-20:],  # last 20 events
        }
        job.status  = "done"
        job.done_at = time.time()
        elapsed     = round(job.done_at - job.started_at, 1)
        log.info(f"[hunt] job_done id={job.job_id} domain={job.domain}"
                 f" findings={len(vuln_result)} elapsed={elapsed}s")

    except Exception as e:
        job.status  = "error"
        job.error   = str(e)
        job.done_at = time.time()
        log.error(f"[hunt] job_error id={job.job_id} domain={job.domain} error={e}")

    job_registry[job.job_id] = job
    return job


# ── AUTO-HUNT ENGINE ──────────────────────────────────────────────────────────

class AutoHuntEngine:
    """
    Autonomous hunt loop.

    Usage:
        engine = AutoHuntEngine(db)
        engine.start()
        engine.submit("example.com", priority=1)
        status = engine.job_status(job_id)
        engine.stop()
    """

    def __init__(self, db, max_workers: int = MAX_WORKERS):
        self.db           = db
        self.max_workers  = max_workers
        self._job_queue:  queue.PriorityQueue = queue.PriorityQueue()
        self._registry:   Dict[str, HuntJob]  = {}
        self._lock        = threading.Lock()
        self._workers:    List[threading.Thread] = []
        self._stop_event  = threading.Event()
        self._last_scan:  Dict[str, float] = {}  # domain → last scan time
        self._status_cbs: List[Callable] = []

    # ── Public API ────────────────────────────────────────────────────────────

    def start(self):
        """Start worker threads."""
        self._stop_event.clear()
        for i in range(self.max_workers):
            t = threading.Thread(
                target=self._worker_loop,
                name=f"hunt-worker-{i}",
                daemon=True,
            )
            t.start()
            self._workers.append(t)
        log.info(f"[hunt] engine started workers={self.max_workers}")

    def stop(self):
        """Graceful shutdown — wait for running jobs to finish."""
        self._stop_event.set()
        for t in self._workers:
            t.join(timeout=30)
        log.info("[hunt] engine stopped")

    def submit(self, domain: str,
               priority:   int        = 5,
               phases:     List[str]  = None,
               bugs:       List[str]  = None,
               force:      bool       = False) -> str:
        """
        Queue a domain for autonomous hunting.
        Returns job_id.
        """
        # Dedup — don't re-scan within RESCAN_INTERVAL_H
        if not force:
            last = self._last_scan.get(domain, 0)
            if time.time() - last < RESCAN_INTERVAL_H * 3600:
                existing = [j for j in self._registry.values()
                            if j.domain == domain and j.status in ("pending","running")]
                if existing:
                    log.info(f"[hunt] skip domain={domain} (recent scan)")
                    return existing[0].job_id

        import hashlib, uuid
        job_id = f"j_{hashlib.md5(f'{domain}{time.time()}'.encode()).hexdigest()[:12]}"
        job = HuntJob(
            domain   = domain,
            job_id   = job_id,
            priority = priority,
            phases   = phases or ["surface","endpoints","intelligence","vuln"],
            bugs     = bugs or [],
        )
        with self._lock:
            self._registry[job_id] = job
        # PriorityQueue uses (priority, counter, item) for stable ordering
        self._job_queue.put((priority, time.time(), job))
        log.info(f"[hunt] queued domain={domain} job_id={job_id} priority={priority}")
        return job_id

    def submit_bulk(self, domains: List[str], priority: int = 5) -> List[str]:
        """Queue multiple domains — deduped, ordered by priority."""
        return [self.submit(d, priority=priority) for d in domains if d]

    def job_status(self, job_id: str) -> Optional[Dict]:
        """Return job status dict or None."""
        j = self._registry.get(job_id)
        return j.to_dict() if j else None

    def list_jobs(self, status_filter: str = None) -> List[Dict]:
        """Return all jobs, optionally filtered by status."""
        jobs = [j.to_dict() for j in self._registry.values()]
        if status_filter:
            jobs = [j for j in jobs if j["status"] == status_filter]
        return sorted(jobs, key=lambda x: -x["created_at"])

    def queue_depth(self) -> Dict:
        pending  = sum(1 for j in self._registry.values() if j.status == "pending")
        running  = sum(1 for j in self._registry.values() if j.status == "running")
        done     = sum(1 for j in self._registry.values() if j.status == "done")
        errors   = sum(1 for j in self._registry.values() if j.status == "error")
        return {
            "pending": pending, "running": running,
            "done": done,       "errors":  errors,
            "total": len(self._registry),
            "workers": self.max_workers,
        }

    def on_status(self, cb: Callable):
        """Register a callback for real-time job events."""
        self._status_cbs.append(cb)

    # ── Worker loop ───────────────────────────────────────────────────────────

    def _worker_loop(self):
        """Background thread — pulls jobs and executes them."""
        name = threading.current_thread().name
        log.info(f"[hunt] {name} started")
        while not self._stop_event.is_set():
            try:
                priority, ts, job = self._job_queue.get(timeout=2)
            except queue.Empty:
                continue

            if self._stop_event.is_set():
                break

            job = _run_job(
                job          = job,
                db           = self.db,
                job_registry = self._registry,
                status_cb    = self._broadcast_status,
            )
            self._last_scan[job.domain] = time.time()
            self._job_queue.task_done()

        log.info(f"[hunt] {name} stopped")

    def _broadcast_status(self, job_id: str, event: Dict):
        for cb in self._status_cbs:
            try: cb(job_id, event)
            except Exception: pass


# ── Singleton management ──────────────────────────────────────────────────────
_engine_instance: Optional[AutoHuntEngine] = None
_engine_lock = threading.Lock()


def get_engine(db=None) -> Optional[AutoHuntEngine]:
    """Get or create the singleton engine. Pass db on first call."""
    global _engine_instance
    with _engine_lock:
        if _engine_instance is None and db is not None:
            _engine_instance = AutoHuntEngine(db)
            _engine_instance.start()
        return _engine_instance


def shutdown_engine():
    global _engine_instance
    with _engine_lock:
        if _engine_instance:
            _engine_instance.stop()
            _engine_instance = None
