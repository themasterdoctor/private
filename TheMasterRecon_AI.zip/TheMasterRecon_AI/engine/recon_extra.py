"""
TheMasterRecon AI — Extended Recon Sources
Integrates:
- waymore (waybackurls on steroids)
- AlienVault OTX (domain intel)
- small-tools-for-hunters (SAN, favicon hash, reverse WHOIS, AbuseIP)
- GitHub dorking for secrets
- CommonCrawl
"""
import re, json, logging, urllib.request, urllib.parse, ssl, time, os
from typing import List, Dict, Optional
from pathlib import Path

log = logging.getLogger("elite.recon_extra")

APP_ROOT = Path(__file__).parent.parent

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _get(url: str, timeout: int = 15, headers: dict = None) -> Optional[str]:
    try:
        h = {"User-Agent": "Mozilla/5.0 TheMasterRecon/3.0", **(headers or {})}
        req = urllib.request.Request(url, headers=h)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.read(1_000_000).decode("utf-8", "ignore")
    except Exception as e:
        log.debug(f"[recon_extra] GET {url}: {e}")
        return None

def _getj(url: str, timeout: int = 15, headers: dict = None) -> Optional[dict]:
    raw = _get(url, timeout, headers)
    if raw:
        try: return json.loads(raw)
        except: pass
    return None


# ── AlienVault OTX ─────────────────────────────────────────────────────────────

def otx_urls(domain: str, limit: int = 2400) -> List[str]:
    """Fetch historical URLs from AlienVault OTX."""
    urls = []
    page = 1
    while True:
        endpoint = (f"https://otx.alienvault.com/api/v1/indicators/domain/"
                    f"{domain}/url_list?limit=500&page={page}")
        data = _getj(endpoint)
        if not data: break

        url_list = data.get("url_list", [])
        for item in url_list:
            u = item.get("url","")
            if u and domain in u:
                urls.append(u)

        if not data.get("has_next", False) or len(urls) >= limit:
            break
        page += 1
        time.sleep(0.3)

    log.info(f"[otx] {domain}: {len(urls)} URLs")
    return list(dict.fromkeys(urls))  # dedup


def otx_subdomains(domain: str) -> List[str]:
    """Fetch passive subdomains from OTX."""
    data = _getj(f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/passive_dns")
    if not data: return []
    subs = set()
    for rec in data.get("passive_dns", []):
        host = rec.get("hostname", "")
        if host.endswith(f".{domain}") or host == domain:
            subs.add(host.lower())
    log.info(f"[otx] {domain}: {len(subs)} passive DNS entries")
    return sorted(subs)


def otx_domain_info(domain: str) -> Dict:
    """Full OTX domain intelligence."""
    result = {"domain": domain, "urls": [], "subdomains": [], "pulses": 0, "malicious": False}
    try:
        # General info
        info = _getj(f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/general")
        if info:
            result["pulses"]    = info.get("pulse_info", {}).get("count", 0)
            result["malicious"] = result["pulses"] > 5

        result["subdomains"] = otx_subdomains(domain)
        result["urls"]       = otx_urls(domain, limit=500)
    except Exception as e:
        log.debug(f"[otx] {domain}: {e}")
    return result


# ── Waymore (comprehensive URL collection) ──────────────────────────────────────

def waymore_urls(domain: str, limit: int = 5000) -> List[str]:
    """
    Collect URLs from multiple sources (mirrors waymore's approach):
    - Wayback Machine
    - Common Crawl index  
    - URLScan.io
    - AlienVault OTX
    - VirusTotal (if key available)
    """
    urls = set()

    # 1. Wayback Machine CDX API
    try:
        endpoint = (f"http://web.archive.org/cdx/search/cdx?url=*.{domain}/*"
                    f"&output=text&fl=original&collapse=urlkey&limit={limit}&fastLatest=true")
        raw = _get(endpoint, timeout=30)
        if raw:
            for line in raw.splitlines():
                line = line.strip()
                if line and domain in line:
                    urls.add(line)
        log.info(f"[waymore] wayback: {len(urls)} URLs")
    except Exception as e:
        log.debug(f"[waymore] wayback: {e}")

    # 2. Common Crawl (latest index)
    try:
        cc_endpoint = (f"https://index.commoncrawl.org/CC-MAIN-2024-10-index"
                       f"?url=*.{domain}&output=json&limit=1000")
        raw2 = _get(cc_endpoint, timeout=20)
        if raw2:
            for line in raw2.splitlines():
                try:
                    item = json.loads(line)
                    u = item.get("url","")
                    if u and domain in u:
                        urls.add(u)
                except: pass
        log.info(f"[waymore] commoncrawl total: {len(urls)} URLs")
    except Exception as e:
        log.debug(f"[waymore] commoncrawl: {e}")

    # 3. URLScan.io
    try:
        r = _getj(f"https://urlscan.io/api/v1/search/?q=domain:{domain}&size=1000")
        if r:
            for item in r.get("results", []):
                u = item.get("page", {}).get("url","")
                if u and domain in u: urls.add(u)
        log.info(f"[waymore] urlscan total: {len(urls)} URLs")
    except Exception as e:
        log.debug(f"[waymore] urlscan: {e}")

    # 4. OTX
    try:
        otx = otx_urls(domain, limit=1000)
        urls.update(otx)
        log.info(f"[waymore] otx total: {len(urls)} URLs")
    except: pass

    result = sorted(urls)[:limit]
    log.info(f"[waymore] {domain}: {len(result)} unique URLs total")
    return result


# ── GitHub Dorking ───────────────────────────────────────────────────────────────

def github_dork(domain: str, api_key: str = "") -> List[Dict]:
    """Search GitHub for exposed secrets related to domain."""
    if not api_key:
        api_key = os.environ.get("GITHUB_TOKEN","")
    if not api_key:
        return []

    headers = {
        "Authorization": f"token {api_key}",
        "Accept": "application/vnd.github.v3+json",
    }
    queries = [
        f'"{domain}" password',
        f'"{domain}" api_key',
        f'"{domain}" secret',
        f'"{domain}" token',
        f'"{domain}" credential',
    ]
    results = []
    for q in queries[:3]:  # rate limit aware
        encoded = urllib.parse.quote(q)
        data = _getj(
            f"https://api.github.com/search/code?q={encoded}&per_page=5",
            headers=headers, timeout=10
        )
        if data:
            for item in data.get("items", []):
                results.append({
                    "name":       item.get("name",""),
                    "path":       item.get("path",""),
                    "html_url":   item.get("html_url",""),
                    "repository": item.get("repository",{}).get("full_name",""),
                    "query":      q,
                })
        time.sleep(1)  # GitHub rate limit

    return results


# ── CommonCrawl subdomains ──────────────────────────────────────────────────────

def commoncrawl_subdomains(domain: str) -> List[str]:
    """Extract subdomains from CommonCrawl index."""
    subs = set()
    try:
        url = (f"https://index.commoncrawl.org/CC-MAIN-2024-10-index"
               f"?url=*.{domain}&output=json&limit=5000")
        raw = _get(url, timeout=20)
        if raw:
            for line in raw.splitlines():
                try:
                    item = json.loads(line)
                    u = item.get("url","")
                    m = re.search(r'https?://([^/]+)', u)
                    if m:
                        host = m.group(1).lower().split(":")[0]
                        if host.endswith(f".{domain}"):
                            subs.add(host)
                except: pass
    except Exception as e:
        log.debug(f"[cc] {domain}: {e}")
    return sorted(subs)


# ── VirusTotal domain report ────────────────────────────────────────────────────

def virustotal_subdomains(domain: str, api_key: str = "") -> List[str]:
    if not api_key:
        api_key = os.environ.get("VT_API_KEY", os.environ.get("VIRUSTOTAL_API_KEY",""))
    if not api_key:
        return []
    headers = {"x-apikey": api_key}
    data = _getj(
        f"https://www.virustotal.com/api/v3/domains/{domain}/subdomains?limit=40",
        headers=headers, timeout=15
    )
    if not data: return []
    subs = []
    for item in data.get("data",[]):
        s = item.get("id","")
        if s: subs.append(s.lower())
    return subs


# ── CRT.sh enhanced ────────────────────────────────────────────────────────────

def crtsh_enhanced(domain: str) -> List[str]:
    """CRT.sh with dedup and cleanup."""
    subs = set()
    for q in [f"%.{domain}", domain]:
        encoded = urllib.parse.quote(q)
        data = _getj(f"https://crt.sh/?q={encoded}&output=json", timeout=20)
        if data:
            for item in data:
                names = item.get("name_value","")
                for n in names.split("\n"):
                    n = n.strip().lower().lstrip("*.")
                    if n.endswith(domain) and " " not in n:
                        subs.add(n)
        time.sleep(0.5)
    return sorted(subs)


# ── Full domain intelligence ────────────────────────────────────────────────────

def full_domain_recon(domain: str, db=None) -> Dict:
    """
    Run all passive recon sources and return combined results.
    Stores results in DB if provided.
    """
    import concurrent.futures
    result = {
        "domain":     domain,
        "subdomains": set(),
        "urls":       [],
        "otx":        {},
        "github":     [],
    }

    def _run_otx():
        try:
            info = otx_domain_info(domain)
            result["otx"] = info
            result["subdomains"].update(info.get("subdomains",[]))
            result["urls"].extend(info.get("urls",[]))
        except Exception as e:
            log.debug(f"[recon_extra] otx: {e}")

    def _run_waymore():
        try:
            urls = waymore_urls(domain, limit=2000)
            result["urls"].extend(urls)
            # Extract subdomains from URLs
            for u in urls:
                m = re.search(r'https?://([^/]+)', u)
                if m:
                    host = m.group(1).split(":")[0].lower()
                    if host.endswith(f".{domain}"):
                        result["subdomains"].add(host)
        except Exception as e:
            log.debug(f"[recon_extra] waymore: {e}")

    def _run_crtsh():
        try:
            subs = crtsh_enhanced(domain)
            result["subdomains"].update(subs)
        except Exception as e:
            log.debug(f"[recon_extra] crtsh: {e}")

    def _run_cc():
        try:
            subs = commoncrawl_subdomains(domain)
            result["subdomains"].update(subs)
        except Exception as e:
            log.debug(f"[recon_extra] commoncrawl: {e}")

    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as exe:
        futs = [exe.submit(f) for f in [_run_otx, _run_waymore, _run_crtsh, _run_cc]]
        concurrent.futures.wait(futs, timeout=60)

    # Dedup
    result["subdomains"] = sorted(result["subdomains"])
    result["urls"]       = list(dict.fromkeys(result["urls"]))[:5000]
    result["sub_count"]  = len(result["subdomains"])
    result["url_count"]  = len(result["urls"])

    # Store in DB
    if db:
        for sub in result["subdomains"]:
            try: db.add_sub(domain, sub)
            except: pass
        for url in result["urls"]:
            try: db.add_endpoint(domain, url, source="waymore/otx")
            except: pass

    log.info(f"[recon_extra] {domain}: {result['sub_count']} subs, {result['url_count']} URLs")
    return result
