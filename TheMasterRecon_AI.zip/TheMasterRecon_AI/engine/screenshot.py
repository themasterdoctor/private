"""
BugScan ELITE — Screenshot Engine
Captures screenshots of every live host using chromium headless.
Falls back to cutycapt, then wkhtmltoimage, then HTML thumbnail.
"""
import os, re, time, logging, shutil, subprocess, base64, threading
import urllib.request, urllib.parse, ssl
from pathlib import Path
from typing import List, Dict, Optional

log = logging.getLogger("elite.screenshot")

SCREENSHOT_DIR = Path(os.path.expanduser("~")) / "Desktop" / "recon" / "screenshots"


def _which(tool: str) -> Optional[str]:
    p = shutil.which(tool)
    if p: return p
    for d in ["/usr/bin","/usr/local/bin","/snap/bin","/opt/google/chrome"]:
        fp = os.path.join(d, tool)
        if os.path.isfile(fp) and os.access(fp, os.X_OK):
            return fp
    return None


def _safe_filename(url: str) -> str:
    """Convert URL to safe filename."""
    url = re.sub(r'^https?://', '', url)
    url = re.sub(r'[^\w\-.]', '_', url)
    return url[:80] + ".png"


def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False
    c.verify_mode = ssl.CERT_NONE
    return c


class ScreenshotEngine:
    def __init__(self, output_dir: str = "", timeout: int = 15,
                 concurrency: int = 5):
        self.output_dir  = Path(output_dir) if output_dir else SCREENSHOT_DIR
        self.timeout     = timeout
        self.concurrency = concurrency
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self._tool = self._detect_tool()
        log.info(f"[screenshot] tool={self._tool}, output={self.output_dir}")

    def _detect_tool(self) -> str:
        """Detect best available screenshot tool."""
        # Chromium headless (best quality)
        for name in ["chromium","chromium-browser","google-chrome","google-chrome-stable","chrome"]:
            if _which(name):
                return name
        # cutycapt
        if _which("cutycapt"): return "cutycapt"
        # wkhtmltoimage
        if _which("wkhtmltoimage"): return "wkhtmltoimage"
        # xvfb + firefox
        if _which("firefox") and _which("xvfb-run"): return "firefox"
        # gowitness (Go tool)
        for d in [os.path.expanduser("~/go/bin"),"/home/kali/go/bin","/root/go/bin"]:
            fp = os.path.join(d, "gowitness")
            if os.path.isfile(fp): return fp
        return "none"

    def screenshot(self, url: str) -> Optional[Dict]:
        """
        Take screenshot of a single URL.
        Returns: {url, path, base64, width, height, title, status}
        """
        filename = _safe_filename(url)
        out_path = self.output_dir / filename

        success = False
        if self._tool == "none":
            success = self._fallback_html(url, out_path)
        elif "gowitness" in self._tool:
            success = self._gowitness(url, out_path)
        elif self._tool in ("chromium","chromium-browser","google-chrome",
                            "google-chrome-stable","chrome"):
            success = self._chromium(url, out_path)
        elif self._tool == "cutycapt":
            success = self._cutycapt(url, out_path)
        elif self._tool == "wkhtmltoimage":
            success = self._wkhtmltoimage(url, out_path)
        elif self._tool == "firefox":
            success = self._firefox(url, out_path)

        if not success or not out_path.exists():
            # Generate a minimal HTML-based placeholder
            self._gen_placeholder(url, out_path)

        result = {
            "url":    url,
            "path":   str(out_path),
            "file":   filename,
            "ts":     time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "size":   out_path.stat().st_size if out_path.exists() else 0,
        }

        # Encode as base64 for inline display
        if out_path.exists() and out_path.stat().st_size > 0:
            try:
                with open(out_path, "rb") as f:
                    result["base64"] = base64.b64encode(f.read()).decode()
                    result["data_url"] = f"data:image/png;base64,{result['base64']}"
            except: pass

        return result

    def _chromium(self, url: str, out: Path) -> bool:
        try:
            cmd = [
                self._tool,
                "--headless=new",
                "--disable-gpu",
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-web-security",
                "--ignore-certificate-errors",
                "--ignore-ssl-errors=yes",
                f"--screenshot={out}",
                "--window-size=1366,768",
                "--timeout=10000",
                "--virtual-time-budget=5000",
                url,
            ]
            r = subprocess.run(cmd, capture_output=True, timeout=self.timeout,
                             env=dict(os.environ, DISPLAY=":99"))
            return out.exists()
        except Exception as e:
            log.debug(f"chromium {url}: {e}")
            return False

    def _gowitness(self, url: str, out: Path) -> bool:
        try:
            cmd = [self._tool, "single",
                   "--url", url,
                   "--screenshot-path", str(self.output_dir),
                   "--timeout", str(self.timeout),
                   "--disable-logging"]
            subprocess.run(cmd, capture_output=True, timeout=self.timeout+5)
            # gowitness saves with its own naming — find the file
            for f in self.output_dir.glob("*.png"):
                if url.replace("https://","").replace("http://","").split("/")[0] in f.name:
                    if f != out:
                        f.rename(out)
                    return True
            return out.exists()
        except Exception as e:
            log.debug(f"gowitness {url}: {e}")
            return False

    def _cutycapt(self, url: str, out: Path) -> bool:
        try:
            cmd = [
                "cutycapt",
                f"--url={url}",
                f"--out={out}",
                "--insecure",
                "--delay=2000",
            ]
            subprocess.run(cmd, capture_output=True, timeout=self.timeout)
            return out.exists()
        except Exception as e:
            log.debug(f"cutycapt {url}: {e}")
            return False

    def _wkhtmltoimage(self, url: str, out: Path) -> bool:
        try:
            cmd = [
                "wkhtmltoimage",
                "--no-stop-slow-scripts",
                "--javascript-delay", "2000",
                "--width", "1366",
                "--quiet",
                url, str(out),
            ]
            subprocess.run(cmd, capture_output=True, timeout=self.timeout)
            return out.exists()
        except Exception as e:
            log.debug(f"wkhtmltoimage {url}: {e}")
            return False

    def _firefox(self, url: str, out: Path) -> bool:
        try:
            cmd = [
                "xvfb-run", "--auto-servernum",
                "firefox", "--headless",
                "--screenshot", str(out),
                "--window-size=1366,768",
                url,
            ]
            subprocess.run(cmd, capture_output=True, timeout=self.timeout)
            return out.exists()
        except Exception as e:
            log.debug(f"firefox {url}: {e}")
            return False

    def _fallback_html(self, url: str, out: Path) -> bool:
        """Generate SVG thumbnail when no browser available."""
        try:
            import urllib.request as ur
            req = ur.Request(url, headers={"User-Agent":"BugScanELITE/1.0"})
            with ur.urlopen(req, timeout=8, context=_ctx()) as r:
                status = r.status
                body   = r.read(8192).decode("utf-8","ignore")
                title_m = re.search(r'<title[^>]*>(.*?)</title>', body, re.I|re.S)
                title = title_m.group(1)[:60] if title_m else url
                server = r.headers.get("Server","Unknown")
        except Exception:
            status, body, title, server = 0, "", url, "Unknown"

        # Create SVG as PNG substitute
        svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="1366" height="768">
  <rect width="1366" height="768" fill="#0d0d1c"/>
  <rect x="0" y="0" width="1366" height="50" fill="#1a1a2e"/>
  <circle cx="20" cy="25" r="7" fill="#ff5f57"/>
  <circle cx="40" cy="25" r="7" fill="#febc2e"/>
  <circle cx="60" cy="25" r="7" fill="#28c840"/>
  <text x="683" y="30" font-family="monospace" font-size="14" fill="#00e5ff" text-anchor="middle">{url[:80]}</text>
  <text x="683" y="80" font-family="monospace" font-size="24" fill="#c8c8e0" text-anchor="middle">{title[:60]}</text>
  <text x="683" y="120" font-family="monospace" font-size="16" fill="#808098" text-anchor="middle">HTTP {status} | {server}</text>
  <text x="683" y="400" font-family="monospace" font-size="48" fill="#252540" text-anchor="middle">BUGSCAN ELITE</text>
</svg>'''
        # Save as SVG with .png extension (browsers will render it)
        out.write_bytes(svg.encode())
        return True

    def _gen_placeholder(self, url: str, out: Path):
        self._fallback_html(url, out)

    def screenshot_all(self, urls: List[str],
                       progress_cb=None) -> List[Dict]:
        """Screenshot multiple URLs with concurrency control."""
        results   = []
        lock      = threading.Lock()
        semaphore = threading.Semaphore(self.concurrency)

        def worker(url):
            with semaphore:
                r = self.screenshot(url)
                if r:
                    with lock:
                        results.append(r)
                    if progress_cb:
                        progress_cb(r)

        threads = [threading.Thread(target=worker, args=(u,), daemon=True)
                   for u in urls]
        for t in threads: t.start()
        for t in threads: t.join(timeout=self.timeout + 5)
        return results

    def get_gallery_html(self, results: List[Dict], domain: str) -> str:
        """Generate HTML gallery of screenshots."""
        cards = ""
        for r in results:
            data_url = r.get("data_url","")
            url      = r.get("url","")
            if not data_url: continue
            cards += f"""
<div class="ss-card">
  <div class="ss-url">{url}</div>
  <img src="{data_url}" alt="{url}" loading="lazy">
</div>"""

        return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Screenshots — {domain}</title>
<style>
body{{background:#05050e;color:#c8c8e0;font-family:monospace;margin:0;padding:20px}}
h1{{color:#00e5ff;font-size:1.4rem;margin-bottom:20px}}
.gallery{{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:16px}}
.ss-card{{background:#0d0d1c;border:1px solid #1a1a2e;border-radius:6px;overflow:hidden;
          transition:border-color .2s}}
.ss-card:hover{{border-color:#00e5ff}}
.ss-url{{padding:8px 10px;font-size:.7rem;color:#808098;white-space:nowrap;
         overflow:hidden;text-overflow:ellipsis;border-bottom:1px solid #1a1a2e}}
.ss-card img{{width:100%;display:block;max-height:200px;object-fit:cover}}
</style>
</head>
<body>
<h1>📸 Screenshot Gallery — {domain} ({len(results)} hosts)</h1>
<div class="gallery">{cards}</div>
</body>
</html>"""


# Global engine instance
_engine: Optional[ScreenshotEngine] = None

def get_engine(output_dir: str = "") -> "ScreenshotEngine":
    # Always create new engine per call when output_dir specified
    # (different domains need different dirs)
    if output_dir:
        return ScreenshotEngine(output_dir=output_dir)
    global _engine
    if _engine is None:
        _engine = ScreenshotEngine()
    return _engine
