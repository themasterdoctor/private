"""
BugScan ELITE — Tech Fingerprint → Auto Bug Selection Engine
Analyzes detected technologies and auto-selects the highest-yield vuln types.
"""
import re, logging
from typing import List, Dict, Set

log = logging.getLogger("elite.fingerprint")

# ── Tech → Vuln type mappings ─────────────────────────────────────────────────
# Each tech maps to: (priority_bugs, reason)
TECH_VULN_MAP: Dict[str, Dict] = {

    # ── Java / Spring ──────────────────────────────────────────────────────
    "Spring Boot": {
        "bugs":   ["actuator","spring4shell","log4j","deserialization","ssrf","expose"],
        "reason": "Spring Boot → check Actuator endpoints, Spring4Shell, Log4Shell",
        "priority": "critical",
    },
    "Spring": {
        "bugs":   ["actuator","spring4shell","log4j","deserialization"],
        "reason": "Spring Framework → Spring4Shell, Log4Shell, Actuator exposure",
        "priority": "critical",
    },
    "Java": {
        "bugs":   ["deserialization","log4j","xxe","ssrf"],
        "reason": "Java stack → deserialization gadget chains, Log4Shell, XXE",
        "priority": "high",
    },
    "Tomcat": {
        "bugs":   ["deserialization","lfi","expose","panels"],
        "reason": "Apache Tomcat → manager interface, deserialization",
        "priority": "high",
    },
    "Struts": {
        "bugs":   ["rce","deserialization","expose"],
        "reason": "Apache Struts → Struts RCE CVEs (S2-045, S2-059)",
        "priority": "critical",
    },

    # ── PHP ────────────────────────────────────────────────────────────────
    "PHP": {
        "bugs":   ["sqli","lfi","rce","expose","deserialization","fileupload"],
        "reason": "PHP stack → SQLi, LFI, object injection, file upload",
        "priority": "high",
    },
    "WordPress": {
        "bugs":   ["sqli","xss","lfi","fileupload","expose","panels","cve"],
        "reason": "WordPress → xmlrpc.php, plugin SQLi, admin panel",
        "priority": "high",
    },
    "Drupal": {
        "bugs":   ["rce","sqli","fileupload","expose","cve"],
        "reason": "Drupal → Drupalgeddon RCE, file upload",
        "priority": "critical",
    },
    "Joomla": {
        "bugs":   ["sqli","rce","lfi","expose","cve"],
        "reason": "Joomla → SQLi, RCE via com_fields",
        "priority": "high",
    },
    "Magento": {
        "bugs":   ["sqli","rce","xxe","deserialization","expose","cve"],
        "reason": "Magento → Magento SQLi, XXE, deserialization chains",
        "priority": "critical",
    },
    "Laravel": {
        "bugs":   ["deserialization","expose","sqli","ssti"],
        "reason": "Laravel → .env exposure, debug mode SSTI",
        "priority": "high",
    },

    # ── Python ────────────────────────────────────────────────────────────
    "Python": {
        "bugs":   ["ssti","deserialization","ssrf","expose"],
        "reason": "Python stack → Jinja2/Mako SSTI, Pickle deserialization",
        "priority": "high",
    },
    "Django": {
        "bugs":   ["ssti","sqli","expose","cors"],
        "reason": "Django → debug page info leak, SSTI, SQLi",
        "priority": "medium",
    },
    "Flask": {
        "bugs":   ["ssti","expose","cors","ssrf"],
        "reason": "Flask → Jinja2 SSTI, debug mode RCE",
        "priority": "high",
    },

    # ── Node.js ───────────────────────────────────────────────────────────
    "Node.js": {
        "bugs":   ["prototype","nosqli","ssrf","expose","deserialization"],
        "reason": "Node.js → prototype pollution, MongoDB NoSQLi",
        "priority": "high",
    },
    "Express": {
        "bugs":   ["prototype","cors","expose","ssrf","nosqli"],
        "reason": "Express.js → CORS misconfig, prototype pollution",
        "priority": "high",
    },
    "Next.js": {
        "bugs":   ["expose","ssrf","cors","prototype","cve"],
        "reason": "Next.js → CVE-2025-29927 middleware bypass, path traversal",
        "priority": "critical",
    },

    # ── Ruby ──────────────────────────────────────────────────────────────
    "Ruby on Rails": {
        "bugs":   ["deserialization","sqli","ssti","expose","cors"],
        "reason": "Rails → mass assignment, deserialization, SSTI in ERB",
        "priority": "high",
    },

    # ── .NET ──────────────────────────────────────────────────────────────
    "ASP.NET": {
        "bugs":   ["deserialization","sqli","xxe","expose","panels"],
        "reason": "ASP.NET → ViewState deserialization, ELMAH exposure",
        "priority": "high",
    },
    "IIS": {
        "bugs":   ["expose","lfi","cve","panels"],
        "reason": "IIS → web.config exposure, short filename disclosure",
        "priority": "medium",
    },

    # ── APIs / GraphQL ────────────────────────────────────────────────────
    "GraphQL": {
        "bugs":   ["graphql","nosqli","ssrf","idor"],
        "reason": "GraphQL → introspection, batch attacks, injection",
        "priority": "high",
    },
    "REST": {
        "bugs":   ["idor","cors","jwt","oauth","ssrf"],
        "reason": "REST API → IDOR, auth issues, CORS",
        "priority": "high",
    },

    # ── Auth / SSO ────────────────────────────────────────────────────────
    "Keycloak": {
        "bugs":   ["oauth","saml","jwt","expose"],
        "reason": "Keycloak → OIDC misconfig, redirect_uri bypass",
        "priority": "high",
    },
    "Okta": {
        "bugs":   ["oauth","saml","jwt"],
        "reason": "Okta SSO → SAML signature wrapping, OAuth bypass",
        "priority": "high",
    },
    "SAML": {
        "bugs":   ["saml","oauth","cors"],
        "reason": "SAML detected → XML signature wrapping attacks",
        "priority": "critical",
    },
    "OAuth": {
        "bugs":   ["oauth","jwt","cors","redirect"],
        "reason": "OAuth detected → redirect_uri bypass, token theft",
        "priority": "high",
    },
    "JWT": {
        "bugs":   ["jwt","oauth"],
        "reason": "JWT detected → alg:none, RS256→HS256 confusion",
        "priority": "high",
    },

    # ── Databases ─────────────────────────────────────────────────────────
    "MySQL": {
        "bugs":   ["sqli","expose"],
        "reason": "MySQL detected → error-based SQLi",
        "priority": "high",
    },
    "PostgreSQL": {
        "bugs":   ["sqli","ssrf","expose"],
        "reason": "PostgreSQL → SQLi, COPY TO PROGRAM RCE",
        "priority": "high",
    },
    "MongoDB": {
        "bugs":   ["nosqli","expose"],
        "reason": "MongoDB → NoSQL injection, unauthenticated access",
        "priority": "high",
    },
    "Redis": {
        "bugs":   ["ssrf","expose"],
        "reason": "Redis → SSRF via gopher, unauthenticated access",
        "priority": "high",
    },
    "Elasticsearch": {
        "bugs":   ["expose","ssrf"],
        "reason": "Elasticsearch → unauthenticated API access",
        "priority": "high",
    },

    # ── Cloud / Infra ─────────────────────────────────────────────────────
    "AWS": {
        "bugs":   ["ssrf","buckets","expose","jsleak"],
        "reason": "AWS → metadata SSRF, S3 misconfiguration",
        "priority": "critical",
    },
    "Nginx": {
        "bugs":   ["expose","misconfig","lfi"],
        "reason": "Nginx → alias traversal, misconfiguration",
        "priority": "medium",
    },
    "Apache": {
        "bugs":   ["expose","lfi","misconfig","cve"],
        "reason": "Apache → .htaccess, mod_status, directory traversal",
        "priority": "medium",
    },
    "Kubernetes": {
        "bugs":   ["ssrf","expose","panels"],
        "reason": "Kubernetes → API server exposure, SSRF to metadata",
        "priority": "critical",
    },
    "Docker": {
        "bugs":   ["expose","ssrf","panels"],
        "reason": "Docker → API exposure (port 2375), registry access",
        "priority": "high",
    },

    # ── CMS / Platforms ───────────────────────────────────────────────────
    "SharePoint": {
        "bugs":   ["xxe","expose","sqli","cve"],
        "reason": "SharePoint → XXE, SSRF, multiple high CVEs",
        "priority": "high",
    },
    "Confluence": {
        "bugs":   ["rce","expose","cve","ognl"],
        "reason": "Confluence → OGNL injection RCE CVEs",
        "priority": "critical",
    },
    "Jira": {
        "bugs":   ["ssrf","expose","cve","cors"],
        "reason": "Jira → SSRF in webhooks, info disclosure",
        "priority": "high",
    },
    "Jenkins": {
        "bugs":   ["rce","expose","panels","cve"],
        "reason": "Jenkins → script console RCE, unauthenticated access",
        "priority": "critical",
    },
    "GitLab": {
        "bugs":   ["rce","ssrf","expose","cve"],
        "reason": "GitLab → SSRF, RCE via pipeline, token exposure",
        "priority": "critical",
    },

    # ── WAF / CDN ─────────────────────────────────────────────────────────
    "Cloudflare": {
        "bugs":   ["expose"],
        "reason": "Cloudflare detected — WAF bypass strategies enabled",
        "priority": "info",
    },
    "Akamai": {
        "bugs":   ["expose"],
        "reason": "Akamai detected — WAF bypass strategies enabled",
        "priority": "info",
    },
    # Modern tech stacks
    "Nginx":        {"bugs": ["misconfig","expose","cors","smuggling"],       "priority": ["smuggling","misconfig"], "reason": "Nginx detected"},
    "Apache":       {"bugs": ["misconfig","expose","lfi","rce"],              "priority": ["misconfig","lfi"],       "reason": "Apache detected"},
    "Kubernetes":   {"bugs": ["expose","misconfig","ssrf"],                   "priority": ["expose","ssrf"],         "reason": "K8s API detected"},
    "Jenkins":      {"bugs": ["rce","expose","misconfig","panels"],           "priority": ["rce","expose"],          "reason": "Jenkins CI detected"},
    "GitLab":       {"bugs": ["expose","oauth","ssrf","rce"],                 "priority": ["rce","oauth"],           "reason": "GitLab detected"},
    "Confluence":   {"bugs": ["rce","expose","ssrf","xss"],                   "priority": ["rce"],                   "reason": "Confluence detected"},
    "Jira":         {"bugs": ["ssrf","expose","xss","idor"],                  "priority": ["ssrf","idor"],           "reason": "Jira detected"},
    "Grafana":      {"bugs": ["expose","panels","ssrf","lfi"],                "priority": ["expose","panels"],       "reason": "Grafana detected"},
    "Kibana":       {"bugs": ["expose","ssrf","prototype"],                   "priority": ["expose","ssrf"],         "reason": "Kibana detected"},
    "Elasticsearch":{"bugs": ["expose","misconfig","idor"],                   "priority": ["expose","misconfig"],    "reason": "Elasticsearch detected"},
    "Firebase":     {"bugs": ["misconfig","expose","idor"],                   "priority": ["misconfig","idor"],      "reason": "Firebase detected"},
    "Supabase":     {"bugs": ["misconfig","idor","expose","nosqli"],          "priority": ["idor","misconfig"],      "reason": "Supabase detected"},
    "Hasura":       {"bugs": ["graphql","graphql_deep","idor","expose"],      "priority": ["graphql_deep","idor"],   "reason": "Hasura GraphQL detected"},
    "Strapi":       {"bugs": ["idor","expose","misconfig","xss"],             "priority": ["idor","expose"],         "reason": "Strapi CMS detected"},
    "PocketBase":   {"bugs": ["idor","expose","misconfig"],                   "priority": ["idor"],                  "reason": "PocketBase detected"},    # Extended tech stack coverage
    "Nginx":          {"bugs": ["misconfig","smuggling","cors","expose"],          "priority": ["smuggling","misconfig"], "reason": "Nginx detected"},
    "Apache":         {"bugs": ["misconfig","lfi","rce","expose"],                 "priority": ["misconfig","lfi"],       "reason": "Apache detected"},
    "IIS":            {"bugs": ["misconfig","expose","deserialization","iis"],      "priority": ["misconfig","expose"],    "reason": "IIS/ASP.NET detected"},
    "Tomcat":         {"bugs": ["rce","deserialization","expose","misconfig"],      "priority": ["rce","deserialization"], "reason": "Apache Tomcat"},
    "Jenkins":        {"bugs": ["rce","expose","panels","misconfig"],              "priority": ["rce","panels"],          "reason": "Jenkins CI"},
    "GitLab":         {"bugs": ["expose","oauth","ssrf","rce"],                    "priority": ["rce","oauth"],           "reason": "GitLab"},
    "Confluence":     {"bugs": ["rce","ssrf","expose","xss"],                      "priority": ["rce","ssrf"],            "reason": "Confluence"},
    "Jira":           {"bugs": ["ssrf","expose","xss","idor"],                     "priority": ["ssrf","idor"],           "reason": "Jira"},
    "Grafana":        {"bugs": ["expose","panels","ssrf","lfi"],                   "priority": ["expose","panels"],       "reason": "Grafana"},
    "Kibana":         {"bugs": ["expose","ssrf","prototype"],                      "priority": ["expose","ssrf"],         "reason": "Kibana"},
    "Elasticsearch":  {"bugs": ["expose","misconfig","idor"],                      "priority": ["expose","misconfig"],    "reason": "Elasticsearch"},
    "Redis":          {"bugs": ["expose","ssrf","misconfig"],                      "priority": ["ssrf","expose"],         "reason": "Redis"},
    "MongoDB":        {"bugs": ["nosqli","idor","expose"],                         "priority": ["nosqli","expose"],       "reason": "MongoDB"},
    "Firebase":       {"bugs": ["misconfig","expose","idor"],                      "priority": ["misconfig","idor"],      "reason": "Firebase"},
    "Supabase":       {"bugs": ["misconfig","idor","expose","nosqli"],             "priority": ["idor","misconfig"],      "reason": "Supabase"},
    "Hasura":         {"bugs": ["graphql","graphql_deep","idor","expose"],          "priority": ["graphql_deep","idor"],   "reason": "Hasura GraphQL"},
    "Strapi":         {"bugs": ["idor","expose","misconfig","xss"],                "priority": ["idor","expose"],         "reason": "Strapi CMS"},
    "PocketBase":     {"bugs": ["idor","expose","misconfig"],                      "priority": ["idor"],                  "reason": "PocketBase"},
    "Kubernetes":     {"bugs": ["expose","misconfig","ssrf"],                      "priority": ["expose","ssrf"],         "reason": "K8s API"},
    "Docker":         {"bugs": ["expose","misconfig","rce"],                       "priority": ["expose","rce"],          "reason": "Docker"},
    "Cloudflare":     {"bugs": ["cors","cache_poison","waf"],                      "priority": ["cache_poison"],          "reason": "Cloudflare CDN"},
    "Next.js":        {"bugs": ["ssrf","rce","expose","prototype"],                "priority": ["rce","ssrf"],            "reason": "Next.js RSC"},
    "Nuxt":           {"bugs": ["ssrf","expose","prototype"],                      "priority": ["ssrf","expose"],         "reason": "Nuxt.js"},
    "Vite":           {"bugs": ["expose","misconfig"],                             "priority": ["expose"],                "reason": "Vite dev server"},
    "Prisma":         {"bugs": ["sqli","idor","nosqli"],                           "priority": ["sqli","idor"],           "reason": "Prisma ORM"},
    "tRPC":           {"bugs": ["idor","mass_assign","expose"],                    "priority": ["idor","mass_assign"],    "reason": "tRPC API"},
    "Shopify":        {"bugs": ["idor","redirect","expose","cors"],                "priority": ["idor","redirect"],       "reason": "Shopify platform"},
    "Magento":        {"bugs": ["rce","sqli","expose","panels"],                   "priority": ["rce","sqli"],            "reason": "Magento e-commerce"},
    "WooCommerce":    {"bugs": ["sqli","idor","expose","rce"],                     "priority": ["sqli","idor"],           "reason": "WooCommerce"},
    "PrestaShop":     {"bugs": ["sqli","rce","expose"],                            "priority": ["sqli","rce"],            "reason": "PrestaShop"},
    "Plesk":          {"bugs": ["panels","rce","expose","misconfig"],              "priority": ["panels","rce"],          "reason": "Plesk control panel"},
    "cPanel":         {"bugs": ["panels","rce","expose","misconfig"],              "priority": ["panels","rce"],          "reason": "cPanel"},
    "Zimbra":         {"bugs": ["rce","ssrf","expose","xss"],                      "priority": ["rce","ssrf"],            "reason": "Zimbra email"},
    "Exchange":       {"bugs": ["ssrf","rce","expose","deserialization"],          "priority": ["rce","ssrf"],            "reason": "Microsoft Exchange"},
    "Citrix":         {"bugs": ["lfi","ssrf","rce","expose"],                      "priority": ["lfi","rce"],             "reason": "Citrix ADC/Gateway"},
    "FortiOS":        {"bugs": ["rce","lfi","expose","misconfig"],                 "priority": ["rce","lfi"],             "reason": "Fortinet FortiOS"},
    "Palo Alto":      {"bugs": ["rce","expose","misconfig"],                       "priority": ["rce","expose"],          "reason": "Palo Alto PAN-OS"},
    "VMware":         {"bugs": ["rce","ssrf","expose","deserialization"],          "priority": ["rce","ssrf"],            "reason": "VMware vSphere/ESXi"},

}

# Always-on baseline checks regardless of tech
BASELINE_BUGS = [
    "expose", "cors", "misconfig", "panels", "redirect",
    "takeover", "jsleak", "cve",
]


def fingerprint_to_bugs(tech_list: List[str]) -> Dict:
    """
    Given a list of detected technologies, return prioritized bug list.
    Returns: {bugs: [...], reasons: [...], priority_bugs: [...], tech_matched: [...]}
    """
    selected: Set[str]   = set(BASELINE_BUGS)
    priority: Set[str]   = set()
    reasons:  List[str]  = []
    matched:  List[str]  = []

    for tech in tech_list:
        # Exact match
        mapping = TECH_VULN_MAP.get(tech)
        if not mapping:
            # Fuzzy match
            for key, val in TECH_VULN_MAP.items():
                if key.lower() in tech.lower() or tech.lower() in key.lower():
                    mapping = val
                    break

        if mapping:
            matched.append(tech)
            selected.update(mapping["bugs"])
            reasons.append(f"[{tech}] {mapping['reason']}")
            if mapping.get("priority") in ("critical","high"):
                priority.update(mapping["bugs"])

    # Sort: priority bugs first, then rest
    all_bugs = list(priority) + [b for b in selected if b not in priority]

    log.info(f"[fingerprint] tech={tech_list[:5]} → {len(all_bugs)} bugs selected")

    return {
        "bugs":          all_bugs,
        "priority_bugs": list(priority),
        "reasons":       reasons,
        "tech_matched":  matched,
        "baseline":      BASELINE_BUGS,
    }


def parse_httpx_tech(tech_raw) -> List[str]:
    """
    Parse tech from httpx JSON output (various field formats).
    """
    if not tech_raw:
        return []
    if isinstance(tech_raw, list):
        result = []
        for t in tech_raw:
            if isinstance(t, dict):
                name = t.get("name") or t.get("technology") or ""
                if name: result.append(name)
            elif isinstance(t, str):
                result.append(t)
        return result
    if isinstance(tech_raw, dict):
        return list(tech_raw.keys())
    if isinstance(tech_raw, str):
        return [t.strip() for t in tech_raw.split(",") if t.strip()]
    return []


def auto_select_bugs_from_db(domain: str, db) -> Dict:
    """
    Read enriched httpx data from DB, run fingerprinting, return bug selection.
    """
    hosts_data = db.get_hosts(domain)
    enriched   = hosts_data.get("enriched", [])
    tech_db    = db.get_tech(domain)

    # Collect all tech across all hosts
    all_tech: Set[str] = set(tech_db)
    for e in enriched:
        raw = e.get("tech", [])
        for t in parse_httpx_tech(raw):
            all_tech.add(t)

    tech_list = list(all_tech)
    result    = fingerprint_to_bugs(tech_list)
    result["all_tech"] = tech_list
    return result


def get_scan_profile(tech_list: List[str]) -> str:
    """
    Return a named profile based on tech stack.
    """
    t = " ".join(tech_list).lower()
    if any(x in t for x in ["spring","java","tomcat","struts"]):
        return "java_enterprise"
    if any(x in t for x in ["wordpress","drupal","joomla","magento"]):
        return "cms"
    if any(x in t for x in ["graphql","rest","api"]):
        return "api_first"
    if any(x in t for x in ["aws","kubernetes","docker","cloud"]):
        return "cloud_native"
    if any(x in t for x in ["saml","oauth","sso","keycloak","okta"]):
        return "sso_heavy"
    if any(x in t for x in ["node","express","next","react"]):
        return "nodejs"
    return "generic"
