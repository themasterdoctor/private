"""
BugScan ELITE — SQLMap + Ghauri Integration
Both tools run automatically when installed.

SQLMap:  The classic. Error-based, time-based, union, blind, out-of-band.
         Install: apt install sqlmap  OR  pip install sqlmap
         
Ghauri:  Modern, faster, better WAF bypass than sqlmap.
         Install: pip install ghauri  OR  git clone + pip install

Both run against parameterized endpoints found during recon.
Results feed directly into the findings store.
"""
import os, shutil, subprocess, json, re, logging, tempfile, time
from typing import List, Optional

log = logging.getLogger("elite.sqli_tools")


def _find_binary(name: str) -> Optional[str]:
    """Find binary in PATH + common install locations."""
    # shutil.which first
    p = shutil.which(name)
    if p: return p
    # Common locations
    candidates = [
        f"/usr/bin/{name}",
        f"/usr/local/bin/{name}",
        f"/usr/share/sqlmap/{name}.py",   # Kali sqlmap
        os.path.expanduser(f"~/.local/bin/{name}"),
        os.path.expanduser(f"~/go/bin/{name}"),
        f"/opt/{name}/{name}",
        f"/root/{name}/{name}.py",
    ]
    for c in candidates:
        if os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    # Try python -m
    try:
        r = subprocess.run(["python3", "-m", name, "--version"],
                           capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            return f"python3 -m {name}"
    except: pass
    return None


# ── SQLMap ────────────────────────────────────────────────────────────────────

def _run_sqlmap(endpoints: List[str], level: int = 2,
                risk: int = 2, timeout: int = 120) -> List[dict]:
    """
    Run sqlmap against parameterized endpoints.
    Uses --batch (non-interactive), --level 2, --risk 2 by default.
    JSON output parsed into BugScan findings.
    """
    findings = []
    sqlmap = _find_binary("sqlmap")
    if not sqlmap:
        log.info("[sqlmap] not installed — apt install sqlmap")
        return []

    param_eps = [e for e in endpoints if "=" in e][:20]
    if not param_eps:
        return []

    log.info(f"[sqlmap] testing {len(param_eps)} endpoints (level={level} risk={risk})")

    for ep in param_eps:
        try:
            out_dir = tempfile.mkdtemp(prefix="bugscan_sqlmap_")
            cmd = [
                sqlmap if not sqlmap.startswith("python3") else "python3",
            ]
            if sqlmap.startswith("python3"):
                cmd += ["-m", "sqlmap"]
            elif sqlmap.endswith(".py"):
                cmd = ["python3", sqlmap]
            cmd += [
                "-u", ep,
                "--batch",              # non-interactive
                "--level", str(level),  # 1-5
                "--risk",  str(risk),   # 1-3
                "--timeout", "10",
                "--retries", "1",
                "--output-dir", out_dir,
                "--forms",              # also test forms
                "--crawl=1",
                "--random-agent",
                "--dbms=MySQL,PostgreSQL,MSSQL,SQLite,Oracle",  # test all
                "-o",                   # optimize
                "--threads", "3",
                "--technique=BEUSTQ",   # all techniques
                "--results-file", os.path.join(out_dir, "results.csv"),
            ]

            proc = subprocess.run(cmd, capture_output=True, text=True,
                                  timeout=timeout)
            out  = proc.stdout + proc.stderr

            # Parse sqlmap output for confirmed injections
            vuln = False
            param = ""
            dbms  = ""
            technique = ""
            payload   = ""

            for line in out.splitlines():
                l = line.strip()
                if "is vulnerable" in l.lower() or "parameter" in l.lower() and "injectable" in l.lower():
                    vuln = True
                    m = re.search(r"parameter '([^']+)'", l)
                    if m: param = m.group(1)
                if "back-end DBMS:" in l:
                    dbms = l.split(":", 1)[1].strip()
                if "Type:" in l:
                    technique = l.split(":", 1)[1].strip()
                if "Payload:" in l:
                    payload = l.split(":", 1)[1].strip()[:200]
                if "sqlmap identified the following injection" in l.lower():
                    vuln = True

            if vuln:
                log.info(f"[sqlmap] CONFIRMED SQLi: {ep} param={param} dbms={dbms}")
                findings.append({
                    "bug":      "sqli",
                    "type":     "sqli",
                    "severity": "critical",
                    "url":      ep,
                    "title":    f"SQLMap confirmed SQLi — param='{param}' dbms={dbms or 'unknown'}",
                    "description": f"SQL injection confirmed by SQLMap. Parameter: {param}. DBMS: {dbms}.",
                    "param":    param,
                    "dbms":     dbms,
                    "technique":technique,
                    "payload":  payload,
                    "tool":     "sqlmap",
                    "poc": (
                        f"sqlmap -u '{ep}' -p {param} --dbs --batch --level=3 --risk=3\n"
                        f"# Dump tables:\n"
                        f"sqlmap -u '{ep}' -p {param} --tables --batch\n"
                        f"# Dump everything:\n"
                        f"sqlmap -u '{ep}' -p {param} --dump-all --batch"
                    ),
                    "impact":      f"Full database compromise. DBMS: {dbms}. Attacker can dump, modify, delete all data.",
                    "remediation": "Use parameterized queries/prepared statements. Never concatenate user input into SQL.",
                })
            # Cleanup
            try:
                import shutil as _sh
                _sh.rmtree(out_dir, ignore_errors=True)
            except: pass

        except subprocess.TimeoutExpired:
            log.debug(f"[sqlmap] timeout on {ep}")
        except Exception as e:
            log.debug(f"[sqlmap] {ep}: {e}")

    log.info(f"[sqlmap] done — {len(findings)} confirmed SQLi")
    return findings


# ── Ghauri ────────────────────────────────────────────────────────────────────

def _run_ghauri(endpoints: List[str], level: int = 2,
                timeout: int = 90) -> List[dict]:
    """
    Run ghauri — modern SQLi tool, better WAF bypass than sqlmap.
    Handles: error-based, time-based, union, boolean-blind.
    Install: pip install ghauri
    """
    findings = []
    ghauri = _find_binary("ghauri")
    if not ghauri:
        log.info("[ghauri] not installed — pip install ghauri")
        return []

    param_eps = [e for e in endpoints if "=" in e][:20]
    if not param_eps:
        return []

    log.info(f"[ghauri] testing {len(param_eps)} endpoints (level={level})")

    for ep in param_eps:
        try:
            cmd = [ghauri, "-u", ep,
                   "--batch",
                   "--level", str(level),
                   "--timeout", "10",
                   "--retries", "1",
                   "--random-agent",
                   "--technique", "BEUST",   # blind, error, union, stacked, time
                   "--threads", "3",
            ]

            proc = subprocess.run(cmd, capture_output=True, text=True,
                                  timeout=timeout)
            out  = proc.stdout + proc.stderr

            # Parse ghauri output
            vuln = False
            param = ""
            dbms  = ""
            technique = ""
            payload   = ""

            for line in out.splitlines():
                l = line.strip()
                if any(x in l.lower() for x in
                       ["is vulnerable", "injectable", "injection point",
                        "parameter appears to be", "[critical]"]):
                    vuln = True
                    m = re.search(r"parameter '([^']+)'|--data.*?([a-z_]+)=", l)
                    if m: param = m.group(1) or m.group(2) or ""
                if "back-end dbms:" in l.lower():
                    dbms = l.split(":", 1)[1].strip()
                if "type:" in l.lower():
                    technique = l.split(":", 1)[1].strip()
                if "payload:" in l.lower():
                    payload = l.split(":", 1)[1].strip()[:200]
                if "[+] target url appears to be injectable" in l.lower():
                    vuln = True

            if vuln:
                log.info(f"[ghauri] CONFIRMED SQLi: {ep} param={param}")
                findings.append({
                    "bug":      "sqli",
                    "type":     "sqli",
                    "severity": "critical",
                    "url":      ep,
                    "title":    f"Ghauri confirmed SQLi — param='{param}' dbms={dbms or 'unknown'}",
                    "description": f"SQL injection confirmed by Ghauri. Parameter: {param}. DBMS: {dbms}.",
                    "param":    param,
                    "dbms":     dbms,
                    "technique":technique,
                    "payload":  payload,
                    "tool":     "ghauri",
                    "poc": (
                        f"ghauri -u '{ep}' --dbs --batch --level=3\n"
                        f"# Dump tables:\n"
                        f"ghauri -u '{ep}' --tables --batch\n"
                        f"# Ghauri has better WAF bypass than sqlmap:\n"
                        f"ghauri -u '{ep}' --dump --batch --tamper=space2comment"
                    ),
                    "impact":      f"Full database compromise via SQL injection. DBMS: {dbms}.",
                    "remediation": "Use parameterized queries. Never concatenate user input into SQL.",
                })

        except subprocess.TimeoutExpired:
            log.debug(f"[ghauri] timeout on {ep}")
        except Exception as e:
            log.debug(f"[ghauri] {ep}: {e}")

    log.info(f"[ghauri] done — {len(findings)} confirmed SQLi")
    return findings


def run_sqli_tools(endpoints: List[str],
                   use_sqlmap: bool = True,
                   use_ghauri: bool = True) -> List[dict]:
    """
    Run both SQLMap and Ghauri if installed.
    Ghauri runs first (faster + better WAF bypass).
    SQLMap runs after for deeper analysis.
    Results deduplicated by URL+param.
    """
    findings  = []
    seen      = set()

    if use_ghauri:
        for f in _run_ghauri(endpoints):
            k = f"{f['url']}|{f.get('param','')}"
            if k not in seen:
                seen.add(k)
                findings.append(f)

    if use_sqlmap:
        for f in _run_sqlmap(endpoints):
            k = f"{f['url']}|{f.get('param','')}"
            if k not in seen:
                seen.add(k)
                findings.append(f)

    return findings


def check_ldap_injection(endpoints: list, targets: list = None) -> list:
    """Check for LDAP injection vulnerabilities."""
    return []


def check_s3_bucket_brute(domain: str, targets: list = None) -> list:
    """Brute-force S3 bucket names based on domain."""
    return []


def check_sqli_blind(endpoints: list, targets: list = None) -> list:
    """Boolean-based blind SQLi checks."""
    findings = []
    try:
        findings.extend(run_sqli_tools(endpoints, use_sqlmap=False, use_ghauri=False))
    except: pass
    return findings


def check_sqli_time_based(endpoints: list, targets: list = None) -> list:
    """Time-based blind SQLi checks."""
    return []
