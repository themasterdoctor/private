"""
BugScan ELITE — AI Risk Scoring Engine
Converts raw scan findings into business-context severity scores.
Goes beyond CVSS: exploitability + business impact + estimated damage.
"""
import re, time, json, logging, os
from typing import Dict, List, Optional
from pathlib import Path

log = logging.getLogger("elite.risk")

# ── Business impact multipliers by industry ───────────────────────────────────
INDUSTRY_IMPACT = {
    "fintech":      {"data_value": 5.0, "regulatory": 4.0, "reputation": 4.0},
    "healthcare":   {"data_value": 4.5, "regulatory": 5.0, "reputation": 3.5},
    "ecommerce":    {"data_value": 3.5, "regulatory": 3.0, "reputation": 4.5},
    "saas":         {"data_value": 4.0, "regulatory": 3.0, "reputation": 4.5},
    "government":   {"data_value": 4.0, "regulatory": 5.0, "reputation": 5.0},
    "startup":      {"data_value": 3.0, "regulatory": 2.0, "reputation": 3.5},
    "enterprise":   {"data_value": 4.5, "regulatory": 4.0, "reputation": 4.0},
    "default":      {"data_value": 3.0, "regulatory": 3.0, "reputation": 3.0},
}

# ── Base risk scores by vulnerability type ────────────────────────────────────
VULN_BASE_SCORES = {
    # Critical — direct system compromise
    "rce":              {"exploitability": 9.5, "impact": 10.0, "base_damage": 250000},
    "sqli":             {"exploitability": 8.5, "impact": 9.5,  "base_damage": 150000},
    "xxe":              {"exploitability": 7.5, "impact": 8.5,  "base_damage": 100000},
    "deserialization":  {"exploitability": 7.0, "impact": 9.5,  "base_damage": 200000},
    "ssti":             {"exploitability": 8.0, "impact": 9.0,  "base_damage": 150000},
    "jwt":              {"exploitability": 7.5, "impact": 8.5,  "base_damage": 100000},
    "reset_poison":     {"exploitability": 7.0, "impact": 8.5,  "base_damage": 80000},
    # High — significant impact
    "ssrf":             {"exploitability": 8.0, "impact": 8.0,  "base_damage": 80000},
    "lfi":              {"exploitability": 8.0, "impact": 7.5,  "base_damage": 60000},
    "idor":             {"exploitability": 8.5, "impact": 7.0,  "base_damage": 50000},
    "mass_assign":      {"exploitability": 8.0, "impact": 7.5,  "base_damage": 75000},
    "cache_poison":     {"exploitability": 6.5, "impact": 7.0,  "base_damage": 50000},
    "takeover":         {"exploitability": 9.0, "impact": 8.0,  "base_damage": 60000},
    "buckets":          {"exploitability": 9.5, "impact": 7.5,  "base_damage": 80000},
    "saml":             {"exploitability": 6.5, "impact": 8.0,  "base_damage": 90000},
    "oauth":            {"exploitability": 6.0, "impact": 7.5,  "base_damage": 70000},
    # Medium — real but limited
    "xss":              {"exploitability": 7.5, "impact": 6.0,  "base_damage": 30000},
    "stored_xss":       {"exploitability": 8.0, "impact": 7.0,  "base_damage": 50000},
    "cors":             {"exploitability": 6.5, "impact": 6.0,  "base_damage": 25000},
    "redirect":         {"exploitability": 7.0, "impact": 5.5,  "base_damage": 20000},
    "crlf":             {"exploitability": 6.5, "impact": 5.5,  "base_damage": 15000},
    "prototype":        {"exploitability": 6.0, "impact": 6.5,  "base_damage": 30000},
    "race_condition":   {"exploitability": 6.0, "impact": 6.5,  "base_damage": 35000},
    "smuggling":        {"exploitability": 5.5, "impact": 7.0,  "base_damage": 40000},
    # Low — informational but real
    "expose":           {"exploitability": 8.0, "impact": 4.5,  "base_damage": 10000},
    "jsleak":           {"exploitability": 7.0, "impact": 4.0,  "base_damage": 8000},
    "actuator":         {"exploitability": 9.0, "impact": 5.0,  "base_damage": 15000},
    "panels":           {"exploitability": 8.5, "impact": 4.5,  "base_damage": 10000},
    "misconfig":        {"exploitability": 8.0, "impact": 4.0,  "base_damage": 8000},
    "graphql":          {"exploitability": 7.5, "impact": 5.0,  "base_damage": 12000},
    "nosqli":           {"exploitability": 7.0, "impact": 6.5,  "base_damage": 35000},
    "default":          {"exploitability": 5.0, "impact": 5.0,  "base_damage": 15000},
}

# ── Context modifiers ─────────────────────────────────────────────────────────
CONTEXT_MODIFIERS = {
    # URL pattern modifiers
    "admin":    1.5,   # admin panel = higher impact
    "payment":  2.0,   # payment endpoints = major financial risk
    "api":      1.2,   # API = more likely exploitable
    "login":    1.4,   # auth endpoints = ATO risk
    "export":   1.3,   # data export = data breach risk
    "upload":   1.3,   # file upload = RCE vector
    "internal": 1.4,   # internal endpoints = sensitive
    "prod":     1.3,   # production = real impact
    "v1":       0.9,   # old API versions
    # Severity modifiers
    "confirmed": 2.0,  # finding was verified
    "bypass":    1.5,  # bypass involved
    "critical":  1.5,  # already tagged critical
    "chain":     1.8,  # part of attack chain
}


def score_finding(finding: Dict, industry: str = "default",
                  chain_context: List[str] = None) -> Dict:
    """
    Score a single finding with full business context.
    Returns enriched finding with risk score, damage estimate, fix priority.
    """
    bug      = finding.get("bug", "default").lower()
    url      = finding.get("url", "")
    sev      = finding.get("severity", "medium").lower()
    desc     = finding.get("description", "")
    chain_context = chain_context or []

    # Base scores
    base = VULN_BASE_SCORES.get(bug, VULN_BASE_SCORES["default"])
    exploitability = base["exploitability"]
    impact         = base["impact"]
    base_damage    = base["base_damage"]

    # Apply industry multiplier
    ind = INDUSTRY_IMPACT.get(industry, INDUSTRY_IMPACT["default"])
    industry_mult = (ind["data_value"] + ind["regulatory"] + ind["reputation"]) / 9.0

    # Apply context modifiers from URL
    url_lower = url.lower()
    ctx_mult = 1.0
    for kw, mult in CONTEXT_MODIFIERS.items():
        if kw in url_lower or kw in desc.lower():
            ctx_mult = max(ctx_mult, mult)

    # Chain bonus — part of an exploit chain = higher real risk
    if chain_context:
        ctx_mult *= 1.3

    # Compute final risk score (0-100)
    raw_score = ((exploitability * 0.4 + impact * 0.6) / 10.0) * 100
    final_score = min(100, raw_score * industry_mult * ctx_mult)

    # Estimated financial damage
    est_damage = int(base_damage * industry_mult * ctx_mult)

    # Determine real severity (may differ from raw scanner severity)
    if final_score >= 85:   real_sev = "critical"
    elif final_score >= 65: real_sev = "high"
    elif final_score >= 40: real_sev = "medium"
    else:                   real_sev = "low"

    # Fix priority
    if real_sev == "critical": fix_priority = "P0 — Fix within 24 hours"
    elif real_sev == "high":   fix_priority = "P1 — Fix within 1 week"
    elif real_sev == "medium": fix_priority = "P2 — Fix within 1 month"
    else:                      fix_priority = "P3 — Fix in next sprint"

    # Business impact narrative
    impact_text = _build_impact_narrative(bug, url, industry, est_damage, chain_context)

    # Regulatory exposure
    regulatory = _check_regulatory_exposure(bug, industry)

    return {
        **finding,
        "risk_score":        round(final_score, 1),
        "severity":          real_sev,
        "exploitability":    round(exploitability, 1),
        "business_impact":   round(impact, 1),
        "estimated_damage":  f"${est_damage:,}",
        "fix_priority":      fix_priority,
        "impact_narrative":  impact_text,
        "regulatory_risk":   regulatory,
        "industry":          industry,
        "chain_context":     chain_context,
        "scored_at":         int(time.time()),
    }


def _build_impact_narrative(bug: str, url: str, industry: str,
                             damage: int, chain: List[str]) -> str:
    """Generate a business-readable impact statement."""
    narratives = {
        "rce": (f"An attacker can execute arbitrary code on the server, "
                f"gaining complete control of the system. All data, "
                f"credentials, and connected systems are at risk."),
        "sqli": (f"Database contents can be extracted, modified, or deleted. "
                 f"This includes user credentials, financial records, and "
                 f"all stored business data."),
        "ssrf": (f"Attackers can reach internal services not exposed to the internet, "
                 f"potentially accessing cloud metadata, internal APIs, and "
                 f"pivoting to other systems."),
        "lfi": (f"Sensitive files can be read from the server including configuration "
                f"files, credentials, SSH keys, and application source code."),
        "idor": (f"Any authenticated user can access data belonging to other users "
                 f"without authorization — a BOLA/IDOR flaw affecting all accounts."),
        "mass_assign": (f"API accepts unintended parameters, allowing users to escalate "
                        f"their own privileges or modify protected fields like pricing."),
        "cache_poison": (f"Cached responses can be poisoned with attacker-controlled "
                         f"content, affecting all users who receive the cached response."),
        "reset_poison": (f"Password reset links point to attacker-controlled domains, "
                         f"enabling full account takeover of targeted users."),
        "jwt": (f"Authentication tokens can be forged, allowing impersonation of "
                f"any user including administrators without knowing their credentials."),
        "buckets": (f"Cloud storage bucket is publicly accessible, exposing all "
                    f"stored files including backups, exports, and sensitive documents."),
        "xss": (f"Attackers can inject malicious scripts that execute in victim browsers, "
                f"enabling session theft, credential harvesting, and defacement."),
    }
    base = narratives.get(bug, f"This vulnerability allows unauthorized access to {url}.")

    if chain:
        base += f" This finding is part of a multi-step attack chain: {' → '.join(chain)}."

    if "payment" in url.lower() or industry == "fintech":
        base += f" Given payment processing context, estimated financial exposure: ${damage:,}."

    return base


def _check_regulatory_exposure(bug: str, industry: str) -> Dict:
    """Check which regulations this finding may violate."""
    exposure = {}

    data_bugs = {"sqli", "lfi", "ssrf", "idor", "xxe", "rce", "buckets",
                 "mass_assign", "jwt", "reset_poison"}

    if bug in data_bugs:
        if industry in ("healthcare",):
            exposure["HIPAA"] = "Potential PHI exposure — mandatory breach notification"
        if industry in ("fintech", "ecommerce"):
            exposure["PCI-DSS"] = "Cardholder data at risk — may require forensic audit"
        if industry in ("fintech", "healthcare", "saas", "enterprise"):
            exposure["GDPR"] = "Personal data exposure — 72-hour notification requirement, fines up to 4% revenue"
        exposure["SOC2"] = "Security control failure — may affect audit status"

    return exposure


def score_all_findings(findings: List[Dict], industry: str = "default",
                       chains: List[Dict] = None) -> Dict:
    """
    Score all findings for a domain scan.
    Returns scored findings + aggregate stats.
    """
    chains = chains or []

    # Build chain context map: url → chain names it appears in
    url_chains: Dict[str, List[str]] = {}
    for chain in chains:
        for step in chain.get("steps", []):
            url = step.get("url", "")
            if url:
                url_chains.setdefault(url, []).append(chain.get("name", "chain"))

    scored = []
    for f in findings:
        chain_ctx = url_chains.get(f.get("url", ""), [])
        scored.append(score_finding(f, industry, chain_ctx))

    # Aggregate stats
    if not scored:
        return {"findings": [], "stats": {}, "security_score": 100}

    total_score = sum(f["risk_score"] for f in scored)
    avg          = total_score / len(scored)

    by_sev = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    total_damage = 0
    for f in scored:
        by_sev[f["severity"]] = by_sev.get(f["severity"], 0) + 1
        dmg_str = f.get("estimated_damage", "$0").replace("$","").replace(",","")
        try: total_damage += int(dmg_str)
        except: pass

    # Security score: 100 = perfect, 0 = catastrophic
    security_score = max(0, int(100 - (
        by_sev["critical"] * 25 +
        by_sev["high"]     * 10 +
        by_sev["medium"]   *  3 +
        by_sev["low"]      *  1
    )))

    # Sort by risk score descending
    scored.sort(key=lambda x: -x["risk_score"])

    return {
        "findings":       scored,
        "security_score": security_score,
        "stats": {
            "total":          len(scored),
            "by_severity":    by_sev,
            "avg_risk_score": round(avg, 1),
            "total_damage_est": f"${total_damage:,}",
            "industry":       industry,
            "top_risks":      [f.get("bug","unknown") for f in scored[:5]],
        },
    }
