"""
BugScan ELITE — Subdomain Takeover Deep Engine
Extended fingerprints for: Azure, GitHub Pages, Fastly, AWS S3,
Heroku, Netlify, Surge, Cargo, Shopify, WP Engine, etc.
Also checks AAAA records pointing to unroutable IPv6.
"""
import re, time, socket, logging, urllib.request, ssl
from typing import List, Dict

log = logging.getLogger("elite.takeover_deep")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _req(url, timeout=8):
    try:
        req = urllib.request.Request(url, headers={"User-Agent":"Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status, r.read(8192).decode("utf-8","ignore")
    except urllib.error.HTTPError as e:
        try: return e.code, e.read(4096).decode("utf-8","ignore")
        except: return e.code, ""
    except: return None, ""

def _dns_cname(host):
    try:
        import dns.resolver
        ans = dns.resolver.resolve(host, "CNAME")
        return str(ans[0].target).rstrip(".")
    except: pass
    # Fallback: socket
    try:
        return socket.getfqdn(host)
    except: return None

def _dns_cname_raw(host):
    """Get CNAME via nslookup fallback."""
    import subprocess
    try:
        r = subprocess.run(["nslookup","-type=CNAME",host],
                          capture_output=True, text=True, timeout=5)
        m = re.search(r'canonical name\s*=\s*(\S+)', r.stdout, re.I)
        if m: return m.group(1).rstrip(".")
    except: pass
    return None

# Comprehensive fingerprint database
TAKEOVER_FINGERPRINTS = [
    # GitHub Pages
    ("github.io",           ["There isn't a GitHub Pages site here","For root URLs"], "GitHub Pages"),
    ("githubusercontent.com",["There isn't a GitHub Pages site here"],               "GitHub"),
    # Azure
    ("azurewebsites.net",   ["404 Web Site not found"],                               "Azure App Service"),
    ("cloudapp.azure.com",  ["No web app"],                                           "Azure"),
    ("azureedge.net",       ["ERR_CERT_COMMON_NAME_INVALID","404"],                   "Azure CDN"),
    ("trafficmanager.net",  ["404 Not Found"],                                        "Azure Traffic Manager"),
    ("blob.core.windows.net",["Sorry, there is no content here"],                     "Azure Blob"),
    # AWS
    ("s3.amazonaws.com",    ["NoSuchBucket","The specified bucket does not exist"],    "AWS S3"),
    ("s3-website",          ["NoSuchBucket","The specified bucket does not exist"],    "AWS S3 Website"),
    ("cloudfront.net",      ["Bad request","ERROR: The request could not be satisfied"],"AWS CloudFront"),
    ("elasticbeanstalk.com",["NXDOMAIN","404"],                                       "AWS Elastic Beanstalk"),
    # Heroku
    ("herokudns.com",       ["No such app","there's nothing here"],                   "Heroku"),
    ("herokuapp.com",       ["No such app","Application error"],                      "Heroku"),
    # Netlify
    ("netlify.app",         ["Not Found - Request ID","netlify"],                     "Netlify"),
    ("netlify.com",         ["Not Found - Request ID"],                               "Netlify"),
    # Vercel
    ("vercel.app",          ["The deployment you're looking for"],                    "Vercel"),
    # Fastly
    ("fastly.net",          ["Fastly error: unknown domain"],                         "Fastly"),
    # Shopify
    ("myshopify.com",       ["Sorry, this shop is currently unavailable"],            "Shopify"),
    # WordPress.com
    ("wordpress.com",       ["Do you want to register"],                              "WordPress.com"),
    ("wpenginepowered.com", ["This site can't be reached"],                           "WP Engine"),
    # Tumblr
    ("tumblr.com",          ["Whatever you were looking for doesn't currently exist"], "Tumblr"),
    # Ghost
    ("ghost.io",            ["The thing you were looking for is no longer here"],     "Ghost"),
    # Surge
    ("surge.sh",            ["project not found"],                                    "Surge"),
    # Cargo
    ("cargocollective.com", ["Page Not Found"],                                       "Cargo"),
    # Zendesk
    ("zendesk.com",         ["Help Center Closed"],                                   "Zendesk"),
    # Freshdesk
    ("freshdesk.com",       ["We could not find what you're looking for"],            "Freshdesk"),
    # Intercom
    ("intercom.io",         ["This page is reserved"],                                "Intercom"),
    # HubSpot
    ("hs-sites.com",        ["does not exist in our system"],                         "HubSpot"),
    ("hubspotpagebuilder.com",["does not exist in our system"],                       "HubSpot"),
    # Agile CRM
    ("agilecrm.com",        ["Sorry, this page is no longer available"],              "Agile CRM"),
    # Airee
    ("airee.ru",            ["Ошибка"],                                               "Airee"),
]

def check_takeover_deep(subs: List[str], targets: List[str]) -> List[Dict]:
    """Deep subdomain takeover check with extended fingerprints."""
    findings = []

    def F(sub, name, sev, details):
        return {"type":"takeover_deep","bug":"takeover","severity":sev,
                "url":f"https://{sub}","name":name,"details":details,
                "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ")}

    for sub in subs[:200]:
        if not sub or "." not in sub: continue

        # Try to get CNAME
        cname = None
        try:
            cname = socket.getfqdn(sub)
            if cname == sub: cname = None
        except: pass

        if not cname:
            cname = _dns_cname_raw(sub)

        # Check against fingerprint database
        if cname:
            cname_lower = cname.lower()
            for service_domain, fingerprints, service_name in TAKEOVER_FINGERPRINTS:
                if service_domain in cname_lower:
                    # Fetch the subdomain and check fingerprints
                    for scheme in ["https", "http"]:
                        status, body = _req(f"{scheme}://{sub}", timeout=8)
                        if status is None and scheme == "https":
                            continue
                        matched = [fp for fp in fingerprints
                                   if fp.lower() in (body or "").lower()]
                        if matched or status in (404,) and "NoSuchBucket" in (body or ""):
                            findings.append(F(sub,
                                f"Subdomain Takeover: {service_name} ({sub})", "critical", {
                                "subdomain":    sub,
                                "cname":        cname,
                                "service":      service_name,
                                "fingerprints": matched,
                                "http_status":  status,
                                "description": (
                                    f"{sub} points via CNAME to {cname} ({service_name}) "
                                    f"but the resource no longer exists and shows takeover fingerprints."
                                ),
                                "poc": (
                                    f"# Claim this subdomain:\n"
                                    f"# 1. Create account on {service_name}\n"
                                    f"# 2. Configure custom domain: {sub}\n"
                                    f"# 3. Host malicious content\n"
                                    f"# Verify: curl -H 'Host: {sub}' '{scheme}://{sub}'"
                                ),
                                "impact": (
                                    f"Full subdomain takeover — serve malicious content, "
                                    f"steal cookies scoped to *.{'.'.join(sub.split('.')[1:])}, "
                                    f"bypass CSP, host phishing pages under trusted domain."
                                ),
                                "remediation": "Remove dangling DNS record immediately. Implement DNS monitoring.",
                            }))
                            break
                    break  # found matching service, stop checking

        # ── NXDOMAIN dangling CNAME ───────────────────────────────────────────
        try:
            socket.gethostbyname(sub)
        except socket.gaierror as e:
            if "NXDOMAIN" in str(e) or "Name or service not known" in str(e):
                if cname and any(s in cname for s in
                    [".amazonaws.com",".azurewebsites.net",".github.io",
                     ".heroku",".netlify",".vercel",".surge.sh"]):
                    findings.append(F(sub,
                        f"Dangling CNAME → NXDOMAIN ({sub})", "critical", {
                        "subdomain": sub,
                        "cname": cname,
                        "description": f"{sub} has CNAME → {cname} but target resolves NXDOMAIN.",
                        "impact": "Claimable subdomain takeover.",
                        "remediation": "Remove DNS record for non-existent resource.",
                    }))
        except: pass

        # ── AAAA record pointing to unroutable IPv6 ───────────────────────────
        try:
            results = socket.getaddrinfo(sub, None, socket.AF_INET6)
            for r in results:
                ipv6 = r[4][0]
                # Unroutable/reserved IPv6 prefixes
                if (ipv6.startswith("::") or ipv6.startswith("fe80:") or
                    ipv6.startswith("fc") or ipv6.startswith("fd") or
                    ipv6 == "::1"):
                    findings.append(F(sub,
                        f"AAAA Record Points to Unroutable IPv6 ({sub})", "medium", {
                        "subdomain": sub,
                        "ipv6": ipv6,
                        "description": f"{sub} AAAA record points to unroutable IPv6 {ipv6}.",
                        "impact": "Potential DNS rebinding or misconfigured record.",
                        "remediation": "Fix IPv6 record or remove if not needed.",
                    }))
        except: pass

    log.info(f"[takeover_deep] {len(findings)} findings")
    return findings
