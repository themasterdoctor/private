import re
"""
TheMasterRecon AI — SQLite Storage Backend
Replaces JSON file storage with indexed SQLite for:
- 10-100x faster queries on large result sets
- Proper ACID transactions (no corruption on crash)  
- Concurrent read support
- Efficient finding deduplication
"""
import sqlite3, json, threading, logging, os
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional

log = logging.getLogger("elite.storage_sqlite")

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA cache_size=10000;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS domains (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    domain TEXT UNIQUE NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    last_scan  TEXT,
    meta       TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS subdomains (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    domain_id  INTEGER NOT NULL REFERENCES domains(id) ON DELETE CASCADE,
    subdomain  TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    UNIQUE(domain_id, subdomain)
);

CREATE TABLE IF NOT EXISTS live_hosts (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    domain_id  INTEGER NOT NULL REFERENCES domains(id) ON DELETE CASCADE,
    url        TEXT NOT NULL,
    status     INTEGER,
    title      TEXT,
    tech       TEXT DEFAULT '[]',
    ip         TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    UNIQUE(domain_id, url)
);

CREATE TABLE IF NOT EXISTS endpoints (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    domain_id  INTEGER NOT NULL REFERENCES domains(id) ON DELETE CASCADE,
    url        TEXT NOT NULL,
    method     TEXT DEFAULT 'GET',
    source     TEXT DEFAULT '',
    params     TEXT DEFAULT '[]',
    created_at TEXT DEFAULT (datetime('now')),
    UNIQUE(domain_id, url)
);

CREATE TABLE IF NOT EXISTS findings (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    domain_id    INTEGER NOT NULL REFERENCES domains(id) ON DELETE CASCADE,
    bug_type     TEXT NOT NULL,
    severity     TEXT NOT NULL,
    url          TEXT NOT NULL,
    title        TEXT,
    value        TEXT,
    poc          TEXT,
    impact       TEXT,
    remediation  TEXT,
    confidence   INTEGER DEFAULT 70,
    cwe          TEXT,
    cvss         REAL,
    confirmed    INTEGER DEFAULT 0,
    false_pos    INTEGER DEFAULT 0,
    raw_request  TEXT,    -- full HTTP request that triggered the finding
    raw_response TEXT,    -- full HTTP response that confirmed the finding
    xbow_data    TEXT,    -- JSON: XBOW grade, Mythos analysis, evidence score
    created_at   TEXT DEFAULT (datetime('now')),
    hash         TEXT UNIQUE  -- dedup: sha256(bug+url+value)
);

CREATE TABLE IF NOT EXISTS ports (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    domain_id INTEGER NOT NULL REFERENCES domains(id) ON DELETE CASCADE,
    host      TEXT NOT NULL,
    port      INTEGER NOT NULL,
    service   TEXT,
    banner    TEXT,
    UNIQUE(domain_id, host, port)
);

CREATE TABLE IF NOT EXISTS recon_steps (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    domain_id INTEGER NOT NULL REFERENCES domains(id) ON DELETE CASCADE,
    step      TEXT NOT NULL,
    state     TEXT NOT NULL,
    meta      TEXT,
    updated_at TEXT DEFAULT 0,  -- stored as Unix timestamp (int)
    UNIQUE(domain_id, step)
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_subdomains_domain    ON subdomains(domain_id);
CREATE INDEX IF NOT EXISTS idx_endpoints_domain     ON endpoints(domain_id);
CREATE INDEX IF NOT EXISTS idx_findings_domain      ON findings(domain_id);
CREATE INDEX IF NOT EXISTS idx_findings_severity    ON findings(severity);
CREATE INDEX IF NOT EXISTS idx_findings_bug         ON findings(bug_type);
CREATE INDEX IF NOT EXISTS idx_live_domain          ON live_hosts(domain_id);
-- Additional performance indexes
CREATE INDEX IF NOT EXISTS idx_findings_domain_sev  ON findings(domain_id, severity);
CREATE INDEX IF NOT EXISTS idx_findings_confirmed   ON findings(domain_id, confirmed);
CREATE INDEX IF NOT EXISTS idx_endpoints_source     ON endpoints(domain_id, source);
CREATE INDEX IF NOT EXISTS idx_findings_hash        ON findings(hash);
CREATE INDEX IF NOT EXISTS idx_ports_domain         ON ports(domain_id);
-- URL-level lookups: used by _confirm_finding(), dedup checks, finding detail pages
CREATE INDEX IF NOT EXISTS idx_findings_domain_url  ON findings(domain_id, url);
-- Bug+domain: used by scanner dedup and report aggregation
CREATE INDEX IF NOT EXISTS idx_findings_domain_bug  ON findings(domain_id, bug_type);
-- Recon step fast lookup by domain
CREATE INDEX IF NOT EXISTS idx_recon_steps_domain   ON recon_steps(domain_id);
"""


class StorageSQLite:
    """
    SQLite-backed storage replacing JSON file storage.
    Thread-safe via WAL mode + per-connection approach.
    """
    
    def __init__(self, data_dir: str):
        self.root = Path(data_dir)
        self.root.mkdir(parents=True, exist_ok=True)
        self.db_path = str(self.root / "bugscan.db")
        self._did_cache: dict = {}   # domain → id cache (in-process)
        self._local = threading.local()  # Per-thread connections
        self._init_db()
        
        # In-memory dedup sets (fast path)
        self._seen_ends  = {}  # {domain: set}
        self._seen_subs  = {}  # {domain: set}
        self._seen_ports = {}  # {domain: set}
        self._dedup_lock = threading.Lock()
    
    def _conn(self) -> sqlite3.Connection:
        """Get per-thread SQLite connection with WAL + busy_timeout for concurrent access."""
        if not hasattr(self._local, 'conn') or self._local.conn is None:
            conn = sqlite3.connect(self.db_path, timeout=5, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA busy_timeout=3000")   # 3s max wait, not 5s
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA foreign_keys=ON")
            conn.execute("PRAGMA busy_timeout=90000")   # 90s wait for write lock
            conn.execute("PRAGMA cache_size=20000")     # 80MB page cache
            # Migrate any old datetime-string updated_at values to Unix timestamps
            try:
                import time as _tmig
                _now = int(_tmig.time())
                conn.execute("""UPDATE recon_steps
                               SET updated_at = strftime('%s', updated_at)
                               WHERE updated_at GLOB '????-??-??*'""")
                conn.commit()
            except Exception:
                pass
            conn.execute("PRAGMA mmap_size=268435456")  # 256MB memory map
            conn.execute("PRAGMA wal_autocheckpoint=1000")  # checkpoint every 1000 pages
            self._local.conn = conn
        return self._local.conn
    
    def _init_db(self):
        """Initialize schema."""
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.executescript(SCHEMA)
        # Migration: add xbow_data column if this is an existing DB
        try:
            conn.execute("ALTER TABLE findings ADD COLUMN xbow_data TEXT")
            conn.commit()
        except Exception:
            pass  # column already exists
        conn.commit()
        conn.close()
        log.info(f"[storage] SQLite initialized: {self.db_path}")
    
    def _get_domain_id(self, domain: str, conn=None) -> int:
        """Get or create domain, return id. Cached in-process for speed."""
        # Fast path: check in-process cache (avoids SQL on every call)
        cached = self._did_cache.get(domain)
        if cached: return cached
        c = conn or self._conn()
        c.execute("INSERT OR IGNORE INTO domains(domain) VALUES(?)", (domain,))
        row = c.execute("SELECT id FROM domains WHERE domain=?", (domain,)).fetchone()
        did = row[0]
        self._did_cache[domain] = did   # cache for lifetime of process
        return did
    
    # ── Domain management ──────────────────────────────────────────────────
    
    def domain_exists(self, domain: str) -> bool:
        try:
            row = self._conn().execute(
                "SELECT id FROM domains WHERE domain=?", (domain,)).fetchone()
            return row is not None
        except: return False
    
    def list_domains(self) -> List[str]:
        try:
            rows = self._conn().execute(
                "SELECT domain FROM domains ORDER BY last_scan DESC").fetchall()
            return [r[0] for r in rows]
        except: return []
    
    def delete_domain(self, domain: str):
        try:
            conn = self._conn()
            conn.execute("DELETE FROM domains WHERE domain=?", (domain,))
            conn.commit()
            with self._dedup_lock:
                self._seen_ends.pop(domain, None)
                self._seen_subs.pop(domain, None)
                self._seen_ports.pop(domain, None)
        except Exception as e:
            log.error(f"[storage] delete_domain: {e}")
    
    # ── Subdomains ──────────────────────────────────────────────────────────
    
    def add_sub(self, domain: str, sub: str) -> bool:
        """Add subdomain, return True if new."""
        sub = sub.strip().lower()
        if not sub: return False
        with self._dedup_lock:
            if domain not in self._seen_subs:
                # Load existing from DB
                try:
                    did = self._get_domain_id(domain)
                    rows = self._conn().execute(
                        "SELECT subdomain FROM subdomains WHERE domain_id=?", (did,)).fetchall()
                    self._seen_subs[domain] = {r[0] for r in rows}
                except:
                    self._seen_subs[domain] = set()
            if sub in self._seen_subs[domain]:
                return False
            self._seen_subs[domain].add(sub)
        try:
            conn = self._conn()
            did  = self._get_domain_id(domain, conn)
            conn.execute("INSERT OR IGNORE INTO subdomains(domain_id,subdomain) VALUES(?,?)", (did, sub))
            conn.commit()
            return True
        except Exception as e:
            log.debug(f"[storage] add_sub: {e}")
            return False
    
    def get_subs(self, domain: str) -> List[str]:
        try:
            did  = self._get_domain_id(domain)
            rows = self._conn().execute(
                "SELECT subdomain FROM subdomains WHERE domain_id=? ORDER BY subdomain", (did,)).fetchall()
            return [r[0] for r in rows]
        except: return []
    
    def count_subs(self, domain: str) -> int:
        try:
            did = self._get_domain_id(domain)
            return self._conn().execute(
                "SELECT COUNT(*) FROM subdomains WHERE domain_id=?", (did,)).fetchone()[0]
        except: return 0
    
    # ── Live hosts ──────────────────────────────────────────────────────────
    
    def add_active(self, domain: str, url: str, status: int = 200,
                   title: str = "", tech: list = None, ip: str = ""):
        try:
            conn = self._conn()
            did  = self._get_domain_id(domain, conn)
            conn.execute("""INSERT INTO live_hosts(domain_id,url,status,title,tech,ip)
                           VALUES(?,?,?,?,?,?)
                           ON CONFLICT(domain_id,url) DO UPDATE SET
                           status=excluded.status, title=excluded.title,
                           tech=excluded.tech, ip=excluded.ip""",
                        (did, url, status, title or "", json.dumps(tech or []), ip or ""))
            conn.commit()
        except Exception as e:
            log.debug(f"[storage] add_active: {e}")
    
    def get_hosts(self, domain: str) -> Dict:
        try:
            did  = self._get_domain_id(domain)
            rows = self._conn().execute(
                "SELECT url,status,title,tech,ip FROM live_hosts WHERE domain_id=?", (did,)).fetchall()
            active = [r["url"] for r in rows]
            subs   = self.get_subs(domain)
            host_list = [{
                    "url":    r["url"],
                    "status": r["status"],
                    "title":  r["title"],
                    "tech":   json.loads(r["tech"] or "[]"),
                    "ip":     r["ip"],
                } for r in rows]
            return {
                "active": active,
                "subs":   subs,
                "active_count": len(active),
                "subs_count":   len(subs),
                "hosts":    host_list,
                "enriched": host_list,  # alias — frontend expects this key
            }
        except: return {"active": [], "subs": [], "active_count": 0, "subs_count": 0, "hosts": []}
    
    # ── Endpoints ──────────────────────────────────────────────────────────
    
    def add_endpoint(self, domain: str, url: str, method: str = "GET",
                     params: list = None, source: str = "") -> bool:
        url = url.strip()
        if not url: return False
        with self._dedup_lock:
            if domain not in self._seen_ends:
                try:
                    did  = self._get_domain_id(domain)
                    rows = self._conn().execute(
                        "SELECT url FROM endpoints WHERE domain_id=?", (did,)).fetchall()
                    # Cap at 50k to prevent OOM on large domains
                    self._seen_ends[domain] = {r[0] for r in rows[:50000]}
                except:
                    self._seen_ends[domain] = set()
            if url in self._seen_ends[domain]:
                return False
            self._seen_ends[domain].add(url)
        try:
            conn = self._conn()
            did  = self._get_domain_id(domain, conn)
            conn.execute(
                "INSERT OR IGNORE INTO endpoints(domain_id,url,method,params,source) VALUES(?,?,?,?,?)",
                (did, url, method, json.dumps(params or []), source or ""))
            conn.commit()
            return True
        except Exception as e:
            log.debug(f"[storage] add_endpoint: {e}")
            return False
    
    def get_endpoints(self, domain: str, limit: int = 10000, offset: int = 0,
                      with_source: bool = False) -> list:
        try:
            did  = self._get_domain_id(domain)
            if with_source:
                rows = self._conn().execute(
                    "SELECT url, COALESCE(source,'') FROM endpoints WHERE domain_id=? LIMIT ? OFFSET ?",
                    (did, limit, offset)).fetchall()
                return [{"url": r[0], "source": r[1]} for r in rows]
            rows = self._conn().execute(
                "SELECT url FROM endpoints WHERE domain_id=? LIMIT ? OFFSET ?",
                (did, limit, offset)).fetchall()
            return [r[0] for r in rows]
        except: return []
    
    def count_endpoints(self, domain: str) -> int:
        try:
            did = self._get_domain_id(domain)
            # Use fast read-only connection to avoid blocking under write lock
            try:
                conn = sqlite3.connect(self.db_path + "?mode=ro", 
                                       uri=True, timeout=3,
                                       check_same_thread=False)
                result = conn.execute(
                    "SELECT COUNT(*) FROM endpoints WHERE domain_id=?", (did,)
                ).fetchone()
                conn.close()
                return result[0] if result else 0
            except Exception:
                pass
            return self._conn().execute(
                "SELECT COUNT(*) FROM endpoints WHERE domain_id=?", (did,)).fetchone()[0]
        except: return 0
    
    # ── Findings ──────────────────────────────────────────────────────────
    
    def add_finding(self, domain: str, finding: Dict) -> bool:
        """Add finding with dedup by content hash."""
        import hashlib
        bug  = finding.get("bug", finding.get("bug_type", "unknown"))
        url  = finding.get("url", "")
        val  = finding.get("value", finding.get("poc", ""))[:200]
        h    = hashlib.sha256(f"{bug}:{url}:{val}".encode()).hexdigest()
        
        try:
            conn = self._conn()
            did  = self._get_domain_id(domain, conn)
            sev  = finding.get("severity", "medium").lower()
            # Normalize severity
            if sev not in ("critical","high","medium","low","info"):
                sev = "medium"
            
            import json as _j_xbow
            _xbow_fields = {k: v for k, v in finding.items() if k.startswith('_xbow') or k.startswith('_mythos')}
            _xbow_json = _j_xbow.dumps(_xbow_fields) if _xbow_fields else None
            conn.execute("""
                INSERT OR IGNORE INTO findings
                (domain_id, bug_type, severity, url, title, value, poc,
                 impact, remediation, confidence, cwe, cvss,
                 raw_request, raw_response, xbow_data, hash)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                did,
                bug, sev,
                url[:2000],
                finding.get("title", "")[:500],
                val[:500],
                finding.get("poc", "")[:2000],
                finding.get("impact", "")[:500],
                finding.get("remediation", "")[:500],
                int(finding.get("confidence", 70)),
                finding.get("cwe", ""),
                finding.get("cvss"),
                (finding.get("raw_request") or "")[:3000],
                (finding.get("raw_response") or "")[:3000],
                _xbow_json,
                h
            ))
            rows = conn.execute("SELECT changes()").fetchone()
            conn.commit()
            return rows[0] > 0  # True = new finding, False = dup
        except Exception as e:
            log.error(f"[storage] add_finding: {e}")
            return False
    
    def update_finding(self, domain: str, url: str, bug: str, patch: dict):
        """Patch fields on an existing finding (used by AI enhancement)."""
        try:
            did = self._get_domain_id(domain)
            if not did:
                return
            # Build SET clause from patch keys that are safe column names
            safe_keys = {k for k in patch if re.match(r'^[a-z_][a-z0-9_]*$', k)}
            if not safe_keys:
                return
            import json as _json
            # Store AI enhancements in existing or new fields
            with self._conn() as conn:
                for k, v in patch.items():
                    if k not in safe_keys:
                        continue
                    val = _json.dumps(v) if isinstance(v, (dict,list)) else v
                    try:
                        conn.execute(
                            f"UPDATE findings SET {k}=? WHERE domain_id=? AND url=? AND bug=?",
                            (val, did, url, bug)
                        )
                    except Exception:
                        pass  # column may not exist - that's ok
        except Exception as e:
            pass


    def mark_finding_status(self, domain: str, finding_id: str, status: str):
        """Set status field on a finding (confirmed / false_positive / new)."""
        try:
            did = self._get_domain_id(domain)
            if not did:
                return
            with self._conn() as conn:
                # Try by rowid first
                try:
                    fid_int = int(finding_id)
                    conn.execute("UPDATE findings SET status=? WHERE domain_id=? AND rowid=?",
                                 (status, did, fid_int))
                    return
                except (ValueError, Exception):
                    pass
                # Fallback: update all for domain (when no specific ID)
                conn.execute("UPDATE findings SET status=? WHERE domain_id=? AND (url=? OR bug=?)",
                             (status, did, finding_id, finding_id))
        except Exception as e:
            pass


    def get_findings(self, domain: str, severity: str = None,
                     bug_type: str = None, limit: int = 1000,
                     min_confidence: int = 0) -> List[Dict]:
        try:
            did  = self._get_domain_id(domain)
            q    = "SELECT * FROM findings WHERE domain_id=? AND false_pos=0"
            args = [did]
            if severity:
                q += " AND severity=?"; args.append(severity.lower())
            if bug_type:
                q += " AND bug_type=?"; args.append(bug_type)
            if min_confidence > 0:
                q += " AND confidence>=?"; args.append(min_confidence)
            q += " ORDER BY CASE severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 WHEN 'low' THEN 4 ELSE 5 END, confidence DESC, id DESC LIMIT ?"
            args.append(limit)
            rows = self._conn().execute(q, args).fetchall()
            result = []
            for row in rows:
                d = dict(row)
                # Unpack stored XBOW/Mythos data back into the finding dict
                xbow_json = d.pop("xbow_data", None)
                if xbow_json:
                    try:
                        import json as _j2
                        xbow_fields = _j2.loads(xbow_json)
                        d.update(xbow_fields)
                    except Exception:
                        pass
                result.append(d)
            return result
        except: return []
    
    def count_findings(self, domain: str, severity: str = None) -> int:
        try:
            did = self._get_domain_id(domain)
            q   = "SELECT COUNT(*) FROM findings WHERE domain_id=? AND false_pos=0"
            args= [did]
            if severity: q += " AND severity=?"; args.append(severity)
            return self._conn().execute(q, args).fetchone()[0]
        except: return 0
    
    def mark_false_positive(self, domain_or_id, finding_id=None):
        """Accept both mark_false_positive(domain, id) and mark_false_positive(id)"""
        try:
            # Handle both call signatures
            if finding_id is None:
                fid = domain_or_id  # old-style: just the id
            else:
                fid = finding_id    # new-style: (domain, id)
            conn = self._conn()
            conn.execute("UPDATE findings SET false_pos=1 WHERE id=?", (fid,))
            conn.commit()
            return True
        except: return False
    
    def mark_confirmed(self, finding_id: int):
        try:
            conn = self._conn()
            conn.execute("UPDATE findings SET confirmed=1 WHERE id=?", (finding_id,))
            conn.commit()
        except: pass
    
    # ── Ports ──────────────────────────────────────────────────────────────
    
    def add_port(self, domain: str, host: str, port=None,
                 service: str = "", banner: str = "") -> bool:
        # Support both: add_port(domain, "host:port") and add_port(domain, host, port)
        if port is None:
            # host is actually "host:port" string
            if ":" in str(host):
                parts = str(host).rsplit(":", 1)
                host, port = parts[0], int(parts[1])
            else:
                return False
        port = int(port)
        key = f"{host}:{port}"
        with self._dedup_lock:
            if domain not in self._seen_ports:
                self._seen_ports[domain] = set()
            if key in self._seen_ports[domain]: return False
            self._seen_ports[domain].add(key)
        try:
            conn = self._conn()
            did  = self._get_domain_id(domain, conn)
            conn.execute(
                "INSERT OR IGNORE INTO ports(domain_id,host,port,service,banner) VALUES(?,?,?,?,?)",
                (did, host, port, service or "", banner or ""))
            conn.commit()
            return True
        except Exception as e:
            log.debug(f"[storage] add_port: {e}")
            return False
    
    # ── Recon steps ────────────────────────────────────────────────────────
    
    def set_step(self, domain: str, step: str, state: str, meta: str = ""):
        try:
            import time as _t
            conn = self._conn()
            did  = self._get_domain_id(domain, conn)
            # Store as Unix timestamp (integer) so watchdog can compute age_seconds
            ts   = int(_t.time())
            conn.execute("""INSERT INTO recon_steps(domain_id,step,state,meta,updated_at)
                           VALUES(?,?,?,?,?)
                           ON CONFLICT(domain_id,step) DO UPDATE SET
                           state=excluded.state, meta=excluded.meta,
                           updated_at=excluded.updated_at""",
                        (did, step, state, meta or "", ts))
            conn.commit()
        except Exception as e:
            log.debug(f"[storage] set_step: {e}")

    def get_steps_full(self, domain: str) -> list:
        """Return full step rows including state, meta, updated_at."""
        try:
            did  = self._get_domain_id(domain)
            rows = self._conn().execute(
                "SELECT step,state,meta,updated_at FROM recon_steps WHERE domain_id=?",
                (did,)).fetchall()
            return [dict(r) for r in rows]
        except: return []

    def get_step(self, domain: str, step_name: str) -> Optional[Dict]:
        """Get a single step state for a domain. Returns None if not found."""
        try:
            dom_id = self._domain_id(domain)
            if not dom_id: return None
            row = self._conn.execute(
                "SELECT step,state,meta,updated_at FROM recon_steps WHERE domain_id=? AND step=?",
                (dom_id, step_name)
            ).fetchone()
            if row:
                return {"step": row[0], "state": row[1], "meta": row[2], "updated_at": row[3]}
            return None
        except Exception:
            return None

    def vacuum(self) -> None:
        """Run SQLite VACUUM to reclaim space from deleted rows."""
        try:
            self._conn.execute("VACUUM")
            log.info("[db] VACUUM completed")
        except Exception as e:
            log.debug(f"[db] VACUUM error: {e}")

    def get_steps(self, domain: str) -> Dict:
        try:
            did  = self._get_domain_id(domain)
            rows = self._conn().execute(
                "SELECT step,state,meta FROM recon_steps WHERE domain_id=?", (did,)).fetchall()
            return {r["step"]: r["state"] for r in rows}
        except: return {}
    
    # ── Tech / meta ────────────────────────────────────────────────────────
    
    def add_tech(self, domain: str, tech: str):
        pass  # Stored in live_hosts.tech column, queried via get_hosts
    
    def get_tech(self, domain: str) -> List[str]:
        """Read tech stack from DB. Uses short timeout — read-only query."""
        try:
            return self.get_tech_fast(domain)
        except Exception:
            return []

    def get_tech_fast(self, domain: str, timeout_ms: int = 500) -> List[str]:
        """Fast tech read — uses own read-only connection with short busy_timeout.
        Never waits for write lock. Returns [] if DB busy."""
        import sqlite3 as _sl
        try:
            conn = _sl.connect(str(self.db_path), timeout=0.5,
                               uri=False, check_same_thread=False)
            conn.execute(f"PRAGMA busy_timeout={timeout_ms}")
            conn.execute("PRAGMA query_only=ON")
            did_row = conn.execute(
                "SELECT id FROM domains WHERE domain=?", (domain,)).fetchone()
            if not did_row:
                conn.close()
                return []
            rows = conn.execute(
                "SELECT DISTINCT tech FROM live_hosts WHERE domain_id=? AND tech != '[]'",
                (did_row[0],)).fetchall()
            conn.close()
            techs: set = set()
            for r in rows:
                try:
                    for t in json.loads(r[0] or "[]"):
                        if t: techs.add(t)
                except Exception:
                    pass
            return sorted(techs)
        except Exception:
            return []
    
    # ── Compatibility shims ─────────────────────────────────────────────────
    # These match the interface of the original Storage class
    
    def add_sub_list(self, domain: str, subs: List[str]):
        for s in subs: self.add_sub(domain, s)
    
    def get_session_status(self, domain: str) -> Dict:
        try:
            did   = self._get_domain_id(domain)
            subs  = self.count_subs(domain)
            ends  = self.count_endpoints(domain)
            finds = self.count_findings(domain)
            crits = self.count_findings(domain, "critical")
            steps = self.get_steps(domain)
            return {
                "domain": domain,
                "subs_count":  subs,
                "ends_count":  ends,
                "finds_count": finds,
                "crit_count":  crits,
                "steps":       steps,
            }
        except: return {"domain": domain}
    
    def get_auth(self, domain: str) -> Dict:
        # Auth sessions stored separately in JSON for simplicity
        p = self.root / domain.replace("/","_").replace(":","_") / "auth.json"
        if p.exists():
            try: return json.loads(p.read_text())
            except: pass
        return {}
    
    def save_auth(self, domain: str, auth: Dict):
        dd = self.root / domain.replace("/","_").replace(":","_")
        dd.mkdir(exist_ok=True)
        p  = dd / "auth.json"
        p.write_text(json.dumps(auth, indent=2))
    
    def get_waf(self, domain: str) -> Dict:
        p = self.root / domain.replace("/","_").replace(":","_") / "waf.json"
        if p.exists():
            try: return json.loads(p.read_text())
            except: pass
        return {}
    
    def save_waf(self, domain: str, waf: Dict):
        dd = self.root / domain.replace("/","_").replace(":","_")
        dd.mkdir(exist_ok=True)
        (dd / "waf.json").write_text(json.dumps(waf, indent=2))
    
    def get_scope(self, domain: str) -> List[str]:
        return []
    
    def save_scope(self, domain: str, scope: List[str]):
        pass
    
    def export_json(self, domain: str) -> Dict:
        return {
            "domain":    domain,
            "findings":  self.get_findings(domain),
            "hosts":     self.get_hosts(domain),
            "endpoints": self.get_endpoints(domain, limit=5000),
        }


    # ── Compatibility shims for methods missing from StorageSQLite ────────────

    def _dd(self, domain: str):
        d = self.root / domain.replace("/","_").replace(":","_")
        d.mkdir(exist_ok=True)
        return d

    def _rj(self, p, default=None):
        from pathlib import Path as _P
        p = _P(p)
        if not p.exists(): return default
        try: return json.loads(p.read_text())
        except: return default

    def _wj(self, p, data):
        from pathlib import Path as _P
        p = _P(p)
        tmp = p.with_suffix('.tmp')
        try:
            tmp.write_text(json.dumps(data, indent=2))
            tmp.replace(p)
        except Exception:
            try: tmp.unlink()
            except: pass

    def save_meta(self, domain: str, extra: dict):
        from datetime import datetime as _dt
        p = self._dd(domain) / "meta.json"
        cur = self._rj(p, {})
        cur.update(extra)
        if "started" not in cur:
            cur["started"] = _dt.utcnow().isoformat()
        self._wj(p, cur)

    def get_meta(self, domain: str) -> dict:
        return self._rj(self._dd(domain) / "meta.json", {})

    def save_chains(self, domain: str, chains: list):
        self._wj(self._dd(domain) / "chains.json", chains)

    def get_chains(self, domain: str) -> list:
        return self._rj(self._dd(domain) / "chains.json", [])

    def save_enrich(self, domain: str, data: dict):
        # Write to enriched.json for fast access
        p = self._dd(domain) / "enriched.json"
        cur = self._rj(p, {})
        cur[data.get("url", "")] = data
        self._wj(p, cur)
        # ALSO update live_hosts SQLite table so get_hosts() returns rich data
        url    = data.get("url", "")
        status = data.get("status", 0) or 0
        title  = data.get("title", "") or ""
        ip     = data.get("ip", "") or ""
        tech   = data.get("tech", []) or []
        if not url:
            return
        try:
            import json as _json
            conn = self._conn()
            did  = self._get_domain_id(domain, conn)
            # Update if exists, insert if not
            conn.execute("""INSERT INTO live_hosts(domain_id,url,status,title,tech,ip)
                           VALUES(?,?,?,?,?,?)
                           ON CONFLICT(domain_id,url) DO UPDATE SET
                           status=excluded.status,
                           title=excluded.title,
                           tech=excluded.tech,
                           ip=excluded.ip""",
                        (did, url, status, title, _json.dumps(tech), ip))
            conn.commit()
        except Exception:
            pass

    def get_enrich(self, domain: str) -> dict:
        return self._rj(self._dd(domain) / "enriched.json", {})

    def save_js_analysis(self, domain: str, results):
        self._wj(self._dd(domain) / "js_analysis.json", results)

    def get_js_analysis(self, domain: str):
        return self._rj(self._dd(domain) / "js_analysis.json", [])

    def save_report(self, domain: str, report):
        """Accept str (markdown) or dict (JSON report)"""
        import json as _json
        p = self._dd(domain)
        if isinstance(report, dict):
            (p / "report.json").write_text(_json.dumps(report, indent=2), encoding="utf-8")
            # Also write a markdown summary
            md = f"# Report: {domain}\n\n"
            for k, v in report.items():
                md += f"## {k}\n{v}\n\n"
            (p / "report.md").write_text(md, encoding="utf-8")
        else:
            (p / "report.md").write_text(str(report), encoding="utf-8")

    def get_report(self, domain: str) -> dict:
        """Return report as dict (from JSON) or wrapped string (from MD)"""
        import json as _json
        d = self._dd(domain)
        # Prefer JSON format
        pj = d / "report.json"
        if pj.exists():
            try: return _json.loads(pj.read_text(encoding="utf-8"))
            except: pass
        # Fall back to markdown
        pm = d / "report.md"
        if pm.exists():
            return {"content": pm.read_text(encoding="utf-8"), "format": "markdown"}
        return {}

    def save_screenshots(self, domain: str, results):
        self._wj(self._dd(domain) / "screenshots.json", results)

    def get_screenshots(self, domain: str) -> list:
        return self._rj(self._dd(domain) / "screenshots.json", [])

    def save_findings(self, domain: str, findings: list):
        try:
            conn = self._conn()
            did  = self._get_domain_id(domain)
            conn.execute("DELETE FROM findings WHERE domain_id=?", (did,))
            conn.commit()
            for f in findings:
                self.add_finding(domain, f)
        except Exception as e:
            log.error(f"[storage] save_findings: {e}")

    def delete_all(self):
        import shutil as _sh
        try:
            conn = self._conn()
            for tbl in ["findings","endpoints","subdomains","live_hosts","ports","recon_steps","domains"]:
                conn.execute(f"DELETE FROM {tbl}")
            conn.commit()
        except Exception as e:
            log.error(f"[storage] delete_all: {e}")
        for dd in self.root.iterdir():
            if dd.is_dir():
                try: _sh.rmtree(dd)
                except: pass
        with self._dedup_lock:
            self._seen_ends.clear()
            self._seen_subs.clear()
            self._seen_ports.clear()


    # ── Audit log ───────────────────────────────────────────
    def get_audit_log(self, domain: str = "", limit: int = 100) -> list:
        try:
            q = "SELECT * FROM audit_log ORDER BY ts DESC LIMIT ?"
            rows = self._conn().execute(q, (limit,)).fetchall()
            return [dict(r) for r in rows]
        except Exception:
            return []

    # ── Finding collaboration ───────────────────────────────
    def assign_finding(self, domain: str, finding_id: str, assignee: str) -> bool:
        try:
            self._conn().execute(
                "UPDATE findings SET assignee=? WHERE domain_id=? AND id=?",
                (assignee, self._get_domain_id(domain), finding_id))
            return True
        except Exception:
            return False

    def add_comment(self, domain: str, finding_id: str, user: str, text: str) -> bool:
        try:
            import time, json as _json
            p = self._dd(domain) / "comments.json"
            cur = self._rj(p, {})
            if finding_id not in cur:
                cur[finding_id] = []
            cur[finding_id].append({"user": user, "text": text, "ts": time.time()})
            self._wj(p, cur)
            return True
        except Exception:
            return False

    def get_comments(self, domain: str, finding_id: str) -> list:
        try:
            p = self._dd(domain) / "comments.json"
            return self._rj(p, {}).get(finding_id, [])
        except Exception:
            return []

    def update_finding_status(self, domain: str, finding_id: str, status: str) -> bool:
        try:
            self._conn().execute(
                "UPDATE findings SET status=? WHERE domain_id=? AND id=?",
                (status, self._get_domain_id(domain), finding_id))
            return True
        except Exception:
            return False

    # ── Notes ───────────────────────────────────────────────
    def save_note(self, domain: str, note: str) -> bool:
        try:
            p = self._dd(domain) / "notes.json"
            import time
            cur = self._rj(p, [])
            if isinstance(cur, list):
                cur.append({"text": note, "ts": time.time()})
            else:
                cur = [{"text": note, "ts": time.time()}]
            self._wj(p, cur)
            return True
        except Exception:
            return False

    def get_notes(self, domain: str) -> list:
        try:
            p = self._dd(domain) / "notes.json"
            return self._rj(p, [])
        except Exception:
            return []

    # ── User management (delegates to RBAC) ────────────────
    def list_users(self) -> list:
        try:
            from engine.rbac import list_users as _lu
            return _lu()
        except Exception:
            return []

    def create_user(self, username: str, password: str, role: str = "viewer") -> bool:
        try:
            from engine.rbac import create_user as _cu
            return _cu(username, password, role)
        except Exception:
            return False

    def update_user(self, username: str, **kwargs) -> bool:
        try:
            from engine.rbac import update_user as _uu
            return _uu(username, **kwargs)
        except Exception:
            return False

    def delete_user(self, username: str) -> bool:
        try:
            from engine.rbac import delete_user as _du
            return _du(username)
        except Exception:
            return False

    def get_active_sessions(self) -> list:
        try:
            from engine.rbac import get_sessions as _gs
            return _gs()
        except Exception:
            return []

    # ── Workspaces ──────────────────────────────────────────
    def get_workspaces(self) -> list:
        try:
            p = self._root / "workspaces.json"
            return self._rj(p, [])
        except Exception:
            return []

    def create_workspace(self, name: str, owner: str) -> dict:
        try:
            import time, uuid
            ws = {"id": str(uuid.uuid4())[:8], "name": name, "owner": owner,
                  "members": [owner], "created": time.time()}
            p = self._root / "workspaces.json"
            cur = self._rj(p, [])
            cur.append(ws)
            self._wj(p, cur)
            return ws
        except Exception:
            return {}

    def add_member(self, ws_id: str, username: str) -> bool:
        try:
            p = self._root / "workspaces.json"
            cur = self._rj(p, [])
            for ws in cur:
                if ws.get("id") == ws_id:
                    if username not in ws.get("members", []):
                        ws.setdefault("members", []).append(username)
            self._wj(p, cur)
            return True
        except Exception:
            return False

