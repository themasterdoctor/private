"""
TheMasterRecon AI — Live AI Intelligence During Recon
Emits contextual AI tips as the scan progresses.
No blocking — all AI calls are async/background.
"""
import os, re, json, logging, threading, time
from typing import List, Dict, Optional

log     = logging.getLogger("elite.ai_recon")
API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL   = "claude-sonnet-4-5"

# ── Tech → CVE mapping (instant, no API needed) ────────────────────────────
TECH_CVE_MAP = {
    # Web servers
    "apache":        [("CVE-2021-41773","critical","Apache 2.4.49 Path Traversal RCE — check /cgi-bin/"),
                      ("CVE-2021-42013","critical","Apache 2.4.49-50 RCE via mod_cgi"),
                      ("CVE-2017-7679","high","Apache mod_mime buffer overflow")],
    "nginx":         [("CVE-2021-23017","critical","nginx DNS resolver 1-byte OOB write"),
                      ("CVE-2019-9511","high","HTTP/2 DoS — Data Dribble"),
                      ("CVE-2019-9513","high","HTTP/2 Resource Loop DoS")],
    "iis":           [("CVE-2021-31166","critical","IIS HTTP Protocol Stack RCE"),
                      ("CVE-2022-21907","critical","HTTP Protocol Stack RCE")],
    "tomcat":        [("CVE-2020-1938","critical","Ghostcat — AJP file read/RCE"),
                      ("CVE-2019-0232","critical","Remote code exec via CGI Servlet"),
                      ("CVE-2017-12617","high","JSP upload via PUT")],
    "spring":        [("CVE-2022-22965","critical","Spring4Shell — RCE via data binding"),
                      ("CVE-2022-22963","critical","Spring Cloud RCE via routing expressions"),
                      ("CVE-2021-22053","high","Spring Data MongoDB RCE")],
    "struts":        [("CVE-2017-5638","critical","Struts2 RCE — Content-Type header"),
                      ("CVE-2018-11776","critical","Struts2 RCE — no namespace"),
                      ("CVE-2019-0230","critical","Struts2 OGNL RCE")],
    "wordpress":     [("CVE-2022-21661","critical","WordPress SQLi via WP_Query"),
                      ("CVE-2021-29447","high","WordPress XXE via Media Library"),
                      ("CVE-2020-28032","high","WordPress PHP object injection")],
    "drupal":        [("CVE-2018-7600","critical","Drupalgeddon2 — unauthenticated RCE"),
                      ("CVE-2019-6340","critical","Drupal RCE via REST API")],
    "joomla":        [("CVE-2015-8562","critical","Joomla RCE via session data"),
                      ("CVE-2021-23132","high","Joomla com_media path traversal")],
    "log4j":         [("CVE-2021-44228","critical","Log4Shell — JNDI injection RCE"),
                      ("CVE-2021-45046","critical","Log4j2 JNDI injection bypass")],
    "php":           [("CVE-2021-21705","high","PHP SSRF via SoapClient"),
                      ("CVE-2019-11043","critical","PHP-FPM RCE via nginx misconfig")],
    "java":          [("CVE-2021-44228","critical","Log4Shell if log4j present"),
                      ("CVE-2015-4852","critical","Java deserialization via Commons Collections")],
    "jenkins":       [("CVE-2019-1003000","critical","Jenkins RCE via Script Security bypass"),
                      ("CVE-2018-1000861","critical","Jenkins RCE unauthenticated")],
    "confluence":    [("CVE-2022-26134","critical","Confluence OGNL RCE — unauthenticated"),
                      ("CVE-2021-26084","critical","Confluence WebWork RCE")],
    "jira":          [("CVE-2022-0540","critical","Jira auth bypass via Seraph"),
                      ("CVE-2019-8449","high","Jira user enumeration")],
    "gitlab":        [("CVE-2021-22205","critical","GitLab RCE via ExifTool"),
                      ("CVE-2022-2185","critical","GitLab RCE via project import")],
    "redis":         [("CVE-2022-0543","critical","Redis Lua sandbox escape"),
                      ("redis-unauth","high","Redis exposed without authentication")],
    "elasticsearch": [("CVE-2015-1427","critical","Groovy sandbox escape RCE"),
                      ("es-unauth","high","Elasticsearch unauthenticated access")],
    "grafana":       [("CVE-2021-43798","critical","Grafana path traversal — read files"),
                      ("CVE-2022-21703","high","Grafana CSRF")],
    "nextjs":        [("CVE-2024-34351","high","Next.js SSRF via Host header"),
                      ("CVE-2024-46982","high","Next.js cache poisoning")],
    "node":          [("CVE-2021-44906","high","Node.js prototype pollution via minimist"),
                      ("CVE-2022-25878","high","Prototype pollution in protobufjs")],
    "react":         [("react-dangerouslySetInnerHTML","medium","Check for XSS via dangerouslySetInnerHTML")],
    "angular":       [("angular-template-injection","high","Angular template injection via $interpolate")],
    "laravel":       [("CVE-2021-3129","critical","Laravel RCE via debug mode + Ignition"),
                      ("CVE-2018-15133","critical","Laravel token unserialize RCE")],
    "rails":         [("CVE-2019-5420","critical","Rails RCE via development mode"),
                      ("CVE-2022-32224","critical","Rails Active Record SQLi")],
    "django":        [("CVE-2021-35042","critical","Django QuerySet RCE via column name"),
                      ("CVE-2022-28346","critical","Django SQLi via QuerySet.annotate()")],
    "graphql":       [("graphql-introspection","medium","Check: POST /{__schema} — introspection enabled"),
                      ("graphql-batching","medium","Batching attack for auth bypass"),
                      ("graphql-idor","high","IDOR via GraphQL object ID manipulation")],
    "aws":           [("aws-metadata","critical","Test: http://169.254.169.254/latest/meta-data/"),
                      ("aws-s3-acl","high","S3 bucket misconfiguration — public access")],
    "kubernetes":    [("k8s-api-unauth","critical","Kubernetes API server unauthenticated"),
                      ("CVE-2018-1002105","critical","Kubernetes privilege escalation")],
    "docker":        [("docker-api","critical","Docker daemon API exposed on port 2375/2376"),
                      ("CVE-2019-5736","critical","Docker runc container escape")],
}

def get_tech_cves(tech_list: List[str]) -> List[Dict]:
    """
    Instantly match detected technologies to known CVEs.
    No API needed — pure local lookup.
    Returns list of {cve, severity, description, tech} dicts.
    """
    results = []
    seen = set()
    for tech in tech_list:
        tech_lower = tech.lower().strip()
        for key, cves in TECH_CVE_MAP.items():
            if key in tech_lower or tech_lower in key:
                for cve_id, sev, desc in cves:
                    if cve_id not in seen:
                        seen.add(cve_id)
                        results.append({
                            "cve": cve_id, "severity": sev,
                            "description": desc, "tech": tech,
                        })
    # Sort critical first
    results.sort(key=lambda x: 0 if x["severity"]=="critical" else 1)
    return results


def generate_recon_tip(event_type: str, data: dict) -> Optional[str]:
    """
    Generate a contextual AI tip for a recon event.
    Fast path: returns None if no API key.
    Background path: calls Claude for rich context.
    """
    if not API_KEY:
        return _local_tip(event_type, data)
    return _local_tip(event_type, data)  # Always use local for speed


def _local_tip(event_type: str, data: dict) -> Optional[str]:
    """Rule-based tips that don't need API (instant)."""
    if event_type == "tech_detected":
        tech_list = data.get("tech", [])
        cves = get_tech_cves(tech_list)
        if cves:
            top = cves[0]
            sev_emoji = "🔴" if top["severity"]=="critical" else "🟠"
            return f"{sev_emoji} {top['tech']} detected → {top['cve']}: {top['description']}"

    elif event_type == "subdomain_count":
        count = data.get("count", 0)
        if count > 1000:
            return f"🌐 {count:,} subdomains — focus on: dev.*, api.*, admin.*, internal.*, staging.*"
        elif count > 100:
            return f"🌐 {count} subdomains — look for forgotten dev/staging environments"

    elif event_type == "endpoint_count":
        count = data.get("count", 0)
        if count > 5000:
            return f"🔗 {count:,} endpoints — large attack surface. Prioritize: /api/*, /admin/*, /upload/*"

    elif event_type == "js_files":
        count = data.get("count", 0)
        if count > 100:
            return f"📜 {count} JS files — running secret + endpoint extraction"

    elif event_type == "live_host":
        url = data.get("url", "")
        tech = data.get("tech", [])
        title = data.get("title", "")
        tips = []
        if any(t in " ".join(tech).lower() for t in ["jenkins","grafana","kibana","sonarqube"]):
            tips.append(f"🎯 {' '.join(tech[:2])} — check default credentials + CVEs")
        if any(k in url.lower() for k in [".git","/.env","backup","staging","dev"]):
            tips.append(f"⚠️  Sensitive path in URL: {url}")
        if tips:
            return tips[0]

    elif event_type == "port_open":
        port = data.get("port", 0)
        port_tips = {
            6379: "🔴 Redis on port 6379 — test unauthenticated access",
            27017: "🔴 MongoDB on 27017 — test unauthenticated access",
            9200: "🔴 Elasticsearch on 9200 — test unauthenticated access",
            8080: "🟠 Port 8080 — check for Tomcat manager, Jenkins",
            8443: "🟠 Port 8443 — check for admin panels",
            2375: "🔴 Docker API on 2375 — unauthenticated access!",
            5432: "🟠 PostgreSQL on 5432 — test creds: postgres/postgres",
            3306: "🟠 MySQL on 3306 — test creds: root/root, root/''",
        }
        if port in port_tips:
            return port_tips[port]

    return None


def ai_suggest_next(domain: str, findings: list, tech: list,
                    endpoints_count: int) -> str:
    """
    'What should I scan next?' — AI recommendation.
    Uses Claude if API key present, otherwise rule-based.
    """
    if API_KEY:
        return _claude_suggest_next(domain, findings, tech, endpoints_count)
    return _local_suggest_next(findings, tech)


def _local_suggest_next(findings: list, tech: list) -> str:
    """Rule-based next-scan recommendation."""
    recs = []

    # Tech-based recommendations
    tech_str = " ".join(tech).lower()
    if "wordpress" in tech_str:
        recs.append("Run: wpscan --url {domain} --enumerate ap,at,u --api-token YOUR_KEY")
    if "java" in tech_str or "spring" in tech_str or "tomcat" in tech_str:
        recs.append("Test: Log4Shell — send JNDI payload to all headers")
        recs.append("Test: Java deserialization — run ysoserial against Java endpoints")
    if "graphql" in tech_str:
        recs.append("Test: GraphQL introspection, batching attack, field suggestion")
    if "aws" in tech_str or "s3" in tech_str:
        recs.append("Run: aws s3 ls s3://{domain} --no-sign-request")

    # Finding-based recommendations
    crits = [f for f in findings if f.get("severity")=="critical"]
    highs = [f for f in findings if f.get("severity")=="high"]

    if crits:
        top = crits[0]
        recs.insert(0, f"🔴 ESCALATE: {top.get('bug','').upper()} @ {top.get('url','')[:60]} — submit now")

    if not recs:
        recs = [
            "Run full XSS scan on all parametrized endpoints",
            "Check admin panels for default credentials",
            "Test all file upload endpoints for arbitrary upload",
            "Run sqlmap on endpoints with error-based SQLi indicators",
        ]

    return "\n".join(f"→ {r}" for r in recs[:5])


def _claude_suggest_next(domain: str, findings: list, tech: list,
                         endpoints_count: int) -> str:
    """Claude-powered next scan recommendation."""
    import ssl, urllib.request
    crits = [f for f in findings if f.get("severity")=="critical"]
    highs = [f for f in findings if f.get("severity")=="high"]

    prompt = f"""Target: {domain}
Tech: {', '.join(tech[:10])}
Endpoints: {endpoints_count}
Critical findings: {len(crits)}
High findings: {len(highs)}
Top findings:
{chr(10).join(f"  [{f.get('severity','').upper()}] {f.get('bug','').upper()} @ {f.get('url','')[:60]}" for f in (crits+highs)[:5])}

In 3-5 bullet points: what should the security researcher test NEXT to maximize impact?
Be specific: exact commands, exact attack vectors, exact URLs from the data above."""

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        body = json.dumps({
            "model": MODEL, "max_tokens": 400,
            "messages": [{"role":"user","content":prompt}]
        }).encode()
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=body,
            headers={"Content-Type":"application/json",
                     "x-api-key": API_KEY,
                     "anthropic-version":"2023-06-01"})
        with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
            data = json.loads(r.read())
            return data["content"][0]["text"]
    except Exception as e:
        log.debug(f"[ai_recon] claude call failed: {e}")
        return _local_suggest_next(findings, tech)


def format_h1_submission(finding: dict, domain: str) -> str:
    """Format a finding as HackerOne submission (AI-enhanced or template)."""
    bug    = finding.get("bug","").upper()
    sev    = finding.get("severity","medium").capitalize()
    url    = finding.get("url","")
    poc    = finding.get("poc","")
    impact = finding.get("impact","")
    title  = finding.get("title","")

    sev_map = {"Critical":"P1","High":"P2","Medium":"P3","Low":"P4","Info":"N/A"}
    priority = sev_map.get(sev,"P3")

    if API_KEY:
        return _claude_h1_format(finding, domain)

    return f"""**Title:** {title or bug + ' vulnerability in ' + domain}
**Severity:** {sev} ({priority})

## Summary
{impact or f'A {bug} vulnerability was discovered at {url} that allows an attacker to...'}

## Steps to Reproduce
1. Navigate to: `{url}`
2. {poc or f'Send the following request...'}

## Impact
{impact or f'An attacker can exploit this {bug} vulnerability to...'}

## Supporting Material
- **URL:** `{url}`
- **Evidence:** {poc[:200] if poc else 'See attached screenshots'}

## Recommendations
- Implement proper input validation
- Apply the principle of least privilege
- Review related endpoints for the same issue
"""


def _claude_h1_format(finding: dict, domain: str) -> str:
    """Claude writes the HackerOne report."""
    import ssl, urllib.request
    prompt = f"""Write a professional HackerOne bug report for this finding:
Bug type: {finding.get('bug','').upper()}
Severity: {finding.get('severity','medium')}
URL: {finding.get('url','')}
PoC: {finding.get('poc','')[:300]}
Impact: {finding.get('impact','')}
Target: {domain}

Format: HackerOne markdown. Include title, summary, steps to reproduce, impact, recommendations.
Be specific and technical. Write as an experienced bug bounty hunter."""

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        body = json.dumps({
            "model": MODEL, "max_tokens": 800,
            "messages": [{"role":"user","content":prompt}]
        }).encode()
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=body,
            headers={"Content-Type":"application/json",
                     "x-api-key": API_KEY,
                     "anthropic-version":"2023-06-01"})
        with urllib.request.urlopen(req, timeout=20, context=ctx) as r:
            data = json.loads(r.read())
            return data["content"][0]["text"]
    except Exception as e:
        log.debug(f"[ai_recon] h1 format failed: {e}")
        return format_h1_submission(finding, domain)
