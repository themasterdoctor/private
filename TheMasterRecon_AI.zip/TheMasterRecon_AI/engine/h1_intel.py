"""
TheMasterRecon AI — H1 Intelligence Engine v2
Replaces raw frequency counting with multi-factor confidence scoring.
Adds: context extraction, HTTP method detection, auth context, surface classification,
program/tech correlation, risk hotspots, parameter→bug mapping, recommendations.

All queries return scored results. No heuristic is hidden — every score component
is exposed so callers can understand and tune weighting.
"""
from __future__ import annotations

import json, logging, math, re, time
from typing import Any, Dict, List, Optional, Tuple
from pathlib import Path

log = logging.getLogger("elite.h1_intel")

# ── Severity numeric weights ───────────────────────────────────────────────────
_SEV_WEIGHT = {"critical": 1.0, "high": 0.75, "medium": 0.45, "low": 0.15, "none": 0.0}

# ── Bug type certainty — how cleanly H1 weakness maps to this type ─────────────
_BUG_CERTAINTY = {
    "xss":    0.90, "sqli":   0.95, "ssrf":   0.92, "rce":    0.95,
    "idor":   0.85, "lfi":    0.88, "xxe":    0.92, "ssti":   0.90,
    "csrf":   0.80, "cors":   0.78, "redirect":0.72,"takeover":0.88,
    "jwt":    0.75, "graphql":0.80, "smuggling":0.85,"race":   0.70,
    "fileupload":0.82,"nosqli":0.80,"crlf":   0.75, "logic":  0.60,
    "misconfig":0.65,"other": 0.40,
}

# ── Surface classification keywords ────────────────────────────────────────────
_SURFACE_PATTERNS = {
    "graphql":  ["/graphql", "introspection", "__schema", "query {", "mutation {"],
    "api":      ["/api/", "/v1/", "/v2/", "/v3/", "/rest/", "/rpc/"],
    "admin":    ["/admin", "/dashboard", "/manage", "/console", "/internal", "/debug"],
    "auth":     ["/auth", "/login", "/oauth", "/token", "/sso", "/saml", "/oidc"],
    "upload":   ["/upload", "/import", "/file", "multipart", "Content-Disposition"],
    "webhook":  ["/webhook", "/callback", "/notify", "/hook"],
    "export":   ["/export", "/download", "/report", "/csv", "/pdf"],
    "mobile":   ["android", "ios", "mobile", "app-version", "x-platform"],
}

# ── HTTP method extraction ─────────────────────────────────────────────────────
_METHOD_RE = re.compile(
    r'\b(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+([/\w\-\.%?&={}:]+)',
    re.I,
)

# ── Auth context patterns ──────────────────────────────────────────────────────
_AUTH_PATTERNS = [
    (r'authorization[:\s]+bearer', "bearer"),
    (r'cookie[:\s]+session', "session_cookie"),
    (r'api[_-]?key', "api_key"),
    (r'x-auth-token', "x_auth_token"),
    (r'without auth|unauthenticated|no auth|anonymous|no login', "none"),
    (r'logged.?in|authenticated|requires auth|with.?session', "required"),
]
_AUTH_RE = [(re.compile(p, re.I), label) for p, label in _AUTH_PATTERNS]

# ── Parameter→bug mapping (used for param risk scoring) ─────────────────────
PARAM_BUG_MAP: Dict[str, List[str]] = {
    # SSRF
    "url":          ["ssrf", "redirect"], "callback":    ["ssrf"],
    "redirect":     ["ssrf", "redirect"], "webhook":     ["ssrf"],
    "endpoint":     ["ssrf"], "fetch":        ["ssrf"],
    "proxy":        ["ssrf"], "src":          ["ssrf", "lfi"],
    "uri":          ["ssrf"], "link":         ["ssrf", "redirect"],
    "feed":         ["ssrf"], "image":        ["ssrf"],
    # LFI / Path traversal
    "file":         ["lfi"], "path":          ["lfi"],
    "template":     ["lfi", "ssti"], "include":     ["lfi"],
    "load":         ["lfi"], "page":          ["lfi"],
    "doc":          ["lfi"], "lang":          ["lfi"],
    # IDOR
    "id":           ["idor"], "user_id":       ["idor"],
    "account_id":   ["idor"], "profile_id":    ["idor"],
    "order_id":     ["idor"], "ticket_id":     ["idor"],
    "conversation_id":["idor"], "message_id":  ["idor"],
    "uid":          ["idor"], "pid":           ["idor"],
    # XSS
    "q":            ["xss"], "search":         ["xss"],
    "name":         ["xss"], "comment":        ["xss"],
    "body":         ["xss"], "message":        ["xss"],
    "title":        ["xss"], "description":    ["xss"],
    "content":      ["xss"], "text":           ["xss"],
    # SQLi
    "filter":       ["sqli"], "sort":           ["sqli"],
    "order":        ["sqli"], "offset":         ["sqli"],
    "limit":        ["sqli"], "query":          ["sqli"],
    # SSTI
    "render":       ["ssti"], "view":           ["ssti"],
    "format":       ["ssti"],
    # RCE / CMD injection
    "cmd":          ["rce"], "exec":            ["rce"],
    "command":      ["rce"], "shell":           ["rce"],
    "ping":         ["rce"], "host":            ["rce"],
    # Open redirect
    "next":         ["redirect"], "return":      ["redirect"],
    "goto":         ["redirect"], "target":      ["redirect"],
    "back":         ["redirect"], "returnUrl":   ["redirect"],
    # JWT
    "token":        ["jwt"], "access_token":    ["jwt"],
    "refresh_token":["jwt"],
    # CORS — Origin header misconfig; Origin/cors params rare but exist in APIs
    "origin":       ["cors"], "cors":            ["cors"],
}


# ══════════════════════════════════════════════════════════════════════════════
# EXTRACTION — upgraded from basic regex to layered context extraction
# ══════════════════════════════════════════════════════════════════════════════

def extract_http_methods(text: str) -> List[Tuple[str, str]]:
    """
    Extract (METHOD, path) from report text.
    Returns deduplicated list, max 20.
    """
    seen, results = set(), []
    for m in _METHOD_RE.finditer(text):
        method = m.group(1).upper()
        path   = m.group(2).split("?")[0].rstrip("/") or "/"
        key    = f"{method}:{path}"
        if key not in seen:
            seen.add(key)
            results.append((method, path))
    return results[:20]


def detect_auth_context(text: str) -> str:
    """
    Detect authentication context from report text.
    Returns: 'none' | 'required' | 'bearer' | 'session_cookie' | 'api_key' | 'unknown'
    """
    tl = text.lower()
    for pattern, label in _AUTH_RE:
        if pattern.search(tl):
            return label
    return "unknown"


def classify_surface(text: str, endpoints: List[str]) -> List[str]:
    """
    Classify vulnerability surface: graphql/api/admin/auth/upload/webhook/export/mobile/web
    Returns list of matched surfaces (can be multiple).
    """
    combined = (text + " " + " ".join(endpoints)).lower()
    surfaces = []
    for surface, patterns in _SURFACE_PATTERNS.items():
        if any(p.lower() in combined for p in patterns):
            surfaces.append(surface)
    if not surfaces:
        surfaces = ["web"]
    return surfaces


def extract_context_params(text: str, vuln_type: str) -> List[Tuple[str, str, float]]:
    """
    Context-aware parameter extraction.
    Returns (name, context, confidence) tuples.
    Confidence 0-1 based on: param appears near a payload, named in vuln sentence,
    or listed in a known param→bug mapping for this vuln type.
    """
    results = []
    seen    = set()
    tl      = text.lower()
    lines   = text.split("\n")

    # Regex extraction (existing)
    param_re = re.compile(
        r'(?:[?&]([a-zA-Z_][a-zA-Z0-9_\-]{0,40})='         # query string
        r'|"([a-zA-Z_][a-zA-Z0-9_\-]{0,40})":\s*["\d\[{]' # JSON body
        r'|`([a-zA-Z_][a-zA-Z0-9_\-]{0,40})`)'             # backtick literal
    )

    for m in param_re.finditer(text):
        name = (m.group(1) or m.group(2) or m.group(3) or "").lower().strip()
        if not name or len(name) < 2 or len(name) > 40:
            continue
        if name in seen:
            continue
        seen.add(name)

        # Determine context
        pos  = m.start()
        snip = text[max(0, pos - 60): pos + 80].lower()
        ctx  = ("query"  if ("?" in snip[:60] or "&" in snip[:60])
                else "body"   if ("{" in snip or "post" in snip or "json" in snip)
                else "header" if "header" in snip
                else "path"   if "/" + name + "/" in snip
                else "query")

        # Confidence: base from position near payload indicators
        confidence = 0.5
        # Boost if param is known to map to this vuln type
        known_bugs = PARAM_BUG_MAP.get(name, [])
        if vuln_type in known_bugs:
            confidence += 0.30
        elif known_bugs:
            confidence += 0.10
        # Boost if param appears within 100 chars of a payload-like string
        nearby = text[max(0, pos - 100): pos + 100]
        if re.search(r'<script|onerror|SLEEP\(|169\.254|etc/passwd|\{\{|\$\{', nearby, re.I):
            confidence += 0.20
        # Boost if param is explicitly named in a vuln description sentence
        for line in lines:
            ll = line.lower()
            if name in ll and any(w in ll for w in ["vulnerable", "inject", "bypass", "exploit"]):
                confidence += 0.15
                break

        results.append((name, ctx, min(confidence, 1.0)))

    return sorted(results, key=lambda x: -x[2])[:30]


# ══════════════════════════════════════════════════════════════════════════════
# CONFIDENCE SCORING ENGINE
# ══════════════════════════════════════════════════════════════════════════════

def _recency_weight(disclosed_at: str) -> float:
    """
    Weight by recency. Reports in last 6m = 1.0, 1yr = 0.8, 2yr = 0.6, older = 0.4.
    """
    if not disclosed_at:
        return 0.5
    try:
        # Parse ISO date, handle both YYYY-MM-DD and YYYY-MM-DDTHH:MM:SSZ
        date_str = disclosed_at[:10]
        import datetime
        report_date = datetime.date.fromisoformat(date_str)
        today       = datetime.date.today()
        age_days    = (today - report_date).days
        if age_days <= 180:   return 1.0
        if age_days <= 365:   return 0.85
        if age_days <= 730:   return 0.70
        if age_days <= 1460:  return 0.55
        return 0.40
    except Exception:
        return 0.5


def score_pattern(
    frequency:    int,
    severity_max: str,
    last_seen:    str,
    program_count:int,
    bug_type:     str,
    pattern_type: str,  # 'endpoint' | 'param' | 'payload'
) -> float:
    """
    Compute a 0–100 confidence score for a pattern.

    Components:
      frequency_score   (0-30): log-scaled report count across all programs
      severity_score    (0-25): highest severity seen for this pattern
      recency_score     (0-20): how recently this pattern appeared in disclosures
      breadth_score     (0-15): number of distinct programs reporting this pattern
      certainty_score   (0-10): how well-defined the bug type is

    Score = sum of components, clamped 0–100.
    """
    # 1. Frequency — log-scaled so 1 report ≠ 0 but 1000 ≠ infinitely better than 100
    freq_score = min(30.0, 30.0 * math.log(1 + frequency, 10) / math.log(11, 10))

    # 2. Severity
    sev_score = _SEV_WEIGHT.get(severity_max or "medium", 0.45) * 25.0

    # 3. Recency
    rec_score = _recency_weight(last_seen) * 20.0

    # 4. Breadth (distinct programs)
    breadth_score = min(15.0, 15.0 * math.log(1 + program_count, 2) / math.log(9, 2))

    # 5. Bug type certainty
    certainty_score = _BUG_CERTAINTY.get(bug_type, 0.5) * 10.0

    raw = freq_score + sev_score + rec_score + breadth_score + certainty_score
    return round(min(100.0, max(0.0, raw)), 1)


# ══════════════════════════════════════════════════════════════════════════════
# SCORED QUERY API
# ══════════════════════════════════════════════════════════════════════════════

def _get_db():
    from engine.h1_ingest import _db
    return _db()


def get_scored_endpoints(
    bug_type:  str  = "",
    limit:     int  = 50,
    min_score: float = 0.0,
) -> List[Dict]:
    """
    Return endpoint patterns with confidence scores.
    Each item: value, bug_type, frequency, severity_max, score, score_components,
               example_ids, last_seen, program_count
    """
    with _get_db() as conn:
        if bug_type:
            rows = conn.execute("""
                SELECT p.value, p.bug_type, p.frequency, p.severity_max,
                       p.example_ids, p.last_seen,
                       COUNT(DISTINCT e.program) AS program_count
                FROM h1_patterns p
                LEFT JOIN h1_endpoints e ON e.pattern = p.value AND e.bug_type = p.bug_type
                WHERE p.pattern_type = 'endpoint' AND p.bug_type = ?
                GROUP BY p.value, p.bug_type
                ORDER BY p.frequency DESC LIMIT ?
            """, (bug_type, limit * 2)).fetchall()
        else:
            rows = conn.execute("""
                SELECT p.value, p.bug_type, p.frequency, p.severity_max,
                       p.example_ids, p.last_seen,
                       COUNT(DISTINCT e.program) AS program_count
                FROM h1_patterns p
                LEFT JOIN h1_endpoints e ON e.pattern = p.value AND e.bug_type = p.bug_type
                WHERE p.pattern_type = 'endpoint'
                GROUP BY p.value, p.bug_type
                ORDER BY p.frequency DESC LIMIT ?
            """, (limit * 2,)).fetchall()

    results = []
    for r in rows:
        freq = r["frequency"] or 1
        sev  = r["severity_max"] or "medium"
        prog = r["program_count"] or 1
        ls   = r["last_seen"] or ""
        bt   = r["bug_type"] or "other"

        freq_s    = round(min(30.0, 30.0 * math.log(1 + freq, 10) / math.log(11, 10)), 1)
        sev_s     = round(_SEV_WEIGHT.get(sev, 0.45) * 25.0, 1)
        rec_s     = round(_recency_weight(ls) * 20.0, 1)
        breadth_s = round(min(15.0, 15.0 * math.log(1 + prog, 2) / math.log(9, 2)), 1)
        cert_s    = round(_BUG_CERTAINTY.get(bt, 0.5) * 10.0, 1)
        total     = round(min(100.0, freq_s + sev_s + rec_s + breadth_s + cert_s), 1)

        if total < min_score:
            continue

        results.append({
            "value":       r["value"],
            "bug_type":    bt,
            "frequency":   freq,
            "severity_max":sev,
            "program_count":prog,
            "score":       total,
            "score_components": {
                "frequency": freq_s,
                "severity":  sev_s,
                "recency":   rec_s,
                "breadth":   breadth_s,
                "certainty": cert_s,
            },
            "example_ids": json.loads(r["example_ids"] or "[]"),
            "last_seen":   ls,
        })

    results.sort(key=lambda x: -x["score"])
    return results[:limit]


def get_scored_params(
    bug_type:  str  = "",
    limit:     int  = 50,
    min_score: float = 0.0,
) -> List[Dict]:
    """Return param patterns with confidence scores and mapped bug types."""
    with _get_db() as conn:
        if bug_type:
            rows = conn.execute("""
                SELECT p.value, p.bug_type, p.frequency, p.severity_max,
                       p.example_ids, p.last_seen,
                       COUNT(DISTINCT pa.report_id) AS report_count
                FROM h1_patterns p
                LEFT JOIN h1_params pa ON pa.name = p.value AND pa.bug_type = p.bug_type
                WHERE p.pattern_type = 'param' AND p.bug_type = ?
                GROUP BY p.value, p.bug_type
                ORDER BY p.frequency DESC LIMIT ?
            """, (bug_type, limit * 2)).fetchall()
        else:
            rows = conn.execute("""
                SELECT p.value, p.bug_type, p.frequency, p.severity_max,
                       p.example_ids, p.last_seen,
                       COUNT(DISTINCT pa.report_id) AS report_count
                FROM h1_patterns p
                LEFT JOIN h1_params pa ON pa.name = p.value AND pa.bug_type = p.bug_type
                WHERE p.pattern_type = 'param'
                GROUP BY p.value, p.bug_type
                ORDER BY p.frequency DESC LIMIT ?
            """, (limit * 2,)).fetchall()

    results = []
    for r in rows:
        freq = r["frequency"] or 1
        sev  = r["severity_max"] or "medium"
        ls   = r["last_seen"] or ""
        bt   = r["bug_type"] or "other"

        freq_s    = round(min(30.0, 30.0 * math.log(1 + freq, 10) / math.log(11, 10)), 1)
        sev_s     = round(_SEV_WEIGHT.get(sev, 0.45) * 25.0, 1)
        rec_s     = round(_recency_weight(ls) * 20.0, 1)
        cert_s    = round(_BUG_CERTAINTY.get(bt, 0.5) * 10.0, 1)
        # No breadth component for params — use report_count / 5 instead
        breadth_s = round(min(15.0, (r["report_count"] or 1) * 2.0), 1)
        total     = round(min(100.0, freq_s + sev_s + rec_s + breadth_s + cert_s), 1)

        if total < min_score:
            continue

        # All bug types this param maps to (from static map + DB)
        all_bugs = list(set(PARAM_BUG_MAP.get(r["value"], []) + [bt]))

        results.append({
            "value":       r["value"],
            "bug_type":    bt,
            "all_bug_types": all_bugs,
            "frequency":   freq,
            "severity_max":sev,
            "score":       total,
            "score_components": {
                "frequency": freq_s,
                "severity":  sev_s,
                "recency":   rec_s,
                "breadth":   breadth_s,
                "certainty": cert_s,
            },
            "example_ids": json.loads(r["example_ids"] or "[]"),
            "last_seen":   ls,
        })

    results.sort(key=lambda x: -x["score"])
    return results[:limit]


def get_risk_hotspots(limit: int = 20) -> List[Dict]:
    """
    Return the highest-scoring endpoint+bug_type combinations across all data.
    These are the paths most worth targeting first.
    """
    return get_scored_endpoints(limit=limit)


def get_recommendations(path: str, bug_type: str = "") -> Dict:
    """
    For a given URL path, return structured attack recommendations derived from H1 data.
    Includes: matched bugs with scores, prioritised param list, payload set,
    attack surface, recommended test sequence.
    """
    from engine.h1_ingest import _normalise_endpoint, get_payloads

    norm = _normalise_endpoint(path)
    path_lower = path.lower()

    # Detect surface
    surfaces = classify_surface(path_lower, [path])

    with _get_db() as conn:
        # Endpoint intelligence
        path_segs = [s for s in norm.split("/") if s and s not in ("{id}", "{uuid}")]
        if path_segs:
            like = "%" + "/".join(path_segs[:2]) + "%"
        else:
            like = "%" + norm[:20] + "%"

        ep_rows = conn.execute("""
            SELECT p.value, p.bug_type, p.frequency, p.severity_max,
                   p.example_ids, p.last_seen,
                   COUNT(DISTINCT e.program) AS program_count
            FROM h1_patterns p
            LEFT JOIN h1_endpoints e ON e.pattern=p.value AND e.bug_type=p.bug_type
            WHERE p.pattern_type='endpoint'
              AND (p.value=? OR p.value LIKE ? OR ? LIKE '%'||REPLACE(p.value,'{id}','')||'%')
            GROUP BY p.value, p.bug_type
            ORDER BY p.frequency DESC LIMIT 15
        """, (norm, like, norm)).fetchall()

        # Top params by score for the matched bug types
        matched_bug_types = list({r["bug_type"] for r in ep_rows}) or (
            [bug_type] if bug_type else []
        )

    # Score each matched bug
    matched = []
    seen_bugs = set()
    for r in ep_rows:
        bt = r["bug_type"]
        if bt in seen_bugs:
            continue
        seen_bugs.add(bt)
        freq  = r["frequency"] or 1
        sev   = r["severity_max"] or "medium"
        prog  = r["program_count"] or 1
        ls    = r["last_seen"] or ""

        score = score_pattern(freq, sev, ls, prog, bt, "endpoint")
        matched.append({
            "bug_type":     bt,
            "score":        score,
            "frequency":    freq,
            "severity_max": sev,
            "examples":     json.loads(r["example_ids"] or "[]")[:5],
            "payloads":     get_payloads(bt, 5),
        })

    matched.sort(key=lambda x: -x["score"])

    # Params prioritised for this path
    top_bugs = [m["bug_type"] for m in matched[:3]]
    all_params = []
    seen_params: set = set()
    for bt in (top_bugs or list(_BUG_CERTAINTY.keys())[:5]):
        for p in get_scored_params(bt, 15):
            if p["value"] not in seen_params:
                seen_params.add(p["value"])
                all_params.append(p)
    all_params.sort(key=lambda x: -x["score"])

    # Build recommended test sequence
    tests = _build_test_sequence(norm, matched, surfaces)

    return {
        "path":              norm,
        "surfaces":          surfaces,
        "matched_bugs":      matched,
        "priority_params":   all_params[:15],
        "recommended_tests": tests,
        "total_reports":     sum(m["frequency"] for m in matched),
    }


def _build_test_sequence(
    path: str,
    matched: List[Dict],
    surfaces: List[str],
) -> List[Dict]:
    """
    Build an ordered list of recommended tests for a path+surface combination.
    Each test: priority (1=highest), test_type, description, params_to_test, payloads
    """
    tests = []
    priority = 1

    # Surface-driven first tests
    if "graphql" in surfaces:
        tests.append({
            "priority": priority, "priority_label": "HIGH",
            "test_type": "graphql_introspection",
            "description": "GraphQL endpoint — check introspection enabled, IDOR via direct object queries, batching attacks",
            "params_to_test": ["query", "operationName", "variables"],
            "payloads": [
                '{"query":"{__schema{types{name}}}"}',
                '{"query":"query{user(id:1){email password}}"}',
            ],
        })
        priority += 1

    if "auth" in surfaces:
        tests.append({
            "priority": priority, "priority_label": "HIGH",
            "test_type": "auth_bypass",
            "description": "Auth endpoint — test token reuse, parameter pollution, JWT none alg",
            "params_to_test": ["token", "access_token", "state", "code", "redirect_uri"],
            "payloads": [
                '{"alg":"none","typ":"JWT"}',
                "?client_id=x&redirect_uri=https://attacker.com",
                "Authorization: Bearer null",
            ],
        })
        priority += 1

    if "upload" in surfaces:
        tests.append({
            "priority": priority, "priority_label": "HIGH",
            "test_type": "file_upload_abuse",
            "description": "Upload endpoint — test MIME bypass, path traversal in filename, RCE via polyglot",
            "params_to_test": ["file", "filename", "path", "content_type"],
            "payloads": [
                "../../../etc/passwd",
                "shell.php%00.jpg",
                "test.php;.jpg",
            ],
        })
        priority += 1

    if "export" in surfaces:
        tests.append({
            "priority": priority, "priority_label": "MEDIUM",
            "test_type": "idor_export",
            "description": "Export endpoint — IDOR via resource ID, mass data extraction, insecure direct reference",
            "params_to_test": ["id", "user_id", "report_id", "format"],
            "payloads": ["1", "2", "99999", "../../../sensitive"],
        })
        priority += 1

    # Bug-driven tests from matched patterns
    for m in matched[:5]:
        bt = m["bug_type"]
        if bt == "ssrf":
            tests.append({
                "priority": priority, "priority_label": "HIGH",
                "test_type": "ssrf",
                "description": f"SSRF — seen {m['frequency']}x in H1 reports on similar paths. Test internal metadata access.",
                "params_to_test": ["url", "callback", "redirect", "webhook", "endpoint", "fetch", "proxy"],
                "payloads": m["payloads"] or [
                    "http://169.254.169.254/latest/meta-data/",
                    "http://127.0.0.1:6379/",
                    "file:///etc/passwd",
                ],
            })
        elif bt == "idor":
            tests.append({
                "priority": priority, "priority_label": "HIGH",
                "test_type": "idor",
                "description": f"IDOR — seen {m['frequency']}x. Enumerate IDs, swap user context, test horizontal privilege escalation.",
                "params_to_test": ["id", "user_id", "account_id", "profile_id", "order_id"],
                "payloads": ["1", "2", "0", "-1", "99999", "me", "admin"],
            })
        elif bt == "xss":
            tests.append({
                "priority": priority, "priority_label": "MEDIUM",
                "test_type": "xss",
                "description": f"XSS — seen {m['frequency']}x. Test reflection, stored, DOM sinks. Check CSP.",
                "params_to_test": ["q", "search", "name", "comment", "message", "title"],
                "payloads": m["payloads"] or [
                    "<script>alert(document.domain)</script>",
                    "<img src=x onerror=alert(1)>",
                    "<svg/onload=alert(1)>",
                ],
            })
        elif bt == "sqli":
            tests.append({
                "priority": priority, "priority_label": "HIGH",
                "test_type": "sqli",
                "description": f"SQLi — seen {m['frequency']}x. Test time-based blind, union, error-based.",
                "params_to_test": ["id", "search", "q", "filter", "sort", "order"],
                "payloads": m["payloads"] or [
                    "' AND SLEEP(5)--",
                    "' UNION SELECT NULL,version(),NULL--",
                    "1' OR '1'='1",
                ],
            })
        elif bt == "lfi":
            tests.append({
                "priority": priority, "priority_label": "HIGH",
                "test_type": "lfi",
                "description": f"LFI — seen {m['frequency']}x. Test path traversal, null byte, encoding bypasses.",
                "params_to_test": ["file", "path", "page", "template", "include", "doc"],
                "payloads": m["payloads"] or [
                    "../../../../etc/passwd",
                    "..%2F..%2F..%2Fetc%2Fshadow",
                    "....//....//etc/passwd",
                ],
            })
        elif bt == "ssti":
            tests.append({
                "priority": priority, "priority_label": "HIGH",
                "test_type": "ssti",
                "description": f"SSTI — seen {m['frequency']}x. Test Jinja2, Twig, Freemarker, Smarty.",
                "params_to_test": ["template", "render", "view", "format", "name"],
                "payloads": m["payloads"] or [
                    "{{7*7}}",
                    "${7*7}",
                    "<%= 7 * 7 %>",
                    "#{7*7}",
                ],
            })
        else:
            continue
        priority += 1

    return sorted(tests, key=lambda x: x["priority"])


# ══════════════════════════════════════════════════════════════════════════════
# PROGRAM / TECH CORRELATION
# ══════════════════════════════════════════════════════════════════════════════

def get_related_patterns(bug_type: str, limit: int = 10) -> Dict:
    """
    Return correlated patterns for a bug type:
    - co-occurring endpoint families
    - most-used parameter names
    - programs with highest frequency
    - payload diversity
    """
    with _get_db() as conn:
        # Endpoint families (strip IDs, keep path prefix)
        ep_rows = conn.execute("""
            SELECT p.value, p.frequency, p.severity_max, p.last_seen
            FROM h1_patterns p
            WHERE p.pattern_type='endpoint' AND p.bug_type=?
            ORDER BY p.frequency DESC LIMIT ?
        """, (bug_type, limit)).fetchall()

        param_rows = conn.execute("""
            SELECT p.value, p.frequency, p.severity_max
            FROM h1_patterns p
            WHERE p.pattern_type='param' AND p.bug_type=?
            ORDER BY p.frequency DESC LIMIT ?
        """, (bug_type, limit)).fetchall()

        program_rows = conn.execute("""
            SELECT r.program, COUNT(*) AS n,
                   MAX(CASE r.severity WHEN 'critical' THEN 4
                                       WHEN 'high'     THEN 3
                                       WHEN 'medium'   THEN 2
                                       ELSE 1 END) AS sev_int,
                   AVG(COALESCE(r.bounty, 0)) AS avg_bounty
            FROM h1_reports r
            WHERE r.bug_type=? AND r.program != ''
            GROUP BY r.program
            ORDER BY n DESC LIMIT ?
        """, (bug_type, limit)).fetchall()

        payload_rows = conn.execute("""
            SELECT p.value, p.frequency
            FROM h1_patterns p
            WHERE p.pattern_type='payload' AND p.bug_type=?
            ORDER BY p.frequency DESC LIMIT ?
        """, (bug_type, limit)).fetchall()

        total = conn.execute(
            "SELECT COUNT(*) FROM h1_reports WHERE bug_type=?", (bug_type,)
        ).fetchone()[0]

    return {
        "bug_type":   bug_type,
        "total_reports": total,
        "endpoints":  [{"value": r["value"], "frequency": r["frequency"],
                        "severity_max": r["severity_max"]} for r in ep_rows],
        "params":     [{"value": r["value"], "frequency": r["frequency"]} for r in param_rows],
        "programs":   [{"program": r["program"], "count": r["n"],
                        "avg_bounty": round(r["avg_bounty"] or 0, 0)} for r in program_rows],
        "payloads":   [r["value"] for r in payload_rows],
    }


def get_programs_by_bug(bug_type: str, limit: int = 20) -> List[Dict]:
    """Programs with most reports for this bug type, with avg bounty."""
    with _get_db() as conn:
        rows = conn.execute("""
            SELECT program, program_name, COUNT(*) AS n,
                   AVG(COALESCE(bounty,0)) AS avg_bounty,
                   MAX(bounty) AS max_bounty,
                   GROUP_CONCAT(DISTINCT severity) AS severities
            FROM h1_reports
            WHERE bug_type=? AND program != ''
            GROUP BY program
            ORDER BY n DESC LIMIT ?
        """, (bug_type, limit)).fetchall()
    return [dict(r) for r in rows]


def get_param_intel(name: str) -> Dict:
    """
    Full intelligence for a single parameter name.
    Returns: bug types it maps to, frequency across types, scored risk, example payloads.
    """
    name = name.lower().strip()
    static_bugs = PARAM_BUG_MAP.get(name, [])

    with _get_db() as conn:
        rows = conn.execute("""
            SELECT p.bug_type, p.frequency, p.severity_max, p.last_seen, p.example_ids
            FROM h1_patterns p
            WHERE p.pattern_type='param' AND p.value=?
            ORDER BY p.frequency DESC
        """, (name,)).fetchall()

        total_reports = conn.execute(
            "SELECT COUNT(*) FROM h1_params WHERE name=?", (name,)
        ).fetchone()[0]

    db_bugs = {r["bug_type"]: dict(r) for r in rows}
    all_bugs = list(set(static_bugs + list(db_bugs.keys())))

    per_bug = []
    for bt in all_bugs:
        if bt in db_bugs:
            r = db_bugs[bt]
            score = score_pattern(
                r["frequency"], r["severity_max"], r["last_seen"], 1, bt, "param"
            )
            per_bug.append({
                "bug_type":    bt,
                "frequency":   r["frequency"],
                "severity_max":r["severity_max"],
                "score":       score,
                "source":      "observed",
                "examples":    json.loads(r["example_ids"] or "[]"),
            })
        else:
            # Known from static map but not yet observed in DB
            per_bug.append({
                "bug_type": bt, "frequency": 0, "severity_max": "unknown",
                "score": _BUG_CERTAINTY.get(bt, 0.5) * 30,
                "source": "static_map", "examples": [],
            })

    per_bug.sort(key=lambda x: -x["score"])

    from engine.h1_ingest import get_payloads
    top_payloads = {}
    for bt in [b["bug_type"] for b in per_bug[:3]]:
        pls = get_payloads(bt, 5)
        if pls:
            top_payloads[bt] = pls

    return {
        "name":          name,
        "total_reports": total_reports,
        "bug_types":     per_bug,
        "top_payloads":  top_payloads,
        "static_map":    static_bugs,
        "risk_summary":  ("HIGH"   if any(b["score"] > 60 for b in per_bug)
                          else "MEDIUM" if any(b["score"] > 30 for b in per_bug)
                          else "LOW"),
    }


# ══════════════════════════════════════════════════════════════════════════════
# BACKGROUND INDEX REBUILD (incremental, no full table lock)
# ══════════════════════════════════════════════════════════════════════════════

_rebuild_state: Dict = {"running": False, "started": None, "done": 0, "total": 0}


def rebuild_index_background() -> bool:
    """Start background rebuild. Returns False if already running."""
    if _rebuild_state["running"]:
        return False
    import threading
    threading.Thread(target=_do_rebuild, daemon=True, name="h1-index-rebuild").start()
    return True


def _do_rebuild():
    _rebuild_state["running"] = True
    _rebuild_state["started"] = time.time()
    try:
        from engine.h1_ingest import build_pattern_index
        build_pattern_index()
        _rebuild_state["done"] = 1
    except Exception as e:
        log.error(f"[h1_intel] rebuild failed: {e}")
    finally:
        _rebuild_state["running"] = False


def rebuild_status() -> Dict:
    return {
        "running":  _rebuild_state["running"],
        "started":  _rebuild_state["started"],
        "elapsed":  round(time.time() - (_rebuild_state["started"] or time.time()), 1)
                    if _rebuild_state["started"] else None,
    }
