"""
TheMasterRecon AI — Compliance & Standards Mapping
Maps findings to OWASP Top 10, CWE, CVSS 3.1, PCI-DSS, NIST, GDPR.
Auto-calculates CVSS 3.1 vector strings from finding data.
"""
import re
from typing import Dict, List, Optional

# OWASP Top 10 2021 mapping
OWASP_MAP = {
    "sqli":             ("A03:2021","Injection"),
    "nosqli":           ("A03:2021","Injection"),
    "ldap_injection":   ("A03:2021","Injection"),
    "xss":              ("A03:2021","Injection"),
    "ssti":             ("A03:2021","Injection"),
    "rce":              ("A03:2021","Injection"),
    "email_injection":  ("A03:2021","Injection"),
    "xxe":              ("A05:2021","Security Misconfiguration"),
    "cors":             ("A05:2021","Security Misconfiguration"),
    "misconfig":        ("A05:2021","Security Misconfiguration"),
    "expose":           ("A05:2021","Security Misconfiguration"),
    "panels":           ("A05:2021","Security Misconfiguration"),
    "actuator":         ("A05:2021","Security Misconfiguration"),
    "idor":             ("A01:2021","Broken Access Control"),
    "redirect":         ("A01:2021","Broken Access Control"),
    "auth":             ("A07:2021","Identification & Authentication Failures"),
    "jwt":              ("A07:2021","Identification & Authentication Failures"),
    "mfa_bypass":       ("A07:2021","Identification & Authentication Failures"),
    "oauth":            ("A07:2021","Identification & Authentication Failures"),
    "saml":             ("A07:2021","Identification & Authentication Failures"),
    "ssrf":             ("A10:2021","Server-Side Request Forgery"),
    "lfi":              ("A04:2021","Insecure Design"),
    "fileupload":       ("A04:2021","Insecure Design"),
    "deserialization":  ("A08:2021","Software & Data Integrity Failures"),
    "prototype":        ("A08:2021","Software & Data Integrity Failures"),
    "dep_confusion":    ("A08:2021","Software & Data Integrity Failures"),
    "jsleak":           ("A02:2021","Cryptographic Failures"),
    "takeover":         ("A06:2021","Vulnerable & Outdated Components"),
    "log4j":            ("A06:2021","Vulnerable & Outdated Components"),
    "spring4shell":     ("A06:2021","Vulnerable & Outdated Components"),
    "cve":              ("A06:2021","Vulnerable & Outdated Components"),
    "smuggling":        ("A04:2021","Insecure Design"),
    "race_condition":   ("A04:2021","Insecure Design"),
    "graphql":          ("A04:2021","Insecure Design"),
    "websocket":        ("A04:2021","Insecure Design"),
    "business_logic":   ("A04:2021","Insecure Design"),
    "cors_deep":        ("A01:2021","Broken Access Control"),
    "host_header":      ("A03:2021","Injection"),
    "crlf":             ("A03:2021","Injection"),
    "mass_assign":      ("A01:2021","Broken Access Control"),
    "http2":            ("A04:2021","Insecure Design"),
}

# CWE mapping
CWE_MAP = {
    "xss":           ("CWE-79",  "Improper Neutralization of Input During Web Page Generation"),
    "sqli":          ("CWE-89",  "Improper Neutralization of Special Elements in SQL Commands"),
    "ssrf":          ("CWE-918", "Server-Side Request Forgery"),
    "lfi":           ("CWE-22",  "Path Traversal"),
    "rce":           ("CWE-78",  "OS Command Injection"),
    "idor":          ("CWE-639", "Authorization Bypass Through User-Controlled Key"),
    "cors":          ("CWE-942", "Overly Permissive Cross-domain Policy"),
    "ssti":          ("CWE-94",  "Code Injection"),
    "xxe":           ("CWE-611", "Improper Restriction of XML External Entity Reference"),
    "jwt":           ("CWE-347", "Improper Verification of Cryptographic Signature"),
    "redirect":      ("CWE-601", "URL Redirection to Untrusted Site"),
    "deserialization":("CWE-502","Deserialization of Untrusted Data"),
    "prototype":     ("CWE-1321","Prototype Pollution"),
    "smuggling":     ("CWE-444", "Inconsistent Interpretation of HTTP Requests"),
    "crlf":          ("CWE-93",  "Improper Neutralization of CRLF Sequences"),
    "takeover":      ("CWE-284", "Improper Access Control"),
    "jsleak":        ("CWE-200", "Exposure of Sensitive Information"),
    "expose":        ("CWE-200", "Exposure of Sensitive Information"),
    "fileupload":    ("CWE-434", "Unrestricted Upload of File with Dangerous Type"),
    "misconfig":     ("CWE-16",  "Configuration"),
    "race_condition":("CWE-362", "Race Condition"),
    "mass_assign":   ("CWE-915", "Improperly Controlled Modification of Dynamically-Determined Object Attributes"),
    "log4j":         ("CWE-917", "Improper Neutralization of Special Elements in Expression Language Statement"),
    "dep_confusion": ("CWE-829", "Inclusion of Functionality from Untrusted Control Sphere"),
    "host_header":   ("CWE-644", "Improper Neutralization of HTTP Headers"),
    "auth":          ("CWE-287", "Improper Authentication"),
    "oauth":         ("CWE-285", "Improper Authorization"),
    "saml":          ("CWE-285", "Improper Authorization"),
}

# PCI-DSS 4.0 requirements mapping
PCI_MAP = {
    "xss":           "6.2.4 — Prevent common attacks",
    "sqli":          "6.2.4 — Prevent common attacks",
    "rce":           "6.2.4 — Prevent common attacks",
    "ssrf":          "6.2.4 — Prevent common attacks",
    "expose":        "2.2.7 — Remove unnecessary functionality",
    "panels":        "2.2.7 — Remove unnecessary functionality",
    "cors":          "6.2.4 — Prevent cross-origin attacks",
    "jsleak":        "3.3 — Protect cardholder data",
    "jwt":           "8.3.6 — Authenticate all access",
    "misconfig":     "2.2 — Develop configuration standards",
    "takeover":      "6.3.2 — Inventory of bespoke & custom software",
    "cve":           "6.3.3 — Security patches within 1 month",
    "log4j":         "6.3.3 — Critical patches within one month",
}

# NIST CSF mapping
NIST_MAP = {
    "xss":           ("PR.IP-1", "Baseline configuration established"),
    "sqli":          ("PR.IP-1", "Baseline configuration established"),
    "expose":        ("PR.DS-1", "Data-at-rest is protected"),
    "ssrf":          ("PR.AC-3", "Remote access is managed"),
    "misconfig":     ("PR.IP-1", "Baseline configuration established"),
    "jsleak":        ("PR.DS-1", "Data-at-rest is protected"),
    "auth":          ("PR.AC-1", "Identities and credentials are issued"),
    "jwt":           ("PR.AC-7", "Users, devices, and other assets are authenticated"),
    "cve":           ("PR.IP-12","Vulnerabilities are identified and remediated"),
    "log4j":         ("PR.IP-12","Vulnerabilities are identified and remediated"),
    "dep_confusion": ("PR.IP-2", "Software development lifecycle is implemented"),
}

# CVSS 3.1 base score calculation
def calc_cvss(bug: str, severity: str, poc: str = "", url: str = "",
              auth_required: bool = False, user_interaction: bool = False) -> Dict:
    """Calculate approximate CVSS 3.1 score from finding metadata."""

    # Base metrics per bug type
    ATTACK_VECTOR_MAP = {
        "ssrf": "N", "xss": "N", "sqli": "N", "lfi": "N", "rce": "N",
        "idor": "N", "cors": "N", "ssti": "N", "xxe": "N",
        "fileupload": "N", "misconfig": "N", "expose": "N",
        "takeover": "N", "deserialization": "N",
        "prototype": "L",  # local prototype pollution harder
        "race_condition": "N",
    }
    SCOPE_CHANGED = {"xss", "ssrf", "rce", "ssti", "xxe", "log4j", "spring4shell",
                     "host_header", "redirect", "clickjacking"}

    av  = ATTACK_VECTOR_MAP.get(bug, "N")  # Network by default
    ac  = "L"  # Low complexity (scanner confirmed it)
    pr  = "H" if auth_required else "N"
    ui  = "R" if user_interaction or bug in {"xss","redirect","clickjacking"} else "N"
    s   = "C" if bug in SCOPE_CHANGED else "U"

    # Impact based on bug type
    CONF_IMPACT = {"sqli":"H","lfi":"H","ssrf":"H","expose":"H","jsleak":"H",
                   "rce":"H","deserialization":"H","xxe":"H","ssti":"H","log4j":"H",
                   "cors":"L","xss":"L","redirect":"N","misconfig":"L","idor":"H","jwt":"H"}
    INTEG_IMPACT = {"sqli":"H","rce":"H","deserialization":"H","ssti":"H","log4j":"H",
                    "fileupload":"H","xss":"L","misconfig":"L","idor":"H",
                    "prototype":"H","xxe":"L","ssrf":"L","expose":"N"}
    AVAIL_IMPACT = {"rce":"H","deserialization":"H","log4j":"H","ssti":"H",
                    "race_condition":"H","smuggling":"H","http2":"H",
                    "sqli":"L","ssrf":"L","misconfig":"L"}

    conf = CONF_IMPACT.get(bug, "L")
    integ = INTEG_IMPACT.get(bug, "N")
    avail = AVAIL_IMPACT.get(bug, "N")

    # Severity → approximate score
    sev_score = {"critical":9.0,"high":7.5,"medium":5.0,"low":3.0,"info":0.0}
    base_score = sev_score.get(severity.lower(), 5.0)

    vector = f"CVSS:3.1/AV:{av}/AC:{ac}/PR:{pr}/UI:{ui}/S:{s}/C:{conf}/I:{integ}/A:{avail}"

    return {
        "vector":     vector,
        "base_score": base_score,
        "severity":   severity,
        "av": av, "ac": ac, "pr": pr, "ui": ui, "s": s,
        "conf": conf, "integ": integ, "avail": avail,
    }


def map_finding(finding: Dict) -> Dict:
    """Add compliance mappings + CVSS to a finding."""
    bug = finding.get("bug","").lower().replace("-","_")
    sev = finding.get("severity","medium")

    result = dict(finding)

    # OWASP
    owasp = OWASP_MAP.get(bug)
    if owasp:
        result["owasp_id"]    = owasp[0]
        result["owasp_name"]  = owasp[1]

    # CWE
    cwe = CWE_MAP.get(bug)
    if cwe:
        result["cwe_id"]   = cwe[0]
        result["cwe_name"] = cwe[1]

    # CVSS
    cvss = calc_cvss(bug, sev,
                     poc=finding.get("poc",""),
                     url=finding.get("url",""))
    result["cvss_vector"] = cvss["vector"]
    result["cvss_score"]  = cvss["base_score"]

    # PCI-DSS
    pci = PCI_MAP.get(bug)
    if pci:
        result["pci_dss"] = pci

    # NIST CSF
    nist = NIST_MAP.get(bug)
    if nist:
        result["nist_id"]   = nist[0]
        result["nist_name"] = nist[1]

    return result


def map_all(findings: List[Dict]) -> List[Dict]:
    """Map all findings to compliance frameworks."""
    return [map_finding(f) for f in findings]


def compliance_summary(findings: List[Dict]) -> Dict:
    """Generate compliance summary across all frameworks."""
    mapped = map_all(findings)

    owasp_hits = {}
    cwe_hits   = {}
    pci_hits   = {}

    for f in mapped:
        if f.get("owasp_id"):
            key = f"{f['owasp_id']} — {f.get('owasp_name','')}"
            owasp_hits.setdefault(key, {"count":0,"severities":[]})
            owasp_hits[key]["count"] += 1
            owasp_hits[key]["severities"].append(f.get("severity",""))
        if f.get("cwe_id"):
            cwe_hits.setdefault(f["cwe_id"], {"name":f.get("cwe_name",""),"count":0})
            cwe_hits[f["cwe_id"]]["count"] += 1
        if f.get("pci_dss"):
            pci_hits.setdefault(f["pci_dss"], 0)
            pci_hits[f["pci_dss"]] += 1

    return {
        "owasp_top10": owasp_hits,
        "cwe":         cwe_hits,
        "pci_dss":     pci_hits,
        "cvss_avg":    round(sum(f.get("cvss_score",0) for f in mapped)/max(len(mapped),1), 1),
        "total":       len(findings),
    }
