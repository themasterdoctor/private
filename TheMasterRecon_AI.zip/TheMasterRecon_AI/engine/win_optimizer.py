"""
TheMasterRecon AI — Win Optimizer
Scores report quality and gives concrete suggestions before submission.
Output: WIN SCORE: 82/100 + actionable issues.
"""
import re, logging
from typing import Dict, List, Tuple

log = logging.getLogger("elite.win_optimizer")


# ── Scoring rubric ─────────────────────────────────────────────────────────────
# Each check: (name, max_points, check_fn(report) -> (points_earned, issue_or_none))

def _check_title(r: Dict) -> Tuple[int, str]:
    title = r.get("title","")
    if not title:                                    return 0,  "Missing title"
    if len(title) < 15:                              return 5,  "Title too short — add bug type + location"
    if len(title) > 120:                             return 8,  "Title too long — trim to <120 chars"
    if not any(k in title.lower() for k in
               ["xss","sqli","ssrf","rce","idor","lfi","cors","ssti","xxe",
                "redirect","injection","traversal","forgery","exposure",
                "bypass","deserialization","overflow"]):
        return 8, "Title doesn't name the bug type — add e.g. 'SSRF via url parameter'"
    return 15, None

def _check_steps(r: Dict) -> Tuple[int, str]:
    steps = r.get("steps", [])
    if not steps:                    return 0,  "No steps to reproduce — mandatory"
    if len(steps) < 2:               return 5,  "Only 1 step — add target URL, payload, and expected result"
    if len(steps) < 3:               return 10, "Add more detail: URL → inject → observe"
    # Check for numbered steps or action verbs
    joined = " ".join(steps).lower()
    if not any(k in joined for k in ["navigate","go to","send","submit","request","click","visit"]):
        return 12, "Steps lack action verbs — use 'Navigate to', 'Send request', 'Observe'"
    return 20, None

def _check_poc(r: Dict) -> Tuple[int, str]:
    poc = r.get("poc","").strip()
    if not poc:
        return 0,  "Missing PoC — include curl command, request, or script"
    if len(poc) < 20:
        return 5,  "PoC too brief — should be a full curl/HTTP request"
    if "curl" in poc.lower() or "http" in poc.lower():
        return 15, None
    return 10, "PoC should include a curl command or raw HTTP request for reproducibility"

def _check_proof(r: Dict) -> Tuple[int, str]:
    proof = r.get("proof","").strip()
    if not proof:
        return 0,  "Missing proof — add response snippet, screenshot description, or timing evidence"
    if len(proof) < 20:
        return 5,  "Proof too brief — include actual response data or timing delta"
    if any(k in proof.lower() for k in
           ["ami-id","instance-id","root:","confirmed","delay","baseline","reflected","200 ok"]):
        return 15, None
    return 10, "Proof doesn't show concrete evidence — add response body or timing data"

def _check_impact(r: Dict) -> Tuple[int, str]:
    impact = r.get("impact","").strip()
    if not impact:
        return 0,  "Missing impact — mandatory for triage"
    generic = ["security vulnerability","potential issue","could lead to","may allow"]
    if any(g in impact.lower() for g in generic) and len(impact) < 60:
        return 5,  "Impact too generic — specify: what data? whose accounts? what business risk?"
    # Good impacts mention concrete outcomes
    if any(k in impact.lower() for k in
           ["iam","credential","database","admin","session","account takeover",
            "rce","server","data exfil","pii","password","token"]):
        return 15, None
    return 10, "Impact could be stronger — mention specific data or access gained"

def _check_remediation(r: Dict) -> Tuple[int, str]:
    rem = r.get("remediation","").strip()
    if not rem:
        return 0,  "Missing remediation — always include, even brief"
    if len(rem) < 20:
        return 3,  "Remediation too brief — add specific fix e.g. 'parameterized queries'"
    return 10, None

def _check_auth_context(r: Dict) -> Tuple[int, str]:
    steps = " ".join(r.get("steps",[])).lower()
    poc   = r.get("poc","").lower()
    combined = steps + " " + poc
    # Does it mention auth level?
    if any(k in combined for k in
           ["unauthenticated","no auth","without login","anonymous","authenticated",
            "logged in","session","cookie","bearer","authorization"]):
        return 5, None
    return 0, "Missing auth context — state if exploitable without login (much higher bounty)"

def _check_severity_justification(r: Dict) -> Tuple[int, str]:
    sev    = r.get("severity","medium").lower()
    impact = r.get("impact","").lower()
    if sev in ("critical","high"):
        # High/critical need strong impact statement
        if len(impact) < 40:
            return 0, f"Severity={sev} but impact is weak — justify with concrete consequences"
        if any(k in impact.lower() for k in
               ["rce","full","complete","all users","database","iam","credential"]):
            return 5, None
        return 3, f"Severity={sev} — strengthen impact to justify (add: data scope, user count affected)"
    return 5, None

def _check_duplicate_risk(r: Dict) -> Tuple[int, str]:
    # Warn if this looks like a commonly reported issue
    bug = r.get("bug_type","").lower()
    url = r.get("url","").lower()
    title = r.get("title","").lower()

    common_dupes = {
        "cors":     "CORS misconfiguration — very commonly reported; check program's dupe rate first",
        "redirect": "Open redirect — high dupe rate on most programs; verify it's truly exploitable",
        "misconfig":"Misconfiguration — check if publicly documented before submitting",
    }
    if bug in common_dupes:
        return 0, f"⚠ Dupe risk: {common_dupes[bug]}"

    # Check for obviously generic paths that every researcher hits
    if any(p in url for p in ["/robots.txt","/sitemap.xml","/.git","/phpinfo"]):
        return 0, "⚠ Dupe risk: this exact URL is scanned by every automated tool"

    return 0, None   # no penalty, no bonus

def _check_cvss(r: Dict) -> Tuple[int, str]:
    if r.get("cvss","").strip():
        return 5, None
    return 0, "No CVSS vector — add for faster triage (use calculator.first.org)"


_CHECKS = [
    ("Title quality",           15, _check_title),
    ("Steps to reproduce",      20, _check_steps),
    ("Proof of concept",        15, _check_poc),
    ("Evidence/proof",          15, _check_proof),
    ("Impact statement",        15, _check_impact),
    ("Remediation",             10, _check_remediation),
    ("Auth context",             5, _check_auth_context),
    ("Severity justification",   5, _check_severity_justification),
    ("Duplicate risk check",     0, _check_duplicate_risk),  # penalty-only
    ("CVSS vector",              5, _check_cvss),
]
MAX_SCORE = sum(m for _, m, _ in _CHECKS if m > 0)


def score_report(report: Dict) -> Dict:
    """
    Score a report draft and return actionable feedback.

    Returns:
        {
          win_score: int (0-100),
          breakdown: [{name, earned, max, issue}],
          issues: [str],
          suggestions: [str],
          ready_to_submit: bool,
          summary: str
        }
    """
    total_earned = 0
    breakdown    = []
    issues       = []
    suggestions  = []

    for name, max_pts, check_fn in _CHECKS:
        try:
            earned, issue = check_fn(report)
        except Exception as e:
            log.debug(f"[win_optimizer] check '{name}' error: {e}")
            earned, issue = 0, None

        total_earned += earned
        breakdown.append({
            "name":   name,
            "earned": earned,
            "max":    max_pts,
            "issue":  issue,
        })
        if issue:
            if issue.startswith("⚠"):
                suggestions.append(issue)
            elif earned == 0 and max_pts > 0:
                issues.append(f"✗ {issue}")
            else:
                suggestions.append(f"→ {issue}")

    # Normalize to 0-100
    win_score = round(total_earned / MAX_SCORE * 100) if MAX_SCORE else 0
    win_score = max(0, min(100, win_score))

    # Add concrete improvement suggestions
    if not any("curl" in i.lower() for i in [report.get("poc","")]):
        if not any("curl" in s for s in suggestions):
            suggestions.append("Add curl command with exact headers and payload")

    if report.get("severity","") in ("critical","high") and not report.get("cvss"):
        suggestions.append("Add CVSS vector to justify severity — use https://calculator.first.org/")

    ready = win_score >= 70 and not any("Missing" in i for i in issues)

    # Build summary line
    if win_score >= 85:
        grade = "Excellent — ready to submit"
    elif win_score >= 70:
        grade = "Good — address suggestions for higher payout"
    elif win_score >= 50:
        grade = "Needs work — fix issues before submitting"
    else:
        grade = "Poor — significant improvements required"

    summary = f"WIN SCORE: {win_score}/100 — {grade}"

    log.info(
        f"[win_optimizer] score={win_score}/100"
        f" issues={len(issues)}"
        f" ready={ready}"
        f" title={report.get('title','')[:40]}"
    )

    return {
        "win_score":       win_score,
        "max_score":       100,
        "grade":           grade,
        "breakdown":       breakdown,
        "issues":          issues,
        "suggestions":     suggestions,
        "ready_to_submit": ready,
        "summary":         summary,
    }


def optimize(report: Dict) -> Dict:
    """Alias for score_report — name used in routes."""
    return score_report(report)
