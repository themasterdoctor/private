"""
BugScan ELITE — Continuous Monitoring Engine

Provides:
  - Scheduled recurring scans (cron-style)
  - Delta detection: new subdomains, new endpoints, new findings, changed files
  - Change alerting via notifications
  - Snapshot storage and diff computation
  - Per-program monitoring configuration

This is the "set it and forget it" value proposition that justifies
recurring subscription pricing.
"""

import hashlib, json, logging, os, re, secrets, sqlite3, time, threading
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("elite.monitoring")

_DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "..", "data", "monitoring.db")
_conn: Optional[sqlite3.Connection] = None
_lock = threading.Lock()

# Scheduler thread
_scheduler_thread: Optional[threading.Thread] = None
_scheduler_stop   = threading.Event()


def _db() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        os.makedirs(os.path.dirname(_DB_PATH), exist_ok=True)
        _conn = sqlite3.connect(_DB_PATH, timeout=15, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA journal_mode=WAL")
        _bootstrap_schema()
    return _conn


def _bootstrap_schema():
    stmts = [
        # ── Monitor jobs (what to watch and how often) ─────────────────────
        """CREATE TABLE IF NOT EXISTS monitor_jobs (
            id           TEXT PRIMARY KEY,
            org_id       TEXT DEFAULT '',
            program_id   TEXT DEFAULT '',
            domain       TEXT NOT NULL,
            name         TEXT DEFAULT '',
            enabled      INTEGER DEFAULT 1,
            interval_h   INTEGER DEFAULT 24,     -- hours between runs
            last_run_at  REAL DEFAULT 0,
            next_run_at  REAL DEFAULT 0,
            last_status  TEXT DEFAULT 'pending', -- pending|running|done|error
            run_count    INTEGER DEFAULT 0,
            alert_on     TEXT DEFAULT '["new_subdomain","new_finding","score_change"]',
            notify_channels TEXT DEFAULT '["discord","telegram"]',
            options      TEXT DEFAULT '{}',
            created_at   REAL,
            updated_at   REAL
        )""",

        # ── Snapshots (point-in-time state capture) ────────────────────────
        """CREATE TABLE IF NOT EXISTS snapshots (
            id           TEXT PRIMARY KEY,
            job_id       TEXT REFERENCES monitor_jobs(id),
            domain       TEXT NOT NULL,
            taken_at     REAL NOT NULL,
            sub_count    INTEGER DEFAULT 0,
            live_count   INTEGER DEFAULT 0,
            endpoint_count INTEGER DEFAULT 0,
            finding_count INTEGER DEFAULT 0,
            finding_highs INTEGER DEFAULT 0,
            sub_hash     TEXT DEFAULT '',    -- hash of subdomain set
            endpoint_hash TEXT DEFAULT '',
            finding_hash TEXT DEFAULT '',
            raw_subs     TEXT DEFAULT '[]',  -- JSON list
            raw_endpoints TEXT DEFAULT '[]',
            raw_findings TEXT DEFAULT '[]',
            snapshot_meta TEXT DEFAULT '{}'
        )""",

        # ── Delta records (changes between two snapshots) ──────────────────
        """CREATE TABLE IF NOT EXISTS deltas (
            id            TEXT PRIMARY KEY,
            job_id        TEXT,
            domain        TEXT NOT NULL,
            from_snapshot TEXT,
            to_snapshot   TEXT,
            detected_at   REAL NOT NULL,
            delta_type    TEXT NOT NULL,  -- new_subdomain|lost_subdomain|new_endpoint|new_finding|score_change|tech_change
            severity      TEXT DEFAULT 'info',
            item          TEXT NOT NULL,  -- the changed item
            detail        TEXT DEFAULT '',
            notified      INTEGER DEFAULT 0,
            alert_sent_at REAL
        )""",

        # ── Indexes ────────────────────────────────────────────────────────
        "CREATE INDEX IF NOT EXISTS idx_jobs_next  ON monitor_jobs(next_run_at)",
        "CREATE INDEX IF NOT EXISTS idx_jobs_domain ON monitor_jobs(domain)",
        "CREATE INDEX IF NOT EXISTS idx_snaps_domain ON snapshots(domain, taken_at)",
        "CREATE INDEX IF NOT EXISTS idx_deltas_job ON deltas(job_id, detected_at)",
        "CREATE INDEX IF NOT EXISTS idx_deltas_unnotified ON deltas(notified, detected_at)",
    ]
    for stmt in stmts:
        _conn.execute(stmt)
    _conn.commit()
    log.info("[monitoring] schema ready")


# ── Monitor Job Management ────────────────────────────────────────────────────

def create_job(domain: str, org_id: str = "", program_id: str = "",
               name: str = "", interval_h: int = 24,
               alert_on: List[str] = None,
               notify_channels: List[str] = None,
               options: Dict = None) -> Dict:
    jid = "job_" + secrets.token_hex(6)
    ts  = time.time()
    if not name: name = f"Monitor {domain}"
    with _lock:
        _db().execute("""INSERT INTO monitor_jobs
            (id,org_id,program_id,domain,name,enabled,interval_h,
             last_run_at,next_run_at,last_status,alert_on,notify_channels,
             options,created_at,updated_at)
            VALUES (?,?,?,?,?,1,?,0,?,?,?,?,?,?,?)""",
            (jid, org_id, program_id, domain, name, interval_h,
             ts,  # next_run_at = now so it runs immediately
             "pending",
             json.dumps(alert_on or ["new_subdomain","new_finding","new_endpoint"]),
             json.dumps(notify_channels or ["discord","telegram"]),
             json.dumps(options or {}),
             ts, ts))
        _db().commit()
    log.info(f"[monitoring] job created id={jid} domain={domain} interval={interval_h}h")
    return get_job(jid)


def get_job(job_id: str) -> Optional[Dict]:
    row = _db().execute("SELECT * FROM monitor_jobs WHERE id=?", (job_id,)).fetchone()
    if not row: return None
    d = dict(row)
    for f in ("alert_on", "notify_channels", "options"):
        try: d[f] = json.loads(d.get(f, "[]") or "[]")
        except: pass
    return d


def list_jobs(org_id: str = "", domain: str = "", enabled_only: bool = False) -> List[Dict]:
    q = "SELECT * FROM monitor_jobs WHERE 1=1"
    p = []
    if org_id: q += " AND org_id=?"; p.append(org_id)
    if domain: q += " AND domain=?"; p.append(domain)
    if enabled_only: q += " AND enabled=1"
    q += " ORDER BY created_at DESC"
    rows = _db().execute(q, p).fetchall()
    result = []
    for row in rows:
        d = dict(row)
        for f in ("alert_on", "notify_channels", "options"):
            try: d[f] = json.loads(d.get(f, "[]") or "[]")
            except: pass
        result.append(d)
    return result


def update_job(job_id: str, updates: Dict) -> Optional[Dict]:
    allowed = {"name","enabled","interval_h","alert_on","notify_channels","options"}
    sets, vals = [], []
    for k, v in updates.items():
        if k not in allowed: continue
        if isinstance(v, (list, dict)): v = json.dumps(v)
        sets.append(f"{k}=?"); vals.append(v)
    if not sets: return get_job(job_id)
    vals += [time.time(), job_id]
    with _lock:
        _db().execute(f"UPDATE monitor_jobs SET {', '.join(sets)}, updated_at=? WHERE id=?", vals)
        _db().commit()
    return get_job(job_id)


def delete_job(job_id: str) -> bool:
    with _lock:
        _db().execute("DELETE FROM monitor_jobs WHERE id=?", (job_id,))
        _db().commit()
    return True


# ── Snapshots ────────────────────────────────────────────────────────────────

def take_snapshot(job_id: str, domain: str, db_ref) -> Dict:
    """
    Capture current state of a domain from the recon DB.
    Returns snapshot record.
    """
    snap_id = "snap_" + secrets.token_hex(6)
    ts      = time.time()
    try:
        subs      = db_ref.get_subs(domain)      or []
        endpoints = db_ref.get_endpoints(domain)  or []
        findings  = db_ref.get_findings(domain)   or []
        live      = db_ref.get_active(domain)     or []
    except Exception as e:
        log.warning(f"[monitoring] snapshot DB read error: {e}")
        subs = endpoints = findings = live = []

    sub_list  = [s if isinstance(s,str) else s.get("subdomain","") for s in subs]
    ep_list   = [e if isinstance(e,str) else e.get("url","") for e in endpoints]
    find_list = [{"bug": f.get("bug_type", f.get("bug","")),
                  "sev": f.get("severity",""),
                  "url": f.get("url",""),
                  "conf": f.get("confidence",0)} for f in findings]
    highs = sum(1 for f in find_list if f.get("sev") in ("high","critical"))

    def _hash(lst): return hashlib.md5(json.dumps(sorted(lst)).encode()).hexdigest()[:12]

    with _lock:
        _db().execute("""INSERT INTO snapshots
            (id,job_id,domain,taken_at,sub_count,live_count,endpoint_count,
             finding_count,finding_highs,sub_hash,endpoint_hash,finding_hash,
             raw_subs,raw_endpoints,raw_findings)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (snap_id, job_id, domain, ts,
             len(sub_list), len(live), len(ep_list), len(find_list), highs,
             _hash(sub_list), _hash(ep_list), _hash(find_list),
             json.dumps(sub_list[:5000]),
             json.dumps(ep_list[:5000]),
             json.dumps(find_list[:2000])))
        _db().commit()

    log.info(f"[monitoring] snapshot taken id={snap_id} domain={domain}"
             f" subs={len(sub_list)} eps={len(ep_list)} findings={len(find_list)}")
    return get_snapshot(snap_id)


def get_snapshot(snap_id: str) -> Optional[Dict]:
    row = _db().execute("SELECT * FROM snapshots WHERE id=?", (snap_id,)).fetchone()
    if not row: return None
    d = dict(row)
    for f in ("raw_subs","raw_endpoints","raw_findings"):
        try: d[f] = json.loads(d.get(f,"[]") or "[]")
        except: d[f] = []
    return d


def get_latest_snapshot(domain: str, job_id: str = "") -> Optional[Dict]:
    q = "SELECT * FROM snapshots WHERE domain=?"
    p = [domain]
    if job_id: q += " AND job_id=?"; p.append(job_id)
    q += " ORDER BY taken_at DESC LIMIT 1"
    row = _db().execute(q, p).fetchone()
    if not row: return None
    d = dict(row)
    for f in ("raw_subs","raw_endpoints","raw_findings"):
        try: d[f] = json.loads(d.get(f,"[]") or "[]")
        except: d[f] = []
    return d


# ── Delta Detection ───────────────────────────────────────────────────────────

def compute_delta(old_snap: Dict, new_snap: Dict, job_id: str = "") -> List[Dict]:
    """
    Compare two snapshots and return list of detected changes.
    Each change: {delta_type, severity, item, detail}
    """
    deltas = []
    domain = new_snap.get("domain","")
    ts     = time.time()

    old_subs = set(old_snap.get("raw_subs", []))
    new_subs = set(new_snap.get("raw_subs", []))
    old_eps  = set(old_snap.get("raw_endpoints", []))
    new_eps  = set(new_snap.get("raw_endpoints", []))
    old_find = {f.get("url","") + f.get("bug","") for f in old_snap.get("raw_findings",[])}
    new_find = {f.get("url","") + f.get("bug","") for f in new_snap.get("raw_findings",[])}
    new_find_objs = new_snap.get("raw_findings",[])

    # New subdomains
    for sub in (new_subs - old_subs):
        deltas.append({
            "delta_type": "new_subdomain",
            "severity":   "info",
            "item":       sub,
            "detail":     f"New subdomain discovered: {sub}",
        })

    # Lost subdomains (can indicate takedown or ownership change)
    for sub in (old_subs - new_subs):
        if len(old_subs - new_subs) <= 50:  # don't spam on bulk loss
            deltas.append({
                "delta_type": "lost_subdomain",
                "severity":   "notice",
                "item":       sub,
                "detail":     f"Subdomain no longer resolves: {sub}",
            })

    # New endpoints
    for ep in list(new_eps - old_eps)[:200]:
        sev = "info"
        if any(p in ep for p in ["/admin","/api/","/auth","/login","/internal",
                                   "/.env","/.git","/backup","/config"]):
            sev = "notice"
        deltas.append({
            "delta_type": "new_endpoint",
            "severity":   sev,
            "item":       ep[:200],
            "detail":     f"New endpoint detected: {ep[:200]}",
        })

    # New findings
    for find_key in (new_find - old_find):
        # Find the matching finding object
        f_obj = next((f for f in new_find_objs
                      if f.get("url","") + f.get("bug","") == find_key), {})
        sev   = f_obj.get("sev", "medium")
        bug   = f_obj.get("bug","unknown")
        url   = f_obj.get("url","")[:100]
        deltas.append({
            "delta_type": "new_finding",
            "severity":   sev,
            "item":       f"{bug}:{url}",
            "detail":     f"New {sev.upper()} {bug} signal at {url}",
        })

    # Score change (large subdomain count change)
    old_count = old_snap.get("sub_count", 0)
    new_count = new_snap.get("sub_count", 0)
    if old_count > 0:
        pct_change = abs(new_count - old_count) / old_count * 100
        if pct_change > 20 and abs(new_count - old_count) > 10:
            deltas.append({
                "delta_type": "scope_change",
                "severity":   "notice",
                "item":       domain,
                "detail":     f"Attack surface changed: {old_count}→{new_count} subdomains ({pct_change:.0f}%)",
            })

    # Store deltas in DB
    for d in deltas:
        did = "dlt_" + secrets.token_hex(5)
        with _lock:
            _db().execute("""INSERT INTO deltas
                (id,job_id,domain,from_snapshot,to_snapshot,detected_at,
                 delta_type,severity,item,detail,notified)
                VALUES (?,?,?,?,?,?,?,?,?,?,0)""",
                (did, job_id or "", domain,
                 old_snap.get("id",""), new_snap.get("id",""),
                 ts, d["delta_type"], d["severity"],
                 d["item"][:200], d["detail"][:500]))
        _db().commit()

    log.info(f"[monitoring] delta computed domain={domain}"
             f" new_subs={len(new_subs-old_subs)}"
             f" new_eps={len(new_eps-old_eps)}"
             f" new_findings={len(new_find-old_find)}"
             f" total_deltas={len(deltas)}")
    return deltas


def get_deltas(domain: str = "", job_id: str = "", unnotified_only: bool = False,
               limit: int = 100) -> List[Dict]:
    q = "SELECT * FROM deltas WHERE 1=1"
    p = []
    if domain:           q += " AND domain=?";   p.append(domain)
    if job_id:           q += " AND job_id=?";   p.append(job_id)
    if unnotified_only:  q += " AND notified=0"
    q += " ORDER BY detected_at DESC LIMIT ?"
    p.append(limit)
    return [dict(r) for r in _db().execute(q, p).fetchall()]


def mark_notified(delta_ids: List[str]):
    ts = time.time()
    with _lock:
        for did in delta_ids:
            _db().execute(
                "UPDATE deltas SET notified=1, alert_sent_at=? WHERE id=?", (ts, did))
        _db().commit()


# ── Alert Sending ─────────────────────────────────────────────────────────────

def send_delta_alerts(domain: str, deltas: List[Dict], job: Dict = None):
    """Send change notifications through the notification engine."""
    if not deltas: return
    try:
        from engine.notify import get_notifier, safe_notification_url
        n = get_notifier()
        if not n.configured: return

        # Group by severity
        highs   = [d for d in deltas if d.get("severity") in ("high","critical")]
        notices = [d for d in deltas if d.get("severity") == "notice"]
        infos   = [d for d in deltas if d.get("severity") == "info"]

        # Build summary message
        lines = [f"🔔 **Attack Surface Change** — `{domain}`\n"]
        if highs:
            lines.append(f"🔴 {len(highs)} HIGH severity changes")
        if notices:
            lines.append(f"🟡 {len(notices)} notable changes")
        lines.append(f"📊 {len(deltas)} total changes detected")

        # Sample top items (no payloads, no sensitive params)
        for d in (highs + notices)[:3]:
            item = d.get("item","")
            # Safe URL redaction for items that look like URLs
            if item.startswith("http"):
                item = safe_notification_url(item)
            lines.append(f"  • {d.get('delta_type','change')}: `{item[:80]}`")

        lines.append(f"\n_Stored for analyst review. Use /monitoring/deltas to see full list._")
        msg = "\n".join(lines)

        if n.discord_webhook:
            from engine.notify import _post, SEV_COLOR
            color = 0xFF0000 if highs else 0xFFCC00 if notices else 0x3399FF
            _post(n.discord_webhook, {"embeds":[{
                "title":       f"🔔 Surface Change — {domain}",
                "description": msg,
                "color":       color,
                "footer":      {"text": f"BugScan ELITE Monitoring • {time.strftime('%H:%M UTC')}"},
            }]})
            log.info(f"[monitoring] discord alert sent domain={domain} changes={len(deltas)}")
        if n.telegram_token and n.telegram_chat:
            n._send_telegram(msg)
            log.info(f"[monitoring] telegram alert sent domain={domain}")

    except Exception as e:
        log.warning(f"[monitoring] alert error: {e}")


# ── Scheduler ────────────────────────────────────────────────────────────────

def get_due_jobs(now: float = None) -> List[Dict]:
    """Return jobs that are due to run."""
    if now is None: now = time.time()
    rows = _db().execute("""
        SELECT * FROM monitor_jobs
        WHERE enabled=1 AND next_run_at<=? AND last_status!='running'
        ORDER BY next_run_at ASC LIMIT 10""",
        (now,)).fetchall()
    result = []
    for row in rows:
        d = dict(row)
        for f in ("alert_on","notify_channels","options"):
            try: d[f] = json.loads(d.get(f,"[]") or "[]")
            except: pass
        result.append(d)
    return result


def mark_job_running(job_id: str):
    ts = time.time()
    with _lock:
        _db().execute(
            "UPDATE monitor_jobs SET last_status='running', last_run_at=?, updated_at=? WHERE id=?",
            (ts, ts, job_id))
        _db().commit()


def mark_job_done(job_id: str, status: str = "done"):
    job = get_job(job_id)
    if not job: return
    next_run = time.time() + (job.get("interval_h", 24) * 3600)
    ts = time.time()
    with _lock:
        _db().execute("""UPDATE monitor_jobs
            SET last_status=?, next_run_at=?, run_count=run_count+1, updated_at=?
            WHERE id=?""",
            (status, next_run, ts, job_id))
        _db().commit()
    log.info(f"[monitoring] job {job_id} {status} next_run={time.strftime('%Y-%m-%d %H:%M', time.localtime(next_run))}")


def run_job(job: Dict, db_ref) -> Dict:
    """
    Execute one monitoring job:
    1. Take snapshot of current state
    2. Compare with previous snapshot
    3. Compute deltas
    4. Send alerts for changes
    Returns result summary.
    """
    job_id = job["id"]
    domain = job["domain"]
    log.info(f"[monitoring] running job id={job_id} domain={domain}")
    mark_job_running(job_id)

    try:
        new_snap = take_snapshot(job_id, domain, db_ref)
        old_snap = _db().execute("""
            SELECT * FROM snapshots WHERE job_id=? AND id!=?
            ORDER BY taken_at DESC LIMIT 1""",
            (job_id, new_snap["id"])).fetchone()

        if old_snap:
            old_snap_d = dict(old_snap)
            for f in ("raw_subs","raw_endpoints","raw_findings"):
                try: old_snap_d[f] = json.loads(old_snap_d.get(f,"[]") or "[]")
                except: old_snap_d[f] = []
            deltas = compute_delta(old_snap_d, new_snap, job_id)
            # Send alerts for significant changes
            if deltas:
                send_delta_alerts(domain, deltas, job)
        else:
            deltas = []
            log.info(f"[monitoring] first snapshot for {domain} — no delta yet")

        mark_job_done(job_id, "done")
        return {
            "ok":          True,
            "job_id":      job_id,
            "domain":      domain,
            "snapshot_id": new_snap["id"],
            "delta_count": len(deltas),
            "deltas":      deltas[:10],
        }
    except Exception as e:
        log.error(f"[monitoring] job error id={job_id}: {e}")
        mark_job_done(job_id, "error")
        return {"ok": False, "job_id": job_id, "error": str(e)}


def start_scheduler(db_ref):
    """Start background scheduler thread."""
    global _scheduler_thread
    if _scheduler_thread and _scheduler_thread.is_alive():
        return
    _scheduler_stop.clear()

    def _loop():
        log.info("[monitoring] scheduler started")
        while not _scheduler_stop.is_set():
            try:
                due = get_due_jobs()
                for job in due:
                    run_job(job, db_ref)
            except Exception as e:
                log.debug(f"[monitoring] scheduler error: {e}")
            _scheduler_stop.wait(timeout=60)  # check every minute
        log.info("[monitoring] scheduler stopped")

    _scheduler_thread = threading.Thread(target=_loop, daemon=True, name="monitor-scheduler")
    _scheduler_thread.start()


def stop_scheduler():
    _scheduler_stop.set()
