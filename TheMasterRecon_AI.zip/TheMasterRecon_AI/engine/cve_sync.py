"""
BugScan ELITE — CVE Sync Engine

Keeps the local CVE DB current by syncing from:
  1. NVD API v2      — official NIST database (270k+ CVEs)
  2. OSV.dev         — open source package vulnerabilities (npm, PyPI, Go, Maven, etc.)
  3. EPSS scores     — exploit prediction scoring (which CVEs are actually being exploited)
  4. CISA KEV        — CISA Known Exploited Vulnerabilities catalog (actively exploited NOW)
  5. GitHub Advisory — security advisories for open source packages

Strategy:
  - On startup: sync CISA KEV (550 CVEs, most dangerous, fast) + last 30 days NVD
  - Weekly background: full sync of tech-relevant CVEs from NVD
  - On demand: /cve/sync endpoint triggers immediate sync
  - With NVDAPIKEY: 10x faster (50 req/30s vs 5 req/30s)

CISA KEV = if it's in there, it's being actively exploited in the wild RIGHT NOW.
EPSS    = probability score 0-1 that a CVE will be exploited in next 30 days.
"""

import json, logging, os, re, sqlite3, threading, time, urllib.request, urllib.parse, ssl
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("elite.cve_sync")

# ── Config ─────────────────────────────────────────────────────────────────────
NVD_API_KEY    = os.environ.get("NVDAPIKEY", "")
NVD_BASE       = "https://services.nvd.nist.gov/rest/json/cves/2.0"
EPSS_API       = "https://api.first.org/data/v1/epss"
CISA_KEV_URL   = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
OSV_QUERY_URL  = "https://api.osv.dev/v1/query"
GITHUB_ADV_URL = "https://api.github.com/advisories"

# Tech keywords to sync — covers ~90% of bug bounty program tech stacks
# Ordered by frequency of appearance in bug bounty programs
SYNC_KEYWORDS = [
    # Web servers
    "apache http server", "nginx", "microsoft iis", "apache tomcat", "jetty", "lighttpd",
    # Frameworks / languages
    "spring framework", "spring boot", "django", "rails", "laravel", "symfony",
    "express", "fastapi", "flask", "struts", "log4j", "log4shell",
    "php", "node.js", "next.js", "nuxt", "angular", "react", "vue",
    # CMS
    "wordpress", "drupal", "joomla", "magento", "typo3", "ghost",
    # Dev tools / CI
    "jenkins", "gitlab", "github enterprise", "jira", "confluence", "bitbucket",
    "teamcity", "bamboo", "sonarqube", "artifactory",
    # Databases
    "mysql", "postgresql", "mongodb", "redis", "elasticsearch", "opensearch",
    "cassandra", "couchdb", "influxdb", "mariadb",
    # Infrastructure
    "kubernetes", "docker", "containerd", "grafana", "prometheus", "kibana",
    "vault", "consul", "nomad", "terraform",
    # Mail
    "exim", "postfix", "sendmail", "dovecot", "zimbra", "roundcube",
    # Network / VPN
    "openssh", "openssl", "cisco", "fortinet", "palo alto", "f5", "citrix",
    "pulse secure", "globalprotect", "anyconnect",
    # Cloud
    "aws", "azure", "gcp", "minio", "keycloak", "oauth",
    # Apps
    "vmware", "exchange", "sharepoint", "outlook", "office", "zoom",
    "grafana", "zabbix", "nagios", "icinga",
]

# OSV ecosystem → package list (most impactful for web apps)
OSV_PACKAGES = {
    "npm":    ["express","lodash","axios","next","react","vue","angular","webpack",
               "moment","serialize-javascript","node-fetch","minimist","got"],
    "PyPI":   ["django","flask","fastapi","pillow","requests","cryptography",
               "sqlalchemy","celery","paramiko","pyyaml","jinja2","werkzeug"],
    "Go":     ["github.com/gin-gonic/gin","github.com/gorilla/mux",
               "github.com/go-chi/chi","golang.org/x/crypto"],
    "Maven":  ["org.springframework:spring-core","org.apache.struts:struts2-core",
               "org.apache.logging.log4j:log4j-core","com.fasterxml.jackson.core:jackson-databind"],
}

# ── SSL / HTTP ─────────────────────────────────────────────────────────────────
def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _get(url: str, timeout: int = 15, headers: dict = None) -> Optional[dict]:
    try:
        h = {"User-Agent": "BugScanELITE-CVESync/1.0", "Accept": "application/json"}
        if headers: h.update(headers)
        req = urllib.request.Request(url, headers=h)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return json.loads(r.read())
    except Exception as e:
        log.debug(f"[cve_sync] GET {url[:60]}: {e}")
        return None

def _post_json(url: str, body: dict, timeout: int = 15) -> Optional[dict]:
    try:
        data = json.dumps(body).encode()
        req  = urllib.request.Request(url, data=data,
            headers={"Content-Type":"application/json","User-Agent":"BugScanELITE-CVESync/1.0"},
            method="POST")
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return json.loads(r.read())
    except Exception as e:
        log.debug(f"[cve_sync] POST {url[:60]}: {e}")
        return None

# ── DB access ──────────────────────────────────────────────────────────────────
def _cve_db():
    from engine.cve_engine import _db
    return _db()

def _upsert_cve(cve_id: str, tech: str, severity: str, cvss: float,
                description: str, tags: str = "", source: str = "nvd",
                vmin: str = "", vmax: str = "",
                epss_score: float = 0.0, kev: bool = False):
    """Insert or update a CVE in the local cache."""
    try:
        conn = _cve_db()
        # Add epss/kev columns if they don't exist yet
        try:
            conn.execute("ALTER TABLE cve_cache ADD COLUMN epss_score REAL DEFAULT 0")
            conn.execute("ALTER TABLE cve_cache ADD COLUMN in_kev INTEGER DEFAULT 0")
            conn.commit()
        except Exception: pass

        conn.execute("""INSERT OR REPLACE INTO cve_cache
            (cve_id, tech, version_min, version_max, severity, cvss_score,
             description, nuclei_tags, source, added_at, epss_score, in_kev)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (cve_id, tech[:50], vmin, vmax, severity, cvss,
             description[:500], tags[:200], source, time.time(),
             epss_score, 1 if kev else 0))
        conn.commit()
    except Exception as e:
        log.debug(f"[cve_sync] upsert {cve_id}: {e}")

# ── Severity helpers ───────────────────────────────────────────────────────────
def _sev_from_cvss(cvss: float) -> str:
    if cvss >= 9.0: return "critical"
    if cvss >= 7.0: return "high"
    if cvss >= 4.0: return "medium"
    if cvss >  0:   return "low"
    return "info"

def _extract_cvss(metrics: dict) -> float:
    for key in ("cvssMetricV31","cvssMetricV30","cvssMetricV40","cvssMetricV2"):
        if key in metrics and metrics[key]:
            return float(metrics[key][0].get("cvssData",{}).get("baseScore", 0))
    return 0.0

def _extract_tags(cve_id: str, tech: str, desc: str) -> str:
    """Build nuclei-compatible tag string from CVE context."""
    tags = {tech.lower().split()[0]}
    desc_l = desc.lower()
    if any(w in desc_l for w in ["remote code execution","rce","command execution"]):
        tags.add("rce")
    if any(w in desc_l for w in ["sql injection","sqli"]):
        tags.add("sqli")
    if any(w in desc_l for w in ["cross-site scripting","xss"]):
        tags.add("xss")
    if any(w in desc_l for w in ["path traversal","directory traversal","lfi"]):
        tags.add("lfi")
    if any(w in desc_l for w in ["server-side request","ssrf"]):
        tags.add("ssrf")
    if any(w in desc_l for w in ["authentication bypass","unauthenticated","pre-auth"]):
        tags.add("auth-bypass")
    if any(w in desc_l for w in ["privilege escalation","privesc"]):
        tags.add("privesc")
    if "log4" in tech.lower():
        tags.add("jndi")
    tags.add("cve")
    return ",".join(sorted(tags))

# ── 1. CISA KEV sync ──────────────────────────────────────────────────────────
def sync_cisa_kev() -> int:
    """
    Sync CISA Known Exploited Vulnerabilities catalog.
    These are CVEs being actively exploited in the wild RIGHT NOW.
    ~550 entries, updates regularly, highest priority.
    """
    log.info("[cve_sync] syncing CISA KEV...")
    data = _get(CISA_KEV_URL, timeout=20)
    if not data:
        log.warning("[cve_sync] CISA KEV fetch failed")
        return 0

    vulns = data.get("vulnerabilities", [])
    count = 0
    for v in vulns:
        cve_id = v.get("cveID","")
        if not cve_id: continue
        vendor  = v.get("vendorProject","").lower()
        product = v.get("product","").lower()
        desc    = f"[ACTIVELY EXPLOITED] {v.get('shortDescription','')}"[:500]
        tech    = product or vendor or "unknown"
        tags    = _extract_tags(cve_id, tech, desc) + ",kev"

        _upsert_cve(cve_id=cve_id, tech=tech, severity="critical",
                    cvss=9.0, description=desc, tags=tags,
                    source="cisa_kev", kev=True)
        count += 1

    log.info(f"[cve_sync] CISA KEV: {count} actively-exploited CVEs synced")
    return count

# ── 2. NVD API v2 sync ────────────────────────────────────────────────────────
def sync_nvd_keyword(keyword: str, days_back: int = 90) -> int:
    """Fetch CVEs from NVD for a keyword, up to days_back days."""
    from datetime import datetime, timedelta, timezone
    now   = datetime.now(timezone.utc)
    start = (now - timedelta(days=days_back)).strftime("%Y-%m-%dT%H:%M:%S.000")
    end   = now.strftime("%Y-%m-%dT%H:%M:%S.000")

    url = (f"{NVD_BASE}?keywordSearch={urllib.parse.quote(keyword)}"
           f"&lastModStartDate={urllib.parse.quote(start)}"
           f"&lastModEndDate={urllib.parse.quote(end)}"
           f"&resultsPerPage=100")

    headers = {}
    if NVD_API_KEY:
        headers["apiKey"] = NVD_API_KEY
    # Rate limiting: 5 req/30s without key, 50 with key
    if not NVD_API_KEY:
        time.sleep(6.5)  # stay under 5/30s limit

    data = _get(url, timeout=20, headers=headers)
    if not data: return 0

    count = 0
    for item in data.get("vulnerabilities", []):
        cve_data = item.get("cve", {})
        cve_id   = cve_data.get("id", "")
        if not cve_id: continue

        cvss  = _extract_cvss(cve_data.get("metrics", {}))
        sev   = _sev_from_cvss(cvss)
        descs = cve_data.get("descriptions", [])
        desc  = next((d["value"] for d in descs if d.get("lang")=="en"), "")[:500]
        tags  = _extract_tags(cve_id, keyword, desc)

        # Extract affected version ranges
        vmin = vmax = ""
        for cfg in cve_data.get("configurations", []):
            for node in cfg.get("nodes", []):
                for cpe in node.get("cpeMatch", []):
                    if cpe.get("vulnerable"):
                        vmin = cpe.get("versionStartIncluding", "") or cpe.get("versionStartExcluding","")
                        vmax = cpe.get("versionEndIncluding", "")   or cpe.get("versionEndExcluding","")
                        if vmin or vmax: break
                if vmin or vmax: break

        _upsert_cve(cve_id=cve_id, tech=keyword, severity=sev, cvss=cvss,
                    description=desc, tags=tags, source="nvd",
                    vmin=vmin, vmax=vmax)
        count += 1

    return count

def sync_nvd_recent(days_back: int = 30) -> int:
    """Sync all recently modified CVEs from NVD (not keyword-filtered)."""
    from datetime import datetime, timedelta, timezone
    log.info(f"[cve_sync] NVD recent sync (last {days_back} days)...")
    now   = datetime.now(timezone.utc)
    start = (now - timedelta(days=days_back)).strftime("%Y-%m-%dT%H:%M:%S.000")
    end   = now.strftime("%Y-%m-%dT%H:%M:%S.000")

    total = 0
    start_idx = 0
    page_size = 100

    while True:
        url = (f"{NVD_BASE}?lastModStartDate={urllib.parse.quote(start)}"
               f"&lastModEndDate={urllib.parse.quote(end)}"
               f"&resultsPerPage={page_size}&startIndex={start_idx}")
        headers = {"apiKey": NVD_API_KEY} if NVD_API_KEY else {}
        if not NVD_API_KEY: time.sleep(6.5)

        data = _get(url, timeout=20, headers=headers)
        if not data: break

        vulns = data.get("vulnerabilities", [])
        if not vulns: break

        for item in vulns:
            cve_data = item.get("cve", {})
            cve_id   = cve_data.get("id","")
            if not cve_id: continue
            cvss = _extract_cvss(cve_data.get("metrics",{}))
            if cvss < 7.0: continue  # only high/critical for recent sync
            sev  = _sev_from_cvss(cvss)
            descs = cve_data.get("descriptions",[])
            desc  = next((d["value"] for d in descs if d.get("lang")=="en"),"")[:500]

            # Extract tech from CPE data
            tech = "unknown"
            for cfg in cve_data.get("configurations",[]):
                for node in cfg.get("nodes",[]):
                    for cpe in node.get("cpeMatch",[]):
                        cpe_uri = cpe.get("criteria","")
                        parts   = cpe_uri.split(":")
                        if len(parts) > 4:
                            tech = parts[4].replace("_"," ")
                            break
                    if tech != "unknown": break
                if tech != "unknown": break

            tags = _extract_tags(cve_id, tech, desc)
            _upsert_cve(cve_id=cve_id, tech=tech, severity=sev,
                        cvss=cvss, description=desc, tags=tags, source="nvd")
            total += 1

        result_per_page = data.get("resultsPerPage", 0)
        total_results   = data.get("totalResults", 0)
        start_idx      += result_per_page
        if start_idx >= min(total_results, 2000):  # cap at 2000 per sync
            break
        if not NVD_API_KEY: time.sleep(6.5)

    log.info(f"[cve_sync] NVD recent: {total} CVEs (high/critical only)")
    return total

# ── 3. EPSS scores ────────────────────────────────────────────────────────────
def sync_epss_for_critical() -> int:
    """
    Fetch EPSS (Exploit Prediction Scoring System) scores for critical CVEs.
    EPSS = probability 0-1 that a CVE will be exploited in next 30 days.
    High EPSS + in KEV = prioritize immediately.
    """
    try:
        conn  = _cve_db()
        cvids = [r[0] for r in conn.execute(
            "SELECT cve_id FROM cve_cache WHERE severity IN ('critical','high') "
            "ORDER BY cvss_score DESC LIMIT 500").fetchall()]
    except Exception:
        return 0
    if not cvids: return 0

    # EPSS accepts comma-separated CVE IDs
    batch_size = 100
    updated = 0
    for i in range(0, len(cvids), batch_size):
        batch = cvids[i:i+batch_size]
        url   = f"{EPSS_API}?cve={','.join(batch)}"
        data  = _get(url, timeout=15)
        if not data: continue
        for item in data.get("data", []):
            cve_id = item.get("cve","")
            epss   = float(item.get("epss", 0))
            try:
                conn.execute("UPDATE cve_cache SET epss_score=? WHERE cve_id=?",
                             (epss, cve_id))
                updated += 1
            except Exception: pass
        conn.commit()
        time.sleep(0.5)

    log.info(f"[cve_sync] EPSS: updated {updated} scores")
    return updated

# ── 4. OSV sync ───────────────────────────────────────────────────────────────
def sync_osv_packages() -> int:
    """Sync vulnerabilities from OSV.dev for key packages."""
    total = 0
    for ecosystem, packages in OSV_PACKAGES.items():
        for package in packages:
            data = _post_json(OSV_QUERY_URL,
                              {"package": {"name": package, "ecosystem": ecosystem}},
                              timeout=10)
            if not data: continue
            for vuln in data.get("vulns", []):
                vid  = vuln.get("id","")
                cve  = next((a for a in vuln.get("aliases",[]) if a.startswith("CVE-")), vid)
                if not cve: continue
                desc = vuln.get("summary","")[:500]
                sev  = "medium"
                for s in vuln.get("severity",[]):
                    score = s.get("score","")
                    if "CRITICAL" in score.upper(): sev="critical"; break
                    elif "HIGH" in score.upper():   sev="high";     break
                cvss = 9.0 if sev=="critical" else 7.5 if sev=="high" else 5.0
                tags = _extract_tags(cve, package, desc)

                # Version ranges from OSV affected block
                vmin = vmax = ""
                for affected in vuln.get("affected", []):
                    for r in affected.get("ranges",[]):
                        for ev in r.get("events",[]):
                            if "introduced" in ev: vmin = ev["introduced"]
                            if "fixed"      in ev: vmax = ev["fixed"]

                _upsert_cve(cve_id=cve, tech=package, severity=sev,
                            cvss=cvss, description=desc, tags=tags,
                            source="osv", vmin=vmin, vmax=vmax)
                total += 1
            time.sleep(0.3)  # gentle rate limiting
    log.info(f"[cve_sync] OSV: {total} vulnerabilities synced")
    return total

# ── 5. GitHub Security Advisories ────────────────────────────────────────────
def sync_github_advisories(limit: int = 200) -> int:
    """
    Sync critical/high GitHub Security Advisories.
    No auth needed for public advisories. Covers npm, PyPI, Go, Maven.
    """
    url  = f"{GITHUB_ADV_URL}?per_page=100&severity=critical,high&type=reviewed"
    data = _get(url, timeout=15,
                headers={"Accept": "application/vnd.github+json",
                         "X-GitHub-Api-Version": "2022-11-28"})
    if not data or not isinstance(data, list): return 0

    count = 0
    for adv in data[:limit]:
        ghsa  = adv.get("ghsa_id","")
        cve   = adv.get("cve_id","") or ghsa
        if not cve: continue
        sev   = adv.get("severity","medium").lower()
        desc  = adv.get("summary","")[:500]
        cvss  = float(adv.get("cvss",{}).get("score", 0) or
                      (9.5 if sev=="critical" else 7.5))
        for vuln in adv.get("vulnerabilities",[]):
            pkg  = vuln.get("package",{}).get("name","unknown")
            eco  = vuln.get("package",{}).get("ecosystem","").lower()
            tech = pkg
            tags = _extract_tags(cve, tech, desc)
            vmin = vuln.get("vulnerable_version_range","").split(",")[0].strip(">=< ")
            vmax = vuln.get("first_patched_version","")
            _upsert_cve(cve_id=cve, tech=tech, severity=sev, cvss=cvss,
                        description=desc, tags=tags, source="github",
                        vmin=vmin, vmax=vmax)
            count += 1

    log.info(f"[cve_sync] GitHub Advisories: {count} vulnerabilities")
    return count

# ── Sync orchestrator ─────────────────────────────────────────────────────────
_sync_lock   = threading.Lock()
_sync_status = {
    "running":       False,
    "last_sync_at":  None,
    "last_sync_type": None,
    "total_cves":    0,
    "sources":       {},
    "error":         None,
}

def run_full_sync(mode: str = "startup") -> Dict:
    """
    Run a full CVE sync. Modes:
      startup  — CISA KEV + NVD last 30 days + EPSS (fast, ~2 min)
      weekly   — all sources, all keywords (~10 min without API key)
      quick    — CISA KEV only (~30 seconds)
    """
    with _sync_lock:
        if _sync_status["running"]:
            return {"ok": False, "reason": "sync already running"}
        _sync_status["running"]     = True
        _sync_status["error"]       = None
        _sync_status["last_sync_type"] = mode

    results = {}
    try:
        log.info(f"[cve_sync] starting {mode} sync...")

        # Always sync CISA KEV first — these are actively exploited
        results["cisa_kev"] = sync_cisa_kev()

        if mode in ("startup", "weekly"):
            # NVD recent high/critical CVEs (last 30 days)
            results["nvd_recent"] = sync_nvd_recent(days_back=30)

        if mode == "weekly":
            # Full keyword sweep
            kw_total = 0
            for i, kw in enumerate(SYNC_KEYWORDS):
                try:
                    n = sync_nvd_keyword(kw, days_back=365)
                    kw_total += n
                    log.info(f"[cve_sync] NVD keyword [{i+1}/{len(SYNC_KEYWORDS)}]"
                             f" '{kw}': {n} CVEs")
                except Exception as e:
                    log.debug(f"[cve_sync] keyword '{kw}': {e}")
            results["nvd_keywords"] = kw_total

            # OSV packages
            results["osv"] = sync_osv_packages()

            # GitHub advisories
            results["github"] = sync_github_advisories()

        # Always update EPSS scores for critical CVEs
        if mode in ("startup","weekly"):
            results["epss"] = sync_epss_for_critical()

        # Get final count
        from engine.cve_engine import get_cve_stats
        stats = get_cve_stats()
        total = stats.get("total_cves", 0)

        _sync_status.update({
            "running":       False,
            "last_sync_at":  time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "total_cves":    total,
            "sources":       results,
        })
        log.info(f"[cve_sync] {mode} sync complete — total={total} sources={results}")
        return {"ok": True, "mode": mode, "total_cves": total, "results": results}

    except Exception as e:
        _sync_status["running"] = False
        _sync_status["error"]   = str(e)
        log.error(f"[cve_sync] sync error: {e}")
        return {"ok": False, "error": str(e)}


def get_sync_status() -> Dict:
    return dict(_sync_status)


def start_background_sync(mode: str = "startup"):
    """Fire sync in background thread — non-blocking."""
    t = threading.Thread(target=run_full_sync, args=(mode,),
                         daemon=True, name=f"cve-sync-{mode}")
    t.start()
    return t


def schedule_weekly_sync():
    """Background thread that re-syncs every 7 days."""
    def _loop():
        time.sleep(3600)  # wait 1h after startup before first weekly
        while True:
            try:
                run_full_sync("weekly")
            except Exception as e:
                log.error(f"[cve_sync] weekly error: {e}")
            time.sleep(7 * 24 * 3600)

    t = threading.Thread(target=_loop, daemon=True, name="cve-weekly-sync")
    t.start()
    return t
