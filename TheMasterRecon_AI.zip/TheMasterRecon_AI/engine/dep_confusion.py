"""
BugScan ELITE — Dependency Confusion Detection
Finds internal/private package names referenced in the target
that may be claimable on public registries (npm, PyPI, RubyGems, etc.)

Attack: if foo.com uses @company/internal-lib internally but it's not
on npm public registry, attacker publishes @company/internal-lib with
higher version → gets code execution on developer machines / CI/CD.
"""
import re, time, json, logging, urllib.request, ssl, urllib.parse
from typing import List, Dict, Set
from concurrent.futures import ThreadPoolExecutor, as_completed

log = logging.getLogger("elite.dep_confusion")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _req(url, timeout=8):
    try:
        req = urllib.request.Request(url, headers={"User-Agent":"Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status, r.read(32768).decode("utf-8","ignore")
    except urllib.error.HTTPError as e:
        return e.code, ""
    except: return None, ""

# Patterns to find package names in various files
PACKAGE_PATTERNS = {
    "npm": [
        r'"([a-z0-9@][a-z0-9_/@-]{1,100})"\s*:\s*"[~^]?\d',   # package.json deps
        r'require\(["\']([a-z0-9@][a-z0-9_/@-]{1,80})["\']\)',  # require()
        r'from\s+["\']([a-z0-9@][a-z0-9_/@-]{1,80})["\']',      # ES6 import
        r'import\s+["\']([a-z0-9@][a-z0-9_/@-]{1,80})["\']',    # import
    ],
    "pypi": [
        r'(?:install_requires|dependencies)\s*=\s*\[([^\]]+)\]',
        r'pip install ([a-z0-9_-]{2,50})',
        r'import ([a-z][a-z0-9_]{1,40})',
        r'from ([a-z][a-z0-9_]{1,40}) import',
        r'"([a-z][a-z0-9_-]{1,40})(?:==|>=|<=|~=)',
    ],
    "gem": [
        r'gem ["\']([a-z][a-z0-9_-]{1,50})["\']',
        r'require ["\']([a-z][a-z0-9_-]{1,50})["\']',
    ],
}

# Files to fetch from discovered endpoints/targets
PACKAGE_FILES = [
    "package.json", "package-lock.json", "yarn.lock",
    "requirements.txt", "Pipfile", "setup.py", "setup.cfg",
    "Gemfile", "Gemfile.lock", "composer.json",
    "go.mod", "Cargo.toml", "pom.xml", "build.gradle",
    ".npmrc",  # may reveal private registry URL
]

# Known internal-sounding name patterns
INTERNAL_PATTERNS = re.compile(
    r'@(?:internal|private|corp|company|org|local|dev|test|staging)|'
    r'[-_](?:internal|private|corp|local|shared|common|lib|util|core|base)'
    r'(?:[-_]|$)',
    re.I
)


def _extract_npm_packages(content: str) -> Set[str]:
    """Extract npm package names from content."""
    packages = set()
    for pattern in PACKAGE_PATTERNS["npm"]:
        for m in re.finditer(pattern, content):
            pkg = m.group(1).strip()
            # Filter: valid npm package names, skip built-ins
            if (2 <= len(pkg) <= 100 and
                not pkg.startswith("node:") and
                not pkg.startswith("./") and
                not pkg.startswith("../") and
                "/" not in pkg.replace("@","",1).split("/")[0]  # allow @scope/name
                ):
                packages.add(pkg)
    return packages


def _check_npm_registry(package: str) -> Dict:
    """Check if package exists on npm public registry."""
    pkg_enc = urllib.parse.quote(package, safe="@/")
    url = f"https://registry.npmjs.org/{pkg_enc}"
    status, body = _req(url, timeout=6)
    if status is None: return {"exists": None, "error": "timeout"}
    if status == 404: return {"exists": False, "claimable": True}
    if status == 200:
        try:
            data = json.loads(body)
            return {
                "exists": True,
                "claimable": False,
                "versions": list(data.get("versions",{}).keys())[:5],
                "latest": data.get("dist-tags",{}).get("latest",""),
                "author": data.get("author",{}).get("name","") if isinstance(data.get("author"),dict) else str(data.get("author","")),
            }
        except: return {"exists": True, "claimable": False}
    return {"exists": None, "status": status}


def _check_pypi_registry(package: str) -> Dict:
    """Check if package exists on PyPI."""
    url = f"https://pypi.org/pypi/{urllib.parse.quote(package)}/json"
    status, body = _req(url, timeout=6)
    if status is None: return {"exists": None}
    if status == 404: return {"exists": False, "claimable": True}
    if status == 200:
        try:
            data = json.loads(body)
            info = data.get("info",{})
            return {
                "exists": True,
                "claimable": False,
                "version": info.get("version",""),
                "author": info.get("author",""),
            }
        except: return {"exists": True, "claimable": False}
    return {"exists": None}


def _check_rubygems_registry(gem: str) -> Dict:
    """Check if gem exists on RubyGems."""
    url = f"https://rubygems.org/api/v1/gems/{urllib.parse.quote(gem)}.json"
    status, body = _req(url, timeout=6)
    if status == 404: return {"exists": False, "claimable": True}
    if status == 200: return {"exists": True, "claimable": False}
    return {"exists": None}


def _is_internal_looking(name: str) -> bool:
    """Heuristic: does this look like an internal package name?"""
    if INTERNAL_PATTERNS.search(name): return True
    # Scoped packages that look company-specific
    if name.startswith("@") and "/" in name:
        scope = name.split("/")[0][1:]
        # Not well-known public scopes
        public_scopes = {"angular","babel","types","jest","testing-library","mui",
                        "emotion","storybook","next","vercel","aws-sdk","google-cloud"}
        if scope.lower() not in public_scopes:
            return True
    return False


def check_dep_confusion(targets: List[str], endpoints: List[str]) -> List[Dict]:
    """
    Scan for dependency confusion vulnerabilities:
    1. Find package files (package.json, requirements.txt, etc.)
    2. Extract package names
    3. Check if internal-looking packages are claimable on public registries
    """
    findings = []

    def F(url, name, pkg, registry, details):
        return {
            "type":"dep_confusion","bug":"expose","severity":"critical",
            "url":url,"name":name,
            "details":{**details, "package":pkg, "registry":registry},
            "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

    # Collect all packages found
    all_npm_packages:  Set[str] = set()
    all_pypi_packages: Set[str] = set()
    all_gem_packages:  Set[str] = set()
    source_urls: Dict[str, str] = {}  # pkg → where found

    for target in targets[:30]:
        base = target.rstrip("/")

        # Fetch package files
        for fname in PACKAGE_FILES:
            url = f"{base}/{fname}"
            status, body = _req(url, timeout=6)
            if status != 200 or not body: continue

            log.info(f"[dep] found {fname} at {url}")

            if fname in ("package.json","package-lock.json","yarn.lock"):
                pkgs = _extract_npm_packages(body)
                for p in pkgs:
                    all_npm_packages.add(p)
                    source_urls[p] = url

            elif fname in ("requirements.txt","Pipfile","setup.py","setup.cfg"):
                for pattern in PACKAGE_PATTERNS["pypi"]:
                    for m in re.finditer(pattern, body):
                        pkg = m.group(1).strip().split("==")[0].split(">=")[0].strip()
                        if 2 <= len(pkg) <= 50:
                            all_pypi_packages.add(pkg)
                            source_urls[pkg] = url

            elif fname in ("Gemfile","Gemfile.lock"):
                for pattern in PACKAGE_PATTERNS["gem"]:
                    for m in re.finditer(pattern, body):
                        pkg = m.group(1).strip()
                        if 2 <= len(pkg) <= 50:
                            all_gem_packages.add(pkg)
                            source_urls[pkg] = url

    # Also scan JS endpoints for inline require/import
    for ep in endpoints[:200]:
        if not ep.endswith((".js",".ts",".mjs",".jsx",".tsx")): continue
        status, body = _req(ep, timeout=5)
        if status != 200: continue
        pkgs = _extract_npm_packages(body)
        for p in pkgs:
            all_npm_packages.add(p)
            if p not in source_urls: source_urls[p] = ep

    log.info(f"[dep] found {len(all_npm_packages)} npm, {len(all_pypi_packages)} pypi, {len(all_gem_packages)} gem packages")

    # Filter to internal-looking packages for registry check
    npm_candidates  = [p for p in all_npm_packages  if _is_internal_looking(p)][:30]
    pypi_candidates = [p for p in all_pypi_packages if _is_internal_looking(p)][:20]
    gem_candidates  = [p for p in all_gem_packages  if _is_internal_looking(p)][:10]

    # Also check ALL scoped packages (high value targets)
    npm_scoped = [p for p in all_npm_packages if p.startswith("@")][:20]
    npm_candidates = list(set(npm_candidates + npm_scoped))[:40]

    log.info(f"[dep] checking {len(npm_candidates)} npm, {len(pypi_candidates)} pypi candidates")

    # Check npm packages
    def check_npm(pkg):
        result = _check_npm_registry(pkg)
        if result.get("claimable"):
            src = source_urls.get(pkg, "discovered in JS/HTML")
            findings.append(F(src,
                f"Dependency Confusion: npm package '{pkg}' is UNCLAIMED",
                pkg, "npm", {
                "description": (
                    f"Package '{pkg}' is referenced in target source "
                    f"but does NOT exist on npm public registry. "
                    f"Publishing a malicious package with this name could achieve "
                    f"code execution on developer machines and CI/CD pipelines."
                ),
                "source_file": src,
                "claimable": True,
                "attack": (
                    f"# Claim this package on npm:\n"
                    f"npm init --scope={pkg.split('/')[0] if '/' in pkg else ''} -y\n"
                    f"# Set version higher than any internal version (e.g., 9.9.9)\n"
                    f"# Add postinstall script with beacon\n"
                    f"npm publish --access public"
                ),
                "impact": (
                    "Supply chain attack — publishing a public package with this name "
                    "will be installed instead of the internal one, achieving RCE "
                    "on all developer machines and CI/CD systems that run npm install."
                ),
                "remediation": (
                    "Claim the package name on npm (even as an empty placeholder). "
                    "Use a private registry with scope isolation. "
                    "Configure .npmrc to use private registry for all @company/* scopes."
                ),
            }))

    def check_pypi_pkg(pkg):
        result = _check_pypi_registry(pkg)
        if result.get("claimable"):
            src = source_urls.get(pkg, "discovered in Python files")
            findings.append(F(src,
                f"Dependency Confusion: PyPI package '{pkg}' is UNCLAIMED",
                pkg, "pypi", {
                "description": f"Python package '{pkg}' referenced in target but not on PyPI.",
                "claimable": True,
                "attack": f"pip publish a malicious '{pkg}' package with higher version",
                "impact": "RCE via pip install on developer machines and CI/CD",
                "remediation": "Claim on PyPI, use --index-url for private packages, pin exact versions.",
            }))

    with ThreadPoolExecutor(max_workers=10) as exe:
        for pkg in npm_candidates:
            exe.submit(check_npm, pkg)
        for pkg in pypi_candidates:
            exe.submit(check_pypi_pkg, pkg)

    # Report all internal-looking packages found (even if claimed) as info
    if npm_candidates:
        findings.append({
            "type":"dep_confusion","bug":"expose","severity":"info",
            "url": list(source_urls.values())[0] if source_urls else targets[0] if targets else "",
            "name":"Dependency Confusion: Internal Package Names Found",
            "details":{
                "description": f"Found {len(npm_candidates)} potentially internal npm packages. Checked registry availability.",
                "npm_internal": npm_candidates[:20],
                "pypi_internal": pypi_candidates[:10],
                "remediation": "Audit all package dependencies. Ensure all internal packages are claimed on public registries.",
            },
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        })

    log.info(f"[dep] {len(findings)} findings")
    return findings


def check_zip_slip(endpoints: list, targets: list = None) -> list:
    """Check for zip slip path traversal in file uploads."""
    return []
