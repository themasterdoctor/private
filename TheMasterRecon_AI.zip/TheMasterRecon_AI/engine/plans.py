"""
BugScan ELITE — SaaS Plans & Multi-Tenant Engine
Plan enforcement, API key auth, usage tracking, Stripe integration hooks.
"""
import json, time, hashlib, secrets, sqlite3, logging, os
from typing import Dict, List, Optional
from pathlib import Path
from functools import wraps

log = logging.getLogger("elite.plans")

_DB_PATH = Path(os.path.dirname(__file__)).parent / "data" / "saas.db"
_DB_PATH.parent.mkdir(parents=True, exist_ok=True)

# ── Plan definitions ──────────────────────────────────────────────────────────
PLANS = {
    "free": {
        "name":            "Free",
        "price_monthly":   0,
        "domains_limit":   1,
        "scans_per_month": 5,
        "subs_limit":      50,
        "endpoints_limit": 200,
        "bugs_allowed":    ["xss","sqli","expose","cors","redirect","takeover","jsleak"],
        "features": {
            "ai_risk_score":    False,
            "executive_report": False,
            "poc_generator":    False,
            "monitoring":       False,
            "api_access":       False,
            "attack_chains":    False,
            "knowledge_graph":  False,
            "apex_brain":       False,
            "commix":           False,
        },
        "rate_limit_rps":  2,
    },
    "pro": {
        "name":            "Pro",
        "price_monthly":   49,
        "domains_limit":   10,
        "scans_per_month": 50,
        "subs_limit":      500,
        "endpoints_limit": 5000,
        "bugs_allowed":    "all",
        "features": {
            "ai_risk_score":    True,
            "executive_report": True,
            "poc_generator":    True,
            "monitoring":       True,
            "api_access":       True,
            "attack_chains":    True,
            "knowledge_graph":  True,
            "apex_brain":       False,
            "commix":           False,
        },
        "rate_limit_rps":  10,
    },
    "elite": {
        "name":            "Elite",
        "price_monthly":   149,
        "domains_limit":   50,
        "scans_per_month": 500,
        "subs_limit":      5000,
        "endpoints_limit": 50000,
        "bugs_allowed":    "all",
        "features": {
            "ai_risk_score":    True,
            "executive_report": True,
            "poc_generator":    True,
            "monitoring":       True,
            "api_access":       True,
            "attack_chains":    True,
            "knowledge_graph":  True,
            "apex_brain":       True,
            "commix":           True,
        },
        "rate_limit_rps":  50,
    },
    "enterprise": {
        "name":            "Enterprise",
        "price_monthly":   499,
        "domains_limit":   -1,   # unlimited
        "scans_per_month": -1,
        "subs_limit":      -1,
        "endpoints_limit": -1,
        "bugs_allowed":    "all",
        "features": {k: True for k in [
            "ai_risk_score","executive_report","poc_generator",
            "monitoring","api_access","attack_chains","knowledge_graph",
            "apex_brain","commix","white_label","sso","dedicated_support",
        ]},
        "rate_limit_rps": 200,
    },
}

# ── Database ──────────────────────────────────────────────────────────────────
def _get_db():
    conn = sqlite3.connect(str(_DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id          TEXT PRIMARY KEY,
            email       TEXT UNIQUE,
            plan        TEXT DEFAULT 'free',
            api_key     TEXT UNIQUE,
            stripe_id   TEXT DEFAULT '',
            created     REAL,
            active      INTEGER DEFAULT 1,
            scans_used  INTEGER DEFAULT 0,
            scans_reset REAL DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS api_usage (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id   TEXT,
            endpoint  TEXT,
            domain    TEXT DEFAULT '',
            ts        REAL,
            plan      TEXT
        )
    """)
    conn.commit()
    return conn

# ── User management ───────────────────────────────────────────────────────────
def create_user(email: str, plan: str = "free") -> Dict:
    user_id = hashlib.sha256(email.encode()).hexdigest()[:16]
    api_key = "bse_" + secrets.token_urlsafe(32)
    now     = time.time()
    with _get_db() as db:
        try:
            db.execute(
                "INSERT INTO users (id,email,plan,api_key,created,scans_reset) VALUES (?,?,?,?,?,?)",
                (user_id, email, plan, api_key, now, now + 2592000)
            )
        except sqlite3.IntegrityError:
            # User exists — return existing
            row = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
            if row: return dict(row)
    return {"id": user_id, "email": email, "plan": plan, "api_key": api_key}

def get_user_by_key(api_key: str) -> Optional[Dict]:
    with _get_db() as db:
        row = db.execute("SELECT * FROM users WHERE api_key=? AND active=1",
                         (api_key,)).fetchone()
    return dict(row) if row else None

def get_user_by_email(email: str) -> Optional[Dict]:
    with _get_db() as db:
        row = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    return dict(row) if row else None

def upgrade_plan(user_id: str, new_plan: str, stripe_id: str = ""):
    with _get_db() as db:
        db.execute("UPDATE users SET plan=?, stripe_id=? WHERE id=?",
                   (new_plan, stripe_id, user_id))

def rotate_api_key(user_id: str) -> str:
    new_key = "bse_" + secrets.token_urlsafe(32)
    with _get_db() as db:
        db.execute("UPDATE users SET api_key=? WHERE id=?", (new_key, user_id))
    return new_key

# ── Usage tracking ────────────────────────────────────────────────────────────
def get_scans_used(user_id: str) -> int:
    """Get scans used this month (resets monthly)."""
    now = time.time()
    with _get_db() as db:
        row = db.execute("SELECT scans_used, scans_reset FROM users WHERE id=?",
                         (user_id,)).fetchone()
        if not row: return 0
        if row["scans_reset"] < now:
            # Reset monthly counter
            next_reset = now + 2592000
            db.execute("UPDATE users SET scans_used=0, scans_reset=? WHERE id=?",
                        (next_reset, user_id))
            return 0
        return row["scans_used"]

def increment_scan_usage(user_id: str):
    with _get_db() as db:
        db.execute("UPDATE users SET scans_used=scans_used+1 WHERE id=?", (user_id,))

def log_api_call(user_id: str, endpoint: str, domain: str = "", plan: str = ""):
    with _get_db() as db:
        db.execute("INSERT INTO api_usage (user_id,endpoint,domain,ts,plan) VALUES (?,?,?,?,?)",
                   (user_id, endpoint, domain, time.time(), plan))

# ── Plan enforcement ──────────────────────────────────────────────────────────
def check_plan_limit(user: Dict, resource: str, value=None) -> Dict:
    """
    Check if user is within plan limits.
    Returns: {allowed: bool, reason: str, limit: int, used: int}
    """
    plan_id   = user.get("plan","free")
    plan      = PLANS.get(plan_id, PLANS["free"])
    user_id   = user.get("id","")

    if resource == "scan":
        limit = plan["scans_per_month"]
        used  = get_scans_used(user_id)
        if limit == -1: return {"allowed": True}
        if used >= limit:
            return {"allowed": False,
                    "reason": f"Scan limit reached ({used}/{limit} this month). Upgrade to continue.",
                    "limit":  limit, "used": used, "upgrade_to": _next_plan(plan_id)}

    elif resource == "feature":
        feature = value
        features = plan.get("features", {})
        if not features.get(feature, False):
            return {"allowed": False,
                    "reason":  f"'{feature}' requires {_min_plan_for_feature(feature)} plan or higher.",
                    "upgrade_to": _min_plan_for_feature(feature)}

    elif resource == "bug":
        allowed_bugs = plan.get("bugs_allowed", [])
        if allowed_bugs != "all" and value not in allowed_bugs:
            return {"allowed": False,
                    "reason": f"Bug type '{value}' requires Pro plan or higher.",
                    "upgrade_to": "pro"}

    elif resource == "subs":
        limit = plan.get("subs_limit",-1)
        if limit != -1 and value and int(value) > limit:
            return {"allowed": True, "capped_to": limit,
                    "reason": f"Subdomain limit: {limit} on {plan['name']} plan"}

    return {"allowed": True}

def get_plan_info(plan_id: str) -> Dict:
    return PLANS.get(plan_id, PLANS["free"])

def _next_plan(current: str) -> str:
    order = ["free","pro","elite","enterprise"]
    idx   = order.index(current) if current in order else 0
    return order[min(idx+1, len(order)-1)]

def _min_plan_for_feature(feature: str) -> str:
    for plan_id in ["free","pro","elite","enterprise"]:
        if PLANS[plan_id].get("features",{}).get(feature,False):
            return plan_id
    return "enterprise"

# ── Flask middleware helpers ──────────────────────────────────────────────────
def get_api_user_from_request(request) -> Optional[Dict]:
    """Extract and validate API key from request."""
    # Check Authorization header
    auth = request.headers.get("Authorization","")
    if auth.startswith("Bearer "):
        key = auth[7:]
    else:
        key = request.headers.get("X-API-Key","") or request.args.get("api_key","")

    if not key:
        return None
    return get_user_by_key(key)

def require_feature(feature: str):
    """Flask decorator: require a specific plan feature."""
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            from flask import request, jsonify
            user = get_api_user_from_request(request)
            if not user:
                # Allow local access (no API key = local usage = elite)
                if request.remote_addr in ("127.0.0.1","::1"):
                    return fn(*args, **kwargs)
                return jsonify({"error": "API key required", "docs": "/api/docs"}), 401
            check = check_plan_limit(user, "feature", feature)
            if not check["allowed"]:
                return jsonify({"error": check["reason"],
                                "upgrade": f"/upgrade?to={check.get('upgrade_to','pro')}"}), 403
            log_api_call(user["id"], request.path, plan=user.get("plan",""))
            return fn(*args, **kwargs)
        return wrapper
    return decorator

def require_scan_quota():
    """Flask decorator: enforce scan count limits."""
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            from flask import request, jsonify
            user = get_api_user_from_request(request)
            if not user or request.remote_addr in ("127.0.0.1","::1"):
                return fn(*args, **kwargs)
            check = check_plan_limit(user, "scan")
            if not check["allowed"]:
                return jsonify({"error": check["reason"],
                                "upgrade": f"/upgrade?to={check.get('upgrade_to','pro')}"}), 429
            increment_scan_usage(user["id"])
            return fn(*args, **kwargs)
        return wrapper
    return decorator

def get_usage_stats(user_id: str) -> Dict:
    """Return usage stats for user dashboard."""
    user = None
    with _get_db() as db:
        row = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        if row: user = dict(row)
    if not user: return {}

    plan = PLANS.get(user.get("plan","free"), PLANS["free"])
    used = get_scans_used(user_id)
    limit = plan["scans_per_month"]

    # API calls this month
    month_ago = time.time() - 2592000
    with _get_db() as db:
        api_calls = db.execute(
            "SELECT COUNT(*) as cnt FROM api_usage WHERE user_id=? AND ts>?",
            (user_id, month_ago)
        ).fetchone()["cnt"]

    return {
        "plan":          plan["name"],
        "scans_used":    used,
        "scans_limit":   limit if limit > 0 else "Unlimited",
        "scans_pct":     int(used/limit*100) if limit > 0 else 0,
        "api_calls":     api_calls,
        "features":      plan["features"],
        "reset_date":    time.strftime("%Y-%m-%d", time.localtime(
                             time.time() + 2592000)),
        "upgrade_url":   "/upgrade" if plan["price_monthly"] < 499 else None,
    }
