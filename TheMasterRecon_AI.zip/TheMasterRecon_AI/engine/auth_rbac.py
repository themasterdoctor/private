"""
TheMasterRecon AI — RBAC Multi-User Authentication
Roles: admin, analyst, viewer
Sessions: JWT-based, stored in DB
"""
import os, json, hashlib, hmac, time, secrets, logging, re
from pathlib import Path
from typing import Optional, Dict, List
from functools import wraps

log = logging.getLogger("elite.auth_rbac")

# Roles and their permissions
ROLES = {
    "admin": {
        "can_scan":        True,
        "can_recon":       True,
        "can_delete":      True,
        "can_manage_users":True,
        "can_manage_scope":True,
        "can_export":      True,
        "can_view":        True,
        "can_ai":          True,
    },
    "analyst": {
        "can_scan":        True,
        "can_recon":       True,
        "can_delete":      False,
        "can_manage_users":False,
        "can_manage_scope":True,
        "can_export":      True,
        "can_view":        True,
        "can_ai":          True,
    },
    "viewer": {
        "can_scan":        False,
        "can_recon":       False,
        "can_delete":      False,
        "can_manage_users":False,
        "can_manage_scope":False,
        "can_export":      True,
        "can_view":        True,
        "can_ai":          False,
    },
}

SECRET_KEY = os.environ.get("TMR_SECRET_KEY", secrets.token_hex(32))
TOKEN_TTL   = int(os.environ.get("TMR_TOKEN_TTL", "86400"))  # 24h default


class UserDB:
    def __init__(self, data_dir: str = "./data"):
        self.db_path = Path(data_dir) / "_users" / "users.json"
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_default_admin()

    def _load(self) -> dict:
        if self.db_path.exists():
            try:
                return json.load(open(self.db_path))
            except Exception:
                pass
        return {"users": {}, "sessions": {}}

    def _save(self, data: dict):
        json.dump(data, open(self.db_path, "w"), indent=2)

    def _hash_password(self, password: str) -> str:
        salt = os.environ.get("TMR_SECRET_KEY", "tmr-default-salt")
        return hmac.new(salt.encode(), password.encode(), hashlib.sha256).hexdigest()

    def _ensure_default_admin(self):
        """Create default admin if no users exist."""
        data = self._load()
        if not data["users"]:
            default_pass = os.environ.get("TMR_ADMIN_PASSWORD", "TheMasterRecon2024!")
            data["users"]["admin"] = {
                "username":   "admin",
                "password":   self._hash_password(default_pass),
                "role":       "admin",
                "email":      "admin@localhost",
                "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
                "last_login": None,
                "active":     True,
            }
            self._save(data)
            log.info(f"[rbac] Default admin created (password: {default_pass})")


    def get_user_by_token(self, token: str) -> Optional[dict]:
        """Get user by session token."""
        data = self._load()
        sessions = data.get("sessions", {})
        session = sessions.get(token)
        if not session:
            return None
        import time
        if time.time() > session.get("expires", 0):
            return None
        username = session.get("username","")
        return data.get("users", {}).get(username)

    def authenticate(self, username: str, password: str) -> Optional[dict]:
        data = self._load()
        user = data["users"].get(username)
        if not user or not user.get("active"):
            return None
        if user["password"] != self._hash_password(password):
            return None
        # Update last login
        data["users"][username]["last_login"] = time.strftime("%Y-%m-%dT%H:%M:%SZ")
        self._save(data)
        return {k: v for k, v in user.items() if k != "password"}

    def create_session(self, username: str, role: str) -> str:
        token   = secrets.token_urlsafe(32)
        data    = self._load()
        data["sessions"][token] = {
            "username":   username,
            "role":       role,
            "created_at": time.time(),
            "expires_at": time.time() + TOKEN_TTL,
        }
        # Clean expired sessions
        data["sessions"] = {k: v for k, v in data["sessions"].items()
                            if v.get("expires_at", 0) > time.time()}
        self._save(data)
        return token

    def validate_session(self, token: str) -> Optional[dict]:
        if not token: return None
        data = self._load()
        sess = data["sessions"].get(token)
        if not sess: return None
        if sess.get("expires_at", 0) < time.time():
            del data["sessions"][token]
            self._save(data)
            return None
        return sess

    def revoke_session(self, token: str):
        data = self._load()
        data["sessions"].pop(token, None)
        self._save(data)

    def get_user(self, username: str) -> Optional[dict]:
        data = self._load()
        user = data["users"].get(username)
        if user:
            return {k: v for k, v in user.items() if k != "password"}
        return None

    def list_users(self) -> List[dict]:
        data = self._load()
        return [{k: v for k, v in u.items() if k != "password"}
                for u in data["users"].values()]

    def create_user(self, username: str, password: str, role: str,
                    email: str = "") -> dict:
        if role not in ROLES:
            raise ValueError(f"Invalid role: {role}")
        if not re.match(r'^[a-zA-Z0-9_.-]{3,32}$', username):
            raise ValueError("Username must be 3-32 alphanumeric chars")
        data = self._load()
        if username in data["users"]:
            raise ValueError(f"User {username} already exists")
        data["users"][username] = {
            "username":   username,
            "password":   self._hash_password(password),
            "role":       role,
            "email":      email,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "last_login": None,
            "active":     True,
        }
        self._save(data)
        return {k: v for k, v in data["users"][username].items() if k != "password"}

    def update_user(self, username: str, **kwargs) -> dict:
        data = self._load()
        if username not in data["users"]:
            raise ValueError(f"User {username} not found")
        if "password" in kwargs:
            kwargs["password"] = self._hash_password(kwargs["password"])
        if "role" in kwargs and kwargs["role"] not in ROLES:
            raise ValueError(f"Invalid role: {kwargs['role']}")
        data["users"][username].update(kwargs)
        self._save(data)
        return {k: v for k, v in data["users"][username].items() if k != "password"}

    def delete_user(self, username: str):
        if username == "admin":
            raise ValueError("Cannot delete the default admin user")
        data = self._load()
        data["users"].pop(username, None)
        # Revoke all sessions for this user
        data["sessions"] = {k: v for k, v in data["sessions"].items()
                            if v.get("username") != username}
        self._save(data)

    def has_permission(self, token: str, permission: str) -> bool:
        sess = self.validate_session(token)
        if not sess: return False
        role_perms = ROLES.get(sess.get("role", "viewer"), {})
        return role_perms.get(permission, False)

    def get_active_sessions(self) -> List[dict]:
        data = self._load()
        now  = time.time()
        return [{**v, "token": k[:8]+"..."} for k, v in data["sessions"].items()
                if v.get("expires_at", 0) > now]


# Singleton
_user_db: Optional[UserDB] = None

def get_user_db(data_dir: str = "./data") -> UserDB:
    global _user_db
    if _user_db is None:
        _user_db = UserDB(data_dir)
    return _user_db


def require_auth(permission: str = "can_view"):
    """Flask route decorator for authentication + permission check."""
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            from flask import request, jsonify
            token = (request.headers.get("X-TMR-Token") or
                     request.cookies.get("tmr_token") or
                     request.args.get("token"))
            # If auth is disabled (single-user mode), skip check
            if os.environ.get("TMR_AUTH_DISABLED","").lower() in ("1","true","yes"):
                return f(*args, **kwargs)
            db = get_user_db()
            sess = db.validate_session(token)
            if not sess:
                return jsonify({"error":"Unauthorized — login required","code":401}), 401
            role_perms = ROLES.get(sess.get("role","viewer"),{})
            if not role_perms.get(permission, False):
                return jsonify({"error":f"Forbidden — requires {permission}","code":403}), 403
            return f(*args, **kwargs)
        return wrapped
    return decorator


def get_current_user():
    """Get currently authenticated user from Flask request context."""
    try:
        from flask import request, g
        if hasattr(g, '_current_user_cache'):
            return g._current_user_cache
        token = request.cookies.get("tmr_token","")
        if not token:
            auth = request.headers.get("Authorization","")
            if auth.startswith("Bearer "):
                token = auth[7:]
        if not token:
            return None
        udb = get_user_db()
        user = udb.get_user_by_token(token)
        if user:
            g._current_user_cache = user
            return user
    except Exception:
        pass
    return None
