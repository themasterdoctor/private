"""
TheMasterRecon AI — API Schema Import Engine
Auto-discovers and imports Swagger/OpenAPI/GraphQL schemas.
Extracts all endpoints, params, auth requirements for targeted scanning.
"""
import re, json, ssl, logging, urllib.request, urllib.parse
from typing import List, Dict, Optional, Tuple

log = logging.getLogger("elite.api_schema")

SWAGGER_PATHS = [
    "/swagger.json","/swagger/v1/swagger.json","/swagger/v2/swagger.json",
    "/api-docs","/api-docs.json","/api/docs","/api/swagger.json",
    "/openapi.json","/openapi.yaml","/openapi/v1/openapi.json",
    "/v1/api-docs","/v2/api-docs","/v3/api-docs",
    "/api/v1/swagger.json","/api/v2/swagger.json","/api/v3/swagger.json",
    "/docs/swagger.json","/documentation/swagger.json",
    "/.well-known/openapi.json",
    "/swagger-ui.html","/swagger-ui/","/swagger/",
    "/api/swagger-ui.html","/redoc","/rapidoc",
]
GRAPHQL_PATHS = [
    "/graphql","/graphiql","/api/graphql","/gql",
    "/v1/graphql","/v2/graphql","/__graphql","/graph",
]


def _get(url: str, timeout: int = 10) -> Optional[Tuple[int, str]]:
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(url,
            headers={"User-Agent":"TheMasterRecon-AI/2.0",
                     "Accept":"application/json,text/yaml,*/*"})
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
            return r.status, r.read().decode("utf-8","ignore")
    except urllib.error.HTTPError as e:
        try: return e.code, e.read().decode("utf-8","ignore")
        except: return e.code, ""
    except Exception:
        return None


def discover_schemas(base_url: str) -> List[Dict]:
    """Probe common paths to find API schema definitions."""
    base = base_url.rstrip("/")
    found = []

    for path in SWAGGER_PATHS:
        url = base + path
        result = _get(url)
        if not result: continue
        st, body = result
        if st != 200 or len(body) < 100: continue

        # Detect schema type
        is_swagger   = '"swagger"' in body[:500] or '"openapi"' in body[:500]
        is_swagger_yaml = 'swagger:' in body[:200] or 'openapi:' in body[:200]
        is_swagger_ui = 'swagger-ui' in body.lower() or 'SwaggerUI' in body[:2000]

        if is_swagger or is_swagger_yaml:
            found.append({"type":"openapi","url":url,"size":len(body),"raw":body[:50000]})
        elif is_swagger_ui and 'swagger-ui.html' in path:
            # Try to find the actual JSON from the UI
            m = re.search(r'url:\s*["\']([^"\']+\.json)', body)
            if m:
                json_url = urljoin(base, m.group(1))
                r2 = _get(json_url)
                if r2 and r2[0] == 200:
                    found.append({"type":"openapi","url":json_url,"size":len(r2[1]),"raw":r2[1][:50000]})

    for path in GRAPHQL_PATHS:
        url = base + path
        result = _get(url)
        if not result: continue
        st, body = result
        if st in [200, 400]:  # 400 = endpoint exists but needs proper query
            if 'graphql' in body.lower() or '"data"' in body or '"errors"' in body or st == 400:
                found.append({"type":"graphql","url":url,"size":len(body)})

    return found


def parse_openapi(schema_raw: str) -> Dict:
    """Parse OpenAPI/Swagger JSON or YAML and extract all endpoints."""
    # Try JSON first
    schema = None
    try:
        schema = json.loads(schema_raw)
    except Exception:
        # Try YAML
        try:
            import yaml
            schema = yaml.safe_load(schema_raw)
        except Exception:
            pass

    if not schema:
        return {"error": "Could not parse schema", "endpoints": []}

    version  = schema.get("openapi","") or schema.get("swagger","")
    title    = schema.get("info",{}).get("title","Unknown API")
    api_ver  = schema.get("info",{}).get("version","")
    base     = schema.get("basePath","") or schema.get("servers",[{}])[0].get("url","")

    endpoints = []
    paths = schema.get("paths",{})

    for path, methods in paths.items():
        if not isinstance(methods, dict): continue
        for method, details in methods.items():
            if method.lower() in ("get","post","put","delete","patch","options","head"):
                # Extract parameters
                params = []
                for p in details.get("parameters",[]):
                    params.append({
                        "name":     p.get("name",""),
                        "in":       p.get("in",""),  # query/path/header/cookie/body
                        "required": p.get("required",False),
                        "type":     p.get("schema",{}).get("type","") or p.get("type",""),
                    })

                # Extract request body params
                req_body = details.get("requestBody",{})
                if req_body:
                    for ct, ct_schema in req_body.get("content",{}).items():
                        props = ct_schema.get("schema",{}).get("properties",{})
                        for pname, pschema in props.items():
                            params.append({
                                "name": pname, "in": "body",
                                "required": pname in ct_schema.get("schema",{}).get("required",[]),
                                "type": pschema.get("type","")
                            })

                # Check auth requirements
                security = details.get("security",[]) or schema.get("security",[])
                requires_auth = bool(security)

                endpoints.append({
                    "path":          path,
                    "method":        method.upper(),
                    "full_path":     base + path if base else path,
                    "summary":       details.get("summary",""),
                    "tags":          details.get("tags",[]),
                    "params":        params,
                    "requires_auth": requires_auth,
                    "deprecated":    details.get("deprecated",False),
                    # Interesting params for security testing
                    "interesting_params": [p["name"] for p in params
                                          if any(kw in p["name"].lower() for kw in
                                          ["id","user","admin","file","path","url","redirect",
                                           "token","key","secret","password","cmd","exec","query"])]
                })

    # Security definitions
    security_schemes = (schema.get("securityDefinitions",{}) or
                        schema.get("components",{}).get("securitySchemes",{}))

    return {
        "title":       title,
        "version":     api_ver,
        "spec_version": version,
        "base_url":    base,
        "endpoints":   endpoints,
        "total":       len(endpoints),
        "methods":     {},
        "auth_schemes": list(security_schemes.keys()),
        "has_auth":    bool(security_schemes),
        "attack_surface": {
            "unauthenticated": [e for e in endpoints if not e["requires_auth"]],
            "with_id_params":  [e for e in endpoints if e["interesting_params"]],
            "write_methods":   [e for e in endpoints if e["method"] in ("POST","PUT","PATCH","DELETE")],
        }
    }


def introspect_graphql(url: str) -> Optional[Dict]:
    """Run GraphQL introspection query to get full schema."""
    introspection_query = '''
    {"query":"{ __schema { queryType{name} mutationType{name} subscriptionType{name} types { name kind description fields { name type { name kind ofType { name kind } } args { name type { name kind } } } } } }"}
    '''
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(url,
            data=introspection_query.encode(),
            headers={"Content-Type":"application/json",
                     "User-Agent":"TheMasterRecon-AI/2.0"},
            method="POST")
        with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
            body = r.read().decode("utf-8","ignore")
            data = json.loads(body)
            schema = data.get("data",{}).get("__schema",{})
            if not schema:
                return None

            types = [t for t in schema.get("types",[])
                     if not t.get("name","").startswith("__")]
            queries    = [t for t in types if t.get("kind")=="OBJECT" and t.get("name")=="Query"]
            mutations  = [t for t in types if t.get("kind")=="OBJECT" and t.get("name")=="Mutation"]

            return {
                "url":         url,
                "types":       len(types),
                "has_mutations": bool(mutations),
                "type_names":  [t["name"] for t in types[:30]],
                "query_fields": [f["name"] for f in (queries[0].get("fields",[]) if queries else [])],
                "mutation_fields": [f["name"] for f in (mutations[0].get("fields",[]) if mutations else [])],
                "raw_schema":  schema,
            }
    except Exception as e:
        log.debug(f"[api_schema] graphql introspect: {e}")
        return None


def generate_attack_urls(parsed_schema: Dict, base_url: str) -> List[str]:
    """Generate targeted scan URLs from OpenAPI schema."""
    urls = []
    base = base_url.rstrip("/")

    for ep in parsed_schema.get("endpoints",[]):
        path = ep["path"]
        # Replace path params with test values
        path = re.sub(r'\{(\w+)\}', lambda m: "1" if "id" in m.group(1).lower() else "test", path)

        url = base + path
        method = ep["method"]

        # Add interesting param combinations
        q_params = [p for p in ep["params"] if p.get("in") == "query"]
        if q_params:
            query = "&".join(f"{p['name']}=test" for p in q_params[:5])
            url += "?" + query

        urls.append(f"{method} {url}")

    return urls
