"""
engine/bounty_report.py — Draft engine, scope gate, submission packages

All report generation is for human review only.
Auto-submission is not implemented and must never be added.
"""

import json, time, zipfile, logging
from pathlib import Path
from typing import Dict, Optional
from engine.bounty_db import (
    create_report, attach_evidence, get_report,
    set_status, verify_scope as _db_verify_scope
)
from engine.reporter import (
    generate_h1_report, generate_intigriti_report, generate_bugcrowd_report
)

log = logging.getLogger("elite.bounty_report")

_REPORTS_DIR = Path(__file__).parent.parent / "data" / "reports"

SEVERITY_RATIONALE = {
    "critical": "CVSS 9.0+. Direct impact on confidentiality/integrity/availability of critical data.",
    "high":     "CVSS 7.0-8.9. Significant security impact requiring prompt remediation.",
    "medium":   "CVSS 4.0-6.9. Moderate risk; exploitable under specific conditions.",
    "low":      "CVSS 0.1-3.9. Limited impact; defence-in-depth improvement.",
    "info":     "Informational. No direct exploitability but noteworthy for security posture.",
}


# ── Scope safety gate (Phase 6) ───────────────────────────────────────────────

def check_scope(domain: str, bug_type: str, severity: str,
                programs: list) -> Dict:
    """
    Check whether a finding is in scope before creating a draft.
    Returns {in_scope, program, platform, notes, verified}.

    Hard rule: verified=False unless a matching program with explicit
    scope entries exists.
    """
    if not programs:
        return {
            "verified":  False,
            "in_scope":  False,
            "program":   "",
            "platform":  "",
            "notes":     "No programs configured — add programs via /programs/import",
            "reason":    "scope_not_verified",
        }

    # Match domain against program scope entries
    for prog in programs:
        scope_entries = prog.get("scope", [])
        if not scope_entries:
            continue
        for entry in scope_entries:
            entry_domain = entry if isinstance(entry, str) else entry.get("domain","")
            if not entry_domain:
                continue
            # Wildcard or exact match
            if entry_domain.startswith("*."):
                parent = entry_domain[2:]
                if domain.endswith(parent) or domain == parent:
                    return _scope_match(prog, domain, bug_type, severity)
            elif entry_domain == domain or domain.endswith("." + entry_domain):
                return _scope_match(prog, domain, bug_type, severity)

    return {
        "verified": False,
        "in_scope": False,
        "program":  "",
        "platform": "",
        "notes":    f"Domain {domain} not found in any program scope",
        "reason":   "domain_not_in_scope",
    }


def _scope_match(prog: Dict, domain: str,
                 bug_type: str, severity: str) -> Dict:
    prog_name    = prog.get("name","") or prog.get("title","")
    platform     = prog.get("platform","") or prog.get("source","")
    out_of_scope = [t.lower() for t in prog.get("out_of_scope_bug_types",[])]
    min_sev      = prog.get("minimum_severity","info")
    SEV_ORDER    = ["info","low","medium","high","critical"]

    if bug_type.lower() in out_of_scope:
        return {
            "verified": True, "in_scope": False,
            "program":  prog_name, "platform": platform,
            "notes":    f"{bug_type} explicitly out of scope for {prog_name}",
            "reason":   "bug_type_out_of_scope",
        }
    if min_sev in SEV_ORDER and severity in SEV_ORDER:
        if SEV_ORDER.index(severity) < SEV_ORDER.index(min_sev):
            return {
                "verified": True, "in_scope": False,
                "program":  prog_name, "platform": platform,
                "notes":    f"{severity} below program minimum ({min_sev})",
                "reason":   "severity_below_minimum",
            }

    log.info(f"[bounty] scope_verified=true domain={domain}"
             f" program={prog_name} platform={platform}")
    return {
        "verified": True, "in_scope": True,
        "program":  prog_name, "platform": platform,
        "notes":    f"In scope for {prog_name} ({platform})",
        "reason":   "in_scope",
    }


# ── Draft creation (Phase 2) ──────────────────────────────────────────────────

def create_draft(domain: str, finding: Dict, programs: list) -> Dict:
    """
    Create a bounty report draft for a confirmed or needs_review finding.
    Rejected findings are blocked here.

    Returns {report_id, status, scope}.
    """
    bug  = finding.get("bug","")
    url  = finding.get("url","")
    sev  = finding.get("severity","medium")
    conf = finding.get("eil_confidence", finding.get("confidence",0))

    # Hard rule: no draft for rejected/unvalidated findings
    if not finding.get("eil_confirmed") and conf < 40:
        log.warning(f"[bounty] draft_blocked: eil_confirmed=false conf={conf}"
                    f" bug={bug} url={url[:60]}")
        return {"error": "rejected_finding", "report_id": None,
                "reason": "EIL validation failed — confidence too low for draft"}

    # Scope gate
    scope = check_scope(domain, bug, sev, programs)

    # Build steps_to_reproduce from EIL evidence
    raw_req  = finding.get("raw_request","") or finding.get("poc","")
    eil_ev   = finding.get("eil_evidence",{}) or {}
    payload  = finding.get("payload","") or finding.get("value","")
    steps    = _build_steps(bug, url, payload, raw_req, eil_ev)
    finding["steps_to_reproduce"] = steps
    finding["severity_rationale"] = SEVERITY_RATIONALE.get(sev, "")

    # Add title if missing
    if not finding.get("title"):
        from engine.reporter import BUG_DESCRIPTIONS
        desc = BUG_DESCRIPTIONS.get(bug, (bug.upper(), ""))[0]
        host = url.split("/")[2] if "/" in url else url
        finding["title"] = f"{desc} in {host}"

    # Create DB record
    rid = create_report(
        domain, finding,
        program_name    = scope.get("program",""),
        platform        = scope.get("platform",""),
        scope_verified  = scope.get("verified", False),
        scope_notes     = scope.get("notes",""),
    )

    # Attach evidence
    _attach_eil_evidence(rid, finding)

    # Save markdown draft
    _save_draft_md(rid, domain, finding, scope)

    return {"report_id": rid, "status": get_report(rid)["status"], "scope": scope}


def _build_steps(bug: str, url: str, payload: str,
                 raw_req: str, eil_evidence: Dict) -> list:
    steps = [
        f"Browse to: `{url}`",
    ]
    if payload:
        steps.append(f"Inject payload in vulnerable parameter: `{payload[:200]}`")
    if raw_req:
        steps.append(f"Send the following HTTP request:\n```\n{raw_req[:800]}\n```")
    markers = eil_evidence.get("markers_found",[])
    if markers:
        steps.append(f"Observe server response contains: `{', '.join(str(m) for m in markers[:3])}`")
    timing = eil_evidence.get("timing_delta_s")
    if timing and bug in ("sqli","ssrf"):
        steps.append(f"Response delay confirmed: {timing}s (above baseline)")
    steps.append("Compare response against baseline (no payload) to confirm behaviour is injected.")
    return steps


def _attach_eil_evidence(rid: str, finding: Dict) -> None:
    eil_ev = finding.get("eil_evidence",{}) or {}

    if finding.get("raw_request"):
        attach_evidence(rid, "raw_request", "HTTP Request",
                        finding["raw_request"][:5000])
    if finding.get("raw_response"):
        attach_evidence(rid, "raw_response", "HTTP Response (preview)",
                        finding["raw_response"][:3000])
    if eil_ev.get("probe_response"):
        pr = eil_ev["probe_response"]
        attach_evidence(rid, "raw_response", "Probe Response",
                        f"Status: {pr.get('status')}\n"
                        f"Headers: {json.dumps(dict(list(pr.get('headers',{}).items())[:10]))}\n"
                        f"Body preview:\n{pr.get('body','')[:2000]}")
    if eil_ev.get("baseline_response"):
        br = eil_ev["baseline_response"]
        attach_evidence(rid, "raw_request", "Baseline Response",
                        f"Status: {br.get('status')}\n"
                        f"Body preview:\n{br.get('body','')[:1000]}")
    if eil_ev.get("timing_delta_s") is not None:
        attach_evidence(rid, "timing",
                        "Timing Evidence",
                        f"timing_delta_s={eil_ev['timing_delta_s']}\n"
                        f"probe_elapsed={eil_ev.get('probe_elapsed','?')}\n"
                        f"baseline_elapsed={eil_ev.get('baseline_elapsed','?')}")
    if eil_ev.get("markers_found"):
        attach_evidence(rid, "markers",
                        "Response Markers",
                        "\n".join(str(m) for m in eil_ev["markers_found"]))
    proof = finding.get("eil_proof","")
    if proof:
        attach_evidence(rid, "markers", "EIL Proof Summary", proof[:1000])


def _save_draft_md(rid: str, domain: str,
                   finding: Dict, scope: Dict) -> None:
    try:
        report_dir = _REPORTS_DIR / domain
        report_dir.mkdir(parents=True, exist_ok=True)
        md = _render_md(rid, domain, finding, scope)
        path = report_dir / f"{rid}.md"
        path.write_text(md)
        log.info(f"[bounty] report_draft_saved path={path}")
    except Exception as e:
        log.warning(f"[bounty] draft_md save failed: {e}")


def _render_md(rid: str, domain: str,
               finding: Dict, scope: Dict) -> str:
    bug    = finding.get("bug","")
    sev    = finding.get("severity","medium").upper()
    url    = finding.get("url","")
    title  = finding.get("title","")
    conf   = finding.get("eil_confidence", finding.get("confidence",0))
    steps  = finding.get("steps_to_reproduce",[])
    impact = finding.get("impact","")
    remedi = finding.get("remediation","")
    rationale = finding.get("severity_rationale","")

    from engine.reporter import REMEDIATION_MAP
    if not remedi:
        remedi = REMEDIATION_MAP.get(bug,"Follow OWASP remediation guidelines.")

    steps_md = "\n".join(f"{i+1}. {s}" for i,s in enumerate(steps))
    scope_line = scope.get("notes","Not verified")
    prog_line  = f"{scope.get('program','')} ({scope.get('platform','')})" if scope.get("program") else "Unknown"

    return f"""# {title}

**Report ID:** {rid}
**Status:** DRAFT — Pending Human Review
**Severity:** {sev}
**Confidence:** {conf}%
**Bug Type:** {bug.upper()}
**Program:** {prog_line}
**Scope:** {scope_line}
**Domain:** {domain}
**Affected URL:** `{url}`
**Generated:** {time.strftime('%Y-%m-%d %H:%M UTC', time.gmtime())}

---

## Summary

{finding.get("summary","") or finding.get("description","") or f"A {bug.upper()} vulnerability was identified at the affected endpoint."}

## Affected Endpoint

```
{url}
```

## Steps to Reproduce

{steps_md}

## Evidence

See attached evidence artifacts (request/response/timing).

EIL Proof: `{finding.get("eil_proof","")}`

## Impact

{impact or "An attacker could exploit this vulnerability to " + finding.get("poc","compromise the application.")}

## Severity Rationale

{rationale}

## Remediation

{remedi}

---

*This report was generated by TheMasterRecon AI and requires human review before submission.*
*Do not submit without operator approval.*
"""


# ── Submission package (Phase 4) ──────────────────────────────────────────────

def build_package(report_id: str) -> Optional[bytes]:
    """
    Build a submission package ZIP for an approved report.
    Contains: H1/Intigriti/Bugcrowd markdown + evidence + payload.
    Returns raw ZIP bytes. Never submits.
    """
    r = get_report(report_id)
    if not r:
        return None
    if r.get("status") not in ("approved", "submitted", "triaged",
                                "resolved", "duplicate", "informative"):
        log.warning(f"[bounty] package blocked id={report_id}: not approved")
        return None

    # Reconstruct a finding dict from the report record
    finding = {
        "bug":        r["bug_type"],
        "severity":   r["severity"],
        "url":        r["url"],
        "title":      r["title"],
        "summary":    r["summary"],
        "impact":     r["impact"],
        "remediation":r["remediation"],
        "poc":        r.get("eil_proof",""),
        "confidence": r.get("eil_confidence",0),
    }
    domain = r["domain"]

    # Generate platform-specific markdown
    try: h1_md     = generate_h1_report(finding, domain)
    except Exception: h1_md = f"# {r.get('title','')}\n\n{r.get('summary','')}"
    try: intigriti = generate_intigriti_report(finding, domain)
    except Exception: intigriti = h1_md
    try: bugcrowd  = generate_bugcrowd_report(finding, domain)
    except Exception: bugcrowd  = h1_md

    # Draft markdown
    md_path = _REPORTS_DIR / domain / f"{report_id}.md"
    draft_md = md_path.read_text() if md_path.exists() else h1_md

    # Evidence text
    evidence_txt = "# Evidence Bundle\n\n"
    for ev in r.get("evidence",[]):
        evidence_txt += f"## {ev.get('label','Evidence')} ({ev.get('evidence_type','')})\n\n"
        evidence_txt += f"```\n{ev.get('content','')[:3000]}\n```\n\n"

    # Payload copy-paste
    payload_ev = next((e for e in r.get("evidence",[])
                       if e.get("evidence_type") == "raw_request"), None)
    payload_txt = payload_ev.get("content","No raw request captured.") if payload_ev else ""

    import io
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(f"{report_id}/README.txt",
                    f"TheMasterRecon AI — Bounty Report Package\n"
                    f"Report ID: {report_id}\n"
                    f"Domain: {domain}\n"
                    f"Status: {r.get('status')}\n"
                    f"Generated: {time.strftime('%Y-%m-%d %H:%M UTC', time.gmtime())}\n\n"
                    f"IMPORTANT: This package is for human review only.\n"
                    f"Do not submit without operator approval.\n")
        zf.writestr(f"{report_id}/report_draft.md",     draft_md)
        zf.writestr(f"{report_id}/hackerone.md",        h1_md)
        zf.writestr(f"{report_id}/intigriti.md",        intigriti)
        zf.writestr(f"{report_id}/bugcrowd.md",         bugcrowd)
        zf.writestr(f"{report_id}/evidence_bundle.md",  evidence_txt)
        zf.writestr(f"{report_id}/payload_request.txt", payload_txt)

    buf.seek(0)
    log.info(f"[bounty] package_ready platform=all id={report_id}")
    return buf.read()
