"""
TheMasterRecon AI — Scope Management Engine
Handles include/exclude rules for bug bounty programs.
Prevents accidental out-of-scope testing.
"""
import re, fnmatch, logging, urllib.parse
from typing import List, Optional

log = logging.getLogger("elite.scope")


class ScopeManager:
    """
    Manages in-scope / out-of-scope rules for a target.
    
    Rules use wildcard or regex patterns:
      *.example.com         — all subdomains
      example.com/*         — all paths  
      !mail.example.com     — exclude (! prefix)
      /regex:/^.*admin.*$/  — regex pattern
    """
    def __init__(self, includes: List[str] = None, excludes: List[str] = None):
        self.includes  = [r.strip() for r in (includes or []) if r.strip()]
        self.excludes  = [r.strip() for r in (excludes or []) if r.strip()]
        self._compiled = {}

    def _match_pattern(self, pattern: str, url: str) -> bool:
        """Match URL against a wildcard or regex pattern."""
        pattern = pattern.lstrip("!")
        if pattern.startswith("/regex:"):
            rx = pattern[7:].strip("/")
            try:
                return bool(re.search(rx, url, re.I))
            except re.error:
                return False
        # Wildcard match on domain+path
        parsed = urllib.parse.urlparse(url if "://" in url else "https://"+url)
        host = parsed.netloc.lower().split(":")[0]
        full = host + parsed.path
        # Try pattern as domain or domain+path
        pat_clean = pattern.replace("https://","").replace("http://","").strip("/")
        if "*" in pat_clean or "?" in pat_clean:
            return fnmatch.fnmatch(host, pat_clean) or fnmatch.fnmatch(full, pat_clean)
        return host.endswith(pat_clean) or full.startswith(pat_clean)

    def is_in_scope(self, url: str) -> bool:
        """Returns True if URL is in scope."""
        url = url.strip()
        if not url:
            return False
        # Check excludes first
        for exc in self.excludes:
            if self._match_pattern(exc, url):
                log.debug(f"[scope] OUT: {url} matched exclude '{exc}'")
                return False
        # If includes defined, must match at least one
        if self.includes:
            for inc in self.includes:
                if self._match_pattern(inc, url):
                    return True
            log.debug(f"[scope] OUT: {url} not in any include rule")
            return False
        return True  # no include rules = everything in scope

    def filter_urls(self, urls: List[str]) -> List[str]:
        """Filter a list of URLs to only in-scope ones."""
        return [u for u in urls if self.is_in_scope(u)]

    def filter_hosts(self, hosts: List[str]) -> List[str]:
        return [h for h in hosts if self.is_in_scope(h)]

    def to_dict(self) -> dict:
        return {"includes": self.includes, "excludes": self.excludes}

    @classmethod
    def from_dict(cls, d: dict) -> "ScopeManager":
        return cls(includes=d.get("includes",[]), excludes=d.get("excludes",[]))

    @classmethod
    def from_program(cls, program_type: str, domain: str) -> "ScopeManager":
        """Pre-built scope templates for common bug bounty program types."""
        templates = {
            "wildcard": {
                "includes": [f"*.{domain}", domain],
                "excludes": ["mail."+domain, "email."+domain, "smtp."+domain,
                             "mx."+domain, "ns1."+domain, "ns2."+domain],
            },
            "main_only": {
                "includes": [domain, "www."+domain],
                "excludes": [],
            },
            "api_only": {
                "includes": ["api."+domain, "api2."+domain, "v1.api."+domain],
                "excludes": [],
            },
            "full": {
                "includes": [f"*.{domain}"],
                "excludes": [],
            },
        }
        t = templates.get(program_type, templates["wildcard"])
        return cls(**t)
