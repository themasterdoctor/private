"""
TheMasterRecon RAG Ingestion Pipeline
Fetches reports from 40+ public sources and stores them in rag_db.
Covers: HackerOne disclosures, bug bounty writeups, payloads, OWASP, nuclei templates.
Runs as a background thread. Resumable. Rate-limited.
"""
from __future__ import annotations
import json, logging, os, re, sqlite3, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, Any, Iterator, List, Optional
from urllib.parse import urljoin

log = logging.getLogger("elite.rag_ingest")

# ── HTTP client (reuses app's ssl-tolerant session) ───────────────────────────
import ssl, urllib.request

def _fetch(url: str, timeout: int = 15) -> Optional[str]:
    """Fetch URL, return text or None."""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 TMR-RAG-Ingest/1.0",
            "Accept": "text/html,application/json,text/plain,*/*",
        })
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
            raw = r.read()
            enc = r.headers.get_content_charset("utf-8")
            return raw.decode(enc, errors="replace")
    except Exception as e:
        log.debug(f"[ingest] fetch {url}: {e}")
        return None


def _gh_raw(url: str) -> str:
    """Convert github.com blob URL to raw.githubusercontent.com."""
    return url.replace("github.com","raw.githubusercontent.com").replace("/blob/","/")


def _gh_api(owner: str, repo: str, path: str = "", ref: str = "master") -> Optional[List[dict]]:
    """GitHub contents API."""
    url  = f"https://api.github.com/repos/{owner}/{repo}/contents/{path}?ref={ref}"
    text = _fetch(url, timeout=20)
    if not text: return None
    try:
        data = json.loads(text)
        return data if isinstance(data, list) else None
    except Exception:
        return None


def _gh_walk_md(owner: str, repo: str, path: str = "", branch: str = "master", max_files: int = 300) -> Iterator[Dict]:
    """Walk a GitHub repo and yield markdown files."""
    items = _gh_api(owner, repo, path, branch)
    if not items:
        # Try main branch
        items = _gh_api(owner, repo, path, "main")
    if not items:
        return
    count = 0
    for item in items:
        if count >= max_files:
            break
        if item.get("type") == "file" and item.get("name","").endswith(".md"):
            raw_url = item.get("download_url","")
            if not raw_url:
                continue
            content = _fetch(raw_url)
            if content and len(content.strip()) > 100:
                count += 1
                yield {
                    "url":     item.get("html_url", raw_url),
                    "content": content,
                    "path":    item.get("path",""),
                }
        elif item.get("type") == "dir":
            yield from _gh_walk_md(owner, repo, item.get("path",""), branch, max_files - count)


# ── Text utilities ─────────────────────────────────────────────────────────────
_VULN_MAP = {
    "xss": "xss", "cross-site scripting": "xss", "cross site scripting": "xss",
    "sql injection": "sqli", "sqli": "sqli", "sql": "sqli",
    "ssrf": "ssrf", "server-side request forgery": "ssrf", "server side request": "ssrf",
    "idor": "idor", "insecure direct object": "idor", "access control": "idor", "bola": "idor",
    "rce": "rce", "remote code execution": "rce", "command injection": "rce",
    "lfi": "lfi", "local file inclusion": "lfi", "path traversal": "lfi",
    "xxe": "xxe", "xml external": "xxe",
    "ssti": "ssti", "template injection": "ssti",
    "csrf": "csrf", "cross-site request forgery": "csrf",
    "cors": "cors", "cross-origin": "cors",
    "open redirect": "redirect", "redirect": "redirect",
    "jwt": "jwt", "json web token": "jwt",
    "oauth": "oauth", "saml": "saml",
    "graphql": "graphql",
    "prototype pollution": "prototype",
    "smuggling": "smuggling", "request smuggling": "smuggling",
    "takeover": "takeover", "subdomain takeover": "takeover",
    "disclosure": "misconfig", "information disclosure": "misconfig",
    "deserialization": "deserialization",
    "race condition": "race",
    "upload": "fileupload", "file upload": "fileupload",
    "nosql": "nosqli",
    "crlf": "crlf",
    "host header": "host_header",
    "clickjacking": "clickjacking",
}

_SEV_MAP = {"critical":4,"high":3,"medium":2,"low":1,"info":0}

def _detect_bug(text: str) -> str:
    tl = text.lower()
    for kw, bug in _VULN_MAP.items():
        if kw in tl:
            return bug
    return "other"

def _detect_severity(text: str) -> str:
    tl = text.lower()
    for kw in ["critical","high","medium","low","info"]:
        if f"severity: {kw}" in tl or f"**{kw}**" in tl or f"#{kw}" in tl:
            return kw
    return "medium"

def _extract_title(text: str, fallback: str = "") -> str:
    for line in text.split("\n")[:10]:
        line = line.strip()
        if line.startswith("# "):   return line[2:].strip()[:300]
        if line.startswith("## "):  return line[3:].strip()[:300]
    return (fallback or text[:80]).strip()[:300]

def _extract_tech(text: str) -> List[str]:
    TECH = ["php","python","django","flask","ruby","rails","node","express","java","spring",
            "wordpress","drupal","laravel","react","angular","vue","next.js","graphql",
            "aws","gcp","azure","cloudflare","mysql","postgresql","mongodb","redis",
            "nginx","apache","iis","jquery","webpack","kubernetes","docker","golang","rust"]
    tl   = text.lower()
    return [t for t in TECH if re.search(r'\b'+re.escape(t)+r'\b', tl)][:8]

def _extract_bounty(text: str) -> Optional[float]:
    m = re.search(r'\$\s*([\d,]+)', text)
    if m:
        try: return float(m.group(1).replace(",",""))
        except: pass
    return None

def _extract_program(text: str, url: str = "") -> str:
    m = re.search(r'(?:program|company|target)[:\s]+([A-Za-z0-9 _\-\.]+)', text, re.I)
    if m:
        return m.group(1).strip()[:100]
    # From HackerOne URL: hackerone.com/reports/12345 -> no program info
    # From github URL: owner/repo
    if "github.com" in url:
        parts = url.replace("https://github.com/","").split("/")
        if len(parts) >= 2: return f"{parts[0]}/{parts[1]}"
    return ""


# ── Source adapters ────────────────────────────────────────────────────────────

def _parse_md_report(content: str, url: str, source: str) -> Dict[str, Any]:
    """Parse a markdown report into a normalized dict."""
    title    = _extract_title(content, url.rsplit("/",1)[-1])
    bug_type = _detect_bug(content)
    severity = _detect_severity(content)
    tech     = _extract_tech(content)
    bounty   = _extract_bounty(content)
    program  = _extract_program(content, url)
    return {
        "url": url, "title": title, "source": source,
        "bug_type": bug_type, "severity": severity,
        "tech": tech, "bounty": bounty, "program": program,
        "body": content[:20000],
    }


def source_h1_top_reports() -> Iterator[Dict]:
    """
    reddelexc/hackerone-reports — FULL repository walker.
    ~15,000+ disclosed H1 reports with full markdown content.
    Walks ALL folders: tops_100/, tops_by_bug_type/, tops_by_program/
    """
    # Walk all top-level folders
    FOLDERS = [
        ("tops_100", "master"),
        ("tops_by_bug_type", "master"),
        ("tops_by_program", "master"),
    ]
    total = 0
    for folder, branch in FOLDERS:
        log.info(f"[reddelexc] walking {folder}...")
        for item in _gh_walk_md("reddelexc", "hackerone-reports", folder, branch, max_files=5000):
            content = item["content"]
            # Each .md file is a disclosed H1 report with full content
            report = _parse_md_report(content, item["url"], "reddelexc-reports")

            # Also extract any linked H1 report URLs from index files
            links = re.findall(
                r'\[([^\]]+)\]\((https://hackerone\.com/reports/\d+[^)]*)\)',
                content
            )
            if links and len(links) > 5:
                # This is an index file — yield each linked report
                for link_title, report_url in links:
                    yield {
                        "url":      report_url,
                        "title":    link_title,
                        "source":   "reddelexc-reports",
                        "bug_type": _detect_bug(link_title),
                        "severity": "high",
                        "tech":     _extract_tech(link_title),
                        "body":     f"# {link_title}\n\n{report_url}\n\n{content[:5000]}",
                    }
                    total += 1
            else:
                # This is a full report file
                yield report
                total += 1

            if total % 500 == 0:
                log.info(f"[reddelexc] {total} reports yielded...")

        time.sleep(0.5)

    log.info(f"[reddelexc] done: {total} reports from full repo walk")


def source_h1_valid_reports() -> Iterator[Dict]:
    """ashikurrahmans/h1-bugbounty-valid-reports."""
    for item in _gh_walk_md("ashikurrahmans","h1-bugbounty-valid-reports","","master",300):
        yield _parse_md_report(item["content"], item["url"], "h1-valid-reports")
    time.sleep(0.3)


def source_holmes_summaries() -> Iterator[Dict]:
    """holmes-py/reports-summary."""
    for item in _gh_walk_md("holmes-py","reports-summary","","master",300):
        yield _parse_md_report(item["content"], item["url"], "holmes-summaries")
    time.sleep(0.3)


def source_imusabkhan_writeups() -> Iterator[Dict]:
    """imusabkhan/bugbounty-writeups."""
    for item in _gh_walk_md("imusabkhan","bugbounty-writeups","","main",200):
        yield _parse_md_report(item["content"], item["url"], "imusabkhan-writeups")
    time.sleep(0.3)


def source_bidokhti_h1reports() -> Iterator[Dict]:
    """AmirhosseinBidokhti/h1reports."""
    for item in _gh_walk_md("AmirhosseinBidokhti","h1reports","","master",200):
        yield _parse_md_report(item["content"], item["url"], "bidokhti-h1reports")
    time.sleep(0.3)


def source_codebygk_reports() -> Iterator[Dict]:
    """codebygk/hackerone-bug-bounty-reports."""
    for item in _gh_walk_md("codebygk","hackerone-bug-bounty-reports","","master",200):
        yield _parse_md_report(item["content"], item["url"], "codebygk-reports")
    time.sleep(0.3)


def source_kh4sh3i_writeups() -> Iterator[Dict]:
    """kh4sh3i/bug-bounty-writeups."""
    for item in _gh_walk_md("kh4sh3i","bug-bounty-writeups","","main",200):
        yield _parse_md_report(item["content"], item["url"], "kh4sh3i-writeups")
    time.sleep(0.3)


def source_h1pmnh_reports() -> Iterator[Dict]:
    """h1pmnh/h1reports."""
    for item in _gh_walk_md("h1pmnh","h1reports","","master",200):
        yield _parse_md_report(item["content"], item["url"], "h1pmnh-reports")
    time.sleep(0.3)


def source_phlmox_reports() -> Iterator[Dict]:
    """phlmox/public-reports."""
    for item in _gh_walk_md("phlmox","public-reports","","main",150):
        yield _parse_md_report(item["content"], item["url"], "phlmox-reports")
    time.sleep(0.3)


def source_rclue_reports() -> Iterator[Dict]:
    """RClueX/Hackerone-Reports."""
    for item in _gh_walk_md("RClueX","Hackerone-Reports","","master",200):
        yield _parse_md_report(item["content"], item["url"], "rclue-reports")
    time.sleep(0.3)


def source_marcotulio_reports() -> Iterator[Dict]:
    """marcotuliocnd/bugbounty-disclosed-reports."""
    for item in _gh_walk_md("marcotuliocnd","bugbounty-disclosed-reports","","master",200):
        yield _parse_md_report(item["content"], item["url"], "marcotulio-reports")
    time.sleep(0.3)


def source_ngalongc_reference() -> Iterator[Dict]:
    """ngalongc/bug-bounty-reference."""
    raw = _fetch("https://raw.githubusercontent.com/ngalongc/bug-bounty-reference/master/README.md")
    if not raw:
        return
    links = re.findall(r'\[([^\]]+)\]\((https?://[^)]+)\)', raw)
    for title, url in links[:300]:
        if any(skip in url for skip in ["github.com","twitter.com","youtube.com"]):
            continue
        yield {
            "url": url, "title": title, "source": "ngalongc-reference",
            "bug_type": _detect_bug(title), "severity": "medium",
            "tech": _extract_tech(title), "body": f"# {title}\n\n{url}",
        }
        time.sleep(0.05)


def source_edoverflow_cheatsheet() -> Iterator[Dict]:
    """EdOverflow/bugbounty-cheatsheet."""
    for item in _gh_walk_md("EdOverflow","bugbounty-cheatsheet","","master",100):
        yield _parse_md_report(item["content"], item["url"], "edoverflow-cheatsheet")
    time.sleep(0.3)


def source_edoverflow_takeover() -> Iterator[Dict]:
    """EdOverflow/can-i-take-over-xyz — subdomain takeover fingerprints."""
    raw = _fetch("https://raw.githubusercontent.com/EdOverflow/can-i-take-over-xyz/master/README.md")
    if not raw:
        return
    for line in raw.split("\n"):
        if "|" in line and "vulnerable" in line.lower():
            parts = [p.strip() for p in line.split("|")]
            if len(parts) >= 3:
                service = parts[1] if parts[1] else "unknown"
                yield {
                    "url": f"https://github.com/EdOverflow/can-i-take-over-xyz#{service.lower()}",
                    "title": f"Subdomain Takeover: {service}",
                    "source": "can-i-take-over-xyz",
                    "bug_type": "takeover", "severity": "high",
                    "tech": [service.lower()],
                    "body": f"# Subdomain Takeover: {service}\n\n{line}",
                }


def source_payloads_all_things() -> Iterator[Dict]:
    """swisskyrepo/PayloadsAllTheThings — payloads for each vuln type."""
    VULN_DIRS = [
        ("XSS Injection", "xss"), ("SQL Injection", "sqli"),
        ("Server Side Request Forgery", "ssrf"), ("SSTI", "ssti"),
        ("Path Traversal", "lfi"), ("XXE Injection", "xxe"),
        ("CSRF Injection", "csrf"), ("Open Redirect", "redirect"),
        ("Command Injection", "rce"), ("CORS Misconfiguration", "cors"),
        ("JWT Attacks", "jwt"), ("OAuth Bypass", "oauth"),
        ("GraphQL Injection", "graphql"), ("HTTP Request Smuggling", "smuggling"),
        ("Prototype Pollution", "prototype"), ("Race Condition", "race"),
        ("File Upload", "fileupload"), ("NoSQL Injection", "nosqli"),
    ]
    for dir_name, bug_type in VULN_DIRS:
        # Convert dir name to URL path
        path = dir_name.replace(" ", "%20")
        items = _gh_api("swisskyrepo","PayloadsAllTheThings", dir_name, "master")
        if not items:
            items = _gh_api("swisskyrepo","PayloadsAllTheThings", dir_name, "main")
        if not items:
            continue
        for item in items:
            if not item.get("name","").endswith(".md"):
                continue
            raw_url = item.get("download_url","")
            if not raw_url:
                continue
            content = _fetch(raw_url)
            if content and len(content) > 200:
                yield {
                    "url": item.get("html_url", raw_url),
                    "title": f"PayloadsAllTheThings: {dir_name} — {item['name']}",
                    "source": "payloads-all-things",
                    "bug_type": bug_type, "severity": "high",
                    "tech": _extract_tech(content),
                    "body": content[:20000],
                }
        time.sleep(0.5)


def source_owasp_cheatsheets() -> Iterator[Dict]:
    """OWASP/CheatSheetSeries — defensive knowledge."""
    items = _gh_api("OWASP","CheatSheetSeries","cheatsheets","master")
    if not items:
        return
    for item in items:
        if not item.get("name","").endswith(".md"):
            continue
        content = _fetch(item.get("download_url",""))
        if not content:
            continue
        yield {
            "url": item.get("html_url",""),
            "title": f"OWASP Cheatsheet: {item['name'].replace('_Cheat_Sheet.md','')}",
            "source": "owasp-cheatsheets",
            "bug_type": _detect_bug(item["name"]),
            "severity": "info", "tech": _extract_tech(content),
            "body": content[:20000],
        }
        time.sleep(0.2)


def source_bounty_targets() -> Iterator[Dict]:
    """arkadiyt/bounty-targets-data — program scopes (HackerOne + Bugcrowd)."""
    for platform, fname in [("hackerone","hackerone_data.json"),("bugcrowd","bugcrowd_data.json")]:
        url  = f"https://raw.githubusercontent.com/arkadiyt/bounty-targets-data/main/data/{fname}"
        text = _fetch(url, timeout=30)
        if not text:
            continue
        try:
            programs = json.loads(text)
            if not isinstance(programs, list):
                continue
            for prog in programs[:500]:
                name    = prog.get("name","") or prog.get("handle","")
                targets = prog.get("targets",{})
                in_scope= targets.get("in_scope",[])
                domains = [t.get("asset_identifier","") for t in in_scope if t.get("asset_type") in ("URL","DOMAIN","WILDCARD")]
                yield {
                    "url":      f"https://{platform}.com/{name}",
                    "title":    f"Bug Bounty Program: {name} ({platform})",
                    "source":   f"bounty-targets-{platform}",
                    "bug_type": "scope",
                    "severity": "info",
                    "tech":     [],
                    "program":  name,
                    "body":     f"# {name}\nPlatform: {platform}\nIn-scope domains:\n" + "\n".join(domains[:20]),
                }
        except Exception as e:
            log.debug(f"[ingest] bounty-targets {platform}: {e}")
        time.sleep(0.5)


def source_hacktivity_graphql(max_reports: int = 500) -> Iterator[Dict]:
    """HackerOne Hacktivity — live disclosed reports via GraphQL (no auth needed)."""
    QUERY = """query{hacktivity_items(first:25,after:%s,
      where:{disclosed:{_eq:true}},
      order_by:{field:latest_disclosable_activity_at,direction:DESC}){
      pageInfo{hasNextPage endCursor}
      edges{node{...on HackerOneHacktivityItem{
        report{id title vulnerability_information severity_rating bounty_amount disclosed_at
          team{handle name}
          weakness{name cwe_id}}}}}}}"""

    import json as _json
    cursor = "null"
    count  = 0
    while count < max_reports:
        query  = QUERY % cursor
        payload = _json.dumps({"query": query.replace("\n","")})
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
            import urllib.request as _ur
            req = _ur.Request("https://hackerone.com/graphql",
                              data=payload.encode(),
                              headers={"Content-Type":"application/json","Accept":"application/json"})
            with _ur.urlopen(req, timeout=20, context=ctx) as r:
                data = _json.loads(r.read())
        except Exception as e:
            log.debug(f"[ingest] hacktivity graphql: {e}")
            break

        edges = (data.get("data",{}).get("hacktivity_items",{}).get("edges") or [])
        pinfo = (data.get("data",{}).get("hacktivity_items",{}).get("pageInfo") or {})

        for edge in edges:
            rep = (edge.get("node",{}).get("report") or {})
            if not rep: continue
            rid      = rep.get("id","")
            title    = rep.get("title","")
            vuln_info= rep.get("vulnerability_information","") or ""
            severity = rep.get("severity_rating","medium")
            bounty   = rep.get("bounty_amount")
            weakness = rep.get("weakness",{}) or {}
            team     = rep.get("team",{}) or {}

            body = f"# {title}\n\nProgram: {team.get('name','')}\nSeverity: {severity}\n"
            if bounty: body += f"Bounty: ${bounty}\n"
            if vuln_info: body += f"\n## Vulnerability Information\n\n{vuln_info}"

            yield {
                "url":      f"https://hackerone.com/reports/{rid}",
                "title":    title,
                "source":   "hackerone-hacktivity",
                "bug_type": _detect_bug(title + " " + weakness.get("name","")),
                "severity": severity,
                "program":  team.get("handle",""),
                "bounty":   float(bounty) if bounty else None,
                "tech":     _extract_tech(vuln_info),
                "body":     body[:20000],
            }
            count += 1
            if count >= max_reports: break

        if not pinfo.get("hasNextPage"): break
        cursor = f'"{pinfo.get("endCursor","")}"'
        time.sleep(1.0)

    log.info(f"[ingest] hacktivity: {count} reports")


def source_nahamsec_resources() -> Iterator[Dict]:
    """nahamsec/Resources-for-Beginner-Bug-Bounty-Hunters."""
    for item in _gh_walk_md("nahamsec","Resources-for-Beginner-Bug-Bounty-Hunters","","master",100):
        yield _parse_md_report(item["content"], item["url"], "nahamsec-resources")


def source_gobeecode_reports() -> Iterator[Dict]:
    """gobeecode/bug-bounty-reports-hackerone."""
    for item in _gh_walk_md("gobeecode","bug-bounty-reports-hackerone","","main",200):
        yield _parse_md_report(item["content"], item["url"], "gobeecode-reports")


def source_dod_reports() -> Iterator[Dict]:
    """Ravirajrao/DoD-Disclosed-Reports-from-HackerOne."""
    for item in _gh_walk_md("Ravirajrao","DoD-Disclosed-Reports-from-HackerOne","","main",200):
        yield _parse_md_report(item["content"], item["url"], "dod-reports")




def source_0xpatrik_writeups() -> Iterator[Dict]:
    """0xpatrik/writeups — comprehensive bug bounty writeups."""
    for item in _gh_walk_md("0xpatrik","writeups","","main",300):
        yield _parse_md_report(item["content"], item["url"], "0xpatrik-writeups")
    time.sleep(0.3)


def source_hakluke_reports() -> Iterator[Dict]:
    """hakluke/how-to-become-a-hacker — methodology + writeups."""
    for item in _gh_walk_md("hakluke","how-to-become-a-hacker","","master",100):
        yield _parse_md_report(item["content"], item["url"], "hakluke-reports")
    time.sleep(0.3)


def source_brutelogic_xss() -> Iterator[Dict]:
    """brutelogic/research — XSS research and payloads."""
    for item in _gh_walk_md("brutelogic","research","","master",100):
        yield _parse_md_report(item["content"], item["url"], "brutelogic-xss")
    time.sleep(0.3)


def source_jhaddix_content() -> Iterator[Dict]:
    """jhaddix/content — bug bounty hunting resources."""
    for item in _gh_walk_md("jhaddix","content","","master",150):
        yield _parse_md_report(item["content"], item["url"], "jhaddix-content")
    time.sleep(0.3)


def source_allpayloads() -> Iterator[Dict]:
    """foospidy/payloads — comprehensive payload list."""
    raw = _fetch("https://raw.githubusercontent.com/foospidy/payloads/master/README.md")
    if not raw:
        return
    links = re.findall(r'\[([^\]]+)\]\((https?://[^)]+)\)', raw)
    for title, url in links[:200]:
        yield {
            "url": url, "title": title, "source": "allpayloads",
            "bug_type": _detect_bug(title), "severity": "medium",
            "tech": _extract_tech(title), "body": f"# {title}\n\n{url}",
        }
        time.sleep(0.05)


def source_portswigger_labs() -> Iterator[Dict]:
    """PortSwigger Web Academy labs — the gold standard for learning."""
    LABS = [
        ("XSS", "https://portswigger.net/web-security/cross-site-scripting", "xss"),
        ("SQLi", "https://portswigger.net/web-security/sql-injection", "sqli"),
        ("SSRF", "https://portswigger.net/web-security/ssrf", "ssrf"),
        ("IDOR", "https://portswigger.net/web-security/access-control/idor", "idor"),
        ("CORS", "https://portswigger.net/web-security/cors", "cors"),
        ("JWT", "https://portswigger.net/web-security/jwt", "jwt"),
        ("SSTI", "https://portswigger.net/web-security/server-side-template-injection", "ssti"),
        ("Smuggling", "https://portswigger.net/web-security/request-smuggling", "smuggling"),
        ("XXE", "https://portswigger.net/web-security/xxe", "xxe"),
        ("Prototype Pollution", "https://portswigger.net/web-security/prototype-pollution", "prototype"),
        ("OAuth", "https://portswigger.net/web-security/oauth", "oauth"),
        ("GraphQL", "https://portswigger.net/web-security/graphql", "graphql"),
        ("WebSockets", "https://portswigger.net/web-security/websockets", "websocket"),
        ("Race Conditions", "https://portswigger.net/web-security/race-conditions", "race"),
        ("Cache Poisoning", "https://portswigger.net/web-security/web-cache-poisoning", "cache_poison"),
        ("LFI", "https://portswigger.net/web-security/file-path-traversal", "lfi"),
        ("File Upload", "https://portswigger.net/web-security/file-upload", "fileupload"),
        ("CSRF", "https://portswigger.net/web-security/csrf", "csrf"),
        ("Clickjacking", "https://portswigger.net/web-security/clickjacking", "clickjacking"),
        ("Deserialization", "https://portswigger.net/web-security/deserialization", "deserialization"),
    ]
    for name, url, bug_type in LABS:
        content = _fetch(url) or ""
        yield {
            "url": url,
            "title": f"PortSwigger Academy: {name}",
            "source": "portswigger-labs",
            "bug_type": bug_type, "severity": "high",
            "tech": _extract_tech(content),
            "body": f"# PortSwigger Web Security Academy: {name}\n\nURL: {url}\n\n{content[:5000]}",
        }
        time.sleep(0.5)


def source_hacktricks() -> Iterator[Dict]:
    """carlospolop/hacktricks — pentesting techniques database."""
    TOPICS = [
        ("pentesting-web/xss-cross-site-scripting", "xss"),
        ("pentesting-web/sql-injection", "sqli"),
        ("pentesting-web/ssrf-server-side-request-forgery", "ssrf"),
        ("pentesting-web/idor", "idor"),
        ("pentesting-web/cors-bypass", "cors"),
        ("pentesting-web/deserialization", "deserialization"),
        ("pentesting-web/ssti-server-side-template-injection", "ssti"),
        ("pentesting-web/http-request-smuggling", "smuggling"),
        ("pentesting-web/file-upload", "fileupload"),
        ("pentesting-web/xxe-xee-xml-external-entity", "xxe"),
        ("pentesting-web/jwt-attacks", "jwt"),
        ("pentesting-web/oauth-to-account-takeover", "oauth"),
        ("pentesting-web/graphql", "graphql"),
    ]
    for path, bug_type in TOPICS:
        url = f"https://book.hacktricks.xyz/v/hacktricks-web/{path}"
        content = _fetch(url) or ""
        if len(content) > 200:
            yield {
                "url": url,
                "title": f"HackTricks: {path.split('/')[-1].replace('-',' ').title()}",
                "source": "hacktricks",
                "bug_type": bug_type, "severity": "high",
                "tech": _extract_tech(content),
                "body": content[:20000],
            }
        time.sleep(0.3)


def source_bugbountyreports_net() -> Iterator[Dict]:
    """Public bug bounty report indexes from common aggregators."""
    INDEXES = [
        ("https://raw.githubusercontent.com/alexbirsan/bugbounty-writeups/main/README.md", "alexbirsan"),
        ("https://raw.githubusercontent.com/devanshbatham/Awesome-Bugbounty-Writeups/main/README.md", "awesome-writeups"),
        ("https://raw.githubusercontent.com/m0chan/HackerOne-WriteUps/master/README.md", "m0chan-writeups"),
    ]
    for url, source_name in INDEXES:
        raw = _fetch(url)
        if not raw:
            continue
        links = re.findall(r'\[([^\]]+)\]\((https?://[^)]+)\)', raw)
        for title, link_url in links[:100]:
            if any(skip in link_url for skip in ["github.com", "twitter.com", "youtube.com", "linkedin.com"]):
                continue
            yield {
                "url": link_url, "title": title,
                "source": source_name,
                "bug_type": _detect_bug(title), "severity": "high",
                "tech": _extract_tech(title),
                "body": f"# {title}\n\nSource: {source_name}\n{link_url}",
            }
            time.sleep(0.05)


def source_h1_hacktivity_extended(max_reports: int = 2000) -> Iterator[Dict]:
    """HackerOne Hacktivity — extended fetch (2000 most recent disclosed reports)."""
    yield from source_hacktivity_graphql(max_reports=max_reports)




def source_seed_reports() -> Iterator[Dict]:
    """Built-in seed reports — 21 real bug bounty techniques. Works offline."""
    try:
        from engine.rag_seed import get_seed_reports
        for rep in get_seed_reports():
            yield {
                "url":      f"https://hackerone.com/reports/seed-{rep['bug_type']}-{abs(hash(rep['title']))%100000}",
                "title":    rep["title"],
                "source":   rep.get("source", "seed-reports"),
                "bug_type": rep.get("bug_type", "other"),
                "severity": rep.get("severity", "high"),
                "program":  rep.get("program", ""),
                "bounty":   rep.get("bounty"),
                "tech":     rep.get("tech", []),
                "body":     rep.get("body", ""),
            }
    except Exception as e:
        log.debug(f"[seed] {e}")

def source_pentesterland_writeups() -> Iterator[Dict]:
    """pentester.land/writeups — curated bug bounty writeup list."""
    # Fetch the writeups page
    raw = _fetch("https://pentester.land/writeups/")
    if not raw:
        return
    links = re.findall(r'href="(https?://[^"]+)"[^>]*>([^<]+)<', raw)
    for url, title in links[:200]:
        if any(skip in url for skip in ["pentester.land", "twitter", "youtube", "github.com/pentesterland"]):
            continue
        if len(title.strip()) < 5:
            continue
        yield {
            "url": url, "title": title.strip(),
            "source": "pentesterland",
            "bug_type": _detect_bug(title), "severity": "high",
            "tech": _extract_tech(title),
            "body": f"# {title.strip()}\n\n{url}",
        }
        time.sleep(0.05)


# ── Source registry ────────────────────────────────────────────────────────────
SOURCES = {
    "h1-top-reports":       source_h1_top_reports,
    "h1-valid-reports":     source_h1_valid_reports,
    "holmes-summaries":     source_holmes_summaries,
    "imusabkhan-writeups":  source_imusabkhan_writeups,
    "bidokhti-h1reports":   source_bidokhti_h1reports,
    "codebygk-reports":     source_codebygk_reports,
    "kh4sh3i-writeups":     source_kh4sh3i_writeups,
    "h1pmnh-reports":       source_h1pmnh_reports,
    "phlmox-reports":       source_phlmox_reports,
    "rclue-reports":        source_rclue_reports,
    "marcotulio-reports":   source_marcotulio_reports,
    "gobeecode-reports":    source_gobeecode_reports,
    "dod-reports":          source_dod_reports,
    "ngalongc-reference":   source_ngalongc_reference,
    "edoverflow-cheatsheet":source_edoverflow_cheatsheet,
    "edoverflow-takeover":  source_edoverflow_takeover,
    "payloads-all-things":  source_payloads_all_things,
    "owasp-cheatsheets":    source_owasp_cheatsheets,
    "bounty-targets":       source_bounty_targets,
    "hackerone-hacktivity": source_hacktivity_graphql,
    "nahamsec-resources":       source_nahamsec_resources,
    "0xpatrik-writeups":        source_0xpatrik_writeups,
    "hakluke-reports":          source_hakluke_reports,
    "brutelogic-xss":           source_brutelogic_xss,
    "jhaddix-content":          source_jhaddix_content,
    "portswigger-labs":         source_portswigger_labs,
    "hacktricks":               source_hacktricks,
    "bugbountyreports-net":     source_bugbountyreports_net,
    "h1-hacktivity-extended":   source_h1_hacktivity_extended,
    "pentesterland":            source_pentesterland_writeups,
    "seed-reports":             source_seed_reports,
}

FAST_SOURCES = [
    # Always-available offline intelligence
    "seed-reports",
    # H1 disclosed reports (live)
    "hackerone-hacktivity",
    "h1-top-reports",
    "h1-valid-reports",
    # Curated writeup repos
    "holmes-summaries",
    "kh4sh3i-writeups",
    "rclue-reports",
    "ngalongc-reference",
    "nahamsec-resources",
    # Payload + technique databases
    "edoverflow-takeover",
    "payloads-all-things",
    "owasp-cheatsheets",
    # Extended sources (slower)
    # "h1-hacktivity-extended",  # 2000 reports — run manually
    # "portswigger-labs",        # requires web scraping
    # "hacktricks",              # requires web scraping
]

# Full source list for --all ingestion
ALL_SOURCES = list(SOURCES.keys())


def run_source(name: str) -> Dict[str, Any]:
    """Run one source and insert all reports. Returns stats."""
    from engine.rag_db import insert_report

    fn = SOURCES.get(name)
    if not fn:
        return {"source": name, "status": "unknown", "count": 0}

    started = time.time()
    count   = 0
    errors  = 0

    try:
        from engine.rag_db import _conn
        with _conn() as db:
            db.execute("INSERT INTO ingest_log (source,status,started) VALUES (?,?,?)",
                       (name, "running", started))
        log.info(f"[ingest] {name}: starting…")
        for report in fn():
            inserted = insert_report(report)
            if inserted:
                count += 1
            if count % 50 == 0 and count:
                log.info(f"[ingest] {name}: {count} inserted…")
        status = "done"
        log.info(f"[ingest] {name}: {count} reports")
    except Exception as e:
        log.error(f"[ingest] {name} failed: {e}", exc_info=True)
        status = "failed"
        errors = 1

    finished = time.time()
    try:
        from engine.rag_db import _conn
        with _conn() as db:
            db.execute("""UPDATE ingest_log SET status=?,count=?,finished=?
                          WHERE source=? AND status='running'""",
                       (status, count, finished, name))
    except Exception:
        pass

    return {"source": name, "status": status, "count": count, "errors": errors}


def run_all(sources: List[str] = None, embed_after: bool = True, max_workers: int = 2) -> List[Dict]:
    """Run multiple sources concurrently. Embeds and rebuilds index after."""
    sources = sources or FAST_SOURCES
    results = []

    with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="rag-ingest") as pool:
        futures = {pool.submit(run_source, s): s for s in sources}
        for fut in as_completed(futures):
            try:
                results.append(fut.result())
            except Exception as e:
                results.append({"source": futures[fut], "status": "error", "error": str(e)})

    if embed_after:
        from engine.rag_db import embed_pending, build_index
        log.info("[ingest] Starting embedding pass…")
        n = embed_pending()
        log.info(f"[ingest] Embedded {n} reports, rebuilding index…")
        build_index()

    return results
