"""
BugScan ELITE — XBOW Exploit Replay Engine
Replicates XBOW's exploit replay + regression confirmation.

XBOW's approach:
- Every validated finding can be REPLAYED to confirm it's still live
- After a fix is claimed, replay confirms it's actually fixed
- Regressions tracked: was this bug re-introduced?

This is the missing piece from our XBOW-style pipeline.
"""
import time, re, logging, json, urllib.request, urllib.parse, ssl
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("elite.xbow_replay")

_SEV_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}


def _req(url: str, method: str = "GET", headers: dict = None,
         data: bytes = None, timeout: int = 12) -> Tuple[int, dict, str]:
    """Make HTTP request. Returns (status, headers, body)."""
    h = {
        "User-Agent": "BugScanELITE-Replay/1.0 (authorized security testing)",
        "Accept":     "*/*",
    }
    if headers:
        h.update(headers)
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        req = urllib.request.Request(url, data=data, headers=h, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            body = resp.read().decode("utf-8", "ignore")
            resp_headers = dict(resp.headers)
            return resp.getcode(), resp_headers, body
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", "ignore")
        except Exception:
            body = ""
        return e.code, {}, body
    except Exception as e:
        log.debug(f"[replay] request error: {e}")
        return 0, {}, ""


def replay_finding(finding: Dict) -> Dict:
    """
    XBOW-style: replay a finding to confirm it's still live.

    Returns: {
        status: "confirmed_live" | "confirmed_fixed" | "inconclusive",
        still_vulnerable: bool,
        replay_evidence: str,
        response_code: int,
        response_snippet: str,
        replayed_at: str,
    }
    """
    bug   = finding.get("bug", finding.get("bug_type", "")).lower()
    url   = finding.get("url", "")
    poc   = str(finding.get("poc", ""))
    param = finding.get("param", "")

    if not url:
        return _inconclusive("No URL to replay")

    # ── Extract the actual test URL from PoC or url field ────────────────────
    # If PoC has a curl command, extract the URL from it
    test_url = url
    curl_match = re.search(r"curl\s+(?:-\w+\s+)*'([^']+)'", poc)
    if curl_match:
        test_url = curl_match.group(1)

    # ── Make the replay request ───────────────────────────────────────────────
    try:
        status, headers, body = _req(test_url, timeout=15)
    except Exception as e:
        return _inconclusive(f"Request failed: {e}")

    # ── Check for confirmation signals ────────────────────────────────────────
    still_vuln, evidence = _check_signal(bug, body, headers, status, finding)

    result = {
        "status":           "confirmed_live" if still_vuln else "confirmed_fixed",
        "still_vulnerable": still_vuln,
        "replay_evidence":  evidence,
        "response_code":    status,
        "response_snippet": body[:300].replace("\n", " "),
        "replayed_at":      time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "test_url":         test_url,
    }

    log.info(f"[replay] {bug} @ {url[:60]}: {result['status']}")
    return result


def _check_signal(bug: str, body: str, headers: dict, status: int,
                  finding: Dict) -> Tuple[bool, str]:
    """
    Check if the replay response shows the vulnerability is still present.
    Returns (still_vulnerable, evidence_description)
    """
    body_lower = body.lower()
    desc_lower = str(finding.get("description", "")).lower()

    if bug in ("xss", "stored_xss"):
        # Check for our canary or known XSS signals
        canary = finding.get("details", {}).get("canary", "")
        if canary and canary in body:
            return True, f"XSS canary '{canary}' still reflected in response"
        if re.search(r'<script>alert|onerror=alert|onload=alert', body, re.I):
            return True, "XSS payload still executed in response"
        if status == 200 and "csp" not in str(headers).lower():
            return True, "Page loads without CSP — XSS may still be exploitable"
        return False, "XSS signal not found in response"

    elif bug == "sqli":
        # Check for SQL error patterns
        sql_errors = [
            "you have an error in your sql syntax",
            "mysql_fetch", "pg::", "ora-", "sqlstate", "sqlite",
            "microsoft sql server", "odbc sql server driver",
        ]
        for err in sql_errors:
            if err in body_lower:
                return True, f"SQL error still present: '{err}'"
        # Check for time-based (look at response time in future enhancement)
        return False, "No SQL error found in response"

    elif bug == "ssrf":
        # OOB confirmation can't be replayed without callback server
        if finding.get("oob_confirmed"):
            return True, "OOB was confirmed — requires new callback to re-verify"
        # Check if internal content leaked
        internal_signals = ["169.254", "ami-id", "iam", "metadata", "instance-id"]
        for sig in internal_signals:
            if sig in body_lower:
                return True, f"Internal metadata still accessible: '{sig}'"
        return False, "No SSRF evidence in response"

    elif bug == "cors":
        # Check CORS headers
        origin_tested = finding.get("details", {}).get("origin_tested", "https://evil.attacker.com")
        acao = headers.get("Access-Control-Allow-Origin", "")
        acac = headers.get("Access-Control-Allow-Credentials", "")
        if acao == origin_tested or acao == "*":
            return True, f"CORS still misconfigured: ACAO={acao}, ACAC={acac}"
        return False, f"CORS appears fixed: ACAO={acao}"

    elif bug in ("lfi", "rce"):
        file_signals = ["root:x:", "root:*:", "[extensions]", "<?php", "#!/bin"]
        for sig in file_signals:
            if sig in body:
                return True, f"File read confirmed: '{sig}' in response"
        return False, "No file read evidence in response"

    elif bug in ("expose", "actuator", "misconfig"):
        # Check for sensitive data still exposed
        if status == 200 and any(k in body_lower for k in
                ["password", "secret", "token", "api_key", "private_key"]):
            return True, "Sensitive data still exposed in response"
        if status in (401, 403, 404):
            return False, f"Endpoint now returns {status} — appears fixed"
        return True, f"Endpoint still accessible (HTTP {status})"

    elif bug == "redirect":
        if status in (301, 302, 303, 307, 308):
            location = headers.get("Location", "")
            if location and not location.startswith("/") and "example.com" not in location:
                return True, f"Open redirect still active → {location[:60]}"
        return False, "Redirect no longer points off-domain"

    # Generic: if status is 200 and original was a vulnerability
    if status == 200:
        return True, f"Endpoint still accessible (HTTP 200) — manual verification needed"
    return False, f"HTTP {status} — endpoint may be fixed or protected"


def _inconclusive(reason: str) -> Dict:
    return {
        "status":           "inconclusive",
        "still_vulnerable": False,
        "replay_evidence":  reason,
        "response_code":    0,
        "response_snippet": "",
        "replayed_at":      time.strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def batch_replay(findings: List[Dict], domain: str = "",
                 min_severity: str = "medium") -> Dict:
    """
    Replay all confirmed findings to check regression.
    Only replays findings above min_severity.
    """
    min_idx    = _SEV_ORDER.get(min_severity, 1)
    candidates = [f for f in findings if
                  _SEV_ORDER.get(f.get("severity", "info"), 0) >= min_idx and
                  f.get("_xbow_verdict") in ("confirmed", None)]

    results = []
    still_live = still_fixed = inconclusive = 0

    for f in candidates:
        replay = replay_finding(f)
        results.append({
            "finding_id": f.get("dedupe_key", f.get("hash", "")),
            "bug":        f.get("bug", ""),
            "severity":   f.get("severity", ""),
            "url":        f.get("url", "")[:80],
            "replay":     replay,
        })
        if replay["status"] == "confirmed_live":
            still_live += 1
        elif replay["status"] == "confirmed_fixed":
            still_fixed += 1
        else:
            inconclusive += 1
        time.sleep(0.5)  # be polite

    return {
        "domain":       domain,
        "total":        len(candidates),
        "still_live":   still_live,
        "fixed":        still_fixed,
        "inconclusive": inconclusive,
        "results":      results,
        "replayed_at":  time.strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def regression_check(finding: Dict, previous_replay: Dict) -> Dict:
    """
    Compare current replay with a previous one.
    Detects: newly fixed, newly regressed, or no change.
    """
    was_live = previous_replay.get("still_vulnerable", False)
    now_live = replay_finding(finding).get("still_vulnerable", False)

    if was_live and not now_live:
        status = "fixed"
        label  = "✅ Fixed since last check"
    elif not was_live and now_live:
        status = "regressed"
        label  = "🔴 REGRESSED — vulnerability reintroduced"
    elif was_live and now_live:
        status = "still_live"
        label  = "⚠️ Still vulnerable"
    else:
        status = "still_fixed"
        label  = "✅ Still fixed"

    return {
        "status":       status,
        "label":        label,
        "was_live":     was_live,
        "is_now_live":  now_live,
        "checked_at":   time.strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
