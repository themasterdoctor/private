"""
BugScan ELITE — GitHub Repository Scanner (White-Box)

Scans public GitHub repositories for security vulnerabilities in source code.
Complements black-box web scanning with static analysis patterns.

Detects:
  - Hardcoded secrets (API keys, tokens, passwords)
  - SQL injection patterns (string concatenation in queries)
  - Command injection (subprocess with user input)
  - Path traversal (unsafe file operations)
  - Insecure dependencies (known vulnerable packages)
  - Exposed configuration files
  - Weak cryptography patterns
  - Dangerous deserialization

Safe: read-only analysis of public code. No exploitation.
"""

import json, logging, os, re, ssl, time, urllib.request, urllib.parse
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("elite.github_scanner")

GITHUB_API = "https://api.github.com"

# Regex patterns for vulnerability detection in source code
VULN_PATTERNS = {
    # ── Hardcoded secrets ──────────────────────────────────────────────────────
    "hardcoded_secret": [
        (r'(?i)(password|passwd|pwd)\s*=\s*["\'][^"\']{8,}["\']',       "Hardcoded password"),
        (r'(?i)(api_key|apikey|api-key)\s*=\s*["\'][A-Za-z0-9_\-]{16,}["\']', "Hardcoded API key"),
        (r'(?i)(secret|token)\s*=\s*["\'][A-Za-z0-9_\-]{20,}["\']',    "Hardcoded secret/token"),
        (r'(?i)aws_access_key_id\s*=\s*["\']?AKIA[A-Z0-9]{16}',        "AWS Access Key"),
        (r'(?i)aws_secret_access_key\s*=\s*["\'][A-Za-z0-9/+=]{40}',   "AWS Secret Key"),
        (r'ghp_[A-Za-z0-9]{36}',                                         "GitHub Personal Access Token"),
        (r'sk-[A-Za-z0-9]{48}',                                           "OpenAI API Key"),
        (r'xoxb-[0-9]{11}-[0-9]{11}-[A-Za-z0-9]{24}',                   "Slack Bot Token"),
        (r'AIza[0-9A-Za-z_\-]{35}',                                       "Google API Key"),
        (r'-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----',         "Private Key in source"),
    ],
    # ── SQL Injection ──────────────────────────────────────────────────────────
    "sqli": [
        (r'(?i)(query|sql|execute)\s*\(\s*[f"\'].*\+.*(?:id|user|name|param)',  "SQL string concat"),
        (r'(?i)\.query\(`[^`]*\$\{',                                            "JS template literal SQL"),
        (r'(?i)execute\s*\(\s*["\'].*%s.*["\'],?\s*%\s*\(',                     "Python % formatting in SQL"),
        (r'(?i)db\.(execute|query|run)\s*\(\s*[f"\']SELECT.*\+',                "String concat in DB query"),
        (r'(?i)WHERE\s+\w+\s*=\s*["\']?\s*\+',                                  "WHERE clause with concat"),
    ],
    # ── Command Injection ──────────────────────────────────────────────────────
    "rce": [
        (r'(?i)(exec|system|popen|subprocess\.call|os\.system)\s*\(\s*[f"\'].*\$\{', "Command injection JS"),
        (r'(?i)subprocess\.(call|run|Popen)\s*\([^)]*\+',                             "subprocess with concat"),
        (r'(?i)os\.system\s*\(\s*[f"\'].*(?:request\.|params\.|input)',               "OS command with user input"),
        (r'(?i)eval\s*\(\s*(?:request|params|input|data)',                             "eval with user input"),
        (r'(?i)exec\s*\(\s*(?:request|params|user_input)',                             "exec with user input"),
        (r'(?i)child_process\.(exec|spawn)\s*\([^)]*req\.',                           "Node.js RCE via req"),
    ],
    # ── Path Traversal ─────────────────────────────────────────────────────────
    "lfi": [
        (r'(?i)(open|read_file|file_get_contents)\s*\(\s*[f"\'].*(?:request\.|param)',  "File open with user input"),
        (r'(?i)path\.join\s*\([^)]*(?:request|params|user)',                             "Path join with user input"),
        (r'(?i)fs\.(read|readFile)\s*\([^)]*req\.',                                      "Node.js file read with req"),
        (r'(?i)include\s*\(\s*\$_(?:GET|POST|REQUEST)',                                   "PHP include with input"),
    ],
    # ── SSRF ───────────────────────────────────────────────────────────────────
    "ssrf": [
        (r'(?i)requests\.get\s*\(\s*(?:request|params|user)',                 "Python SSRF via requests"),
        (r'(?i)urllib\.request\.urlopen\s*\([^)]*(?:request|param|user)',     "Python SSRF via urllib"),
        (r'(?i)fetch\s*\([^)]*req\.',                                          "JS SSRF via fetch"),
        (r'(?i)axios\.(get|post)\s*\([^)]*req\.',                              "Node.js SSRF via axios"),
        (r'(?i)http\.(get|request)\s*\([^)]*req\.',                            "Node.js SSRF via http"),
    ],
    # ── Insecure deserialization ────────────────────────────────────────────────
    "deserialization": [
        (r'(?i)pickle\.loads\s*\(',                               "Python pickle.loads"),
        (r'(?i)yaml\.load\s*\([^)]*Loader\s*=\s*yaml\.Loader',   "PyYAML unsafe load"),
        (r'(?i)yaml\.load\s*\([^)]*\)',                            "PyYAML load without SafeLoader"),
        (r'(?i)unserialize\s*\(\s*\$_(?:GET|POST|COOKIE|REQUEST)', "PHP unserialize with input"),
        (r'(?i)ObjectInputStream\s*\(',                            "Java ObjectInputStream"),
        (r'(?i)JSON\.parse\s*\([^)]*eval',                         "JS JSON.parse + eval"),
    ],
    # ── Weak crypto ────────────────────────────────────────────────────────────
    "crypto": [
        (r'(?i)hashlib\.(md5|sha1)\s*\(',                          "Weak hash: MD5/SHA1"),
        (r'(?i)algorithm\s*:\s*["\']?(HS256|MD5|SHA1)',            "Weak JWT/hash algorithm"),
        (r'(?i)crypto\.createHash\s*\(["\'](?:md5|sha1)["\']',     "Node.js weak hash"),
        (r'(?i)DES|RC2|RC4|Blowfish',                               "Weak encryption cipher"),
        (r'(?i)random\.(random|randint|choice)\s*\(',               "Python insecure random"),
    ],
    # ── XSS patterns ───────────────────────────────────────────────────────────
    "xss": [
        (r'(?i)innerHTML\s*=\s*[^"\'`]',                           "innerHTML assignment"),
        (r'(?i)document\.write\s*\(',                               "document.write"),
        (r'(?i)dangerouslySetInnerHTML',                            "React dangerouslySetInnerHTML"),
        (r'(?i)v-html\s*=',                                          "Vue v-html directive"),
        (r'(?i)echo\s+\$_(?:GET|POST|REQUEST)',                     "PHP echo with input"),
    ],
}

# File extensions to scan
SCAN_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".php", ".rb", ".go",
    ".java", ".cs", ".cpp", ".c", ".sh", ".env", ".yml", ".yaml",
    ".json", ".xml", ".conf", ".config", ".ini", ".properties",
}

# Files to skip
SKIP_PATHS = {
    "node_modules", ".git", "vendor", "dist", "build", "__pycache__",
    ".min.js", "test", "tests", "spec", "mock", "fixture",
}


def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c


def _gh_get(path: str, token: str = "") -> Optional[dict]:
    url = f"{GITHUB_API}{path}" if path.startswith("/") else path
    headers = {"Accept": "application/vnd.github.v3+json",
               "User-Agent": "BugScanELITE/1.0"}
    if token: headers["Authorization"] = f"token {token}"
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=15, context=_ctx()) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        if e.code == 403:
            log.debug(f"[github] rate limited: {path}")
        else:
            log.debug(f"[github] HTTP {e.code}: {path}")
        return None
    except Exception as e:
        log.debug(f"[github] {path}: {e}")
        return None


def _gh_get_text(url: str, token: str = "") -> Optional[str]:
    headers = {"Accept": "application/vnd.github.v3.raw",
               "User-Agent": "BugScanELITE/1.0"}
    if token: headers["Authorization"] = f"token {token}"
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=10, context=_ctx()) as r:
            return r.read().decode("utf-8", errors="replace")
    except Exception as e:
        log.debug(f"[github] raw {url}: {e}")
        return None


def parse_github_url(url: str) -> Tuple[str, str]:
    """Extract owner/repo from GitHub URL."""
    url = url.rstrip("/")
    m = re.search(r'github\.com/([^/]+)/([^/\s?#]+)', url)
    if m: return m.group(1), m.group(2).replace(".git","")
    return "", ""


def get_repo_info(owner: str, repo: str, token: str = "") -> Optional[Dict]:
    """Get basic repo info."""
    return _gh_get(f"/repos/{owner}/{repo}", token)


def list_repo_files(owner: str, repo: str, path: str = "",
                    token: str = "", depth: int = 0) -> List[Dict]:
    """Recursively list all files in a repo."""
    if depth > 4: return []
    data = _gh_get(f"/repos/{owner}/{repo}/contents/{path}", token)
    if not data or not isinstance(data, list): return []
    files = []
    for item in data:
        name = item.get("name","")
        item_path = item.get("path","")
        if any(skip in item_path.lower() for skip in SKIP_PATHS): continue
        if item.get("type") == "file":
            ext = os.path.splitext(name)[1].lower()
            if ext in SCAN_EXTENSIONS or name in {".env",".env.example","Dockerfile",
                                                    "docker-compose.yml","requirements.txt",
                                                    "package.json","Gemfile","go.mod"}:
                files.append(item)
        elif item.get("type") == "dir":
            files.extend(list_repo_files(owner, repo, item_path, token, depth+1))
    return files


def scan_file_content(content: str, file_path: str) -> List[Dict]:
    """Scan file content for vulnerability patterns."""
    findings = []
    lines = content.splitlines()

    for bug_type, patterns in VULN_PATTERNS.items():
        for pattern, description in patterns:
            for line_no, line in enumerate(lines, 1):
                # Skip comment lines
                stripped = line.strip()
                if stripped.startswith(("#","//","*","--","<!--")): continue
                if re.search(pattern, line):
                    findings.append({
                        "bug_type":    bug_type,
                        "severity":    "critical" if bug_type in ("hardcoded_secret","sqli","rce") else
                                       "high" if bug_type in ("deserialization","lfi","ssrf") else "medium",
                        "file":        file_path,
                        "line":        line_no,
                        "code":        line.strip()[:200],
                        "description": description,
                        "pattern":     pattern[:50],
                    })
                    break  # One finding per pattern per file is enough

    return findings


def scan_dependencies(owner: str, repo: str, token: str = "") -> List[Dict]:
    """Check package files for known vulnerable dependencies."""
    findings = []

    # Check package.json for known vulnerable packages
    pkg_json = _gh_get_text(
        f"https://raw.githubusercontent.com/{owner}/{repo}/HEAD/package.json", token)
    if pkg_json:
        try:
            pkg = json.loads(pkg_json)
            deps = {**pkg.get("dependencies",{}), **pkg.get("devDependencies",{})}
            # Known vulnerable packages (simplified check)
            KNOWN_VULN = {
                "lodash": ("4.17.20", "Prototype pollution CVE-2021-23337"),
                "axios":  ("0.21.1",  "SSRF CVE-2020-28168"),
                "minimist":("1.2.5",  "Prototype pollution CVE-2021-44906"),
                "moment": ("2.29.1",  "ReDoS CVE-2022-24785"),
                "serialize-javascript": ("3.1.0", "XSS CVE-2020-7660"),
                "node-fetch": ("2.6.1", "Redirect CVE-2022-0235"),
                "glob-parent": ("5.1.1", "ReDoS CVE-2020-28469"),
            }
            for pkg_name, (safe_ver, vuln_desc) in KNOWN_VULN.items():
                if pkg_name in deps:
                    ver = deps[pkg_name].lstrip("^~>=")
                    findings.append({
                        "bug_type":    "dependency",
                        "severity":    "high",
                        "file":        "package.json",
                        "description": f"Potentially vulnerable dependency: {pkg_name}@{ver}",
                        "details":     vuln_desc,
                        "safe_version": safe_ver,
                    })
        except Exception: pass

    return findings


def scan_repository(repo_url: str, token: str = "",
                    max_files: int = 50) -> Dict:
    """
    Full repository security scan.
    Returns findings dict with vulnerabilities found in source code.
    """
    owner, repo = parse_github_url(repo_url)
    if not owner or not repo:
        return {"error": f"Invalid GitHub URL: {repo_url}", "findings": []}

    log.info(f"[github_scanner] scanning {owner}/{repo}")
    t0 = time.time()

    # Get repo info
    info = get_repo_info(owner, repo, token)
    if not info:
        return {"error": f"Repo not found or private: {owner}/{repo}", "findings": []}
    if info.get("private"):
        return {"error": "Private repository — requires auth token", "findings": []}

    # List files
    log.info(f"[github_scanner] listing files...")
    files = list_repo_files(owner, repo, token=token)
    files = files[:max_files]  # cap
    log.info(f"[github_scanner] {len(files)} files to scan")

    all_findings = []

    # Scan each file
    for file_info in files:
        raw_url = file_info.get("download_url","")
        if not raw_url: continue
        content = _gh_get_text(raw_url, token)
        if not content: continue
        # Skip minified files
        if any(line for line in content.splitlines() if len(line) > 500):
            avg_line = sum(len(l) for l in content.splitlines()) / max(len(content.splitlines()),1)
            if avg_line > 300: continue  # minified
        findings = scan_file_content(content, file_info.get("path",""))
        all_findings.extend(findings)
        time.sleep(0.1)  # gentle rate limiting

    # Check dependencies
    dep_findings = scan_dependencies(owner, repo, token)
    all_findings.extend(dep_findings)

    duration = round(time.time()-t0, 1)

    # Deduplicate by (bug_type, file, line)
    seen = set()
    deduped = []
    for f in all_findings:
        key = f"{f.get('bug_type')}/{f.get('file')}/{f.get('line',0)}"
        if key not in seen:
            seen.add(key)
            deduped.append(f)

    # Count by severity
    crits = sum(1 for f in deduped if f.get("severity")=="critical")
    highs = sum(1 for f in deduped if f.get("severity")=="high")
    meds  = sum(1 for f in deduped if f.get("severity")=="medium")

    log.info(f"[github_scanner] {owner}/{repo}: {len(deduped)} findings "
             f"({crits}c/{highs}h/{meds}m) in {duration}s")

    return {
        "ok":           True,
        "repo":         f"{owner}/{repo}",
        "repo_url":     repo_url,
        "html_url":     info.get("html_url",""),
        "language":     info.get("language",""),
        "stars":        info.get("stargazers_count",0),
        "files_scanned": len(files),
        "duration_s":   duration,
        "total":        len(deduped),
        "critical":     crits,
        "high":         highs,
        "medium":       meds,
        "findings":     deduped,
        "note":         "Static analysis only — findings require manual verification. No exploitation performed.",
    }
