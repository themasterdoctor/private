"""
TheMasterRecon AI — Advanced JS Analysis Engine
Implements:
- LinkFinder-style endpoint extraction (recursive, context-aware)
- xnLinkFinder-style aggressive pattern matching
- SecretFinder API key detection
- Bundler analysis (webpack chunk walking)
- Source map reversal
- postMessage/prototype pollution sink detection
"""
import re, json, logging, ssl, urllib.request, urllib.parse, concurrent.futures, time, os
from typing import List, Dict, Set, Optional
from pathlib import Path

log = logging.getLogger("elite.js_deep")

APP_ROOT = Path(__file__).parent.parent


def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _get(url: str, timeout: int = 12) -> str:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 TheMasterRecon/3.0"})
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.read(2_000_000).decode("utf-8", "ignore")
    except Exception as e:
        log.debug(f"[js_deep] GET {url}: {e}")
        return ""


# ── LinkFinder-style endpoint extraction ────────────────────────────────────

ENDPOINT_PATTERNS = [
    # Standard paths
    r'["\`](\/?(?:api|v\d+|rest|graphql|auth|admin|internal|private|user|account|dashboard'
    r'|login|logout|register|upload|download|config|settings|webhook|callback|redirect'
    r'|oauth|token|session|health|status|metrics|debug)[^\s"\`\'<>]{0,150})["\`]',
    # URL parameters
    r'(?:url|href|src|action|endpoint|redirect|next|return_to|callback)\s*[=:]\s*["\`]([^"\`\s]{5,200})["\`]',
    # fetch/axios/XHR calls
    r'(?:fetch|axios\.(?:get|post|put|delete|patch)|\.open)\s*\(\s*["\`]([^"\`\s\)]{5,200})["\`]',
    # Route definitions
    r'(?:router\.(?:get|post|put|delete|patch)|app\.(?:get|post|use))\s*\(\s*["\`]([^"\`\s\)]{2,100})["\`]',
    # Template literals with API base
    r'`\$\{[^}]+\}([/a-z][a-z0-9/_.-]{3,100})`',
    # Object properties with path-like values
    r'(?:path|route|uri|endpoint)\s*:\s*["\`]([/a-z][a-z0-9/_.-]{3,100})["\`]',
    # Next.js / React Router patterns
    r'["\`](/(?:api|_next|pages|app)/[a-z0-9/_\[\]-]{2,80})["\`]',
    # GraphQL operations
    r'(?:query|mutation|subscription)\s+(\w+)\s*\{',
    # Hidden inputs and forms
    r'action\s*=\s*["\']([^"\']{5,200})["\']',
    # Comments with API paths
    r'//\s*((?:/api|/v\d+)[^\s]{3,100})',
    # String concatenation paths
    r'["\'](?:/api|/v\d+)[a-z0-9/_-]{1,80}["\']',
]

def linkfinder(content: str, base_url: str = "") -> List[str]:
    """
    Extract endpoints from JS content (LinkFinder-style).
    Returns cleaned, deduplicated list of endpoints.
    """
    endpoints = set()
    
    for pattern in ENDPOINT_PATTERNS:
        try:
            for m in re.finditer(pattern, content, re.IGNORECASE | re.MULTILINE):
                ep = m.group(1).strip().strip("\"'`")
                # Clean up
                ep = re.sub(r'\s+', '', ep)
                if not ep or len(ep) < 3 or len(ep) > 300:
                    continue
                # Filter noise
                if any(skip in ep.lower() for skip in [
                    '.png','.jpg','.gif','.css','.woff','.svg','.ico',
                    'data:','blob:','mailto:','tel:','javascript:',
                    '{{','}}','${','<','>',
                ]):
                    continue
                # Normalize
                if ep.startswith('//'):
                    ep = 'https:' + ep
                elif ep.startswith('/'):
                    if base_url:
                        parsed = urllib.parse.urlparse(base_url)
                        ep = f"{parsed.scheme}://{parsed.netloc}{ep}"
                endpoints.add(ep)
        except re.error:
            continue
    
    return sorted(endpoints)


def xnlinkfinder_aggressive(content: str, domain: str = "") -> List[str]:
    """
    xnLinkFinder-style aggressive extraction.
    Finds more with less filtering — designed for large JS bundles.
    """
    endpoints = set()
    
    # Pattern 1: Any string starting with / followed by word chars
    for m in re.finditer(r'["\`\']((?:/[\w.-]+){2,10}(?:\?[\w=&%+.-]*)?)["\`\']', content):
        ep = m.group(1)
        if 2 < len(ep) < 200 and not any(x in ep for x in ['.png','.jpg','.css','.ico','.gif','.woff']):
            endpoints.add(ep)
    
    # Pattern 2: API base + path combinations
    api_bases = re.findall(r'(?:baseURL|BASE_URL|apiUrl|API_URL|apiBase)\s*[=:]\s*["\`]([^"\`\s]+)["\`]', content)
    api_paths = re.findall(r'["\`](/[\w./%-]{3,80})["\`]', content)
    for base in api_bases[:3]:
        for path in api_paths[:50]:
            endpoints.add(base.rstrip('/') + path)
    
    # Pattern 3: Webpack chunk discovery
    chunk_ids = re.findall(r'\.(\d{3,6})\s*:\s*\{', content)
    if chunk_ids and domain:
        parsed = urllib.parse.urlparse(f"https://{domain}")
        base = f"{parsed.scheme}://{parsed.netloc}"
        for cid in chunk_ids[:10]:
            endpoints.add(f"{base}/{cid}.chunk.js")
    
    # Pattern 4: Dynamic route construction
    for m in re.finditer(r'`([^`]*\$\{[^}]+\}[^`]*)`', content):
        template = m.group(1)
        # Replace template vars with placeholder
        normalized = re.sub(r'\$\{[^}]+\}', '__PARAM__', template)
        if '/' in normalized and len(normalized) < 150:
            endpoints.add(normalized)
    
    return sorted(endpoints)


def analyze_webpack_chunks(js_url: str, content: str) -> List[str]:
    """
    Detect webpack chunks and enumerate them to find more JS files.
    """
    chunk_urls = []
    
    # Find chunk map patterns
    chunk_map = re.search(
        r'chunkId\s*\)\s*\+\s*["\'](\.[^"\']+)["\']|'
        r'\.js"\s*:\s*[\'"]([\w-]+)["\']|'
        r'chunks\s*:\s*\{([^}]+)\}',
        content
    )
    
    base = re.sub(r'/[^/]+$', '/', js_url)
    
    # Method 1: e+".chunk.js" pattern
    if re.search(r'\.chunk\.js', content):
        chunk_ids = re.findall(r'(?:e|n|t)\[(\d+)\]\s*=\s*["\w]', content)
        for cid in set(chunk_ids[:20]):
            chunk_urls.append(f"{base}{cid}.chunk.js")
    
    # Method 2: Named chunks
    named = re.findall(r'["\']([a-z0-9_-]+)["\']:(\d+)', content)
    for name, cid in named[:10]:
        chunk_urls.append(f"{base}{cid}.{name}.chunk.js")
    
    return chunk_urls


def check_source_maps(js_url: str, content: str) -> List[Dict]:
    """Detect and attempt to fetch source maps."""
    maps = []
    
    for m in re.finditer(r'//# sourceMappingURL=([^\s\n]+)', content):
        map_url = m.group(1)
        if not map_url.startswith('data:'):
            # Resolve relative URL
            if not map_url.startswith('http'):
                map_url = re.sub(r'/[^/]+$', '/', js_url) + map_url
            maps.append({"js": js_url, "map": map_url})
    
    return maps


SECRET_PATTERNS = {
    "AWS Access Key":         r'AKIA[0-9A-Z]{16}',
    "AWS Secret Key":         r'(?i)aws[_\-\s]{0,5}secret[_\-\s]{0,5}(access[_\-\s]{0,5})?key[\s\S]{0,20}["\']([0-9a-zA-Z/+=]{40})',
    "GitHub Token":           r'ghp_[0-9a-zA-Z]{36}',
    "GitHub OAuth":           r'gho_[0-9a-zA-Z]{36}',
    "Google API Key":         r'AIza[0-9A-Za-z\-_]{35}',
    "Slack Token":            r'xox[baprs]-[0-9a-zA-Z\-]{10,100}',
    "Stripe Secret":          r'sk_live_[0-9a-zA-Z]{24}',
    "Firebase":               r'AAAA[A-Za-z0-9_-]{7}:[A-Za-z0-9_-]{140}',
    "JWT Token":              r'eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}',
    "Private Key":            r'-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----',
    "OpenAI API Key":         r'sk-[a-zA-Z0-9]{48}',
    "Anthropic API Key":      r'sk-ant-[a-zA-Z0-9_-]{80,}',
    "HuggingFace Token":      r'hf_[a-zA-Z0-9]{34,}',
    "SendGrid Key":           r'SG\.[a-zA-Z0-9]{22}\.[a-zA-Z0-9]{43}',
    "Mailgun Key":            r'key-[0-9a-zA-Z]{32}',
    "NPM Token":              r'npm_[a-zA-Z0-9]{36}',
    "DockerHub Token":        r'dckr_pat_[a-zA-Z0-9_-]{27}',
    "Twilio SID":             r'AC[a-z0-9]{32}',
    "Shopify Secret":         r'shpss_[a-fA-F0-9]{32}',
    "Discord Token":          r'[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}',
    "Telegram Bot":           r'[0-9]{8,10}:[a-zA-Z0-9_-]{35}',
    "Generic API Key":        r'(?i)(?:api[_-]?key|apikey)\s*[=:]\s*["\'][a-zA-Z0-9_\-]{16,64}["\']',
    "Basic Auth (Base64)":    r'(?i)authorization:\s*basic\s+[a-zA-Z0-9+/=]{8,}',
    "Firebase API Key":       r'AIza[0-9A-Za-z\-_]{35}',
    "GCP Service Account":    r'"private_key":\s*"-----BEGIN RSA PRIVATE',
    "Azure Storage Key":      r'AccountKey=[a-zA-Z0-9+/]{86}==',
    "Twilio Auth Token":      r'SK[0-9a-fA-F]{32}',
}

def secretfinder(content: str, source_url: str = "") -> List[Dict]:
    """
    SecretFinder-style API key and secret detection.
    Returns list of {type, value, preview, severity}.
    """
    findings = []
    seen_values = set()
    
    for secret_type, pattern in SECRET_PATTERNS.items():
        try:
            for m in re.finditer(pattern, content, re.MULTILINE):
                val = m.group(0)
                # Deduplicate by value fingerprint
                val_key = val[:40].lower().strip()
                if val_key in seen_values:
                    continue
                seen_values.add(val_key)
                
                # Get context (50 chars around match)
                start   = max(0, m.start() - 50)
                end     = min(len(content), m.end() + 50)
                context = content[start:end].replace('\n', ' ').strip()
                
                sev = "critical" if any(k in secret_type for k in [
                    "AWS","Private Key","Stripe","OpenAI","Anthropic","Firebase","GCP","Azure","SendGrid"
                ]) else "high"
                
                findings.append({
                    "type":       secret_type,
                    "value":      val[:120],
                    "preview":    val[:60] + "..." if len(val) > 60 else val,
                    "context":    context[:200],
                    "source":     source_url,
                    "severity":   sev,
                    "tool":       "SecretFinder",
                })
        except re.error:
            continue
    
    return findings


def postmessage_sinks(content: str) -> List[Dict]:
    """Detect dangerous postMessage sinks and prototype pollution vectors."""
    issues = []
    
    # postMessage without origin check
    pm_handlers = re.findall(
        r'addEventListener\s*\(\s*["\']message["\']\s*,\s*(?:function\s*\([^)]*\)|[^,]+)',
        content
    )
    for handler in pm_handlers:
        if 'origin' not in handler and 'source' not in handler:
            issues.append({
                "type":    "postmessage_no_origin",
                "detail":  "postMessage handler without origin validation",
                "snippet": handler[:150],
            })
    
    # Prototype pollution sinks
    proto_sinks = [
        r'(?:merge|extend|assign|defaults)\s*\([^)]*\)',
        r'\$\.extend\s*\(',
        r'Object\.assign\s*\(',
        r'_\.merge\s*\(',
        r'\[constructor\]\s*\[prototype\]',
        r'__proto__',
    ]
    for pattern in proto_sinks:
        matches = re.findall(pattern, content, re.IGNORECASE)
        if matches:
            issues.append({
                "type":    "prototype_sink",
                "detail":  f"Prototype pollution sink: {pattern}",
                "count":   len(matches),
            })
    
    return issues


def full_js_analysis(js_urls: List[str], domain: str = "",
                     max_files: int = 100) -> Dict:
    """
    Full JS analysis pipeline:
    1. Fetch all JS files
    2. LinkFinder endpoint extraction
    3. xnLinkFinder aggressive patterns
    4. SecretFinder API key detection
    5. Webpack chunk discovery
    6. Source map detection
    7. postMessage/prototype sink detection
    """
    results = {
        "domain":      domain,
        "files":       0,
        "endpoints":   set(),
        "secrets":     [],
        "source_maps": [],
        "chunks":      [],
        "sinks":       [],
        "errors":      0,
    }
    
    seen_secrets = set()
    
    def analyze_one(url: str):
        content = _get(url, timeout=15)
        if not content:
            results["errors"] += 1
            return
        
        results["files"] += 1
        
        # Endpoint extraction
        endpoints = linkfinder(content, url)
        endpoints += xnlinkfinder_aggressive(content, domain)
        results["endpoints"].update(endpoints)
        
        # Secret detection
        secrets = secretfinder(content, url)
        for s in secrets:
            key = s["value"][:30]
            if key not in seen_secrets:
                seen_secrets.add(key)
                results["secrets"].append(s)
        
        # Chunks
        chunks = analyze_webpack_chunks(url, content)
        results["chunks"].extend(chunks[:5])
        
        # Source maps
        maps = check_source_maps(url, content)
        results["source_maps"].extend(maps)
        
        # Sinks
        sinks = postmessage_sinks(content)
        results["sinks"].extend(sinks)
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as exe:
        futs = [exe.submit(analyze_one, url) for url in js_urls[:max_files]]
        concurrent.futures.wait(futs, timeout=120)
    
    # Also analyze newly discovered chunks
    if results["chunks"]:
        chunk_urls = [c for c in results["chunks"] if c not in js_urls][:10]
        for url in chunk_urls:
            content = _get(url, timeout=10)
            if content:
                results["endpoints"].update(linkfinder(content, url))
                for s in secretfinder(content, url):
                    key = s["value"][:30]
                    if key not in seen_secrets:
                        seen_secrets.add(key)
                        results["secrets"].append(s)
    
    results["endpoints"]     = sorted(results["endpoints"])
    results["endpoint_count"] = len(results["endpoints"])
    results["secret_count"]  = len(results["secrets"])
    
    log.info(f"[js_deep] {domain}: {results['files']} files, "
             f"{results['endpoint_count']} endpoints, {results['secret_count']} secrets")
    return results
