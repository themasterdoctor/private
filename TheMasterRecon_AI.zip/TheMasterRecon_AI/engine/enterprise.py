"""
BugScan ELITE — Enterprise Multi-Tenancy Engine

Provides:
  - Organizations (isolated tenants)
  - Teams (sub-groups within an org)
  - Programs (bug bounty/pentest programs with scope)
  - API keys (per-user, per-org, with rate limiting)
  - Rate limiting (per org/user)
  - Usage metering (scans, findings, endpoints per billing period)

Database: data/enterprise.db (separate from bugscan.db for isolation)
"""

import hashlib, json, logging, os, secrets, sqlite3, time, threading
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("elite.enterprise")

_DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "..", "data", "enterprise.db")
_conn: Optional[sqlite3.Connection] = None
_lock = threading.Lock()


def _db() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        os.makedirs(os.path.dirname(_DB_PATH), exist_ok=True)
        _conn = sqlite3.connect(_DB_PATH, timeout=15, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA journal_mode=WAL")
        _conn.execute("PRAGMA foreign_keys=ON")
        _bootstrap()
    return _conn


def _bootstrap():
    """Create all enterprise tables if they don't exist."""
    stmts = [
        # ── Organizations ─────────────────────────────────────────────────────
        """CREATE TABLE IF NOT EXISTS organizations (
            id           TEXT PRIMARY KEY,
            name         TEXT NOT NULL,
            slug         TEXT UNIQUE NOT NULL,
            plan         TEXT DEFAULT 'starter',   -- starter|pro|enterprise
            max_scans_pm INTEGER DEFAULT 10,        -- scans per month
            max_users    INTEGER DEFAULT 5,
            max_programs INTEGER DEFAULT 10,
            settings     TEXT DEFAULT '{}',         -- JSON: SSO, branding, etc.
            created_at   REAL,
            updated_at   REAL
        )""",

        # ── Teams ─────────────────────────────────────────────────────────────
        """CREATE TABLE IF NOT EXISTS teams (
            id           TEXT PRIMARY KEY,
            org_id       TEXT REFERENCES organizations(id),
            name         TEXT NOT NULL,
            description  TEXT DEFAULT '',
            permissions  TEXT DEFAULT '{}',          -- JSON: what team can do
            created_at   REAL,
            updated_at   REAL
        )""",

        # ── Org Members ───────────────────────────────────────────────────────
        """CREATE TABLE IF NOT EXISTS org_members (
            id           TEXT PRIMARY KEY,
            org_id       TEXT REFERENCES organizations(id),
            user_id      TEXT NOT NULL,
            username     TEXT NOT NULL,
            email        TEXT NOT NULL,
            role         TEXT DEFAULT 'analyst',  -- owner|admin|analyst|viewer
            team_id      TEXT,
            joined_at    REAL,
            last_active  REAL
        )""",

        # ── Programs ──────────────────────────────────────────────────────────
        """CREATE TABLE IF NOT EXISTS programs (
            id              TEXT PRIMARY KEY,
            org_id          TEXT REFERENCES organizations(id),
            name            TEXT NOT NULL,
            slug            TEXT NOT NULL,
            platform        TEXT DEFAULT 'private',  -- hackerone|bugcrowd|intigriti|private
            type            TEXT DEFAULT 'bbp',      -- bbp|vdp|pentest|internal
            status          TEXT DEFAULT 'active',   -- active|paused|closed
            scope_domains   TEXT DEFAULT '[]',        -- JSON list of in-scope domains
            scope_wildcards TEXT DEFAULT '[]',        -- JSON list of *.domain.com patterns
            out_of_scope    TEXT DEFAULT '[]',        -- JSON list of OOS items
            reward_range    TEXT DEFAULT '{}',        -- {low: 50, high: 10000, currency: USD}
            policy_url      TEXT DEFAULT '',
            notes           TEXT DEFAULT '',
            created_by      TEXT,
            created_at      REAL,
            updated_at      REAL
        )""",

        # ── Program Assets (discovered domains/IPs attached to a program) ─────
        """CREATE TABLE IF NOT EXISTS program_assets (
            id          TEXT PRIMARY KEY,
            program_id  TEXT REFERENCES programs(id),
            asset       TEXT NOT NULL,             -- domain or IP
            asset_type  TEXT DEFAULT 'domain',     -- domain|ip|url|mobile
            in_scope    INTEGER DEFAULT 1,
            added_at    REAL,
            last_seen   REAL
        )""",

        # ── API Keys ──────────────────────────────────────────────────────────
        """CREATE TABLE IF NOT EXISTS api_keys (
            id           TEXT PRIMARY KEY,
            key_hash     TEXT UNIQUE NOT NULL,    -- SHA256 of raw key (never store raw)
            key_prefix   TEXT NOT NULL,            -- first 8 chars for identification
            user_id      TEXT NOT NULL,
            org_id       TEXT,
            name         TEXT DEFAULT 'Default',
            permissions  TEXT DEFAULT '["scan","read"]',  -- JSON list
            rate_limit   INTEGER DEFAULT 100,      -- requests per minute
            expires_at   REAL,                     -- NULL = never expires
            last_used_at REAL,
            use_count    INTEGER DEFAULT 0,
            active       INTEGER DEFAULT 1,
            created_at   REAL
        )""",

        # ── Rate limit buckets (sliding window) ───────────────────────────────
        """CREATE TABLE IF NOT EXISTS rate_buckets (
            key          TEXT PRIMARY KEY,   -- org_id:user_id or api_key_prefix
            tokens       INTEGER DEFAULT 100,
            last_refill  REAL,
            window_s     INTEGER DEFAULT 60
        )""",

        # ── Usage Metering ────────────────────────────────────────────────────
        """CREATE TABLE IF NOT EXISTS usage_records (
            id          TEXT PRIMARY KEY,
            org_id      TEXT,
            user_id     TEXT,
            action      TEXT,   -- scan_started|finding_saved|export|api_call
            resource    TEXT,   -- domain or endpoint
            cost_units  INTEGER DEFAULT 1,
            period      TEXT,   -- YYYY-MM (billing period)
            created_at  REAL
        )""",

        # ── Indexes ───────────────────────────────────────────────────────────
        "CREATE INDEX IF NOT EXISTS idx_org_members_org ON org_members(org_id)",
        "CREATE INDEX IF NOT EXISTS idx_programs_org ON programs(org_id)",
        "CREATE INDEX IF NOT EXISTS idx_api_keys_hash ON api_keys(key_hash)",
        "CREATE INDEX IF NOT EXISTS idx_usage_org_period ON usage_records(org_id, period)",
    ]
    for stmt in stmts:
        _conn.execute(stmt)
    _conn.commit()
    log.info("[enterprise] schema ready")


# ── ID helpers ────────────────────────────────────────────────────────────────

def _id(prefix: str = "") -> str:
    return (prefix + "_" if prefix else "") + secrets.token_hex(8)


def _slug(name: str) -> str:
    import re
    return re.sub(r"[^a-z0-9-]", "-", name.lower().strip())[:40].strip("-")


# ── Organizations ─────────────────────────────────────────────────────────────

def create_org(name: str, plan: str = "starter", owner_user_id: str = "",
               owner_username: str = "", owner_email: str = "") -> Dict:
    oid  = _id("org")
    slug = _slug(name)
    # Ensure slug uniqueness
    existing = _db().execute("SELECT id FROM organizations WHERE slug=?", (slug,)).fetchone()
    if existing:
        slug = slug + "-" + secrets.token_hex(2)
    ts = time.time()
    plan_limits = {
        "starter":    {"max_scans_pm": 10,   "max_users": 5,  "max_programs": 3},
        "pro":        {"max_scans_pm": 100,  "max_users": 25, "max_programs": 20},
        "enterprise": {"max_scans_pm": 9999, "max_users": 999,"max_programs": 999},
    }.get(plan, {"max_scans_pm": 10, "max_users": 5, "max_programs": 3})
    with _lock:
        _db().execute("""INSERT INTO organizations
            (id,name,slug,plan,max_scans_pm,max_users,max_programs,settings,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (oid, name, slug, plan,
             plan_limits["max_scans_pm"], plan_limits["max_users"], plan_limits["max_programs"],
             "{}", ts, ts))
        # Add owner as first member
        if owner_user_id:
            _db().execute("""INSERT INTO org_members
                (id,org_id,user_id,username,email,role,joined_at,last_active)
                VALUES (?,?,?,?,?,'owner',?,?)""",
                (_id("mbr"), oid, owner_user_id, owner_username, owner_email, ts, ts))
        _db().commit()
    log.info(f"[enterprise] org created id={oid} name={name!r} plan={plan}")
    return get_org(oid)


def get_org(org_id: str) -> Optional[Dict]:
    row = _db().execute("SELECT * FROM organizations WHERE id=?", (org_id,)).fetchone()
    return dict(row) if row else None


def get_org_by_slug(slug: str) -> Optional[Dict]:
    row = _db().execute("SELECT * FROM organizations WHERE slug=?", (slug,)).fetchone()
    return dict(row) if row else None


def list_orgs() -> List[Dict]:
    return [dict(r) for r in _db().execute(
        "SELECT * FROM organizations ORDER BY created_at DESC").fetchall()]


def update_org(org_id: str, updates: Dict) -> Optional[Dict]:
    allowed = {"name", "plan", "max_scans_pm", "max_users", "max_programs", "settings"}
    sets  = ", ".join(f"{k}=?" for k in updates if k in allowed)
    vals  = [updates[k] for k in updates if k in allowed]
    if not sets: return get_org(org_id)
    vals += [time.time(), org_id]
    with _lock:
        _db().execute(f"UPDATE organizations SET {sets}, updated_at=? WHERE id=?", vals)
        _db().commit()
    return get_org(org_id)


# ── Teams ─────────────────────────────────────────────────────────────────────

def create_team(org_id: str, name: str, description: str = "") -> Dict:
    tid = _id("team"); ts = time.time()
    with _lock:
        _db().execute("""INSERT INTO teams (id,org_id,name,description,permissions,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?)""",
            (tid, org_id, name, description, '{"scan":true,"read":true}', ts, ts))
        _db().commit()
    return get_team(tid)


def get_team(team_id: str) -> Optional[Dict]:
    row = _db().execute("SELECT * FROM teams WHERE id=?", (team_id,)).fetchone()
    return dict(row) if row else None


def list_teams(org_id: str) -> List[Dict]:
    return [dict(r) for r in _db().execute(
        "SELECT * FROM teams WHERE org_id=? ORDER BY name", (org_id,)).fetchall()]


# ── Members ───────────────────────────────────────────────────────────────────

def add_member(org_id: str, user_id: str, username: str, email: str,
               role: str = "analyst", team_id: str = "") -> Dict:
    mid = _id("mbr"); ts = time.time()
    if role not in ("owner", "admin", "analyst", "viewer", "reporter"):
        role = "analyst"
    existing = _db().execute(
        "SELECT id FROM org_members WHERE org_id=? AND user_id=?",
        (org_id, user_id)).fetchone()
    if existing:
        return dict(_db().execute("SELECT * FROM org_members WHERE id=?",
                                   (existing[0],)).fetchone())
    with _lock:
        _db().execute("""INSERT INTO org_members
            (id,org_id,user_id,username,email,role,team_id,joined_at,last_active)
            VALUES (?,?,?,?,?,?,?,?,?)""",
            (mid, org_id, user_id, username, email, role, team_id or None, ts, ts))
        _db().commit()
    log.info(f"[enterprise] member added org={org_id} user={username} role={role}")
    return dict(_db().execute("SELECT * FROM org_members WHERE id=?", (mid,)).fetchone())


def get_member(org_id: str, user_id: str) -> Optional[Dict]:
    row = _db().execute(
        "SELECT * FROM org_members WHERE org_id=? AND user_id=?",
        (org_id, user_id)).fetchone()
    return dict(row) if row else None


def list_members(org_id: str) -> List[Dict]:
    return [dict(r) for r in _db().execute(
        "SELECT * FROM org_members WHERE org_id=? ORDER BY joined_at",
        (org_id,)).fetchall()]


def update_member_role(org_id: str, user_id: str, role: str) -> bool:
    if role not in ("owner", "admin", "analyst", "viewer", "reporter"):
        return False
    with _lock:
        _db().execute(
            "UPDATE org_members SET role=? WHERE org_id=? AND user_id=?",
            (role, org_id, user_id))
        _db().commit()
    return True


# ── Programs ──────────────────────────────────────────────────────────────────

def create_program(org_id: str, name: str, platform: str = "private",
                   prog_type: str = "bbp", created_by: str = "",
                   scope_domains: List[str] = None,
                   scope_wildcards: List[str] = None,
                   out_of_scope: List[str] = None,
                   reward_range: Dict = None,
                   policy_url: str = "") -> Dict:
    pid  = _id("prog")
    slug = _slug(name)
    ts   = time.time()
    with _lock:
        _db().execute("""INSERT INTO programs
            (id,org_id,name,slug,platform,type,status,
             scope_domains,scope_wildcards,out_of_scope,
             reward_range,policy_url,created_by,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (pid, org_id, name, slug, platform, prog_type, "active",
             json.dumps(scope_domains or []),
             json.dumps(scope_wildcards or []),
             json.dumps(out_of_scope or []),
             json.dumps(reward_range or {}),
             policy_url, created_by, ts, ts))
        _db().commit()
    log.info(f"[enterprise] program created id={pid} name={name!r} org={org_id}")
    return get_program(pid)


def get_program(program_id: str) -> Optional[Dict]:
    row = _db().execute("SELECT * FROM programs WHERE id=?", (program_id,)).fetchone()
    if not row: return None
    d = dict(row)
    for f in ("scope_domains", "scope_wildcards", "out_of_scope", "reward_range"):
        try: d[f] = json.loads(d.get(f, "[]") or "[]")
        except: pass
    return d


def list_programs(org_id: str, status: str = "") -> List[Dict]:
    q = "SELECT * FROM programs WHERE org_id=?"
    params = [org_id]
    if status:
        q += " AND status=?"
        params.append(status)
    q += " ORDER BY created_at DESC"
    rows = _db().execute(q, params).fetchall()
    result = []
    for row in rows:
        d = dict(row)
        for f in ("scope_domains", "scope_wildcards", "out_of_scope", "reward_range"):
            try: d[f] = json.loads(d.get(f, "[]") or "[]")
            except: pass
        result.append(d)
    return result


def update_program(program_id: str, updates: Dict) -> Optional[Dict]:
    allowed = {"name", "platform", "type", "status", "scope_domains", "scope_wildcards",
               "out_of_scope", "reward_range", "policy_url", "notes"}
    sets  = []
    vals  = []
    for k, v in updates.items():
        if k not in allowed: continue
        if isinstance(v, (list, dict)): v = json.dumps(v)
        sets.append(f"{k}=?"); vals.append(v)
    if not sets: return get_program(program_id)
    vals += [time.time(), program_id]
    with _lock:
        _db().execute(f"UPDATE programs SET {', '.join(sets)}, updated_at=? WHERE id=?", vals)
        _db().commit()
    return get_program(program_id)


def is_in_scope(program_id: str, domain: str) -> Tuple[bool, str]:
    """Check if a domain is in scope for a program. Returns (in_scope, reason)."""
    prog = get_program(program_id)
    if not prog: return False, "program_not_found"
    import re as _re
    oos = prog.get("out_of_scope", [])
    for oos_item in oos:
        if domain == oos_item or domain.endswith("." + oos_item):
            return False, f"out_of_scope: matches {oos_item}"
    scope = prog.get("scope_domains", [])
    for s in scope:
        if domain == s or domain.endswith("." + s):
            return True, f"in_scope: matches {s}"
    wildcards = prog.get("scope_wildcards", [])
    for w in wildcards:
        pattern = w.lstrip("*.")
        if domain == pattern or domain.endswith("." + pattern):
            return True, f"in_scope: matches wildcard {w}"
    return False, "not_in_scope"


def add_program_asset(program_id: str, asset: str, asset_type: str = "domain") -> Dict:
    aid = _id("ast"); ts = time.time()
    with _lock:
        _db().execute("""INSERT OR REPLACE INTO program_assets
            (id,program_id,asset,asset_type,in_scope,added_at,last_seen)
            VALUES (?,?,?,?,1,?,?)""",
            (aid, program_id, asset, asset_type, ts, ts))
        _db().commit()
    return {"id": aid, "program_id": program_id, "asset": asset}


def list_program_assets(program_id: str) -> List[Dict]:
    return [dict(r) for r in _db().execute(
        "SELECT * FROM program_assets WHERE program_id=? ORDER BY added_at DESC",
        (program_id,)).fetchall()]


# ── API Keys ──────────────────────────────────────────────────────────────────

def create_api_key(user_id: str, org_id: str = "", name: str = "Default",
                   permissions: List[str] = None,
                   rate_limit: int = 100,
                   expires_days: int = None) -> Tuple[str, Dict]:
    """
    Create an API key. Returns (raw_key, key_record).
    The raw_key is shown ONCE and never stored — only the SHA256 hash is kept.
    """
    raw_key = "bse_" + secrets.token_urlsafe(32)
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    key_prefix = raw_key[:12]
    kid = _id("key"); ts = time.time()
    expires_at = ts + (expires_days * 86400) if expires_days else None
    with _lock:
        _db().execute("""INSERT INTO api_keys
            (id,key_hash,key_prefix,user_id,org_id,name,permissions,
             rate_limit,expires_at,active,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,1,?)""",
            (kid, key_hash, key_prefix, user_id, org_id or None, name,
             json.dumps(permissions or ["scan","read"]),
             rate_limit, expires_at, ts))
        _db().commit()
    log.info(f"[enterprise] api_key created prefix={key_prefix} user={user_id}")
    record = dict(_db().execute("SELECT * FROM api_keys WHERE id=?", (kid,)).fetchone())
    record.pop("key_hash", None)  # never return hash
    return raw_key, record


def verify_api_key(raw_key: str) -> Optional[Dict]:
    """Verify an API key. Returns key record (without hash) or None."""
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    row = _db().execute(
        "SELECT * FROM api_keys WHERE key_hash=? AND active=1", (key_hash,)).fetchone()
    if not row: return None
    d = dict(row)
    # Check expiry
    if d.get("expires_at") and time.time() > d["expires_at"]:
        return None
    # Update last_used
    with _lock:
        _db().execute(
            "UPDATE api_keys SET last_used_at=?, use_count=use_count+1 WHERE id=?",
            (time.time(), d["id"]))
        _db().commit()
    d.pop("key_hash", None)
    return d


def revoke_api_key(key_id: str, user_id: str) -> bool:
    with _lock:
        _db().execute(
            "UPDATE api_keys SET active=0 WHERE id=? AND user_id=?",
            (key_id, user_id))
        _db().commit()
    return True


def list_api_keys(user_id: str) -> List[Dict]:
    rows = _db().execute(
        "SELECT * FROM api_keys WHERE user_id=? ORDER BY created_at DESC",
        (user_id,)).fetchall()
    result = []
    for row in rows:
        d = dict(row)
        d.pop("key_hash", None)
        result.append(d)
    return result


# ── Rate Limiting ─────────────────────────────────────────────────────────────

def check_rate_limit(identifier: str, max_per_minute: int = 60) -> Tuple[bool, int]:
    """
    Token-bucket rate limiter.
    Returns (allowed, remaining_tokens).
    """
    now  = time.time()
    key  = identifier[:100]
    with _lock:
        row = _db().execute(
            "SELECT tokens, last_refill FROM rate_buckets WHERE key=?", (key,)).fetchone()
        if row:
            tokens, last_refill = row
            elapsed = now - last_refill
            # Refill at max_per_minute per 60s
            refill  = int(elapsed * max_per_minute / 60)
            tokens  = min(max_per_minute, tokens + refill)
            last_refill = now if refill > 0 else last_refill
        else:
            tokens = max_per_minute
            last_refill = now
        if tokens > 0:
            tokens -= 1
            allowed = True
        else:
            allowed = False
        _db().execute("""INSERT OR REPLACE INTO rate_buckets
            (key, tokens, last_refill, window_s) VALUES (?,?,?,60)""",
            (key, tokens, last_refill))
        _db().commit()
    return allowed, tokens


# ── Usage Metering ────────────────────────────────────────────────────────────

def record_usage(org_id: str, user_id: str, action: str,
                 resource: str = "", cost_units: int = 1):
    period = time.strftime("%Y-%m")
    with _lock:
        _db().execute("""INSERT INTO usage_records
            (id,org_id,user_id,action,resource,cost_units,period,created_at)
            VALUES (?,?,?,?,?,?,?,?)""",
            (_id("use"), org_id, user_id, action, resource[:200], cost_units,
             period, time.time()))
        _db().commit()


def get_usage_summary(org_id: str, period: str = "") -> Dict:
    if not period: period = time.strftime("%Y-%m")
    rows = _db().execute("""
        SELECT action, SUM(cost_units) as total
        FROM usage_records WHERE org_id=? AND period=?
        GROUP BY action""", (org_id, period)).fetchall()
    org   = get_org(org_id)
    usage = {r[0]: r[1] for r in rows}
    return {
        "org_id":       org_id,
        "period":       period,
        "usage":        usage,
        "scans_used":   usage.get("scan_started", 0),
        "scans_limit":  org.get("max_scans_pm") if org else 0,
        "findings":     usage.get("finding_saved", 0),
    }


def can_start_scan(org_id: str) -> Tuple[bool, str]:
    """Check if org is within their scan quota for this month."""
    summary = get_usage_summary(org_id)
    used  = summary["scans_used"]
    limit = summary["scans_limit"]
    if limit <= 0 or used < limit:
        return True, f"{used}/{limit} scans used this month"
    return False, f"scan quota exceeded: {used}/{limit} this month (upgrade plan to continue)"
