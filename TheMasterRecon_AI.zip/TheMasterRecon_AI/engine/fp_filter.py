"""
TheMasterRecon AI — False Positive Filter
Uses Claude to review each finding and determine if it's real.
Scores: confirmed / probable / possible / unlikely / false_positive
"""
import json, os, ssl, urllib.request, re, logging
from typing import Dict, List

log = logging.getLogger("elite.fp_filter")
API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL   = "claude-sonnet-4-6"

SYSTEM = (
    "You are an expert penetration tester reviewing vulnerability scanner findings. "
    "Your job is to determine if each finding is a real vulnerability or a false positive. "
    "Be skeptical. Generic error pages, timeouts, and reflection without execution are NOT vulnerabilities. "
    "Output only valid JSON."
)


def _claude(prompt: str) -> str:
    if not API_KEY:
        return json.dumps({"verdict": "possible", "confidence": 50,
                           "reason": "ANTHROPIC_API_KEY not set"})
    try:
        body = json.dumps({"model": MODEL, "max_tokens": 300,
            "system": SYSTEM,
            "messages": [{"role": "user", "content": prompt}]}).encode()
        ctx = ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request("https://api.anthropic.com/v1/messages",
            data=body, method="POST",
            headers={"x-api-key": API_KEY, "anthropic-version": "2023-06-01",
                     "content-type": "application/json"})
        with urllib.request.urlopen(req, timeout=20, context=ctx) as r:
            d = json.loads(r.read())
            for block in d.get("content", []):
                if block.get("type") == "text":
                    return block["text"].strip()
    except Exception as e:
        log.warning(f"fp_filter: {e}")
    return json.dumps({"verdict": "possible", "confidence": 50, "reason": str(e)})


def review_finding(finding: Dict, response_preview: str = "") -> Dict:
    """
    AI reviews a single finding. Returns:
    {"verdict": "confirmed|probable|possible|unlikely|false_positive",
     "confidence": 0-100, "reason": "...", "exploit_likely": true/false}
    """
    bug      = finding.get("bug", "")
    sev      = finding.get("severity", "")
    url      = finding.get("url", "")
    title    = finding.get("title", "")
    poc      = finding.get("poc", "")
    payload  = finding.get("payload", "")
    param    = finding.get("param", "")
    preview  = response_preview or finding.get("response_preview", "")[:500]
    scanner_conf = finding.get("confidence", 50)

    prompt = f"""Review this vulnerability scanner finding:

Bug Type: {bug}
Severity: {sev}
URL: {url}
Title: {title}
Parameter: {param}
Payload used: {payload}
PoC command: {poc}
Scanner confidence: {scanner_conf}%
Response preview: {preview[:300] if preview else '(not captured)'}

Is this a real vulnerability or a false positive?

Respond with ONLY this JSON:
{{
  "verdict": "confirmed",
  "confidence": 90,
  "exploit_likely": true,
  "reason": "The response reflects the XSS payload in executable context (innerHTML sink detected). PoC is valid.",
  "what_to_check": "Manually verify by visiting PoC URL in browser"
}}

Verdicts: confirmed (>90% sure), probable (70-90%), possible (50-70%), unlikely (30-50%), false_positive (<30%)"""

    raw = _claude(prompt)
    m   = re.search(r'\{.*\}', raw, re.DOTALL)
    try:
        result = json.loads(m.group() if m else raw)
        result["finding_bug"] = bug
        result["finding_url"] = url
        return result
    except Exception:
        return {"verdict": "possible", "confidence": 50,
                "reason": "Could not parse AI review", "exploit_likely": False,
                "finding_bug": bug, "finding_url": url}


def batch_review(findings: List[Dict], max_findings: int = 20) -> List[Dict]:
    """Review multiple findings. Returns list of review results."""
    results = []
    for f in findings[:max_findings]:
        review = review_finding(f)
        review["finding"] = f
        results.append(review)
    return results


def filter_confirmed(findings: List[Dict], min_verdict: str = "probable") -> List[Dict]:
    """
    Quick local filter (no AI) using heuristics to pre-score findings.
    Use before AI review to reduce API calls.
    """
    verdict_order = {"confirmed":5,"probable":4,"possible":3,"unlikely":2,"false_positive":1}
    min_score     = verdict_order.get(min_verdict, 3)

    scored = []
    for f in findings:
        score = 3  # default: possible

        # High confidence scanner result
        if int(f.get("confidence", 50)) >= 90:
            score = max(score, 4)
        elif int(f.get("confidence", 50)) >= 70:
            score = max(score, 3)

        # Has a working PoC
        if f.get("poc","").strip() and "curl" in f.get("poc",""):
            score = max(score, 4)

        # Critical severity
        if f.get("severity") == "critical":
            score = max(score, 4)

        # Has response preview with evidence
        preview = f.get("response_preview","") + f.get("preview","")
        if preview and any(s in preview for s in ["root:","admin:","secret","password","token","aws","iam"]):
            score = max(score, 5)

        # Potential FP indicators
        if "timeout" in f.get("title","").lower():
            score = min(score, 2)
        if f.get("confidence",50) < 40:
            score = min(score, 2)

        if score >= min_score:
            scored.append(f)

    return scored
