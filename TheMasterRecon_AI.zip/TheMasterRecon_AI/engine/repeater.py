"""
TheMasterRecon AI — HTTP Request Repeater (Burp-style)
Send, modify, and replay HTTP requests with full control.
Stores request history per domain.
"""
import json, ssl, time, logging, re, socket
import urllib.request, urllib.parse
from typing import Optional, Dict, List
from pathlib import Path

log = logging.getLogger("elite.repeater")


def _ssl():
    c = ssl.create_default_context()
    c.check_hostname = False
    c.verify_mode = ssl.CERT_NONE
    return c


def send_request(method: str, url: str, headers: Dict[str, str] = None,
                 body: str = "", timeout: int = 30, follow_redirects: bool = True) -> dict:
    """Send a raw HTTP request and return full response details."""
    headers = headers or {}
    start_ts = time.time()

    # Default headers if not set
    if "User-Agent" not in headers:
        headers["User-Agent"] = "TheMasterRecon-AI/2.0"

    try:
        data = body.encode("utf-8") if body else None
        if data and "Content-Length" not in headers:
            headers["Content-Length"] = str(len(data))

        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        opener = urllib.request.build_opener(
            urllib.request.HTTPSHandler(context=_ssl()),
        )
        if not follow_redirects:
            opener = urllib.request.build_opener(
                urllib.request.HTTPSHandler(context=_ssl()),
                urllib.request.HTTPRedirectHandler()
            )

        with opener.open(req, timeout=timeout) as resp:
            resp_body   = resp.read().decode("utf-8", errors="replace")
            resp_status = resp.status
            resp_hdrs   = dict(resp.headers)
            elapsed     = round((time.time() - start_ts) * 1000)

        # Build raw response text
        raw_resp  = f"HTTP/1.1 {resp_status} {resp.reason}\n"
        raw_resp += "\n".join(f"{k}: {v}" for k,v in resp_hdrs.items())
        raw_resp += f"\n\n{resp_body[:50000]}"

        # Build raw request text
        raw_req  = f"{method} {urllib.parse.urlparse(url).path or '/'}"
        if urllib.parse.urlparse(url).query:
            raw_req += "?" + urllib.parse.urlparse(url).query
        raw_req += " HTTP/1.1\n"
        raw_req += f"Host: {urllib.parse.urlparse(url).netloc}\n"
        raw_req += "\n".join(f"{k}: {v}" for k,v in headers.items() if k != "Host")
        if body:
            raw_req += f"\n\n{body}"

        return {
            "ok":           True,
            "status":       resp_status,
            "reason":       getattr(resp, 'reason', ''),
            "headers":      resp_hdrs,
            "body":         resp_body[:100000],
            "body_length":  len(resp_body),
            "elapsed_ms":   elapsed,
            "raw_request":  raw_req,
            "raw_response": raw_resp[:100000],
            "url":          url,
            "method":       method,
            "ts":           time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

    except urllib.error.HTTPError as e:
        elapsed = round((time.time() - start_ts) * 1000)
        try:
            err_body = e.read().decode("utf-8", errors="replace")
        except Exception:
            err_body = ""
        return {
            "ok":           True,
            "status":       e.code,
            "reason":       str(e.reason),
            "headers":      dict(e.headers),
            "body":         err_body[:100000],
            "body_length":  len(err_body),
            "elapsed_ms":   elapsed,
            "raw_request":  f"{method} {url}",
            "raw_response": f"HTTP/1.1 {e.code} {e.reason}\n{err_body[:10000]}",
            "url":          url,
            "method":       method,
            "ts":           time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        }
    except Exception as e:
        return {
            "ok":          False,
            "error":       str(e),
            "elapsed_ms":  round((time.time() - start_ts) * 1000),
            "url":         url,
            "method":      method,
            "ts":          time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        }


def parse_raw_request(raw: str, base_url: str = "") -> dict:
    """Parse a raw HTTP request string into components."""
    lines = raw.replace("\r\n", "\n").split("\n")
    if not lines:
        return {}

    # First line: METHOD PATH HTTP/VERSION
    first = lines[0].strip()
    parts = first.split(" ", 2)
    method = parts[0] if len(parts) > 0 else "GET"
    path   = parts[1] if len(parts) > 1 else "/"

    # Headers
    headers = {}
    body_start = 0
    for i, line in enumerate(lines[1:], 1):
        if line.strip() == "":
            body_start = i + 1
            break
        if ":" in line:
            k, v = line.split(":", 1)
            headers[k.strip()] = v.strip()

    body = "\n".join(lines[body_start:]) if body_start else ""

    # Build full URL
    host = headers.get("Host","")
    if host and not path.startswith("http"):
        scheme = "https" if "443" in host or base_url.startswith("https") else "http"
        url = f"{scheme}://{host}{path}"
    elif base_url:
        parsed = urllib.parse.urlparse(base_url)
        url = f"{parsed.scheme}://{parsed.netloc}{path}"
    else:
        url = path

    return {"method": method, "url": url, "headers": headers, "body": body, "path": path}


def compare_responses(resp1: dict, resp2: dict) -> dict:
    """Compare two HTTP responses and highlight differences."""
    def diff_lines(a: str, b: str) -> list:
        a_lines = a.splitlines()
        b_lines = b.splitlines()
        result  = []
        import difflib
        for line in difflib.unified_diff(a_lines, b_lines, lineterm="",
                                          fromfile="Response 1", tofile="Response 2", n=3):
            result.append(line)
        return result

    status_diff = resp1.get("status") != resp2.get("status")
    len_diff    = abs(resp1.get("body_length",0) - resp2.get("body_length",0))
    time_diff   = abs(resp1.get("elapsed_ms",0) - resp2.get("elapsed_ms",0))

    body_diff   = diff_lines(resp1.get("body",""), resp2.get("body",""))
    hdr_diff    = diff_lines(
        json.dumps(resp1.get("headers",{}), indent=2),
        json.dumps(resp2.get("headers",{}), indent=2))

    # Find interesting differences (potential vulnerabilities)
    interesting = []
    if status_diff:
        interesting.append(f"Status changed: {resp1.get('status')} → {resp2.get('status')}")
    if len_diff > 100:
        interesting.append(f"Body length diff: {len_diff} bytes")
    if time_diff > 2000:
        interesting.append(f"Time diff: {time_diff}ms (possible time-based injection)")
    if resp1.get("status") == 200 and resp2.get("status") in [401,403]:
        interesting.append("Auth bypass detected: response 1 succeeded, response 2 blocked")
    if resp2.get("status") == 200 and resp1.get("status") in [401,403]:
        interesting.append("Auth bypass detected: modified request bypassed access control")

    return {
        "status_changed":  status_diff,
        "length_diff":     len_diff,
        "time_diff_ms":    time_diff,
        "body_diff":       body_diff[:200],
        "header_diff":     hdr_diff[:50],
        "interesting":     interesting,
        "identical":       not status_diff and len_diff == 0 and not body_diff,
    }
