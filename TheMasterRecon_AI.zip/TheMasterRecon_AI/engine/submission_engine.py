"""
TheMasterRecon AI — Submission Engine
Human-gated pipeline: finding → draft → approved → submitted → tracked.
NEVER auto-submits. Reviewer approval required at every stage.
"""
import os, re, json, logging, hashlib, sqlite3, threading, time, secrets
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime

log = logging.getLogger("elite.submission")

_DATA_DIR = Path(os.environ.get("TMR_DATA_DIR", "./data"))
_DB_PATH  = str(_DATA_DIR / "submissions.db")
_lock     = threading.Lock()

# Draft lifecycle states
STATE_DRAFT    = "DRAFT"
STATE_READY    = "READY_FOR_REVIEW"
STATE_APPROVED = "APPROVED"
STATE_SUBMITTED= "SUBMITTED"
STATE_TRIAGED  = "TRIAGED"
STATE_RESOLVED = "RESOLVED"
STATE_REJECTED = "REJECTED"     # reviewer rejected before submit
STATE_DUPLICATE= "DUPLICATE"    # platform marked duplicate
STATE_INFO     = "INFORMATIVE"  # platform marked informative

_SCHEMA = """
CREATE TABLE IF NOT EXISTS drafts (
    id           TEXT PRIMARY KEY,
    finding_hash TEXT NOT NULL,
    program_id   TEXT NOT NULL,
    title        TEXT NOT NULL,
    severity     TEXT NOT NULL,
    bug_type     TEXT NOT NULL,
    url          TEXT NOT NULL,
    state        TEXT NOT NULL DEFAULT 'DRAFT',
    platform     TEXT DEFAULT 'generic',
    report_json  TEXT DEFAULT '{}',
    submission_id TEXT DEFAULT '',
    reviewer     TEXT DEFAULT '',
    reviewed_at  TEXT DEFAULT '',
    submitted_at TEXT DEFAULT '',
    notes        TEXT DEFAULT '',
    created_at   TEXT DEFAULT (datetime('now')),
    updated_at   TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_drafts_program ON drafts(program_id);
CREATE INDEX IF NOT EXISTS idx_drafts_state   ON drafts(state);
CREATE INDEX IF NOT EXISTS idx_drafts_hash    ON drafts(finding_hash);
"""


def _conn() -> sqlite3.Connection:
    _DATA_DIR.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(_DB_PATH, timeout=10, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.executescript(_SCHEMA)
    return c


# ── Core pipeline ──────────────────────────────────────────────────────────────

def create_draft(finding: Dict, program_id: str, reviewer_notes: str = "") -> str:
    """
    Create a submission draft from a confirmed finding.
    Returns draft_id. State = DRAFT.
    """
    from engine.program_intel import dedupe_key, is_in_scope, allowed_test

    # Scope check — hard block
    domain = re.sub(r"^https?://", "", finding.get("url","")).split("/")[0].split(":")[0]
    if not is_in_scope(domain, program_id):
        raise ValueError(
            f"[submission] BLOCKED: {domain} is not in scope for program {program_id}"
        )

    # Bug type allowed check
    bug = finding.get("bug", finding.get("bug_type","unknown"))
    if not allowed_test(bug, program_id):
        raise ValueError(
            f"[submission] BLOCKED: {bug} not in allowed_bugs for program {program_id}"
        )

    # Confidence check
    from engine.program_intel import get_config
    cfg = get_config(program_id)
    conf_min = cfg.get("confidence_min", 70)
    if finding.get("confidence", 0) < conf_min:
        raise ValueError(
            f"[submission] BLOCKED: confidence {finding.get('confidence',0)}"
            f" < threshold {conf_min}"
        )

    # Dedup — check existing drafts for same finding
    fhash = dedupe_key(finding)
    with _lock:
        conn = _conn()
        existing = conn.execute(
            "SELECT id, state FROM drafts WHERE finding_hash=? AND program_id=?",
            (fhash, program_id)
        ).fetchone()
        if existing:
            log.warning(
                f"[submission] duplicate finding_hash={fhash}"
                f" existing_draft={existing['id']} state={existing['state']}"
            )
            raise ValueError(
                f"Duplicate: finding already exists as draft {existing['id']}"
                f" (state={existing['state']})"
            )

    # Build report JSON
    platform = cfg.get("report_format", "generic")
    report   = _build_report(finding, program_id, platform)

    draft_id = "sub_" + secrets.token_hex(8)
    with _lock:
        conn = _conn()
        conn.execute(
            "INSERT INTO drafts(id,finding_hash,program_id,title,severity,"
            "bug_type,url,state,platform,report_json,notes)"
            " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (draft_id, fhash, program_id,
             report.get("title","Untitled"),
             finding.get("severity","medium"),
             bug,
             finding.get("url",""),
             STATE_DRAFT,
             platform,
             json.dumps(report),
             reviewer_notes)
        )
        conn.commit()

    log.info(f"[submission] draft created id={draft_id} bug={bug} program={program_id}")
    return draft_id


def approve_draft(draft_id: str, reviewer: str) -> Dict:
    """
    Mark a draft as APPROVED by a human reviewer.
    This is the only gate before submission.
    """
    if not reviewer or not reviewer.strip():
        raise ValueError("reviewer identity required — cannot approve anonymously")

    with _lock:
        conn = _conn()
        row = conn.execute("SELECT * FROM drafts WHERE id=?", (draft_id,)).fetchone()
        if not row:
            raise ValueError(f"Draft {draft_id} not found")
        if row["state"] not in (STATE_DRAFT, STATE_READY):
            raise ValueError(
                f"Cannot approve draft in state {row['state']} "
                f"(must be DRAFT or READY_FOR_REVIEW)"
            )
        conn.execute(
            "UPDATE drafts SET state=?, reviewer=?, reviewed_at=?, updated_at=datetime('now')"
            " WHERE id=?",
            (STATE_APPROVED, reviewer.strip(), datetime.utcnow().isoformat(), draft_id)
        )
        conn.commit()

    log.info(f"[submission] approved by {reviewer} id={draft_id}")
    return get_draft(draft_id)


def submit(draft_id: str) -> Dict:
    """
    Submit an APPROVED draft. Generates submission payload.
    NEVER submits unless state == APPROVED.
    Returns submission result with platform-formatted payload.
    """
    with _lock:
        conn = _conn()
        row = conn.execute("SELECT * FROM drafts WHERE id=?", (draft_id,)).fetchone()
        if not row:
            raise ValueError(f"Draft {draft_id} not found")
        if row["state"] != STATE_APPROVED:
            raise ValueError(
                f"BLOCKED: cannot submit draft in state {row['state']}. "
                f"Reviewer must approve first via approve_draft()."
            )

    report   = json.loads(row["report_json"] or "{}")
    platform = row["platform"]

    # Format for target platform
    payload  = _format_for_platform(report, platform)

    # Attempt API submission (adapters handle auth themselves)
    submission_id = ""
    submitted_via = "copy_paste"  # default: no API configured

    try:
        if platform == "hackerone":
            from engine.hackerone_adapter import submit as _h1_submit
            submission_id = _h1_submit(payload)
            submitted_via = "api"
        elif platform == "intigriti":
            from engine.intigriti_adapter import submit as _ig_submit
            submission_id = _ig_submit(payload)
            submitted_via = "api"
        elif platform == "yeswehack":
            from engine.yeswehack_adapter import submit as _ywh_submit
            submission_id = _ywh_submit(payload)
            submitted_via = "api"
    except ImportError:
        # Adapter not configured — return copy-paste payload
        log.info(f"[submission] no API adapter for {platform} — generating copy-paste payload")
    except Exception as e:
        log.warning(f"[submission] API submit failed: {e} — falling back to copy-paste")

    with _lock:
        conn = _conn()
        conn.execute(
            "UPDATE drafts SET state=?, submission_id=?, submitted_at=?, updated_at=datetime('now')"
            " WHERE id=?",
            (STATE_SUBMITTED, submission_id, datetime.utcnow().isoformat(), draft_id)
        )
        conn.commit()

    log.info(
        f"[submission] submitted to {platform}"
        f" id={submission_id or '(copy-paste)'}"
        f" draft={draft_id}"
    )

    return {
        "draft_id":      draft_id,
        "state":         STATE_SUBMITTED,
        "platform":      platform,
        "submitted_via": submitted_via,
        "submission_id": submission_id,
        "payload":       payload,   # ready to copy-paste if no API
    }


def sync_status(draft_id: str, new_state: str = "", bounty: float = 0.0) -> Dict:
    """
    Update submission status (manual or via platform API poll).
    new_state: TRIAGED | RESOLVED | DUPLICATE | INFORMATIVE
    """
    valid = {STATE_TRIAGED, STATE_RESOLVED, STATE_DUPLICATE, STATE_INFO, STATE_REJECTED}
    if new_state and new_state not in valid:
        raise ValueError(f"Invalid state {new_state}. Valid: {valid}")

    with _lock:
        conn = _conn()
        if new_state:
            conn.execute(
                "UPDATE drafts SET state=?, updated_at=datetime('now') WHERE id=?",
                (new_state, draft_id)
            )
            conn.commit()
        row = conn.execute("SELECT * FROM drafts WHERE id=?", (draft_id,)).fetchone()

    if not row: raise ValueError(f"Draft {draft_id} not found")

    if new_state:
        log.info(f"[submission] status updated: id={draft_id} state={new_state} bounty=${bounty}")

        # Update payout if bounty provided
        if bounty > 0:
            try:
                from engine.payout_tracker import update_status
                update_status(draft_id, new_state, bounty=bounty)
            except Exception as e:
                log.debug(f"[submission] payout update: {e}")

    return dict(row)


def get_draft(draft_id: str) -> Optional[Dict]:
    with _lock:
        conn = _conn()
        row = conn.execute("SELECT * FROM drafts WHERE id=?", (draft_id,)).fetchone()
    return dict(row) if row else None


def list_drafts(program_id: str = "", state: str = "") -> List[Dict]:
    with _lock:
        conn = _conn()
        q    = "SELECT * FROM drafts WHERE 1=1"
        args = []
        if program_id: q += " AND program_id=?"; args.append(program_id)
        if state:      q += " AND state=?";      args.append(state)
        q += " ORDER BY created_at DESC"
        rows = conn.execute(q, args).fetchall()
    return [dict(r) for r in rows]


# ── Report builder ─────────────────────────────────────────────────────────────

def _build_report(finding: Dict, program_id: str, platform: str) -> Dict:
    """Build a structured report from a finding."""
    bug   = finding.get("bug", finding.get("bug_type","vulnerability"))
    url   = finding.get("url","")
    sev   = finding.get("severity","medium")
    param = finding.get("param","")
    poc   = finding.get("poc","")
    proof = finding.get("proof","")
    conf  = finding.get("confidence",0)

    title = (
        f"{bug.upper()} in {_extract_path(url)}"
        if not finding.get("title") else finding["title"]
    )

    # Steps to reproduce
    steps = [
        f"1. Navigate to: {url}",
    ]
    if param:
        steps.append(f"2. Inject payload in parameter: `{param}`")
    if poc:
        steps.append(f"3. Execute: `{poc}`")
    steps.append(f"4. Observe: {proof or 'vulnerability confirmed'}")

    impact = finding.get("impact") or _default_impact(bug)
    remediation = finding.get("remediation") or _default_remediation(bug)

    return {
        "title":        title,
        "bug_type":     bug,
        "severity":     sev,
        "url":          url,
        "param":        param,
        "confidence":   conf,
        "program_id":   program_id,
        "platform":     platform,
        "summary":      f"{bug.upper()} vulnerability found at {url}",
        "steps":        steps,
        "poc":          poc,
        "proof":        proof,
        "impact":       impact,
        "remediation":  remediation,
        "cvss":         finding.get("cvss",""),
        "cwe":          finding.get("cwe",""),
        "nuclei_template": finding.get("nuclei_template",""),
        "tool":         finding.get("tool","scanner"),
        "created_at":   datetime.utcnow().isoformat(),
    }


def _format_for_platform(report: Dict, platform: str) -> Dict:
    """Format report dict for specific platform."""
    if platform == "hackerone":
        return {
            "data": {
                "type": "report",
                "attributes": {
                    "title":             report["title"],
                    "vulnerability_information": (
                        f"## Summary\n{report['summary']}\n\n"
                        f"## Steps to Reproduce\n" +
                        "\n".join(report.get("steps",[])) +
                        f"\n\n## Impact\n{report['impact']}\n\n"
                        f"## Proof of Concept\n```\n{report['poc']}\n```\n\n"
                        f"## Remediation\n{report['remediation']}"
                    ),
                    "severity_rating":   _h1_severity(report["severity"]),
                    "weakness_id":       report.get("cwe","").replace("CWE-","") or None,
                }
            }
        }
    elif platform == "intigriti":
        return {
            "title":       report["title"],
            "description": (
                f"**Summary:** {report['summary']}\n\n"
                f"**Steps:**\n" + "\n".join(report.get("steps",[])) +
                f"\n\n**PoC:**\n```\n{report['poc']}\n```\n\n"
                f"**Impact:** {report['impact']}"
            ),
            "type":        report["bug_type"],
            "severity":    _intigriti_severity(report["severity"]),
            "endpoint":    report["url"],
        }
    elif platform == "yeswehack":
        return {
            "title":          report["title"],
            "scope":          report["url"],
            "vulnerability_type": report["bug_type"],
            "cvss_vector":    report.get("cvss",""),
            "proof_of_concept": (
                "\n".join(report.get("steps",[])) +
                f"\n\nPoC:\n{report['poc']}"
            ),
            "impact":         report["impact"],
        }
    else:
        # Generic one-click copy payload
        return {
            "title":         report["title"],
            "severity":      report["severity"],
            "url":           report["url"],
            "summary":       report["summary"],
            "steps":         "\n".join(report.get("steps",[])),
            "poc":           report["poc"],
            "proof":         report["proof"],
            "impact":        report["impact"],
            "remediation":   report["remediation"],
            "cvss":          report.get("cvss",""),
            "cwe":           report.get("cwe",""),
            "confidence":    report.get("confidence",0),
        }


def _h1_severity(sev: str) -> str:
    return {"critical":"critical","high":"high","medium":"medium","low":"low"}.get(sev.lower(),"medium")

def _intigriti_severity(sev: str) -> str:
    return {"critical":"Critical","high":"High","medium":"Medium","low":"Low"}.get(sev.lower(),"Medium")

def _extract_path(url: str) -> str:
    from urllib.parse import urlparse
    try:   return urlparse(url).path[:40] or url[:40]
    except: return url[:40]

def _default_impact(bug: str) -> str:
    impacts = {
        "ssrf":    "Access to cloud metadata (AWS IMDS), internal services, credential theft",
        "sqli":    "Full database read/write, authentication bypass, potential RCE",
        "xss":     "Session hijacking, credential theft, account takeover",
        "rce":     "Full server compromise, data exfiltration, persistence",
        "lfi":     "Read sensitive files (/etc/passwd, config, private keys)",
        "idor":    "Unauthorized access to other users' data",
        "ssti":    "Remote code execution via template engine",
        "cors":    "Cross-origin API access, token theft from authenticated sessions",
        "redirect":"Phishing, OAuth token theft via malicious redirect",
    }
    return impacts.get(bug.lower(), f"Security vulnerability with potential data exposure")

def _default_remediation(bug: str) -> str:
    rems = {
        "ssrf":    "Validate/whitelist allowed URLs server-side; block internal IP ranges",
        "sqli":    "Use parameterized queries / prepared statements throughout",
        "xss":     "Encode all user-supplied output; implement strict Content-Security-Policy",
        "rce":     "Never pass user input to shell commands; use allowlist validation",
        "lfi":     "Use allowlist of permitted file paths; never use user input in file operations",
        "idor":    "Enforce object-level authorization on every request",
        "ssti":    "Never pass user input to template engines; use sandboxed rendering",
        "cors":    "Restrict CORS to specific trusted origins; never reflect arbitrary Origin",
        "redirect":"Validate redirect targets against allowlist; reject external destinations",
    }
    return rems.get(bug.lower(), "Review and fix the identified vulnerability following OWASP guidelines")
