"""
BugScan ELITE — Rich Notification Cards
Sends beautifully formatted cards to Telegram/Discord/Slack
with CVSS score, PoC preview, one-tap links, and context.
"""
import os, json, time, logging, urllib.request, urllib.parse, ssl
from typing import Dict, List, Optional

log = logging.getLogger("elite.richnotify")

CVSS_SCORES = {
    "critical":10.0,"high":7.5,"medium":5.3,"low":3.1,"info":0.0
}
SEV_EMOJI   = {"critical":"🔴","high":"🟠","medium":"🟡","low":"🔵","info":"⚪"}
SEV_COLOR   = {"critical":0xFF0000,"high":0xFF6600,"medium":0xFFCC00,
               "low":0x3399FF,"info":0x808080}
BUG_EMOJI   = {
    "rce":"💀","sqli":"🗄️","ssrf":"🌐","lfi":"📁","ssti":"🧩",
    "xxe":"📄","cors":"🔗","idor":"🔓","xss":"💉","expose":"🔑",
    "actuator":"⚙️","takeover":"🏴","jsleak":"🔐","oauth":"🎫",
    "jwt":"🎟️","graphql":"🕸️","saml":"🔏","log4j":"☢️",
    "spring4shell":"🌱","misconfig":"⚠️","buckets":"☁️","cve":"🩹",
}

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _post(url, payload, headers=None, timeout=10):
    try:
        data = json.dumps(payload).encode()
        h    = {"Content-Type":"application/json","User-Agent":"BugScanELITE/1.0"}
        if headers: h.update(headers)
        req  = urllib.request.Request(url, data=data, headers=h, method="POST")
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status in (200,204)
    except Exception as e:
        log.debug(f"rich notify {url}: {e}")
        return False

def _telegram_post(token, chat_id, payload, timeout=10):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    return _post(url, {**payload, "chat_id": chat_id}, timeout=timeout)


class RichNotifier:
    """Sends rich formatted notifications for all event types."""

    def __init__(self):
        self.slack_wh    = os.environ.get("SLACK_WEBHOOK","")
        self.discord_wh  = os.environ.get("DISCORD_WEBHOOK","")
        self.tg_token    = os.environ.get("TELEGRAM_TOKEN", os.environ.get("TELEGRAM_BOT_TOKEN",""))
        self.tg_chat     = os.environ.get("TELEGRAM_CHAT_ID","")
        self.min_sev     = os.environ.get("NOTIFY_MIN_SEV","high")

    @property
    def configured(self):
        return bool(self.slack_wh or self.discord_wh or
                    (self.tg_token and self.tg_chat))

    def _sev_rank(self, sev):
        return ["info","low","medium","high","critical"].index(sev) \
               if sev in ["info","low","medium","high","critical"] else 0

    def should_notify(self, sev):
        return self._sev_rank(sev) >= self._sev_rank(self.min_sev)

    # ── Finding notification ──────────────────────────────────────────────────
    def finding(self, f: Dict, domain: str):
        sev = f.get("severity","info").lower()
        if not self.should_notify(sev): return

        bug    = f.get("bug","")
        url    = f.get("url","")
        det    = f.get("details",{})
        cvss   = CVSS_SCORES.get(sev,0.0)
        emoji  = SEV_EMOJI.get(sev,"⚪")
        bemoji = BUG_EMOJI.get(bug,"🐛")
        desc   = det.get("description","") or det.get("impact","") or ""
        poc    = det.get("poc","") or det.get("curl","")
        h1t    = det.get("h1_title","")

        # Telegram — rich markdown
        if self.tg_token and self.tg_chat:
            lines = [
                f"{emoji} *{sev.upper()} — {bug.upper()}*  {bemoji}",
                f"",
                f"🎯 `{domain}`",
                f"🔗 `{url[:80]}`",
                f"📊 CVSS: *{cvss}*",
            ]
            if desc: lines += [f"", f"📝 {desc[:200]}"]
            if poc:  lines += [f"", f"```{poc[:200]}```"]
            if h1t:  lines += [f"", f"📋 H1 Title: _{h1t[:70]}_"]
            lines += [f"", f"⏰ {time.strftime('%H:%M UTC')}"]

            _telegram_post(self.tg_token, self.tg_chat, {
                "text":       "\n".join(lines),
                "parse_mode": "Markdown",
                "disable_web_page_preview": True,
            })

        # Discord — embed card
        if self.discord_wh:
            fields = [
                {"name":"Severity","value":f"{emoji} {sev.upper()}","inline":True},
                {"name":"CVSS","value":str(cvss),"inline":True},
                {"name":"Type","value":f"{bemoji} {bug.upper()}","inline":True},
                {"name":"URL","value":f"`{url[:80]}`","inline":False},
            ]
            if desc: fields.append({"name":"Description","value":desc[:300],"inline":False})
            if poc:  fields.append({"name":"PoC","value":f"```{poc[:200]}```","inline":False})

            _post(self.discord_wh, {"embeds":[{
                "title":       f"{emoji} {sev.upper()} — {bug.upper()} in {domain}",
                "description": h1t or desc[:100],
                "color":       SEV_COLOR.get(sev,0x808080),
                "fields":      fields,
                "footer":      {"text":f"BugScan ELITE • {time.strftime('%H:%M UTC')}"},
                "thumbnail":   {"url":"https://i.imgur.com/bug.png"},
            }]})

        # Slack — attachment
        if self.slack_wh:
            color_map = {"critical":"#FF0000","high":"#FF6600",
                         "medium":"#FFCC00","low":"#3399FF"}
            _post(self.slack_wh, {
                "text": f"{emoji} *{sev.upper()} — {bug.upper()}* in `{domain}`",
                "attachments":[{
                    "color": color_map.get(sev,"#808080"),
                    "fields":[
                        {"title":"URL","value":url[:80],"short":False},
                        {"title":"CVSS","value":str(cvss),"short":True},
                        {"title":"Type","value":bug.upper(),"short":True},
                        {"title":"Description","value":desc[:200],"short":False},
                        *([{"title":"PoC","value":f"```{poc[:150]}```","short":False}] if poc else []),
                    ],
                    "footer":f"BugScan ELITE • {time.strftime('%H:%M UTC')}",
                }]
            })

    # ── Chain notification ────────────────────────────────────────────────────
    def chain(self, c: Dict, domain: str):
        name   = c.get("name","")
        impact = c.get("impact","")
        sev    = c.get("severity","critical")
        steps  = c.get("steps",[])[:3]
        poc    = c.get("poc","")[:300]

        if self.tg_token and self.tg_chat:
            lines = [
                f"⛓ *EXPLOITATION CHAIN FOUND*",
                f"",
                f"🎯 `{domain}`",
                f"💥 *{name}*",
                f"",
                f"📌 Impact: {impact[:150]}",
                f"",
                *[f"→ {s}" for s in steps],
                f"",
                *([f"```{poc}```"] if poc else []),
                f"⏰ {time.strftime('%H:%M UTC')}",
            ]
            _telegram_post(self.tg_token, self.tg_chat, {
                "text":       "\n".join(lines),
                "parse_mode": "Markdown",
                "disable_web_page_preview": True,
            })

        if self.discord_wh:
            fields = [
                {"name":"Impact","value":impact[:200],"inline":False},
                {"name":"Steps","value":"\n".join(f"• {s}" for s in steps),"inline":False},
            ]
            if poc:
                fields.append({"name":"PoC","value":f"```{poc[:300]}```","inline":False})
            _post(self.discord_wh, {"embeds":[{
                "title":  f"⛓ CHAIN: {name}",
                "color":  0xFF0000,
                "fields": fields,
                "footer": {"text":f"BugScan ELITE • {domain} • {time.strftime('%H:%M UTC')}"},
            }]})

        if self.slack_wh:
            _post(self.slack_wh, {
                "text": f"⛓ *EXPLOITATION CHAIN: {name}*",
                "attachments":[{
                    "color":"#FF0000",
                    "fields":[
                        {"title":"Domain","value":domain,"short":True},
                        {"title":"Severity","value":sev.upper(),"short":True},
                        {"title":"Impact","value":impact[:200],"short":False},
                        {"title":"Steps","value":"\n".join(f"• {s}" for s in steps),"short":False},
                    ],
                }]
            })

    # ── Recon complete ────────────────────────────────────────────────────────
    def recon_done(self, domain: str, subs: int, live: int,
                   ends: int, tech: List[str]):
        msg_tg = (
            f"✅ *Recon Complete*\n"
            f"🎯 `{domain}`\n"
            f"📊 {subs} subs · {live} live · {ends} endpoints\n"
            f"⚙️ {', '.join(tech[:5]) or 'Unknown'}\n"
            f"⏰ {time.strftime('%H:%M UTC')}"
        )
        if self.tg_token and self.tg_chat:
            _telegram_post(self.tg_token, self.tg_chat,
                           {"text":msg_tg,"parse_mode":"Markdown"})
        if self.discord_wh:
            _post(self.discord_wh, {"embeds":[{
                "title":f"✅ Recon Complete — {domain}",
                "color":0x00FF88,
                "fields":[
                    {"name":"Subdomains","value":str(subs),"inline":True},
                    {"name":"Live Hosts","value":str(live),"inline":True},
                    {"name":"Endpoints","value":str(ends),"inline":True},
                    {"name":"Technologies","value":", ".join(tech[:8]) or "Unknown","inline":False},
                ],
                "footer":{"text":f"BugScan ELITE • {time.strftime('%H:%M UTC')}"},
            }]})

    # ── Scan complete ─────────────────────────────────────────────────────────
    def scan_done(self, domain: str, total: int, crits: int,
                  highs: int, chains: int, ai_summary: str = ""):
        emoji = "🔴" if crits > 0 else "🟢"
        msg_tg = (
            f"{emoji} *Scan Complete*\n"
            f"🎯 `{domain}`\n"
            f"🐛 {total} findings · 🔴 {crits} critical · 🟠 {highs} high\n"
            f"⛓ {chains} exploitation chains\n"
        )
        if ai_summary:
            msg_tg += f"\n💡 _{ai_summary[:200]}_\n"
        msg_tg += f"⏰ {time.strftime('%H:%M UTC')}"

        if self.tg_token and self.tg_chat:
            _telegram_post(self.tg_token, self.tg_chat,
                           {"text":msg_tg,"parse_mode":"Markdown"})
        if self.discord_wh:
            _post(self.discord_wh, {"embeds":[{
                "title":       f"{emoji} Scan Complete — {domain}",
                "description": ai_summary[:400] if ai_summary else None,
                "color":       0xFF0000 if crits > 0 else 0x00FF88,
                "fields":[
                    {"name":"Total Findings","value":str(total),"inline":True},
                    {"name":"Critical","value":str(crits),"inline":True},
                    {"name":"High","value":str(highs),"inline":True},
                    {"name":"Chains","value":str(chains),"inline":True},
                ],
                "footer":{"text":f"BugScan ELITE • {time.strftime('%H:%M UTC')}"},
            }]})

    # ── Retest result ─────────────────────────────────────────────────────────
    def retest_result(self, result: Dict, domain: str):
        status = result.get("status","")
        bug    = result.get("bug","")
        url    = result.get("url","")
        msg_map = {
            "fixed":          ("✅","FIXED"),
            "still_vulnerable":("🔴","STILL VULNERABLE"),
            "regressed":      ("⚠️","REGRESSED"),
            "inconclusive":   ("❓","INCONCLUSIVE"),
        }
        emoji, label = msg_map.get(status, ("❓","UNKNOWN"))

        msg = (
            f"{emoji} *Retest: {label}*\n"
            f"🐛 {bug.upper()} · 🎯 `{domain}`\n"
            f"🔗 `{url[:60]}`\n"
            f"📝 {result.get('message','')[:150]}"
        )
        if self.tg_token and self.tg_chat:
            _telegram_post(self.tg_token, self.tg_chat,
                           {"text":msg,"parse_mode":"Markdown"})

    # ── Diff alert ────────────────────────────────────────────────────────────
    def diff_alert(self, domain: str, diff: Dict):
        new_subs  = len(diff.get("subdomains",{}).get("new",[]))
        new_finds = diff.get("findings",{}).get("new_count",0)
        new_crits = len(diff.get("findings",{}).get("new_critical",[]))
        sev       = diff.get("severity","info")

        if not self.should_notify(sev): return

        emoji = SEV_EMOJI.get(sev,"⚪")
        msg   = (
            f"{emoji} *Attack Surface Change — {domain}*\n"
            f"🆕 {new_subs} new subdomains\n"
            f"🐛 {new_finds} new findings ({new_crits} critical)\n"
            f"⏰ {time.strftime('%H:%M UTC')}"
        )
        if self.tg_token and self.tg_chat:
            _telegram_post(self.tg_token, self.tg_chat,
                           {"text":msg,"parse_mode":"Markdown"})

    # ── Test ──────────────────────────────────────────────────────────────────
    def test(self) -> Dict:
        results = {}
        msg = "🔔 BugScan ELITE — Rich notification test"

        if self.tg_token and self.tg_chat:
            ok = _telegram_post(self.tg_token, self.tg_chat,
                                {"text":msg,"parse_mode":"Markdown"})
            results["telegram"] = ok

        if self.discord_wh:
            ok = _post(self.discord_wh, {
                "embeds":[{"title":"Test","description":msg,"color":0x00FF88}]
            })
            results["discord"] = ok

        if self.slack_wh:
            ok = _post(self.slack_wh, {"text":msg})
            results["slack"] = ok

        return results


# Global singleton
_rich: Optional[RichNotifier] = None

def get_rich_notifier() -> RichNotifier:
    global _rich
    if _rich is None:
        _rich = RichNotifier()
    return _rich
