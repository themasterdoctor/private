"""
engine/surface_intel.py — Elite Bug Bounty Recon Logic v1

High-signal attack surface classification, hidden endpoint discovery,
API chain detection, auth priority tagging, GraphQL/Swagger parsing,
JS secret intelligence, and safe test plan generation.

HARD RULES:
  - No auto-exploitation
  - No auto-submission
  - No fabricated impact
  - Safe test plans only
"""

import re
import json
import time
import logging
import hashlib
from typing import Dict, List, Tuple, Optional
from urllib.parse import urlparse, urljoin

log = logging.getLogger("elite.surface_intel")

# ── Surface categories and scores ─────────────────────────────────────────────

SURFACE_RULES: List[Tuple[str, str, int, re.Pattern]] = [
    # (category, label, score, pattern)
    ("payment",   "Payment/Billing",    10, re.compile(
        r"(payment|billing|invoice|stripe|checkout|subscribe|pricing|"
        r"credit.card|paypal|purchase|order|cart|transaction)", re.I)),
    ("api",       "API Endpoint",       9, re.compile(
        r"(/api/|/v\d+/|/rest/|/graphql|/gql|/rpc/|\.json$|/json$)", re.I)),
    ("auth",      "Auth/Login/SSO",     9, re.compile(
        r"(login|signin|sign[-_]?in|auth|oauth|oidc|saml|sso|"
        r"token|session|logout|register|signup|password|"
        r"forgot[-_]?pass|reset[-_]?pass|2fa|mfa|totp|webauthn)", re.I)),
    ("admin",     "Admin/Management",   9, re.compile(
        r"(admin|administrator|manage|management|dashboard|console|"
        r"panel|cp|backoffice|backend|superuser|moderator|"
        r"wp-admin|phpmyadmin|adminer|cpanel|plesk)", re.I)),
    ("webhook",   "Webhook/Callback",   8, re.compile(
        r"(webhook|callback|notify|notification|hook|event|"
        r"trigger|subscribe|push|delivery)", re.I)),
    ("upload",    "Upload/File",        8, re.compile(
        r"(upload|import|file|attachment|document|media|"
        r"image|avatar|logo|asset|binary|blob|export)", re.I)),
    ("graphql",   "GraphQL",            8, re.compile(
        r"(graphql|graphiql|gql|graph/query|graphql/console)", re.I)),
    ("swagger",   "Swagger/OpenAPI",    8, re.compile(
        r"(swagger|openapi|api-docs|api/docs|redoc|v3/api-docs|"
        r"api.json|api.yaml|swagger.json|swagger.yaml)", re.I)),
    ("cloud",     "Cloud/Storage",      7, re.compile(
        r"(s3|bucket|blob|storage|gcs|azure|cloudfront|"
        r"lambda|function|serverless|cdn|asset)", re.I)),
    ("internal",  "Internal/Corp",      7, re.compile(
        r"(internal|corp|intranet|vpn|private|local|"
        r"dev\.|develop|staging|stage|preprod|pre-prod|"
        r"qa\.|test\.|sandbox|uat\.|demo\.)", re.I)),
    ("debug",     "Debug/Dev",          6, re.compile(
        r"(debug|trace|health|ping|metrics|actuator|"
        r"\.env|\.git|\.svn|config\.|phpinfo|"
        r"test\.|dev\.|localhost|127\.0\.0)", re.I)),
    ("oauth_cb",  "OAuth Callback",     6, re.compile(
        r"(callback|redirect_uri|return_url|returnUrl|"
        r"next=|redirect=|continue=|goto=|dest=)", re.I)),
]

ACCESS_CONTROL_PATHS = re.compile(
    r"/(me|profile|account|user|users|admin|team|teams|org|"
    r"billing|invoice|roles|permissions|settings|preferences|"
    r"member|members|project|projects|workspace)[/\?]?", re.I)

HIGH_VALUE = {"payment","api","auth","admin","webhook","upload","graphql","swagger","cloud"}

# ── Surface classification ────────────────────────────────────────────────────

def classify_url(url: str) -> Dict:
    """
    Classify a single URL into surface categories with scores.
    Returns: {surfaces, score, access_control_candidate, labels}
    """
    surfaces: List[str] = []
    labels:   List[str] = []
    score = 0
    for cat, label, cat_score, pat in SURFACE_RULES:
        if pat.search(url):
            surfaces.append(cat)
            labels.append(label)
            score = max(score, cat_score)
    ac = bool(ACCESS_CONTROL_PATHS.search(url))
    if ac and score < 7:
        score = 7
    return {
        "url":                      url,
        "surfaces":                 surfaces or ["generic"],
        "labels":                   labels or ["Generic"],
        "score":                    score or 1,
        "access_control_candidate": ac,
        "is_high_value":            bool(surfaces and any(s in HIGH_VALUE for s in surfaces)),
    }


def classify_host(url: str, tech: list = None, title: str = "") -> Dict:
    """Classify a live host by URL, tech stack, and page title."""
    tech  = tech or []
    info  = classify_url(url)
    extra: List[str] = []
    # Tech-based surface additions
    tech_str = " ".join(tech).lower()
    if any(t in tech_str for t in ["react","angular","vue","next","nuxt","gatsby"]):
        extra.append("js_spa")
    if any(t in tech_str for t in ["graphql","hasura","apollo"]):
        if "graphql" not in info["surfaces"]:
            info["surfaces"].append("graphql")
            info["score"] = max(info["score"], 8)
    if any(t in tech_str for t in ["wordpress","drupal","joomla"]):
        extra.append("cms")
    if title:
        tl = title.lower()
        if any(w in tl for w in ["login","sign in","dashboard","admin","portal"]):
            info["score"] = min(10, info["score"] + 1)
    info["extra_surfaces"] = extra
    return info


def map_surface(hosts: List[Dict], endpoints: List[str]) -> Dict:
    """
    Full surface map for a domain.
    Returns classified hosts, endpoints, and top attack surfaces.
    """
    classified_hosts: Dict[str, Dict] = {}
    for h in hosts:
        url  = h.get("url","")
        tech = h.get("tech",[])
        title = h.get("title","")
        if url:
            classified_hosts[url] = classify_host(url, tech, title)

    classified_eps: Dict[str, Dict] = {}
    for ep in endpoints:
        classified_eps[ep] = classify_url(ep)

    # Surface frequency counts
    surface_counts: Dict[str, int] = {}
    high_value_eps: List[Dict]     = []
    for ep, info in classified_eps.items():
        for s in info["surfaces"]:
            surface_counts[s] = surface_counts.get(s,0) + 1
        if info["is_high_value"] or info["access_control_candidate"]:
            high_value_eps.append({
                "url":   ep,
                "score": info["score"],
                "surfaces": info["surfaces"],
                "ac":    info["access_control_candidate"],
            })

    high_value_eps.sort(key=lambda x: -x["score"])

    top_hosts = sorted(
        classified_hosts.values(),
        key=lambda h: -h.get("score",0)
    )[:20]

    return {
        "hosts":              classified_hosts,
        "endpoints":          classified_eps,
        "surface_counts":     surface_counts,
        "top_attack_surfaces": sorted(surface_counts.items(), key=lambda x: -x[1])[:10],
        "high_value_endpoints": high_value_eps[:100],
        "top_hosts":          top_hosts,
        "stats": {
            "total_hosts":          len(classified_hosts),
            "total_endpoints":      len(classified_eps),
            "high_value_endpoints": len(high_value_eps),
            "access_control_candidates": sum(
                1 for v in classified_eps.values()
                if v["access_control_candidate"]
            ),
        }
    }


# ── Hidden endpoint discovery ─────────────────────────────────────────────────

# Patterns for extracting hidden paths from JS/source
_JS_PATH_PATS = [
    re.compile(r'''['"]((/[\w\-./?=&%#@+:]+){2,})['"]'''),          # quoted paths
    re.compile(r'(?:path|url|endpoint|route|api):\s*["\']([^"\']+)'),# config keys
    re.compile(r'fetch\(["\']([^"\']+)["\']'),                        # fetch() calls
    re.compile(r'axios\.[a-z]+\(["\']([^"\']+)["\']'),               # axios calls
    re.compile(r'\.open\(["\'][A-Z]+["\'],\s*["\']([^"\']+)["\']'),  # XHR open
]
_JS_SECRET_PATS = [
    (re.compile(r'(?i)api[_\-]?key\s*[:=]\s*["\']([a-zA-Z0-9\-_]{20,})'), "api_key",        "high"),
    (re.compile(r'(?i)firebase[^{]*apiKey\s*:\s*["\']([^"\']+)'),          "firebase_key",   "high"),
    (re.compile(r'(?i)sentry[^{]*dsn\s*[:=]\s*["\']([^"\']+)'),           "sentry_dsn",     "medium"),
    (re.compile(r'(?i)stripe[^{]*pk_(?:live|test)_([a-zA-Z0-9_]+)'),      "stripe_pk",      "medium"),
    (re.compile(r'(?i)client.?id\s*[:=]\s*["\']([a-zA-Z0-9\-_.]{10,})'), "oauth_client_id","medium"),
    (re.compile(r'(?i)(?:secret|token)\s*[:=]\s*["\']([a-zA-Z0-9\-_]{16,})'), "secret_token","high"),
    (re.compile(r'(?i)(?:password|passwd)\s*[:=]\s*["\']([^"\']{6,})'),   "hardcoded_pw",   "critical"),
    (re.compile(r'(?i)(?:internal|staging|dev)[_\-]?(?:url|host|api)\s*[:=]\s*["\']([^"\']+)'), "internal_url","medium"),
    (re.compile(r'https?://(?:internal|corp|intranet|vpn|private)[^"\'>\s]+'), "internal_url","medium"),
    (re.compile(r'(?i)aws[_\-]?(?:access[_\-]?key|secret)[_\-]?(?:id)?\s*[:=]\s*["\']([A-Z0-9/+=]{16,})'), "aws_key","critical"),
]

def extract_js_endpoints(content: str, base_url: str) -> List[str]:
    """Extract API paths from JavaScript content."""
    found: set = set()
    for pat in _JS_PATH_PATS:
        for m in pat.findall(content):
            path = m if isinstance(m, str) else m[0]
            if len(path) < 3 or len(path) > 200:
                continue
            if any(skip in path for skip in ["/home/","/root/","/usr/","/var/",".min.js"]):
                continue
            if path.startswith("/"):
                try:
                    parsed = urlparse(base_url)
                    full   = f"{parsed.scheme}://{parsed.netloc}{path}"
                    found.add(full)
                except Exception:
                    pass
            elif path.startswith("http"):
                found.add(path)
    return list(found)[:500]


def extract_js_secrets(content: str, source_url: str) -> List[Dict]:
    """Extract secrets and sensitive config from JS content."""
    findings: List[Dict] = []
    for pat, secret_type, impact in _JS_SECRET_PATS:
        for m in pat.findall(content):
            val = m if isinstance(m, str) else (m[0] if m else "")
            if len(val) < 6:
                continue
            # Basic entropy check — skip obvious placeholders
            if val in ("YOUR_KEY_HERE","REPLACE_ME","undefined","null","true","false"):
                continue
            findings.append({
                "secret_type":       secret_type,
                "source_url":        source_url,
                "value_preview":     val[:20] + ("..." if len(val) > 20 else ""),
                "impact":            impact,
                "confidence":        "medium",
                "needs_validation":  True,
                "hash":              hashlib.sha256(val.encode()).hexdigest()[:8],
            })
    return findings[:10]  # cap per-file to avoid noise


def discover_hidden(host: str, fetch_fn) -> Dict:
    """
    Discover hidden endpoints from standard discovery paths.
    fetch_fn(url, timeout) → (status, headers, body) or None
    """
    DISCOVERY_PATHS = [
        "/robots.txt",
        "/sitemap.xml",
        "/swagger.json",
        "/swagger/v1/swagger.json",
        "/api/swagger.json",
        "/openapi.json",
        "/api/openapi.json",
        "/v3/api-docs",
        "/api-docs",
        "/api/docs",
        "/graphql",
        "/.well-known/openid-configuration",
        "/.well-known/jwks.json",
        "/api/graphql",
        "/graphiql",
        "/api/schema",
        "/schema.json",
    ]
    found_endpoints: List[str] = []
    sources: Dict[str, int]    = {}
    secrets: List[Dict]        = []
    host_base = host.rstrip("/")

    for path in DISCOVERY_PATHS:
        url = host_base + path
        try:
            r = fetch_fn(url, 8)
            if not r or r[0] not in (200, 401, 403):
                continue
            body = r[2] or ""

            # Swagger / OpenAPI — extract paths
            if "swagger" in path or "openapi" in path or "api-docs" in path or "schema" in path:
                try:
                    doc = json.loads(body)
                    paths = list(doc.get("paths", {}).keys()) + \
                            [s.get("url","") for s in doc.get("servers",[])]
                    for p in paths[:200]:
                        if p:
                            found_endpoints.append(host_base + p if p.startswith("/") else p)
                    sources["swagger"] = sources.get("swagger",0) + len(paths)
                    log.info(f"[hidden] source=swagger host={host_base} endpoints={len(paths)}")
                except Exception:
                    pass

            # robots.txt — extract disallowed paths
            elif "robots.txt" in path:
                for line in body.splitlines():
                    if line.lower().startswith(("disallow:","allow:")):
                        p = line.split(":",1)[1].strip()
                        if p and p != "/":
                            found_endpoints.append(host_base + p)
                            sources["robots"] = sources.get("robots",0) + 1

            # sitemap.xml — extract URLs
            elif "sitemap" in path:
                locs = re.findall(r"<loc>(.*?)</loc>", body)
                for loc in locs[:100]:
                    found_endpoints.append(loc)
                sources["sitemap"] = sources.get("sitemap",0) + len(locs)

            # GraphQL — mark as found
            elif "graphql" in path.lower() or "graphiql" in path.lower():
                found_endpoints.append(url)
                sources["graphql"] = sources.get("graphql",0) + 1
                log.info(f"[hidden] source=graphql host={host_base} url={url}")

            # OpenID / JWKS
            elif "well-known" in path:
                try:
                    doc = json.loads(body)
                    for key in ("authorization_endpoint","token_endpoint",
                                "userinfo_endpoint","revocation_endpoint"):
                        ep = doc.get(key,"")
                        if ep:
                            found_endpoints.append(ep)
                            sources["oidc"] = sources.get("oidc",0) + 1
                except Exception:
                    pass

        except Exception as e:
            log.debug(f"[hidden] {url}: {e}")

    return {
        "host":       host_base,
        "endpoints":  list(set(found_endpoints)),
        "sources":    sources,
        "secrets":    secrets,
        "count":      len(found_endpoints),
    }


# ── GraphQL / Swagger intelligence ────────────────────────────────────────────

def parse_swagger(content: str, base_url: str) -> Dict:
    """Parse Swagger/OpenAPI JSON and extract endpoints + auth info."""
    try:
        doc = json.loads(content)
    except Exception:
        return {}

    endpoints: List[Dict] = []
    objects: set = set()

    for path, methods in doc.get("paths", {}).items():
        for method, op in (methods.items() if isinstance(methods, dict) else []):
            if method.lower() in ("get","post","put","patch","delete","head","options"):
                auth_required = bool(
                    op.get("security") or
                    any("auth" in str(p.get("name","")).lower()
                        for p in op.get("parameters",[]))
                )
                ep_info = classify_url(base_url + path)
                endpoints.append({
                    "path":          path,
                    "method":        method.upper(),
                    "summary":       op.get("summary","")[:100],
                    "auth_required": auth_required,
                    "surfaces":      ep_info["surfaces"],
                    "score":         ep_info["score"],
                    "tags":          op.get("tags",[]),
                })
                # Extract object names from path
                for seg in path.split("/"):
                    if seg and not seg.startswith("{") and len(seg) > 2:
                        objects.add(seg.lower())

    endpoints.sort(key=lambda x: -x["score"])
    return {
        "version": doc.get("openapi", doc.get("swagger","")),
        "title":   doc.get("info",{}).get("title",""),
        "servers": [s.get("url","") for s in doc.get("servers",[])],
        "endpoints": endpoints[:200],
        "objects":   sorted(objects),
        "auth_required_count": sum(1 for e in endpoints if e["auth_required"]),
    }


def parse_graphql_schema(content: str) -> Dict:
    """Extract types and operations from GraphQL introspection response."""
    try:
        raw = json.loads(content)
        schema = raw.get("data",{}).get("__schema", raw.get("__schema",{}))
        if not schema:
            return {}
        types: List[str] = []
        queries:  List[str] = []
        mutations: List[str] = []
        for t in schema.get("types",[]):
            name = t.get("name","")
            if name.startswith("__"): continue
            if t.get("kind") == "OBJECT":
                types.append(name)
                for f in t.get("fields",[]) or []:
                    fname = f.get("name","")
                    if t.get("name","") == "Query":
                        queries.append(fname)
                    elif t.get("name","") == "Mutation":
                        mutations.append(fname)
        return {
            "types":     types[:50],
            "queries":   queries[:50],
            "mutations": mutations[:50],
            "has_mutations": bool(mutations),
        }
    except Exception:
        return {}


# ── API chain detection ────────────────────────────────────────────────────────


# ── ID segment detection — matches real-world API IDs ─────────────────────────
_ID_SEG = re.compile(
    r"^("
    r"\{[^}]+\}"                                        # {param}
    r"|:\w+"                                            # :param
    r"|<[^>]+>"                                         # <param>
    r"|\d{1,20}"                                        # numeric: 1, 123, 99999
    r"|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-"           # UUID
    r"[0-9a-f]{4}-[0-9a-f]{12}"
    r"|[a-zA-Z0-9]{20,}"                                # long opaque token
    r"|[a-zA-Z]+-\d+"                                   # prefixed: proj-123, team-456
    r"|[a-zA-Z0-9_]+-[a-zA-Z0-9_-]{6,}"                # slug-hash: post-a1b2c3d4
    r"|[a-z]{2,10}\d{3,}"                               # acct789, proj456, inv001
    r")$"
)

# Known REST resource names — always recognised even without an explicit ID seg
_KNOWN_OBJECTS = {
    "user","users","account","accounts","team","teams","org","orgs",
    "organization","organizations","project","projects","order","orders",
    "invoice","invoices","billing","payment","payments","file","files",
    "document","documents","workspace","workspaces","member","members",
    "role","roles","permission","permissions","resource","resources",
    "subscription","subscriptions","plan","plans","webhook","webhooks",
    "token","tokens","key","keys","repo","repos","repository","repositories",
    "issue","issues","deployment","deployments","secret","secrets",
}


def detect_api_chains(endpoints: List[str]) -> Dict:
    """
    Group REST endpoints by object model and detect IDOR/BOLA candidates.

    Two complementary strategies:
    1. Template normalisation — replace concrete IDs with {id} and group
       URLs that share the same template.  Multiple URLs → same template = IDOR.
    2. Known-object matching — even without an ID segment, group URLs that
       contain known resource names so BOLA tests can be generated.
    """
    by_object:  Dict[str, set]       = {}   # obj_name  → {urls}
    templates:  Dict[str, List[str]] = {}   # /v1/users/{id} → [concrete urls]

    def _normalize(path: str) -> Tuple[str, List[str]]:
        segs = path.rstrip("/").split("/")
        tpl, ids = [], []
        for seg in segs:
            if seg and _ID_SEG.match(seg):
                tpl.append("{id}")
                ids.append(seg)
            else:
                tpl.append(seg)
        return "/".join(tpl), ids

    for url in endpoints:
        try:
            path = urlparse(url).path.rstrip("/") or "/"
            segs = [s for s in path.split("/") if s]
        except Exception:
            continue

        # Strategy 1: known object names
        for i, seg in enumerate(segs):
            seg_l = seg.lower()
            if seg_l in _KNOWN_OBJECTS:
                by_object.setdefault(seg_l, set()).add(url)
            # Segment before an ID segment → resource name
            if i + 1 < len(segs) and _ID_SEG.match(segs[i + 1]):
                obj = seg_l.rstrip("s") if seg_l.endswith("s") else seg_l
                by_object.setdefault(obj, set()).add(url)

        # Strategy 2: template normalisation
        tpl, ids = _normalize(path)
        if "{id}" in tpl:
            templates.setdefault(tpl, [])
            if url not in templates[tpl]:
                templates[tpl].append(url)

    # Build candidate chains
    candidate_chains: List[Dict] = []
    seen_objects: set = set()

    # From templates with multiple concrete URLs (strongest IDOR signal)
    for tpl, urls in templates.items():
        if len(urls) < 2:
            continue
        tpl_segs = [s for s in tpl.split("/") if s]
        obj = next(
            (s.rstrip("s") for s in tpl_segs
             if s != "{id}" and not s.startswith("v") and not s.isdigit()),
            "resource"
        )
        seen_objects.add(obj)
        bugs = ["IDOR/BOLA"]
        id_parts = tpl.split("/")
        id_idx   = id_parts.index("{id}") if "{id}" in id_parts else -1
        if id_idx >= 0 and len(id_parts) > id_idx + 1:
            bugs.append("Broken Object Property Level Auth")
        candidate_chains.append({
            "object":         obj,
            "template":       tpl,
            "endpoints":      urls[:6],
            "endpoint_count": len(urls),
            "risk":           "high",
            "likely_bugs":    bugs,
            "test_note":      f"Swap the ID in '{tpl}' with another user's resource ID",
        })

    # From known-object groupings without explicit ID match
    for obj, url_set in by_object.items():
        urls = list(url_set)
        if len(urls) >= 2 and obj not in seen_objects:
            url_str = " ".join(urls).lower()
            bugs = ["IDOR/BOLA"]
            if any(w in url_str for w in ["/role","/admin","/permission","?role=","?admin="]):
                bugs.append("Broken Function-Level Auth")
            if any(w in url_str for w in ["/billing","/invoice","/payment","/subscription"]):
                bugs.append("IDOR on Billing Object")
            candidate_chains.append({
                "object":         obj,
                "template":       f"/{obj}/{{id}}",
                "endpoints":      urls[:6],
                "endpoint_count": len(urls),
                "risk":           "high" if len(urls) >= 3 else "medium",
                "likely_bugs":    bugs,
                "test_note":      f"Test horizontal access across different {obj} IDs",
            })

    candidate_chains.sort(key=lambda x: -x["endpoint_count"])

    # High-risk test objects — infer bug class from URL content
    high_risk: List[Dict] = []
    for obj, url_set in sorted(by_object.items(), key=lambda x: -len(x[1])):
        urls    = list(url_set)
        url_str = " ".join(urls).lower()
        bugs: List[str] = []
        if len(urls) >= 2:
            bugs.append("IDOR/BOLA")
        if any(w in url_str for w in ["create","new","add","update","patch"]):
            bugs.append("Mass Assignment")
        if any(w in url_str for w in ["role","permission","admin"]):
            bugs.append("Broken Func-Level Auth")
        if any(w in url_str for w in ["file","document","download","attachment"]):
            bugs.append("File Access Control")
        if any(w in url_str for w in ["billing","invoice","payment","subscription"]):
            bugs.append("Billing IDOR")
        if any(w in url_str for w in ["team","org","workspace","tenant"]):
            bugs.append("Tenant Isolation")
        if bugs:
            high_risk.append({
                "object":         obj,
                "endpoint_count": len(urls),
                "likely_bugs":    bugs,
                "sample_urls":    urls[:3],
                "risk":           "high" if len(bugs) >= 2 else "medium",
            })

    high_risk.sort(key=lambda x: -x["endpoint_count"])

    return {
        "objects":           {k: list(v)[:5] for k, v in list(by_object.items())[:30]},
        "candidate_chains":  candidate_chains[:30],
        "high_risk_tests":   high_risk[:20],
        "total_objects":     len(by_object),
        "total_candidates":  len(candidate_chains),
    }


# ── Test plan generator ───────────────────────────────────────────────────────

BOUNTY_VALUE = {
    "payment": "high", "api": "high", "auth": "high", "admin": "high",
    "graphql": "high", "swagger": "medium", "webhook": "high",
    "upload": "medium", "cloud": "medium", "oauth_cb": "high",
    "internal": "medium", "debug": "low",
}

# Safe test plan templates — one entry per bug class
_PLAN_TEMPLATES = [
    {
        "type":     "IDOR/BOLA",
        "surfaces": ["api"],
        "trigger":  lambda u: bool(re.search(r"/\d{1,12}|/[a-z]{2,8}\d{3,}|/[a-z]+-\d+", u, re.I)),
        "steps": [
            "1. Authenticate as User A, note the resource ID in the URL",
            "2. Log in as User B (different account / incognito)",
            "3. Replace User A's resource ID in the request with User B's ID",
            "4. Observe if User A's data is returned to User B",
            "5. Repeat with PUT/PATCH/DELETE to test write access",
        ],
        "impact": "Unauthorized access to another user's data / account takeover",
    },
    {
        "type":     "Horizontal Privilege Escalation",
        "surfaces": ["auth","admin"],
        "trigger":  lambda u: bool(re.search(r"/(me|profile|account|settings|user)", u, re.I)),
        "steps": [
            "1. Authenticate as a low-privilege user",
            "2. Retrieve /me or /profile to get your account object IDs",
            "3. Try accessing /users/{other_id} or /accounts/{other_id}",
            "4. Check if you receive another user's data without a 403",
        ],
        "impact": "Cross-account data exposure",
    },
    {
        "type":     "Broken Function-Level Authorization",
        "surfaces": ["admin"],
        "trigger":  lambda u: bool(re.search(r"/(admin|role|permission|manage)", u, re.I)),
        "steps": [
            "1. Authenticate as a regular (non-admin) user",
            "2. Call the admin endpoint directly with your session token",
            "3. Try HTTP verb tampering: GET → POST → PUT on the same path",
            "4. Check if role enforcement is applied server-side",
        ],
        "impact": "Privilege escalation to admin functionality",
    },
    {
        "type":     "OAuth Redirect / Token Theft",
        "surfaces": ["oauth_cb","auth"],
        "trigger":  lambda u: bool(re.search(r"(callback|redirect_uri|return_url|oauth|sso)", u, re.I)),
        "steps": [
            "1. Find the OAuth /authorize endpoint",
            "2. Check if redirect_uri is validated strictly (exact match vs prefix/wildcard)",
            "3. Modify redirect_uri to https://attacker.com",
            "4. Observe whether the authorization code is sent to the external URI",
            "5. Test state parameter bypass (CSRF on OAuth flow)",
        ],
        "impact": "OAuth token theft / account takeover via open redirect",
    },
    {
        "type":     "GraphQL Introspection / Info Disclosure",
        "surfaces": ["graphql"],
        "trigger":  lambda u: bool(re.search(r"(graphql|graphiql|gql)", u, re.I)),
        "steps": [
            "1. POST {\"query\":\"{__schema{types{name}}}\"} to the GraphQL endpoint",
            "2. If introspection is open: enumerate all types, queries, mutations",
            "3. Test a depth-10 nested query for batching DoS",
            "4. Look for mutations that accept admin-level arguments without auth",
        ],
        "impact": "Full schema enumeration, sensitive data exposure, batching DoS",
    },
    {
        "type":     "Swagger/OpenAPI Exposure",
        "surfaces": ["swagger"],
        "trigger":  lambda u: bool(re.search(r"(swagger|openapi|api-docs|redoc)", u, re.I)),
        "steps": [
            "1. Access the Swagger endpoint without authentication",
            "2. Enumerate all listed paths, especially /admin and /internal",
            "3. Use the spec to call auth-required endpoints with no token",
            "4. Check for internal server names or credentials in example values",
        ],
        "impact": "Full API enumeration, unauthenticated access via documented endpoints",
    },
    {
        "type":     "File Upload Abuse",
        "surfaces": ["upload"],
        "trigger":  lambda u: bool(re.search(r"(upload|import|file|attachment)", u, re.I)),
        "steps": [
            "1. Upload a polyglot file (e.g. shell.php.jpg)",
            "2. Change Content-Type to text/html while keeping .jpg extension",
            "3. Test path traversal in filename: ../../../etc/passwd",
            "4. Check if uploaded files are served from the same origin (stored XSS risk)",
            "5. Verify file size limits (DoS via large upload)",
        ],
        "impact": "RCE via file upload, path traversal, stored XSS, DoS",
    },
    {
        "type":     "SSRF via Webhook/Callback",
        "surfaces": ["webhook"],
        "trigger":  lambda u: bool(re.search(r"(webhook|callback|notify|hook|subscribe|event)", u, re.I)),
        "steps": [
            "1. Register a webhook pointing to http://169.254.169.254/latest/meta-data/",
            "2. Try http://localhost:8080 and http://internal-service/",
            "3. Use a Burp Collaborator URL to detect blind SSRF",
            "4. Check if HTTP redirects are followed (SSRF bypass via redirect)",
        ],
        "impact": "SSRF → cloud metadata exfiltration, internal network access",
    },
    {
        "type":     "Mass Assignment",
        "surfaces": ["api"],
        "trigger":  lambda u: bool(re.search(r"(create|register|update|/new)", u, re.I)),
        "steps": [
            "1. Call a create/update endpoint with only the documented fields",
            "2. Inject undocumented fields: role, admin, isVerified, plan, credits",
            "3. Verify whether the server reflects or persists the injected value",
            "4. Try JSON expansion: {\"user\": {\"role\": \"admin\"}}",
        ],
        "impact": "Privilege escalation via parameter pollution",
    },
    {
        "type":     "Tenant Isolation / Cross-Tenant Access",
        "surfaces": ["api","admin"],
        "trigger":  lambda u: bool(re.search(r"(org|team|tenant|workspace|account)", u, re.I)),
        "steps": [
            "1. Authenticate to Tenant A, note your org_id / team_id",
            "2. Replace your tenant ID with Tenant B's ID in API calls",
            "3. Check if the server validates tenant ownership",
            "4. Test nested resources: /orgs/{B_id}/projects, /teams/{B_id}/members",
        ],
        "impact": "Cross-tenant data leakage, multi-tenancy isolation bypass",
    },
    {
        "type":     "Billing / Pricing Manipulation",
        "surfaces": ["payment"],
        "trigger":  lambda u: bool(re.search(r"(payment|billing|invoice|checkout|subscribe|plan|price|coupon)", u, re.I)),
        "steps": [
            "1. Start a checkout, intercept the request in a proxy",
            "2. Modify price/amount/quantity to 0 or a negative value",
            "3. Verify if the server re-validates price from its own DB",
            "4. Test coupon stacking by submitting two coupon codes",
            "5. Try IDOR on /invoices/{other_id} with your token",
        ],
        "impact": "Free/discounted access, financial data IDOR, billing bypass",
    },
]


def generate_test_plan(
    domain: str,
    surface_map: Dict,
    api_chains: Dict,
    swagger_docs: List[Dict] = None,
) -> Dict:
    """
    Safe, triager-friendly test plan.
    No auto-exploitation — all steps are manually executed by a human researcher.
    """
    swagger_docs = swagger_docs or []
    top_targets:  List[Dict] = []
    plans:        List[Dict] = []
    max_bounty = "low"
    used_types:   set = set()

    hv_eps = surface_map.get("high_value_endpoints", [])

    # Build top targets
    for ep in hv_eps[:100]:
        url   = ep["url"]
        surfs = ep.get("surfaces", [])
        score = ep.get("score", 1)
        bugs: List[str] = []
        bval = "low"
        for s in surfs:
            v = BOUNTY_VALUE.get(s, "low")
            if {"low":0,"medium":1,"high":2}.get(v,0) > {"low":0,"medium":1,"high":2}.get(bval,0):
                bval = v
        if "auth"     in surfs: bugs += ["Auth Bypass","Password Reset Flaw","Session Fixation"]
        if "admin"    in surfs: bugs += ["Broken Access Control","Admin Exposure"]
        if "api"      in surfs: bugs += ["IDOR","BOLA","Mass Assignment","Rate Limit Bypass"]
        if "upload"   in surfs: bugs += ["Unrestricted Upload","Path Traversal","Stored XSS"]
        if "graphql"  in surfs: bugs += ["GraphQL Introspection","Batching DoS","Schema Leak"]
        if "webhook"  in surfs: bugs += ["SSRF","Webhook Forgery","CSRF"]
        if "oauth_cb" in surfs: bugs += ["Open Redirect","OAuth Token Theft","State Bypass"]
        if "payment"  in surfs: bugs += ["Price Manipulation","Billing IDOR","Coupon Bypass"]
        if "swagger"  in surfs: bugs += ["API Enumeration","Unauthenticated Endpoint"]
        if ep.get("access_control_candidate"): bugs += ["Horizontal Priv Esc","Vertical Priv Esc"]
        if bugs:
            top_targets.append({
                "url":          url, "surfaces": surfs, "score": score,
                "likely_bugs":  list(dict.fromkeys(bugs))[:5],
                "bounty_value": bval, "safe_test": True, "auto_exploit": False,
            })
            if {"low":0,"medium":1,"high":2}.get(bval,0) > {"low":0,"medium":1,"high":2}.get(max_bounty,0):
                max_bounty = bval

    # Match plan templates to actual endpoints
    for tmpl in _PLAN_TEMPLATES:
        matching = [ep["url"] for ep in hv_eps
                    if any(s in ep.get("surfaces",[]) for s in tmpl["surfaces"])
                    and tmpl["trigger"](ep["url"])]
        # Also pull chain endpoints for IDOR / mass-assign / tenant plans
        if "IDOR" in tmpl["type"] or "Mass" in tmpl["type"] or "Tenant" in tmpl["type"]:
            for ch in api_chains.get("candidate_chains",[]):
                matching.extend(ch.get("endpoints",[]))
        matching = list(dict.fromkeys(matching))[:5]

        if matching and tmpl["type"] not in used_types:
            used_types.add(tmpl["type"])
            plans.append({
                "type":            tmpl["type"],
                "targets":         matching,
                "target_count":    len(matching),
                "test_steps":      tmpl["steps"],
                "safe":            True,
                "auto_exploit":    False,
                "expected_impact": tmpl["impact"],
            })

    # One plan per API chain (IDOR-specific, object-level)
    for chain in api_chains.get("candidate_chains", [])[:5]:
        plan_type = f"IDOR — /{chain['object']}"
        if plan_type not in used_types:
            used_types.add(plan_type)
            plans.append({
                "type":        plan_type,
                "targets":     chain["endpoints"][:3],
                "target_count": chain["endpoint_count"],
                "test_steps": [
                    f"1. Authenticate as User A, GET {chain['template']}",
                    "2. Note the resource ID",
                    "3. Authenticate as User B",
                    f"4. Replace User A's ID in {chain['template']}",
                    "5. Check if User A's resource is returned to User B",
                    "6. Test write access: PUT/PATCH/DELETE with swapped ID",
                ],
                "safe": True, "auto_exploit": False,
                "expected_impact": f"Unauthorized {chain['object']} access across account boundaries",
                "note": chain.get("test_note",""),
            })

    top_targets.sort(key=lambda x: -x["score"])

    return {
        "domain":                domain,
        "top_10_targets":        top_targets[:10],
        "test_plans":            plans,
        "test_plan_count":       len(plans),
        "expected_bounty_value": max_bounty,
        "total_high_value":      len(top_targets),
        "generated_at":          int(time.time()),
        "note": (
            "All plans are safe for manual execution by a human researcher. "
            "No auto-exploitation. Human approval required before any submission."
        ),
    }
