"""
engine/elite_recon_v2.py — Ultimate Recon Engine v2

Param-level target scoring, per-endpoint test plan generation,
API chain detection with template normalisation, hidden endpoint expansion,
and signal routing.

Wraps / extends surface_intel.py (v1) with:
  - score_endpoint()     — param-level scoring (+5 id/user, +4 auth, …)
  - classify_endpoint()  — surface tag list for one URL
  - detect_chains_v2()   — richer chain detection with bug-class inference
  - expand_hidden()      — param variation expansion
  - generate_test_plan() — per-endpoint safe test plan
  - route_target()       — full_scan / targeted_scan / passive_only
  - analyse_domain()     — full v2 intelligence pass

HARD RULES:
  - No auto-exploitation
  - No auto-submission
  - No fabricated results
  - Safe test plans only — human approval required before any action
"""

import re
import time
import logging
from typing import Dict, List, Optional, Tuple
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

log = logging.getLogger("elite.recon_v2")

# ── Param-level scoring rules ─────────────────────────────────────────────────
# Each rule: (bonus, match_function)
# Applied to: path segments + query param names + query param values

_PARAM_RULES: List[Tuple[int, re.Pattern]] = [
    # +5 — identity / ownership params (highest IDOR signal)
    (5, re.compile(
        r"\b(id|user_?id|account_?id|profile_?id|member_?id|"
        r"owner_?id|customer_?id|uid|userid|uuid|guid|pid|cid)\b", re.I)),
    # +4 — auth / session params
    (4, re.compile(
        r"\b(token|auth|login|oauth|session|password|passwd|"
        r"api_?key|apikey|secret|credential|access_?token|"
        r"refresh_?token|jwt|bearer|sso|saml|oidc)\b", re.I)),
    # +3 — API / GraphQL params
    (3, re.compile(
        r"\b(query|mutation|graphql|schema|operation|variables|"
        r"fields|include|expand|embed|select|filter|format|"
        r"version|v\d+|api)\b", re.I)),
    # +3 — admin / privileged params
    (3, re.compile(
        r"\b(admin|role|permission|privilege|sudo|superuser|"
        r"dashboard|manage|console|panel|backoffice)\b", re.I)),
    # +2 — upload / file params
    (2, re.compile(
        r"\b(file|upload|import|attachment|document|media|"
        r"image|avatar|logo|blob|binary|content|data|payload)\b", re.I)),
    # +2 — webhook / callback params
    (2, re.compile(
        r"\b(webhook|callback|redirect|redirect_?uri|"
        r"return_?url|next|dest|goto|url|endpoint|notify)\b", re.I)),
    # +1 — generic object params (low signal but still useful)
    (1, re.compile(
        r"\b(name|email|username|handle|slug|key|ref|"
        r"resource|object|entity|item|record|entry)\b", re.I)),
]

# Surface tag patterns (applied to full URL)
_SURFACE_PATTERNS: List[Tuple[str, re.Pattern]] = [
    ("payment",  re.compile(r"(payment|billing|invoice|stripe|checkout|subscribe|cart|order|transaction)", re.I)),
    ("api",      re.compile(r"(/api/|/v\d+/|/rest/|\.json$|/json$|/rpc/)", re.I)),
    ("graphql",  re.compile(r"(graphql|graphiql|gql|graph/query)", re.I)),
    ("auth",     re.compile(r"(login|signin|auth|oauth|oidc|saml|sso|token|session|logout|register|password|2fa|mfa)", re.I)),
    ("admin",    re.compile(r"(admin|administrator|manage|management|dashboard|console|panel|backoffice)", re.I)),
    ("upload",   re.compile(r"(upload|import|file|attachment|document|media|image|avatar|blob|binary)", re.I)),
    ("webhook",  re.compile(r"(webhook|callback|notify|hook|event|trigger|subscribe)", re.I)),
    ("swagger",  re.compile(r"(swagger|openapi|api-docs|api/docs|redoc|v3/api-docs)", re.I)),
    ("cloud",    re.compile(r"(s3|bucket|blob|storage|gcs|azure|cloudfront|lambda)", re.I)),
    ("internal", re.compile(r"(internal|corp|intranet|staging|preprod|sandbox|uat\.)", re.I)),
    ("debug",    re.compile(r"(debug|health|ping|metrics|actuator|\.env|\.git|config\.|phpinfo)", re.I)),
    ("oauth_cb", re.compile(r"(callback|redirect_uri|return_url|next=|redirect=|goto=)", re.I)),
]

# ID segment pattern (for template normalisation)
_ID_SEG = re.compile(
    r"^(\{[^}]+\}|:\w+|<[^>]+>|\d{1,20}"
    r"|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
    r"|[a-zA-Z0-9]{20,}|[a-zA-Z]+-\d+|[a-zA-Z0-9_]+-[a-zA-Z0-9_-]{6,}"
    r"|[a-z]{2,10}\d{3,})$"
)

# Known param expansions for hidden endpoint discovery
_PARAM_EXPANSIONS: Dict[str, List[str]] = {
    # Snake_case and camelCase both covered
    "id":          ["user_id", "account_id", "profile_id", "member_id", "customer_id", "uid", "pid"],
    "userid":      ["id", "user_id", "account_id", "uid"],
    "user_id":     ["id", "account_id", "profile_id", "uid"],
    "teamid":      ["team_id", "org_id", "account_id"],
    "team_id":     ["teamId", "org_id", "account_id"],
    "account_id":  ["id", "user_id", "org_id", "tenant_id"],
    "accountid":   ["account_id", "user_id", "org_id"],
    "token":       ["access_token", "refresh_token", "api_key", "auth_token", "bearer"],
    "file":        ["filename", "path", "filepath", "attachment", "document", "media"],
    "url":         ["redirect_uri", "return_url", "callback_url", "next", "dest", "goto"],
    "role":        ["permission", "privilege", "access_level", "scope"],
    "name":        ["username", "handle", "email", "slug"],
    "q":           ["query", "search", "filter", "keyword"],
    "page":        ["offset", "skip", "from", "start"],
    "format":      ["output", "type", "content_type", "response_type"],
    # camelCase common in modern APIs
    "userid":      ["accountId", "profileId", "memberId"],
    "teamid":      ["orgId", "workspaceId", "accountId"],
    "projectid":   ["project_id", "repoId", "deploymentId"],
    "callback":    ["redirect_uri", "return_url", "next", "dest"],
}

# Per-surface safe test plan templates
_TEST_TEMPLATES: Dict[str, Dict] = {
    "idor": {
        "type":    "IDOR / BOLA",
        "risk":    "high",
        "surfaces": ["api", "payment", "auth"],
        "steps": [
            "1. Authenticate as User A — note the resource ID in the URL",
            "2. Authenticate as User B (separate account)",
            "3. Replace User A's ID with User B's ID in the request",
            "4. Check if User A's data is returned to User B",
            "5. Repeat with PUT / PATCH / DELETE for write IDOR",
        ],
        "expected":     "Cross-account data access / modification",
        "auto_exploit": False,
    },
    "auth_bypass": {
        "type":    "Auth Bypass",
        "risk":    "high",
        "surfaces": ["auth", "admin"],
        "steps": [
            "1. Send the request without any Authorization header",
            "2. Try with an expired / invalid JWT",
            "3. Try with a regular-user token on an admin endpoint",
            "4. Try HTTP verb tampering: GET → POST → PUT",
            "5. Check if the server enforces auth server-side",
        ],
        "expected":     "Unauthenticated access / privilege escalation",
        "auto_exploit": False,
    },
    "ssrf": {
        "type":    "SSRF via Webhook / URL Param",
        "risk":    "high",
        "surfaces": ["webhook", "upload", "api"],
        "steps": [
            "1. Find URL / callback parameters in the request",
            "2. Register a webhook pointing to http://169.254.169.254/",
            "3. Try http://localhost:8080 and http://internal-host/",
            "4. Use Burp Collaborator / interactsh to detect blind SSRF",
            "5. If DNS hit observed, attempt cloud metadata path",
        ],
        "expected":     "SSRF → internal network / cloud metadata access",
        "auto_exploit": False,
    },
    "upload_abuse": {
        "type":    "File Upload Abuse",
        "risk":    "high",
        "surfaces": ["upload"],
        "steps": [
            "1. Upload a file with a double extension: shell.php.jpg",
            "2. Change Content-Type to text/html while keeping .jpg extension",
            "3. Test path traversal in filename: ../../../../etc/passwd",
            "4. Check if uploaded file is served from the same origin (stored XSS)",
            "5. Test file size limit (DoS via oversized upload)",
        ],
        "expected":     "RCE via upload / path traversal / stored XSS",
        "auto_exploit": False,
    },
    "graphql": {
        "type":    "GraphQL Introspection / Schema Leak",
        "risk":    "medium",
        "surfaces": ["graphql"],
        "steps": [
            '1. POST {"query":"{__schema{types{name}}}"} to the endpoint',
            "2. If introspection open: enumerate all types, queries, mutations",
            "3. Test depth-10 nested query for batching DoS",
            "4. Find mutations that accept IDs — test for IDOR",
            "5. Check if auth is enforced per-operation or only at entry",
        ],
        "expected":     "Schema enumeration / IDOR via mutation / batching DoS",
        "auto_exploit": False,
    },
    "oauth_redirect": {
        "type":    "OAuth Open Redirect / Token Theft",
        "risk":    "high",
        "surfaces": ["oauth_cb", "auth"],
        "steps": [
            "1. Find the OAuth /authorize endpoint",
            "2. Check if redirect_uri is validated strictly (exact vs prefix/wildcard)",
            "3. Modify redirect_uri to https://attacker.example.com",
            "4. Check if the auth code is sent to the modified URI",
            "5. Test state parameter bypass (CSRF on OAuth flow)",
        ],
        "expected":     "Account takeover via OAuth token theft",
        "auto_exploit": False,
    },
    "mass_assignment": {
        "type":    "Mass Assignment",
        "risk":    "medium",
        "surfaces": ["api"],
        "steps": [
            "1. Call a create / update endpoint with only documented fields",
            "2. Add undocumented fields: role, admin, isVerified, plan, credits",
            "3. Check if the server reflects or persists the injected value",
            '4. Try JSON key expansion: {"user": {"role": "admin"}}',
            "5. Test with nested / aliased field names",
        ],
        "expected":     "Privilege escalation via parameter pollution",
        "auto_exploit": False,
    },
    "bola": {
        "type":    "BOLA — Broken Object-Level Authorization",
        "risk":    "high",
        "surfaces": ["api", "admin"],
        "steps": [
            "1. Identify all endpoints that accept a resource ID",
            "2. Authenticate as User A — collect IDs of A's resources",
            "3. Authenticate as User B — call A's resource endpoints with A's IDs",
            "4. Check for 200 responses that expose A's data to B",
            "5. Test sub-resources: /users/{A_id}/files, /orgs/{A_id}/members",
        ],
        "expected":     "Unauthorized access to another tenant's objects",
        "auto_exploit": False,
    },
}


# ── 1. TARGET SCORING ─────────────────────────────────────────────────────────

def score_endpoint(url: str) -> int:
    """
    Param-level scoring for a single endpoint URL.
    Checks path segments, query parameter names, and query parameter values.
    Returns int 1–10.

    Scoring:
      +5  id / user / account param
      +4  auth / login / oauth
      +3  api / graphql
      +3  admin / dashboard
      +2  upload / webhook
      +1  generic object param
    """
    try:
        parsed = urlparse(url)
        path   = parsed.path.lower()
        qs     = parse_qs(parsed.query)
        # All scoreable tokens: path segments + param names + param values
        tokens = (
            path.replace("/", " ").replace("-", " ").replace("_", " ")
            + " "
            + " ".join(qs.keys())
            + " "
            + " ".join(v for vals in qs.values() for v in vals)
        )
    except Exception:
        tokens = url.lower()

    score = 0
    for bonus, pat in _PARAM_RULES:
        if pat.search(tokens):
            score += bonus
            # Only count each rule once per URL
    return min(10, max(1, score))


# ── 2. SURFACE CLASSIFICATION ─────────────────────────────────────────────────

def classify_endpoint(url: str) -> List[str]:
    """
    Return a list of surface tags for a single URL.
    E.g. ["api", "auth", "admin"]
    """
    tags: List[str] = []
    for tag, pat in _SURFACE_PATTERNS:
        if pat.search(url):
            tags.append(tag)
    return tags or ["generic"]


# ── 3. API CHAIN DETECTION ────────────────────────────────────────────────────

def _normalise_path(path: str) -> str:
    """Replace concrete ID segments with {id}."""
    segs = path.rstrip("/").split("/")
    return "/".join("{id}" if s and _ID_SEG.match(s) else s for s in segs)


def detect_chains_v2(endpoints: List[str]) -> Dict:
    """
    Group endpoints by normalised path template.
    Return IDOR / BOLA / auth-bypass candidates with concrete examples.

    Returns:
      {
        "templates":  { "/v1/users/{id}": [...urls...] },
        "candidates": [ { object, template, endpoints, bug_classes, risk } ],
        "total":      N
      }
    """
    templates: Dict[str, List[str]] = {}

    for url in endpoints:
        try:
            path = urlparse(url).path
        except Exception:
            continue
        tpl = _normalise_path(path)
        if "{id}" in tpl:
            templates.setdefault(tpl, [])
            if url not in templates[tpl]:
                templates[tpl].append(url)

    candidates: List[Dict] = []
    for tpl, urls in templates.items():
        # Extract the last non-{id} segment as the object name
        segs = [s for s in tpl.split("/") if s and s != "{id}"]
        obj  = segs[-1].rstrip("s") if segs else "resource"

        bug_classes: List[str] = ["IDOR"]
        url_str = " ".join(urls).lower()
        if any(w in url_str for w in ["/role", "/permission", "/admin"]):
            bug_classes.append("Broken Function-Level Auth")
        if any(w in url_str for w in ["/billing", "/invoice", "/payment"]):
            bug_classes.append("IDOR on Billing Object")
        if len(segs) >= 3:
            # /objects/{id}/sub-resource — property-level BOLA
            bug_classes.append("BOLA")

        risk = "high" if len(urls) >= 2 else "medium"
        candidates.append({
            "object":       obj,
            "template":     tpl,
            "endpoints":    urls[:6],
            "endpoint_count": len(urls),
            "bug_classes":  bug_classes,
            "risk":         risk,
            "test_note":    f"Swap the concrete ID in '{tpl}' with another user's resource ID",
            "auto_exploit": False,
        })

    candidates.sort(key=lambda x: (-len(x["bug_classes"]), -x["endpoint_count"]))
    return {
        "templates":  {k: v[:5] for k, v in templates.items()},
        "candidates": candidates[:30],
        "total":      len(candidates),
    }


# ── 4. HIDDEN ENDPOINT EXPANSION ─────────────────────────────────────────────

def expand_hidden(url: str) -> List[Dict]:
    """
    Generate plausible hidden endpoint variations from query param names.

    Example:
      ?id=123 → also try ?user_id=123, ?account_id=123, ?profile_id=123

    Returns list of { url, param_original, param_expanded, reason }
    """
    try:
        parsed  = urlparse(url)
        qs      = parse_qs(parsed.query, keep_blank_values=True)
    except Exception:
        return []

    expansions: List[Dict] = []
    seen: set = set()

    for param, values in qs.items():
        param_l = param.lower()
        for expansion in _PARAM_EXPANSIONS.get(param_l, []):
            if expansion == param_l:
                continue
            new_qs = dict(qs)
            del new_qs[param]
            new_qs[expansion] = values
            new_parsed = parsed._replace(query=urlencode(new_qs, doseq=True))
            new_url    = urlunparse(new_parsed)
            if new_url not in seen:
                seen.add(new_url)
                expansions.append({
                    "url":             new_url,
                    "param_original":  param,
                    "param_expanded":  expansion,
                    "reason":          f"'{param}' often aliased as '{expansion}' — different access control path",
                    "auto_exploit":    False,
                })

    return expansions[:20]


# ── 5. PER-ENDPOINT TEST PLAN ─────────────────────────────────────────────────

def generate_test_plan(url: str) -> List[Dict]:
    """
    Generate safe, human-executable test plans for a single endpoint.
    Returns list of { type, steps, expected, risk, surfaces, auto_exploit }.

    NO auto-exploitation. Human approval required before any action.
    """
    surfaces  = classify_endpoint(url)
    score     = score_endpoint(url)
    plans: List[Dict] = []
    used: set = set()

    def _add(key: str, tmpl: Dict):
        if key not in used and any(s in surfaces or score >= 7
                                   for s in tmpl["surfaces"]):
            used.add(key)
            plans.append({
                "type":         tmpl["type"],
                "risk":         tmpl["risk"],
                "url":          url,
                "surfaces":     surfaces,
                "score":        score,
                "steps":        tmpl["steps"],
                "expected":     tmpl["expected"],
                "auto_exploit": False,
                "safe":         True,
            })

    # IDOR / BOLA — triggered by ID params or API surface
    parsed = urlparse(url)
    qs     = parse_qs(parsed.query)
    has_id_param = bool(re.search(r"\b(id|user_?id|account_?id|uid)\b",
                                  " ".join(qs.keys()), re.I))
    has_id_path  = bool(_ID_SEG.search(parsed.path.split("/")[-1]))
    if has_id_param or has_id_path or "api" in surfaces:
        _add("idor",      _TEST_TEMPLATES["idor"])
        _add("bola",      _TEST_TEMPLATES["bola"])

    if "auth" in surfaces or "admin" in surfaces:
        _add("auth_bypass", _TEST_TEMPLATES["auth_bypass"])

    if "oauth_cb" in surfaces or "auth" in surfaces:
        if re.search(r"(callback|redirect_uri|return_url|oauth)", url, re.I):
            _add("oauth_redirect", _TEST_TEMPLATES["oauth_redirect"])

    if "upload" in surfaces:
        _add("upload_abuse", _TEST_TEMPLATES["upload_abuse"])

    if "graphql" in surfaces:
        _add("graphql", _TEST_TEMPLATES["graphql"])

    if "webhook" in surfaces or re.search(r"(webhook|callback|url=|redirect=)", url, re.I):
        _add("ssrf", _TEST_TEMPLATES["ssrf"])

    if "api" in surfaces and re.search(r"(create|register|update|/new)", url, re.I):
        _add("mass_assignment", _TEST_TEMPLATES["mass_assignment"])

    # Always include at least one plan for high-score endpoints
    if not plans and score >= 7:
        _add("idor", _TEST_TEMPLATES["idor"])

    plans.sort(key=lambda p: {"high":2,"medium":1,"low":0}.get(p["risk"], 0), reverse=True)
    return plans


# ── 6. SIGNAL ROUTING ────────────────────────────────────────────────────────

def route_target(score: int) -> str:
    """
    Route a target to the appropriate scan intensity.

    score 9–10 → full_scan      (nuclei + EIL + bounty draft candidate)
    score 6–8  → targeted_scan  (nuclei with surface-specific tags)
    score 1–5  → passive_only   (no active scanning)
    """
    if score >= 9:
        return "full_scan"
    if score >= 6:
        return "targeted_scan"
    return "passive_only"


# ── 7. FULL DOMAIN ANALYSIS ───────────────────────────────────────────────────

def analyse_domain(domain: str, endpoints: List[str],
                   max_targets: int = 200) -> Dict:
    """
    Full v2 intelligence pass for a domain.
    Returns: high_value_targets, top_targets, chains, test_plans, expected_bounty
    """
    t0 = time.monotonic()

    # Score and classify every endpoint
    scored: List[Dict] = []
    for url in endpoints:
        if not url:
            continue
        s     = score_endpoint(url)
        surfs = classify_endpoint(url)
        scored.append({
            "url":          url,
            "score":        s,
            "surfaces":     surfs,
            "routing":      route_target(s),
            "is_high_value": s >= 6,
        })

    scored.sort(key=lambda x: -x["score"])
    high_value = [t for t in scored if t["is_high_value"]]
    top        = scored[:max_targets]

    # Chain detection
    chains = detect_chains_v2(endpoints)

    # Boost chain endpoints
    chain_urls = {u for c in chains["candidates"] for u in c["endpoints"]}
    for t in top:
        if t["url"] in chain_urls and "IDOR" not in str(t.get("likely_bugs",[])):
            t["score"]    = min(10, t["score"] + 1)
            t["in_chain"] = True

    # Per-endpoint test plans for top 50 high-value targets
    test_plans: List[Dict] = []
    for t in high_value[:50]:
        plans = generate_test_plan(t["url"])
        for p in plans:
            test_plans.append(p)

    # Dedup plans by type+url
    seen_plans: set = set()
    unique_plans: List[Dict] = []
    for p in test_plans:
        key = f"{p['type']}:{p['url']}"
        if key not in seen_plans:
            seen_plans.add(key)
            unique_plans.append(p)

    # Hidden expansions for top 20
    expansions: List[Dict] = []
    for t in high_value[:20]:
        exps = expand_hidden(t["url"])
        expansions.extend(exps)

    # Expected bounty
    has_high  = any(t["score"] >= 9 for t in high_value)
    has_med   = any(t["score"] >= 6 for t in high_value)
    bounty    = "high" if has_high else "medium" if has_med else "low"

    elapsed = round(time.monotonic() - t0, 2)
    log.info(
        f"[elitev2] domain={domain}"
        f" endpoints={len(endpoints)}"
        f" high_value={len(high_value)}"
        f" chains={chains['total']}"
        f" plans={len(unique_plans)}"
        f" bounty={bounty}"
        f" elapsed={elapsed}s"
    )

    return {
        "domain":               domain,
        "high_value_targets":   len(high_value),
        "top_targets":          top[:50],
        "all_scored":           scored[:max_targets],
        "chains":               chains,
        "test_plans":           unique_plans[:100],
        "hidden_expansions":    expansions[:40],
        "expected_bounty":      bounty,
        "routing_summary": {
            "full_scan":      sum(1 for t in scored if t["routing"] == "full_scan"),
            "targeted_scan":  sum(1 for t in scored if t["routing"] == "targeted_scan"),
            "passive_only":   sum(1 for t in scored if t["routing"] == "passive_only"),
        },
        "stats": {
            "total_endpoints": len(endpoints),
            "scored":          len(scored),
            "high_value":      len(high_value),
            "with_test_plans": len(set(p["url"] for p in unique_plans)),
            "chains_found":    chains["total"],
            "hidden_variants": len(expansions),
        },
        "elapsed_s":    elapsed,
        "generated_at": int(time.time()),
        "note": "Safe analysis only. No auto-exploitation. Human approval required.",
    }
