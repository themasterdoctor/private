"""
TheMasterRecon AI — Live Attack Graph Engine
Builds D3.js force-directed graph of findings → chains → impact.
Visualizes: SSRF→Cloud Metadata, XSS→Session Hijack, SQLi→Data Exfil
"""
import re, json, logging
from typing import List, Dict, Set, Tuple

log = logging.getLogger("elite.attack_graph")

# Escalation rules: (source_bug, target_bug, label, severity_upgrade)
ESCALATION_RULES = [
    ("ssrf",         "cloud_takeover",    "→ AWS Metadata",     "critical"),
    ("ssrf",         "rce",               "→ Internal RCE",     "critical"),
    ("cors",         "xss",               "→ Cross-origin XSS", "high"),
    ("cors",         "session_hijack",    "→ Session Theft",    "critical"),
    ("xss",          "session_hijack",    "→ Cookie Steal",     "critical"),
    ("xss",          "csrf",              "→ CSRF via XSS",     "high"),
    ("xss",          "credential_harvest","→ Phishing",         "high"),
    ("sqli",         "data_exfil",        "→ DB Dump",          "critical"),
    ("sqli",         "auth_bypass",       "→ Auth Bypass",      "critical"),
    ("sqli",         "rce",               "→ INTO OUTFILE RCE", "critical"),
    ("idor",         "data_exfil",        "→ User Data Leak",   "high"),
    ("idor",         "privilege_escalation","→ Priv Esc",       "critical"),
    ("jwt",          "auth_bypass",       "→ Token Forgery",    "critical"),
    ("jwt",          "privilege_escalation","→ Role Elevation", "critical"),
    ("lfi",          "rce",               "→ Log Poisoning RCE","critical"),
    ("lfi",          "credential_harvest","→ Config File Read", "high"),
    ("ssti",         "rce",               "→ Template RCE",     "critical"),
    ("rce",          "full_compromise",   "→ Full Compromise",  "critical"),
    ("rce",          "data_exfil",        "→ File Exfil",       "critical"),
    ("misconfig",    "expose",            "→ Data Exposure",    "medium"),
    ("expose",       "credential_harvest","→ Cred Leak",        "critical"),
    ("takeover",     "phishing",          "→ Subdomain Phishing","high"),
    ("oauth",        "account_takeover",  "→ ATO via OAuth",    "critical"),
    ("saml",         "account_takeover",  "→ ATO via SAML",     "critical"),
    ("prototype",    "rce",               "→ Prototype RCE",    "critical"),
    ("deserialization","rce",             "→ Deser RCE",        "critical"),
    ("host_header",  "ssrf",              "→ Header SSRF",      "high"),
    ("redirect",     "phishing",          "→ Open Redirect Phish","medium"),
    ("race_condition","idor",             "→ Race→IDOR",        "high"),
]

SEV_COLORS = {
    "critical": "#ff0044",
    "high":     "#ff8800",
    "medium":   "#ffcc00",
    "low":      "#00ff88",
    "info":     "#4466ff",
}

IMPACT_NODES = {
    "cloud_takeover":       {"label":"☁ Cloud Takeover",    "color":"#ff0044","size":30},
    "full_compromise":      {"label":"💀 Full Compromise",  "color":"#ff0044","size":35},
    "account_takeover":     {"label":"👤 Account Takeover", "color":"#ff0044","size":28},
    "data_exfil":           {"label":"📤 Data Exfil",       "color":"#ff4400","size":26},
    "rce":                  {"label":"⚡ RCE",               "color":"#ff0044","size":30},
    "auth_bypass":          {"label":"🔓 Auth Bypass",      "color":"#ff8800","size":24},
    "session_hijack":       {"label":"🎫 Session Hijack",   "color":"#ff8800","size":22},
    "privilege_escalation": {"label":"⬆ Priv Esc",          "color":"#ff4400","size":24},
    "credential_harvest":   {"label":"🔑 Cred Harvest",     "color":"#ff8800","size":22},
    "phishing":             {"label":"🎣 Phishing",          "color":"#ff8800","size":20},
    "csrf":                 {"label":"↩ CSRF",               "color":"#ffcc00","size":18},
}


def build_graph(findings: List[Dict], chains: List[Dict] = None) -> Dict:
    """
    Build attack graph data structure for D3.js visualization.
    Returns nodes[] and links[] ready for force-directed graph.
    """
    nodes = {}  # id -> node data
    links = []  # {source, target, label, color}
    chains = chains or []

    def add_node(node_id: str, label: str, color: str, size: int,
                 node_type: str, finding: Dict = None):
        if node_id not in nodes:
            nodes[node_id] = {
                "id":    node_id,
                "label": label,
                "color": color,
                "size":  size,
                "type":  node_type,
            }
            if finding:
                nodes[node_id]["url"]      = finding.get("url","")
                nodes[node_id]["severity"] = finding.get("severity","")
                nodes[node_id]["poc"]      = finding.get("poc","")

    # Add attacker node
    add_node("attacker", "🌐 Attacker", "#9966ff", 25, "attacker")

    # Add all findings as nodes
    bug_nodes = {}  # bug_type -> list of node_ids
    for i, f in enumerate(findings):
        bug   = f.get("bug","unknown").lower()
        sev   = f.get("severity","medium").lower()
        url   = f.get("url","")
        color = SEV_COLORS.get(sev, "#4466ff")
        size  = {"critical":24,"high":20,"medium":16,"low":12}.get(sev, 14)

        node_id = f"finding_{i}"
        label   = f"{bug.upper()}\n{url[-30:] if url else ''}"
        add_node(node_id, f"{bug.upper()}", color, size, "finding", f)
        bug_nodes.setdefault(bug, []).append(node_id)

        # Connect attacker to finding
        links.append({
            "source": "attacker",
            "target": node_id,
            "label":  sev,
            "color":  color,
            "dashed": False,
        })

    # Apply escalation rules
    added_impacts = set()
    for src_bug, target_impact, edge_label, upgrade_sev in ESCALATION_RULES:
        src_nodes = bug_nodes.get(src_bug, [])
        if not src_nodes:
            continue

        # Add impact node if not exists
        if target_impact not in added_impacts:
            if target_impact in IMPACT_NODES:
                imp = IMPACT_NODES[target_impact]
                add_node(target_impact, imp["label"], imp["color"], imp["size"], "impact")
            else:
                # It's another bug type
                pass
            added_impacts.add(target_impact)

        # Link finding → impact
        color = SEV_COLORS.get(upgrade_sev, "#ff8800")
        for src_node in src_nodes[:2]:  # max 2 per rule
            if target_impact in nodes or target_impact in bug_nodes:
                target_node = target_impact if target_impact in nodes else f"finding_{list(bug_nodes.get(target_impact,['x']))[0].replace('finding_','')}"
                if target_node in nodes or target_impact in nodes:
                    links.append({
                        "source": src_node,
                        "target": target_impact if target_impact in IMPACT_NODES else target_node,
                        "label":  edge_label,
                        "color":  color,
                        "dashed": True,
                    })

    # Add explicit chains
    for chain in chains:
        chain_bugs = chain.get("bugs",[])
        chain_name = chain.get("name","Chain")
        chain_sev  = chain.get("severity","high")
        chain_color = SEV_COLORS.get(chain_sev,"#ff8800")

        for j in range(len(chain_bugs)-1):
            src_bug = chain_bugs[j].lower()
            dst_bug = chain_bugs[j+1].lower()
            src_nodes_list = bug_nodes.get(src_bug,[])
            dst_nodes_list = bug_nodes.get(dst_bug,[])
            if src_nodes_list and dst_nodes_list:
                links.append({
                    "source": src_nodes_list[0],
                    "target": dst_nodes_list[0],
                    "label":  f"⛓ {chain_name}",
                    "color":  chain_color,
                    "dashed": False,
                    "chain":  True,
                })

    # Stats
    crit_paths = [l for l in links if l.get("color") == "#ff0044"]
    return {
        "nodes": list(nodes.values()),
        "links": links,
        "stats": {
            "total_nodes":   len(nodes),
            "total_links":   len(links),
            "critical_paths": len(crit_paths),
            "impact_nodes":  len([n for n in nodes.values() if n.get("type")=="impact"]),
        }
    }
