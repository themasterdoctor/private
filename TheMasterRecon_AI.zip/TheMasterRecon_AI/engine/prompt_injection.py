"""
BugScan ELITE — Invisible Prompt Injection Scanner
Based on Lonkero v3.1 research + github.com/bountyyfi/invisible-prompt-injection

Detects hidden instructions in README.md and markdown files that are
invisible when rendered but readable by LLMs (AI supply chain attack).
"""
import re, urllib.request
from typing import Dict, List, Optional, Tuple

# ── Suspicious content heuristics ─────────────────────────────────────────────
_AI_INSTRUCTION_PATTERNS = [
    r'you must\b', r'always use\b', r'when generating\b', r'in your code\b',
    r'system prompt', r'ignore previous', r'new instruction', r'override',
    r'you are now', r'act as', r'pretend to be',
]

_DEPENDENCY_INJECTION = [
    r'require\s*\(', r'import\s+["\']', r'npm install', r'pip install',
    r'yarn add', r'gem install', r'cargo add',
]

_DATA_EXFILTRATION = [
    r'environment variable', r'process\.env', r'os\.environ',
    r'\bsecret\b', r'\bcredential', r'\bapi[_\s]?key\b', r'\btoken\b',
    r'\bpassword\b', r'\bprivate[_\s]?key\b',
]

_URL_HIJACKING = [
    r'api endpoint', r'webhook', r'callback url', r'base.?url',
    r'https?://(?!github\.com|docs\.|npm\.|pypi\.|crates\.io)',  # unknown domains
]

_PROMPT_OVERRIDE = [
    r'system prompt', r'ignore previous', r'new instruction',
    r'forget previous', r'disregard', r'your new purpose',
]


def _is_suspicious(content: str) -> Tuple[bool, List[str]]:
    """Check if hidden content is suspicious. Returns (is_suspicious, reasons)."""
    reasons = []
    content_lower = content.lower()
    
    for pattern in _AI_INSTRUCTION_PATTERNS:
        if re.search(pattern, content_lower):
            reasons.append(f"AI instruction pattern: {pattern}")
            break
    
    for pattern in _DEPENDENCY_INJECTION:
        if re.search(pattern, content_lower):
            reasons.append(f"Dependency injection: {pattern}")
            break
    
    for pattern in _DATA_EXFILTRATION:
        if re.search(pattern, content_lower):
            reasons.append(f"Data exfiltration pattern: {pattern}")
            break
    
    for pattern in _URL_HIJACKING:
        if re.search(pattern, content_lower):
            reasons.append(f"URL/endpoint hijacking: {pattern}")
            break
    
    for pattern in _PROMPT_OVERRIDE:
        if re.search(pattern, content_lower):
            reasons.append(f"Prompt override: {pattern}")
            break
    
    return bool(reasons), reasons


def scan_readme_prompt_injection(url: str) -> Optional[Dict]:
    """
    Fetch README.md from a URL and scan for invisible prompt injection.
    Works on: GitHub repos, npm packages, any markdown URL.
    """
    # Try to fetch README
    readme_content = None
    readme_url     = url
    
    # Handle GitHub URLs
    if 'github.com' in url:
        parts = url.rstrip('/').split('/')
        if len(parts) >= 5:
            user, repo = parts[3], parts[4]
            raw_url = f"https://raw.githubusercontent.com/{user}/{repo}/main/README.md"
            try:
                req = urllib.request.Request(raw_url, headers={'User-Agent': 'BugScan/3.0'})
                r   = urllib.request.urlopen(req, timeout=10)
                readme_content = r.read().decode('utf-8', errors='replace')
                readme_url     = raw_url
            except Exception:
                pass
    
    if not readme_content:
        return None
    
    return analyze_markdown_injection(readme_content, readme_url)


def analyze_markdown_injection(content: str, source_url: str = "") -> Optional[Dict]:
    """
    Analyze markdown content for invisible prompt injection techniques.
    Returns finding dict or None.
    """
    findings_raw = []
    
    # ── Technique 1: HTML comments <!-- ... --> ────────────────────────────────
    html_comments = re.findall(r'<!--(.*?)-->', content, re.DOTALL)
    for comment in html_comments:
        comment = comment.strip()
        if len(comment) < 5:
            continue
        suspicious, reasons = _is_suspicious(comment)
        if suspicious:
            findings_raw.append({
                "technique": "HTML comment",
                "pattern":   "<!-- ... -->",
                "content":   comment[:200],
                "reasons":   reasons,
            })
    
    # ── Technique 2: Markdown reference links [//]: # (...) ───────────────────
    ref_links = re.findall(r'^\[.*?\]:\s*#\s*\((.+?)\)\s*$', content, re.M)
    for ref in ref_links:
        suspicious, reasons = _is_suspicious(ref)
        if suspicious:
            findings_raw.append({
                "technique": "Markdown reference link",
                "pattern":   "[//]: # (...)",
                "content":   ref[:200],
                "reasons":   reasons,
            })
    
    # ── Technique 3: Hidden reference links [_label]: # (...) ─────────────────
    hidden_refs = re.findall(r'^\[_\w+\]:\s*(?:#|https?://)\s*\(?(.+?)\)?\s*$', content, re.M)
    for ref in hidden_refs:
        suspicious, reasons = _is_suspicious(ref)
        if suspicious:
            findings_raw.append({
                "technique": "Hidden reference link",
                "pattern":   "[_label]: # (...)",
                "content":   ref[:200],
                "reasons":   reasons,
            })
    
    # ── Distributed injection detection (>3 hidden blocks even if benign) ─────
    total_hidden = len(html_comments) + len(ref_links) + len(hidden_refs)
    if total_hidden > 3 and not findings_raw:
        findings_raw.append({
            "technique": "Distributed injection (volume)",
            "pattern":   f"{total_hidden} hidden blocks",
            "content":   f"{total_hidden} hidden content blocks — possible distributed instruction injection",
            "reasons":   [f"Suspicious density: {total_hidden} hidden blocks"],
        })
    
    if not findings_raw:
        return None
    
    # Build evidence string
    evidence_parts = []
    for i, f in enumerate(findings_raw[:5], 1):
        evidence_parts.append(f"{i}. [{f['technique']}] {f['content'][:100]}")
    evidence = "\n".join(evidence_parts)
    
    reasons_all = [r for f in findings_raw for r in f["reasons"]]
    
    poc = (
        f"# Invisible Prompt Injection Scanner\n"
        f"# Source: {source_url}\n\n"
        f"# Fetch raw markdown (what LLMs process):\n"
        f"curl -sk '{source_url}' | grep -E '<!--.*-->|\\[.*\\].*#'\n\n"
        f"# View HTML comments:\n"
        f"curl -sk '{source_url}' | python3 -c \"\n"
        f"import re,sys; content=sys.stdin.read()\n"
        f"for m in re.findall(r'<!--(.*?)-->', content, re.DOTALL): print(m)\n"
        f"\""
    )
    
    return {
        "bug":         "prompt_injection",
        "severity":    "high",
        "url":         source_url,
        "title":       f"Invisible Prompt Injection in Markdown ({len(findings_raw)} hidden blocks)",
        "description": (
            f"Hidden instructions found in markdown that are invisible when rendered "
            f"but fully readable by LLMs processing raw source.\n\n"
            f"Techniques: {', '.join(set(f['technique'] for f in findings_raw))}\n\n"
            f"Suspicious patterns: {', '.join(set(reasons_all))[:200]}\n\n"
            f"Evidence:\n{evidence}"
        ),
        "poc":         poc,
        "confidence":  85,
        "details": {
            "hidden_blocks":  total_hidden,
            "html_comments":  len(html_comments),
            "ref_links":      len(ref_links),
            "hidden_refs":    len(hidden_refs),
            "techniques":     [f["technique"] for f in findings_raw],
            "reasons":        reasons_all[:10],
        },
        "cwe": "CWE-1059",  # Insufficient Technical Documentation (closest)
        "remediation": (
            "1. Strip HTML comments from markdown before LLM processing\n"
            "2. Render markdown to plain text before feeding to AI models\n"
            "3. Remove markdown reference links not referenced in the document\n"
            "4. Audit README.md files using raw source view\n"
            "5. Implement content security policies for AI-assisted development"
        ),
    }


def check_prompt_injection_supply_chain(targets: List[str], endpoints: List[str]) -> List[Dict]:
    """
    Scan for prompt injection in:
    1. README.md files found on the target
    2. package.json, requirements.txt, Cargo.toml linked from JS
    """
    findings = []
    checked  = set()
    
    # Check for README.md on each live host
    for target in targets[:20]:
        for readme_path in ['/README.md', '/readme.md', '/Readme.md']:
            readme_url = target.rstrip('/') + readme_path
            if readme_url in checked:
                continue
            checked.add(readme_url)
            
            try:
                import urllib.request as _ur
                req = _ur.Request(readme_url, headers={'User-Agent': 'BugScan/3.0'})
                resp = _ur.urlopen(req, timeout=8)
                if resp.getcode() == 200:
                    content = resp.read().decode('utf-8', errors='replace')
                    if len(content) > 50:
                        result = analyze_markdown_injection(content, readme_url)
                        if result:
                            findings.append(result)
            except Exception:
                pass
    
    # Check for GitHub README links in JS endpoints
    for ep in endpoints[:500]:
        if 'github.com' in ep and ep not in checked:
            checked.add(ep)
            result = scan_readme_prompt_injection(ep)
            if result:
                findings.append(result)
    
    return findings


# Make is_suspicious importable
def is_suspicious(content: str):
    return _is_suspicious(content)
