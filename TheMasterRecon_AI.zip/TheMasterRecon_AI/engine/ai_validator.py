"""
BugScan ELITE — AI Vulnerability Validation Pipeline

Safe validation only. Hard rules enforced throughout:
  - No auto-exploitation
  - No destructive payloads
  - No credential / data extraction
  - No auth bypass
  - No automatic report submission
  - Human approval required before any escalation
  - Payloads redacted in all external outputs
  - Evidence stored internally only, never transmitted

Flow: scanner finding → AI triage → safe probe → confidence score
      → evidence bundle → human review queue → manual decision
"""

import hashlib, json, logging, os, re, sqlite3, time, threading
from typing import Dict, List, Optional
# Signal quality — Tasks 1-4
from engine.signal_quality import (
    compute_confidence_breakdown,
    enforce_consensus,
    validation_fingerprint,
    cache_get, cache_set,
    structured_response_diff,
    build_evidence_quality_report,
)

log = logging.getLogger("elite.ai_validator")

# ── Validation queue DB ───────────────────────────────────────────────────────
_VQ_DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "validation_queue.db")
_vq_lock    = threading.Lock()

_vq_conn: Optional[sqlite3.Connection] = None

def _vdb() -> sqlite3.Connection:
    global _vq_conn
    db_path = os.path.normpath(_VQ_DB_PATH)
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    if _vq_conn is None:
        _vq_conn = sqlite3.connect(db_path, timeout=10, check_same_thread=False)
        _vq_conn.row_factory = sqlite3.Row
        _vq_conn.execute("PRAGMA journal_mode=WAL")
        _vq_conn.execute("""
        CREATE TABLE IF NOT EXISTS validation_queue (
            id             TEXT PRIMARY KEY,
            domain         TEXT,
            bug_type       TEXT,
            severity       TEXT,
            url_safe       TEXT,
            confidence     INTEGER,
            ai_decision    TEXT,
            validation_method TEXT,
            evidence_json  TEXT,
            ai_reason      TEXT,
            requires_manual_review INTEGER DEFAULT 1,
            human_decision TEXT,
            human_notes    TEXT,
            report_id      TEXT,
            created_at     REAL,
            updated_at     REAL
        )
        """)
        _vq_conn.commit()
    return _vq_conn


def _vq_id(domain: str, bug_type: str, url: str) -> str:
    raw = f"{domain}|{bug_type}|{url.split('?')[0]}"
    return hashlib.md5(raw.encode()).hexdigest()[:16]


# ── Safe validation methods per bug type ──────────────────────────────────────
# Each method describes what is SAFE to check — nothing destructive

_SAFE_METHODS = {
    "xss":               "reflection_check",     # confirm reflection only, no JS execution
    "sqli":              "boolean_timing",        # boolean comparison + timing delta only
    "lfi":               "marker_detection",      # safe file marker only (e.g. [boot loader])
    "ssrf":              "oob_callback",          # OOB DNS/HTTP callback only (no metadata)
    "ssti":              "expression_reflection", # safe expression reflection ({{7*7}}→49)
    "open_redirect":     "location_header",       # confirm Location: header only
    "redirect":          "location_header",
    "cache_poison":      "cache_key_probe",       # safe cache-key behavior only
    "cache_poisoning":   "cache_key_probe",
    "crlf":              "harmless_header",       # confirm injected harmless header only
    "cors":              "cors_reflection",       # confirm ACAO header reflection
    "idor":              "status_diff",           # compare authenticated vs unauthenticated
    "bola":              "status_diff",
    "rce":               "oob_callback",          # OOB only — no command output extraction
    "xxe":               "oob_callback",          # OOB only — no file reading
    "host_header":       "reflection_check",      # confirm header reflected safely
    "prototype":         "expression_reflection",
    "prototype_pollution":"expression_reflection",
    "info_disclosure":   "response_scan",         # scan response for patterns only
    "expose":            "response_scan",
    "auth_bypass":       "status_diff",
    "jwt":               "status_diff",
    "csrf":              "response_scan",
    "graphql":           "response_scan",
    "actuator":          "response_scan",
}

_FORBIDDEN_ACTIONS = [
    "auto_exploitation", "credential_theft", "data_exfiltration",
    "destructive_payload", "auth_bypass", "cloud_metadata_extraction",
    "internal_scanning", "shadow_file_read", "private_key_extraction",
    "automatic_report_submission", "account_takeover", "data_dumping",
]

# Per-bug-type allowed validation types and hard-blocked actions
# Format: { bug_type: { "allowed": [...], "blocked": [...], "validation_type": str } }
_BUG_VALIDATION_RULES: dict = {
    "xss": {
        "validation_type": "reflection",
        "allowed":  ["reflection_check", "html_context_detection", "harmless_marker"],
        "blocked":  ["credential_theft", "session_theft", "malicious_js",
                     "cookie_theft", "dom_xss_execution", "script_execution"],
        "probe_desc": "Reflection check — canary string in response body, no JS execution",
    },
    "sqli": {
        "validation_type": "boolean_diff",
        "allowed":  ["boolean_difference", "timing_difference", "harmless_syntax"],
        "blocked":  ["union_extraction", "table_dump", "write_query",
                     "blind_data_extraction", "stacked_query", "file_read"],
        "probe_desc": "Boolean/timing difference — no data extraction or write operations",
    },
    "lfi": {
        "validation_type": "reflection",
        "allowed":  ["harmless_marker_validation", "path_reflection"],
        "blocked":  ["sensitive_file_dump", "private_key_read", "passwd_file",
                     "shadow_read", "ssh_key_extraction", "/etc/ file read"],
        "probe_desc": "Harmless marker only — no sensitive file content retrieved",
    },
    "ssrf": {
        "validation_type": "oob",
        "allowed":  ["controlled_oob_callback"],
        "blocked":  ["cloud_credential_extraction", "internal_scanning",
                     "metadata_endpoint", "169.254.169.254", "aws_metadata",
                     "gcp_metadata", "azure_metadata", "internal_ip_range"],
        "probe_desc": "OOB callback to analyst-controlled server only — no internal access",
    },
    "rce": {
        "validation_type": "oob",
        "allowed":  ["oob_callback_only"],
        "blocked":  ["shell_execution", "reverse_shell", "command_output",
                     "file_write", "persistence", "privilege_escalation",
                     "lateral_movement", "data_extraction"],
        "probe_desc": "OOB DNS/HTTP callback only — no command output, no shell",
    },
    "xxe": {
        "validation_type": "oob",
        "allowed":  ["oob_callback_only"],
        "blocked":  ["file_read", "internal_ssrf", "private_key_extraction",
                     "passwd_file", "shadow_file", "data_exfiltration"],
        "probe_desc": "OOB callback only — no file content, no internal network access",
    },
    "ssti": {
        "validation_type": "reflection",
        "allowed":  ["safe_expression_reflection"],
        "blocked":  ["code_execution", "rce_via_template", "os_module",
                     "file_read", "reverse_shell", "popen", "subprocess"],
        "probe_desc": "Safe expression probe (e.g. arithmetic result reflection) only",
    },
    "redirect": {
        "validation_type": "header_diff",
        "allowed":  ["location_header_validation"],
        "blocked":  ["phishing_redirect", "credential_harvest",
                     "session_fixation", "open_redirect_chain"],
        "probe_desc": "Location header inspection only — no active redirect following",
    },
    "open_redirect": {
        "validation_type": "header_diff",
        "allowed":  ["location_header_validation"],
        "blocked":  ["phishing_redirect", "credential_harvest"],
        "probe_desc": "Location header inspection only",
    },
    "cors": {
        "validation_type": "header_diff",
        "allowed":  ["acao_header_reflection"],
        "blocked":  ["credential_request", "withCredentials_exploit",
                     "cookie_theft", "session_hijack"],
        "probe_desc": "ACAO header reflection check — no cross-origin credential theft",
    },
    "cache_poison": {
        "validation_type": "header_diff",
        "allowed":  ["cache_key_gap_probe", "header_reflection_check"],
        "blocked":  ["cache_poisoning_execution", "stored_xss_via_cache",
                     "response_hijack", "phishing_cache"],
        "probe_desc": "Cache header diff with Cache-Control: no-store — no live cache poisoned",
    },
    "crlf": {
        "validation_type": "header_diff",
        "allowed":  ["harmless_header_injection"],
        "blocked":  ["session_fixation", "xss_via_header", "cache_poisoning",
                     "response_splitting_exploit"],
        "probe_desc": "Harmless header injection confirmation only",
    },
    "idor": {
        "validation_type": "boolean_diff",
        "allowed":  ["status_code_difference", "response_structure_diff"],
        "blocked":  ["data_extraction", "other_user_data_access",
                     "privilege_escalation", "account_takeover"],
        "probe_desc": "Status code and response structure diff — no data content accessed",
    },
    "proto_pollution": {
        "validation_type": "reflection",
        "allowed":  ["property_reflection"],
        "blocked":  ["rce_via_pollution", "auth_bypass_via_pollution"],
        "probe_desc": "Property reflection only — no prototype chain exploitation",
    },
}

# Default rules for unmapped bug types
_DEFAULT_VALIDATION_RULES = {
    "validation_type": "reflection",
    "allowed":  ["response_scan", "harmless_marker"],
    "blocked":  ["data_extraction", "credential_theft", "auto_exploitation"],
    "probe_desc": "Safe response scan only",
}

def get_validation_rules(bug_type: str) -> dict:
    """Return safe/blocked rules for a bug type."""
    return _BUG_VALIDATION_RULES.get(bug_type.lower(), _DEFAULT_VALIDATION_RULES)

def is_action_blocked(bug_type: str, action: str) -> bool:
    """True if the action is in the blocked list for this bug type."""
    rules = get_validation_rules(bug_type)
    blocked = rules.get("blocked", [])
    action_lower = action.lower()
    return any(b.lower() in action_lower or action_lower in b.lower() for b in blocked)


def _safe_url(url: str) -> str:
    """Strip querystring — never store or display raw params."""
    return url.split("?")[0][:300] if url else ""


def _safe_diff_summary(baseline_body: str, probe_body: str,
                       max_len: int = 200,
                       baseline_status: int = 0, probe_status: int = 0,
                       baseline_headers: dict = None, probe_headers: dict = None) -> str:
    """
    TASK 4 upgrade — delegates to structured_response_diff for full diff analysis.
    Returns analyst-readable summary string, never includes payloads.
    """
    diff = structured_response_diff(
        baseline_status=baseline_status or 0,
        probe_status=probe_status or 0,
        baseline_body=baseline_body or "",
        probe_body=probe_body or "",
        baseline_headers=baseline_headers,
        probe_headers=probe_headers,
    )
    return diff.get("summary", "no_significant_diff")[:max_len]


# ── AI triage (uses Anthropic API safely) ────────────────────────────────────

def _ai_triage(finding: Dict) -> Dict:
    """
    Call Anthropic API to classify and assess a finding.
    Only provides triage decision, validation method, and impact summary.
    Never suggests exploitation. Never outputs payloads.
    """
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        return {
            "triage_decision":   "needs_review",
            "validation_method": _SAFE_METHODS.get(finding.get("bug","").lower(), "response_scan"),
            "confidence_score":  finding.get("confidence", 50),
            "impact_summary":    "AI triage unavailable — manual review required",
            "ai_used":           False,
        }

    bug    = finding.get("bug", finding.get("type", "unknown")).lower()
    sev    = finding.get("severity", "medium")
    url    = _safe_url(finding.get("url", ""))
    domain = finding.get("domain", "")
    conf   = finding.get("confidence", 50)

    # Strict prompt — never asks for payloads or exploitation steps
    prompt = f"""You are a security triage assistant. Assess this finding and return ONLY valid JSON.

Finding:
- Type: {bug}
- Severity: {sev}
- Domain: {domain}
- Path: {url}
- Initial confidence: {conf}

Return ONLY this JSON (no other text):
{{
  "triage_decision": "confirm|reject|needs_review",
  "validation_method": "{_SAFE_METHODS.get(bug, 'response_scan')}",
  "confidence_score": <0-100 integer>,
  "impact_summary": "<one sentence, no payloads, no exploit details>",
  "requires_manual_review": true
}}

Rules:
- Do NOT include any payloads, exploit syntax, or attack instructions
- Do NOT suggest exploitation steps
- Do NOT output credential extraction methods
- impact_summary must be safe for analyst communication
- requires_manual_review must always be true"""

    try:
        import urllib.request as _ur, urllib.error
        payload = json.dumps({
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 300,
            "messages": [{"role": "user", "content": prompt}],
        }).encode()
        req = _ur.Request(
            "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={
                "x-api-key":         api_key,
                "anthropic-version": "2023-06-01",
                "content-type":      "application/json",
            },
            method="POST",
        )
        import ssl
        ctx = ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        with _ur.urlopen(req, timeout=15, context=ctx) as resp:
            data = json.loads(resp.read())
        text = "".join(b.get("text","") for b in data.get("content",[]) if b.get("type")=="text")
        # Strip any markdown fences
        text = re.sub(r"```(?:json)?|```", "", text).strip()
        result = json.loads(text)
        # Hard-enforce requires_manual_review=True regardless of AI output
        result["requires_manual_review"] = True
        result["ai_used"] = True
        # Safety check: reject if AI tried to include forbidden actions
        impact = result.get("impact_summary", "")
        for forbidden in ["payload", "exploit", "inject", "bypass", "exfil",
                          "dump", "extract", "/etc/shadow", "private key"]:
            if forbidden.lower() in impact.lower():
                result["impact_summary"] = "Potential security issue detected. Analyst review required."
        return result
    except Exception as e:
        log.debug(f"[ai-validate] AI triage error: {e}")
        return {
            "triage_decision":    "needs_review",
            "validation_method":  _SAFE_METHODS.get(bug, "response_scan"),
            "confidence_score":   conf,
            "impact_summary":     "Triage error — manual review required",
            "requires_manual_review": True,
            "ai_used":            False,
            "ai_error":           str(e)[:100],
        }


# ── Safe probe execution ──────────────────────────────────────────────────────

def _run_safe_probe(finding: Dict, method: str) -> Dict:
    """
    Execute a safe validation probe for the finding.
    Only allowed: response comparison, reflection check, OOB callback check.
    NEVER executes destructive payloads. NEVER extracts data.
    """
    url      = finding.get("url", "")
    if not url:
        return {"skipped": True, "reason": "no_url"}

    baseline_status = 0
    probe_status    = 0
    diff_summary    = "not_run"
    oob_event_id    = None
    evidence_note   = f"safe_{method}_probe"

    try:
        import urllib.request as _ur, ssl
        ctx = ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        ua  = {"User-Agent": "Mozilla/5.0 (BugScanELITE-SafeProbe/1.0)"}

        # Baseline request — no modification
        req_b = _ur.Request(url, headers=ua, method="GET")
        try:
            with _ur.urlopen(req_b, timeout=10, context=ctx) as r:
                baseline_status = r.status
                baseline_body   = r.read(8192).decode("utf-8", errors="replace")
        except Exception as e:
            baseline_body = ""; baseline_status = 0

        # Probe depends on method — safe checks only
        probe_body = ""
        if method == "reflection_check":
            # Check if a safe canary string reflects — no JS, no event handlers
            canary  = "bselite-probe-" + hashlib.md5(url.encode()).hexdigest()[:8]
            safe_url = url + ("&" if "?" in url else "?") + f"_probe={canary}"
            try:
                with _ur.urlopen(_ur.Request(safe_url, headers=ua), timeout=10, context=ctx) as r:
                    probe_status = r.status
                    probe_body   = r.read(8192).decode("utf-8", errors="replace")
                    if canary in probe_body:
                        diff_summary = "canary_reflected"
                    else:
                        diff_summary = "canary_not_reflected"
            except Exception:
                probe_status = 0

        elif method in ("boolean_timing", "expression_reflection", "location_header",
                        "response_scan", "cors_reflection", "status_diff",
                        "marker_detection", "harmless_header", "cache_key_probe"):
            # For these: simply compare baseline with a harmless second request
            # (actual payload probing is deferred to human-reviewed validation_engine)
            try:
                with _ur.urlopen(req_b, timeout=10, context=ctx) as r2:
                    probe_status = r2.status
                    probe_body   = r2.read(8192).decode("utf-8", errors="replace")
            except Exception:
                probe_status = baseline_status
                probe_body   = baseline_body

        elif method == "oob_callback":
            # Register OOB intent only — actual callback monitored passively
            try:
                from engine.oob import get_oob_client
                oob = get_oob_client()
                if oob and hasattr(oob, "register_probe"):
                    oob_event_id = oob.register_probe(url)
                    diff_summary = f"oob_probe_registered id={oob_event_id}"
                else:
                    diff_summary = "oob_not_configured"
            except Exception:
                diff_summary = "oob_not_available"
            probe_status = baseline_status

        diff_summary = diff_summary or _safe_diff_summary(baseline_body, probe_body)

    except Exception as e:
        diff_summary = f"probe_error: {str(e)[:80]}"

    return {
        "baseline_status": baseline_status,
        "probe_status":    probe_status,
        "diff_summary":    diff_summary,
        "oob_event_id":    oob_event_id,
        "payload_redacted": True,           # hard: never store payload in evidence
        "evidence_note":   evidence_note,
    }


# ── Safe PoC Validation Engine — public API ──────────────────────────────────

def validate_poc_safe(finding: dict, authorized_domain: str = "") -> dict:
    """
    TASK 1 — Safe PoC Validation Engine.

    Validates a finding using safe, non-destructive probes only.
    NEVER: auto-exploits, gains shells, dumps databases, steals credentials,
           bypasses auth, exfiltrates cloud metadata, modifies target data,
           or chains vulnerabilities automatically.

    Returns:
    {
      "confirmed":          bool,
      "confidence":         int,          # 0-100
      "severity":           str,          # critical/high/medium/low
      "validation_type":    str,          # reflection|boolean_diff|timing|oob|header_diff
      "evidence_summary":   str,          # analyst-readable, no payloads
      "manual_review_required": True,     # ALWAYS True
      "blocked_actions":    [str],        # what was explicitly not attempted
      "allowed_methods":    [str],        # what probes were used
      "probe_description":  str,          # what the probe did
    }
    """
    bug      = finding.get("bug", finding.get("type", "unknown")).lower()
    url      = finding.get("url", "")
    sev      = finding.get("severity", "medium")
    base_conf = int(finding.get("confidence", 50) or 50)

    # Get per-bug rules
    rules          = get_validation_rules(bug)
    validation_type = rules["validation_type"]
    blocked_actions = rules["blocked"]
    allowed_methods = rules["allowed"]
    probe_desc      = rules["probe_desc"]

    # Check authorized domain if provided
    if authorized_domain and authorized_domain.lower() not in url.lower():
        log.warning(f"[validate-poc] domain mismatch: url={url} authorized={authorized_domain}")
        return {
            "confirmed":              False,
            "confidence":             0,
            "severity":               sev,
            "validation_type":        validation_type,
            "evidence_summary":       "Validation skipped — URL not in authorized scope",
            "manual_review_required": True,
            "blocked_actions":        blocked_actions,
            "allowed_methods":        allowed_methods,
            "probe_description":      probe_desc,
            "error":                  "scope_mismatch",
        }

    # TASK 3 — Check validation cache first
    _fp = validation_fingerprint(
        path     = url.split("?")[0],
        bug_type = bug,
        params   = [k.split("=")[0] for k in url.split("?")[1].split("&") if "=" in k] if "?" in url else [],
    )
    cached = cache_get(_fp)
    if cached:
        return cached

    log.info(f"[validate] finding queued bug={bug} sev={sev} url={_safe_url(url)}")

    # Run the full ai_validate_finding pipeline
    result = ai_validate_finding(finding, mode="safe")

    # Map internal result to standardized validate_poc_safe output
    raw_evidence  = result.get("safe_evidence", [{}])
    evidence_item = raw_evidence[0] if raw_evidence else {}
    diff          = evidence_item.get("diff_summary", "no_diff")
    baseline_st   = evidence_item.get("baseline_status", 0)
    probe_st      = evidence_item.get("probe_status", 0)

    # Build analyst-readable evidence summary (no payloads, no extracted data)
    evidence_parts = [f"Validation method: {validation_type}"]
    if baseline_st and probe_st:
        if baseline_st != probe_st:
            evidence_parts.append(f"HTTP status changed: {baseline_st} → {probe_st}")
        else:
            evidence_parts.append(f"HTTP status stable: {baseline_st}")
    if diff and diff not in ("not_run", "no_significant_diff"):
        evidence_parts.append(f"Response diff: {diff[:100]}")
    if evidence_item.get("oob_event_id"):
        evidence_parts.append(f"OOB probe registered: {evidence_item['oob_event_id'][:20]}")

    evidence_parts.append(f"Probe: {probe_desc}")
    evidence_parts.append("Payload redacted: yes")
    evidence_summary = " | ".join(evidence_parts)

    confirmed   = result.get("confirmed", False)
    final_conf  = result.get("confidence", base_conf)

    log.info(f"[validate] safe validation complete confidence={final_conf} confirmed={confirmed}")
    log.info(f"[validate] analyst review required")

    final_result = {
        "confirmed":              confirmed,
        "confidence":             final_conf,
        "severity":               sev,
        "validation_type":        validation_type,
        "evidence_summary":       evidence_summary,
        "manual_review_required": True,   # ALWAYS — hard rule
        "blocked_actions":        blocked_actions,
        "allowed_methods":        allowed_methods,
        "probe_description":      probe_desc,
        "validation_id":          result.get("id", ""),
        "confidence_breakdown":   result.get("confidence_breakdown", {}),
        # Evidence bundle — no payloads stored
        "evidence": {
            "baseline_status": baseline_st,
            "probe_status":    probe_st,
            "response_diff":   diff[:200] if diff else "",
            "headers_changed": [],    # populated by safe header probe
            "oob_confirmed":   bool(evidence_item.get("oob_event_id")),
            "payload_redacted": True, # ALWAYS True
        },
    }
    # Store in cache (TTL 1 hour)
    cache_set(_fp, final_result)
    return final_result


# ── Main entry point ──────────────────────────────────────────────────────────

def ai_validate_finding(finding: Dict, mode: str = "safe") -> Dict:
    """
    AI Vulnerability Validation Pipeline — safe mode only.

    Flow:
      1. AI triage  — classify, assess confidence, never suggest exploitation
      2. Safe probe — run one safe HTTP check matching the bug type
      3. Evidence   — store baseline vs probe diff internally (payload redacted)
      4. Queue      — store in validation_queue for human review

    Returns:
    {
      "id":                   str,
      "confirmed":            bool,
      "confidence":           int,
      "severity":             str,
      "safe_evidence":        [dict],
      "reason":               str,
      "requires_manual_review": true,   # always true
      "human_decision":       null,
      "ai_used":              bool,
    }

    Hard rules (enforced in code, not just prompt):
      - requires_manual_review is ALWAYS True
      - payload_redacted is ALWAYS True in evidence
      - No auto-escalation to exploit
      - No credential/data extraction
    """
    if mode not in ("safe",):
        mode = "safe"   # Only safe mode supported

    bug    = finding.get("bug", finding.get("type", "unknown")).lower()
    domain = finding.get("domain", finding.get("url","").split("/")[2] if "://" in finding.get("url","") else "")
    url    = finding.get("url", "")
    url_safe  = _safe_url(url)
    vid       = _vq_id(domain, bug, url)

    log.info(f"[ai-validate] finding queued id={vid} bug={bug}"
             f" sev={finding.get('severity','?')} conf={finding.get('confidence','?')}")

    # Step 1: AI triage
    triage = _ai_triage(finding)

    # Step 2: Safe probe
    method  = _SAFE_METHODS.get(bug, "response_scan")
    evidence = _run_safe_probe(finding, method)

    # Step 3: Structured diff and confidence breakdown (Tasks 1 + 4)
    base_conf  = int(finding.get("confidence", 50) or 50)
    ai_conf    = int(triage.get("confidence_score", base_conf) or base_conf)

    # Build structured diff from probe evidence
    struct_diff = structured_response_diff(
        baseline_status=evidence.get("baseline_status", 0),
        probe_status=evidence.get("probe_status", 0),
        baseline_body="",   # not stored — safe
        probe_body="",
    )
    # Use diff summary from probe, augment with signals
    diff_summary = evidence.get("diff_summary", "")
    if struct_diff.get("summary") not in ("no_significant_diff", ""):
        diff_summary = struct_diff["summary"]

    # Collect signals observed from evidence + diff
    observed_signals = struct_diff.get("signals", [])
    if "reflected" in diff_summary or "canary" in diff_summary:
        observed_signals.append("canary_reflected")
    if "length_diff" in diff_summary:
        observed_signals.append("length_diff_large")
    if "new_keyword" in diff_summary or struct_diff.get("keyword_hits"):
        observed_signals.append("keyword_hit")
    if evidence.get("oob_event_id"):
        observed_signals.append("oob_http")
    if ai_conf > 75:
        observed_signals.append("context_match")

    # Confidence breakdown (Task 1)
    conf_breakdown = compute_confidence_breakdown(observed_signals)
    weighted_conf  = conf_breakdown["total_confidence"]
    final_conf     = min(97, max(base_conf, ai_conf, base_conf + weighted_conf // 3))

    # Multi-validator consensus (Task 2)
    severity    = finding.get("severity", "medium")
    severity, final_conf, consensus_reason = enforce_consensus(
        severity, final_conf, observed_signals)

    # Step 4: Confirmed if AI agrees AND confidence is sufficient
    ai_decision  = triage.get("triage_decision", "needs_review")
    confirmed    = ai_decision == "confirm" and final_conf >= 70

    reason = triage.get("impact_summary", "")
    if not reason:
        reason = f"{method} probe + AI triage"
    if diff_summary and diff_summary not in ("not_run", "no_significant_diff"):
        reason += f" | diff: {diff_summary[:80]}"
    if consensus_reason and "ok" not in consensus_reason:
        reason += f" | {consensus_reason}"

    log.info(f"[ai-validate] safe validation complete"
             f" id={vid} confidence={final_conf} confirmed={confirmed}")
    log.info(f"[ai-validate] manual review required id={vid}")

    result = {
        "id":                     vid,
        "confirmed":              confirmed,
        "confidence":             final_conf,
        "severity":               severity,
        "safe_evidence":          [evidence],
        "reason":                 reason,
        "requires_manual_review": True,   # ALWAYS — hard rule
        "human_decision":         None,
        "ai_used":                triage.get("ai_used", False),
        "validation_method":      method,
        "triage_decision":        ai_decision,
        "domain":                 domain,
        "url_safe":               url_safe,
        "bug_type":               bug,
        "created_at":             time.time(),
    }

    # Step 5: Store in validation queue
    try:
        with _vq_lock:
            _vdb().execute("""
                INSERT OR REPLACE INTO validation_queue
                (id, domain, bug_type, severity, url_safe, confidence,
                 ai_decision, validation_method, evidence_json, ai_reason,
                 requires_manual_review, human_decision, created_at, updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,1,NULL,?,?)
            """, (vid, domain, bug, severity, url_safe, final_conf,
                  ai_decision, method,
                  json.dumps({"evidence": evidence, "payload_redacted": True}),
                  reason[:500], time.time(), time.time()))
            _vdb().commit()
    except Exception as e:
        log.warning(f"[ai-validate] queue store error: {e}")

    return result


# ── Queue management ──────────────────────────────────────────────────────────

def get_validation_queue(status: str = None, limit: int = 50) -> List[Dict]:
    """Return pending validation items requiring human review."""
    try:
        q = "SELECT * FROM validation_queue"
        params = []
        if status:
            q += " WHERE human_decision = ?" if status != "pending" else " WHERE human_decision IS NULL"
            if status != "pending": params.append(status)
        q += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        rows = _vdb().execute(q, params).fetchall()
        items = []
        for row in rows:
            d = dict(row)
            # Never return raw evidence JSON in list view — summary only
            d.pop("evidence_json", None)
            items.append(d)
        return items
    except Exception as e:
        log.warning(f"[ai-validate] queue read error: {e}")
        return []


def human_decision(vid: str, decision: str, notes: str = "") -> bool:
    """
    Record a human approve/reject decision for a validation item.
    'approved' items are eligible for report generation.
    'rejected' items are archived.
    """
    if decision not in ("approved", "rejected"):
        return False
    try:
        with _vq_lock:
            _vdb().execute(
                "UPDATE validation_queue SET human_decision=?, human_notes=?, updated_at=? WHERE id=?",
                (decision, notes[:500], time.time(), vid)
            )
            _vdb().commit()
        log.info(f"[ai-validate] human decision id={vid} decision={decision}")
        return True
    except Exception as e:
        log.warning(f"[ai-validate] human decision error: {e}")
        return False


def get_validation_item(vid: str) -> Optional[Dict]:
    """Fetch one validation item for report generation."""
    try:
        row = _vdb().execute(
            "SELECT * FROM validation_queue WHERE id=?", (vid,)
        ).fetchone()
        return dict(row) if row else None
    except Exception:
        return None
