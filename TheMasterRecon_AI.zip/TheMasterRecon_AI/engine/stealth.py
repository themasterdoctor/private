import os
"""
BugScan ELITE — Stealth & Rate Limiting Engine
Randomized delays, User-Agent rotation, request throttling per host.
"""
import time, random, threading, logging, collections
from typing import Dict, Optional

log = logging.getLogger("elite.stealth")

USER_AGENTS = [
    # Chrome on Windows
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    # Chrome on Mac
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.6045.159 Safari/537.36",
    # Firefox
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.1; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
    # Safari
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
    # Edge
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
    # Googlebot (for WAF bypass)
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    # Bingbot
    "Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)",
]

ACCEPT_HEADERS = [
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "application/json, text/plain, */*",
    "*/*",
]

ACCEPT_LANGS = [
    "en-US,en;q=0.9",
    "en-GB,en;q=0.9",
    "en-US,en;q=0.5",
    "en;q=0.9,fr;q=0.8",
]


class RateLimiter:
    """Per-host rate limiter with exponential backoff on 429."""

    def __init__(self, rps: float = 10.0):
        self._rps       = rps
        self._min_delay = 1.0 / rps
        self._host_last: Dict[str, float] = {}
        self._host_429:  Dict[str, int]   = {}  # consecutive 429s
        self._lock       = threading.Lock()

    def wait(self, host: str):
        """Wait appropriate time before making request to host."""
        with self._lock:
            last    = self._host_last.get(host, 0)
            backoff = self._host_429.get(host, 0)
            delay   = self._min_delay

            # Exponential backoff for rate-limited hosts
            if backoff > 0:
                delay = min(self._min_delay * (2 ** backoff), 30.0)
                log.debug(f"[stealth] {host} rate limited (backoff={backoff}), delay={delay:.1f}s")

            # Add jitter ±20%
            jitter = delay * random.uniform(-0.2, 0.2)
            delay  = max(0, delay + jitter)

            elapsed = time.time() - last
            if elapsed < delay:
                time.sleep(delay - elapsed)

            self._host_last[host] = time.time()

    def on_429(self, host: str):
        with self._lock:
            self._host_429[host] = self._host_429.get(host, 0) + 1

    def on_success(self, host: str):
        with self._lock:
            if host in self._host_429:
                self._host_429[host] = max(0, self._host_429[host] - 1)

    def set_rps(self, rps: float):
        self._rps       = rps
        self._min_delay = 1.0 / rps


# Extended user agents
USER_AGENTS_EXTENDED = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:123.0) Gecko/20100101 Firefox/123.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.64 Mobile Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0",
    "PostmanRuntime/7.37.0",
    "python-httpx/0.26.0",
    "axios/1.6.7",
    "node-fetch/3.3.2",
]

# Proxy pool — add proxies here or set HTTP_PROXY env var
_PROXY_POOL: list = []
_proxy_idx  = 0

def set_proxies(proxy_list: list):
    global _PROXY_POOL
    _PROXY_POOL = [p for p in proxy_list if p]
    log.info(f"[stealth] {len(_PROXY_POOL)} proxies configured")

def get_proxy():
    global _proxy_idx
    env = os.environ.get("HTTP_PROXY") or os.environ.get("HTTPS_PROXY","")
    if env: return env
    if not _PROXY_POOL: return None
    p = _PROXY_POOL[_proxy_idx % len(_PROXY_POOL)]
    _proxy_idx += 1
    return p


class StealthEngine:
    """
    Manages stealth settings: mode, rate limiter, UA rotation, proxy support.
    """

    MODES = {
        "aggressive": {"rps": 50,  "delay_range": (0.0, 0.1),  "ua_rotate": False},
        "normal":     {"rps": 10,  "delay_range": (0.05, 0.3), "ua_rotate": True},
        "stealth":    {"rps": 2,   "delay_range": (1.0, 4.0),  "ua_rotate": True},
        "ghost":      {"rps": 0.5, "delay_range": (3.0, 10.0), "ua_rotate": True},
    }

    def __init__(self, mode: str = "normal"):
        self.mode    = mode
        cfg          = self.MODES.get(mode, self.MODES["normal"])
        self._rl     = RateLimiter(rps=cfg["rps"])
        self._drange = cfg["delay_range"]
        self._rotate = cfg["ua_rotate"]
        self._ua_idx = 0
        self._lock   = threading.Lock()

    def set_mode(self, mode: str):
        if mode not in self.MODES:
            mode = "normal"
        self.mode  = mode
        cfg        = self.MODES[mode]
        self._rl.set_rps(cfg["rps"])
        self._drange = cfg["delay_range"]
        self._rotate = cfg["ua_rotate"]
        log.info(f"[stealth] mode={mode}, rps={cfg['rps']}")

    def get_headers(self) -> Dict[str, str]:
        """Get randomized request headers."""
        if self._rotate:
            ua = random.choice(USER_AGENTS + USER_AGENTS_EXTENDED)
        else:
            ua = (USER_AGENTS + USER_AGENTS_EXTENDED)[0]

        return {
            "User-Agent":      ua,
            "Accept":          random.choice(ACCEPT_HEADERS),
            "Accept-Language": random.choice(ACCEPT_LANGS),
            "Accept-Encoding": "gzip, deflate, br",
            "Connection":      "keep-alive",
            "Cache-Control":   "no-cache",
            "Pragma":          "no-cache",
        }

    def throttle(self, host: str):
        """Apply rate limiting for host."""
        self._rl.wait(host)
        # Extra random delay in stealth modes
        lo, hi = self._drange
        if hi > 0:
            time.sleep(random.uniform(lo, hi))

    def on_429(self, host: str):
        self._rl.on_429(host)

    def on_success(self, host: str):
        self._rl.on_success(host)

    def extract_host(self, url: str) -> str:
        try:
            from urllib.parse import urlparse
            return urlparse(url).netloc
        except: return url


# Global singleton
_stealth: Optional[StealthEngine] = None

def get_stealth(mode: str = "normal") -> StealthEngine:
    global _stealth
    if _stealth is None:
        _stealth = StealthEngine(mode)
    return _stealth

def set_stealth_mode(mode: str):
    get_stealth().set_mode(mode)

def get_headers() -> Dict[str, str]:
    return get_stealth().get_headers()

def throttle(url: str):
    s = get_stealth()
    s.throttle(s.extract_host(url))
