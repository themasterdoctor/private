"""
BugScan ELITE — Smart Parameter Classifier
Inspired by Lonkero v3.0: context-aware parameter filtering.

Classifies parameters by risk level. Skips untestable ones.
Semantic URL deduplication: /users/123 == /users/456 == /users/{id}
"""
import re, urllib.parse
from typing import Dict, List, Set, Tuple

# ── Parameter risk classification ─────────────────────────────────────────────
RISK_HIGH = "high"       # XSS, SQLi, SSRF, CMDi — test everything
RISK_MED  = "medium"     # XSS, SQLi
RISK_LOW  = "low"        # XSS only
RISK_SKIP = "skip"       # Framework internal — never test

_SKIP_PARAMS: Set[str] = {
    # CSRF / security tokens
    'csrf', 'csrf_token', '_token', 'authenticity_token', 'nonce', '__requestverificationtoken',
    'x-csrf-token', 'x-xsrf-token', '__csrf', 'csrfmiddlewaretoken', 'csrftoken',
    # Session / auth (testing these breaks the flow)
    'session', 'sessionid', 'sid', 'jsessionid', 'phpsessid', 'aspsessionid',
    'access_token', 'refresh_token', 'bearer', 'api_key', 'apikey', 'auth_token',
    # Pagination (reflected but not injectable)
    'page', 'p', 'pg', 'paged', 'per_page', 'limit', 'offset', 'start', 'rows',
    'count', 'size', 'from', 'skip', 'cursor', 'after', 'before',
    # Sort/filter (reflected but usually integer or enum)
    'sort', 'sortby', 'sort_by', 'orderby', 'order_by', 'order', 'direction', 'asc', 'desc',
    # Locale / display (not injectable)
    'lang', 'language', 'locale', 'tz', 'timezone', 'currency', 'country', 'region',
    # Misc framework internals
    'format', 'callback', 'jsonp', '_', 'nocache', 'v', 'version', 'ts', 'timestamp',
    'debug', 'trace', 'test', 'preview', 'mode',
    # State flags (booleans — no injection surface)
    'ajax', 'xhr', 'async', 'json', 'xml', 'rss', 'atom',
}

_HIGH_RISK_PARAMS: Set[str] = {
    # URL/path injection → SSRF, redirect, LFI
    'url', 'uri', 'href', 'src', 'source', 'dest', 'destination', 'redirect',
    'redirect_uri', 'return', 'return_url', 'next', 'goto', 'continue', 'target',
    'path', 'file', 'filename', 'filepath', 'include', 'require', 'load', 'fetch',
    # Command injection targets
    'cmd', 'exec', 'command', 'run', 'shell', 'ping', 'host', 'ip', 'domain',
    # Template injection
    'template', 'tpl', 'view', 'layout',
    # SQL-adjacent
    'query', 'q', 'search', 'filter', 'where', 'conditions',
    'id', 'user_id', 'account_id', 'item_id', 'product_id', 'order_id',
}

_MEDIUM_RISK_PARAMS: Set[str] = {
    # User input → XSS, SQLi
    'name', 'username', 'user', 'email', 'title', 'description', 'message',
    'text', 'content', 'body', 'comment', 'note', 'remark', 'input',
    'first_name', 'last_name', 'fullname', 'display_name',
    'subject', 'topic', 'category', 'tag', 'label', 'keyword',
    'address', 'city', 'state', 'zip', 'country',
    'phone', 'mobile', 'fax',
}


def classify_param(param: str, value: str = "") -> str:
    """Classify a parameter's risk level for testing."""
    p = param.lower().strip()
    
    # Exact skip match
    if p in _SKIP_PARAMS:
        return RISK_SKIP
    
    # Partial skip patterns
    if any(p.endswith(s) for s in ('_token', '_nonce', '_csrf', '_key', '_id_')):
        if p not in _HIGH_RISK_PARAMS:
            return RISK_SKIP
    
    # Value-based classification
    if value:
        if re.match(r'^https?://', value):
            return RISK_HIGH  # URL value → SSRF/redirect
        if re.match(r'^[a-f0-9]{32,}$', value, re.I):
            return RISK_SKIP  # Hash/token
        if re.match(r'^\d+$', value) and int(value) < 0:
            return RISK_SKIP  # Negative numeric
    
    # High risk by name
    if p in _HIGH_RISK_PARAMS:
        return RISK_HIGH
    if any(p.startswith(h) or p.endswith(h) for h in ('url', 'uri', 'src', 'path', 'file', 'cmd')):
        return RISK_HIGH
    
    # Medium risk
    if p in _MEDIUM_RISK_PARAMS:
        return RISK_MED
    
    # Default: medium (test for XSS/SQLi)
    return RISK_MED


def filter_params_for_testing(params: Dict[str, List[str]],
                               vuln_type: str = "xss") -> Dict[str, str]:
    """
    Filter params to only those worth testing for a given vuln type.
    Returns {param: value} dict of testable params.
    
    vuln_type: xss | sqli | ssrf | cmdi | all
    """
    result = {}
    
    for param, values in params.items():
        risk = classify_param(param, values[0] if values else "")
        
        if risk == RISK_SKIP:
            continue
        
        if vuln_type == "ssrf" and risk != RISK_HIGH:
            continue  # SSRF only on URL params
        
        if vuln_type == "cmdi" and risk != RISK_HIGH:
            continue  # CMDi only on high-risk params
        
        result[param] = values[0] if values else ""
    
    return result


# ── Semantic URL deduplication ─────────────────────────────────────────────────

_UUID_PATTERN    = re.compile(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', re.I)
_OBJECTID_PATTERN= re.compile(r'[0-9a-f]{24}', re.I)
_NUMERIC_PATTERN = re.compile(r'/\d+(?:/|$)')
_HASH_PATTERN    = re.compile(r'/[0-9a-f]{32,64}(?:/|$)', re.I)


def normalize_url(url: str) -> str:
    """
    Normalize URL for semantic deduplication.
    /users/123/posts/456 → /users/{id}/posts/{id}
    /items/550e8400-e29b → /items/{uuid}
    ?sort=asc&page=2&q=test → ?q=test (sort/page removed, params sorted)
    """
    try:
        parsed = urllib.parse.urlparse(url)
        path   = parsed.path
        
        # Replace UUIDs
        path = _UUID_PATTERN.sub('{uuid}', path)
        
        # Replace MongoDB ObjectIds (24 hex chars)
        path = _OBJECTID_PATTERN.sub('{oid}', path)
        
        # Replace hash-like segments
        path = _HASH_PATTERN.sub('/{hash}/', path)
        
        # Replace numeric path segments
        path = _NUMERIC_PATTERN.sub('/{id}/', path)
        
        # Normalize query params: remove skip params, sort rest
        if parsed.query:
            qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
            clean_qs = {k: v for k, v in qs.items() if k.lower() not in _SKIP_PARAMS}
            sorted_qs = urllib.parse.urlencode(sorted(clean_qs.items()), doseq=True)
        else:
            sorted_qs = ""
        
        # Rebuild
        return urllib.parse.urlunparse((
            parsed.scheme, parsed.netloc,
            path, parsed.params, sorted_qs, ""
        ))
    except Exception:
        return url


def deduplicate_endpoints(urls: List[str]) -> List[str]:
    """
    Deduplicate endpoints using semantic normalization.
    Keeps first occurrence of each normalized URL.
    Returns deduped list maintaining order.
    """
    seen_normalized: Set[str] = set()
    result: List[str] = []
    
    for url in urls:
        norm = normalize_url(url)
        if norm not in seen_normalized:
            seen_normalized.add(norm)
            result.append(url)
    
    return result


def score_endpoint_priority(url: str) -> int:
    """
    Score an endpoint's testing priority (higher = test first).
    Inspired by Lonkero's priority queue crawling.
    """
    path = urllib.parse.urlparse(url).path.lower()
    qs   = urllib.parse.urlparse(url).query
    score = 0
    
    # High-value paths
    HIGH_PATHS = ['/login', '/signin', '/register', '/signup', '/admin',
                  '/dashboard', '/graphql', '/api/graphql',
                  '/checkout', '/payment', '/cart', '/account', '/profile',
                  '/settings', '/forgot', '/reset', '/password',
                  '/oauth', '/auth', '/token', '/upload', '/import', '/export']
    
    MED_PATHS = ['/api/', '/v1/', '/v2/', '/v3/', '/search', '/filter',
                 '/users/', '/orders/', '/products/', '/items/',
                 '/admin/', '/manage/', '/backend/']
    
    LOW_PATHS = ['/blog/', '/news/', '/about/', '/static/', '/assets/', '/cdn/']
    
    for p in HIGH_PATHS:
        if path.startswith(p) or path == p:
            score += 50
            break
    
    for p in MED_PATHS:
        if p in path:
            score += 25
            break
    
    for p in LOW_PATHS:
        if p in path:
            score -= 30
            break
    
    # Parameters present
    if qs:
        param_count = qs.count('=')
        score += min(40, param_count * 10)
    
    # Dynamic path segments
    dynamic_segments = len(re.findall(r'/\d+|/[0-9a-f-]{8,}', path))
    score += min(30, dynamic_segments * 10)
    
    # Static file penalty
    if re.search(r'\.(css|js|png|jpg|gif|svg|ico|woff|ttf|map)($|\?)', path):
        score -= 80
    
    return score
