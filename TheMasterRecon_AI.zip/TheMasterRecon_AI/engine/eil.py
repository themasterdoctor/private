"""
engine/eil.py — Exploit Intelligence Layer

Wraps existing engine modules into a canonical interface:
  - Finding normalization (canonical object with id, dedup_key, method, param)
  - Validation plans (preconditions, safe requests, negative control)
  - Burp-ready raw HTTP artifacts
  - Relationship detection (wraps chain.py)
  - Report generation (wraps reporter.py + poc_generator.py)

All output follows the contract:
{
  "status":    "ok" | "error",
  "tool":      "eil",
  "data":      {...},
  "logs":      ["[eil] ..."]
}
"""

import hashlib, json, logging, re, time, urllib.parse
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("elite.eil")

# ── Finding normalization ─────────────────────────────────────────────────────

_NOISE_PARAMS = {
    "utm_source","utm_medium","utm_campaign","utm_content","utm_term",
    "_ga","_gid","fbclid","gclid","msclkid","ref","referrer",
    "ts","timestamp","_","rand","nocache","cb","cache","v","ver",
}

def normalize_url(url: str) -> str:
    """Strip noise/tracking params; lowercase host; sort remaining params."""
    if not url:
        return url
    try:
        p  = urllib.parse.urlparse(url)
        qs = urllib.parse.parse_qs(p.query, keep_blank_values=True)
        qs = {k: v for k, v in qs.items() if k.lower() not in _NOISE_PARAMS}
        # Normalize numeric IDs to sentinel so id=1 and id=2 dedup together
        qs = {k: [re.sub(r"^\d+$", "N", v[0])] for k, v in qs.items()}
        norm_query = urllib.parse.urlencode(
            dict(sorted(qs.items())), doseq=True
        )
        return urllib.parse.urlunparse(
            p._replace(netloc=p.netloc.lower(), query=norm_query)
        )
    except Exception:
        return url


def finding_id(finding: Dict) -> str:
    """SHA-256 dedup key → 16-char hex."""
    bug   = (finding.get("bug") or finding.get("bug_type") or "").lower()
    url   = normalize_url(finding.get("url",""))
    param = (finding.get("param") or "").lower()
    raw   = f"{bug}:{url}:{param}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def normalize_finding(finding: Dict) -> Dict:
    """
    Return a canonical finding object.

    Canonical fields:
      id, bug_type, url, method, param, evidence, confidence,
      source, severity, timestamp, dedup_key, meta
    """
    bug   = (finding.get("bug") or finding.get("bug_type") or "unknown").lower()
    url   = finding.get("url","")
    param = (finding.get("param") or "").lower()
    method = (finding.get("method") or "GET").upper()
    conf  = finding.get("confidence", finding.get("confidence_score", 70))
    if isinstance(conf, str):
        conf = {"high":90,"medium":70,"low":40}.get(conf.lower(), 70)

    conf_label = "high" if conf >= 80 else ("medium" if conf >= 50 else "low")

    norm = {
        "id":         finding_id(finding),
        "bug_type":   bug,
        "url":        url,
        "normalized_url": normalize_url(url),
        "method":     method,
        "param":      param,
        "evidence":   finding.get("evidence","") or finding.get("proof",""),
        "confidence": conf_label,
        "confidence_score": int(conf),
        "validated":  finding.get("confirmed", False),
        "source":     finding.get("source","scanner"),
        "severity":   (finding.get("severity") or "medium").lower(),
        "timestamp":  finding.get("timestamp","") or time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "dedup_key":  f"{bug}:{normalize_url(url)}:{param}",
        "meta": {
            k: v for k, v in finding.items()
            if k not in ("bug","bug_type","url","param","method","evidence",
                         "proof","confidence","confidence_score","confirmed",
                         "source","severity","timestamp")
        }
    }
    return norm


# ── Validation plans ─────────────────────────────────────────────────────────

def _safe_payload(bug: str) -> Tuple[str, List[str]]:
    """
    Return (probe_payload, expected_markers) — minimal safe probes only.
    No destructive payloads. No privilege escalation.
    """
    _plans = {
        "ssrf":     ("http://169.254.169.254/latest/meta-data/",
                     ["ami-id","instance-id","169.254"]),
        "sqli":     ("'",
                     ["syntax error","mysql_fetch","ORA-","SQLSTATE","near \\\"'"]),
        "lfi":      ("../../../etc/passwd",
                     ["root:","daemon:","nobody:"]),
        "xss":      ("<tmr-xss>",
                     ["<tmr-xss>"]),
        "ssti":     ("{{7*7}}",
                     ["49"]),
        "xxe":      ('<?xml version="1.0"?><!DOCTYPE t [<!ENTITY x "tmr-xxe">]><t>&x;</t>',
                     ["tmr-xxe"]),
        "cors":     ("https://tmr-cors-test.evil.com",
                     ["Access-Control-Allow-Origin"]),
        "redirect": ("https://evil.com",
                     ["evil.com","Location"]),
        "crlf":     ("%0d%0aX-TMR: injected",
                     ["X-TMR: injected","x-tmr: injected"]),
        "idor":     ("0",
                     []),   # IDOR requires manual diff comparison
    }
    payload, markers = _plans.get(bug, ("tmr-test", []))
    return payload, markers


def build_validation_plan(finding: Dict) -> Dict:
    """
    Build a structured ValidationPlan for a finding.
    No actual HTTP calls — just the plan structure.

    [eil] plan_generated bug=...
    """
    nf = normalize_finding(finding)
    bug   = nf["bug_type"]
    url   = nf["url"]
    param = nf["param"]
    method = nf["method"]

    payload, expected_markers = _safe_payload(bug)

    # Inject payload into URL or body depending on method/param
    if param and "?" in url:
        parsed = urllib.parse.urlparse(url)
        qs     = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        qs_inj = dict(qs)
        if param in qs_inj:
            qs_inj[param] = [payload]
        probe_url = urllib.parse.urlunparse(
            parsed._replace(
                query=urllib.parse.urlencode(qs_inj, doseq=True)
            )
        )
    else:
        sep = "&" if "?" in url else "?"
        probe_url = f"{url}{sep}{param or 'test'}={urllib.parse.quote(payload)}" if param else url

    # Negative control: send a benign value to confirm the behavior is payload-specific
    neg_url = url
    if param and "?" in url:
        parsed = urllib.parse.urlparse(url)
        qs     = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        qs_neg = dict(qs)
        if param in qs_neg:
            qs_neg[param] = ["tmr-benign-value-12345"]
        neg_url = urllib.parse.urlunparse(
            parsed._replace(
                query=urllib.parse.urlencode(qs_neg, doseq=True)
            )
        )

    plan = {
        "bug_type":      bug,
        "finding_id":    nf["id"],
        "url":           url,
        "param":         param,
        "preconditions": _preconditions(bug),
        "requests": [
            {
                "step":        1,
                "description": f"Baseline — confirm endpoint is reachable",
                "method":      method,
                "url":         url,
                "headers":     {"User-Agent": "BugScanELITE/2.0"},
                "body":        "",
                "expected":    {"status_lt": 500, "contains": []},
            },
            {
                "step":        2,
                "description": f"Probe — inject {bug} payload",
                "method":      method,
                "url":         probe_url,
                "headers":     {"User-Agent": "BugScanELITE/2.0"},
                "body":        "",
                "expected": {
                    "status_lt":    500,
                    "contains":     expected_markers,
                    "note":         "Response must contain at least one marker for confirmation",
                },
            },
        ],
        "negative_control": {
            "description": "Send benign value — markers must NOT appear",
            "method":      method,
            "url":         neg_url,
            "expected":    {"contains_none_of": expected_markers},
        },
        "notes": _validation_notes(bug),
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
    }

    log.info(f"[eil] plan_generated bug={bug} finding_id={nf['id']}")
    return plan


def _preconditions(bug: str) -> List[str]:
    _pre = {
        "ssrf":     ["Endpoint makes outbound HTTP requests",
                     "url/dest/redirect parameter accepts arbitrary URLs",
                     "Network allows outbound connections from server"],
        "sqli":     ["Endpoint accepts user input in parameter",
                     "Parameter value is passed to SQL query without sanitization"],
        "lfi":      ["Parameter controls file path",
                     "Server reads/includes files based on parameter value"],
        "xss":      ["Parameter value is reflected in HTML response",
                     "No output encoding applied to reflection point"],
        "ssti":     ["Template engine processes user input",
                     "Input is evaluated as template expression"],
        "cors":     ["Endpoint returns CORS headers",
                     "Origin header is reflected without validation"],
        "redirect": ["Parameter controls redirect destination",
                     "Redirect is performed server-side without allowlist check"],
        "crlf":     ["Parameter value injected into HTTP response header",
                     "No newline character filtering applied"],
        "idor":     ["Resource identifier in parameter controls data access",
                     "No object-level authorization check performed"],
    }
    return _pre.get(bug, [f"Endpoint processes user input via {bug} vector"])


def _validation_notes(bug: str) -> List[str]:
    _notes = {
        "ssrf":     ["Do NOT test against internal production services",
                     "169.254.169.254 is safe read-only metadata service",
                     "Confirm blind SSRF via OOB callback if no response"],
        "sqli":     ["Time-based: use SLEEP(5) only once per URL to avoid DoS",
                     "Error-based: check for DB-specific error strings",
                     "Do NOT modify, delete or insert data"],
        "lfi":      ["/etc/passwd is read-only — safe to read",
                     "Windows: try win.ini for cross-platform confirmation",
                     "Stop at file read — do not attempt RCE escalation"],
        "xss":      ["Use non-alarming marker like <tmr-xss> not <script>alert(1)>",
                     "Confirm reflection point in HTML source",
                     "Stored XSS: check that injection persists on reload"],
        "cors":     ["Check Access-Control-Allow-Origin: https://evil.com",
                     "Only valid if Access-Control-Allow-Credentials: true also present",
                     "Report as medium without credentials, high with credentials"],
        "idor":     ["Replace own user ID with another user's ID",
                     "Use two accounts if possible",
                     "Do NOT access data beyond confirming access is granted"],
    }
    return _notes.get(bug, ["Validate with minimal, read-only payloads only"])


# ── Raw HTTP artifact (Burp-ready) ────────────────────────────────────────────

def build_raw_http(finding: Dict) -> str:
    """
    Build a Burp-Suite-ready raw HTTP request string from a finding.
    Format: METHOD /path?query HTTP/1.1\r\nHost: ...\r\n\r\n[body]
    """
    nf     = normalize_finding(finding)
    url    = nf["url"]
    method = nf["method"]
    param  = nf["param"]

    try:
        parsed = urllib.parse.urlparse(url)
        host   = parsed.netloc or "target.example.com"
        path   = parsed.path or "/"
        query  = parsed.query
    except Exception:
        host, path, query = "target.example.com", "/", ""

    # For GET requests, params are in query string
    # For POST, move params to body
    body_str = ""
    if method in ("POST","PUT","PATCH") and param:
        payload, _ = _safe_payload(nf["bug_type"])
        body_str   = f"{param}={urllib.parse.quote(payload)}"
        request_line = f"{method} {path}{'?'+query if query else ''} HTTP/1.1"
        extra_headers = (
            f"Content-Type: application/x-www-form-urlencoded\r\n"
            f"Content-Length: {len(body_str)}\r\n"
        )
    else:
        request_line  = f"{method} {path}{'?'+query if query else ''} HTTP/1.1"
        extra_headers = ""

    raw = (
        f"{request_line}\r\n"
        f"Host: {host}\r\n"
        f"User-Agent: Mozilla/5.0 (BugScanELITE/2.0)\r\n"
        f"Accept: */*\r\n"
        f"{extra_headers}"
        f"Connection: close\r\n"
        f"\r\n"
        f"{body_str}"
    )
    return raw


def build_curl(finding: Dict) -> str:
    """
    Build a safe curl command from a finding.
    Wraps engine/poc_generator if available, otherwise builds directly.
    """
    nf  = normalize_finding(finding)
    url = nf["url"]
    method = nf["method"]
    param  = nf["param"]

    payload, _ = _safe_payload(nf["bug_type"])

    if method in ("POST","PUT","PATCH") and param:
        curl = (
            f"curl -i -X {method} '{url}' \\\n"
            f"  -H 'User-Agent: Mozilla/5.0' \\\n"
            f"  --data '{param}={urllib.parse.quote(payload)}'"
        )
    else:
        if param and "?" in url:
            parsed = urllib.parse.urlparse(url)
            qs     = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
            if param in qs:
                qs[param] = [payload]
            probe_url = urllib.parse.urlunparse(
                parsed._replace(query=urllib.parse.urlencode(qs, doseq=True))
            )
        else:
            sep = "&" if "?" in url else "?"
            probe_url = f"{url}{sep}{param}={urllib.parse.quote(payload)}" if param else url
        curl = (
            f"curl -i -sk -X {method} \\\n"
            f"  '{probe_url}' \\\n"
            f"  -H 'User-Agent: Mozilla/5.0'"
        )
    return curl


# ── Relationships ─────────────────────────────────────────────────────────────

def find_related(finding: Dict, all_findings: List[Dict]) -> Dict:
    """
    Find related findings: same param, same endpoint pattern, same bug type.
    Wraps engine/chain.py logic without building exploit chains.

    [eil] related_found count=N
    """
    nf     = normalize_finding(finding)
    bug    = nf["bug_type"]
    param  = nf["param"]
    host   = urllib.parse.urlparse(nf["url"]).netloc

    related = []
    shared_params  = []
    same_bug_other = []

    for f in all_findings:
        fid = finding_id(f)
        if fid == nf["id"]:
            continue
        f_bug   = (f.get("bug") or f.get("bug_type") or "").lower()
        f_param = (f.get("param") or "").lower()
        f_host  = urllib.parse.urlparse(f.get("url","")).netloc

        # Same param on same host → likely shared pattern
        if f_param and f_param == param and f_host == host:
            shared_params.append(f)

        # Same bug type → patterns across app
        if f_bug == bug and f_host == host:
            same_bug_other.append(f)

    related = list({finding_id(f): f
                    for f in shared_params + same_bug_other}.values())[:10]

    # Recommended follow-ups based on finding type
    followups = _recommended_followups(bug)

    log.info(f"[eil] related_found count={len(related)} bug={bug}")
    return {
        "finding_id":          nf["id"],
        "bug_type":            bug,
        "related_findings":    [normalize_finding(f) for f in related],
        "shared_surface":      f"Same parameter '{param}' appears across {len(shared_params)} endpoints" if shared_params else "",
        "same_bug_count":      len(same_bug_other),
        "recommended_followups": followups,
    }


def _recommended_followups(bug: str) -> List[str]:
    _fu = {
        "ssrf":  ["Test all url/dest/redirect params on this host",
                  "Try blind SSRF with OOB callback (interactsh)",
                  "Check cloud metadata: 169.254.169.254, metadata.google.internal"],
        "sqli":  ["Test all id/user/page params on this host",
                  "Try UNION SELECT to enumerate tables (read-only)",
                  "Check for second-order SQLi in stored values"],
        "lfi":   ["Check if RFI is possible (http://evil.com/shell.php)",
                  "Try log poisoning via User-Agent if logs are readable",
                  "Look for /proc/self/environ, /proc/self/fd/*"],
        "xss":   ["Test stored variant: submit payload, revisit page",
                  "Check DOM XSS: look for document.write, innerHTML sinks",
                  "Test CSP bypass if Content-Security-Policy header present"],
        "idor":  ["Enumerate IDs ±1 to find adjacent records",
                  "Test with UUID-format IDs if integer IDs are not present",
                  "Check mass assignment: send extra fields in POST body"],
        "cors":  ["Verify Access-Control-Allow-Credentials: true",
                  "Check if null origin is accepted: Origin: null",
                  "Test preflight OPTIONS request behavior"],
        "redirect": ["Test for OAuth redirect_uri bypass",
                     "Try URL encoding: https:%2F%2Fevil.com",
                     "Check for host-only matching: https://evil.com.target.com"],
    }
    return _fu.get(bug, [f"Test other {bug} vectors on nearby endpoints"])


# ── Impact analysis ────────────────────────────────────────────────────────────

def analyze_impact(finding: Dict) -> Dict:
    """
    Produce grounded impact analysis based on observed behavior.
    No exaggeration — tied to evidence.
    """
    nf  = normalize_finding(finding)
    bug = nf["bug_type"]
    sev = nf["severity"]
    ev  = nf["evidence"]

    _impacts = {
        "ssrf": {
            "summary": "Server-side request forgery allows reading internal resources",
            "business_risk": "Credential theft (AWS IAM), internal service access, IMDS exploitation",
            "data_at_risk": ["Cloud credentials (AWS/GCP/Azure IAM keys)",
                             "Internal network topology",
                             "Other microservice APIs"],
            "conditions_required": ["Server makes outbound HTTP requests",
                                    "Response reflects fetched content or behavior changes"],
            "severity_hint": "critical" if "ami-id" in ev or "iam" in ev.lower() else "high",
            "rationale": "SSRF to cloud metadata exposes IAM credentials directly",
        },
        "sqli": {
            "summary": "SQL injection allows unauthorized database access",
            "business_risk": "Full database read/write, authentication bypass, potential RCE",
            "data_at_risk": ["All database tables", "User credentials (if stored)",
                             "PII and business data"],
            "conditions_required": ["Parameter is not parameterized/sanitized",
                                    "Error messages or timing confirm injection"],
            "severity_hint": "critical",
            "rationale": "SQL injection is consistently critical due to full DB access potential",
        },
        "lfi": {
            "summary": "Local file inclusion allows reading server filesystem",
            "business_risk": "Source code disclosure, credential exposure, potential RCE via log poisoning",
            "data_at_risk": ["Application source code", "Configuration files with credentials",
                             "/etc/passwd, SSH keys"],
            "conditions_required": ["Server reads files based on user parameter",
                                    "Path traversal sequences not filtered"],
            "severity_hint": "high",
            "rationale": "LFI commonly leads to credential disclosure and RCE escalation",
        },
        "xss": {
            "summary": "Cross-site scripting allows injecting arbitrary JavaScript",
            "business_risk": "Session hijacking, credential theft, defacement",
            "data_at_risk": ["Session cookies", "CSRF tokens", "Stored credentials in browser"],
            "conditions_required": ["User input reflected in HTML without encoding",
                                    "Victim visits the crafted URL or stored payload executes"],
            "severity_hint": "medium" if "reflected" in ev.lower() else "high",
            "rationale": "Reflected XSS is medium; stored XSS affecting many users is high",
        },
        "cors": {
            "summary": "Misconfigured CORS allows cross-origin API access",
            "business_risk": "Account takeover if authenticated endpoints are affected",
            "data_at_risk": ["API responses", "User data if credentials are included"],
            "conditions_required": ["Access-Control-Allow-Credentials: true",
                                    "Origin reflected without validation"],
            "severity_hint": "high" if "credentials" in ev.lower() else "medium",
            "rationale": "CORS without credentials is medium; with credentials is high",
        },
        "idor": {
            "summary": "Insecure direct object reference allows accessing other users' resources",
            "business_risk": "Horizontal privilege escalation, data breach",
            "data_at_risk": ["Other users' private data", "Account details", "Files/documents"],
            "conditions_required": ["Object identifier (id, uuid) in parameter",
                                    "No authorization check for object ownership"],
            "severity_hint": "high",
            "rationale": "IDOR affecting personal data is typically high severity",
        },
    }

    result = _impacts.get(bug, {
        "summary": f"{bug.upper()} vulnerability observed",
        "business_risk": "Security vulnerability with potential data exposure",
        "data_at_risk": ["Application data"],
        "conditions_required": ["Vulnerability confirmed via testing"],
        "severity_hint": sev,
        "rationale": f"Severity assigned based on {bug} class and observed evidence",
    })

    result["bug_type"]   = bug
    result["finding_id"] = nf["id"]
    result["evidence"]   = ev[:200]
    return result


# ── Full EIL bundle ────────────────────────────────────────────────────────────

def eil_bundle(finding: Dict, all_findings: List[Dict] = None) -> Dict:
    """
    Build the complete EIL bundle for one finding:
      - normalized finding
      - validation plan
      - raw HTTP + curl artifacts
      - impact analysis
      - related findings

    Wraps existing poc_generator.generate_poc() and reporter.generate_h1_report()
    for PoC and report generation.

    Logs: [eil] bundle_ready id=...
    """
    logs = []

    nf = normalize_finding(finding)
    logs.append(f"[eil] normalizing finding id={nf['id']} bug={nf['bug_type']}")

    plan = build_validation_plan(finding)
    logs.append(f"[eil] plan_generated bug={nf['bug_type']}")

    raw_http = build_raw_http(finding)
    curl     = build_curl(finding)
    logs.append(f"[eil] artifacts_built curl={len(curl)}chars raw_http={len(raw_http)}chars")

    impact = analyze_impact(finding)
    logs.append(f"[eil] impact_analyzed severity_hint={impact.get('severity_hint')}")

    related_data: Dict = {}
    if all_findings:
        related_data = find_related(finding, all_findings)
        logs.append(f"[eil] related_found count={len(related_data.get('related_findings',[]))}")

    # Generate PoC via existing poc_generator
    poc: Dict = {}
    try:
        from engine.poc_generator import generate_poc
        poc = generate_poc(finding)
        logs.append(f"[eil] poc_generated tool=poc_generator")
    except Exception as e:
        logs.append(f"[eil] poc_generator failed: {e}")

    # Generate report via existing reporter
    report_md = ""
    try:
        from engine.reporter import generate_h1_report
        domain = urllib.parse.urlparse(finding.get("url","")).netloc or "target"
        report_md = generate_h1_report(finding, domain)
        logs.append(f"[eil] report_ready id={nf['id']}")
    except Exception as e:
        logs.append(f"[eil] reporter failed: {e}")

    bundle = {
        "finding":         nf,
        "validation_plan": plan,
        "artifacts": {
            "curl":     curl,
            "raw_http": raw_http,
            "python":   poc.get("python_script",""),
        },
        "impact":    impact,
        "related":   related_data,
        "report_md": report_md,
        "poc":       poc,
    }

    log.info(f"[eil] bundle_ready id={nf['id']} bug={nf['bug_type']}")
    return {
        "status": "ok",
        "tool":   "eil",
        "data":   bundle,
        "logs":   logs,
    }
