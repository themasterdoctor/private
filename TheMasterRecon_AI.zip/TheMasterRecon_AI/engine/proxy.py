"""
TheMasterRecon AI — HTTP Intercepting Proxy
mitmproxy-style request interception, modification, and history.
Runs as a local HTTPS proxy that the user configures their browser to use.
"""
import os, ssl, socket, threading, logging, json, time, re, gzip
import urllib.request, urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from http.client import HTTPConnection, HTTPSConnection
from pathlib import Path
from typing import List, Optional, Dict

log = logging.getLogger("elite.proxy")

# ── In-memory request history ─────────────────────────────────────────────────
_history: List[dict] = []
_history_lock         = threading.Lock()
_intercept_rules: List[dict] = []  # rules to match requests for interception
_intercept_queue: List[dict] = []  # requests waiting for user action
_max_history       = 2000
_proxy_running     = False
_proxy_port        = int(os.environ.get("TMR_PROXY_PORT", "8082"))


def add_to_history(entry: dict):
    with _history_lock:
        _history.append(entry)
        if len(_history) > _max_history:
            _history.pop(0)


def get_history(domain_filter: str = "", method_filter: str = "",
                status_filter: str = "", limit: int = 500) -> List[dict]:
    with _history_lock:
        items = list(reversed(_history))
    if domain_filter:
        items = [i for i in items if domain_filter.lower() in i.get("host","").lower()]
    if method_filter:
        items = [i for i in items if i.get("method","") == method_filter.upper()]
    if status_filter:
        try:
            sc = int(status_filter)
            items = [i for i in items if str(i.get("status","")).startswith(str(sc//100))]
        except ValueError:
            pass
    return items[:limit]


def clear_history():
    with _history_lock:
        _history.clear()


# ── Intercept rules ───────────────────────────────────────────────────────────
def add_intercept_rule(rule: dict) -> dict:
    """Add a rule to intercept matching requests."""
    rule["id"]   = f"rule_{int(time.time()*1000)}"
    rule["hits"] = 0
    _intercept_rules.append(rule)
    return rule


def matches_rule(rule: dict, host: str, path: str, method: str) -> bool:
    if rule.get("host_pattern"):
        if not re.search(rule["host_pattern"], host, re.I):
            return False
    if rule.get("path_pattern"):
        if not re.search(rule["path_pattern"], path, re.I):
            return False
    if rule.get("method") and rule["method"] != method:
        return False
    return True


# ── Proxy request handler ─────────────────────────────────────────────────────
class ProxyHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args): pass  # suppress default logging

    def _ssl_ctx(self):
        c = ssl.create_default_context()
        c.check_hostname = False
        c.verify_mode    = ssl.CERT_NONE
        return c

    def do_CONNECT(self):
        """Handle HTTPS CONNECT tunneling."""
        host, _, port = self.path.partition(":")
        port = int(port) if port else 443
        try:
            remote = socket.create_connection((host, port), timeout=10)
            self.send_response(200, "Connection Established")
            self.end_headers()
            # Simple tunnel (no interception for HTTPS in basic mode)
            self._tunnel(remote)
        except Exception as e:
            self.send_error(502, str(e))

    def _tunnel(self, remote):
        """Bidirectional tunnel."""
        import select
        client = self.connection
        client.setblocking(False)
        remote.setblocking(False)
        while True:
            try:
                r, _, _ = select.select([client, remote], [], [], 10)
                if not r: break
                for s in r:
                    try:
                        data = s.recv(65536)
                        if not data:
                            return
                        (remote if s is client else client).send(data)
                    except Exception:
                        return
            except Exception:
                break

    def do_GET(self):    self._handle_request("GET")
    def do_POST(self):   self._handle_request("POST")
    def do_PUT(self):    self._handle_request("PUT")
    def do_DELETE(self): self._handle_request("DELETE")
    def do_PATCH(self):  self._handle_request("PATCH")
    def do_OPTIONS(self):self._handle_request("OPTIONS")
    def do_HEAD(self):   self._handle_request("HEAD")

    def _handle_request(self, method: str):
        url     = self.path
        parsed  = urllib.parse.urlparse(url)
        host    = parsed.netloc or self.headers.get("Host","")
        path    = parsed.path + ("?"+parsed.query if parsed.query else "")
        scheme  = parsed.scheme or "http"

        # Read request body
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length) if content_length else b""

        # Build request headers
        req_headers = {k: v for k, v in self.headers.items()
                       if k.lower() not in ("proxy-connection","proxy-authorization")}

        start_ts = time.time()
        entry = {
            "id":          f"r_{int(start_ts*1000)}",
            "ts":          time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "method":      method,
            "url":         url,
            "host":        host.split(":")[0],
            "path":        path,
            "scheme":      scheme,
            "req_headers": dict(req_headers),
            "req_body":    body.decode("utf-8","replace")[:5000],
            "status":      0,
            "resp_headers":{},
            "resp_body":   "",
            "elapsed_ms":  0,
            "flagged":     False,
            "notes":       "",
        }

        # Check intercept rules
        for rule in _intercept_rules:
            if matches_rule(rule, host, path, method):
                rule["hits"] += 1
                entry["flagged"] = True
                entry["matched_rule"] = rule.get("id","")

        try:
            # Forward request
            conn_host = parsed.hostname or host.split(":")[0]
            conn_port = parsed.port or (443 if scheme=="https" else 80)

            if scheme == "https":
                conn = HTTPSConnection(conn_host, conn_port, context=self._ssl_ctx(), timeout=30)
            else:
                conn = HTTPConnection(conn_host, conn_port, timeout=30)

            conn.request(method, path or "/", body, req_headers)
            resp = conn.getresponse()

            resp_body  = resp.read()
            elapsed_ms = round((time.time() - start_ts) * 1000)

            # Decode gzip if needed
            if resp.getheader("Content-Encoding","") == "gzip":
                try: resp_body = gzip.decompress(resp_body)
                except Exception: pass

            resp_body_str = resp_body.decode("utf-8","replace")

            entry.update({
                "status":       resp.status,
                "resp_headers": dict(resp.getheaders()),
                "resp_body":    resp_body_str[:50000],
                "elapsed_ms":   elapsed_ms,
            })

            # Auto-flag interesting responses
            if not entry["flagged"]:
                if any(x in resp_body_str.lower() for x in
                       ["token","secret","api_key","password","credential","private"]):
                    entry["flagged"] = True
                    entry["notes"]   = "Contains potential secrets"

            # Send response back to client
            self.send_response(resp.status)
            for hdr, val in resp.getheaders():
                if hdr.lower() not in ("transfer-encoding",):
                    self.send_header(hdr, val)
            self.end_headers()
            self.wfile.write(resp_body)

        except Exception as e:
            entry["error"] = str(e)
            self.send_error(502, str(e))

        add_to_history(entry)


# ── Proxy server lifecycle ────────────────────────────────────────────────────
_proxy_server: Optional[HTTPServer] = None
_proxy_thread:  Optional[threading.Thread] = None


def start_proxy(port: int = None) -> dict:
    global _proxy_server, _proxy_thread, _proxy_running, _proxy_port
    if _proxy_running:
        return {"running": True, "port": _proxy_port}

    port = port or _proxy_port
    try:
        _proxy_server  = HTTPServer(("0.0.0.0", port), ProxyHandler)
        _proxy_server.timeout = 1
        _proxy_thread  = threading.Thread(target=_proxy_server.serve_forever, daemon=True)
        _proxy_thread.start()
        _proxy_running = True
        _proxy_port    = port
        log.info(f"[proxy] HTTP proxy started on port {port}")
        return {"running": True, "port": port,
                "configure": f"Set browser proxy to 127.0.0.1:{port}"}
    except Exception as e:
        log.error(f"[proxy] Failed to start: {e}")
        return {"running": False, "error": str(e)}


def stop_proxy():
    global _proxy_server, _proxy_running
    if _proxy_server:
        _proxy_server.shutdown()
        _proxy_server = None
    _proxy_running = False
    log.info("[proxy] Proxy stopped")


def get_proxy_status() -> dict:
    return {
        "running":  _proxy_running,
        "port":     _proxy_port,
        "history":  len(_history),
        "rules":    len(_intercept_rules),
        "queued":   len(_intercept_queue),
    }


# Thread-safe captured requests store
import threading as _threading
_captured_reqs  = []
_captured_lock  = _threading.Lock()
_intercept_queue = []
_intercept_lock  = _threading.Lock()

def get_captured(limit: int = 200, domain_filter: str = "") -> list:
    """Return list of captured HTTP requests."""
    with _captured_lock:
        items = list(_captured_reqs[-limit:])
    if domain_filter:
        items = [r for r in items if domain_filter in r.get("url","")]
    return items

def get_intercepted() -> list:
    """Return requests currently held for manual forwarding."""
    with _intercept_lock:
        return list(_intercept_queue)

def forward_request(req_id: str, modified_body: str = None,
                    modified_headers: dict = None) -> dict:
    """Forward an intercepted request (optionally with modifications)."""
    import ssl, urllib.request
    with _intercept_lock:
        req = next((r for r in _intercept_queue if r.get("id") == req_id), None)
        if req:
            _intercept_queue.remove(req)

    if not req:
        return {"error": f"Request {req_id} not found in intercept queue"}

    try:
        url      = req.get("url","")
        method   = req.get("method","GET")
        headers  = modified_headers or req.get("headers",{})
        body     = (modified_body or req.get("body","")).encode() if modified_body or req.get("body") else None

        ctx = ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        http_req = urllib.request.Request(url, data=body, headers=headers, method=method)

        with urllib.request.urlopen(http_req, timeout=30, context=ctx) as r:
            resp_body = r.read().decode("utf-8","ignore")
            return {
                "ok":      True,
                "status":  r.status,
                "headers": dict(r.headers),
                "body":    resp_body[:50000],
            }
    except Exception as e:
        return {"error": str(e)}

def get_stats() -> dict:
    """Return proxy statistics."""
    hist = get_history("") if callable(get_history) else []
    with _captured_lock:
        captured = len(_captured_reqs)
    return {
        "history_count":    len(hist),
        "captured_count":   captured,
        "intercepted_count": len(_intercept_queue),
        "proxy_status":     get_proxy_status(),
    }

def add_captured(method: str, url: str, headers: dict = None,
                 body: str = "", status: int = 0,
                 response_body: str = "") -> None:
    """Add a request/response pair to captured store."""
    import secrets as _sec, time as _t
    entry = {
        "id":       _sec.token_hex(6),
        "ts":       _t.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "method":   method,
        "url":      url,
        "headers":  headers or {},
        "body":     body[:10000],
        "status":   status,
        "response": response_body[:10000],
    }
    with _captured_lock:
        _captured_reqs.append(entry)
        if len(_captured_reqs) > 2000:
            _captured_reqs.pop(0)
