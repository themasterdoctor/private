"""
engine/elite_recon.py — Elite Recon + Validation Orchestration

Wires together:
  surface_intel → classify / score
  detect_api_chains → chain hypotheses
  generate_test_plan → safe test plans
  nuclei routing → tag-selected templates per surface category
  bounty_db → report pipeline status

HARD RULES (enforced here, not just documented):
  - No auto-exploitation
  - No credential theft
  - No persistence
  - No destructive payloads
  - Safe test plans only
  - Human approval required before any submission
"""

import logging
from typing import Dict, List, Tuple, Optional

log = logging.getLogger("elite.recon")

# ── Surface → nuclei tag mapping ──────────────────────────────────────────────
# Carefully curated — no RCE/destructive templates by default

SURFACE_NUCLEI_TAGS: Dict[str, Dict] = {
    "api": {
        "tags":        ["api","sqli","ssrf","auth-bypass","idor","exposure","misconfiguration"],
        "severity":    ["medium","high","critical"],
        "description": "API endpoint — SQLi, SSRF, auth bypass, exposure",
        "max_templates": 150,
    },
    "auth": {
        "tags":        ["auth-bypass","default-login","token","session","exposure"],
        "severity":    ["medium","high","critical"],
        "description": "Auth / Login — bypass, default credentials, token issues",
        "max_templates": 80,
    },
    "admin": {
        "tags":        ["panel","auth-bypass","default-login","exposure","misconfiguration"],
        "severity":    ["medium","high","critical"],
        "description": "Admin panel — exposure, default creds, bypass",
        "max_templates": 80,
    },
    "upload": {
        "tags":        ["file-upload","ssrf","exposure","misconfiguration"],
        "severity":    ["medium","high","critical"],
        "description": "File upload — unrestricted upload, SSRF via file, exposure",
        "max_templates": 60,
    },
    "graphql": {
        "tags":        ["graphql","misconfiguration","exposure"],
        "severity":    ["low","medium","high"],
        "description": "GraphQL — introspection open, misconfiguration",
        "max_templates": 30,
    },
    "oauth_cb": {
        "tags":        ["redirect","oauth","token","exposure"],
        "severity":    ["medium","high","critical"],
        "description": "OAuth / OIDC — open redirect, token exposure",
        "max_templates": 40,
    },
    "cloud": {
        "tags":        ["cloud","s3","bucket","exposure","secrets","takeover"],
        "severity":    ["medium","high","critical"],
        "description": "Cloud / storage — bucket exposure, secrets, takeover",
        "max_templates": 80,
    },
    "payment": {
        "tags":        ["exposure","misconfiguration","auth-bypass","idor"],
        "severity":    ["medium","high","critical"],
        "description": "Payment / billing — exposure, IDOR, bypass",
        "max_templates": 50,
    },
    "swagger": {
        "tags":        ["exposure","misconfiguration","api"],
        "severity":    ["low","medium","high"],
        "description": "Swagger / OpenAPI — exposed docs, sensitive info",
        "max_templates": 40,
    },
    "webhook": {
        "tags":        ["ssrf","exposure","misconfiguration"],
        "severity":    ["medium","high","critical"],
        "description": "Webhook — SSRF via callback URL, exposure",
        "max_templates": 40,
    },
    "debug": {
        "tags":        ["exposure","misconfiguration","debug"],
        "severity":    ["low","medium","high"],
        "description": "Debug / dev endpoints — info disclosure, actuator exposure",
        "max_templates": 50,
    },
    "internal": {
        "tags":        ["exposure","misconfiguration","takeover"],
        "severity":    ["medium","high","critical"],
        "description": "Internal / staging — exposure, takeover candidates",
        "max_templates": 60,
    },
}

# Default fallback when surface category not in map
_DEFAULT_TAGS = {
    "tags":     ["exposure","misconfiguration"],
    "severity": ["medium","high","critical"],
    "description": "Generic — exposure, misconfiguration",
    "max_templates": 40,
}

# Chain → bug hypothesis mapping (safe, no exploit)
_CHAIN_HYPOTHESES = [
    {
        "trigger_surface": "swagger",
        "chained_to":      "api",
        "hypothesis":      "Exposed API docs → enumerate undocumented endpoints → IDOR test",
        "safe_steps": [
            "1. Download the Swagger/OpenAPI spec",
            "2. Extract all paths, especially hidden/admin ones",
            "3. For each ID-bearing path, run the IDOR comparison test plan",
        ],
        "expected_finding": "IDOR/BOLA on documented API endpoints",
    },
    {
        "trigger_surface": "oauth_cb",
        "chained_to":      "auth",
        "hypothesis":      "OAuth callback endpoint → open redirect → token theft potential",
        "safe_steps": [
            "1. Find redirect_uri parameter in the OAuth flow",
            "2. Test for open redirect by modifying the URI",
            "3. Check state parameter for CSRF protection",
        ],
        "expected_finding": "Open redirect enabling OAuth token theft",
    },
    {
        "trigger_surface": "upload",
        "chained_to":      "api",
        "hypothesis":      "Upload endpoint → path traversal in filename → SSRF via URL import",
        "safe_steps": [
            "1. Test filename field for path traversal: ../../../etc/passwd",
            "2. If URL import exists, test with http://169.254.169.254/",
            "3. Check if uploaded content is served from same origin",
        ],
        "expected_finding": "Path traversal or SSRF via file upload",
    },
    {
        "trigger_surface": "webhook",
        "chained_to":      "cloud",
        "hypothesis":      "Webhook URL → SSRF → cloud metadata → credentials",
        "safe_steps": [
            "1. Register webhook with OOB URL (Burp Collaborator / interactsh)",
            "2. Try internal addresses: 169.254.169.254, localhost, 10.0.0.1",
            "3. If DNS hit observed, attempt to read cloud metadata path",
        ],
        "expected_finding": "SSRF to cloud metadata service",
    },
    {
        "trigger_surface": "admin",
        "chained_to":      "auth",
        "hypothesis":      "Admin panel → missing auth → access control review",
        "safe_steps": [
            "1. Visit admin panel without authentication cookie",
            "2. Try common default credentials: admin/admin, admin/password",
            "3. Test with a regular user token — check if admin API responds",
        ],
        "expected_finding": "Exposed admin panel or broken access control",
    },
    {
        "trigger_surface": "graphql",
        "chained_to":      "api",
        "hypothesis":      "GraphQL introspection open → object enumeration → IDOR on mutations",
        "safe_steps": [
            "1. Run introspection query to get all types and mutations",
            "2. Identify mutations that accept resource IDs",
            "3. Test IDOR on those mutations with another user's ID",
        ],
        "expected_finding": "IDOR via GraphQL mutation with open introspection",
    },
    {
        "trigger_surface": "internal",
        "chained_to":      "debug",
        "hypothesis":      "Staging/dev environment → weaker auth → debug endpoints exposed",
        "safe_steps": [
            "1. Check staging host for /debug, /.env, /actuator, /healthz",
            "2. Test if admin features are gated the same as production",
            "3. Look for verbose error messages and stack traces",
        ],
        "expected_finding": "Debug/dev environment with weaker security posture",
    },
]

# Tool recommendation by surface + score
def _recommend_tools(surfaces: List[str], score: int) -> List[str]:
    tools = ["manual"]   # always recommend manual review
    if score >= 9:
        tools = ["nuclei", "eil", "manual"]
    elif score >= 7:
        tools = ["nuclei", "manual"]
    if "graphql" in surfaces:
        tools = list(dict.fromkeys(["graphql_probe"] + tools))
    if "swagger" in surfaces:
        tools = list(dict.fromkeys(["swagger_review"] + tools))
    if "upload" in surfaces:
        tools = list(dict.fromkeys(["upload_test"] + tools))
    return tools


# ── Phase 1 — Unified target priority ────────────────────────────────────────

def rank_targets(surface_map: Dict, api_chains: Dict,
                 findings: List[Dict] = None) -> List[Dict]:
    """
    Produce a unified, scored priority list from surface map + chain data.
    Returns targets sorted by score desc, annotated with recommended tools.

    Logs: [elite] targets_ranked=N
    """
    findings  = findings or []
    confirmed = {f.get("url","") for f in findings if f.get("eil_confirmed")}
    targets: List[Dict] = []

    # From high-value endpoints
    for ep in surface_map.get("high_value_endpoints", []):
        url    = ep["url"]
        surfs  = ep.get("surfaces", [])
        score  = ep.get("score", 1)
        bugs   = _infer_bugs(surfs, ep.get("access_control_candidate", False))
        tools  = _recommend_tools(surfs, score)
        targets.append({
            "url":                url,
            "score":              score,
            "surface":            surfs,
            "likely_bugs":        bugs,
            "recommended_tools":  tools,
            "access_control":     ep.get("access_control_candidate", False),
            "already_confirmed":  url in confirmed,
            "priority":           "critical" if score >= 10 else
                                  "high"     if score >= 8  else
                                  "medium"   if score >= 5  else "low",
        })

    # Boost targets that appear in API chains
    chain_urls: set = set()
    for ch in api_chains.get("candidate_chains", []):
        for ep_url in ch.get("endpoints", []):
            chain_urls.add(ep_url)
    for t in targets:
        if t["url"] in chain_urls:
            t["score"]   = min(10, t["score"] + 1)
            if "IDOR/BOLA" not in t["likely_bugs"]:
                t["likely_bugs"].insert(0, "IDOR/BOLA")

    targets.sort(key=lambda x: (-x["score"], x["url"]))
    log.info(f"[elite] targets_ranked={len(targets)}")
    return targets[:200]


def _infer_bugs(surfaces: List[str],
                access_control: bool = False) -> List[str]:
    bugs: List[str] = []
    if "auth"     in surfaces: bugs += ["Auth Bypass","Password Reset Flaw"]
    if "admin"    in surfaces: bugs += ["Admin Exposure","Broken Access Control"]
    if "api"      in surfaces: bugs += ["IDOR","BOLA","Mass Assignment"]
    if "upload"   in surfaces: bugs += ["Unrestricted Upload","Path Traversal"]
    if "graphql"  in surfaces: bugs += ["GraphQL Introspection","Schema Leak"]
    if "webhook"  in surfaces: bugs += ["SSRF","Webhook Forgery"]
    if "oauth_cb" in surfaces: bugs += ["Open Redirect","OAuth Token Theft"]
    if "payment"  in surfaces: bugs += ["Billing IDOR","Price Manipulation"]
    if "swagger"  in surfaces: bugs += ["API Enumeration","Unauthenticated Access"]
    if "cloud"    in surfaces: bugs += ["Bucket Exposure","Secret Leak"]
    if "internal" in surfaces: bugs += ["Staging Exposure","Weaker Auth"]
    if "debug"    in surfaces: bugs += ["Debug Endpoint","Info Disclosure"]
    if access_control:
        bugs = list(dict.fromkeys(["Horizontal Priv Esc"] + bugs))
    return list(dict.fromkeys(bugs))[:6]


# ── Phase 3 — Nuclei router ──────────────────────────────────────────────────

def build_nuclei_plan(targets: List[Dict],
                      live_hosts: List[str]) -> Dict:
    """
    Group targets by surface category and assign nuclei tag sets.
    Returns grouped target lists + tag configs — nothing is executed here.

    Logs: [elite] nuclei_group {surface} targets=N tags=...
    """
    groups: Dict[str, Dict] = {}

    for t in targets:
        surfs = t.get("surface", ["generic"])
        score = t.get("score", 1)
        if score < 5:
            continue   # low-priority — passive only
        for surf in surfs:
            cfg = SURFACE_NUCLEI_TAGS.get(surf, _DEFAULT_TAGS)
            if surf not in groups:
                groups[surf] = {
                    "surface":      surf,
                    "description":  cfg["description"],
                    "tags":         cfg["tags"],
                    "severity":     cfg["severity"],
                    "max_templates": cfg["max_templates"],
                    "targets":      [],
                }
            if t["url"] not in groups[surf]["targets"]:
                groups[surf]["targets"].append(t["url"])

    # Also add bare hosts for host-level templates
    for h in live_hosts[:50]:
        for surf in ["debug","internal","cloud"]:
            if surf in groups:
                if h not in groups[surf]["targets"]:
                    groups[surf]["targets"].append(h)

    for surf, grp in groups.items():
        log.info(
            f"[elite] nuclei_group {surf}"
            f" targets={len(grp['targets'])}"
            f" tags={','.join(grp['tags'][:4])}"
        )

    total_targets = sum(len(g["targets"]) for g in groups.values())
    return {
        "groups":        groups,
        "total_groups":  len(groups),
        "total_targets": total_targets,
        "note": (
            "Templates are tag-filtered to exposure/misconfiguration/auth-bypass. "
            "No destructive templates. Run nuclei with these tags and target files."
        ),
    }


# ── Phase 5 — Bug chain suggestions ──────────────────────────────────────────

def build_chain_suggestions(surface_counts: Dict[str, int],
                             api_chains: Dict) -> List[Dict]:
    """
    Generate safe chain hypotheses based on observed surfaces.
    Returns only hypotheses where the trigger surface was observed.

    Logs: [elite] chain_suggestions=N
    """
    observed   = set(surface_counts.keys())
    suggestions: List[Dict] = []

    for hyp in _CHAIN_HYPOTHESES:
        trig   = hyp["trigger_surface"]
        chained = hyp["chained_to"]
        if trig in observed:
            count = surface_counts.get(trig, 0)
            suggestions.append({
                "trigger_surface":  trig,
                "chained_to":       chained,
                "both_present":     chained in observed,
                "hypothesis":       hyp["hypothesis"],
                "safe_steps":       hyp["safe_steps"],
                "expected_finding": hyp["expected_finding"],
                "trigger_endpoint_count": count,
                "risk":             "high" if count >= 3 else "medium",
                "safe":             True,
                "auto_exploit":     False,
            })

    # Add chain suggestions from API chain candidates
    for ch in api_chains.get("candidate_chains", [])[:5]:
        suggestions.append({
            "trigger_surface":  "api",
            "chained_to":       ch["object"],
            "both_present":     True,
            "hypothesis":       f"Multiple /{ch['object']}/{{id}} endpoints → IDOR chain",
            "safe_steps": [
                f"1. Collect all endpoints matching {ch['template']}",
                "2. Authenticate as User A, fetch each endpoint",
                "3. Replace ID with User B's known ID",
                "4. Check if cross-account data is returned",
            ],
            "expected_finding": f"IDOR on {ch['object']} resource",
            "trigger_endpoint_count": ch["endpoint_count"],
            "risk":        ch.get("risk","high"),
            "safe":        True,
            "auto_exploit": False,
        })

    suggestions.sort(key=lambda x: (
        -{"high":2,"medium":1,"low":0}.get(x["risk"],0),
        -x["trigger_endpoint_count"]
    ))
    log.info(f"[elite] chain_suggestions={len(suggestions)}")
    return suggestions[:20]


# ── Phase 6 — Debug summary ───────────────────────────────────────────────────

def build_debug_summary(domain: str, targets: List[Dict],
                         nuclei_plan: Dict, test_plan: Dict,
                         chain_suggestions: List[Dict],
                         findings: List[Dict],
                         bounty_reports: List[Dict]) -> Dict:
    """Build the /elite/debug summary object."""
    confirmed  = [f for f in findings if f.get("eil_confirmed")]
    rfr_count  = sum(1 for r in bounty_reports
                     if r.get("status") == "ready_for_review")
    approved   = sum(1 for r in bounty_reports if r.get("status") == "approved")

    by_priority = {"critical":0,"high":0,"medium":0,"low":0}
    for t in targets:
        p = t.get("priority","low")
        by_priority[p] = by_priority.get(p,0) + 1

    nuclei_groups_summary = {
        surf: {
            "targets": len(grp["targets"]),
            "tags":    grp["tags"][:4],
        }
        for surf, grp in nuclei_plan.get("groups",{}).items()
    }

    log.info(f"[elite] targets_ranked={len(targets)}")
    log.info(f"[elite] test_plans={test_plan.get('test_plan_count',0)}")
    log.info(f"[elite] chain_suggestions={len(chain_suggestions)}")
    log.info(f"[elite] reports_ready={rfr_count}")

    return {
        "domain":                    domain,
        "elite_loaded":              True,
        "high_value_targets":        len(targets),
        "targets_by_priority":       by_priority,
        "nuclei_groups":             nuclei_groups_summary,
        "nuclei_total_target_files": nuclei_plan.get("total_targets",0),
        "safe_test_plans":           test_plan.get("test_plan_count",0),
        "chain_suggestions":         len(chain_suggestions),
        "confirmed_findings":        len(confirmed),
        "total_findings":            len(findings),
        "ready_for_review_reports":  rfr_count,
        "approved_reports":          approved,
        "total_bounty_reports":      len(bounty_reports),
        "signal_routing": {
            "critical (score 10)": "nuclei + EIL + bounty_draft",
            "high (score 8-9)":    "nuclei + EIL",
            "medium (score 5-7)":  "nuclei only",
            "low (score <5)":      "passive observation only",
        },
    }
