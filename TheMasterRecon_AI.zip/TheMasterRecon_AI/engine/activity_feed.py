"""
engine/activity_feed.py — Real-time scan activity feed (NEW, isolated)

HOW IT WORKS:
  1. Call activity_feed.attach(domain, queue_fn) once at scan start
     (one-line plug: activity_feed.attach(domain, emit) inside run_scan)
  2. Monkey-patches scanner._req to emit [TESTING]/[RESULT] events
  3. Does NOT modify any scanner logic — wraps transparently
  4. Call activity_feed.detach() at scan end

EVENTS EMITTED (type='feed'):
  {type:'feed', kind:'testing', label:'[TESTING] GET /api/login?user=X ...payload...'}
  {type:'feed', kind:'result',  label:'[RESULT]  200 — 142 bytes — match: sql error', finding:True}
  {type:'feed', kind:'phase',   label:'[PHASE]   XSS scanner starting — 2665 endpoints'}
"""

import threading, time, re
import logging

log = logging.getLogger("elite.activity_feed")

# ── Thread-local state ────────────────────────────────────────────────────────
_tl     = threading.local()      # per-thread: current bug/phase label
_emit   = None                   # the emit(event) callable from run_scan
_domain = ""
_orig_req  = None                # original scanner._req before patch
_patched   = False
_lock      = threading.Lock()

# ── Throttle: max 1 TESTING event per URL+method to avoid spam ───────────────
_seen_testing: dict = {}         # url_prefix → last_emit_ts
_THROTTLE_S = 0.05              # minimum seconds between testing events per URL

def attach(domain: str, emit_fn):
    """
    Call once at start of run_scan to activate the activity feed.
    emit_fn is the existing emit() closure from run_scan.
    """
    global _emit, _domain, _orig_req, _patched, _seen_testing
    with _lock:
        _emit        = emit_fn
        _domain      = domain
        _seen_testing = {}
        _patch_req()

def detach():
    """Call at end of run_scan."""
    global _patched
    with _lock:
        _unpatch_req()

def set_phase(bug: str, endpoint_count: int = 0):
    """
    Emit a [PHASE] event showing which bug type is now being tested.
    Call this from run_scan's bug loop — one line per bug.
    """
    _tl.current_bug = bug
    if _emit:
        label = f"[PHASE] {bug.upper()} scanner — {endpoint_count:,} endpoints"
        _safe_emit("phase", label)

def emit_testing(url: str, method: str = "GET", payload: str = "", bug: str = ""):
    """Emit a [TESTING] event. Called by patched _req."""
    now = time.monotonic()
    key = url[:60]
    if now - _seen_testing.get(key, 0) < _THROTTLE_S:
        return
    _seen_testing[key] = now

    pl = payload[:60] if payload else ""
    bug_label = f"[{bug.upper()}]" if bug else ""
    label = f"[TESTING] {method} {_trim_url(url)}" + (f" {pl}" if pl else "") + (f" {bug_label}" if bug_label else "")
    _safe_emit("testing", label)

def emit_result(url: str, status: int, body_len: int,
                matched: bool = False, match_detail: str = "", bug: str = ""):
    """Emit a [RESULT] event. Called by patched _req after response."""
    if matched:
        label = f"[FOUND]  {status} — {body_len}B — {match_detail[:60]}"
    else:
        label = f"[RESULT] {status} — {body_len}B"
    _safe_emit("result", label, finding=matched)

def _safe_emit(kind: str, label: str, finding: bool = False):
    try:
        if _emit:
            _emit({"type": "feed", "kind": kind, "label": label, "finding": finding})
    except Exception:
        pass

def _trim_url(url: str) -> str:
    """Shorten URL for display."""
    try:
        from urllib.parse import urlparse
        p = urlparse(url)
        path = p.path[:50]
        qs   = ("?" + p.query[:40]) if p.query else ""
        return p.netloc + path + qs
    except Exception:
        return url[:90]

# ── Monkey-patch scanner._req ─────────────────────────────────────────────────
def _patch_req():
    global _orig_req, _patched
    try:
        import scanner as _sc
        if _patched or not hasattr(_sc, '_req'):
            return
        _orig_req = _sc._req

        def _instrumented_req(url, method="GET", headers=None, data=None,
                               timeout=10, use_auth=True, retries=2,
                               allow_redirects=True):
            # Emit TESTING event (throttled)
            payload = ""
            if data:
                try:
                    payload = data.decode("utf-8", "ignore")[:60] if isinstance(data, bytes) else str(data)[:60]
                except Exception:
                    pass
            bug = getattr(_tl, "current_bug", "")
            emit_testing(url, method, payload, bug)

            # Call the REAL _req — zero modification to its logic
            result = _orig_req(url, method=method, headers=headers, data=data,
                               timeout=timeout, use_auth=use_auth, retries=retries,
                               allow_redirects=allow_redirects)

            # Emit RESULT event
            if result is not None:
                status, hdrs, body = result if len(result) == 3 else (result[0], {}, "")
                emit_result(url, status or 0, len(body or ""), bug=bug)

            return result

        _sc._req = _instrumented_req
        # Also patch _get and _post since they call _req
        if hasattr(_sc, '_get'):
            _sc._get = lambda url, **kw: _instrumented_req(url, "GET", **kw)
        if hasattr(_sc, '_post'):
            _sc._post = lambda url, data=None, **kw: _instrumented_req(url, "POST", data=data, **kw)

        _patched = True
        log.info("[activity_feed] _req patched — live feed active")
    except Exception as e:
        log.warning(f"[activity_feed] patch failed: {e}")

def _unpatch_req():
    global _orig_req, _patched
    try:
        import scanner as _sc
        if _orig_req and hasattr(_sc, '_req'):
            _sc._req  = _orig_req
            if hasattr(_sc, '_get'):
                _sc._get = lambda url, **kw: _orig_req(url, "GET", **kw)
            if hasattr(_sc, '_post'):
                _sc._post = lambda url, data=None, **kw: _orig_req(url, "POST", data=data, **kw)
        _patched   = False
        _orig_req  = None
        log.info("[activity_feed] _req unpatched")
    except Exception as e:
        log.warning(f"[activity_feed] unpatch failed: {e}")
