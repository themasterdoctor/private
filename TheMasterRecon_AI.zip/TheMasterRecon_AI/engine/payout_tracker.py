"""
TheMasterRecon AI — Payout Tracker
Tracks bug bounty submission outcomes, bounty amounts, and earnings metrics.
"""
import os, json, logging, sqlite3, threading, time
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime, timezone

log = logging.getLogger("elite.payout_tracker")

_DATA_DIR = Path(os.environ.get("TMR_DATA_DIR", "./data"))
_DB_PATH  = str(_DATA_DIR / "payouts.db")
_lock     = threading.Lock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS payouts (
    report_id       TEXT PRIMARY KEY,
    program_id      TEXT NOT NULL DEFAULT '',
    submission_id   TEXT DEFAULT '',
    title           TEXT DEFAULT '',
    bug_type        TEXT DEFAULT '',
    severity        TEXT DEFAULT '',
    status          TEXT DEFAULT 'submitted',
    bounty_amount   REAL DEFAULT 0.0,
    currency        TEXT DEFAULT 'USD',
    created_at      TEXT DEFAULT (datetime('now')),
    updated_at      TEXT DEFAULT (datetime('now')),
    triaged_at      TEXT DEFAULT '',
    resolved_at     TEXT DEFAULT '',
    notes           TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_payouts_program  ON payouts(program_id);
CREATE INDEX IF NOT EXISTS idx_payouts_severity ON payouts(severity);
CREATE INDEX IF NOT EXISTS idx_payouts_status   ON payouts(status);
"""

VALID_STATUSES = {
    "submitted", "triaged", "resolved", "duplicate",
    "informative", "rejected", "not_applicable"
}


def _conn() -> sqlite3.Connection:
    _DATA_DIR.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(_DB_PATH, timeout=10, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.executescript(_SCHEMA)
    return c


def record_submission(report_id: str, submission_id: str,
                      program_id: str = "", title: str = "",
                      bug_type: str = "", severity: str = "") -> Dict:
    """Record a new submission in the payout tracker."""
    with _lock:
        conn = _conn()
        conn.execute(
            "INSERT OR IGNORE INTO payouts"
            "(report_id,program_id,submission_id,title,bug_type,severity)"
            " VALUES(?,?,?,?,?,?)",
            (report_id, program_id, submission_id, title, bug_type, severity)
        )
        conn.commit()
        row = conn.execute("SELECT * FROM payouts WHERE report_id=?", (report_id,)).fetchone()
    log.info(f"[payout] recorded submission report_id={report_id} program={program_id}")
    return dict(row)


def update_status(report_id: str, status: str,
                  bounty: float = 0.0, currency: str = "USD",
                  notes: str = "") -> Dict:
    """Update submission status and optionally record a bounty."""
    status = status.lower().replace("-","_")
    if status not in VALID_STATUSES:
        raise ValueError(f"Invalid status '{status}'. Valid: {VALID_STATUSES}")

    now = datetime.now(timezone.utc).isoformat()
    with _lock:
        conn = _conn()
        fields  = ["status=?", "updated_at=datetime('now')"]
        args    = [status]

        if bounty > 0:
            fields += ["bounty_amount=?", "currency=?"]
            args   += [bounty, currency]

        if notes:
            fields.append("notes=?"); args.append(notes)

        if status == "triaged":
            fields.append("triaged_at=?"); args.append(now)
        elif status == "resolved":
            fields.append("resolved_at=?"); args.append(now)

        args.append(report_id)
        conn.execute(
            f"UPDATE payouts SET {', '.join(fields)} WHERE report_id=?", args
        )
        conn.commit()
        row = conn.execute("SELECT * FROM payouts WHERE report_id=?", (report_id,)).fetchone()

    bounty_str = f" ${bounty:,.0f} {currency}" if bounty > 0 else ""
    log.info(f"[payout] updated: report_id={report_id} status={status}{bounty_str}")
    return dict(row) if row else {}


def get_record(report_id: str) -> Optional[Dict]:
    with _lock:
        conn = _conn()
        row = conn.execute("SELECT * FROM payouts WHERE report_id=?", (report_id,)).fetchone()
    return dict(row) if row else None


def list_records(program_id: str = "", status: str = "",
                 limit: int = 100) -> List[Dict]:
    with _lock:
        conn = _conn()
        q, args = "SELECT * FROM payouts WHERE 1=1", []
        if program_id: q += " AND program_id=?"; args.append(program_id)
        if status:     q += " AND status=?";     args.append(status)
        q += " ORDER BY created_at DESC LIMIT ?"
        args.append(limit)
        rows = conn.execute(q, args).fetchall()
    return [dict(r) for r in rows]


def metrics(program_id: str = "") -> Dict:
    """
    Return dashboard metrics:
      total_submissions, total_earnings, win_rate,
      avg_payout_by_severity, time_to_triage, time_to_payout,
      status_breakdown
    """
    with _lock:
        conn = _conn()
        q, args = "SELECT * FROM payouts", []
        if program_id:
            q += " WHERE program_id=?"; args.append(program_id)
        rows = [dict(r) for r in conn.execute(q, args).fetchall()]

    if not rows:
        return {
            "total_submissions": 0, "total_earnings": 0.0,
            "win_rate": 0.0, "avg_payout_by_severity": {},
            "time_to_triage_days": None, "time_to_payout_days": None,
            "status_breakdown": {}, "top_programs": [],
        }

    total        = len(rows)
    resolved     = [r for r in rows if r["status"] == "resolved"]
    paid         = [r for r in resolved if (r["bounty_amount"] or 0) > 0]
    duplicates   = [r for r in rows if r["status"] == "duplicate"]
    informatives = [r for r in rows if r["status"] == "informative"]
    triaged      = [r for r in rows if r["status"] == "triaged"]

    total_earnings = sum(r["bounty_amount"] or 0 for r in paid)
    win_rate = round(len(resolved) / total * 100, 1) if total else 0.0

    # Average payout per severity
    avg_by_sev = {}
    for sev in ("critical", "high", "medium", "low"):
        sev_paid = [r["bounty_amount"] for r in paid
                    if r["severity"] == sev and r["bounty_amount"]]
        if sev_paid:
            avg_by_sev[sev] = round(sum(sev_paid) / len(sev_paid), 2)

    # Time metrics
    def _days_between(a, b):
        try:
            ta = datetime.fromisoformat(a.replace("Z",""))
            tb = datetime.fromisoformat(b.replace("Z",""))
            return round(abs((tb - ta).total_seconds() / 86400), 1)
        except Exception:
            return None

    triage_times  = [_days_between(r["created_at"], r["triaged_at"])
                     for r in rows if r.get("triaged_at")]
    payout_times  = [_days_between(r["created_at"], r["resolved_at"])
                     for r in paid if r.get("resolved_at")]

    avg_triage = round(sum(t for t in triage_times if t)/len(triage_times),1) if triage_times else None
    avg_payout = round(sum(t for t in payout_times if t)/len(payout_times),1) if payout_times else None

    # Status breakdown
    status_bd = {}
    for r in rows:
        s = r["status"]
        status_bd[s] = status_bd.get(s, 0) + 1

    # Top programs by earnings
    prog_earnings = {}
    for r in paid:
        prog_earnings[r["program_id"]] = prog_earnings.get(r["program_id"],0) + (r["bounty_amount"] or 0)
    top_programs = sorted(prog_earnings.items(), key=lambda x: -x[1])[:5]

    return {
        "total_submissions":    total,
        "total_earnings":       round(total_earnings, 2),
        "total_resolved":       len(resolved),
        "total_paid":           len(paid),
        "total_duplicates":     len(duplicates),
        "total_informatives":   len(informatives),
        "win_rate":             win_rate,
        "avg_payout_by_severity": avg_by_sev,
        "time_to_triage_days":  avg_triage,
        "time_to_payout_days":  avg_payout,
        "status_breakdown":     status_bd,
        "top_programs":         [{"program_id": p, "earnings": e} for p, e in top_programs],
        "currency":             "USD",
    }
