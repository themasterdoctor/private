"""
BugScan ELITE — Attack Surface Diff & Monitoring Engine
Compare scan runs: new subdomains, new endpoints, disappeared services,
new findings, tech stack changes, port changes.
"""
import json, time, logging, hashlib
from pathlib import Path
from typing import List, Dict, Set, Optional, Tuple
from datetime import datetime

log = logging.getLogger("elite.diff")


def _ts() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ")

def _hash(data: str) -> str:
    return hashlib.md5(data.encode()).hexdigest()[:8]


class DiffEngine:
    """
    Compares two scan snapshots and returns a detailed diff report.
    Tracks: subdomains, live hosts, endpoints, findings, tech, ports.
    """

    def snapshot(self, domain: str, db) -> Dict:
        """Capture current state as a snapshot."""
        hosts     = db.get_hosts(domain)
        findings  = db.get_findings(domain)
        endpoints = db.get_endpoints(domain, limit=50000)
        tech      = db.get_tech(domain)
        meta      = db.get_meta(domain)

        snap = {
            "domain":    domain,
            "ts":        _ts(),
            "subs":      sorted(hosts.get("subs", [])),
            "active":    sorted(hosts.get("active", [])),
            "ports":     sorted(hosts.get("ports", [])),
            "endpoints": sorted(endpoints),
            "findings":  findings,
            "tech":      sorted(tech),
            "subs_count":    hosts.get("subs_count", 0),
            "active_count":  hosts.get("active_count", 0),
            "ends_count":    len(endpoints),
            "finds_count":   len(findings),
        }
        return snap

    def diff(self, snap_old: Dict, snap_new: Dict) -> Dict:
        """
        Compare two snapshots. Returns comprehensive diff.
        """
        domain = snap_new.get("domain","")
        ts_old = snap_old.get("ts","")
        ts_new = snap_new.get("ts","")

        # ── Subdomains ────────────────────────────────────────────────────
        subs_old = set(snap_old.get("subs",[]))
        subs_new = set(snap_new.get("subs",[]))
        new_subs      = sorted(subs_new - subs_old)
        removed_subs  = sorted(subs_old - subs_new)

        # ── Live hosts ────────────────────────────────────────────────────
        hosts_old = set(snap_old.get("active",[]))
        hosts_new = set(snap_new.get("active",[]))
        new_hosts     = sorted(hosts_new - hosts_old)
        removed_hosts = sorted(hosts_old - hosts_new)

        # ── Ports ─────────────────────────────────────────────────────────
        ports_old = set(snap_old.get("ports",[]))
        ports_new = set(snap_new.get("ports",[]))
        new_ports     = sorted(ports_new - ports_old)
        removed_ports = sorted(ports_old - ports_new)

        # ── Endpoints ─────────────────────────────────────────────────────
        ends_old = set(snap_old.get("endpoints",[]))
        ends_new = set(snap_new.get("endpoints",[]))
        new_ends     = sorted(ends_new - ends_old)
        removed_ends = sorted(ends_old - ends_new)

        # ── Tech stack changes ─────────────────────────────────────────────
        tech_old = set(snap_old.get("tech",[]))
        tech_new = set(snap_new.get("tech",[]))
        new_tech     = sorted(tech_new - tech_old)
        removed_tech = sorted(tech_old - tech_new)

        # ── Findings ──────────────────────────────────────────────────────
        finds_old = snap_old.get("findings",[])
        finds_new = snap_new.get("findings",[])

        # Identify new findings (by URL+bug combination)
        old_find_keys = set(
            f"{f.get('bug','')}:{f.get('url','')}" for f in finds_old
        )
        new_findings = [
            f for f in finds_new
            if f"{f.get('bug','')}:{f.get('url','')}" not in old_find_keys
        ]
        # Fixed findings
        new_find_keys = set(
            f"{f.get('bug','')}:{f.get('url','')}" for f in finds_new
        )
        fixed_findings = [
            f for f in finds_old
            if f"{f.get('bug','')}:{f.get('url','')}" not in new_find_keys
        ]

        new_crits = [f for f in new_findings if f.get("severity")=="critical"]
        new_highs = [f for f in new_findings if f.get("severity")=="high"]

        # ── Risk delta ────────────────────────────────────────────────────
        risk_delta = self._risk_delta(finds_old, finds_new)

        # ── Summary ───────────────────────────────────────────────────────
        has_changes = any([
            new_subs, removed_subs, new_hosts, removed_hosts,
            new_ends, new_findings, new_tech, new_ports,
        ])

        return {
            "domain":   domain,
            "ts_old":   ts_old,
            "ts_new":   ts_new,
            "has_changes": has_changes,

            "subdomains": {
                "new":     new_subs,
                "removed": removed_subs,
                "total_old": len(subs_old),
                "total_new": len(subs_new),
                "delta":   len(subs_new) - len(subs_old),
            },
            "hosts": {
                "new":     new_hosts,
                "removed": removed_hosts,
                "total_old": len(hosts_old),
                "total_new": len(hosts_new),
                "delta":   len(hosts_new) - len(hosts_old),
            },
            "ports": {
                "new":     new_ports,
                "removed": removed_ports,
            },
            "endpoints": {
                "new":      new_ends[:500],
                "removed":  removed_ends[:200],
                "total_old": len(ends_old),
                "total_new": len(ends_new),
                "delta":    len(ends_new) - len(ends_old),
                "new_count": len(new_ends),
            },
            "tech": {
                "new":     new_tech,
                "removed": removed_tech,
            },
            "findings": {
                "new":            new_findings,
                "fixed":          fixed_findings,
                "new_critical":   new_crits,
                "new_high":       new_highs,
                "total_old":      len(finds_old),
                "total_new":      len(finds_new),
                "delta":          len(finds_new) - len(finds_old),
                "new_count":      len(new_findings),
                "fixed_count":    len(fixed_findings),
            },
            "risk_delta": risk_delta,
            "severity":   self._diff_severity(new_findings, new_subs, new_hosts),
        }

    def _risk_delta(self, old_finds: List, new_finds: List) -> Dict:
        def score(finds):
            s = {"critical":0,"high":0,"medium":0,"low":0}
            for f in finds:
                sev = f.get("severity","low")
                s[sev] = s.get(sev,0) + 1
            return s
        old_s = score(old_finds)
        new_s = score(new_finds)
        return {
            "critical_delta": new_s["critical"] - old_s["critical"],
            "high_delta":     new_s["high"]     - old_s["high"],
            "medium_delta":   new_s["medium"]   - old_s["medium"],
            "old_score":      old_s,
            "new_score":      new_s,
        }

    def _diff_severity(self, new_findings, new_subs, new_hosts) -> str:
        crits = [f for f in new_findings if f.get("severity")=="critical"]
        highs = [f for f in new_findings if f.get("severity")=="high"]
        if crits: return "critical"
        if highs or new_hosts: return "high"
        if new_subs or new_findings: return "medium"
        return "info"

    def render_diff_report(self, diff: Dict) -> str:
        """Render a markdown diff report."""
        d = diff
        domain = d.get("domain","")
        sev    = d.get("severity","info").upper()
        emoji  = {"CRITICAL":"🔴","HIGH":"🟠","MEDIUM":"🟡","INFO":"🟢"}.get(sev,"⚪")

        new_finds = d.get("findings",{}).get("new",[])
        new_crits = d.get("findings",{}).get("new_critical",[])
        fixed     = d.get("findings",{}).get("fixed",[])
        new_subs  = d.get("subdomains",{}).get("new",[])[:20]
        new_hosts = d.get("hosts",{}).get("new",[])[:20]
        new_ends  = d.get("endpoints",{}).get("new",[])[:30]
        new_tech  = d.get("tech",{}).get("new",[])
        new_ports = d.get("ports",{}).get("new",[])[:20]
        rd        = d.get("risk_delta",{})

        finds_md = ""
        for f in new_finds[:15]:
            bug = f.get("bug","").upper()
            url = f.get("url","")
            sv  = f.get("severity","").upper()
            finds_md += f"| {sv} | {bug} | `{url[:80]}` |\n"

        fixed_md = ""
        for f in fixed[:10]:
            bug = f.get("bug","").upper()
            url = f.get("url","")
            fixed_md += f"- ~~{bug}~~ `{url[:60]}`\n"

        return f"""# {emoji} Attack Surface Diff — {domain}

**Period**: `{d.get('ts_old','')[:10]}` → `{d.get('ts_new','')[:10]}`
**Change Severity**: **{sev}**

---

## Summary

| Metric | Before | After | Δ |
|--------|--------|-------|---|
| Subdomains | {d['subdomains']['total_old']} | {d['subdomains']['total_new']} | **{d['subdomains']['delta']:+d}** |
| Live Hosts | {d['hosts']['total_old']} | {d['hosts']['total_new']} | **{d['hosts']['delta']:+d}** |
| Endpoints  | {d['endpoints']['total_old']} | {d['endpoints']['total_new']} | **{d['endpoints']['delta']:+d}** |
| Findings   | {d['findings']['total_old']} | {d['findings']['total_new']} | **{d['findings']['delta']:+d}** |
| Critical   | {rd.get('old_score',{}).get('critical',0)} | {rd.get('new_score',{}).get('critical',0)} | **{rd.get('critical_delta',0):+d}** |

---

## 🆕 New Subdomains ({len(new_subs)})
{chr(10).join(f'- `{s}`' for s in new_subs) or '_None_'}

## 🖥 New Live Hosts ({len(new_hosts)})
{chr(10).join(f'- `{h}`' for h in new_hosts) or '_None_'}

## 🔌 New Open Ports ({len(new_ports)})
{chr(10).join(f'- `{p}`' for p in new_ports) or '_None_'}

## 🔗 New Endpoints ({d['endpoints']['new_count']})
{chr(10).join(f'- `{e}`' for e in new_ends) or '_None_'}
{'...' if d["endpoints"]["new_count"] > 30 else ''}

## ⚙️ Tech Stack Changes
**New**: {', '.join(new_tech) or 'None'}
**Removed**: {', '.join(d['tech'].get('removed',[])[:10]) or 'None'}

## 🐛 New Findings ({d['findings']['new_count']})

| Severity | Type | URL |
|----------|------|-----|
{finds_md or '| — | None | — |'}

## ✅ Fixed Findings ({d['findings']['fixed_count']})
{fixed_md or '_None_'}

---

*Generated by BugScan ELITE Diff Engine · {d.get('ts_new','')}*
"""


class MonitorEngine:
    """
    Continuous monitoring: saves snapshots, computes diffs on each new scan.
    """

    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self._diff = DiffEngine()

    def _snap_path(self, domain: str, ts: str) -> Path:
        dd = self.data_dir / domain.replace("/","_").replace(":","_")
        dd.mkdir(exist_ok=True)
        safe_ts = ts.replace(":","").replace("-","")[:15]
        return dd / f"snap_{safe_ts}.json"

    def save_snapshot(self, domain: str, db) -> Dict:
        snap = self._diff.snapshot(domain, db)
        ts   = snap["ts"]
        path = self._snap_path(domain, ts)
        path.write_text(json.dumps(snap, indent=2))
        log.info(f"[monitor] snapshot saved: {domain} @ {ts}")
        return snap

    def get_snapshots(self, domain: str) -> List[Dict]:
        """Return all snapshots for a domain, sorted oldest first."""
        dd = self.data_dir / domain.replace("/","_").replace(":","_")
        if not dd.exists(): return []
        snaps = []
        for f in sorted(dd.glob("snap_*.json")):
            try:
                snaps.append(json.loads(f.read_text()))
            except: pass
        return snaps

    def latest_diff(self, domain: str, db) -> Optional[Dict]:
        """Compare previous snapshot with current state."""
        snaps = self.get_snapshots(domain)
        if not snaps:
            # No previous snapshot — save one and return None
            self.save_snapshot(domain, db)
            return None

        # Get previous snapshot
        prev = snaps[-1]

        # Current state
        curr = self._diff.snapshot(domain, db)

        # Save current
        path = self._snap_path(domain, curr["ts"])
        path.write_text(json.dumps(curr, indent=2))

        # Compute diff
        diff = self._diff.diff(prev, curr)
        report = self._diff.render_diff_report(diff)
        diff["report"] = report
        return diff

    def diff_between(self, domain: str, idx_old: int, idx_new: int) -> Optional[Dict]:
        """Diff between two specific snapshot indices."""
        snaps = self.get_snapshots(domain)
        if idx_old >= len(snaps) or idx_new >= len(snaps):
            return None
        diff = self._diff.diff(snaps[idx_old], snaps[idx_new])
        diff["report"] = self._diff.render_diff_report(diff)
        return diff

    def list_snapshots(self, domain: str) -> List[Dict]:
        snaps = self.get_snapshots(domain)
        return [{"ts": s.get("ts",""), "idx": i,
                 "subs": s.get("subs_count",0),
                 "active": s.get("active_count",0),
                 "finds": s.get("finds_count",0)}
                for i,s in enumerate(snaps)]
