"""
BugScan ELITE — HackerOne & Bugcrowd Auto-Submit Engine
Draft and submit reports directly via API. No copy-paste.
"""
import os, json, time, logging, base64, re
import urllib.request, urllib.parse, ssl
from typing import Dict, List, Optional

log = logging.getLogger("elite.h1")


def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c


def _req(url, method="GET", data=None, headers=None, timeout=30):
    try:
        h = {"Content-Type":"application/json","Accept":"application/json",
             "User-Agent":"BugScanELITE/1.0"}
        if headers: h.update(headers)
        body = json.dumps(data).encode() if data else None
        req  = urllib.request.Request(url, data=body, headers=h, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode())
        except: return e.code, {}
    except Exception as ex:
        log.error(f"api req {url}: {ex}")
        return 0, {}


# ── Severity mappings ─────────────────────────────────────────────────────────
H1_SEVERITY = {
    "critical": {"rating":"critical","score":10.0},
    "high":     {"rating":"high",    "score":8.0},
    "medium":   {"rating":"medium",  "score":5.0},
    "low":      {"rating":"low",     "score":3.0},
    "info":     {"rating":"none",    "score":0.0},
}

BC_SEVERITY = {
    "critical": "P1",
    "high":     "P2",
    "medium":   "P3",
    "low":      "P4",
    "info":     "P5",
}

VULN_TYPES_H1 = {
    "sqli":            "SQL Injection",
    "ssrf":            "Server-Side Request Forgery (SSRF)",
    "lfi":             "Path Traversal",
    "rce":             "Remote Code Execution",
    "xss":             "Cross-Site Scripting (XSS)",
    "idor":            "Insecure Direct Object Reference (IDOR)",
    "cors":            "Cross-Origin Resource Sharing (CORS) Misconfiguration",
    "expose":          "Information Disclosure",
    "actuator":        "Information Disclosure",
    "takeover":        "Subdomain Takeover",
    "jsleak":          "Sensitive Data Exposure",
    "oauth":           "Broken Authentication and Session Management",
    "jwt":             "Broken Authentication and Session Management",
    "saml":            "Broken Authentication and Session Management",
    "graphql":         "Sensitive Data Exposure",
    "ssti":            "Server-Side Template Injection",
    "xxe":             "XML External Entity (XXE) Injection",
    "deserialization": "Insecure Deserialization",
    "log4j":           "Remote Code Execution",
    "spring4shell":    "Remote Code Execution",
    "crlf":            "HTTP Response Splitting",
    "redirect":        "Open Redirect",
    "prototype":       "Cross-Site Scripting (XSS)",
    "fileupload":      "Unrestricted File Upload",
    "nosqli":          "SQL Injection",
    "buckets":         "Security Misconfiguration",
    "misconfig":       "Security Misconfiguration",
    "smuggling":       "HTTP Request Smuggling",
    "panels":          "Security Misconfiguration",
    "cve":             "Use of a Broken or Risky Cryptographic Algorithm",
}


class HackerOneClient:
    """
    HackerOne API v1 client.
    API key = username:api_token (base64 encoded)
    """

    BASE = "https://api.hackerone.com/v1"

    def __init__(self, username: str = "", api_token: str = ""):
        self.username  = username or os.environ.get("H1_USERNAME","")
        self.api_token = api_token or os.environ.get("H1_API_TOKEN","")
        self._auth     = base64.b64encode(
            f"{self.username}:{self.api_token}".encode()
        ).decode() if self.username and self.api_token else ""

    @property
    def configured(self) -> bool:
        return bool(self._auth)

    def _headers(self) -> Dict:
        return {"Authorization": f"Basic {self._auth}",
                "Accept": "application/json",
                "Content-Type": "application/json"}

    def get_programs(self) -> List[Dict]:
        """List programs you have access to."""
        status, data = _req(f"{self.BASE}/hackers/me/programs",
                            headers=self._headers())
        if status == 200:
            return data.get("data",[])
        log.warning(f"H1 get_programs: {status}")
        return []

    def find_program(self, domain: str) -> Optional[Dict]:
        """Find program by domain."""
        progs = self.get_programs()
        domain_lower = domain.lower()
        for p in progs:
            attrs = p.get("attributes",{})
            handle = attrs.get("handle","")
            # Check if domain matches program scope
            if domain_lower in handle or handle in domain_lower:
                return p
        # Search in scopes
        for p in progs:
            scope = p.get("relationships",{}).get("structured_scopes",{}).get("data",[])
            for s in scope:
                identifier = s.get("attributes",{}).get("asset_identifier","")
                if domain_lower in identifier.lower():
                    return p
        return progs[0] if progs else None

    def draft_report(self, finding: Dict, domain: str, program_handle: str,
                     report_md: str) -> Dict:
        """
        Create a draft report on HackerOne.
        Returns the created report data.
        """
        bug  = finding.get("bug","")
        sev  = finding.get("severity","medium")
        url  = finding.get("url","")

        vuln_type = VULN_TYPES_H1.get(bug, "Information Disclosure")
        sev_data  = H1_SEVERITY.get(sev, H1_SEVERITY["medium"])

        title = f"{sev.upper()}: {vuln_type} in {domain}"

        payload = {
            "data": {
                "type": "report",
                "attributes": {
                    "title":             title,
                    "vulnerability_information": report_md,
                    "impact":            finding.get("details",{}).get("description",""),
                    "severity_rating":   sev_data["rating"],
                    "weakness_id":       None,
                    "source":            "api",
                }
            }
        }

        status, data = _req(
            f"{self.BASE}/hackers/reports",
            method="POST",
            data=payload,
            headers=self._headers(),
        )

        if status in (200, 201):
            report_id = data.get("data",{}).get("id","")
            log.info(f"[h1] report created: #{report_id}")
            return {
                "success":   True,
                "report_id": report_id,
                "url":       f"https://hackerone.com/reports/{report_id}",
                "title":     title,
                "data":      data,
            }
        else:
            log.warning(f"[h1] draft failed: {status} {data}")
            return {"success": False, "status": status, "error": data}

    def get_report(self, report_id: str) -> Dict:
        status, data = _req(f"{self.BASE}/reports/{report_id}",
                            headers=self._headers())
        return data if status == 200 else {}

    def add_comment(self, report_id: str, comment: str) -> bool:
        payload = {"data":{"type":"activity-comment",
                            "attributes":{"message":comment,"internal":False}}}
        status, _ = _req(f"{self.BASE}/reports/{report_id}/activities",
                         method="POST", data=payload, headers=self._headers())
        return status in (200,201)

    def me(self) -> Dict:
        status, data = _req(f"{self.BASE}/hackers/me", headers=self._headers())
        return data if status == 200 else {}

    def test_auth(self) -> bool:
        me = self.me()
        return bool(me.get("data"))


class BugcrowdClient:
    """
    Bugcrowd API v1 client.
    """
    BASE = "https://bugcrowd.com/api/v1"

    def __init__(self, api_token: str = ""):
        self.api_token = api_token or os.environ.get("BUGCROWD_API_TOKEN","")

    @property
    def configured(self) -> bool:
        return bool(self.api_token)

    def _headers(self) -> Dict:
        return {
            "Authorization": f"Token {self.api_token}",
            "Accept":        "application/vnd.bugcrowd.v4+json",
            "Content-Type":  "application/json",
        }

    def get_programs(self) -> List[Dict]:
        status, data = _req(f"{self.BASE}/engagements",
                            headers=self._headers())
        return data.get("data",[]) if status == 200 else []

    def submit_report(self, finding: Dict, domain: str,
                      program_id: str, report_md: str) -> Dict:
        bug = finding.get("bug","")
        sev = finding.get("severity","medium")
        url = finding.get("url","")

        title    = f"{BC_SEVERITY.get(sev,'P3')}: {VULN_TYPES_H1.get(bug,'Vulnerability')} in {domain}"
        priority = BC_SEVERITY.get(sev, "P3")

        payload = {
            "data": {
                "type": "submission",
                "attributes": {
                    "title":              title,
                    "description":        report_md,
                    "vulnerability_references": [{"url": url}],
                },
                "relationships": {
                    "target": {"data": {"type": "engagement", "id": program_id}}
                }
            }
        }

        status, data = _req(f"{self.BASE}/submissions",
                            method="POST", data=payload,
                            headers=self._headers())

        if status in (200,201):
            sub_id = data.get("data",{}).get("id","")
            log.info(f"[bugcrowd] submitted: #{sub_id}")
            return {
                "success":       True,
                "submission_id": sub_id,
                "url":           f"https://bugcrowd.com/submissions/{sub_id}",
                "title":         title,
            }
        return {"success":False,"status":status,"error":data}

    def test_auth(self) -> bool:
        status, _ = _req(f"{self.BASE}/user", headers=self._headers())
        return status == 200


class ReportSubmitter:
    """
    Unified interface for submitting to H1 or Bugcrowd.
    Also generates a complete markdown report for copy-paste.
    """

    def __init__(self):
        self.h1 = HackerOneClient()
        self.bc = BugcrowdClient()

    @property
    def h1_ready(self) -> bool:
        return self.h1.configured

    @property
    def bc_ready(self) -> bool:
        return self.bc.configured

    def submit_to_h1(self, finding: Dict, domain: str,
                     report_md: str, program_handle: str = "") -> Dict:
        if not self.h1.configured:
            return {"success":False,"error":"H1 not configured — set H1_USERNAME and H1_API_TOKEN"}
        if not program_handle:
            prog = self.h1.find_program(domain)
            program_handle = prog.get("attributes",{}).get("handle","") if prog else ""
        if not program_handle:
            return {"success":False,"error":f"No H1 program found for {domain}"}
        return self.h1.draft_report(finding, domain, program_handle, report_md)

    def submit_to_bugcrowd(self, finding: Dict, domain: str,
                           report_md: str, program_id: str = "") -> Dict:
        if not self.bc.configured:
            return {"success":False,"error":"Bugcrowd not configured — set BUGCROWD_API_TOKEN"}
        return self.bc.submit_report(finding, domain, program_id, report_md)

    def status(self) -> Dict:
        return {
            "hackerone": {
                "configured": self.h1.configured,
                "username":   self.h1.username,
            },
            "bugcrowd": {
                "configured": self.bc.configured,
            },
        }

    def test(self) -> Dict:
        results = {}
        if self.h1.configured:
            results["hackerone"] = self.h1.test_auth()
        if self.bc.configured:
            results["bugcrowd"] = self.bc.test_auth()
        return results


# Global singleton
_submitter: Optional[ReportSubmitter] = None

def get_submitter() -> ReportSubmitter:
    global _submitter
    if _submitter is None:
        _submitter = ReportSubmitter()
    return _submitter
