"""
BugScan ELITE — Authentication Engine
Auto-login, session management, authenticated surface scanning.
"""
import re, json, time, logging, urllib.request, urllib.parse, urllib.error, ssl
from typing import Dict, List, Optional, Tuple
from http.cookiejar import CookieJar

log = logging.getLogger("elite.auth")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

class Session:
    """Maintains cookies and auth headers across requests."""

    def __init__(self):
        self.cookies: Dict[str, str] = {}
        self.headers: Dict[str, str] = {
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                         "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/json,*/*;q=0.9",
            "Accept-Language": "en-US,en;q=0.9",
        }
        self.token: Optional[str]  = None
        self.token_type: str       = "Bearer"
        self.logged_in: bool       = False
        self.login_url: Optional[str] = None
        self.username: Optional[str]  = None
        self._history: List[Dict]     = []

    def set_token(self, token: str, token_type: str = "Bearer"):
        self.token = token
        self.token_type = token_type
        self.headers["Authorization"] = f"{token_type} {token}"

    def set_cookies(self, cookie_str: str):
        """Parse cookie string like 'name=val; name2=val2'."""
        for part in cookie_str.split(";"):
            part = part.strip()
            if "=" in part:
                k, v = part.split("=", 1)
                self.cookies[k.strip()] = v.strip()

    def cookie_header(self) -> str:
        return "; ".join(f"{k}={v}" for k,v in self.cookies.items())

    def request(self, url: str, method: str = "GET",
                data=None, extra_headers: Dict = None,
                timeout: int = 10) -> Optional[Tuple]:
        h = dict(self.headers)
        if self.cookies:
            h["Cookie"] = self.cookie_header()
        if extra_headers:
            h.update(extra_headers)
        if data and isinstance(data, dict):
            data = urllib.parse.urlencode(data).encode()
            h.setdefault("Content-Type", "application/x-www-form-urlencoded")
        elif data and isinstance(data, str):
            data = data.encode()
        try:
            req = urllib.request.Request(url, data=data, headers=h, method=method)
            with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
                # Capture set-cookie
                for hdr, val in r.headers.items():
                    if hdr.lower() == "set-cookie":
                        self._parse_set_cookie(val)
                body = r.read(65536).decode("utf-8","ignore")
                self._history.append({"url":url,"status":r.status,"method":method})
                return r.status, dict(r.headers), body
        except urllib.error.HTTPError as e:
            try: return e.code, dict(e.headers), e.read(4096).decode("utf-8","ignore")
            except: return e.code, {}, ""
        except Exception as ex:
            log.debug(f"session req {url}: {ex}")
            return None

    def _parse_set_cookie(self, val: str):
        """Parse Set-Cookie header value."""
        parts = val.split(";")
        if parts:
            kv = parts[0].strip()
            if "=" in kv:
                k, v = kv.split("=", 1)
                self.cookies[k.strip()] = v.strip()

    def get(self, url, **kw): return self.request(url, "GET", **kw)
    def post(self, url, data=None, **kw): return self.request(url, "POST", data=data, **kw)


class AuthEngine:
    """Handles login forms, token extraction, and session management."""

    def __init__(self):
        self.session = Session()
        self.csrf_token: Optional[str] = None

    def detect_login_form(self, url: str) -> Optional[Dict]:
        """
        Find login form on a page.
        Returns: {action, username_field, password_field, csrf_field, csrf_value}
        """
        r = self.session.get(url)
        if not r: return None
        status, hdrs, body = r

        # Find forms
        form_pattern = r'<form[^>]*action=["\']?([^"\'>\s]*)["\']?[^>]*>([\s\S]*?)</form>'
        input_pattern = r'<input[^>]*name=["\']([^"\']+)["\'][^>]*(?:type=["\']([^"\']+)["\'])?[^>]*(?:value=["\']([^"\']*)["\'])?[^>]*/?\s*>'

        for form_match in re.finditer(form_pattern, body, re.IGNORECASE):
            action = form_match.group(1) or url
            form_body = form_match.group(2)

            inputs = {}
            for inp in re.finditer(input_pattern, form_body, re.IGNORECASE):
                name = inp.group(1)
                itype = (inp.group(2) or "text").lower()
                value = inp.group(3) or ""
                inputs[name] = {"type": itype, "value": value}

            # Identify username/password fields
            user_field = None
            pass_field = None
            csrf_field = None
            csrf_value = ""

            for name, info in inputs.items():
                n = name.lower()
                t = info["type"]
                if t == "password":
                    pass_field = name
                elif t == "hidden" and any(k in n for k in ["csrf","token","nonce","_token","authenticity"]):
                    csrf_field = name
                    csrf_value = info["value"]
                elif t in ("text","email") or any(k in n for k in
                    ["user","email","login","name","account","id"]):
                    user_field = name

            if user_field and pass_field:
                # Make action absolute
                if action and not action.startswith("http"):
                    base = "/".join(url.split("/")[:3])
                    action = base + ("" if action.startswith("/") else "/") + action

                return {
                    "url":            url,
                    "action":         action or url,
                    "username_field": user_field,
                    "password_field": pass_field,
                    "csrf_field":     csrf_field,
                    "csrf_value":     csrf_value,
                    "all_inputs":     inputs,
                }
        return None

    def login_form(self, login_url: str, username: str, password: str,
                   extra_fields: Dict = None) -> bool:
        """Attempt form-based login."""
        form = self.detect_login_form(login_url)
        if not form:
            log.warning(f"[auth] no login form found at {login_url}")
            return False

        data = {
            form["username_field"]: username,
            form["password_field"]: password,
        }
        if form["csrf_field"]:
            data[form["csrf_field"]] = form["csrf_value"]
        if extra_fields:
            data.update(extra_fields)

        r = self.session.post(form["action"], data=data)
        if not r: return False
        status, hdrs, body = r

        # Check if login succeeded
        success_indicators = [
            status in (200, 302),
            "logout" in body.lower(),
            "dashboard" in body.lower(),
            "welcome" in body.lower(),
            "profile" in body.lower(),
            "signout" in body.lower(),
        ]
        fail_indicators = [
            "invalid" in body.lower() and "password" in body.lower(),
            "incorrect" in body.lower(),
            "wrong" in body.lower() and ("password" in body.lower() or "credential" in body.lower()),
            "failed" in body.lower() and "login" in body.lower(),
            "error" in body.lower() and "password" in body.lower(),
        ]

        if any(success_indicators) and not any(fail_indicators):
            self.session.logged_in = True
            self.session.login_url = login_url
            self.session.username = username
            log.info(f"[auth] login SUCCESS at {login_url} as {username}")

            # Try to extract token from response
            token = self._extract_token(body, hdrs)
            if token:
                self.session.set_token(token)
            return True
        else:
            log.warning(f"[auth] login FAILED at {login_url}")
            return False

    def login_api(self, api_url: str, username: str, password: str,
                  username_key: str = "username", password_key: str = "password") -> bool:
        """Attempt JSON API-based login."""
        payload = json.dumps({username_key: username, password_key: password}).encode()
        r = self.session.request(api_url, "POST", data=payload,
                                extra_headers={"Content-Type":"application/json"})
        if not r: return False
        status, hdrs, body = r

        if status in (200, 201):
            token = self._extract_token(body, hdrs)
            if token:
                self.session.set_token(token)
                self.session.logged_in = True
                self.session.login_url = api_url
                self.session.username = username
                log.info(f"[auth] API login SUCCESS at {api_url}")
                return True
        log.warning(f"[auth] API login FAILED at {api_url} status={status}")
        return False

    def _extract_token(self, body: str, headers: Dict) -> Optional[str]:
        """Extract JWT or bearer token from response."""
        # From Authorization header
        auth_header = headers.get("Authorization","")
        if auth_header:
            m = re.search(r'Bearer\s+([a-zA-Z0-9._\-]+)', auth_header, re.I)
            if m: return m.group(1)

        # From body
        try:
            d = json.loads(body)
            for key in ["token","access_token","accessToken","jwt","id_token",
                        "auth_token","authToken","bearer","Authorization"]:
                if key in d:
                    return str(d[key])
                # Nested
                for subkey in ["data","user","auth","result"]:
                    if subkey in d and isinstance(d[subkey], dict):
                        if key in d[subkey]:
                            return str(d[subkey][key])
        except: pass

        # JWT regex in body
        jwt_pattern = r'eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]+'
        m = re.search(jwt_pattern, body)
        if m: return m.group(0)

        return None

    def set_manual_session(self, cookie_str: str = "", token: str = "",
                           headers: Dict = None):
        """Manually set session from user-provided values."""
        if cookie_str:
            self.session.set_cookies(cookie_str)
        if token:
            self.session.set_token(token)
        if headers:
            self.session.headers.update(headers)
        self.session.logged_in = bool(cookie_str or token)
        log.info(f"[auth] manual session set: cookies={bool(cookie_str)}, token={bool(token)}")

    def get_session(self) -> Session:
        return self.session

    def is_authenticated(self) -> bool:
        return self.session.logged_in

    def test_protected_endpoint(self, url: str) -> Dict:
        """
        Test if an endpoint requires auth and whether our session bypasses it.
        """
        # Unauthenticated
        plain_sess = Session()
        r_unauth = plain_sess.get(url)

        # Authenticated
        r_auth = self.session.get(url)

        result = {
            "url":            url,
            "unauth_status":  r_unauth[0] if r_unauth else 0,
            "auth_status":    r_auth[0] if r_auth else 0,
            "auth_bypasses":  False,
            "diff_size":      0,
        }

        if r_unauth and r_auth:
            result["diff_size"] = abs(len(r_auth[2]) - len(r_unauth[2]))
            # Auth bypass if unauth gets 401/403 but auth gets 200
            if r_unauth[0] in (401, 403) and r_auth[0] == 200:
                result["auth_bypasses"] = True
            # Or significantly different content
            elif r_auth[0] == 200 and r_unauth[0] == 200 and result["diff_size"] > 500:
                result["content_differs"] = True

        return result
