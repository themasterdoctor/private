"""
BugScan ELITE — CVE Correlation Engine

Inspired by XBOW's CVE-2026-45185 discovery:
  - Version-aware tech fingerprinting → CVE matching
  - Service banner parsing (SMTP/SSH/FTP/HTTP)
  - Live NVD/OSV feed integration
  - Nuclei CVE template auto-selection
  - Background CVE DB with local cache

Flow:
  detected_tech + version → version_check → CVE list → nuclei templates → scan

Safe rules:
  - Detection only — no exploit payloads
  - CVE data from public NVD/OSV APIs only
  - Nuclei templates are probe-only
  - Human review required for critical findings
"""

import json, logging, os, re, sqlite3, threading, time, urllib.request, ssl
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("elite.cve_engine")

_DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "..", "data", "cve_cache.db")
_conn: Optional[sqlite3.Connection] = None
_lock = threading.Lock()

# ── SSL context ───────────────────────────────────────────────────────────────
def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c


def _fetch(url: str, timeout: int = 10) -> Optional[dict]:
    try:
        req = urllib.request.Request(url,
            headers={"User-Agent": "BugScanELITE-CVE/1.0", "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return json.loads(r.read())
    except Exception as e:
        log.debug(f"[cve] fetch {url}: {e}")
        return None


# ── DB ────────────────────────────────────────────────────────────────────────

def _db() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        os.makedirs(os.path.dirname(_DB_PATH), exist_ok=True)
        _conn = sqlite3.connect(_DB_PATH, timeout=10, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA journal_mode=WAL")
        _conn.execute("""CREATE TABLE IF NOT EXISTS cve_cache (
            cve_id      TEXT PRIMARY KEY,
            tech        TEXT,
            version_min TEXT DEFAULT '',
            version_max TEXT DEFAULT '',
            severity    TEXT,
            cvss_score  REAL DEFAULT 0,
            description TEXT,
            nuclei_tags TEXT DEFAULT '',
            source      TEXT DEFAULT 'local',
            added_at    REAL,
            epss_score  REAL DEFAULT 0,
            in_kev      INTEGER DEFAULT 0
        )""")
        _conn.execute("""CREATE TABLE IF NOT EXISTS domain_cves (
            id          TEXT PRIMARY KEY,
            domain      TEXT,
            cve_id      TEXT,
            tech        TEXT,
            version     TEXT,
            severity    TEXT,
            confirmed   INTEGER DEFAULT 0,
            nuclei_hit  INTEGER DEFAULT 0,
            detected_at REAL
        )""")
        _conn.execute("CREATE INDEX IF NOT EXISTS idx_cve_tech ON cve_cache(tech)")
        _conn.execute("CREATE INDEX IF NOT EXISTS idx_dcve_domain ON domain_cves(domain)")
        _conn.commit()
        _seed_local_db()
    return _conn


# ── Local CVE seed data — version-aware ──────────────────────────────────────
# Format: (cve_id, tech, version_min, version_max, severity, cvss, description, nuclei_tags)
_SEED_CVES = [
    # Apache HTTP Server
    ("CVE-2021-41773","apache","2.4.49","2.4.49","critical",9.8,"Path traversal + RCE via mod_cgi on Apache 2.4.49","apache,rce,lfi"),
    ("CVE-2021-42013","apache","2.4.49","2.4.50","critical",9.8,"Apache 2.4.49-2.4.50 RCE via path traversal","apache,rce"),
    ("CVE-2022-31813","apache","2.4.0","2.4.53","high",9.8,"Apache mod_proxy forward request headers","apache"),
    ("CVE-2024-38473","apache","2.4.0","2.4.59","high",7.5,"Apache HTTP Server mod_rewrite SSRF","apache,ssrf"),

    # Nginx
    ("CVE-2021-23017","nginx","0.6.18","1.20.0","critical",8.1,"nginx DNS resolver off-by-one heap write","nginx"),
    ("CVE-2024-7347","nginx","1.25.0","1.27.0","medium",5.5,"nginx HTTP/3 QUIC out-of-bounds read","nginx"),

    # IIS
    ("CVE-2021-31166","iis","10.0","10.0","critical",9.8,"IIS HTTP Protocol Stack RCE — pre-auth","iis,rce"),
    ("CVE-2022-21907","iis","10.0","10.0","critical",9.8,"HTTP Protocol Stack remote code execution","iis,rce"),
    ("CVE-2022-30130","iis","","","low",3.3,".NET Framework DoS via crafted request","iis"),

    # Tomcat
    ("CVE-2025-24813","tomcat","9.0.0","9.0.98","critical",9.8,"Apache Tomcat partial PUT RCE — no auth required","tomcat,rce"),
    ("CVE-2022-42252","tomcat","8.5.0","8.5.82","high",7.5,"Apache Tomcat request smuggling","tomcat"),
    ("CVE-2023-28709","tomcat","9.0.0","9.0.74","high",7.5,"Apache Tomcat DoS via incomplete multipart","tomcat"),
    ("CVE-2019-0232","tomcat","9.0.0","9.0.17","critical",9.8,"Apache Tomcat CGI RCE on Windows","tomcat,rce"),

    # Spring
    ("CVE-2022-22965","spring","5.3.0","5.3.17","critical",9.8,"Spring4Shell — RCE via classLoader","spring,rce"),
    ("CVE-2022-22963","spring","3.1.6","3.2.2","critical",9.8,"Spring Cloud Function SpEL injection RCE","spring,rce"),
    ("CVE-2021-22096","spring","5.3.0","5.3.12","medium",4.3,"Spring Framework insufficient encoding","spring"),
    ("CVE-2024-38819","spring","6.0.0","6.1.14","high",7.5,"Spring Framework path traversal","spring,lfi"),

    # Log4j
    ("CVE-2021-44228","log4j","2.0","2.14.1","critical",10.0,"Log4Shell — JNDI injection RCE — unauth remote","log4j,rce,jndi"),
    ("CVE-2021-45046","log4j","2.0","2.15.0","critical",9.0,"Log4Shell bypass — context lookup RCE","log4j,rce"),
    ("CVE-2021-45105","log4j","2.0","2.16.0","high",7.5,"Log4j2 infinite recursion DoS","log4j"),
    ("CVE-2021-44832","log4j","2.0","2.17.0","medium",6.6,"Log4j2 RCE via JDBC Appender","log4j,rce"),

    # WordPress
    ("CVE-2022-21661","wordpress","5.8.0","5.8.3","high",8.8,"WordPress SQL injection via WP_Query","wordpress,sqli"),
    ("CVE-2022-21663","wordpress","5.8.0","5.8.3","medium",6.8,"WordPress stored XSS via template names","wordpress,xss"),
    ("CVE-2024-4439","wordpress","6.5.0","6.5.1","high",7.2,"WordPress core XSS in Avatar URL field","wordpress,xss"),
    ("CVE-2023-22622","wordpress","","","medium",5.3,"WordPress subscriber+ arbitrary file upload","wordpress"),

    # Drupal
    ("CVE-2022-25271","drupal","8.0.0","9.3.15","high",8.1,"Drupal arbitrary PHP code execution","drupal,rce"),
    ("CVE-2023-29197","drupal","9.4.0","9.5.10","high",7.5,"Drupal access bypass via phar stream","drupal"),

    # Jenkins
    ("CVE-2024-23897","jenkins","2.0","2.441","critical",9.8,"Jenkins CLI arbitrary file read — unauth","jenkins,lfi"),
    ("CVE-2023-27898","jenkins","2.0","2.393","critical",9.8,"Jenkins XSS/CSRF leading to RCE","jenkins,xss,rce"),
    ("CVE-2022-34177","jenkins","2.0","2.355","medium",7.5,"Jenkins arbitrary file write via pipeline","jenkins"),

    # Confluence
    ("CVE-2023-22515","confluence","8.0.0","8.5.2","critical",10.0,"Confluence Data Center privilege escalation — unauth admin","confluence,rce"),
    ("CVE-2023-22518","confluence","","","critical",10.0,"Confluence improper auth — data destruction possible","confluence"),
    ("CVE-2022-26134","confluence","7.4.0","7.18.0","critical",9.8,"Confluence Server OGNL injection RCE — unauth","confluence,rce"),
    ("CVE-2021-26084","confluence","6.13.0","7.12.5","critical",9.8,"Confluence OGNL injection RCE via setup wizard","confluence,rce"),

    # GitLab
    ("CVE-2023-7028","gitlab","16.0","16.6.0","critical",10.0,"GitLab account takeover via password reset — unauth","gitlab"),
    ("CVE-2023-2825","gitlab","16.0","16.0.0","critical",10.0,"GitLab path traversal arbitrary file read","gitlab,lfi"),
    ("CVE-2021-22205","gitlab","11.9","13.10.2","critical",10.0,"GitLab ExifTool RCE — unauth image upload","gitlab,rce"),

    # Jira
    ("CVE-2022-0540","jira","8.0.0","8.22.1","critical",9.8,"Jira authentication bypass via WebWork","jira"),
    ("CVE-2021-26086","jira","8.4.0","8.19.1","medium",5.3,"Jira path traversal information disclosure","jira,lfi"),

    # Redis
    ("CVE-2022-24736","redis","7.0.0","7.0.0","low",3.3,"Redis SRANDMEMBER integer overflow","redis"),
    ("CVE-2023-28856","redis","7.0.0","7.0.11","medium",6.5,"Redis OBJECT ENCODING OOB read","redis"),

    # Grafana
    ("CVE-2021-43798","grafana","8.0.0","8.3.0","high",7.5,"Grafana path traversal — unauth file read","grafana,lfi"),
    ("CVE-2022-31097","grafana","5.0.0","9.0.3","high",8.8,"Grafana stored XSS via Unified Alerting","grafana,xss"),
    ("CVE-2024-9264","grafana","11.0.0","11.0.4","critical",9.9,"Grafana SQL Expressions RCE via DuckDB","grafana,rce"),

    # Elasticsearch
    ("CVE-2021-22144","elasticsearch","7.0.0","7.13.3","medium",6.5,"Elasticsearch zip bomb DoS via search","elasticsearch"),
    ("CVE-2023-31419","elasticsearch","8.0.0","8.9.1","medium",6.5,"Elasticsearch StackOverflow DoS","elasticsearch"),

    # PHP
    ("CVE-2024-4577","php","8.1.0","8.1.28","critical",9.8,"PHP CGI argument injection RCE on Windows","php,rce"),
    ("CVE-2024-2961","php","8.1.0","8.1.28","high",7.5,"PHP iconv buffer overflow","php"),
    ("CVE-2023-3824","php","8.0.0","8.1.21","high",9.4,"PHP phar heap buffer overflow","php"),

    # Node.js
    ("CVE-2023-32002","node","20.0.0","20.4.0","critical",9.8,"Node.js policy experimental sandbox escape","node,rce"),
    ("CVE-2024-22025","node","18.0.0","21.6.1","medium",6.5,"Node.js path traversal via fetch","node,lfi"),

    # Next.js
    ("CVE-2025-29927","nextjs","13.0.0","14.2.24","critical",9.1,"Next.js middleware auth bypass via x-middleware-subrequest","nextjs"),
    ("CVE-2024-46982","nextjs","13.0.0","14.2.9","high",7.5,"Next.js cache poisoning via crafted request","nextjs,cache"),

    # Kubernetes
    ("CVE-2024-0193","kubernetes","1.26.0","1.28.6","high",8.8,"Kubernetes privilege escalation via netfilter","kubernetes"),
    ("CVE-2023-5528","kubernetes","1.0.0","1.28.3","high",8.8,"Kubernetes CSI provisioner SSRF","kubernetes,ssrf"),

    # Docker
    ("CVE-2024-21626","docker","25.0.0","25.0.2","high",8.6,"runc container escape — GHSA","docker,rce"),
    ("CVE-2023-39325","docker","","","high",7.5,"HTTP/2 rapid reset DoS (affects many runtimes)","docker"),

    # OpenSSH
    ("CVE-2024-6387","openssh","4.4","9.7","critical",8.1,"OpenSSH regreSSHion race condition RCE — unauth","ssh,rce"),
    ("CVE-2023-38408","openssh","5.5","9.3","critical",9.8,"OpenSSH ssh-agent RCE via PKCS#11","ssh,rce"),

    # Exim (from XBOW post)
    ("CVE-2026-45185","exim","4.97","4.97","critical",9.8,"Exim GnuTLS UAF — unauthenticated RCE via BDAT+STARTTLS","smtp,rce"),
    ("CVE-2021-27216","exim","4.0","4.94","critical",9.8,"Exim 21Nails: multiple RCE vulnerabilities","smtp,rce"),
    ("CVE-2023-42115","exim","4.0","4.96.1","critical",9.8,"Exim SMTP AUTH OOB write — unauth","smtp,rce"),

    # Postfix / Sendmail
    ("CVE-2023-51765","postfix","3.0","3.8.4","high",7.5,"Postfix SMTP smuggling","smtp"),

    # ProxyShell/Exchange
    ("CVE-2021-34473","exchange","15.0","15.2.922","critical",9.8,"Exchange ProxyShell SSRF pre-auth","exchange,ssrf,rce"),
    ("CVE-2021-34523","exchange","15.0","15.2.922","critical",9.8,"Exchange privilege escalation","exchange,rce"),
    ("CVE-2022-41082","exchange","15.0","15.2.1118","critical",8.8,"Exchange ProxyNotShell RCE post-auth","exchange,rce"),

    # VMware
    ("CVE-2021-21985","vmware","6.5","7.0.2","critical",9.8,"VMware vCenter Server RCE via Plugin","vmware,rce"),
    ("CVE-2021-22005","vmware","6.5","7.0.2","critical",9.8,"VMware vCenter arbitrary file upload","vmware,rce"),

    # Laravel
    ("CVE-2024-52301","laravel","11.0","11.29","critical",9.8,"Laravel env injection via query string","laravel,rce"),
    ("CVE-2021-43503","laravel","8.0","8.6.11","high",8.8,"Laravel deserialization RCE","laravel,rce"),

    # Django
    ("CVE-2022-28346","django","2.2","4.0.3","high",9.8,"Django SQL injection via QuerySet.annotate","django,sqli"),
    ("CVE-2023-41164","django","3.2","4.2.4","high",7.5,"Django potential ReDoS in EmailValidator","django"),

    # Rails
    ("CVE-2022-32224","rails","6.0","7.0.3","critical",9.8,"Rails deserialization RCE via cookie","rails,rce"),
    ("CVE-2023-22796","rails","5.0","7.0.3","high",7.5,"Rails ReDoS in ActiveRecord sanitize_sql_like","rails"),

    # Struts
    ("CVE-2023-50164","struts","2.5.0","2.5.32","critical",9.8,"Apache Struts2 file upload path traversal","struts,rce,lfi"),
    ("CVE-2022-25762","struts","2.5.0","2.5.29","high",8.1,"Struts2 path traversal OGNL injection","struts"),
]


def _seed_local_db():
    """Seed the CVE DB with known CVEs on first run."""
    existing = _conn.execute("SELECT COUNT(*) FROM cve_cache").fetchone()[0]
    if existing >= len(_SEED_CVES):
        return
    ts = time.time()
    for row in _SEED_CVES:
        cve_id, tech, vmin, vmax, sev, cvss, desc, tags = row
        _conn.execute("""INSERT OR REPLACE INTO cve_cache
            (cve_id, tech, version_min, version_max, severity, cvss_score,
             description, nuclei_tags, source, added_at)
            VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (cve_id, tech, vmin, vmax, sev, cvss, desc, tags, "local", ts))
    _conn.commit()
    log.info(f"[cve] seeded {len(_SEED_CVES)} CVEs to local DB")


# ── Version parsing ────────────────────────────────────────────────────────────

def _parse_version(v: str) -> Tuple[int, ...]:
    """Parse version string to tuple for comparison. '2.4.49' → (2, 4, 49)"""
    if not v: return (0,)
    parts = re.findall(r'\d+', v)
    return tuple(int(p) for p in parts[:4]) if parts else (0,)


def _version_in_range(version: str, vmin: str, vmax: str) -> bool:
    """Return True if version is between vmin and vmax (inclusive)."""
    if not vmin and not vmax: return True  # no version constraint
    v = _parse_version(version)
    if vmin and v < _parse_version(vmin): return False
    if vmax and v > _parse_version(vmax): return False
    return True


# ── Banner parsing ─────────────────────────────────────────────────────────────

# Regex patterns to extract tech + version from service banners
_BANNER_PATTERNS = [
    # HTTP Server headers
    (r'Apache[/ ]([\d.]+)', 'apache'),
    (r'nginx/([\d.]+)', 'nginx'),
    (r'Microsoft-IIS/([\d.]+)', 'iis'),
    (r'Apache Tomcat/([\d.]+)', 'tomcat'),
    # Mail servers
    (r'Exim ([\d.]+)', 'exim'),
    (r'Postfix ([\d.]+)', 'postfix'),
    (r'Sendmail ([\d.]+)', 'sendmail'),
    (r'Dovecot ([\d.]+)', 'dovecot'),
    # SSH
    (r'OpenSSH[_/ ]([\d.]+p?\d*)', 'openssh'),
    # FTP
    (r'ProFTPD ([\d.]+)', 'proftpd'),
    (r'vsftpd ([\d.]+)', 'vsftpd'),
    # Databases
    (r'MySQL ([\d.]+)', 'mysql'),
    (r'PostgreSQL ([\d.]+)', 'postgresql'),
    (r'Redis ([\d.]+)', 'redis'),
    # CMSes / apps
    (r'WordPress/([\d.]+)', 'wordpress'),
    (r'Drupal ([\d.]+)', 'drupal'),
    (r'Joomla[!/ ]*([\d.]+)', 'joomla'),
    # Frameworks / languages
    (r'PHP/([\d.]+)', 'php'),
    (r'Python/([\d.]+)', 'python'),
    (r'Ruby/([\d.]+)', 'ruby'),
    (r'Java/([\d.]+)', 'java'),
    (r'Jetty/([\d.]+)', 'jetty'),
    # Cloud
    (r'AmazonS3', 'aws'),
    (r'CloudFront', 'aws'),
]


def parse_banner(banner: str) -> List[Dict]:
    """
    Extract tech + version from a service banner string.
    Returns list of {tech, version} dicts.
    """
    results = []
    seen = set()
    for pattern, tech in _BANNER_PATTERNS:
        m = re.search(pattern, banner, re.I)
        if m and tech not in seen:
            version = m.group(1) if m.lastindex else ""
            results.append({"tech": tech, "version": version.strip()})
            seen.add(tech)
    return results


# ── Core CVE matching ──────────────────────────────────────────────────────────

def match_cves(tech: str, version: str = "") -> List[Dict]:
    """
    Match a single tech + version against the CVE DB.
    Returns list of matching CVEs sorted by severity/CVSS.
    """
    tech_lower = tech.lower().strip()
    # Normalize tech names
    _ALIASES = {
        "apache http server": "apache", "apache httpd": "apache",
        "microsoft iis": "iis", "internet information services": "iis",
        "apache tomcat": "tomcat", "spring boot": "spring",
        "spring framework": "spring", "apache struts": "struts",
        "next.js": "nextjs", "node.js": "node",
        "openssh": "openssh", "exim mta": "exim",
    }
    for alias, canonical in _ALIASES.items():
        if alias in tech_lower: tech_lower = canonical; break

    rows = _db().execute("""
        SELECT cve_id, tech, version_min, version_max, severity, cvss_score,
               description, nuclei_tags, source
        FROM cve_cache
        WHERE LOWER(tech) LIKE ?
        ORDER BY cvss_score DESC, severity
    """, (f"%{tech_lower}%",)).fetchall()

    results = []
    for row in rows:
        d = dict(row)
        # Version check — skip if version given and doesn't match range
        if version:
            if not _version_in_range(version, d.get("version_min",""),
                                              d.get("version_max","")):
                continue
        sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        d["severity_order"] = sev_order.get(d.get("severity","low"), 4)
        d["version_matched"] = bool(version)
        d["version_checked"] = version or "unknown"
        results.append(d)

    results.sort(key=lambda x: (x["severity_order"], -x.get("cvss_score", 0)))
    return results


def correlate_domain_cves(domain: str, db_ref) -> List[Dict]:
    """
    Main entry point: correlate all detected tech for a domain against CVEs.

    1. Get tech stack from recon DB
    2. Parse version from each tech string
    3. Match against CVE DB
    4. Check if nuclei has templates for matched CVEs
    5. Store domain_cves for analyst review
    Returns prioritized list of CVE matches.
    """
    try:
        tech_list = db_ref.get_tech(domain) or []
    except Exception:
        tech_list = []

    # Also pull from live hosts (banner data if available)
    try:
        live_hosts = db_ref.get_active(domain) or []
        for host in live_hosts:
            banner = host.get("banner","") or host.get("server","") or ""
            if banner:
                for parsed in parse_banner(banner):
                    entry = f"{parsed['tech'].title()}/{parsed['version']}" if parsed['version'] else parsed['tech']
                    if entry not in tech_list:
                        tech_list.append(entry)
    except Exception:
        pass

    if not tech_list:
        return []

    all_cves = []
    seen_cves = set()
    ts = time.time()

    for tech_entry in tech_list:
        # Parse tech name and version from entries like "Apache/2.4.49" or "WordPress 5.9"
        version = ""
        tech = tech_entry
        m = re.match(r'^([^/\s:]+)[/\s:]+([\d.]+)', tech_entry)
        if m:
            tech    = m.group(1)
            version = m.group(2)

        matches = match_cves(tech, version)
        for cve in matches:
            if cve["cve_id"] in seen_cves: continue
            seen_cves.add(cve["cve_id"])
            cve["matched_from_tech"] = tech_entry
            all_cves.append(cve)

            # Store in domain_cves table
            try:
                import secrets as _sec
                _db().execute("""INSERT OR REPLACE INTO domain_cves
                    (id, domain, cve_id, tech, version, severity, confirmed, nuclei_hit, detected_at)
                    VALUES (?,?,?,?,?,?,0,0,?)""",
                    (_sec.token_hex(6), domain, cve["cve_id"],
                     tech, version, cve.get("severity","unknown"), ts))
            except Exception: pass

    try: _db().commit()
    except Exception: pass

    # Sort: critical first, then by CVSS
    all_cves.sort(key=lambda x: (x.get("severity_order", 4), -x.get("cvss_score", 0)))
    log.info(f"[cve] domain={domain} tech_count={len(tech_list)} cve_matches={len(all_cves)}")
    return all_cves


def get_domain_cves(domain: str) -> List[Dict]:
    """Return previously correlated CVEs for a domain."""
    rows = _db().execute("""
        SELECT dc.*, cc.cvss_score, cc.description, cc.nuclei_tags
        FROM domain_cves dc
        LEFT JOIN cve_cache cc ON cc.cve_id = dc.cve_id
        WHERE dc.domain=?
        ORDER BY cc.cvss_score DESC
    """, (domain,)).fetchall()
    return [dict(r) for r in rows]


# ── NVD/OSV Live Feed ──────────────────────────────────────────────────────────

def fetch_nvd_cves(tech: str, limit: int = 10) -> List[Dict]:
    """
    Fetch recent CVEs from NVD API v2 for a given tech keyword.
    Requires no API key for basic queries.
    Results cached to local DB.
    """
    url = (f"https://services.nvd.nist.gov/rest/json/cves/2.0"
           f"?keywordSearch={urllib.parse.quote(tech)}&resultsPerPage={limit}")
    import urllib.parse
    data = _fetch(url, timeout=15)
    if not data: return []

    results = []
    ts = time.time()
    for item in data.get("vulnerabilities", [])[:limit]:
        cve_data = item.get("cve", {})
        cve_id   = cve_data.get("id","")
        if not cve_id: continue

        # Extract CVSS score
        cvss = 0.0
        metrics = cve_data.get("metrics", {})
        for key in ("cvssMetricV31","cvssMetricV30","cvssMetricV2"):
            if key in metrics and metrics[key]:
                cvss = metrics[key][0].get("cvssData",{}).get("baseScore", 0.0)
                break

        # Severity
        sev = "medium"
        if cvss >= 9.0: sev = "critical"
        elif cvss >= 7.0: sev = "high"
        elif cvss >= 4.0: sev = "medium"
        elif cvss > 0:    sev = "low"

        # Description
        descs = cve_data.get("descriptions", [])
        desc  = next((d["value"] for d in descs if d.get("lang") == "en"), "")[:300]

        result = {
            "cve_id": cve_id, "tech": tech, "version_min": "", "version_max": "",
            "severity": sev, "cvss_score": cvss, "description": desc,
            "nuclei_tags": tech.lower(), "source": "nvd",
        }
        results.append(result)

        # Cache to local DB
        try:
            with _lock:
                _db().execute("""INSERT OR REPLACE INTO cve_cache
                    (cve_id, tech, version_min, version_max, severity, cvss_score,
                     description, nuclei_tags, source, added_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (cve_id, tech, "", "", sev, cvss, desc, tech.lower(), "nvd", ts))
                _db().commit()
        except Exception: pass

    log.info(f"[cve] nvd fetch tech={tech} results={len(results)}")
    return results


def fetch_osv_cves(package: str, ecosystem: str = "PyPI") -> List[Dict]:
    """
    Fetch CVEs from OSV (Open Source Vulnerabilities) API.
    Supports PyPI, npm, Go, Maven, etc.
    """
    url  = "https://api.osv.dev/v1/query"
    body = json.dumps({"package": {"name": package, "ecosystem": ecosystem}}).encode()
    try:
        req = urllib.request.Request(url, data=body,
            headers={"Content-Type":"application/json","User-Agent":"BugScanELITE/1.0"},
            method="POST")
        with urllib.request.urlopen(req, timeout=10, context=_ctx()) as r:
            data = json.loads(r.read())
    except Exception as e:
        log.debug(f"[cve] osv {package}: {e}")
        return []

    results = []
    for vuln in data.get("vulns", [])[:10]:
        vid   = vuln.get("id","")
        cve   = next((a for a in vuln.get("aliases",[]) if a.startswith("CVE-")), vid)
        desc  = vuln.get("summary","")[:300]
        sev   = "medium"
        for s in vuln.get("severity",[]):
            score = s.get("score","")
            if "CRITICAL" in score: sev="critical"; break
            elif "HIGH" in score:   sev="high"; break
        results.append({
            "cve_id": cve, "tech": package, "severity": sev,
            "description": desc, "source": "osv", "cvss_score": 0,
        })
    log.info(f"[cve] osv {package}/{ecosystem}: {len(results)} vulns")
    return results


# ── Nuclei template selector ───────────────────────────────────────────────────

def get_nuclei_tags_for_cves(cve_list: List[Dict]) -> List[str]:
    """
    Return nuclei -tags arguments to scan for matched CVEs.
    Combines CVE IDs and tech tags.
    """
    tags = set()
    cve_ids = []
    for cve in cve_list:
        cve_id = cve.get("cve_id","")
        if cve_id.startswith("CVE-"):
            cve_ids.append(cve_id.lower())
        for tag in (cve.get("nuclei_tags","") or "").split(","):
            t = tag.strip()
            if t: tags.add(t)
    # Nuclei tag format: -tags cve,apache,rce
    all_tags = sorted(tags)
    return all_tags, cve_ids


def build_nuclei_cve_command(target: str, cve_list: List[Dict],
                              nuclei_bin: str = "nuclei",
                              severity_filter: str = "critical,high") -> List[str]:
    """
    Build a nuclei command targeting specific CVEs.
    Only probes — no exploit payloads.
    Returns command list (for display/human review, not auto-exec).
    """
    tags, cve_ids = get_nuclei_tags_for_cves(cve_list)
    cmd = [nuclei_bin, "-target", target,
           "-severity", severity_filter,
           "-silent", "-j"]

    if cve_ids[:10]:
        # Use -id to target specific CVE templates
        cmd += ["-id", ",".join(cve_ids[:10])]
    elif tags:
        cmd += ["-tags", ",".join(tags[:5])]
    else:
        cmd += ["-tags", "cve"]

    return cmd


# ── Stats ──────────────────────────────────────────────────────────────────────

def get_cve_stats() -> Dict:
    """Return DB stats for the CVE engine."""
    try:
        total = _db().execute("SELECT COUNT(*) FROM cve_cache").fetchone()[0]
        by_sev = dict(_db().execute(
            "SELECT severity, COUNT(*) FROM cve_cache GROUP BY severity").fetchall())
        by_src = dict(_db().execute(
            "SELECT source, COUNT(*) FROM cve_cache GROUP BY source").fetchall())
        domains = _db().execute("SELECT COUNT(DISTINCT domain) FROM domain_cves").fetchone()[0]
        return {
            "total_cves":     total,
            "by_severity":    by_sev,
            "by_source":      by_src,
            "domains_scanned": domains,
        }
    except Exception as e:
        return {"error": str(e)}


# Lazy init
import urllib.parse
