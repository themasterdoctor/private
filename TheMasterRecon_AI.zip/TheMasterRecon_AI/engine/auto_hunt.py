"""
TheMasterRecon AI — Autonomous Hunt Mode
Loop: findings → Claude analysis → new targeted payload → execute → repeat
"""
import json, logging, os, ssl, time, urllib.request, urllib.parse
from typing import Dict, List, Optional

log = logging.getLogger("elite.autohunt")
API_KEY = os.environ.get("ANTHROPIC_API_KEY","")
MODEL   = "claude-sonnet-4-6"

def _claude(prompt: str, system: str, max_tokens: int = 800) -> str:
    if not API_KEY:
        return json.dumps({"payloads":[],"reasoning":"No API key configured"})
    body = json.dumps({
        "model": MODEL, "max_tokens": max_tokens, "system": system,
        "messages": [{"role":"user","content":prompt}]
    }).encode()
    ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages", data=body,
        headers={"Content-Type":"application/json","x-api-key":API_KEY,
                 "anthropic-version":"2023-06-01"})
    try:
        with urllib.request.urlopen(req, timeout=30, context=ctx) as r:
            data = json.loads(r.read())
            return data["content"][0]["text"]
    except Exception as e:
        log.error(f"Claude: {e}")
        return "{}"

# ── System prompt ─────────────────────────────────────────────────────────────
_SYSTEM = """You are an elite offensive security researcher embedded in TheMasterRecon AI.
Given scan findings, you generate PRECISE attack payloads for the next iteration.

ALWAYS respond with valid JSON only:
{
  "payloads": [
    {"bug": "xss", "url": "...", "param": "q", "payload": "...", "method": "GET"},
    ...
  ],
  "reasoning": "...",
  "priority_bug": "sqli",
  "next_action": "escalate|pivot|report"
}

Rules:
- Generate 3-8 targeted payloads based on what was found
- Escalate: if SQLi found → try UNION SELECT for data extraction
- Pivot: if SSRF found → probe internal services at 169.254.169.254
- Only generate payloads for bugs with confirmed endpoints
- Include WAF bypass variants if WAF is detected"""

# ── Natural language scan parser ──────────────────────────────────────────────
_NL_SYSTEM = """You are a bug bounty scanner assistant. Parse natural language requests into
scanner configuration JSON. Respond ONLY with valid JSON.

Example input: "find all IDOR in API endpoints"
Example output:
{
  "bugs": ["idor","mass_assign"],
  "endpoint_filter": "/api/",
  "param_targets": ["id","user_id","account_id"],
  "reasoning": "IDOR targets API endpoints with ID parameters"
}

Available bugs: xss, sqli, lfi, ssrf, ssti, idor, cors, rce, jwt, graphql, nosqli,
redirect, crlf, xxe, deserialization, prototype, fileupload, buckets, jsleak,
expose, actuator, panels, takeover, misconfig, business_logic, bxss, cors_deep,
smuggling, race_condition, oauth, saml, jwt_deep, cache_poison, mass_assign,
reset_poison, websocket, mfa_bypass, dep_confusion, ssrf_cloud"""

_FP_SYSTEM = """You are a senior penetration tester reviewing vulnerability scanner findings.
Determine if each finding is a real vulnerability or false positive.

Respond ONLY with valid JSON:
{
  "verdict": "confirmed|probable|possible|unlikely|false_positive",
  "confidence": 0-100,
  "reasoning": "...",
  "recommendation": "escalate|verify|discard"
}

Be skeptical of:
- Generic error pages that happen to contain SQL keywords
- CORS on * without credentials — low severity, not critical
- Self-XSS (only exploitable by the victim themselves)
- Port scan results on common non-sensitive ports"""

# ── AI False Positive Filter ──────────────────────────────────────────────────
def ai_filter_finding(finding: Dict) -> Dict:
    """Ask Claude if a finding is real or FP. Returns {verdict, confidence, reasoning}."""
    prompt = json.dumps({
        "finding": {
            "bug":          finding.get("bug_type") or finding.get("bug",""),
            "severity":     finding.get("severity",""),
            "url":          finding.get("url",""),
            "title":        finding.get("title",""),
            "payload":      finding.get("payload") or finding.get("poc","")[:200],
            "raw_request":  finding.get("raw_request","")[:400],
            "raw_response": finding.get("raw_response","")[:400],
            "confidence":   finding.get("confidence",50),
        }
    }, indent=2)
    raw = _claude(prompt, _FP_SYSTEM, max_tokens=400)
    try:
        result = json.loads(raw)
        return result
    except Exception:
        return {"verdict":"possible","confidence":50,"reasoning":"Parse error","recommendation":"verify"}

# ── Natural language scanner ──────────────────────────────────────────────────
def parse_nl_scan(user_input: str, endpoints: List[str]) -> Dict:
    """
    Parse 'find all IDOR in /api/' → {bugs:[...], endpoint_filter:'...', param_targets:[...]}
    """
    # Sample endpoints to help Claude
    sample = endpoints[:20] if endpoints else []
    prompt = json.dumps({
        "user_request": user_input,
        "sample_endpoints": sample,
        "total_endpoints": len(endpoints),
    }, indent=2)
    raw = _claude(prompt, _NL_SYSTEM, max_tokens=400)
    try:
        result = json.loads(raw)
        # Apply endpoint filter
        ef = result.get("endpoint_filter","")
        if ef and endpoints:
            result["filtered_endpoints"] = [e for e in endpoints if ef.lower() in e.lower()]
        return result
    except Exception:
        return {"bugs":[], "reasoning":"Parse error", "filtered_endpoints": endpoints[:100]}

# ── Auto-hunt loop ────────────────────────────────────────────────────────────
def auto_hunt_iteration(findings: List[Dict], domain: str,
                         endpoints: List[str], waf: str = "") -> Dict:
    """
    Given current findings, ask Claude for next-iteration payloads.
    Returns {payloads:[...], reasoning:'...', priority_bug:'...'}
    """
    # Summarise findings for Claude
    summary = []
    for f in findings[:15]:
        summary.append({
            "bug":      f.get("bug_type") or f.get("bug",""),
            "severity": f.get("severity",""),
            "url":      f.get("url",""),
            "title":    f.get("title",""),
            "param":    f.get("param",""),
            "payload":  f.get("payload","")[:60] if f.get("payload") else "",
            "confirmed":f.get("confirmed",False),
        })
    prompt = json.dumps({
        "domain":    domain,
        "waf":       waf,
        "findings":  summary,
        "endpoints": endpoints[:30],
    }, indent=2)

    raw = _claude(prompt, _SYSTEM, max_tokens=600)
    try:
        result = json.loads(raw)
        return result
    except Exception:
        return {"payloads":[], "reasoning":"Parse error", "next_action":"report"}

# ── Execute hunt payloads ─────────────────────────────────────────────────────
def execute_hunt_payloads(payloads: List[Dict], q=None) -> List[Dict]:
    """Run AI-generated payloads, return new findings."""
    import ssl, urllib.parse, urllib.request
    from concurrent.futures import ThreadPoolExecutor, as_completed
    results = []

    def _probe(p: Dict):
        url     = p.get("url","")
        param   = p.get("param","")
        payload = p.get("payload","")
        method  = p.get("method","GET").upper()
        bug     = p.get("bug","")
        if not url: return None
        try:
            parsed = urllib.parse.urlparse(url)
            qs     = dict(urllib.parse.parse_qsl(parsed.query))
            if param: qs[param] = payload
            test_url = urllib.parse.urlunparse(parsed._replace(query=urllib.parse.urlencode(qs)))
            ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            req = urllib.request.Request(test_url, headers={
                "User-Agent":"Mozilla/5.0","Accept":"*/*"})
            with urllib.request.urlopen(req, timeout=10, context=ctx) as r:
                body = r.read(1<<20).decode("utf-8","replace")
                status = r.status
                hdrs   = dict(r.headers)
            # Check for finding signals
            hit = False; evidence = ""
            if bug == "xss" and payload and payload in body:
                hit = True; evidence = f"Payload reflected"
            elif bug in ("sqli","sqli_time") and any(s in body for s in ["SQL syntax","ORA-","SQLSTATE","mysql_fetch"]):
                hit = True; evidence = "SQL error"
            elif bug == "ssrf" and any(s in body for s in ["ami-id","metadata","computeMetadata"]):
                hit = True; evidence = "SSRF confirmed"
            if hit:
                if q: q.put({"type":"finding","finding":{
                    "bug":bug,"bug_type":bug,"severity":"high","url":url,
                    "title":f"[AutoHunt] {bug.upper()} via {param}",
                    "param":param,"payload":payload,"poc":f"curl '{test_url}'",
                    "confidence":80,"autohunt":True,"evidence":evidence,
                }})
                return {"hit":True,"url":test_url,"bug":bug,"evidence":evidence,"param":param,"payload":payload}
        except Exception as e:
            log.debug(f"hunt probe {url}: {e}")
        return None

    with ThreadPoolExecutor(max_workers=8) as exe:
        futs = {exe.submit(_probe, p): p for p in payloads}
        for fut in as_completed(futs, timeout=120):
            try:
                r = fut.result(timeout=15)
                if r: results.append(r)
            except: pass
    return results
