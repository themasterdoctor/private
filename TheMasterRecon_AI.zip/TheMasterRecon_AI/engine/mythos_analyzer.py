"""
BugScan ELITE — Mythos-style Root Cause Analyzer
Mission: Reason like a senior vulnerability researcher.
Find the broken assumption. Map the trust boundary. 
Show what the attacker knows that the developer forgot.
"""
from typing import Dict, List, Optional
import re

# ── Broken assumption templates per bug type ──────────────────────────────────
_BROKEN_ASSUMPTIONS: Dict[str, Dict] = {
    "xss": {
        "assumption": "User input will be rendered safely in HTML context",
        "broken_by":  "Input is reflected without encoding, allowing arbitrary HTML/JS injection",
        "trust_boundary": "Browser ↔ Server: server trusted that rendered content was safe for DOM execution",
        "root_causes": [
            "Missing output encoding (HTML entity encoding not applied)",
            "Dangerous sinks used without sanitization (innerHTML, document.write, eval)",
            "Content-Type mismatch (JSON served as text/html)",
            "Template engine auto-escape disabled",
            "DOM-based: client-side code uses location.hash or postMessage without validation",
        ],
        "chain_paths": [
            "Reflected XSS → session cookie theft → account takeover",
            "Stored XSS → admin panel → persistent access",
            "DOM XSS → postMessage → cross-origin data theft",
            "XSS + CSRF → state-changing actions on behalf of victim",
        ],
        "ask": "Can this XSS steal session tokens? Can it reach privileged endpoints? Is CSP weak enough to bypass?",
    },
    "sqli": {
        "assumption": "User input will be treated as data, never as SQL syntax",
        "broken_by":  "Input is interpolated directly into SQL query without parameterization",
        "trust_boundary": "Application ↔ Database: application trusted that all queries were constructed safely",
        "root_causes": [
            "String concatenation used instead of prepared statements",
            "ORM raw() / execute() called with user input",
            "Type casting not applied before numeric input in queries",
            "Second-order injection: input stored safely but replayed unsafely later",
        ],
        "chain_paths": [
            "Error-based SQLi → schema dump → credential extraction → auth bypass",
            "Blind boolean SQLi → user data exfiltration → account takeover",
            "Time-based SQLi → automated dump → mass data breach",
            "SQLi + FILE privilege → LFI/RCE via LOAD_FILE / INTO OUTFILE",
        ],
        "ask": "Is this DB user privileged? Is FILE privilege granted? Can we reach auth tables?",
    },
    "ssrf": {
        "assumption": "The server can safely fetch user-provided URLs and the result is harmless",
        "broken_by":  "Server makes HTTP requests to attacker-controlled destinations including internal network",
        "trust_boundary": "External Internet ↔ Internal Network: server's network position was not considered untrusted",
        "root_causes": [
            "URL validation missing or bypassable (DNS rebinding, redirects, IP encoding)",
            "HTTP client follows redirects to private IP ranges",
            "Cloud metadata endpoint accessible (169.254.169.254, fd00::ec2::254)",
            "Internal services lack auth because they assumed external inaccessibility",
        ],
        "chain_paths": [
            "SSRF → AWS IMDSv1 → IAM credentials → full cloud account access",
            "SSRF → internal Redis → session forgery → auth bypass",
            "SSRF → Kubernetes API → pod enumeration → privilege escalation",
            "SSRF → internal admin panel → arbitrary actions as admin",
        ],
        "ask": "Is IMDSv2 enforced? What internal services are reachable? Can we redirect to 169.254.x.x?",
    },
    "idor": {
        "assumption": "Objects can only be accessed by users who own them",
        "broken_by":  "Object references are predictable and authorization is not re-verified per request",
        "trust_boundary": "User A ↔ User B: authorization assumed that knowing an ID implies ownership",
        "root_causes": [
            "Authorization check missing or only at session level, not per-object",
            "Sequential or guessable IDs (integer, UUID v1, timestamp-based)",
            "Indirect reference maps not used (direct DB IDs exposed in API)",
            "Horizontal privilege escalation: different users, same privilege level",
            "Vertical privilege escalation: user accesses admin objects",
        ],
        "chain_paths": [
            "IDOR on /api/users/{id} → mass account data exfiltration",
            "IDOR on /api/orders/{id} → competitor price/customer data leak",
            "IDOR + parameter pollution → privilege escalation to admin role",
            "IDOR on file endpoint → arbitrary file access / path traversal combo",
        ],
        "ask": "Can we enumerate? What data is exposed? Can we modify other users' data? Can we reach admin IDs?",
    },
    "cors": {
        "assumption": "CORS headers correctly restrict which origins can access sensitive data",
        "broken_by":  "Origin validation is missing, permissive, or bypassable via subdomain/prefix tricks",
        "trust_boundary": "Origin A ↔ Origin B: server trusted that browser enforces same-origin policy without CORS",
        "root_causes": [
            "Origin header reflected without validation",
            "Prefix matching: attacker registers evil.target.com",
            "Null origin allowed: sandbox/file:// origin accepted",
            "Wildcard (*) with credentials: browsers block this but some clients don't",
            "Subdomain takeover + CORS = attacker-controlled trusted origin",
        ],
        "chain_paths": [
            "CORS misconfiguration → authenticated API response readable from evil.com",
            "CORS + OAuth token in response → account takeover via token theft",
            "CORS + IDOR → bulk data exfiltration from another user's account",
            "CORS on admin API → admin action execution from attacker page",
        ],
        "ask": "Are credentials included? What data is in the response? Is there an auth token? Can we register evil.target.com?",
    },
    "jwt": {
        "assumption": "JWT signature guarantees authenticity and the algorithm is enforced server-side",
        "broken_by":  "Server accepts tampered tokens, allows alg:none, or is vulnerable to key confusion",
        "trust_boundary": "Client ↔ Server: server trusted that token contents were unmodifiable without the secret",
        "root_causes": [
            "alg:none accepted: no signature verification when alg is none",
            "Algorithm confusion (RS256 → HS256): public key used as HMAC secret",
            "Weak secret: brute-forceable HMAC secret",
            "kid injection: kid parameter used in file read or SQL query",
            "JWK injection: server accepts attacker-provided JWK for verification",
        ],
        "chain_paths": [
            "JWT alg:none → forge any user's token → account takeover",
            "Algorithm confusion → forge admin token → full privilege escalation",
            "kid SQL injection → bypass JWT verification entirely",
            "Weak secret → offline crack → persistent token forgery",
        ],
        "ask": "Can we change the alg header? What claims are trusted? Is there a kid parameter? What is the secret strength?",
    },
    "rce": {
        "assumption": "User input cannot influence what commands the server executes",
        "broken_by":  "Input reaches a command execution sink without sanitization",
        "trust_boundary": "User ↔ OS: application trusted that user input was data, not code",
        "root_causes": [
            "Shell injection: subprocess called with shell=True and user input",
            "Deserialization: unsafe pickle/Java deserialization of user data",
            "SSTI leading to code execution via template engine escapes",
            "File upload + execution: uploaded file interpreted as code",
            "Log poisoning: LFI + log injection + PHP inclusion = code execution",
        ],
        "chain_paths": [
            "Command injection → reverse shell → full server access",
            "Deserialization RCE → internal network pivoting → lateral movement",
            "SSTI RCE → read /etc/passwd, .env, cloud credentials",
            "File upload webshell → persistent backdoor → exfiltration",
        ],
        "ask": "What user runs the process? Are there file system restrictions? Can we reach cloud metadata? What can we read?",
    },
    "oauth": {
        "assumption": "OAuth flow cannot be hijacked by a third party",
        "broken_by":  "State parameter missing/not validated, redirect_uri not strict, or code reuse possible",
        "trust_boundary": "User ↔ OAuth Provider ↔ Client: flow assumes attacker cannot intercept the code",
        "root_causes": [
            "Missing state parameter: CSRF on authorization endpoint",
            "Redirect URI not validated: code sent to attacker-controlled domain",
            "Authorization code reuse: code accepted more than once",
            "Token leakage in Referer header or browser history",
            "Implicit flow: token in URL fragment leaks via referrer",
        ],
        "chain_paths": [
            "OAuth CSRF → link victim's account to attacker's OAuth → ATO",
            "redirect_uri bypass → code theft → token exchange → ATO",
            "State fixation → login CSRF → victim logs into attacker's session",
        ],
        "ask": "Is state validated? Is redirect_uri strict? Can we register a similar domain? Is there a code timeout?",
    },
    "lfi": {
        "assumption": "File paths provided by users are constrained to safe directories",
        "broken_by":  "Path traversal sequences (../) are not normalized before file system access",
        "trust_boundary": "User ↔ File System: server trusted that users could not escape intended directory",
        "root_causes": [
            "Path concatenation without normalization",
            "Null byte injection bypassing extension checks (pre-PHP 5.3)",
            "PHP wrappers: php://filter, php://input, phar://",
            "Zip slip: archive extraction follows symlinks or ../ in filenames",
        ],
        "chain_paths": [
            "LFI /etc/passwd → user enumeration → targeted attacks",
            "LFI + PHP wrapper → source code disclosure → further vulns",
            "LFI → /proc/self/environ → log poisoning → RCE",
            "LFI → SSH keys, .env files → credential theft",
        ],
        "ask": "Can we read /etc/passwd? .env? Can we include PHP wrappers? Is there a log file we can poison first?",
    },
    "ssti": {
        "assumption": "Template variables are data, not code, and cannot escape the template context",
        "broken_by":  "User input reaches a template engine and is rendered as template syntax",
        "trust_boundary": "User ↔ Template Engine: application trusted that template context was isolated",
        "root_causes": [
            "Direct rendering of user input as template string",
            "Jinja2 autoescape disabled",
            "ERB/Twig/Pebble with user-controlled template fragments",
            "String formatting used as template engine (Python % / .format())",
        ],
        "chain_paths": [
            "SSTI → {{config.items()}} → secret key disclosure",
            "SSTI → subprocess.Popen → RCE",
            "SSTI → read /etc/passwd, SSH keys, cloud credentials",
        ],
        "ask": "What template engine? Can we call __class__.__mro__? Can we reach subclasses? Can we execute os.system?",
    },
    "graphql": {
        "assumption": "GraphQL introspection and resolvers only expose authorized data",
        "broken_by":  "Introspection enabled in production, resolvers lack per-field authorization",
        "trust_boundary": "User ↔ API Schema: server trusted that schema structure was not sensitive",
        "root_causes": [
            "Introspection not disabled in production — exposes full schema to attackers",
            "Per-field authorization missing — resolver checks only route-level auth",
            "Batching attacks: send 1000 queries in one request bypassing rate limits",
            "SQL injection through GraphQL arguments: id parameter unsanitized",
            "IDOR through GraphQL nodes: sequential/guessable IDs in node(id:) interface",
        ],
        "chain_paths": [
            "Introspection → schema dump → find sensitive mutations → exploit",
            "GraphQL IDOR → mass user data via node() interface",
            "GraphQL SQLi → database dump → credential theft",
            "Mutation CSRF → state change on behalf of authenticated user",
        ],
        "ask": "Is introspection disabled? Are mutations rate-limited? Do resolvers check field-level auth?",
    },
    "takeover": {
        "assumption": "DNS records only point to services the organization actively controls",
        "broken_by":  "CNAME or NS record points to an external service that is no longer provisioned",
        "trust_boundary": "DNS ↔ External Service: org trusted that deprovisioned services would keep their DNS",
        "root_causes": [
            "Deprovisioned Heroku/GitHub Pages/S3/Netlify app with DNS CNAME remaining",
            "Dangling NS delegation: subdomain NS points to registrar that attacker can claim",
            "MX takeover: mail service deprovisioned but MX record remains",
            "Azure/GCP/AWS service deprovisioned but CNAME to cloud hostname remains",
        ],
        "chain_paths": [
            "Subdomain takeover → serve malicious content from trusted domain",
            "Takeover → cookies scoped to *.parent.com stolen",
            "Takeover + XSS → CSP bypass (subdomain was whitelisted)",
            "MX takeover → intercept email → password resets → ATO",
        ],
        "ask": "What cookies are scoped to *.domain? Is this subdomain in any CSP? Can we receive email via MX takeover?",
    },
    "cache_poison": {
        "assumption": "Cached responses are consistent for all users requesting the same URL",
        "broken_by":  "Request headers that vary per-user are reflected in responses but not included in cache key",
        "trust_boundary": "User ↔ Cache ↔ Origin: cache trusted that all requests for a URL were equivalent",
        "root_causes": [
            "X-Forwarded-Host / X-Host reflected in response but not in cache key",
            "Unkeyed query parameters reflected in response (UTM params, etc.)",
            "Fat GET: body of GET request reflected but not cached",
            "Cookie-based variations not included in cache key",
        ],
        "chain_paths": [
            "Cache poison → reflect arbitrary JS host → XSS delivery to all users",
            "Cache poison → redirect users to phishing page",
            "Cache poison + open redirect → steal OAuth codes from cached redirects",
            "Cache DOS: poison with invalid response → service unavailable for all users",
        ],
        "ask": "What headers are reflected? What is the cache key? Can we poison a high-traffic page?",
    },
    "race": {
        "assumption": "Sequential operations complete atomically — no concurrent state corruption",
        "broken_by":  "Check-then-act pattern executed concurrently creates a race window for double-spending",
        "trust_boundary": "Request ↔ Database: application trusted that operations appeared atomic to concurrent users",
        "root_causes": [
            "Check-use race: if (balance >= amount) { deduct() } — two threads pass check simultaneously",
            "Missing database-level locking (SELECT FOR UPDATE not used)",
            "Optimistic concurrency without version checking",
            "Coupon/voucher redemption without atomic test-and-set",
        ],
        "chain_paths": [
            "Race condition on payment → double-spend → financial fraud",
            "Race on coupon code → unlimited discount abuse",
            "Race on account limits → bypass rate limits / send quota",
            "Race on privilege check → privilege escalation window",
        ],
        "ask": "Can we send 20 concurrent requests? Is there a SELECT FOR UPDATE? Is Redis SETNX used?",
    },
    "deserialization": {
        "assumption": "Deserialized data is from a trusted source and cannot execute code",
        "broken_by":  "Attacker-controlled serialized data is deserialized, triggering gadget chains",
        "trust_boundary": "Network ↔ Application: application trusted that serialized objects were integrity-protected",
        "root_causes": [
            "Java ObjectInputStream deserializes untrusted data (Apache Commons gadget chains)",
            "Python pickle.loads() called on user-controlled data",
            "PHP unserialize() on cookie or POST data",
            "YAML.load() instead of YAML.safe_load() in Python",
            "JWT with HS256 deserializes attacker-controlled header parameters",
        ],
        "chain_paths": [
            "Java deserialization + Commons Collections → RCE via gadget chain",
            "Python pickle → os.system() → reverse shell",
            "PHP deserialization → __destruct() gadget → file write → webshell",
            "Deserialization RCE → internal network pivot → cloud credentials",
        ],
        "ask": "What language/framework? Is there a gadget library (Commons Collections, Spring, etc.)? Can we send binary data?",
    },
    "fileupload": {
        "assumption": "Uploaded files are validated and cannot be executed as code",
        "broken_by":  "File type validation is bypassable and uploaded files are stored in web-accessible locations",
        "trust_boundary": "User ↔ Web Server: server trusted that uploaded content was data, not executable code",
        "root_causes": [
            "Content-Type validation only (client-controlled, not server-enforced)",
            "Extension check bypassable: file.php.jpg, file.pHp, file.php%00.jpg",
            "MIME sniffing: browser interprets uploaded HTML/JS as executable",
            "Upload path is web-accessible: /uploads/shell.php directly reachable",
            "Archive extraction with path traversal (zip slip)",
        ],
        "chain_paths": [
            "File upload webshell → RCE → full server compromise",
            "SVG upload → XSS via SVG JavaScript execution",
            "SSRF via file upload → fetch internal resources via SVG/HTML",
            "Zip slip → overwrite application files → backdoor",
        ],
        "ask": "Where are files stored? Is the path web-accessible? What extensions are blocked? Can we bypass with double extension?",
    },
    "xxe": {
        "assumption": "XML parsing is safe and external entity references cannot be resolved",
        "broken_by":  "XML parser resolves external entity references, enabling file read or SSRF",
        "trust_boundary": "User ↔ XML Parser: application trusted that XML could not reference external resources",
        "root_causes": [
            "XML parser with external entity processing enabled (libxml2 default before 2.13)",
            "DOCTYPE not stripped before parsing",
            "SVG, DOCX, XLSX, or other XML-based formats parsed with entity expansion",
            "SAML assertions parsed without external entity protection",
        ],
        "chain_paths": [
            "XXE → /etc/passwd file read → user enumeration",
            "XXE → SSRF → cloud metadata → IAM credentials",
            "Blind XXE → OOB DNS → confirm exploitability",
            "XXE in SAML → auth bypass via signature wrapping",
        ],
        "ask": "What XML parser? Is DOCTYPE allowed? Can we send SVG/DOCX? Is there a blind OOB channel?",
    },
    "default": {
        "assumption": "Application enforces security controls on this operation",
        "broken_by":  "An attacker-controlled input or action bypasses an intended security control",
        "trust_boundary": "User ↔ Application: assumption about what users can control was incorrect",
        "root_causes": ["Security control is missing, incomplete, or bypassable"],
        "chain_paths": ["Finding may chain with other vulnerabilities for higher impact"],
        "ask": "What does this allow? What data or actions become accessible? What assumption did the developer make?",
    }
}


def analyze_root_cause(finding: Dict) -> Dict:
    """
    Mythos-style root cause analysis.
    Returns structured analysis for each finding.
    """
    bug      = finding.get("bug", finding.get("bug_type", "")).lower()
    url      = finding.get("url", "")
    severity = finding.get("severity", "info")
    desc     = finding.get("description", "")
    
    template = _BROKEN_ASSUMPTIONS.get(bug, _BROKEN_ASSUMPTIONS["default"])
    
    # Infer most likely root cause from evidence
    likely_root_cause = _infer_root_cause(bug, desc, finding)
    
    # Score chain potential
    chain_risk = _score_chain_potential(bug, severity, finding)
    
    # Generate attack hypothesis
    hypothesis = _generate_hypothesis(bug, url, finding, template)
    
    return {
        "broken_assumption": template["assumption"],
        "broken_by":         template["broken_by"],
        "trust_boundary":    template["trust_boundary"],
        "all_root_causes":   template["root_causes"],
        "likely_root_cause": likely_root_cause,
        "attack_chains":     template["chain_paths"],
        "chain_risk_score":  chain_risk,
        "investigator_ask":  template["ask"],
        "hypothesis":        hypothesis,
        "exploitability":    _exploitability_score(bug, finding),
    }


def _infer_root_cause(bug: str, desc: str, finding: Dict) -> str:
    desc_lower = desc.lower()
    poc        = str(finding.get("poc", "")).lower()
    
    if bug == "sqli":
        if "time-based" in desc_lower or "sleep" in poc: return "Time-based blind SQLi — no visible error output"
        if "error" in desc_lower: return "Error-based SQLi — SQL errors returned in response"
        if "boolean" in desc_lower: return "Boolean-based blind SQLi — different response for true/false"
        if "union" in poc: return "UNION-based SQLi — query can be extended"
        return "SQLi — technique to be confirmed by manual testing"
    
    if bug == "xss":
        if "dom" in desc_lower: return "DOM-based XSS — client-side JS processes user input unsafely"
        if "stored" in bug: return "Stored XSS — malicious input persisted in database, executed on load"
        return "Reflected XSS — input echoed back in HTML response without encoding"
    
    if bug == "ssrf":
        if "169.254" in poc or "metadata" in desc_lower: return "Cloud metadata endpoint reachable — potential IAM credential theft"
        if "localhost" in poc or "127.0.0.1" in poc: return "Localhost services reachable — internal service exposure"
        if "oob" in desc_lower: return "Out-of-band SSRF confirmed — DNS/HTTP callback received"
        return "SSRF — server fetches attacker-controlled URLs"
    
    if bug == "idor":
        param = finding.get("param", "")
        return f"IDOR on parameter '{param}' — object authorization not verified per-request"
    
    if bug == "cors":
        origin = finding.get("details", {}).get("origin_tested", "")
        if "null" in origin: return "Null origin accepted — sandbox/file:// origin trusted"
        return f"CORS: origin '{origin}' accepted — insufficient validation"
    
    if bug == "jwt":
        if "none" in desc_lower: return "alg:none accepted — signature verification skipped"
        if "confusion" in desc_lower: return "Algorithm confusion — RS256 public key used as HS256 HMAC secret"
        if "kid" in desc_lower: return "kid injection — key ID parameter processed unsafely"
        return "JWT misconfiguration — signing verification can be bypassed"
    
    return "Root cause requires manual investigation — see investigator_ask for guidance"


def _score_chain_potential(bug: str, severity: str, finding: Dict) -> int:
    """Score 0-100 how likely this finding chains to high-impact exploitation."""
    score = 0
    
    # Base score by severity
    base = {"critical": 80, "high": 60, "medium": 40, "low": 20, "info": 5}
    score += base.get(severity, 20)
    
    # Bug type multipliers
    chain_bugs = {
        "ssrf": 20, "rce": 25, "sqli": 20, "ssti": 20,
        "cors": 15, "idor": 15, "oauth": 20, "jwt": 20,
        "lfi": 15, "xss": 10, "xxe": 15, "takeover": 20,
    }
    score += chain_bugs.get(bug, 5)
    
    # Evidence bonuses
    if finding.get("oob_confirmed"): score += 10
    if finding.get("param"): score += 5
    if finding.get("poc") and len(str(finding.get("poc", ""))) > 50: score += 5
    
    return min(100, score)


def _generate_hypothesis(bug: str, url: str, finding: Dict, template: Dict) -> str:
    param = finding.get("param", "")
    desc  = finding.get("description", "")[:100]
    
    param_str = f" via parameter '{param}'" if param else ""
    
    return (
        f"Hypothesis: The application at {url} {template['broken_by'].lower()}{param_str}. "
        f"The broken assumption is: '{template['assumption']}'. "
        f"To confirm impact, investigate: {template['ask']}"
    )


def _exploitability_score(bug: str, finding: Dict) -> int:
    """Score how exploitable this finding is in practice (0-100)."""
    score = 50  # base
    
    # Hard evidence
    if finding.get("oob_confirmed"): score += 30
    if finding.get("eil_confirmed"): score += 25
    if finding.get("poc") and "curl" in str(finding.get("poc", "")): score += 15
    
    # Bug class inherent exploitability
    easy_bugs = {"rce", "sqli", "ssti", "xxe"}
    hard_bugs  = {"cache_poison", "race_condition", "business_logic"}
    if bug in easy_bugs: score += 10
    if bug in hard_bugs: score -= 10
    
    # Confidence adjustment
    conf = int(finding.get("confidence", 50))
    score += (conf - 50) // 5
    
    return max(0, min(100, score))


def generate_mythos_report(finding: Dict) -> str:
    """
    Generate Mythos-style vulnerability analysis narrative.
    Format: suitable for H1 report 'Root Cause' section.
    """
    analysis = analyze_root_cause(finding)
    bug      = finding.get("bug", "vulnerability")
    url      = finding.get("url", "")
    param    = finding.get("param", "")
    
    lines = [
        f"## Root Cause Analysis",
        f"",
        f"**Broken Assumption:** {analysis['broken_assumption']}",
        f"",
        f"**How It's Broken:** {analysis['broken_by']}",
        f"",
        f"**Trust Boundary Violated:** {analysis['trust_boundary']}",
        f"",
        f"**Most Likely Root Cause:** {analysis['likely_root_cause']}",
        f"",
        f"**Attack Chain Risk:** {analysis['chain_risk_score']}/100",
        f"",
        f"**Potential Attack Chains:**",
    ]
    
    for chain in analysis["attack_chains"][:3]:
        lines.append(f"- {chain}")
    
    lines += [
        f"",
        f"**Investigator Questions:**",
        f"{analysis['investigator_ask']}",
        f"",
        f"**Hypothesis:**",
        f"{analysis['hypothesis']}",
    ]
    
    return "\n".join(lines)
