"""
BugScan ELITE — Executive Report Generator
Converts technical findings into C-suite readable security reports.
Includes: security score, financial impact, top risks, remediation roadmap.
"""
import time, json, re
from typing import Dict, List, Optional
from pathlib import Path

def generate_executive_report(domain: str, scored_results: Dict,
                               chains: List[Dict] = None,
                               company_name: str = "",
                               industry: str = "default") -> Dict:
    """
    Generate a complete executive security report.
    Input: scored_results from risk_engine.score_all_findings()
    Output: structured report dict (render as HTML/PDF/markdown)
    """
    chains       = chains or []
    findings     = scored_results.get("findings", [])
    stats        = scored_results.get("stats", {})
    sec_score    = scored_results.get("security_score", 100)
    company_name = company_name or domain

    # Score grade
    if sec_score >= 90:   grade, grade_color = "A", "#00c853"
    elif sec_score >= 75: grade, grade_color = "B", "#64dd17"
    elif sec_score >= 60: grade, grade_color = "C", "#ffab00"
    elif sec_score >= 40: grade, grade_color = "D", "#ff6d00"
    else:                 grade, grade_color = "F", "#d50000"

    by_sev    = stats.get("by_severity", {})
    top_risks = _top_risks(findings[:5])
    roadmap   = _remediation_roadmap(findings)
    financial = _financial_summary(findings, industry)
    exec_summary = _executive_summary(
        company_name, domain, sec_score, grade, by_sev,
        financial["total_exposure"], chains, industry
    )

    return {
        "meta": {
            "domain":       domain,
            "company":      company_name,
            "industry":     industry,
            "generated_at": time.strftime("%Y-%m-%d %H:%M UTC"),
            "report_id":    f"BSE-{int(time.time())}",
        },
        "security_score": {
            "score":       sec_score,
            "grade":       grade,
            "grade_color": grade_color,
            "label":       _score_label(sec_score),
            "delta":       None,  # Compare to previous scan
        },
        "executive_summary": exec_summary,
        "findings_overview": {
            "total":    stats.get("total", 0),
            "critical": by_sev.get("critical", 0),
            "high":     by_sev.get("high", 0),
            "medium":   by_sev.get("medium", 0),
            "low":      by_sev.get("low", 0),
        },
        "financial_impact":    financial,
        "top_risks":           top_risks,
        "attack_chains":       _summarize_chains(chains),
        "remediation_roadmap": roadmap,
        "regulatory_exposure": _regulatory_summary(findings, industry),
        "technical_findings":  findings[:50],  # Top 50 for report
        "appendix": {
            "methodology": _methodology_text(),
            "scope":       f"Full scan of {domain} and all discovered subdomains",
            "tools":       "BugScan ELITE — Passive recon, active scanning, AI risk analysis",
        },
    }


def _score_label(score: int) -> str:
    if score >= 90: return "Excellent — Security posture is strong"
    if score >= 75: return "Good — Minor issues requiring attention"
    if score >= 60: return "Fair — Significant vulnerabilities present"
    if score >= 40: return "Poor — Critical issues requiring immediate action"
    return "Critical — Organization is at immediate risk of breach"


def _executive_summary(company, domain, score, grade, by_sev,
                        total_exposure, chains, industry) -> str:
    crits  = by_sev.get("critical", 0)
    highs  = by_sev.get("high", 0)
    mediums= by_sev.get("medium", 0)

    chain_text = ""
    if chains:
        chain_text = (f" Our analysis identified {len(chains)} multi-step attack chain(s) "
                      f"that could allow an attacker to escalate from initial access to "
                      f"full system compromise without additional tools.")

    urgency = ""
    if crits > 0:
        urgency = (f" IMMEDIATE ACTION REQUIRED: {crits} critical vulnerabilit"
                   f"{'y requires' if crits==1 else 'ies require'} remediation "
                   f"within 24 hours to prevent a potential breach.")

    return (
        f"This security assessment of {company} ({domain}) identified a total of "
        f"{crits + highs + mediums} significant vulnerabilities across the target environment. "
        f"The overall security score is {score}/100 (Grade: {grade}). "
        f"{urgency}"
        f" The estimated total financial exposure from identified vulnerabilities is "
        f"{total_exposure}, considering potential breach costs, regulatory fines, "
        f"and reputational damage in the {industry} sector."
        f"{chain_text}"
        f" This report provides a prioritized remediation roadmap to systematically "
        f"address identified risks and improve the security posture."
    )


def _top_risks(top_findings: List[Dict]) -> List[Dict]:
    """Convert top findings into executive-friendly risk cards."""
    risks = []
    for f in top_findings:
        risks.append({
            "rank":             len(risks) + 1,
            "title":            _risk_title(f),
            "severity":         f.get("severity","medium"),
            "risk_score":       f.get("risk_score", 0),
            "location":         f.get("url","")[:80],
            "business_impact":  f.get("impact_narrative",""),
            "estimated_damage": f.get("estimated_damage","Unknown"),
            "fix_priority":     f.get("fix_priority",""),
            "regulatory":       f.get("regulatory_risk",{}),
        })
    return risks


def _risk_title(finding: Dict) -> str:
    bug_titles = {
        "sqli":        "SQL Injection — Database Compromise Risk",
        "rce":         "Remote Code Execution — Complete Server Takeover",
        "ssrf":        "Server-Side Request Forgery — Internal Network Access",
        "lfi":         "Local File Inclusion — Credential and Config Exposure",
        "xss":         "Cross-Site Scripting — User Session Compromise",
        "stored_xss":  "Stored XSS — Persistent Malicious Content",
        "idor":        "Broken Object Level Authorization — User Data Exposure",
        "mass_assign": "Mass Assignment — Unauthorized Privilege Escalation",
        "jwt":         "JWT Authentication Bypass — Account Takeover",
        "buckets":     "Exposed Cloud Storage — Public Data Disclosure",
        "takeover":    "Subdomain Takeover — Brand Impersonation Risk",
        "cache_poison":"Cache Poisoning — Mass User Manipulation",
        "reset_poison":"Password Reset Hijacking — Account Takeover",
        "cors":        "CORS Misconfiguration — Cross-Origin Data Theft",
        "expose":      "Sensitive File Exposure — Information Disclosure",
        "actuator":    "Spring Boot Actuator Exposed — Infrastructure Disclosure",
        "saml":        "SAML Vulnerability — Single Sign-On Bypass",
        "oauth":       "OAuth Misconfiguration — Authorization Bypass",
        "ssti":        "Template Injection — Potential Remote Code Execution",
        "xxe":         "XML External Entity — File System Access",
    }
    bug  = finding.get("bug","")
    desc = finding.get("description","")
    return bug_titles.get(bug, desc[:60] if desc else f"{bug.upper()} Vulnerability")


def _financial_summary(findings: List[Dict], industry: str) -> Dict:
    total    = 0
    by_type  = {}
    max_loss = 0

    for f in findings:
        dmg_str = f.get("estimated_damage","$0").replace("$","").replace(",","")
        try:
            dmg = int(dmg_str)
            total += dmg
            bug = f.get("bug","other")
            by_type[bug] = by_type.get(bug,0) + dmg
            max_loss = max(max_loss, dmg)
        except: pass

    # Industry breach cost multiplier (based on IBM Cost of Data Breach Report)
    industry_cost = {
        "healthcare":  10_930_000,
        "fintech":      6_080_000,
        "government":   2_070_000,
        "ecommerce":    3_270_000,
        "saas":         4_450_000,
        "enterprise":   5_000_000,
        "default":      4_350_000,  # Global average
    }
    avg_breach = industry_cost.get(industry, industry_cost["default"])

    # Top 3 most expensive vulnerability types
    top_types = sorted(by_type.items(), key=lambda x: -x[1])[:3]

    return {
        "total_exposure":        f"${total:,}",
        "total_exposure_int":    total,
        "max_single_finding":    f"${max_loss:,}",
        "industry_avg_breach":   f"${avg_breach:,}",
        "by_vulnerability_type": {k: f"${v:,}" for k, v in top_types},
        "note": (f"Estimates based on {industry} industry breach costs, "
                 f"regulatory fine exposure, and incident response costs. "
                 f"Actual costs may vary."),
    }


def _remediation_roadmap(findings: List[Dict]) -> Dict:
    """Group findings into 30/60/90 day remediation phases."""
    p0 = []  # < 24h
    p1 = []  # 1 week
    p2 = []  # 1 month
    p3 = []  # Next sprint

    for f in findings:
        priority = f.get("fix_priority","P3")
        item = {
            "title":    _risk_title(f),
            "url":      f.get("url","")[:60],
            "severity": f.get("severity",""),
            "effort":   _estimate_effort(f),
        }
        if "P0" in priority:   p0.append(item)
        elif "P1" in priority: p1.append(item)
        elif "P2" in priority: p2.append(item)
        else:                   p3.append(item)

    return {
        "phase_0_24h": {
            "label":    "Immediate (< 24 hours)",
            "items":    p0,
            "count":    len(p0),
            "rationale": "These findings present immediate exploitation risk and must be addressed before close of business.",
        },
        "phase_1_week": {
            "label":    "Short-term (1 week)",
            "items":    p1[:10],
            "count":    len(p1),
            "rationale": "High-severity findings that require coordinated remediation effort.",
        },
        "phase_2_month": {
            "label":    "Medium-term (1 month)",
            "items":    p2[:10],
            "count":    len(p2),
            "rationale": "Medium-severity findings that can be addressed in regular sprint cycles.",
        },
        "phase_3_sprint": {
            "label":    "Backlog (next sprints)",
            "items":    p3[:10],
            "count":    len(p3),
            "rationale": "Lower severity findings and hardening recommendations.",
        },
    }


def _estimate_effort(finding: Dict) -> str:
    bug = finding.get("bug","")
    effort_map = {
        "sqli":        "Medium (1-3 days) — parameterized queries throughout codebase",
        "xss":         "Low (hours) — output encoding in templates",
        "stored_xss":  "Medium (1-2 days) — sanitization + stored data cleanup",
        "idor":        "High (1-2 weeks) — authorization layer refactor",
        "mass_assign": "Low (hours) — add field allowlists to serializers",
        "cache_poison":"Low (hours) — remove unkeyed headers from cache",
        "reset_poison":"Low (hours) — build URLs from config not request host",
        "jwt":         "Medium (1-3 days) — key rotation + algorithm enforcement",
        "ssrf":        "Medium (1-3 days) — URL allowlist implementation",
        "lfi":         "Low (hours) — path traversal prevention",
        "buckets":     "Low (< 1 hour) — set bucket ACL to private",
        "cors":        "Low (hours) — update CORS allowlist",
        "expose":      "Low (< 1 hour) — web server config update",
        "actuator":    "Low (hours) — restrict actuator endpoints",
        "rce":         "High (1+ weeks) — full input validation audit",
    }
    return effort_map.get(bug, "Medium (1-3 days) — consult security team")


def _summarize_chains(chains: List[Dict]) -> List[Dict]:
    return [{
        "name":     c.get("name","Attack Chain"),
        "severity": c.get("severity","high"),
        "steps":    len(c.get("steps",[])),
        "impact":   c.get("impact",""),
        "summary":  " → ".join(s.get("type","?") for s in c.get("steps",[])[:5]),
    } for c in chains[:5]]


def _regulatory_summary(findings: List[Dict], industry: str) -> Dict:
    regulations: Dict[str, List[str]] = {}
    for f in findings:
        for reg, desc in f.get("regulatory_risk",{}).items():
            regulations.setdefault(reg,[]).append(desc)

    summary = {}
    for reg, items in regulations.items():
        summary[reg] = {
            "triggered_by": len(items),
            "description":  items[0] if items else "",
            "affected_findings": len(items),
        }
    return summary


def _methodology_text() -> str:
    return (
        "Assessment performed using BugScan ELITE automated security platform. "
        "Methodology includes: passive subdomain enumeration (27 OSINT sources), "
        "active endpoint discovery, technology fingerprinting, automated vulnerability "
        "scanning (nuclei, sqlmap, dalfox, custom checks), AI-powered risk scoring "
        "with business context, and multi-step attack chain analysis. "
        "All testing was performed with minimal traffic and no destructive operations."
    )


def report_to_markdown(report: Dict) -> str:
    """Convert report dict to markdown format for H1/Bugcrowd submission."""
    meta   = report["meta"]
    score  = report["security_score"]
    summ   = report["executive_summary"]
    risks  = report["top_risks"]
    fin    = report["financial_impact"]
    road   = report["remediation_roadmap"]

    md = f"""# Security Assessment Report
**Target:** {meta['domain']}  
**Company:** {meta['company']}  
**Date:** {meta['generated_at']}  
**Report ID:** {meta['report_id']}

---

## Security Score: {score['score']}/100 — Grade {score['grade']}

{score['label']}

---

## Executive Summary

{summ}

---

## Findings Overview

| Severity | Count |
|----------|-------|
| 🔴 Critical | {report['findings_overview']['critical']} |
| 🟠 High | {report['findings_overview']['high']} |
| 🟡 Medium | {report['findings_overview']['medium']} |
| 🔵 Low | {report['findings_overview']['low']} |

**Total Estimated Exposure:** {fin['total_exposure']}  
**Industry Average Breach Cost:** {fin['industry_avg_breach']}

---

## Top Risks

"""
    for risk in risks:
        md += f"""### {risk['rank']}. {risk['title']}
**Severity:** {risk['severity'].upper()}  
**Risk Score:** {risk['risk_score']}/100  
**Location:** `{risk['location']}`  
**Estimated Damage:** {risk['estimated_damage']}  
**Fix Priority:** {risk['fix_priority']}

{risk['business_impact']}

---
"""

    md += f"""## Remediation Roadmap

### Phase 0 — Immediate ({road['phase_0_24h']['count']} items)
"""
    for item in road["phase_0_24h"]["items"][:5]:
        md += f"- **{item['title']}** — {item['effort']}\n"

    md += f"\n### Phase 1 — This Week ({road['phase_1_week']['count']} items)\n"
    for item in road["phase_1_week"]["items"][:5]:
        md += f"- **{item['title']}** — {item['effort']}\n"

    md += f"\n---\n\n*{report['appendix']['methodology']}*\n"
    return md
