"""
BugScan ELITE — DNS Brute Force Engine
Active subdomain discovery via DNS resolution.
Finds subdomains that never appear in any passive source.

Strategy:
1. Built-in wordlist (top 5000 common subdomains)
2. puredns + massdns if installed (fastest — millions/sec)
3. shuffledns if installed  
4. Pure Python DNS resolver fallback (always works)

All results feed directly into the subdomain store.
"""
import os, re, socket, logging, threading, shutil, subprocess, tempfile
from typing import List, Set, Callable, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

log = logging.getLogger("elite.dns_brute")

# ── Wordlist — top 5000 subdomain prefixes ────────────────────────────────
# Sourced from SecLists best-dns-wordlist (condensed top 5000)
TOP_SUBS = """
www api mail smtp pop imap ftp dev staging stage test qa uat beta vpn
remote admin dashboard portal login auth sso oauth app mobile api2 cdn static assets media
images img files uploads downloads backup db mysql postgres redis mongo elasticsearch kibana grafana prometheus
jenkins gitlab github ci cd deploy build prod production dev2 dev3 staging2 test2 demo internal
intranet extranet git mail2 monitoring alerting exchange autodiscover webmail sip voip shop ecom payment checkout
cart billing docs documentation confluence jira helpdesk support ticket sandbox preprod preview feature release hotfix
patch web web2 web3 ns ns1 ns2 ns3 mx mx1 mx2 office365 owa sharepoint teams
corp meet video conference graphql search grpc legacy metrics archived deprecated health status uptime ping
partner affiliate reseller wholesale store hr payroll finance erp accounting crm salesforce docker wiki swarm
rancher openshift aws azure gcp cloud akamai fastly security firewall waf proxy gateway ingress s3
rest blob storage archive lan bastion jump microservice service svc worker k8s kubernetes job cron
notification sendgrid cloudfront mailgun webhook callback events stream pub message sub dev-api staging-api test-api prod-api
internal-api signin signup forgot reset password account accounts profile user analytics bi data devops sre
consul vault primary secondary replica cache memcache register varnish haproxy nginx apache tomcat pipeline auth2
saml oauth2 adfs keycloak okta push realtime ws websocket socket payments stripe braintree superadmin root
editor warehouse marketing collector aggregator remote-desktop old new next v1 v2 v3 v4 info sec
private public open feedback contact about careers jobs legal privacy terms help status2 api3 api4
app2 app3 home hub lab labs lambda ldap live load marketplace member merchant order orders
org origin platform profiles sandbox2 scheduler secret server services session settings slack source stat sync
system tech tools tracking ui upload verify version widget workspace smtp2 pop3 news blog forum
social media2 video2 photo photos map maps search2 directory network resources reports reporting dashboard2 console
client clients cloud2 customer customers data2 delivery design digital direct feed frontend game games go
help2 identity image index info2 infrastructure integration iot it jobs2 kafka legacy2 log logs lookup
mobile2 monitor2 operations partner2 pipeline2 postfix registry review role sandbox3 schedule stat2 static2 store2 stream2
sync2 tag task test3 token tools2 transfer upload2 use video3 vpn2 webhook2 work zone a
b c d e f g h i j k l m n o p
q r s t u v w x y z api-dev api-prod api-staging api-test api-v1
api-v2 api-v3 api-v4 api-v5 app-dev app-prod app-staging app-test auth-dev auth-prod auth-staging backend-api backend-dev backend-prod backend-staging
backend-test beta2 beta3 build2 cache2 cdn2 cdn3 chat client2 cloud3 code config configs configuration corp2
data3 db-dev db-prod db-staging debug delivery2 design2 dev-portal devportal devtest dhcp dns dns1 dns2 email-api
employee enterprise env env2 export feed2 file files2 forum2 ftp2 git2 go2 graphql2 grpc2 guest
helpdesk2 host http https hub2 id identity2 img2 import inbox index2 info3 integration2 internal2 internal3
intranet2 ip issue item key knowledge lab2 label language layer level link list local localhost
log2 login2 mail3 manage manage2 manager2 map2 member2 message2 metric mobile3 monitor3 move name net
network2 new2 next2 notify null object old2 old3 open2 optimize output overview page parse path
pay performance plan play point post print process project publish push2 query queue2 record redirect2
ref refresh relay report resource2 restart result route run save scope service2 set show sign
skill source2 start step store3 submit switch sync3 table target task2 test4 test5 time token2
topic trigger type update user2 users2 util validate value view watch write zone2 accounting2 admin2
admin3 alert alerts api-gateway api-internal app4 app5 archive2 asset2 assets2 audit auto backup2 backups base
batch board bot bridge cache3 call campaign central change channel check claim click code2 collect
command community connect control create customer2 dash database2 decommission delete deploy2 detail device dispatch dmz
domain download draft dynamic edge enable error event example explore extension external extra factor field
filter find fix flag flow format function generate group guide handler health2 host2 hub3 iam
image2 import2 inbox2 index3 info4 input install instance interface invite item2 key2 label2 lang ldap2
link2 list2 location log3 login3 lookup2 mail4 main manage3 manager3 map3 match meta method migration
model module monitor4 move2 name2 namespace nfs node2 notifications object2 oauth3 old4 onboarding open3 ops2
order2 org2 origin2 override overview2 page2 parse2 path2 pdf performance2 plan2 platform2 play2 plugin plugins
pool portal2 postfix2 print2 process2 product2 profile2 project2 publish2 push3 query2 queue3 rbac read realm
record2 redis2 region registry2 relay2 release2 remote2 render replace request reset2 resource3 restart2 result2 review2
role2 router run2 sandbox4 save2 schedule2 scope2 secret2 send service3 session2 settings2 setup sign2 signup2
site source3 space start2 stats step2 storage2 store4 strategy stream3 submit2 subscription sync4 system2 table2
tag2 target2 task3 tenant test6 time2 token3 tools3 topic2 trace track trigger2 type2 unit update2
upload3 user3 users3 util2 validate2 value2 vault2 verify2 version2 view2 webhook3 widget2 workflow workspace2 www4
zone3 dev4 dev5 stage2 stage3 preprod2 qa2 qa3 qa4 uat2 uat3 alpha alpha2 release3 rc
snapshot canary green blue rollback migration2
"""
TOP_SUBS = [w for w in TOP_SUBS.split() if w.strip()]


def _resolve(hostname: str, timeout: float = 2.0) -> Optional[str]:
    """Resolve hostname to IP. Returns IP or None."""
    try:
        return socket.gethostbyname(hostname)
    except: return None



def _detect_wildcard(domain: str) -> str:
    """
    Detect wildcard DNS on a domain.
    Returns the wildcard IP if all random subdomains resolve to same IP, else empty string.
    Uses 3 random 16-char subdomains to confirm.
    """
    import random, string as _str
    ips = []
    for _ in range(3):
        rand = ''.join(random.choices(_str.ascii_lowercase, k=16))
        ip = _resolve(f"{rand}.{domain}")
        if not ip:
            return ""   # at least one didn't resolve → no simple wildcard
        ips.append(ip)
    if len(set(ips)) == 1:
        wc_ip = ips[0]
        log.info(f"[dns_brute] Wildcard DNS on {domain} → {wc_ip} (filtering enabled)")
        return wc_ip
    return ""



def _find(name: str) -> Optional[str]:
    p = shutil.which(name)
    if p: return p
    for d in [
        "/usr/bin", "/usr/local/bin", "/usr/sbin",
        os.path.expanduser("~/go/bin"),
        "/root/go/bin", "/home/kali/go/bin",
        "/opt/massdns/bin", "/opt/puredns",
        os.path.expanduser("~/.local/bin"),
    ]:
        fp = os.path.join(d, name)
        if os.path.isfile(fp) and os.access(fp, os.X_OK):
            return fp
    return None


def brute_python(domain: str, wordlist: List[str] = None,
                 threads: int = 100,
                 callback: Callable = None,
                 stop_event: threading.Event = None) -> Set[str]:
    """
    Pure Python DNS brute force — always works, no external tools.
    Tests each word.domain, resolves via socket.gethostbyname.
    """
    words = wordlist or _get_words()
    found = set()
    tested = 0

    # Detect wildcard DNS first — filter it out
    wc_ip = _detect_wildcard(domain)
    if wc_ip:
        log.info(f"[dns_brute] Wildcard DNS ({wc_ip}) — will filter wildcard IPs from results")

    def _check(word):
        if stop_event and stop_event.is_set(): return None
        host = f"{word}.{domain}"
        ip = _resolve(host)
        if ip:
            # Filter out wildcard results
            if wc_ip and ip == wc_ip:
                return None
            log.debug(f"[dns_brute] FOUND: {host} → {ip}")
            return host
        return None

    log.info(f"[dns_brute] python: {len(words)} words, {threads} threads{'  (wildcard filtered)' if wc_ip else ''}")
    exe  = ThreadPoolExecutor(max_workers=threads)
    futs = {exe.submit(_check, w): w for w in words}
    cancelled = 0
    try:
        for fut in as_completed(futs, timeout=300):
            try:
                result = fut.result()
                if result:
                    found.add(result)
                    if callback: callback(result)
            except: pass
            tested += 1
            if tested % 500 == 0:
                log.debug(f"[dns_brute] {tested}/{len(words)} tested, {len(found)} found")
    except Exception:
        # TimeoutError or other — cancel all pending futures immediately
        for f in futs:
            if not f.done():
                f.cancel()
                cancelled += 1
        log.info(f"[dns_brute] budget_exceeded tested={tested} found={len(found)}"
                 f" cancelled_unfinished={cancelled}")
    finally:
        exe.shutdown(wait=False)  # do NOT block waiting for in-flight futures

    pct = len(found)*100//len(words) if words else 0
    if pct == 100 and len(found) > 50:
        log.info(f"[dns_brute] python done: {len(found)}/{len(words)} words resolved "
                 f"(100% hit rate — platform domain like vercel.app where every "
                 f"word is a real tenant subdomain — results are valid)")
    else:
        log.info(f"[dns_brute] python done: {len(found)} subdomains from {len(words)} words")
    return found


def brute_puredns(domain: str, wordlist_path: str = None,
                  resolvers_path: str = None,
                  callback: Callable = None) -> Set[str]:
    """
    puredns + massdns — fastest DNS brute forcer.
    Resolves millions of subdomains per second.
    Install: go install github.com/d3mondev/puredns/v2@latest
    """
    puredns = _find("puredns")
    massdns  = _find("massdns")
    if not puredns:
        log.info("[dns_brute] puredns not installed — go install github.com/d3mondev/puredns/v2@latest")
        return set()
    # massdns optional for puredns v2 (has built-in resolver engine)
    if not massdns:
        log.info("[dns_brute] massdns not found — puredns will use built-in resolver")

    found = set()

    # Use best available wordlist
    _cleanup_wl = False
    if not wordlist_path or not os.path.isfile(wordlist_path):
        wordlist_path = _best_wordlist()
        _cleanup_wl = wordlist_path.startswith(tempfile.gettempdir())

    # Default resolvers — public DNS
    if not resolvers_path or not os.path.isfile(resolvers_path):
        tmp_res = tempfile.mktemp(suffix=".txt")
        with open(tmp_res, "w") as f:
            # 50 public reliable resolvers for better puredns performance
            f.write("\n".join([
                "1.1.1.1","1.0.0.1","8.8.8.8","8.8.4.4",
                "9.9.9.9","149.112.112.112","208.67.222.222","208.67.220.220",
                "64.6.64.6","64.6.65.6","185.228.168.9","185.228.169.9",
                "77.88.8.8","77.88.8.1","94.140.14.14","94.140.15.15",
                "76.76.19.19","76.223.122.150","8.26.56.26","8.20.247.20",
                "156.154.70.1","156.154.71.1","198.101.242.72","23.253.163.53",
                "84.200.69.80","84.200.70.40","91.239.100.100","89.233.43.71",
                "74.82.42.42","109.69.8.51","195.46.39.39","195.46.39.40",
                "216.146.35.35","216.146.36.36","37.235.1.174","37.235.1.177",
                "45.90.28.0","45.90.30.0","180.76.76.76","223.5.5.5",
                "223.6.6.6","119.29.29.29","182.254.116.116","114.114.114.114",
            ]))
        resolvers_path = tmp_res
        _cleanup_res = True
    else:
        _cleanup_res = False

    try:
        import tempfile as _tf2
        out_file = _tf2.mktemp(suffix=".txt")
        cmd = [
            puredns, "brute",
            wordlist_path, domain,
            "--resolvers", resolvers_path,
            "--write", out_file,
            "-q",
        ]
        if massdns:
            cmd += ["--bin", massdns]
        log.info(f"[dns_brute] puredns: {wordlist_path} → {domain}")
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        # Read from both stdout and output file (version compatibility)
        raw_output = proc.stdout
        if os.path.exists(out_file):
            with open(out_file) as _of:
                raw_output += "\n" + _of.read()
            os.unlink(out_file)
        for line in raw_output.splitlines():
            sub = line.strip().lower()
            if sub and (sub == domain or sub.endswith("." + domain)):
                found.add(sub)
                if callback: callback(sub)
        log.info(f"[dns_brute] puredns done: {len(found)} subdomains")
    except subprocess.TimeoutExpired:
        log.warning("[dns_brute] puredns timeout")
    except Exception as e:
        log.warning(f"[dns_brute] puredns: {e}")
    finally:
        if _cleanup_wl:
            try: os.unlink(wordlist_path)
            except: pass
        if _cleanup_res:
            try: os.unlink(resolvers_path)
            except: pass

    return found


def brute_shuffledns(domain: str, wordlist_path: str = None,
                     callback: Callable = None) -> Set[str]:
    """
    shuffledns — massdns wrapper with wildcard filtering.
    Install: go install github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest
    """
    shuffledns = _find("shuffledns")
    massdns    = _find("massdns")
    if not shuffledns or not massdns:
        return set()

    found = set()
    tmp_wl = None

    if not wordlist_path or not os.path.isfile(wordlist_path):
        tmp_wl = tempfile.mktemp(suffix=".txt")
        with open(tmp_wl, "w") as f:
            f.write("\n".join(TOP_SUBS))
        wordlist_path = tmp_wl

    # Temp resolvers
    tmp_res = tempfile.mktemp(suffix=".txt")
    with open(tmp_res, "w") as f:
        f.write("1.1.1.1\n8.8.8.8\n9.9.9.9\n")

    try:
        cmd = [shuffledns, "-d", domain,
               "-w", wordlist_path,
               "-r", tmp_res,
               "-m", massdns,
               "-silent"]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        for line in proc.stdout.splitlines():
            sub = line.strip().lower()
            if sub and sub.endswith("." + domain):
                found.add(sub)
                if callback: callback(sub)
        log.info(f"[dns_brute] shuffledns: {len(found)} subdomains")
    except Exception as e:
        log.debug(f"[dns_brute] shuffledns: {e}")
    finally:
        for p in [tmp_res]:
            try: os.unlink(p)
            except: pass
        if tmp_wl:
            try: os.unlink(tmp_wl)
            except: pass

    return found



# ── Wordlist helpers ──────────────────────────────────────────────────────────
_SECLISTS_PATHS = [
    os.path.expanduser("~/Desktop/recon/SecLists/Discovery/DNS/subdomains-top1million-20000.txt"),
    "/home/kali/Desktop/recon/SecLists/Discovery/DNS/subdomains-top1million-20000.txt",
    "/root/Desktop/recon/SecLists/Discovery/DNS/subdomains-top1million-20000.txt",
    os.path.expanduser("~/SecLists/Discovery/DNS/subdomains-top1million-20000.txt"),
    "/usr/share/seclists/Discovery/DNS/subdomains-top1million-20000.txt",
    "/opt/SecLists/Discovery/DNS/subdomains-top1million-20000.txt",
    os.path.expanduser("~/Desktop/recon/SecLists/Discovery/DNS/bitquark-subdomains-top100000.txt"),
    "/home/kali/Desktop/recon/SecLists/Discovery/DNS/bitquark-subdomains-top100000.txt",
    os.path.expanduser("~/Desktop/recon/SecLists/Discovery/DNS/subdomains-top1million-110000.txt"),
    "/home/kali/Desktop/recon/SecLists/Discovery/DNS/subdomains-top1million-110000.txt",
    "/usr/share/wordlists/seclists/Discovery/DNS/subdomains-top1million-20000.txt",
]

def _find_seclists_wordlist() -> Optional[str]:
    """Find the best SecLists DNS wordlist on the system."""
    for path in _SECLISTS_PATHS:
        if path and os.path.isfile(path):
            log.info(f"[dns_brute] Using SecLists wordlist: {path}")
            return path
    return None


def _best_wordlist() -> str:
    """
    Return path to best available wordlist.
    Priority: SecLists (20k+) > built-in TOP_SUBS (831 words).
    Writes built-in to temp file if no SecLists found.
    """
    sl = _find_seclists_wordlist()
    if sl:
        return sl
    # Write built-in wordlist to temp file
    tmp = tempfile.mktemp(suffix=".txt")
    with open(tmp, "w") as f:
        f.write("\n".join(TOP_SUBS))
    log.info(f"[dns_brute] Using built-in wordlist ({len(TOP_SUBS)} words). "
             "Install SecLists for better coverage: "
             "git clone https://github.com/danielmiessler/SecLists ~/Desktop/recon/SecLists")
    return tmp


def _get_words() -> List[str]:
    """Load words from best available source."""
    sl = _find_seclists_wordlist()
    if sl:
        try:
            words = [l.strip() for l in open(sl) if l.strip() and not l.startswith("#")]
            return words[:50000]
        except Exception:
            pass
    return TOP_SUBS

def run_dns_brute(domain: str,
                  wordlist_path: str = None,
                  emit_fn: Callable = None,
                  add_fn: Callable = None,
                  stop_event: threading.Event = None) -> Set[str]:
    """
    Main entry — tries puredns → shuffledns → python fallback.
    All discovered subdomains emitted via emit_fn and stored via add_fn.
    """
    all_found = set()

    def _on_found(sub: str):
        if sub in all_found: return
        all_found.add(sub)
        log.info(f"[dns_brute] new: {sub}")
        if add_fn:
            try: add_fn(sub)
            except: pass
        if emit_fn:
            try: emit_fn({"type":"subdomain","sub":sub,"source":"dns_brute"})
            except: pass

    log.info(f"[dns_brute] starting on {domain}")

    # Use alterx to generate permuted wordlist from known subs (if available)
    alterx_bin = _find("alterx")
    if alterx_bin and all_found:
        import tempfile, os as _os
        try:
            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tf:
                for s in list(all_found)[:200]:
                    tf.write(s.split('.')[0] + chr(10))
                tf_name = tf.name
            proc = subprocess.run(
                [alterx_bin, "-enrich"],
                input=chr(10).join(s.split('.')[0] for s in list(all_found)[:200]),
                capture_output=True, text=True, timeout=30
            )
            if proc.stdout.strip():
                extra_words = set(proc.stdout.strip().split(chr(10)))
                log.info(f"[dns_brute] alterx: {len(extra_words)} permuted words")
                # These will be used in the brute force below
            _os.unlink(tf_name)
        except Exception as e:
            log.debug(f"[dns_brute] alterx: {e}")

        # Try fast tools first
    if _find("puredns") and _find("massdns"):
        log.info("[dns_brute] using puredns (fastest)")
        for sub in brute_puredns(domain, wordlist_path, callback=_on_found):
            _on_found(sub)
    elif _find("shuffledns") and _find("massdns"):
        log.info("[dns_brute] using shuffledns")
        for sub in brute_shuffledns(domain, wordlist_path, callback=_on_found):
            _on_found(sub)

    # Python fallback ALWAYS runs (different wordlist section if fast tools ran)
    # If fast tools found stuff, python does a targeted sweep with remaining words
    fast_found = len(all_found)
    log.info(f"[dns_brute] python sweep (fast tools found {fast_found})")
    for sub in brute_python(domain, TOP_SUBS, threads=150,
                            callback=_on_found, stop_event=stop_event):
        _on_found(sub)

    log.info(f"[dns_brute] total: {len(all_found)} subdomains discovered")
    return all_found
