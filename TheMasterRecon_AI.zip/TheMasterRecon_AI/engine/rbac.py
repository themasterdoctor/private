"""
TheMasterRecon AI — RBAC (Role-Based Access Control)
Multi-user system with roles: admin, analyst, viewer, reporter
Supports local auth + API key auth. No external SSO deps needed.
"""
import os, json, hashlib, secrets, time, logging, re
from pathlib import Path
from typing import Optional, Dict, List
from datetime import datetime, timedelta

log = logging.getLogger("elite.rbac")

ROLES = {
    "admin":    {"level":4, "desc":"Full access — manage users, all scans, all settings"},
    "analyst":  {"level":3, "desc":"Run scans, view all findings, generate reports"},
    "viewer":   {"level":2, "desc":"View findings and reports, no scan execution"},
    "reporter": {"level":1, "desc":"View and download reports only"},
}

PERMISSIONS = {
    "scan.run":         ["admin","analyst"],
    "scan.stop":        ["admin","analyst"],
    "recon.run":        ["admin","analyst"],
    "findings.view":    ["admin","analyst","viewer","reporter"],
    "findings.delete":  ["admin"],
    "report.view":      ["admin","analyst","viewer","reporter"],
    "report.generate":  ["admin","analyst"],
    "report.pdf":       ["admin","analyst","viewer","reporter"],
    "users.manage":     ["admin"],
    "users.view":       ["admin"],
    "settings.view":    ["admin","analyst"],
    "settings.edit":    ["admin"],
    "api_keys.manage":  ["admin","analyst"],
    "domains.delete":   ["admin"],
    "rules.edit":       ["admin","analyst"],
    "intruder.run":     ["admin","analyst"],
    "payload.gen":      ["admin","analyst"],
}

_DATA_DIR = Path(os.environ.get("TMR_DATA_DIR", "./data"))
_USERS_FILE = _DATA_DIR / "_users" / "users.json"
_SESSIONS: Dict[str, dict] = {}   # token → {user, expires, ip}
SESSION_TTL = 86400 * 7           # 7 days


def _hash_pw(password: str, salt: str = "") -> str:
    if not salt:
        salt = secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 200_000)
    return f"{salt}:{h.hex()}"


def _verify_pw(password: str, stored: str) -> bool:
    try:
        salt, _ = stored.split(":", 1)
        return _hash_pw(password, salt) == stored
    except Exception:
        return False


def _load_users() -> dict:
    """Load users as dict: {username: user_dict}. Handles both list and dict formats."""
    try:
        _USERS_FILE.parent.mkdir(parents=True, exist_ok=True)
        if _USERS_FILE.exists():
            raw = json.loads(_USERS_FILE.read_text())
            # Handle legacy list format
            if isinstance(raw, list):
                return {"users": {u["username"]: u for u in raw if "username" in u}}
            # Handle dict-of-users format
            if isinstance(raw, dict) and "users" in raw:
                return raw
            # Handle flat dict format (username → user)
            if isinstance(raw, dict):
                return {"users": raw}
        return {"users": {}}
    except Exception:
        return {"users": {}}


def _save_users(users: dict):
    """Save users dict to file."""
    _USERS_FILE.parent.mkdir(parents=True, exist_ok=True)
    _USERS_FILE.write_text(json.dumps(users, indent=2))


def _ensure_admin():
    """Create default admin if no users exist.

    Password priority:
      1. TMR_ADMIN_PASSWORD env var  → uses it as-is, logs 'set via env var'
      2. No env var                  → generates cryptographically random 20-char password,
                                       prints it ONCE to stdout (not the logger),
                                       sets TMR_SETUP_REQUIRED=1 so UI can prompt change

    The generated password is NEVER stored anywhere except the hashed users.json.
    Operator must capture it from startup output or set TMR_ADMIN_PASSWORD in .env.
    """
    users = _load_users()
    if not users.get("users"):
        env_pw = os.environ.get("TMR_ADMIN_PASSWORD", "")
        if env_pw:
            default_pw = env_pw
            pw_source  = "set via TMR_ADMIN_PASSWORD env var"
        else:
            # Generate a random password — secure, non-guessable
            alphabet   = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789!@#$%"
            default_pw = "".join(secrets.choice(alphabet) for _ in range(20))
            pw_source  = "auto-generated (shown once below)"
            os.environ["TMR_SETUP_REQUIRED"] = "1"

        admin = {
            "id":           "u_admin",
            "username":     "admin",
            "email":        os.environ.get("TMR_ADMIN_EMAIL", "admin@localhost"),
            "password":     _hash_pw(default_pw),
            "role":         "admin",
            "api_key":      "tmr_" + secrets.token_hex(24),
            "created":      datetime.utcnow().isoformat(),
            "last_login":   None,
            "active":       True,
            "must_change_pw": not bool(env_pw),   # force change on first login if auto-generated
        }
        _save_users({"users": {admin["username"]: admin}})
        log.info(f"[rbac] Default admin created — password source: {pw_source}")
        log.info(f"[rbac] API key: {admin['api_key']}")

        if not env_pw:
            # Print to stdout (bypasses log level filtering, visible in terminal)
            _banner = (
                "\n" + "="*60 +
                "\n  FIRST RUN — ADMIN CREDENTIALS" +
                f"\n  Username : admin" +
                f"\n  Password : {default_pw}" +
                "\n  CHANGE THIS PASSWORD immediately via /auth/change_password" +
                "\n  Or set TMR_ADMIN_PASSWORD in .env before restarting." +
                "\n" + "="*60 + "\n"
            )
            print(_banner, flush=True)
        return admin
    return None


# Initialize on import
_ensure_admin()


def login(username: str, password: str, ip: str = "") -> Optional[dict]:
    """Authenticate user, return session token dict or None."""
    users_data = _load_users()
    users_dict = users_data.get("users", {})
    # Support lookup by username or email
    user = users_dict.get(username) or next(
        (u for u in users_dict.values() if u.get("email") == username), None
    )
    if not user or not user.get("active"):
        return None
    if not _verify_pw(password, user["password"]):
        return None

    # Create session token
    token    = "tmrs_" + secrets.token_hex(32)
    expires  = time.time() + SESSION_TTL
    _SESSIONS[token] = {
        "user_id":  user["id"],
        "username": user["username"],
        "role":     user["role"],
        "email":    user["email"],
        "ip":       ip,
        "expires":  expires,
        "token":    token,
    }

    # Update last_login
    if username in users_dict:
        users_dict[username]["last_login"] = datetime.utcnow().isoformat()
    else:
        for uname, u in users_dict.items():
            if u.get("id") == user["id"]:
                users_dict[uname]["last_login"] = datetime.utcnow().isoformat()
                break
    _save_users(users_data)

    log.info(f"[rbac] Login: {username} from {ip} role={user['role']}")
    return {
        "token":    token,
        "username": user["username"],
        "role":     user["role"],
        "email":    user["email"],
        "expires":  expires,
    }


def logout(token: str):
    _SESSIONS.pop(token, None)


def get_session(token: str) -> Optional[dict]:
    """Get session info for a token. Returns None if invalid/expired."""
    if not token:
        return None
    token = token.replace("Bearer ", "").strip()
    if not token:
        return None

    # 1. Check in-memory sessions (fast path — covers tmr_sess_ tokens)
    sess = _SESSIONS.get(token)
    if sess:
        if sess["expires"] < time.time():
            _SESSIONS.pop(token, None)
            return None
        return sess

    # 2. Check file-based sessions (survives server restart)
    if token.startswith("tmr_sess_"):
        try:
            users_data = _load_users()
            sess = users_data.get("sessions", {}).get(token)
            if sess:
                if sess["expires"] < time.time():
                    return None
                # Restore to in-memory for subsequent requests
                _SESSIONS[token] = sess
                return sess
        except Exception:
            pass
        return None

    # 3. API key auth (permanent keys stored on user record)
    if token.startswith("tmr_"):
        users_data = _load_users()
        all_users  = users_data.get("users", {})
        user = next((u for u in all_users.values()
                     if u.get("api_key") == token and u.get("active", True)), None)
        if user:
            return {
                "username": user["username"],
                "role":     user["role"],
                "expires":  9999999999,
            }
        return None

    return None


def require_permission(token: str, permission: str) -> tuple:
    """Check if token has permission. Returns (ok: bool, session: dict|None)."""
    sess = get_session(token)
    if not sess:
        return False, None
    allowed = PERMISSIONS.get(permission, [])
    if sess["role"] in allowed:
        return True, sess
    return False, sess


def has_permission(sess: Optional[dict], permission: str) -> bool:
    if not sess:
        return False
    return sess.get("role") in PERMISSIONS.get(permission, [])


# User management
def create_user(username: str, email: str, password: str,
                role: str = "analyst", created_by: str = "admin") -> dict:
    if role not in ROLES:
        raise ValueError(f"Invalid role: {role}. Must be one of: {list(ROLES)}")
    if not re.match(r'^[a-zA-Z0-9_-]{3,32}$', username):
        raise ValueError("Username must be 3-32 chars: letters, numbers, _ -")
    users = _load_users()
    if any(u["username"] == username for u in users):
        raise ValueError(f"Username '{username}' already exists")
    if any(u["email"] == email for u in users):
        raise ValueError(f"Email '{email}' already registered")

    user = {
        "id":         "u_" + secrets.token_hex(8),
        "username":   username,
        "email":      email,
        "password":   _hash_pw(password),
        "role":       role,
        "api_key":    "tmr_" + secrets.token_hex(24),
        "created":    datetime.utcnow().isoformat(),
        "created_by": created_by,
        "last_login": None,
        "active":     True,
        "workspaces": [],
    }
    users.append(user)
    _save_users(users)
    log.info(f"[rbac] User created: {username} role={role} by={created_by}")
    return {k:v for k,v in user.items() if k != "password"}


def update_user(user_id: str, updates: dict) -> dict:
    users = _load_users()
    for u in users:
        if u["id"] == user_id:
            if "password" in updates:
                updates["password"] = _hash_pw(updates["password"])
            if "role" in updates and updates["role"] not in ROLES:
                raise ValueError(f"Invalid role: {updates['role']}")
            u.update({k:v for k,v in updates.items()
                      if k in ["email","role","active","workspaces"]})
            if "password" in updates:
                u["password"] = updates["password"]
            _save_users(users)
            return {k:v for k,v in u.items() if k != "password"}
    raise ValueError(f"User {user_id} not found")


def delete_user(user_id: str):
    users = _load_users()
    users = [u for u in users if u["id"] != user_id]
    _save_users(users)
    # Invalidate sessions
    to_del = [t for t,s in _SESSIONS.items() if s["user_id"] == user_id]
    for t in to_del: del _SESSIONS[t]


def list_users() -> list:
    return [{k:v for k,v in u.items() if k not in ["password"]}
            for u in _load_users()]


def rotate_api_key(user_id: str) -> str:
    users = _load_users()
    new_key = "tmr_" + secrets.token_hex(24)
    for u in users:
        if u["id"] == user_id:
            u["api_key"] = new_key
            _save_users(users)
            return new_key
    raise ValueError(f"User {user_id} not found")


def get_user_by_id(user_id: str) -> Optional[dict]:
    users_data = _load_users()
    all_users  = users_data.get("users", {})
    u = next((u for u in all_users.values() if u.get("id") == user_id), None)
    if u:
        return {k: v for k, v in u.items() if k != "password"}
    return None


def get_user(username: str) -> Optional[dict]:
    """Get user by username."""
    users_data = _load_users()
    u = users_data.get("users", {}).get(username)
    if u:
        return {k: v for k, v in u.items() if k != "password"}
    return None


def get_current_user():
    """Get current user - checks both in-memory + file auth systems."""
    try:
        from flask import request, g
        if hasattr(g, '_tmr_user'): return g._tmr_user
        token = request.cookies.get("tmr_token","")
        if not token:
            ah = request.headers.get("Authorization","")
            if ah.startswith("Bearer "): token = ah[7:]
        if not token: return None
        try:
            from engine.auth_rbac import get_user_db
            import os as _os
            udb = get_user_db(_os.environ.get("TMR_DATA_DIR","./data"))
            u = udb.get_user_by_token(token)
            if u: g._tmr_user = u; return u
        except Exception: pass
    except Exception: pass
    return None

def get_store(data_dir: str = "./data") -> dict:
    """Get or create the user store. Alias for _load_users."""
    return _load_users()

def verify_token(token: str) -> Optional[Dict]:
    """Verify a session token and return the user dict, or None."""
    return get_session(token)

def create_token(username: str, role: str = "analyst") -> str:
    """Create a new session token for a user. Stored both in-memory and on disk."""
    import secrets as _sec, time as _t
    token   = "tmr_sess_" + _sec.token_hex(20)
    expires = _t.time() + SESSION_TTL
    sess    = {
        "username": username,
        "role":     role,
        "created":  _t.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "expires":  expires,
    }
    # In-memory store (fast path)
    _SESSIONS[token] = sess
    # Persist to disk for surviv across restarts
    try:
        users = _load_users()
        users.setdefault("sessions", {})[token] = sess
        _save_users(users)
    except Exception:
        pass
    return token

def login_user(username: str, password: str) -> Optional[Dict]:
    """Authenticate username+password, return user dict + token on success."""
    users = _load_users()
    user  = users.get("users", {}).get(username)
    if not user or not user.get("active", True):
        return None
    if not _verify_pw(password, user.get("password", "")):
        return None
    token = create_token(username, user.get("role","analyst"))
    safe_user = {k: v for k, v in user.items() if k != "password"}
    return {
        "token":    token,
        "user":     safe_user,
        "username": safe_user.get("username",""),
        "role":     safe_user.get("role","analyst"),
    }
