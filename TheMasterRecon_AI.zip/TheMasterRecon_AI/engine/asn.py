"""
BugScan ELITE — ASN & IP Range Expansion Engine
Given a domain/IP, find the full IP ranges the company owns.
"""
import re, socket, logging, urllib.request, ssl, json, ipaddress
from typing import List, Dict, Optional, Set

log = logging.getLogger("elite.asn")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _get(url, timeout=15):
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "BugScanELITE/1.0",
            "Accept": "application/json",
        })
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.read(65536).decode("utf-8","ignore")
    except: return ""

def _json(url):
    t = _get(url)
    try: return json.loads(t)
    except: return None


def resolve_ip(domain: str) -> Optional[str]:
    """Resolve domain to IP."""
    try:
        return socket.gethostbyname(domain)
    except: return None


def get_asn_info(ip: str) -> Dict:
    """Get ASN info for an IP address."""
    result = {"ip": ip, "asn": "", "org": "", "country": "", "ranges": []}

    # bgpview
    d = _json(f"https://api.bgpview.io/ip/{ip}")
    if d and d.get("data"):
        data = d["data"]
        prefixes = data.get("prefixes", [])
        rir = data.get("rir_allocation", {})
        if prefixes:
            p = prefixes[0]
            result["asn"] = str(p.get("asn", {}).get("asn", ""))
            result["org"] = p.get("asn", {}).get("description", "")
            result["country"] = p.get("country_code", "")
        result["ranges"] = [p.get("prefix","") for p in prefixes if p.get("prefix")]
        log.info(f"[asn] bgpview: {ip} → ASN{result['asn']} {result['org']}")
        return result

    # ipinfo fallback
    d = _json(f"https://ipinfo.io/{ip}/json")
    if d:
        result["asn"] = d.get("org","").split()[0].lstrip("AS") if d.get("org") else ""
        result["org"] = " ".join(d.get("org","").split()[1:]) if d.get("org") else ""
        result["country"] = d.get("country","")
        if d.get("ip"):
            result["ranges"] = [_get_range_for_ip(ip)]
    return result


def get_asn_ranges(asn: str) -> List[str]:
    """Get all IP ranges for an ASN."""
    if not asn: return []
    asn_clean = asn.lstrip("ASas")
    ranges = []

    d = _json(f"https://api.bgpview.io/asn/{asn_clean}/prefixes")
    if d and d.get("data"):
        v4 = d["data"].get("ipv4_prefixes", [])
        for prefix in v4:
            p = prefix.get("prefix","")
            if p: ranges.append(p)
        log.info(f"[asn] ASN{asn_clean} → {len(ranges)} IPv4 ranges")
    return ranges


def _get_range_for_ip(ip: str) -> str:
    """Get the /24 range for an IP."""
    try:
        network = ipaddress.ip_network(f"{ip}/24", strict=False)
        return str(network)
    except: return f"{ip}/24"


def expand_ip_range(cidr: str, max_hosts: int = 256) -> List[str]:
    """Expand a CIDR to list of IPs (capped)."""
    try:
        network = ipaddress.ip_network(cidr, strict=False)
        hosts = list(network.hosts())
        if len(hosts) > max_hosts:
            log.warning(f"[asn] {cidr} has {len(hosts)} hosts, capping at {max_hosts}")
            hosts = hosts[:max_hosts]
        return [str(h) for h in hosts]
    except Exception as e:
        log.warning(f"[asn] expand {cidr}: {e}")
        return []


def get_company_ranges(domain: str) -> Dict:
    """
    Full pipeline: domain → IP → ASN → all company IP ranges.
    Returns dict with asn info and all CIDR ranges.
    """
    result = {
        "domain":   domain,
        "ip":       None,
        "asn":      None,
        "org":      None,
        "country":  None,
        "ranges":   [],
        "total_ips":0,
    }

    ip = resolve_ip(domain)
    if not ip:
        log.warning(f"[asn] could not resolve {domain}")
        return result
    result["ip"] = ip

    asn_info = get_asn_info(ip)
    result["asn"]     = asn_info.get("asn","")
    result["org"]     = asn_info.get("org","")
    result["country"] = asn_info.get("country","")

    # Get all ranges for this ASN
    if result["asn"]:
        all_ranges = get_asn_ranges(result["asn"])
        result["ranges"] = all_ranges or asn_info.get("ranges",[])
    else:
        result["ranges"] = asn_info.get("ranges",[])

    # Count total IPs
    total = 0
    for cidr in result["ranges"]:
        try:
            total += ipaddress.ip_network(cidr, strict=False).num_addresses
        except: pass
    result["total_ips"] = total

    log.info(f"[asn] {domain}: IP={ip}, ASN={result['asn']}, "
             f"org='{result['org']}', ranges={len(result['ranges'])}, "
             f"total_ips={total}")
    return result


def get_related_domains_from_asn(ip: str) -> List[str]:
    """Find other domains hosted on same ASN via reverse DNS and shodan."""
    domains = set()

    # Reverse DNS on nearby IPs
    try:
        parts = ip.split('.')
        base = '.'.join(parts[:3])
        for last in range(1, 50):
            test_ip = f"{base}.{last}"
            try:
                hostname = socket.gethostbyaddr(test_ip)[0]
                if hostname and '.' in hostname:
                    domains.add(hostname)
            except: pass
    except: pass

    # bgpview peer check
    d = _json(f"https://api.bgpview.io/ip/{ip}")
    if d and d.get("data"):
        for prefix in d["data"].get("prefixes",[]):
            parent = prefix.get("parent",{})
            if parent.get("prefix"):
                domains.add(parent.get("prefix",""))

    return list(domains)[:50]


def format_ranges_for_nmap(ranges: List[str], max_ranges: int = 5) -> str:
    """Format ranges for nmap input (limited to avoid huge scans)."""
    limited = ranges[:max_ranges]
    return " ".join(limited)
