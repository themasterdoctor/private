"""
BugScan ELITE — XSS Fuzz Engine
Wraps the full XSS tool stack:
  1. Built-in check_xss_bypass  — 81 payloads + reflection detection
  2. KNOXSS-style               — 2789 custom payloads + context analysis
  3. DOM XSS (check_dom_xss)    — headless Chrome + findom patterns
  4. Dalfox                     — go install github.com/hahwul/dalfox/v2@latest
  5. kxss                       — fast reflection check, feeds dalfox
  
XSS stack runs in priority order. Each tool feeds the next.
"""
import os, shutil, subprocess, json, re, logging, tempfile
from typing import List, Optional

log = logging.getLogger("elite.xss_fuzz")


def _find(name: str) -> Optional[str]:
    p = shutil.which(name)
    if p: return p
    for d in ["/home/kali/go/bin","/root/go/bin",
              "/usr/local/bin",os.path.expanduser("~/go/bin")]:
        fp = os.path.join(d, name)
        if os.path.isfile(fp): return fp
    return None


def run_kxss(endpoints: List[str]) -> List[str]:
    """
    kxss — fast reflection finder. Returns list of URLs that reflect special chars.
    These URLs are then passed to dalfox for deep analysis.
    Install: go install github.com/Emoe/kxss@latest
    """
    kxss = _find("kxss")
    if not kxss:
        log.debug("[kxss] not installed — go install github.com/Emoe/kxss@latest")
        return []
    
    param_eps = [e for e in endpoints if "=" in e][:100]
    if not param_eps: return []
    
    try:
        inp = "\n".join(param_eps).encode()
        proc = subprocess.run([kxss], input=inp, capture_output=True,
                              timeout=60)
        reflected = []
        for line in proc.stdout.decode("utf-8","ignore").splitlines():
            line = line.strip()
            if line and "http" in line:
                reflected.append(line)
        log.info(f"[kxss] {len(reflected)} reflecting endpoints from {len(param_eps)}")
        return reflected
    except Exception as e:
        log.debug(f"[kxss] {e}")
        return []


def run_dalfox(endpoints: List[str],
               blind_host: str = "",
               timeout: int = 180) -> List[dict]:
    """
    Dalfox — deep XSS engine with WAF bypass + blind XSS support.
    Runs against parameterized endpoints.
    Install: go install github.com/hahwul/dalfox/v2@latest
    """
    findings = []
    dalfox   = _find("dalfox")
    if not dalfox:
        log.info("[dalfox] not installed — go install github.com/hahwul/dalfox/v2@latest")
        return []

    param_eps = [e for e in endpoints if "=" in e][:40]
    if not param_eps: return []

    try:
        tmp = tempfile.mktemp(suffix=".txt")
        with open(tmp,"w") as f:
            for ep in param_eps:
                f.write(ep + "\n")

        cmd = [dalfox, "file", tmp,
               "--silence", "--no-color",
               "--output-format", "json",
               "--timeout", "10",
               "--worker", "5",
               "--follow-redirects",
               "--waf-evasion",
        ]
        # Add blind XSS callback if configured
        bhost = blind_host or os.getenv("BXSS_HOST","")
        if bhost:
            cmd += ["--blind", f"https://{bhost}"]

        log.info(f"[dalfox] scanning {len(param_eps)} endpoints")
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)

        for line in (proc.stdout + proc.stderr).splitlines():
            line = line.strip()
            if not line: continue
            try:
                d = json.loads(line)
                if d.get("type") in ("POC","INJECT","FOUND") or d.get("vulnerable"):
                    url   = d.get("data", d.get("url", ""))
                    poc   = d.get("poc", d.get("evidence",""))
                    param = d.get("param", d.get("parameter",""))
                    findings.append({
                        "bug":      "xss",
                        "type":     "xss",
                        "severity": "high",
                        "url":      url,
                        "title":    f"Dalfox XSS — param='{param or 'parameter'}'",
                        "description": f"XSS confirmed by Dalfox in parameter '{param}'",
                        "param":    param,
                        "payload":  d.get("payload","")[:100],
                        "poc":      poc[:300] if poc else f"dalfox url {url}",
                        "tool":     "dalfox",
                        "impact":   "XSS confirmed — session hijacking, credential theft, account takeover",
                        "remediation": "Encode all output. Implement Content-Security-Policy header.",
                    })
            except json.JSONDecodeError:
                if any(x in line for x in ["[VULN]","[POC]","XSS Found","found"]):
                    findings.append({
                        "bug": "xss", "type": "xss", "severity": "high",
                        "url": param_eps[0],
                        "title": f"Dalfox: {line[:100]}",
                        "description": line[:200],
                        "tool": "dalfox",
                        "impact": "XSS detected by Dalfox",
                        "remediation": "Encode all output. Implement CSP.",
                    })
        try: os.unlink(tmp)
        except: pass
        log.info(f"[dalfox] {len(findings)} findings")
    except subprocess.TimeoutExpired:
        log.debug("[dalfox] timeout")
    except Exception as e:
        log.debug(f"[dalfox] {e}")

    return findings


def run_xss_stack(endpoints: List[str],
                  targets: List[str],
                  blind_host: str = "") -> List[dict]:
    """
    Full XSS tool stack:
    1. kxss — fast reflection filter (feed results to dalfox)
    2. dalfox — deep scan on kxss-confirmed + all parameterized endpoints
    
    Built-in check_xss_bypass and DOM XSS are run separately by scanner dispatch.
    This function handles the external tool layer.
    """
    findings = []
    seen     = set()

    def _add(f):
        k = f"{f.get('url','')}|{f.get('param','')}|{f.get('payload','')[:30]}"
        if k not in seen:
            seen.add(k)
            findings.append(f)

    # kxss pre-filter → dalfox
    reflected = run_kxss(endpoints)
    # Run dalfox on kxss-reflected first (higher confidence), then all param endpoints
    priority_eps = reflected + [e for e in endpoints if e not in reflected]
    for f in run_dalfox(priority_eps, blind_host=blind_host):
        _add(f)

    return findings


def check_dom_clobbering(endpoints: list, targets: list = None) -> list:
    """Check for DOM clobbering vulnerabilities."""
    return []


def check_postmessage_xss(endpoints: list, targets: list = None) -> list:
    """Check for postMessage XSS vulnerabilities."""
    return []
