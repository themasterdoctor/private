"""
TheMasterRecon AI — DOM XSS Scanner (Playwright-powered)
Finds DOM-based XSS, JS prototype pollution, and SPA injection points
that HTTP scanners completely miss.
"""
import asyncio, re, json, logging, time, os
from typing import List, Dict, Optional
from urllib.parse import urljoin, urlparse

log = logging.getLogger("elite.dom_xss")

DOM_SINKS = [
    "innerHTML","outerHTML","document.write","document.writeln",
    "insertAdjacentHTML","eval(","Function(","setTimeout(","setInterval(",
    "location.href=","location.replace(","location.assign(",
    "src=","href=","srcdoc=","action=",
]
DOM_SOURCES = [
    "location.hash","location.search","location.href","document.URL",
    "document.referrer","window.name","document.cookie",
    "localStorage","sessionStorage",
    "URLSearchParams","location.pathname",
]
XSS_PROBES = [
    '<img src=x onerror=window._tmr_xss=1>',
    '<svg onload=window._tmr_xss=2>',
    "javascript:window._tmr_xss=3",
    '"><script>window._tmr_xss=4</script>',
    "'><img src=x onerror=window._tmr_xss=5>",
    '%3Cimg%20src%3Dx%20onerror%3Dwindow._tmr_xss%3D6%3E',
    '\\u003cimg src=x onerror=window._tmr_xss=7\\u003e',
]
PROTO_PROBES = [
    '{"__proto__":{"polluted":true}}',
    '{"constructor":{"prototype":{"polluted":true}}}',
]


async def scan_dom_xss_async(url: str, timeout: int = 30,
                              max_pages: int = 5) -> List[Dict]:
    """Async DOM XSS scan using Playwright."""
    findings = []
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        log.warning("playwright not installed — pip install playwright && playwright install chromium")
        return findings

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=True,
            args=["--no-sandbox","--disable-setuid-sandbox",
                  "--disable-dev-shm-usage","--disable-gpu",
                  "--no-first-run","--no-zygote"])
        ctx = await browser.new_context(
            ignore_https_errors=True,
            user_agent="Mozilla/5.0 (TheMasterRecon-AI/2.0) AppleWebKit/537.36",
            viewport={"width":1280,"height":720},
            java_script_enabled=True)

        page = await ctx.new_page()

        # Intercept console errors and JS exceptions
        js_errors   = []
        js_sinks_hit = []

        page.on("console", lambda msg: js_errors.append(msg.text) if msg.type=="error" else None)
        page.on("pageerror", lambda err: js_errors.append(str(err)))

        # Inject detection hook before page load
        await ctx.add_init_script("""
            window._tmr_xss = 0;
            window._tmr_sinks = [];
            const _orig_dw = document.write.bind(document);
            document.write = function(s){ window._tmr_sinks.push({sink:'document.write',data:s.slice?s.slice(0,200):s}); return _orig_dw(s); };
            Object.defineProperty(document, 'innerHTML', {
                set: function(v){ window._tmr_sinks.push({sink:'innerHTML',data:(v+'').slice(0,200)}); }
            });
        """)

        try:
            await page.goto(url, wait_until="networkidle", timeout=timeout*1000)
        except Exception as e:
            log.debug(f"[dom_xss] page load: {e}")
            await browser.close()
            return findings

        # 1. Analyze page source for dangerous patterns
        content  = await page.content()
        page_url = page.url

        # Check for source→sink patterns in JS
        for source in DOM_SOURCES:
            if source in content:
                for sink in DOM_SINKS:
                    if sink in content:
                        # Check proximity (within 500 chars)
                        src_idx = content.find(source)
                        snk_idx = content.find(sink)
                        if abs(src_idx - snk_idx) < 2000:
                            findings.append({
                                "bug":         "dom_xss",
                                "severity":    "high",
                                "url":         page_url,
                                "title":       f"DOM XSS source→sink: {source} → {sink}",
                                "source":      source,
                                "sink":        sink,
                                "confidence":  75,
                                "poc":         f"# DOM XSS: {source} flows to {sink}\n# Try: {url}#{source.split('.')[-1]}=<img src=x onerror=alert(document.domain)>",
                                "impact":      "JavaScript execution in victim's browser context. Cookie theft, session hijack, keylogging.",
                                "remediation": f"Sanitize {source} before passing to {sink}. Use textContent instead of innerHTML. Implement strict CSP.",
                            })

        # 2. Test URL hash/search params with XSS probes
        parsed = urlparse(page_url)
        test_params = []

        # Get existing params
        from urllib.parse import parse_qs, urlencode
        existing_params = parse_qs(parsed.query)
        for param in list(existing_params.keys())[:5]:
            test_params.append(("param", param, page_url))

        # Also test hash
        test_params.append(("hash", "#", page_url))

        for probe in XSS_PROBES[:3]:
            for ptype, param, base in test_params[:3]:
                try:
                    if ptype == "hash":
                        test_url = base.split('#')[0] + '#' + probe
                    else:
                        from urllib.parse import urlparse as up, urlencode, parse_qs, urlunparse
                        p = up(base)
                        q = parse_qs(p.query)
                        q[param] = [probe]
                        test_url = urlunparse(p._replace(query=urlencode(q, doseq=True)))

                    await page.goto(test_url, wait_until="domcontentloaded", timeout=15000)
                    await page.wait_for_timeout(1000)

                    # Check if XSS fired
                    xss_fired = await page.evaluate("window._tmr_xss > 0")
                    if xss_fired:
                        xss_id = await page.evaluate("window._tmr_xss")
                        findings.append({
                            "bug":        "dom_xss",
                            "severity":   "critical",
                            "url":        test_url,
                            "title":      f"DOM XSS confirmed via {ptype} parameter",
                            "payload":    probe,
                            "param":      param,
                            "confidence": 98,
                            "poc":        f"# CONFIRMED DOM XSS — probe #{xss_id} fired\n{test_url}",
                            "impact":     "CONFIRMED: XSS payload executed. Full cookie/session theft, keylogging, phishing.",
                            "remediation":"Sanitize all URL-derived input before DOM operations. Use DOMPurify. Implement strict CSP.",
                        })
                        break
                except Exception as e:
                    log.debug(f"[dom_xss] probe: {e}")

        # 3. Check for postMessage handlers without origin check
        pm_check = await page.evaluate("""
            () => {
                const listeners = window._tmr_pm_listeners || [];
                const src = document.documentElement.innerHTML;
                const hasListener = /addEventListener\\s*\\(\\s*['"]message['"]/.test(src);
                const hasOriginCheck = /event\\.origin|message\\.origin/.test(src);
                const hasSink = /innerHTML|document\\.write|eval\\(/.test(src);
                return {hasListener, hasOriginCheck, hasSink};
            }
        """)
        if pm_check.get("hasListener") and not pm_check.get("hasOriginCheck") and pm_check.get("hasSink"):
            findings.append({
                "bug":        "dom_xss",
                "severity":   "high",
                "url":        page_url,
                "title":      "PostMessage XSS — no origin validation + dangerous sink",
                "confidence": 80,
                "poc":        f"<iframe src='{page_url}'></iframe>\n<script>\ndocument.querySelector('iframe').onload=()=>{{\n  document.querySelector('iframe').contentWindow.postMessage('<img src=x onerror=alert(1)>','*');\n}};\n</script>",
                "impact":     "Cross-origin JS execution via unvalidated postMessage",
                "remediation":"Always validate event.origin. Use allowlist of trusted origins.",
            })

        await browser.close()
    return findings


def scan_dom_xss(url: str, timeout: int = 30) -> List[Dict]:
    """Synchronous wrapper for DOM XSS scan."""
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        results = loop.run_until_complete(scan_dom_xss_async(url, timeout))
        loop.close()
        return results
    except Exception as e:
        log.error(f"[dom_xss] {e}")
        return []
