"""
engine/tool_health.py — Full tool execution health check.

Tests actual binary execution for all 69 pipeline tools.
Detects wrong binaries (Python httpx, venv paths, etc.).
Provides fix commands and script generation for broken tools.
"""

import os, re, shutil, subprocess, time, logging
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("elite.tool_health")

_WRONG_MARKERS = {
    "httpx":   ["no such option", "usage: httpx [", "pip install"],
    "notify":  ["no such option", "python notify"],
    "dnsx":    ["no such option"],
    "mapcidr": ["no such option"],
}
_VENV_SKIP = ("venv", "site-packages", ".local/lib", "dist-packages", "__pypackages__")
_PD_MARKERS = ("projectdiscovery", "current version", "version:", "v1.", "v2.", "v3.")
_PD_TOOLS   = {"httpx","dnsx","tlsx","notify","naabu","katana","nuclei","subfinder",
               "alterx","cdncheck","asnmap","mapcidr","uncover"}

FIX_COMMANDS: Dict[str, str] = {
    "subfinder":    "go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest",
    "httpx":        "go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest",
    "dnsx":         "go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest",
    "tlsx":         "go install -v github.com/projectdiscovery/tlsx/cmd/tlsx@latest",
    "naabu":        "go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest",
    "katana":       "go install -v github.com/projectdiscovery/katana/cmd/katana@latest",
    "nuclei":       "go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
    "alterx":       "go install -v github.com/projectdiscovery/alterx/cmd/alterx@latest",
    "cdncheck":     "go install -v github.com/projectdiscovery/cdncheck/cmd/cdncheck@latest",
    "asnmap":       "go install -v github.com/projectdiscovery/asnmap/cmd/asnmap@latest",
    "uncover":      "go install -v github.com/projectdiscovery/uncover/cmd/uncover@latest",
    "mapcidr":      "go install -v github.com/projectdiscovery/mapcidr/cmd/mapcidr@latest",
    "interactsh-client": "go install -v github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest",
    "notify":       "go install -v github.com/projectdiscovery/notify/cmd/notify@latest",
    "amass":        "go install -v github.com/owasp-amass/amass/v4/...@master",
    "assetfinder":  "go install -v github.com/tomnomnom/assetfinder@latest",
    "findomain":    "wget -qO- https://github.com/Findomain/Findomain/releases/latest/download/findomain-linux.zip | zcat > /usr/local/bin/findomain && chmod +x /usr/local/bin/findomain",
    "chaos":        "go install -v github.com/projectdiscovery/chaos-client/cmd/chaos@latest",
    "puredns":      "go install -v github.com/d3mondev/puredns/v2@latest",
    "shuffledns":   "go install -v github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest",
    "massdns":      "sudo apt install massdns -y",
    "altdns":       "pip3 install py-altdns",
    "dnsgen":       "pip3 install dnsgen",
    "gau":          "go install -v github.com/lc/gau/v2/cmd/gau@latest",
    "gauplus":      "go install -v github.com/bp0lr/gauplus@latest",
    "waybackurls":  "go install -v github.com/tomnomnom/waybackurls@latest",
    "paramspider":  "pip3 install paramspider",
    "subjs":        "go install -v github.com/lc/subjs@latest",
    "anew":         "go install -v github.com/tomnomnom/anew@latest",
    "gf":           "go install -v github.com/tomnomnom/gf@latest",
    "qsreplace":    "go install -v github.com/tomnomnom/qsreplace@latest",
    "gospider":     "go install -v github.com/jaeles-project/gospider@latest",
    "hakrawler":    "go install -v github.com/hakluke/hakrawler@latest",
    "httprobe":     "go install -v github.com/tomnomnom/httprobe@latest",
    "kr":           "go install -v github.com/asciimoo/kr@latest",
    "subjack":      "go install -v github.com/haccer/subjack@latest",
    "tko-subs":     "go install -v github.com/anshumanbh/tko-subs@latest",
    "trufflehog":   "go install -v github.com/trufflesecurity/trufflehog/v3@latest",
    "gitleaks":     "go install -v github.com/gitleaks/gitleaks/v8@latest",
    "s3scanner":    "pip3 install s3scanner",
    "cloudbrute":   "go install -v github.com/d3mondev/cloudbrute@latest",
    "gowitness":    "go install -v github.com/sensepost/gowitness@latest",
    "dalfox":       "go install -v github.com/hahwul/dalfox/v2@latest",
    "kxss":         "go install -v github.com/Emoe/kxss@latest",
    "crlfuzz":      "go install -v github.com/dwisiswant0/crlfuzz/cmd/crlfuzz@latest",
    "ssrfuzz":      "go install -v github.com/ryandamour/ssrfuzz@latest",
    "byp4xx":       "go install -v github.com/lobuhi/byp4xx@latest",
    "403jump":      "go install -v github.com/trap-bytes/403jump@latest",
    "nmap":         "sudo apt install nmap -y",
    "masscan":      "sudo apt install masscan -y",
    "rustscan":     "sudo apt install rustscan -y",
    "zmap":         "sudo apt install zmap -y",
    "nikto":        "sudo apt install nikto -y",
    "whatweb":      "sudo apt install whatweb -y",
    "wpscan":       "sudo apt install wpscan -y",
    "wfuzz":        "sudo apt install wfuzz -y",
    "ffuf":         "sudo apt install ffuf -y",
    "gobuster":     "sudo apt install gobuster -y",
    "dirsearch":    "sudo apt install dirsearch -y",
    "feroxbuster":  "sudo apt install feroxbuster -y",
    "jxscout":      "go install github.com/jxscout/jxscout@latest",
    "kiterunner":   "go install github.com/assetnote/kiterunner/cmd/kr@latest",
    "scoutsuite":   "pip3 install scoutsuite --break-system-packages",
    "wkhtmltopdf":  "sudo apt install wkhtmltopdf -y",
    "sqlmap":       "sudo apt install sqlmap -y",
    "commix":       "sudo apt install commix -y",
    "detect-secrets": "pip3 install detect-secrets",
    "sublist3r":    "pip3 install sublist3r",
    "knockpy":      "pip3 install knock-subdomains",
    "arjun":        "pip3 install arjun",
    "ghauri":       "pip3 install ghauri",
    "pacu":         "pip3 install pacu",
    "bypass-403":   "pip3 install bypass-403",
}

_TOOL_TESTS: Dict[str, dict] = {
    "subfinder":    {"va":["-version"],           "sa":["-d","example.com","-silent","-timeout","5"], "st":12, "pd":True},
    "amass":        {"va":["-version"],           "sa":None, "st":5},
    "assetfinder":  {"va":["--help"],             "sa":None, "st":5},
    "findomain":    {"va":["--version"],          "sa":None, "st":5},
    "chaos":        {"va":["-version"],           "sa":None, "st":5, "pd":True},
    "sublist3r":    {"va":["-h"],                 "sa":None, "st":5},
    "knockpy":      {"va":["--help"],             "sa":None, "st":5},
    "dnsx":         {"va":["-version"],           "sa":["-silent","-resp"], "si":"example.com\n", "st":10, "pd":True},
    "puredns":      {"va":["--version"],          "sa":None, "st":5},
    "massdns":      {"va":["-h"],                 "sa":None, "st":5},
    "shuffledns":   {"va":["-version"],           "sa":None, "st":5, "pd":True},
    "alterx":       {"va":["-version"],           "sa":["-enrich","-silent"], "si":"test.example.com\n", "st":8, "pd":True},
    "altdns":       {"va":["-h"],                 "sa":None, "st":5},
    "dnsgen":       {"va":["-h"],                 "sa":None, "st":5},
    "tlsx":         {"va":["-version"],           "sa":None, "st":5, "pd":True},
    "cdncheck":     {"va":["-version"],           "sa":None, "st":5, "pd":True},
    "httpx":        {"va":["-version"],           "sa":["-silent","-status-code","-no-color"], "si":"https://example.com\n", "st":15, "pd":True},
    "httprobe":     {"va":["-h"],                 "sa":None, "st":5},
    "naabu":        {"va":["-version"],           "sa":None, "st":5, "pd":True},
    "nmap":         {"va":["--version"],          "sa":None, "st":5},
    "masscan":      {"va":["--version"],          "sa":None, "st":5},
    "rustscan":     {"va":["--version"],          "sa":None, "st":5},
    "zmap":         {"va":["--version"],          "sa":None, "st":5},
    "katana":       {"va":["-version"],           "sa":["-u","https://example.com","-d","1","-silent","-timeout","8"], "st":15, "pd":True},
    "gospider":     {"va":["--help"],             "sa":None, "st":5},
    "hakrawler":    {"va":["-h"],                 "sa":None, "st":5},
    "gau":          {"va":["--version"],          "sa":["example.com","--threads","3"], "st":15},
    "gauplus":      {"va":["-h"],                 "sa":None, "st":5},
    "waybackurls":  {"va":["-h"],                 "sa":None, "st":5},
    "paramspider":  {"va":["-h"],                 "sa":None, "st":5},
    "subjs":        {"va":["-version"], "vfb":["-h"], "sa":None, "st":5},
    "anew":         {"va":["-h"],                 "sa":None, "st":5},
    "gf":           {"va":["-h"],                 "sa":None, "st":5},
    "qsreplace":    {"va":["-h"],                 "sa":None, "st":5},
    "kr":           {"va":["-h"],                 "sa":None, "st":5},
    "ffuf":         {"va":["-V"],                 "sa":None, "st":5},
    "gobuster":     {"va":["version"],            "sa":None, "st":5},
    "feroxbuster":  {"va":["--version"],          "sa":None, "st":5},
    "dirsearch":    {"va":["-h"],                 "sa":None, "st":5},
    "wfuzz":        {"va":["--version"],          "sa":None, "st":5},
    "arjun":        {"va":["-h"],                 "sa":None, "st":5},
    "nuclei":       {"va":["-version"],           "sa":["-u","https://example.com","-silent","-severity","info","-rate-limit","5","-timeout","5","-no-color"], "st":20, "pd":True},
    "nikto":        {"va":["-Version"],           "sa":None, "st":5},
    "whatweb":      {"va":["--version"],          "sa":None, "st":5},
    "wpscan":       {"va":["--version"],          "sa":None, "st":5},
    "sqlmap":       {"va":["--version"],          "sa":None, "st":5},
    "ghauri":       {"va":["--version"],          "sa":None, "st":5},
    "dalfox":       {"va":["version"],            "sa":None, "st":5},
    "kxss":         {"va":["-h"],                 "sa":None, "st":5},
    "crlfuzz":      {"va":["-h"],                 "sa":None, "st":5},
    "ssrfuzz":      {"va":["-h"],                 "sa":None, "st":5},
    "commix":       {"va":["--version"],          "sa":None, "st":5},
    "byp4xx":       {"va":["-h"],                 "sa":None, "st":5},
    "403jump":      {"va":["-h"],                 "sa":None, "st":5},
    "bypass-403":   {"va":["-h"],                 "sa":None, "st":5},
    "subjack":      {"va":["-h"],                 "sa":None, "st":5},
    "tko-subs":     {"va":["-h"],                 "sa":None, "st":5},
    "trufflehog":   {"va":["--version"],          "sa":None, "st":5},
    "gitleaks":     {"va":["version"],            "sa":None, "st":5},
    "detect-secrets":{"va":["--version"],         "sa":None, "st":5},
    "s3scanner":    {"va":["-h"],                 "sa":None, "st":5},
    "cloudbrute":   {"va":["-h"],                 "sa":None, "st":5},
    "pacu":         {"va":["--help"],             "sa":None, "st":5},
    "gowitness":    {"va":["version"],            "sa":None, "st":5},
    "interactsh-client": {"va":["-version"],      "sa":None, "st":5, "pd":True},
    "notify":       {"va":["-version"],           "sa":None, "st":5, "pd":True},
    "mapcidr":      {"va":["-version"],           "sa":None, "st":5, "pd":True},
    "asnmap":       {"va":["-version"],           "sa":None, "st":5, "pd":True},
    "uncover":      {"va":["-version"],           "sa":None, "st":5, "pd":True},
    # Additional tools
    "jxscout":      {"va":["--version"],          "sa":None, "st":5},
    "kiterunner":   {"va":["version"],            "sa":None, "st":5, "bin":"kr"},
    "scoutsuite":   {"va":["--version"],          "sa":None, "st":5, "bin":"scout"},
    "wkhtmltopdf":  {"va":["--version"],          "sa":None, "st":5},
}

CRITICAL_TOOLS  = ["httpx","nuclei","subfinder","katana","dnsx"]
IMPORTANT_TOOLS = ["gau","ffuf","gobuster","naabu","alterx","gowitness","waybackurls","gospider"]

_PD_DIRS = [
    os.path.expanduser("~/go/bin"), "/home/kali/go/bin", "/root/go/bin",
    "/usr/local/go/bin", "/usr/local/bin", "/usr/bin", "/snap/bin",
]

def _resolve_path(name):
    cfg = _TOOL_TESTS.get(name, {})
    # Use explicit bin field if set (e.g. kiterunner → kr, scoutsuite → scout)
    binary = cfg.get("bin", name)
    
    if binary in _PD_TOOLS or name in _PD_TOOLS:
        for d in _PD_DIRS:
            fp = os.path.join(d, binary)
            if os.path.isfile(fp) and os.access(fp, os.X_OK):
                return fp
    p = shutil.which(binary)
    if p and any(s in p for s in _VENV_SKIP):
        return None
    if not p and binary != name:
        # Try original name too
        p = shutil.which(name)
        if p and any(s in p for s in _VENV_SKIP):
            return None
    return p

def _extract_version(output):
    for pat in [r"v(\d+\.\d+\.\d+[\w.-]*)", r"version[:\s]+(\d+\.\d+[\w.-]*)", r"(\d+\.\d+\.\d+)"]:
        m = re.search(pat, output, re.I)
        if m:
            raw = m.group(0)
            return raw if raw.startswith("v") else "v" + m.group(1)
    return None

def _is_wrong_binary(name, output):
    out_l = output.lower()
    if any(s in out_l for s in _VENV_SKIP): return "wrong_binary_venv_path"
    # Python package CLIs (venv/argparse) for PD tools
    if name in _PD_TOOLS and "no such option" in out_l: return "wrong_binary_python_package"
    for marker in _WRONG_MARKERS.get(name, []):
        if marker.lower() in out_l: return "wrong_binary_python_package"
    return None

def _run_check(cmd, timeout, stdin_data=None):
    t0 = time.monotonic()
    try:
        inp = stdin_data.encode() if stdin_data else None
        r   = subprocess.run(cmd, input=inp, capture_output=True, timeout=timeout)
        ela = round(time.monotonic()-t0, 2)
        return r.returncode, r.stdout.decode(errors="replace"), r.stderr.decode(errors="replace"), ela
    except subprocess.TimeoutExpired:
        return -1, "", f"timed out after {timeout}s", round(time.monotonic()-t0, 2)
    except FileNotFoundError:
        return -2, "", "binary not found", round(time.monotonic()-t0, 2)
    except Exception as e:
        return -3, "", str(e), round(time.monotonic()-t0, 2)


def check_tool(name: str) -> Dict:
    """Full health check for one tool — doctor-format output."""
    cfg    = _TOOL_TESTS.get(name, {})
    path   = _resolve_path(name)
    t0     = time.monotonic()

    result = {
        "tool": name, "installed": bool(path), "path": path,
        "validated": False, "version": None, "execution_ok": False,
        "version_ok": False, "smoke_ok": None, "exit_code": None,
        "stdout_sample": None, "stderr_sample": None,
        "command_tested": None, "wrong_binary": None, "error": None,
        "fix_command": FIX_COMMANDS.get(name), "duration_ms": 0,
    }

    if not path:
        result["error"] = "not_found"
        result["duration_ms"] = round((time.monotonic()-t0)*1000)
        log.info(f"[tool-health] {name} not_found")
        return result

    v_cmd = [path] + cfg.get("va", ["-version"])
    rc, out, err, _ = _run_check(v_cmd, timeout=8)
    combined = out + err

    result["command_tested"] = " ".join(v_cmd)
    result["exit_code"]      = rc
    result["stdout_sample"]  = (out[:200].strip() or None)
    result["stderr_sample"]  = (err[:200].strip() or None)

    wrong = _is_wrong_binary(name, combined)
    if wrong:
        result["wrong_binary"] = wrong
        result["error"]        = wrong
        result["fix_command"]  = (
            f"export PATH=$HOME/go/bin:$PATH  # ensure Go bin first, then: "
            f"{FIX_COMMANDS.get(name,'reinstall')}")
        result["duration_ms"]  = round((time.monotonic()-t0)*1000)
        log.warning(f"[tool-health] {name} wrong_binary={wrong} path={path}")
        return result

    # Fallback version args
    if rc not in (0, 1) and cfg.get("vfb"):
        v2 = [path] + cfg["vfb"]
        rc2, out2, err2, _ = _run_check(v2, timeout=8)
        if rc2 in (0, 1):
            combined = out2 + err2; rc, out, err = rc2, out2, err2
            result.update({"command_tested":" ".join(v2),"exit_code":rc2,
                           "stdout_sample":out2[:200].strip() or None,
                           "stderr_sample":err2[:200].strip() or None})

    result["version"]    = _extract_version(combined)
    result["version_ok"] = rc in (0, 1) or bool(result["version"])

    if cfg.get("pd"):
        pd_ok = any(m in combined.lower() for m in _PD_MARKERS)
        if not pd_ok and "no such option" in combined.lower():
            result["wrong_binary"] = "wrong_binary_python_package"
            result["error"]        = "wrong_binary_python_package"
            result["duration_ms"]  = round((time.monotonic()-t0)*1000)
            return result
        result["validated"] = pd_ok
    else:
        result["validated"] = result["version_ok"] or rc in (0, 1)

    result["execution_ok"] = result["version_ok"]

    # Smoke test
    s_args = cfg.get("sa")
    if s_args is not None and result["validated"]:
        s_cmd = [path] + s_args
        result["command_tested"] = " ".join(s_cmd[:7]) + ("…" if len(s_cmd) > 7 else "")
        s_rc, s_out, s_err, _ = _run_check(s_cmd, timeout=cfg.get("st",10),
                                            stdin_data=cfg.get("si"))
        result.update({"exit_code":s_rc,
                        "stdout_sample":s_out[:300].strip() or None,
                        "stderr_sample":s_err[:200].strip() or None})
        wrong2 = _is_wrong_binary(name, s_out + s_err)
        if wrong2:
            result.update({"wrong_binary":wrong2,"smoke_ok":False,"validated":False,"error":wrong2})
        elif s_rc == -1:
            result["smoke_ok"] = False
            result["error"]    = f"smoke_timeout_{cfg.get('st',10)}s"
        elif s_rc in (0, 1):
            result["smoke_ok"] = True; result["execution_ok"] = True
        else:
            result["smoke_ok"] = False
            result["error"]    = f"smoke_exit_{s_rc}: {(s_err[:80].strip() or str(s_rc))}"

    result["duration_ms"] = round((time.monotonic()-t0)*1000)
    log.info(f"[tool-health] {name} {'ok' if result['execution_ok'] else 'failed'}"
             f" validated={result['validated']} version={result['version']}")
    return result


def check_all(tools: List[str] = None) -> Dict:
    if tools is None:
        tools = list(_TOOL_TESTS.keys())
    results, broken, missing, wrong_b, warnings = {}, [], [], [], []
    for name in tools:
        r = check_tool(name)
        results[name] = r
        if not r["installed"]:
            missing.append(name)
            if name in CRITICAL_TOOLS: broken.append(name)
        elif r.get("wrong_binary"):
            wrong_b.append(name)
            if name in CRITICAL_TOOLS: broken.append(name)
            else: warnings.append(f"{name}_wrong_binary")
        elif not r["execution_ok"]:
            if name in CRITICAL_TOOLS: broken.append(name)
            elif name in IMPORTANT_TOOLS: warnings.append(f"{name}_failed")
    return {
        "results": results, "critical_ok": not any(t in broken for t in CRITICAL_TOOLS),
        "broken": broken, "missing": missing, "wrong_binary": wrong_b, "warnings": warnings,
        "checked_at": int(time.time()),
        "summary": {"total":len(tools),
                    "ok":sum(1 for r in results.values() if r["execution_ok"]),
                    "failed":sum(1 for r in results.values() if not r["execution_ok"] and r["installed"]),
                    "missing":len(missing), "wrong_binary":len(wrong_b)},
    }


def generate_fix_script(check_result: Dict) -> str:
    needs = list(dict.fromkeys(
        check_result.get("missing",[]) +
        check_result.get("wrong_binary",[]) +
        check_result.get("broken",[])))
    lines = [
        "#!/usr/bin/env bash",
        "# TheMasterRecon AI — Auto-generated tool fix script",
        f"# Generated: {__import__('datetime').datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}",
        f"# Tools to fix: {', '.join(needs) or 'none'}",
        "export PATH=\"$HOME/go/bin:/usr/local/go/bin:$PATH\"", "",
    ]
    apt = [t for t in needs if FIX_COMMANDS.get(t,"").startswith("sudo apt")]
    pip = [t for t in needs if FIX_COMMANDS.get(t,"").startswith("pip3")]
    go  = [t for t in needs if FIX_COMMANDS.get(t,"").startswith("go install")]
    oth = [t for t in needs if t not in apt+pip+go and FIX_COMMANDS.get(t)]
    if apt:
        pkgs = " ".join(re.search(r"apt install (?:-y )?([\w\-]+)",FIX_COMMANDS.get(t,"")).group(1)
                        for t in apt if re.search(r"apt install",FIX_COMMANDS.get(t,"")))
        if pkgs: lines += ["# APT", f"sudo apt install -y {pkgs}", ""]
    if pip:
        pkgs = " ".join(re.search(r"pip3 install ([\w\-]+)",FIX_COMMANDS.get(t,"")).group(1)
                        for t in pip if re.search(r"pip3 install",FIX_COMMANDS.get(t,"")))
        if pkgs: lines += ["# Python", f"pip3 install {pkgs}", ""]
    if go:
        lines.append("# Go tools")
        for t in go: lines += [f"echo Installing {t}...", FIX_COMMANDS[t]]
        lines.append("")
    for t in oth: lines += [f"# {t}", FIX_COMMANDS[t], ""]
    if check_result.get("wrong_binary"):
        lines += ["", "# Fix PATH so Go binaries take precedence over venv",
                  "echo 'export PATH=\"$HOME/go/bin:/usr/local/go/bin:$PATH\"' >> ~/.bashrc && source ~/.bashrc"]
    lines += ["", "echo 'Done. Restart with ./start.sh and verify at /tools/doctor'"]
    return "\n".join(lines)
