"""
TheMasterRecon AI — Team Collaboration Engine
Workspaces, shared scan access, comments, assignments, activity feed.
"""
import os, json, secrets, time, logging
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict

log = logging.getLogger("elite.team")

_DATA_DIR   = Path(os.environ.get("TMR_DATA_DIR", "./data"))
_TEAMS_FILE = _DATA_DIR / "_teams" / "workspaces.json"


def _load() -> dict:
    try:
        _TEAMS_FILE.parent.mkdir(parents=True, exist_ok=True)
        if _TEAMS_FILE.exists():
            data = json.loads(_TEAMS_FILE.read_text())
            if not isinstance(data, dict):
                data = {"workspaces": {}, "members": {}, "activity": []}
            # Migrate old list-format workspaces to dict
            if isinstance(data.get("workspaces"), list):
                ws_list = data["workspaces"]
                data["workspaces"] = {ws.get("id", str(i)): ws for i,ws in enumerate(ws_list) if isinstance(ws, dict)}
            return data
        return {"workspaces": {}, "members": {}, "activity": []}
    except Exception:
        return {"workspaces": {}, "members": {}, "activity": []}


def _save(data: dict):
    _TEAMS_FILE.parent.mkdir(parents=True, exist_ok=True)
    _TEAMS_FILE.write_text(json.dumps(data, indent=2))


def _log_activity(actor: str, action: str, target: str, detail: str = ""):
    data = _load()
    data.setdefault("activity", []).insert(0, {
        "id":     secrets.token_hex(6),
        "actor":  actor,
        "action": action,
        "target": target,
        "detail": detail,
        "ts":     datetime.utcnow().isoformat() + "Z",
    })
    data["activity"] = data["activity"][:500]  # keep last 500
    _save(data)


# ── Workspaces ─────────────────────────────────────────────────────────────────
def create_workspace(name: str, description: str = "",
                     created_by: str = "admin") -> dict:
    data = _load()
    ws = {
        "id":          "ws_" + secrets.token_hex(8),
        "name":        name,
        "description": description,
        "created_by":  created_by,
        "created":     datetime.utcnow().isoformat(),
        "members":     [{"user_id": created_by, "role": "owner", "added": datetime.utcnow().isoformat()}],
        "domains":     [],
        "tags":        [],
        "color":       "#4466ff",
    }
    data.setdefault("workspaces", []).append(ws)
    _save(data)
    _log_activity(created_by, "created_workspace", ws["id"], name)
    return ws


def get_workspace(ws_id: str) -> Optional[dict]:
    data = _load()
    return next((w for w in data.get("workspaces",[]) if w["id"] == ws_id), None)


def list_workspaces(user_id: str = None) -> list:
    data = _load()
    ws_list = data.get("workspaces", [])
    if user_id:
        ws_list = [w for w in ws_list
                   if any(m["user_id"] == user_id for m in w.get("members",[]))]
    return ws_list


def add_member(ws_id: str, user_id: str, role: str = "analyst",
               added_by: str = "admin") -> dict:
    data = _load()
    for w in data.get("workspaces", []):
        if w["id"] == ws_id:
            # Remove existing
            w["members"] = [m for m in w.get("members",[]) if m["user_id"] != user_id]
            w["members"].append({"user_id":user_id,"role":role,
                                  "added":datetime.utcnow().isoformat(),"added_by":added_by})
            _save(data)
            _log_activity(added_by, "added_member", ws_id, f"{user_id} as {role}")
            return w
    raise ValueError(f"Workspace {ws_id} not found")


def remove_member(ws_id: str, user_id: str, removed_by: str = "admin"):
    data = _load()
    for w in data.get("workspaces", []):
        if w["id"] == ws_id:
            w["members"] = [m for m in w.get("members",[]) if m["user_id"] != user_id]
            _save(data)
            _log_activity(removed_by, "removed_member", ws_id, user_id)
            return
    raise ValueError(f"Workspace {ws_id} not found")


def add_domain_to_workspace(ws_id: str, domain: str, added_by: str = "admin"):
    data = _load()
    for w in data.get("workspaces", []):
        if w["id"] == ws_id:
            if domain not in w.get("domains", []):
                w.setdefault("domains", []).append(domain)
                _save(data)
                _log_activity(added_by, "added_domain", ws_id, domain)
            return
    raise ValueError(f"Workspace {ws_id} not found")


def user_can_access_domain(user_id: str, domain: str) -> bool:
    """Check if user can access a domain via any workspace membership."""
    data = _load()
    for w in data.get("workspaces", []):
        member_ids = [m["user_id"] for m in w.get("members", [])]
        if user_id in member_ids and domain in w.get("domains", []):
            return True
    return False  # If no workspaces, domain is accessible (single-user mode)


# ── Comments on findings ────────────────────────────────────────────────────────
_COMMENTS_DIR = _DATA_DIR / "_comments"


def add_comment(domain: str, finding_id: str, author: str,
                text: str, finding_title: str = "") -> dict:
    _COMMENTS_DIR.mkdir(parents=True, exist_ok=True)
    cf = _COMMENTS_DIR / f"{domain.replace('/','_')}.json"
    comments = json.loads(cf.read_text()) if cf.exists() else []
    comment = {
        "id":            "c_" + secrets.token_hex(6),
        "finding_id":    finding_id,
        "finding_title": finding_title,
        "author":        author,
        "text":          text,
        "ts":            datetime.utcnow().isoformat() + "Z",
        "edited":        False,
    }
    comments.append(comment)
    cf.write_text(json.dumps(comments, indent=2))
    _log_activity(author, "commented", domain, f"on {finding_title}: {text[:50]}")
    return comment


def get_comments(domain: str, finding_id: str = None) -> list:
    cf = _COMMENTS_DIR / f"{domain.replace('/','_')}.json"
    if not cf.exists():
        return []
    comments = json.loads(cf.read_text())
    if finding_id:
        comments = [c for c in comments if c.get("finding_id") == finding_id]
    return comments


def delete_comment(domain: str, comment_id: str, deleted_by: str):
    cf = _COMMENTS_DIR / f"{domain.replace('/','_')}.json"
    if not cf.exists():
        return
    comments = json.loads(cf.read_text())
    comments  = [c for c in comments if c["id"] != comment_id]
    cf.write_text(json.dumps(comments, indent=2))
    _log_activity(deleted_by, "deleted_comment", domain, comment_id)


# ── Finding assignments ─────────────────────────────────────────────────────────
_ASSIGNS_DIR = _DATA_DIR / "_assignments"


def assign_finding(domain: str, finding_id: str, assignee: str,
                   assigned_by: str, note: str = "") -> dict:
    _ASSIGNS_DIR.mkdir(parents=True, exist_ok=True)
    af = _ASSIGNS_DIR / f"{domain.replace('/','_')}.json"
    assigns = json.loads(af.read_text()) if af.exists() else {}
    assigns[finding_id] = {
        "assignee":    assignee,
        "assigned_by": assigned_by,
        "note":        note,
        "ts":          datetime.utcnow().isoformat() + "Z",
        "status":      "open",
    }
    af.write_text(json.dumps(assigns, indent=2))
    _log_activity(assigned_by, "assigned_finding", domain,
                  f"{finding_id} → {assignee}")
    return assigns[finding_id]


def get_assignments(domain: str) -> dict:
    af = _ASSIGNS_DIR / f"{domain.replace('/','_')}.json"
    if not af.exists():
        return {}
    return json.loads(af.read_text())


def update_assignment_status(domain: str, finding_id: str,
                             status: str, updated_by: str):
    """Status: open | in_progress | fixed | wont_fix | false_positive"""
    af = _ASSIGNS_DIR / f"{domain.replace('/','_')}.json"
    assigns = json.loads(af.read_text()) if af.exists() else {}
    if finding_id in assigns:
        assigns[finding_id]["status"]     = status
        assigns[finding_id]["updated_by"] = updated_by
        assigns[finding_id]["updated_ts"] = datetime.utcnow().isoformat() + "Z"
        af.write_text(json.dumps(assigns, indent=2))
        _log_activity(updated_by, "status_changed", domain,
                      f"{finding_id} → {status}")


# ── Activity feed ───────────────────────────────────────────────────────────────
def get_activity(limit: int = 50, user_id: str = None) -> list:
    data = _load()
    feed = data.get("activity", [])
    if user_id:
        feed = [a for a in feed if a.get("actor") == user_id]
    return feed[:limit]


def get_team_stats() -> dict:
    """Dashboard stats for team overview."""
    data  = _load()
    users_file = Path(os.environ.get("TMR_DATA_DIR","./data")) / "_users" / "users.json"
    users = json.loads(users_file.read_text()) if users_file.exists() else []

    return {
        "total_workspaces": len(data.get("workspaces", [])),
        "total_members":    len(users),
        "total_activity":   len(data.get("activity", [])),
        "active_members":   sum(1 for u in users if u.get("active")),
        "roles":            {r: sum(1 for u in users if u.get("role")==r)
                             for r in ["admin","analyst","viewer","reporter"]},
    }


# ══════════════════════════════════════════════════════════════════════════════
# NOTIFICATIONS
# ══════════════════════════════════════════════════════════════════════════════

def get_notifications(username: str, unread_only: bool = False) -> list:
    """Get notifications for a user."""
    data  = _load()
    notifs = data.get("notifications", {}).get(username, [])
    if unread_only:
        notifs = [n for n in notifs if not n.get("read", False)]
    return sorted(notifs, key=lambda n: n.get("ts",""), reverse=True)[:50]


def mark_notifications_read(username: str, ids: list = None) -> bool:
    """Mark notifications as read. Pass ids=None to mark all."""
    data = _load()
    notifs = data.get("notifications", {})
    user_notifs = notifs.get(username, [])
    for n in user_notifs:
        if ids is None or n.get("id") in ids:
            n["read"] = True
    notifs[username] = user_notifs
    data["notifications"] = notifs
    _save(data)
    return True


def add_notification(username: str, title: str, body: str,
                     notif_type: str = "info", link: str = "") -> dict:
    """Add a notification for a user."""
    import secrets as _sec
    data  = _load()
    notifs = data.setdefault("notifications", {})
    user_n = notifs.setdefault(username, [])
    n = {"id": _sec.token_hex(6), "title": title, "body": body,
         "type": notif_type, "link": link, "read": False,
         "ts": __import__("time").strftime("%Y-%m-%dT%H:%M:%SZ")}
    user_n.insert(0, n)
    notifs[username] = user_n[:100]  # keep last 100
    data["notifications"] = notifs
    _save(data)
    return n


# ══════════════════════════════════════════════════════════════════════════════
# AUDIT LOG
# ══════════════════════════════════════════════════════════════════════════════

def audit_log(username: str, action: str, resource: str = "",
              details: dict = None) -> None:
    """Append an audit log entry."""
    data = _load()
    logs = data.setdefault("audit_log", [])
    logs.append({
        "ts":       __import__("time").strftime("%Y-%m-%dT%H:%M:%SZ"),
        "user":     username,
        "action":   action,
        "resource": resource,
        "details":  details or {},
    })
    data["audit_log"] = logs[-5000:]  # keep last 5000
    _save(data)


def get_audit_log(limit: int = 100, username: str = "",
                  action: str = "") -> list:
    """Retrieve audit log entries with optional filters."""
    data = _load()
    logs = data.get("audit_log", [])
    if username:
        logs = [l for l in logs if l.get("user") == username]
    if action:
        logs = [l for l in logs if action.lower() in l.get("action","").lower()]
    return sorted(logs, key=lambda l: l.get("ts",""), reverse=True)[:limit]


# ══════════════════════════════════════════════════════════════════════════════
# WORKSPACE NOTES
# ══════════════════════════════════════════════════════════════════════════════

def add_note(workspace_id: str, author: str, domain: str,
             content: str) -> dict:
    """Add a note to a domain within a workspace."""
    import secrets as _sec
    data = _load()
    ws   = data.get("workspaces", {}).get(workspace_id)
    if not ws:
        return {"error": "Workspace not found"}
    notes = ws.setdefault("notes", {}).setdefault(domain, [])
    note  = {"id": _sec.token_hex(6), "author": author,
             "content": content,
             "ts": __import__("time").strftime("%Y-%m-%dT%H:%M:%SZ")}
    notes.append(note)
    ws["notes"][domain] = notes
    _save(data)
    _log_activity(workspace_id, author, "add_note", domain=domain)
    return note


def get_notes(workspace_id: str, domain: str = "") -> list:
    """Get notes for a workspace (optionally filtered by domain)."""
    data = _load()
    ws   = data.get("workspaces", {}).get(workspace_id, {})
    notes_map = ws.get("notes", {})
    if domain:
        return notes_map.get(domain, [])
    # Return all notes flattened
    all_notes = []
    for d, dnotes in notes_map.items():
        for n in dnotes:
            all_notes.append({**n, "domain": d})
    return sorted(all_notes, key=lambda n: n.get("ts",""), reverse=True)


# ══════════════════════════════════════════════════════════════════════════════
# REPORT SHARING
# ══════════════════════════════════════════════════════════════════════════════

def share_report(domain: str, shared_by: str, findings: list,
                 expires_hours: int = 72) -> dict:
    """Generate a shareable report token."""
    import secrets as _sec, time as _t
    data   = _load()
    shares = data.setdefault("shared_reports", {})
    token  = _sec.token_urlsafe(24)
    shares[token] = {
        "domain":    domain,
        "shared_by": shared_by,
        "findings":  findings,
        "created":   _t.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "expires":   _t.time() + (expires_hours * 3600),
        "views":     0,
    }
    data["shared_reports"] = shares
    _save(data)
    return {"token": token, "expires_hours": expires_hours}


def get_shared_report(token: str) -> dict:
    """Retrieve a shared report by token."""
    import time as _t
    data  = _load()
    share = data.get("shared_reports", {}).get(token)
    if not share:
        return {"error": "Report not found"}
    if _t.time() > share.get("expires", 0):
        return {"error": "Report link has expired"}
    # Increment view count
    share["views"] += 1
    _save(data)
    return share


# ══════════════════════════════════════════════════════════════════════════════
# WORKSPACE UPDATE + INVITE JOIN
# ══════════════════════════════════════════════════════════════════════════════

def update_workspace(workspace_id: str, updates: dict) -> dict:
    """Update workspace metadata."""
    data = _load()
    ws   = data.get("workspaces", {}).get(workspace_id)
    if not ws:
        return {"error": "Workspace not found"}
    allowed = {"name", "description", "color", "icon", "settings"}
    for k, v in updates.items():
        if k in allowed:
            ws[k] = v
    ws["updated"] = __import__("time").strftime("%Y-%m-%dT%H:%M:%SZ")
    _save(data)
    return ws


def join_by_invite(invite_code: str, username: str) -> dict:
    """Join a workspace using an invite code."""
    data = _load()
    # Search all workspaces for this invite code
    for ws_id, ws in data.get("workspaces", {}).items():
        invites = ws.get("invite_codes", [])
        for inv in invites:
            if inv.get("code") == invite_code:
                if not inv.get("active", True):
                    return {"error": "Invite code has been deactivated"}
                # Add member
                members = ws.setdefault("members", [])
                if username not in [m if isinstance(m,str) else m.get("username") for m in members]:
                    members.append({"username": username, "role": "analyst",
                                    "joined": __import__("time").strftime("%Y-%m-%dT%H:%M:%SZ")})
                    ws["members"] = members
                    _log_activity(ws_id, username, "joined_via_invite")
                    _save(data)
                return {"ok": True, "workspace_id": ws_id, "workspace_name": ws.get("name","")}
    return {"error": "Invalid or expired invite code"}
