"""
BugScan APEX — Knowledge Graph
Maps relationships: domains → subdomains → endpoints → technologies → vulnerabilities.
Used to discover attack paths and prioritize targets intelligently.
"""
import json, time, logging, re, urllib.parse
from typing import Dict, List, Set, Optional, Tuple
from pathlib import Path
from collections import defaultdict
import os

log = logging.getLogger("apex.graph")

_GRAPH_DIR = Path(os.path.dirname(__file__)).parent / "data" / "apex_brain"
_GRAPH_DIR.mkdir(parents=True, exist_ok=True)


class KnowledgeGraph:
    """
    Graph structure:
        domain → {subdomains, ips, tech_stack}
        subdomain → {endpoints, open_ports, server}
        endpoint → {params, tech, classification, findings}
        finding → {type, severity, pivot_targets}

    Enables:
        - Find all endpoints that share a vulnerability pattern
        - Map which subdomains have the most attack surface
        - Trace exploitation paths across the graph
        - Identify high-value pivot points
    """

    def __init__(self, domain: str):
        self.domain  = domain
        self.nodes: Dict[str, Dict] = {}   # id → node data
        self.edges: List[Tuple]     = []   # (from_id, rel, to_id)
        self._load()

    # ── Node management ───────────────────────────────────────────────────────

    def add_domain(self, domain: str, meta: Dict = None):
        nid = f"domain:{domain}"
        self.nodes[nid] = {"type": "domain", "domain": domain, **(meta or {})}
        return nid

    def add_subdomain(self, sub: str, ip: str = "", server: str = "",
                      tech: List[str] = None, status: int = 0):
        nid = f"sub:{sub}"
        self.nodes[nid] = {
            "type":   "subdomain", "host": sub,
            "ip":     ip, "server": server,
            "tech":   tech or [], "status": status,
            "ts":     int(time.time()),
        }
        # Edge: domain → subdomain
        domain = ".".join(sub.split(".")[-2:])
        dom_nid = f"domain:{domain}"
        if dom_nid not in self.nodes:
            self.add_domain(domain)
        self._edge(dom_nid, "has_sub", nid)
        return nid

    def add_endpoint(self, url: str, params: List[str] = None,
                     classification: str = "", tech: List[str] = None):
        nid = f"ep:{url[:120]}"
        parsed = urllib.parse.urlparse(url)
        host   = parsed.netloc
        self.nodes[nid] = {
            "type":   "endpoint", "url": url,
            "host":   host, "path": parsed.path,
            "params": params or [],
            "class":  classification,
            "tech":   tech or [],
            "ts":     int(time.time()),
        }
        # Edge: subdomain → endpoint
        sub_nid = f"sub:{host}"
        if sub_nid not in self.nodes:
            self.add_subdomain(host)
        self._edge(sub_nid, "has_ep", nid)
        return nid

    def add_finding(self, url: str, bug: str, severity: str,
                    description: str, poc: str = ""):
        fid = f"vuln:{bug}:{url[:80]}"
        self.nodes[fid] = {
            "type":        "vulnerability",
            "bug":         bug, "severity": severity,
            "url":         url, "description": description,
            "poc":         poc[:200],
            "ts":          int(time.time()),
        }
        ep_nid = f"ep:{url[:120]}"
        if ep_nid not in self.nodes:
            self.add_endpoint(url)
        self._edge(ep_nid, "has_vuln", fid)

        # Auto-infer pivot edges
        self._infer_pivots(fid, bug, url)
        return fid

    def _infer_pivots(self, finding_nid: str, bug: str, url: str):
        """Automatically add pivot edges based on finding type."""
        # SSRF on one host can reach all internal hosts
        if bug == "ssrf":
            for nid, node in self.nodes.items():
                if node["type"] == "subdomain":
                    self._edge(finding_nid, "can_pivot_to", nid)

        # LFI can expose configs that affect other endpoints
        if bug == "lfi":
            host = urllib.parse.urlparse(url).netloc
            for nid, node in self.nodes.items():
                if node["type"] == "endpoint" and node.get("host") == host:
                    self._edge(finding_nid, "may_expose", nid)

        # XSS → session theft → all authenticated endpoints
        if bug == "xss":
            for nid, node in self.nodes.items():
                if node["type"] == "endpoint" and "login" in node.get("class",""):
                    self._edge(finding_nid, "enables_session_theft", nid)

    def _edge(self, from_id: str, rel: str, to_id: str):
        e = (from_id, rel, to_id)
        if e not in self.edges:
            self.edges.append(e)

    # ── Graph queries ──────────────────────────────────────────────────────────

    def get_attack_paths(self) -> List[Dict]:
        """Find all multi-step exploitation paths through the graph."""
        paths = []

        # Path type 1: SSRF → internal endpoint
        ssrf_nodes = [nid for nid, n in self.nodes.items()
                      if n.get("bug") == "ssrf"]
        for sn in ssrf_nodes:
            pivots = [t for f, r, t in self.edges
                      if f == sn and r == "can_pivot_to"]
            if pivots:
                paths.append({
                    "type":   "ssrf_internal_pivot",
                    "start":  sn,
                    "steps":  pivots[:5],
                    "impact": "Reach internal services, possible RCE",
                    "severity": "critical",
                })

        # Path type 2: XSS → session theft
        xss_nodes = [nid for nid, n in self.nodes.items()
                     if n.get("bug") == "xss"]
        for xn in xss_nodes:
            session_targets = [t for f, r, t in self.edges
                               if f == xn and r == "enables_session_theft"]
            if session_targets:
                paths.append({
                    "type":   "xss_account_takeover",
                    "start":  xn,
                    "steps":  session_targets[:3],
                    "impact": "Steal session tokens, account takeover",
                    "severity": "high",
                })

        # Path type 3: LFI → config disclosure
        lfi_nodes = [nid for nid, n in self.nodes.items()
                     if n.get("bug") == "lfi"]
        for ln in lfi_nodes:
            exposed = [t for f, r, t in self.edges
                       if f == ln and r == "may_expose"]
            if exposed:
                paths.append({
                    "type":   "lfi_credential_leak",
                    "start":  ln,
                    "steps":  exposed[:5],
                    "impact": "Extract config files, credentials, source code",
                    "severity": "high",
                })

        return paths

    def get_high_value_targets(self) -> List[Dict]:
        """Return endpoints with most attack surface / highest priority."""
        scores = {}
        for nid, node in self.nodes.items():
            if node["type"] != "endpoint": continue
            score = 0
            # More params = more attack surface
            score += len(node.get("params", [])) * 2
            # Known vulnerable tech
            for t in node.get("tech", []):
                score += len({
                    "spring": 5, "php": 3, "jenkins": 5,
                    "wordpress": 4, "graphql": 4
                }.get(t.lower(), 0))
            # Has login/api/admin in class
            if node.get("class") in ("login_portal","admin_panel","api_endpoint"):
                score += 5
            scores[nid] = score

        ranked = sorted(scores.items(), key=lambda x: -x[1])[:20]
        result = []
        for nid, score in ranked:
            n = self.nodes[nid]
            # Count findings on this endpoint
            findings = [t for f, r, t in self.edges
                        if f == nid and r == "has_vuln"]
            result.append({
                "url":      n["url"],
                "score":    score,
                "params":   n.get("params", []),
                "tech":     n.get("tech", []),
                "class":    n.get("class", ""),
                "findings": len(findings),
            })
        return result

    def get_subdomain_risk_map(self) -> List[Dict]:
        """Return subdomains ranked by vulnerability count and severity."""
        risk = defaultdict(lambda: {"critical": 0, "high": 0, "medium": 0,
                                     "low": 0, "endpoints": 0, "host": ""})
        for nid, node in self.nodes.items():
            if node["type"] == "vulnerability":
                # Find the subdomain this vuln belongs to
                url  = node.get("url","")
                host = urllib.parse.urlparse(url).netloc
                sev  = node.get("severity","low")
                risk[host][sev]  = risk[host].get(sev, 0) + 1
                risk[host]["host"] = host

        for nid, node in self.nodes.items():
            if node["type"] == "endpoint":
                risk[node["host"]]["endpoints"] += 1

        result = [v for v in risk.values() if v["host"]]
        result.sort(key=lambda x: -(x["critical"]*10 + x["high"]*3 + x["medium"]))
        return result[:20]

    def get_stats(self) -> Dict:
        by_type = defaultdict(int)
        for n in self.nodes.values():
            by_type[n["type"]] += 1
        return {
            "total_nodes": len(self.nodes),
            "total_edges": len(self.edges),
            "by_type":     dict(by_type),
            "attack_paths": len(self.get_attack_paths()),
        }

    # ── Persistence ───────────────────────────────────────────────────────────

    def _path(self):
        safe = re.sub(r'[^\w.-]', '_', self.domain)
        return _GRAPH_DIR / f"graph_{safe}.json"

    def _load(self):
        p = self._path()
        if p.exists():
            try:
                data = json.loads(p.read_text())
                self.nodes = data.get("nodes", {})
                self.edges = [tuple(e) for e in data.get("edges", [])]
            except: pass

    def save(self):
        try:
            self._path().write_text(json.dumps({
                "domain": self.domain,
                "nodes":  self.nodes,
                "edges":  self.edges,
                "saved":  int(time.time()),
            }, indent=2))
        except Exception as e:
            log.debug(f"[apex.graph] save error: {e}")


# ── Graph registry ────────────────────────────────────────────────────────────
_graphs: Dict[str, KnowledgeGraph] = {}

def get_graph(domain: str) -> KnowledgeGraph:
    if domain not in _graphs:
        _graphs[domain] = KnowledgeGraph(domain)
    return _graphs[domain]
