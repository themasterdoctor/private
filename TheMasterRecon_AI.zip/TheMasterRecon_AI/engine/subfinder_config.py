"""
TheMasterRecon AI — Subfinder Provider Config Generator

Subfinder v2 supports 50+ API sources via ~/.config/subfinder/provider-config.yaml
This module auto-generates that config from whatever keys are in .env / environment.

Sources supported by subfinder (from official docs):
https://github.com/projectdiscovery/subfinder/wiki/provider-config

On every recon run, we regenerate the config with current keys so subfinder
automatically uses all configured API sources without any extra code.
"""
import os, yaml, logging, subprocess, shutil
from pathlib import Path

log = logging.getLogger("elite.subfinder_config")

# Mapping from our .env var names to subfinder provider-config keys
# Source: https://github.com/projectdiscovery/subfinder docs
KEY_MAP = {
    # Provider name in subfinder → list of (env_var, yaml_field) tuples
    "bevigil":          [("BEVIGIL_API_KEY",         "api_key")],
    "binaryedge":       [("BINARYEDGE_API_KEY",       "api_key")],
    "bufferover":       [],  # free, no key needed
    "c99":              [("C99_API_KEY",               "api_key")],
    "censys":           [("CENSYS_API_ID",             "api_id"),
                         ("CENSYS_API_SECRET",         "api_secret")],
    "certspotter":      [("CERTSPOTTER_API_KEY",       "api_key")],
    "chaos":            [("CHAOS_API_KEY",             "api_key")],
    "chinaz":           [("CHINAZ_API_KEY",            "api_key")],
    "dnsdb":            [("DNSDB_API_KEY",             "api_key")],
    "dnsrepo":          [],  # free
    "facebook":         [("FACEBOOK_APP_ID",           "app_id"),
                         ("FACEBOOK_APP_SECRET",       "app_secret")],
    "fofa":             [("FOFA_EMAIL",                "email"),
                         ("FOFA_API_KEY",              "api_key")],
    "fullhunt":         [("FULLHUNT_API_KEY",          "api_key")],
    "github":           [("GITHUB_TOKEN",              "api_key")],
    "hunter":           [("HUNTER_API_KEY",            "api_key")],
    "intelx":           [("INTELX_API_KEY",            "api_key"),
                         ("INTELX_HOST",               "host")],
    "leakix":           [("LEAKIX_API_KEY",            "api_key")],
    "netlas":           [("NETLAS_API_KEY",             "api_key")],
    "passivetotal":     [("PT_USERNAME",               "username"),
                         ("PT_KEY",                    "api_key")],
    "quake":            [("QUAKE_TOKEN",               "api_key")],
    "robtex":           [],  # free
    "securitytrails":   [("SECURITYTRAILS_API_KEY",   "api_key")],
    "shodan":           [("SHODAN_API_KEY",            "api_key")],
    "threatbook":       [("THREATBOOK_API_KEY",        "api_key")],
    "virustotal":       [("VIRUSTOTAL_API_KEY",        "api_key"),
                         ("VT_API_KEY",                "api_key")],
    "whoisxmlapi":      [("WHOISXML_API_KEY",          "api_key")],
    "zoomeye":          [("ZOOMEYE_API_KEY",           "api_key"),
                         ("ZOOMEYE_USERNAME",          "username")],
    # Additional sources (ProjectDiscovery infrastructure)
    "builtwith":        [("BUILTWITH_API_KEY",         "api_key")],
    "urlscan":          [("URLSCAN_API_KEY",           "api_key")],
    "recon_dev":        [],  # free
    "rapiddns":         [],  # free
}

SUBFINDER_CONFIG_DIR  = Path.home() / ".config" / "subfinder"
SUBFINDER_CONFIG_FILE = SUBFINDER_CONFIG_DIR / "provider-config.yaml"


def generate_provider_config() -> dict:
    """
    Generate subfinder provider config from environment variables.
    Returns the config dict and writes to ~/.config/subfinder/provider-config.yaml
    """
    config = {}
    configured_sources = []
    free_sources = []

    for provider, key_pairs in KEY_MAP.items():
        if not key_pairs:
            # Free source — always include
            free_sources.append(provider)
            continue

        # Build the provider config from env vars
        provider_cfg = {}
        has_any_key = False

        for env_var, yaml_key in key_pairs:
            val = os.environ.get(env_var, "").strip()
            if val:
                # Subfinder expects lists for most keys
                if yaml_key not in provider_cfg:
                    provider_cfg[yaml_key] = []
                provider_cfg[yaml_key].append(val)
                has_any_key = True

        if has_any_key:
            config[provider] = provider_cfg
            configured_sources.append(provider)

    if configured_sources or free_sources:
        try:
            SUBFINDER_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            SUBFINDER_CONFIG_FILE.write_text(yaml.dump(config, default_flow_style=False))
            log.info(f"[subfinder_config] Written: {len(configured_sources)} API + {len(free_sources)} free sources")
        except Exception as e:
            log.warning(f"[subfinder_config] Write failed: {e}")

    return {
        "config_file":          str(SUBFINDER_CONFIG_FILE),
        "configured_sources":   configured_sources,
        "free_sources":         free_sources,
        "total_active":         len(configured_sources) + len(free_sources),
        "all_sources":          list(KEY_MAP.keys()),
    }


def get_subfinder_cmd(domain: str, threads: int = 100, timeout: int = 30) -> list:
    """
    Build optimized subfinder command with current config.
    Generates provider config first so all API keys are used.
    """
    sf = shutil.which("subfinder")
    if not sf:
        return []

    # Generate fresh config each time (keys might have changed)
    generate_provider_config()

    cmd = [
        sf, "-d", domain,
        "-silent", "-all",
        "-t", str(threads),
        "-timeout", str(timeout),
        "-config", str(SUBFINDER_CONFIG_FILE),
    ]
    return cmd


def get_configured_count() -> int:
    """Return number of configured API sources."""
    result = generate_provider_config()
    return result["total_active"]
