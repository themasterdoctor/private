"""
engine/bounty_db.py — Bounty Revenue Mode: report lifecycle + payout tracking

Tables:
  bounty_reports  — one row per finding draft (draft → approved → submitted)
  bounty_payouts  — payout entries logged by human operator
  bounty_evidence — EIL evidence blobs attached to each report

States:
  draft              Created, EIL ran, evidence attached, not yet reviewed
  needs_review       Scope unverified or confidence < threshold
  ready_for_review   Scope verified, human review invited
  approved           Human operator approved — ready to package
  submitted          Operator marked as submitted to platform
  triaged            Platform acknowledged
  resolved           Platform marked resolved/fixed
  duplicate          Platform marked duplicate
  informative        Platform marked informational

Hard rules enforced here:
  - rejected findings (EIL confirmed=false) never get a draft
  - submitted requires approved first
  - scope_verified required before ready_for_review
"""

import sqlite3, json, time, hashlib, logging
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger("elite.bounty_db")

_DB_PATH = Path(__file__).parent.parent / "data" / "bounty.db"
_CONN: Optional[sqlite3.Connection] = None


def _db() -> sqlite3.Connection:
    global _CONN
    if _CONN is None:
        _DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(_DB_PATH), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.executescript("""
            PRAGMA journal_mode=WAL;

            CREATE TABLE IF NOT EXISTS bounty_reports (
                id              TEXT PRIMARY KEY,
                domain          TEXT NOT NULL,
                finding_id      TEXT,
                bug_type        TEXT NOT NULL,
                severity        TEXT NOT NULL,
                url             TEXT NOT NULL,
                title           TEXT,
                summary         TEXT,
                steps           TEXT,   -- JSON list of steps
                impact          TEXT,
                remediation     TEXT,
                severity_rationale TEXT,
                scope_verified  INTEGER DEFAULT 0,
                scope_notes     TEXT,
                program_name    TEXT,
                platform        TEXT,   -- hackerone|bugcrowd|intigriti|other
                eil_confirmed   INTEGER DEFAULT 0,
                eil_confidence  INTEGER DEFAULT 0,
                eil_proof       TEXT,
                status          TEXT DEFAULT 'draft',
                created_at      INTEGER DEFAULT (strftime('%s','now')),
                updated_at      INTEGER DEFAULT (strftime('%s','now')),
                approved_by     TEXT,
                approved_at     INTEGER,
                submitted_at    INTEGER,
                rejection_reason TEXT
            );

            CREATE TABLE IF NOT EXISTS bounty_evidence (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                report_id       TEXT NOT NULL REFERENCES bounty_reports(id) ON DELETE CASCADE,
                evidence_type   TEXT NOT NULL,  -- raw_request|raw_response|timing|headers|markers|screenshot
                label           TEXT,
                content         TEXT,
                created_at      INTEGER DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS bounty_payouts (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                report_id       TEXT NOT NULL REFERENCES bounty_reports(id),
                program_name    TEXT,
                platform        TEXT,
                severity        TEXT,
                status          TEXT,
                amount          REAL DEFAULT 0,
                currency        TEXT DEFAULT 'USD',
                submitted_date  TEXT,
                resolved_date   TEXT,
                notes           TEXT,
                created_at      INTEGER DEFAULT (strftime('%s','now'))
            );

            CREATE INDEX IF NOT EXISTS idx_br_domain  ON bounty_reports(domain);
            CREATE INDEX IF NOT EXISTS idx_br_status  ON bounty_reports(status);
            CREATE INDEX IF NOT EXISTS idx_bp_report  ON bounty_payouts(report_id);
        """)
        conn.commit()
        _CONN = conn
    return _CONN


def _rid(domain: str, url: str, bug_type: str) -> str:
    """Generate a stable report ID from domain+url+bug_type."""
    raw = f"{domain}:{url}:{bug_type}:{int(time.time())}"
    return "rpt_" + hashlib.sha256(raw.encode()).hexdigest()[:12]


def _row(r) -> Optional[Dict]:
    if r is None:
        return None
    d = dict(r)
    for key in ("steps",):
        if d.get(key):
            try:
                d[key] = json.loads(d[key])
            except Exception:
                pass
    return d


# ── Report CRUD ───────────────────────────────────────────────────────────────

def create_report(domain: str, finding: Dict,
                  program_name: str = "", platform: str = "",
                  scope_verified: bool = False,
                  scope_notes: str = "") -> str:
    """
    Create a bounty report draft from a finding.
    Only called when EIL confirmed=true OR needs_review.
    Returns report_id.
    """
    rid = _rid(domain, finding.get("url",""), finding.get("bug",""))
    steps = finding.get("steps_to_reproduce", [])
    if isinstance(steps, str):
        steps = [steps]
    status = "draft" if scope_verified else "needs_review"

    _db().execute("""
        INSERT OR IGNORE INTO bounty_reports
          (id, domain, finding_id, bug_type, severity, url, title,
           summary, steps, impact, remediation, severity_rationale,
           scope_verified, scope_notes, program_name, platform,
           eil_confirmed, eil_confidence, eil_proof, status)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        rid, domain,
        finding.get("id","") or finding.get("dedup_key",""),
        finding.get("bug",""), finding.get("severity","medium"),
        finding.get("url",""), finding.get("title",""),
        finding.get("summary","") or finding.get("description",""),
        json.dumps(steps),
        finding.get("impact",""), finding.get("remediation",""),
        finding.get("severity_rationale",""),
        1 if scope_verified else 0,
        scope_notes, program_name, platform,
        1 if finding.get("eil_confirmed") else 0,
        finding.get("eil_confidence", finding.get("confidence", 0)),
        finding.get("eil_proof",""),
        status,
    ))
    _db().commit()
    log.info(f"[bounty] report_draft_created id={rid} status={status}"
             f" bug={finding.get('bug','')} url={finding.get('url','')[:60]}")
    return rid


def attach_evidence(report_id: str, evidence_type: str,
                    label: str, content: str) -> None:
    """Attach an evidence artifact to a report."""
    _db().execute("""
        INSERT INTO bounty_evidence (report_id, evidence_type, label, content)
        VALUES (?,?,?,?)
    """, (report_id, evidence_type, label, content[:50_000]))
    _db().commit()
    log.info(f"[bounty] evidence_attached id={report_id}"
             f" type={evidence_type} label={label[:40]}")


def get_report(report_id: str) -> Optional[Dict]:
    r = _db().execute(
        "SELECT * FROM bounty_reports WHERE id=?", (report_id,)
    ).fetchone()
    d = _row(r)
    if d:
        d["evidence"] = [dict(e) for e in _db().execute(
            "SELECT * FROM bounty_evidence WHERE report_id=? ORDER BY id",
            (report_id,)
        ).fetchall()]
        d["payouts"] = [dict(p) for p in _db().execute(
            "SELECT * FROM bounty_payouts WHERE report_id=? ORDER BY id",
            (report_id,)
        ).fetchall()]
    return d


def list_reports(domain: str = "", status: str = "",
                 limit: int = 200) -> List[Dict]:
    q = "SELECT * FROM bounty_reports WHERE 1=1"
    params: list = []
    if domain:
        q += " AND domain=?"
        params.append(domain)
    if status:
        q += " AND status=?"
        params.append(status)
    q += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)
    return [_row(r) for r in _db().execute(q, params).fetchall()]


def set_status(report_id: str, status: str,
               approved_by: str = "", reason: str = "") -> bool:
    """
    Transition report status. Enforces business rules:
      - submitted requires approved first
      - ready_for_review requires scope_verified
    Returns True on success, False if rule violated.
    """
    VALID = {"draft","needs_review","ready_for_review",
             "approved","submitted","triaged","resolved",
             "duplicate","informative"}
    if status not in VALID:
        return False

    r = get_report(report_id)
    if not r:
        return False

    # Hard rule: cannot submit without approval
    if status == "submitted" and r.get("status") != "approved":
        log.warning(f"[bounty] submit blocked id={report_id}: not approved first")
        return False

    # Hard rule: cannot mark ready_for_review without scope verification
    if status == "ready_for_review" and not r.get("scope_verified"):
        log.warning(f"[bounty] ready_for_review blocked id={report_id}: scope not verified")
        return False

    now = int(time.time())
    updates = {"status": status, "updated_at": now}
    if status == "approved":
        updates["approved_by"] = approved_by or "operator"
        updates["approved_at"] = now
    if status == "submitted":
        updates["submitted_at"] = now
    if reason:
        updates["rejection_reason"] = reason

    cols = ", ".join(f"{k}=?" for k in updates)
    vals = list(updates.values()) + [report_id]
    _db().execute(f"UPDATE bounty_reports SET {cols} WHERE id=?", vals)
    _db().commit()

    if approved_by:
        log.info(f"[bounty] approved_by={approved_by} id={report_id}")
    log.info(f"[bounty] status_changed id={report_id} → {status}")
    return True


def verify_scope(report_id: str, verified: bool,
                 notes: str = "", program_name: str = "",
                 platform: str = "") -> None:
    """Mark scope verified. If verified, elevate draft → ready_for_review."""
    now = int(time.time())
    _db().execute("""
        UPDATE bounty_reports
        SET scope_verified=?, scope_notes=?, program_name=COALESCE(NULLIF(?,program_name),program_name),
            platform=COALESCE(NULLIF(?,platform),platform), updated_at=?
        WHERE id=?
    """, (1 if verified else 0, notes,
          program_name or "", platform or "", now, report_id))
    _db().commit()

    if verified:
        r = get_report(report_id)
        if r and r.get("status") == "draft":
            set_status(report_id, "ready_for_review")
        log.info(f"[bounty] scope_verified=true id={report_id}"
                 f" program={program_name} platform={platform}")
    else:
        log.info(f"[bounty] scope_verified=false id={report_id}")


# ── Payout CRUD ───────────────────────────────────────────────────────────────

def add_payout(report_id: str, amount: float, currency: str = "USD",
               program_name: str = "", platform: str = "",
               status: str = "", submitted_date: str = "",
               resolved_date: str = "", notes: str = "") -> int:
    cur = _db().execute("""
        INSERT INTO bounty_payouts
          (report_id, program_name, platform, severity, status,
           amount, currency, submitted_date, resolved_date, notes)
        SELECT ?, ?, ?, severity, ?,?,?,?,?,?
        FROM bounty_reports WHERE id=?
    """, (report_id, program_name, platform, status,
          amount, currency, submitted_date, resolved_date, notes,
          report_id))
    _db().commit()
    log.info(f"[bounty] payout_updated id={report_id}"
             f" amount={amount} {currency}")
    return cur.lastrowid


def get_stats() -> Dict:
    """Aggregate payout and report stats."""
    db = _db()
    total     = db.execute("SELECT COUNT(*) FROM bounty_reports").fetchone()[0]
    by_status = {r["status"]: r["cnt"] for r in db.execute(
        "SELECT status, COUNT(*) as cnt FROM bounty_reports GROUP BY status"
    ).fetchall()}
    pay_rows  = db.execute(
        "SELECT SUM(amount) as total, COUNT(*) as cnt, AVG(amount) as avg"
        " FROM bounty_payouts WHERE amount > 0"
    ).fetchone()
    total_pay   = pay_rows["total"] or 0
    avg_pay     = pay_rows["avg"]   or 0
    pay_count   = pay_rows["cnt"]   or 0
    submitted_n = by_status.get("submitted",0) + by_status.get("triaged",0) + \
                  by_status.get("resolved",0)
    resolved_n  = by_status.get("resolved",0)
    dup_n       = by_status.get("duplicate",0)
    win_rate    = round(resolved_n / max(submitted_n,1) * 100, 1)
    dup_rate    = round(dup_n / max(submitted_n,1) * 100, 1)
    return {
        "total_reports":    total,
        "by_status":        by_status,
        "draft":            by_status.get("draft",0),
        "needs_review":     by_status.get("needs_review",0),
        "ready_for_review": by_status.get("ready_for_review",0),
        "approved":         by_status.get("approved",0),
        "submitted":        submitted_n,
        "triaged":          by_status.get("triaged",0),
        "resolved":         resolved_n,
        "duplicate":        dup_n,
        "total_bounty":     round(total_pay,2),
        "average_payout":   round(avg_pay,2),
        "payout_count":     pay_count,
        "win_rate_pct":     win_rate,
        "duplicate_rate_pct": dup_rate,
    }
