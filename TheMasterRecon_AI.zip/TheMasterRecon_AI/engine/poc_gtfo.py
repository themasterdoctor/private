"""
BugScan ELITE — Hacktron PoC||GTFO Gate
Principle: every finding must prove impact with a working PoC.
No working PoC = downgrade severity + flag for manual review.

Hacktron's actual pipeline:
1. Find bug candidate
2. Generate PoC
3. Verify PoC works
4. Auto-generate patch suggestion
5. PoC || GTFO — if you can't prove it, don't report it
"""
import re, urllib.parse, hashlib, time
from typing import Dict, List, Optional, Tuple


# ── PoC quality standards per bug type ────────────────────────────────────────
_POC_STANDARDS: Dict[str, Dict] = {
    "xss": {
        "required_keywords": ["alert", "onerror", "onload", "javascript:", "svg", "<script"],
        "required_elements": ["url", "param"],
        "min_poc_length":    30,
        "proof_type":        "execution",
        "downgrade_to":      "medium",  # without PoC
    },
    "sqli": {
        "required_keywords": ["sleep", "union", "error", "boolean", "syntax", "mysql", "pg_sleep", "waitfor"],
        "required_elements": ["url", "param"],
        "min_poc_length":    20,
        "proof_type":        "injection",
        "downgrade_to":      "medium",
    },
    "ssrf": {
        "required_keywords": ["169.254", "localhost", "127.0.0.1", "10.", "192.168", "oob", "internal", "metadata"],
        "required_elements": ["url"],
        "min_poc_length":    20,
        "proof_type":        "callback",
        "downgrade_to":      "low",
    },
    "rce": {
        "required_keywords": ["cmd", "exec", "shell", "output", "oob", "id;", "whoami", "sleep"],
        "required_elements": ["url", "poc"],
        "min_poc_length":    30,
        "proof_type":        "execution",
        "downgrade_to":      "medium",
    },
    "lfi": {
        "required_keywords": ["etc/passwd", "etc/shadow", "win/system", "boot.ini", "wp-config", "root:x:"],
        "required_elements": ["url"],
        "min_poc_length":    15,
        "proof_type":        "file_read",
        "downgrade_to":      "low",
    },
    "ssti": {
        "required_keywords": ["7*7", "49", "{{", "${", "expression", "evaluated", "math"],
        "required_elements": ["url", "param"],
        "min_poc_length":    10,
        "proof_type":        "evaluation",
        "downgrade_to":      "medium",
    },
    "idor": {
        "required_keywords": ["other user", "different user", "unauthorized", "account", "user_id"],
        "required_elements": ["url", "param"],
        "min_poc_length":    20,
        "proof_type":        "data_access",
        "downgrade_to":      "low",
    },
    "cors": {
        "required_keywords": ["access-control-allow-origin", "credentials", "origin"],
        "required_elements": ["url"],
        "min_poc_length":    20,
        "proof_type":        "header_evidence",
        "downgrade_to":      "low",
    },
    "jwt": {
        "required_keywords": ["alg", "none", "accepted", "tampered", "confusion", "bypass"],
        "required_elements": ["url"],
        "min_poc_length":    20,
        "proof_type":        "token_tamper",
        "downgrade_to":      "medium",
    },
    "default": {
        "required_keywords": [],
        "required_elements": [],
        "min_poc_length":    0,
        "proof_type":        "generic",
        "downgrade_to":      "info",
    }
}


def enforce_poc_gtfo(finding: Dict) -> Tuple[bool, str, Dict]:
    """
    Hacktron PoC||GTFO enforcement.

    Returns:
        (passed: bool, reason: str, updated_finding: Dict)

    If passed=False:
        - severity is downgraded
        - _gtfo_flag = True added to finding
        - reason explains what's missing
    """
    bug      = finding.get("bug", finding.get("bug_type", "")).lower()
    poc      = str(finding.get("poc", "")).lower()
    desc     = str(finding.get("description", "")).lower()
    url      = finding.get("url", "")
    param    = finding.get("param", "")
    sev      = finding.get("severity", "info")
    oob      = finding.get("oob_confirmed", False) or finding.get("eil_confirmed", False)
    preview  = str(finding.get("preview", "")).lower()
    combined = poc + " " + desc + " " + preview

    std = _POC_STANDARDS.get(bug, _POC_STANDARDS["default"])

    failures = []

    # OOB confirmed = always passes (deterministic proof)
    if oob:
        updated = dict(finding)
        updated["_gtfo_passed"] = True
        updated["_gtfo_reason"] = "OOB/EIL confirmation — deterministic proof"
        return True, "OOB confirmed", updated

    # Check keyword evidence
    if std["required_keywords"]:
        has_keyword = any(k in combined for k in std["required_keywords"])
        if not has_keyword:
            failures.append(
                f"No {std['proof_type']} evidence in PoC "
                f"(expected one of: {', '.join(std['required_keywords'][:4])})"
            )

    # Check required elements
    if "url" in std["required_elements"] and not url:
        failures.append("No target URL")
    if "param" in std["required_elements"] and not param:
        failures.append("No vulnerable parameter identified")
    if "poc" in std["required_elements"] and (not poc or len(poc) < 5):
        failures.append("No PoC provided")

    # Check minimum PoC length
    if std["min_poc_length"] > 0 and len(poc) < std["min_poc_length"]:
        if not oob:
            failures.append(
                f"PoC too short ({len(poc)} chars, "
                f"minimum {std['min_poc_length']} for {bug})"
            )

    # ── Decision ──────────────────────────────────────────────────────────────
    updated = dict(finding)

    if not failures:
        updated["_gtfo_passed"] = True
        updated["_gtfo_reason"] = f"PoC meets {bug} proof standard"
        return True, updated["_gtfo_reason"], updated
    else:
        # Downgrade severity
        reason = f"PoC||GTFO: {'; '.join(failures)}"
        downgrade_to = std["downgrade_to"]

        SEV_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
        if SEV_ORDER.get(sev, 0) > SEV_ORDER.get(downgrade_to, 0):
            updated["severity"]        = downgrade_to
            updated["_severity_orig"]  = sev
            updated["_gtfo_downgraded"]= True

        updated["_gtfo_passed"]  = False
        updated["_gtfo_reason"]  = reason
        updated["_gtfo_missing"] = failures
        return False, reason, updated


def auto_generate_poc(finding: Dict) -> str:
    """
    Auto-generate a safe, reproducible PoC curl command.
    Used when poc field is empty or too short.
    Hacktron-style: every finding gets a working PoC.
    """
    bug   = finding.get("bug", finding.get("bug_type", "")).lower()
    url   = finding.get("url", "")
    param = finding.get("param", "")

    if not url:
        return ""

    # Parse base URL
    try:
        parsed = urllib.parse.urlparse(url)
        base   = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
        qs     = urllib.parse.parse_qs(parsed.query)
    except Exception:
        base = url
        qs   = {}

    # Per-bug PoC generation
    if bug in ("xss", "stored_xss"):
        payload = urllib.parse.quote('<img src=x onerror=alert(document.domain)>')
        if param:
            return f"# XSS PoC — parameter: {param}\ncurl -sk '{base}?{param}={payload}' | grep -i 'onerror\\|alert'"
        return f"# XSS PoC\ncurl -sk '{url}' | grep -i '<img\\|onerror'"

    elif bug == "sqli":
        if param:
            p1 = urllib.parse.quote("' AND SLEEP(5)-- -")
            p2 = urllib.parse.quote("' AND 1=1-- -")
            p3 = urllib.parse.quote("' AND 1=2-- -")
            return (
                f"# SQLi PoC — time-based (Hacktron OOBZero style)\n"
                f"time curl -sk '{base}?{param}={p1}'  # expect ~5s delay\n\n"
                f"# Boolean-based\n"
                f"curl -sk '{base}?{param}={p2}' > /tmp/true.html\n"
                f"curl -sk '{base}?{param}={p3}' > /tmp/false.html\n"
                f"diff /tmp/true.html /tmp/false.html  # should differ"
            )
        return f"# SQLi PoC — check all parameters\ncurl -sk '{url}' -v"

    elif bug == "ssrf":
        if param:
            p = urllib.parse.quote("http://169.254.169.254/latest/meta-data/")
            return (
                f"# SSRF PoC — cloud metadata\n"
                f"curl -sk '{base}?{param}={p}'\n\n"
                f"# OOB alternative (replace with your Burp Collaborator / interactsh)\n"
                f"curl -sk '{base}?{param}=http://YOUR-OOB-HOST/ssrf-test'"
            )
        return f"# SSRF PoC\ncurl -sk '{url}'"

    elif bug in ("rce", "ssti"):
        if param:
            p = urllib.parse.quote("{{7*7}}")
            return (
                f"# SSTI/RCE PoC — math test\n"
                f"curl -sk '{base}?{param}={p}' | grep '49'  # 7*7=49 confirms template execution"
            )

    elif bug == "lfi":
        if param:
            p = urllib.parse.quote("../../../etc/passwd")
            return (
                f"# LFI PoC\n"
                f"curl -sk '{base}?{param}={p}' | grep 'root:'"
            )

    elif bug == "cors":
        return (
            f"# CORS PoC\n"
            f"curl -sk -H 'Origin: https://evil.attacker.com' '{url}' -v 2>&1 | "
            f"grep -i 'access-control'"
        )

    elif bug == "jwt":
        return (
            f"# JWT PoC — alg:none test\n"
            f"# 1. Decode your JWT at jwt.io\n"
            f"# 2. Change alg to 'none', remove signature\n"
            f"# 3. Send modified token to: {url}"
        )

    elif bug == "idor":
        if param:
            return (
                f"# IDOR PoC\n"
                f"# With User A's session:\n"
                f"curl -sk '{base}?{param}=1' -H 'Cookie: session=USER_A_SESSION'\n"
                f"# Try accessing User B's ID:\n"
                f"curl -sk '{base}?{param}=2' -H 'Cookie: session=USER_A_SESSION'"
            )

    # Generic
    return (
        f"# {bug.upper()} PoC\n"
        f"curl -sk -v '{url}'"
    )


def generate_patch_suggestion(finding: Dict) -> str:
    """
    Hacktron-style patch suggestion.
    Returns a concrete code fix (not vague 'sanitize input' advice).
    """
    bug = finding.get("bug", finding.get("bug_type", "")).lower()

    patches = {
        "sqli": (
            "# Patch: Use parameterized queries (never string concatenation)\n\n"
            "# Python/SQLAlchemy\n"
            "# BAD:  cursor.execute(f'SELECT * FROM users WHERE id = {user_id}')\n"
            "# GOOD: cursor.execute('SELECT * FROM users WHERE id = %s', (user_id,))\n\n"
            "# Node.js/pg\n"
            "# BAD:  db.query(`SELECT * FROM users WHERE id = ${req.query.id}`)\n"
            "# GOOD: db.query('SELECT * FROM users WHERE id = $1', [req.query.id])"
        ),
        "xss": (
            "# Patch: Output encoding at render time\n\n"
            "# Python/Jinja2\n"
            "# BAD:  {{ user_input | safe }}\n"
            "# GOOD: {{ user_input }}  # autoescape enabled by default\n\n"
            "# JavaScript\n"
            "# BAD:  element.innerHTML = userInput\n"
            "# GOOD: element.textContent = userInput\n\n"
            "# Add CSP header:\n"
            "# Content-Security-Policy: default-src 'self'; script-src 'self'"
        ),
        "ssrf": (
            "# Patch: URL allowlist + block private IP ranges\n\n"
            "import ipaddress, urllib.parse\n\n"
            "ALLOWED_DOMAINS = {'api.example.com', 'cdn.example.com'}\n"
            "BLOCKED_RANGES  = [ipaddress.ip_network('169.254.0.0/16'),\n"
            "                   ipaddress.ip_network('10.0.0.0/8'),\n"
            "                   ipaddress.ip_network('172.16.0.0/12'),\n"
            "                   ipaddress.ip_network('192.168.0.0/16')]\n\n"
            "def safe_fetch(url):\n"
            "    parsed = urllib.parse.urlparse(url)\n"
            "    if parsed.hostname not in ALLOWED_DOMAINS:\n"
            "        raise ValueError('Domain not in allowlist')\n"
            "    # Also resolve and check IP\n"
            "    ip = ipaddress.ip_address(socket.gethostbyname(parsed.hostname))\n"
            "    if any(ip in net for net in BLOCKED_RANGES):\n"
            "        raise ValueError('Private IP range blocked')"
        ),
        "cors": (
            "# Patch: Strict origin allowlist\n\n"
            "ALLOWED_ORIGINS = {'https://app.example.com', 'https://www.example.com'}\n\n"
            "def get_cors_headers(request_origin):\n"
            "    if request_origin in ALLOWED_ORIGINS:\n"
            "        return {'Access-Control-Allow-Origin': request_origin,\n"
            "                'Access-Control-Allow-Credentials': 'true',\n"
            "                'Vary': 'Origin'}  # critical: add Vary header\n"
            "    return {}  # don't reflect arbitrary origins"
        ),
        "jwt": (
            "# Patch: Enforce algorithm + use strong secret\n\n"
            "import jwt\n\n"
            "# BAD: jwt.decode(token, key)  # accepts any algorithm\n"
            "# GOOD:\n"
            "jwt.decode(token, SECRET_KEY, algorithms=['HS256'])  # explicit allowlist\n\n"
            "# For RS256:\n"
            "jwt.decode(token, PUBLIC_KEY, algorithms=['RS256'])  # never allow HS256"
        ),
        "lfi": (
            "# Patch: Path canonicalization + allowlist\n\n"
            "import os\n\n"
            "SAFE_DIR = '/var/www/uploads/'\n\n"
            "def safe_open(user_path):\n"
            "    # Resolve symlinks and .. sequences\n"
            "    full_path = os.path.realpath(os.path.join(SAFE_DIR, user_path))\n"
            "    # Ensure it's inside the safe directory\n"
            "    if not full_path.startswith(SAFE_DIR):\n"
            "        raise PermissionError('Path traversal blocked')\n"
            "    return open(full_path)"
        ),
        "rce": (
            "# Patch: Never pass user input to shell\n\n"
            "import subprocess\n\n"
            "# BAD:  subprocess.run(f'ping {user_input}', shell=True)\n"
            "# GOOD: subprocess.run(['ping', '-c', '1', user_input], shell=False)\n\n"
            "# Validate input is a valid hostname/IP:\n"
            "import re\n"
            "if not re.match(r'^[a-zA-Z0-9.-]+$', user_input):\n"
            "    raise ValueError('Invalid input')"
        ),
        "idor": (
            "# Patch: Per-object authorization check\n\n"
            "# BAD:\n"
            "# def get_order(order_id):\n"
            "#     return db.query('SELECT * FROM orders WHERE id = ?', order_id)\n\n"
            "# GOOD:\n"
            "def get_order(order_id, current_user_id):\n"
            "    order = db.query('SELECT * FROM orders WHERE id = ?', order_id)\n"
            "    if order.user_id != current_user_id:\n"
            "        raise PermissionError('Access denied')  # 403\n"
            "    return order"
        ),
    }

    return patches.get(bug, (
        f"# Patch for {bug}\n"
        "# Consult OWASP guidelines for this vulnerability class.\n"
        "# Key principle: validate all input, encode all output,\n"
        "# enforce authorization at every object access."
    ))


def batch_enforce_poc(findings: List[Dict]) -> Dict:
    """
    Run PoC||GTFO on all findings.
    Returns {passed, failed, downgraded, updated_findings}
    """
    passed = failed = downgraded = 0
    updated = []

    for f in findings:
        ok, reason, f2 = enforce_poc_gtfo(f)
        if ok:
            passed += 1
        else:
            failed += 1
            if f2.get("_gtfo_downgraded"):
                downgraded += 1
        # Auto-generate PoC if missing
        if not f2.get("poc") or len(str(f2.get("poc", ""))) < 20:
            f2["poc"] = auto_generate_poc(f2) or f2.get("poc", "")
        # Add patch suggestion
        if not f2.get("_patch_suggestion"):
            f2["_patch_suggestion"] = generate_patch_suggestion(f2)
        updated.append(f2)

    return {
        "passed":           passed,
        "failed":           failed,
        "downgraded":       downgraded,
        "total":            len(findings),
        "updated_findings": updated,
    }
