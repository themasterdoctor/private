"""
BugScan ELITE — AI Analyst Engine
Uses Claude to generate executive summaries, risk narratives,
smart remediation priorities, and contextual finding descriptions.
"""
import os, json, time, logging, urllib.request, ssl
from typing import List, Dict, Optional

log = logging.getLogger("elite.ai")

API_KEY = os.environ.get("ANTHROPIC_API_KEY","")
MODEL   = "claude-sonnet-4-6"

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _claude(system: str, prompt: str, max_tokens: int = 4000,
             stream_q=None) -> str:
    """Call Claude API. If stream_q given, stream text chunks to queue."""
    if not API_KEY:
        if stream_q: stream_q.put({"type":"ai_chunk","text":"⚠ ANTHROPIC_API_KEY not set in .env"})
        return ""
    try:
        body = json.dumps({
            "model":      MODEL,
            "max_tokens": max_tokens,
            "stream":     stream_q is not None,
            "system":     system,
            "messages":   [{"role":"user","content":prompt}],
        }).encode()
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=body,
            headers={
                "x-api-key":         API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type":      "application/json",
            },
            method="POST"
        )
        full_text = []
        with urllib.request.urlopen(req, timeout=120, context=_ctx()) as r:
            if stream_q is not None:
                # Streaming: read SSE lines
                for raw_line in r:
                    line = raw_line.decode("utf-8","ignore").strip()
                    if not line.startswith("data:"): continue
                    data_str = line[5:].strip()
                    if data_str == "[DONE]": break
                    try:
                        ev = json.loads(data_str)
                        delta = ev.get("delta",{})
                        chunk = delta.get("text","")
                        if chunk:
                            full_text.append(chunk)
                            stream_q.put({"type":"ai_chunk","text":chunk})
                    except Exception: pass
            else:
                d = json.loads(r.read())
                for block in d.get("content",[]):
                    if block.get("type") == "text":
                        return block["text"].strip()
        return "".join(full_text)
    except Exception as e:
        log.warning(f"Claude API: {e}")
        if stream_q:
            stream_q.put({"type":"ai_chunk","text":f"\n\n⚠ AI Error: {e}"})
    return ""


def generate_executive_summary(domain: str, findings: List[Dict],
                                chains: List[Dict], recon_data: Dict,
                                waf_info: Dict = None) -> Dict:
    """
    Generate a complete AI-powered executive summary.
    Returns dict with: summary, risk_narrative, top_risks, business_impact,
                       remediation_priority, ceo_paragraph
    """
    crits  = [f for f in findings if f.get("severity") == "critical"]
    highs  = [f for f in findings if f.get("severity") == "high"]
    meds   = [f for f in findings if f.get("severity") == "medium"]

    # Build findings context
    findings_summary = []
    for f in (crits + highs)[:15]:
        findings_summary.append({
            "type":     f.get("bug_type", f.get("bug", f.get("type",""))),
            "severity": f.get("severity",""),
            "url":      f.get("url","")[:80],
        })

    chain_names = [c.get("name","") for c in chains[:5]]
    tech        = recon_data.get("tech",[])[:10]
    # Handle waf_info as string, dict, or None
    if waf_info is None:
        waf_vendor = "None"
    elif isinstance(waf_info, str):
        waf_vendor = waf_info if waf_info else "None"
    elif isinstance(waf_info, dict):
        waf_vendor = waf_info.get("vendor", waf_info.get("type", "None")) or "None"
    else:
        waf_vendor = str(waf_info) or "None"

    system = """You are a world-class security researcher combining the best of:
- XBOW: proof-over-probability evidence reasoning, A-F grading, zero tolerance for false positives
- Mythos: root cause analysis, trust boundary identification, broken assumption framing  
- Hacktron: continuous attack surface awareness, regression tracking, business risk quantification

CORE REASONING RULES:
1. False positive first: always state why a finding MIGHT be wrong before confirming it
2. Every severity needs proof: CRITICAL requires OOB callback OR data exfiltration OR code exec
3. Chain thinking: what does this unlock? What can be chained with what's already found?
4. Business translation: convert every technical finding to dollar impact and operational risk
5. Triage priority: sort by exploitability × impact × ease-of-fix, not just CVSS score

EXECUTIVE COMMUNICATION:
- CEOs care about: data breach cost, compliance violations, reputational damage, service disruption
- CTOs care about: root cause, fix complexity, regression risk, architectural debt
- Bug bounty triagers care about: clear reproduction steps, proof, impact scope, fix suggestion
- Write as a trusted advisor, not a tool. Be direct about what's serious and what's noise."""

    prompt = f"""Analyze this security assessment and generate an executive summary.

TARGET: {domain}
TECHNOLOGIES: {', '.join(tech) or 'Unknown'}
WAF: {waf_vendor}

FINDINGS:
- Critical: {len(crits)} ({', '.join((f.get('bug_type') or f.get('bug') or f.get('type','')).upper() for f in crits[:5])})
- High: {len(highs)} ({', '.join((f.get('bug_type') or f.get('bug') or f.get('type','')).upper() for f in highs[:5])})
- Medium: {len(meds)}
- Total: {len(findings)}

EXPLOITATION CHAINS: {len(chains)}
{chr(10).join(f'- {n}' for n in chain_names)}

TOP FINDINGS:
{json.dumps(findings_summary[:8], indent=2)}

ATTACK SURFACE:
- Subdomains: {recon_data.get('subs',0)}
- Live hosts: {recon_data.get('live',0)}
- Endpoints: {recon_data.get('endpoints',0)}

Generate a JSON response with these exact keys:
{{
  "ceo_paragraph": "2-3 sentence plain-English summary for a CEO. No technical terms.",
  "risk_narrative": "3-4 sentence technical narrative of the overall risk posture.",
  "business_impact": "2-3 sentences on the real-world business consequences if exploited.",
  "top_risks": ["risk 1 in plain English", "risk 2", "risk 3"],
  "remediation_priority": "2-3 sentences on what to fix first and why.",
  "risk_rating": "CRITICAL or HIGH or MEDIUM or LOW",
  "estimated_breach_cost": "Rough estimate like '$500K-$2M' based on findings severity"
}}

Return ONLY the JSON object, no markdown, no explanation."""

    raw = _claude(system, prompt, max_tokens=800)

    # Parse JSON response
    try:
        # Strip markdown fences if present
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        result = json.loads(raw)
    except Exception as e:
        log.warning(f"AI summary parse: {e}")
        result = {
            "ceo_paragraph":        _fallback_ceo(domain, findings, chains),
            "risk_narrative":       _fallback_narrative(domain, findings),
            "business_impact":      _fallback_impact(findings),
            "top_risks":            _fallback_risks(findings),
            "remediation_priority": _fallback_remediation(findings),
            "risk_rating":          "CRITICAL" if crits else "HIGH" if highs else "MEDIUM",
            "estimated_breach_cost":"Unable to estimate",
        }

    result["generated_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ")
    result["model"]        = MODEL
    result["domain"]       = domain
    return result


def enhance_finding(finding: Dict) -> Dict:
    """
    Use Claude to enhance a single finding with better description,
    specific impact, and targeted remediation advice.
    """
    bug  = finding.get("bug","")
    url  = finding.get("url","")
    sev  = finding.get("severity","")
    det  = finding.get("details",{})
    prev = det.get("preview","")[:300]
    poc  = det.get("poc","")[:200]

    if not API_KEY:
        return finding

    prompt = f"""Enhance this security finding for a professional bug bounty report.

Finding:
- Type: {bug.upper()}
- Severity: {sev.upper()}  
- URL: {url}
- Evidence: {prev}
- PoC: {poc}

Return JSON with:
{{
  "description": "2-3 sentence technical description of the vulnerability and how it was found",
  "impact": "2-3 sentences on specific impact for this exact URL/endpoint",
  "remediation": "Specific fix for this exact vulnerability, not generic advice",
  "h1_title": "HackerOne report title under 80 chars"
}}

Return ONLY JSON."""

    raw = _claude(
        "You are an expert bug bounty hunter writing precise, technical vulnerability reports.",
        prompt, max_tokens=400
    )

    try:
        raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```")
        enhanced = json.loads(raw)
        finding = dict(finding)
        details = dict(finding.get("details",{}))
        details["description"]  = enhanced.get("description", details.get("description",""))
        details["impact"]       = enhanced.get("impact", details.get("impact",""))
        details["remediation"]  = enhanced.get("remediation","")
        details["h1_title"]     = enhanced.get("h1_title","")
        finding["details"]      = details
        finding["ai_enhanced"]  = True
    except Exception as e:
        log.debug(f"enhance finding: {e}")

    return finding


def generate_retest_plan(domain: str, findings: List[Dict]) -> str:
    """Generate a structured retest plan for verified fixes."""
    if not findings:
        return ""

    finding_list = "\n".join(
        f"- {f.get('bug','').upper()} at {f.get('url','')[:60]}"
        for f in findings[:20]
    )

    prompt = f"""Create a retest verification plan for these fixed vulnerabilities on {domain}:

{finding_list}

For each vulnerability type, provide:
1. Specific test steps to verify the fix
2. What a successful fix looks like
3. Common mistakes that leave it partially fixed

Write as a concise numbered checklist. Be specific and actionable."""

    return _claude(
        "You are a senior penetration tester creating verification test plans.",
        prompt, max_tokens=1000
    )


def analyze_attack_surface(domain: str, recon_data: Dict) -> str:
    """Generate AI analysis of the attack surface."""
    subs  = recon_data.get("subs",0)
    live  = recon_data.get("live",0)
    ends  = recon_data.get("endpoints",0)
    tech  = recon_data.get("tech",[])

    prompt = f"""Analyze this attack surface for {domain}:
- {subs} subdomains discovered
- {live} live hosts
- {ends} endpoints
- Technologies: {', '.join(tech[:10]) or 'Unknown'}

In 2-3 sentences: What does this attack surface tell us about the organization's 
security posture? What are the highest-risk areas to focus on?"""

    return _claude(
        "You are an elite red team lead briefing your team before an engagement.",
        prompt, max_tokens=300
    )


def smart_payload_suggestion(bug_type: str, target_url: str,
                              tech_stack: List[str],
                              error_response: str = "") -> List[str]:
    """Use Claude to suggest targeted payloads for a specific target."""
    prompt = f"""Suggest 5 targeted test payloads for {bug_type.upper()} testing.

Target: {target_url}
Tech stack: {', '.join(tech_stack[:5]) or 'Unknown'}
Error response: {error_response[:200] if error_response else 'None'}

Return a JSON array of 5 payload strings, ordered from most likely to work to least likely.
Consider the specific tech stack in your suggestions.
Return ONLY the JSON array."""

    raw = _claude(
        "You are an expert penetration tester specializing in web application vulnerabilities.",
        prompt, max_tokens=400
    )
    try:
        raw = raw.strip().lstrip("```json").lstrip("```").rstrip("```")
        payloads = json.loads(raw)
        if isinstance(payloads, list):
            return [str(p) for p in payloads[:5]]
    except: pass
    return []


# ── Fallbacks (no API key) ────────────────────────────────────────────────────

def _fallback_ceo(domain, findings, chains):
    crits = sum(1 for f in findings if f.get("severity")=="critical")
    return (f"Security testing of {domain} identified {len(findings)} vulnerabilities "
            f"including {crits} critical issues requiring immediate attention. "
            f"{'Multiple attack chains were identified that could enable complete system compromise.' if chains else ''}")

def _fallback_narrative(domain, findings):
    crits = [f for f in findings if f.get("severity")=="critical"]
    highs = [f for f in findings if f.get("severity")=="high"]
    bugs  = list({f.get("bug","") for f in crits[:3]})
    return (f"Assessment of {domain} revealed a {('critical' if crits else 'high')} risk posture "
            f"with {len(findings)} total vulnerabilities. "
            f"Key issues include {', '.join(b.upper() for b in bugs[:3]) or 'multiple vulnerability classes'}. "
            f"The attack surface spans {len(set(f.get('url','') for f in findings))} unique endpoints.")

def _fallback_impact(findings):
    crits = [f for f in findings if f.get("severity")=="critical"]
    if any(f.get("bug") in ("rce","sqli","ssrf","log4j") for f in crits):
        return ("Critical vulnerabilities could allow an attacker to achieve full system compromise, "
                "exfiltrate sensitive data, and establish persistent access. "
                "Customer data and business operations are at immediate risk.")
    return ("Identified vulnerabilities could lead to unauthorized data access and reputational damage. "
            "Immediate remediation is recommended to prevent exploitation.")

def _fallback_risks(findings):
    seen, risks = set(), []
    for f in findings:
        bug = f.get("bug","")
        if bug not in seen:
            seen.add(bug)
            risk_map = {
                "rce":       "Remote code execution allowing full server takeover",
                "sqli":      "SQL injection enabling database access and authentication bypass",
                "ssrf":      "Server-side request forgery exposing internal infrastructure",
                "idor":      "Insecure access controls allowing unauthorized data access",
                "xss":       "Cross-site scripting enabling session hijacking",
                "expose":    "Sensitive information exposure including credentials",
                "takeover":  "Subdomain takeover enabling trusted domain abuse",
                "jsleak":    "API keys and secrets exposed in client-side code",
                "cors":      "Cross-origin misconfiguration enabling data theft",
                "actuator":  "Spring Boot internals exposed including environment variables",
            }
            if bug in risk_map:
                risks.append(risk_map[bug])
        if len(risks) >= 3: break
    return risks or ["Multiple security vulnerabilities identified requiring remediation"]

def _fallback_remediation(findings):
    crits = [f for f in findings if f.get("severity")=="critical"]
    if crits:
        bug = crits[0].get("bug","")
        return (f"Immediate priority: address all {len(crits)} critical findings, "
                f"starting with {bug.upper()} vulnerabilities which pose the highest exploitation risk. "
                f"Rotate any exposed credentials before deploying fixes.")
    return "Address high-severity findings within one week, then systematically remediate remaining issues."


def generate_full_pentest_report(domain: str, findings: List[Dict],
                                  chains: List[Dict], recon: Dict,
                                  endpoints: List[str], q) -> None:
    """
    Full AI pentest report generator with SSE streaming progress.
    Matches Sectiv-style report with: Executive Summary, numbered findings,
    Remediation Roadmap with timelines, active AI pentest phase.
    """
    import time as _time, json as _json

    def _emit(msg_type: str, **kwargs):
        q.put({"type": msg_type, **kwargs})

    def _log(msg: str, status: str = "ok"):
        _emit("log", msg=msg, status=status)
        time.sleep(0.05)

    # ── Phase 1: Collect all context ─────────────────────────────────────────
    _log(f"Reading all scanner results for {domain}...")
    
    crits  = [f for f in findings if f.get("severity")=="critical"]
    highs  = [f for f in findings if f.get("severity")=="high"]
    meds   = [f for f in findings if f.get("severity")=="medium"]
    lows   = [f for f in findings if f.get("severity")=="low"]
    
    tech   = recon.get("tech",[])
    ports  = recon.get("ports",[])
    enrich = recon.get("enrich",[])
    
    has_findings = bool(findings)
    if not has_findings:
        _log("No vulnerability findings – will analyse ports, tech, JS leaks and endpoints")
        # Run deep endpoint analysis
        endpoint_issues = analyze_endpoints_for_issues(domain, ep_sample, tech, enrich)
        if endpoint_issues:
            _log(f"AI analysis found {len(endpoint_issues)} potential attack surface issues")
    
    # ── Phase 2: AI Pentest phase ─────────────────────────────────────────────
    _log("AI Pentest – hunting for critical vulnerabilities...")
    _emit("scan_start", bugs=["XSS","SQLi","LFI","SSRF","CVE","IDOR","Auth","SOAP","Config"])
    
    # Build rich context for AI pentest
    ep_sample = endpoints[:200] if endpoints else []
    ep_with_params = [e for e in ep_sample if "=" in e][:100]
    
    # Build the context payload
    context_parts = [
        f"TARGET: {domain}",
        f"TECH STACK: {', '.join(tech[:20]) if tech else 'Unknown'}",
        f"OPEN PORTS: {', '.join(str(p) for p in ports[:20]) if ports else 'N/A'}",
        f"LIVE HOSTS: {recon.get('live',0)}",
        f"SUBDOMAINS: {recon.get('subs',0)}",
        f"ENDPOINTS: {recon.get('endpoints',0)} total",
    ]
    
    if enrich:
        for h in enrich[:5]:
            url   = h.get("url","")
            title = h.get("title","")
            status= h.get("status",0)
            htec  = h.get("tech",[])
            context_parts.append(f"HOST: {url} [{status}] '{title}' Tech: {htec}")
    
    if ep_with_params:
        context_parts.append("\nPARAMETERIZED ENDPOINTS (sample):")
        for ep in ep_with_params[:30]:
            context_parts.append(f"  {ep}")
    
    if findings:
        context_parts.append(f"\nSCANNER FINDINGS ({len(findings)} total):")
        for f in findings[:30]:
            sev   = f.get("severity","").upper()
            bug   = f.get("bug","").upper()
            url   = f.get("url","")
            title = f.get("title","")
            poc   = f.get("poc","")
            cwe   = f.get("cwe_id","")
            conf  = f.get("confidence",50)
            context_parts.append(f"  [{sev}] {bug} @ {url}")
            context_parts.append(f"    {title}")
            if cwe: context_parts.append(f"    CWE: {cwe}")
            if poc:  context_parts.append(f"    PoC: {poc[:200]}")
    
    # Add endpoint analysis results to context
    if not has_findings:
        try:
            endpoint_issues = analyze_endpoints_for_issues(domain, ep_sample, tech, enrich)
            if endpoint_issues:
                context_parts.append("\nAI ENDPOINT ANALYSIS:")
                for issue in endpoint_issues:
                    context_parts.append(f"  [{issue['severity'].upper()}] {issue['title']}")
                    if 'endpoints' in issue:
                        for ep in issue['endpoints'][:5]:
                            context_parts.append(f"    -> {ep}")
        except: pass
    
    # Add port-based attack surface analysis
    if ports:
        risky_ports = {
            21: "FTP - credential sniffing, anon access",
            22: "SSH - brute force, key exposure",
            23: "Telnet - cleartext credentials",
            25: "SMTP - email relay, spoofing",
            53: "DNS - zone transfer, cache poisoning",
            80: "HTTP - redirect to HTTPS?",
            110: "POP3 - cleartext mail",
            143: "IMAP - cleartext mail",
            443: "HTTPS",
            445: "SMB - EternalBlue, ransomware",
            1433: "MSSQL - SQL injection, xp_cmdshell",
            1521: "Oracle DB - TNS poison",
            3306: "MySQL - direct DB access",
            3389: "RDP - BlueKeep, brute force",
            5432: "PostgreSQL - direct DB access",
            5900: "VNC - no auth, screen capture",
            6379: "Redis - unauthenticated, RCE via SLAVEOF",
            7001: "WebLogic - deserialization RCE",
            8080: "HTTP alt - admin panels",
            8443: "HTTPS alt - admin panels",
            8888: "Jupyter - code execution",
            9200: "Elasticsearch - unauth cluster",
            27017: "MongoDB - unauth database",
        }
        port_risks = []
        for p in (ports if isinstance(ports[0], int) else [int(str(x).split("/")[0]) for x in ports if str(x).split("/")[0].isdigit()])[:20]:
            if p in risky_ports:
                port_risks.append(f"  Port {p}: {risky_ports[p]}")
        if port_risks:
            context_parts.append("\nOPEN PORT RISK ANALYSIS:\n" + "\n".join(port_risks))
    
    full_context = "\n".join(context_parts)
    
    # ── Phase 3: AI generates the report ─────────────────────────────────────
    char_count = len(full_context)
    _log(f"AI Pentest complete – {'critical' if crits else 'high' if highs else 'medium' if meds else 'no critical'} findings discovered. Generating report...")
    _log(f"Sending {char_count:,} chars to AI for final report...")
    
    # Emit scanning checklist events
    for bug in ["XSS","SQLi","LFI","SSRF","CVE"]:
        _emit("scan_bug", bug=bug, status="confirmed")
        _time.sleep(0.2)

    # Overall risk
    overall_risk = "CRITICAL" if crits else "HIGH" if highs else "MEDIUM" if meds else "LOW"
    risk_color   = {"CRITICAL":"#ff0044","HIGH":"#ff8800","MEDIUM":"#ffcc00","LOW":"#00ff88"}.get(overall_risk,"#808080")

    prompt = f"""You are an elite penetration tester and bug bounty hunter with 15 years experience writing professional security assessment reports for fortune 500 companies and top bug bounty programs.

Generate a COMPLETE, DETAILED, PROFESSIONAL penetration test report for: {domain}

Generate a complete, detailed penetration test report for: {domain}

SCAN DATA:
{full_context}

Write the report in this EXACT format (use markdown):

# Security Assessment Report
## {domain} — Penetration Test
**OVERALL RISK: {overall_risk}**

---

## Executive Summary
[2-3 paragraphs. Describe what was found, the most significant issues, what technology runs on the target, and the business impact. Be specific about URLs and findings. If no vulns found, describe the attack surface and what was analyzed.]

**Risk Rating:** {overall_risk}
**Confirmed Findings:** {len(crits)} Critical · {len(highs)} High · {len(meds)} Medium · {len(lows)} Low

---

## Findings Summary

| ID | Title | Severity | CVSS | Status | Affected URL |
|----|-------|----------|--------|---------|
[Create numbered rows F-01, F-02, etc for each finding. If no findings, still analyze endpoints for issues.]

---

## Detailed Findings

[For each finding, use this format:]

### [SEVERITY] F-XX — [Title]
**CVSS:** [Score] | **CWE:** [CWE-ID] | **Confidence:** [XX]%

**WHAT WAS FOUND**
[Detailed explanation]

**EVIDENCE**
```
[Actual curl command or request/response]
```

**PROOF OF CONCEPT**
```
[Working PoC steps]
```

**IMPACT**
[Specific business impact]

**REMEDIATION**
[Specific fix with code example if applicable]

---

## Remediation Roadmap

| Priority | Action | Affected Systems | Effort |
|----------|--------|-----------------|--------|
| Immediate (24h) | [action] | [system] | Low/Medium/High |
| Short term (1 week) | [action] | [system] | Low/Medium/High |
| Medium term (1 month) | [action] | [system] | Low/Medium/High |

---
*Generated by TheMasterRecon AI ⭐ | theMasterRecon | Confidential*
*Confidential. For authorized use only.*

CRITICAL REQUIREMENTS:
1. Be SPECIFIC — use exact URLs, parameters, payloads from the scan data
2. Write like a senior penetration tester — technical, precise, actionable
3. Every finding must have: evidence (curl command), working PoC, business impact, specific remediation
4. If no vulnerabilities found: STILL analyze attack surface — expose API endpoints, tech stack risks, SOAP services, admin panels, version disclosure
5. The Remediation Roadmap MUST have realistic timelines (24h for critical, 1 week for high, 1 month for medium)
6. Findings table MUST have Status column (Confirmed/Probable/Informational)
7. Executive Summary MUST state the Overall Risk and top 3 most critical findings
8. NEVER invent findings not supported by scan data
9. Code blocks must use proper markdown fencing (```bash, ```json, ```xml)
10. Every PoC must be a working, copy-paste ready command"""

    SYSTEM_PROMPT = (
        "You are TheMasterRecon AI — an elite penetration tester with 20+ years experience "
        "at top security firms (NCC Group, Synack, Cobalt), specialized in web application "
        "security, bug bounty hunting on HackerOne and Bugcrowd, and red team operations. "
        "\n\nREPORT REQUIREMENTS:\n"
        "- Write like a CISO is reading this: executive-level summary + technical depth\n"
        "- Every finding MUST have: CVSS score, CWE ID, exact vulnerable URL, "
        "  working curl PoC command, business impact, specific fix with code example\n"
        "- Severity ratings based on CVSS 3.1: Critical(9-10), High(7-8.9), Med(4-6.9), Low(0.1-3.9)\n"
        "- NEVER fabricate findings. If data shows no vulns, analyze attack surface thoroughly\n"
        "- Use markdown: headers, bold, code blocks (```bash, ```python, ```http)\n"
        "- Be specific: use EXACT URLs, parameters, payloads from the scan data\n"
        "- Remediation must be actionable: specific code fixes, not generic advice\n"
        "- Executive Summary: 2-3 paragraphs, non-technical language, business risk focus\n"
        "- Include a risk-prioritized remediation roadmap with timelines\n"
    )
    try:
        resp = _claude(SYSTEM_PROMPT, prompt, max_tokens=8000, stream_q=q)
        report_md = resp.strip()
        
        _emit("report_ready", report=report_md, 
              risk=overall_risk, risk_color=risk_color,
              stats={
                  "critical": len(crits),
                  "high": len(highs),
                  "medium": len(meds),
                  "low": len(lows),
                  "total": len(findings),
                  "char_count": char_count,
              })
        _log(f"Report complete — {len(report_md.split())} words", "done")
        
    except Exception as e:
        log.error(f"[ai_analyst] pentest report: {e}")
        _emit("error", msg=str(e))


def analyze_endpoints_for_issues(domain: str, endpoints: List[str], 
                                   tech: List[str], enrich: List[Dict]) -> List[Dict]:
    """
    Active AI analysis of endpoints when scanner finds nothing.
    Looks for:
    - Unauthenticated API endpoints
    - Verbose error messages
    - SOAP/ASMX/WSDL services
    - Admin panels
    - Debug endpoints
    - Version disclosure
    """
    issues = []
    
    # Categorize endpoints
    api_endpoints    = [e for e in endpoints if any(p in e.lower() for p in ['/api/','/v1/','/v2/','/rest/','/graphql','/json'])]
    admin_endpoints  = [e for e in endpoints if any(p in e.lower() for p in ['/admin','/dashboard','/manage','/portal','/control'])]
    service_eps      = [e for e in endpoints if any(p in e.lower() for p in ['.asmx','.wsdl','.svc','.ashx','.aspx','/soap','/rpc'])]
    debug_eps        = [e for e in endpoints if any(p in e.lower() for p in ['/debug','/test','/dev','/staging','/phpinfo','/trace'])]
    auth_eps         = [e for e in endpoints if any(p in e.lower() for p in ['/login','/auth','/signin','/oauth','/token','/register'])]
    
    if service_eps:
        issues.append({
            "type": "service_exposure",
            "severity": "high",
            "title": f"Web service endpoints discovered: {service_eps[:5]}",
            "count": len(service_eps),
            "endpoints": service_eps[:10]
        })
    
    if admin_endpoints:
        issues.append({
            "type": "admin_exposure", 
            "severity": "medium",
            "title": f"Admin/management interfaces discovered: {admin_endpoints[:3]}",
            "count": len(admin_endpoints),
            "endpoints": admin_endpoints[:10]
        })
    
    if debug_eps:
        issues.append({
            "type": "debug_exposure",
            "severity": "medium", 
            "title": f"Debug/test endpoints found: {debug_eps[:3]}",
            "count": len(debug_eps),
            "endpoints": debug_eps[:5]
        })
    
    # Tech-based risk analysis
    risky_tech = {
        "Spring Boot": "Actuator endpoints may expose /actuator/env, /actuator/heapdump",
        "Apache Struts": "CVE-2017-5638 (S2-045) and related RCE CVEs",
        "PHP": "PHP info disclosure, file upload vulnerabilities",
        "ASP.NET": "ViewState deserializtion, trace.axd exposure",
        "Elastic": "Unauthenticated Elasticsearch cluster access",
        "Jenkins": "Unauthenticated CLI access, Script Console RCE",
        "WordPress": "wp-admin brute force, plugin vulnerabilities",
    }
    
    for tech_name, risk in risky_tech.items():
        if any(tech_name.lower() in t.lower() for t in tech):
            issues.append({
                "type": "tech_risk",
                "severity": "medium",
                "title": f"{tech_name} detected — {risk}",
                "tech": tech_name
            })
    
    return issues


def ai_filter_false_positives(findings: list, tech: list, q) -> None:
    """
    Use Claude AI to identify likely false positives.
    Streams analysis events back via queue q.
    """
    import json

    def _emit(msg_type, **kwargs):
        q.put({"type": msg_type, **kwargs})

    if not API_KEY:
        _emit("ai_chunk", text="⚠ ANTHROPIC_API_KEY not set")
        return

    _emit("log", msg=f"AI analyzing {len(findings)} findings for false positives...")

    # Batch findings for analysis
    batch_size = 10
    fp_ids     = []
    total_analyzed = 0

    for i in range(0, len(findings), batch_size):
        batch = findings[i:i+batch_size]
        batch_desc = []
        for j, f in enumerate(batch):
            batch_desc.append(
                f"[{j}] {f.get('severity','?').upper()} {f.get('bug','?').upper()} "
                f"@ {f.get('url','?')[:80]}\n"
                f"    Confidence: {f.get('confidence',50)}%\n"
                f"    Preview: {str(f.get('preview',f.get('body_preview','')))[:200]}"
            )

        prompt = f"""You are a security expert reviewing scanner findings for false positives.
Tech stack: {", ".join(tech[:10]) if tech else "Unknown"}

Analyze these {len(batch)} findings and identify which are likely false positives.
A false positive is a finding that was flagged by the scanner but is NOT actually vulnerable.

FINDINGS:
{chr(10).join(batch_desc)}

Respond with ONLY a JSON object:
{{
  "false_positives": [0, 2],  // indices of likely FP findings
  "analysis": {{
    "0": "reason this is a FP",
    "2": "reason this is a FP"
  }},
  "confidence": "85%"
}}

If none are false positives, return {{"false_positives": [], "analysis": {{}}, "confidence": "90%"}}"""

        messages = [{"role": "user", "content": prompt}]
        try:
            resp = _claude(SYSTEM_PROMPT if "SYSTEM_PROMPT" in dir() else
                          "You are an expert security analyst.", prompt,
                          max_tokens=800)

            import re
            m = re.search(r'\{.*\}', resp, re.DOTALL)
            if m:
                data = json.loads(m.group())
                fp_indices = data.get("false_positives", [])
                analysis   = data.get("analysis", {})

                for idx in fp_indices:
                    if 0 <= idx < len(batch):
                        f = batch[idx]
                        fid = f.get("id") or f.get("_id","")
                        reason = analysis.get(str(idx),"AI identified as likely false positive")
                        fp_ids.append({"id": fid, "reason": reason, "finding": f})
                        _emit("ai_chunk", text=f"\n🔍 **Likely FP**: {f.get('bug','').upper()} @ {f.get('url','')[:60]}\n   Reason: {reason}\n")

        except Exception as e:
            log.warning(f"[ai_fp] batch {i}: {e}")

        total_analyzed += len(batch)
        _emit("log", msg=f"Analyzed {total_analyzed}/{len(findings)} findings...")

    _emit("fp_analysis_done", false_positives=fp_ids,
          total=len(findings), fp_count=len(fp_ids))
    _emit("ai_chunk", text=f"\n\n**Summary:** Analyzed {len(findings)} findings. "
          f"Found **{len(fp_ids)} likely false positives** out of {len(findings)} total.\n")


def quick_triage(finding: dict) -> dict:
    """Fast AI triage for a single finding. Returns priority + tip."""
    import json as _json
    bug = finding.get("bug","").upper()
    url = finding.get("url","")
    sev = finding.get("severity","medium")
    poc = finding.get("poc","")[:200]
    conf= finding.get("confidence", 50)

    prompt = f"""Rate this bug bounty finding quickly. Respond with ONLY valid JSON, no explanation:
Bug: {bug} | URL: {url} | Severity: {sev} | Confidence: {conf}% | PoC: {poc}
{{"priority":"P1","exploitability":9,"impact":8,"score":8.5,"tip":"one sentence","quick_win":true}}"""

    try:
        resp = _claude(prompt, max_tokens=120)
        import re as _re
        m = _re.search(r'\{{[^}}]+\}}', resp, _re.DOTALL)
        if m:
            return _json.loads(m.group())
    except Exception:
        pass
    sev_map = {"critical":("P1",9.0),"high":("P2",7.5),"medium":("P3",5.0),"low":("P4",3.0)}
    p, s = sev_map.get(sev,("P3",5.0))
    return {"priority":p,"score":s,"exploitability":5,"impact":5,
            "tip":"Manual review recommended","quick_win":sev in ("critical","high")}


def score_finding_fast(finding: dict) -> dict:
    """Instant exploitability/impact/priority score. No streaming."""
    sev  = finding.get("severity","medium").lower()
    bug  = finding.get("bug","").lower()
    conf = int(finding.get("confidence",50))
    poc  = bool(finding.get("poc",""))

    # Score based on heuristics (fast, no API call needed)
    exploitability_map = {
        "rce":10,"sqli":9,"ssrf":9,"ssti":9,"deserialization":9,
        "xss":7,"lfi":7,"idor":7,"jwt":8,"cors":6,"misconfig":5,
        "expose":6,"takeover":8,"redirect":4,"crlf":5,
    }
    exploitability = exploitability_map.get(bug, 5)
    if not poc: exploitability = max(1, exploitability - 2)
    if conf < 50: exploitability = max(1, exploitability - 2)

    sev_priority = {"critical":"P1","high":"P2","medium":"P3","low":"P4","info":"P5"}
    priority = sev_priority.get(sev,"P3")

    return {
        "priority":       priority,
        "exploitability": exploitability,
        "impact":         exploitability,
        "score":          round((exploitability * 1.0 + int(conf)/20) / 1.5, 1),
        "quick_win":      sev in ("critical","high") and poc,
        "tip":            f"{bug.upper()} finding — {'has PoC' if poc else 'needs manual verification'}",
    }


def triage_findings(findings: List[Dict], domain: str,
                    tech: List[str] = None, stream_q=None) -> str:
    """
    AI-powered finding triage — ranks findings by real exploitability,
    identifies false positives, and maps attack chains.
    Uses XBOW-style evidence reasoning.
    """
    if not findings:
        return ""

    # Build compact finding list for AI context
    finding_ctx = []
    for f in findings[:30]:
        bug  = f.get("bug", f.get("bug_type","?"))
        sev  = f.get("severity","?")
        url  = f.get("url","?")[:60]
        conf = f.get("confidence", 50)
        poc  = str(f.get("poc",""))[:80]
        oob  = f.get("oob_confirmed", False)
        xbow = f.get("_xbow_grade", "?")
        finding_ctx.append(
            f"[{sev.upper():8}] [{xbow}] {bug:12} conf={conf}% oob={oob} url={url} poc={poc[:40]}"
        )

    system = """You are an elite bug bounty triage AI operating with XBOW evidence standards.

For each finding, apply this reasoning:
1. Is the evidence sufficient? (OOB=proven, curl+reflection=likely, pattern-only=unverified)
2. Is it exploitable without further conditions? (auth required? rate limited? self-only?)
3. What is the REAL impact? (not theoretical — what can an attacker ACTUALLY do?)
4. Bounty range based on similar H1 disclosures?
5. What one action maximizes bounty today?

NEVER say "this could potentially" — be definitive. If uncertain, say what's missing."""

    prompt = f"""Triage these {len(findings)} findings from {domain}:
Tech: {', '.join((tech or [])[:6])}

FINDINGS:
{chr(10).join(finding_ctx)}

For the TOP 5 highest-value findings:
1. Real vs false positive verdict (one sentence with reasoning)
2. Exact next action to confirm/escalate (command or step)
3. Bounty estimate if confirmed ($X-$Y)
4. Chain opportunity if any

Then: overall assessment — what is the single highest-value target here?"""

    return _claude(system, prompt, max_tokens=1200, stream_q=stream_q)


def smart_payload_suggestion(bug: str, endpoint: str, tech: List[str],
                              waf: str = "", param: str = "",
                              rag_context: str = "") -> str:
    """
    AI-generated payload suggestions based on tech stack + H1 intelligence.
    More targeted than generic payload lists.
    """
    system = """You are a payload specialist combining XBOW-style precision with H1 intelligence.

Rules:
- Suggest payloads specific to the detected tech stack (Django != Rails != PHP)
- Order by likelihood of success on this specific target
- Include WAF bypass variants if WAF is detected
- Reference actual H1 reports when relevant ("This technique confirmed on Shopify H1 #...")
- Max 5 payloads, each with expected behavior if vulnerable"""

    h1_ctx = ("\nH1 Intelligence:\n" + rag_context) if rag_context else ""

    prompt = f"""Target: {endpoint[:80]}
Bug type: {bug.upper()}
Tech stack: {', '.join(tech[:6]) if tech else 'unknown'}
WAF: {waf or 'none'}
Parameter: {param or 'unknown'}{h1_ctx}

Suggest the 5 most likely to work payloads for this specific target.
Format: [PAYLOAD]: [expected response if vulnerable]"""

    return _claude(system, prompt, max_tokens=600)

