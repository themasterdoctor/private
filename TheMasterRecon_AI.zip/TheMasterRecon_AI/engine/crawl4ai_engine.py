"""
BugScan ELITE — Crawl4AI Integration
AI-powered web crawler that handles what our other crawlers miss:
  - SPAs (React, Vue, Angular, Next.js)
  - Lazy-loaded content
  - Content behind clicks, scrolls, dynamic rendering
  - Bot-detection-protected pages (stealth mode)
  - Authenticated sessions (inject saved cookies)
  - Shadow DOM, iframes, overlays
  - Network request capture (XHR/fetch endpoints)
  - Deep BFS crawl with link scoring

Install: pip install crawl4ai
"""
import asyncio, logging, os, re, urllib.parse
from typing import List, Dict, Set, Optional, Callable

log = logging.getLogger("elite.crawl4ai")

def _is_available() -> bool:
    try:
        import crawl4ai
        return True
    except ImportError:
        return False


async def _crawl_target(url: str, results: dict, add_endpoint, emit) -> None:
    """Crawl a single URL with crawl4ai."""
    try:
        from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig, CacheMode
    except ImportError:
        return

    target_domain = url.split('/')[2] if '/' in url else url

    browser_cfg = BrowserConfig(headless=True, verbose=False)
    crawl_cfg   = CrawlerRunConfig(
        cache_mode=CacheMode.BYPASS,
        wait_until="domcontentloaded",
        page_timeout=15000,
    )

    try:
        async with AsyncWebCrawler(config=browser_cfg) as crawler:
            # crawl4ai v0.3+ returns CrawlResult directly, not async iterable
            result = await crawler.arun(url, config=crawl_cfg)

            # Handle both API versions
            if hasattr(result, '__aiter__'):
                pages = []
                async for p in result:
                    pages.append(p)
            elif isinstance(result, list):
                pages = result
            else:
                pages = [result] if result else []

            for page in pages:
                if not page or not page.success:
                    err = getattr(page, 'error_message', 'unknown') if page else 'null result'
                    results["errors"].append(err)
                    continue

                results["pages_crawled"] += 1

                # Extract links
                links_data = getattr(page, 'links', {}) or {}
                for link_type in ["internal", "external"]:
                    for link in links_data.get(link_type, []):
                        href = link.get("href", "") if isinstance(link, dict) else str(link)
                        if href and href.startswith("http"):
                            if link_type == "internal" or target_domain in href:
                                if add_endpoint(href):
                                    results["endpoints"] += 1
                                    emit({"type": "crawled", "url": href})

                # Extract from markdown/text
                text = getattr(page, 'markdown', '') or getattr(page, 'extracted_content', '') or ''
                if text:
                    for href in re.findall(r"https?://[^\x22\x27<> )]+", text):
                        if target_domain in href and add_endpoint(href):
                            results["endpoints"] += 1

    except Exception as e:
        results["errors"].append(f"{url}: {e}")
        log.debug(f"[crawl4ai] {url}: {e}")


def run_crawl4ai(targets: List[str],
                  domain: str = "",
                  cookies: str = "",
                  token: str = "",
                  depth: int = 2,
                  max_pages: int = 30,
                  add_endpoint_fn: Callable = None,
                  emit_fn: Callable = None) -> Dict:
    """
    Synchronous wrapper — runs crawl4ai against all live targets.
    Results feed into the endpoint store via add_endpoint_fn.
    """
    if not _is_available():
        log.info("[crawl4ai] not installed — pip install crawl4ai")
        return {"total_endpoints": 0, "total_pages": 0}

    all_endpoints:    Set[str] = set()
    all_network:      Set[str] = set()
    all_links:        Set[str] = set()
    total_pages:      int = 0

    async def _run_all():
        nonlocal total_pages
        # Run targets sequentially to avoid memory overload
        for target in targets[:10]:   # cap at 10 targets
            try:
                if emit_fn:
                    emit_fn({"type": "step", "name": "crawl", "state": "run",
                              "meta": f"crawl4ai: {target}"})

                # _crawl_target signature: (url, results, add_endpoint, emit)
                # It mutates `results` in-place and returns None.
                res: dict = {
                    "pages_crawled": 0,
                    "endpoints":     0,   # count, not list
                    "errors":        [],
                }

                def _add_ep(url: str) -> bool:
                    """Wrapper: feed into outer sets and call add_endpoint_fn."""
                    if url in all_endpoints:
                        return False
                    all_endpoints.add(url)
                    if add_endpoint_fn:
                        try: add_endpoint_fn(url)
                        except Exception: pass
                    return True

                def _emit(ev: dict) -> None:
                    if emit_fn:
                        try: emit_fn(ev)
                        except Exception: pass

                await _crawl_target(target, res, _add_ep, _emit)

                total_pages += res.get("pages_crawled", 0)
                ep_count = res.get("endpoints", 0)
                log.info(f"[crawl4ai] {target}: done "
                         f"({res.get('pages_crawled', 0)} pages, "
                         f"{ep_count} endpoints)")
                if res.get("errors"):
                    for err in res["errors"][:3]:
                        log.debug(f"[crawl4ai] error: {err}")
            except Exception as e:
                log.warning(f"[crawl4ai] {target}: {e}")

    # Run async event loop
    try:
        loop = asyncio.new_event_loop()
        loop.run_until_complete(_run_all())
        loop.close()
    except Exception as e:
        log.warning(f"[crawl4ai] event loop: {e}")

    summary = {
        "total_endpoints":       len(all_endpoints),
        "total_network_calls":   len(all_network),
        "total_links":           len(all_links),
        "total_pages":           total_pages,
        "endpoints":             list(all_endpoints)[:500],
        "network_requests":      list(all_network)[:200],
    }
    log.info(f"[crawl4ai] complete: {summary['total_endpoints']} endpoints, "
             f"{summary['total_pages']} pages crawled")
    return summary
