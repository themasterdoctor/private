"""
BugScan ELITE — Runtime Watchdog & Hardening
Tasks 5-6: subprocess/future audit, timeout enforcement, bounded queues,
            watchdog logs, non-blocking notifications, scan recovery.

HARD RULES:
  - No auto-exploitation ever
  - Stability over features
  - All operations bounded by timeout
  - Failed stages don't freeze UI
"""

import logging, os, queue, threading, time, traceback
from typing import Callable, Dict, List, Optional

log = logging.getLogger("elite.watchdog")

# ── TASK 5 — Global runtime stats ─────────────────────────────────────────────

_RUNTIME_STATS: Dict = {
    "subprocess_timeouts":    0,
    "future_cancellations":   0,
    "request_timeouts":       0,
    "validation_timeouts":    0,
    "notify_timeouts":        0,
    "stage_recoveries":       0,
    "watchdog_checks":        0,
    "queue_overflows":        0,
    "started_at":             time.time(),
}
_RUNTIME_LOCK = threading.Lock()

def bump(key: str, n: int = 1):
    with _RUNTIME_LOCK:
        _RUNTIME_STATS[key] = _RUNTIME_STATS.get(key, 0) + n


# ── Active subprocess registry ────────────────────────────────────────────────

_ACTIVE_PROCS: Dict[int, Dict] = {}
_PROC_LOCK = threading.Lock()


def register_proc(pid: int, name: str, timeout: int = 120):
    with _PROC_LOCK:
        _ACTIVE_PROCS[pid] = {
            "name":       name,
            "started_at": time.time(),
            "timeout":    timeout,
        }


def deregister_proc(pid: int):
    with _PROC_LOCK:
        _ACTIVE_PROCS.pop(pid, None)


def active_proc_count() -> int:
    with _PROC_LOCK:
        return len(_ACTIVE_PROCS)


def proc_snapshot() -> List[Dict]:
    with _PROC_LOCK:
        now = time.time()
        return [
            {
                "pid":           pid,
                "name":          info["name"],
                "age_seconds":   round(now - info["started_at"], 1),
                "timeout":       info["timeout"],
                "overdue":       (now - info["started_at"]) > info["timeout"],
            }
            for pid, info in _ACTIVE_PROCS.items()
        ]


# ── TASK 5 — Bounded async notification queue ─────────────────────────────────
#
# Discord/Telegram sends are always async via this queue.
# The worker thread picks items off the queue and sends with a hard timeout.
# Queue is bounded (MAX_NOTIFY_QUEUE) to prevent memory growth on blocked senders.

MAX_NOTIFY_QUEUE = 200
NOTIFY_SEND_TIMEOUT = 12    # seconds per send attempt
NOTIFY_WORKER_SLEEP = 0.4   # seconds between queue polls

_notify_queue: queue.Queue = queue.Queue(maxsize=MAX_NOTIFY_QUEUE)
_notify_worker_alive = threading.Event()
_notify_worker_alive.set()


def enqueue_notification(send_fn: Callable, *args, **kwargs) -> bool:
    """
    TASK 5 — Non-blocking notification enqueue.
    Returns True if queued, False if queue is full (overflow logged).
    NEVER blocks the calling thread.
    """
    try:
        _notify_queue.put_nowait({"fn": send_fn, "args": args, "kwargs": kwargs})
        return True
    except queue.Full:
        bump("queue_overflows")
        log.warning("[watchdog] notify queue full — notification dropped")
        return False


def _notification_worker():
    """Background thread: dequeue and send notifications with timeout."""
    while _notify_worker_alive.is_set():
        try:
            item = _notify_queue.get(timeout=NOTIFY_WORKER_SLEEP)
        except queue.Empty:
            continue

        t0 = time.time()
        try:
            # Execute send in a daemon thread so we can enforce a hard timeout
            result_holder = {}
            def _do_send():
                try:
                    item["fn"](*item["args"], **item["kwargs"])
                    result_holder["ok"] = True
                except Exception as e:
                    result_holder["err"] = str(e)

            t = threading.Thread(target=_do_send, daemon=True)
            t.start()
            t.join(timeout=NOTIFY_SEND_TIMEOUT)

            if t.is_alive():
                bump("notify_timeouts")
                log.warning(f"[notify] async send timeout after {NOTIFY_SEND_TIMEOUT}s — moving on")
            elif result_holder.get("err"):
                log.debug(f"[notify] send error: {result_holder['err']}")
            else:
                elapsed = round(time.time()-t0, 2)
                log.info(f"[notify] async send complete elapsed={elapsed}s")

        except Exception as e:
            log.debug(f"[watchdog] notification worker error: {e}")
        finally:
            _notify_queue.task_done()


# Start the notification worker
_notify_thread = threading.Thread(target=_notification_worker,
                                   name="notify-worker", daemon=True)
_notify_thread.start()


def notify_queue_depth() -> int:
    return _notify_queue.qsize()


# ── TASK 6 — Stage recovery tracking ─────────────────────────────────────────
#
# Any pipeline stage that crashes records its failure here.
# The pipeline always continues to the next stage rather than freezing.

_STAGE_STATE: Dict[str, Dict] = {}    # domain → {stage_name → status}
_STAGE_LOCK  = threading.Lock()

STAGE_RUNNING  = "running"
STAGE_DONE     = "done"
STAGE_FAILED   = "failed"
STAGE_TIMEOUT  = "timeout"
STAGE_SKIPPED  = "skipped"


def stage_start(domain: str, stage: str):
    with _STAGE_LOCK:
        _STAGE_STATE.setdefault(domain, {})[stage] = {
            "status":     STAGE_RUNNING,
            "started_at": time.time(),
            "error":      None,
            "recovered":  False,
        }
    log.debug(f"[watchdog] stage_start domain={domain} stage={stage}")


def stage_done(domain: str, stage: str):
    with _STAGE_LOCK:
        s = _STAGE_STATE.setdefault(domain, {})
        if stage in s:
            s[stage]["status"] = STAGE_DONE
            s[stage]["ended_at"] = time.time()
    log.debug(f"[watchdog] stage_done domain={domain} stage={stage}")


def stage_fail(domain: str, stage: str, error: str = "",
               notify_fn: Optional[Callable] = None):
    """
    TASK 6 — Mark a stage as failed and continue pipeline safely.
    NEVER re-raises. NEVER freezes. Notifies via safe notification queue.
    """
    with _STAGE_LOCK:
        s = _STAGE_STATE.setdefault(domain, {})
        s[stage] = {
            "status":     STAGE_FAILED,
            "started_at": s.get(stage, {}).get("started_at", time.time()),
            "ended_at":   time.time(),
            "error":      error[:200] if error else "unknown error",
            "recovered":  True,
        }
    bump("stage_recoveries")
    log.warning(f"[watchdog] recovered stuck stage={stage} domain={domain} error={error[:80]}")

    # Async notification — non-blocking
    if notify_fn:
        try:
            enqueue_notification(notify_fn, domain=domain, stage=stage, error=error)
        except Exception:
            pass   # notification failure must NEVER affect scan


def stage_timeout_check(domain: str, max_age_per_stage: int = 900) -> List[str]:
    """
    Watchdog: find stages that have been running longer than max_age_per_stage seconds.
    Returns list of stuck stage names. Caller should call stage_fail() on them.
    """
    with _STAGE_LOCK:
        stages = _STAGE_STATE.get(domain, {})

    now   = time.time()
    stuck = []
    for name, info in stages.items():
        if info.get("status") == STAGE_RUNNING:
            age = now - info.get("started_at", now)
            if age > max_age_per_stage:
                stuck.append(name)
                log.warning(f"[watchdog] stuck stage detected: stage={name} "
                            f"domain={domain} age={int(age)}s")
    return stuck


def domain_stage_snapshot(domain: str) -> Dict:
    """Return current stage state for a domain."""
    with _STAGE_LOCK:
        raw = _STAGE_STATE.get(domain, {})
    now = time.time()
    result = {}
    for name, info in raw.items():
        age = round(now - info.get("started_at", now), 1)
        result[name] = {
            "status":      info.get("status", "unknown"),
            "age_seconds": age,
            "error":       info.get("error"),
            "recovered":   info.get("recovered", False),
        }
    return result


def all_domains_snapshot() -> Dict:
    """Return stage state for all tracked domains."""
    with _STAGE_LOCK:
        domains = list(_STAGE_STATE.keys())
    return {d: domain_stage_snapshot(d) for d in domains}


def clear_domain_stages(domain: str):
    with _STAGE_LOCK:
        _STAGE_STATE.pop(domain, None)


# ── TASK 5 — Subprocess wrapper with registration + timeout ───────────────────

def run_subprocess_safe(
    cmd: List[str],
    timeout: int = 120,
    name: str = "",
    capture_output: bool = True,
    env: Optional[Dict] = None,
) -> Dict:
    """
    TASK 5 — Safe subprocess runner with:
    - Hard timeout enforcement
    - Process registration/deregistration
    - Watchdog log on timeout
    - Never raises — returns error dict on failure

    Returns: {"ok": bool, "stdout": str, "stderr": str, "returncode": int, "timedout": bool}
    """
    import subprocess
    label = name or (cmd[0] if cmd else "subprocess")
    pid   = None
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE if capture_output else None,
            stderr=subprocess.PIPE if capture_output else None,
            env=env,
        )
        pid = proc.pid
        register_proc(pid, label, timeout)

        try:
            stdout_b, stderr_b = proc.communicate(timeout=timeout)
            rc = proc.returncode
            return {
                "ok":         rc == 0,
                "stdout":     (stdout_b or b"").decode("utf-8", errors="replace"),
                "stderr":     (stderr_b or b"").decode("utf-8", errors="replace"),
                "returncode": rc,
                "timedout":   False,
            }
        except subprocess.TimeoutExpired:
            bump("subprocess_timeouts")
            log.warning(f"[watchdog] subprocess timeout name={label} timeout={timeout}s pid={pid}")
            try:
                proc.kill()
                proc.communicate(timeout=5)
            except Exception:
                pass
            return {
                "ok": False, "stdout": "", "stderr": f"timeout after {timeout}s",
                "returncode": -1, "timedout": True,
            }
    except Exception as e:
        return {
            "ok": False, "stdout": "", "stderr": str(e),
            "returncode": -1, "timedout": False,
        }
    finally:
        if pid:
            deregister_proc(pid)


# ── TASK 5 — Future executor with timeout + cancellation ──────────────────────

def run_futures_safe(
    tasks: List[Dict],          # [{"fn": callable, "args": tuple, "kwargs": dict, "name": str}]
    max_workers: int = 10,
    timeout: int = 60,
    label: str = "futures",
) -> List[Dict]:
    """
    TASK 5 — Run concurrent tasks with hard timeout and cancellation.

    Returns list of {"name": str, "result": any, "error": str|None, "cancelled": bool}
    Guarantees all futures are cancelled/resolved within timeout seconds.
    """
    import concurrent.futures as _cf

    results = []
    with _cf.ThreadPoolExecutor(max_workers=max_workers) as exe:
        fut_map = {
            exe.submit(t["fn"], *t.get("args",()), **t.get("kwargs",{})): t
            for t in tasks
        }
        done, not_done = _cf.wait(fut_map, timeout=timeout)

        # Cancel anything still running
        for fut in not_done:
            fut.cancel()
            bump("future_cancellations")
            t = fut_map[fut]
            log.warning(f"[watchdog] future cancelled label={label} name={t.get('name','?')}")
            results.append({
                "name":      t.get("name", ""),
                "result":    None,
                "error":     f"cancelled after {timeout}s",
                "cancelled": True,
            })

        for fut in done:
            t = fut_map[fut]
            try:
                results.append({
                    "name":      t.get("name",""),
                    "result":    fut.result(),
                    "error":     None,
                    "cancelled": False,
                })
            except Exception as e:
                results.append({
                    "name":      t.get("name",""),
                    "result":    None,
                    "error":     str(e)[:200],
                    "cancelled": False,
                })
    return results


# ── Scan timing tracker ────────────────────────────────────────────────────────

_SCAN_TIMINGS: List[float] = []   # recent scan durations (last 20)
_TIMING_LOCK = threading.Lock()


def record_scan_duration(seconds: float):
    with _TIMING_LOCK:
        _SCAN_TIMINGS.append(seconds)
        if len(_SCAN_TIMINGS) > 20:
            _SCAN_TIMINGS.pop(0)


def avg_scan_duration() -> float:
    with _TIMING_LOCK:
        return round(sum(_SCAN_TIMINGS) / len(_SCAN_TIMINGS), 1) if _SCAN_TIMINGS else 0.0


# ── Global runtime health snapshot ────────────────────────────────────────────

def runtime_health_snapshot(active_scans: Dict, validation_queue_depth: int = 0) -> Dict:
    """
    TASK 7 — Full runtime health for /system/live_health.
    Called by the Flask route.
    """
    from engine.signal_quality import cache_stats as val_cache_stats

    now = time.time()
    uptime = round(now - _RUNTIME_STATS["started_at"], 1)

    # Stuck stage detection across all domains
    stuck_stages = []
    with _STAGE_LOCK:
        all_domains = list(_STAGE_STATE.keys())
    for domain in all_domains:
        stuck = stage_timeout_check(domain)
        for s in stuck:
            stuck_stages.append({"domain": domain, "stage": s})

    return {
        # TASK 7 fields
        "running_scans":         len(active_scans),
        "active_domains":        list(active_scans.keys()),
        "stuck_stages":          stuck_stages,
        "active_subprocesses":   active_proc_count(),
        "subprocess_list":       proc_snapshot()[:10],
        "validation_queue_depth": validation_queue_depth,
        "notifier_queue_depth":  notify_queue_depth(),
        "avg_scan_duration_s":   avg_scan_duration(),
        # Timeout/error counters
        "timeout_counts": {
            "subprocess":   _RUNTIME_STATS.get("subprocess_timeouts", 0),
            "futures":      _RUNTIME_STATS.get("future_cancellations", 0),
            "requests":     _RUNTIME_STATS.get("request_timeouts", 0),
            "validation":   _RUNTIME_STATS.get("validation_timeouts", 0),
            "notify":       _RUNTIME_STATS.get("notify_timeouts", 0),
        },
        "stage_recoveries":      _RUNTIME_STATS.get("stage_recoveries", 0),
        "notify_queue_overflows": _RUNTIME_STATS.get("queue_overflows", 0),
        "watchdog_checks":       _RUNTIME_STATS.get("watchdog_checks", 0),
        # Signal quality cache
        "validation_cache":      val_cache_stats(),
        # System uptime
        "uptime_seconds":        uptime,
        "uptime_human":          _fmt_uptime(uptime),
        "timestamp":             now,
    }


def _fmt_uptime(seconds: float) -> str:
    s = int(seconds)
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    return f"{h}h {m}m {sec}s"


# ── Background watchdog thread ────────────────────────────────────────────────

_watchdog_running = threading.Event()
_watchdog_running.set()


def _watchdog_loop(check_interval: int = 60, stage_max_age: int = 900):
    """
    Periodically checks for stuck stages and timed-out subprocesses.
    Marks them as failed and continues — never panics, never freezes.
    """
    while _watchdog_running.is_set():
        try:
            bump("watchdog_checks")
            with _STAGE_LOCK:
                all_domains = list(_STAGE_STATE.keys())

            for domain in all_domains:
                stuck = stage_timeout_check(domain, max_age_per_stage=stage_max_age)
                for s in stuck:
                    stage_fail(domain, s, f"watchdog timeout after {stage_max_age}s")

            # Check subprocess timeouts
            with _PROC_LOCK:
                procs_snap = list(_ACTIVE_PROCS.items())
            now = time.time()
            for pid, info in procs_snap:
                age = now - info.get("started_at", now)
                if age > info.get("timeout", 120) + 30:   # 30s grace period
                    log.warning(f"[watchdog] overdue subprocess pid={pid} "
                                f"name={info['name']} age={int(age)}s")

        except Exception as e:
            log.debug(f"[watchdog] loop error: {e}")

        time.sleep(check_interval)


_watchdog_thread = threading.Thread(
    target=_watchdog_loop,
    name="runtime-watchdog",
    daemon=True,
)
_watchdog_thread.start()
