"""
TheMasterRecon AI — Plugin / BApp Store System
The equivalent of Burp's BApp Store but self-hosted and open.

Three plugin types:
  1. Nuclei YAML templates  — standard Nuclei format, 9,000+ from community
  2. TMR YAML checks        — our own format for custom logic
  3. Python modules         — full scanner.py-style functions (advanced)

Plugin sources:
  - Built-in library    (custom-templates/)
  - Nuclei community    (nuclei-templates/ — auto-synced daily)
  - User uploads        (via /plugins/install endpoint)
  - Remote marketplace  (future: tmr-plugins GitHub repo)
"""
import os, re, json, logging, hashlib, threading, shutil, ssl, time
import urllib.request
from pathlib import Path
from typing import List, Dict, Optional
from datetime import datetime

log = logging.getLogger("elite.plugins")

APP_ROOT      = Path(__file__).parent.parent
CUSTOM_TPL    = APP_ROOT / "custom-templates"
NUCLEI_TPL    = APP_ROOT / "nuclei-templates"
PLUGIN_META   = APP_ROOT / "data" / "plugins_meta.json"
PLUGIN_LOCK   = threading.Lock()

# ── Built-in plugin library (always available) ─────────────────────────────

BUILTIN_PLUGINS = [
    {
        "id":          "tmr-cors-bypass",
        "name":        "CORS Bypass (Origin Variations)",
        "description": "Tests 10+ origin bypass techniques for CORS misconfiguration",
        "author":      "TMR Team",
        "severity":    "high",
        "tags":        "cors,bypass,misconfiguration",
        "category":    "Access Control",
        "builtin":     True,
        "installed":   True,
    },
    {
        "id":          "tmr-firebase-exposed",
        "name":        "Firebase API Key Exposure",
        "description": "Detects exposed Firebase configs and tests for open Firestore access",
        "author":      "TMR Team",
        "severity":    "critical",
        "tags":        "firebase,exposure,cloud",
        "category":    "Cloud Security",
        "builtin":     True,
        "installed":   True,
    },
    {
        "id":          "tmr-graphql-introspection",
        "name":        "GraphQL Introspection Enabled",
        "description": "Checks if GraphQL introspection is enabled (info disclosure in production)",
        "author":      "TMR Team",
        "severity":    "medium",
        "tags":        "graphql,introspection,api",
        "category":    "API Security",
        "builtin":     True,
        "installed":   True,
    },
    {
        "id":          "tmr-aws-metadata",
        "name":        "AWS Metadata SSRF",
        "description": "Tests SSRF vectors targeting AWS metadata endpoint (169.254.169.254)",
        "author":      "TMR Team",
        "severity":    "critical",
        "tags":        "ssrf,aws,cloud,metadata",
        "category":    "Cloud Security",
        "builtin":     True,
        "installed":   True,
    },
    {
        "id":          "tmr-jwt-none",
        "name":        "JWT None Algorithm Attack",
        "description": "Tests JWT tokens with 'none' algorithm signature bypass",
        "author":      "TMR Team",
        "severity":    "critical",
        "tags":        "jwt,authentication,bypass",
        "category":    "Authentication",
        "builtin":     True,
        "installed":   True,
    },
    {
        "id":          "tmr-host-header-injection",
        "name":        "Host Header Injection",
        "description": "Tests Host header manipulation for cache poisoning and SSRF",
        "author":      "TMR Team",
        "severity":    "high",
        "tags":        "host-header,cache-poisoning,ssrf",
        "category":    "Injection",
        "builtin":     True,
        "installed":   True,
    },
    {
        "id":          "tmr-prototype-pollution",
        "name":        "Prototype Pollution (Client + Server)",
        "description": "Tests both client-side DOM prototype pollution and server-side Node.js variants",
        "author":      "TMR Team",
        "severity":    "high",
        "tags":        "prototype-pollution,javascript,nodejs",
        "category":    "JavaScript",
        "builtin":     True,
        "installed":   True,
    },
    {
        "id":          "tmr-http-smuggling",
        "name":        "HTTP Request Smuggling (CL.TE + TE.CL + H2)",
        "description": "Full smuggling test suite: Content-Length/Transfer-Encoding desync + HTTP/2 downgrade",
        "author":      "TMR Team",
        "severity":    "critical",
        "tags":        "smuggling,http-desync,http2",
        "category":    "Protocol",
        "builtin":     True,
        "installed":   True,
    },
    {
        "id":          "tmr-oauth-pkce",
        "name":        "OAuth PKCE Bypass",
        "description": "Tests OAuth flows for missing/weak PKCE, state fixation, redirect_uri bypass",
        "author":      "TMR Team",
        "severity":    "high",
        "tags":        "oauth,pkce,authentication",
        "category":    "Authentication",
        "builtin":     True,
        "installed":   True,
    },
    {
        "id":          "tmr-cache-deception",
        "name":        "Web Cache Deception",
        "description": "Tests path confusion attacks to cache authenticated responses for unauthenticated users",
        "author":      "TMR Team",
        "severity":    "high",
        "tags":        "cache,deception,authentication",
        "category":    "Cache Attacks",
        "builtin":     True,
        "installed":   True,
    },
    {
        "id":          "tmr-mass-assignment",
        "name":        "Mass Assignment (IDOR + Role Escalation)",
        "description": "Probes JSON/form bodies for hidden fields: role, admin, is_admin, privilege",
        "author":      "TMR Team",
        "severity":    "high",
        "tags":        "mass-assignment,idor,access-control",
        "category":    "Access Control",
        "builtin":     True,
        "installed":   True,
    },
    {
        "id":          "tmr-subdomain-takeover",
        "name":        "Subdomain Takeover (30+ services)",
        "description": "Checks dangling CNAME/A records for takeover on GitHub Pages, Heroku, Netlify, Vercel...",
        "author":      "TMR Team",
        "severity":    "high",
        "tags":        "takeover,subdomain,dns",
        "category":    "Infrastructure",
        "builtin":     True,
        "installed":   True,
    },
]

MARKETPLACE_PLUGINS = [
    {
        "id":          "nuclei-cve-2024-latest",
        "name":        "Latest CVE Pack (auto-updated daily)",
        "description": "9,000+ Nuclei templates covering CVEs from 2015–today, updated within hours of disclosure",
        "author":      "ProjectDiscovery Community",
        "severity":    "critical",
        "tags":        "cve,vulnerability,community",
        "category":    "CVE Detection",
        "source":      "nuclei-community",
        "template_count": 9000,
    },
    {
        "id":          "nuclei-exposures",
        "name":        "Exposed Panels & Services",
        "description": "Detects admin panels, login pages, exposed services (Jenkins, Kibana, Grafana...)",
        "author":      "ProjectDiscovery Community",
        "severity":    "medium",
        "tags":        "panel,exposure,login",
        "category":    "Exposure",
        "source":      "nuclei-community",
    },
    {
        "id":          "nuclei-technologies",
        "name":        "Technology Fingerprinting",
        "description": "Identify frameworks, CMSes, servers, and libraries from response signatures",
        "author":      "ProjectDiscovery Community",
        "severity":    "info",
        "tags":        "fingerprint,technology,detection",
        "category":    "Reconnaissance",
        "source":      "nuclei-community",
    },
    {
        "id":          "nuclei-default-logins",
        "name":        "Default Credentials",
        "description": "Tests 200+ default login combinations across routers, cameras, admin panels",
        "author":      "ProjectDiscovery Community",
        "severity":    "critical",
        "tags":        "default-login,credentials,authentication",
        "category":    "Authentication",
        "source":      "nuclei-community",
    },
    {
        "id":          "nuclei-wordpress",
        "name":        "WordPress Plugin Vulnerabilities",
        "description": "Checks for 500+ vulnerable WordPress plugins, themes, and core versions",
        "author":      "ProjectDiscovery Community",
        "severity":    "high",
        "tags":        "wordpress,cms,plugin",
        "category":    "CMS",
        "source":      "nuclei-community",
    },
    {
        "id":          "nuclei-cloud-misconfig",
        "name":        "Cloud Misconfiguration",
        "description": "AWS S3, GCP, Azure storage + IAM misconfiguration detection",
        "author":      "ProjectDiscovery Community",
        "severity":    "critical",
        "tags":        "cloud,misconfiguration,aws,gcp,azure",
        "category":    "Cloud Security",
        "source":      "nuclei-community",
    },
    {
        "id":          "nuclei-network",
        "name":        "Network Service Detection",
        "description": "TCP/UDP service fingerprinting, open port enumeration, banner grabbing",
        "author":      "ProjectDiscovery Community",
        "severity":    "medium",
        "tags":        "network,tcp,service",
        "category":    "Network",
        "source":      "nuclei-community",
    },
]


# ── Core functions ─────────────────────────────────────────────────────────

def _load_meta() -> Dict:
    """Load plugin installation metadata."""
    if PLUGIN_META.exists():
        try: return json.loads(PLUGIN_META.read_text())
        except: pass
    return {"installed": {}, "custom": {}}


def _save_meta(meta: Dict):
    PLUGIN_META.parent.mkdir(parents=True, exist_ok=True)
    PLUGIN_META.write_text(json.dumps(meta, indent=2))


def list_plugins(category: str = "", source: str = "",
                 installed_only: bool = False) -> Dict:
    """
    List all available plugins.
    Returns: {builtin, marketplace, custom, nuclei_templates, total}
    """
    meta     = _load_meta()
    installed_ids = set(meta.get("installed", {}).keys())

    # Custom templates from disk
    CUSTOM_TPL.mkdir(parents=True, exist_ok=True)
    custom = []
    for f in sorted(CUSTOM_TPL.rglob("*.yaml")):
        try:
            content = f.read_text(encoding="utf-8")
            pid  = re.search(r"^id:\s*(.+)$",       content, re.M)
            pname= re.search(r"^\s+name:\s*(.+)$",   content, re.M)
            psev = re.search(r"^\s+severity:\s*(.+)$",content, re.M)
            ptag = re.search(r"^\s+tags:\s*(.+)$",   content, re.M)
            pdesc= re.search(r"^\s+description:\s*(.+)$", content, re.M)
            custom.append({
                "id":          pid.group(1).strip()   if pid  else f.stem,
                "name":        pname.group(1).strip() if pname else f.stem,
                "severity":    psev.group(1).strip()  if psev else "medium",
                "tags":        ptag.group(1).strip()  if ptag else "",
                "description": pdesc.group(1).strip() if pdesc else "",
                "author":      "You",
                "category":    "Custom",
                "file":        str(f.relative_to(APP_ROOT)),
                "installed":   True,
                "custom":      True,
                "size":        f.stat().st_size,
            })
        except: pass

    # Nuclei template stats
    nuclei_count = 0
    nuclei_cats  = {}
    if NUCLEI_TPL.exists():
        for root, dirs, files in os.walk(NUCLEI_TPL):
            yaml_count = sum(1 for f in files if f.endswith(".yaml"))
            if yaml_count:
                cat = Path(root).relative_to(NUCLEI_TPL).parts
                cat_name = cat[0] if cat else "root"
                nuclei_cats[cat_name] = nuclei_cats.get(cat_name, 0) + yaml_count
                nuclei_count += yaml_count

    # Mark marketplace plugins as installed if nuclei templates exist
    marketplace = []
    for p in MARKETPLACE_PLUGINS:
        p2 = dict(p)
        p2["installed"] = p["id"] in installed_ids or (
            p.get("source") == "nuclei-community" and nuclei_count > 0)
        marketplace.append(p2)

    return {
        "builtin":    BUILTIN_PLUGINS,
        "marketplace": marketplace,
        "custom":     custom,
        "nuclei": {
            "installed": nuclei_count > 0,
            "count":     nuclei_count,
            "categories": nuclei_cats,
            "path":      str(NUCLEI_TPL) if NUCLEI_TPL.exists() else "",
        },
        "total": len(BUILTIN_PLUGINS) + len(marketplace) + len(custom) + nuclei_count,
    }


def install_plugin(plugin_id: str = "", yaml_content: str = "",
                   url: str = "") -> Dict:
    """
    Install a plugin:
    - yaml_content: raw YAML — save to custom-templates/
    - url: download YAML from URL
    - plugin_id: install from marketplace (triggers nuclei template update)
    """
    with PLUGIN_LOCK:
        # Case 1: raw YAML upload
        if yaml_content:
            return _install_yaml(yaml_content)

        # Case 2: URL download
        if url:
            try:
                ctx = ssl.create_default_context()
                ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
                with urllib.request.urlopen(url, timeout=15, context=ctx) as r:
                    content = r.read().decode("utf-8", "ignore")
                return _install_yaml(content, source_url=url)
            except Exception as e:
                return {"ok": False, "error": f"Download failed: {e}"}

        # Case 3: marketplace plugin (nuclei templates)
        if plugin_id:
            p = next((p for p in MARKETPLACE_PLUGINS if p["id"] == plugin_id), None)
            if p and p.get("source") == "nuclei-community":
                from engine.nuclei_engine import update_templates
                result = update_templates(force=True)
                if result.get("ok"):
                    meta = _load_meta()
                    meta.setdefault("installed", {})[plugin_id] = {
                        "installed_at": datetime.now().isoformat(),
                        "source": "nuclei-community",
                    }
                    _save_meta(meta)
                    return {"ok": True, "templates": result.get("templates", 0),
                            "note": f"Nuclei templates synced: {result.get('templates',0)} ready"}
                return result

        return {"ok": False, "error": "Provide yaml_content, url, or plugin_id"}


def _install_yaml(content: str, source_url: str = "") -> Dict:
    """Save YAML template to custom-templates/."""
    CUSTOM_TPL.mkdir(parents=True, exist_ok=True)
    try:
        import yaml
        data = yaml.safe_load(content)
        if not isinstance(data, dict):
            return {"ok": False, "error": "Invalid YAML: not a mapping"}
        if "id" not in data:
            return {"ok": False, "error": "Missing required field: id"}
        if "info" not in data:
            return {"ok": False, "error": "Missing required field: info"}
        plugin_id = re.sub(r"[^a-zA-Z0-9_\-]", "_", data["id"])
        path = CUSTOM_TPL / f"{plugin_id}.yaml"
        path.write_text(content, encoding="utf-8")
        meta = _load_meta()
        meta.setdefault("custom", {})[plugin_id] = {
            "installed_at": datetime.now().isoformat(),
            "source_url":   source_url,
            "file":         str(path),
        }
        _save_meta(meta)
        return {
            "ok":   True,
            "id":   plugin_id,
            "name": data.get("info", {}).get("name", plugin_id),
            "path": str(path),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def uninstall_plugin(plugin_id: str) -> Dict:
    """Remove a custom plugin."""
    safe_id = re.sub(r"[^a-zA-Z0-9_\-]", "_", plugin_id)
    path = CUSTOM_TPL / f"{safe_id}.yaml"
    if path.exists():
        path.unlink()
        meta = _load_meta()
        meta.get("custom", {}).pop(plugin_id, None)
        _save_meta(meta)
        return {"ok": True}
    return {"ok": False, "error": "Plugin not found"}


def validate_plugin(content: str) -> Dict:
    """Validate a Nuclei-format YAML plugin."""
    try:
        import yaml
        data = yaml.safe_load(content)
        if not isinstance(data, dict):
            return {"valid": False, "error": "Not a YAML mapping"}
        missing = [k for k in ["id", "info"] if k not in data]
        if missing:
            return {"valid": False, "error": f"Missing: {missing}"}
        info = data.get("info", {})
        missing2 = [k for k in ["name", "severity"] if k not in info]
        if missing2:
            return {"valid": False, "error": f"Missing info.{missing2[0]}"}
        # Check for at least one request type
        has_req = any(k in data for k in ["http","tcp","dns","network","headless","ssl"])
        return {
            "valid":    True,
            "id":       data.get("id"),
            "name":     info.get("name"),
            "severity": info.get("severity"),
            "has_http": "http" in data,
            "has_requests": has_req,
            "warning":  "" if has_req else "No request block found — template may not run",
        }
    except Exception as e:
        return {"valid": False, "error": str(e)}


def run_plugin(plugin_id: str, targets: List[str], emit_fn=None) -> List[Dict]:
    """Run a specific plugin against targets."""
    safe_id = re.sub(r"[^a-zA-Z0-9_\-]", "_", plugin_id)
    path    = CUSTOM_TPL / f"{safe_id}.yaml"

    if not path.exists():
        # Try nuclei templates
        if NUCLEI_TPL.exists():
            matches = list(NUCLEI_TPL.rglob(f"*{plugin_id}*.yaml"))
            if matches: path = matches[0]

    if not path.exists():
        return [{"error": f"Plugin {plugin_id} not found"}]

    try:
        from engine.nuclei_engine import scan as nuclei_scan
        return nuclei_scan(
            targets=targets,
            templates=[str(path)],
            emit_fn=emit_fn,
        )
    except Exception as e:
        log.error(f"[plugins] run {plugin_id}: {e}")
        return []


def get_nuclei_cve_stats() -> Dict:
    """Get CVE coverage statistics from installed nuclei templates."""
    if not NUCLEI_TPL.exists():
        return {"total": 0, "cves": 0, "critical": 0, "high": 0, "categories": {}}
    
    stats = {"total": 0, "cves": 0, "critical": 0, "high": 0,
             "medium": 0, "categories": {}, "years": {}}
    
    for root, _, files in os.walk(NUCLEI_TPL):
        for fname in files:
            if not fname.endswith(".yaml"): continue
            stats["total"] += 1
            cat = Path(root).relative_to(NUCLEI_TPL).parts
            cat_name = cat[0] if cat else "misc"
            stats["categories"][cat_name] = stats["categories"].get(cat_name, 0) + 1
            
            # Quick parse for severity and CVE IDs (read first 500 bytes only)
            try:
                with open(os.path.join(root, fname), "rb") as f:
                    head = f.read(800).decode("utf-8", "ignore")
                m_sev = re.search(r"severity:\s*(\w+)", head)
                if m_sev:
                    sev = m_sev.group(1).lower()
                    if sev in stats: stats[sev] += 1
                m_cve = re.search(r"CVE-(\d{4})-\d+", head, re.I)
                if m_cve:
                    stats["cves"] += 1
                    yr = m_cve.group(1)
                    stats["years"][yr] = stats["years"].get(yr, 0) + 1
            except: pass
    
    return stats
