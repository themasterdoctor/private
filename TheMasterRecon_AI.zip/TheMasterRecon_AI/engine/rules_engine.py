"""
TheMasterRecon AI — Custom Detection Rules Engine (Nuclei-style)
YAML-compatible rule definitions with regex, header, body, status matchers.
Import/export rules. Scan any endpoint against all rules.
"""
import re, yaml, json, os, time, logging, ssl, urllib.request, urllib.parse
from pathlib import Path
from typing import List, Dict, Optional

log = logging.getLogger("elite.rules")

DATA_DIR   = Path("./data/_rules")
RULES_FILE = DATA_DIR / "custom_rules.yaml"

# Default built-in rules
BUILTIN_RULES = [
    {"id":"tmr-001","name":"AWS Key Exposed","severity":"critical",
     "pattern":r"AKIA[0-9A-Z]{16}","field":"response_body","tags":["secrets","aws"]},
    {"id":"tmr-002","name":"Private Key Exposed","severity":"critical",
     "pattern":r"-----BEGIN (RSA |EC )?PRIVATE KEY-----","field":"response_body","tags":["secrets"]},
    {"id":"tmr-003","name":"GitHub Token","severity":"critical",
     "pattern":r"ghp_[A-Za-z0-9]{36}","field":"response_body","tags":["secrets","github"]},
    {"id":"tmr-004","name":"Debug Mode On","severity":"medium",
     "pattern":r"(?i)(debug\s*=\s*true|debug_mode\s*=\s*1|APP_DEBUG\s*=\s*true)","field":"response_body","tags":["misconfig"]},
    {"id":"tmr-005","name":"Stack Trace Exposed","severity":"medium",
     "pattern":r"(?i)(stack trace|traceback \(most recent|at [A-Za-z]+\.[A-Za-z]+\(|System\.Exception)","field":"response_body","tags":["exposure"]},
    {"id":"tmr-006","name":"SQL Error","severity":"high",
     "pattern":r"(?i)(SQL syntax.*MySQL|Warning.*mysqli|ORA-\d+|PG::|sqlite3\.|Microsoft OLE DB Provider for SQL)","field":"response_body","tags":["sqli"]},
    {"id":"tmr-007","name":"Missing HSTS Header","severity":"low",
     "pattern":r"^$","field":"header:strict-transport-security","negate":True,"tags":["headers"]},
    {"id":"tmr-008","name":"X-Frame-Options Missing","severity":"medium",
     "pattern":r"^$","field":"header:x-frame-options","negate":True,
     "path_filter":r"/(login|admin|dashboard|account)","tags":["clickjacking"]},
    {"id":"tmr-009","name":"Server Version Disclosure","severity":"low",
     "pattern":r"(?i)(apache/[\d\.]+|nginx/[\d\.]+|Microsoft-IIS/[\d\.]+|PHP/[\d\.]+)","field":"header:server","tags":["exposure"]},
    {"id":"tmr-010","name":"Backup File Accessible","severity":"high",
     "pattern":r"","field":"status","status_match":[200],"url_pattern":r"\.(bak|backup|old|orig|copy|sql|dump)$","tags":["exposure"]},
    {"id":"tmr-011","name":"JWT None Algorithm","severity":"critical",
     "pattern":r"eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.","field":"response_body",
     "extra_check":"jwt_alg_none","tags":["jwt"]},
    {"id":"tmr-012","name":"CORS Wildcard","severity":"medium",
     "pattern":r"^\*$","field":"header:access-control-allow-origin","tags":["cors"]},
    {"id":"tmr-013","name":"GraphQL Introspection","severity":"low",
     "pattern":r'"__schema"',"field":"response_body","tags":["graphql"]},
    {"id":"tmr-014","name":"MongoDB Exposed","severity":"critical",
     "status_match":[200],"url_pattern":r"(:27017|/mongo|/mongodb)","field":"status",
     "pattern":r"","tags":["database"]},
    {"id":"tmr-015","name":"Sensitive Path in Response","severity":"medium",
     "pattern":r"(?i)(/etc/passwd|/etc/shadow|/proc/self|c:\\\\windows\\\\system32)","field":"response_body","tags":["lfi"]},
]


def _ssl():
    c = ssl.create_default_context()
    c.check_hostname = False
    c.verify_mode = ssl.CERT_NONE
    return c


def load_rules() -> List[dict]:
    """Load all rules: builtin + custom."""
    rules = list(BUILTIN_RULES)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if RULES_FILE.exists():
        try:
            content = RULES_FILE.read_text()
            custom  = yaml.safe_load(content) or []
            if isinstance(custom, list):
                rules.extend(custom)
        except Exception as e:
            log.warning(f"[rules] load error: {e}")
    return rules

def save_custom_rule(rule: dict) -> dict:
    """Save a new custom rule."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    existing = []
    if RULES_FILE.exists():
        try:
            existing = yaml.safe_load(RULES_FILE.read_text()) or []
        except Exception:
            pass
    # Update or append
    found = False
    for i, r in enumerate(existing):
        if r.get("id") == rule.get("id"):
            existing[i] = rule
            found = True
            break
    if not found:
        if not rule.get("id"):
            rule["id"] = f"custom-{int(time.time())}"
        existing.append(rule)
    RULES_FILE.write_text(yaml.dump(existing, default_flow_style=False))
    return rule

def delete_rule(rule_id: str) -> bool:
    if not RULES_FILE.exists():
        return False
    try:
        rules = yaml.safe_load(RULES_FILE.read_text()) or []
        rules = [r for r in rules if r.get("id") != rule_id]
        RULES_FILE.write_text(yaml.dump(rules, default_flow_style=False))
        return True
    except Exception:
        return False

def import_rules_yaml(yaml_text: str) -> int:
    """Import rules from YAML text. Returns count imported."""
    try:
        new_rules = yaml.safe_load(yaml_text)
        if not isinstance(new_rules, list):
            new_rules = [new_rules]
        count = 0
        for rule in new_rules:
            if isinstance(rule, dict) and rule.get("pattern") is not None:
                save_custom_rule(rule)
                count += 1
        return count
    except Exception as e:
        raise ValueError(f"Invalid YAML: {e}")

def export_rules_yaml(include_builtin: bool = False) -> str:
    """Export rules as YAML."""
    rules = load_rules() if include_builtin else []
    if not include_builtin and RULES_FILE.exists():
        try:
            rules = yaml.safe_load(RULES_FILE.read_text()) or []
        except Exception:
            rules = []
    return yaml.dump(rules, default_flow_style=False, allow_unicode=True)


def _match_rule(rule: dict, url: str, status: int,
                req_headers: dict, resp_headers: dict, body: str) -> bool:
    """Check if a response matches a rule."""
    # URL pattern filter
    url_pat = rule.get("url_pattern","")
    if url_pat and not re.search(url_pat, url, re.I):
        return False
    # Path filter
    path_filter = rule.get("path_filter","")
    if path_filter and not re.search(path_filter, url, re.I):
        return False
    # Status check
    status_match = rule.get("status_match",[])
    if status_match and status not in status_match:
        return False

    field   = rule.get("field","response_body")
    pattern = rule.get("pattern","")
    negate  = rule.get("negate", False)

    # Determine target text
    if field == "response_body":
        target = body
    elif field == "status":
        target = str(status)
    elif field.startswith("header:"):
        hdr_name = field.split(":",1)[1].lower()
        hdrs_lower = {k.lower():v for k,v in resp_headers.items()}
        target = hdrs_lower.get(hdr_name,"")
    elif field == "url":
        target = url
    else:
        target = body

    if not pattern and not status_match:
        return False

    if pattern:
        try:
            matched = bool(re.search(pattern, target, re.I | re.S))
        except re.error:
            matched = pattern in target

        if negate:
            return not matched
        return matched

    return True


def scan_url_with_rules(url: str, rules: List[dict] = None) -> List[dict]:
    """Scan a URL against all (or given) rules. Returns list of matches."""
    if rules is None:
        rules = load_rules()

    try:
        req = urllib.request.Request(url, headers={"User-Agent":"TheMasterRecon-Rules/1.0"})
        with urllib.request.urlopen(req, timeout=15, context=_ssl()) as r:
            body_bytes = r.read(500000)
            status     = r.status
            resp_hdrs  = dict(r.headers)
            try:
                body = body_bytes.decode("utf-8","ignore")
            except Exception:
                body = ""
    except urllib.error.HTTPError as e:
        status    = e.code
        resp_hdrs = dict(e.headers)
        try: body = e.read().decode("utf-8","ignore")
        except: body = ""
    except Exception as e:
        return [{"error": str(e), "url": url}]

    matches = []
    for rule in rules:
        if not rule.get("enabled", True):
            continue
        try:
            if _match_rule(rule, url, status, {}, resp_hdrs, body):
                matches.append({
                    "rule_id":     rule.get("id",""),
                    "rule_name":   rule.get("name",""),
                    "severity":    rule.get("severity","medium"),
                    "tags":        rule.get("tags",[]),
                    "url":         url,
                    "status":      status,
                    "matched_field": rule.get("field",""),
                    "pattern":     rule.get("pattern",""),
                })
        except Exception:
            pass
    return matches


def scan_urls_with_rules(urls: List[str], rules: List[dict] = None,
                         threads: int = 5) -> dict:
    """Scan multiple URLs against all rules. Returns {url: [matches]}."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    if rules is None:
        rules = load_rules()

    results = {}
    with ThreadPoolExecutor(max_workers=threads) as exe:
        futs = {exe.submit(scan_url_with_rules, url, rules): url for url in urls}
        for fut in as_completed(futs):
            url = futs[fut]
            try:
                results[url] = fut.result()
            except Exception as e:
                results[url] = [{"error": str(e)}]
    return results
