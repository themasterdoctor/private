"""
TheMasterRecon AI — Built-in OOB/Collaborator Server
Self-hosted DNS + HTTP callback server for blind vulnerability detection.
Replaces dependency on external oast.pro / burp collaborator.

Usage:
  from engine.oob_server import OOBServer
  oob = OOBServer(http_port=8088, dns_port=5354)
  oob.start()
  token = oob.gen_token("ssrf")          # unique canary
  oob.poll(token, timeout=10)            # check if called back
  oob.stop()
"""

import os, threading, time, hashlib, base64, json, logging, socket
import http.server, socketserver, uuid, re
from collections import defaultdict
from datetime import datetime

log = logging.getLogger("elite.oob")

# ── Storage for callbacks ─────────────────────────────────────────────────────
_callbacks   = defaultdict(list)   # token → list of hit dicts
_lock        = threading.Lock()
_server_host = ""  # filled at start

def _record_hit(token: str, source_ip: str, protocol: str, data: str = ""):
    with _lock:
        _callbacks[token].append({
            "ts":       datetime.utcnow().isoformat() + "Z",
            "ip":       source_ip,
            "protocol": protocol,
            "data":     data[:500],
        })
    log.info(f"[oob] HIT token={token[:12]}… protocol={protocol} from={source_ip}")


# ── HTTP callback handler ─────────────────────────────────────────────────────
class _OOBHTTPHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass  # silence default logging

    def _handle(self):
        # Extract token from path: /TOKEN or /oob/TOKEN
        path = self.path.split("?")[0].strip("/")
        parts = path.split("/")
        token = parts[-1] if parts else ""
        if token and len(token) >= 8:
            body = ""
            if self.headers.get("Content-Length"):
                body = self.rfile.read(int(self.headers["Content-Length"])).decode("utf-8","ignore")
            _record_hit(token, self.client_address[0], "HTTP",
                        f"{self.command} {self.path} | body={body[:200]}")
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"OK")

    do_GET  = _handle
    do_POST = _handle
    do_HEAD = _handle
    do_PUT  = _handle


# ── DNS callback handler ──────────────────────────────────────────────────────
def _dns_server_loop(sock, domain_suffix: str):
    """Minimal DNS server — answers A queries, records token from label."""
    try:
        from dnslib import DNSRecord, RR, QTYPE, A
    except ImportError:
        log.warning("[oob] dnslib not installed — DNS OOB disabled")
        return

    while True:
        try:
            data, addr = sock.recvfrom(4096)
            req = DNSRecord.parse(data)
            qname = str(req.q.qname).rstrip(".")
            # Extract token from first label: TOKEN.oob.example.com
            parts = qname.split(".")
            token = parts[0] if parts else ""
            if token and len(token) >= 8:
                _record_hit(token, addr[0], "DNS", f"query={qname}")
            # Always respond with 127.0.0.1
            reply = req.reply()
            reply.add_answer(RR(req.q.qname, QTYPE.A, rdata=A("127.0.0.1"), ttl=60))
            sock.sendto(reply.pack(), addr)
        except Exception:
            pass


# ── Main OOB Server class ─────────────────────────────────────────────────────
class OOBServer:
    def __init__(self, http_port: int = 8088, dns_port: int = 5354,
                 domain: str = ""):
        self.http_port    = http_port
        self.dns_port     = dns_port
        self.domain       = domain or f"oob.localhost"
        self._http_server = None
        self._threads     = []
        self._started     = False
        self._my_ip       = self._detect_ip()

    def _detect_ip(self) -> str:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def start(self):
        if self._started:
            return
        global _server_host
        _server_host = self._my_ip

        # HTTP server thread — auto-retry on alternate ports if 8088 in use
        _bound = False
        for _try_port in range(self.http_port, self.http_port + 20):
            try:
                self._http_server = socketserver.TCPServer(
                    ("0.0.0.0", _try_port), _OOBHTTPHandler)
                self._http_server.allow_reuse_address = True
                t = threading.Thread(target=self._http_server.serve_forever, daemon=True)
                t.start()
                self._threads.append(t)
                self.http_port = _try_port   # remember actual port
                log.info(f"[oob] HTTP callback server on port {_try_port}")
                _bound = True
                break
            except OSError:
                log.debug(f"[oob] port {_try_port} busy, trying {_try_port+1}...")
        if not _bound:
            log.warning(f"[oob] HTTP server failed: all ports {self.http_port}–{self.http_port+20} in use")

        # DNS server thread
        try:
            dns_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            dns_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            dns_sock.bind(("0.0.0.0", self.dns_port))
            t = threading.Thread(target=_dns_server_loop,
                                 args=(dns_sock, self.domain), daemon=True)
            t.start()
            self._threads.append(t)
            log.info(f"[oob] DNS callback server on port {self.dns_port}")
        except OSError as e:
            log.warning(f"[oob] DNS server failed (need root for 53): {e}")

        self._started = True

    def stop(self):
        if self._http_server:
            self._http_server.shutdown()
        self._started = False

    def gen_token(self, tag: str = "") -> str:
        """Generate a unique OOB token."""
        uid  = uuid.uuid4().hex[:16]
        tok  = f"{uid}.{self.domain}"
        return tok

    def gen_payload(self, tag: str = "", proto: str = "http") -> tuple:
        """
        Returns (token, payload_url, dns_hostname).
        payload_url  — use in SSRF, XXE, Log4j etc.
        dns_hostname — use for DNS-based OOB (nslookup, dig).
        """
        uid = uuid.uuid4().hex[:12]
        dns_host   = f"{uid}.{self.domain}"
        http_url   = f"http://{self._my_ip}:{self.http_port}/{uid}"
        return uid, http_url, dns_host

    def poll(self, token: str, timeout: float = 8.0) -> list:
        """Wait up to `timeout` seconds for a callback on this token."""
        start = time.time()
        while time.time() - start < timeout:
            with _lock:
                hits = list(_callbacks.get(token, []))
            if hits:
                return hits
            time.sleep(0.3)
        return []

    def get_hits(self, token: str) -> list:
        with _lock:
            return list(_callbacks.get(token, []))

    def all_hits(self) -> dict:
        with _lock:
            return dict(_callbacks)

    @property
    def my_ip(self) -> str:
        return self._my_ip

    @property
    def callback_url(self) -> str:
        return f"http://{self._my_ip}:{self.http_port}"

    @property
    def callback_domain(self) -> str:
        return self.domain


# ── Singleton ─────────────────────────────────────────────────────────────────
_instance: OOBServer | None = None

def get_oob_server() -> OOBServer:
    global _instance
    if _instance is None:
        port = int(os.environ.get("OOB_HTTP_PORT", "8088"))
        dns  = int(os.environ.get("OOB_DNS_PORT",  "5354"))
        dom  = os.environ.get("OOB_DOMAIN", "")
        _instance = OOBServer(http_port=port, dns_port=dns, domain=dom)
        _instance.start()
    return _instance
