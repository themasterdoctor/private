"""
TheMasterRecon AI — Endpoint Prioritization Engine
Scores every endpoint and returns high_value_targets[] for the scanner to
focus on first. Replaces random endpoint ordering with signal-based ranking.

Score components (0-100 each, weighted sum → final 0-1000):
  - Parameter signal   (200): injectable params, SSRF-named params, upload params
  - Auth signal        (150): requires authentication → higher value
  - Response type      (100): JSON APIs > HTML forms > static
  - Keyword signal     (200): admin/upload/redirect/callback/api/v[0-9]
  - Path depth         (50):  deeper paths often have more logic
  - Extension signal   (100): .php/.asp/.aspx > .html > nothing
  - Method signal      (100): POST/PUT/DELETE > GET
  - Port signal        (100): non-standard ports (8080/8443/9000) = custom apps
"""
import re, logging
from typing import List, Dict
from urllib.parse import urlparse, parse_qs

log = logging.getLogger("elite.priority")

# ── Param signal tables ────────────────────────────────────────────────────────
SSRF_PARAMS = {
    "url","uri","path","redirect","return","dest","target","next","go",
    "continue","redir","callback","page","host","site","src","href",
    "img","image","link","data","fetch","load","request","endpoint",
    "api","service","webhook","notify","proxy",
}
SQLI_PARAMS = {
    "id","uid","user_id","item_id","product_id","order_id","page","offset",
    "limit","sort","order","filter","search","q","query","cat","category",
    "type","kind","mode","view","num","no","ref","token",
}
UPLOAD_PARAMS = {"file","upload","attachment","document","photo","image","avatar","import","csv","xml"}
IDOR_PARAMS   = {"id","uid","user","account","profile","record","object","uuid","key","ref","code"}
XSS_PARAMS    = {"q","search","query","s","msg","message","error","text","name","title","comment","body"}
AUTH_PARAMS   = {"token","auth","api_key","apikey","key","secret","password","pass","pwd","session","jwt","bearer"}

# High-signal keywords in path
HIGH_VALUE_KEYWORDS = {
    "admin":200, "administrator":200, "manage":150, "management":150,
    "api":120, "graphql":180, "rest":100,
    "upload":180, "file":120, "import":150, "export":150,
    "redirect":160, "callback":150, "oauth":170, "auth":130,
    "login":130, "logout":80, "register":100,
    "payment":180, "billing":170, "invoice":160, "checkout":150,
    "reset":140, "password":150, "forgot":130,
    "internal":200, "debug":180, "test":100, "dev":120, "staging":150,
    "backup":180, "config":170, "settings":120, "env":160,
    "webhook":150, "notify":120, "event":100,
    "user":100, "users":110, "account":110, "profile":100,
    "report":100, "export":130, "download":130,
    "search":80, "query":100,
}

# Response type signals
RESP_TYPE_SCORE = {
    "application/json": 100, "application/xml": 80, "application/graphql": 120,
    "text/json": 100, "text/xml": 80,
    "text/html": 50, "application/octet-stream": 90,
    "multipart/form-data": 110,
}

# Extension signals
EXT_SCORE = {
    ".php": 90, ".asp": 90, ".aspx": 90, ".jsp": 85, ".cfm": 85,
    ".pl": 80, ".cgi": 80, ".py": 70, ".rb": 70,
    ".do": 75, ".action": 75, ".svc": 70,
    ".json": 60, ".xml": 55, ".yaml": 50,
    ".bak": 100, ".sql": 100, ".env": 100, ".config": 90, ".conf": 90,
    ".log": 80, ".backup": 100, ".old": 80, ".orig": 80,
    ".html": 20, ".htm": 20, ".js": 30, ".css": 5, ".png": 0,
    ".jpg": 0, ".gif": 0, ".ico": 0, ".woff": 0, ".ttf": 0,
}

# Ports that indicate custom applications (not default web)
HIGH_VALUE_PORTS = {8080, 8443, 8888, 9000, 9090, 9200, 9300, 4443, 4000, 3000, 5000, 6443, 10000}


def score_endpoint(url: str, meta: dict = None) -> Dict:
    """
    Score a single endpoint. Returns {url, score, signals, bug_hints}.

    meta keys (all optional):
      auth_required (bool)   — endpoint needs a session/token
      response_type (str)    — Content-Type of the response
      status_code   (int)    — HTTP status of the response
      method        (str)    — HTTP method used
      response_size (int)    — response body size in bytes
      response_time (float)  — seconds to respond
    """
    meta   = meta or {}
    parsed = urlparse(url)
    path   = (parsed.path or "").lower()
    qs     = parse_qs(parsed.query)
    params = set(k.lower() for k in qs.keys())
    ext    = re.search(r"\.\w{1,5}$", path)
    ext    = ext.group(0).lower() if ext else ""
    port   = parsed.port or (443 if parsed.scheme == "https" else 80)
    score  = 0
    signals = []
    bug_hints = []

    # ── Parameter signal (max 200) ────────────────────────────────────────────
    if params:
        ssrf_hit  = params & SSRF_PARAMS
        sqli_hit  = params & SQLI_PARAMS
        upload_hit = params & UPLOAD_PARAMS
        idor_hit  = params & IDOR_PARAMS
        xss_hit   = params & XSS_PARAMS
        auth_hit  = params & AUTH_PARAMS

        if ssrf_hit:
            score += 200
            signals.append(f"SSRF params: {', '.join(ssrf_hit)}")
            bug_hints.append("ssrf")
        if upload_hit:
            score += 180
            signals.append(f"Upload params: {', '.join(upload_hit)}")
            bug_hints += ["fileupload", "xxe", "ssrf"]
        if idor_hit:
            score += 120
            signals.append(f"IDOR params: {', '.join(idor_hit)}")
            bug_hints.append("idor")
        if sqli_hit:
            score += 100
            signals.append(f"SQLi params: {', '.join(sqli_hit)}")
            bug_hints.append("sqli")
        if xss_hit:
            score += 80
            signals.append(f"XSS params: {', '.join(xss_hit)}")
            bug_hints.append("xss")
        if auth_hit:
            score += 90
            signals.append(f"Auth params: {', '.join(auth_hit)}")
            bug_hints.append("auth")
        if not (ssrf_hit or upload_hit or idor_hit or sqli_hit or xss_hit or auth_hit):
            score += 30  # has params, no known signal
    else:
        score += 5   # no params

    # ── Auth signal (max 150) ─────────────────────────────────────────────────
    if meta.get("auth_required"):
        score += 150
        signals.append("auth-gated endpoint")
        bug_hints += ["idor", "auth", "jwt"]
    elif meta.get("status_code") == 403:
        score += 120
        signals.append("403 Forbidden → auth bypass candidate")
        bug_hints += ["idor", "auth"]
    elif meta.get("status_code") == 401:
        score += 100
        signals.append("401 Unauthorized → JWT/token target")
        bug_hints.append("jwt")

    # ── Response type signal (max 100) ────────────────────────────────────────
    ct = (meta.get("response_type") or "").lower()
    for mime, pts in RESP_TYPE_SCORE.items():
        if mime in ct:
            score += pts
            signals.append(f"Content-Type: {mime}")
            if "json" in mime:
                bug_hints += ["idor", "cors", "sqli"]
            break

    # ── Keyword signal (max 200 per keyword, capped at 300 total) ────────────
    kw_total = 0
    matched_kws = []
    for kw, pts in HIGH_VALUE_KEYWORDS.items():
        if f"/{kw}" in path or f"/{kw}/" in path or path.endswith(f"/{kw}"):
            kw_total = min(kw_total + pts, 300)
            matched_kws.append(kw)
            # Map keywords to bug types
            kw_bugs = {
                "admin": ["idor","auth","misconfig"], "graphql": ["graphql","idor"],
                "upload": ["fileupload","xxe"], "redirect": ["redirect","ssrf"],
                "callback": ["ssrf","redirect","xss"], "oauth": ["oauth","csrf"],
                "payment": ["idor","business_logic"], "backup": ["expose"],
                "config": ["expose"], "env": ["expose"], "debug": ["expose","misconfig"],
                "internal": ["ssrf","idor"], "webhook": ["ssrf","cors"],
            }
            for k, bugs in kw_bugs.items():
                if kw == k:
                    bug_hints += bugs
    if matched_kws:
        score += kw_total
        signals.append(f"Keywords: {', '.join(matched_kws)}")

    # ── Path depth signal (max 50) ─────────────────────────────────────────────
    depth = len([p for p in path.split("/") if p])
    if depth >= 4:
        score += 50
        signals.append(f"deep path (depth={depth})")
    elif depth >= 2:
        score += 20

    # ── Extension signal (max 100) ─────────────────────────────────────────────
    if ext in EXT_SCORE:
        pts = EXT_SCORE[ext]
        if pts > 0:
            score += pts
            signals.append(f"extension: {ext}")
            if ext in (".bak", ".sql", ".env", ".config", ".conf", ".backup", ".log", ".old", ".orig"):
                bug_hints.append("expose")
    elif not ext:
        # No extension = probably a framework route → more interesting
        score += 40
        signals.append("no extension (framework route)")

    # ── Method signal (max 100) ────────────────────────────────────────────────
    method = (meta.get("method") or "GET").upper()
    if method in ("POST", "PUT", "PATCH", "DELETE"):
        score += 100
        signals.append(f"method: {method}")
        bug_hints += ["sqli", "ssrf", "idor", "csrf"]
    elif method == "GET" and params:
        score += 20

    # ── Port signal (max 100) ─────────────────────────────────────────────────
    if port in HIGH_VALUE_PORTS:
        score += 100
        signals.append(f"non-standard port: {port}")
        bug_hints += ["misconfig", "expose"]

    # ── API version signal ─────────────────────────────────────────────────────
    if re.search(r"/v\d+/", path) or re.search(r"/api/v\d+", path):
        score += 80
        signals.append("versioned API")
        bug_hints += ["idor", "cors"]

    # Deduplicate bug hints, preserve order
    seen_bugs = set()
    unique_bugs = []
    for b in bug_hints:
        if b not in seen_bugs:
            seen_bugs.add(b)
            unique_bugs.append(b)

    return {
        "url":       url,
        "score":     score,
        "priority":  ("critical" if score >= 600 else
                      "high"     if score >= 400 else
                      "medium"   if score >= 200 else "low"),
        "signals":   signals,
        "bug_hints": unique_bugs,
        "params":    sorted(params),
        "method":    method,
    }


def prioritize(endpoints: List[str], meta_map: dict = None,
               top_n: int = 50) -> List[Dict]:
    """
    Score all endpoints and return top_n sorted by score desc.

    meta_map: {url -> {auth_required, response_type, status_code, method}}
    """
    meta_map = meta_map or {}
    scored = []
    for url in endpoints:
        if not url or not url.startswith(("http://", "https://")):
            continue
        m = meta_map.get(url, {})
        s = score_endpoint(url, m)
        scored.append(s)

    scored.sort(key=lambda x: x["score"], reverse=True)
    top = scored[:top_n]

    log.info(f"[priority] scored {len(scored)} endpoints — "
             f"critical={sum(1 for s in scored if s['priority']=='critical')} "
             f"high={sum(1 for s in scored if s['priority']=='high')} "
             f"med={sum(1 for s in scored if s['priority']=='medium')}")
    return top


def build_high_value_targets(endpoints: List[str], findings: List[dict] = None,
                              meta_map: dict = None) -> List[Dict]:
    """
    Main entry point. Returns high_value_targets[] ready for AI and scanner.
    Boosts score for endpoints that already have a finding on them.
    """
    findings  = findings or []
    hit_urls  = {f.get("url", "") for f in findings}

    meta_map = meta_map or {}

    # Boost meta for already-found endpoints
    boosted_meta = dict(meta_map)
    for url in endpoints:
        if url in hit_urls:
            existing = dict(boosted_meta.get(url, {}))
            existing["_finding_hit"] = True
            boosted_meta[url] = existing

    scored = prioritize(endpoints, boosted_meta, top_n=100)

    # Extra boost for endpoints with confirmed findings
    for item in scored:
        if item["url"] in hit_urls:
            item["score"] = min(item["score"] + 200, 1000)
            item["signals"].insert(0, "⚡ confirmed finding on this endpoint")
            item["priority"] = "critical"

    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored[:50]
