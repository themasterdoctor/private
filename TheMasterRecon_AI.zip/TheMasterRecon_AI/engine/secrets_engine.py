"""
TheMasterRecon AI — Elite Secrets Engine
Combines 4 scanners for maximum secret detection:
1. detect-secrets (Yelp) — 20+ detector types, baseline support
2. TruffleHog — high-entropy + regex, git-aware  
3. Gitleaks — git history deep scan, SARIF output
4. Built-in regex — 65+ patterns (no binary dependency)

Pipeline:
  URL → fetch JS → detect-secrets + trufflehog + regex → deduplicate → findings
"""
import os, re, json, logging, shutil, subprocess, tempfile, threading
import urllib.request, urllib.parse, ssl, hashlib, concurrent.futures, time
from typing import List, Dict, Optional, Tuple
from pathlib import Path

log = logging.getLogger("elite.secrets")

APP_ROOT = Path(__file__).parent.parent

# ── Built-in patterns (always active, no binary needed) ──────────────────────
BUILTIN_PATTERNS: Dict[str, str] = {
    "AWS Access Key":         r"AKIA[0-9A-Z]{16}",
    "AWS Secret":             r"(?i)aws[_\-\s]{0,5}secret[_\-\s]{0,10}(?:key|access)?[\s\"':=]+([A-Za-z0-9/+=]{40})",
    "AWS Session Token":      r"AQoD[A-Za-z0-9/+=]{100,}",
    "Google API Key":         r"AIza[0-9A-Za-z\-_]{35}",
    "Google OAuth":           r"[0-9]+-[0-9A-Za-z_]{32}\.apps\.googleusercontent\.com",
    "Firebase":               r"AAAA[A-Za-z0-9_-]{7}:[A-Za-z0-9_-]{140}",
    "GCP Service Account":    r'"private_key":\s*"-----BEGIN RSA PRIVATE',
    "GitHub Token":           r"gh[pousr]_[A-Za-z0-9]{36,}",
    "GitHub OAuth":           r"gho_[A-Za-z0-9]{36}",
    "GitHub Fine-Grained":    r"github_pat_[A-Za-z0-9_]{82}",
    "GitLab Token":           r"glpat-[A-Za-z0-9\-]{20}",
    "Slack Token":            r"xox[baprs]-[0-9a-zA-Z\-]{10,100}",
    "Slack Webhook":          r"https://hooks\.slack\.com/services/T[A-Za-z0-9]+/B[A-Za-z0-9]+/[A-Za-z0-9]+",
    "Stripe Secret":          r"sk_live_[0-9a-zA-Z]{24,}",
    "Stripe Public":          r"pk_live_[0-9a-zA-Z]{24,}",
    "OpenAI Key":             r"sk-[a-zA-Z0-9]{48}",
    "Anthropic Key":          r"sk-ant-[a-zA-Z0-9_\-]{80,}",
    "HuggingFace Token":      r"hf_[a-zA-Z0-9]{34,}",
    "Twilio SID":             r"AC[a-z0-9]{32}",
    "Twilio Token":           r"SK[0-9a-fA-F]{32}",
    "SendGrid Key":           r"SG\.[a-zA-Z0-9\-_.]{22}\.[a-zA-Z0-9\-_.]{43}",
    "Mailgun Key":            r"key-[0-9a-zA-Z]{32}",
    "Mailchimp Key":          r"[0-9a-f]{32}-us[0-9]{1,2}",
    "Braintree Token":        r"access_token\$production\$[0-9a-z]{16}\$[0-9a-f]{32}",
    "Shopify Secret":         r"shpss_[a-fA-F0-9]{32}",
    "Shopify Access":         r"shpat_[a-fA-F0-9]{32}",
    "NPM Token":              r"npm_[a-zA-Z0-9]{36}",
    "Docker Hub":             r"dckr_pat_[a-zA-Z0-9_\-]{27}",
    "Discord Token":          r"[MN][A-Za-z\d]{23}\.[\w\-]{6}\.[\w\-]{27}",
    "Discord Webhook":        r"https://discord(?:app)?\.com/api/webhooks/[0-9]+/[A-Za-z0-9\-_]+",
    "Telegram Bot":           r"[0-9]{8,10}:[a-zA-Z0-9_\-]{35}",
    "Telegram Token":         r"bot[0-9]{8,10}:[a-zA-Z0-9_\-]{35}",
    "Azure Storage":          r"AccountKey=[a-zA-Z0-9+/]{86}==",
    "Azure SAS":              r"sv=[0-9]{4}-[0-9]{2}-[0-9]{2}&s[a-z]=",
    
    "JWT Token":              r"eyJ[a-zA-Z0-9_\-]{10,}\.eyJ[a-zA-Z0-9_\-]{10,}\.[a-zA-Z0-9_\-]{10,}",
    "Private Key (RSA)":      r"-----BEGIN (RSA |EC |DSA |OPENSSH |)PRIVATE KEY-----",
    "Private Key (PKCS8)":    r"-----BEGIN ENCRYPTED PRIVATE KEY-----",
    "SSL Certificate":        r"-----BEGIN CERTIFICATE-----",
    "Basic Auth (Base64)":    r"(?i)(?:authorization|auth):\s*basic\s+[a-zA-Z0-9+/=]{10,}",
    "Bearer Token":           r"(?i)(?:authorization|auth):\s*bearer\s+[a-zA-Z0-9\-_=.]{20,}",
    "Generic API Key":        r'(?i)(?:api[_\-]?key|apikey|api_token|auth_token|access_token|secret_key|private_key)\s*[=:]\s*["\']([a-zA-Z0-9_\-]{16,80})["\']',
    "Generic Password":       r'(?i)(?:password|passwd|pwd)\s*[=:]\s*["\']([^"\']{8,50})["\']',
    "Database URL":           r"(?:postgresql|mysql|mongodb|redis|mssql)://[^@\s]+:[^@\s]+@[^\s\"\'<>]+",
    "S3 Bucket URL":          r"s3://[a-zA-Z0-9\-_./]+",
    "Heroku API Key":         r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}",
    "Jira Token":             r"(?i)jira[_\-]?(?:api)?[_\-]?token\s*[=:]\s*[\"']([a-zA-Z0-9]{24})[\"']",
    "Confluence Token":       r"(?i)confluence[_\-]?token\s*[=:]\s*[\"']([a-zA-Z0-9]{24})[\"']",
    
    "PagerDuty Key":          r"[uo]_[a-z0-9]{18}",
    
    "Hashicorp Vault":        r"(?i)vault_token\s*[=:]\s*[\"']([a-zA-Z0-9._\-]{20,})[\"']",
    "LaunchDarkly":           r"(?:api|sdk)-[a-zA-Z0-9-]{8,}",
    "Dynatrace":              r"dt0[a-zA-Z]{1}[0-9]{2}\.[A-Z0-9]{24}\.[A-Z0-9]{64}",
    "Dropbox Token":          r"sl\.[a-zA-Z0-9\-_]{130,}",
    
    "Zendesk Token":          r"[a-zA-Z0-9]{40}\/token",
    "Intercom Token":         r"dG9r[a-zA-Z0-9]{50,}",
    "Adyen Key":              r"AQE[a-zA-Z0-9+/]{100,}=",
    "Square Token":           r"EAAAl[a-zA-Z0-9\-_]{32,}",
    "Plaid Key":              r"(?:access|public)-(?:sandbox|development|production)-[a-z0-9-]{36}",
}

# Severity mapping
HIGH_SEVERITY = {
    "AWS Access Key","AWS Secret","AWS Session Token","GCP Service Account",
    "Google API Key","Firebase","GitHub Token","GitHub Fine-Grained",
    "Stripe Secret","OpenAI Key","Anthropic Key","Azure Storage",
    "Private Key (RSA)","Private Key (PKCS8)","Database URL",
    "SendGrid Key","Twilio Token","HuggingFace Token",
}


def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _fetch(url: str, timeout: int = 12) -> str:
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 TheMasterRecon/3.0 SecretScanner"
        })
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.read(3_000_000).decode("utf-8", "ignore")
    except Exception as e:
        log.debug(f"[secrets] fetch {url}: {e}")
        return ""


# ── Layer 1: Built-in regex scanner ──────────────────────────────────────────

def scan_builtin(content: str, source: str = "") -> List[Dict]:
    """Scan content with 65+ built-in patterns. Always available, no binary needed."""
    findings = []
    seen     = set()

    for secret_type, pattern in BUILTIN_PATTERNS.items():
        try:
            for m in re.finditer(pattern, content, re.MULTILINE | re.DOTALL):
                val  = (m.group(1) if m.lastindex else m.group(0))[:120]
                key  = hashlib.md5(f"{secret_type}:{val[:40]}".encode()).hexdigest()
                if key in seen: continue
                seen.add(key)

                # Get context window
                s   = max(0, m.start() - 60)
                e   = min(len(content), m.end() + 60)
                ctx = content[s:e].replace('\n', ' ').strip()

                sev = "critical" if secret_type in HIGH_SEVERITY else "high"
                findings.append({
                    "type":     secret_type,
                    "value":    val,
                    "preview":  val[:50] + "…" if len(val) > 50 else val,
                    "context":  ctx[:200],
                    "source":   source,
                    "severity": sev,
                    "tool":     "builtin",
                    "hash":     key,
                })
        except re.error:
            continue

    return findings


# ── Layer 2: detect-secrets (Yelp) ───────────────────────────────────────────

def scan_detect_secrets(content: str, source: str = "") -> List[Dict]:
    """
    Use detect-secrets library (pip install detect-secrets).
    Handles: AWS, GitHub, Slack, Stripe, JWT, private keys, and more.
    """
    try:
        # detect-secrets v1.5 compatible
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as tf:
            tf.write(content)
            tf_name = tf.name

        findings = []
        seen     = set()

        try:
            r = subprocess.run(
                ["detect-secrets", "scan", tf_name],
                capture_output=True, text=True, timeout=30
            )
            if r.returncode == 0 and r.stdout.strip():
                data = json.loads(r.stdout)
                for fname, secrets in data.get("results", {}).items():
                    for secret in secrets:
                        stype = secret.get("type","")
                        line  = secret.get("line_number", 0)
                        key   = hashlib.md5(f"ds:{stype}:{line}:{source}".encode()).hexdigest()
                        if key in seen: continue
                        seen.add(key)
                        findings.append({
                            "type":     stype,
                            "value":    f"[line {line}]",
                            "preview":  f"{stype} at line {line}",
                            "source":   source,
                            "line":     line,
                            "severity": "critical" if stype in HIGH_SEVERITY else "high",
                            "tool":     "detect-secrets",
                            "hash":     key,
                        })
        finally:
            try: os.unlink(tf_name)
            except: pass

        return findings

    except ImportError:
        log.debug("[secrets] detect-secrets not installed")
        return []
    except Exception as e:
        log.debug(f"[secrets] detect-secrets: {e}")
        return []


# ── Layer 3: TruffleHog ──────────────────────────────────────────────────────

def scan_trufflehog_content(content: str, source: str = "") -> List[Dict]:
    """
    Run TruffleHog on content (filesystem mode).
    Supports: git history, high-entropy, regex, and 700+ detector types.
    """
    truf = shutil.which("trufflehog")
    if not truf:
        log.debug("[secrets] trufflehog not installed")
        return []

    findings = []
    seen     = set()

    with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as tf:
        tf.write(content)
        tf_name = tf.name

    try:
        # TruffleHog filesystem scan (the pip version uses this CLI)
        r = subprocess.run(
            [truf, "--json", tf_name],
            capture_output=True, text=True, timeout=30
        )

        # Parse JSONL output
        for line in (r.stdout + r.stderr).splitlines():
            line = line.strip()
            if not line or not line.startswith("{"):
                continue
            try:
                item = json.loads(line)
                secret_type = item.get("stringsFound", [""])[0] if item.get("stringsFound") else item.get("reason","")
                val  = str(item.get("stringsFound",[""])[0] if item.get("stringsFound") else "")[:80]
                key  = hashlib.md5(f"th:{secret_type}:{val[:40]}".encode()).hexdigest()
                if key in seen or not val: continue
                seen.add(key)
                findings.append({
                    "type":     secret_type or "Secret",
                    "value":    val,
                    "preview":  val[:50],
                    "source":   source,
                    "severity": "critical",
                    "tool":     "trufflehog",
                    "hash":     key,
                    "raw":      item,
                })
            except json.JSONDecodeError:
                continue
    except subprocess.TimeoutExpired:
        log.debug("[secrets] trufflehog timed out")
    except Exception as e:
        log.debug(f"[secrets] trufflehog: {e}")
    finally:
        try: os.unlink(tf_name)
        except: pass

    return findings


def scan_trufflehog_git(repo_url: str) -> List[Dict]:
    """Scan a git repository URL with TruffleHog for secret history."""
    truf = shutil.which("trufflehog")
    if not truf:
        return []

    findings = []
    seen     = set()

    try:
        r = subprocess.run(
            [truf, "--json", "--regex", "--entropy=False", repo_url],
            capture_output=True, text=True, timeout=120
        )

        for line in r.stdout.splitlines():
            if not line.strip().startswith("{"): continue
            try:
                item = json.loads(line)
                strings = item.get("stringsFound", [])
                for s in strings[:5]:
                    key = hashlib.md5(f"th_git:{s[:40]}".encode()).hexdigest()
                    if key in seen: continue
                    seen.add(key)
                    findings.append({
                        "type":     item.get("reason", "Secret"),
                        "value":    s[:80],
                        "preview":  s[:50],
                        "source":   repo_url,
                        "commit":   item.get("commitHash",""),
                        "branch":   item.get("branch",""),
                        "severity": "critical",
                        "tool":     "trufflehog",
                        "hash":     key,
                    })
            except: continue
    except subprocess.TimeoutExpired:
        log.warning("[secrets] trufflehog git scan timed out")
    except Exception as e:
        log.debug(f"[secrets] trufflehog git: {e}")

    return findings


# ── Layer 4: Gitleaks ────────────────────────────────────────────────────────

def scan_gitleaks_content(content: str, source: str = "") -> List[Dict]:
    """Run gitleaks on content (no-git mode)."""
    gl = shutil.which("gitleaks")
    if not gl:
        return []

    findings = []
    seen     = set()

    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tf:
        tf.write(content)
        tf_name = tf.name

    report_f = tempfile.mktemp(suffix='.json')

    try:
        subprocess.run(
            [gl, "detect", "--source", tf_name, "--report-format", "json",
             "--report-path", report_f, "--no-banner", "--no-git"],
            capture_output=True, text=True, timeout=30
        )
        if os.path.exists(report_f):
            try:
                data = json.loads(open(report_f).read())
                items = data if isinstance(data, list) else []
                for item in items:
                    val = item.get("Secret", "")[:80]
                    key = hashlib.md5(f"gl:{item.get('RuleID','')}:{val[:40]}".encode()).hexdigest()
                    if key in seen: continue
                    seen.add(key)
                    findings.append({
                        "type":     item.get("RuleID", "Secret"),
                        "value":    val,
                        "preview":  val[:50],
                        "source":   source,
                        "line":     item.get("StartLine", 0),
                        "severity": "critical" if item.get("RuleID","") in HIGH_SEVERITY else "high",
                        "tool":     "gitleaks",
                        "hash":     key,
                    })
            except: pass
    except subprocess.TimeoutExpired:
        log.debug("[secrets] gitleaks timed out")
    except Exception as e:
        log.debug(f"[secrets] gitleaks: {e}")
    finally:
        try: os.unlink(tf_name)
        except: pass
        try: os.unlink(report_f)
        except: pass

    return findings


def scan_gitleaks_repo(repo_url: str, depth: int = 100) -> List[Dict]:
    """Clone and scan git repository with gitleaks."""
    gl = shutil.which("gitleaks")
    if not gl:
        return []

    findings = []
    seen     = set()
    tmp_dir  = tempfile.mkdtemp(prefix="gl_repo_")

    try:
        # Clone (shallow)
        subprocess.run(
            ["git", "clone", "--depth", str(depth), repo_url, tmp_dir],
            capture_output=True, text=True, timeout=120
        )

        report_f = tempfile.mktemp(suffix='.json')
        subprocess.run(
            [gl, "detect", "--source", tmp_dir, "--report-format", "json",
             "--report-path", report_f, "--no-banner"],
            capture_output=True, text=True, timeout=120
        )

        if os.path.exists(report_f):
            try:
                data = json.loads(open(report_f).read())
                items = data if isinstance(data, list) else []
                for item in items[:200]:  # cap at 200
                    val = item.get("Secret", "")[:80]
                    key = hashlib.md5(f"gl_git:{val[:40]}".encode()).hexdigest()
                    if key in seen: continue
                    seen.add(key)
                    findings.append({
                        "type":     item.get("RuleID", "Secret"),
                        "value":    val,
                        "preview":  val[:50],
                        "source":   repo_url,
                        "file":     item.get("File",""),
                        "line":     item.get("StartLine",0),
                        "commit":   item.get("Commit",""),
                        "severity": "critical",
                        "tool":     "gitleaks",
                        "hash":     key,
                    })
            except: pass
    except Exception as e:
        log.debug(f"[secrets] gitleaks repo: {e}")
    finally:
        import shutil as _sh
        try: _sh.rmtree(tmp_dir)
        except: pass
        try: os.unlink(report_f)
        except: pass

    return findings


# ── Full pipeline: URL → all scanners ────────────────────────────────────────

def scan_url(url: str) -> Dict:
    """
    Fetch URL content and run all 4 secret scanners against it.
    Returns deduplicated findings with tool attribution.
    """
    content = _fetch(url)
    if not content:
        return {"url": url, "findings": [], "error": "fetch failed", "bytes": 0}

    all_findings = []
    seen_hashes  = set()

    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as exe:
        futs = {
            exe.submit(scan_builtin,        content, url): "builtin",
            exe.submit(scan_detect_secrets, content, url): "detect-secrets",
            exe.submit(scan_trufflehog_content, content, url): "trufflehog",
        }
        for fut, tool in futs.items():
            try:
                results = fut.result(timeout=30)
                for r in results:
                    h = r.get("hash","") or hashlib.md5(f"{r['type']}:{r['value'][:30]}".encode()).hexdigest()
                    if h not in seen_hashes:
                        seen_hashes.add(h)
                        all_findings.append(r)
                log.info(f"[secrets] {tool}: {len(results)} findings from {url}")
            except Exception as e:
                log.debug(f"[secrets] {tool}: {e}")

    # Sort by severity
    sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    all_findings.sort(key=lambda x: sev_order.get(x.get("severity","low"), 3))

    return {
        "url":      url,
        "bytes":    len(content),
        "findings": all_findings,
        "count":    len(all_findings),
        "critical": sum(1 for f in all_findings if f.get("severity")=="critical"),
        "tools":    list(set(f.get("tool","") for f in all_findings)),
    }


def scan_domain_js(domain: str, js_urls: List[str] = None,
                   max_files: int = 100) -> Dict:
    """
    Elite JS + Secret scanning pipeline:
    1. Collect JS URLs (from stored endpoints)
    2. Run all 4 scanners against each file
    3. Deduplicate and rank findings
    """
    if not js_urls:
        js_urls = []

    results = {
        "domain":   domain,
        "files":    0,
        "findings": [],
        "critical": 0,
        "high":     0,
        "by_type":  {},
        "by_tool":  {},
        "js_urls":  js_urls[:max_files],
    }

    seen_hashes = set()

    def _scan_one(url):
        r = scan_url(url)
        results["files"] += 1
        for f in r.get("findings", []):
            h = f.get("hash","") or hashlib.md5(f"{f['type']}:{f['value'][:30]}".encode()).hexdigest()
            if h in seen_hashes: return
            seen_hashes.add(h)
            results["findings"].append(f)
            results["by_type"][f["type"]] = results["by_type"].get(f["type"],0) + 1
            results["by_tool"][f.get("tool","")] = results["by_tool"].get(f.get("tool",""),0) + 1

    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as exe:
        list(exe.map(_scan_one, js_urls[:max_files]))

    sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    results["findings"].sort(key=lambda x: sev_order.get(x.get("severity","low"), 3))
    results["critical"] = sum(1 for f in results["findings"] if f.get("severity")=="critical")
    results["high"]     = sum(1 for f in results["findings"] if f.get("severity")=="high")

    log.info(f"[secrets] {domain}: {len(results['findings'])} secrets in {results['files']} JS files")
    return results


def get_engine_status() -> Dict:
    """Return status of all secret scanning tools."""
    return {
        "builtin":         True,
        "builtin_patterns": len(BUILTIN_PATTERNS),
        "detect_secrets":  bool(shutil.which("detect-secrets")),
        "trufflehog":      bool(shutil.which("trufflehog")),
        "gitleaks":        bool(shutil.which("gitleaks")),
        "secret_hunter":   (APP_ROOT / "secret_hunter").exists() and os.access(APP_ROOT / "secret_hunter", os.X_OK),
        "total_active":    sum([
            True,
            bool(shutil.which("detect-secrets")),
            bool(shutil.which("trufflehog")),
            bool(shutil.which("gitleaks")),
            (APP_ROOT / "secret_hunter").exists(),
        ]),
    }
