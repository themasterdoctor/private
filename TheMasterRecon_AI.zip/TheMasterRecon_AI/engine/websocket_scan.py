"""
BugScan ELITE — WebSocket Security Scanner
Tests WebSocket endpoints for:
- Authentication bypass (no token check on WS upgrade)
- Origin validation bypass (cross-origin WS)
- Message injection / XSS via WS
- SQLi / command injection via WS messages
- Information disclosure via WS
"""
import re, time, logging, urllib.parse, urllib.request, ssl, json, socket
import threading, base64, hashlib, struct
from typing import List, Dict, Optional

log = logging.getLogger("elite.websocket")


def _find_ws_endpoints(html: str, base_url: str) -> List[str]:
    """Extract WebSocket URLs from HTML/JS source."""
    ws_urls = set()
    patterns = [
        r'new\s+WebSocket\s*\(\s*["\']([^"\']+)["\']',
        r'WebSocket\s*\(\s*["\']([^"\']+)["\']',
        r'["\']wss?://[^"\']+["\']',
        r'wsUrl\s*[=:]\s*["\']([^"\']+)["\']',
        r'socketUrl\s*[=:]\s*["\']([^"\']+)["\']',
        r'ws_url\s*[=:]\s*["\']([^"\']+)["\']',
        r'websocket[_\-]?url\s*[=:]\s*["\']([^"\']+)["\']',
    ]
    for p in patterns:
        for m in re.finditer(p, html, re.I):
            u = m.group(1) if m.lastindex else m.group(0).strip("\"'")
            if u.startswith("ws://") or u.startswith("wss://"):
                ws_urls.add(u)
            elif u.startswith("/"):
                base_parsed = urllib.parse.urlparse(base_url)
                scheme = "wss" if base_parsed.scheme == "https" else "ws"
                ws_urls.add(f"{scheme}://{base_parsed.netloc}{u}")
    return list(ws_urls)


def _ws_handshake(host: str, port: int, path: str, use_ssl: bool,
                  origin: str = "", extra_headers: dict = None,
                  timeout: int = 8) -> Optional[socket.socket]:
    """
    Perform WebSocket handshake manually.
    Returns connected socket or None.
    """
    try:
        key = base64.b64encode(b"BugScanELITE12345"[:16]).decode()
        headers = [
            f"GET {path} HTTP/1.1",
            f"Host: {host}:{port}",
            "Upgrade: websocket",
            "Connection: Upgrade",
            f"Sec-WebSocket-Key: {key}",
            "Sec-WebSocket-Version: 13",
        ]
        if origin:
            headers.append(f"Origin: {origin}")
        if extra_headers:
            for k, v in extra_headers.items():
                headers.append(f"{k}: {v}")
        headers.append("\r\n")
        request = "\r\n".join(headers)

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)

        if use_ssl:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode    = ssl.CERT_NONE
            sock = ctx.wrap_socket(sock, server_hostname=host)

        sock.connect((host, port))
        sock.sendall(request.encode())

        response = b""
        while b"\r\n\r\n" not in response:
            chunk = sock.recv(4096)
            if not chunk: break
            response += chunk
            if len(response) > 16384: break

        if b"101 Switching Protocols" in response:
            return sock
        sock.close()
        return None
    except Exception as e:
        log.debug(f"ws handshake {host}:{port}{path}: {e}")
        return None


def _ws_send(sock: socket.socket, message: str) -> Optional[str]:
    """Send WebSocket text frame and read response."""
    try:
        data  = message.encode("utf-8")
        frame = bytearray()
        frame.append(0x81)  # FIN + text opcode
        mask  = b"\x89\xf3\x21\x4a"  # static mask

        if len(data) < 126:
            frame.append(0x80 | len(data))
        elif len(data) < 65536:
            frame.append(0x80 | 126)
            frame.extend(struct.pack(">H", len(data)))
        else:
            frame.append(0x80 | 127)
            frame.extend(struct.pack(">Q", len(data)))

        frame.extend(mask)
        masked = bytearray(b ^ mask[i%4] for i,b in enumerate(data))
        frame.extend(masked)

        sock.sendall(bytes(frame))
        sock.settimeout(5)

        response = b""
        try:
            response = sock.recv(16384)
        except socket.timeout:
            pass

        if response:
            # Parse WebSocket frame
            if len(response) >= 2:
                fin_opcode = response[0]
                payload_len = response[1] & 0x7f
                masked_bit  = (response[1] & 0x80) >> 7
                offset = 2
                if payload_len == 126: offset += 2; payload_len = struct.unpack(">H", response[2:4])[0]
                elif payload_len == 127: offset += 8
                if masked_bit: offset += 4
                payload = response[offset:offset+payload_len]
                return payload.decode("utf-8","ignore")
        return ""
    except Exception as e:
        log.debug(f"ws send: {e}")
        return None


def check_websocket(targets: List[str], endpoints: List[str],
                    session_cookies: str = "") -> List[Dict]:
    """Main WebSocket vulnerability scanner."""
    findings = []

    # Discover WebSocket endpoints from HTML/JS
    ws_endpoints = set()

    # Common WS paths to probe
    ws_paths = [
        "/ws", "/websocket", "/socket", "/ws/", "/socket.io/",
        "/cable", "/actioncable", "/notifications/ws",
        "/chat/ws", "/live", "/realtime", "/stream",
        "/api/ws", "/api/websocket", "/api/socket",
        "/hub", "/signalr", "/sockjs", "/sockjs-node",
    ]

    def _ctx2():
        c = ssl.create_default_context()
        c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
        return c

    for target in targets[:30]:
        base   = target.rstrip("/")
        parsed = urllib.parse.urlparse(base)
        host   = parsed.hostname
        port   = parsed.port or (443 if parsed.scheme == "https" else 80)
        ssl_on = parsed.scheme == "https"

        # Fetch main page and JS to find WS URLs
        try:
            req = urllib.request.Request(base,
                headers={"User-Agent":"Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=8, context=_ctx2()) as r:
                html = r.read(65536).decode("utf-8","ignore")
            for ws_url in _find_ws_endpoints(html, base):
                ws_endpoints.add(ws_url)
        except: pass

        # Also probe common WS paths
        for path in ws_paths:
            scheme = "wss" if ssl_on else "ws"
            ws_endpoints.add(f"{scheme}://{host}:{port}{path}")

    # Also extract from discovered endpoints
    for ep in endpoints[:200]:
        try:
            req = urllib.request.Request(ep,
                headers={"User-Agent":"Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=5, context=_ctx2()) as r:
                content = r.read(32768).decode("utf-8","ignore")
                ep_parsed = urllib.parse.urlparse(ep)
                for ws_url in _find_ws_endpoints(content, ep):
                    ws_endpoints.add(ws_url)
        except: pass

    log.info(f"[websocket] testing {len(ws_endpoints)} WS endpoints")

    for ws_url in list(ws_endpoints)[:50]:
        try:
            parsed = urllib.parse.urlparse(ws_url)
            host   = parsed.hostname
            if not host: continue
            port   = parsed.port or (443 if parsed.scheme == "wss" else 80)
            path   = parsed.path or "/"
            ssl_on = parsed.scheme == "wss"

            # ── 1. No-auth connection ─────────────────────────────────────
            sock = _ws_handshake(host, port, path, ssl_on)
            if not sock:
                continue

            log.info(f"[websocket] connected: {ws_url}")

            # ── 2. Origin validation bypass ───────────────────────────────
            evil_sock = _ws_handshake(host, port, path, ssl_on,
                                       origin="https://evil.com")
            if evil_sock:
                findings.append({
                    "type": "websocket","bug":"cors","severity":"high",
                    "url":  ws_url,
                    "name": "WebSocket Missing Origin Validation",
                    "details": {
                        "description": f"WebSocket at {ws_url} accepts connections from any origin (evil.com connected successfully).",
                        "poc": f"new WebSocket('{ws_url}')",
                        "impact": "Cross-site WebSocket hijacking — attacker can read/write messages from victim's session.",
                        "remediation": "Validate the Origin header against a strict whitelist on WebSocket upgrade.",
                    },
                    "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
                })
                evil_sock.close()

            # ── 3. XSS via WebSocket message ──────────────────────────────
            xss_payloads = [
                '{"message":"<img src=x onerror=alert(1)>"}',
                '{"content":"<script>alert(1)</script>"}',
                '{"data":"<svg onload=alert(1)>"}',
                "<img src=x onerror=alert(1)>",
                '{"type":"message","data":"<img src=x onerror=alert(1)>"}',
            ]
            for payload in xss_payloads[:3]:
                resp = _ws_send(sock, payload)
                if resp and "<img src=x" in resp:
                    findings.append({
                        "type":"websocket","bug":"xss","severity":"high",
                        "url":ws_url,
                        "name":"XSS via WebSocket Message",
                        "details":{
                            "description":f"XSS payload reflected in WebSocket response.",
                            "payload":payload,
                            "response":resp[:200],
                            "poc":f"ws = new WebSocket('{ws_url}'); ws.send('{payload}')",
                            "impact":"Persistent XSS if message is stored and rendered to other users.",
                            "remediation":"Sanitize all WebSocket message content before processing or broadcasting.",
                        },
                        "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ"),
                    })
                    break

            # ── 4. Information disclosure via WS ──────────────────────────
            info_probes = [
                '{"type":"ping"}', '{"action":"status"}',
                '{"cmd":"help"}',  '{"op":"list"}',
                '{"type":"subscribe","channel":"all"}',
            ]
            for probe in info_probes:
                resp = _ws_send(sock, probe)
                if resp and len(resp) > 20:
                    sensitive = any(kw in resp.lower() for kw in
                        ["email","password","token","secret","key","user","admin","db"])
                    if sensitive:
                        findings.append({
                            "type":"websocket","bug":"expose","severity":"medium",
                            "url":ws_url,
                            "name":"Sensitive Data via WebSocket",
                            "details":{
                                "description":f"WebSocket returns sensitive information in response to: {probe}",
                                "probe":probe,
                                "response":resp[:300],
                                "poc":f"ws=new WebSocket('{ws_url}'); ws.onopen=()=>ws.send('{probe}')",
                                "impact":"Information disclosure via WebSocket.",
                                "remediation":"Restrict WebSocket message handling to authorized actions only.",
                            },
                            "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ"),
                        })
                        break

            # ── 5. SQLi via WebSocket ─────────────────────────────────────
            sqli_probes = [
                '{"id":"1\'","action":"get"}',
                '{"query":"1 OR 1=1--","type":"search"}',
                '{"user_id":"1 UNION SELECT 1,2,3--"}',
            ]
            sql_errors = ["SQL","syntax","mysql","postgresql","sqlite","ORA-","SQLSTATE"]
            for probe in sqli_probes:
                resp = _ws_send(sock, probe)
                if resp and any(e.lower() in resp.lower() for e in sql_errors):
                    findings.append({
                        "type":"websocket","bug":"sqli","severity":"critical",
                        "url":ws_url,
                        "name":"SQL Injection via WebSocket",
                        "details":{
                            "description":f"SQL error triggered via WebSocket message: {probe}",
                            "payload":probe,
                            "error_response":resp[:300],
                            "poc":f"ws=new WebSocket('{ws_url}'); ws.onopen=()=>ws.send('{probe}')",
                            "impact":"Full database access via WebSocket SQL injection.",
                            "remediation":"Use parameterized queries for all WebSocket message handlers.",
                        },
                        "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ"),
                    })
                    break

            sock.close()

        except Exception as e:
            log.debug(f"ws test {ws_url}: {e}")

    log.info(f"[websocket] done: {len(findings)} findings")
    return findings
