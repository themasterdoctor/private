"""
BugScan ELITE — Auto-Retest Engine
Automatically retests findings after developer claims a fix.
Marks findings as verified-fixed, regressed, or still-vulnerable.
"""
import time, logging, re, json, urllib.request, urllib.parse, ssl
from typing import List, Dict, Optional, Tuple

log = logging.getLogger("elite.retest")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _req(url, method="GET", headers=None, data=None, timeout=12):
    try:
        h = {"User-Agent":"Mozilla/5.0 BugScanELITE-Retest/1.0","Accept":"*/*"}
        if headers: h.update(headers)
        body = data.encode() if isinstance(data,str) else data
        req  = urllib.request.Request(url, data=body, headers=h, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status, dict(r.headers), r.read(32768).decode("utf-8","ignore")
    except urllib.error.HTTPError as e:
        try: return e.code, dict(e.headers), e.read(4096).decode("utf-8","ignore")
        except: return e.code, {}, ""
    except: return None

STATUS_FIXED        = "fixed"
STATUS_VULNERABLE   = "still_vulnerable"
STATUS_REGRESSED    = "regressed"
STATUS_INCONCLUSIVE = "inconclusive"


class RetestEngine:
    """Retests individual findings to verify fixes."""

    def retest(self, finding: Dict) -> Dict:
        """
        Retest a single finding. Returns retest result dict.
        """
        bug     = finding.get("bug","")
        url     = finding.get("url","")
        details = finding.get("details",{})
        result  = {
            "finding_id": f"{bug}:{url}",
            "bug":        bug,
            "url":        url,
            "status":     STATUS_INCONCLUSIVE,
            "retested_at":time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "evidence":   [],
            "message":    "",
        }

        if not url:
            result["message"] = "No URL to retest"
            return result

        try:
            if bug == "cors":
                result.update(self._retest_cors(url, details))
            elif bug == "expose":
                result.update(self._retest_expose(url, details))
            elif bug == "actuator":
                result.update(self._retest_actuator(url, details))
            elif bug == "xss":
                result.update(self._retest_xss(url, details))
            elif bug == "sqli":
                result.update(self._retest_sqli(url, details))
            elif bug == "ssrf":
                result.update(self._retest_ssrf(url, details))
            elif bug == "redirect":
                result.update(self._retest_redirect(url, details))
            elif bug == "idor":
                result.update(self._retest_idor(url, details))
            elif bug == "takeover":
                result.update(self._retest_takeover(url, details))
            elif bug == "jsleak":
                result.update(self._retest_jsleak(url, details))
            elif bug in ("misconfig","panels","graphql"):
                result.update(self._retest_generic_get(url, details))
            else:
                result.update(self._retest_generic_get(url, details))
        except Exception as e:
            result["message"] = f"Retest error: {e}"
            log.warning(f"[retest] {bug} @ {url}: {e}")

        log.info(f"[retest] {bug} @ {url[:60]}: {result['status']}")
        return result

    def _retest_cors(self, url, details) -> Dict:
        origin = details.get("origin_tested","https://evil.com")
        r = _req(url, headers={"Origin": origin})
        if not r: return {"status":STATUS_INCONCLUSIVE,"message":"No response"}
        status, hdrs, body = r
        acao = hdrs.get("Access-Control-Allow-Origin","")
        acac = hdrs.get("Access-Control-Allow-Credentials","")
        if acao == origin or (acao == "*" and acac.lower() == "true"):
            return {
                "status":  STATUS_VULNERABLE,
                "message": f"CORS still misconfigured: ACAO={acao}",
                "evidence":[f"Access-Control-Allow-Origin: {acao}"],
            }
        return {
            "status":  STATUS_FIXED,
            "message": f"CORS fixed. ACAO now: '{acao}'",
            "evidence":[f"Origin '{origin}' no longer reflected"],
        }

    def _retest_expose(self, url, details) -> Dict:
        r = _req(url)
        if not r: return {"status":STATUS_INCONCLUSIVE}
        status, hdrs, body = r
        preview = details.get("preview","")
        sigs    = details.get("signatures",[])
        if status == 200:
            # Check if the sensitive content is still there
            checks = sigs if sigs else [preview[:50]] if preview else []
            for sig in checks:
                if sig and sig.lower() in body.lower():
                    return {
                        "status":  STATUS_VULNERABLE,
                        "message": f"File still accessible with sensitive content",
                        "evidence":[f"HTTP {status}, signature '{sig[:40]}' found"],
                    }
            return {
                "status":  STATUS_INCONCLUSIVE,
                "message": f"File accessible (HTTP 200) but sensitive content not confirmed",
                "evidence":[f"HTTP {status}, {len(body)} bytes"],
            }
        elif status in (401, 403, 404):
            return {
                "status":  STATUS_FIXED,
                "message": f"File now returns HTTP {status} — access blocked",
                "evidence":[f"HTTP {status}"],
            }
        return {"status":STATUS_INCONCLUSIVE,"message":f"HTTP {status}"}

    def _retest_actuator(self, url, details) -> Dict:
        r = _req(url)
        if not r: return {"status":STATUS_INCONCLUSIVE}
        status, hdrs, body = r
        if status == 200 and any(k in body for k in
                ["_links","beans","env","health","metrics","mappings"]):
            return {
                "status":  STATUS_VULNERABLE,
                "message": "Actuator endpoint still exposed",
                "evidence":[f"HTTP 200, actuator data present"],
            }
        return {
            "status":  STATUS_FIXED,
            "message": f"Actuator endpoint now returns HTTP {status}",
            "evidence":[f"HTTP {status}"],
        }

    def _retest_xss(self, url, details) -> Dict:
        param   = details.get("param","")
        payload = details.get("payload","<script>alert(1)</script>")
        if not param or "=" not in url:
            return {"status":STATUS_INCONCLUSIVE,"message":"No param to retest"}
        try:
            parsed = urllib.parse.urlparse(url)
            qs     = urllib.parse.parse_qs(parsed.query)
            if param not in qs:
                return {"status":STATUS_INCONCLUSIVE,"message":f"Param '{param}' not in URL"}
            nq   = dict(qs); nq[param] = [payload]
            test = urllib.parse.urlunparse(parsed._replace(
                query=urllib.parse.urlencode(nq,doseq=True)))
            r = _req(test)
            if not r: return {"status":STATUS_INCONCLUSIVE}
            status, hdrs, body = r
            csp = hdrs.get("Content-Security-Policy","")
            if payload in body:
                if csp:
                    return {
                        "status":  STATUS_INCONCLUSIVE,
                        "message": "Payload reflected but CSP may mitigate",
                        "evidence":[f"CSP: {csp[:80]}"],
                    }
                return {
                    "status":  STATUS_VULNERABLE,
                    "message": f"XSS payload still reflected in param '{param}'",
                    "evidence":[f"Payload found in HTTP {status} response"],
                }
            return {
                "status":  STATUS_FIXED,
                "message": f"XSS payload no longer reflected in '{param}'",
                "evidence":["Payload not present in response"],
            }
        except Exception as e:
            return {"status":STATUS_INCONCLUSIVE,"message":str(e)}

    def _retest_sqli(self, url, details) -> Dict:
        param = details.get("param","")
        if not param:
            return {"status":STATUS_INCONCLUSIVE,"message":"No param to retest"}
        try:
            parsed = urllib.parse.urlparse(url)
            qs     = urllib.parse.parse_qs(parsed.query)
            # Test with basic error payload
            nq   = dict(qs); nq[param] = ["'"]
            test = urllib.parse.urlunparse(parsed._replace(
                query=urllib.parse.urlencode(nq,doseq=True)))
            r = _req(test)
            if not r: return {"status":STATUS_INCONCLUSIVE}
            status, hdrs, body = r
            sql_errors = ["SQL syntax","mysql_fetch","ORA-","SQLSTATE",
                         "Warning: mysql","pg_query","sqlite_","syntax error"]
            if any(e.lower() in body.lower() for e in sql_errors):
                return {
                    "status":  STATUS_VULNERABLE,
                    "message": f"SQLi still present in '{param}' — DB error visible",
                    "evidence":[f"SQL error in HTTP {status} response"],
                }
            return {
                "status":  STATUS_FIXED,
                "message": f"No SQL errors in '{param}' — appears fixed",
                "evidence":["No SQL errors detected"],
            }
        except Exception as e:
            return {"status":STATUS_INCONCLUSIVE,"message":str(e)}

    def _retest_ssrf(self, url, details) -> Dict:
        param = details.get("param","url")
        try:
            parsed = urllib.parse.urlparse(url)
            qs     = urllib.parse.parse_qs(parsed.query)
            if param not in qs:
                return {"status":STATUS_INCONCLUSIVE}
            nq   = dict(qs); nq[param] = ["http://169.254.169.254/latest/meta-data/"]
            test = urllib.parse.urlunparse(parsed._replace(
                query=urllib.parse.urlencode(nq,doseq=True)))
            r = _req(test, timeout=8)
            if r and r[0] == 200:
                if any(s in r[2] for s in ["ami-id","instance-id","hostname"]):
                    return {
                        "status":  STATUS_VULNERABLE,
                        "message": "SSRF still exploitable — metadata accessible",
                        "evidence":[f"AWS metadata in response"],
                    }
            return {
                "status":  STATUS_FIXED,
                "message": "SSRF payload no longer returns internal data",
                "evidence":["Metadata endpoint not accessible"],
            }
        except Exception as e:
            return {"status":STATUS_INCONCLUSIVE,"message":str(e)}

    def _retest_redirect(self, url, details) -> Dict:
        param = details.get("param","url")
        try:
            parsed = urllib.parse.urlparse(url)
            qs     = urllib.parse.parse_qs(parsed.query)
            nq     = dict(qs); nq[param] = ["https://evil.com"]
            test   = urllib.parse.urlunparse(parsed._replace(
                query=urllib.parse.urlencode(nq,doseq=True)))
            r = _req(test)
            if r:
                loc = r[1].get("Location","")
                if "evil.com" in loc:
                    return {
                        "status":  STATUS_VULNERABLE,
                        "message": f"Open redirect still works → {loc[:60]}",
                        "evidence":[f"Location: {loc[:80]}"],
                    }
            return {
                "status":  STATUS_FIXED,
                "message": "Open redirect blocked — evil.com not in Location header",
                "evidence":["Redirect to external domain prevented"],
            }
        except Exception as e:
            return {"status":STATUS_INCONCLUSIVE,"message":str(e)}

    def _retest_idor(self, url, details) -> Dict:
        orig_id = details.get("original_id","")
        test_id = details.get("test_id","")
        if not orig_id or not test_id:
            return {"status":STATUS_INCONCLUSIVE,"message":"No IDs to retest"}
        test_url = url.replace(str(orig_id), str(test_id), 1)
        r1 = _req(url)
        r2 = _req(test_url)
        if r1 and r2:
            if r2[0] == 200 and r1[2] != r2[2] and len(r2[2]) > 100:
                return {
                    "status":  STATUS_VULNERABLE,
                    "message": f"IDOR still present — ID {test_id} returns data",
                    "evidence":[f"HTTP 200, {len(r2[2])} bytes"],
                }
            elif r2[0] in (401,403):
                return {
                    "status":  STATUS_FIXED,
                    "message": f"IDOR fixed — ID {test_id} now returns HTTP {r2[0]}",
                    "evidence":[f"HTTP {r2[0]} — access denied"],
                }
        return {"status":STATUS_INCONCLUSIVE,"message":"Could not determine fix status"}

    def _retest_takeover(self, url, details) -> Dict:
        sig = details.get("signature","")
        r   = _req(url)
        if not r: return {"status":STATUS_INCONCLUSIVE}
        status, hdrs, body = r
        if sig and sig.lower() in body.lower():
            return {
                "status":  STATUS_VULNERABLE,
                "message": f"Subdomain still shows takeover signature",
                "evidence":[f"Signature '{sig[:40]}' still present"],
            }
        return {
            "status":  STATUS_FIXED,
            "message": "Takeover signature no longer present",
            "evidence":[f"HTTP {status}, signature not found"],
        }

    def _retest_jsleak(self, url, details) -> Dict:
        secret_type = details.get("secret_type","")
        preview     = details.get("preview","")[:40]
        r = _req(url)
        if not r: return {"status":STATUS_INCONCLUSIVE}
        if preview and preview in r[2]:
            return {
                "status":  STATUS_VULNERABLE,
                "message": f"{secret_type} still present in JS file",
                "evidence":[f"Secret value still in response"],
            }
        return {
            "status":  STATUS_FIXED,
            "message": f"{secret_type} removed from JS bundle",
            "evidence":["Secret no longer found in response"],
        }

    def _retest_generic_get(self, url, details) -> Dict:
        r = _req(url)
        if not r:
            return {"status":STATUS_INCONCLUSIVE,"message":"No response"}
        status, hdrs, body = r
        preview = details.get("preview","")[:50]
        if status == 200 and preview and preview.lower() in body.lower():
            return {
                "status":  STATUS_VULNERABLE,
                "message": f"Endpoint still returns sensitive content",
                "evidence":[f"HTTP {status}"],
            }
        if status in (401,403,404):
            return {
                "status":  STATUS_FIXED,
                "message": f"Endpoint now returns HTTP {status}",
                "evidence":[f"HTTP {status} — access controlled"],
            }
        return {
            "status":  STATUS_INCONCLUSIVE,
            "message": f"HTTP {status} — manual verification needed",
            "evidence":[f"HTTP {status}, {len(body)} bytes"],
        }


def retest_all(findings: List[Dict], only_bugs: List[str] = None) -> List[Dict]:
    """Retest all findings (or filtered subset). Returns retest results."""
    engine  = RetestEngine()
    results = []
    targets = findings if not only_bugs else [
        f for f in findings if f.get("bug","") in only_bugs
    ]
    for finding in targets:
        try:
            r = engine.retest(finding)
            results.append(r)
            time.sleep(0.5)  # gentle throttle
        except Exception as e:
            log.error(f"retest {finding.get('url','')}: {e}")
    return results


def retest_summary(results: List[Dict]) -> Dict:
    """Summarize retest results."""
    fixed  = [r for r in results if r["status"] == STATUS_FIXED]
    vuln   = [r for r in results if r["status"] == STATUS_VULNERABLE]
    incon  = [r for r in results if r["status"] == STATUS_INCONCLUSIVE]
    return {
        "total":        len(results),
        "fixed":        len(fixed),
        "still_vuln":   len(vuln),
        "inconclusive": len(incon),
        "fix_rate":     f"{int(len(fixed)/len(results)*100)}%" if results else "0%",
        "results":      results,
    }
