"""
BugScan ELITE — Real-time Notification Engine

Professional analyst triage alerts only.
Rules enforced:
  - No payloads / exploit text in notifications
  - No raw URL parameters exposed
  - Confidence gating: min 70 to fire
  - Severity routing: HIGH/CRITICAL → Discord+Telegram, MEDIUM → Slack only
  - Fingerprint-based deduplication (1 alert per vuln-type+path per hour)
  - All findings stored to DB regardless of notification status
"""

import os, re, json, time, hashlib, logging, urllib.request, urllib.parse, ssl, threading
from typing import Optional, Dict, List, Tuple

log = logging.getLogger("elite.notify")

# ── HTTP helper ───────────────────────────────────────────────────────────────
def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _post(url: str, payload: dict, headers: dict = None) -> bool:
    """
    TASK 5 — Non-blocking HTTP POST with hard timeout.
    Runs in calling context but with timeout enforced.
    Never raises — returns False on any failure.
    """
    try:
        data = json.dumps(payload).encode()
        h = {"Content-Type": "application/json", "User-Agent": "BugScanELITE/1.0"}
        if headers: h.update(headers)
        req = urllib.request.Request(url, data=data, headers=h, method="POST")
        # Hard 8-second timeout — never block scan pipeline
        with urllib.request.urlopen(req, timeout=8, context=_ctx()) as r:
            return r.status in (200, 204)
    except Exception as e:
        log.debug(f"notify post {url}: {e}")
        return False

SEV_EMOJI  = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵", "info": "⚪"}
SEV_COLOR  = {"critical": 0xFF0000, "high": 0xFF6600, "medium": 0xFFCC00,
              "low": 0x3399FF, "info": 0x808080}

# Minimum confidence to fire external notification (Discord/Telegram/Slack)
CONFIDENCE_GATE   = int(os.environ.get("NOTIFY_CONFIDENCE_MIN", "75"))
# Deduplication window in seconds
DEDUP_WINDOW      = int(os.environ.get("NOTIFY_DEDUP_WINDOW", "3600"))

# ── Safe URL redaction ────────────────────────────────────────────────────────
_SENSITIVE_PARAMS = re.compile(
    r"\b(token|key|api_?key|auth|secret|password|passwd|jwt|bearer|session"
    r"|access_token|refresh_token|id_token|oauth|nonce|sig|signature|hash"
    r"|csrftoken|csrf|x-auth|authorization)\b",
    re.I
)

def safe_notification_url(url: str) -> str:
    """
    Return a safe URL for notifications — path only, querystring stripped.
    Never exposes tokens, payloads, IDs, or raw params in any form.
    Example: /ecology/charte.php?id=13 → /ecology/charte.php
    """
    if not url:
        return ""
    try:
        # Always strip querystring completely — path only
        if url.startswith("/") or "://" not in url:
            return url.split("?")[0][:200]
        parsed = urllib.parse.urlparse(url)
        path   = (parsed.path or "/").rstrip("/") or "/"
        return f"{parsed.scheme}://{parsed.netloc}{path}"[:200]
    except Exception:
        return url.split("?")[0][:200]

def _safe_desc(desc: str) -> str:
    """
    Remove exploit hints, payloads, and attack syntax from description text.
    Returns a sanitised analyst-friendly summary.

    TASK 6 — Notification Safety:
    Discord/Telegram NEVER contain: payloads, exploit steps, tokens,
    cookies, headers, credentials. Only: summary + confidence + safe path.
    """
    if not desc:
        return ""

    # Hard-blocked: strip entire line if dangerous patterns found
    _HARD_BLOCKED = [
        r"(?i)(password|passwd|token|secret|bearer|jwt|session|cookie|credential)[\s]*[:=][\s]*\S+",
        r"(?i)(payload|exploit|<script|javascript:|union\s+select|exec\(|system\(|eval\()",
        r"169\.254\.169\.254|metadata\.google",
        r"(?i)curl\s+-[a-zA-Z]|wget\s+http",
        r"(?i)/etc/passwd|/etc/shadow|id_rsa",
    ]

    import re as _re
    lines_out = []
    for line in desc.splitlines():
        skip = False
        for pat in _HARD_BLOCKED:
            if _re.search(pat, line):
                skip = True
                break
        if not skip:
            lines_out.append(line)
    desc = "\n".join(lines_out)

    # Strip any line containing known exploit keywords
    bad_patterns = re.compile(
        r"(union\s+select|<script|javascript:|onerror=|onload=|eval\(|alert\("
        r"|payload|sqlmap|exploit|x-forwarded|injection point|proof-of-concept"
        r"|via\s+x-|via\s+(header|param|query|cookie|host|port|proto|method)"
        r"|injection\s+via|poisoning\s+via|bypass\s+via|traversal\s+via"
        r"|'[^']*'|\"[^\"]*\"|\\x[0-9a-f]{2}|%3[cC]|%27|%22"
        r"|reproduce|poc|curl\s+-|wget\s+http|\$\{|{{|<\?php|exec\(|system\("
        r"|;\s*(ls|cat|id|whoami|wget|curl|bash|sh|python)\b"
        r"|&&\s*\w+|\|\s*\w+\s+\w+|`[^`]+`)",
        re.I
    )
    lines = [l for l in desc.split("\n") if not bad_patterns.search(l)]
    clean = " ".join(lines).strip()
    # Collapse whitespace
    clean = re.sub(r"\s{2,}", " ", clean)
    return clean[:300]

def _safe_bug_label(bug: str) -> str:
    """Return an analyst-friendly label without attack specifics."""
    label_map = {
        "xss":             "Cross-Site Scripting signal",
        "sqli":            "SQL Injection signal",
        "lfi":             "Local File Inclusion signal",
        "rfi":             "Remote File Inclusion signal",
        "ssrf":            "Server-Side Request Forgery signal",
        "ssti":            "Template Injection signal",
        "rce":             "Remote Code Execution signal",
        "idor":            "Insecure Direct Object Reference",
        "open_redirect":   "Open Redirect",
        "xxe":             "XXE Injection signal",
        "cors":            "CORS Misconfiguration",
        "cache_poison":    "Cache Poisoning signal",
        "cache_poisoning": "Cache Poisoning signal",
        "smuggling":       "Request Smuggling signal",
        "crlf":            "CRLF Injection signal",
        "log4j":           "Log4Shell signal",
        "prototype":       "Prototype Pollution signal",
        "auth_bypass":     "Authentication Bypass signal",
        "host_header":     "Host Header Injection signal",
        "path_traversal":  "Path Traversal signal",
        "info_disclosure": "Information Disclosure",
        "exposed_env":     "Exposed Environment Data",
        "jwt":             "JWT Weakness signal",
        "csrf":            "CSRF signal",
        "bola":            "Broken Object-Level Auth signal",
        "mass_assignment": "Mass Assignment signal",
        "postmessage_xss": "postMessage XSS signal",
        "dom_xss":         "DOM XSS signal",
        "graphql":         "GraphQL Misconfiguration",
        "actuator":        "Actuator Endpoint Exposure",
        "expose":          "Sensitive Endpoint Exposure",
    }
    key = bug.lower().replace("-", "_").replace(" ", "_")
    return label_map.get(key, f"Security Signal — {bug.upper()[:30]}")

# ── Deduplication ─────────────────────────────────────────────────────────────
def _fingerprint(domain: str, bug: str, url: str) -> str:
    """Stable fingerprint: domain + vuln_type + path (no query string)."""
    path = url.split("?")[0].rstrip("/")
    raw  = f"{domain}|{bug.lower()}|{path}"
    return hashlib.md5(raw.encode()).hexdigest()[:16]

# ── Stats tracking ────────────────────────────────────────────────────────────
_STATS: Dict = {
    "total_sent":               0,
    "deduped":                  0,
    "suppressed_low_confidence": 0,
    "suppressed_low_severity":  0,
    "last_sent":                None,
    "last_error":               None,
}


class NotifyEngine:
    def __init__(self):
        self.slack_webhook   = os.environ.get("SLACK_WEBHOOK", "")
        self.discord_webhook = os.environ.get("DISCORD_WEBHOOK", "")
        self.telegram_token  = os.environ.get("TELEGRAM_TOKEN", "")
        self.telegram_chat   = os.environ.get("TELEGRAM_CHAT_ID", "")
        self.min_severity    = os.environ.get("NOTIFY_MIN_SEV", "high")
        self._queue:  List[Dict] = []
        self._seen:   Dict[str, float] = {}  # fingerprint → last_sent_ts
        self._lock    = threading.Lock()
        self._thread  = threading.Thread(target=self._worker, daemon=True)
        self._thread.start()

    # ── Routing rules ─────────────────────────────────────────────────────────
    def _should_notify(self, sev: str) -> bool:
        order   = ["info","low","medium","high","critical"]
        min_idx = order.index(self.min_severity) if self.min_severity in order else 3
        sev_idx = order.index(sev) if sev in order else 0
        return sev_idx >= min_idx

    def _channels_for_sev(self, sev: str) -> Tuple[bool, bool, bool]:
        """Returns (discord, telegram, slack) based on severity routing."""
        s = sev.lower()
        discord  = s in ("high", "critical")
        telegram = s in ("high", "critical")
        slack    = s in ("medium", "high", "critical")
        return discord, telegram, slack

    # ── Queue ──────────────────────────────────────────────────────────────────
    def _sanitize_for_notify(self, finding: dict) -> dict:
        """
        Strip all sensitive fields — only safe summary fields survive.
        NEVER forwards: payload, poc, headers, cookies, tokens, raw evidence.
        """
        return {
            "bug_type":   finding.get("bug_type", finding.get("bug", "unknown")),
            "severity":   finding.get("severity", "unknown"),
            "url":        safe_notification_url(finding.get("url", "")),
            "confidence": finding.get("confidence", 0),
            "title":      _safe_desc(str(finding.get("title",
                          finding.get("description", "")))[:120]),
        }

    def queue_finding(self, finding: Dict, domain: str):
        sev  = finding.get("severity", "info").lower()
        conf = int(finding.get("confidence", 0) or
                   finding.get("eil_confidence", 0) or 0)
        bug  = (finding.get("bug") or finding.get("type", "")).lower()
        url  = finding.get("url", "")
        verified = bool(finding.get("eil_confirmed") or finding.get("verified"))

        # 0. Severity remap — CRITICAL only if verified + confidence >= 85
        if sev == "critical" and not (verified and conf >= 85):
            sev = "high"
            log.debug(f"[notify] severity downgraded critical→high (not verified or conf<85) conf={conf}")

        # 1. Confidence gate — checked first so log is always correct
        if conf < CONFIDENCE_GATE and not verified:
            _STATS["suppressed_low_confidence"] += 1
            log.info(f"[notify] suppressed_low_confidence severity={sev} confidence={conf}")
            return

        # 2. Severity gate
        if not self._should_notify(sev):
            _STATS["suppressed_low_severity"] += 1
            log.debug(f"[notify] suppressed low_severity sev={sev}")
            return

        # 3. Deduplication — runs before channel check so fingerprints are tracked
        fp = _fingerprint(domain, bug, url)
        with self._lock:
            now  = time.time()
            last = self._seen.get(fp, 0)
            if now - last < DEDUP_WINDOW:
                _STATS["deduped"] += 1
                log.info(f"[notify] deduped finding fingerprint={fp} sev={sev} bug={bug}")
                return
            self._seen[fp] = now

        # 4. Channel check — after dedup so fingerprint is always registered
        if not self.configured:
            log.info(f"[notify] sent severity={sev.upper()} confidence={conf}"
                     f" path={safe_notification_url(url)}"
                     f" (no channel configured — stored internally)")
            return

        with self._lock:
            self._queue.append({
                "finding": finding, "domain": domain,
                "ts": time.strftime("%H:%M UTC"),
                "fp": fp,
            })

    def queue_chain(self, chain: Dict, domain: str):
        """Alert on exploitation chain — sends summary only, no steps."""
        if not self.configured:
            return
        with self._lock:
            self._queue.append({
                "chain": chain, "domain": domain,
                "ts": time.strftime("%H:%M UTC"), "is_chain": True,
            })

    # ── Worker ─────────────────────────────────────────────────────────────────
    def _worker(self):
        while True:
            item = None
            with self._lock:
                if self._queue:
                    item = self._queue.pop(0)
            if item:
                try:
                    if item.get("is_chain"):
                        self._send_chain(item["chain"], item["domain"], item["ts"])
                    else:
                        self._send_finding(item["finding"], item["domain"],
                                           item["ts"], item.get("fp",""))
                except Exception as e:
                    log.debug(f"notify worker: {e}")
                    _STATS["last_error"] = str(e)
            time.sleep(0.5)

    # ── Finding alert — safe format ────────────────────────────────────────────
    def _send_finding(self, f: Dict, domain: str, ts: str, fp: str = ""):
        bug    = (f.get("bug") or f.get("type", "")).lower()
        sev    = f.get("severity", "info").lower()
        conf   = int(f.get("confidence", 0) or f.get("eil_confidence", 0) or 0)
        url    = safe_notification_url(f.get("url", ""))
        label  = _safe_bug_label(bug)
        emoji  = SEV_EMOJI.get(sev, "⚪")

        # Safe status line — no payloads, no params
        status = f"Potentially vulnerable endpoint detected. Stored for analyst review."

        do_discord, do_telegram, do_slack = self._channels_for_sev(sev)

        # ── Discord ──────────────────────────────────────────────────────────
        log.info(f"[notify-flow] _send_finding sev={sev.upper()} conf={conf} path={url}")
        if do_discord and self.discord_webhook:
            payload = {
                "embeds": [{
                    "title": f"{emoji} {sev.upper()} — {label}",
                    "description": (
                        f"Domain: {domain}\n"
                        f"Path: {url}\n"
                        f"Confidence: {conf}\n"
                        f"Source: {f.get('source','scanner')}\n\n"
                        f"Status:\n{status}\n\n"
                        f"BugScan ELITE"
                    ),
                    "color":  SEV_COLOR.get(sev, 0x808080),
                    "footer": {"text": ts},
                }]
            }
            if _post(self.discord_webhook, payload):
                _STATS["total_sent"] += 1
                _STATS["last_sent"]   = ts
                log.info(f"[notify] discord sent event=finding_confirmed"
                         f" severity={sev.upper()} confidence={conf}")
            else:
                log.warning(f"[notify] failed channel=discord reason=post_failed")

        # ── Telegram ─────────────────────────────────────────────────────────
        if do_telegram and self.telegram_token and self.telegram_chat:
            text = (
                f"{emoji} {sev.upper()} — {label}\n\n"
                f"Domain: {domain}\n"
                f"Path: {url}\n"
                f"Confidence: {conf}\n"
                f"Source: {f.get('source','scanner')}\n\n"
                f"Status:\n{status}\n\n"
                f"BugScan ELITE"
            )
            self._send_telegram(text)
            _STATS["total_sent"] += 1
            _STATS["last_sent"]   = ts
            log.info(f"[notify] telegram sent event=finding_confirmed"
                     f" severity={sev.upper()} confidence={conf}")

        # ── Slack (medium+) ───────────────────────────────────────────────────
        if do_slack and self.slack_webhook:
            color = "#FF0000" if sev == "critical" else "#FF6600" if sev == "high" else "#FFCC00"
            _post(self.slack_webhook, {
                "text": f"{emoji} *{sev.upper()} — {label}* in `{domain}`",
                "attachments": [{
                    "color": color,
                    "fields": [
                        {"title": "Domain",     "value": domain,  "short": True},
                        {"title": "Confidence", "value": str(conf),"short": True},
                        {"title": "Path",       "value": url,     "short": False},
                        {"title": "Status",     "value": status,  "short": False},
                    ],
                    "footer": f"BugScan ELITE • {ts}",
                }]
            })

    # ── Chain alert — summary only, no steps ──────────────────────────────────
    def _send_chain(self, chain: Dict, domain: str, ts: str):
        """Send a chain alert without exposing exploit steps."""
        name   = chain.get("name", "Multi-stage Security Issue")
        impact = chain.get("impact", "Potential combined vulnerability detected")
        # Strip any exploit-looking text from impact
        impact = _safe_desc(impact)[:200]
        sev    = chain.get("severity", "high")
        emoji  = SEV_EMOJI.get(sev, "🟠")
        num    = len(chain.get("steps", []))

        msg = (
            f"{emoji} *Security Signal Chain — {name}*\n"
            f"🎯 Domain: `{domain}`\n"
            f"📌 {num} related signals detected\n"
            f"⚠️ {impact}\n"
            f"🔎 Review in dashboard for details.\n"
            f"⏰ {ts}"
        )
        if self.discord_webhook:
            _post(self.discord_webhook, {"embeds":[{
                "title":       f"{emoji} Signal Chain — {name}",
                "description": (
                    f"**Domain:** `{domain}`\n"
                    f"**Signals:** {num}\n"
                    f"**Impact:** {impact}\n\n"
                    "*Review in dashboard for full details.*"
                ),
                "color": SEV_COLOR.get(sev, 0xFF6600),
                "footer": {"text": f"BugScan ELITE • {ts}"},
            }]})
            log.info("[notify] discord sent event=chain_detected")
        if self.telegram_token and self.telegram_chat:
            self._send_telegram(msg)
            log.info("[notify] telegram sent event=chain_detected")

    # ── Telegram transport ────────────────────────────────────────────────────
    def _send_telegram(self, text: str):
        url     = f"https://api.telegram.org/bot{self.telegram_token}/sendMessage"
        payload = {"chat_id": self.telegram_chat, "text": text, "parse_mode": "Markdown"}
        if not _post(url, payload):
            log.warning("[notify] failed channel=telegram reason=post_failed")

    # ── notify-cli binary ─────────────────────────────────────────────────────
    def _notify_cli_binary(self):
        """Return notify binary path if installed and configured."""
        import shutil as _sh
        nb = _sh.which("notify") or next(
            (p for d in [os.path.expanduser("~/go/bin"),"/home/kali/go/bin","/usr/local/bin"]
             for p in [os.path.join(d,"notify")] if os.path.isfile(p) and os.access(p,os.X_OK)),
            None
        )
        return nb

    def _notify_cli_configured(self) -> bool:
        """Return True only if notify binary exists AND config file exists."""
        nb = self._notify_cli_binary()
        if not nb:
            return False
        cfg_paths = [
            os.path.expanduser("~/.config/notify/provider-config.yaml"),
            os.path.expanduser("~/.config/notify/notify-config.yaml"),
            os.path.expanduser("~/.config/projectdiscovery/notify/provider-config.yaml"),
        ]
        return any(os.path.isfile(p) for p in cfg_paths)

    def _notify_cli(self, msg: str) -> bool:
        """Send via PD notify binary. Only runs if binary + config both present."""
        if not self._notify_cli_configured():
            return False
        import subprocess as _sp
        try:
            r = _sp.run([self._notify_cli_binary(), "-silent", "-bulk"],
                        input=msg.encode(), capture_output=True, timeout=8)
            if r.returncode == 0:
                log.info("[notify] notify_cli sent event=notification")
                return True
            else:
                log.debug(f"[notify] notify_cli exit={r.returncode} stderr={r.stderr[:80]}")
                return False
        except Exception as e:
            log.debug(f"[notify] notify_cli error: {e}")
            return False

    # ── Lifecycle events ──────────────────────────────────────────────────────
    def send_recon_complete(self, domain: str, subs: int, live: int, ends: int):
        msg = f"✅ *Recon complete* — `{domain}`\n📊 {subs} subs • {live} live • {ends} endpoints"
        if self.discord_webhook:
            _post(self.discord_webhook, {"embeds":[{"title":"✅ Recon Complete",
                "description": msg, "color": 0x00FF88}]})
            log.info("[notify] discord sent event=recon_complete")
        if self.telegram_token and self.telegram_chat:
            self._send_telegram(msg)
            log.info("[notify] telegram sent event=recon_complete")
        if self.slack_webhook:
            _post(self.slack_webhook, {"text": msg})

    def send_scan_complete(self, domain: str, total: int, crits: int,
                           findings: list = None):
        """Send scan complete notification with actual top findings breakdown."""
        emoji = "🔴" if crits > 0 else "🟢"

        # Build finding breakdown by type
        findings = findings or []
        by_type: dict = {}
        for f in findings:
            bug = (f.get("bug_type") or f.get("bug") or f.get("type","unknown")).lower()
            sev = f.get("severity","medium").lower()
            key = bug
            if key not in by_type:
                by_type[key] = {"count":0,"sev":sev}
            by_type[key]["count"] += 1
            # Keep highest severity
            sev_order = {"critical":0,"high":1,"medium":2,"low":3,"info":4}
            if sev_order.get(sev,4) < sev_order.get(by_type[key]["sev"],4):
                by_type[key]["sev"] = sev

        # Sort by severity then count
        sev_order = {"critical":0,"high":1,"medium":2,"low":3,"info":4}
        sorted_types = sorted(by_type.items(),
            key=lambda x: (sev_order.get(x[1]["sev"],4), -x[1]["count"]))

        # Top findings summary (critical/high only, max 8)
        sev_emoji = {"critical":"🔴","high":"🟠","medium":"🟡","low":"🔵","info":"⚪"}
        top_lines = []
        for bug, info in sorted_types:
            if info["sev"] not in ("critical","high"): continue
            se = sev_emoji.get(info["sev"],"🔵")
            label = _safe_bug_label(bug)
            top_lines.append(f"{se} **{label}** × {info['count']}")
            if len(top_lines) >= 8: break

        # Count by severity
        highs = sum(1 for f in findings if f.get("severity") in ("high",))
        meds  = sum(1 for f in findings if f.get("severity") == "medium")

        # Build Discord embed
        desc_lines = [
            f"**Domain:** `{domain}`",
            f"**Total:** {total} findings  |  🔴 {crits} critical  |  🟠 {highs} high  |  🟡 {meds} medium",
        ]
        if top_lines:
            desc_lines.append("")
            desc_lines.append("**Top findings:**")
            desc_lines.extend(top_lines)
        desc_lines.append("")
        desc_lines.append("*Review all findings in BugScan ELITE dashboard*")

        if self.discord_webhook:
            _post(self.discord_webhook, {"embeds":[{
                "title": f"{emoji} Scan Complete — {domain}",
                "description": "\n".join(desc_lines),
                "color": 0xFF0000 if crits > 0 else 0x00FF88,
                "footer": {"text": f"BugScan ELITE • {time.strftime('%H:%M UTC')}"},
                "fields": [
                    {"name":"Total","value":str(total),"inline":True},
                    {"name":"Critical","value":str(crits),"inline":True},
                    {"name":"High","value":str(highs),"inline":True},
                ],
            }]})
            log.info(f"[notify] discord sent event=scan_complete total={total} crits={crits}")

        # Telegram — compact version
        tg_lines = [
            f"{emoji} *Scan Complete* — `{domain}`",
            f"📊 {total} findings • {crits} critical • {highs} high",
        ]
        if top_lines:
            tg_lines.append("")
            for line in top_lines[:5]:
                # Strip markdown bold for Telegram
                tg_lines.append(line.replace("**","*"))
        tg_lines.append(f"⏰ {time.strftime('%H:%M UTC')}")

        if self.telegram_token and self.telegram_chat:
            self._send_telegram("\n".join(tg_lines))
            log.info(f"[notify] telegram sent event=scan_complete total={total} crits={crits}")
        if self.slack_webhook:
            _post(self.slack_webhook, {"text": f"{emoji} *{domain}*: {total} findings, {crits} critical"})
        self._notify_cli(f"Scan complete {domain}: {total} findings, {crits} critical")

    def notify_event(self, event: str, data: dict = None):
        """Fire a named lifecycle event notification."""
        data   = data or {}
        domain = data.get("domain", "")
        emoji_map = {
            "scan_started":      "🚀",
            "recon_done":        "🔍",
            "scan_complete":     "✅",
            "scan_error":        "❌",
            "finding_confirmed": "🎯",
            "nuclei_finding":    "⚡",
            "queue_started":     "📋",
            "queue_finished":    "📦",
        }
        emoji = emoji_map.get(event, "📌")

        if event == "scan_started":
            msg = f"{emoji} *Scan started* — `{domain}`"
        elif event == "recon_done":
            subs = data.get("subs",0); live = data.get("live",0); ends = data.get("endpoints",0)
            msg = f"{emoji} *Recon complete* — `{domain}`\n🌐 {subs} subs • {live} live • {ends} endpoints"
        elif event == "scan_complete":
            findings = data.get("findings",0); crits = data.get("critical",0)
            msg = f"{emoji} *Scan complete* — `{domain}`\n🐛 {findings} findings stored"
        elif event == "scan_error":
            # Sanitise error text — no stack traces
            err = str(data.get("error","unknown"))[:150]
            err = re.sub(r'File "[^"]+", line \d+', '', err)
            msg = f"{emoji} *Scan error* — `{domain}`\n{err}"
        elif event in ("finding_confirmed", "nuclei_finding"):
            # Route through queue_finding for proper gating
            self.queue_finding(data, domain)
            return True
        else:
            msg = f"{emoji} `{event}` — `{domain}`"

        sent = False
        if self.discord_webhook:
            if _post(self.discord_webhook, {"embeds":[{
                    "title": f"{emoji} {event.replace('_',' ').title()}",
                    "description": msg, "color": 0x3399FF}]}):
                sent = True
                log.info(f"[notify] discord sent event={event}")
        if self.telegram_token and self.telegram_chat:
            self._send_telegram(msg)
            sent = True
            log.info(f"[notify] telegram sent event={event}")
        if self.slack_webhook:
            _post(self.slack_webhook, {"text": msg})
        self._notify_cli(msg)
        return sent

    def test(self) -> Dict:
        """Send test notification to all configured channels."""
        results = {}
        test_msg = "🔔 BugScan ELITE — Notification test (all systems nominal)"
        if self.slack_webhook:
            results["slack"]    = _post(self.slack_webhook, {"text": test_msg})
        if self.discord_webhook:
            results["discord"]  = _post(self.discord_webhook,
                {"embeds":[{"title":"🔔 Test","description":test_msg,"color":0x00FF88}]})
        if self.telegram_token and self.telegram_chat:
            self._send_telegram(test_msg)
            results["telegram"] = True
        return results

    def get_stats(self) -> Dict:
        return dict(_STATS)

    @property
    def configured(self) -> bool:
        return bool(self.slack_webhook or self.discord_webhook or
                    (self.telegram_token and self.telegram_chat))


# ── Public helpers ────────────────────────────────────────────────────────────
_notifier: Optional[NotifyEngine] = None

def get_notifier() -> NotifyEngine:
    global _notifier
    if _notifier is None:
        _notifier = NotifyEngine()
    return _notifier
