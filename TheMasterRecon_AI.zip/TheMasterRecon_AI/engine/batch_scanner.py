"""
TheMasterRecon AI — Multi-Target Batch Scanner
Scan multiple domains/IPs in parallel with shared queue.
"""
import threading, queue, time, logging, os
from typing import List, Dict, Callable, Optional

log = logging.getLogger("elite.batch")


class BatchScanner:
    """Run scans against multiple targets in parallel."""

    def __init__(self, max_parallel: int = 3):
        self.max_parallel = max_parallel
        self._jobs    = {}   # job_id -> job_state
        self._lock    = threading.Lock()

    def submit(self, targets: List[str], bugs: List[str],
               db, q, scan_opts: Dict = None) -> str:
        """Submit a batch job. Returns job_id."""
        import secrets
        job_id = secrets.token_hex(8)
        job = {
            "id":       job_id,
            "targets":  targets,
            "bugs":     bugs,
            "opts":     scan_opts or {},
            "status":   "queued",
            "started":  time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "results":  {},  # domain -> findings count
            "errors":   {},
            "progress": 0,
            "total":    len(targets),
            "done":     0,
        }
        with self._lock:
            self._jobs[job_id] = job

        threading.Thread(target=self._run_job,
                         args=(job_id, targets, bugs, db, q, scan_opts or {}),
                         daemon=True).start()
        return job_id

    def _run_job(self, job_id: str, targets: List[str], bugs: List[str],
                 db, q, opts: Dict):
        with self._lock:
            self._jobs[job_id]["status"] = "running"

        sem   = threading.Semaphore(self.max_parallel)
        done  = [0]

        def scan_target(domain: str):
            with sem:
                try:
                    q.put({"type": "batch_progress",
                           "job_id": job_id,
                           "domain": domain,
                           "status": "scanning",
                           "done": done[0],
                           "total": len(targets)})

                    # Auto-probe if no recon data
                    hosts = db.get_hosts(domain)
                    if not hosts.get("active"):
                        for scheme in ["https","http"]:
                            try:
                                import urllib.request, ssl
                                ctx = ssl.create_default_context()
                                ctx.check_hostname = False
                                ctx.verify_mode = ssl.CERT_NONE
                                urllib.request.urlopen(f"{scheme}://{domain}",
                                    timeout=8, context=ctx)
                                db.add_active(domain, f"{scheme}://{domain}")
                                break
                            except Exception:
                                pass

                    # Run scan with live streaming via a proxy queue
                    from scanner import run_scan, _clear_stop_event
                    _clear_stop_event(domain)  # only clears THIS domain's stop event

                    # ProxyQueue: forwards all events to the shared SSE queue live,
                    # while tracking finding counts for the job summary
                    count = [0]
                    crits = [0]

                    class _ProxyQueue:
                        """Forwards items to shared q and counts findings in real time."""
                        def put(self, item):
                            try:
                                if isinstance(item, dict):
                                    # Tag with domain so client knows which target
                                    item.setdefault("domain", domain)
                                    if item.get("type") == "finding":
                                        count[0] += 1
                                        if item.get("severity") == "critical":
                                            crits[0] += 1
                                q.put(item)
                            except Exception:
                                pass
                        def get(self, *a, **kw): raise __import__("queue").Empty
                        def empty(self): return True

                    live_q = _ProxyQueue()
                    run_scan(domain, bugs, live_q, db,
                             scan_speed=opts.get("speed","fast"))

                    with self._lock:
                        self._jobs[job_id]["results"][domain] = {
                            "findings": count[0], "critical": crits[0]}
                        done[0] += 1
                        self._jobs[job_id]["done"]     = done[0]
                        self._jobs[job_id]["progress"] = round(done[0]/len(targets)*100)

                    q.put({"type": "batch_target_done",
                           "job_id": job_id, "domain": domain,
                           "findings": count[0], "critical": crits[0],
                           "done": done[0], "total": len(targets)})

                except Exception as e:
                    with self._lock:
                        self._jobs[job_id]["errors"][domain] = str(e)
                        done[0] += 1
                    log.warning(f"[batch] {domain}: {e}")

        threads = [threading.Thread(target=scan_target, args=(d,), daemon=True)
                   for d in targets]
        for t in threads: t.start()
        for t in threads: t.join()

        with self._lock:
            self._jobs[job_id]["status"]   = "done"
            self._jobs[job_id]["finished"] = time.strftime("%Y-%m-%dT%H:%M:%SZ")

        q.put({"type": "batch_done", "job_id": job_id,
               "total_targets": len(targets),
               "total_findings": sum(r["findings"] for r in self._jobs[job_id]["results"].values()),
               "errors": len(self._jobs[job_id]["errors"])})

    def get_job(self, job_id: str) -> Optional[Dict]:
        with self._lock:
            return dict(self._jobs.get(job_id, {}))

    def list_jobs(self) -> List[Dict]:
        with self._lock:
            return [dict(j) for j in self._jobs.values()]


_batch_scanner = BatchScanner(max_parallel=3)


def get_batch_scanner() -> BatchScanner:
    return _batch_scanner


def add_to_queue(domain: str, db) -> bool:
    """Add a domain to the app-level scan queue (used by /scan/bulk)."""
    # Import app-level queue state
    try:
        import app as _app_module
        with _app_module._queue_lock:
            # Prevent duplicates
            if any(q["domain"] == domain and q["status"] == "pending"
                   for q in _app_module._scan_queue):
                log.info(f"[batch] {domain} already queued")
                return False
            entry = {
                "domain":   domain,
                "bugs":     [],       # will use defaults at scan time
                "status":   "pending",
                "added_at": __import__("time").strftime("%H:%M:%S"),
            }
            _app_module._scan_queue.append(entry)
            log.info(f"[batch] queued: {domain} (position {len(_app_module._scan_queue)})")
            return True
    except Exception as e:
        log.warning(f"[batch] add_to_queue failed: {e}")
        return False
