"""
TheMasterRecon RAG Database
SQLite-backed vector store + BM25 keyword index.
Stores real public H1/bug bounty reports and serves similarity search.
No external API needed — all local.
"""
from __future__ import annotations
import json, logging, os, re, sqlite3, time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

log = logging.getLogger("elite.rag_db")

_DB_PATH  = Path(__file__).parent.parent / "data" / "rag" / "rag.db"
_MODEL    = None        # lazy-loaded sentence transformer
_INDEX    = None        # in-memory numpy matrix
_INDEX_IDS: List[int] = []
_BM25     = None
_BM25_IDS: List[int] = []


# ── Schema ─────────────────────────────────────────────────────────────────────
SCHEMA = """
CREATE TABLE IF NOT EXISTS reports (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT,
    url         TEXT UNIQUE,
    source      TEXT,
    bug_type    TEXT,
    severity    TEXT,
    program     TEXT,
    tech        TEXT,          -- JSON list
    bounty      REAL,
    body        TEXT,
    keywords    TEXT,          -- space-joined for BM25
    embedding   BLOB,          -- numpy float32 bytes
    ingested_at REAL
);
CREATE INDEX IF NOT EXISTS idx_bug     ON reports(bug_type);
CREATE INDEX IF NOT EXISTS idx_source  ON reports(source);
CREATE INDEX IF NOT EXISTS idx_severity ON reports(severity);

CREATE TABLE IF NOT EXISTS ingest_log (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    source   TEXT,
    status   TEXT,
    count    INTEGER DEFAULT 0,
    error    TEXT,
    started  REAL,
    finished REAL
);
"""


def _conn() -> sqlite3.Connection:
    _DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(str(_DB_PATH), timeout=30, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA synchronous=NORMAL")
    c.executescript(SCHEMA)
    return c


# ── Embedding model ────────────────────────────────────────────────────────────
_TFIDF = None

class _TFIDFEmbedder:
    """TF-IDF fallback when neural model is unavailable."""
    def __init__(self, dim=256):
        self.vocab: dict = {}
        self.dim = dim
    def fit(self, corpus):
        import re
        words: set = set()
        for doc in corpus:
            words.update(re.sub(r"[^a-z0-9 ]","",doc.lower()).split())
        self.vocab = {w: i % self.dim for i,w in enumerate(sorted(words))}
    def encode(self, texts):
        import re, math
        out = __import__('numpy').zeros((len(texts),self.dim),dtype='float32')
        for i,text in enumerate(texts):
            words = re.sub(r"[^a-z0-9 ]","",text.lower()).split()
            freq: dict = {}
            for w in words: freq[w]=freq.get(w,0)+1
            for w,c in freq.items():
                idx2 = self.vocab.get(w, abs(hash(w))%self.dim)
                out[i][idx2] += math.log(1+c)
            n = __import__('numpy').linalg.norm(out[i])
            if n>0: out[i]/=n
        return out

def _get_model():
    global _MODEL
    if _MODEL is not None: return _MODEL
    try:
        from sentence_transformers import SentenceTransformer
        log.info("[rag_db] Loading all-MiniLM-L6-v2…")
        _MODEL = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
        log.info("[rag_db] Neural model ready (384-dim)")
        return _MODEL
    except Exception as e:
        log.warning(f"[rag_db] Neural model unavailable — TF-IDF active ({e.__class__.__name__})")
        return None

def embed(texts):
    model = _get_model()
    if model is not None:
        vecs = model.encode(texts, batch_size=32, normalize_embeddings=True, show_progress_bar=False)
        return __import__('numpy').array(vecs, dtype='float32')
    global _TFIDF
    if _TFIDF is None: _TFIDF = _TFIDFEmbedder()
    if not _TFIDF.vocab: _TFIDF.fit(texts)
    return _TFIDF.encode(texts)


def build_index():
    """Load all embeddings from DB into RAM for fast cosine search."""
    global _INDEX, _INDEX_IDS, _BM25, _BM25_IDS
    try:
        from rank_bm25 import BM25Okapi
    except ImportError:
        BM25Okapi = None

    with _conn() as db:
        rows = db.execute("SELECT id, embedding, keywords FROM reports WHERE embedding IS NOT NULL").fetchall()

    if not rows:
        log.info("[rag_db] No embeddings yet — run ingest first")
        return 0

    ids, vecs, kw_corpus = [], [], []
    for row in rows:
        ids.append(row["id"])
        vecs.append(np.frombuffer(row["embedding"], dtype=np.float32))
        kw_corpus.append((row["keywords"] or "").lower().split())

    _INDEX     = np.stack(vecs)           # (N, D)
    _INDEX_IDS = ids
    log.info(f"[rag_db] Vector index: {len(ids)} reports")

    if BM25Okapi and kw_corpus:
        _BM25     = BM25Okapi(kw_corpus)
        _BM25_IDS = ids
        log.info("[rag_db] BM25 index ready")

    return len(ids)


# ── Insert ─────────────────────────────────────────────────────────────────────
def insert_report(report: Dict[str, Any]) -> Optional[int]:
    """Insert a report. Returns row id or None if duplicate."""
    url = report.get("url","").strip()
    if not url:
        return None
    try:
        with _conn() as db:
            # Dedup by URL
            exists = db.execute("SELECT id FROM reports WHERE url=?", (url,)).fetchone()
            if exists:
                return None
            cur = db.execute("""
                INSERT INTO reports (title,url,source,bug_type,severity,program,tech,bounty,body,keywords,ingested_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """, (
                report.get("title","")[:500],
                url,
                report.get("source",""),
                report.get("bug_type",""),
                report.get("severity",""),
                report.get("program","")[:200],
                json.dumps(report.get("tech",[])),
                report.get("bounty"),
                (report.get("body","") or "")[:30000],
                _keywords(report),
                time.time(),
            ))
            return cur.lastrowid
    except sqlite3.IntegrityError:
        return None
    except Exception as e:
        log.warning(f"[rag_db] insert failed: {e}")
        return None


def embed_pending(batch: int = 64):
    """Embed all reports that have no embedding yet."""
    with _conn() as db:
        rows = db.execute("SELECT id, title, bug_type, body FROM reports WHERE embedding IS NULL LIMIT 2000").fetchall()
    if not rows:
        return 0

    log.info(f"[rag_db] Embedding {len(rows)} reports…")
    texts = [f"{r['title']} {r['bug_type']} {(r['body'] or '')[:400]}" for r in rows]
    ids   = [r["id"] for r in rows]

    for i in range(0, len(texts), batch):
        batch_texts = texts[i:i+batch]
        batch_ids   = ids[i:i+batch]
        vecs = embed(batch_texts)
        with _conn() as db:
            for rid, vec in zip(batch_ids, vecs):
                db.execute("UPDATE reports SET embedding=? WHERE id=?",
                           (vec.tobytes(), rid))
    log.info(f"[rag_db] Embedded {len(rows)} reports")
    build_index()
    return len(rows)


# ── Search ─────────────────────────────────────────────────────────────────────
def search(query: str, top_k: int = 5,
           bug_type: str = "", tech: str = "",
           severity: str = "") -> List[Dict[str, Any]]:
    """
    Hybrid search: cosine similarity + BM25. Returns top_k report dicts.
    Works even with no embeddings (falls back to keyword-only).
    """
    sem_scores: Dict[int, float] = {}
    lex_scores: Dict[int, float] = {}

    # Semantic search
    if _INDEX is not None and len(_INDEX_IDS) > 0:
        try:
            qvec = embed([query])[0]
            sims = (_INDEX @ qvec).tolist()   # cosine (already normalised)
            for rid, score in zip(_INDEX_IDS, sims):
                sem_scores[rid] = float(score)
        except Exception as e:
            log.debug(f"[rag_db] semantic search error: {e}")

    # BM25 keyword search
    if _BM25 is not None:
        try:
            tokens = query.lower().split()
            bm25_s = _BM25.get_scores(tokens)
            mx     = max(bm25_s) if max(bm25_s) > 0 else 1.0
            for rid, score in zip(_BM25_IDS, bm25_s):
                lex_scores[rid] = float(score) / mx
        except Exception as e:
            log.debug(f"[rag_db] bm25 error: {e}")

    # Fallback: full-text SQLite LIKE
    if not sem_scores and not lex_scores:
        terms = query.lower().split()[:5]
        cond  = " OR ".join(["lower(keywords) LIKE ?" for _ in terms])
        vals  = [f"%{t}%" for t in terms]
        try:
            with _conn() as db:
                rows = db.execute(f"SELECT id FROM reports WHERE {cond} LIMIT 100", vals).fetchall()
            for i, row in enumerate(rows):
                lex_scores[row["id"]] = 1.0 - i * 0.01
        except Exception:
            pass

    # Combine scores: 60% semantic + 40% BM25
    all_ids = set(sem_scores) | set(lex_scores)
    scored  = [(rid, sem_scores.get(rid,0)*0.6 + lex_scores.get(rid,0)*0.4)
               for rid in all_ids]
    scored.sort(key=lambda x: -x[1])
    top_ids = [rid for rid, _ in scored[:top_k*3]]

    if not top_ids:
        return []

    # Load from DB with optional filters
    placeholders = ",".join("?" * len(top_ids))
    where_clauses = [f"id IN ({placeholders})"]
    params: List[Any] = top_ids[:]
    if bug_type:
        where_clauses.append("bug_type LIKE ?"); params.append(f"%{bug_type}%")
    if severity:
        where_clauses.append("severity=?"); params.append(severity)

    sql = f"SELECT * FROM reports WHERE {' AND '.join(where_clauses)} LIMIT {top_k*2}"
    with _conn() as db:
        rows = db.execute(sql, params).fetchall()

    # Build result dicts, preserve score order
    score_map = {rid: s for rid, s in scored}
    results = []
    for row in rows:
        d = dict(row)
        d["score"]     = round(score_map.get(d["id"], 0), 4)
        d["embedding"] = None  # don't return blob
        try: d["tech"] = json.loads(d.get("tech","[]"))
        except: d["tech"] = []
        results.append(d)

    results.sort(key=lambda x: -x["score"])

    # Tech filter (post-SQL, since tech is JSON)
    if tech:
        tl = tech.lower()
        results = [r for r in results if any(tl in t.lower() for t in r.get("tech",[]))] or results

    return results[:top_k]


def stats() -> Dict[str, Any]:
    """Return DB statistics."""
    with _conn() as db:
        total     = db.execute("SELECT COUNT(*) FROM reports").fetchone()[0]
        embedded  = db.execute("SELECT COUNT(*) FROM reports WHERE embedding IS NOT NULL").fetchone()[0]
        by_bug    = dict(db.execute("SELECT bug_type, COUNT(*) FROM reports GROUP BY bug_type ORDER BY 2 DESC LIMIT 15").fetchall())
        by_source = dict(db.execute("SELECT source, COUNT(*) FROM reports GROUP BY source ORDER BY 2 DESC LIMIT 10").fetchall())
        by_sev    = dict(db.execute("SELECT severity, COUNT(*) FROM reports GROUP BY severity").fetchall())
        last_log  = db.execute("SELECT source,status,count,started FROM ingest_log ORDER BY id DESC LIMIT 5").fetchall()
    return {
        "total_reports":   total,
        "embedded":        embedded,
        "index_size":      len(_INDEX_IDS),
        "by_bug_type":     by_bug,
        "by_source":       by_source,
        "by_severity":     by_sev,
        "recent_ingest":   [dict(r) for r in last_log],
    }


def _keywords(report: Dict) -> str:
    """Build keyword string for BM25."""
    parts = [
        report.get("title",""),
        report.get("bug_type",""),
        report.get("program",""),
        report.get("severity",""),
        " ".join(report.get("tech",[])),
        (report.get("body","") or "")[:500],
    ]
    text = " ".join(p for p in parts if p).lower()
    text = re.sub(r'[^a-z0-9 ]', ' ', text)
    return " ".join(text.split())
