"""
TheMasterRecon AI — PDF Report Generator
Converts AI markdown reports to professional PDF using WeasyPrint.
"""
import os, re, logging, tempfile, base64
from datetime import datetime

log = logging.getLogger("elite.pdf")

_CSS = """
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&family=JetBrains+Mono:wght@400;600&display=swap');

* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: 'Inter', -apple-system, sans-serif;
    font-size: 10.5pt;
    line-height: 1.6;
    color: #1a1a2e;
    background: white;
}
@page {
    margin: 2cm 2.2cm 2cm 2.2cm;
    @bottom-right { content: "Page " counter(page) " of " counter(pages); font-size: 8pt; color: #888; }
    @bottom-left  { content: "TheMasterRecon AI ⭐ — CONFIDENTIAL"; font-size: 8pt; color: #888; }
}

/* Cover page */
.cover {
    display: flex; flex-direction: column;
    min-height: 24cm;
    background: linear-gradient(135deg, #05050e 0%, #0d0d2e 100%);
    color: white;
    padding: 3cm 2.5cm;
    page-break-after: always;
}
.cover-logo { font-size: 32pt; font-weight: 900; letter-spacing: 2px; margin-bottom: 8px; }
.cover-logo span { color: #ffaa00; }
.cover-tagline { font-size: 10pt; color: #808098; letter-spacing: 3px; text-transform: uppercase; margin-bottom: 4cm; }
.cover-title { font-size: 24pt; font-weight: 700; color: white; margin-bottom: 16px; }
.cover-target { font-size: 13pt; color: #00e5ff; margin-bottom: 3cm; font-family: 'JetBrains Mono', monospace; }
.cover-meta { border-top: 1px solid rgba(255,255,255,.15); padding-top: 1cm; display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
.cover-meta-item label { display: block; font-size: 7pt; color: #808098; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 3px; }
.cover-meta-item value { font-size: 10pt; color: #c8c8e0; }
.risk-badge {
    display: inline-block; padding: 6px 18px; border-radius: 4px;
    font-size: 11pt; font-weight: 800; letter-spacing: 1px; text-transform: uppercase;
}
.risk-critical { background: rgba(255,0,68,.15); color: #ff0044; border: 1px solid #ff0044; }
.risk-high     { background: rgba(255,136,0,.15); color: #ff8800; border: 1px solid #ff8800; }
.risk-medium   { background: rgba(255,204,0,.15); color: #cc8800; border: 1px solid #ccaa00; }
.risk-low      { background: rgba(0,200,100,.15); color: #00aa55; border: 1px solid #00aa55; }

/* Content */
h1 { font-size: 20pt; font-weight: 900; color: #0d0d2e; margin: 1.5em 0 0.5em; border-bottom: 3px solid #0d0d2e; padding-bottom: 6px; page-break-after: avoid; }
h2 { font-size: 15pt; font-weight: 700; color: #0d0d2e; margin: 1.3em 0 0.4em; border-left: 4px solid #4466ff; padding-left: 10px; page-break-after: avoid; }
h3 { font-size: 12pt; font-weight: 700; color: #222; margin: 1em 0 0.3em; page-break-after: avoid; }

p  { margin: 0.5em 0; }
ul, ol { margin: 0.5em 0 0.5em 1.5em; }
li { margin: 3px 0; }
a  { color: #4466ff; }

strong { font-weight: 700; }
em     { font-style: italic; }

/* Tables */
table { width: 100%; border-collapse: collapse; margin: 1em 0; font-size: 9.5pt; }
th { background: #0d0d2e; color: white; padding: 7px 10px; text-align: left; font-size: 8.5pt; letter-spacing: 0.5px; }
td { padding: 6px 10px; border-bottom: 1px solid #e8eaf0; }
tr:nth-child(even) td { background: #f8f9fc; }

/* Code */
pre, code {
    font-family: 'JetBrains Mono', 'Courier New', monospace;
    font-size: 8.5pt;
    background: #05050e;
    color: #c8c8e0;
}
pre { padding: 14px 16px; border-radius: 6px; overflow: auto; margin: 0.8em 0; border-left: 3px solid #4466ff; }
code { padding: 1px 5px; border-radius: 3px; }

/* Severity badges */
.sev-critical { color: #ff0044; font-weight: 800; }
.sev-high     { color: #ff8800; font-weight: 700; }
.sev-medium   { color: #cc8800; font-weight: 700; }
.sev-low      { color: #007733; font-weight: 600; }

/* Finding blocks */
.finding-block {
    border: 1px solid #e0e4f0;
    border-radius: 8px;
    margin: 1.5em 0;
    overflow: hidden;
    page-break-inside: avoid;
}
.finding-header {
    padding: 10px 16px;
    background: #f4f6fb;
    border-bottom: 1px solid #e0e4f0;
    font-weight: 700;
}
.finding-body { padding: 12px 16px; }

/* Footer watermark */
.watermark { color: #aaa; font-size: 8pt; text-align: center; margin-top: 3em; padding-top: 1em; border-top: 1px solid #eee; }
"""

def markdown_to_html(md: str, domain: str, risk: str, stats: dict) -> str:
    """Convert markdown report to styled HTML."""
    try:
        import markdown
        body_html = markdown.markdown(md, extensions=['tables','fenced_code','nl2br','toc'])
    except ImportError:
        # Fallback: basic markdown conversion
        body_html = _basic_md_to_html(md)

    date_str = datetime.utcnow().strftime("%B %d, %Y")
    risk_cls  = f"risk-{risk.lower()}" if risk.lower() in ['critical','high','medium','low'] else 'risk-medium'

    cover = f"""
<div class="cover">
  <div class="cover-logo">TheMaster<span>Recon</span> AI ⭐</div>
  <div class="cover-tagline">Elite Security Assessment Platform</div>
  <div class="cover-title">Penetration Test Report</div>
  <div class="cover-target">{domain}</div>
  <div class="cover-meta">
    <div class="cover-meta-item">
      <label>Date</label>
      <value>{date_str}</value>
    </div>
    <div class="cover-meta-item">
      <label>Overall Risk</label>
      <value><span class="risk-badge {risk_cls}">{risk}</span></value>
    </div>
    <div class="cover-meta-item">
      <label>Critical Findings</label>
      <value>{stats.get('critical',0)}</value>
    </div>
    <div class="cover-meta-item">
      <label>Total Findings</label>
      <value>{stats.get('total',0)}</value>
    </div>
    <div class="cover-meta-item">
      <label>High Findings</label>
      <value>{stats.get('high',0)}</value>
    </div>
    <div class="cover-meta-item">
      <label>Medium / Low</label>
      <value>{stats.get('medium',0)} / {stats.get('low',0)}</value>
    </div>
  </div>
</div>
"""
    watermark = f'<div class="watermark">Generated by TheMasterRecon AI ⭐ &mdash; CONFIDENTIAL &mdash; {date_str}</div>'

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Security Assessment — {domain}</title>
<style>{_CSS}</style>
</head>
<body>
{cover}
{body_html}
{watermark}
</body>
</html>"""


def _basic_md_to_html(md: str) -> str:
    """Basic markdown → HTML without markdown library."""
    import html as _html
    lines, out, in_code = md.split('\n'), [], False
    for line in lines:
        if line.startswith('```'):
            if in_code: out.append('</code></pre>'); in_code = False
            else:       out.append('<pre><code>');   in_code = True
            continue
        if in_code:
            out.append(_html.escape(line)); continue
        line = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', line)
        line = re.sub(r'`([^`]+)`', r'<code>\1</code>', line)
        line = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', line)
        if line.startswith('### '): out.append(f'<h3>{line[4:]}</h3>')
        elif line.startswith('## '): out.append(f'<h2>{line[3:]}</h2>')
        elif line.startswith('# '):  out.append(f'<h1>{line[2:]}</h1>')
        elif line.startswith('- ') or line.startswith('* '):
            out.append(f'<li>{line[2:]}</li>')
        elif line.strip() == '---': out.append('<hr>')
        elif line.strip():  out.append(f'<p>{line}</p>')
        else:               out.append('')
    return '\n'.join(out)


def generate_pdf(markdown_text: str, domain: str, risk: str = "HIGH",
                 stats: dict = None) -> bytes:
    """Generate PDF bytes from markdown report."""
    stats = stats or {}
    html  = markdown_to_html(markdown_text, domain, risk, stats)

    try:
        from weasyprint import HTML as WP_HTML, CSS
        from weasyprint.text.fonts import FontConfiguration
        font_config = FontConfiguration()
        pdf_bytes   = WP_HTML(string=html).write_pdf(font_config=font_config)
        log.info(f"[pdf] Generated {len(pdf_bytes):,} bytes via WeasyPrint")
        return pdf_bytes
    except Exception as e:
        log.warning(f"[pdf] WeasyPrint failed: {e} — trying reportlab fallback")
        return _reportlab_fallback(markdown_text, domain, risk, stats)


def _reportlab_fallback(md: str, domain: str, risk: str, stats: dict) -> bytes:
    """ReportLab fallback PDF generator."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.lib import colors
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                     Table, TableStyle, HRFlowable, PageBreak,
                                     Preformatted)
    from io import BytesIO

    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=2*cm, rightMargin=2*cm,
                            topMargin=2*cm,  bottomMargin=2*cm)
    styles = getSampleStyleSheet()
    DARK   = colors.HexColor('#0d0d2e')
    CYAN   = colors.HexColor('#00e5ff')
    GOLD   = colors.HexColor('#ffaa00')
    RED    = colors.HexColor('#ff0044')

    title_style = ParagraphStyle('title', parent=styles['Title'],
        fontSize=22, textColor=colors.white, backColor=DARK,
        spaceAfter=6, leading=28, alignment=1)
    h1_style = ParagraphStyle('h1', parent=styles['h1'],
        fontSize=16, textColor=DARK, spaceBefore=16, spaceAfter=6,
        borderPad=4, borderWidth=0, borderColor=DARK)
    h2_style = ParagraphStyle('h2', parent=styles['h2'],
        fontSize=13, textColor=DARK, spaceBefore=12, spaceAfter=4)
    body_style = ParagraphStyle('body', parent=styles['Normal'],
        fontSize=10, leading=15, spaceAfter=6)
    code_style = ParagraphStyle('code', parent=styles['Code'],
        fontSize=8, leading=11, backColor=colors.HexColor('#f4f4f8'),
        leftIndent=10, rightIndent=10, spaceBefore=4, spaceAfter=4)

    story = []

    # Cover
    story.append(Spacer(1, 1*cm))
    story.append(Paragraph("TheMasterRecon AI ⭐", title_style))
    story.append(Paragraph("PENETRATION TEST REPORT", ParagraphStyle('sub',
        parent=styles['Normal'], fontSize=11, textColor=colors.HexColor('#808098'),
        alignment=1, spaceAfter=12)))
    story.append(Spacer(1, 0.5*cm))
    story.append(Paragraph(domain, ParagraphStyle('dom',
        parent=styles['Normal'], fontSize=14, textColor=CYAN,
        alignment=1, fontName='Courier-Bold', spaceAfter=6)))

    sev_color = {'CRITICAL': RED, 'HIGH': colors.HexColor('#ff8800'),
                 'MEDIUM': colors.HexColor('#cc8800'), 'LOW': colors.HexColor('#007733')}.get(risk.upper(), DARK)
    story.append(Paragraph(f"Overall Risk: <font color='{sev_color.hexval()}'><b>{risk.upper()}</b></font>",
        ParagraphStyle('risk', parent=styles['Normal'], fontSize=12, alignment=1, spaceAfter=20)))

    meta_data = [
        ['Date', datetime.utcnow().strftime("%B %d, %Y")],
        ['Critical', str(stats.get('critical',0))],
        ['High', str(stats.get('high',0))],
        ['Medium', str(stats.get('medium',0))],
        ['Low', str(stats.get('low',0))],
        ['Total', str(stats.get('total',0))],
    ]
    meta_table = Table([[r[0], r[1]] for r in meta_data], colWidths=[6*cm, 9*cm])
    meta_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (0,-1), colors.HexColor('#f4f6fb')),
        ('TEXTCOLOR',  (0,0), (0,-1), DARK),
        ('FONTNAME',   (0,0), (0,-1), 'Helvetica-Bold'),
        ('FONTSIZE',   (0,0), (-1,-1), 9),
        ('GRID',       (0,0), (-1,-1), 0.5, colors.HexColor('#e0e4f0')),
        ('ROWBACKGROUNDS', (0,0), (-1,-1), [colors.white, colors.HexColor('#f8f9fc')]),
        ('PADDING',    (0,0), (-1,-1), 7),
    ]))
    story.append(meta_table)
    story.append(PageBreak())

    # Parse markdown lines
    in_code = False
    code_buf = []
    for line in md.split('\n'):
        if line.startswith('```'):
            if in_code:
                story.append(Preformatted('\n'.join(code_buf), code_style))
                code_buf = []; in_code = False
            else:
                in_code = True
            continue
        if in_code:
            code_buf.append(line); continue

        if line.startswith('# '):
            story.append(Paragraph(line[2:], h1_style))
            story.append(HRFlowable(width='100%', thickness=2, color=DARK))
        elif line.startswith('## '):
            story.append(Paragraph(line[3:], h2_style))
        elif line.startswith('### '):
            story.append(Paragraph(line[4:], ParagraphStyle('h3',
                parent=styles['h3'], fontSize=11, textColor=DARK,
                spaceBefore=8, spaceAfter=3)))
        elif line.startswith('---'):
            story.append(HRFlowable(width='100%', thickness=0.5,
                                    color=colors.HexColor('#e0e4f0')))
        elif line.strip():
            clean = (line.replace('**','<b>',1).replace('**','</b>',1)
                        .replace('*','<i>',1).replace('*','</i>',1))
            try:
                story.append(Paragraph(clean, body_style))
            except Exception:
                story.append(Paragraph(line, body_style))
        else:
            story.append(Spacer(1, 4))

    doc.build(story)
    pdf_bytes = buf.getvalue()
    log.info(f"[pdf] Generated {len(pdf_bytes):,} bytes via ReportLab")
    return pdf_bytes


def generate_html_report(domain: str, findings: list, recon_data: dict = None,
                         chains: list = None, title: str = "") -> str:
    """Generate a complete HTML pentest report (no WeasyPrint needed)."""
    from engine.compliance import map_all, compliance_summary
    import time

    recon_data = recon_data or {}
    chains     = chains or []
    title      = title or f"Security Assessment — {domain}"

    mapped   = map_all(findings)
    summary  = compliance_summary(findings)

    sev_count = {"critical":0,"high":0,"medium":0,"low":0,"info":0}
    for f in findings:
        sev = f.get("severity","info").lower()
        sev_count[sev] = sev_count.get(sev,0) + 1

    sev_colors = {"critical":"#ff1744","high":"#ff6d00","medium":"#ffd600","low":"#00e676","info":"#4466ff"}

    def finding_card(f):
        sev   = f.get("severity","info").lower()
        color = sev_colors.get(sev,"#888")
        cvss  = f.get("cvss_score","")
        owasp = f.get("owasp_id","")
        cwe   = f.get("cwe_id","")
        poc   = f.get("poc","")
        rem   = f.get("remediation","")
        return f"""
<div style="border-left:4px solid {color};padding:16px;margin:12px 0;background:#f8f9fa;border-radius:0 8px 8px 0">
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
    <span style="background:{color};color:white;padding:2px 10px;border-radius:4px;font-size:11px;font-weight:700;text-transform:uppercase">{sev}</span>
    {'<span style="background:#e3f2fd;color:#1565c0;padding:2px 8px;border-radius:4px;font-size:11px">'+owasp+'</span>' if owasp else ''}
    {'<span style="background:#f3e5f5;color:#6a1b9a;padding:2px 8px;border-radius:4px;font-size:11px">'+cwe+'</span>' if cwe else ''}
    {'<span style="background:#e8f5e9;color:#2e7d32;padding:2px 8px;border-radius:4px;font-size:11px">CVSS '+str(cvss)+'</span>' if cvss else ''}
  </div>
  <h3 style="margin:0 0 8px;font-size:15px;color:#1a1a2e">{f.get("title",f.get("bug","Finding")).replace("<","&lt;")}</h3>
  <p style="margin:4px 0;font-size:12px;color:#555"><strong>URL:</strong> <code style="background:#eee;padding:1px 6px;border-radius:3px">{f.get("url","").replace("<","&lt;")}</code></p>
  {f'<p style="margin:4px 0;font-size:12px;color:#555"><strong>Parameter:</strong> <code style="background:#eee;padding:1px 6px;border-radius:3px">{f.get("param","")}</code></p>' if f.get("param") else ""}
  {f'<p style="margin:8px 0 4px;font-size:12px;color:#333">{f.get("description",f.get("impact",""))[:400].replace("<","&lt;")}</p>' if f.get("description") or f.get("impact") else ""}
  {f'<pre style="background:#1a1a2e;color:#00e676;padding:10px;border-radius:6px;font-size:11px;overflow:auto;margin:8px 0">{poc.replace("<","&lt;")[:500]}</pre>' if poc else ""}
  {f'<div style="background:#fff3e0;padding:8px 12px;border-radius:6px;font-size:12px;margin:6px 0"><strong>Fix:</strong> {rem.replace("<","&lt;")[:300]}</div>' if rem else ""}
</div>"""

    crit_findings = [f for f in mapped if f.get("severity")=="critical"]
    high_findings = [f for f in mapped if f.get("severity")=="high"]
    med_findings  = [f for f in mapped if f.get("severity")=="medium"]
    low_findings  = [f for f in mapped if f.get("severity") in ("low","info")]

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title>
<style>
  body{{font-family:'Segoe UI',system-ui,sans-serif;margin:0;padding:0;background:#fff;color:#1a1a2e}}
  .cover{{background:linear-gradient(135deg,#060610,#1a1a3e);color:#fff;padding:80px 60px;min-height:200px}}
  .cover h1{{font-size:32px;margin:0 0 8px;font-weight:800}}
  .cover .sub{{color:rgba(255,255,255,.6);font-size:14px;margin:4px 0}}
  .cover .domain{{color:#f5a623;font-size:22px;font-weight:700;margin:12px 0}}
  .section{{padding:40px 60px;border-bottom:1px solid #eee}}
  h2{{font-size:20px;font-weight:800;color:#1a1a2e;border-bottom:3px solid #f5a623;padding-bottom:6px;margin-bottom:20px}}
  .kpi-grid{{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin:20px 0}}
  .kpi{{text-align:center;padding:20px;border-radius:10px;border:2px solid #f0f0f0}}
  .kpi-num{{font-size:36px;font-weight:900;font-family:monospace}}
  .kpi-lbl{{font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#666;margin-top:4px}}
  .chain{{background:#fff8e1;border:1px solid #ffe082;border-radius:8px;padding:14px;margin:8px 0}}
  @media print{{.section{{page-break-inside:avoid}}}}
</style>
</head>
<body>
<div class="cover">
  <div style="font-size:12px;letter-spacing:3px;color:rgba(255,255,255,.4);text-transform:uppercase;margin-bottom:16px">TheMasterRecon AI — Penetration Test Report</div>
  <h1>{title}</h1>
  <div class="domain">🎯 {domain}</div>
  <div class="sub">Generated: {time.strftime("%B %d, %Y at %H:%M UTC")}</div>
  <div class="sub">Total findings: <strong style="color:#f5a623">{len(findings)}</strong></div>
</div>

<div class="section">
  <h2>Executive Summary</h2>
  <div class="kpi-grid">
    <div class="kpi"><div class="kpi-num" style="color:#ff1744">{sev_count['critical']}</div><div class="kpi-lbl">Critical</div></div>
    <div class="kpi"><div class="kpi-num" style="color:#ff6d00">{sev_count['high']}</div><div class="kpi-lbl">High</div></div>
    <div class="kpi"><div class="kpi-num" style="color:#ffd600">{sev_count['medium']}</div><div class="kpi-lbl">Medium</div></div>
    <div class="kpi"><div class="kpi-num" style="color:#00e676">{sev_count['low']}</div><div class="kpi-lbl">Low</div></div>
    <div class="kpi"><div class="kpi-num" style="color:#2979ff">{summary.get('cvss_avg','—')}</div><div class="kpi-lbl">Avg CVSS</div></div>
  </div>
</div>

{'<div class="section"><h2>🔴 Critical Findings</h2>'+"".join(finding_card(f) for f in crit_findings)+'</div>' if crit_findings else ''}
{'<div class="section"><h2>🟠 High Findings</h2>'+"".join(finding_card(f) for f in high_findings)+'</div>' if high_findings else ''}
{'<div class="section"><h2>🟡 Medium Findings</h2>'+"".join(finding_card(f) for f in med_findings)+'</div>' if med_findings else ''}
{'<div class="section"><h2>🟢 Low / Info Findings</h2>'+"".join(finding_card(f) for f in low_findings)+'</div>' if low_findings else ''}

{'<div class="section"><h2>⛓ Exploit Chains</h2>'+"".join(f'<div class="chain"><strong>{c.get("name","Chain")}</strong> [{c.get("severity","")}] — {" → ".join(c.get("bugs",[]))}</div>' for c in chains)+"</div>" if chains else ""}

<div class="section" style="background:#f8f9fa">
  <p style="text-align:center;color:#999;font-size:11px">Generated by TheMasterRecon AI ⭐ — Confidential</p>
</div>
</body>
</html>"""
    return html
