"""
TheMasterRecon AI — External Tools Integration
Integrates the uploaded tool packages into the pipeline:

  scripts-main/     → orchestration helpers (wayback.sh, alienvault.sh,
                        lostfuzzer.sh, naabutonmap.py, virustotal.sh, urlscan.py)
  GFpattren-main/   → gf pattern files for URL classification
  payloads-main/    → curated payload wordlists
  lostfuzzer-main/  → gau+uro+httpx+nuclei DAST pipeline (shell)
  loxs-main/        → multi-bug scanner (LFI/SQLi/XSS/CRLF/OpenRedirect)
  customBsqli-main/ → blind SQLi timing scanner (BSQLI class)
  crtmon-main/      → certificate-transparency monitor (Go binary)
  swagger-main/     → swagger wordlist + XSS cookie PoC
  wayback-url-finder-main/ → Wayback CDX API URL patterns (browser ext logic
                              re-implemented as Python)

Pipeline:
  recon → normalize → score (GF patterns) → attack (loxs/bsqli/lostfuzzer)
       → confirm → report
"""

import os, re, json, logging, subprocess, tempfile, shutil, time, threading
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import urllib.request, urllib.parse, ssl

log = logging.getLogger("elite.external_tools")

# ── Tool directories (resolved relative to this file's app root) ──────────────
APP_ROOT    = Path(__file__).parent.parent
TOOLS_BASE  = APP_ROOT / "external_tools"

# Subdirectory for each package, installed by install_external_tools()
SCRIPTS_DIR    = TOOLS_BASE / "scripts-main"
GF_DIR         = TOOLS_BASE / "GFpattren-main"
PAYLOADS_DIR   = TOOLS_BASE / "payloads-main"
LOSTFUZZER_DIR = TOOLS_BASE / "lostfuzzer-main"
LOXS_DIR       = TOOLS_BASE / "loxs-main"
BSQLI_DIR      = TOOLS_BASE / "customBsqli-main"
CRTMON_DIR     = TOOLS_BASE / "crtmon-main"
SWAGGER_DIR    = TOOLS_BASE / "swagger-main"
WAYBACK_DIR    = TOOLS_BASE / "wayback-url-finder-main"


def _which(name: str) -> Optional[str]:
    return shutil.which(name)


def _run(cmd: List[str], timeout: int = 120,
         env: dict = None) -> Tuple[int, str, str]:
    """Run a subprocess, return (returncode, stdout, stderr)."""
    try:
        r = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=timeout, env=env or os.environ.copy()
        )
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return -1, "", "timeout"
    except FileNotFoundError as e:
        return -2, "", str(e)
    except Exception as e:
        return -3, "", str(e)


def _ssl_ctx():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def _http_get(url: str, timeout: int = 20) -> str:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "TMR/2.0"})
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_ctx()) as r:
            return r.read().decode("utf-8", errors="replace")
    except Exception as e:
        log.debug(f"[ext] http_get {url}: {e}")
        return ""


# ══════════════════════════════════════════════════════════════════════════════
# 1. GF PATTERN CLASSIFIER
#    Uses the JSON pattern files from GFpattren-main/ to classify URLs
#    by vulnerability type — no external binary required.
# ══════════════════════════════════════════════════════════════════════════════

# Cache: {name → compiled_regex}
_GF_CACHE: Dict[str, re.Pattern] = {}


def _load_gf_patterns(name: str) -> Optional[re.Pattern]:
    """Load a GFpattren-main JSON file and compile to regex."""
    if name in _GF_CACHE:
        return _GF_CACHE[name]
    json_file = GF_DIR / f"{name}.json"
    if not json_file.exists():
        return None
    try:
        data = json.loads(json_file.read_text())
        patterns = data.get("patterns", [])
        # Escape and join as alternation
        rx = re.compile("|".join(re.escape(p) for p in patterns if p),
                        re.IGNORECASE)
        _GF_CACHE[name] = rx
        return rx
    except Exception as e:
        log.debug(f"[gf] load {name}: {e}")
        return None


# Map: vuln_type → GF pattern file name
GF_BUG_MAP = {
    "sqli":     "sqli",
    "xss":      "xss",
    "lfi":      "lfi",
    "ssrf":     "ssrf",
    "redirect": "redirect",
    "idor":     "idor",
    "cors":     "cors",
    "ssti":     "ssti",
    "xxe":      "xxe",
    "rce":      "rce",
    "or":       "or",         # open-redirect (alias)
    "debug":    "debug_logic",
    "secret":   "secrets",
    "jwt":      "jwt",
    "upload":   "upload-fields",
    "domxss":   "domxss",
}


def gf_classify_url(url: str) -> List[str]:
    """
    Classify a URL against all GF patterns.
    Returns list of matching bug types.
    Used for endpoint scoring before attack phase.
    """
    matches = []
    for bug, pname in GF_BUG_MAP.items():
        rx = _load_gf_patterns(pname)
        if rx and rx.search(url):
            matches.append(bug)
    return matches


def gf_filter_urls(urls: List[str], pattern_name: str) -> List[str]:
    """
    Filter a list of URLs to those matching a specific GF pattern.
    Mirrors what `gf <pattern>` does on the CLI.
    """
    rx = _load_gf_patterns(pattern_name)
    if not rx:
        log.warning(f"[gf] pattern '{pattern_name}' not found in {GF_DIR}")
        return []
    return [u for u in urls if rx.search(u)]


def gf_split_by_vuln(urls: List[str]) -> Dict[str, List[str]]:
    """
    Split a URL list into per-vuln buckets using GF patterns.
    Used by the pipeline to route URLs to the right scanner.
    Returns: {"sqli": [...], "xss": [...], ...}
    """
    buckets: Dict[str, List[str]] = {k: [] for k in GF_BUG_MAP}
    for url in urls:
        for bug, pname in GF_BUG_MAP.items():
            rx = _load_gf_patterns(pname)
            if rx and rx.search(url):
                buckets[bug].append(url)
    # Deduplicate within each bucket
    return {k: list(dict.fromkeys(v)) for k, v in buckets.items() if v}


# ══════════════════════════════════════════════════════════════════════════════
# 2. SCRIPTS-MAIN WRAPPERS
#    Each script is invoked via subprocess using its exact interface.
# ══════════════════════════════════════════════════════════════════════════════

def scripts_wayback(domain: str, subdomains: bool = True,
                    status_include: str = "", status_exclude: str = "404,500",
                    extensions_only: bool = False,
                    timeout: int = 60) -> List[str]:
    """
    Invoke scripts-main/wayback.sh directly against the Wayback CDX API.
    Returns list of URLs (re-implements the shell logic in Python for reliability).

    wayback.sh interface:
      $0 domain.com [-s] [-e] [-sc codes] [-scx codes]
    """
    base = (
        f"https://web.archive.org/cdx/search/cdx?"
        f"url={'*.' if subdomains else ''}{domain}/*"
        f"&collapse=urlkey&output=text&fl=original,statuscode"
    )

    ext_regex = (
        r"xls|xml|xlsx|json|pdf|sql|doc|docx|pptx|txt|git|zip|tar\.gz|tgz"
        r"|bak|7z|rar|log|cache|secret|db|backup|yml|gz|config|csv|yaml"
        r"|md|md5|exe|dll|bin|ini|bat|sh|tar|deb|rpm|iso|img|env|apk"
        r"|msi|dmg|tmp|crt|pem|key|pub|asc"
    )
    if extensions_only:
        base += f"&filter=original:.*\\.({ext_regex})$"
    if status_include:
        rx = status_include.replace(",", "|")
        base += f"&filter=statuscode:({rx})"
    if status_exclude:
        rx = status_exclude.replace(",", "|")
        base += f"&filter=!statuscode:({rx})"

    log.info(f"[wayback] fetching URLs for {domain} (subdomains={subdomains})")
    raw = _http_get(base, timeout=timeout)
    if not raw:
        return []
    # Each line: "url statuscode" or just "url"
    urls = []
    for line in raw.strip().splitlines():
        parts = line.split()
        if parts:
            urls.append(parts[0])
    log.info(f"[wayback] {len(urls)} URLs for {domain}")
    return urls


def scripts_alienvault(domain: str, timeout: int = 60) -> List[str]:
    """
    Re-implements scripts-main/alienvault.sh in Python.
    Paginates AlienVault OTX /url_list API.
    Returns list of URLs.
    """
    urls: List[str] = []
    page, limit = 1, 500
    log.info(f"[alienvault] fetching URLs for {domain}")
    while True:
        raw = _http_get(
            f"https://otx.alienvault.com/api/v1/indicators/hostname"
            f"/{domain}/url_list?limit={limit}&page={page}",
            timeout=timeout
        )
        if not raw:
            break
        try:
            data = json.loads(raw)
            batch = [e.get("url","") for e in data.get("url_list", []) if e.get("url")]
            urls.extend(batch)
            if len(batch) < limit:
                break
            page += 1
        except Exception as e:
            log.debug(f"[alienvault] parse error p{page}: {e}")
            break
    log.info(f"[alienvault] {len(urls)} URLs for {domain}")
    return urls


def scripts_urlscan(domain: str, mode: str = "urls",
                    api_key: str = "",
                    timeout: int = 30) -> List[str]:
    """
    Implements scripts-main/urlscan.py logic.
    mode: 'subdomains' | 'urls'
    Returns list of subdomains or URLs.
    """
    if not api_key:
        api_key = os.environ.get("URLSCAN_API_KEY", "")
    if not api_key:
        log.debug("[urlscan] no API key — skipping")
        return []

    url = f"https://urlscan.io/api/v1/search/?q=page.domain:{domain}&size=100"
    try:
        req = urllib.request.Request(url, headers={
            "API-Key": api_key, "User-Agent": "TMR/2.0"
        })
        with urllib.request.urlopen(req, timeout=timeout,
                                    context=_ssl_ctx()) as r:
            text = r.read().decode("utf-8", errors="replace")
    except Exception as e:
        log.debug(f"[urlscan] {e}")
        return []

    results: List[str] = []
    if mode == "subdomains":
        matched = re.findall(
            rf"https?://((?:[a-zA-Z0-9_-]+\.)+{re.escape(domain)})", text
        )
        results = sorted(set(
            m.split("/")[0] for m in matched if m != domain
        ))
    else:
        results = sorted(set(re.findall(
            rf"https?://(?:[a-zA-Z0-9_-]+\.)+{re.escape(domain)}/[^\s\"'>]+",
            text
        )))

    log.info(f"[urlscan] {len(results)} {mode} for {domain}")
    return results


def scripts_virustotal(target: str, api_key: str = "",
                       timeout: int = 30) -> Dict:
    """
    Re-implements scripts-main/virustotal.sh (v2 API).
    Returns dict with 'hostnames' (if IP) or 'undetected_urls'.
    """
    if not api_key:
        api_key = os.environ.get("VIRUSTOTAL_API_KEY", "")
    if not api_key:
        return {}

    is_ip = bool(re.match(r"^\d+\.\d+\.\d+\.\d+$", target))
    if is_ip:
        url = f"https://www.virustotal.com/vtapi/v2/ip-address/report?apikey={api_key}&ip={target}"
    else:
        clean = re.sub(r"^https?://", "", target)
        url = f"https://www.virustotal.com/vtapi/v2/domain/report?apikey={api_key}&domain={clean}"

    raw = _http_get(url, timeout=timeout)
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        result = {"undetected_urls": []}
        if is_ip:
            result["hostnames"] = [r.get("hostname","")
                                   for r in data.get("resolutions",[])
                                   if r.get("hostname")]
        result["undetected_urls"] = [
            u[0] for u in data.get("undetected_urls", []) if u
        ]
        return result
    except Exception as e:
        log.debug(f"[virustotal] {e}")
        return {}


def scripts_naabutonmap(naabu_results_file: str,
                        output_dir: str,
                        threads: int = 4) -> bool:
    """
    Invoke scripts-main/naabutonmap.py directly.
    Input:  naabu_results.txt (lines: ip:port)
    Output: nmap XML files in output_dir
    """
    script = SCRIPTS_DIR / "naabutonmap.py"
    if not script.exists():
        log.warning("[naabutonmap] script not found")
        return False
    rc, out, err = _run(
        ["python3", str(script), "-i", naabu_results_file,
         "-o", output_dir, "-t", str(threads)],
        timeout=600
    )
    if rc != 0:
        log.warning(f"[naabutonmap] exit={rc} stderr={err[:200]}")
    else:
        log.info(f"[naabutonmap] done: {out[:100]}")
    return rc == 0


def scripts_lostfuzzer(domain: str, subdomains_file: str = "",
                       threads: int = 10,
                       output_dir: str = "",
                       timeout: int = 300) -> Dict:
    """
    Invoke scripts-main/lostfuzzer.sh (the scripts-main version, not lostfuzzer-main).
    Pipeline: gau → uro → filter ?params → httpx-toolkit → nuclei -dast

    Returns dict: {gau_count, filtered_count, live_count, nuclei_count,
                   output_dir, nuclei_results_file}
    """
    script = SCRIPTS_DIR / "lostfuzzer.sh"
    if not script.exists():
        log.warning("[lostfuzzer] scripts-main/lostfuzzer.sh not found")
        return {}

    # Check required tools
    for tool in ["gau", "uro", "httpx-toolkit", "nuclei"]:
        if not _which(tool):
            log.warning(f"[lostfuzzer] required tool missing: {tool}")
            return {"error": f"{tool} not installed"}

    if not output_dir:
        output_dir = tempfile.mkdtemp(prefix="lostfuzzer_")

    if subdomains_file:
        cmd = ["bash", str(script), "-l", subdomains_file, "-t", str(threads)]
    else:
        cmd = ["bash", str(script), "-d", domain, "-t", str(threads)]

    log.info(f"[lostfuzzer] EXEC: {' '.join(cmd)}")
    env = os.environ.copy()
    env["OUTPUT_DIR"] = output_dir

    rc, out, err = _run(cmd, timeout=timeout, env=env)
    log.info(f"[lostfuzzer] exit_code: {rc}")
    if err:
        log.warning(f"[lostfuzzer:stderr] {err[:300]}")

    # Parse summary from stdout
    result = {
        "exit_code":           rc,
        "output_dir":          output_dir,
        "gau_count":           0,
        "filtered_count":      0,
        "live_count":          0,
        "nuclei_count":        0,
        "nuclei_results_file": "",
        "stdout":              out[:500],
    }
    for line in out.splitlines():
        m = re.search(r"Total URLs fetched:\s+(\d+)", line)
        if m: result["gau_count"] = int(m.group(1))
        m = re.search(r"URLs with params:\s+(\d+)", line)
        if m: result["filtered_count"] = int(m.group(1))
        m = re.search(r"Live URLs:\s+(\d+)", line)
        if m: result["live_count"] = int(m.group(1))
        m = re.search(r"Vulnerabilities:\s+(\d+)", line)
        if m: result["nuclei_count"] = int(m.group(1))

    # Find nuclei output file in the output dir
    for f in Path(output_dir).glob("nuclei_results*"):
        result["nuclei_results_file"] = str(f)
        break

    log.info(
        f"[lostfuzzer] results_found: {result['nuclei_count']}"
        f" | gau={result['gau_count']}"
        f" | filtered={result['filtered_count']}"
        f" | live={result['live_count']}"
    )
    return result


# ══════════════════════════════════════════════════════════════════════════════
# 3. LOXS SCANNER WRAPPER
#    loxs.py has interactive prompts — we invoke the internal functions
#    programmatically by importing and calling run_*_scanner with a scan_state
#    dict that pre-fills the prompts.
# ══════════════════════════════════════════════════════════════════════════════

def loxs_scan(urls: List[str], scan_type: str,
              payload_file: str = "",
              cookie: str = "",
              threads: int = 5,
              timeout: int = 120) -> List[Dict]:
    """
    Run loxs.py scanner programmatically.
    scan_type: 'lfi' | 'sqli' | 'xss' | 'crlf' | 'or'

    loxs uses run_*_scanner(scan_state) where scan_state is a dict
    with pre-filled answers. We write urls to a temp file and pass it.

    Returns list of finding dicts: [{url, bug, payload, evidence}]
    """
    loxs_bin = LOXS_DIR / "loxs.py"
    if not loxs_bin.exists():
        log.warning(f"[loxs] loxs.py not found at {loxs_bin}")
        return []

    # Determine payload file from loxs payloads/ if not specified
    _payload_map = {
        "lfi":  str(LOXS_DIR / "payloads" / "lfi.txt"),
        "sqli": str(LOXS_DIR / "payloads" / "sqli" / "mysql.txt"),
        "xss":  str(LOXS_DIR / "payloads" / "xss.txt"),
        "crlf": "",    # loxs generates CRLF payloads internally
        "or":   str(LOXS_DIR / "payloads" / "or.txt"),
    }
    if not payload_file:
        payload_file = _payload_map.get(scan_type, "")

    # Write URLs to temp file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt",
                                     delete=False, prefix="loxs_urls_") as tf:
        tf.write("\n".join(urls))
        urls_file = tf.name

    # Write output file path
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json",
                                     delete=False, prefix="loxs_out_") as of:
        out_file = of.name

    try:
        # loxs doesn't have a clean non-interactive CLI mode,
        # so we build a wrapper invocation via subprocess with stdin pipe
        _type_map = {"lfi": "1", "or": "2", "sqli": "3", "xss": "4", "crlf": "5"}
        choice = _type_map.get(scan_type, "3")

        # Build stdin answers:
        # menu choice → verbose(n) → url/file → payload_file → cookie → threads
        stdin_input = "\n".join([
            choice,           # menu selection
            "n",              # verbose
            urls_file,        # URL list file
            payload_file,     # payload file
            cookie or "",     # cookie
            str(threads),     # threads
            "",               # any additional prompts
        ]) + "\n"

        log.info(f"[loxs] EXEC: python3 {loxs_bin} (type={scan_type}, urls={len(urls)}, payloads={payload_file})")

        env = os.environ.copy()
        env["PYTHONPATH"] = str(LOXS_DIR)

        proc = subprocess.Popen(
            ["python3", str(loxs_bin)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=str(LOXS_DIR),
            env=env,
        )
        try:
            stdout, stderr = proc.communicate(input=stdin_input, timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            stdout, stderr = proc.communicate()
            log.warning(f"[loxs] timeout after {timeout}s")

        exit_code = proc.returncode
        log.info(f"[loxs] exit_code: {exit_code}")
        if stderr:
            for line in stderr.splitlines()[:5]:
                if line.strip():
                    log.warning(f"[loxs:stderr] {line}")

        # Parse findings from stdout
        findings = _parse_loxs_output(stdout, scan_type)
        log.info(f"[loxs] results_found: {len(findings)} for {scan_type}")
        return findings

    finally:
        for f in [urls_file, out_file]:
            try: os.unlink(f)
            except: pass


def _parse_loxs_output(stdout: str, scan_type: str) -> List[Dict]:
    """Parse loxs stdout for vulnerability lines."""
    findings = []
    seen = set()

    # loxs prints findings as: [VULN] URL | PAYLOAD or [+] URL
    vuln_patterns = [
        re.compile(r"\[VULN\]\s+(.+?)\s+\|\s+(.+)", re.I),
        re.compile(r"\[VULNERABLE\]\s+(.+?)\s+\|\s+(.+)", re.I),
        re.compile(r"\[\+\]\s+Vulnerable:\s+(.+)", re.I),
        re.compile(r"\[!\]\s+XSS Found.*?URL:\s+(.+)", re.I),
        re.compile(r"Vulnerable URL:\s+(.+)", re.I),
        re.compile(r"\[SQLi\]\s+(.+)", re.I),
        re.compile(r"LFI.*?found.*?:?\s+(https?://\S+)", re.I),
        re.compile(r"CRLF.*?Injected.*?URL:\s+(https?://\S+)", re.I),
    ]

    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        for rx in vuln_patterns:
            m = rx.search(line)
            if m:
                url = m.group(1).strip()
                payload = m.group(2).strip() if m.lastindex >= 2 else ""
                key = f"{scan_type}:{url}:{payload[:30]}"
                if key not in seen:
                    seen.add(key)
                    findings.append({
                        "bug":      scan_type,
                        "url":      url,
                        "payload":  payload,
                        "evidence": line,
                        "tool":     "loxs",
                        "severity": _loxs_severity(scan_type),
                    })
                break

    return findings


def _loxs_severity(scan_type: str) -> str:
    return {
        "lfi":  "high",
        "sqli": "critical",
        "xss":  "medium",
        "crlf": "medium",
        "or":   "medium",
    }.get(scan_type, "medium")


# ══════════════════════════════════════════════════════════════════════════════
# 4. CUSTOMBSQLI WRAPPER
#    BSQLI class from customBsqli-main/lostsec.py
#    Interface: URL(s) + payload file → timing-based blind SQLi detection
# ══════════════════════════════════════════════════════════════════════════════

def bsqli_scan(urls: List[str],
               payload_file: str = "",
               cookie: str = "",
               threads: int = 5,
               timeout: int = 120) -> List[Dict]:
    """
    Run customBsqli blind SQLi scanner.
    Uses BSQLI.perform_request() with timing analysis (>= 4.5s delay = vulnerable).
    payload_file: path to payload txt (default: customBsqli-main/payloads/mysql.txt)
    """
    lostsec_py = BSQLI_DIR / "lostsec.py"
    if not lostsec_py.exists():
        log.warning(f"[bsqli] lostsec.py not found at {lostsec_py}")
        return []

    if not payload_file:
        payload_file = str(BSQLI_DIR / "payloads" / "mysql.txt")

    if not os.path.exists(payload_file):
        log.warning(f"[bsqli] payload file not found: {payload_file}")
        return []

    # Write URLs to temp file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt",
                                     delete=False, prefix="bsqli_urls_") as tf:
        tf.write("\n".join(urls))
        urls_file = tf.name

    # Build stdin: verbose(n) → url_file → payload_file → cookie → threads
    stdin_input = "\n".join(["n", urls_file, payload_file,
                              cookie or "", str(threads), ""]) + "\n"

    log.info(f"[bsqli] EXEC: python3 {lostsec_py}"
             f" (urls={len(urls)}, payload={payload_file})")

    env = os.environ.copy()
    env["PYTHONPATH"] = str(BSQLI_DIR)

    proc = subprocess.Popen(
        ["python3", str(lostsec_py)],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, cwd=str(BSQLI_DIR), env=env,
    )
    try:
        stdout, stderr = proc.communicate(input=stdin_input, timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill(); stdout, stderr = proc.communicate()
        log.warning(f"[bsqli] timeout after {timeout}s")

    exit_code = proc.returncode
    log.info(f"[bsqli] exit_code: {exit_code}")
    if stderr:
        for ln in stderr.splitlines()[:3]:
            if ln.strip(): log.warning(f"[bsqli:stderr] {ln}")

    findings = _parse_bsqli_output(stdout)
    log.info(f"[bsqli] results_found: {len(findings)}")
    return findings


def _parse_bsqli_output(stdout: str) -> List[Dict]:
    """Parse BSQLI stdout for vulnerable URL lines."""
    findings = []
    seen = set()
    # BSQLI prints: "Vulnerable: <url><payload>" or "Time-based SQLi: <url>"
    patterns = [
        re.compile(r"Vulnerable[:\s]+(\S+)", re.I),
        re.compile(r"Time-based SQLi.*?:\s+(\S+)", re.I),
        re.compile(r"\[VULNERABLE\]\s+(\S+)", re.I),
        re.compile(r"Response time.*?(\d+\.\d+)s.*?(https?://\S+)", re.I),
    ]
    for line in stdout.splitlines():
        for rx in patterns:
            m = rx.search(line)
            if m:
                url = m.group(1) if "http" in m.group(1) else (
                    m.group(2) if m.lastindex >= 2 and "http" in m.group(2)
                    else m.group(1)
                )
                if url.startswith("http") and url not in seen:
                    seen.add(url)
                    findings.append({
                        "bug":      "sqli",
                        "url":      url,
                        "payload":  "",
                        "evidence": line.strip(),
                        "tool":     "customBsqli",
                        "severity": "critical",
                    })
                break
    return findings


# ══════════════════════════════════════════════════════════════════════════════
# 5. CRTMON WRAPPER
#    Certificate Transparency monitor (Go binary)
#    crtmon -target *.example.com -json → streams JSON lines:
#    {"domain":"...", "target":"...", "not_before":"...", ...}
# ══════════════════════════════════════════════════════════════════════════════

def crtmon_get_binary() -> Optional[str]:
    """Find crtmon binary: tools/bin/ → crtmon-main/ → PATH."""
    candidates = [
        APP_ROOT / "tools" / "bin" / "crtmon",
        CRTMON_DIR / "crtmon",
    ]
    # Only add shutil.which result if it's actually a real path
    which_result = _which("crtmon")
    if which_result:
        candidates.append(Path(which_result))

    for p in candidates:
        if p and str(p) not in (".", "") and p.exists() and os.access(str(p), os.X_OK):
            return str(p)
    return None


def crtmon_monitor(domain: str,
                   scope_keyword: str = "",
                   duration_seconds: int = 60,
                   emit_fn=None) -> List[Dict]:
    """
    Run crtmon against a domain for duration_seconds.
    Streams JSON output and calls emit_fn(entry) for each new subdomain.

    crtmon interface:
      crtmon -target *.domain.com [-scope keyword] -json

    JSON output per line:
      {"domain": "sub.example.com", "target": "*.example.com",
       "not_before": "...", "not_after": "...", "issuer": "...", "log_url": "..."}
    """
    binary = crtmon_get_binary()
    if not binary:
        log.warning("[crtmon] binary not found — build with: cd crtmon-main && go build")
        return []

    target = f"*.{domain}"
    cmd = [binary, "-target", target, "-json"]
    if scope_keyword:
        cmd += ["-scope", scope_keyword]

    log.info(f"[crtmon] EXEC: {' '.join(cmd)} (duration={duration_seconds}s)")

    entries = []
    seen_domains: set = set()

    try:
        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, bufsize=1
        )

        deadline = time.monotonic() + duration_seconds

        def _drain_stderr():
            for ln in proc.stderr:
                ln = ln.strip()
                if ln: log.debug(f"[crtmon:stderr] {ln}")
        _se_t = threading.Thread(target=_drain_stderr, daemon=True)
        _se_t.start()

        for line in proc.stdout:
            if time.monotonic() > deadline:
                proc.kill()
                log.info("[crtmon] duration limit reached")
                break
            line = line.strip()
            if not line or not line.startswith("{"):
                continue
            try:
                entry = json.loads(line)
                if "error" in entry:
                    log.warning(f"[crtmon:error] {entry['error']}")
                    continue
                subdomain = entry.get("domain", "")
                if subdomain and subdomain not in seen_domains:
                    seen_domains.add(subdomain)
                    entries.append(entry)
                    if emit_fn:
                        try: emit_fn(entry)
                        except: pass
            except json.JSONDecodeError:
                continue

        try:
            exit_code = proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            exit_code = -1

        log.info(
            f"[crtmon] exit_code: {exit_code}"
            f" | results_found: {len(entries)}"
            f" | new subdomains: {len(seen_domains)}"
        )
        _se_t.join(timeout=3)

    except Exception as e:
        log.error(f"[crtmon] {e}")

    return entries


# ══════════════════════════════════════════════════════════════════════════════
# 6. SWAGGER INTEGRATION
#    swagger-main provides:
#    - swagger-wordlist.txt: paths to fuzz for Swagger/OpenAPI endpoints
#    - Swagger.yaml: example OpenAPI spec for reference
#    - xsscookie.yaml / xsstest.yaml: nuclei-style XSS templates
#    - script.js: XSS PoC payload (cookie stealer)
# ══════════════════════════════════════════════════════════════════════════════

def swagger_get_wordlist() -> List[str]:
    """Return lines from swagger-main/swagger-wordlist.txt."""
    wl = SWAGGER_DIR / "swagger-wordlist.txt"
    if not wl.exists():
        return []
    return [l.strip() for l in wl.read_text().splitlines() if l.strip()]


def swagger_discover_endpoints(base_url: str,
                                timeout: int = 30) -> List[Dict]:
    """
    Probe a base URL for Swagger/OpenAPI endpoint paths using the wordlist.
    Returns list of found endpoints: [{url, status, is_swagger}]
    """
    wordlist = swagger_get_wordlist()
    if not wordlist:
        log.warning("[swagger] wordlist not found")
        return []

    base_url = base_url.rstrip("/")
    found = []

    log.info(f"[swagger] probing {base_url} with {len(wordlist)} paths")

    for path in wordlist:
        url = f"{base_url}/{path.lstrip('/')}"
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": "TMR/2.0",
                              "Accept": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=5,
                                        context=_ssl_ctx()) as resp:
                body = resp.read(2048).decode("utf-8", errors="replace")
                status = resp.status
                is_swagger = (
                    '"swagger"' in body or '"openapi"' in body
                    or "swagger" in body.lower()[:200]
                )
                found.append({
                    "url":        url,
                    "status":     status,
                    "is_swagger": is_swagger,
                    "preview":    body[:100],
                })
        except urllib.error.HTTPError as e:
            if e.code not in (404, 400):
                found.append({"url": url, "status": e.code, "is_swagger": False})
        except Exception:
            pass

    swagger_hits = [f for f in found if f.get("is_swagger")]
    log.info(f"[swagger] {len(found)} responded, {len(swagger_hits)} swagger endpoints")
    return found


def swagger_xss_poc() -> str:
    """Return the XSS PoC JavaScript from swagger-main/script.js."""
    js = SWAGGER_DIR / "script.js"
    if not js.exists():
        return ""
    return js.read_text()


# ══════════════════════════════════════════════════════════════════════════════
# 7. WAYBACK-URL-FINDER (re-implemented from browser extension popup.js logic)
#    The extension uses web.archive.org CDX API — same API as wayback.sh.
#    We expose the 4 modes: domain, wildcard, specific, extensions
# ══════════════════════════════════════════════════════════════════════════════

def wayback_cdx(domain: str, mode: str = "wildcard",
                specific_path: str = "",
                timeout: int = 60) -> List[str]:
    """
    Re-implements wayback-url-finder popup.js CDX API calls.

    mode:
      'domain'   → domain.com/* (main domain only)
      'wildcard' → *.domain.com/* (subdomains included)
      'specific' → domain.com/path/* (specific path)
      'extensions' → files with sensitive extensions

    Returns list of archived URLs.
    """
    ext_list = (
        "xls|xml|xlsx|json|pdf|sql|doc|docx|pptx|txt|zip|tar\\.gz|tgz|bak"
        "|7z|rar|log|cache|secret|db|backup|yml|gz|git|config|csv|yaml|md"
        "|md5|exe|dll|bin|ini|bat|sh|tar|deb|rpm|iso|img|apk|msi|env|dmg"
        "|tmp|crt|pem|key|pub|asc"
    )

    if mode == "wildcard":
        cdx_url = (
            f"https://web.archive.org/cdx/search/cdx"
            f"?url=*.{domain}/*&collapse=urlkey&output=text&fl=original"
        )
    elif mode == "domain":
        cdx_url = (
            f"https://web.archive.org/cdx/search/cdx"
            f"?url={domain}/*&collapse=urlkey&output=text&fl=original"
        )
    elif mode == "specific" and specific_path:
        cdx_url = (
            f"https://web.archive.org/cdx/search/cdx"
            f"?url={specific_path}/*&collapse=urlkey&output=text&fl=original"
        )
    elif mode == "extensions":
        cdx_url = (
            f"https://web.archive.org/cdx/search/cdx"
            f"?url=*.{domain}/*&collapse=urlkey&output=text&fl=original"
            f"&filter=original:.*\\.({ext_list})$"
        )
    else:
        cdx_url = (
            f"https://web.archive.org/cdx/search/cdx"
            f"?url=*.{domain}/*&collapse=urlkey&output=text&fl=original"
        )

    log.info(f"[wayback_cdx] mode={mode} domain={domain}")
    raw = _http_get(cdx_url, timeout=timeout)
    if not raw:
        return []
    urls = [l.strip() for l in raw.splitlines() if l.strip()]
    log.info(f"[wayback_cdx] {len(urls)} archived URLs (mode={mode})")
    return urls


# ══════════════════════════════════════════════════════════════════════════════
# 8. PAYLOADS-MAIN HELPER
#    Returns paths and contents of curated payload files.
# ══════════════════════════════════════════════════════════════════════════════

# Map: tag → filename in payloads-main/
PAYLOAD_FILE_MAP = {
    "sqli":             "allsqli.txt",
    "sqli_blind":       "blindsqli.txt",
    "lfi_unix":         "directory_traversal_unix.txt",
    "lfi_win":          "directory_traversal_win.txt",
    "xss":              "xss_html_full.txt",   # if available
    "403_header":       "403_header_payloads.txt",
    "403_url":          "403_url_payloads.txt",
    "admin":            "admin.txt",
    "api":              "api.txt",
    "backup":           "backup_files_only.txt",
    "config":           "config.txt",
    "crlf":             "crlf.txt",
    "env":              "env.txt",
    "all_fuzz":         "all_fuzz.txt",
    "fuzz":             "fuzz.txt",
    "secrets":          "secrets.txt",
    "sql":              "SQL.txt",
}


def payloads_get_file(tag: str) -> Optional[Path]:
    """Return Path to a payload file by tag, or None if not found."""
    fname = PAYLOAD_FILE_MAP.get(tag)
    if not fname:
        return None
    p = PAYLOADS_DIR / fname
    return p if p.exists() else None


def payloads_load(tag: str, limit: int = 0) -> List[str]:
    """Load payload lines by tag. limit=0 means all."""
    p = payloads_get_file(tag)
    if not p:
        log.debug(f"[payloads] tag '{tag}' not found")
        return []
    lines = [l.strip() for l in p.read_text(errors="replace").splitlines()
             if l.strip()]
    return lines[:limit] if limit > 0 else lines


def payloads_list() -> Dict[str, Dict]:
    """List all available payload files with line counts."""
    result = {}
    for tag, fname in PAYLOAD_FILE_MAP.items():
        p = PAYLOADS_DIR / fname
        if p.exists():
            try:
                count = p.read_text(errors="replace").count("\n")
                result[tag] = {"file": fname, "lines": count, "path": str(p)}
            except Exception:
                pass
    return result


# ══════════════════════════════════════════════════════════════════════════════
# 9. FULL PIPELINE: recon → normalize → score → attack → confirm
# ══════════════════════════════════════════════════════════════════════════════

def pipeline_run(domain: str,
                 live_hosts: List[str],
                 raw_endpoints: List[str],
                 config: Dict = None,
                 emit_fn=None) -> Dict:
    """
    Full pipeline using the uploaded tools:

    1. URL enrichment: wayback_cdx + alienvault + scripts_urlscan
    2. Normalization: dedup, strip cache params
    3. GF scoring: classify URLs by bug type
    4. Attack:
       - loxs: LFI, SQLi (error-based), XSS, CRLF, OpenRedirect
       - bsqli: blind SQLi (timing)
       - lostfuzzer: gau+nuclei DAST
    5. swagger discovery
    6. Return aggregated findings

    config keys:
      urlscan_api_key, virustotal_api_key, cookie,
      threads, timeout, skip_enrichment, skip_lostfuzzer
    """
    cfg = config or {}
    findings: List[Dict] = []
    stats: Dict = {
        "domain":         domain,
        "raw_endpoints":  len(raw_endpoints),
        "enriched_urls":  0,
        "gf_buckets":     {},
        "findings":       0,
    }

    def _emit(msg: str):
        log.info(msg)
        if emit_fn:
            try: emit_fn({"type": "step", "name": "ext_pipeline",
                          "state": "run", "meta": msg})
            except: pass

    # ── Step 1: URL enrichment ─────────────────────────────────────────────
    all_urls = list(raw_endpoints)

    if not cfg.get("skip_enrichment"):
        _emit(f"[pipeline] enriching URLs for {domain}")

        wb_urls = wayback_cdx(domain, mode="wildcard", timeout=60)
        all_urls.extend(wb_urls)
        _emit(f"[pipeline] wayback: +{len(wb_urls)} URLs")

        av_urls = scripts_alienvault(domain, timeout=60)
        all_urls.extend(av_urls)
        _emit(f"[pipeline] alienvault: +{len(av_urls)} URLs")

        if cfg.get("urlscan_api_key"):
            us_urls = scripts_urlscan(domain, mode="urls",
                                      api_key=cfg["urlscan_api_key"])
            all_urls.extend(us_urls)
            _emit(f"[pipeline] urlscan: +{len(us_urls)} URLs")

    # ── Step 2: Normalize ──────────────────────────────────────────────────
    _CACHE_PARAMS = {"rand","_","v","ver","version","cb","ts","t","nocache","nc"}
    seen_n: set = set()
    normalized: List[str] = []
    for url in all_urls:
        try:
            p = urllib.parse.urlparse(url)
            qs = urllib.parse.parse_qs(p.query, keep_blank_values=True)
            qs_c = {k: v for k, v in qs.items()
                    if k.lower() not in _CACHE_PARAMS}
            norm = urllib.parse.urlunparse(p._replace(
                query=urllib.parse.urlencode(qs_c, doseq=True)
            ))
        except Exception:
            norm = url
        if norm not in seen_n:
            seen_n.add(norm)
            normalized.append(url)

    # Keep only HTTP(S) URLs
    normalized = [u for u in normalized if u.startswith(("http://","https://"))]
    stats["enriched_urls"] = len(normalized)
    _emit(f"[pipeline] normalized: {len(normalized)} unique HTTP URLs")

    # ── Step 3: GF scoring / split by bug type ─────────────────────────────
    buckets = gf_split_by_vuln(normalized)
    stats["gf_buckets"] = {k: len(v) for k, v in buckets.items()}
    _emit(
        f"[pipeline] GF classification: "
        + ", ".join(f"{k}={len(v)}" for k, v in buckets.items() if v)
    )

    # ── Step 4: Attack phase ───────────────────────────────────────────────
    _cookie  = cfg.get("cookie", "")
    _threads = int(cfg.get("threads", 5))
    _timeout = int(cfg.get("timeout", 120))

    # loxs: route each GF bucket to the right scanner
    loxs_route = {
        "lfi":      "lfi",
        "sqli":     "sqli",
        "xss":      "xss",
        "redirect": "or",
    }
    for gf_key, loxs_type in loxs_route.items():
        urls_for_bug = buckets.get(gf_key, [])[:50]  # cap per type
        if urls_for_bug:
            _emit(f"[pipeline] loxs/{loxs_type}: {len(urls_for_bug)} URLs")
            new_f = loxs_scan(
                urls_for_bug, loxs_type,
                cookie=_cookie, threads=_threads, timeout=_timeout
            )
            findings.extend(new_f)
            _emit(f"[pipeline] loxs/{loxs_type}: {len(new_f)} findings")

    # blind SQLi on sqli-classified URLs
    sqli_urls = buckets.get("sqli", [])[:30]
    if sqli_urls:
        _emit(f"[pipeline] bsqli: {len(sqli_urls)} URLs")
        b_findings = bsqli_scan(
            sqli_urls, cookie=_cookie,
            threads=_threads, timeout=_timeout
        )
        findings.extend(b_findings)
        _emit(f"[pipeline] bsqli: {len(b_findings)} blind SQLi findings")

    # lostfuzzer: gau+nuclei DAST on live hosts
    if not cfg.get("skip_lostfuzzer") and live_hosts:
        _emit(f"[pipeline] lostfuzzer: DAST on {len(live_hosts)} hosts")
        lf_result = scripts_lostfuzzer(domain, threads=_threads, timeout=300)
        if lf_result.get("nuclei_count", 0) > 0:
            _emit(f"[pipeline] lostfuzzer: {lf_result['nuclei_count']} nuclei hits")
            stats["lostfuzzer"] = lf_result

    # ── Step 5: Swagger discovery on live hosts ────────────────────────────
    for host in live_hosts[:5]:
        sw = swagger_discover_endpoints(host, timeout=30)
        swagger_hits = [e for e in sw if e.get("is_swagger")]
        if swagger_hits:
            _emit(f"[pipeline] swagger: {len(swagger_hits)} spec endpoints on {host}")
            for e in swagger_hits:
                findings.append({
                    "bug":      "expose",
                    "url":      e["url"],
                    "title":    "Swagger/OpenAPI Spec Exposed",
                    "severity": "medium",
                    "tool":     "swagger",
                    "evidence": e.get("preview",""),
                })

    stats["findings"] = len(findings)
    _emit(f"[pipeline] DONE: {len(findings)} total findings")
    return {"findings": findings, "stats": stats}


# ══════════════════════════════════════════════════════════════════════════════
# 10. INSTALL HELPER — copies tool files into external_tools/
# ══════════════════════════════════════════════════════════════════════════════

def get_status() -> Dict:
    """Return availability status for each tool package."""
    return {
        "scripts_main":    SCRIPTS_DIR.exists(),
        "gf_patterns":     GF_DIR.exists(),
        "payloads":        PAYLOADS_DIR.exists(),
        "lostfuzzer":      (LOSTFUZZER_DIR / "lostfuzzer.sh").exists(),
        "loxs":            (LOXS_DIR / "loxs.py").exists(),
        "bsqli":           (BSQLI_DIR / "lostsec.py").exists(),
        "crtmon_binary":   bool(crtmon_get_binary()),
        "swagger":         (SWAGGER_DIR / "swagger-wordlist.txt").exists(),
        "wayback_finder":  (WAYBACK_DIR / "popup.js").exists(),
        "gf_binary":       bool(_which("gf")),
        "gau":             bool(_which("gau")),
        "uro":             bool(_which("uro")),
        "httpx_toolkit":   bool(_which("httpx-toolkit")),
        "nuclei":          bool(_which("nuclei")),
        "nmap":            bool(_which("nmap")),
    }
