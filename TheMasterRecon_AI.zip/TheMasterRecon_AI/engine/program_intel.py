"""
TheMasterRecon AI — Program Intelligence
Stores bug bounty program metadata, enforces scope, deduplicates findings.
"""
import os, re, json, logging, hashlib, sqlite3, threading, time
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import urlparse

log = logging.getLogger("elite.program_intel")

_DATA_DIR = Path(os.environ.get("TMR_DATA_DIR", "./data"))
_DB_PATH  = str(_DATA_DIR / "programs.db")
_lock     = threading.Lock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS programs (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    platform    TEXT DEFAULT '',
    url         TEXT DEFAULT '',
    meta        TEXT DEFAULT '{}',
    created_at  TEXT DEFAULT (datetime('now')),
    updated_at  TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS scope_rules (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    program_id  TEXT NOT NULL,
    type        TEXT NOT NULL,   -- 'domain', 'wildcard', 'cidr', 'url_prefix'
    value       TEXT NOT NULL,
    in_scope    INTEGER DEFAULT 1,  -- 1=in, 0=out
    UNIQUE(program_id, type, value)
);
CREATE TABLE IF NOT EXISTS program_config (
    program_id      TEXT PRIMARY KEY,
    severity_min    TEXT DEFAULT 'low',
    allowed_bugs    TEXT DEFAULT '[]',   -- JSON list; empty=all
    confidence_min  INTEGER DEFAULT 70,
    rate_limit_rps  INTEGER DEFAULT 10,
    report_format   TEXT DEFAULT 'generic',
    notes           TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_scope_program ON scope_rules(program_id);
"""


def _conn() -> sqlite3.Connection:
    _DATA_DIR.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(_DB_PATH, timeout=10, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.executescript(_SCHEMA)
    return c


# ── Public API ─────────────────────────────────────────────────────────────────

def import_program(program: Dict) -> str:
    """
    Import or update a program.
    program dict keys:
      id, name, platform, url,
      in_scope (list of domain/wildcard strings),
      out_of_scope (list),
      allowed_bugs (list, empty=all),
      severity_min (str),
      confidence_min (int),
      rate_limit_rps (int),
      report_format (str: hackerone|intigriti|yeswehack|generic)
      notes (str)
    Returns program_id.
    """
    pid  = program.get("id") or re.sub(r"[^a-z0-9_]", "_", program.get("name","prog").lower())
    name = program.get("name", pid)
    with _lock:
        conn = _conn()
        conn.execute(
            "INSERT OR REPLACE INTO programs(id,name,platform,url,meta,updated_at)"
            " VALUES(?,?,?,?,?,datetime('now'))",
            (pid, name,
             program.get("platform",""),
             program.get("url",""),
             json.dumps({k: program[k] for k in program
                         if k not in ("id","name","platform","url","in_scope","out_of_scope",
                                      "allowed_bugs","severity_min","confidence_min",
                                      "rate_limit_rps","report_format","notes")}))
        )
        # Scope rules
        for domain in program.get("in_scope", []):
            _add_scope(conn, pid, domain, in_scope=True)
        for domain in program.get("out_of_scope", []):
            _add_scope(conn, pid, domain, in_scope=False)
        # Config
        conn.execute(
            "INSERT OR REPLACE INTO program_config"
            "(program_id,severity_min,allowed_bugs,confidence_min,rate_limit_rps,report_format,notes)"
            " VALUES(?,?,?,?,?,?,?)",
            (pid,
             program.get("severity_min","low"),
             json.dumps(program.get("allowed_bugs",[])),
             program.get("confidence_min",70),
             program.get("rate_limit_rps",10),
             program.get("report_format","generic"),
             program.get("notes",""))
        )
        conn.commit()
    log.info(f"[program_intel] imported program: {pid} ({name})")
    return pid


def _add_scope(conn, program_id: str, value: str, in_scope: bool):
    """Classify and insert a scope rule."""
    value = value.strip().lower()
    if not value: return
    if value.startswith("*."):
        rule_type = "wildcard"
    elif re.match(r"^\d+\.\d+\.\d+\.\d+(/\d+)?$", value):
        rule_type = "cidr"
    elif value.startswith("http"):
        rule_type = "url_prefix"
    else:
        rule_type = "domain"
    conn.execute(
        "INSERT OR IGNORE INTO scope_rules(program_id,type,value,in_scope) VALUES(?,?,?,?)",
        (program_id, rule_type, value, 1 if in_scope else 0)
    )


def is_in_scope(domain: str, program_id: str) -> bool:
    """
    Return True if domain is in-scope for the program.
    Checks wildcard, exact domain, and url_prefix rules.
    Out-of-scope rules take precedence.
    """
    domain = re.sub(r"^https?://", "", domain.lower()).split("/")[0].split(":")[0]
    with _lock:
        conn = _conn()
        rules = conn.execute(
            "SELECT type, value, in_scope FROM scope_rules WHERE program_id=?",
            (program_id,)
        ).fetchall()

    if not rules:
        # No scope defined → assume all in-scope
        return True

    in_matches  = []
    out_matches = []
    for r in rules:
        rt, rv, ins = r["type"], r["value"], r["in_scope"]
        matched = False
        if rt == "domain"    and domain == rv:               matched = True
        if rt == "wildcard"  and domain.endswith(rv[1:]):    matched = True  # *.example.com
        if rt == "url_prefix"and domain in rv:               matched = True
        if matched:
            (in_matches if ins else out_matches).append(rv)

    if out_matches:
        log.debug(f"[scope] {domain} OUT of scope: {out_matches}")
        return False
    if in_matches:
        return True
    # No match → out of scope by default if explicit scope was defined
    return False


def allowed_test(bug_type: str, program_id: str) -> bool:
    """Return True if bug_type is allowed for the program."""
    with _lock:
        conn = _conn()
        row = conn.execute(
            "SELECT allowed_bugs FROM program_config WHERE program_id=?",
            (program_id,)
        ).fetchone()
    if not row: return True
    allowed = json.loads(row["allowed_bugs"] or "[]")
    return not allowed or bug_type.lower() in allowed


def get_config(program_id: str) -> Dict:
    """Return program config dict."""
    with _lock:
        conn = _conn()
        row = conn.execute(
            "SELECT * FROM program_config WHERE program_id=?",
            (program_id,)
        ).fetchone()
    if not row: return {}
    return dict(row)


def dedupe_key(finding: Dict) -> str:
    """
    Generate a stable dedup key for a finding.
    Normalizes URL (strips session tokens), param, bug_type.
    """
    url   = finding.get("url", "")
    param = finding.get("param", "")
    bug   = finding.get("bug", finding.get("bug_type", ""))

    # Normalize URL: strip common session/token params
    _TOKEN_PARAMS = re.compile(
        r"[?&](session|token|csrf|nonce|_|timestamp|t|ts|rand|key"
        r"|auth|api_key|apikey|access_token|jwt)=[^&]*",
        re.I
    )
    url_norm = _TOKEN_PARAMS.sub("", url).rstrip("?&")

    # Normalize: strip numeric IDs to catch id=1 vs id=2 same endpoint
    url_norm = re.sub(r"=\d+", "=N", url_norm)

    raw = f"{bug}:{url_norm}:{param}".lower()
    return hashlib.sha256(raw.encode()).hexdigest()[:24]


def list_programs() -> List[Dict]:
    """List all programs with scope summary."""
    with _lock:
        conn = _conn()
        progs = [dict(r) for r in conn.execute("SELECT * FROM programs ORDER BY name").fetchall()]
        for p in progs:
            scope_count = conn.execute(
                "SELECT COUNT(*) FROM scope_rules WHERE program_id=? AND in_scope=1",
                (p["id"],)
            ).fetchone()[0]
            p["in_scope_count"] = scope_count
            cfg = conn.execute(
                "SELECT * FROM program_config WHERE program_id=?",
                (p["id"],)
            ).fetchone()
            if cfg: p.update(dict(cfg))
    return progs


def get_program(program_id: str) -> Optional[Dict]:
    """Get full program details including scope rules."""
    with _lock:
        conn = _conn()
        row = conn.execute("SELECT * FROM programs WHERE id=?", (program_id,)).fetchone()
        if not row: return None
        p = dict(row)
        rules = conn.execute("SELECT * FROM scope_rules WHERE program_id=?", (program_id,)).fetchall()
        cfg   = conn.execute("SELECT * FROM program_config WHERE program_id=?", (program_id,)).fetchone()
        p["scope_rules"] = [dict(r) for r in rules]
        if cfg: p.update(dict(cfg))
    return p
