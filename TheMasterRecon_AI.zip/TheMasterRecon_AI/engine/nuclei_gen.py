
"""
BugScan ELITE — Nuclei Template Auto-Generator
When you find a vulnerability manually, auto-generate a Nuclei template.
Uses Anthropic Claude API if key is set, falls back to rule-based generation.
"""
import os, json, re, hashlib, logging, urllib.request, ssl
from typing import Optional

log = logging.getLogger("elite.nuclei_gen")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _ai_generate(finding: dict) -> Optional[str]:
    """Use Claude API to generate a Nuclei template from a finding."""
    api_key = os.getenv("ANTHROPIC_API_KEY","")
    if not api_key: return None
    try:
        prompt = f"""Generate a Nuclei YAML template for this vulnerability:

Bug Type: {finding.get("bug","")}
Severity: {finding.get("severity","")}
URL: {finding.get("url","")}
Title: {finding.get("title","")}
Param: {finding.get("param","")}
Payload: {finding.get("payload","")}
POC: {finding.get("poc","")}

Return ONLY valid Nuclei v2 YAML. No explanation. No markdown blocks."""

        body = json.dumps({
            "model": "claude-sonnet-4-6",
            "max_tokens": 1000,
            "messages": [{"role":"user","content": prompt}]
        }).encode()
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=body,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=20, context=_ctx()) as r:
            d = json.loads(r.read())
            text = d["content"][0]["text"]
            # Clean markdown if present
            text = re.sub(r"```ya?ml", "", text)
            text = re.sub(r"```", "", text)
            return text.strip()
    except Exception as e:
        log.debug(f"[nuclei_gen] AI: {e}")
        return None

def _rule_generate(finding: dict) -> str:
    """Rule-based Nuclei template generation (no API key needed)."""
    bug      = finding.get("bug","generic")
    sev      = finding.get("severity","medium").lower()
    url      = finding.get("url","")
    title    = finding.get("title","Vulnerability")
    param    = finding.get("param","")
    payload  = finding.get("payload","")
    preview  = finding.get("preview","")

    # Parse URL
    import urllib.parse
    try: parsed = urllib.parse.urlparse(url)
    except: parsed = None
    path = (parsed.path if parsed else "/") or "/"

    # Build template ID
    uid = hashlib.md5(f"{bug}{url}{param}".encode()).hexdigest()[:8]
    template_id = f"bugscan-{bug}-{uid}"

    # Severity mapping
    nuclei_sev = {"critical":"critical","high":"high","medium":"medium","low":"low","info":"info"}.get(sev,"medium")

    # Tags
    tags_map = {
        "xss":          "xss,reflected",
        "sqli":         "sqli,injection",
        "ssrf":         "ssrf",
        "lfi":          "lfi,traversal",
        "rce":          "rce",
        "ssti":         "ssti,injection",
        "idor":         "idor,auth-bypass",
        "bxss":         "xss,blind-xss",
        "cors":         "cors,misconfiguration",
        "graphql":      "graphql,introspection",
        "oauth":        "oauth,misconfiguration",
        "jwt":          "jwt,auth-bypass",
        "smuggling":    "request-smuggling,http",
        "misconfig":    "misconfiguration",
        "buckets":      "misconfig,aws,storage",
        "takeover":     "takeover,dns",
    }
    tags = tags_map.get(bug, f"{bug},bugscan")

    # Build matcher based on bug type
    matchers = ""
    if bug == "xss" and payload:
        safe_payload = payload.replace("'",'"')
        matchers = f"""  matchers-condition: and
  matchers:
    - type: word
      part: body
      words:
        - "{safe_payload[:60]}"
    - type: status
      status: [200]"""
    elif bug == "sqli":
        matchers = """  matchers-condition: or
  matchers:
    - type: word
      part: body
      words:
        - "SQL syntax"
        - "mysql_fetch"
        - "ORA-"
        - "PostgreSQL"
        - "syntax error"
      condition: or
    - type: status
      status: [500]"""
    elif bug == "ssrf" and preview:
        matchers = """  matchers:
    - type: word
      part: body
      words:
        - "compute.internal"
        - "amazonaws.com"
        - "169.254"
      condition: or"""
    elif bug in ("misconfig","cors","graphql","oauth"):
        matchers = """  matchers:
    - type: status
      status: [200]"""
        if preview:
            # Add a word matcher from the preview
            word = preview[:50].replace('"','').replace("'","").strip()
            if word:
                matchers += f"""
    - type: word
      part: body
      words:
        - "{word[:40]}" """
    else:
        matchers = """  matchers:
    - type: status
      status: [200, 201, 202]"""

    # Build request
    if param and payload:
        request_section = f"""http:
  - method: GET
    path:
      - "{{{{BaseURL}}}}{path}?{param}={urllib.parse.quote(payload[:60])}"
    headers:
      User-Agent: "Mozilla/5.0"
{matchers}"""
    elif path:
        request_section = f"""http:
  - method: GET
    path:
      - "{{{{BaseURL}}}}{path}"
    headers:
      User-Agent: "Mozilla/5.0"
{matchers}"""
    else:
        request_section = f"""http:
  - method: GET
    path:
      - "{{{{BaseURL}}}}/"
{matchers}"""

    template = f"""id: {template_id}

info:
  name: "{title[:80]}"
  author: bugscan-elite
  severity: {nuclei_sev}
  description: |
    {title}
    Discovered by BugScan ELITE automated scanner.
  tags: {tags}
  metadata:
    bugscan-bug: {bug}
    bugscan-url: "{url[:100]}"

{request_section}
"""
    return template


def generate_nuclei_template(finding: dict) -> dict:
    """
    Auto-generate a Nuclei template from a BugScan finding.
    Returns dict with: template_id, yaml, filename, source
    """
    bug = finding.get("bug","generic")
    uid = hashlib.md5(json.dumps(finding, sort_keys=True).encode()).hexdigest()[:8]
    template_id = f"bugscan-{bug}-{uid}"
    filename    = f"{template_id}.yaml"

    # Try AI first, fall back to rule-based
    yaml = _ai_generate(finding)
    source = "ai"
    if not yaml:
        yaml = _rule_generate(finding)
        source = "rule-based"

    log.info(f"[nuclei_gen] generated {filename} ({source})")

    # Save to nuclei_templates/ directory
    try:
        import pathlib
        out_dir = pathlib.Path("nuclei_templates")
        out_dir.mkdir(exist_ok=True)
        (out_dir / filename).write_text(yaml, encoding="utf-8")
        log.info(f"[nuclei_gen] saved: nuclei_templates/{filename}")
    except Exception as e:
        log.debug(f"[nuclei_gen] save error: {e}")

    return {
        "template_id": template_id,
        "filename":    filename,
        "yaml":        yaml,
        "source":      source,
    }


def generate_from_scan_results(findings: list) -> list:
    """Generate Nuclei templates for all confirmed findings."""
    generated = []
    # Only generate for confirmed high-value findings
    worthy = [f for f in findings
              if f.get("severity") in ("critical","high")
              and f.get("bug") not in ("panels","misconfig")]
    for finding in worthy[:20]:  # cap at 20 per scan
        try:
            t = generate_nuclei_template(finding)
            generated.append(t)
        except Exception as e:
            log.debug(f"[nuclei_gen] {e}")
    return generated

# Alias for compatibility
generate_all = _ctx


def generate_all(findings: list, domain: str, output_dir: str = None) -> list:
    """
    Generate Nuclei templates for all findings.
    Called by /nuclei_templates route in app.py.
    Returns list of generated template file paths.
    """
    import os, tempfile
    if output_dir is None:
        output_dir = os.path.join(tempfile.gettempdir(), "nuclei_templates", domain.replace("/","_"))
    os.makedirs(output_dir, exist_ok=True)

    paths = []
    seen  = set()
    for finding in findings:
        bug = finding.get("bug", finding.get("type", ""))
        url = finding.get("url", "")
        key = f"{bug}:{url}"
        if key in seen:
            continue
        seen.add(key)
        try:
            path = generate_nuclei_template(finding, output_dir)
            if path:
                paths.append(path)
        except Exception as e:
            log.debug(f"[nuclei_gen] skip {bug}: {e}")

    # Also try from scan results  
    if findings:
        try:
            extra = generate_from_scan_results(findings, output_dir)
            paths.extend(extra)
        except Exception:
            pass

    log.info(f"[nuclei_gen] generated {len(paths)} templates for {domain}")
    return list(set(paths))
