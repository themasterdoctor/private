"""
TheMasterRecon AI — Nuclei Engine
Complete integration with ProjectDiscovery Nuclei:
- Auto-install nuclei binary
- Auto-update 9,000+ templates daily
- Template-based scanning with CVE coverage
- Plugin/extension system via YAML templates
"""
import os, re, json, logging, subprocess, threading, time, shutil, platform
import urllib.request, ssl, gzip, tarfile, tempfile
from pathlib import Path
from typing import List, Dict, Optional
from datetime import datetime, timedelta

log = logging.getLogger("elite.nuclei")

APP_ROOT      = Path(__file__).parent.parent
NUCLEI_DIR    = APP_ROOT / "tools" / "nuclei"
TEMPLATES_DIR = APP_ROOT / "nuclei-templates"
CUSTOM_TPL    = APP_ROOT / "custom-templates"   # user plugins live here
NUCLEI_BIN    = NUCLEI_DIR / "nuclei"
UPDATE_FILE   = APP_ROOT / ".nuclei_last_update"

_update_lock = threading.Lock()
_install_lock = threading.Lock()


# ── Install ──────────────────────────────────────────────────────────────────

def _platform_tag() -> str:
    sys = platform.system().lower()
    arch = platform.machine().lower()
    if arch in ("x86_64", "amd64"): arch = "amd64"
    elif arch in ("aarch64", "arm64"): arch = "arm64"
    else: arch = "amd64"
    if sys == "linux":   return f"linux_{arch}"
    if sys == "darwin":  return f"macOS_{arch}"
    if sys == "windows": return f"windows_{arch}.exe"
    return f"linux_{arch}"


def _latest_nuclei_release() -> Optional[str]:
    """Get latest Nuclei release version from GitHub."""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(
            "https://api.github.com/repos/projectdiscovery/nuclei/releases/latest",
            headers={"Accept": "application/vnd.github.v3+json",
                     "User-Agent": "TheMasterRecon-AI/2.0"})
        with urllib.request.urlopen(req, timeout=10, context=ctx) as r:
            data = json.loads(r.read())
            return data.get("tag_name", "")
    except Exception as e:
        log.debug(f"[nuclei] release check: {e}")
        return None


def install_nuclei(force: bool = False) -> Dict:
    """
    Download and install the nuclei binary.
    Tries in order:
      1. GitHub release direct download (ZIP)
      2. go install (if Go is available)
      3. Returns install instructions if both fail
    """
    with _install_lock:
        # Check if already installed
        existing = get_binary()
        if not force and existing:
            return {"ok": True, "path": existing, "installed": True,
                    "note": "Already installed"}

        NUCLEI_DIR.mkdir(parents=True, exist_ok=True)

        # ── Method 1: GitHub release download ─────────────────────────────
        tag  = _latest_nuclei_release() or "v3.3.8"
        ptag = _platform_tag()
        filename = f"nuclei_{tag.lstrip('v')}_{ptag}.zip"
        url = f"https://github.com/projectdiscovery/nuclei/releases/download/{tag}/{filename}"
        log.info(f"[nuclei] downloading {tag} for {ptag}...")
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode    = ssl.CERT_NONE
            with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tf:
                req = urllib.request.Request(
                    url, headers={"User-Agent": "TheMasterRecon-AI/2.0"})
                with urllib.request.urlopen(req, timeout=120, context=ctx) as r:
                    tf.write(r.read())
                tmp_path = tf.name

            import zipfile
            with zipfile.ZipFile(tmp_path) as z:
                for name in z.namelist():
                    if "nuclei" in name.lower() and not name.endswith("/"):
                        z.extract(name, str(NUCLEI_DIR))
                        extracted = NUCLEI_DIR / name
                        if extracted != NUCLEI_BIN:
                            extracted.rename(NUCLEI_BIN)
                        break
            try: os.unlink(tmp_path)
            except: pass
            os.chmod(NUCLEI_BIN, 0o755)
            # Verify it runs
            ver = subprocess.run(
                [str(NUCLEI_BIN), "-version"],
                capture_output=True, text=True, timeout=10)
            version = (ver.stdout + ver.stderr).strip().split("\n")[0]
            log.info(f"[nuclei] installed: {version}")
            return {"ok": True, "path": str(NUCLEI_BIN),
                    "version": version, "installed": True,
                    "method": "github"}
        except Exception as e1:
            log.warning(f"[nuclei] GitHub download failed: {e1}")

        # ── Method 2: go build from cloned source ─────────────────────────
        go_bin = shutil.which("go")
        if go_bin:
            # First try go install (works on Kali with full internet)
            log.info("[nuclei] trying go install...")
            try:
                env2 = {**os.environ,
                        "GOPATH":    str(Path.home() / "go"),
                        "GONOSUMDB": "*",
                        "GOFLAGS":   "-mod=mod",
                        "GOPROXY":   "direct"}
                r2 = subprocess.run(
                    [go_bin, "install",
                     "github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"],
                    capture_output=True, text=True, timeout=300, env=env2)
                if r2.returncode == 0:
                    installed = get_binary()
                    if installed:
                        return {"ok": True, "path": installed,
                                "installed": True, "method": "go install"}
            except Exception as e2:
                log.warning(f"[nuclei] go install failed: {e2}")

            # Try building nuclei v2 from cloned source (works with Go 1.20+)
            try:
                import tempfile as _tf
                build_dir = Path(_tf.mkdtemp()) / "nuclei"
                log.info("[nuclei] cloning nuclei v2.9.15 source...")
                clone = subprocess.run(
                    ["git", "clone", "--depth=1", "--branch", "v2.9.15",
                     "https://github.com/projectdiscovery/nuclei.git", str(build_dir)],
                    capture_output=True, text=True, timeout=60)
                if clone.returncode == 0:
                    src_v2 = build_dir / "v2"
                    if src_v2.exists():
                        log.info("[nuclei] building from source...")
                        NUCLEI_DIR.mkdir(parents=True, exist_ok=True)
                        cache_dir = str(Path.home() / "go/pkg/mod/cache/download")
                        build_env = {**os.environ,
                            "GONOSUMDB": "*", "GOPROXY": f"file://{cache_dir},direct",
                            "GOFLAGS": "-mod=mod", "GOPATH": str(Path.home() / "go")}
                        build = subprocess.run(
                            [go_bin, "build", "-o", str(NUCLEI_BIN), "./cmd/nuclei/"],
                            capture_output=True, text=True, timeout=480,
                            cwd=str(src_v2), env=build_env)
                        if build.returncode == 0 and NUCLEI_BIN.exists():
                            os.chmod(NUCLEI_BIN, 0o755)
                            ver = subprocess.run([str(NUCLEI_BIN), "-version"],
                                capture_output=True, text=True, timeout=10)
                            version = (ver.stdout + ver.stderr).strip().split("\n")[0]
                            return {"ok": True, "path": str(NUCLEI_BIN),
                                    "installed": True, "method": "build_source",
                                    "version": version}
            except Exception as e3:
                log.warning(f"[nuclei] build from source failed: {e3}")

        # ── Method 3: apt-get (Kali/Debian/Ubuntu with projectdiscovery repo) ──
        apt = shutil.which("apt-get") or shutil.which("apt")
        if apt:
            try:
                # Try adding projectdiscovery apt repo (Kali has it)
                r3 = subprocess.run(
                    [apt, "install", "-y", "nuclei"],
                    capture_output=True, text=True, timeout=120)
                if r3.returncode == 0:
                    installed = get_binary()
                    if installed:
                        return {"ok": True, "path": installed,
                                "installed": True, "method": "apt"}
            except: pass

        return {
            "ok": False,
            "installed": False,
            "error": "All install methods failed. See manual_install for steps."
        }


# ── Templates ─────────────────────────────────────────────────────────────────

def update_templates(force: bool = False) -> Dict:
    """
    Update Nuclei templates from ProjectDiscovery GitHub.
    Runs daily automatically. 9,000+ templates covering:
    - CVEs (updated within hours of disclosure)
    - Misconfigurations
    - Exposed panels, secrets, APIs
    - OAST / blind detection
    """
    with _update_lock:
        # Check if update needed
        if not force and UPDATE_FILE.exists():
            last = datetime.fromisoformat(UPDATE_FILE.read_text().strip())
            if datetime.now() - last < timedelta(hours=23):
                count = _count_templates()
                return {"ok": True, "cached": True, "templates": count,
                        "last_update": last.isoformat()}

        nuclei = get_binary()
        if not nuclei:
            return {"ok": False, "error": "nuclei not installed"}

        log.info("[nuclei] updating templates...")
        try:
            r = subprocess.run(
                [nuclei, "-update-templates", "-silent"],
                capture_output=True, text=True, timeout=300,
                env=_build_env()
            )
            if r.returncode == 0 or "templates" in r.stdout.lower():
                # Also set our TEMPLATES_DIR if nuclei downloaded elsewhere
                home_templates = Path.home() / "nuclei-templates"
                if home_templates.exists() and not TEMPLATES_DIR.exists():
                    TEMPLATES_DIR.symlink_to(home_templates)

                UPDATE_FILE.write_text(datetime.now().isoformat())
                count = _count_templates()
                log.info(f"[nuclei] {count} templates ready")
                return {"ok": True, "templates": count,
                        "last_update": datetime.now().isoformat()}
            else:
                return {"ok": False, "error": r.stderr[:200]}
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "update timeout"}
        except Exception as e:
            return {"ok": False, "error": str(e)}


# Cache template count — walking 105k templates takes minutes
_tpl_count_cache: dict = {"count": -1, "ts": 0.0}
_TPL_CACHE_TTL = 300   # refresh every 5 minutes


def _count_templates() -> int:
    """Count nuclei templates — cached for 5 minutes to avoid 200+ second delays."""
    import time as _t
    cached = _tpl_count_cache
    if cached["count"] >= 0 and (_t.time() - cached["ts"]) < _TPL_CACHE_TTL:
        return cached["count"]

    # Always count custom templates first (works without binary)
    custom_count = 0
    if CUSTOM_TPL.exists():
        try:
            custom_count = sum(1 for _, _, fs in os.walk(CUSTOM_TPL)
                               for f in fs if f.endswith(".yaml"))
        except Exception:
            pass

    result = [custom_count]  # start with custom templates

    def _count_worker():
        # Try binary first — fastest (nuclei -tl just lists template files)
        try:
            binary = get_binary()
            if binary:
                r = subprocess.run([binary, "-tl"], capture_output=True, text=True, timeout=8)
                lines = [l for l in (r.stdout + r.stderr).splitlines() if l.strip()]
                if len(lines) > 10:
                    result[0] = len(lines) + custom_count
                    return
        except Exception:
            pass
        # Fallback: walk known template directories
        total = custom_count
        for d_str in get_template_dirs():
            d = Path(d_str)
            if str(d) == str(CUSTOM_TPL):
                continue  # already counted
            try:
                if d.exists():
                    cnt = sum(1 for _, _, fs in os.walk(d) for f in fs if f.endswith(".yaml"))
                    if cnt > 0:
                        total += cnt
                        log.debug(f"[nuclei] found {cnt} templates in {d}")
            except (PermissionError, OSError, Exception):
                continue
        if total > 0:
            result[0] = total
            log.info(f"[nuclei] total templates counted: {result[0]}")

    import threading as _thr
    t = _thr.Thread(target=_count_worker, daemon=True)
    t.start()
    t.join(timeout=20)   # Hard 20s cap — no more 215s hangs

    count = result[0]
    _tpl_count_cache["count"] = count
    _tpl_count_cache["ts"]    = _t.time()
    return count


# Pre-warm template count cache in background (avoids 20s delay on first /nuclei/status)
try:
    threading.Thread(target=lambda: (
        __import__("time").sleep(3),
        _count_templates()
    ), daemon=True, name="nuclei-cache-prewarm").start()
except Exception:
    pass


def get_binary() -> Optional[str]:
    """Find nuclei binary — checks all common locations on Kali/Ubuntu/root."""
    # Our installed version
    if NUCLEI_BIN.exists() and os.access(NUCLEI_BIN, os.X_OK):
        return str(NUCLEI_BIN)
    # PATH first — most reliable
    found = shutil.which("nuclei")
    if found: return found
    # Scan ALL home directories for go/bin/nuclei (handles any username)
    candidates = []
    try:
        import pwd as _pwd
        for entry in _pwd.getpwall():
            home = entry.pw_dir
            for subpath in ["go/bin/nuclei", ".local/bin/nuclei"]:
                p = Path(home) / subpath
                candidates.append(p)
    except Exception:
        pass
    # Fixed locations
    candidates += [
        Path("/home/kali/go/bin/nuclei"),
        Path("/root/go/bin/nuclei"),
        Path.home() / "go/bin/nuclei",
        Path("/usr/local/bin/nuclei"),
        Path("/usr/bin/nuclei"),
        Path("/opt/nuclei/nuclei"),
        Path("/opt/go/bin/nuclei"),
        Path("/snap/bin/nuclei"),
        Path("/usr/local/go/bin/nuclei"),
    ]
    for p in candidates:
        try:
            if p.exists() and os.access(str(p), os.X_OK):
                return str(p)
        except (PermissionError, OSError):
            continue
    return None


def _build_env() -> Dict:
    """Build environment for nuclei — include Go bin in PATH and set template path."""
    env = dict(os.environ)
    # Add go bin dirs so nuclei can find itself even if PATH is minimal
    _go_bins = [
        os.path.expanduser("~/go/bin"),
        "/home/kali/go/bin",
        "/root/go/bin",
        "/usr/local/go/bin",
        "/usr/local/bin",
    ]
    # Add any user's go/bin that exists
    try:
        import pwd as _pwd3
        for _entry in _pwd3.getpwall():
            _gob = os.path.join(_entry.pw_dir, "go", "bin")
            if os.path.isdir(_gob) and _gob not in _go_bins:
                _go_bins.append(_gob)
    except Exception:
        pass
    existing_path = env.get("PATH", "")
    extra_paths = [p for p in _go_bins if os.path.isdir(p) and p not in existing_path]
    if extra_paths:
        env["PATH"] = ":".join(extra_paths) + ":" + existing_path
    # Set template path so nuclei can find templates when running as non-root
    if "NUCLEI_TEMPLATES_PATH" not in env:
        for tpl_candidate in [
            os.path.expanduser("~/nuclei-templates"),
            os.path.expanduser("~/.config/nuclei/nuclei-templates"),
            "/home/kali/nuclei-templates",
            "/home/kali/.config/nuclei/nuclei-templates",
        ]:
            if os.path.isdir(tpl_candidate):
                env["NUCLEI_TEMPLATES_PATH"] = tpl_candidate
                break
    extra = ":".join([
        str(NUCLEI_DIR),
        str(Path.home() / "go" / "bin"),
        "/usr/local/go/bin",
    ])
    env["PATH"] = extra + ":" + env.get("PATH", "")
    return env


def get_template_dirs() -> List[str]:
    """Return all template directories in priority order — checks all Kali locations."""
    dirs = []
    candidates = [CUSTOM_TPL, TEMPLATES_DIR]
    # Scan all home dirs (handles any username: kali, root, ubuntu, etc.)
    try:
        import pwd as _pwd2
        for entry in _pwd2.getpwall():
            home = entry.pw_dir
            for subpath in [
                "nuclei-templates",
                ".local/nuclei-templates",
                ".config/nuclei/nuclei-templates",
                ".config/nuclei",           # nuclei v3 stores templates here
                "go/pkg/nuclei-templates",
            ]:
                candidates.append(Path(home) / subpath)
    except Exception:
        pass
    # Fixed fallbacks — nuclei v3 stores templates directly in ~/.config/nuclei
    candidates += [
        # Nuclei v3 primary location (confirmed: contains http/, dns/, cves.json)
        Path("/home/kali/.config/nuclei"),
        Path("/root/.config/nuclei"),
        Path.home() / ".config/nuclei",
        # Legacy / alternate locations
        Path("/home/kali/nuclei-templates"),
        Path("/home/kali/.config/nuclei/nuclei-templates"),
        Path("/root/nuclei-templates"),
        Path("/root/.config/nuclei/nuclei-templates"),
        Path.home() / "nuclei-templates",
        Path.home() / ".config/nuclei/nuclei-templates",
        Path.home() / ".local/share/nuclei-templates",
        Path("/usr/local/share/nuclei-templates"),
        Path("/usr/share/nuclei-templates"),
        Path("/opt/nuclei-templates"),
    ]
    for d in candidates:
        try:
            # PermissionError on /root/* when running as kali user — skip gracefully
            if d.exists() and d.is_dir():
                s = str(d)
                if s not in dirs:
                    dirs.append(s)
        except PermissionError:
            pass  # /root/* not accessible as kali user — skip
        except Exception:
            pass
    return dirs


def get_status() -> Dict:
    """Full status of nuclei engine. Uses cached template count (5min TTL)."""
    binary  = get_binary()
    tpl_cnt = _count_templates()  # cached — fast after first call
    version = ""
    if binary:
        try:
            r = subprocess.run([binary, "-version"], capture_output=True, text=True, timeout=5)
            version = (r.stdout + r.stderr).strip().split("\n")[0]
        except: pass

    last_update = ""
    if UPDATE_FILE.exists():
        last_update = UPDATE_FILE.read_text().strip()

    custom_count = sum(1 for _, _, fs in os.walk(CUSTOM_TPL) for f in fs if f.endswith(".yaml")) \
                   if CUSTOM_TPL.exists() else 0

    # When binary missing, still report custom templates as usable
    effective_templates = tpl_cnt if tpl_cnt > 0 else custom_count
    install_steps = {
        "kali_recommended": "go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest && nuclei -update-templates",
        "download_binary":  "wget https://github.com/projectdiscovery/nuclei/releases/latest/download/nuclei_linux_amd64.zip && unzip nuclei_linux_amd64.zip && mv nuclei /usr/local/bin/",
        "via_api":          "POST /nuclei/install",
    }
    return {
        "installed":        binary is not None,
        "binary":           binary or "",
        "version":          version,
        "templates":        effective_templates,
        "full_templates":   tpl_cnt,
        "custom_templates": custom_count,
        "template_dirs":    get_template_dirs(),
        "last_update":      last_update,
        "auto_update":      True,
        "install_cmd":      "go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
        "install_steps":    install_steps if not binary else {},
        "reason_not_installed": "" if binary else "Go proxy or GitHub releases unavailable in this environment. Install manually on Kali.",
    }


# ── Scan ──────────────────────────────────────────────────────────────────────

SEVERITY_MAP = {"critical": "critical", "high": "high",
                "medium": "medium", "low": "low", "info": "info", "unknown": "info"}

TAG_TO_BUG = {
    frozenset({"rce","remote-code-execution","command-injection"}): "rce",
    frozenset({"sqli","sql-injection","blind-sqli"}):               "sqli",
    frozenset({"xss","cross-site-scripting","reflected-xss"}):      "xss",
    frozenset({"ssrf","server-side-request-forgery"}):              "ssrf",
    frozenset({"lfi","local-file-inclusion","path-traversal"}):     "lfi",
    frozenset({"ssti","template-injection"}):                       "ssti",
    frozenset({"xxe","xml-external-entity"}):                       "xxe",
    frozenset({"cors","cors-misconfiguration"}):                    "cors",
    frozenset({"crlf","header-injection"}):                         "crlf",
    frozenset({"redirect","open-redirect"}):                        "redirect",
    frozenset({"takeover","subdomain-takeover"}):                   "takeover",
    frozenset({"jwt","json-web-token","jwt-attack"}):               "jwt",
    frozenset({"graphql","graphql-injection"}):                     "graphql",
    frozenset({"log4j","log4shell","cve-2021-44228"}):              "log4j",
    frozenset({"spring4shell","cve-2022-22965"}):                   "spring4shell",
    frozenset({"actuator","springboot"}):                           "actuator",
    frozenset({"oauth","oidc"}):                                    "oauth",
    frozenset({"misconfiguration","config","exposed-service"}):     "misconfig",
    frozenset({"exposure","secret","api-key","token"}):             "jsleak",
    frozenset({"cve"}):                                             "cve",
    frozenset({"panel","login","default-login","exposed-panel"}):   "panels",
    frozenset({"nosqli","nosql-injection","mongodb"}):              "nosqli",
    frozenset({"ldap","ldap-injection"}):                           "ldap_injection",
    frozenset({"deserialization","java-deserialization"}):          "deserialization",
    frozenset({"s3","bucket","aws","cloud-storage"}):               "buckets",
    frozenset({"prototype-pollution","client-side"}):               "prototype",
    frozenset({"file-upload","unrestricted-file-upload"}):          "fileupload",
    frozenset({"dependency-confusion","supply-chain"}):             "dep_confusion",
    frozenset({"smuggling","http-smuggling","desync"}):             "smuggling",
    frozenset({"cache-poisoning","cache-deception"}):               "cache_poison",
    frozenset({"clickjacking"}):                                    "clickjacking",
    frozenset({"host-header","host-header-injection"}):             "host_header",
    frozenset({"idor","object-reference","access-control"}):        "idor",
    frozenset({"saml"}):                                            "saml",
    frozenset({"websocket","ws"}):                                  "websocket",
    frozenset({"mfa","2fa"}):                                       "mfa_bypass",
}

def _classify_tags(tags: List[str], template_id: str) -> str:
    """Map nuclei tags to our bug type."""
    tags_set = set(t.lower() for t in tags)
    # CVE template → use 'cve' bug type
    if re.match(r"cve-\d{4}-\d+", template_id.lower()):
        return "cve"
    # Match against our map
    for frozen, bug_type in TAG_TO_BUG.items():
        if tags_set & frozen:
            return bug_type
    return "misconfig"


def _parse_finding(raw: Dict, bug_type: str) -> Dict:
    """Parse a nuclei JSONL result into our finding format."""
    info  = raw.get("info", {})
    cve   = raw.get("template-id", "")
    # Use host as canonical URL — matched-at contains probe paths like /bin/bash
    _host_url    = raw.get("host", raw.get("matched", ""))
    _matched_at  = raw.get("matched-at", _host_url)
    # If matched-at is a probe path (not a real user-facing URL), use host instead
    _PROBE_JUNK  = ["/bin/", "/etc/", "/proc/", "/.git", "/.env", "/actuator",
                    "%%", "%00", "%0a", "%0d", "\\x", "\\u00", "../", "..%2f"]
    _path_part   = _matched_at.split("?")[0] if _matched_at else ""
    if any(p in _path_part.lower() for p in _PROBE_JUNK) and _host_url:
        match = _host_url  # use clean host URL
    else:
        match = _matched_at

    sev   = SEVERITY_MAP.get(info.get("severity", "").lower(), "medium")
    # Nuclei confidence: unconfirmed critical findings need analyst review
    _confirmed    = raw.get("matcher-status", False)
    _nuclei_conf  = (70 if sev == "critical" and not _confirmed else
                     65 if sev == "high"     and not _confirmed else None)

    # Build PoC
    req   = raw.get("request", "")
    resp  = raw.get("response", "")[:200] if raw.get("response") else ""
    poc   = f"# Template: {cve}\n"
    if req: poc += f"# Request:\n{req[:300]}\n"
    poc += f"# Match: {match}"

    # CVSS
    cvss_score = None
    classification = info.get("classification", {})
    if classification:
        cvss_score = classification.get("cvss-score")

    return {
        "bug":          bug_type,
        "severity":     sev,
        "title":        info.get("name", cve),
        "url":          match,
        "matched_at_probe": raw.get("matched-at",""),  # evidence field, not URL
        "value":        raw.get("extracted-results", [""])[0] if raw.get("extracted-results") else "",
        "poc":          poc,
        "impact":       info.get("description", ""),
        "remediation":  info.get("remediation", ""),
        "confidence":   _nuclei_conf if _nuclei_conf else 90,
        "cwe":          str(classification.get("cwe-id", [""])[0]) if classification.get("cwe-id") else "",
        "cvss":         cvss_score,
        "nuclei_template": cve,
        "tags":         info.get("tags", []),
        "reference":    info.get("reference", [])[:3],
        "tool":         "nuclei",
    }


def scan(
    targets: List[str],
    bugs:    List[str] = None,
    tags:    List[str] = None,
    templates: List[str] = None,
    severity: List[str] = None,
    rate_limit: int = 150,
    concurrency: int = 25,
    timeout: int = 15,
    max_time: int = 600,
    include_cves: bool = True,
    emit_fn = None,
    high_signal_only: bool = True,
    tech_stack: List[str] = None,
) -> List[Dict]:
    """
    Run Nuclei scan against a list of targets.

    high_signal_only: if True, score endpoints and send only top 30% to nuclei.
    Falls back to exposure/misconfig/panel templates if no findings from primary run.
    """
    binary = get_binary()
    if not binary:
        log.warning("[nuclei] binary not available — skipping")
        return []

    if not targets:
        return []

    # Ensure templates are available
    tpl_dirs = get_template_dirs()
    if not tpl_dirs:
        log.warning("[nuclei] no templates found, attempting update...")
        update_templates()
        tpl_dirs = get_template_dirs()

    # Build tag set from our bug types
    BUG_TO_TAGS = {
        "sqli":         "sqli,sql-injection,error-based-sqli,blind-sqli",
        "xss":          "xss,reflected-xss,dom-xss,stored-xss",
        "ssrf":         "ssrf,server-side-request-forgery",
        "lfi":          "lfi,local-file-inclusion,path-traversal",
        "ssti":         "ssti,template-injection",
        "xxe":          "xxe,xml-external-entity",
        "cors":         "cors",
        "crlf":         "crlf,header-injection",
        "redirect":     "redirect,open-redirect",
        "takeover":     "takeover,subdomain-takeover",
        "jwt":          "jwt,json-web-token",
        "graphql":      "graphql",
        "log4j":        "log4j,log4shell,jndi",
        "spring4shell": "spring4shell",
        "actuator":     "springboot,actuator",
        "oauth":        "oauth,oidc",
        "misconfig":    "misconfiguration,config,exposed-service",
        "jsleak":       "exposure,secret,api-key,token",
        "cve":          "cve",
        "panels":       "panel,login,default-login",
        "nosqli":       "nosqli,mongodb",
        "deserialization": "deserialization,java-deserialization",
        "buckets":      "s3,bucket,aws,cloud-storage",
        "prototype":    "prototype-pollution",
        "fileupload":   "file-upload",
        "dep_confusion":"dependency-confusion,supply-chain",
        "smuggling":    "http-smuggling,request-smuggling",
        "rce":          "rce,remote-code-execution,command-injection",
        "ldap_injection": "ldap",
        "cache_poison": "cache-poisoning,cache-deception",
        "host_header":  "host-header",
        "idor":         "idor,access-control",
        "saml":         "saml",
        "clickjacking": "clickjacking",
        "websocket":    "websocket",
        "expose":       "exposure,config,backup,sensitive-data,debug,information-disclosure",
        "smartcve":     "cve",
        "waf":          "misconfiguration,waf",
    }

    all_tags = set(tags or [])
    if bugs:
        for bug in bugs:
            tag_str = BUG_TO_TAGS.get(bug, "")
            if tag_str:
                all_tags.update(t.strip() for t in tag_str.split(","))
    if include_cves:
        all_tags.add("cve")

    # ── Bounty-focused default tags when no specific bugs requested ───────────
    # These cover the high-payout bug classes. Only applied when caller didn't
    # specify explicit tags/bugs — prevents overriding targeted scans.
    if not bugs and not tags and not templates:
        _BOUNTY_TAGS = {
            "exposure", "misconfiguration", "default-login", "takeover",
            "ssrf", "lfi", "rce", "auth-bypass", "cloud", "api",
            "graphql", "swagger", "token", "secrets", "backup",
            "panel", "redirect", "idor", "access-control",
        }
        all_tags.update(_BOUNTY_TAGS)
        log.info(f"[nuclei] bounty_mode=true default_tags={sorted(_BOUNTY_TAGS)[:8]}...")

    # ── Endpoint scoring: send top 30% high-signal targets first ─────────────
    # Scores each target on SSRF params (+200), upload (+180), admin (+150),
    # API (+120), auth (+100), parameterized (+60).
    # If high_signal_only, only the top 30% (min 20) go to nuclei.
    def _score_target(url: str) -> int:
        s = 0
        if any(p in url for p in ["url=","uri=","redirect=","dest=","callback=","webhook=","src=","fetch="]): s += 200
        if any(p in url.lower() for p in ["/upload","/import","file=","attachment="]): s += 180
        if any(p in url.lower() for p in ["/admin","/administrator","/manage","/dashboard"]): s += 150
        if any(p in url for p in ["/api/","/v1/","/v2/","/v3/","/graphql","/rest/"]): s += 120
        if any(p in url.lower() for p in ["/login","/auth","/oauth","/saml","/sso","/token"]): s += 100
        if "?" in url: s += 60
        return s

    if high_signal_only and len(targets) >= 100:
        _original_count = len(targets)
        _scored  = sorted(targets, key=_score_target, reverse=True)
        _cutoff  = max(20, int(len(_scored) * 0.30))
        targets  = _scored[:_cutoff]
        log.info(
            f"[nuclei] filtered: {_original_count} → {len(targets)}"
            f" (top 30%, min 20, threshold >=100)"
        )
    else:
        log.info(
            f"[nuclei] filtered: {len(targets)} → {len(targets)}"
            f" (no filter — targets < 100)"
        )

    # ── Tech-aware template selection ─────────────────────────────────────────
    # If tech_stack provided (from httpx -tech-detect), add matching nuclei tags.
    # This maps detected technologies to the templates most likely to find vulns.
    _TECH_TAG_MAP = {
        # CMS / frameworks
        "wordpress":      ["wordpress"],
        "wp":             ["wordpress"],
        "drupal":         ["drupal"],
        "joomla":         ["joomla"],
        "magento":        ["magento"],
        "shopify":        ["shopify"],
        # Languages / runtimes
        "php":            ["php", "php-object-injection"],
        "python":         ["python", "ssti", "flask", "django"],
        "ruby":           ["ruby", "rails"],
        "java":           ["java", "deserialization", "spring", "struts"],
        "asp":            ["asp", "iis"],
        "aspnet":         ["asp", "iis"],
        "asp.net":        ["asp", "iis"],
        "node":           ["node", "nodejs"],
        "nodejs":         ["node", "nodejs"],
        # Web servers / infra
        "nginx":          ["misconfiguration", "nginx"],
        "apache":         ["misconfiguration", "apache"],
        "iis":            ["iis", "misconfiguration"],
        "tomcat":         ["tomcat", "java", "apache"],
        # Databases
        "mysql":          ["mysql", "sqli"],
        "postgresql":     ["postgres", "sqli"],
        "mongodb":        ["nosqli", "mongodb"],
        "redis":          ["redis", "exposure"],
        "elasticsearch":  ["elastic", "exposure"],
        # Cloud / DevOps
        "aws":            ["aws", "cloud-metadata", "s3"],
        "kubernetes":     ["kubernetes", "k8s", "exposure"],
        "docker":         ["docker", "exposure"],
        "jenkins":        ["jenkins", "ci"],
        "jira":           ["jira", "atlassian"],
        "confluence":     ["confluence", "atlassian"],
        # API / Auth
        "graphql":        ["graphql"],
        "swagger":        ["swagger", "exposure"],
        "oauth":          ["oauth", "oidc"],
        "jwt":            ["jwt"],
        # Spring ecosystem
        "spring":         ["spring", "springboot", "actuator"],
        "spring-boot":    ["spring", "springboot", "actuator"],
        "spring boot":    ["spring", "springboot", "actuator"],
    }

    if tech_stack:
        _added_by_tech = set()
        for _tech in tech_stack:
            _tech_lower = _tech.lower().strip()
            for _key, _extra_tags in _TECH_TAG_MAP.items():
                if _key in _tech_lower:
                    _added_by_tech.update(_extra_tags)
        if _added_by_tech:
            _new_tags = _added_by_tech - all_tags
            all_tags.update(_added_by_tech)
            log.info(
                f"[nuclei] tech-aware: detected {tech_stack[:5]}"
                f" → added tags: {sorted(_new_tags)}"
            )

    # Write targets to temp file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False,
                                      prefix="tmr_nuclei_") as tf:
        tf.write("\n".join(targets))
        targets_file = tf.name

    try:
        # Check nuclei version for flag support
        r_help = subprocess.run([binary, "-h"], capture_output=True, text=True, timeout=5)
        help_text = r_help.stdout + r_help.stderr
        json_flag = "-jsonl" if "-jsonl" in help_text else "-json"
        duc_flag  = ["-duc"] if "-duc" in help_text else []

        cmd = [
            binary,
            "-l",          targets_file,
            json_flag,
            "-silent",
            "-timeout",    str(timeout),
            "-retries",    "1",
            "-bulk-size",  str(concurrency),
            "-concurrency", str(concurrency),
            "-rate-limit", str(rate_limit),
            "-no-color",
        ] + duc_flag

        # Tags or templates
        if templates:
            for t in templates: cmd += ["-t", t]
        elif all_tags:
            cmd += ["-tags", ",".join(sorted(all_tags))]
        elif tpl_dirs:
            for d in tpl_dirs: cmd += ["-t", d]

        # Severity filter
        if severity:
            cmd += ["-severity", ",".join(severity)]

        # Custom templates always included
        if CUSTOM_TPL.exists() and str(CUSTOM_TPL) not in (templates or []):
            cmd += ["-t", str(CUSTOM_TPL)]

        log.info(
            f"[nuclei] targets_loaded: {len(targets)}"
            f" | templates_used: {','.join(sorted(all_tags))[:80] or 'all'}"
            f" | cmd: {' '.join(cmd[:6])}..."
        )

        findings = []
        seen = set()
        _stderr_lines = []
        _exit_code = [None]   # mutable for closure

        # ── EXEC log: full command before launch ──────────────────────────────
        _full_cmd = " ".join(cmd)
        log.info(f"[nuclei] EXEC: {_full_cmd}")

        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=_build_env(),
            bufsize=1,
        )

        # Drain stderr in background so it never blocks stdout
        def _drain_stderr():
            for line in proc.stderr:
                line = line.strip()
                if line:
                    _stderr_lines.append(line)
                    log.warning(f"[nuclei:stderr] {line}")   # WARNING so it's always visible
        import threading as _thr
        _se_t = _thr.Thread(target=_drain_stderr, daemon=True)
        _se_t.start()

        deadline = time.time() + max_time
        try:
            for line in proc.stdout:
                if time.time() > deadline:
                    proc.kill()
                    log.warning("[nuclei] scan timeout reached")
                    break
                line = line.strip()
                if not line or not line.startswith("{"):
                    continue
                try:
                    raw  = json.loads(line)
                    info = raw.get("info", {})
                    item_tags  = info.get("tags", [])
                    tpl_id     = raw.get("template-id", "")
                    bug_type   = _classify_tags(item_tags, tpl_id)
                    finding    = _parse_finding(raw, bug_type)
                    dedup_key  = f"{bug_type}:{finding['url']}:{tpl_id}"
                    if dedup_key not in seen:
                        seen.add(dedup_key)
                        findings.append(finding)
                        if emit_fn:
                            try: emit_fn(finding)
                            except: pass
                except json.JSONDecodeError:
                    continue
        finally:
            try:
                _exit_code[0] = proc.wait(timeout=10)
            except Exception:
                proc.kill()
                _exit_code[0] = -1
            _se_t.join(timeout=3)
            log.info(f"[nuclei] exit_code: {_exit_code[0]}")
            if _exit_code[0] not in (0, None) and _exit_code[0] != -1:
                log.warning(
                    f"[nuclei] non-zero exit ({_exit_code[0]}) — stderr:"
                    f" {'; '.join(_stderr_lines[:3]) or '(empty)'}"
                )
            if _stderr_lines:
                log.info(
                    f"[nuclei] stderr ({len(_stderr_lines)} lines):"
                    f" {'; '.join(_stderr_lines[:5])}"
                )

        log.info(f"[nuclei] raw_results: {len(findings)}"
                 f" | targets: {len(targets)}"
                 f" | tags: {','.join(sorted(all_tags))[:60]}")
        log.info(f"[nuclei] results_found: {len(findings)}"
                 f" | exit_code: {_exit_code[0]}"
                 f" | stderr_lines: {len(_stderr_lines)}")

        # ── Fallback mode: if 0 results, run high-payout templates on top 20 ──
        if not findings and targets:
            _primary_count = 0
            log.info(f"[nuclei] primary_results=0")
            log.info(f"[nuclei] fallback_activated=true")

            _BOUNTY_FALLBACK_TAGS = {
                "exposure", "misconfiguration", "panel",
                "default-login", "takeover", "secrets",
                "token", "api-key", "backup", "config", "debug",
            }
            # Limit fallback to top 20 targets by bounty score
            _fb_targets = targets[:20]
            log.info(f"[nuclei] fallback_targets={len(_fb_targets)}")

            if not (_BOUNTY_FALLBACK_TAGS & all_tags):
                with tempfile.NamedTemporaryFile(mode="w", suffix=".txt",
                                                  delete=False, prefix="tmr_fb_") as _fbt:
                    _fbt.write("\n".join(_fb_targets))
                    _fb_targets_file = _fbt.name

                _fb_cmd = [c for c in cmd]
                try:
                    ti = _fb_cmd.index("-tags")
                    _fb_cmd[ti+1] = ",".join(sorted(_BOUNTY_FALLBACK_TAGS))
                    _fb_cmd[ti-1] = _fb_targets_file  # replace targets file
                except ValueError:
                    _fb_cmd += ["-tags", ",".join(sorted(_BOUNTY_FALLBACK_TAGS))]
                # Replace targets file reference
                try:
                    li = _fb_cmd.index("-l")
                    _fb_cmd[li+1] = _fb_targets_file
                except ValueError:
                    pass

                log.info(f"[nuclei:fallback] EXEC: {' '.join(_fb_cmd[:8])}...")

                _fb_proc = subprocess.Popen(
                    _fb_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    text=True, env=_build_env(), bufsize=1
                )
                for _fb_line in _fb_proc.stdout:
                    _fb_line = _fb_line.strip()
                    if not _fb_line or not _fb_line.startswith("{"): continue
                    try:
                        _fb_raw  = json.loads(_fb_line)
                        _fb_info = _fb_raw.get("info", {})
                        _fb_tpl  = _fb_raw.get("template-id", "")
                        _fb_bug  = _classify_tags(_fb_info.get("tags",[]), _fb_tpl)
                        _fb_find = _parse_finding(_fb_raw, _fb_bug)
                        _fb_dk   = f"{_fb_bug}:{_fb_find['url']}:{_fb_tpl}"
                        if _fb_dk not in seen:
                            seen.add(_fb_dk)
                            findings.append(_fb_find)
                            if emit_fn:
                                try: emit_fn(_fb_find)
                                except: pass
                    except json.JSONDecodeError:
                        continue
                try: _fb_proc.wait(timeout=10)
                except: _fb_proc.kill()
                try: os.unlink(_fb_targets_file)
                except: pass

                log.info(f"[nuclei] fallback_results={len(findings)}")

        # ── Zero-result diagnosis ──────────────────────────────────────────────
        if not findings:
            reasons = []
            if not targets:
                reasons.append("no live HTTP targets provided")
            elif not any("?" in t for t in targets) and \
                 not any(p in t for t in targets
                         for p in ["/api/","/v1/","/admin","/graphql","/login"]):
                reasons.append(
                    f"0 parameterized endpoints — all {len(targets)} targets"
                    f" appear to be root URLs; add endpoints from gau/waybackurls"
                )
            if all_tags and not tpl_dirs:
                reasons.append("template directories missing — run /nuclei/install")
            if _stderr_lines:
                # Surface the first meaningful stderr line
                for sl in _stderr_lines[:5]:
                    if any(k in sl.lower() for k in ["error","fatal","warn","no templates","permission"]):
                        reasons.append(f"nuclei stderr: {sl[:120]}")
                        break
            if not reasons:
                reasons.append(
                    f"templates did not match any target technology"
                    f" (tags={','.join(sorted(all_tags))[:60]})"
                )
            log.warning(
                "[nuclei] no findings — reason: " + "; ".join(reasons)
            )
            emit_fn and _emit_zero_result_explanation(emit_fn, reasons, targets, all_tags)

        log.info(f"[nuclei] complete: {len(findings)} findings from {len(targets)} targets")
        return findings

    except Exception as e:
        log.error(f"[nuclei] scan error: {e}")
        return []
    finally:
        try: os.unlink(targets_file)
        except: pass


def _emit_zero_result_explanation(emit_fn, reasons: list, targets: list, tags: set):
    """Emit a structured explanation when nuclei finds nothing."""
    try:
        param_count = sum(1 for t in targets if "?" in t)
        api_count   = sum(1 for t in targets if any(
            p in t for p in ["/api/","/v1/","/v2/","/graphql","/admin","/login"]))
        msg = (
            f"Nuclei: no findings\n"
            f"• Targets scanned: {len(targets)}"
            f" ({param_count} parameterized, {api_count} API/auth endpoints)\n"
            f"• Templates: {','.join(sorted(tags))[:80] or 'all'}\n"
            f"• Reason: {'; '.join(reasons)}"
        )
        # Log the diagnostic — do NOT emit as a finding (prevents junk bounty drafts)
        log.info(f"[nuclei] diagnostic: {msg[:200]}")
    except Exception:
        pass


# ── Plugin / Custom Template System ───────────────────────────────────────────

CUSTOM_TEMPLATE_EXAMPLE = """# TheMasterRecon AI — Custom Template Example
# Place in custom-templates/ directory
# Follows standard Nuclei YAML format

id: tmr-custom-example
info:
  name: Custom Security Check
  author: YourName
  severity: high
  description: Description of what this checks
  tags: custom,tmr

http:
  - method: GET
    path:
      - "{{BaseURL}}/endpoint"
    matchers:
      - type: word
        words:
          - "sensitive_string"
        condition: and
      - type: status
        status:
          - 200
"""

def list_custom_templates() -> List[Dict]:
    """List all custom templates (user plugins)."""
    CUSTOM_TPL.mkdir(parents=True, exist_ok=True)
    templates = []
    for f in sorted(CUSTOM_TPL.rglob("*.yaml")):
        try:
            content = f.read_text(encoding="utf-8")
            # Parse basic info
            id_match   = re.search(r"^id:\s*(.+)$", content, re.M)
            name_match = re.search(r"^\s+name:\s*(.+)$", content, re.M)
            sev_match  = re.search(r"^\s+severity:\s*(.+)$", content, re.M)
            tag_match  = re.search(r"^\s+tags:\s*(.+)$", content, re.M)
            templates.append({
                "id":       id_match.group(1).strip() if id_match else f.stem,
                "name":     name_match.group(1).strip() if name_match else "",
                "severity": sev_match.group(1).strip() if sev_match else "medium",
                "tags":     tag_match.group(1).strip() if tag_match else "",
                "file":     str(f.relative_to(APP_ROOT)),
                "size":     f.stat().st_size,
            })
        except: pass
    return templates


def save_custom_template(template_id: str, content: str) -> Dict:
    """Save a custom template (plugin)."""
    CUSTOM_TPL.mkdir(parents=True, exist_ok=True)
    # Sanitize filename
    safe_id = re.sub(r"[^a-zA-Z0-9_\-]", "_", template_id)
    path = CUSTOM_TPL / f"{safe_id}.yaml"
    try:
        # Validate it's valid YAML
        import yaml
        yaml.safe_load(content)
        path.write_text(content, encoding="utf-8")
        return {"ok": True, "path": str(path), "id": safe_id}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def delete_custom_template(template_id: str) -> Dict:
    """Delete a custom template."""
    safe_id = re.sub(r"[^a-zA-Z0-9_\-]", "_", template_id)
    path = CUSTOM_TPL / f"{safe_id}.yaml"
    if path.exists():
        path.unlink()
        return {"ok": True}
    return {"ok": False, "error": "Template not found"}


def validate_template(content: str) -> Dict:
    """Validate a Nuclei template YAML."""
    try:
        import yaml
        data = yaml.safe_load(content)
        required = ["id", "info"]
        missing = [k for k in required if k not in data]
        if missing:
            return {"valid": False, "error": f"Missing required fields: {missing}"}
        info = data.get("info", {})
        if "name" not in info:
            return {"valid": False, "error": "Missing info.name"}
        if "severity" not in info:
            return {"valid": False, "error": "Missing info.severity"}
        return {"valid": True, "id": data.get("id"), "name": info.get("name")}
    except Exception as e:
        return {"valid": False, "error": str(e)}


# ── Auto-update background thread ─────────────────────────────────────────────

def _auto_update_loop():
    """Background thread that updates templates every 23 hours."""
    while True:
        try:
            time.sleep(300)  # Wait 5 min before first check
            update_templates()
        except Exception as e:
            log.debug(f"[nuclei] auto-update: {e}")
        time.sleep(23 * 3600)  # Then daily


def start_auto_updater():
    """Start background template auto-updater."""
    t = threading.Thread(target=_auto_update_loop, name="nuclei-updater", daemon=True)
    t.start()
    log.info("[nuclei] auto-updater started (daily template updates)")


# Start auto-updater on import
try:
    start_auto_updater()
except Exception:
    pass
