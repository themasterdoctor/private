"""
BugScan ELITE — XBOW-style Evidence Quality Validator
Objective: Proof over probability. Every finding must be replayable, 
           explainable, and defensible before it reaches the analyst.
"""
from typing import Dict, List, Tuple, Optional
import re, urllib.parse, hashlib, time

# ── Evidence requirements per bug type ────────────────────────────────────────
_PROOF_REQUIREMENTS: Dict[str, Dict] = {
    "xss": {
        "min_signals":    2,
        "needs_reflection": True,
        "needs_param":    True,
        "needs_poc":      True,
        "min_confidence": 75,
        "weak_signals": ["status_changed"],
        "strong_signals": ["reflection_detected", "payload_executed", "oob_confirmed"],
        "fp_patterns": [
            r"X-XSS-Protection: 1",  # WAF blocked it
            r"Content-Security-Policy",  # CSP may block
        ],
    },
    "sqli": {
        "min_signals":    2,
        "needs_param":    True,
        "needs_poc":      True,
        "min_confidence": 75,
        "weak_signals": ["error_based_hint", "length_delta"],
        "strong_signals": ["error_confirmed", "blind_boolean", "time_based", "data_exfil", "oob_confirmed"],
        "fp_patterns": [
            r"generic.*error",
            r"maintenance.*mode",
        ],
    },
    "ssrf": {
        "min_signals":    1,  # OOB confirmation alone is enough
        "needs_poc":      True,
        "min_confidence": 70,
        "weak_signals": ["status_changed", "response_delay"],
        "strong_signals": ["oob_confirmed", "metadata_returned", "internal_service_reached"],
    },
    "rce": {
        "min_signals":    2,
        "needs_poc":      True,
        "min_confidence": 80,
        "weak_signals": ["error_pattern"],
        "strong_signals": ["command_output", "oob_confirmed", "file_written", "process_executed"],
    },
    "lfi": {
        "min_signals":    1,
        "needs_poc":      True,
        "min_confidence": 75,
        "weak_signals": ["path_in_response"],
        "strong_signals": ["file_content_returned", "etc_passwd", "log_included"],
    },
    "ssti": {
        "min_signals":    2,
        "needs_poc":      True,
        "min_confidence": 75,
        "weak_signals": ["reflection_detected"],
        "strong_signals": ["expression_evaluated", "code_executed", "math_result"],
    },
    "cors": {
        "min_signals":    2,
        "needs_poc":      True,
        "min_confidence": 70,
        "weak_signals": ["header_present"],
        "strong_signals": ["credentialed_request_allowed", "origin_reflected", "auth_data_accessible"],
        "fp_patterns": [r"Access-Control-Allow-Origin: \*"],  # public API — may be intentional
    },
    "idor": {
        "min_signals":    2,
        "needs_poc":      True,
        "min_confidence": 80,
        "weak_signals": ["different_response"],
        "strong_signals": ["other_user_data_returned", "id_increment_works", "uuid_accessible"],
    },
    "xxe": {
        "min_signals":    1,
        "needs_poc":      True,
        "min_confidence": 75,
        "weak_signals": ["xml_parsed"],
        "strong_signals": ["file_returned", "oob_confirmed", "ssrf_via_xxe"],
    },
    "cache_poison": {
        "min_signals":    3,  # XBOW: reflection alone = low. Need cacheable + keyed + poisoned
        "needs_poc":      True,
        "min_confidence": 80,
        "weak_signals": ["header_reflected"],
        "strong_signals": ["cached_response_poisoned", "second_request_poisoned", "key_gap_confirmed"],
    },
    "jwt": {
        "min_signals":    2,
        "needs_poc":      True,
        "min_confidence": 80,
        "weak_signals": ["alg_detected"],
        "strong_signals": ["token_accepted_tampered", "none_alg_accepted", "key_confusion"],
    },
    "redirect": {
        "min_signals":    2,
        "needs_poc":      True,
        "min_confidence": 70,
        "weak_signals": ["redirect_parameter_found"],
        "strong_signals": ["off_domain_redirect", "external_destination", "protocol_downgrade"],
    },
    "default": {
        "min_signals":    1,
        "needs_poc":      False,
        "min_confidence": 60,
        "weak_signals": [],
        "strong_signals": [],
    }
}

# ── Severity floors by evidence completeness ──────────────────────────────────
_EVIDENCE_FLOOR = {
    # (has_strong_signal, has_poc, has_param, min_confidence_met) -> max_severity
    (True,  True,  True,  True):  "critical",
    (True,  True,  False, True):  "high",
    (True,  True,  True,  False): "high",
    (False, True,  True,  True):  "high",
    (True,  False, True,  True):  "medium",
    (False, True,  False, True):  "medium",
    (False, False, True,  True):  "low",
    (False, False, False, True):  "info",
}


def validate_evidence(finding: Dict) -> Dict:
    """
    XBOW-style evidence quality check.
    
    Returns:
        {
            "grade":           "A" | "B" | "C" | "D" | "F",
            "verdict":         "confirmed" | "needs_review" | "likely_fp" | "insufficient_evidence",
            "confidence":      int,  # possibly adjusted down
            "severity":        str,  # possibly adjusted down
            "evidence_score":  int,  # 0-100
            "missing":         List[str],   # what's missing for a strong report
            "signals":         List[str],   # detected signals
            "strong_signals":  List[str],
            "weak_signals":    List[str],
            "fp_risk":         str,   # "" or explanation
            "report_ready":    bool,
            "analyst_note":    str,
        }
    """
    bug      = finding.get("bug", finding.get("bug_type", "")).lower()
    severity = finding.get("severity", "info").lower()
    conf     = int(finding.get("confidence", 50))
    url      = finding.get("url", "")
    poc      = str(finding.get("poc", ""))
    param    = finding.get("param", "")
    preview  = str(finding.get("preview", ""))
    details  = finding.get("details", {})
    
    req = _PROOF_REQUIREMENTS.get(bug, _PROOF_REQUIREMENTS["default"])
    
    # ── Detect signals present ────────────────────────────────────────────────
    signals_present = []
    
    # OOB confirmed = strongest signal
    if finding.get("oob_confirmed") or finding.get("eil_confirmed"):
        signals_present.append("oob_confirmed")
    
    # Has working curl/http PoC
    if poc and ("curl" in poc or "http" in poc.lower()) and len(poc) > 30:
        signals_present.append("has_curl_poc")
    
    # Reflection detected
    if (finding.get("reflected") or "reflected" in preview.lower() or
            finding.get("reflection_detected") or details.get("reflection_detected")):
        signals_present.append("reflection_detected")
    
    # Response diff (status or length changed)
    if finding.get("status_changed") or details.get("status_changed"):
        signals_present.append("status_changed")
    if finding.get("length_delta", 0) > 50 or details.get("length_delta", 0) > 50:
        signals_present.append("length_delta")
    
    # Error-based signals
    desc = str(finding.get("description", "")).lower()
    if any(k in desc for k in ["syntax error", "sql error", "mysql", "ora-", "pg::", "sqlite"]):
        signals_present.append("error_confirmed")
    if any(k in desc for k in ["time-based", "sleep(", "pg_sleep", "waitfor"]):
        signals_present.append("time_based")
    if any(k in desc for k in ["blind boolean", "true condition", "false condition"]):
        signals_present.append("blind_boolean")
    
    # Template expression evaluation
    if any(k in desc for k in ["7*7", "49", "expression evaluated", "math result"]):
        signals_present.append("expression_evaluated")
    
    # File content returned
    if any(k in desc + preview for k in ["root:x:", "/etc/passwd", "[extensions]", "<?php"]):
        signals_present.append("file_content_returned")
    
    # Off-domain redirect
    if any(k in desc for k in ["redirect to", "external redirect", "off-domain"]):
        signals_present.append("off_domain_redirect")
    
    # CORS credentialed
    if "credentialed" in desc or "access-control-allow-credentials: true" in desc.lower():
        signals_present.append("credentialed_request_allowed")
    
    # Other user data (IDOR)
    if any(k in desc for k in ["other user", "different user", "unauthorized access", "account data"]):
        signals_present.append("other_user_data_returned")
    
    # JWT tamper
    if any(k in desc for k in ["accepted", "tampered", "alg:none", "algorithm confusion"]):
        signals_present.append("token_accepted_tampered")
    
    # Cache poisoning specific
    if details.get("cacheable"):
        signals_present.append("cacheable_response")
    if "second request" in desc or "poisoned cache" in desc:
        signals_present.append("cached_response_poisoned")
    
    # High confidence from scanner (treat as signal)
    if conf >= 90:
        signals_present.append("high_confidence_scanner")
    
    # ── Categorize signals ────────────────────────────────────────────────────
    strong = req.get("strong_signals", [])
    weak   = req.get("weak_signals", [])
    
    strong_present = [s for s in signals_present if s in strong or s == "oob_confirmed"]
    weak_present   = [s for s in signals_present if s in weak]
    
    total_unique   = len(set(signals_present))
    min_needed     = req.get("min_signals", 1)
    
    # ── Check FP risk patterns ────────────────────────────────────────────────
    fp_risk = ""
    for pattern in req.get("fp_patterns", []):
        if re.search(pattern, poc + preview, re.I):
            fp_risk = f"FP pattern detected: {pattern}"
            break
    
    # Extra FP checks
    if bug == "xss" and "alert" not in poc and "onerror" not in poc and "onload" not in poc:
        fp_risk = fp_risk or "XSS PoC missing execution proof (no alert/event)"
    
    if bug == "ssrf" and not any(k in poc + desc for k in 
            ["169.254", "localhost", "127.0.0.1", "oob", "internal", "metadata"]):
        fp_risk = fp_risk or "SSRF PoC missing internal target evidence"
    
    if bug == "sqli" and not any(k in poc + desc for k in 
            ["sleep", "union", "error", "mysql_error", "syntax", "boolean"]):
        fp_risk = fp_risk or "SQLi PoC missing injection technique evidence"
    
    # ── Compute evidence score ────────────────────────────────────────────────
    ev_score = 0
    ev_score += min(40, total_unique * 10)           # up to 40 for signals
    ev_score += 20 if strong_present else 0          # 20 for strong signal
    ev_score += 15 if poc and len(poc) > 30 else 0  # 15 for working PoC
    ev_score += 10 if param else 0                   # 10 for identified param
    ev_score += 10 if conf >= req["min_confidence"] else 0  # 10 for confidence
    ev_score += 5  if not fp_risk else -15           # +5 clean, -15 FP risk
    ev_score = max(0, min(100, ev_score))
    
    # ── OOB / EIL confirmed = IMMEDIATE grade A (deterministic proof) ──────────
    # An OOB callback is mathematical proof — no other signals needed.
    # This is the XBOW principle: proof over probability.
    _oob = (
        finding.get("oob_confirmed") or
        finding.get("eil_confirmed") or
        "oob_confirmed" in signals_present or
        "oob_http" in signals_present or
        "oob_dns" in signals_present
    )
    if _oob:
        return {
            "grade":          "A",
            "verdict":        "confirmed",
            "confidence":     max(conf, 92),
            "severity":       severity,
            "evidence_score": 95,
            "signals":        signals_present + ["oob_confirmed"],
            "strong_signals": ["oob_confirmed"],
            "weak_signals":   [],
            "missing":        [],
            "fp_risk":        "",
            "report_ready":   True,
            "analyst_note":   "✅ OOB/EIL callback confirmed — deterministic proof. Report-ready.",
        }

    # ── Verdict ───────────────────────────────────────────────────────────────
    missing = []
    
    if not poc or len(poc) < 10:
        missing.append("working PoC (curl command or reproduction steps)")
    if req.get("needs_param") and not param:
        missing.append("specific vulnerable parameter identified")
    if total_unique < min_needed:
        missing.append(f"more independent signals ({total_unique}/{min_needed} present)")
    if not strong_present:
        missing.append(f"at least one strong signal: {strong}")
    if conf < req["min_confidence"]:
        missing.append(f"confidence ≥ {req['min_confidence']}% (current: {conf}%)")
    
    if fp_risk:
        verdict = "likely_fp"
        grade   = "D"
    elif not missing and strong_present:
        verdict = "confirmed"
        grade   = "A" if ev_score >= 85 else "B"
    elif not missing:
        verdict = "confirmed"
        grade   = "B" if ev_score >= 65 else "C"
    elif len(missing) <= 1 and (strong_present or total_unique >= min_needed):
        verdict = "needs_review"
        grade   = "C"
    elif ev_score < 20:
        verdict = "insufficient_evidence"
        grade   = "F"
    else:
        verdict = "needs_review"
        grade   = "D"
    
    # ── Severity adjustment based on evidence ─────────────────────────────────
    key = (
        bool(strong_present),
        bool(poc and len(poc) > 10),
        bool(param),
        conf >= req["min_confidence"],
    )
    max_sev = _EVIDENCE_FLOOR.get(key, "low")
    SEV_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
    if SEV_ORDER.get(severity, 0) > SEV_ORDER.get(max_sev, 0):
        severity = max_sev  # cap to evidence-supported level
    
    # ── Report readiness ──────────────────────────────────────────────────────
    report_ready = (
        verdict in ("confirmed",) and
        grade in ("A", "B") and
        not fp_risk and
        poc and
        len(missing) == 0
    )
    
    # ── Analyst note ──────────────────────────────────────────────────────────
    if verdict == "confirmed" and grade == "A":
        note = "✅ Evidence complete. Report-ready."
    elif verdict == "confirmed" and grade == "B":
        note = f"✅ Confirmed with minor gaps: {'; '.join(missing) or 'none'}"
    elif verdict == "needs_review":
        note = f"⚠️ Needs manual review: {'; '.join(missing)}"
    elif verdict == "likely_fp":
        note = f"❌ Likely false positive: {fp_risk}"
    else:
        note = f"❌ Insufficient evidence: {'; '.join(missing)}"
    
    return {
        "grade":           grade,
        "verdict":         verdict,
        "confidence":      conf,
        "severity":        severity,
        "evidence_score":  ev_score,
        "signals":         signals_present,
        "strong_signals":  strong_present,
        "weak_signals":    weak_present,
        "missing":         missing,
        "fp_risk":         fp_risk,
        "report_ready":    report_ready,
        "analyst_note":    note,
    }


def batch_validate_evidence(findings: List[Dict]) -> Dict:
    """Grade all findings, return summary + per-finding grades."""
    graded = []
    stats  = {"A": 0, "B": 0, "C": 0, "D": 0, "F": 0, "report_ready": 0}
    
    for f in findings:
        result = validate_evidence(f)
        graded.append({**f, "_xbow": result})
        stats[result["grade"]] += 1
        if result["report_ready"]:
            stats["report_ready"] += 1
    
    # Sort: report-ready first, then by grade, then by evidence_score
    grade_order = {"A": 0, "B": 1, "C": 2, "D": 3, "F": 4}
    graded.sort(key=lambda x: (
        0 if x["_xbow"]["report_ready"] else 1,
        grade_order.get(x["_xbow"]["grade"], 5),
        -x["_xbow"]["evidence_score"],
    ))
    
    return {
        "findings":     graded,
        "stats":        stats,
        "signal_rate":  round(stats["A"] / max(len(findings), 1) * 100, 1),
        "report_ready": stats["report_ready"],
        "total":        len(findings),
    }
