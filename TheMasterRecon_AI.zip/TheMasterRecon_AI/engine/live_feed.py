"""
TheMasterRecon AI — Real-Time Scan Feed Engine
Emits structured [TESTING] / [RESULT] / [FINDING] events to the SSE queue.
"""
import time, threading
from typing import Optional

_feed_lock = threading.Lock()

# ── Event types ───────────────────────────────────────────────────────────────
def _evt(kind: str, **kw) -> dict:
    return {"type": "feed", "kind": kind, "ts": time.time(), **kw}

def testing(q, method: str, url: str, payload: str = "", param: str = "", bug: str = ""):
    """Emit a [TESTING] event before each HTTP probe."""
    if not q: return
    q.put(_evt("testing",
        method=method.upper(),
        url=url[:200],
        payload=payload[:120] if payload else "",
        param=param,
        bug=bug,
        label=f"[TESTING] {method.upper()} {url[:80]}" +
              (f" | {param}={payload[:40]}" if payload else ""),
    ))

def result(q, url: str, status: int, finding: bool, detail: str = "", bug: str = ""):
    """Emit a [RESULT] event after each HTTP probe."""
    if not q: return
    q.put(_evt("result",
        url=url[:200],
        status=status,
        finding=finding,
        detail=detail[:120],
        bug=bug,
        label=f"[{'FOUND' if finding else 'CLEAN'}] {status} {url[:80]}" +
              (f" — {detail[:60]}" if detail else ""),
    ))

def info(q, msg: str, bug: str = ""):
    """Emit an informational status line."""
    if not q: return
    q.put(_evt("info", msg=msg[:200], bug=bug, label=f"[INFO] {msg[:160]}"))

def phase(q, name: str, detail: str = ""):
    """Mark entry into a scan phase."""
    if not q: return
    q.put(_evt("phase", name=name, detail=detail[:100],
               label=f"[PHASE] {name}" + (f" — {detail}" if detail else "")))

# ── Per-domain rate limiter ───────────────────────────────────────────────────
class RateLimiter:
    """Token-bucket rate limiter — requests per second per domain."""
    def __init__(self, rps: float = 15.0):
        self._rps    = rps
        self._tokens : float = rps
        self._last   : float = time.monotonic()
        self._lock   = threading.Lock()

    def wait(self):
        """Block until a request token is available."""
        with self._lock:
            now = time.monotonic()
            self._tokens = min(self._rps, self._tokens + (now - self._last) * self._rps)
            self._last = now
            if self._tokens >= 1:
                self._tokens -= 1
                return
        # Need to wait
        time.sleep(1.0 / self._rps)
        with self._lock:
            self._tokens = max(0, self._tokens - 1)

_limiters: dict[str, RateLimiter] = {}
_lim_lock = threading.Lock()

def get_limiter(domain: str, rps: float = 15.0) -> RateLimiter:
    with _lim_lock:
        if domain not in _limiters:
            _limiters[domain] = RateLimiter(rps)
        return _limiters[domain]

def clear_limiter(domain: str):
    with _lim_lock:
        _limiters.pop(domain, None)
