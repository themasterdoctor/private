"""
engine/safe_proc.py — Global safe execution wrappers.

safe_run_process()   — subprocess with hard kill-tree timeout
safe_thread_pool()   — ThreadPoolExecutor with cancel-on-timeout

These replace raw subprocess.Popen + as_completed patterns throughout the codebase.
Every blocking operation gets a hard deadline. No infinite waits.
"""

import logging
import os
import signal
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed, Future
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger("elite.safe_proc")


# ── safe_run_process ──────────────────────────────────────────────────────────

def safe_run_process(
    cmd: List[str],
    timeout: int        = 60,
    cwd: str            = None,
    env: dict           = None,
    input_text: str     = None,
    max_stdout_lines:int= 5000,
    max_stderr_lines:int= 1000,
    kill_tree: bool     = True,
    log_tag: str        = "",
) -> Dict:
    """
    Run a subprocess with hard timeout, kill-tree on expiry, and capped output.

    Returns:
    {
        "cmd": str,
        "exit_code": int,
        "stdout_lines": list[str],
        "stderr_lines": list[str],
        "duration_ms": int,
        "timed_out": bool,
        "killed": bool,
        "error": str | None,
    }

    Guarantees:
    - stdout/stderr read loops cannot block forever (thread + timeout)
    - process tree killed on timeout (SIGKILL to process group)
    - no .wait() without a deadline
    """
    tag = f"[safe_proc{' '+log_tag if log_tag else ''}]"
    cmd_str = " ".join(str(x) for x in cmd[:8])
    t0 = time.monotonic()

    result = {
        "cmd":          cmd_str,
        "exit_code":    -1,
        "stdout_lines": [],
        "stderr_lines": [],
        "duration_ms":  0,
        "timed_out":    False,
        "killed":       False,
        "error":        None,
    }

    def _kill(proc):
        """Kill process and its entire process group."""
        try:
            if kill_tree:
                pgid = os.getpgid(proc.pid)
                os.killpg(pgid, signal.SIGKILL)
            else:
                proc.kill()
        except Exception:
            try: proc.kill()
            except Exception: pass

    try:
        inp = input_text.encode() if input_text else None
        log.debug(f"{tag} start cmd={cmd_str} timeout={timeout}s")

        proc = subprocess.Popen(
            cmd,
            stdout     = subprocess.PIPE,
            stderr     = subprocess.PIPE,
            stdin      = subprocess.PIPE if inp else subprocess.DEVNULL,
            cwd        = cwd,
            env        = env,
            start_new_session = kill_tree,  # puts process in own group for killpg
        )

        if inp:
            try:
                proc.stdin.write(inp)
                proc.stdin.close()
            except Exception:
                pass

        stdout_lines: List[str] = []
        stderr_lines: List[str] = []
        timed_out = False

        def _read_stdout():
            try:
                for line in proc.stdout:
                    if len(stdout_lines) >= max_stdout_lines:
                        break
                    l = line.decode(errors="replace").rstrip()
                    if l:
                        stdout_lines.append(l)
            except Exception:
                pass

        def _read_stderr():
            try:
                for line in proc.stderr:
                    if len(stderr_lines) >= max_stderr_lines:
                        break
                    l = line.decode(errors="replace").rstrip()
                    if l:
                        stderr_lines.append(l)
            except Exception:
                pass

        t_out = threading.Thread(target=_read_stdout, daemon=True)
        t_err = threading.Thread(target=_read_stderr, daemon=True)
        t_out.start()
        t_err.start()

        # Wait for process to finish — hard deadline
        try:
            proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            log.warning(f"{tag} timeout after {timeout}s cmd={cmd_str} — killing")
            _kill(proc)
            result["timed_out"] = True
            result["killed"]    = True
        except Exception as e:
            result["error"] = str(e)

        # Join reader threads with short grace period
        t_out.join(timeout=2)
        t_err.join(timeout=2)

        try:
            exit_code = proc.poll()
        except Exception:
            exit_code = -1

        result["exit_code"]    = exit_code if exit_code is not None else -1
        result["stdout_lines"] = stdout_lines
        result["stderr_lines"] = stderr_lines

    except FileNotFoundError:
        result["error"] = f"binary not found: {cmd[0] if cmd else '?'}"
        log.debug(f"{tag} not found: {cmd[0] if cmd else '?'}")
    except Exception as e:
        result["error"] = str(e)
        log.debug(f"{tag} error: {e}")

    result["duration_ms"] = round((time.monotonic() - t0) * 1000)
    log.debug(
        f"{tag} done exit={result['exit_code']}"
        f" stdout={len(result['stdout_lines'])}lines"
        f" timeout={result['timed_out']}"
        f" {result['duration_ms']}ms"
    )
    return result


# ── safe_thread_pool ──────────────────────────────────────────────────────────

def safe_thread_pool(
    tasks: List[Tuple[Callable, tuple]],
    max_workers: int   = 10,
    timeout: float     = 60.0,
    stage_name: str    = "unknown",
    result_handler: Optional[Callable] = None,
) -> Dict:
    """
    Execute tasks in a thread pool with hard timeout and clean cancellation.

    tasks: list of (callable, args_tuple)
    result_handler: optional fn(result) called for each completed future

    Returns:
    {
        "completed": int,
        "cancelled": int,
        "errors":    int,
        "timed_out": bool,
        "results":   list,
        "duration_ms": int,
    }

    Guarantees:
    - as_completed() with timeout — never waits forever
    - all pending futures cancelled on timeout
    - executor.shutdown(wait=False) — never blocks
    """
    t0       = time.monotonic()
    results  = []
    completed = cancelled = errors = 0
    timed_out = False

    if not tasks:
        return {
            "completed": 0, "cancelled": 0, "errors": 0,
            "timed_out": False, "results": [], "duration_ms": 0,
        }

    exe  = ThreadPoolExecutor(max_workers=max_workers,
                               thread_name_prefix=f"stp-{stage_name}")
    futs: Dict[Future, Any] = {}
    for fn, args in tasks:
        futs[exe.submit(fn, *args)] = args

    try:
        for fut in as_completed(futs, timeout=timeout):
            try:
                r = fut.result(timeout=1)
                completed += 1
                results.append(r)
                if result_handler:
                    try: result_handler(r)
                    except Exception: pass
            except Exception:
                errors += 1
    except Exception:
        # TimeoutError or other — cancel everything
        timed_out = True
        for f in futs:
            if not f.done():
                f.cancel()
                cancelled += 1

    finally:
        # NEVER shutdown(wait=True) — that blocks until all futures finish
        exe.shutdown(wait=False)

    dur = round((time.monotonic() - t0) * 1000)
    log.info(
        f"[futures] stage={stage_name}"
        f" completed={completed}"
        f" cancelled={cancelled}"
        f" errors={errors}"
        f" timed_out={timed_out}"
        f" {dur}ms"
    )
    return {
        "completed":   completed,
        "cancelled":   cancelled,
        "errors":      errors,
        "timed_out":   timed_out,
        "results":     results,
        "duration_ms": dur,
    }


# ── finalize_stage ────────────────────────────────────────────────────────────

# Valid terminal states — a stage reaching one of these is done forever
TERMINAL_STATES = frozenset({"done", "skip", "error", "timeout", "skipped"})


def finalize_stage(domain: str, stage: str, state: str,
                   meta: str = "", db=None) -> None:
    """
    Set a stage to its final state.
    Validates that state is terminal — refuses to set `run` via this helper.
    Logs the transition.
    """
    if state not in TERMINAL_STATES:
        log.error(f"[finalize_stage] BUG: tried to set {domain}/{stage} → {state!r}"
                  f" — must be one of {TERMINAL_STATES}. Forcing 'error'.")
        state = "error"
        meta  = meta or f"invalid_state:{state}"

    if db is not None:
        try:
            db.set_step(domain, stage, state, meta)
        except Exception as e:
            log.warning(f"[finalize_stage] db.set_step failed: {e}")

    log.info(f"[stage] {stage} → {state} domain={domain}"
             f"{' meta='+meta[:60] if meta else ''}")
