"""
BugScan APEX — Self-Learning Intelligence Engine
Tracks payload success rates, target patterns, WAF behaviors.
Reinforces successful strategies. Improves every scan.
"""
import json, time, logging, threading, os, re
from typing import Dict, List, Optional, Tuple
from pathlib import Path
from collections import defaultdict

log = logging.getLogger("apex.learn")

# ── Storage path ──────────────────────────────────────────────────────────────
_LEARN_DIR = Path(os.path.dirname(__file__)).parent / "data" / "apex_brain"
_LEARN_DIR.mkdir(parents=True, exist_ok=True)

_lock = threading.Lock()

# ── In-memory knowledge base ──────────────────────────────────────────────────
_KB = {
    "payload_scores":   {},   # payload → {hits, tries, contexts:[]}
    "target_patterns":  {},   # tech_stack → {vuln_type: success_rate}
    "waf_bypasses":     {},   # waf_vendor → [bypass_patterns]
    "param_intel":      {},   # param_name → {vuln_type: hits}
    "chain_success":    {},   # chain_id → {hits, contexts:[]}
    "dead_patterns":    [],   # patterns that never work
    "sessions": 0,
}

def _load():
    global _KB
    p = _LEARN_DIR / "knowledge_base.json"
    if p.exists():
        try:
            with open(p) as f:
                _KB.update(json.load(f))
            log.info(f"[apex.learn] loaded {_KB['sessions']} sessions of learning")
        except: pass

def _save():
    try:
        with open(_LEARN_DIR / "knowledge_base.json", "w") as f:
            json.dump(_KB, f, indent=2)
    except Exception as e:
        log.debug(f"[apex.learn] save error: {e}")

# Load on import
_load()

# ── Core learning API ─────────────────────────────────────────────────────────

def record_payload_hit(payload: str, bug_type: str, tech_stack: List[str],
                       param: str = "", waf: str = ""):
    """Record a successful payload — increase its score."""
    with _lock:
        key = f"{bug_type}::{payload[:80]}"
        if key not in _KB["payload_scores"]:
            _KB["payload_scores"][key] = {"hits": 0, "tries": 0, "contexts": []}
        _KB["payload_scores"][key]["hits"] += 1
        ctx = {"tech": tech_stack, "param": param, "waf": waf, "ts": int(time.time())}
        _KB["payload_scores"][key]["contexts"] = \
            _KB["payload_scores"][key]["contexts"][-9:] + [ctx]

def record_payload_try(payload: str, bug_type: str):
    """Record a payload attempt (whether or not it succeeded)."""
    with _lock:
        key = f"{bug_type}::{payload[:80]}"
        if key not in _KB["payload_scores"]:
            _KB["payload_scores"][key] = {"hits": 0, "tries": 0, "contexts": []}
        _KB["payload_scores"][key]["tries"] += 1

def record_target_vuln(tech_stack: List[str], bug_type: str, found: bool):
    """Record whether a vuln type was found on a given tech stack."""
    with _lock:
        for tech in tech_stack:
            t = tech.lower()
            if t not in _KB["target_patterns"]:
                _KB["target_patterns"][t] = {}
            if bug_type not in _KB["target_patterns"][t]:
                _KB["target_patterns"][t][bug_type] = {"hits": 0, "tries": 0}
            _KB["target_patterns"][t][bug_type]["tries"] += 1
            if found:
                _KB["target_patterns"][t][bug_type]["hits"] += 1

def record_param_intel(param: str, bug_type: str, hit: bool):
    """Track which params are vulnerable to which attacks."""
    with _lock:
        p = param.lower()
        if p not in _KB["param_intel"]:
            _KB["param_intel"][p] = {}
        if bug_type not in _KB["param_intel"][p]:
            _KB["param_intel"][p][bug_type] = {"hits": 0, "tries": 0}
        _KB["param_intel"][p][bug_type]["tries"] += 1
        if hit:
            _KB["param_intel"][p][bug_type]["hits"] += 1

def record_chain_success(chain_id: str, domain: str, impact: str):
    """Record a successful attack chain."""
    with _lock:
        if chain_id not in _KB["chain_success"]:
            _KB["chain_success"][chain_id] = {"hits": 0, "contexts": []}
        _KB["chain_success"][chain_id]["hits"] += 1
        _KB["chain_success"][chain_id]["contexts"].append(
            {"domain": domain, "impact": impact, "ts": int(time.time())}
        )

def record_waf_bypass(waf_vendor: str, bypass_pattern: str):
    """Record a WAF bypass that worked."""
    with _lock:
        if waf_vendor not in _KB["waf_bypasses"]:
            _KB["waf_bypasses"][waf_vendor] = []
        if bypass_pattern not in _KB["waf_bypasses"][waf_vendor]:
            _KB["waf_bypasses"][waf_vendor].append(bypass_pattern)

def end_session():
    """Called at end of each scan — persist learning."""
    with _lock:
        _KB["sessions"] += 1
        _save()
    log.info(f"[apex.learn] session #{_KB['sessions']} persisted")

# ── Intelligence queries ──────────────────────────────────────────────────────

def get_best_payloads(bug_type: str, limit: int = 20) -> List[str]:
    """Return payloads ranked by success rate for this bug type."""
    prefix = f"{bug_type}::"
    scored = []
    for key, data in _KB["payload_scores"].items():
        if not key.startswith(prefix): continue
        tries = data["tries"] or 1
        rate  = data["hits"] / tries
        # Boost payloads with more tries (more confident)
        confidence = min(1.0, data["tries"] / 10)
        score = rate * (0.5 + 0.5 * confidence)
        payload = key[len(prefix):]
        scored.append((score, payload))
    scored.sort(reverse=True)
    return [p for _, p in scored[:limit]]

def get_priority_bugs_for_tech(tech_stack: List[str]) -> List[Tuple[str, float]]:
    """Return bug types ranked by success probability for this tech stack."""
    bug_scores = defaultdict(list)
    for tech in tech_stack:
        t = tech.lower()
        if t in _KB["target_patterns"]:
            for bug, data in _KB["target_patterns"][t].items():
                tries = data["tries"] or 1
                rate  = data["hits"] / tries
                bug_scores[bug].append(rate)
    # Average rates across tech stack
    result = []
    for bug, rates in bug_scores.items():
        avg = sum(rates) / len(rates)
        result.append((bug, avg))
    result.sort(key=lambda x: -x[1])
    return result

def get_best_params_for_bug(bug_type: str) -> List[str]:
    """Return params most likely to be vulnerable to this bug type."""
    scored = []
    for param, bugs in _KB["param_intel"].items():
        if bug_type in bugs:
            data  = bugs[bug_type]
            tries = data["tries"] or 1
            rate  = data["hits"] / tries
            scored.append((rate, param))
    scored.sort(reverse=True)
    return [p for _, p in scored[:15]]

def get_waf_bypasses(waf_vendor: str) -> List[str]:
    """Return known working bypass patterns for this WAF."""
    return list(_KB["waf_bypasses"].get(waf_vendor, []))

def get_stats() -> Dict:
    """Return learning stats for dashboard display."""
    total_payloads = len(_KB["payload_scores"])
    successful     = sum(1 for d in _KB["payload_scores"].values() if d["hits"] > 0)
    return {
        "sessions":       _KB["sessions"],
        "payloads_known": total_payloads,
        "payloads_hit":   successful,
        "tech_patterns":  len(_KB["target_patterns"]),
        "param_patterns": len(_KB["param_intel"]),
        "waf_bypasses":   sum(len(v) for v in _KB["waf_bypasses"].values()),
        "chains_hit":     sum(d["hits"] for d in _KB["chain_success"].values()),
    }
