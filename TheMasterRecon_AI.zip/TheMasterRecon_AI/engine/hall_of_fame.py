"""
BugScan ELITE — Hall of Fame / CVE Disclosure Engine

Tracks responsible disclosures, CVE assignments, and bounty awards.
Public-facing hall of fame for CVEs discovered via BugScan ELITE.

Inspired by BugBunny.ai's Hall of Fame page showing CVE-2026-27471 and CVE-2026-22807.
"""

import json, logging, os, secrets, sqlite3, time, threading
from typing import Dict, List, Optional

log = logging.getLogger("elite.hof")

_DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "..", "data", "hall_of_fame.db")
_conn: Optional[sqlite3.Connection] = None
_lock = threading.Lock()


def _db() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        os.makedirs(os.path.dirname(_DB_PATH), exist_ok=True)
        _conn = sqlite3.connect(_DB_PATH, timeout=10, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA journal_mode=WAL")
        _conn.execute("""CREATE TABLE IF NOT EXISTS disclosures (
            id            TEXT PRIMARY KEY,
            cve_id        TEXT DEFAULT '',
            title         TEXT NOT NULL,
            description   TEXT DEFAULT '',
            target        TEXT DEFAULT '',
            target_type   TEXT DEFAULT 'web',  -- web|oss|api|mobile|infra
            bug_type      TEXT DEFAULT '',
            severity      TEXT DEFAULT 'medium',
            cvss_score    REAL DEFAULT 0,
            cvss_vector   TEXT DEFAULT '',
            cwe_id        TEXT DEFAULT '',
            disclosed_at  REAL,
            reported_at   REAL,
            fixed_at      REAL,
            bounty_usd    INTEGER DEFAULT 0,
            platform      TEXT DEFAULT '',  -- hackerone|bugcrowd|intigriti|direct|vrp
            status        TEXT DEFAULT 'disclosed',  -- disclosed|pending|rejected|acknowledged
            researcher    TEXT DEFAULT 'Anonymous',
            public        INTEGER DEFAULT 1,  -- 1=show in public HoF
            write_up_url  TEXT DEFAULT '',
            nvd_url       TEXT DEFAULT '',
            patch_url     TEXT DEFAULT '',
            tags          TEXT DEFAULT '[]',
            poc_summary   TEXT DEFAULT '',  -- safe summary, no exploits
            impact        TEXT DEFAULT '',
            timeline      TEXT DEFAULT '[]',  -- JSON [{date, event}]
            created_at    REAL
        )""")
        _conn.execute("CREATE INDEX IF NOT EXISTS idx_hof_cve    ON disclosures(cve_id)")
        _conn.execute("CREATE INDEX IF NOT EXISTS idx_hof_public ON disclosures(public, disclosed_at)")
        _conn.execute("CREATE INDEX IF NOT EXISTS idx_hof_sev    ON disclosures(severity, cvss_score)")
        _conn.commit()
        _seed_example_entries()
    return _conn


def _seed_example_entries():
    """Seed with the CVEs from BugBunny research as inspiration examples."""
    count = _conn.execute("SELECT COUNT(*) FROM disclosures").fetchone()[0]
    if count > 0: return
    examples = [
        {
            "cve_id":      "CVE-2026-45185",
            "title":       "Exim GnuTLS UAF — Unauthenticated Remote Code Execution via BDAT+STARTTLS",
            "description": "Use-after-free vulnerability in Exim 4.97 triggered by a freed TLS transfer buffer "
                           "being written to via a stale tls_ungetc callback during BDAT chunking. "
                           "Allows unauthenticated remote code execution on SMTP servers.",
            "target":      "Exim MTA",
            "target_type": "oss",
            "bug_type":    "rce",
            "severity":    "critical",
            "cvss_score":  9.8,
            "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
            "cwe_id":      "CWE-416",
            "platform":    "vrp",
            "status":      "disclosed",
            "researcher":  "XBOW AI",
            "poc_summary": "BDAT+STARTTLS sequence triggers UAF via stale tls_ungetc callback. "
                           "Corrupted storeblock length field builds heap primitive.",
            "impact":      "Unauthenticated RCE on any Exim 4.97 SMTP server with GnuTLS enabled.",
            "bounty_usd":  0,
            "write_up_url": "https://xbow.com/blog/dead-letter-cve-2026-45185-xbow-found-rce-exim",
        },
        {
            "cve_id":      "CVE-2026-27471",
            "title":       "ERPNext Unauthorized Document Access via Missing Validation",
            "description": "Critical access control vulnerability in ERPNext. Certain endpoints lacked "
                           "access validation, allowing unauthorized users to access sensitive business "
                           "documents including employee records, financial data, and invoices without any authentication.",
            "target":      "ERPNext",
            "target_type": "oss",
            "bug_type":    "idor",
            "severity":    "critical",
            "cvss_score":  9.1,
            "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N",
            "cwe_id":      "CWE-284",
            "platform":    "vrp",
            "status":      "disclosed",
            "researcher":  "BugBunny AI",
            "poc_summary": "Missing authorization check on document API endpoints allows unauthenticated "
                           "access to sensitive business records.",
            "impact":      "Unauthorized access to all business documents, employee records, financial data.",
            "bounty_usd":  0,
        },
        {
            "cve_id":      "CVE-2026-22807",
            "title":       "vLLM auto_map RCE via Untrusted Dynamic Module Loading",
            "description": "High severity remote code execution vulnerability in vLLM where Hugging Face "
                           "auto_map dynamic modules are loaded during model resolution without gating on "
                           "trust_remote_code. Allows arbitrary Python code execution when loading models "
                           "from untrusted sources.",
            "target":      "vLLM",
            "target_type": "oss",
            "bug_type":    "rce",
            "severity":    "high",
            "cvss_score":  8.8,
            "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H",
            "cwe_id":      "CWE-470",
            "platform":    "vrp",
            "status":      "disclosed",
            "researcher":  "BugBunny AI",
            "poc_summary": "Loading a model with malicious auto_map config triggers arbitrary Python "
                           "code execution during model resolution phase.",
            "impact":      "RCE on any vLLM deployment loading models from untrusted Hugging Face repos.",
            "bounty_usd":  0,
        },
    ]
    ts = time.time()
    for e in examples:
        _conn.execute("""INSERT OR IGNORE INTO disclosures
            (id,cve_id,title,description,target,target_type,bug_type,severity,
             cvss_score,cvss_vector,cwe_id,platform,status,researcher,poc_summary,
             impact,bounty_usd,write_up_url,public,disclosed_at,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?)""",
            (secrets.token_hex(6), e["cve_id"], e["title"], e["description"],
             e["target"], e["target_type"], e["bug_type"], e["severity"],
             e["cvss_score"], e["cvss_vector"], e["cwe_id"],
             e["platform"], e["status"], e["researcher"],
             e["poc_summary"], e["impact"], e.get("bounty_usd",0),
             e.get("write_up_url",""), ts - 86400*30, ts))
    _conn.commit()
    log.info(f"[hof] seeded {len(examples)} example disclosures")


def add_disclosure(data: Dict) -> Dict:
    """Add a new disclosure to the Hall of Fame."""
    did = secrets.token_hex(8)
    ts  = time.time()
    with _lock:
        _db().execute("""INSERT INTO disclosures
            (id,cve_id,title,description,target,target_type,bug_type,severity,
             cvss_score,cvss_vector,cwe_id,disclosed_at,reported_at,fixed_at,
             bounty_usd,platform,status,researcher,public,write_up_url,
             nvd_url,patch_url,tags,poc_summary,impact,timeline,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (did,
             data.get("cve_id",""),
             data.get("title",""),
             data.get("description",""),
             data.get("target",""),
             data.get("target_type","web"),
             data.get("bug_type",""),
             data.get("severity","medium"),
             float(data.get("cvss_score",0)),
             data.get("cvss_vector",""),
             data.get("cwe_id",""),
             data.get("disclosed_at", ts),
             data.get("reported_at", ts),
             data.get("fixed_at"),
             int(data.get("bounty_usd",0)),
             data.get("platform",""),
             data.get("status","disclosed"),
             data.get("researcher","Anonymous"),
             1 if data.get("public", True) else 0,
             data.get("write_up_url",""),
             data.get("nvd_url",""),
             data.get("patch_url",""),
             json.dumps(data.get("tags",[])),
             data.get("poc_summary",""),
             data.get("impact",""),
             json.dumps(data.get("timeline",[])),
             ts))
        _db().commit()
    return get_disclosure(did)


def get_disclosure(did: str) -> Optional[Dict]:
    row = _db().execute("SELECT * FROM disclosures WHERE id=?", (did,)).fetchone()
    if not row: return None
    d = dict(row)
    for f in ("tags","timeline"):
        try: d[f] = json.loads(d.get(f,"[]") or "[]")
        except: d[f] = []
    return d


def list_disclosures(public_only: bool = True, severity: str = "",
                     limit: int = 50) -> List[Dict]:
    q = "SELECT * FROM disclosures WHERE 1=1"
    p = []
    if public_only: q += " AND public=1"
    if severity:    q += " AND severity=?"; p.append(severity)
    q += " ORDER BY cvss_score DESC, disclosed_at DESC LIMIT ?"
    p.append(limit)
    rows = _db().execute(q, p).fetchall()
    result = []
    for row in rows:
        d = dict(row)
        for f in ("tags","timeline"):
            try: d[f] = json.loads(d.get(f,"[]") or "[]")
            except: d[f] = []
        result.append(d)
    return result


def get_hof_stats() -> Dict:
    db = _db()
    total    = db.execute("SELECT COUNT(*) FROM disclosures WHERE public=1").fetchone()[0]
    crits    = db.execute("SELECT COUNT(*) FROM disclosures WHERE public=1 AND severity='critical'").fetchone()[0]
    highs    = db.execute("SELECT COUNT(*) FROM disclosures WHERE public=1 AND severity='high'").fetchone()[0]
    bounties = db.execute("SELECT COALESCE(SUM(bounty_usd),0) FROM disclosures WHERE public=1").fetchone()[0]
    avg_cvss = db.execute("SELECT ROUND(AVG(cvss_score),1) FROM disclosures WHERE public=1 AND cvss_score>0").fetchone()[0]
    cves     = db.execute("SELECT COUNT(*) FROM disclosures WHERE public=1 AND cve_id!=''").fetchone()[0]
    return {
        "total_disclosures": total,
        "cves_assigned":     cves,
        "critical":          crits,
        "high":              highs,
        "total_bounty_usd":  bounties,
        "avg_cvss":          avg_cvss or 0,
    }


def promote_finding_to_hof(finding: Dict, researcher: str = "Anonymous",
                           platform: str = "", bounty_usd: int = 0) -> Dict:
    """Promote an approved finding to the Hall of Fame."""
    bug  = finding.get("bug_type", finding.get("bug","unknown"))
    sev  = finding.get("severity","medium")
    url  = finding.get("url","")
    from urllib.parse import urlparse
    try: target = urlparse(url).netloc or url
    except: target = url

    data = {
        "title":       finding.get("title","Security Vulnerability Discovered"),
        "description": finding.get("impact", finding.get("description","")),
        "target":      target,
        "bug_type":    bug,
        "severity":    sev,
        "cvss_score":  finding.get("cvss_score", 0),
        "cvss_vector": finding.get("cvss_vector",""),
        "cwe_id":      finding.get("cwe_id",""),
        "platform":    platform,
        "researcher":  researcher,
        "bounty_usd":  bounty_usd,
        "poc_summary": finding.get("remediation","")[:300],
        "impact":      finding.get("impact","")[:500],
        "status":      "disclosed",
        "public":      True,
    }
    return add_disclosure(data)
