"""
TheMasterRecon AI — SSO/SAML/OIDC Integration
Google, GitHub, Microsoft, Okta, Azure AD, Generic OIDC.
No external dependencies — pure stdlib + minimal JWT.
"""
import os, json, ssl, urllib.request, urllib.parse, hashlib, secrets, time, logging
from typing import Optional, Dict

log = logging.getLogger("elite.sso")

# Provider configs
PROVIDERS = {
    "google": {
        "name":          "Google",
        "auth_url":      "https://accounts.google.com/o/oauth2/v2/auth",
        "token_url":     "https://oauth2.googleapis.com/token",
        "userinfo_url":  "https://www.googleapis.com/oauth2/v3/userinfo",
        "scopes":        "openid email profile",
        "icon":          "🔵",
    },
    "github": {
        "name":          "GitHub",
        "auth_url":      "https://github.com/login/oauth/authorize",
        "token_url":     "https://github.com/login/oauth/access_token",
        "userinfo_url":  "https://api.github.com/user",
        "scopes":        "read:user user:email",
        "icon":          "⚫",
    },
    "microsoft": {
        "name":          "Microsoft / Azure AD",
        "auth_url":      "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize",
        "token_url":     "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
        "userinfo_url":  "https://graph.microsoft.com/v1.0/me",
        "scopes":        "openid email profile User.Read",
        "icon":          "🔷",
    },
    "okta": {
        "name":          "Okta",
        "auth_url":      "https://{domain}/oauth2/default/v1/authorize",
        "token_url":     "https://{domain}/oauth2/default/v1/token",
        "userinfo_url":  "https://{domain}/oauth2/default/v1/userinfo",
        "scopes":        "openid email profile",
        "icon":          "🔴",
    },
    "generic_oidc": {
        "name":          "Generic OIDC",
        "auth_url":      "{oidc_base_url}/authorize",
        "token_url":     "{oidc_base_url}/token",
        "userinfo_url":  "{oidc_base_url}/userinfo",
        "scopes":        "openid email profile",
        "icon":          "🔑",
    },
}

# State cache (in-memory, use Redis in prod)
_state_cache: Dict[str, dict] = {}


def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False
    c.verify_mode    = ssl.CERT_NONE
    return c


def _http_get(url: str, headers: dict = None) -> dict:
    h = headers or {}
    req = urllib.request.Request(url, headers=h)
    with urllib.request.urlopen(req, timeout=15, context=_ctx()) as r:
        return json.loads(r.read())


def _http_post(url: str, data: dict, headers: dict = None) -> dict:
    h = {"Content-Type": "application/x-www-form-urlencoded", **(headers or {})}
    body = urllib.parse.urlencode(data).encode()
    req  = urllib.request.Request(url, data=body, headers=h, method="POST")
    with urllib.request.urlopen(req, timeout=15, context=_ctx()) as r:
        ct = r.headers.get("Content-Type","")
        raw = r.read()
        if "json" in ct:
            return json.loads(raw)
        return dict(urllib.parse.parse_qsl(raw.decode()))


def get_provider_config(provider: str) -> Optional[dict]:
    """Get SSO provider config from environment variables."""
    p = PROVIDERS.get(provider)
    if not p:
        return None
    prefix = f"SSO_{provider.upper()}_"
    return {
        **p,
        "client_id":     os.environ.get(f"{prefix}CLIENT_ID",""),
        "client_secret": os.environ.get(f"{prefix}CLIENT_SECRET",""),
        "tenant":        os.environ.get(f"{prefix}TENANT","common"),
        "domain":        os.environ.get(f"{prefix}DOMAIN",""),
        "oidc_base_url": os.environ.get(f"{prefix}OIDC_URL",""),
        "enabled":       bool(os.environ.get(f"{prefix}CLIENT_ID","")),
    }


def get_enabled_providers() -> list:
    """Return list of enabled SSO providers."""
    return [{"id": pid, **get_provider_config(pid)}
            for pid in PROVIDERS
            if get_provider_config(pid) and get_provider_config(pid).get("enabled")]


def build_auth_url(provider: str, redirect_uri: str) -> Optional[str]:
    """Build OAuth2/OIDC authorization URL with state."""
    cfg = get_provider_config(provider)
    if not cfg or not cfg.get("client_id"):
        return None

    state = secrets.token_urlsafe(32)
    _state_cache[state] = {"provider": provider, "ts": time.time()}

    # Template substitutions
    auth_url = cfg["auth_url"]
    for k in ["tenant","domain","oidc_base_url"]:
        auth_url = auth_url.replace("{"+k+"}", cfg.get(k,""))

    params = {
        "client_id":     cfg["client_id"],
        "redirect_uri":  redirect_uri,
        "response_type": "code",
        "scope":         cfg["scopes"],
        "state":         state,
    }
    return auth_url + "?" + urllib.parse.urlencode(params)


def handle_callback(provider: str, code: str, state: str,
                    redirect_uri: str) -> Optional[dict]:
    """Handle OAuth2 callback — exchange code for user info."""
    # Validate state
    cached = _state_cache.pop(state, None)
    if not cached or cached.get("provider") != provider:
        log.warning(f"[sso] invalid state for {provider}")
        return None
    if time.time() - cached["ts"] > 300:
        log.warning(f"[sso] expired state for {provider}")
        return None

    cfg = get_provider_config(provider)
    if not cfg:
        return None

    # Exchange code for token
    token_url = cfg["token_url"]
    for k in ["tenant","domain","oidc_base_url"]:
        token_url = token_url.replace("{"+k+"}", cfg.get(k,""))

    try:
        token_resp = _http_post(token_url, {
            "grant_type":    "authorization_code",
            "code":          code,
            "redirect_uri":  redirect_uri,
            "client_id":     cfg["client_id"],
            "client_secret": cfg["client_secret"],
        })
        access_token = token_resp.get("access_token","")
        if not access_token:
            log.warning(f"[sso] no access token from {provider}: {token_resp}")
            return None
    except Exception as e:
        log.error(f"[sso] token exchange failed: {e}")
        return None

    # Fetch user info
    userinfo_url = cfg["userinfo_url"]
    for k in ["tenant","domain","oidc_base_url"]:
        userinfo_url = userinfo_url.replace("{"+k+"}", cfg.get(k,""))

    try:
        if provider == "github":
            # GitHub needs separate email call
            user = _http_get(userinfo_url,
                             {"Authorization": f"token {access_token}"})
            if not user.get("email"):
                emails = _http_get("https://api.github.com/user/emails",
                                   {"Authorization": f"token {access_token}"})
                primary = next((e["email"] for e in emails if e.get("primary")), "")
                user["email"] = primary
        else:
            user = _http_get(userinfo_url,
                             {"Authorization": f"Bearer {access_token}"})
    except Exception as e:
        log.error(f"[sso] userinfo failed: {e}")
        return None

    # Normalize user info
    return {
        "provider":    provider,
        "provider_id": str(user.get("id") or user.get("sub","")),
        "email":       user.get("email",""),
        "name":        user.get("name") or user.get("login",""),
        "avatar":      user.get("picture") or user.get("avatar_url",""),
        "raw":         user,
    }
