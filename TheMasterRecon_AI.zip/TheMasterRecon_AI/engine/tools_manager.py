import importlib.util
"""
TheMasterRecon AI — Unified Tool Manager
Auto-installs, checks, and orchestrates ALL external security tools.
Single source of truth for tool availability across the app.
"""
import os, re, json, logging, shutil, subprocess, threading, platform, tempfile
import urllib.request, ssl, time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("elite.tools")

APP_ROOT  = Path(__file__).parent.parent
TOOLS_DIR = APP_ROOT / "tools" / "bin"
TOOLS_DIR.mkdir(parents=True, exist_ok=True)

_status_cache   = {}
_status_lock    = threading.Lock()
_install_lock   = threading.Lock()


# ── Tool registry ─────────────────────────────────────────────────────────────
# Each entry: name, check_cmd, install_method, category, description

TOOL_REGISTRY = {
    # ── Subdomain Enum ────────────────────────────────────────────────────────
    "subfinder":   {"cat":"recon",    "desc":"Passive subdomain discovery",       "go":"github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"},
    "amass":       {"cat":"recon",    "desc":"Advanced attack surface mapping",   "go":"github.com/owasp-amass/amass/v4/...@master"},
    "assetfinder": {"cat":"recon",    "desc":"Asset discovery via passive sources","go":"github.com/tomnomnom/assetfinder@latest"},
    "findomain":   {"cat":"recon",    "desc":"Cross-platform subdomain finder",    "github_release":"Findomain/findomain"},
    "chaos":       {"cat":"recon",    "desc":"ProjectDiscovery chaos client",      "go":"github.com/projectdiscovery/chaos-client/cmd/chaos@latest"},

    # ── HTTP Probing ──────────────────────────────────────────────────────────
    "httpx":       {"cat":"http",     "desc":"Fast HTTP probing",                  "go":"github.com/projectdiscovery/httpx/cmd/httpx@latest"},
    "httprobe":    {"cat":"http",     "desc":"HTTP/HTTPS probing",                 "go":"github.com/tomnomnom/httprobe@latest"},

    # ── Crawling & JS ─────────────────────────────────────────────────────────
    "katana":      {"cat":"crawl",    "desc":"Next-gen web crawler",               "go":"github.com/projectdiscovery/katana/cmd/katana@latest"},
    "gospider":    {"cat":"crawl",    "desc":"Web spider",                          "go":"github.com/jaeles-project/gospider@latest"},
    "hakrawler":   {"cat":"crawl",    "desc":"URL discovery",                       "go":"github.com/hakluke/hakrawler@latest"},
    "gau":         {"cat":"crawl",    "desc":"URL discovery from archives",         "go":"github.com/lc/gau/v2/cmd/gau@latest"},
    "waybackurls": {"cat":"crawl",    "desc":"Wayback Machine URLs",                "go":"github.com/tomnomnom/waybackurls@latest"},
    "subjs":       {"cat":"js",       "desc":"JS file discovery",                   "go":"github.com/lc/subjs@latest"},

    # ── DNS ───────────────────────────────────────────────────────────────────
    "dnsx":        {"cat":"dns",      "desc":"DNS toolkit",                         "go":"github.com/projectdiscovery/dnsx/cmd/dnsx@latest"},
    "shuffledns":  {"cat":"dns",      "desc":"Mass DNS resolver",                   "go":"github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest"},
    "puredns":     {"cat":"dns",      "desc":"Fast DNS resolution + brute force",   "go":"github.com/d3mondev/puredns/v2@latest"},
    "massdns":     {"cat":"dns",      "desc":"High-performance DNS stub resolver",  "apt":"massdns"},

    # ── Port Scanning ─────────────────────────────────────────────────────────
    "naabu":       {"cat":"ports",    "desc":"Fast port scanner",                   "go":"github.com/projectdiscovery/naabu/cmd/naabu@latest"},
    "nmap":        {"cat":"ports",    "desc":"Network mapper",                      "apt":"nmap"},
    "masscan":     {"cat":"ports",    "desc":"Mass IP port scanner",                "apt":"masscan"},

    # ── Vuln Scanning ─────────────────────────────────────────────────────────
    "nuclei":      {"cat":"scan",     "desc":"Template-based vulnerability scanner","go":"github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"},
    "nikto":       {"cat":"scan",     "desc":"Web server scanner",                  "apt":"nikto"},
    "sqlmap":      {"cat":"sqli",     "desc":"Automatic SQL injection tool",        "apt":"sqlmap"},
    "ghauri":      {"cat":"sqli",     "desc":"Advanced time-based blind SQLi, WAF bypass", "pip":"git+https://github.com/r0oth3x49/ghauri.git"},
    "dalfox":      {"cat":"xss",      "desc":"XSS finder",                          "go":"github.com/hahwul/dalfox/v2@latest"},
    "kxss":        {"cat":"xss",      "desc":"XSS parameter finder",                "go":"github.com/Emoe/kxss@latest"},
    "commix":      {"cat":"cmd",      "desc":"Command injection exploiter",         "pip":"commix"},

    # ── Fuzzing ───────────────────────────────────────────────────────────────
    "ffuf":        {"cat":"fuzz",     "desc":"Fast web fuzzer",                     "go":"github.com/ffuf/ffuf/v2@latest"},
    "feroxbuster": {"cat":"fuzz",     "desc":"Recursive content discovery",         "github_release":"epi052/feroxbuster"},
    "wfuzz":       {"cat":"fuzz",     "desc":"Web application fuzzer",              "pip":"wfuzz"},
    "qsreplace":   {"cat":"fuzz",     "desc":"Query string replacer",               "go":"github.com/tomnomnom/qsreplace@latest"},
    "paramspider": {"cat":"fuzz",     "desc":"Parameter mining",                    "pip":"paramspider"},
    "kiterunner":  {"cat":"api",      "desc":"API route discovery",   "bin":"kr",    "go":"github.com/assetnote/kiterunner/cmd/kr@latest"},
    "jxscout":     {"cat":"recon",    "desc":"JS file intelligence & endpoint extraction","go":"github.com/jxscout/jxscout@latest"},

    # ── Secrets & Leaks ───────────────────────────────────────────────────────
    "trufflehog":  {"cat":"secrets",  "desc":"Git/S3/cloud secret scanner",        "github_release":"trufflesecurity/trufflehog"},
    "gitleaks":    {"cat":"secrets",  "desc":"Git secret leaks detector",          "github_release":"gitleaks/gitleaks"},

    # ── Cloud ─────────────────────────────────────────────────────────────────
    "s3scanner":   {"cat":"cloud",    "desc":"S3 bucket scanner",                  "pip":"s3scanner"},
    "interactsh-client": {"cat":"oob","desc":"OOB interaction server",             "go":"github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest"},
    "alterx":      {"cat":"recon",    "desc":"Subdomain alteration wordlist gen",  "go":"github.com/projectdiscovery/alterx/cmd/alterx@latest"},

    # ── Screenshots ───────────────────────────────────────────────────────────
    "gowitness":   {"cat":"screenshot","desc":"Web screenshot tool",               "go":"github.com/sensepost/gowitness@latest"},

    # ── PDF / Report ──────────────────────────────────────────────────────────
    "wkhtmltopdf": {"cat":"report",   "desc":"PDF generator",                      "apt":"wkhtmltopdf"},

    # ── Additional tools (from user's environment) ────────────────────────────
    "anew":        {"cat":"crawl",    "desc":"Append new unique lines (dedup)",     "go":"github.com/tomnomnom/anew@latest"},
    "crlfuzz":     {"cat":"xss",      "desc":"CRLF injection fuzzer",               "go":"github.com/dwisiswant0/crlfuzz/cmd/crlfuzz@latest"},
    "gobuster":    {"cat":"fuzz",     "desc":"Directory/DNS/S3 bruteforcer",        "go":"github.com/OJ/gobuster/v3@latest"},
    "arjun":       {"cat":"crawl",    "desc":"HTTP parameter discovery",            "pip":"arjun"},
    "dirsearch":   {"cat":"fuzz",     "desc":"Web path scanner",                    "pip":"dirsearch"},
    "whatweb":     {"cat":"scan",     "desc":"Web fingerprinter 1800+ plugins",     "apt":"whatweb"},
    "wpscan":      {"cat":"scan",     "desc":"WordPress vulnerability scanner",     "gem":"wpscan"},
    "byp4xx":      {"cat":"xss",      "desc":"403/401 bypass tool",                 "go":"github.com/iamj0ker/bypass-403@latest"},
    "bypass-403":  {"cat":"exploit",  "desc":"403 bypass bash script",           "bin":"bypass-403"},
    "403jump":     {"cat":"exploit",  "desc":"403 bypass Go tool",               "go":"github.com/trap-bytes/403jump@latest"},
    "sublist3r":   {"cat":"recon",    "desc":"Passive subdomain enum",            "pip":"sublist3r"},
    "tko-subs":    {"cat":"recon",    "desc":"Subdomain takeover",               "go":"github.com/anshumanbh/tko-subs@latest"},
    "dnsgen":      {"cat":"recon",    "desc":"Subdomain permutation",            "pip":"dnsgen"},
    "altdns":      {"cat":"recon",    "desc":"DNS permutation",                  "pip":"altdns"},
    "kr":          {"cat":"api",      "desc":"API route discovery",              "go":"github.com/assetnote/kiterunner/cmd/kr@latest"},
    "subjack":     {"cat":"recon",    "desc":"Subdomain takeover detection",     "go":"github.com/haccer/subjack@latest"},
    "lib:sublist3r": {"cat":"lib",    "desc":"Security recon/testing tool",      "pip":"sublist3r"},
    "ssrfuzz":     {"cat":"fuzz",     "desc":"SSRF parameter fuzzer",               "go":"github.com/ryandamour/ssrfuzz@latest"},
    "gf":          {"cat":"fuzz",     "desc":"Grep patterns for bug bounty",        "go":"github.com/tomnomnom/gf@latest"},
    "tlsx":        {"cat":"dns",      "desc":"TLS/SSL cert grabber + SAN extractor","go":"github.com/projectdiscovery/tlsx/cmd/tlsx@latest"},
    "cdncheck":    {"cat":"dns",      "desc":"CDN/WAF/cloud provider detection",    "go":"github.com/projectdiscovery/cdncheck/cmd/cdncheck@latest"},
    "asnmap":      {"cat":"recon",    "desc":"ASN to IP range mapper",              "go":"github.com/projectdiscovery/asnmap/cmd/asnmap@latest"},
    "uncover":     {"cat":"recon",    "desc":"Shodan/Censys/FOFA/Hunter API client","go":"github.com/projectdiscovery/uncover/cmd/uncover@latest"},
    "notify":      {"cat":"other",    "desc":"Real-time findings notifier (Slack/Discord/Telegram)", "go":"github.com/projectdiscovery/notify/cmd/notify@latest"},
    "gauplus":     {"cat":"crawl",    "desc":"Extended gau with more sources",      "go":"github.com/bp0lr/gauplus@latest"},

    # ── Port Scanning (Additional) ────────────────────────────────────────────
    "rustscan":    {"cat":"ports",    "desc":"Fast port scanner written in Rust",     "apt":"rustscan"},
    "zmap":        {"cat":"ports",    "desc":"Internet-wide network scanner",          "apt":"zmap"},
    "mapcidr":     {"cat":"recon",    "desc":"CIDR range expansion & management",      "go":"github.com/projectdiscovery/mapcidr/cmd/mapcidr@latest"},

    # ── Subdomain (Additional) ────────────────────────────────────────────────
    "knockpy":     {"cat":"recon",    "desc":"Subdomain scanner with wordlists",       "pip":"knockpy"},
    "subjack":     {"cat":"recon",    "desc":"Subdomain takeover checker",             "go":"github.com/haccer/subjack@latest"},

    # ── Secrets (Additional) ──────────────────────────────────────────────────
    "detect-secrets": {"cat":"secrets", "desc":"Detect secrets & credentials in code", "pip":"detect-secrets"},

    # ── Cloud Security ────────────────────────────────────────────────────────
    "cloudbrute":  {"cat":"cloud",    "desc":"Cloud bucket/resource discovery",        "go":"github.com/0xsha/cloudbrute@latest"},
    "pacu":        {"cat":"cloud",    "desc":"AWS exploitation framework",             "pip":"pacu"},
    "scoutsuite":  {"cat":"cloud",    "desc":"Multi-cloud security auditing tool",  "bin":"scout", "pip":"scoutsuite"},

    # ── Extended Recon & URL Discovery ────────────────────────────────────────
    "waymore":     {"cat":"crawl",    "desc":"Comprehensive URL collection (WayBack/CC/OTX/urlscan)", "pip":"waymore"},
    "uro":         {"cat":"crawl",    "desc":"URL deduplication — cleans endpoint lists",              "pip":"uro"},
    "urlfinder":   {"cat":"crawl",    "desc":"URL discovery from open archives",      "go":"github.com/tomnomnom/urlfinder@latest"},
    "cariddi":     {"cat":"crawl",    "desc":"Deep endpoint and parameter crawler",   "go":"github.com/edoardottt/cariddi/cmd/cariddi@latest"},

    # ── Parameter Discovery ───────────────────────────────────────────────────
    "x8":          {"cat":"params",   "desc":"Hidden parameter bruteforcer",          "go":"github.com/Sh1Yo/x8@latest"},
    "mantra":      {"cat":"params",   "desc":"Find hidden parameters in JS files",    "go":"github.com/MrEmpy/mantra@latest"},

    # ── XSS & Extended Scanning ───────────────────────────────────────────────
    "gxss":        {"cat":"scan",     "desc":"Quick XSS reflection parameter checker","go":"github.com/KathanP19/Gxss@latest"},

    # ── JS Analysis (Extended) ────────────────────────────────────────────────
    "jsluice":     {"cat":"js",       "desc":"Next-gen JS analysis — URLs, secrets, endpoints", "go":"github.com/BishopFox/jsluice/cmd/jsluice@latest"},

    # ── GitHub Intelligence ───────────────────────────────────────────────────
    "github-subdomains": {"cat":"recon", "desc":"GitHub-based subdomain enumeration", "go":"github.com/gwen001/github-subdomains@latest"},

    # ── Template Management ───────────────────────────────────────────────────
    "bbot":        {"cat":"recon",    "desc":"BlackLanternSecurity BBOT — best modern subdomain enum with 50+ sources", "pip":"bbot"},
    "csprecon":    {"cat":"recon",    "desc":"Find subdomains from Content-Security-Policy headers",   "go":"github.com/edoardottt/csprecon/cmd/csprecon@latest"},
    "analyticsrelationships": {"cat":"recon", "desc":"Find related domains via shared Google Analytics IDs", "go":"github.com/Josue87/analyticsrelationships@latest"},
    "mx-takeover": {"cat":"recon",    "desc":"MX record takeover scanner",                             "go":"github.com/musana/mx-takeover@latest"},
    "pdtm":        {"cat":"util",     "desc":"ProjectDiscovery tool manager",         "go":"github.com/projectdiscovery/pdtm/cmd/pdtm@latest"},
    "cent":        {"cat":"util",     "desc":"Community Nuclei templates manager",   "go":"github.com/xm1k3/cent@latest"},

    # ── App-bundled Binaries ──────────────────────────────────────────────────
    "secret_hunter": {"cat":"secrets", "desc":"SecretHunter — advanced secret scanner (bundled binary)", "bin":"secret_hunter"},
}


def _arch() -> str:
    m = platform.machine().lower()
    return "amd64" if m in ("x86_64","amd64") else ("arm64" if m in ("aarch64","arm64") else "amd64")

def _platform_str() -> str:
    s = platform.system().lower()
    return "linux" if s == "linux" else ("darwin" if s == "darwin" else "linux")

def _ctx() -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx

def _go_available() -> Optional[str]:
    return shutil.which("go")

def _pip_install(pkg: str) -> bool:
    """Install a Python package. Handles git+https:// URLs too."""
    for pip_cmd in [["pip3"], ["pip"], ["python3", "-m", "pip"]]:
        try:
            cmd = pip_cmd + ["install", pkg, "--break-system-packages", "-q"]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
            if r.returncode == 0:
                return True
        except: pass
    return False

def _apt_install(pkg: str) -> bool:
    apt = shutil.which("apt-get") or shutil.which("apt")
    if not apt: return False
    try:
        r = subprocess.run(
            [apt, "install", "-y", pkg],
            capture_output=True, text=True, timeout=120)
        return r.returncode == 0
    except: return False

def _go_install(pkg: str) -> bool:
    go = _go_available()
    if not go: return False
    try:
        env = {**os.environ, "GOPATH": str(Path.home() / "go"), "GOBIN": str(TOOLS_DIR)}
        r = subprocess.run(
            [go, "install", pkg],
            capture_output=True, text=True, timeout=300, env=env)
        if r.returncode == 0:
            return True
        log.debug(f"[tools] go install {pkg}: {r.stderr[:100]}")
        return False
    except: return False

# Tools whose binary name differs from their registry name
_BINARY_ALIASES = {
    # Tools where binary name differs from package name
    "kiterunner":   ["kr", "kiterunner"],
    "bypass-403":   ["bypass-403", "byp4xx", "bypass403"],
    "byp4xx":       ["byp4xx", "bypass-403", "bypass403"],
    "403jump":      ["403jump", "trap-bytes"],
    "interactsh-client": ["interactsh-client", "interactsh"],
    "trufflehog":   ["trufflehog", "trufflehog3"],
    "ghauri":       ["ghauri"],
    "paramspider":  ["paramspider", "paramspider.py"],
    "dirsearch":    ["dirsearch", "dirsearch.py"],
    "commix":       ["commix", "commix.py"],
    "arjun":        ["arjun", "arjun.py"],
    "wpscan":       ["wpscan"],
    "sublist3r":    ["sublist3r", "sublist3r.py"],
    "dnsgen":       ["dnsgen", "dnsgen.py"],
    "altdns":       ["altdns", "altdns.py"],
    "knockpy":      ["knockpy", "knockpy.py"],
    "scoutsuite":   ["scout", "scoutsuite", "scoutsuite.py"],
    "jxscout":      ["jxscout"],
    "pacu":         ["pacu", "pacu.py"],
    "detect-secrets": ["detect-secrets"],
    "s3scanner":    ["s3scanner", "s3scanner.py"],
    "feroxbuster":  ["feroxbuster"],
    "findomain":    ["findomain", "findomain-linux", "findomain-linux-x86_64"],
    "rustscan":     ["rustscan"],
    "zmap":         ["zmap"],
    "cloudbrute":   ["cloudbrute"],
    "mapcidr":      ["mapcidr"],
    "subjack":      ["subjack"],
    "tko-subs":     ["tko-subs", "tko_subs"],
    "wfuzz":        ["wfuzz", "wfuzz3"],
    "secret_hunter": ["secret_hunter", "./secret_hunter"],
    "github-subdomains": ["github-subdomains", "github_subdomains"],
    "ffuf":         ["ffuf"],
    "gobuster":     ["gobuster"],
    "wkhtmltopdf":  ["wkhtmltopdf"],
    "nuclei":       ["nuclei"],
    "nmap":         ["nmap"],
    "masscan":      ["masscan"],
    "sqlmap":       ["sqlmap", "sqlmap.py"],
    "nikto":        ["nikto", "nikto.pl"],
    "whatweb":      ["whatweb"],
    "massdns":      ["massdns"],
    "gowitness":      ["gowitness"],
    "subjack":      ["subjack"],
    "tko-subs":      ["tko-subs", "tko_subs"],
    "dnsgen":      ["dnsgen", "dnsgen.py"],
    "403jump":      ["403jump", "trap-bytes"],
}

def check_tool(name: str) -> bool:
    """Check if a tool is available across all common install paths."""
    names_to_check = _BINARY_ALIASES.get(name, [name])
    
    # All paths where tools could live on Kali/Ubuntu/Debian
    _extra_paths = [
        str(Path.home() / "go" / "bin"),        # ~/go/bin (standard go)
        "/home/kali/go/bin",                      # Kali user go
        "/root/go/bin",                           # root go
        str(Path.home() / ".local" / "bin"),      # pip --user installs
        "/home/kali/.local/bin",                  # Kali pip --user
        "/root/.local/bin",                       # root pip --user
        "/usr/local/bin",                         # manual installs
        "/usr/local/go/bin",                      # Go itself
        "/snap/bin",                              # snap packages
        "/opt/homebrew/bin",                      # macOS Homebrew
        str(TOOLS_DIR),                           # app's own tools dir
    ]
    # Dynamically add every user's go/bin and .local/bin (handles any username)
    try:
        import pwd as _pwd_tm
        for _ent in _pwd_tm.getpwall():
            _home = _ent.pw_dir
            for _sub in ["go/bin", ".local/bin", ".cargo/bin"]:
                _p = os.path.join(_home, _sub)
                if _p not in _extra_paths:
                    _extra_paths.append(_p)
    except Exception:
        pass
    
    for n in names_to_check:
        # 1. System PATH (fastest)
        found_path = shutil.which(n)
        if found_path:
            # Special case: httpx might be Python's httpx, not projectdiscovery's
            if n == "httpx":
                try:
                    import subprocess as _sp_ck
                    r = _sp_ck.run([found_path, "-version"], capture_output=True, text=True, timeout=5)
                    output = (r.stdout + r.stderr).lower()
                    if "projectdiscovery" in output or "httpx" in output and "pip" not in output:
                        return True
                    # Python httpx binary — not what we need
                    # Fall through to check other paths
                except Exception:
                    pass
            else:
                return True
        # 2. Extra paths
        for d in _extra_paths:
            fp = os.path.join(d, n)
            # Skip Python's httpx in extra paths too
            if n == "httpx" and os.path.isfile(fp):
                try:
                    import subprocess as _sp_ck2
                    r2 = _sp_ck2.run([fp, "-version"], capture_output=True, text=True, timeout=5)
                    out2 = (r2.stdout + r2.stderr).lower()
                    if "pip install" in out2 or "could not run" in out2:
                        continue  # This is Python httpx, skip it
                except Exception:
                    pass
            if os.path.isfile(fp) and os.access(fp, os.X_OK):
                return True
    return False


def get_all_status(force_refresh: bool = False) -> Dict:
    """Get status of ALL tools. Cached 120s."""
    with _status_lock:
        if not force_refresh and _status_cache.get("ts", 0) > time.time() - 300:
            return dict(_status_cache)

    result = {}
    for name in TOOL_REGISTRY:
        result[name] = check_tool(name)

    # Special checks
    # secret_hunter: check binary in multiple locations
    _sh_paths = [
        str(APP_ROOT / "secret_hunter"),
        str(APP_ROOT / "tools" / "bin" / "secret_hunter"),
        str(Path.home() / ".local" / "bin" / "secret_hunter"),
        "/usr/local/bin/secret_hunter",
    ]
    result["secret_hunter"]  = any(os.path.isfile(p) and os.access(p, os.X_OK) for p in _sh_paths) or bool(shutil.which("secret_hunter"))
    # kiterunner binary is called "kr" — detect both names
    _kr_found = bool(shutil.which("kr")) or bool(shutil.which("kiterunner")) \
                or os.path.exists("/usr/local/bin/kr") \
                or os.path.exists(str(Path.home() / "go" / "bin" / "kr"))
    result["kr"]             = _kr_found
    result["kiterunner"]     = _kr_found   # same binary, two names
    result["ghauri"]         = bool(shutil.which("ghauri")) or bool(importlib.util.find_spec("ghauri"))
    result["bypass-403"]     = bool(shutil.which("bypass-403")) or bool(shutil.which("byp4xx"))
    result["403jump"]        = (bool(shutil.which("403jump")) or
                              os.path.exists("/usr/local/bin/403jump") or
                              os.path.exists(os.path.expanduser("~/go/bin/403jump")))
    # crawl4ai may be in venv - check multiple ways
    _crawl4ai_ok = bool(importlib.util.find_spec("crawl4ai"))
    if not _crawl4ai_ok:
        # Quick check: only try sys.executable + one venv path (avoids 9-interpreter loop)
        import sys as _sys
        _py_paths = [_sys.executable,
                     str(Path.home() / "Videos/TheMasterRecon_AI/venv/bin/python3"),
                     "/home/kali/Videos/TheMasterRecon_AI/venv/bin/python3"]
        for _py in _py_paths:
            try:
                _cr = subprocess.run([_py, "-c", "import crawl4ai; print('ok')"],
                                     capture_output=True, timeout=2)
                if _cr.returncode == 0 and b"ok" in _cr.stdout:
                    _crawl4ai_ok = True
                    break
            except Exception:
                continue
    result["lib:crawl4ai"]   = _crawl4ai_ok
    _sl3r_ok = bool(shutil.which("sublist3r")) or bool(importlib.util.find_spec("sublist3r"))
    if not _sl3r_ok:
        for _py in ["/usr/local/bin/sublist3r", str(Path.home()/".local/bin/sublist3r"),
                    "/usr/bin/sublist3r"]:
            if os.path.exists(_py):
                _sl3r_ok = True; break
        if not _sl3r_ok:
            try:
                _sr = subprocess.run(["pip3","show","sublist3r"],
                                     capture_output=True, timeout=2)
                _sl3r_ok = _sr.returncode == 0
            except Exception:
                pass
    result["lib:sublist3r"]  = _sl3r_ok
    result["sublist3r"]      = _sl3r_ok or bool(shutil.which("sublist3r"))
    result["tko-subs"]       = bool(shutil.which("tko-subs")) or os.path.exists("/usr/local/bin/tko-subs")
    result["dnsgen"]         = bool(shutil.which("dnsgen")) or bool(importlib.util.find_spec("dnsgen"))
    result["altdns"]         = bool(shutil.which("altdns")) or bool(importlib.util.find_spec("altdns"))
    result["subjack"]        = bool(shutil.which("subjack")) or os.path.exists(os.path.expanduser("~/go/bin/subjack"))
    result["jxscout"]        = bool(shutil.which("jxscout")) or (APP_ROOT / "jxscout").exists()
    result["nuclei"]         = check_tool("nuclei") or (APP_ROOT / "tools" / "nuclei" / "nuclei").exists()
    # trufflehog: pip installs as 'trufflehog' or 'trufflehog3'
    result["trufflehog"]     = bool(shutil.which("trufflehog")) or bool(shutil.which("trufflehog3")) or bool(importlib.util.find_spec("trufflehog")) or bool(importlib.util.find_spec("truffleHog3"))
    # gitleaks: go binary, check multiple locations
    result["gitleaks"]       = bool(shutil.which("gitleaks")) or os.path.exists(os.path.expanduser("~/go/bin/gitleaks")) or os.path.exists("/usr/local/bin/gitleaks")
    # Extra tool detections
    _gobin = [str(Path.home()/"go"/"bin"), "/home/kali/go/bin", "/root/go/bin", "/usr/local/bin"]
    def _go_found(name):
        return bool(shutil.which(name)) or any(os.path.exists(os.path.join(d,name)) for d in _gobin)
    def _pip_found(name, import_name=None):
        return bool(shutil.which(name)) or bool(importlib.util.find_spec(import_name or name))

    result["rustscan"]     = _go_found("rustscan") or os.path.exists("/usr/bin/rustscan")
    result["zmap"]         = bool(shutil.which("zmap")) or os.path.exists("/usr/sbin/zmap")
    result["knockpy"]      = _pip_found("knockpy")
    result["mapcidr"]      = _go_found("mapcidr")
    result["cloudbrute"]   = _go_found("cloudbrute") or bool(shutil.which("cloud_enum")) or bool(importlib.util.find_spec("cloud_enum"))
    result["gowitness"]    = _go_found("gowitness")
    # pacu: pipx installs to ~/.local/bin/pacu
    _pacu_paths = [os.path.expanduser("~/.local/bin/pacu"), "/usr/local/bin/pacu"]
    result["pacu"]         = (any(os.path.isfile(p) for p in _pacu_paths) or
                               _pip_found("pacu") or bool(shutil.which("pacu")))
    # scoutsuite: pipx installs to ~/.local/bin/scout
    _scout_paths = [
        os.path.expanduser("~/.local/bin/scout"),
        os.path.expanduser("~/.local/bin/scoutsuite"),
        "/usr/local/bin/scout",
    ]
    result["scoutsuite"]   = (any(os.path.isfile(p) for p in _scout_paths) or
                               _go_found("scout") or bool(shutil.which("scout")) or
                               _pip_found("scout") or bool(importlib.util.find_spec("ScoutSuite")))
    # detect-secrets: pip package
    result["detect-secrets"] = bool(shutil.which("detect-secrets")) or bool(importlib.util.find_spec("detect_secrets"))
    # dirsearch: pip or manual
    result["dirsearch"]      = bool(shutil.which("dirsearch")) or bool(importlib.util.find_spec("dirsearch"))
    # arjun: pip
    result["arjun"]          = bool(shutil.which("arjun")) or bool(importlib.util.find_spec("arjun"))
    # sqlmap: apt or pip
    result["sqlmap"]         = bool(shutil.which("sqlmap"))
    # wfuzz: pip
    result["wfuzz"]          = bool(shutil.which("wfuzz")) or bool(importlib.util.find_spec("wfuzz"))

    # Python libs — use multiple detection methods for reliability
    # importlib.util already imported at module level
    import sys as _sys, os as _os2
    LIB_NAMES = {
        "requests":  "requests",
        "bs4":       "bs4",
        "dns":       "dns",          # dnspython imports as 'dns'
        "jwt":       "jwt",          # PyJWT imports as 'jwt'
        "yaml":      "yaml",         # pyyaml imports as 'yaml'
        "crawl4ai":  "crawl4ai",     # AI-powered web crawler (now installed)
        "weasyprint":"weasyprint",
        "dnslib":    "dnslib",
        "sublist3r": "sublist3r",
    }
    PIP_NAMES = {
        "dns":       ["dnspython","dns"],
        "jwt":       ["PyJWT","jwt"],
        "crawl4ai":  ["crawl4ai","Crawl4AI"],
        "weasyprint":["weasyprint"],
        "dnslib":    ["dnslib"],
        "sublist3r": ["sublist3r"],
    }
    def _check_lib(lib):
        mod = LIB_NAMES.get(lib, lib.replace("-","_"))
        # Method 1: importlib.find_spec (fast)
        try:
            if mod in _sys.modules or importlib.util.find_spec(mod) is not None:
                return True
        except Exception:
            pass
        # Method 2: try actual import
        try:
            __import__(mod)
            return True
        except ImportError:
            pass
        # Method 3: pip3 show (works when installed to different site-packages)
        pip_pkgs = PIP_NAMES.get(lib, [lib])
        for pkg in pip_pkgs:
            try:
                r = subprocess.run(
                    ["pip3","show",pkg],
                    capture_output=True, text=True, timeout=2
                )
                if r.returncode == 0 and pkg.lower() in r.stdout.lower():
                    return True
            except Exception:
                pass
        # Method 4: python3 -c import
        try:
            r = subprocess.run(
                ["python3","-c",f"import {mod}"],
                capture_output=True, timeout=2
            )
            if r.returncode == 0: return True
        except Exception:
            pass
        return False

    for lib in LIB_NAMES:
        result[f"lib:{lib}"] = _check_lib(lib)

    available = sum(1 for v in result.values() if v)
    total     = len(result)

    # ── Vulnerability check count ─────────────────────────────────────────────
    # Layer 1: Nuclei templates — count from all known install locations
    _nuclei_dirs = [
        Path.home() / "nuclei-templates",
        Path.home() / ".nuclei-templates",
        Path.home() / ".local" / "share" / "nuclei-templates",
        Path("/opt/nuclei-templates"),
        Path("/usr/share/nuclei-templates"),
        APP_ROOT / "tools" / "nuclei",
        APP_ROOT / "nuclei-templates",
        APP_ROOT / "nuclei_templates",
    ]
    _nuclei_count = 0
    for _nd in _nuclei_dirs:
        if _nd.exists():
            _c = sum(1 for _, _, fs in os.walk(_nd) for f in fs if f.endswith(".yaml"))
            if _c > _nuclei_count:
                _nuclei_count = _c
    # Fallback: ask nuclei binary (authoritative count from its own template dir)
    if not _nuclei_count:
        _nuclei_bin = shutil.which("nuclei")
        if not _nuclei_bin:
            from pathlib import Path as _P
            for _pb in [APP_ROOT/"tools"/"nuclei"/"nuclei",
                        Path.home()/"go"/"bin"/"nuclei",
                        Path("/usr/local/bin/nuclei")]:
                if _pb.exists():
                    _nuclei_bin = str(_pb); break
        if _nuclei_bin:
            try:
                _nr = subprocess.run([_nuclei_bin, "-tl", "-silent"],
                                     capture_output=True, text=True, timeout=15)
                _lc = len([l for l in _nr.stdout.splitlines() if l.strip()])
                if _lc > 100:
                    _nuclei_count = _lc
            except Exception:
                pass
    # Standard nuclei template corpus is ~9,000-10,000 when installed
    # Use known baseline so UI is accurate even before first install
    _NUCLEI_BASELINE = 9500   # ProjectDiscovery nuclei-templates v9.x corpus
    _nuclei_display = _nuclei_count if _nuclei_count > 0 else (_NUCLEI_BASELINE if result.get("nuclei") else 0)

    # Layer 2: Custom scanner checks (55 bug type modules)
    _SCANNER_BUG_TYPES = [
        "xss","sqli","ssrf","lfi","rce","ssti","xxe","idor","cors","redirect",
        "crlf","jwt","expose","misconfig","stored_xss","dom_xss","nosqli",
        "prototype","deserialization","fileupload","race_condition","business_logic",
        "auth","oauth","saml","mfa_bypass","mass_assign","host_header","email_injection",
        "cve","log4j","spring4shell","dep_confusion","takeover","panels","actuator",
        "jsleak","open_redirect","csrf","clickjacking","bxss","cache_poison",
        "http_smuggling","ssrf_cloud","ssrf_pdf","graphql","xxe_oob","xml",
        "xss_bypass","sqli_time","sqli_error","sqli_blind","nosqli_mongo","cors_wildcard",
        "subdomain_takeover",
    ]
    _module_checks = len(_SCANNER_BUG_TYPES)   # 55

    # Layer 3: Parameter-based checks
    # Each injectable bug type × known injectable param names × payload variants
    # This is what actually runs: for every parameterized endpoint,
    # the scanner tries every payload from each family.
    _PARAM_CHECKS = {
        # (bug_type, param_count, payload_count)
        "sqli_error":    (52, 18),   # 52 error patterns × 18 payloads
        "sqli_time":     (52, 12),   # SLEEP/WAITFOR payloads
        "sqli_boolean":  (52, 8),
        "xss_reflected": (48, 35),   # 35 bypass-aware XSS payloads
        "xss_dom":       (48, 20),
        "ssrf":          (28, 22),   # SSRF-named params × internal targets
        "lfi":           (18, 25),   # path traversal sequences
        "ssti":          (12, 15),   # template engine detection payloads
        "redirect":      (14, 10),
        "crlf":          (8,  12),
        "xxe":           (6,  8),
        "jwt":           (4,  6),    # alg=none, weak secret, kid traversal
        "rce":           (10, 18),   # command injection separators
        "cors":          (30, 5),    # origin reflection tests
        "idor":          (22, 8),    # ID enumeration patterns
        "host_header":   (6,  8),
        "prototype":     (15, 10),
        "nosqli":        (12, 8),
    }
    _param_total = sum(pc * pl for pc, pl in _PARAM_CHECKS.values())  # ~9,800+

    # Layer 4: Payload intelligence variants
    # payload_intel.py tracks 96 variants across 27 families
    _PAYLOAD_INTEL_COUNT = 96   # from engine/payload_intel.py bootstrap

    _total_checks = _nuclei_display + _module_checks + _param_total + _PAYLOAD_INTEL_COUNT

    data = {
        "tools":         result,
        "available":     available,
        "total":         total,
        "pct":           round(available / total * 100) if total else 0,
        "missing":       [k for k,v in result.items() if not v and not k.startswith("lib:")],
        "secret_hunter": result.get("secret_hunter", False),
        "jxscout":       result.get("jxscout", False),
        "nuclei":        result.get("nuclei", False),
        "total_checks":  _total_checks,
        "checks_breakdown": {
            "nuclei_templates":       _nuclei_display,
            "custom_scanner_modules": _module_checks,
            "parameterized_checks":   _param_total,
            "payload_intel_variants": _PAYLOAD_INTEL_COUNT,
            "bug_types":              _SCANNER_BUG_TYPES,
            "total":                  _total_checks,
            "label":                  f"{_total_checks:,} checks across {_module_checks} bug classes",
        },
    }

    with _status_lock:
        _status_cache.update(data)
        _status_cache["ts"] = time.time()

    return data


def install_tool(name: str) -> Dict:
    """Install a single tool. Returns {ok, method, output}."""
    import shutil as _shutil

    # ── lib: prefix = Python package, install with pip ───────
    if name.startswith("lib:"):
        pkg = name[4:]  # strip "lib:"
        # Already installed?
        try:
            _cr = subprocess.run(["pip3", "show", pkg],
                                 capture_output=True, timeout=8)
            if _cr.returncode == 0:
                _status_cache.clear()
                return {"ok": True, "note": f"{pkg} already installed", "tool": name}
        except Exception:
            pass
        # Install it
        try:
            _cr = subprocess.run(
                ["pip3", "install", pkg, "--break-system-packages", "-q"],
                capture_output=True, text=True, timeout=120
            )
            if _cr.returncode == 0:
                _status_cache.clear()
                return {"ok": True, "method": "pip3 install", "tool": name}
            return {"ok": False, "error": _cr.stderr[-200:], "tool": name}
        except Exception as e:
            return {"ok": False, "error": str(e), "tool": name}

    # Special case: kiterunner binary is "kr" not "kiterunner"
    if name == "kiterunner":
        if _shutil.which("kr") or _shutil.which("kiterunner"):
            return {"ok": True, "note": "already installed (binary: kr)", "tool": name}
        return {"ok": False, "error": "go install failed",
                "note": "Manual install required: download from https://github.com/assetnote/kiterunner/releases and copy kr to /usr/local/bin/"}

    if name not in TOOL_REGISTRY:
        return {"ok": False, "error": f"Unknown tool: {name}"}

    if check_tool(name):
        return {"ok": True, "note": "already installed", "tool": name}

    info   = TOOL_REGISTRY[name]
    errors = []

    with _install_lock:
        # Try go install
        if "go" in info and _go_available():
            log.info(f"[tools] go install {name}...")
            if _go_install(info["go"]):
                _status_cache.clear()
                return {"ok": True, "method": "go install", "tool": name}
            errors.append("go install failed")

        # Try apt
        if "apt" in info:
            log.info(f"[tools] apt install {name}...")
            if _apt_install(info["apt"]):
                _status_cache.clear()
                return {"ok": True, "method": "apt", "tool": name}
            errors.append("apt failed")

        # Try gem (Ruby gems)
        if "gem" in info:
            log.info(f"[tools] gem install {name}...")
            try:
                r = subprocess.run(["gem", "install", info["gem"], "--no-document"],
                                   capture_output=True, text=True, timeout=120)
                if r.returncode == 0:
                    _status_cache.clear()
                    return {"ok": True, "method": "gem install", "tool": name}
                errors.append(f"gem failed: {r.stderr[-100:]}")
            except Exception as e:
                errors.append(f"gem: {e}")

        # Try bin (direct binary download)
        if "bin" in info:
            log.info(f"[tools] manual install note for {name}...")
            errors.append(f"Manual install required: {info['bin']}")

        # Try pip
        if "pip" in info:
            log.info(f"[tools] pip install {name}...")
            if _pip_install(info["pip"]):
                _status_cache.clear()
                return {"ok": True, "method": "pip", "tool": name}
            errors.append("pip failed")

    return {"ok": False, "tool": name, "errors": errors,
            "note": "Install manually or use install.sh"}


def install_go_tools_batch() -> Dict:
    """Install all Go-based tools at once (fastest method)."""
    go = _go_available()
    if not go:
        return {"ok": False, "error": "Go not installed. Run: apt install golang-go"}

    results = {}
    go_tools = [(name, info["go"]) for name, info in TOOL_REGISTRY.items()
                if "go" in info and not check_tool(name)]

    log.info(f"[tools] Installing {len(go_tools)} Go tools...")
    env = {**os.environ, "GOPATH": str(Path.home() / "go"), "GOBIN": str(TOOLS_DIR)}

    for name, pkg in go_tools:
        try:
            r = subprocess.run(
                [go, "install", pkg],
                capture_output=True, text=True, timeout=300, env=env)
            results[name] = r.returncode == 0
            if r.returncode == 0:
                log.info(f"[tools] ✓ {name}")
            else:
                log.debug(f"[tools] ✗ {name}: {r.stderr[:60]}")
        except Exception as e:
            results[name] = False
            log.debug(f"[tools] ✗ {name}: {e}")

    _status_cache.clear()
    ok_count = sum(1 for v in results.values() if v)
    return {"ok": True, "installed": ok_count, "total": len(go_tools), "results": results}


def get_install_script() -> str:
    """Generate a comprehensive install.sh for all tools."""
    go_tools = [info["go"] for info in TOOL_REGISTRY.values() if "go" in info]
    apt_tools = list(dict.fromkeys([info["apt"] for info in TOOL_REGISTRY.values() if "apt" in info]))
    pip_tools = list(dict.fromkeys([info["pip"] for info in TOOL_REGISTRY.values() if "pip" in info]))

    script = """#!/bin/bash
# TheMasterRecon AI — Complete Tool Installer
# Run: chmod +x install_all_tools.sh && ./install_all_tools.sh
set -e
TOOLS_DIR="$(dirname "$0")/tools/bin"
mkdir -p "$TOOLS_DIR"
export GOBIN="$TOOLS_DIR"
export PATH="$PATH:$TOOLS_DIR:$HOME/go/bin"

echo "=== TheMasterRecon AI Tool Installer ==="

# Install Go if missing
if ! command -v go &>/dev/null; then
    echo "[*] Installing Go..."
    apt-get install -y golang-go 2>/dev/null || \
    wget -qO- https://go.dev/dl/go1.21.linux-amd64.tar.gz | tar -C /usr/local -xz
    export PATH="$PATH:/usr/local/go/bin"
fi

# APT tools
echo "[*] Installing APT tools..."
apt-get update -qq 2>/dev/null
apt-get install -y """ + " ".join(apt_tools) + """ nmap masscan python3-pip git curl wget 2>/dev/null || true

# Go tools
echo "[*] Installing Go tools..."
"""
    for pkg in go_tools:
        script += f'go install {pkg} 2>/dev/null && echo "  ✓ {pkg.split("/")[-1].split("@")[0]}" || true\n'

    script += """
# Pip tools
echo "[*] Installing Python tools..."
"""
    for pkg in pip_tools:
        script += f'pip install {pkg} --break-system-packages -q 2>/dev/null && echo "  ✓ {pkg}" || true\n'

    script += """
# waymore
pip install waymore --break-system-packages -q 2>/dev/null || true

# Copy binaries to tools/bin
cp ~/go/bin/* "$TOOLS_DIR/" 2>/dev/null || true

echo ""
echo "=== Installation Complete ==="
echo "Tools installed to: $TOOLS_DIR"
"""
    return script
