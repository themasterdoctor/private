"""
engine/endpoint_export.py — Categorized endpoint file export

Classifies all discovered endpoints into categories using GF patterns
and path/param heuristics, then writes one file per category.

Categories (matching user request):
  xss, sqli, lfi, ssrf, redirect, admin, exposed, js, api,
  email, actuator, graphql, oauth, crawled, params_all

Output formats: txt (one URL per line), json, csv
"""

import os, re, json, csv, zipfile, logging
from pathlib import Path
from typing import Dict, List, Set, Tuple
from io import StringIO

log = logging.getLogger("elite.endpoint_export")

# ── GF Pattern loader (reuse from external_tools) ────────────────────────────

_GF_DIR = Path(__file__).parent.parent / "external_tools" / "GFpattren-main"
_PATTERN_CACHE: Dict[str, re.Pattern] = {}


def _load_gf(name: str):
    if name in _PATTERN_CACHE:
        return _PATTERN_CACHE[name]
    f = _GF_DIR / f"{name}.json"
    if not f.exists():
        return None
    try:
        data = json.loads(f.read_text())
        patterns = [p for p in data.get("patterns", []) if p]
        rx = re.compile("|".join(re.escape(p) for p in patterns), re.IGNORECASE)
        _PATTERN_CACHE[name] = rx
        return rx
    except Exception:
        return None


# ── Category definitions ──────────────────────────────────────────────────────
# Each category: list of (gf_pattern_file | None, inline_regex | None)
# A URL matches a category if ANY rule matches.

_RE_ADMIN = re.compile(
    r"(^|[/?])(admin|administrator|manager|management|dashboard|"
    r"console|panel|cp|backoffice|backend|moderator|superuser|siteadmin|"
    r"wp-admin|phpmyadmin|adminer|controlpanel|admin_area|adminpanel)"
    r"([/?#]|$)", re.I
)
_RE_JS = re.compile(
    r"\.js(\?|#|$)|\.jsx(\?|$)|\.ts(\?|$)|/js/|/javascript/|"
    r"\.chunk\.js|\.bundle\.js|/static/.*\.js", re.I
)
_RE_API = re.compile(
    r"(^|[/?])(api|v\d+|rest|graphql|gql|__graphql|graphiql|"
    r"swagger|openapi|api-docs|redoc|json|xml)([/?#]|$)|"
    r"\.json(\?|$)|content-type.*json", re.I
)
_RE_EMAIL = re.compile(
    r"([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})"
    r"|[?&](email|mail|from|to|reply|recipient|contact)=", re.I
)
_RE_ACTUATOR = re.compile(
    r"(^|[/?])(actuator|actuator/|health|metrics|env|info|beans|"
    r"mappings|threaddump|heapdump|loggers|prometheus|jolokia|"
    r"spring|springboot|management/|/manage/)", re.I
)
_RE_GRAPHQL = re.compile(
    r"(graphql|gql|__graphql|graphiql|graph/query|graphql/console)", re.I
)
_RE_OAUTH = re.compile(
    r"(oauth|openid|oidc|sso|saml|authorize|token|callback|"
    r"refresh_token|access_token|code=|state=|client_id=|"
    r"redirect_uri=|response_type=)", re.I
)
_RE_EXPOSED = re.compile(
    r"\.(env|git|htaccess|htpasswd|config|bak|backup|old|orig|sql|"
    r"log|cache|swp|DS_Store|pem|key|crt|cer|pfx|p12|jks|"
    r"yml|yaml|toml|ini|conf|cfg|properties|secret)(\?|$)|"
    r"(\/\.git|\/\.env|\/\.htaccess|\/backup|\/\.svn|\/\.hg|"
    r"\/phpinfo|\/server-status|\/server-info|\/web\.config)", re.I
)
_RE_PARAMS = re.compile(r"\?[^=\s]+=[^&\s]")   # has at least one param

# Map: category_name → (gf_files[], inline_regex | None)
_CATEGORIES: List[Tuple[str, List[str], re.Pattern]] = [
    # (name, [gf_pattern_files], inline_re)
    ("xss",      ["xss", "domxss"],              None),
    ("sqli",     ["sqli", "sqli-error"],          None),
    ("lfi",      ["lfi", "img-traversal"],        None),
    ("ssrf",     ["ssrf"],                        None),
    ("redirect", ["redirect", "or"],              None),
    ("admin",    [],                              _RE_ADMIN),
    ("exposed",  ["secret-urls", "secret-ext",
                  "interestingEXT"],              _RE_EXPOSED),
    ("js",       ["js-interesting", "js-sinks"],  _RE_JS),
    ("api",      ["endpoints"],                   _RE_API),
    ("email",    [],                              _RE_EMAIL),
    ("actuator", ["debug-pages", "debug_logic"],  _RE_ACTUATOR),
    ("graphql",  [],                              _RE_GRAPHQL),
    ("oauth",    ["auth"],                        _RE_OAUTH),
    ("params",   ["interestingparams",
                  "urlparams"],                   _RE_PARAMS),
]

# "crawled" = everything (no filter, useful as master wordlist)
# "all"     = alias for crawled


def classify_url(url: str) -> List[str]:
    """
    Return list of category names this URL belongs to.
    A URL can belong to multiple categories.
    """
    matches = []
    for name, gf_files, inline_re in _CATEGORIES:
        hit = False
        for gf in gf_files:
            rx = _load_gf(gf)
            if rx and rx.search(url):
                hit = True
                break
        if not hit and inline_re and inline_re.search(url):
            hit = True
        if hit:
            matches.append(name)
    return matches


def classify_all(urls: List[str]) -> Dict[str, List[str]]:
    """
    Classify a list of URLs into category buckets.
    Returns {category: [url, ...], 'crawled': all_urls}
    Deduplicates within each bucket.
    """
    buckets: Dict[str, Set[str]] = {name: set() for name, _, _ in _CATEGORIES}
    buckets["crawled"] = set()

    for url in urls:
        url = url.strip()
        if not url:
            continue
        buckets["crawled"].add(url)
        for cat in classify_url(url):
            buckets[cat].add(url)

    return {k: sorted(v) for k, v in buckets.items() if v}


# ── File writers ─────────────────────────────────────────────────────────────

def _write_txt(urls: List[str]) -> bytes:
    return ("\n".join(urls) + "\n").encode()


def _write_json(category: str, domain: str, urls: List[str]) -> bytes:
    return json.dumps({
        "domain":   domain,
        "category": category,
        "count":    len(urls),
        "urls":     urls,
    }, indent=2).encode()


def _write_csv(category: str, domain: str, urls: List[str]) -> bytes:
    buf = StringIO()
    w = csv.writer(buf)
    w.writerow(["domain", "category", "url"])
    for u in urls:
        w.writerow([domain, category, u])
    return buf.getvalue().encode()


def export_endpoints(domain: str,
                     urls: List[str],
                     output_dir: str,
                     fmt: str = "txt",
                     min_count: int = 1) -> Dict[str, str]:
    """
    Classify urls and write one file per category to output_dir.

    Returns {category: filepath} for every file written.
    fmt: 'txt' | 'json' | 'csv'
    min_count: skip categories with fewer than this many URLs.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    buckets = classify_all(urls)
    written: Dict[str, str] = {}
    total = 0

    for category, cat_urls in sorted(buckets.items()):
        if len(cat_urls) < min_count:
            continue
        ext = fmt
        fname = output_dir / f"{domain}_{category}.{ext}"
        try:
            if fmt == "json":
                data = _write_json(category, domain, cat_urls)
            elif fmt == "csv":
                data = _write_csv(category, domain, cat_urls)
            else:
                data = _write_txt(cat_urls)
            fname.write_bytes(data)
            written[category] = str(fname)
            total += len(cat_urls)
            log.info(f"[export] {domain}/{category}: {len(cat_urls)} URLs → {fname.name}")
        except Exception as e:
            log.warning(f"[export] {domain}/{category}: write failed: {e}")

    log.info(f"[export] {domain}: {len(written)} files, {total} total URL-category pairs")
    return written


def export_zip(domain: str,
               urls: List[str],
               fmt: str = "txt") -> bytes:
    """
    Classify urls and return a ZIP archive (in memory) of all category files.
    Returns raw bytes — caller writes to disk or sends as HTTP response.
    """
    import io
    buckets = classify_all(urls)
    buf = io.BytesIO()

    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        # Write manifest
        manifest = {
            "domain":     domain,
            "categories": {k: len(v) for k, v in buckets.items()},
            "total_urls": len(buckets.get("crawled", [])),
        }
        zf.writestr(f"{domain}/manifest.json",
                    json.dumps(manifest, indent=2))

        for category, cat_urls in sorted(buckets.items()):
            if not cat_urls:
                continue
            # Always include txt; also include json for machine readability
            zf.writestr(f"{domain}/{category}.txt", _write_txt(cat_urls).decode())
            zf.writestr(f"{domain}/{category}.json",
                        _write_json(category, domain, cat_urls).decode())

    buf.seek(0)
    log.info(f"[export] {domain}: zip built with {len(buckets)} categories")
    return buf.read()


def export_summary(domain: str, urls: List[str]) -> Dict:
    """Return category counts without writing files."""
    buckets = classify_all(urls)
    return {
        "domain":   domain,
        "total":    len(buckets.get("crawled", [])),
        "categories": {k: len(v) for k, v in buckets.items() if v},
        "samples":    {k: v[:3]  for k, v in buckets.items() if v},
    }
