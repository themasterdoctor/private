"""
BugScan ELITE — Continuous Monitoring Engine
Schedules recurring scans, diffs results, alerts on new vulnerabilities.
No external dependencies (no Celery/Redis required) — uses threads + SQLite.
"""
import json, time, logging, threading, sqlite3, os, re
from typing import Dict, List, Optional, Callable
from pathlib import Path
from datetime import datetime, timedelta

log = logging.getLogger("elite.monitor")

_DB_PATH = Path(os.path.dirname(__file__)).parent / "data" / "monitor.db"
_DB_PATH.parent.mkdir(parents=True, exist_ok=True)

# ── Database setup ────────────────────────────────────────────────────────────
def _get_db():
    conn = sqlite3.connect(str(_DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS schedules (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            domain    TEXT NOT NULL,
            interval  TEXT DEFAULT 'daily',
            bugs      TEXT DEFAULT '',
            active    INTEGER DEFAULT 1,
            last_run  REAL DEFAULT 0,
            next_run  REAL DEFAULT 0,
            created   REAL DEFAULT 0,
            user_id   TEXT DEFAULT ''
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS monitor_alerts (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            domain      TEXT,
            alert_type  TEXT,
            severity    TEXT,
            title       TEXT,
            url         TEXT,
            details     TEXT,
            seen        INTEGER DEFAULT 0,
            created     REAL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS scan_history (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            domain     TEXT,
            scan_type  TEXT DEFAULT 'scheduled',
            started    REAL,
            finished   REAL,
            findings   INTEGER DEFAULT 0,
            new_vulns  INTEGER DEFAULT 0,
            score      INTEGER DEFAULT 100,
            status     TEXT DEFAULT 'running'
        )
    """)
    conn.commit()
    return conn

INTERVAL_SECONDS = {
    "hourly":  3600,
    "daily":   86400,
    "weekly":  604800,
    "monthly": 2592000,
}

# ── Schedule management ───────────────────────────────────────────────────────

def add_schedule(domain: str, interval: str = "daily",
                 bugs: List[str] = None, user_id: str = "") -> int:
    """Add a domain to continuous monitoring."""
    bugs_str = ",".join(bugs or [])
    now  = time.time()
    next_run = now + INTERVAL_SECONDS.get(interval, 86400)
    with _get_db() as db:
        cur = db.execute(
            "INSERT INTO schedules (domain,interval,bugs,active,last_run,next_run,created,user_id) "
            "VALUES (?,?,?,1,0,?,?,?)",
            (domain, interval, bugs_str, next_run, now, user_id)
        )
        sid = cur.lastrowid
    log.info(f"[monitor] scheduled {domain} every {interval} (id={sid})")
    return sid

def remove_schedule(domain: str, user_id: str = ""):
    with _get_db() as db:
        db.execute("UPDATE schedules SET active=0 WHERE domain=? AND user_id=?",
                   (domain, user_id))

def list_schedules(user_id: str = "") -> List[Dict]:
    with _get_db() as db:
        rows = db.execute(
            "SELECT * FROM schedules WHERE active=1 AND (user_id=? OR ?='')",
            (user_id, user_id)
        ).fetchall()
    result = []
    for r in rows:
        next_dt = datetime.fromtimestamp(r["next_run"]).strftime("%Y-%m-%d %H:%M")
        result.append({
            "id":        r["id"],
            "domain":    r["domain"],
            "interval":  r["interval"],
            "bugs":      r["bugs"].split(",") if r["bugs"] else [],
            "active":    bool(r["active"]),
            "last_run":  r["last_run"],
            "next_run":  r["next_run"],
            "next_run_fmt": next_dt,
        })
    return result

def get_due_schedules() -> List[Dict]:
    """Return schedules that are due to run now."""
    now = time.time()
    with _get_db() as db:
        rows = db.execute(
            "SELECT * FROM schedules WHERE active=1 AND next_run <= ?", (now,)
        ).fetchall()
    return [dict(r) for r in rows]

def update_schedule_ran(schedule_id: int, interval: str):
    now      = time.time()
    next_run = now + INTERVAL_SECONDS.get(interval, 86400)
    with _get_db() as db:
        db.execute("UPDATE schedules SET last_run=?, next_run=? WHERE id=?",
                   (now, next_run, schedule_id))

# ── Alert management ──────────────────────────────────────────────────────────

def create_alert(domain: str, alert_type: str, severity: str,
                 title: str, url: str = "", details: Dict = None):
    with _get_db() as db:
        db.execute(
            "INSERT INTO monitor_alerts (domain,alert_type,severity,title,url,details,created) "
            "VALUES (?,?,?,?,?,?,?)",
            (domain, alert_type, severity, title, url,
             json.dumps(details or {}), time.time())
        )
    log.info(f"[monitor] ALERT [{severity.upper()}] {title} — {domain}")
    _dispatch_alert(domain, alert_type, severity, title, url, details or {})

def get_alerts(domain: str = "", unseen_only: bool = False) -> List[Dict]:
    with _get_db() as db:
        q = "SELECT * FROM monitor_alerts WHERE 1=1"
        params = []
        if domain:
            q += " AND domain=?"
            params.append(domain)
        if unseen_only:
            q += " AND seen=0"
        q += " ORDER BY created DESC LIMIT 100"
        rows = db.execute(q, params).fetchall()
    return [dict(r) for r in rows]

def mark_alerts_seen(domain: str):
    with _get_db() as db:
        db.execute("UPDATE monitor_alerts SET seen=1 WHERE domain=?", (domain,))

def get_unseen_count() -> int:
    with _get_db() as db:
        return db.execute("SELECT COUNT(*) FROM monitor_alerts WHERE seen=0").fetchone()[0]

# ── Diff engine ───────────────────────────────────────────────────────────────

def diff_findings(old_findings: List[Dict], new_findings: List[Dict]) -> Dict:
    """
    Compare two scan result sets.
    Returns: new vulnerabilities, resolved vulnerabilities, worsened findings.
    """
    def _key(f):
        return f"{f.get('bug','')}::{f.get('url','')}"

    old_keys = {_key(f): f for f in old_findings}
    new_keys = {_key(f): f for f in new_findings}

    new_vulns     = [f for k, f in new_keys.items() if k not in old_keys]
    resolved      = [f for k, f in old_keys.items() if k not in new_keys]
    worsened      = []

    sev_order = {"critical": 4, "high": 3, "medium": 2, "low": 1}
    for k in new_keys:
        if k in old_keys:
            old_sev = sev_order.get(old_keys[k].get("severity","low"), 1)
            new_sev = sev_order.get(new_keys[k].get("severity","low"), 1)
            if new_sev > old_sev:
                worsened.append({
                    "finding":    new_keys[k],
                    "old_sev":    old_keys[k].get("severity"),
                    "new_sev":    new_keys[k].get("severity"),
                })

    return {
        "new_vulnerabilities": new_vulns,
        "resolved":            resolved,
        "worsened":            worsened,
        "total_new":           len(new_vulns),
        "total_resolved":      len(resolved),
        "net_change":          len(new_vulns) - len(resolved),
    }

# ── Scan history ──────────────────────────────────────────────────────────────

def record_scan_start(domain: str, scan_type: str = "scheduled") -> int:
    with _get_db() as db:
        cur = db.execute(
            "INSERT INTO scan_history (domain,scan_type,started,status) VALUES (?,?,?,?)",
            (domain, scan_type, time.time(), "running")
        )
        return cur.lastrowid

def record_scan_done(scan_id: int, findings: int, new_vulns: int, score: int):
    with _get_db() as db:
        db.execute(
            "UPDATE scan_history SET finished=?,findings=?,new_vulns=?,score=?,status=? WHERE id=?",
            (time.time(), findings, new_vulns, score, "done", scan_id)
        )

def get_scan_history(domain: str, limit: int = 20) -> List[Dict]:
    with _get_db() as db:
        rows = db.execute(
            "SELECT * FROM scan_history WHERE domain=? ORDER BY started DESC LIMIT ?",
            (domain, limit)
        ).fetchall()
    result = []
    for r in rows:
        d = dict(r)
        if d["started"] and d["finished"]:
            d["duration_s"] = int(d["finished"] - d["started"])
        d["started_fmt"] = (datetime.fromtimestamp(d["started"]).strftime("%Y-%m-%d %H:%M")
                            if d["started"] else "")
        result.append(d)
    return result

def get_trend(domain: str) -> Dict:
    """Return security score trend over last 10 scans."""
    history = get_scan_history(domain, limit=10)
    if not history:
        return {"trend": [], "direction": "stable"}

    scores = [(h["started_fmt"], h["score"]) for h in history if h.get("score")]
    if len(scores) >= 2:
        diff   = scores[0][1] - scores[-1][1]
        direction = "improving" if diff > 5 else "declining" if diff < -5 else "stable"
    else:
        direction = "stable"

    return {
        "trend":     [{"date": d, "score": s} for d, s in reversed(scores)],
        "direction": direction,
        "latest":    scores[0][1] if scores else 100,
    }

# ── Alert dispatch ────────────────────────────────────────────────────────────
_alert_handlers: List[Callable] = []

def register_alert_handler(fn: Callable):
    """Register a function to call when alerts fire (Slack, email, etc.)."""
    _alert_handlers.append(fn)

def _dispatch_alert(domain, alert_type, severity, title, url, details):
    for handler in _alert_handlers:
        try:
            handler(domain=domain, alert_type=alert_type, severity=severity,
                    title=title, url=url, details=details)
        except Exception as e:
            log.debug(f"alert handler error: {e}")

# ── Background monitor thread ─────────────────────────────────────────────────
_monitor_running = False
_monitor_thread: Optional[threading.Thread] = None

def _monitor_loop(run_scan_fn: Callable):
    """
    Background loop: check for due schedules, run scans, diff results, create alerts.
    run_scan_fn(domain, bugs) should return List[Dict] of findings.
    """
    global _monitor_running
    log.info("[monitor] background monitor started")

    while _monitor_running:
        try:
            due = get_due_schedules()
            for sched in due:
                domain   = sched["domain"]
                interval = sched["interval"]
                bugs     = sched["bugs"].split(",") if sched.get("bugs") else []

                log.info(f"[monitor] running scheduled scan: {domain}")
                scan_id = record_scan_start(domain, "scheduled")

                try:
                    new_findings = run_scan_fn(domain, bugs) or []

                    # Load previous findings from storage
                    try:
                        from storage import BugScanDB
                        db = BugScanDB()
                        old_findings = db.get_findings(domain)
                    except: old_findings = []

                    # Diff
                    diff = diff_findings(old_findings, new_findings)

                    # Create alerts for new critical/high findings
                    for f in diff["new_vulnerabilities"]:
                        sev = f.get("severity","low")
                        if sev in ("critical","high","medium"):
                            create_alert(
                                domain=domain,
                                alert_type="new_vulnerability",
                                severity=sev,
                                title=f"New {sev.upper()}: {f.get('description','')[:80]}",
                                url=f.get("url",""),
                                details={"bug": f.get("bug"), "finding": f},
                            )

                    # Alert on resolved findings too (good news)
                    if diff["resolved"]:
                        create_alert(
                            domain=domain,
                            alert_type="resolved",
                            severity="info",
                            title=f"{len(diff['resolved'])} vulnerabilities resolved",
                            details={"resolved": [f.get("description","")[:50]
                                                  for f in diff["resolved"][:5]]},
                        )

                    # Score from risk engine
                    try:
                        from engine.risk_engine import score_all_findings
                        result = score_all_findings(new_findings)
                        score  = result.get("security_score", 100)
                    except: score = 100

                    record_scan_done(scan_id, len(new_findings),
                                     diff["total_new"], score)
                    update_schedule_ran(sched["id"], interval)

                    log.info(f"[monitor] {domain}: {len(new_findings)} findings, "
                             f"{diff['total_new']} new, score={score}")

                except Exception as e:
                    log.error(f"[monitor] scan error for {domain}: {e}")
                    record_scan_done(scan_id, 0, 0, 0)
                    update_schedule_ran(sched["id"], interval)

        except Exception as e:
            log.error(f"[monitor] loop error: {e}")

        # Check every 5 minutes
        time.sleep(300)

    log.info("[monitor] background monitor stopped")


def start_monitor(run_scan_fn: Callable):
    """Start the background monitoring thread."""
    global _monitor_running, _monitor_thread
    if _monitor_running:
        return
    _monitor_running = True
    _monitor_thread = threading.Thread(
        target=_monitor_loop, args=(run_scan_fn,), daemon=True, name="monitor"
    )
    _monitor_thread.start()
    log.info("[monitor] started")

def stop_monitor():
    global _monitor_running
    _monitor_running = False
    log.info("[monitor] stopping...")
