"""
BugScan APEX — Autonomous Decision Brain
The central intelligence that decides: what to scan, which attacks to try,
when to pivot, how to chain findings. Operates like an intelligent attacker.
"""
import re, time, logging, json, urllib.parse
from typing import List, Dict, Optional, Tuple, Set
from collections import defaultdict

log = logging.getLogger("apex.brain")

# ── Target classification ─────────────────────────────────────────────────────
TARGET_CLASSES = {
    "login_portal":  {"keywords": ["login","signin","auth","sso","oauth","saml","password"],
                      "priority_bugs": ["sqli","xss","saml","oauth","brute"]},
    "api_endpoint":  {"keywords": ["api","v1","v2","v3","rest","graphql","json","rpc","endpoint"],
                      "priority_bugs": ["idor","sqli","ssrf","jwt","cors","graphql"]},
    "admin_panel":   {"keywords": ["admin","dashboard","console","manage","control","panel","cms"],
                      "priority_bugs": ["sqli","xss","idor","expose","panels","rce"]},
    "file_handler":  {"keywords": ["file","upload","download","attachment","media","image","pdf","doc"],
                      "priority_bugs": ["lfi","rce","xxe","fileupload","ssrf"]},
    "redirect":      {"keywords": ["redirect","return","next","goto","url","link","forward","callback"],
                      "priority_bugs": ["redirect","ssrf","xss"]},
    "search":        {"keywords": ["search","query","q","find","filter","sort","keyword"],
                      "priority_bugs": ["sqli","xss","ssti","nosqli"]},
    "user_data":     {"keywords": ["user","profile","account","id","uid","member","customer"],
                      "priority_bugs": ["idor","sqli","xss","cors"]},
    "payment":       {"keywords": ["pay","payment","checkout","cart","billing","order","invoice"],
                      "priority_bugs": ["idor","sqli","race_condition","business_logic"]},
    "infra":         {"keywords": ["aws","s3","gcp","azure","storage","bucket","blob","lambda"],
                      "priority_bugs": ["buckets","ssrf","expose"]},
}

# ── Attack strategy matrix ────────────────────────────────────────────────────
# What to try first based on param name
PARAM_STRATEGY = {
    # SSRF params
    "url":       ["ssrf","redirect","xss"],
    "uri":       ["ssrf","redirect"],
    "redirect":  ["redirect","ssrf","xss"],
    "return":    ["redirect","ssrf"],
    "next":      ["redirect","ssrf"],
    "goto":      ["redirect","ssrf"],
    "callback":  ["redirect","ssrf","xss"],
    "webhook":   ["ssrf"],
    "target":    ["ssrf","redirect"],
    "dest":      ["ssrf","redirect"],
    "host":      ["ssrf","cors"],
    "endpoint":  ["ssrf"],
    # LFI params
    "file":      ["lfi","ssrf","xxe"],
    "path":      ["lfi","expose"],
    "page":      ["lfi","ssti"],
    "template":  ["ssti","lfi"],
    "view":      ["lfi","ssti"],
    "include":   ["lfi"],
    "load":      ["lfi","ssrf"],
    "read":      ["lfi"],
    "doc":       ["lfi","xxe"],
    # SQLi params
    "id":        ["sqli","idor"],
    "uid":       ["sqli","idor"],
    "user_id":   ["sqli","idor"],
    "order":     ["sqli"],
    "sort":      ["sqli"],
    "limit":     ["sqli"],
    "offset":    ["sqli"],
    # SSTI params
    "name":      ["ssti","xss","sqli"],
    "msg":       ["ssti","xss"],
    "message":   ["ssti","xss"],
    "content":   ["ssti","xss"],
    "body":      ["ssti","xss","xxe"],
    # XSS params
    "q":         ["xss","sqli"],
    "search":    ["xss","sqli"],
    "query":     ["xss","sqli"],
    "text":      ["xss","ssti"],
    "comment":   ["xss","stored_xss"],
    "title":     ["xss","ssti"],
    # Command injection
    "cmd":       ["rce"],
    "exec":      ["rce"],
    "command":   ["rce"],
    "ping":      ["rce","ssrf"],
    "ip":        ["ssrf","rce"],
    "token":     ["jwt","idor"],
}

# ── Tech stack → vulnerability probability ────────────────────────────────────
TECH_VULN_MATRIX = {
    "php":        {"lfi": 0.7, "sqli": 0.6, "rce": 0.5, "xxe": 0.4},
    "wordpress":  {"sqli": 0.6, "xss": 0.7, "lfi": 0.5, "panels": 0.8},
    "java":       {"xxe": 0.6, "deserialization": 0.7, "sqli": 0.5, "ssti": 0.4},
    "spring":     {"actuator": 0.9, "sqli": 0.5, "ssrf": 0.5, "deserialization": 0.6},
    "node":       {"prototype": 0.6, "sqli": 0.4, "nosqli": 0.6, "ssti": 0.5},
    "django":     {"sqli": 0.3, "ssti": 0.5, "idor": 0.6},
    "rails":      {"sqli": 0.4, "ssti": 0.5, "idor": 0.6},
    "graphql":    {"graphql": 0.9, "idor": 0.7, "ssrf": 0.5},
    "aws":        {"buckets": 0.7, "ssrf": 0.6, "iam": 0.5},
    "nginx":      {"expose": 0.5, "cors": 0.4},
    "apache":     {"expose": 0.5, "lfi": 0.4},
    "iis":        {"expose": 0.5, "lfi": 0.4},
    "tomcat":     {"deserialization": 0.6, "panels": 0.7},
    "jenkins":    {"panels": 0.9, "rce": 0.8, "expose": 0.7},
    "kubernetes": {"expose": 0.6, "ssrf": 0.7},
    "react":      {"xss": 0.4, "prototype": 0.5, "jsleak": 0.6},
    "angular":    {"xss": 0.3, "prototype": 0.5, "jsleak": 0.6},
    "vue":        {"xss": 0.4, "prototype": 0.5, "jsleak": 0.5},
    "mysql":      {"sqli": 0.6},
    "postgres":   {"sqli": 0.5},
    "mongodb":    {"nosqli": 0.7, "sqli": 0.2},
    "redis":      {"ssrf": 0.6},
    "elasticsearch": {"expose": 0.7, "ssrf": 0.5},
}

# ── Brain API ─────────────────────────────────────────────────────────────────

class ApexBrain:
    """
    The autonomous decision engine.
    Classifies targets, prioritizes attacks, adapts based on findings.
    """

    def __init__(self):
        self.findings_seen: Set[str] = set()
        self.pivots: List[Dict]      = []
        self.attack_log: List[Dict]  = []
        self.session_start           = time.time()

    def classify_endpoint(self, url: str, body: str = "", headers: Dict = None) -> Dict:
        """Classify what type of endpoint this is and what to attack."""
        headers = headers or {}
        url_lower = url.lower()
        body_lower = (body or "").lower()

        matched_classes = []
        for cls_name, cls_data in TARGET_CLASSES.items():
            score = 0
            for kw in cls_data["keywords"]:
                if kw in url_lower:   score += 2
                if kw in body_lower:  score += 1
            if score > 0:
                matched_classes.append((score, cls_name, cls_data["priority_bugs"]))

        matched_classes.sort(reverse=True)

        # Extract params and classify them
        try:
            parsed = urllib.parse.urlparse(url)
            params = list(urllib.parse.parse_qs(parsed.query).keys())
        except: params = []

        # Build priority attack list
        priority_bugs = []
        seen = set()
        for _, cls_name, bugs in matched_classes[:3]:
            for b in bugs:
                if b not in seen:
                    priority_bugs.append(b)
                    seen.add(b)

        # Add param-based priorities
        for param in params:
            for bug in PARAM_STRATEGY.get(param.lower(), []):
                if bug not in seen:
                    priority_bugs.insert(0, bug)  # param-based = highest priority
                    seen.add(bug)

        return {
            "url":            url,
            "classes":        [c for _, c, _ in matched_classes[:3]],
            "params":         params,
            "priority_bugs":  priority_bugs[:8],
            "is_api":         "api" in url_lower or "json" in headers.get("Content-Type",""),
            "is_login":       any(k in url_lower for k in ["login","signin","auth"]),
            "is_file_handler": any(k in url_lower for k in ["file","upload","download"]),
        }

    def prioritize_bugs_for_tech(self, tech_stack: List[str],
                                  requested_bugs: List[str]) -> List[str]:
        """Reorder requested bugs by probability based on tech stack."""
        from engine.learning import get_priority_bugs_for_tech

        # Get learned priorities
        learned = dict(get_priority_bugs_for_tech(tech_stack))

        # Get static matrix priorities
        static_scores = defaultdict(float)
        for tech in tech_stack:
            t = tech.lower()
            if t in TECH_VULN_MATRIX:
                for bug, prob in TECH_VULN_MATRIX[t].items():
                    static_scores[bug] += prob

        # Combine learned + static (learned has higher weight)
        combined = {}
        for bug in requested_bugs:
            score = learned.get(bug, 0) * 2.0 + static_scores.get(bug, 0)
            combined[bug] = score

        # Sort by combined score (bugs with no signal keep original order)
        scored = [(combined.get(b, 0), i, b) for i, b in enumerate(requested_bugs)]
        scored.sort(key=lambda x: (-x[0], x[1]))

        result = [b for _, _, b in scored]
        if result != requested_bugs:
            log.info(f"[apex.brain] reordered bugs for {tech_stack[:3]}: {result[:5]}")
        return result

    def get_attack_strategy(self, endpoint_info: Dict, tech_stack: List[str]) -> Dict:
        """
        Full attack strategy for a single endpoint.
        Returns ordered list of attacks with payloads, params, etc.
        """
        from engine.learning import get_best_payloads, get_best_params_for_bug

        strategy = {
            "endpoint":    endpoint_info["url"],
            "classes":     endpoint_info.get("classes", []),
            "attacks": [],
        }

        for bug in endpoint_info.get("priority_bugs", [])[:6]:
            # Get best payloads from learning engine
            learned_payloads = get_best_payloads(bug, limit=10)
            # Get best params to target
            learned_params   = get_best_params_for_bug(bug)
            # Merge with endpoint params
            params = endpoint_info.get("params", [])
            if learned_params:
                # Put learned best params first
                ordered_params = [p for p in learned_params if p in params] + \
                                 [p for p in params if p not in learned_params]
            else:
                ordered_params = params

            strategy["attacks"].append({
                "bug":            bug,
                "learned_payloads": learned_payloads,
                "target_params":  ordered_params[:5],
                "confidence":     self._bug_confidence(bug, tech_stack),
            })

        return strategy

    def _bug_confidence(self, bug: str, tech_stack: List[str]) -> float:
        """Estimate confidence 0-1 that this bug exists given the tech stack."""
        scores = []
        for tech in tech_stack:
            matrix = TECH_VULN_MATRIX.get(tech.lower(), {})
            if bug in matrix:
                scores.append(matrix[bug])
        return max(scores) if scores else 0.1

    def should_pivot(self, finding: Dict) -> List[Dict]:
        """
        Given a finding, decide if we should pivot to new attacks.
        Returns list of pivot actions to take.
        """
        pivots = []
        bug    = finding.get("bug","")
        url    = finding.get("url","")
        sev    = finding.get("severity","")

        # SSRF found → try to reach internal services
        if bug == "ssrf":
            pivots.append({
                "reason": "SSRF confirmed → probe internal services",
                "action": "ssrf_pivot",
                "targets": [
                    "http://169.254.169.254/",
                    "http://metadata.google.internal/",
                    "http://kubernetes.default.svc/",
                    "http://127.0.0.1:6379/",
                    "http://127.0.0.1:9200/",
                ],
            })

        # LFI found → try to read sensitive files
        if bug == "lfi":
            pivots.append({
                "reason": "LFI confirmed → extract credentials",
                "action": "lfi_escalate",
                "targets": [
                    "../../../../etc/passwd",
                    "../../../../etc/shadow",
                    "../../../../var/www/html/config.php",
                    "../../../../.env",
                    "../../../../proc/self/environ",
                ],
            })

        # XSS found → try stored XSS and session theft
        if bug == "xss":
            pivots.append({
                "reason": "XSS confirmed → check for stored XSS",
                "action": "stored_xss_check",
                "url": url,
            })

        # Expose found sensitive file → try to use credentials
        if bug == "expose" and sev in ("critical","high"):
            pivots.append({
                "reason": "Sensitive file exposed → extract and use credentials",
                "action": "credential_reuse",
                "url": url,
            })

        # Admin panel found → try default creds
        if bug == "panels":
            pivots.append({
                "reason": "Admin panel found → try default credentials",
                "action": "default_creds",
                "url": url,
            })

        if pivots:
            log.info(f"[apex.brain] {len(pivots)} pivot(s) triggered from {bug} finding")

        return pivots

    def rank_targets(self, live_hosts: List[str], endpoints: List[str],
                     tech_map: Dict[str, List[str]]) -> List[Dict]:
        """
        Rank all targets by expected yield.
        Returns sorted list of {url, score, reason}.
        """
        from engine.learning import get_priority_bugs_for_tech

        ranked = []
        for ep in endpoints:
            host = urllib.parse.urlparse(ep).netloc
            tech = tech_map.get(host, [])

            score  = 0
            reason = []

            # Param-based scoring
            try:
                params = list(urllib.parse.parse_qs(urllib.parse.urlparse(ep).query).keys())
            except: params = []

            for p in params:
                if p.lower() in PARAM_STRATEGY:
                    score += 3
                    reason.append(f"param:{p}")

            # Tech-based scoring
            for tech_name in tech:
                t = tech_name.lower()
                if t in TECH_VULN_MATRIX:
                    score += sum(TECH_VULN_MATRIX[t].values())
                    reason.append(f"tech:{t}")

            # URL pattern scoring
            url_lower = ep.lower()
            for cls, data in TARGET_CLASSES.items():
                for kw in data["keywords"]:
                    if kw in url_lower:
                        score += 1
                        break

            ranked.append({"url": ep, "score": score, "reason": reason[:3]})

        ranked.sort(key=lambda x: -x["score"])
        return ranked

    def auto_select_bugs(self, tech_stack: List[str], endpoint_sample: List[str],
                         available_bugs: List[str]) -> List[str]:
        """
        Autonomously select and order which bugs to scan based on:
        tech stack, endpoint patterns, learned intelligence.
        """
        endpoint_text = " ".join(endpoint_sample).lower()

        # Start with learned priorities
        from engine.learning import get_priority_bugs_for_tech
        learned = dict(get_priority_bugs_for_tech(tech_stack))

        scores = {}
        for bug in available_bugs:
            s = 0
            # Learned intel
            s += learned.get(bug, 0) * 3

            # Tech matrix
            for tech in tech_stack:
                s += TECH_VULN_MATRIX.get(tech.lower(), {}).get(bug, 0) * 2

            # Endpoint patterns
            if bug == "ssrf" and any(k in endpoint_text for k in ["url","redirect","webhook","callback"]):
                s += 3
            if bug == "lfi" and any(k in endpoint_text for k in ["file","page","template","include"]):
                s += 3
            if bug == "sqli" and any(k in endpoint_text for k in ["id=","user=","search="]):
                s += 2
            if bug == "buckets" and any(t in tech_stack for t in ["aws","gcp","azure","s3"]):
                s += 4
            if bug == "actuator" and "spring" in " ".join(tech_stack).lower():
                s += 5
            if bug == "graphql" and "graphql" in endpoint_text:
                s += 5

            scores[bug] = s

        # Sort by score, keep original order for ties
        ordered = sorted(available_bugs, key=lambda b: (-scores.get(b, 0), available_bugs.index(b)))
        log.info(f"[apex.brain] auto-selected bug order: {ordered[:8]}")
        return ordered

    def log_decision(self, action: str, reason: str, data: Dict = None):
        """Log a decision for transparency and debugging."""
        entry = {
            "ts":     time.strftime("%H:%M:%S"),
            "action": action,
            "reason": reason,
        }
        if data: entry["data"] = data
        self.attack_log.append(entry)
        log.info(f"[apex.brain] DECIDE: {action} — {reason}")

    def get_session_report(self) -> Dict:
        """Return a summary of this brain session's decisions."""
        return {
            "duration_s":   int(time.time() - self.session_start),
            "decisions":    len(self.attack_log),
            "pivots":       len(self.pivots),
            "findings_processed": len(self.findings_seen),
            "log":          self.attack_log[-20:],
        }


# ── Singleton brain instance ──────────────────────────────────────────────────
_brain: Optional[ApexBrain] = None

def get_brain() -> ApexBrain:
    global _brain
    if _brain is None:
        _brain = ApexBrain()
    return _brain

def reset_brain():
    global _brain
    _brain = ApexBrain()
