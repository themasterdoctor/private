"""
BugScan ELITE — Report Generator
One-click HackerOne/Bugcrowd-ready reports with CVSS, timeline, PoC.
"""
import json, time, os, re, logging, urllib.request, ssl
from typing import List, Dict, Optional
from datetime import datetime

log = logging.getLogger("elite.reporter")

API_KEY = os.environ.get("ANTHROPIC_API_KEY","")
MODEL   = "claude-sonnet-4-6"

CVSS_MAP = {
    "critical": {"base": 9.5, "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H"},
    "high":     {"base": 7.5, "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N"},
    "medium":   {"base": 5.3, "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N"},
    "low":      {"base": 3.1, "vector": "CVSS:3.1/AV:N/AC:H/PR:N/UI:R/S:U/C:L/I:N/A:N"},
    "info":     {"base": 0.0, "vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:N"},
}

BUG_DESCRIPTIONS = {
    "rce":            ("Remote Code Execution", "Execute arbitrary OS commands on the server"),
    "sqli":           ("SQL Injection", "Read/write the database, bypass authentication"),
    "ssrf":           ("Server-Side Request Forgery", "Make the server fetch internal resources"),
    "lfi":            ("Local File Inclusion", "Read arbitrary files from the server filesystem"),
    "ssti":           ("Server-Side Template Injection", "Execute code via template engine injection"),
    "xxe":            ("XML External Entity Injection", "Read files and perform SSRF via XML"),
    "cors":           ("CORS Misconfiguration", "Cross-origin requests with stolen credentials"),
    "idor":           ("Insecure Direct Object Reference", "Access other users' data without authorization"),
    "xss":            ("Cross-Site Scripting", "Execute JavaScript in victim's browser"),
    "expose":         ("Sensitive Information Exposure", "Access credentials, keys, or configuration"),
    "actuator":       ("Spring Boot Actuator Exposure", "Access internal application data and controls"),
    "takeover":       ("Subdomain Takeover", "Take control of a company subdomain"),
    "jsleak":         ("Secret in JavaScript", "API keys and credentials exposed in client-side code"),
    "oauth":          ("OAuth Misconfiguration", "Authentication bypass or token theft"),
    "jwt":            ("JWT Vulnerability", "Forge authentication tokens"),
    "graphql":        ("GraphQL Vulnerability", "Expose schema and inject malicious queries"),
    "saml":           ("SAML Vulnerability", "SSO authentication bypass"),
    "redirect":       ("Open Redirect", "Redirect users to attacker-controlled domains"),
    "crlf":           ("CRLF Injection", "Inject arbitrary HTTP headers"),
    "prototype":      ("Prototype Pollution", "Modify JavaScript object prototypes"),
    "deserialization":("Insecure Deserialization", "Execute code via deserialization gadget chains"),
    "log4j":          ("Log4Shell (CVE-2021-44228)", "Critical RCE via JNDI injection in Log4j"),
    "spring4shell":   ("Spring4Shell (CVE-2022-22965)", "Critical RCE in Spring Framework"),
    "misconfig":      ("Security Misconfiguration", "Missing security headers or server disclosure"),
    "nosqli":         ("NoSQL Injection", "Bypass authentication or exfiltrate NoSQL data"),
    "fileupload":     ("Unrestricted File Upload", "Upload and execute malicious files"),
    "smuggling":      ("HTTP Request Smuggling", "Bypass security controls via request desync"),
    "buckets":        ("Cloud Storage Misconfiguration", "Public access to sensitive cloud storage"),
    "cve":            ("Known CVE", "Exploit a known vulnerability with public CVE"),
    "panels":         ("Exposed Admin Panel", "Administrative interface accessible without restriction"),
}

REMEDIATION_MAP = {
    "rce":            "Avoid passing user input to OS commands. Use safe APIs and allowlists.",
    "sqli":           "Use parameterized queries or prepared statements throughout.",
    "ssrf":           "Validate/whitelist URLs. Block internal IP ranges at network level.",
    "lfi":            "Validate file paths with allowlist. Use basename(). Never expose path params.",
    "ssti":           "Never render user input through template engines. Use sandboxed rendering.",
    "xxe":            "Disable external entity processing: factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true)",
    "cors":           "Validate Origin header against explicit whitelist. Never reflect arbitrary origins.",
    "idor":           "Implement server-side authorization checks for every resource. Use UUIDs.",
    "xss":            "Encode all output. Implement strict CSP. Use XSS-safe frameworks.",
    "expose":         "Remove sensitive files from web root. Implement access controls.",
    "actuator":       "Restrict actuator access: management.endpoints.web.exposure.include=health,info",
    "takeover":       "Remove or update dangling DNS records immediately.",
    "jsleak":         "Move secrets to server-side environment variables. Audit all JS bundles.",
    "oauth":          "Validate redirect_uri strictly against whitelist. Use state parameter.",
    "jwt":            "Use asymmetric algorithms (RS256). Validate alg header server-side.",
    "graphql":        "Disable introspection in production. Implement query depth/complexity limits.",
    "saml":           "Validate XML signatures strictly. Use established SAML libraries.",
    "redirect":       "Validate redirect URLs against allowlist of trusted domains.",
    "crlf":           "Strip \\r and \\n from all user input used in headers.",
    "prototype":      "Use Object.create(null) for lookup maps. Validate input keys.",
    "deserialization":"Implement deserialization filters. Use serialization allowlists.",
    "log4j":          "Update Log4j to 2.17.1+. Set -Dlog4j2.formatMsgNoLookups=true",
    "spring4shell":   "Update Spring Framework to 5.3.18+. Upgrade to JDK 9+ patch level.",
    "misconfig":      "Implement all security headers. Remove server version information.",
    "nosqli":         "Validate input types. Use type-safe query builders.",
    "fileupload":     "Validate file type by magic bytes. Store outside webroot. Rename files.",
    "smuggling":      "Normalize requests at proxy. Reject ambiguous Transfer-Encoding/Content-Length.",
    "buckets":        "Set bucket ACL to private. Enable Block Public Access. Audit IAM policies.",
    "cve":            "Apply vendor security patch. Review all dependencies for known vulnerabilities.",
    "panels":         "Restrict admin paths to internal IPs only. Implement MFA.",
}

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _ai_enhance(prompt: str) -> str:
    if not API_KEY: return ""
    try:
        body = json.dumps({
            "model": MODEL, "max_tokens": 2048,
            "system": "You are an elite bug bounty hunter writing precise, professional security reports for HackerOne and Bugcrowd. Be technical, concise, and impactful.",
            "messages": [{"role":"user","content":prompt}],
        }).encode()
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages", data=body,
            headers={"x-api-key":API_KEY,"anthropic-version":"2023-06-01",
                     "content-type":"application/json"}, method="POST"
        )
        with urllib.request.urlopen(req, timeout=60, context=_ctx()) as r:
            d = json.loads(r.read())
            for block in d.get("content",[]):
                if block.get("type")=="text": return block["text"]
    except Exception as e:
        log.warning(f"AI enhance: {e}")
    return ""




# ── Bounty estimates from H1 public data ─────────────────────────────────────
# Source: average of disclosed H1 bounties per bug type + severity
_BOUNTY_ESTIMATES = {
    ("critical", "rce"):          (10000, 75000),
    ("critical", "sqli"):         (5000,  25000),
    ("critical", "ssrf"):         (5000,  25000),
    ("critical", "ssti"):         (5000,  20000),
    ("critical", "deserialization"): (5000, 30000),
    ("critical", "xxe"):          (3000,  15000),
    ("critical", "lfi"):          (2000,  10000),
    ("critical", "takeover"):     (1000,   5000),
    ("critical", "jwt"):          (3000,  15000),
    ("critical", "cors"):         (2000,  10000),
    ("critical", "oauth"):        (3000,  20000),
    ("high",     "sqli"):         (1000,  10000),
    ("high",     "ssrf"):         (1000,   8000),
    ("high",     "idor"):         (500,    5000),
    ("high",     "xss"):          (500,    3000),
    ("high",     "cors"):         (500,    3000),
    ("high",     "jwt"):          (1000,   5000),
    ("high",     "oauth"):        (1000,   8000),
    ("high",     "lfi"):          (500,    3000),
    ("high",     "takeover"):     (500,    3000),
    ("high",     "expose"):       (300,    2000),
    ("high",     "panels"):       (500,    5000),
    ("high",     "jsleak"):       (200,    2000),
    ("medium",   "xss"):          (200,    1000),
    ("medium",   "cors"):         (200,    1000),
    ("medium",   "idor"):         (200,    2000),
    ("medium",   "redirect"):     (100,    500),
    ("medium",   "crlf"):         (100,    500),
    ("low",      "expose"):       (100,    500),
}

def _bounty_estimate(bug: str, sev: str) -> str:
    """Return bounty range string from H1 public data."""
    key = (sev.lower(), bug.lower())
    rng = _BOUNTY_ESTIMATES.get(key)
    if not rng:
        # Fall back to severity-only estimate
        fallback = {
            "critical": (3000, 25000), "high": (500, 5000),
            "medium": (100, 1000), "low": (50, 300),
        }
        rng = fallback.get(sev.lower(), (100, 1000))
    lo, hi = rng
    return f"${lo:,} – ${hi:,}"


def _reproducibility_score(finding: Dict) -> Dict:
    """Score how easily a triager can reproduce this finding (0-100)."""
    score = 0
    reasons = []

    poc = str(finding.get("poc", "") or "")
    param = finding.get("param", "")
    details = finding.get("details", {})

    if "curl" in poc.lower():
        score += 30; reasons.append("curl command present")
    if param:
        score += 20; reasons.append(f"parameter '{param}' identified")
    if "grep" in poc.lower() or "observe" in poc.lower():
        score += 10; reasons.append("verification step included")
    if finding.get("payload") or details.get("payload"):
        score += 15; reasons.append("exact payload included")
    if finding.get("oob_confirmed"):
        score += 25; reasons.append("OOB callback confirmed")
    if details.get("preview"):
        score += 10; reasons.append("response preview available")
    if len(poc) > 100:
        score += 10; reasons.append("detailed PoC")

    label = "High" if score >= 70 else "Medium" if score >= 40 else "Low"
    return {"score": min(100, score), "label": label, "reasons": reasons}


def _attack_narrative(finding: Dict, bug: str, sev: str,
                      chains: List[Dict] = None) -> str:
    """
    Write the attack story — what an attacker does step by step,
    what they gain at each step. This is what H1 triagers actually read.
    """
    url = finding.get("url", "")
    param = finding.get("param", "")
    domain = finding.get("domain", "") or (
        url.split("/")[2] if "://" in url else "target"
    )
    poc = finding.get("poc", "")

    narratives = {
        "xss": f"""An attacker crafts a malicious link targeting the `{param}` parameter on `{url}`.
When a victim (e.g., an authenticated user or admin) clicks the link,
JavaScript executes in their browser context — reading session cookies,
making authenticated API calls on their behalf, or redirecting them to a phishing page.
{f"The payload `{finding.get('payload','')}` demonstrates execution." if finding.get('payload') else ""}
Impact escalates to account takeover if session tokens are readable.""",

        "sqli": f"""An attacker injects SQL syntax into the `{param}` parameter at `{url}`.
The database executes attacker-controlled queries. Depending on privileges:
error-based injection reveals DB schema → credentials → admin access;
time-based injection confirms the vulnerability without visible output;
UNION injection extracts arbitrary tables including user credentials.
{f"Technique confirmed: {finding.get('details',{}).get('technique','time-based')}." if finding.get('details') else ""}""",

        "ssrf": f"""An attacker controls the URL processed server-side via `{param}` at `{url}`.
The server makes HTTP requests on the attacker's behalf from inside the network perimeter.
Targets: cloud metadata (169.254.169.254 → IAM credentials),
internal services (Redis, Elasticsearch, admin dashboards),
AWS IMDSv1 → full cloud account compromise via leaked IAM keys.
{f"OOB callback received — server-side request confirmed." if finding.get('oob_confirmed') else ""}""",

        "cors": f"""An attacker hosts a malicious page at evil.com. When a victim visits,
JavaScript on evil.com calls `{url}` with `credentials: include`.
Because the server reflects `evil.com` as a trusted origin with credentials allowed,
the victim's session cookies are sent — the response (API data, tokens, PII) flows to evil.com.
No user interaction needed beyond visiting the attacker's page.""",

        "idor": f"""An attacker with a normal account accesses `{url}` and modifies the `{param}` value.
The server returns data belonging to a different account — authorization is checked at login
but not per-request. By iterating IDs, the attacker reads all accounts' data in bulk.""",

        "takeover": f"""The DNS record for `{url.split('/')[2] if '://' in url else url}` points to
an external service that is no longer provisioned. An attacker registers the unclaimed
external resource, taking full control of the subdomain. This enables:
serving malicious content from a trusted company domain, stealing cookies scoped to
`*.{domain}`, bypassing CSP rules that whitelist the subdomain.""",

        "jwt": f"""The JWT implementation at `{url}` has a signing vulnerability.
An attacker modifies the token payload (changing `role: user` to `role: admin`)
and either uses `alg: none` (no signature required) or exploits algorithm confusion
(RS256 public key used as HS256 HMAC secret). The server accepts the forged token,
granting admin access to any user.""",

        "ssti": f"""User input reaches the template engine at `{url}` via `{param}`.
The application renders input as template syntax instead of data.
Proof: `{{{{7*7}}}}` returns `49` — the expression was evaluated.
Escalation: access to the template engine's Python/Ruby objects enables
OS command execution: `{{'{{config.__class__.__init__.__globals__["os"].popen("id").read()}}'}}` → full RCE.""",

        "lfi": f"""The `{param}` parameter at `{url}` is used in a file system read without path normalization.
An attacker uses `../` sequences to escape the web root and read arbitrary files:
`/etc/passwd` (user enumeration), `.env` (credentials), SSH keys, application source code.
On PHP systems, log poisoning + LFI chains to remote code execution.""",

        "rce": f"""An attacker achieves arbitrary command execution on the server hosting `{url}`.
This is the highest-severity finding class: full server compromise, lateral movement
to internal network, exfiltration of all data, potential cloud credential theft,
and persistence via backdoors. The attack surface is unlimited.""",
    }

    narrative = narratives.get(bug.lower(), f"""The vulnerability at `{url}` allows an attacker to
exceed their intended authorization. Specific impact depends on the data and functionality
exposed at this endpoint, but the finding meets the criteria for {sev.upper()} severity
based on the evidence collected.""")

    # Add chain escalation if relevant
    if chains:
        relevant = [ch for ch in chains if bug.lower() in ch.get("requires", [])]
        if relevant:
            narrative += "\n\n**Chain Escalation:** This finding chains with " + relevant[0]["name"] + " → " + relevant[0]["impact"] + "\n"

    return narrative.strip()



def _similar_h1_reports(bug: str, url: str, n: int = 3) -> str:
    """Fetch similar confirmed H1 reports from RAG for this bug type."""
    try:
        from engine.rag_db import search as rag_search
        query = f"{bug} {url.split('/')[2] if '://' in url else url[:30]}"
        similar = rag_search(query, top_k=n, bug_type=bug.lower())
        if not similar:
            similar = rag_search(bug, top_k=n)
        if not similar:
            return ""
        lines = ["\n---\n\n## Similar Confirmed H1 Reports\n"]
        lines.append("These reports confirm this vulnerability class is reportable:\n")
        for r in similar[:n]:
            bounty = f" — ${r.get('bounty',0):,}" if r.get('bounty') else ""
            program = f" ({r.get('program','')})" if r.get('program') else ""
            url_str = r.get('url','')
            title = r.get('title','')[:70]
            lines.append(f"- [{title}]({url_str}){program}{bounty}")
        return "\n".join(lines) + "\n"
    except Exception:
        return ""

def generate_h1_report(finding: Dict, domain: str, chains: List[Dict] = None) -> str:
    """Generate HackerOne-ready markdown report for a single finding."""
    bug    = finding.get("bug","")
    url    = finding.get("url","")
    sev    = finding.get("severity","medium")
    detail = finding.get("details",{})
    ts     = finding.get("ts", time.strftime("%Y-%m-%dT%H:%M:%SZ"))

    bug_name, bug_desc = BUG_DESCRIPTIONS.get(bug, (bug.upper(), "Security vulnerability"))
    remediation = REMEDIATION_MAP.get(bug, "Apply vendor security patch and review code.")
    cvss = CVSS_MAP.get(sev, CVSS_MAP["medium"])

    # Find related chains
    related_chains = []
    if chains:
        related_chains = [c for c in chains if bug in c.get("findings",{})]

    # Compute additional quality metrics
    bounty_range    = _bounty_estimate(bug, sev)
    repro_score     = _reproducibility_score(finding)
    narrative       = _attack_narrative(finding, bug, sev, related_chains)
    xbow_grade      = finding.get("_xbow_grade", "")
    xbow_verdict    = finding.get("_xbow_verdict", "")
    xbow_score      = finding.get("_xbow_evidence_score", 0)
    xbow_note       = finding.get("_xbow_analyst_note", "")
    xbow_missing    = finding.get("_xbow_missing", [])
    mythos_risk     = finding.get("_mythos_chain_risk", 0)
    mythos_cause    = finding.get("_mythos_root_cause", "")
    mythos_trust    = finding.get("_mythos_trust_boundary", "")
    mythos_assume   = finding.get("_mythos_assumption", "")
    chain_risk_lbl  = "High" if mythos_risk >= 70 else ("Medium" if mythos_risk >= 40 else "Low")

    # Evidence grade badge
    grade_badge = ""
    if xbow_grade:
        grade_colors = {"A":"🟢","B":"🟡","C":"🟠","D":"🔴","F":"⛔"}
        grade_badge  = f" {grade_colors.get(xbow_grade,'⬜')} Evidence Grade: **{xbow_grade}**"

    report = f"""# {bug_name} in {domain}{grade_badge}

## Summary

A **{sev.upper()}** severity {bug_name} vulnerability was identified at `{url}`.
Estimated bounty range: **{bounty_range}** (based on similar H1 disclosures).

{narrative}

---

## Severity & Evidence

| Field | Value |
|-------|-------|
| **Severity** | {sev.upper()} |
| **CVSS Score** | {cvss['base']} — `{cvss['vector']}` |
| **URL** | `{url}` |
| **Parameter** | `{detail.get('param', 'N/A')}` |
| **Discovered** | {ts[:10]} |
| **Evidence Grade** | {xbow_grade or 'Pending'} ({xbow_score}/100) |
| **Reproducibility** | {repro_score['label']} ({repro_score['score']}/100) |
| **Chain Risk** | {chain_risk_lbl} ({mythos_risk}/100) |
| **Bounty Estimate** | {bounty_range} |

---

## Steps to Reproduce

{_generate_steps(bug, url, detail)}

---

## Proof of Concept

```bash
{detail.get('poc', detail.get('curl', detail.get('preview','See steps above')[:500]))}
```

{_preview_block(detail)}

---

## Impact

{_impact_detail(bug, sev, url)}

{_chain_section(related_chains)}

---

## Root Cause Analysis

**Broken Assumption:** {mythos_assume or bug_desc}

**Trust Boundary Violated:** {mythos_trust or "User ↔ Application"}

**Most Likely Root Cause:** {mythos_cause or "Security control missing or bypassable"}

---

## Why This Is Not a False Positive

"""
    # XBOW evidence argument
    if xbow_verdict == "confirmed" and xbow_grade in ("A","B"):
        report += f"Evidence grade **{xbow_grade}** (score {xbow_score}/100) — XBOW validation confirmed.\n\n"
        if finding.get("oob_confirmed"): report += "- ✅ Out-of-band callback received (deterministic proof)\n"
        if detail.get("param"): report += f"- ✅ Vulnerable parameter `{detail.get('param')}` isolated\n"
        if "curl" in str(detail.get("poc","")).lower(): report += "- ✅ Working curl command reproduces the issue\n"
        report += f"- Reproducibility score: {repro_score['label']} ({repro_score['score']}/100) — {', '.join(repro_score['reasons'][:3])}\n"
    else:
        report += f"Manual verification recommended before submission.\n"
        if xbow_missing:
            report += f"To strengthen: {'; '.join(xbow_missing[:3])}\n"

    similar_h1 = _similar_h1_reports(bug, url)

    report += f"""
---

## Remediation

{remediation}

### References
{_references(bug)}
{similar_h1}

---

## Bounty Severity Argument

This finding meets **{sev.upper()}** severity criteria:
- Vulnerability class: {bug_name} — {bug_desc[:80]}
- CVSS {cvss['base']} ({sev.upper()})
- Chain risk: {chain_risk_lbl} ({mythos_risk}/100)
- Evidence quality: {xbow_grade or 'Pending'} grade, {xbow_score}/100 evidence score
- Estimated range: **{bounty_range}** based on similar disclosed H1 reports

*Report generated by BugScan ELITE — {time.strftime("%Y-%m-%d %H:%M UTC")}*
"""
    # ── XBOW/Mythos enhancement ──────────────────────────────────────────────
    xbow_grade    = finding.get("_xbow_grade","")
    xbow_verdict  = finding.get("_xbow_verdict","")
    xbow_score    = finding.get("_xbow_evidence_score",0)
    xbow_note     = finding.get("_xbow_analyst_note","")
    xbow_missing  = finding.get("_xbow_missing",[])
    mythos_risk   = finding.get("_mythos_chain_risk",0)
    mythos_cause  = finding.get("_mythos_root_cause","")
    mythos_trust  = finding.get("_mythos_trust_boundary","")
    mythos_assume = finding.get("_mythos_assumption","")
    if xbow_grade:
        report += f"\n---\n\n## Evidence Quality Grade: {xbow_grade}\n\n"
        report += f"**Verdict:** {xbow_verdict} | **Score:** {xbow_score}/100\n\n**Note:** {xbow_note}\n\n"
        if xbow_missing: report += "**Missing for stronger report:** " + "; ".join(xbow_missing) + "\n\n"
    if mythos_assume:
        report += f"\n---\n\n## Root Cause\n\n**Broken assumption:** {mythos_assume}\n\n"
        report += f"**Trust boundary:** {mythos_trust}\n\n**Likely cause:** {mythos_cause}\n\n"
    report += f"\n---\n\n## Why Not a False Positive\n\n"
    if xbow_verdict == "confirmed":
        report += f"XBOW grade **{xbow_grade}** — evidence score {xbow_score}/100. "
        if finding.get("oob_confirmed"): report += "OOB callback confirmed. "
        if finding.get("param"): report += f"Parameter `{finding.get('param')}` isolated. "
    else:
        report += "Manual verification recommended before submission. "
    chain_txt = "High" if mythos_risk >= 70 else ("Medium" if mythos_risk >= 40 else "Low")
    report += f"\n\n**Suggested bounty severity:** {sev.upper()} — CVSS {cvss['base']} — Chain risk: {chain_txt} ({mythos_risk}/100)\n"
    return report.strip()


def generate_full_report(domain: str, findings: List[Dict],
                         chains: List[Dict], recon_data: Dict,
                         waf_info: Dict = None) -> str:
    """Generate complete penetration test report."""
    ts = time.strftime("%Y-%m-%d")
    crits  = [f for f in findings if f.get("severity")=="critical"]
    highs  = [f for f in findings if f.get("severity")=="high"]
    meds   = [f for f in findings if f.get("severity")=="medium"]
    lows   = [f for f in findings if f.get("severity") not in ("critical","high","medium")]
    risk   = "CRITICAL" if crits else "HIGH" if highs else "MEDIUM" if meds else "LOW"

    subs   = recon_data.get("subs",0)
    lives  = recon_data.get("live",0)
    ends   = recon_data.get("endpoints",0)
    tech   = recon_data.get("tech",[])

    waf_line = ""
    if waf_info and waf_info.get("detected"):
        waf_line = f"\n**WAF Detected**: {waf_info.get('vendor','Unknown')} — bypass strategies applied during testing.\n"

    chain_section = ""
    if chains:
        chain_section = "\n---\n## Exploitation Chains\n\n"
        chain_section += "The following multi-step exploitation chains were identified:\n\n"
        for i, c in enumerate(chains, 1):
            chain_section += f"""### Chain {i}: {c['name']}
**Severity**: {c['severity'].upper()} | **Impact**: {c['impact']}

{chr(10).join(c['steps'])}

**PoC**:
```
{c['poc'][:800]}
```

"""

    # Build per-finding sections
    crit_section = ""
    for i, f in enumerate(crits[:15], 1):
        bug = f.get("bug","")
        name, _ = BUG_DESCRIPTIONS.get(bug, (bug.upper(), ""))
        d = f.get("details",{})
        cvss = CVSS_MAP.get("critical",{})
        crit_section += f"""
### C{i}. {name}
**URL**: `{f.get('url','')}`
**CVSS**: {cvss.get('base',9.5)} | **Vector**: `{cvss.get('vector','')}`

{d.get('description','Vulnerability confirmed.')[:300]}

**Evidence**: `{d.get('preview','')[:200]}`
**Remediation**: {REMEDIATION_MAP.get(bug,'Apply security patch.')}

"""

    high_rows = "\n".join(
        f"| {BUG_DESCRIPTIONS.get(f.get('bug',''),('?',''))[0]} | `{f.get('url','')[:80]}` | HIGH | {CVSS_MAP['high']['base']} |"
        for f in highs[:20]
    )
    med_rows = "\n".join(
        f"| {BUG_DESCRIPTIONS.get(f.get('bug',''),('?',''))[0]} | `{f.get('url','')[:80]}` | MEDIUM |"
        for f in meds[:20]
    )

    report = f"""# Penetration Test Report — {domain}

**Classification**: CONFIDENTIAL
**Date**: {ts}
**Risk Rating**: ⚠️ {risk}
**Tested By**: BugScan ELITE

---

## Executive Summary

Security assessment of **{domain}** identified **{len(findings)} vulnerabilities**:
**{len(crits)} Critical**, **{len(highs)} High**, **{len(meds)} Medium**, **{len(lows)} Low/Info**.
{waf_line}
**Attack Surface**:
| Metric | Count |
|--------|-------|
| Subdomains | {subs} |
| Live Hosts | {lives} |
| Endpoints  | {ends} |
| Technologies | {', '.join(tech[:8]) or 'Unknown'} |
| Critical Findings | **{len(crits)}** |
| High Findings | **{len(highs)}** |
| Exploitation Chains | **{len(chains)}** |

---

## Critical Findings
{crit_section or '_No critical findings._'}

---

## High Findings

| Vulnerability | URL | Severity | CVSS |
|---------------|-----|----------|------|
{high_rows or '| — | None | — | — |'}

---

## Medium Findings

| Vulnerability | URL | Severity |
|---------------|-----|----------|
{med_rows or '| — | None | — |'}

{chain_section}

---

## Remediation Roadmap

| Priority | Action | Timeline |
|----------|--------|----------|
| **Immediate** | Patch all Critical findings — RCE, SQLi, SSRF, secrets exposure | 0–48 hours |
| **Urgent** | Address all High findings — IDOR, auth issues, takeovers | 1 week |
| **Short-term** | Fix Medium findings — XSS, CORS, headers | 1 month |
| **Ongoing** | Security code review, WAF tuning, dependency updates | Continuous |

---

*Generated by BugScan ELITE · {time.strftime("%Y-%m-%d %H:%M UTC")}*
*This report is confidential and intended for authorized personnel only.*
"""
    return report.strip()


def _impact_statement(bug: str, sev: str) -> str:
    impacts = {
        "rce":       "allows an unauthenticated attacker to execute arbitrary commands on the server",
        "sqli":      "allows an attacker to read, modify, or delete the entire database",
        "ssrf":      "allows an attacker to access internal services and cloud metadata",
        "lfi":       "allows an attacker to read sensitive files including credentials and source code",
        "ssti":      "can lead to full Remote Code Execution on the server",
        "xxe":       "allows reading arbitrary files and performing SSRF attacks",
        "cors":      "allows cross-origin theft of authenticated session data",
        "idor":      "allows accessing or modifying other users' private data",
        "xss":       "allows executing arbitrary JavaScript in users' browsers",
        "expose":    "exposes sensitive credentials, configurations, or intellectual property",
        "actuator":  "exposes Spring Boot internals including environment variables and heap memory",
        "takeover":  "allows an attacker to serve malicious content from a trusted company subdomain",
        "jsleak":    "exposes API keys allowing direct access to third-party services",
        "log4j":     "allows unauthenticated remote code execution (CVSS 10.0)",
        "spring4shell": "allows unauthenticated remote code execution on Spring applications",
    }
    return impacts.get(bug, f"poses a {sev} security risk to the application and its users")


def _impact_detail(bug: str, sev: str, url: str) -> str:
    name, _ = BUG_DESCRIPTIONS.get(bug, (bug.upper(),""))
    base = f"Exploitation of this {name} vulnerability could enable an attacker to:\n\n"
    details = {
        "rce":       "- Execute arbitrary OS commands with web server privileges\n- Establish persistent reverse shell access\n- Pivot to internal network\n- Exfiltrate all application data",
        "sqli":      "- Read all database contents including user credentials\n- Bypass authentication\n- Modify or delete data\n- Potentially achieve RCE via INTO OUTFILE",
        "ssrf":      "- Access cloud metadata endpoints (AWS/GCP/Azure)\n- Steal IAM credentials\n- Probe internal network services\n- Potentially achieve RCE via Redis/Memcached SSRF",
        "cors":      "- Steal authenticated session tokens\n- Make authenticated API calls as victim\n- Access private user data\n- Account takeover at scale",
        "idor":      "- Access all other users' private data\n- Modify other users' records\n- Constitute a reportable data breach under GDPR/CCPA",
        "takeover":  "- Serve malicious content from trusted company subdomain\n- Set cookies on parent domain\n- Conduct phishing attacks with high credibility\n- Potentially steal user session cookies",
        "jsleak":    "- Access third-party services with company credentials\n- Read/write cloud storage\n- Send authenticated API requests\n- Incur financial charges to the company",
        "log4j":     "- Unauthenticated remote code execution (CVSS 10.0)\n- Full server compromise\n- Lateral movement across infrastructure\n- Classified as one of the most critical CVEs in history",
    }
    return base + details.get(bug, f"- Compromise the security of {url}\n- Impact user data and application integrity")


def _generate_steps(bug: str, url: str, detail: Dict) -> str:
    param = detail.get("param","[PARAMETER]")
    payload = detail.get("payload","[PAYLOAD]")
    steps = {
        "sqli":     f"1. Navigate to `{url}`\n2. Insert payload `{payload}` in the `{param}` parameter\n3. Observe SQL error or time delay confirming injection",
        "xss":      f"1. Navigate to `{url}`\n2. Insert payload `{payload}` in the `{param}` parameter\n3. Observe JavaScript execution in response",
        "cors":     f"1. Send request to `{url}` with header `Origin: https://evil.com`\n2. Observe `Access-Control-Allow-Origin: https://evil.com` in response\n3. Note `Access-Control-Allow-Credentials: true`",
        "expose":   f"1. Navigate to `{url}`\n2. Observe sensitive file contents returned with HTTP 200\n3. Note exposed credentials/configuration",
        "actuator": f"1. Navigate to `{url}`\n2. Observe Spring Boot actuator data returned\n3. Check /actuator/env for leaked secrets",
        "idor":     f"1. Navigate to `{url}` (ID={detail.get('original_id','1')})\n2. Change ID to `{detail.get('test_id','2')}`\n3. Observe another user's data returned",
        "takeover": f"1. Observe `{url}` CNAME points to `{detail.get('provider','external service')}`\n2. Note signature: `{detail.get('signature','')}`\n3. Register service and claim subdomain",
        "ssrf":     f"1. Send request to `{url}` with `{param}=http://169.254.169.254/latest/meta-data/`\n2. Observe cloud metadata in response",
    }
    return steps.get(bug, f"1. Navigate to `{url}`\n2. Apply test payload\n3. Observe vulnerability response")


def _preview_block(detail: Dict) -> str:
    preview = detail.get("preview","")
    if not preview: return ""
    return f"\n**Response Preview**:\n```\n{preview[:400]}\n```\n"


def _chain_section(chains: List[Dict]) -> str:
    if not chains: return ""
    s = "\n---\n### Exploitation Chain\n\nThis vulnerability can be chained with other findings:\n\n"
    for c in chains[:2]:
        s += f"**{c['name']}** → {c['impact']}\n"
    return s


def _references(bug: str) -> str:
    refs = {
        "rce":       "- [OWASP Command Injection](https://owasp.org/www-community/attacks/Command_Injection)\n- [CWE-78](https://cwe.mitre.org/data/definitions/78.html)",
        "sqli":      "- [OWASP SQL Injection](https://owasp.org/www-community/attacks/SQL_Injection)\n- [CWE-89](https://cwe.mitre.org/data/definitions/89.html)",
        "ssrf":      "- [OWASP SSRF](https://owasp.org/www-community/attacks/Server_Side_Request_Forgery)\n- [CWE-918](https://cwe.mitre.org/data/definitions/918.html)",
        "xss":       "- [OWASP XSS](https://owasp.org/www-community/attacks/xss/)\n- [CWE-79](https://cwe.mitre.org/data/definitions/79.html)",
        "cors":       "- [OWASP CORS](https://owasp.org/www-community/vulnerabilities/CORS_OriginHeaderScrutiny)\n- [CWE-942](https://cwe.mitre.org/data/definitions/942.html)",
        "log4j":     "- [CVE-2021-44228](https://nvd.nist.gov/vuln/detail/CVE-2021-44228)\n- [CVSS 10.0](https://www.first.org/cvss/calculator/3.1#CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H)",
        "spring4shell":"- [CVE-2022-22965](https://nvd.nist.gov/vuln/detail/CVE-2022-22965)\n- [Spring Security Advisory](https://spring.io/blog/2022/03/31/spring-framework-rce-early-announcement)",
        "idor":       "- [OWASP IDOR](https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/05-Authorization_Testing/04-Testing_for_Insecure_Direct_Object_References)\n- [CWE-639](https://cwe.mitre.org/data/definitions/639.html)",
    }
    return refs.get(bug, f"- [OWASP Top 10](https://owasp.org/www-project-top-ten/)\n- [CWE Top 25](https://cwe.mitre.org/top25/archive/2023/2023_top25_list.html)")


def generate_intigriti_report(finding: Dict, domain: str, chains: List[Dict] = None) -> str:
    """
    Generate Intigriti-format vulnerability report.
    Intigriti uses a structured format different from HackerOne.
    """
    bug    = finding.get("bug","")
    url    = finding.get("url","")
    sev    = finding.get("severity","medium")
    detail = finding.get("details",{})
    cwe_id = finding.get("cwe_id", detail.get("cwe",""))
    
    bug_name, bug_desc = BUG_DESCRIPTIONS.get(bug, (bug.upper(), "Security vulnerability"))
    
    # Intigriti severity mapping
    sev_map = {
        "critical": "Critical",
        "high":     "High",
        "medium":   "Medium",
        "low":      "Low",
        "info":     "Informational",
    }
    
    report = f"""# {bug_name} in {domain}

## Vulnerability Summary

**Type:** {bug_name}
**Severity:** {sev_map.get(sev, "Medium")}
**Asset:** {domain}
**URL:** {url}
{f"**CWE:** {cwe_id}" if cwe_id else ""}

## Description

{bug_desc}

{_impact_statement(bug, sev)}

## Steps to Reproduce

{_generate_steps(finding.get("bug","vuln"), finding.get("url",""), finding.get("details",finding))}

## Proof of Concept

```
{finding.get("poc", detail.get("poc", detail.get("curl","N/A")))}
```

## Impact

{_impact_detail(bug, sev, url)}

## Technical Details

| Field | Value |
|-------|-------|
| Endpoint | `{url}` |
{f"| Parameter | `{detail.get('param','')}` |" if detail.get('param') else ""}
{f"| Payload | `{str(detail.get('payload',''))[:100]}` |" if detail.get('payload') else ""}
{f"| CWE | [{cwe_id}](https://cwe.mitre.org/data/definitions/{cwe_id.replace('CWE-','')}.html) |" if cwe_id else ""}

## Remediation

{REMEDIATION_MAP.get(bug, "Apply security best practices and review the affected component.")}

## References

{_references(bug)}
"""
    return report.strip()


def generate_bugcrowd_report(finding: Dict, domain: str, chains: List[Dict] = None) -> str:
    """Generate Bugcrowd VRT-aligned report."""
    bug    = finding.get("bug","")
    url    = finding.get("url","")
    sev    = finding.get("severity","medium")
    detail = finding.get("details",{})
    
    bug_name, bug_desc = BUG_DESCRIPTIONS.get(bug, (bug.upper(), "Security vulnerability"))
    
    # Bugcrowd VRT priority mapping
    priority_map = {"critical":"P1","high":"P2","medium":"P3","low":"P4","info":"P5"}
    priority = priority_map.get(sev,"P3")
    
    report = f"""## Summary

{bug_name} vulnerability identified at {url}.

**Priority:** {priority}
**VRT Category:** {bug_name}
**Affected Asset:** {domain}

## Description

{bug_desc}

{_impact_statement(bug, sev)}

## Steps to Reproduce

{_generate_steps(finding.get("bug","vuln"), finding.get("url",""), finding.get("details",finding))}

## Proof of Concept

```
{finding.get("poc", detail.get("poc","N/A"))}
```

## Supporting Material / References

{_references(bug)}

## Suggested Fix

{REMEDIATION_MAP.get(bug, "Review and remediate the affected component.")}
"""
    return report.strip()

