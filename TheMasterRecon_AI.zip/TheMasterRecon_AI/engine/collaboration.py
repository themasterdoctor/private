"""
TheMasterRecon AI — Team Collaboration Engine
Shared workspaces, finding comments, audit log, real-time notifications.
"""
import os, json, time, logging
from pathlib import Path
from typing import List, Optional, Dict

log = logging.getLogger("elite.collab")


class CollabDB:
    def __init__(self, data_dir: str = "./data"):
        self.root = Path(data_dir) / "_collab"
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, name: str) -> Path:
        return self.root / name

    def _load(self, name: str, default=None):
        p = self._path(name)
        if p.exists():
            try: return json.load(open(p))
            except Exception: pass
        return default if default is not None else {}

    def _save(self, name: str, data):
        json.dump(data, open(self._path(name), "w"), indent=2)

    # ── Workspaces ───────────────────────────────────────────────────────────
    def create_workspace(self, name: str, created_by: str,
                         description: str = "") -> dict:
        workspaces = self._load("workspaces.json", {})
        ws_id = f"ws_{int(time.time())}_{name.lower().replace(' ','_')}"
        workspaces[ws_id] = {
            "id":          ws_id,
            "name":        name,
            "description": description,
            "created_by":  created_by,
            "created_at":  time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "members":     {created_by: "admin"},
            "domains":     [],
        }
        self._save("workspaces.json", workspaces)
        self.audit_log(ws_id, created_by, "workspace_created", {"name": name})
        return workspaces[ws_id]

    def get_workspaces(self, username: str) -> List[dict]:
        workspaces = self._load("workspaces.json", {})
        return [ws for ws in workspaces.values()
                if username in ws.get("members", {})]

    def add_member(self, ws_id: str, username: str, role: str, added_by: str):
        workspaces = self._load("workspaces.json", {})
        if ws_id not in workspaces:
            raise ValueError(f"Workspace {ws_id} not found")
        workspaces[ws_id]["members"][username] = role
        self._save("workspaces.json", workspaces)
        self.audit_log(ws_id, added_by, "member_added", {"username": username, "role": role})

    def add_domain(self, ws_id: str, domain: str, added_by: str):
        workspaces = self._load("workspaces.json", {})
        if ws_id not in workspaces:
            raise ValueError(f"Workspace {ws_id} not found")
        if domain not in workspaces[ws_id]["domains"]:
            workspaces[ws_id]["domains"].append(domain)
        self._save("workspaces.json", workspaces)
        self.audit_log(ws_id, added_by, "domain_added", {"domain": domain})

    # ── Comments on findings ─────────────────────────────────────────────────
    def add_comment(self, domain: str, finding_id: str, username: str,
                    comment: str, tags: List[str] = None) -> dict:
        comments_file = f"comments_{domain.replace('.','_').replace('/','_')}.json"
        comments = self._load(comments_file, {})
        if finding_id not in comments:
            comments[finding_id] = []
        entry = {
            "id":         f"c_{int(time.time()*1000)}",
            "username":   username,
            "comment":    comment,
            "tags":       tags or [],
            "ts":         time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "edited":     False,
        }
        comments[finding_id].append(entry)
        self._save(comments_file, comments)
        return entry

    def get_comments(self, domain: str, finding_id: str = None) -> dict:
        comments_file = f"comments_{domain.replace('.','_').replace('/','_')}.json"
        comments = self._load(comments_file, {})
        if finding_id:
            return comments.get(finding_id, [])
        return comments

    def update_finding_status(self, domain: str, finding_id: str,
                               status: str, username: str, note: str = "") -> dict:
        """Update finding status: open, in_progress, fixed, wont_fix, duplicate, fp"""
        VALID = {"open","in_progress","fixed","wont_fix","duplicate","false_positive"}
        if status not in VALID:
            raise ValueError(f"Invalid status: {status}. Must be one of {VALID}")
        statuses_file = f"statuses_{domain.replace('.','_').replace('/','_')}.json"
        statuses = self._load(statuses_file, {})
        statuses[finding_id] = {
            "status":     status,
            "updated_by": username,
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "note":       note,
        }
        self._save(statuses_file, statuses)
        self.audit_log(domain, username, "finding_status_updated",
                       {"finding_id": finding_id, "status": status})
        return statuses[finding_id]

    def get_finding_statuses(self, domain: str) -> dict:
        statuses_file = f"statuses_{domain.replace('.','_').replace('/','_')}.json"
        return self._load(statuses_file, {})

    # ── Assignments ──────────────────────────────────────────────────────────
    def assign_finding(self, domain: str, finding_id: str,
                       assigned_to: str, assigned_by: str) -> dict:
        assigns_file = f"assigns_{domain.replace('.','_').replace('/','_')}.json"
        assigns = self._load(assigns_file, {})
        assigns[finding_id] = {
            "assigned_to": assigned_to,
            "assigned_by": assigned_by,
            "assigned_at": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        }
        self._save(assigns_file, assigns)
        self.audit_log(domain, assigned_by, "finding_assigned",
                       {"finding_id": finding_id, "to": assigned_to})
        return assigns[finding_id]

    def get_assignments(self, domain: str) -> dict:
        assigns_file = f"assigns_{domain.replace('.','_').replace('/','_')}.json"
        return self._load(assigns_file, {})

    # ── Audit log ────────────────────────────────────────────────────────────
    def audit_log(self, scope: str, username: str, action: str, details: dict = None):
        audit_file = "audit_log.json"
        log_data   = self._load(audit_file, [])
        entry = {
            "ts":       time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "scope":    scope,
            "username": username,
            "action":   action,
            "details":  details or {},
        }
        log_data.append(entry)
        # Keep last 10,000 entries
        if len(log_data) > 10000:
            log_data = log_data[-10000:]
        self._save(audit_file, log_data)

    def get_audit_log(self, scope: str = None, username: str = None,
                      limit: int = 200) -> List[dict]:
        log_data = self._load("audit_log.json", [])
        if scope:
            log_data = [e for e in log_data if e.get("scope") == scope]
        if username:
            log_data = [e for e in log_data if e.get("username") == username]
        return list(reversed(log_data[-limit:]))

    # ── Shared notes ─────────────────────────────────────────────────────────
    def save_note(self, domain: str, note_id: str, title: str,
                  content: str, author: str, tags: List[str] = None) -> dict:
        notes_file = f"notes_{domain.replace('.','_').replace('/','_')}.json"
        notes = self._load(notes_file, {})
        notes[note_id] = {
            "id":         note_id,
            "title":      title,
            "content":    content,
            "author":     author,
            "tags":       tags or [],
            "created_at": notes.get(note_id, {}).get("created_at",
                          time.strftime("%Y-%m-%dT%H:%M:%SZ")),
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        }
        self._save(notes_file, notes)
        return notes[note_id]

    def get_notes(self, domain: str) -> List[dict]:
        notes_file = f"notes_{domain.replace('.','_').replace('/','_')}.json"
        return list(self._load(notes_file, {}).values())


_collab_db: Optional[CollabDB] = None

def get_collab_db(data_dir: str = "./data") -> CollabDB:
    global _collab_db
    if _collab_db is None:
        _collab_db = CollabDB(data_dir)
    return _collab_db
