"""
BugScan ELITE — Signal Quality Engine
Tasks 1-4: false-positive reduction, multi-validator consensus,
            validation cache, structured diff engine.

HARD RULES (enforced throughout):
  - No auto-exploitation
  - No destructive payloads
  - No credential extraction
  - No auth bypass automation
  - Human approval required for all decisions
  - Stability over features
"""

import hashlib, json, logging, re, threading, time
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("elite.signal_quality")

# ── TASK 1 — Per-bug confidence weights ───────────────────────────────────────
#
# Each signal type carries a weight.  Multiple signals accumulate.
# No single reflection → HIGH is possible (enforced in _compute_consensus).

_SIGNAL_WEIGHTS: Dict[str, int] = {
    # Basic signals — low confidence individually
    "reflection_only":       15,   # parameter echoed in response
    "status_diff":           18,   # HTTP status code changed
    "length_diff_small":     10,   # < 50 bytes difference
    "length_diff_large":     22,   # > 200 bytes difference
    "header_diff":           20,   # Location / ACAO / Set-Cookie changed

    # Structural signals — medium confidence
    "keyword_hit":           25,   # error keyword in response (e.g. syntax error)
    "context_match":         20,   # bug-type keyword in correct HTML/JS context
    "timing_delta_weak":     20,   # 1-3s consistent delay
    "timing_delta_strong":   35,   # > 3s consistent delay, ≥3 repeats
    "expression_evaluated":  30,   # {{7*7}} → 49, safe arithmetic

    # High-confidence signals
    "canary_reflected":      28,   # canary string appears in response body
    "canary_in_context":     35,   # canary in correct tag/attribute context
    "oob_dns":               40,   # OOB DNS callback received
    "oob_http":              45,   # OOB HTTP callback received (stronger)

    # Penalties (subtract)
    "single_signal_only":   -10,   # only one type of signal observed
    "inconsistent_timing":  -15,   # timing delta not consistent across runs
    "generic_error_page":    -8,   # error page present on baseline too
}

# Minimum signals required before HIGH/CRITICAL can be assigned
_CONSENSUS_MINIMUMS = {
    "critical": 3,   # needs ≥3 independent signal types
    "high":     2,   # needs ≥2 independent signal types
    "medium":   1,   # single strong signal is enough
    "low":      1,
}

# Severity caps when only one signal type observed
_SINGLE_SIGNAL_CAP = {
    "reflection_only": "medium",
    "status_diff":     "medium",
    "length_diff_small": "low",
    "header_diff":     "medium",
}


def compute_confidence_breakdown(signals: List[str]) -> Dict:
    """
    TASK 1 — Compute weighted confidence from observed signal list.

    Returns:
    {
      "total_confidence": int,
      "breakdown": {"reflection_only": 15, "timing_delta_strong": 35, ...},
      "signal_count": int,
      "consensus_reached": bool,
      "severity_cap": str | None
    }
    """
    breakdown   = {}
    total       = 0
    sev_cap     = None
    signal_types = set(signals)

    for sig in signals:
        weight = _SIGNAL_WEIGHTS.get(sig, 0)
        if weight != 0:
            breakdown[sig] = weight
            total += weight

    # Penalty: only one signal type
    if len(signal_types) == 1:
        only = next(iter(signal_types))
        breakdown["single_signal_only"] = _SIGNAL_WEIGHTS["single_signal_only"]
        total += _SIGNAL_WEIGHTS["single_signal_only"]
        sev_cap = _SINGLE_SIGNAL_CAP.get(only)

    total = max(0, min(100, total))
    consensus_reached = len(signal_types) >= 2

    log.debug(f"[signal-quality] confidence={total} signals={list(signal_types)[:4]} "
              f"consensus={consensus_reached} cap={sev_cap}")
    return {
        "total_confidence": total,
        "breakdown":        breakdown,
        "signal_count":     len(signal_types),
        "consensus_reached": consensus_reached,
        "severity_cap":     sev_cap,
    }


def enforce_consensus(severity: str, confidence: int,
                      signal_types: List[str]) -> Tuple[str, int, str]:
    """
    TASK 2 — Multi-validator consensus enforcement.

    Rules:
    - CRITICAL requires ≥3 independent signal types AND confidence ≥ 88
    - HIGH    requires ≥2 independent signal types AND confidence ≥ 72
    - No single reflection alone may produce HIGH
    - No single status_diff alone may produce HIGH

    Returns (adjusted_severity, adjusted_confidence, reason)
    """
    unique_signals = len(set(signal_types))
    sev_lower      = severity.lower()
    reason_parts   = []

    # CRITICAL guard
    if sev_lower == "critical":
        if unique_signals < _CONSENSUS_MINIMUMS["critical"]:
            severity = "high"
            reason_parts.append(
                f"downgraded critical→high: only {unique_signals} signal type(s), "
                f"need {_CONSENSUS_MINIMUMS['critical']}")
        if confidence < 88:
            severity = "high"
            reason_parts.append(f"downgraded critical→high: confidence {confidence} < 88")

    # HIGH guard
    if sev_lower in ("critical", "high"):
        if unique_signals < _CONSENSUS_MINIMUMS["high"]:
            severity = "medium"
            reason_parts.append(
                f"downgraded {sev_lower}→medium: only {unique_signals} signal type(s), "
                f"need {_CONSENSUS_MINIMUMS['high']}")
        if confidence < 72 and severity == "high":
            severity = "medium"
            reason_parts.append(f"downgraded high→medium: confidence {confidence} < 72")

    # Single-signal cap
    if len(set(signal_types)) == 1:
        only = next(iter(signal_types), "")
        cap = _SINGLE_SIGNAL_CAP.get(only)
        if cap:
            SEV_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
            if SEV_ORDER.get(severity, 0) > SEV_ORDER.get(cap, 0):
                old_sev = severity
                severity = cap
                reason_parts.append(
                    f"single signal '{only}' capped at {cap} (was {old_sev})")

    consensus = unique_signals >= 2
    if consensus and not reason_parts:
        log.info(f"[validate] consensus achieved confidence={confidence} signals={unique_signals}")
    elif reason_parts:
        log.info(f"[validate] severity adjusted: {'; '.join(reason_parts)}")

    return severity, confidence, "; ".join(reason_parts) or "consensus ok"


# ── TASK 3 — Validation cache ─────────────────────────────────────────────────

_VAL_CACHE: Dict[str, Dict] = {}
_VAL_CACHE_LOCK = threading.Lock()
_CACHE_TTL = 3600   # 1 hour


def validation_fingerprint(path: str, bug_type: str,
                           params: Optional[List[str]] = None,
                           response_sig: str = "") -> str:
    """
    TASK 3 — Produce a stable cache key for a finding.

    Normalises:
    - path (strips querystring)
    - bug_type (lowercase)
    - params (sorted, lowercased)
    - response_sig (first 64 chars of response length pattern)
    """
    norm_path  = path.split("?")[0].rstrip("/").lower()
    norm_bug   = bug_type.lower().strip()
    norm_params = ",".join(sorted(p.lower() for p in (params or [])))
    sig_part   = response_sig[:64] if response_sig else ""
    raw        = f"{norm_path}|{norm_bug}|{norm_params}|{sig_part}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def cache_get(fingerprint: str) -> Optional[Dict]:
    """Return cached validation result if still fresh."""
    with _VAL_CACHE_LOCK:
        entry = _VAL_CACHE.get(fingerprint)
        if entry and (time.time() - entry["cached_at"]) < _CACHE_TTL:
            log.info(f"[validate] cached validation hit fp={fingerprint}")
            return entry["result"]
        if entry:
            del _VAL_CACHE[fingerprint]   # expired
        return None


def cache_set(fingerprint: str, result: Dict) -> None:
    """Store a validation result in the cache."""
    with _VAL_CACHE_LOCK:
        # Limit cache size — evict oldest if needed
        if len(_VAL_CACHE) > 2000:
            oldest = min(_VAL_CACHE, key=lambda k: _VAL_CACHE[k]["cached_at"])
            del _VAL_CACHE[oldest]
        _VAL_CACHE[fingerprint] = {
            "result":    result,
            "cached_at": time.time(),
        }
    log.debug(f"[validate] cached result fp={fingerprint} size={len(_VAL_CACHE)}")


def cache_stats() -> Dict:
    """Return current cache statistics."""
    with _VAL_CACHE_LOCK:
        now   = time.time()
        fresh = sum(1 for e in _VAL_CACHE.values()
                    if (now - e["cached_at"]) < _CACHE_TTL)
        return {
            "total":   len(_VAL_CACHE),
            "fresh":   fresh,
            "expired": len(_VAL_CACHE) - fresh,
            "ttl_seconds": _CACHE_TTL,
        }


# ── TASK 4 — Safe structured response diff engine ────────────────────────────

# Keywords that indicate a server-side error (safe to report as signal)
_ERROR_KEYWORDS = [
    "syntax error", "sql error", "database error", "mysql error", "ora-",
    "pg::", "sqlite3", "unterminated quoted", "you have an error in your sql",
    "warning: ", "notice: ", "exception in thread", "traceback (most",
    "java.lang.", "nullpointerexception", "500 internal server",
    "unexpected token", "parse error", "undefined variable",
    "invalid argument", "division by zero",
]

# Keywords that are benign / present on most pages
_NOISE_KEYWORDS = [
    "cookie", "session", "cache", "vary", "etag", "last-modified",
    "x-request-id", "date:", "content-length",
]


def structured_response_diff(
    baseline_status: int,
    probe_status:    int,
    baseline_body:   str,
    probe_body:      str,
    baseline_headers: Dict = None,
    probe_headers:    Dict = None,
) -> Dict:
    """
    TASK 4 — Structured diff between baseline and probe responses.

    Returns:
    {
      "status_changed":       bool,
      "length_delta":         int,
      "header_delta":         [str],     # header names that changed
      "keyword_hits":         [str],     # error keywords in probe but not baseline
      "reflection_detected":  bool,      # safe canary or known marker reflected
      "signals":              [str],     # list of signal type names for TASK 1
      "summary":              str,       # analyst-readable, no payloads
    }
    """
    baseline_body = baseline_body or ""
    probe_body    = probe_body    or ""
    bh = baseline_headers or {}
    ph = probe_headers    or {}

    signals       = []
    keyword_hits  = []
    header_delta  = []

    # 1. Status change
    status_changed = baseline_status != probe_status and baseline_status > 0
    if status_changed:
        signals.append("status_diff")

    # 2. Body length delta
    length_delta = abs(len(probe_body) - len(baseline_body))
    if length_delta > 200:
        signals.append("length_diff_large")
    elif length_delta > 50:
        signals.append("length_diff_small")

    # 3. Header changes (ignore noise headers)
    all_headers = set(bh.keys()) | set(ph.keys())
    for h in all_headers:
        h_lower = h.lower()
        if any(n in h_lower for n in _NOISE_KEYWORDS):
            continue
        bval = bh.get(h, "")
        pval = ph.get(h, "")
        if bval != pval:
            header_delta.append(h)
            signals.append("header_diff")
    header_delta = list(set(header_delta))[:8]

    # 4. Keyword hits — error keywords present in probe but not baseline
    b_lower = baseline_body.lower()
    p_lower = probe_body.lower()
    for kw in _ERROR_KEYWORDS:
        if kw in p_lower and kw not in b_lower:
            keyword_hits.append(kw)
            if "keyword_hit" not in signals:
                signals.append("keyword_hit")
    keyword_hits = keyword_hits[:5]

    # 5. Reflection detection — look for safe canary pattern
    #    (canary format: bselite-probe-XXXXXXXX)
    canary_pat = re.compile(r"bselite-probe-[a-f0-9]{8}")
    reflection_detected = bool(canary_pat.search(probe_body))
    if reflection_detected:
        # Check if it's in an interesting HTML/JS context
        m = canary_pat.search(probe_body)
        if m:
            ctx = probe_body[max(0, m.start()-30):m.end()+30].lower()
            if any(tag in ctx for tag in ["value=", "href=", "src=", "action=",
                                           "ng-", "v-model", "data-"]):
                signals.append("canary_in_context")
            else:
                signals.append("canary_reflected")
    elif "reflection_only" not in signals and length_delta == 0 and not status_changed:
        # No signal at all
        pass

    # 6. Generic error page check (penalty signal)
    generic_404 = any(t in p_lower for t in ["404 not found", "page not found",
                                               "not exist", "does not exist"])
    if generic_404 and any(t in b_lower for t in ["404", "not found"]):
        signals.append("generic_error_page")

    # Build summary
    summary_parts = []
    if status_changed:
        summary_parts.append(f"status {baseline_status}→{probe_status}")
    if length_delta:
        summary_parts.append(f"length_delta={length_delta}")
    if header_delta:
        summary_parts.append(f"headers_changed=[{','.join(header_delta[:3])}]")
    if keyword_hits:
        summary_parts.append(f"keywords=[{','.join(keyword_hits[:2])}]")
    if reflection_detected:
        summary_parts.append("canary_reflected")
    if not summary_parts:
        summary_parts.append("no_significant_diff")

    return {
        "status_changed":      status_changed,
        "length_delta":        length_delta,
        "header_delta":        header_delta,
        "keyword_hits":        keyword_hits,
        "reflection_detected": reflection_detected,
        "signals":             list(dict.fromkeys(signals)),  # deduplicate, preserve order
        "summary":             "; ".join(summary_parts),
    }


def build_evidence_quality_report(
    finding: Dict,
    diff:    Dict,
    conf_breakdown: Dict,
    validation_type: str,
) -> Dict:
    """
    TASK 8 — Build analyst-ready evidence quality report.

    NEVER includes: payloads, tokens, secrets, exploit chains.
    ALWAYS includes: validation reason, safe evidence, confidence explanation,
                     affected path only, remediation guidance.
    """
    url_safe = finding.get("url", "").split("?")[0][:200]
    bug_type = finding.get("bug", finding.get("type", "unknown")).lower()

    # Remediation snippets per bug type (safe, educational)
    _REMEDIATION = {
        "xss":         "Encode all user-controlled output. Implement a strict Content-Security-Policy.",
        "sqli":        "Use parameterized queries / prepared statements. Never concatenate user input into SQL.",
        "ssrf":        "Validate and allowlist outbound request targets. Reject internal IP ranges.",
        "lfi":         "Sanitize file path inputs. Use realpath() validation against allowed directories.",
        "rce":         "Never pass user input to shell commands. Use array-form subprocess invocation.",
        "ssti":        "Disable dangerous template engine features. Sandbox template execution.",
        "redirect":    "Validate redirect targets against an allowlist. Reject arbitrary destinations.",
        "cors":        "Set Access-Control-Allow-Origin to specific trusted origins only.",
        "cache_poison":"Add Vary headers for unkeyed inputs. Strip unrecognized forwarding headers.",
        "idor":        "Enforce ownership checks server-side on every resource access.",
        "xxe":         "Disable external entity processing in XML parser configuration.",
        "default":     "Apply input validation and least-privilege principles.",
    }
    remediation = _REMEDIATION.get(bug_type, _REMEDIATION["default"])

    # Confidence explanation
    conf_total = conf_breakdown.get("total_confidence", 0)
    n_signals  = conf_breakdown.get("signal_count", 0)
    consensus  = conf_breakdown.get("consensus_reached", False)
    conf_explain = (
        f"Confidence {conf_total}% based on {n_signals} independent signal type(s). "
        + ("Multi-signal consensus reached. " if consensus else "Single-signal — lower confidence. ")
        + f"Signals: {list(conf_breakdown.get('breakdown', {}).keys())[:4]}"
    )

    return {
        "affected_path":       url_safe,
        "bug_type":            bug_type,
        "validation_type":     validation_type,
        "validation_reason":   f"{validation_type} probe — {diff.get('summary', 'no diff')}",
        "safe_evidence": {
            "status_changed":      diff.get("status_changed", False),
            "length_delta":        diff.get("length_delta", 0),
            "header_delta":        diff.get("header_delta", []),
            "keyword_hits":        diff.get("keyword_hits", []),
            "reflection_detected": diff.get("reflection_detected", False),
            "payload_redacted":    True,   # ALWAYS True
        },
        "confidence_explanation": conf_explain,
        "confidence_breakdown":   conf_breakdown.get("breakdown", {}),
        "remediation_guidance":   remediation,
        "manual_review_required": True,   # ALWAYS True
        "analyst_notes": (
            "This is an automated signal detection result only. "
            "All evidence was gathered using safe, non-destructive probes. "
            "Human analyst review is required before any disclosure or report submission."
        ),
    }
