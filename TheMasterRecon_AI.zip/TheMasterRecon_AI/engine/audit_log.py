"""
BugScan ELITE — Compliance Audit Log (SOC2 Type II / ISO 27001)

Append-only immutable audit trail.
Every significant action: who, what, when, from where, result.
No UPDATE or DELETE ever runs on audit_events.
"""

import hashlib, json, logging, os, secrets, sqlite3, time, threading
from typing import Dict, List, Optional

log = logging.getLogger("elite.audit")

_DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "..", "data", "audit.db")
_conn: Optional[sqlite3.Connection] = None
_lock = threading.Lock()

CATEGORY_AUTH       = "auth"
CATEGORY_SCAN       = "scan"
CATEGORY_FINDING    = "finding"
CATEGORY_PROGRAM    = "program"
CATEGORY_ORG        = "org"
CATEGORY_USER       = "user"
CATEGORY_API_KEY    = "api_key"
CATEGORY_EXPORT     = "export"
CATEGORY_REPORT     = "report"
CATEGORY_SYSTEM     = "system"
CATEGORY_VALIDATION = "validation"
SEV_INFO     = "info"
SEV_NOTICE   = "notice"
SEV_WARNING  = "warning"
SEV_CRITICAL = "critical"


def _db() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        os.makedirs(os.path.dirname(_DB_PATH), exist_ok=True)
        _conn = sqlite3.connect(_DB_PATH, timeout=15, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA journal_mode=WAL")
        _conn.execute("""CREATE TABLE IF NOT EXISTS audit_events (
            id             TEXT PRIMARY KEY,
            ts             REAL NOT NULL,
            ts_human       TEXT NOT NULL,
            org_id         TEXT DEFAULT '',
            user_id        TEXT DEFAULT '',
            username       TEXT DEFAULT '',
            ip             TEXT DEFAULT '',
            session_id     TEXT DEFAULT '',
            api_key_prefix TEXT DEFAULT '',
            action         TEXT NOT NULL,
            category       TEXT NOT NULL,
            resource_type  TEXT DEFAULT '',
            resource_id    TEXT DEFAULT '',
            resource_name  TEXT DEFAULT '',
            result         TEXT DEFAULT 'success',
            error_msg      TEXT DEFAULT '',
            details        TEXT DEFAULT '{}',
            request_id     TEXT DEFAULT '',
            severity       TEXT DEFAULT 'info'
        )""")
        for idx in [
            "CREATE INDEX IF NOT EXISTS idx_audit_ts   ON audit_events(ts)",
            "CREATE INDEX IF NOT EXISTS idx_audit_org  ON audit_events(org_id)",
            "CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_events(user_id)",
            "CREATE INDEX IF NOT EXISTS idx_audit_act  ON audit_events(action)",
        ]:
            _conn.execute(idx)
        _conn.commit()
    return _conn


def log_event(action: str, category: str = CATEGORY_SYSTEM,
              org_id: str = "", user_id: str = "", username: str = "",
              ip: str = "", session_id: str = "", api_key_prefix: str = "",
              resource_type: str = "", resource_id: str = "", resource_name: str = "",
              result: str = "success", error_msg: str = "",
              details: Dict = None, severity: str = SEV_INFO,
              request_id: str = "") -> str:
    now  = time.time()
    eid  = secrets.token_hex(8)
    ts_h = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(now))
    with _lock:
        _db().execute("""INSERT INTO audit_events
            (id,ts,ts_human,org_id,user_id,username,ip,session_id,api_key_prefix,
             action,category,resource_type,resource_id,resource_name,
             result,error_msg,details,request_id,severity)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (eid, now, ts_h,
             (org_id or "")[:100], (user_id or "")[:100], (username or "")[:100],
             (ip or "")[:45], (session_id or "")[:100], (api_key_prefix or "")[:20],
             action[:100], category[:50],
             (resource_type or "")[:50], (resource_id or "")[:100], (resource_name or "")[:200],
             result[:20], (error_msg or "")[:500],
             json.dumps(details or {})[:2000],
             (request_id or "")[:64], severity[:20]))
        _db().commit()
    if severity in (SEV_WARNING, SEV_CRITICAL):
        log.warning(f"[audit] {action} user={username} result={result}")
    return eid


def audit(action: str, category: str = CATEGORY_SYSTEM,
          resource_type: str = "", resource_id: str = "", resource_name: str = "",
          result: str = "success", error_msg: str = "",
          details: Dict = None, severity: str = SEV_INFO) -> str:
    """Auto-extract Flask request context and log event."""
    ctx = {}
    try:
        from flask import request as _req
        ip = (_req.headers.get("X-Forwarded-For","").split(",")[0].strip()
              or _req.remote_addr or "")
        tok = (_req.headers.get("Authorization","").replace("Bearer","").strip()
               or _req.args.get("token",""))
        ctx = {"ip": ip, "session_id": tok[:20]}
        # Try to get user from RBAC
        try:
            from engine.rbac import get_session
            sess = get_session(tok) if tok else None
            if sess:
                ctx["user_id"]  = sess.get("user_id","")
                ctx["username"] = sess.get("username","")
        except Exception: pass
    except Exception: pass
    return log_event(action=action, category=category,
                     resource_type=resource_type, resource_id=resource_id,
                     resource_name=resource_name, result=result,
                     error_msg=error_msg, details=details or {},
                     severity=severity, **ctx)


# Legacy compatibility — old code calls log_action()
def log_action(action: str, user: str = "system", domain: str = "",
               details: dict = None, result: str = "success",
               ip: str = "", severity: str = "info") -> str:
    return log_event(action=action, username=user, resource_type="domain",
                     resource_id=domain, result=result, ip=ip,
                     details=details or {}, severity=severity,
                     category=CATEGORY_SCAN if domain else CATEGORY_SYSTEM)


def query_events(org_id: str = "", user_id: str = "", action: str = "",
                 category: str = "", result: str = "",
                 since_ts: float = 0, until_ts: float = 0,
                 limit: int = 100, offset: int = 0) -> List[Dict]:
    q = "SELECT * FROM audit_events WHERE 1=1"
    params = []
    if org_id:   q += " AND org_id=?";   params.append(org_id)
    if user_id:  q += " AND user_id=?";  params.append(user_id)
    if action:   q += " AND action=?";   params.append(action)
    if category: q += " AND category=?"; params.append(category)
    if result:   q += " AND result=?";   params.append(result)
    if since_ts: q += " AND ts>=?";      params.append(since_ts)
    if until_ts: q += " AND ts<=?";      params.append(until_ts)
    q += " ORDER BY ts DESC LIMIT ? OFFSET ?"
    params += [min(limit, 1000), offset]
    rows = _db().execute(q, params).fetchall()
    out = []
    for row in rows:
        d = dict(row)
        try: d["details"] = json.loads(d.get("details","{}") or "{}")
        except: pass
        out.append(d)
    return out


def get_logs(days: int = 7, user: str = None, action: str = None,
             limit: int = 200) -> List[Dict]:
    """Legacy-compatible wrapper."""
    since = time.time() - (days * 86400)
    return query_events(user_id=user or "", action=action or "",
                        since_ts=since, limit=limit)


def get_stats(days: int = 30, org_id: str = "") -> Dict:
    since = time.time() - (days * 86400)
    base  = "FROM audit_events WHERE ts>=?"
    p     = [since]
    if org_id:
        base += " AND org_id=?"; p.append(org_id)
    total  = _db().execute(f"SELECT COUNT(*) {base}", p).fetchone()[0]
    failed = _db().execute(f"SELECT COUNT(*) {base} AND result='failure'", p).fetchone()[0]
    top_a  = _db().execute(
        f"SELECT action, COUNT(*) n {base} GROUP BY action ORDER BY n DESC LIMIT 10", p).fetchall()
    top_u  = _db().execute(
        f"SELECT username, COUNT(*) n {base} AND username!='' GROUP BY username ORDER BY n DESC LIMIT 10", p).fetchall()
    return {
        "period_days":   days,
        "total_events":  total,
        "failure_count": failed,
        "failure_rate":  round(failed/total*100, 1) if total else 0,
        "top_actions":   [{"action": r[0], "count": r[1]} for r in top_a],
        "top_users":     [{"username": r[0], "count": r[1]} for r in top_u],
    }


def verify_integrity(days: int = 1) -> dict:
    """Legacy compatibility stub."""
    return {"ok": True, "events_checked": 0, "note": "SQLite WAL mode — append only"}
