"""
TheMasterRecon AI — Natural Language Query Engine
"Show me critical XSS on subdomains with login"
"Which findings have no patch?"
"Group by severity, only last 7 days"
"""
import re, json, os, logging, ssl, urllib.request, time
from typing import List, Dict, Optional
from datetime import datetime, timedelta

log = logging.getLogger("elite.nl_query")
API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL   = "claude-sonnet-4-5"


def _claude(prompt: str, max_tokens: int = 500) -> str:
    if not API_KEY:
        return "{}"
    try:
        body = json.dumps({"model": MODEL, "max_tokens": max_tokens,
            "system": "You are a JSON query builder. Output only valid JSON, no explanation.",
            "messages": [{"role": "user", "content": prompt}]}).encode()
        ctx = ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request("https://api.anthropic.com/v1/messages",
            data=body, method="POST",
            headers={"x-api-key": API_KEY, "anthropic-version": "2023-06-01",
                     "content-type": "application/json"})
        with urllib.request.urlopen(req, timeout=30, context=ctx) as r:
            d = json.loads(r.read())
            for block in d.get("content", []):
                if block.get("type") == "text":
                    return block["text"].strip()
    except Exception as e:
        log.warning(f"nl_query claude: {e}")
    return "{}"


def nl_to_filter(query: str, findings: List[Dict]) -> Dict:
    """
    Convert natural language query to a filter spec using Claude,
    then apply it to the findings list.
    Returns {"results": [...], "filter_spec": {...}, "explanation": "..."}
    """
    # Build schema description for Claude
    sample = findings[:3] if findings else []
    sample_keys = set()
    for f in sample:
        sample_keys.update(f.keys())

    prompt = f"""User query: "{query}"

Available finding fields: {sorted(sample_keys) if sample_keys else ['bug', 'severity', 'url', 'title', 'confidence', 'ts', 'poc', 'param']}
Severity values: critical, high, medium, low
Bug type examples: xss, sqli, ssrf, lfi, idor, cors, jwt, rce, ssti, xxe, misconfig, expose, takeover

Translate the query into a JSON filter spec:
{{
  "severity": ["critical","high"],   // list or null for any
  "bug_types": ["xss","sqli"],       // list or null for any  
  "url_contains": "admin",           // string or null
  "title_contains": null,            // string or null
  "min_confidence": 80,              // 0-100 or null
  "days_ago": 7,                     // integer or null
  "has_poc": null,                   // true/false/null
  "sort_by": "severity",             // severity/confidence/url/ts
  "sort_desc": true,
  "limit": null,                     // integer or null
  "explanation": "showing critical and high XSS findings from last 7 days"
}}

Respond with ONLY the JSON object."""

    raw = _claude(prompt, max_tokens=300)
    # Extract JSON
    m = re.search(r'\{.*\}', raw, re.DOTALL)
    try:
        spec = json.loads(m.group() if m else raw)
    except Exception:
        spec = {"explanation": "Could not parse query — showing all findings"}

    results = apply_filter(findings, spec)
    return {
        "results":      results,
        "filter_spec":  spec,
        "explanation":  spec.get("explanation", ""),
        "count":        len(results),
        "total":        len(findings),
    }


def apply_filter(findings: List[Dict], spec: Dict) -> List[Dict]:
    """Apply a filter spec dict to a findings list."""
    results = list(findings)

    sev_order = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}

    # Severity filter
    if spec.get("severity"):
        sevs = [s.lower() for s in spec["severity"]]
        results = [f for f in results if (f.get("severity","").lower() in sevs)]

    # Bug type filter
    if spec.get("bug_types"):
        types = [t.lower() for t in spec["bug_types"]]
        results = [f for f in results
                   if any(t in (f.get("bug","") + f.get("type","")).lower() for t in types)]

    # URL contains
    if spec.get("url_contains"):
        q = spec["url_contains"].lower()
        results = [f for f in results if q in (f.get("url","") + f.get("endpoint","")).lower()]

    # Title contains
    if spec.get("title_contains"):
        q = spec["title_contains"].lower()
        results = [f for f in results if q in f.get("title","").lower()]

    # Min confidence
    if spec.get("min_confidence") is not None:
        mc = int(spec["min_confidence"])
        results = [f for f in results if int(f.get("confidence", 50)) >= mc]

    # Has PoC
    if spec.get("has_poc") is True:
        results = [f for f in results if f.get("poc","").strip()]
    elif spec.get("has_poc") is False:
        results = [f for f in results if not f.get("poc","").strip()]

    # Days ago
    if spec.get("days_ago"):
        cutoff = (datetime.utcnow() - timedelta(days=int(spec["days_ago"]))).isoformat()
        results = [f for f in results if (f.get("ts","") or f.get("created_at","")) >= cutoff]

    # Sort
    sort_key = spec.get("sort_by", "severity")
    desc     = spec.get("sort_desc", True)
    if sort_key == "severity":
        results.sort(key=lambda f: sev_order.get(f.get("severity","").lower(), 0), reverse=desc)
    elif sort_key == "confidence":
        results.sort(key=lambda f: int(f.get("confidence",50)), reverse=desc)
    elif sort_key == "ts":
        results.sort(key=lambda f: f.get("ts",""), reverse=desc)
    else:
        results.sort(key=lambda f: str(f.get(sort_key,"")), reverse=desc)

    # Limit
    if spec.get("limit"):
        results = results[:int(spec["limit"])]

    return results


def quick_filter(query: str, findings: List[Dict]) -> List[Dict]:
    """
    Fast regex-based filter (no Claude needed for simple queries).
    Handles: 'critical', 'xss high', 'admin url', 'has poc', etc.
    Falls back to Claude for complex queries.
    """
    q = query.lower().strip()

    # Simple severity-only
    if q in ("critical","high","medium","low","info"):
        return [f for f in findings if f.get("severity","").lower() == q]

    # Severity + bug type
    sev_order = {"critical":4,"high":3,"medium":2,"low":1}
    severities = [s for s in sev_order if s in q]
    bug_words  = [w for w in q.split() if w not in sev_order and len(w) > 2]

    results = findings
    if severities:
        results = [f for f in results if f.get("severity","").lower() in severities]
    if bug_words:
        results = [f for f in results if any(
            bw in (f.get("bug","") + f.get("title","") + f.get("url","")).lower()
            for bw in bug_words)]

    # Special keywords
    if "poc" in q or "exploit" in q:
        results = [f for f in results if f.get("poc","").strip()]
    if "no fix" in q or "unpatched" in q:
        results = [f for f in results if not f.get("remediation","").strip()]

    return results
