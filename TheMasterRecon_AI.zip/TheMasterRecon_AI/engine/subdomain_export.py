"""
engine/subdomain_export.py — Subdomain export system.

Writes categorized subdomain files to data/exports/<domain>/.
Reads from DB when in-memory vars are unavailable (e.g. called from API routes).
Does NOT touch endpoint export.
"""

import json
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional

log = logging.getLogger("elite.subdomain_export")

# Score rules — same as recon.py _score_sub
_SCORE_RULES = [
    (10, ["payment","billing","checkout","stripe","pay","invoice"]),
    (9,  ["api","graphql","rest","grpc","rpc"]),
    (9,  ["admin","administrator","manage","management","cpanel","plesk"]),
    (8,  ["auth","login","sso","oauth","saml","oidc","idp","identity"]),
    (8,  ["vpn","internal","corp","intranet","private"]),
    (7,  ["dev","develop","developer","staging","stage","preprod","pre-prod","qa","test"]),
    (7,  ["dashboard","portal","panel","console"]),
    (6,  ["upload","files","file","cdn","assets","media","storage","s3"]),
    (5,  ["mail","smtp","mx","email","webmail","imap"]),
    (4,  ["app","web","service","srv","svc"]),
    (3,  ["www","www2","www3"]),
]


def _score(host: str) -> int:
    prefix = host.lower().split(".")[0]
    for score, kws in _SCORE_RULES:
        if any(k in prefix for k in kws if k):
            return score
    return 1


def _load_subs_from_db(domain: str, db) -> List[str]:
    """Try every known DB method to get subdomains. Never crashes."""
    for method in ("get_subs", "get_subdomains", "list_subdomains"):
        fn = getattr(db, method, None)
        if fn:
            try:
                result = fn(domain)
                if result:
                    return [s if isinstance(s, str) else s.get("subdomain", s.get("host", ""))
                            for s in result]
            except Exception:
                pass

    # Direct SQLite fallback
    try:
        import sqlite3
        conn = sqlite3.connect(db.db_path)
        did = conn.execute("SELECT id FROM domains WHERE domain=?", (domain,)).fetchone()
        if did:
            rows = conn.execute(
                "SELECT subdomain FROM subdomains WHERE domain_id=?", (did[0],)
            ).fetchall()
            conn.close()
            return [r[0] for r in rows if r[0]]
        conn.close()
    except Exception:
        pass
    return []


def _load_live_from_db(domain: str, db) -> List[str]:
    """Load live hosts from DB."""
    try:
        hosts_info = db.get_hosts(domain) or {}
        return hosts_info.get("active", []) or []
    except Exception:
        return []


def export_subdomains(
    domain: str,
    db,
    subs: Optional[List[str]]       = None,
    live_hosts: Optional[List[str]] = None,
    sub_sources: Optional[Dict]     = None,
    sub_scores:  Optional[Dict]     = None,
    reason:      str                = "manual",
) -> Dict:
    """
    Write subdomain export files to data/exports/<domain>/.

    Files written:
      <domain>_subdomains_raw.txt        — all collected (may include dupes)
      <domain>_subdomains_unique.txt     — deduplicated, sorted
      <domain>_subdomains_resolved.txt   — resolved/live hosts
      <domain>_subdomains_live.txt       — live HTTP hosts (from httpx)
      <domain>_subdomains_scored.txt     — sorted by score desc, one per line: score\thost
      <domain>_subdomains_by_source.json — {source: [hosts...]}

    Returns dict with counts.
    Logs: [subdomain-export] autosave domain=X subs=N live=M reason=... files=6
    """
    # Load from DB if not passed in
    if subs is None:
        subs = _load_subs_from_db(domain, db)
    if live_hosts is None:
        live_hosts = _load_live_from_db(domain, db)

    # Normalise
    subs_raw    = list(subs) if subs else []
    subs_unique = sorted(set(s.strip() for s in subs_raw if s.strip()))
    live_clean  = [h.replace("https://","").replace("http://","").split("/")[0]
                   for h in (live_hosts or [])]
    live_clean  = sorted(set(h for h in live_clean if h))

    # Score
    if sub_scores:
        scored = [(sub_scores.get(h, _score(h)), h) for h in subs_unique]
    else:
        scored = [(_score(h), h) for h in subs_unique]
    scored.sort(key=lambda x: -x[0])

    # Out dir
    out_dir = Path("data") / "exports" / domain
    out_dir.mkdir(parents=True, exist_ok=True)

    files_written = 0

    def _write(name: str, lines: List[str]) -> None:
        nonlocal files_written
        (out_dir / name).write_text("\n".join(lines) + ("\n" if lines else ""))
        files_written += 1

    _write(f"{domain}_subdomains_raw.txt",      subs_raw)
    _write(f"{domain}_subdomains_unique.txt",   subs_unique)
    _write(f"{domain}_subdomains_resolved.txt", live_clean)
    _write(f"{domain}_subdomains_live.txt",     live_clean)
    _write(f"{domain}_subdomains_scored.txt",
           [f"{score}\t{host}" for score, host in scored])

    # By-source JSON
    by_source: Dict = {}
    if sub_sources:
        by_source = {src: list(hosts) for src, hosts in sub_sources.items()}
    (out_dir / f"{domain}_subdomains_by_source.json").write_text(
        json.dumps(by_source, indent=2)
    )
    files_written += 1

    log.info(
        f"[subdomain-export] autosave domain={domain}"
        f" subs={len(subs_unique)}"
        f" live={len(live_clean)}"
        f" reason={reason}"
        f" files={files_written}"
    )

    return {
        "ok":               True,
        "domain":           domain,
        "total_subdomains": len(subs_unique),
        "raw_count":        len(subs_raw),
        "live_hosts":       len(live_clean),
        "files_written":    files_written,
        "out_dir":          str(out_dir),
        "reason":           reason,
        "timestamp":        int(time.time()),
    }
