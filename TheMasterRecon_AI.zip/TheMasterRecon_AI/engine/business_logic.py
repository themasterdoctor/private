"""
BugScan ELITE — Business Logic Vulnerability Engine
Tests for:
- Price/amount manipulation (negative quantities, zero prices)
- Workflow step skipping (checkout bypass, 2FA bypass)
- Mass assignment (hidden fields, extra JSON params)
- IDOR depth (UUID prediction, sequential ID enumeration)
- Privilege escalation via parameter tampering
- Insecure direct function references
"""
import re, time, logging, json, urllib.parse, urllib.request, ssl
import threading
from typing import List, Dict, Optional

log = logging.getLogger("elite.bizlogic")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _req(url, method="GET", headers=None, data=None, timeout=8, cookies=""):
    try:
        h = {"User-Agent":"Mozilla/5.0","Accept":"*/*,application/json"}
        if cookies: h["Cookie"] = cookies
        if headers: h.update(headers)
        body = data.encode() if isinstance(data,str) else data
        req  = urllib.request.Request(url, data=body, headers=h, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            return r.status, dict(r.headers), r.read(32768).decode("utf-8","ignore")
    except urllib.error.HTTPError as e:
        try: return e.code, dict(e.headers), e.read(4096).decode("utf-8","ignore")
        except: return e.code, {}, ""
    except: return None

def _post_json(url, data, cookies=""):
    return _req(url, "POST",
                headers={"Content-Type":"application/json"},
                data=json.dumps(data), cookies=cookies)

def _F(url, name, sev, details):
    return {
        "type":"business_logic","bug":"idor","severity":sev,
        "url":url,"name":name,"details":details,
        "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def check_price_manipulation(targets: List[str], endpoints: List[str],
                              cookies: str = "") -> List[Dict]:
    """Test price/quantity manipulation in checkout flows."""
    findings = []

    price_paths = [
        "/cart/add", "/cart/update", "/basket/add", "/shop/add-to-cart",
        "/api/cart", "/api/basket", "/api/order", "/api/checkout",
        "/checkout", "/order/create", "/purchase",
    ]

    for target in targets[:20]:
        base = target.rstrip("/")
        for path in price_paths:
            url = base + path

            # Test 1: Negative price
            for price_field in ["price","amount","cost","total","subtotal"]:
                r = _post_json(url, {
                    "item_id": 1, "quantity": 1,
                    price_field: -99.99,
                    "product_id": 1,
                }, cookies=cookies)
                if r and r[0] in (200,201):
                    body = r[2].lower()
                    if any(w in body for w in ["success","added","ok","cart","order"]):
                        findings.append(_F(url,
                            f"Negative Price Accepted ({price_field}=-99.99)", "critical", {
                            "description": f"Negative price value accepted in {price_field} field — may credit attacker's account.",
                            "poc": f'curl -X POST {url} -H "Content-Type: application/json" -d \'{{"item_id":1,"{price_field}":-99.99}}\'',
                            "impact": "Purchase items at negative prices, potentially getting store credit.",
                            "remediation": "Validate all price/amount fields server-side. Never trust client-submitted prices.",
                        }))

            # Test 2: Zero price
            r = _post_json(url, {"item_id":1,"quantity":1,"price":0.00}, cookies=cookies)
            if r and r[0] in (200,201) and "success" in r[2].lower():
                findings.append(_F(url, "Zero Price Accepted", "high", {
                    "description": "Items accepted at price=0.00",
                    "poc": f'curl -X POST {url} -d \'{{"item_id":1,"price":0.00}}\'',
                    "impact": "Purchase items for free by setting price to zero.",
                    "remediation": "Server must look up prices from database, never accept client-submitted prices.",
                }))

            # Test 3: Integer overflow
            r = _post_json(url, {"quantity": 9999999999, "item_id":1}, cookies=cookies)
            if r and r[0] in (200,201):
                body = r[2].lower()
                if "error" not in body and "invalid" not in body:
                    findings.append(_F(url, "Integer Overflow in Quantity", "medium", {
                        "description": "Extremely large quantity accepted without validation.",
                        "poc": f'curl -X POST {url} -d \'{{"quantity":9999999999}}\'',
                        "impact": "Integer overflow may cause price to wrap to negative or zero.",
                        "remediation": "Validate quantity ranges. Use safe integer arithmetic.",
                    }))

    return findings


def check_mass_assignment(targets: List[str], endpoints: List[str],
                           cookies: str = "") -> List[Dict]:
    """Test for mass assignment / parameter pollution vulnerabilities."""
    findings = []

    # Privileged fields attackers would want to inject
    priv_fields = [
        {"role": "admin"},
        {"is_admin": True},
        {"admin": True},
        {"is_superuser": True},
        {"privilege": "admin"},
        {"account_type": "premium"},
        {"subscription": "enterprise"},
        {"credits": 99999},
        {"balance": 99999},
        {"verified": True},
        {"email_verified": True},
        {"approved": True},
    ]

    # Find profile update / registration endpoints
    mass_paths = [
        "/profile/update", "/account/update", "/user/update",
        "/api/user", "/api/profile", "/api/account",
        "/register", "/signup", "/api/register",
        "/settings", "/api/settings",
    ]

    for target in targets[:20]:
        base = target.rstrip("/")
        for path in mass_paths:
            url = base + path

            # Get baseline (what fields are accepted)
            baseline = _req(url, cookies=cookies)
            if not baseline or baseline[0] in (404,): continue

            for priv_data in priv_fields[:5]:
                # Send update with privileged field
                r = _post_json(url, {
                    "name": "testuser",
                    "email": "test@test.com",
                    **priv_data
                }, cookies=cookies)
                if not r: continue

                if r[0] in (200,201):
                    # Check if field was accepted
                    field  = list(priv_data.keys())[0]
                    value  = priv_data[field]
                    # Verify by fetching profile
                    check = _req(base + "/api/user", cookies=cookies) or \
                            _req(base + "/api/profile", cookies=cookies) or \
                            _req(base + "/profile", cookies=cookies)
                    if check and str(value).lower() in check[2].lower():
                        findings.append(_F(url,
                            f"Mass Assignment: '{field}' accepted", "critical", {
                            "description": f"The field '{field}={value}' was accepted and reflected in profile, indicating mass assignment vulnerability.",
                            "field": field, "value": str(value),
                            "poc": f'curl -X POST {url} -H "Content-Type: application/json" -d \'{json.dumps({"name":"test","email":"a@b.com",**priv_data})}\'',
                            "impact": f"Attacker can set {field}={value} to escalate privileges or gain unauthorized features.",
                            "remediation": "Use explicit allowlists for accepted fields. Never use mass-assignment patterns like Model.create(params).",
                        }))

    return findings


def check_workflow_bypass(targets: List[str], endpoints: List[str],
                           cookies: str = "") -> List[Dict]:
    """Test for workflow step-skipping vulnerabilities."""
    findings = []

    # Checkout flow bypass
    checkout_sequences = [
        ["/cart", "/checkout", "/payment", "/order/confirm"],
        ["/basket", "/checkout/shipping", "/checkout/payment", "/checkout/complete"],
        ["/shop/cart", "/shop/checkout", "/shop/payment", "/shop/success"],
    ]

    for target in targets[:20]:
        base = target.rstrip("/")
        for flow in checkout_sequences:
            # Try to skip directly to final step
            last_step = base + flow[-1]
            r = _req(last_step, cookies=cookies)
            if not r: continue

            if r[0] == 200:
                body = r[2].lower()
                if any(w in body for w in ["order","confirm","success","complete","thank you"]):
                    findings.append(_F(last_step,
                        "Checkout Workflow Step Bypass", "high", {
                        "description": f"Able to access final checkout step {flow[-1]} without completing previous steps.",
                        "poc": f"curl '{last_step}'  # Skip directly to order confirmation",
                        "impact": "Complete purchases without proper authorization or payment verification.",
                        "remediation": "Implement server-side workflow state tracking. Validate each step server-side before allowing progression.",
                    }))
                    break

    # 2FA bypass — access protected pages after login but before 2FA
    twofa_paths = [
        "/api/user/profile", "/dashboard", "/account",
        "/api/transactions", "/admin",
    ]

    return findings


def check_idor_depth(targets: List[str], endpoints: List[str],
                     cookies: str = "") -> List[Dict]:
    """Deep IDOR testing: UUID analysis, sequential IDs, parameter manipulation."""
    findings = []

    # Find endpoints with IDs in path
    id_pattern = re.compile(
        r'/(\d{1,10}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})'
        r'(?:/|$|\?)',
        re.I
    )

    tested = set()
    for ep in endpoints[:300]:
        m = id_pattern.search(ep)
        if not m: continue

        orig_id = m.group(1)
        base_ep = ep[:m.start(1)]
        key = base_ep

        if key in tested: continue
        tested.add(key)

        # Get baseline
        r_orig = _req(ep, cookies=cookies)
        if not r_orig or r_orig[0] != 200: continue

        baseline_len = len(r_orig[2])

        # Test IDs around the original
        is_numeric = orig_id.isdigit()
        is_uuid    = len(orig_id) == 36 and "-" in orig_id

        if is_numeric:
            test_ids = [
                str(int(orig_id) - 1),
                str(int(orig_id) + 1),
                str(int(orig_id) - 100),
                "1", "2", "3", "0",
            ]
        elif is_uuid:
            # Try predictable UUIDs
            test_ids = [
                "00000000-0000-0000-0000-000000000001",
                "00000000-0000-0000-0000-000000000002",
                orig_id[:-4] + "0001",
                orig_id[:-4] + "0002",
            ]
        else:
            continue

        for test_id in test_ids:
            test_url = ep[:m.start(1)] + test_id + ep[m.end(1):]
            if test_url == ep: continue

            r_test = _req(test_url, cookies=cookies)
            if not r_test: continue

            if r_test[0] == 200 and abs(len(r_test[2]) - baseline_len) > 100:
                # Different user's data returned
                if not _is_same_user_data(r_orig[2], r_test[2]):
                    findings.append(_F(test_url,
                        f"IDOR: Access to Other User's Data (ID={test_id})", "high", {
                        "description": f"Replacing ID '{orig_id}' with '{test_id}' returns different user's data.",
                        "original_url":  ep,
                        "exploit_url":   test_url,
                        "original_id":   orig_id,
                        "test_id":       test_id,
                        "response_size": len(r_test[2]),
                        "poc": f"curl '{test_url}'",
                        "impact": "Unauthorized access to other users' data — account info, orders, messages, files.",
                        "remediation": "Enforce object-level authorization on every endpoint. Verify the requesting user owns the requested resource.",
                    }))

    return findings


def _is_same_user_data(body1: str, body2: str) -> bool:
    """Heuristic: are two responses likely the same user's data?"""
    # Extract emails, usernames, IDs from both
    emails1 = set(re.findall(r'[\w.+-]+@[\w-]+\.\w+', body1))
    emails2 = set(re.findall(r'[\w.+-]+@[\w-]+\.\w+', body2))
    if emails1 and emails2 and emails1 != emails2:
        return False
    if body1[:200] == body2[:200]:
        return True
    return len(set(body1.split()) & set(body2.split())) / max(len(set(body1.split())),1) > 0.8


def check_business_logic(targets: List[str], endpoints: List[str],
                         cookies: str = "") -> List[Dict]:
    """Run all business logic checks."""
    findings = []
    findings.extend(check_price_manipulation(targets, endpoints, cookies))
    findings.extend(check_mass_assignment(targets, endpoints, cookies))
    findings.extend(check_workflow_bypass(targets, endpoints, cookies))
    findings.extend(check_idor_depth(targets, endpoints, cookies))
    log.info(f"[bizlogic] {len(findings)} findings")
    return findings
