"""
TheMasterRecon AI — HTTP Intercepting Proxy (Burp-style)
Transparent HTTP/HTTPS proxy that captures, logs, and optionally
intercepts requests for modification before forwarding.
"""
import socket, ssl, threading, time, logging, re, json, gzip
import urllib.parse, secrets, queue, base64
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Optional, List, Dict

log = logging.getLogger("elite.proxy")

DATA_DIR    = Path("./data/_proxy")
HISTORY_FILE = DATA_DIR / "history.json"
INTERCEPT_Q  = queue.Queue(maxsize=50)  # Intercepted requests pending approval

_proxy_running   = False
_proxy_server    = None
_intercept_mode  = False
_history         = []
_history_lock    = threading.Lock()
_max_history     = 1000


def _load_history() -> list:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if HISTORY_FILE.exists():
        try:
            return json.loads(HISTORY_FILE.read_text())[-_max_history:]
        except Exception:
            pass
    return []

def _save_history():
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        HISTORY_FILE.write_text(json.dumps(_history[-_max_history:], indent=2))
    except Exception:
        pass

def _log_request(entry: dict):
    with _history_lock:
        _history.append(entry)
        if len(_history) > _max_history:
            _history.pop(0)
    _save_history()


class ProxyHandler(BaseHTTPRequestHandler):
    """Handles incoming proxy connections."""

    def log_message(self, *args): pass

    def _send_error(self, code: int, msg: str):
        self.send_response(code)
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(msg.encode())

    def _forward_request(self, method: str, url: str, headers: dict,
                         body: bytes) -> tuple:
        """Forward request to target and return (status, resp_headers, body)."""
        import urllib.request
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE

        req = urllib.request.Request(url, data=body or None, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=20, context=ctx) as r:
                resp_body = r.read()
                return r.status, dict(r.headers), resp_body
        except urllib.error.HTTPError as e:
            try:
                body = e.read()
            except Exception:
                body = b""
            return e.code, dict(e.headers), body
        except Exception as e:
            return 502, {}, f"Proxy error: {e}".encode()

    def do_CONNECT(self):
        """Handle HTTPS CONNECT tunneling."""
        host, _, port = self.path.partition(":")
        port = int(port or 443)
        try:
            remote = socket.create_connection((host, port), timeout=10)
            self.send_response(200, "Connection Established")
            self.end_headers()
            # Simple tunnel — just pipe data
            def pipe(src, dst):
                try:
                    while True:
                        data = src.recv(8192)
                        if not data: break
                        dst.sendall(data)
                except Exception: pass
                finally:
                    try: dst.close()
                    except: pass
            t1 = threading.Thread(target=pipe, args=(self.connection, remote), daemon=True)
            t2 = threading.Thread(target=pipe, args=(remote, self.connection), daemon=True)
            t1.start(); t2.start()
            t1.join(); t2.join()
        except Exception as e:
            self._send_error(502, f"CONNECT failed: {e}")

    def _handle(self):
        method  = self.command
        url     = self.path
        if not url.startswith("http"):
            url = f"http://{self.headers.get('Host','localhost')}{url}"

        # Read body
        body = b""
        cl = self.headers.get("Content-Length")
        if cl:
            body = self.rfile.read(int(cl))

        # Build headers dict (strip hop-by-hop)
        HOP_BY_HOP = {"connection","keep-alive","proxy-authenticate",
                       "proxy-authorization","te","trailers","transfer-encoding","upgrade"}
        hdrs = {k:v for k,v in self.headers.items()
                if k.lower() not in HOP_BY_HOP}

        start_ts = time.time()

        # Intercept mode: hold the request
        if _intercept_mode:
            req_id  = secrets.token_hex(8)
            pending = {"id":req_id,"method":method,"url":url,
                       "headers":hdrs,"body":body.decode("utf-8","ignore"),
                       "ts":time.strftime("%Y-%m-%dT%H:%M:%SZ")}
            INTERCEPT_Q.put(pending, timeout=5)
            # Wait for release/drop decision (max 60s)
            deadline = time.time() + 60
            while time.time() < deadline:
                if req_id in _released:
                    modified = _released.pop(req_id)
                    method  = modified.get("method", method)
                    url     = modified.get("url",    url)
                    hdrs    = modified.get("headers", hdrs)
                    body    = modified.get("body","").encode()
                    break
                if req_id in _dropped:
                    _dropped.discard(req_id)
                    self._send_error(403, "Request dropped by intercept")
                    return
                time.sleep(0.2)

        # Forward
        status, resp_hdrs, resp_body = self._forward_request(method, url, hdrs, body)
        elapsed = round((time.time()-start_ts)*1000)

        # Decompress if needed
        content_encoding = resp_hdrs.get("Content-Encoding","")
        display_body = resp_body
        if "gzip" in content_encoding:
            try: display_body = gzip.decompress(resp_body)
            except Exception: pass

        # Log entry
        entry = {
            "id":           secrets.token_hex(6),
            "ts":           time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "method":       method,
            "url":          url,
            "host":         urllib.parse.urlparse(url).netloc,
            "status":       status,
            "req_length":   len(body),
            "resp_length":  len(resp_body),
            "elapsed_ms":   elapsed,
            "content_type": resp_hdrs.get("Content-Type",""),
            "req_headers":  dict(hdrs),
            "req_body":     body.decode("utf-8","ignore")[:2000],
            "resp_headers": dict(resp_hdrs),
            "resp_body":    display_body.decode("utf-8","ignore")[:10000],
            "flagged":      False,
            "notes":        "",
        }
        # Auto-flag interesting responses
        body_str = display_body.decode("utf-8","ignore")
        if any(s in body_str for s in ["password","secret","token","api_key","private"]):
            entry["flagged"]   = True
            entry["flag_reason"] = "Sensitive keyword in response"

        _log_request(entry)

        # Send response back to client
        self.send_response(status)
        SKIP_HDRS = {"transfer-encoding","connection","content-encoding"}
        for k,v in resp_hdrs.items():
            if k.lower() not in SKIP_HDRS:
                self.send_header(k, v)
        self.send_header("Content-Length", str(len(resp_body)))
        self.end_headers()
        self.wfile.write(resp_body)

    do_GET     = _handle
    do_POST    = _handle
    do_PUT     = _handle
    do_DELETE  = _handle
    do_PATCH   = _handle
    do_OPTIONS = _handle
    do_HEAD    = _handle


_released: Dict[str, dict] = {}
_dropped:  set = set()


# ── Public API ────────────────────────────────────────────────────────────────
def start_proxy(port: int = 8080) -> bool:
    global _proxy_server, _proxy_running
    if _proxy_running:
        return True
    try:
        _proxy_server = HTTPServer(("0.0.0.0", port), ProxyHandler)
        t = threading.Thread(target=_proxy_server.serve_forever, daemon=True)
        t.start()
        _proxy_running = True
        log.info(f"[proxy] started on port {port}")
        # Load history
        _history.extend(_load_history())
        return True
    except Exception as e:
        log.error(f"[proxy] start failed: {e}")
        return False

def stop_proxy():
    global _proxy_server, _proxy_running
    if _proxy_server:
        _proxy_server.shutdown()
    _proxy_running = False
    log.info("[proxy] stopped")

def get_status() -> dict:
    return {
        "running":         _proxy_running,
        "intercept_mode":  _intercept_mode,
        "history_count":   len(_history),
        "pending_intercept": INTERCEPT_Q.qsize(),
    }

def get_history(limit: int = 100, filter_host: str = "",
                filter_status: str = "", flagged_only: bool = False) -> list:
    with _history_lock:
        h = list(reversed(_history))
    if filter_host:
        h = [e for e in h if filter_host.lower() in e.get("host","").lower()]
    if filter_status:
        h = [e for e in h if str(e.get("status","")).startswith(filter_status)]
    if flagged_only:
        h = [e for e in h if e.get("flagged")]
    return h[:limit]

def clear_history():
    with _history_lock:
        _history.clear()
    _save_history()

def set_intercept(enabled: bool):
    global _intercept_mode
    _intercept_mode = enabled
    log.info(f"[proxy] intercept {'ON' if enabled else 'OFF'}")

def get_intercepted() -> Optional[dict]:
    """Get next intercepted request (non-blocking)."""
    try:
        return INTERCEPT_Q.get_nowait()
    except queue.Empty:
        return None

def release_request(req_id: str, modified: dict = None):
    """Release an intercepted request (optionally with modifications)."""
    _released[req_id] = modified or {}

def drop_request(req_id: str):
    """Drop an intercepted request."""
    _dropped.add(req_id)

def flag_entry(entry_id: str, note: str = ""):
    with _history_lock:
        for e in _history:
            if e.get("id") == entry_id:
                e["flagged"] = True
                e["notes"]   = note
                break
    _save_history()

def search_history(pattern: str, field: str = "resp_body") -> list:
    """Search proxy history with regex."""
    try:
        rx = re.compile(pattern, re.I)
    except re.error:
        rx = re.compile(re.escape(pattern), re.I)
    with _history_lock:
        h = list(_history)
    return [e for e in h if rx.search(str(e.get(field,"")))]
