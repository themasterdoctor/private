"""
BugScan ELITE — Mythos-Style Iterative Exploitation Loop
Inspired by Anthropic Claude Mythos Preview methodology:
  - Scoped context (not full codebase dumps)
  - Iterative multi-step attack sequences
  - Tool-access style prompting
  - Chain escalation reasoning

The real Mythos is a frontier AI model. This replicates its pipeline
using the Claude API with structured exploitation prompting.
"""
import os, json, logging, urllib.request, ssl, time
from typing import Dict, List, Optional

log    = logging.getLogger("elite.mythos_loop")
_KEY   = os.environ.get("ANTHROPIC_API_KEY", "")
_MODEL = "claude-sonnet-4-6"

_SYSTEM = """You are an elite offensive security researcher operating on authorized targets.
Your job: given a finding, reason through multi-step exploitation.

Rules:
- Work ONLY on authorized targets. Never suggest attacking systems without authorization.
- Focus on PROOF and IMPACT, not speculation.
- Every exploitation step must be reproducible with safe, non-destructive payloads.
- Think like XBOW + Hacktron: PoC or it didn't happen.
- Reason step by step. If you can't prove something, say so.

Output format: structured JSON only."""


def _call(prompt: str, max_tokens: int = 1200) -> str:
    if not _KEY:
        return ""
    try:
        body = json.dumps({
            "model":      _MODEL,
            "max_tokens": max_tokens,
            "system":     _SYSTEM,
            "messages":   [{"role": "user", "content": prompt}],
        }).encode()
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=body,
            headers={
                "x-api-key":         _KEY,
                "anthropic-version": "2023-06-01",
                "content-type":      "application/json",
            },
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=60, context=ctx) as r:
            data = json.loads(r.read())
            for block in data.get("content", []):
                if block.get("type") == "text":
                    return block.get("text", "")
    except Exception as e:
        log.debug(f"[mythos_loop] API error: {e}")
    return ""


def _parse_json(text: str) -> Optional[Dict]:
    """Extract JSON from response even if it has markdown fences."""
    import re
    # Try direct parse
    try:
        return json.loads(text)
    except Exception:
        pass
    # Strip markdown fences
    m = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception:
            pass
    # Find first { ... } block
    m2 = re.search(r'\{.*\}', text, re.DOTALL)
    if m2:
        try:
            return json.loads(m2.group(0))
        except Exception:
            pass
    return None


def run_exploitation_loop(finding: Dict, max_steps: int = 3) -> Dict:
    """
    Mythos-style iterative exploitation loop.

    Step 1: Initial hypothesis — what's the attack path?
    Step 2: Escalation — can this chain into something worse?
    Step 3: Confirmation — what's the minimum proof required?

    Returns: {
        attack_path, escalation_chains, minimum_proof,
        poc_steps, business_impact, confidence, loop_steps
    }
    """
    bug      = finding.get("bug", finding.get("bug_type", ""))
    url      = finding.get("url", "")
    param    = finding.get("param", "")
    sev      = finding.get("severity", "medium")
    desc     = finding.get("description", "")[:500]
    poc      = str(finding.get("poc", ""))[:300]
    oob      = finding.get("oob_confirmed", False)
    domain   = finding.get("domain", "")

    loop_steps = []

    # ── Step 1: Attack path hypothesis ────────────────────────────────────────
    prompt_1 = f"""Finding to analyze:
Bug type: {bug}
Severity: {sev}
URL: {url}
Parameter: {param}
Description: {desc}
OOB confirmed: {oob}
Existing PoC: {poc}
Target domain: {domain}

Analyze this finding and reason through the attack path.
Return ONLY valid JSON:
{{
  "attack_path": "step-by-step description of how an attacker exploits this",
  "entry_point": "exact parameter/endpoint/header",
  "trust_boundary": "which security boundary is crossed",
  "data_at_risk": "what data or actions become accessible",
  "attacker_capability": "what the attacker gains",
  "confidence": 0-100
}}"""

    raw_1 = _call(prompt_1, 600)
    step1  = _parse_json(raw_1) or {}
    loop_steps.append({"step": 1, "label": "attack_hypothesis", "result": step1})

    # ── Step 2: Escalation chains ──────────────────────────────────────────────
    prompt_2 = f"""Based on this {bug} vulnerability at {url}:
Attack path: {step1.get('attack_path', desc)[:300]}
Attacker gains: {step1.get('attacker_capability', '')}

Now reason through escalation. Can this chain into:
- Account takeover?
- Data exfiltration?
- Privilege escalation?
- RCE or server access?
- Lateral movement?

Return ONLY valid JSON:
{{
  "can_escalate": true/false,
  "escalation_paths": [
    {{"chain": "describe the chain", "impact": "what it achieves", "steps": ["step1", "step2"], "likelihood": "high/medium/low"}}
  ],
  "max_impact": "worst case impact if fully exploited",
  "chain_risk_score": 0-100
}}"""

    raw_2 = _call(prompt_2, 700)
    step2  = _parse_json(raw_2) or {}
    loop_steps.append({"step": 2, "label": "escalation_chains", "result": step2})

    # ── Step 3: Minimum proof (PoC||GTFO) ─────────────────────────────────────
    prompt_3 = f"""For this {bug} at {url} (parameter: {param}):
Attack path: {step1.get('attack_path', desc)[:200]}
Max impact: {step2.get('max_impact', '')}

Define the MINIMUM PROOF required to confirm this is real and report-ready.
Then write the exact reproduction steps (safe, non-destructive).

Return ONLY valid JSON:
{{
  "minimum_proof": "exactly what evidence is needed",
  "is_report_ready": true/false,
  "missing_evidence": ["list what's missing"],
  "reproduction_steps": [
    "Step 1: ...",
    "Step 2: ...",
    "Step 3: ..."
  ],
  "safe_poc_curl": "curl command if applicable",
  "why_not_fp": "argument for why this is a real finding",
  "suggested_severity": "critical/high/medium/low",
  "bounty_argument": "why this deserves a payout and at what level"
}}"""

    raw_3 = _call(prompt_3, 800)
    step3  = _parse_json(raw_3) or {}
    loop_steps.append({"step": 3, "label": "proof_requirements", "result": step3})

    # ── Assemble result ────────────────────────────────────────────────────────
    return {
        "attack_path":       step1.get("attack_path", ""),
        "entry_point":       step1.get("entry_point", param),
        "trust_boundary":    step1.get("trust_boundary", ""),
        "attacker_gains":    step1.get("attacker_capability", ""),
        "can_escalate":      step2.get("can_escalate", False),
        "escalation_paths":  step2.get("escalation_paths", []),
        "max_impact":        step2.get("max_impact", ""),
        "chain_risk_score":  step2.get("chain_risk_score", 0),
        "minimum_proof":     step3.get("minimum_proof", ""),
        "is_report_ready":   step3.get("is_report_ready", False),
        "missing_evidence":  step3.get("missing_evidence", []),
        "reproduction_steps":step3.get("reproduction_steps", []),
        "safe_poc_curl":     step3.get("safe_poc_curl", ""),
        "why_not_fp":        step3.get("why_not_fp", ""),
        "suggested_severity":step3.get("suggested_severity", sev),
        "bounty_argument":   step3.get("bounty_argument", ""),
        "loop_steps":        loop_steps,
        "confidence":        step1.get("confidence", 0),
        "api_used":          bool(_KEY),
    }


def analyze_code_target(source_code: str, language: str = "python",
                         context: str = "") -> Dict:
    """
    Hacktron-style source code analysis.
    Parses for vulnerability patterns, generates PoC, suggests patch.
    Works on snippets — not full codebases.
    """
    if not _KEY:
        return {"error": "ANTHROPIC_API_KEY not set"}

    prompt = f"""Analyze this {language} code for security vulnerabilities.
Context: {context}

Code:
```{language}
{source_code[:3000]}
```

Apply attacker-style reasoning. Look for:
- Injection points (SQL, command, template, LDAP)
- Broken auth / missing authorization checks
- Insecure deserialization
- Path traversal
- Business logic flaws
- Race conditions
- Cryptographic weaknesses

For each finding, you MUST provide a working PoC. PoC || GTFO.

Return ONLY valid JSON:
{{
  "vulnerabilities": [
    {{
      "bug_type": "sqli/xss/rce/idor/etc",
      "severity": "critical/high/medium/low",
      "line_numbers": [10, 15],
      "description": "what's wrong and why",
      "attack_vector": "how an attacker exploits this",
      "poc": "exact exploit payload or HTTP request",
      "patch": "code fix in diff format",
      "confidence": 0-100
    }}
  ],
  "attack_surface_summary": "overall assessment",
  "highest_risk": "most critical finding"
}}"""

    raw = _call(prompt, 2000)
    result = _parse_json(raw)
    if not result:
        return {"error": "Failed to parse AI response", "raw": raw[:200]}
    return result


def generate_hacktron_report(finding: Dict) -> str:
    """
    Hacktron-style report: PoC||GTFO.
    Every finding must have working reproduction steps.
    """
    if not _KEY:
        return _fallback_report(finding)

    bug  = finding.get("bug", finding.get("bug_type", ""))
    url  = finding.get("url", "")
    desc = finding.get("description", "")[:400]

    prompt = f"""Write a Hacktron-style security report for this finding.
Hacktron principle: PoC || GTFO. Every claim needs working proof.

Finding:
- Bug: {bug}
- URL: {url}
- Description: {desc}
- Existing PoC: {str(finding.get('poc',''))[:200]}

Write a concise, technical report with:
1. Executive summary (2 sentences)
2. Technical details (what's broken and why)
3. Working reproduction steps (exact commands)
4. Impact (what an attacker can do)
5. Remediation (specific code fix or config change)

Be direct. No fluff. If something is unproven, say so."""

    return _call(prompt, 1000) or _fallback_report(finding)


def _fallback_report(finding: Dict) -> str:
    """Fallback report when API key is not set."""
    bug = finding.get("bug", "vulnerability")
    url = finding.get("url", "")
    return (
        f"## {bug.upper()} — {url}\n\n"
        f"**Description:** {finding.get('description', '')}\n\n"
        f"**PoC:** {finding.get('poc', 'Not available')}\n\n"
        f"*Set ANTHROPIC_API_KEY for AI-enhanced reporting.*"
    )
