"""
TheMasterRecon AI — HackerOne Disclosed Report Intelligence Pipeline
Ingests public disclosed reports from HackerOne Hacktivity (GraphQL, no auth).
Extracts structured vulnerability patterns for scanner intelligence.

Sources used:
  - HackerOne GraphQL /graphql  (public disclosed only, paginated)
  - GitHub repos of curated H1 report writeups (via existing rag_ingest sources)

Rate limits respected:
  - 1 req/s to H1 GraphQL (they allow ~60/min anonymous)
  - Exponential backoff on 429/503
  - Cursor-based pagination (never skip/offset)
  - Resumes from last cursor stored in DB
"""
from __future__ import annotations

import json, logging, os, re, sqlite3, ssl, time, urllib.request
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional, Tuple

log = logging.getLogger("elite.h1_ingest")

# ── Paths ──────────────────────────────────────────────────────────────────────
_BASE = Path(__file__).parent.parent / "data" / "rag"
_DB   = _BASE / "h1_intel.db"

# ── Rate limiting ──────────────────────────────────────────────────────────────
_H1_DELAY   = 0.8          # seconds between requests (H1 allows ~60/min anonymous)
_BATCH_SIZE = 25           # H1 GraphQL max per page (API hard limit)
_MAX_RETRY  = 6            # retries on transient failure (more for long runs)
_RETRY_BASE = 2.0          # exponential backoff base seconds
_CHECKPOINT_EVERY = 500    # save progress every N reports


# ══════════════════════════════════════════════════════════════════════════════
# PHASE 1 — DATABASE SCHEMA
# ══════════════════════════════════════════════════════════════════════════════

SCHEMA = """
-- Core report store (deduped by H1 report ID)
CREATE TABLE IF NOT EXISTS h1_reports (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    h1_id           TEXT    UNIQUE NOT NULL,   -- HackerOne report ID
    title           TEXT    NOT NULL,
    url             TEXT    NOT NULL,
    program         TEXT,                      -- team handle
    program_name    TEXT,
    bug_type        TEXT,                      -- normalised: xss/sqli/ssrf/idor/…
    cwe             TEXT,                      -- CWE-79, CWE-89, …
    severity        TEXT,                      -- critical/high/medium/low
    bounty          REAL,
    disclosed_at    TEXT,
    vuln_body       TEXT,                      -- vulnerability_information field
    ingested_at     REAL    DEFAULT (unixepoch())
);
CREATE INDEX IF NOT EXISTS idx_h1_bug      ON h1_reports(bug_type);
CREATE INDEX IF NOT EXISTS idx_h1_severity ON h1_reports(severity);
CREATE INDEX IF NOT EXISTS idx_h1_program  ON h1_reports(program);
CREATE INDEX IF NOT EXISTS idx_h1_cwe      ON h1_reports(cwe);
CREATE INDEX IF NOT EXISTS idx_h1_date     ON h1_reports(disclosed_at);

-- Extracted endpoint patterns (per report, one row per pattern)
CREATE TABLE IF NOT EXISTS h1_endpoints (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id   INTEGER REFERENCES h1_reports(id) ON DELETE CASCADE,
    pattern     TEXT NOT NULL,     -- /api/v1/users, /graphql, /admin/…
    raw         TEXT,              -- exact URL if found
    bug_type    TEXT,
    severity    TEXT,
    program     TEXT
);
CREATE INDEX IF NOT EXISTS idx_ep_pattern  ON h1_endpoints(pattern);
CREATE INDEX IF NOT EXISTS idx_ep_bug      ON h1_endpoints(bug_type);

-- Extracted parameter names (per report)
CREATE TABLE IF NOT EXISTS h1_params (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id   INTEGER REFERENCES h1_reports(id) ON DELETE CASCADE,
    name        TEXT NOT NULL,     -- id, redirect_url, file, token, …
    context     TEXT,              -- query / body / header / path
    bug_type    TEXT,
    severity    TEXT
);
CREATE INDEX IF NOT EXISTS idx_param_name  ON h1_params(name);
CREATE INDEX IF NOT EXISTS idx_param_bug   ON h1_params(bug_type);

-- Extracted payload patterns
CREATE TABLE IF NOT EXISTS h1_payloads (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id   INTEGER REFERENCES h1_reports(id) ON DELETE CASCADE,
    payload     TEXT NOT NULL,
    bug_type    TEXT,
    confidence  REAL DEFAULT 0.5    -- 0-1 how payload-like this is
);
CREATE INDEX IF NOT EXISTS idx_payload_bug ON h1_payloads(bug_type);

-- Aggregated pattern index (rebuilt by build_pattern_index())
CREATE TABLE IF NOT EXISTS h1_patterns (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern_type TEXT NOT NULL,    -- endpoint / param / payload
    value        TEXT NOT NULL,
    bug_type     TEXT,
    frequency    INTEGER DEFAULT 1,
    severity_max TEXT,
    example_ids  TEXT,             -- JSON list of h1_report.h1_ids
    last_seen    TEXT,
    UNIQUE(pattern_type, value, bug_type)
);
CREATE INDEX IF NOT EXISTS idx_pat_type    ON h1_patterns(pattern_type);
CREATE INDEX IF NOT EXISTS idx_pat_bug     ON h1_patterns(bug_type);
CREATE INDEX IF NOT EXISTS idx_pat_freq    ON h1_patterns(frequency DESC);

-- Ingestion cursor state (resumable pagination)
CREATE TABLE IF NOT EXISTS h1_cursor (
    key     TEXT PRIMARY KEY,
    value   TEXT,
    updated REAL DEFAULT (unixepoch())
);
"""

def _db() -> sqlite3.Connection:
    _BASE.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(_DB), timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript(SCHEMA)
    return conn


# ══════════════════════════════════════════════════════════════════════════════
# PHASE 2 — H1 HACKTIVITY INGESTION
# ══════════════════════════════════════════════════════════════════════════════

# Full query — fetches every useful public field from disclosed reports
_HACKTIVITY_QUERY = """
query HacktivityFeed($cursor: String) {
  hacktivity_items(
    first: 25
    after: $cursor
    where: { disclosed: { _eq: true } }
    order_by: { field: latest_disclosable_activity_at direction: DESC }
  ) {
    pageInfo { hasNextPage endCursor totalCount }
    edges {
      node {
        ... on HackerOneHacktivityItem {
          report {
            id
            title
            vulnerability_information
            severity_rating
            bounty_amount
            disclosed_at
            created_at
            url
            team {
              handle
              name
              url
            }
            weakness {
              name
              cwe_id
              external_id
            }
            structured_scope {
              asset_identifier
              asset_type
            }
          }
        }
      }
    }
  }
}
"""

_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode    = ssl.CERT_NONE


def _h1_graphql(cursor: Optional[str] = None) -> Optional[Dict]:
    """
    Call HackerOne's public GraphQL endpoint.
    No authentication required for disclosed reports.
    Rate limit: ~60 req/min anonymous.
    """
    variables = {"cursor": cursor} if cursor else {}
    payload   = json.dumps({"query": _HACKTIVITY_QUERY, "variables": variables}).encode()

    for attempt in range(_MAX_RETRY):
        try:
            req = urllib.request.Request(
                "https://hackerone.com/graphql",
                data    = payload,
                headers = {
                    "Content-Type": "application/json",
                    "Accept":       "application/json",
                    "Origin":       "https://hackerone.com",
                    "Referer":      "https://hackerone.com/hacktivity",
                    "User-Agent":   "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
                    "X-Auth-Token": "",
                },
                method  = "POST",
            )
            with urllib.request.urlopen(req, timeout=30, context=_SSL_CTX) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            if e.code in (429, 503):
                wait = _RETRY_BASE ** (attempt + 1)
                log.warning(f"[h1_ingest] rate limited ({e.code}) — waiting {wait:.0f}s")
                time.sleep(wait)
            else:
                log.debug(f"[h1_ingest] HTTP {e.code}: {e.reason}")
                return None
        except Exception as e:
            wait = _RETRY_BASE ** attempt
            log.debug(f"[h1_ingest] attempt {attempt+1}: {e} — retry in {wait:.0f}s")
            time.sleep(wait)
    return None


def _get_cursor() -> Optional[str]:
    try:
        with _db() as conn:
            row = conn.execute("SELECT value FROM h1_cursor WHERE key='hacktivity'").fetchone()
            return row["value"] if row else None
    except Exception:
        return None


def _save_cursor(cursor: str):
    try:
        with _db() as conn:
            conn.execute("INSERT OR REPLACE INTO h1_cursor(key,value,updated) VALUES('hacktivity',?,unixepoch())",
                         (cursor,))
    except Exception as e:
        log.debug(f"[h1_ingest] cursor save: {e}")


def fetch_hacktivity(
    max_reports: int = 5000,
    resume: bool     = True,
    progress_cb      = None,
) -> Generator[Dict, None, None]:
    """
    Paginate through HackerOne disclosed reports.
    Yields normalised report dicts. Saves cursor for resume.

    Args:
        max_reports: Stop after this many reports fetched.
        resume:      Start from saved cursor (default True).
        progress_cb: Optional callable(fetched, total_so_far) for progress.
    """
    cursor  = _get_cursor() if resume else None
    fetched = 0

    log.info(f"[h1_ingest] starting hacktivity fetch (max={max_reports}, resume={resume})")
    if cursor:
        log.info(f"[h1_ingest] resuming from cursor: {cursor[:20]}…")

    while fetched < max_reports:
        data = _h1_graphql(cursor)
        if not data:
            log.warning("[h1_ingest] empty response — stopping")
            break

        items  = (data.get("data",{}).get("hacktivity_items",{}) or {})
        edges  = items.get("edges") or []
        pinfo  = items.get("pageInfo") or {}

        for edge in edges:
            if fetched >= max_reports:
                break
            node   = edge.get("node",{}) or {}
            report = node.get("report") or {}
            if not report or not report.get("id"):
                continue

            normalised = _normalise_h1_report(report)
            fetched += 1
            if progress_cb:
                progress_cb(fetched, max_reports)
            yield normalised

        if pinfo.get("hasNextPage") and pinfo.get("endCursor"):
            cursor = pinfo["endCursor"]
            _save_cursor(cursor)
        else:
            log.info("[h1_ingest] reached end of hacktivity feed")
            # Reset cursor so next run starts fresh from latest
            try:
                with _db() as conn:
                    conn.execute("DELETE FROM h1_cursor WHERE key='hacktivity'")
            except Exception:
                pass
            break

        time.sleep(_H1_DELAY)

    log.info(f"[h1_ingest] fetch complete: {fetched} reports")


# ══════════════════════════════════════════════════════════════════════════════
# PHASE 3 — NORMALISATION
# ══════════════════════════════════════════════════════════════════════════════

# Canonical bug type mapping from H1 weakness names + CWEs
_WEAKNESS_MAP: Dict[str, str] = {
    # XSS
    "cross-site scripting": "xss", "xss": "xss",
    "cwe-79": "xss", "cwe-80": "xss",
    # SQLi
    "sql injection": "sqli", "cwe-89": "sqli",
    # SSRF
    "server-side request forgery": "ssrf", "cwe-918": "ssrf",
    # IDOR / Broken Access Control
    "insecure direct object reference": "idor",
    "broken access control": "idor",
    "improper access control": "idor",
    "authorization bypass": "idor",
    "cwe-639": "idor", "cwe-284": "idor", "cwe-285": "idor",
    # RCE
    "remote code execution": "rce", "command injection": "rce",
    "code injection": "rce",
    "cwe-77": "rce", "cwe-78": "rce", "cwe-94": "rce",
    # LFI / Path Traversal
    "path traversal": "lfi", "local file inclusion": "lfi",
    "directory traversal": "lfi",
    "cwe-22": "lfi", "cwe-23": "lfi",
    # XXE
    "xml external entity": "xxe", "xxe": "xxe",
    "cwe-611": "xxe",
    # SSTI
    "server-side template injection": "ssti", "ssti": "ssti",
    "cwe-94": "ssti",
    # CSRF
    "cross-site request forgery": "csrf", "csrf": "csrf",
    "cwe-352": "csrf",
    # CORS
    "cors": "cors", "cross-origin resource sharing": "cors",
    "cwe-942": "cors",
    # Redirect
    "open redirect": "redirect", "url redirection": "redirect",
    "cwe-601": "redirect",
    # Takeover
    "subdomain takeover": "takeover",
    # Information Disclosure
    "information disclosure": "misconfig",
    "sensitive data exposure": "misconfig",
    "cwe-200": "misconfig", "cwe-201": "misconfig",
    # JWT
    "improper authentication": "jwt", "cwe-287": "jwt",
    # GraphQL
    "graphql": "graphql",
    # Race condition
    "race condition": "race", "cwe-362": "race",
    # File upload
    "unrestricted upload": "fileupload", "cwe-434": "fileupload",
    # Deserialization
    "deserialization": "deserialization", "cwe-502": "deserialization",
    # HTTP Smuggling
    "http request smuggling": "smuggling", "cwe-444": "smuggling",
    # CRLF
    "crlf injection": "crlf",
    # Prototype pollution
    "prototype pollution": "prototype",
    # Business logic
    "business logic": "logic",
}

_SEV_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1, "none": 0}


def _normalise_bug_type(weakness_name: str, cwe_id: str, title: str) -> str:
    """Map H1 weakness + CWE + title to canonical bug type."""
    combined = f"{weakness_name} {cwe_id} {title}".lower()
    for kw, btype in _WEAKNESS_MAP.items():
        if kw in combined:
            return btype
    # Fallback: title heuristics
    title_l = title.lower()
    for kw in ["xss","sqli","ssrf","idor","rce","lfi","xxe","ssti","csrf","cors",
               "redirect","takeover","graphql","race","jwt","smuggling"]:
        if kw in title_l:
            return kw
    return "other"


def _normalise_h1_report(report: Dict) -> Dict:
    """Convert raw H1 GraphQL report to canonical normalised dict."""
    weakness = report.get("weakness") or {}
    team     = report.get("team") or {}
    rid      = str(report.get("id",""))
    title    = report.get("title","").strip()
    vuln_info= (report.get("vulnerability_information") or "").strip()
    severity = (report.get("severity_rating") or "medium").lower()
    bounty   = report.get("bounty_amount")

    bug_type = _normalise_bug_type(
        weakness.get("name",""),
        weakness.get("cwe_id",""),
        title,
    )
    cwe = weakness.get("cwe_id","")
    if cwe and not cwe.startswith("CWE-"):
        cwe = f"CWE-{cwe}"

    return {
        "h1_id":        rid,
        "title":        title,
        "url":          f"https://hackerone.com/reports/{rid}",
        "program":      team.get("handle",""),
        "program_name": team.get("name",""),
        "bug_type":     bug_type,
        "cwe":          cwe,
        "severity":     severity if severity in _SEV_ORDER else "medium",
        "bounty":       float(bounty) if bounty else None,
        "disclosed_at": report.get("disclosed_at",""),
        "vuln_body":    vuln_info[:20000],
    }


# ══════════════════════════════════════════════════════════════════════════════
# PHASE 4 — PATTERN EXTRACTION
# ══════════════════════════════════════════════════════════════════════════════

# Endpoint patterns — normalised paths (strip IDs and UUIDs)
_EP_REGEX = re.compile(
    r'https?://[^/\s"\'<>]+(/[^\s"\'<>?#]{2,})',
    re.I,
)
_UUID_RE  = re.compile(r'/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', re.I)
_NUM_RE   = re.compile(r'/\d+')

# Parameter name extraction
_PARAM_REGEX = re.compile(
    r'(?:'
    r'[?&]([a-zA-Z_][a-zA-Z0-9_\-]{0,40})='         # query params
    r'|"([a-zA-Z_][a-zA-Z0-9_\-]{0,40})":\s*["\d{]' # JSON body params
    r'|body:\s*\{[^}]*["\']([a-zA-Z_][a-zA-Z0-9_\-]{0,40})["\']' # body object
    r')',
)

# Payload extraction: lines that look like actual attack payloads
_PAYLOAD_INDICATORS = [
    # XSS
    r"<script[^>]*>",
    r"onerror\s*=",
    r"javascript:",
    r"alert\s*\(",
    r"confirm\s*\(",
    r"prompt\s*\(",
    r"<img[^>]+src\s*=",
    r"<svg[^>]+on\w+\s*=",
    # SQLi
    r"'\s*(?:OR|AND|UNION)\s+",
    r"1\s*=\s*1",
    r"sleep\s*\(\d",
    r"waitfor\s+delay",
    r"--\s*$",
    r";\s*DROP\s+TABLE",
    r"BENCHMARK\s*\(",
    # SSRF
    r"169\.254\.169\.254",
    r"metadata\.google\.internal",
    r"file:///",
    r"dict://",
    r"gopher://",
    # SSTI
    r"\{\{.*\}\}",
    r"\$\{.*\}",
    r"<%.*%>",
    r"#{.*}",
    # Path traversal
    r"\.\./\.\.",
    r"\.\.\\",
    r"%2e%2e%2f",
    # XXE
    r"<!ENTITY",
    r"SYSTEM\s+[\"']file://",
    # Command injection
    r";\s*(?:ls|cat|id|whoami|wget|curl)\b",
    r"\|\s*(?:ls|cat|id|whoami)",
    r"`[^`]+`",
    r"\$\([^)]+\)",
]
_PAYLOAD_RE = re.compile("|".join(_PAYLOAD_INDICATORS), re.I)

# Stop words for parameter extraction
_PARAM_STOPWORDS = {
    "true","false","null","undefined","type","name","value","data","id",
    "href","src","rel","alt","class","style","id","lang","dir",
    "width","height","xmlns","version","encoding",
}

# High-value endpoint prefixes
_INTERESTING_PREFIXES = [
    "/api/", "/v1/", "/v2/", "/v3/", "/graphql", "/admin",
    "/dashboard", "/user", "/account", "/auth", "/login",
    "/oauth", "/token", "/upload", "/import", "/export",
    "/webhook", "/callback", "/redirect", "/proxy",
    "/internal", "/debug", "/test", "/staging", "/dev",
]


def _normalise_endpoint(path: str) -> str:
    """Strip IDs/UUIDs from path for grouping: /users/123 → /users/{id}"""
    path = _UUID_RE.sub("/{uuid}", path)
    path = _NUM_RE.sub("/{id}", path)
    # Remove trailing slash
    return path.rstrip("/") or "/"


def extract_endpoints(text: str) -> List[Tuple[str, str]]:
    """
    Extract (pattern, raw_url) tuples from report text.
    Only keeps paths matching _INTERESTING_PREFIXES or containing 2+ segments.
    Returns list of (normalised_pattern, raw_path).
    """
    results: List[Tuple[str, str]] = []
    seen: set = set()
    for m in _EP_REGEX.finditer(text):
        raw = m.group(1)
        if len(raw) < 3 or raw.count("/") < 1:
            continue
        norm = _normalise_endpoint(raw)
        if norm in seen:
            continue
        seen.add(norm)
        # Only keep interesting endpoints
        if (any(raw.lower().startswith(pfx) for pfx in _INTERESTING_PREFIXES)
                or raw.count("/") >= 2):
            results.append((norm, raw))
    return results[:30]  # max 30 per report


def extract_params(text: str) -> List[Tuple[str, str]]:
    """
    Extract (param_name, context) from report text.
    context = 'query' | 'body' | 'header'
    Returns deduplicated list.
    """
    results: List[Tuple[str, str]] = []
    seen: set = set()
    for m in _PARAM_REGEX.finditer(text):
        name = (m.group(1) or m.group(2) or m.group(3) or "").strip().lower()
        if not name or name in _PARAM_STOPWORDS or len(name) < 2 or len(name) > 40:
            continue
        if name in seen:
            continue
        seen.add(name)
        # Determine context
        pos   = m.start()
        snip  = text[max(0, pos-30):pos+40].lower()
        ctx   = ("query" if "?" in snip or "&" in snip
                 else "body" if "{" in snip or "post" in snip
                 else "header" if "header" in snip
                 else "query")
        results.append((name, ctx))
    return results[:50]


def extract_payloads(text: str) -> List[str]:
    """
    Extract actual attack payload strings from report text.
    Lines that contain payload indicators get extracted.
    Strips prose prefixes and skips prose sentences that happen to contain
    payload content (e.g. "2. POST with body: {comment: <script>...}").
    """
    # Prose sentence starters — skip entire line if it starts with these
    _SKIP_RE = re.compile(
        r'^(?:'
        r'\d+\.\s+'                                    # numbered step: "2. POST..."
        r'|(?:navigate|visit|go to|open|send|intercept|craft|try|the following)\b'
        r'|this (?:allows|leads|will)\b'
        r'|(?:note|impact|summary|description|i found|also tested|step \d+)[:\s]'
        r'|(?:post|get|put|patch|delete)\s+with\b'
        r')',
        re.I,
    )
    # Prefixes to strip from matching lines before storing
    _STRIP_RE = re.compile(
        r'^(?:payload(?:\s+used)?|poc|example|content|requ\w+|'
        r'also tested|tried|reproduction)[:\s]+',
        re.I,
    )
    payloads: List[str] = []
    seen: set = set()
    lines = text.split("\n")
    for line in lines:
        line = line.strip()
        if len(line) < 4 or len(line) > 500:
            continue
        # Skip pure markdown structural lines
        if line.startswith(("#", ">", "|", "---")) and not _PAYLOAD_RE.search(line):
            continue
        # Skip prose sentences that incidentally contain payload chars
        if _SKIP_RE.match(line):
            continue
        if _PAYLOAD_RE.search(line):
            # Strip label prefixes, markdown backticks
            clean = _STRIP_RE.sub('', line).strip()
            # Remove leading/trailing markdown markup
            clean = re.sub(r'^[`*_]+|[`*_\s]+$', '', clean).strip()
            # Truncate trailing prose after the payload's closing delimiter.
            # Patterns: "> text", "} text", ") text" where text is prose (capital word + common verb)
            # Strip trailing prose after HTML/template payload closes.
            # Only match after > or } or ) — NOT after ' (prevents SQLi truncation).
            # Prose indicator: Capitalised English word (not SQL/operator keyword).
            # Strip trailing prose after HTML/template close (> } ) ]).
            # Titlecase: "Stored", "Found", etc. — or known uppercase prose words.
            # Strip trailing prose after payload: "../../../../etc/passwd LFI in /api..."
            # Match: payload-text then space then KNOWN_TYPE or common prose connectors
            _trail = re.search(
                r'(?<=[>})\]]|(?<=[a-z0-9]))\s+'
                r'(?='
                r'(?:XSS|IDOR|SSRF|SQLi|RCE|LFI|SSTI|XXE|CSRF|CORS|RCE|BUG|CVE)\s'
                r'|(?:in|at|via|for|from|on|by)\s+/'   # " in /path at program"
                r')',
                clean,
            )
            if _trail:
                clean = clean[:_trail.start()].strip()
            if clean and clean not in seen and len(clean) >= 4 and _PAYLOAD_RE.search(clean):
                seen.add(clean)
                payloads.append(clean[:300])
    return payloads[:20]


# ══════════════════════════════════════════════════════════════════════════════
# PHASE 5 — STORAGE
# ══════════════════════════════════════════════════════════════════════════════

def insert_report(report: Dict) -> Optional[int]:
    """
    Insert a normalised report and its extracted patterns.
    Returns the row id, or None if duplicate.
    """
    try:
        with _db() as conn:
            # Dedup by H1 report ID
            row = conn.execute(
                "SELECT id FROM h1_reports WHERE h1_id=?", (report["h1_id"],)
            ).fetchone()
            if row:
                return None

            cur = conn.execute("""
                INSERT INTO h1_reports
                  (h1_id, title, url, program, program_name, bug_type, cwe,
                   severity, bounty, disclosed_at, vuln_body)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """, (
                report["h1_id"], report["title"], report["url"],
                report["program"], report["program_name"], report["bug_type"],
                report["cwe"], report["severity"], report["bounty"],
                report["disclosed_at"], report["vuln_body"],
            ))
            rid = cur.lastrowid

            # Extract and store patterns
            body = (report.get("vuln_body") or "") + " " + report.get("title","")

            # Endpoints
            for pattern, raw in extract_endpoints(body):
                conn.execute("""
                    INSERT INTO h1_endpoints (report_id, pattern, raw, bug_type, severity, program)
                    VALUES (?,?,?,?,?,?)
                """, (rid, pattern, raw, report["bug_type"], report["severity"], report["program"]))

            # Parameters
            for name, ctx in extract_params(body):
                conn.execute("""
                    INSERT INTO h1_params (report_id, name, context, bug_type, severity)
                    VALUES (?,?,?,?,?)
                """, (rid, name, ctx, report["bug_type"], report["severity"]))

            # Payloads
            for payload in extract_payloads(body):
                confidence = 0.9 if _PAYLOAD_RE.search(payload) else 0.5
                conn.execute("""
                    INSERT INTO h1_payloads (report_id, payload, bug_type, confidence)
                    VALUES (?,?,?,?)
                """, (rid, payload, report["bug_type"], confidence))

            return rid

    except sqlite3.IntegrityError:
        return None
    except Exception as e:
        log.warning(f"[h1_ingest] insert_report: {e}")
        return None


# ══════════════════════════════════════════════════════════════════════════════
# PHASE 6 — PATTERN INDEX (aggregated, searchable)
# ══════════════════════════════════════════════════════════════════════════════

def build_pattern_index():
    """
    Aggregate raw endpoints/params/payloads into h1_patterns.
    Computes frequency, max severity, example report IDs.
    Safe to call incrementally — uses INSERT OR REPLACE.
    """
    log.info("[h1_ingest] building pattern index…")
    with _db() as conn:

        # ── Endpoint patterns ─────────────────────────────────────────────
        conn.execute("DELETE FROM h1_patterns WHERE pattern_type='endpoint'")
        ep_rows = conn.execute("""
            SELECT
                h1_endpoints.pattern,
                h1_endpoints.bug_type,
                COUNT(*) AS freq,
                MAX(CASE h1_endpoints.severity WHEN 'critical' THEN 4
                                               WHEN 'high'     THEN 3
                                               WHEN 'medium'   THEN 2
                                               WHEN 'low'      THEN 1
                                               ELSE 0 END) AS sev_int,
                MAX(h1_endpoints.severity)  AS severity_max,
                GROUP_CONCAT(DISTINCT h1_reports.h1_id) AS ids,
                MAX(h1_reports.disclosed_at) AS last_seen
            FROM h1_endpoints
            JOIN h1_reports ON h1_reports.id = h1_endpoints.report_id
            GROUP BY h1_endpoints.pattern, h1_endpoints.bug_type
            ORDER BY freq DESC
        """).fetchall()

        for row in ep_rows:
            ids_list = (row["ids"] or "").split(",")[:10]
            conn.execute("""
                INSERT OR REPLACE INTO h1_patterns
                  (pattern_type, value, bug_type, frequency, severity_max, example_ids, last_seen)
                VALUES ('endpoint',?,?,?,?,?,?)
            """, (row["pattern"], row["bug_type"], row["freq"],
                  row["severity_max"], json.dumps(ids_list), row["last_seen"]))

        # ── Parameter patterns ────────────────────────────────────────────
        conn.execute("DELETE FROM h1_patterns WHERE pattern_type='param'")
        param_rows = conn.execute("""
            SELECT
                h1_params.name,
                h1_params.bug_type,
                COUNT(*) AS freq,
                MAX(h1_params.severity) AS severity_max,
                GROUP_CONCAT(DISTINCT h1_reports.h1_id) AS ids,
                MAX(h1_reports.disclosed_at) AS last_seen
            FROM h1_params
            JOIN h1_reports ON h1_reports.id = h1_params.report_id
            GROUP BY h1_params.name, h1_params.bug_type
            ORDER BY freq DESC
        """).fetchall()

        for row in param_rows:
            ids_list = (row["ids"] or "").split(",")[:10]
            conn.execute("""
                INSERT OR REPLACE INTO h1_patterns
                  (pattern_type, value, bug_type, frequency, severity_max, example_ids, last_seen)
                VALUES ('param',?,?,?,?,?,?)
            """, (row["name"], row["bug_type"], row["freq"],
                  row["severity_max"], json.dumps(ids_list), row["last_seen"]))

        # ── Payload patterns (group by first 80 chars as key) ─────────────
        conn.execute("DELETE FROM h1_patterns WHERE pattern_type='payload'")
        pay_rows = conn.execute("""
            SELECT
                h1_payloads.payload AS key,
                h1_payloads.bug_type,
                COUNT(*) AS freq,
                MAX(h1_reports.disclosed_at) AS last_seen,
                GROUP_CONCAT(DISTINCT h1_reports.h1_id) AS ids
            FROM h1_payloads
            JOIN h1_reports ON h1_reports.id = h1_payloads.report_id
            WHERE h1_payloads.confidence >= 0.7
            GROUP BY key, h1_payloads.bug_type
            ORDER BY freq DESC
        """).fetchall()

        for row in pay_rows:
            ids_list = (row["ids"] or "").split(",")[:5]
            conn.execute("""
                INSERT OR REPLACE INTO h1_patterns
                  (pattern_type, value, bug_type, frequency, severity_max, example_ids, last_seen)
                VALUES ('payload',?,?,?,NULL,?,?)
            """, (row["key"], row["bug_type"], row["freq"],
                  json.dumps(ids_list), row["last_seen"]))

    log.info("[h1_ingest] pattern index built")


# ══════════════════════════════════════════════════════════════════════════════
# PHASE 7 — QUERY API (used by scanner integration)
# ══════════════════════════════════════════════════════════════════════════════

def get_endpoint_patterns(
    bug_type: str = "",
    min_frequency: int = 2,
    limit: int = 50,
) -> List[Dict]:
    """
    Return endpoint patterns ranked by frequency.
    Used by scanner to prioritise which paths to fuzz.
    """
    with _db() as conn:
        if bug_type:
            rows = conn.execute("""
                SELECT value, bug_type, frequency, severity_max, example_ids, last_seen
                FROM h1_patterns
                WHERE pattern_type='endpoint' AND bug_type=? AND frequency>=?
                ORDER BY frequency DESC LIMIT ?
            """, (bug_type, min_frequency, limit)).fetchall()
        else:
            rows = conn.execute("""
                SELECT value, bug_type, frequency, severity_max, example_ids, last_seen
                FROM h1_patterns
                WHERE pattern_type='endpoint' AND frequency>=?
                ORDER BY frequency DESC LIMIT ?
            """, (min_frequency, limit)).fetchall()
    return [dict(r) for r in rows]


def get_param_patterns(
    bug_type: str = "",
    min_frequency: int = 3,
    limit: int = 100,
) -> List[Dict]:
    """
    Return parameter names most commonly associated with vulnerabilities.
    Used by scanner to inject payloads into high-value params first.
    """
    with _db() as conn:
        if bug_type:
            rows = conn.execute("""
                SELECT value, bug_type, frequency, severity_max
                FROM h1_patterns
                WHERE pattern_type='param' AND bug_type=? AND frequency>=?
                ORDER BY frequency DESC LIMIT ?
            """, (bug_type, min_frequency, limit)).fetchall()
        else:
            rows = conn.execute("""
                SELECT value, bug_type, frequency, severity_max
                FROM h1_patterns
                WHERE pattern_type='param' AND frequency>=?
                ORDER BY frequency DESC LIMIT ?
            """, (min_frequency, limit)).fetchall()
    return [dict(r) for r in rows]


def get_payloads(
    bug_type: str,
    limit: int = 30,
) -> List[str]:
    """
    Return real-world payload strings for a bug type, ranked by frequency.
    Used by scanner to prepend H1-proven payloads to its list.
    """
    with _db() as conn:
        rows = conn.execute("""
            SELECT value, frequency FROM h1_patterns
            WHERE pattern_type='payload' AND bug_type=?
            ORDER BY frequency DESC LIMIT ?
        """, (bug_type, limit)).fetchall()
    return [r["value"] for r in rows]


def get_intel_for_endpoint(path: str, bug_type: str = "") -> Dict:
    """
    Given a URL path, return intelligence: which bug types were found on
    similar paths, most common params, relevant payloads.
    """
    norm = _normalise_endpoint(path)

    with _db() as conn:
        # Find matching endpoint patterns
        # Match: exact, path prefix, or segment overlap
        path_segments = [s for s in norm.split('/') if s and s not in ('{id}','{uuid}')]
        ep_rows = []
        if norm:
            like_pat = '%' + '/'.join(path_segments[:2]) + '%' if len(path_segments) >= 2 else '%' + norm[:20] + '%'
            ep_rows = conn.execute("""
                SELECT value, bug_type, frequency, severity_max, example_ids
                FROM h1_patterns
                WHERE pattern_type='endpoint'
                  AND (value=?
                    OR value LIKE ?
                    OR ? LIKE '%' || REPLACE(value,'{id}','') || '%')
                ORDER BY frequency DESC LIMIT 10
            """, (norm, like_pat, norm)).fetchall()

        # Top params for this bug type
        if bug_type:
            param_rows = conn.execute("""
                SELECT value, frequency FROM h1_patterns
                WHERE pattern_type='param' AND bug_type=?
                ORDER BY frequency DESC LIMIT 20
            """, (bug_type,)).fetchall()
        else:
            param_rows = conn.execute("""
                SELECT value, frequency FROM h1_patterns
                WHERE pattern_type='param'
                ORDER BY frequency DESC LIMIT 20
            """).fetchall()

    matched_bugs = {}
    for r in ep_rows:
        bt = r["bug_type"]
        if bt not in matched_bugs or matched_bugs[bt]["frequency"] < r["frequency"]:
            matched_bugs[bt] = {
                "bug_type":    bt,
                "frequency":   r["frequency"],
                "severity_max":r["severity_max"],
                "examples":    json.loads(r["example_ids"] or "[]"),
            }

    return {
        "path":         norm,
        "matched_bugs": list(matched_bugs.values()),
        "top_params":   [r["value"] for r in param_rows],
        "payloads":     get_payloads(bug_type, 10) if bug_type else [],
    }


def db_stats() -> Dict:
    """Return counts for UI display."""
    with _db() as conn:
        def count(table, where=""):
            q = f"SELECT COUNT(*) FROM {table}" + (f" WHERE {where}" if where else "")
            return conn.execute(q).fetchone()[0]

        by_bug = dict(conn.execute(
            "SELECT bug_type, COUNT(*) FROM h1_reports GROUP BY bug_type ORDER BY 2 DESC LIMIT 15"
        ).fetchall())
        by_sev = dict(conn.execute(
            "SELECT severity, COUNT(*) FROM h1_reports GROUP BY severity"
        ).fetchall())
        top_programs = dict(conn.execute(
            "SELECT program, COUNT(*) FROM h1_reports GROUP BY program ORDER BY 2 DESC LIMIT 10"
        ).fetchall())
        pattern_by_type = dict(conn.execute(
            "SELECT pattern_type, COUNT(*) FROM h1_patterns GROUP BY pattern_type"
        ).fetchall())

    return {
        "reports":         count("h1_reports"),
        "endpoints":       count("h1_endpoints"),
        "params":          count("h1_params"),
        "payloads":        count("h1_payloads"),
        "patterns":        count("h1_patterns"),
        "by_bug_type":     by_bug,
        "by_severity":     by_sev,
        "top_programs":    top_programs,
        "patterns_by_type":pattern_by_type,
    }


# ══════════════════════════════════════════════════════════════════════════════
# PHASE 8 — FULL PIPELINE (batch ingest)
# ══════════════════════════════════════════════════════════════════════════════

def run_ingest(
    max_reports:    int  = 500000,   # default: fetch ALL disclosed reports
    resume:         bool = True,     # always resume from checkpoint
    build_index:    bool = True,
    also_feed_rag:  bool = True,
    progress_cb          = None,
    batch_embed:    int  = 500,      # embed every N inserts (memory efficiency)
) -> Dict:
    """
    Full pipeline: fetch → normalise → insert → extract patterns → index.
    Scale: designed for 500,000+ reports.

    Args:
        max_reports:   How many reports to fetch (default: ALL = 500k+).
                       H1 has ~200k+ publicly disclosed reports.
        resume:        Resume from last cursor checkpoint (default True).
                       Safe to interrupt and restart — picks up exactly where stopped.
        build_index:   Rebuild pattern index after ingestion.
        also_feed_rag: Also insert into RAG DB for semantic search.
        progress_cb:   Optional callback(fetched, total) for progress UI.
        batch_embed:   Embed reports in batches of this size (avoids memory issues).

    Returns:
        Dict with stats: inserted, duplicates, rag_inserted, errors, elapsed_s, rate_per_s.

    Estimated time for 500k reports at 0.8s/25 reports:
        ~500000 / 25 * 0.8 = ~16,000 seconds = ~4.4 hours
        (resumable — can be run across multiple sessions)
    """
    inserted    = 0
    duplicates  = 0
    rag_inserted= 0
    errors      = 0
    t0          = time.time()

    log.info(f"[h1_ingest] pipeline start (max={max_reports})")

    # Feed the existing RAG DB as well (for semantic search)
    rag_insert_fn = None
    if also_feed_rag:
        try:
            from engine.rag_db import insert_report as rag_insert
            rag_insert_fn = rag_insert
        except Exception as e:
            log.debug(f"[h1_ingest] RAG DB unavailable: {e}")

    for report in fetch_hacktivity(max_reports, resume, progress_cb):
        try:
            row_id = insert_report(report)
            if row_id:
                inserted += 1
                # Also insert into the main RAG DB
                if rag_insert_fn:
                    rag_row = {
                        "url":      report["url"],
                        "title":    report["title"],
                        "source":   "hackerone-hacktivity",
                        "bug_type": report["bug_type"],
                        "severity": report["severity"],
                        "program":  report["program"],
                        "tech":     [],
                        "bounty":   report["bounty"],
                        "body":     (f"# {report['title']}\n"
                                     f"Program: {report['program_name']}\n"
                                     f"Severity: {report['severity']}\n"
                                     f"CWE: {report['cwe']}\n\n"
                                     + (report.get("vuln_body") or "")),
                    }
                    if rag_insert_fn(rag_row):
                        rag_inserted += 1
            else:
                duplicates += 1

            # Log progress and batch-embed every N inserts
            processed = inserted + duplicates
            if processed % 100 == 0 and processed:
                elapsed = time.time() - t0
                rate = processed / elapsed
                eta_s = (max_reports - processed) / max(rate, 0.1)
                log.info(f"[h1_ingest] {inserted} new / {duplicates} dup "
                         f"({rate:.1f}/s — ETA {eta_s/3600:.1f}h)")

            # Batch embed periodically (avoids holding everything in memory)
            if also_feed_rag and rag_inserted > 0 and rag_inserted % batch_embed == 0:
                try:
                    from engine.rag_db import embed_pending
                    n_emb = embed_pending(batch=64)
                    if n_emb:
                        log.info(f"[h1_ingest] batch embedded {n_emb} reports")
                except Exception as _emb_e:
                    log.debug(f"[h1_ingest] batch embed: {_emb_e}")
        except Exception as e:
            errors += 1
            log.warning(f"[h1_ingest] error on {report.get('h1_id','?')}: {e}")

    elapsed = time.time() - t0

    if build_index and inserted > 0:
        log.info("[h1_ingest] building pattern index…")
        build_pattern_index()

    # Also trigger RAG embedding for new reports
    if also_feed_rag and rag_inserted > 0:
        try:
            from engine.rag_db import embed_pending, build_index as rag_build
            embedded = embed_pending(batch=64)
            if embedded:
                rag_build()
                log.info(f"[h1_ingest] embedded {embedded} new RAG reports")
        except Exception as e:
            log.debug(f"[h1_ingest] RAG embed: {e}")

    stats = {
        "inserted":     inserted,
        "duplicates":   duplicates,
        "rag_inserted": rag_inserted,
        "errors":       errors,
        "elapsed_s":    round(elapsed, 1),
        "rate_per_s":   round(inserted / elapsed, 2) if elapsed > 0 else 0,
    }
    log.info(f"[h1_ingest] done: {stats}")
    return stats
