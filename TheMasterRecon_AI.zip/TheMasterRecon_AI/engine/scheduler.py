"""
BugScan ELITE — Scan Scheduler
Schedule recurring scans: daily, weekly, on-change alerts.
"""
import json, time, threading, logging, os, re
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Callable

log = logging.getLogger("elite.scheduler")

SCHEDULE_FILE = Path(os.path.expanduser("~")) / ".bugscan_schedules.json"


class Schedule:
    def __init__(self, domain: str, bugs: List[str],
                 interval_hours: int = 24,
                 stealth: str = "normal",
                 notify_on_new: bool = True,
                 active: bool = True,
                 label: str = ""):
        self.id             = f"{domain}_{int(time.time())}"
        self.domain         = domain
        self.bugs           = bugs
        self.interval_hours = interval_hours
        self.stealth        = stealth
        self.notify_on_new  = notify_on_new
        self.active         = active
        self.label          = label or domain
        self.last_run       = 0.0
        self.next_run       = time.time()
        self.run_count      = 0
        self.created_at     = time.strftime("%Y-%m-%dT%H:%M:%SZ")

    def to_dict(self) -> Dict:
        return self.__dict__.copy()

    @classmethod
    def from_dict(cls, d: Dict) -> "Schedule":
        s = cls(d["domain"], d.get("bugs",[]))
        for k,v in d.items():
            setattr(s, k, v)
        return s

    def is_due(self) -> bool:
        return self.active and time.time() >= self.next_run

    def mark_ran(self):
        self.last_run  = time.time()
        self.next_run  = time.time() + self.interval_hours * 3600
        self.run_count += 1


class Scheduler:
    """
    Background scheduler that triggers scans on schedule.
    Integrates with recon, scanner, diff, notify engines.
    """

    def __init__(self, db, run_recon_fn: Callable, run_scan_fn: Callable):
        self._db          = db
        self._run_recon   = run_recon_fn
        self._run_scan    = run_scan_fn
        self._schedules:  Dict[str, Schedule] = {}
        self._lock        = threading.Lock()
        self._thread      = threading.Thread(target=self._loop, daemon=True,
                                              name="bugscan-scheduler")
        self._running     = True
        self._load()
        self._thread.start()
        log.info(f"[scheduler] started with {len(self._schedules)} schedules")

    def _load(self):
        """Load schedules from disk."""
        if SCHEDULE_FILE.exists():
            try:
                data = json.loads(SCHEDULE_FILE.read_text())
                for d in data:
                    s = Schedule.from_dict(d)
                    self._schedules[s.id] = s
            except Exception as e:
                log.warning(f"load schedules: {e}")

    def _save(self):
        """Persist schedules to disk."""
        try:
            data = [s.to_dict() for s in self._schedules.values()]
            SCHEDULE_FILE.write_text(json.dumps(data, indent=2))
        except Exception as e:
            log.warning(f"save schedules: {e}")

    def add(self, domain: str, bugs: List[str],
            interval_hours: int = 24,
            stealth: str = "normal",
            notify_on_new: bool = True,
            run_now: bool = False,
            label: str = "") -> Schedule:
        s = Schedule(domain, bugs, interval_hours, stealth, notify_on_new,
                     label=label)
        if run_now:
            s.next_run = time.time()
        with self._lock:
            self._schedules[s.id] = s
            self._save()
        log.info(f"[scheduler] added: {domain} every {interval_hours}h")
        return s

    def remove(self, schedule_id: str) -> bool:
        with self._lock:
            if schedule_id in self._schedules:
                del self._schedules[schedule_id]
                self._save()
                return True
        return False

    def pause(self, schedule_id: str):
        with self._lock:
            if schedule_id in self._schedules:
                self._schedules[schedule_id].active = False
                self._save()

    def resume(self, schedule_id: str):
        with self._lock:
            if schedule_id in self._schedules:
                self._schedules[schedule_id].active = True
                self._save()

    def list(self) -> List[Dict]:
        with self._lock:
            return [s.to_dict() for s in self._schedules.values()]

    def _loop(self):
        """Main scheduler loop — checks every 60 seconds."""
        while self._running:
            try:
                due = []
                with self._lock:
                    for s in self._schedules.values():
                        if s.is_due():
                            due.append(s)
                for s in due:
                    self._execute(s)
            except Exception as e:
                log.error(f"scheduler loop: {e}")
            time.sleep(60)

    def _execute(self, s: Schedule):
        """Execute a scheduled scan."""
        log.info(f"[scheduler] running: {s.domain} (#{s.run_count+1})")
        import queue as Q
        domain = s.domain
        q = Q.Queue()

        # Recon
        try:
            opts = {"skip_subs":False,"skip_crawl":False,"skip_port":True,
                    "skip_endpoints":False,"skip_js":False}
            t = threading.Thread(target=self._run_recon,
                                 args=(domain, opts, q, self._db), daemon=True)
            t.start()
            t.join(timeout=1800)  # 30min max
        except Exception as e:
            log.error(f"scheduler recon {domain}: {e}")

        # Scan
        try:
            sq = Q.Queue()
            t2 = threading.Thread(target=self._run_scan,
                                   args=(domain, s.bugs, sq, self._db),
                                   kwargs={"stealth_mode":s.stealth,"auto_select":True},
                                   daemon=True)
            t2.start()
            t2.join(timeout=3600)  # 1hr max
        except Exception as e:
            log.error(f"scheduler scan {domain}: {e}")

        # Diff and notify
        if s.notify_on_new:
            try:
                from engine.diff import MonitorEngine
                from engine.notify import get_notifier
                from pathlib import Path
                monitor = MonitorEngine(Path.home()/"Desktop"/"recon"/"snapshots")
                diff    = monitor.latest_diff(domain, self._db)
                notifier= get_notifier()
                if diff and diff.get("has_changes"):
                    # Notify new findings
                    for f in diff.get("findings",{}).get("new",[]):
                        notifier.queue_finding(f, domain)
                    # Notify new subdomains
                    new_subs = diff.get("subdomains",{}).get("new",[])
                    if new_subs:
                        notifier.send_recon_complete(
                            domain, len(new_subs),
                            len(diff.get("hosts",{}).get("new",[])),
                            len(diff.get("endpoints",{}).get("new",[])),
                        )
            except Exception as e:
                log.warning(f"scheduler notify {domain}: {e}")

        with self._lock:
            s.mark_ran()
            self._save()
        log.info(f"[scheduler] done: {domain}")

    def stop(self):
        self._running = False


def human_interval(hours: int) -> str:
    if hours < 24: return f"Every {hours} hour{'s' if hours>1 else ''}"
    if hours < 168: return f"Every {hours//24} day{'s' if hours//24>1 else ''}"
    return f"Every {hours//168} week{'s' if hours//168>1 else ''}"


def next_run_human(ts: float) -> str:
    delta = ts - time.time()
    if delta < 0: return "overdue"
    if delta < 3600: return f"in {int(delta//60)}m"
    if delta < 86400: return f"in {int(delta//3600)}h"
    return f"in {int(delta//86400)}d"
