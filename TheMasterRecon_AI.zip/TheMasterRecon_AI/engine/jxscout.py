"""
TheMasterRecon AI - jxscout + UnifiedSecretHunter Integration
https://github.com/francisconeves97/jxscout

UnifiedSecretHunter is the primary secret detection engine.
Binary must be placed at the app root: cp UnifiedSecretHunter-linux ./secret_hunter && chmod +x ./secret_hunter
No license proxy, no bypass - runs clean or not at all.
"""
import os, re, json, logging, subprocess, ssl, time, threading, tempfile
import urllib.request, urllib.parse
from typing import List, Dict, Optional
from pathlib import Path

log = logging.getLogger("elite.jxscout")

_APP_ROOT   = Path(__file__).parent.parent
HUNTER_BIN  = str(_APP_ROOT / "secret_hunter")
JXSCOUT_BIN = str(_APP_ROOT / "jxscout") if (_APP_ROOT / "jxscout").exists() else ""


def is_installed() -> bool:
    return os.path.isfile(HUNTER_BIN) and os.access(HUNTER_BIN, os.X_OK)


def get_status() -> Dict:
    return {
        "secret_hunter": {
            "installed": is_installed(),
            "binary":    HUNTER_BIN,
            "note": (
                "Binary not found - place UnifiedSecretHunter binary at app root as 'secret_hunter'"
                if not is_installed() else
                "Binary found - ready to scan"
            ),
        },
        "jxscout": {
            "installed": bool(JXSCOUT_BIN),
            "install":   "go install github.com/francisconeves97/jxscout/cmd/jxscout@latest",
        }
    }


def run_secret_hunter(
    targets: List[str],
    domain:  str = "",
    output_file: str = "",
    threads: int = 5,
    timeout: int = 30,
    crawl:   bool = False,
    no_validate: bool = True,
    license_key: str = "",
) -> List[Dict]:
    """
    Run UnifiedSecretHunter on URLs or files.
    Binary must be present at app root. Runs normally or skips cleanly.
    """
    if not is_installed():
        log.info(
            "[secret_hunter] running in safe mode — binary not installed. "
            "Place UnifiedSecretHunter binary at app root as 'secret_hunter'. "
            "Internal pattern scanner active as fallback."
        )
        return []

    if not targets:
        return []

    urls  = [t for t in targets if t.startswith(("http://", "https://"))]
    files = [t for t in targets if not t.startswith(("http://", "https://"))]

    with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False,
                                     prefix="tmr_sh_") as tf:
        out_path = tf.name

    try:
        cmd = [HUNTER_BIN, "-o", out_path, "-th", str(threads), "-t", str(timeout)]

        if urls:
            cmd += ["-u"] + urls[:100]
        if files:
            cmd += ["-f"] + files[:50]
        if no_validate:
            cmd.append("--no-validate")
        if crawl and urls:
            cmd.append("--crawl")
        if domain:
            cmd += ["-s", f"*{domain}*"]

        log.info(f"[secret_hunter] scanning {len(targets)} targets for {domain or 'unknown'}")

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout * 2 + 30,
            env=os.environ.copy(),
            cwd=str(_APP_ROOT),
        )

        if result.returncode not in (0, 1):
            log.warning(f"[secret_hunter] exit {result.returncode}: {result.stderr[:200]}")

        findings = []
        if os.path.exists(out_path):
            for line in open(out_path).read().strip().splitlines():
                line = line.strip()
                if not line: continue
                try:
                    item = json.loads(line)
                    risk = (item.get("risk_level") or "").lower()
                    if risk in ("critical", "high"):
                        sev = risk
                    elif risk in ("medium",):
                        sev = "medium"
                    else:
                        t = (item.get("type") or "").lower()
                        sev = "critical" if any(k in t for k in [
                            "aws", "private key", "stripe", "github", "openai",
                            "firebase", "gcp", "anthropic", "sendgrid", "slack"
                        ]) else "high"

                    findings.append({
                        "type":       item.get("type", "Secret"),
                        "value":      (item.get("value") or "")[:120],
                        "source":     item.get("source", ""),
                        "context":    (item.get("context") or "")[:300],
                        "severity":   sev,
                        "valid":      item.get("valid", False),
                        "risk_level": item.get("risk_level", "Unknown"),
                        "timestamp":  item.get("timestamp", ""),
                        "tool":       "UnifiedSecretHunter",
                    })
                except json.JSONDecodeError:
                    continue

        log.info(f"[secret_hunter] found {len(findings)} secrets in {len(targets)} targets")
        return findings

    except subprocess.TimeoutExpired:
        log.warning(f"[secret_hunter] timeout after {timeout*2+30}s")
        return []
    except Exception as e:
        log.error(f"[secret_hunter] error: {e}")
        return []
    finally:
        try: os.unlink(out_path)
        except: pass


def run_secret_hunter_on_domain(domain: str, db=None, max_js: int = 100) -> List[Dict]:
    if not is_installed() or not db:
        return []
    all_ends = db.get_endpoints(domain, limit=5000) if db else []
    js_files = [u for u in all_ends if re.search(r'\.js(\?|#|$)', u, re.I)][:max_js]
    if not js_files:
        log.debug(f"[secret_hunter] no JS files found for {domain}")
        return []
    return run_secret_hunter(js_files, domain=domain)


_jxscout_proc = None
_jxscout_lock = threading.Lock()


def start_jxscout(project: str = "default", scope: str = "", port: int = 3333) -> Dict:
    global _jxscout_proc
    if not JXSCOUT_BIN:
        return {"error": "jxscout not installed. Run: go install github.com/francisconeves97/jxscout/cmd/jxscout@latest"}
    with _jxscout_lock:
        if _jxscout_proc and _jxscout_proc.poll() is None:
            return {"ok": True, "msg": "already running", "pid": _jxscout_proc.pid}
        cmd = [JXSCOUT_BIN, f"-port={port}", f"-project-name={project}"]
        if scope: cmd.append(f"-scope={scope}")
        try:
            _jxscout_proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                stdin=subprocess.PIPE, cwd=str(_APP_ROOT))
            time.sleep(1)
            if _jxscout_proc.poll() is not None:
                return {"error": "jxscout exited immediately"}
            return {"ok": True, "pid": _jxscout_proc.pid, "port": port}
        except Exception as e:
            return {"error": str(e)}


def stop_jxscout() -> Dict:
    global _jxscout_proc
    with _jxscout_lock:
        if _jxscout_proc and _jxscout_proc.poll() is None:
            _jxscout_proc.terminate()
            try: _jxscout_proc.wait(timeout=5)
            except: _jxscout_proc.kill()
            _jxscout_proc = None
            return {"ok": True, "msg": "stopped"}
    return {"ok": True, "msg": "not running"}


def _fetch(url: str, timeout: int = 10) -> str:
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (TheMasterRecon-AI/2.0)"})
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
            return r.read().decode("utf-8", "ignore")[:500000]
    except Exception:
        return ""


def _extract_endpoints(content: str) -> List[str]:
    patterns = [
        r'["\'`](/(?:api|v\d+|rest|graphql|auth|admin|internal)[^\s"\'`\)]{1,100})',
        r'fetch\(["\'`]([^"\'`\s]{5,200})["\'`]',
        r'axios\.[a-z]+\(["\'`]([^"\'`\s]{5,200})["\'`]',
        r'baseURL\s*[:=]\s*["\'`]([^"\'`\s]+)["\'`]',
    ]
    eps = set()
    for p in patterns:
        for m in re.finditer(p, content, re.I):
            ep = m.group(1).strip("\"'`")
            if 5 < len(ep) < 200: eps.add(ep)
    return sorted(eps)[:100]


def _detect_bundler(content: str) -> Optional[str]:
    if "__webpack_require__" in content: return "webpack"
    if "__vite__" in content or "vitePreload" in content: return "vite"
    if "parcelRequire" in content: return "parcel"
    return None


def analyze_domain_js(domain: str, js_files: List[str]) -> Dict:
    all_eps = set(); bundlers = set(); maps = []
    for url in js_files[:80]:
        content = _fetch(url, timeout=10)
        if not content: continue
        all_eps.update(_extract_endpoints(content))
        b = _detect_bundler(content)
        if b: bundlers.add(b)
        for m in re.findall(r"//# sourceMappingURL=([^\s\n]+)", content):
            maps.append({"map": m, "js": url})
    return {
        "domain":         domain,
        "files_analyzed": len(js_files),
        "endpoints":      sorted(all_eps)[:200],
        "source_maps":    maps[:20],
        "bundlers":       list(bundlers),
    }
