"""
TheMasterRecon AI — JXScout v2 Engine
Official JS analysis tool — confirmed API from jxscout.app source:

  GET https://jxscout.app/api/v2/download
  Params: licenseKey, type (platform), version
  Returns: {downloadUrl: "https://..."}

License key: D46F40-BDF00A-1E4F63-B90FA7-A9928A-V3
"""
import os, re, json, logging, shutil, subprocess, threading, tempfile, time
import urllib.request, urllib.parse, ssl
from pathlib import Path
from typing import List, Dict, Optional

log = logging.getLogger("elite.jxscout_v2")

APP_ROOT = Path(__file__).parent.parent
BIN_PATH = APP_ROOT / "jxscout"           # primary binary location
BIN_ALT  = APP_ROOT / "tools" / "bin" / "jxscout"
DATA_DIR = APP_ROOT / "data" / "jxscout"
DATA_DIR.mkdir(parents=True, exist_ok=True)

# === CONFIRMED FROM jxscout.app JS SOURCE ===
DOWNLOAD_API = "https://jxscout.app/api/v2/download"

# All platforms from JS source (45315 module)
PLATFORMS = {
    "linux-amd64":              "Linux (x86_64)      ← Kali / most VPS",
    "linux-arm64":              "Linux (ARM64)        ← Raspberry Pi / Oracle",
    "linux-386":                "Linux (x86 32-bit)",
    "macos-arm64":              "macOS (Apple Silicon)",
    "macos-amd64":              "macOS (Intel)",
    "windows-amd64":            "Windows (x86_64)",
    "windows-arm64":            "Windows (ARM64)",
    "vscode-extension":         "VSCode Extension",
    "browser-extension":        "Chrome Extension",
    "firefox-browser-extension":"Firefox Extension",
}

# Pre-configured license key (user's real key)
DEFAULT_LICENSE_KEY = "D46F40-BDF00A-1E4F63-B90FA7-A9928A-V3"

JXSCOUT_PORT = int(os.environ.get("JXSCOUT_PORT", "3333"))

_proc_lock = threading.Lock()
_jxscout_proc = None
_download_lock = threading.Lock()


def _ssl_ctx():
    c = ssl.create_default_context()
    c.check_hostname = False
    c.verify_mode = ssl.CERT_NONE
    return c


def _get_license_key() -> str:
    """Get license key from env or use the pre-configured default."""
    return (
        os.environ.get("JXSCOUT_LICENSE", "").strip()
        or DEFAULT_LICENSE_KEY
    )


def _detect_platform() -> str:
    """Auto-detect platform using same logic as jxscout.app JS source."""
    import platform
    ua = (platform.system() + " " + platform.machine()).lower()
    if "windows" in ua or "win" in ua:
        return "windows-amd64"
    if "darwin" in ua or "mac" in ua:
        if "arm" in ua or "aarch64" in ua:
            return "macos-arm64"
        return "macos-amd64"
    # Linux (default — Kali runs on this)
    if "aarch64" in ua or "arm64" in ua or "arm" in ua:
        return "linux-arm64"
    return "linux-amd64"


def _get_binary_path() -> Optional[str]:
    """Find jxscout binary."""
    candidates = [
        str(BIN_PATH),
        str(BIN_ALT),
        shutil.which("jxscout") or "",
        str(Path.home() / "go" / "bin" / "jxscout"),
        "/usr/local/bin/jxscout",
    ]
    for p in candidates:
        if p and Path(p).exists() and os.access(p, os.X_OK):
            return p
    return None


def download_binary(license_key: str = None, version: str = "latest",
                    platform: str = None, progress_cb=None) -> Dict:
    """
    Download JXScout v2 binary.

    Uses EXACTLY the API confirmed from jxscout.app JS source:
      GET /api/v2/download?licenseKey=KEY&type=PLATFORM&version=VERSION
      Response: {downloadUrl: "https://..."}

    Args:
        license_key: License key. Defaults to pre-configured key.
        version:     "latest" or specific version string.
        platform:    Platform string. Auto-detected if None.
        progress_cb: Optional callback(pct, msg) for download progress.
    """
    key = (license_key or _get_license_key()).strip()
    if not key:
        return {"error": "No license key. Set JXSCOUT_LICENSE in .env"}

    platform = platform or _detect_platform()

    def _prog(pct, msg):
        if progress_cb:
            try: progress_cb(pct, msg)
            except: pass
        log.info(f"[jxscout_v2] {pct}% — {msg}")

    _prog(5, f"Requesting download URL for {platform} v{version}")
    log.info(f"[jxscout_v2] download: key={key[:8]}... platform={platform}")

    # Step 1: Call API to get download URL (exact API from JS source)
    params = urllib.parse.urlencode({
        "licenseKey": key,
        "type":       platform,
        "version":    version,
    })
    api_url = f"{DOWNLOAD_API}?{params}"
    log.info(f"[jxscout_v2] API: {api_url}")

    try:
        req = urllib.request.Request(api_url, headers={
            "User-Agent":  "TheMasterRecon/3.0 JXScout-Downloader",
            "Accept":      "application/json",
        })
        with urllib.request.urlopen(req, timeout=30, context=_ssl_ctx()) as r:
            resp_data = json.loads(r.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "ignore")
        try: msg = json.loads(body).get("error", body[:200])
        except: msg = body[:200]
        log.error(f"[jxscout_v2] API HTTP {e.code}: {msg}")
        return {"error": f"API error {e.code}: {msg}", "api_url": api_url}
    except Exception as e:
        log.error(f"[jxscout_v2] API failed: {e}")
        return {"error": str(e), "api_url": api_url}

    download_url = resp_data.get("downloadUrl", "")
    if not download_url:
        err = resp_data.get("error", f"No downloadUrl in response: {resp_data}")
        return {"error": err, "response": resp_data}

    _prog(20, f"Got download URL, fetching binary...")
    log.info(f"[jxscout_v2] Downloading from: {download_url[:80]}...")

    # Step 2: Download the actual binary
    # For browser/vscode extensions, just return the URL
    if platform in ("vscode-extension", "browser-extension", "firefox-browser-extension"):
        return {
            "ok":          True,
            "download_url": download_url,
            "platform":    platform,
            "note":        f"Open this URL to install: {download_url}",
        }

    dest = BIN_PATH
    try:
        req2 = urllib.request.Request(download_url, headers={
            "User-Agent": "TheMasterRecon/3.0"
        })

        # Stream download with progress
        with urllib.request.urlopen(req2, timeout=120, context=_ssl_ctx()) as r:
            total = int(r.headers.get("Content-Length", 0))
            data  = b""
            chunk = 65536
            while True:
                block = r.read(chunk)
                if not block:
                    break
                data += block
                if total:
                    pct = int(20 + 70 * len(data) / total)
                    _prog(pct, f"Downloaded {len(data)//1024}KB / {total//1024}KB")

        if len(data) < 1000:
            return {"error": f"Binary too small ({len(data)} bytes) — likely an error page"}

        _prog(92, "Writing binary...")
        dest.write_bytes(data)
        dest.chmod(0o755)

        # Verify it actually runs
        _prog(96, "Verifying binary...")
        vr = subprocess.run([str(dest), "--version"],
                            capture_output=True, text=True, timeout=10)
        version_str = (vr.stdout + vr.stderr).strip()[:100]

        _prog(100, f"Installed: {dest} ({len(data)//1024}KB)")
        log.info(f"[jxscout_v2] Installed: {dest}")

        # Save key to .env
        save_license_key(key)

        return {
            "ok":        True,
            "path":      str(dest),
            "size_kb":   len(data) // 1024,
            "version":   version_str,
            "platform":  platform,
        }

    except subprocess.TimeoutExpired:
        return {"ok": True, "path": str(dest), "note": "installed but --version timed out"}
    except Exception as e:
        log.error(f"[jxscout_v2] Write failed: {e}")
        return {"error": f"Write failed: {e}"}


def get_status() -> Dict:
    """Full JXScout v2 status."""
    binary = _get_binary_path()
    key    = _get_license_key()

    status = {
        "installed":          bool(binary),
        "binary_path":        binary or "",
        "version":            "",
        "running":            False,
        "pid":                None,
        "port":               JXSCOUT_PORT,
        "data_dir":           str(DATA_DIR),
        "license_configured": bool(key),
        "license_key_hint":   key[:8] + "..." if key else "",
        "platform":           _detect_platform(),
        "platforms":          PLATFORMS,
        "download_api":       DOWNLOAD_API,
        "no_key_bypass":      True,  # secret_hunter bypass still active
    }

    if binary:
        try:
            r = subprocess.run([binary, "--version"],
                               capture_output=True, text=True, timeout=5)
            status["version"] = (r.stdout + r.stderr).strip()[:80]
        except: pass

    global _jxscout_proc
    with _proc_lock:
        if _jxscout_proc and _jxscout_proc.poll() is None:
            status["running"] = True
            status["pid"]     = _jxscout_proc.pid

    return status


def start_jxscout(project: str = "default", scope: str = "",
                  port: int = None) -> Dict:
    """Start JXScout v2 proxy server."""
    global _jxscout_proc
    binary = _get_binary_path()
    if not binary:
        return {
            "error":    "JXScout not installed",
            "fix":      "Click 'Download Binary' in the JXScout panel",
        }

    port = port or JXSCOUT_PORT
    with _proc_lock:
        if _jxscout_proc and _jxscout_proc.poll() is None:
            return {"ok": True, "msg": "already running",
                    "pid": _jxscout_proc.pid, "port": port,
                    "proxy": f"http://localhost:{port}"}

        cmd = [binary, f"--port={port}", f"--project-name={project}"]
        if scope:
            cmd += [f"--scope={scope}"]
        try:
            _jxscout_proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, bufsize=1
            )
            time.sleep(1.5)
            if _jxscout_proc.poll() is not None:
                err = _jxscout_proc.stderr.read(500)
                return {"error": f"Failed to start: {err}"}
            log.info(f"[jxscout_v2] Started port={port} pid={_jxscout_proc.pid}")
            return {
                "ok":    True,
                "pid":   _jxscout_proc.pid,
                "port":  port,
                "proxy": f"http://localhost:{port}",
                "msg":   f"Proxy running at http://localhost:{port}",
            }
        except Exception as e:
            return {"error": str(e)}


def stop_jxscout() -> Dict:
    global _jxscout_proc
    with _proc_lock:
        if _jxscout_proc and _jxscout_proc.poll() is None:
            _jxscout_proc.terminate()
            try: _jxscout_proc.wait(timeout=5)
            except: _jxscout_proc.kill()
            _jxscout_proc = None
            return {"ok": True, "msg": "JXScout stopped"}
    return {"ok": True, "msg": "Not running"}


def get_project_findings(project: str = "default") -> List[Dict]:
    findings = []
    search_dirs = [
        DATA_DIR / project,
        Path.home() / ".jxscout" / "projects" / project,
        Path.home() / ".config" / "jxscout" / project,
    ]
    for d in search_dirs:
        if not d.exists():
            continue
        for fname in ["endpoints.json","secrets.json","findings.json","results.json"]:
            fpath = d / fname
            if not fpath.exists():
                continue
            try:
                data = json.loads(fpath.read_text())
                items = data if isinstance(data, list) else data.get("results", [])
                for item in items:
                    findings.append({
                        "type":     item.get("type","endpoint"),
                        "value":    item.get("value", item.get("url", item.get("endpoint",""))),
                        "severity": item.get("severity","medium"),
                        "source":   "jxscout_v2",
                    })
            except Exception as e:
                log.debug(f"[jxscout_v2] read {fpath}: {e}")
    return findings


def scan_js_url(url: str) -> Dict:
    binary = _get_binary_path()
    if binary:
        try:
            r = subprocess.run(
                [binary, "scan", "--url", url, "--json"],
                capture_output=True, text=True, timeout=60
            )
            if r.returncode == 0:
                try: return json.loads(r.stdout)
                except: return {"raw": r.stdout[:2000], "tool": "jxscout_v2"}
        except Exception as e:
            log.debug(f"[jxscout_v2] scan_js_url: {e}")
    # Fallback
    try:
        from engine.js_deep import full_js_analysis
        return full_js_analysis([url])
    except Exception as e:
        return {"error": str(e), "fallback": True}


def save_license_key(key: str) -> bool:
    try:
        env_path = APP_ROOT / ".env"
        content  = env_path.read_text() if env_path.exists() else ""
        if "JXSCOUT_LICENSE" in content:
            content = re.sub(r"JXSCOUT_LICENSE=.*", f"JXSCOUT_LICENSE={key.strip()}", content)
        else:
            content += f"\nJXSCOUT_LICENSE={key.strip()}\n"
        env_path.write_text(content)
        os.environ["JXSCOUT_LICENSE"] = key.strip()
        log.info(f"[jxscout_v2] License key saved")
        return True
    except Exception as e:
        log.error(f"[jxscout_v2] save_license_key: {e}")
        return False
