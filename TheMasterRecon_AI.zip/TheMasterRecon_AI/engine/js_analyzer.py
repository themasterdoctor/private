"""
BugScan ELITE — JavaScript Analysis Engine
Deep analysis: API routes, secrets, endpoints, auth flows, hardcoded values.
"""
import re, logging, urllib.request, urllib.parse, ssl, json
from typing import List, Dict, Set, Optional

log = logging.getLogger("elite.js")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _get(url, timeout=15):
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
            "Accept-Encoding": "gzip, deflate",
        })
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            raw = r.read(2*1024*1024)  # 2MB max
            try:
                import gzip
                if r.headers.get("Content-Encoding") == "gzip":
                    raw = gzip.decompress(raw)
            except: pass
            return raw.decode("utf-8","ignore")
    except: return ""

# ── Patterns ──────────────────────────────────────────────────────────────────

SECRET_PATTERNS = {
    # Cloud
    "AWS Access Key":       r'AKIA[0-9A-Z]{16}',
    "AWS Secret":           r'(?i)aws[_\-\s]{0,5}secret[_\-\s]{0,5}(?:access[_\-\s]{0,5})?key[\s\S]{0,30}["\']([0-9a-zA-Z/+=]{40})',
    "GCP API Key":          r'AIza[0-9A-Za-z\-_]{35}',
    "GCP Service Account":  r'"type":\s*"service_account"',
    "Azure Connection":     r'DefaultEndpointsProtocol=https;AccountName=[^;]+;AccountKey=[A-Za-z0-9+/=]{88}',
    # Auth
    "GitHub PAT":           r'gh[pous]_[0-9a-zA-Z]{36,255}',
    "GitHub OAuth":         r'gho_[0-9a-zA-Z]{36}',
    "GitHub App":           r'ghs_[0-9a-zA-Z]{36}',
    "GitLab Token":         r'glpat-[0-9a-zA-Z\-\_]{20}',
    "Slack Token":          r'xox[baprs]-[0-9]{12}-[0-9]{12}-[0-9a-zA-Z]{24}',
    "Slack Webhook":        r'https://hooks\.slack\.com/services/T[0-9A-Z]{8,10}/B[0-9A-Z]{8,10}/[0-9a-zA-Z]{24}',
    "Discord Token":        r'[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}',
    "Discord Webhook":      r'https://discord(?:app)?\.com/api/webhooks/[0-9]+/[a-zA-Z0-9_-]+',
    # Payment
    "Stripe Secret":        r'sk_live_[0-9a-zA-Z]{24,}',
    "Stripe Restricted":    r'rk_live_[0-9a-zA-Z]{24,}',
    "Stripe Publishable":   r'pk_live_[0-9a-zA-Z]{24,}',
    "Square Token":         r'sq0atp-[0-9A-Za-z\-_]{22}',
    "PayPal BrainTree":     r'access_token\$production\$[0-9a-z]{16}\$[0-9a-f]{32}',
    "Adyen API Key":        r'AQE[a-zA-Z0-9+/]{20,}',
    # Communication
    "Twilio SID":           r'AC[a-z0-9]{32}',
    "Twilio Auth":          r'SK[0-9a-fA-F]{32}',
    "SendGrid":             r'SG\.[a-zA-Z0-9]{22}\.[a-zA-Z0-9]{43}',
    "Mailgun":              r'key-[0-9a-zA-Z]{32}',
    "Mailchimp":            r'[0-9a-f]{32}-us[0-9]{1,2}',
    "Postmark":             r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
    # Dev services
    "NPM Token":            r'npm_[a-zA-Z0-9]{36}',
    "PyPI Token":           r'pypi-AgEIcHlwaS5vcmc[a-zA-Z0-9\-_]{50,}',
    "DockerHub":            r'dckr_pat_[a-zA-Z0-9_-]{27}',
    "Firebase":             r'AAAA[A-Za-z0-9_-]{7}:[A-Za-z0-9_-]{140}',
    "Heroku":               r'[hH]eroku[a-zA-Z0-9_\-]{0,20}[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}',
    "Netlify Token":        r'netlify_[a-zA-Z0-9]{40}',
    "Vercel Token":         r'(?i)vercel[_\-\s]{0,5}token[\s\S]{0,20}["\']([a-zA-Z0-9_-]{24,})',
    "Terraform Cloud":      r'[a-zA-Z0-9]{14}\.atlasv1\.[a-zA-Z0-9_=\-]{60,}',
    # Databases
    "MongoDB URI":          r'mongodb(?:\+srv)?://[^:]+:[^@]+@[^\s"\']+',
    "MySQL URI":            r'mysql://[^:]+:[^@]+@[^\s"\']+',
    "PostgreSQL URI":       r'postgres(?:ql)?://[^:]+:[^@]+@[^\s"\']+',
    "Redis URI":            r'redis://(?:[^:]+:[^@]+@)?[^\s"\']+',
    # Generic high-value
    "JWT":                  r'eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}',
    "Private Key":          r'-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----',
    "Certificate":          r'-----BEGIN CERTIFICATE-----',
    "Generic API Key":      r'(?i)(?:api[_\-]?key|apikey|api[_\-]?secret|app[_\-]?secret)["\s]*[=:]["\s]*["\']([a-zA-Z0-9_\-]{20,})["\']',
    "Generic Token":        r'(?i)(?:access[_\-]?token|auth[_\-]?token|bearer[_\-]?token)["\s]*[=:]["\s]*["\']([a-zA-Z0-9_\.\-]{20,})["\']',
    "Generic Password":     r'(?i)(?:password|passwd|pwd|secret)["\s]*[=:]["\s]*["\']([^"\']{8,})["\']',
    "Google OAuth":         r'[0-9]+-[0-9A-Za-z_]{32}\.apps\.googleusercontent\.com',
    "Alibaba AK":           r'LTAI[a-zA-Z0-9]{20}',
    "Alibaba Secret":       r'(?i)alibaba[_\-\s]{0,10}secret[\s\S]{0,20}["\']([a-zA-Z0-9]{30})',
    "Telegram Bot":         r'[0-9]{8,10}:[a-zA-Z0-9_-]{35}',
    "Linear API Key":       r'lin_api_[a-zA-Z0-9]{40}',
    "Airtable API Key":     r'key[a-zA-Z0-9]{14}',
    "Mapbox Token":         r'pk\.eyJ1IjoiW[a-zA-Z0-9\-_]+',
    "Contentful":           r'CFPAT-[a-zA-Z0-9_\-]{43}',
    "Dropbox":              r'sl\.[a-zA-Z0-9\-\_]{136}',
    "Box Token":            r'(?i)box[_\-\s]{0,5}(?:access[_\-])?token[\s\S]{0,20}["\']([a-zA-Z0-9]{32})',
    "HubSpot":              r'(?i)hubspot[_\-\s]{0,10}(?:api[_\-]?)?key[\s\S]{0,20}["\']([a-zA-Z0-9\-]{36})',
    "Shopify":              r'shpss_[a-fA-F0-9]{32}',
    "Shopify Private":      r'shpat_[a-fA-F0-9]{32}',
    "WooCommerce CK":       r'ck_[a-f0-9]{40}',
    "WooCommerce CS":       r'cs_[a-f0-9]{40}',
    "Okta Token":           r'00[a-zA-Z0-9_\-]{40}',
    "Datadog":              r'(?i)dd(?:api|app)[_\-]?key[\s\S]{0,20}["\']([a-zA-Z0-9]{32,40})',
    "New Relic":            r'NRAK-[A-Z0-9]{27}',
    "Sentry DSN":           r'https://[a-z0-9]{32}@(?:o[0-9]+\.)?sentry\.io/[0-9]+',
    "PagerDuty":            r'(?i)pagerduty[_\-\s]{0,10}(?:api[_\-]?)?key[\s\S]{0,20}["\']([a-zA-Z0-9+/_\-]{20})',
    "Cloudinary":           r'cloudinary://[0-9]+:[A-Za-z0-9_\-]+@[a-z]+',
    "Pusher":               r'(?i)pusher[_\-\s]{0,10}(?:app[_\-]?)?(?:key|secret)[\s\S]{0,20}["\']([a-zA-Z0-9]{20})',
    "Intercom":             r'(?i)intercom[_\-\s]{0,10}(?:api[_\-]?)?(?:key|token)[\s\S]{0,20}["\']([a-zA-Z0-9_]{52})',
    "Zendesk Token":        r'(?i)zendesk[_\-\s]{0,10}(?:api[_\-]?)?token[\s\S]{0,20}["\']([a-zA-Z0-9_\-/]{40})',
}

# API route patterns
API_ROUTE_PATTERNS = [
    r'["\'`](/api/v?\d*/?[a-zA-Z0-9_/\-{}]+)["\'\`]',
    r'["\'`](/v\d+/[a-zA-Z0-9_/\-{}]+)["\'\`]',
    r'["\'`](/graphql[a-zA-Z0-9_/\-]*)["\'\`]',
    r'["\'`](/auth/[a-zA-Z0-9_/\-{}]+)["\'\`]',
    r'["\'`](/user[s]?/[a-zA-Z0-9_/\-{}]+)["\'\`]',
    r'["\'`](/admin/[a-zA-Z0-9_/\-{}]+)["\'\`]',
    r'["\'`](/internal/[a-zA-Z0-9_/\-{}]+)["\'\`]',
    r'["\'`](/private/[a-zA-Z0-9_/\-{}]+)["\'\`]',
    r'["\'`](/management/[a-zA-Z0-9_/\-{}]+)["\'\`]',
    r'["\'`](/webhook[s]?/[a-zA-Z0-9_/\-{}]+)["\'\`]',
    r'path:\s*["\'`](/[a-zA-Z0-9_/\-{}?=&]+)["\'\`]',
    r'url:\s*["\'`](https?://[^\s"\'`]+)["\'\`]',
    r'endpoint:\s*["\'`](/[a-zA-Z0-9_/\-{}]+)["\'\`]',
    r'fetch\(["\'\`](https?://[^\s"\'`\)]+)',
    r'axios\.[a-z]+\(["\'\`](https?://[^\s"\'`\)]+)',
    r'\.get\(["\'\`](https?://[^\s"\'`\)]+)',
    r'\.post\(["\'\`](https?://[^\s"\'`\)]+)',
    r'\.put\(["\'\`](https?://[^\s"\'`\)]+)',
    r'\.delete\(["\'\`](https?://[^\s"\'`\)]+)',
    r'baseURL:\s*["\'`](https?://[^\s"\'`]+)["\'\`]',
    r'BASE_URL["\s]*[=:]["\s]*["\'`](https?://[^\s"\'`]+)["\'\`]',
    r'API_URL["\s]*[=:]["\s]*["\'`](https?://[^\s"\'`]+)["\'\`]',
    r'API_BASE["\s]*[=:]["\s]*["\'`](https?://[^\s"\'`]+)["\'\`]',
    r'REACT_APP_API[_A-Z]*["\s]*[=:]["\s]*["\'`](https?://[^\s"\'`]+)["\'\`]',
    r'NEXT_PUBLIC_API[_A-Z]*["\s]*[=:]["\s]*["\'`](https?://[^\s"\'`]+)["\'\`]',
    r'VUE_APP_API[_A-Z]*["\s]*[=:]["\s]*["\'`](https?://[^\s"\'`]+)["\'\`]',
]

# Interesting comment patterns
COMMENT_PATTERNS = [
    r'//\s*TODO[:\s]+(.+)',
    r'//\s*FIXME[:\s]+(.+)',
    r'//\s*HACK[:\s]+(.+)',
    r'//\s*XXX[:\s]+(.+)',
    r'//\s*password[:\s]+(.+)',
    r'//\s*token[:\s]+(.+)',
    r'//\s*key[:\s]+(.+)',
    r'/\*[\s\S]*?password[\s\S]*?\*/',
    r'/\*[\s\S]*?secret[\s\S]*?\*/',
    r'/\*[\s\S]*?internal[\s\S]*?\*/',
]

# Interesting variable names
INTERESTING_VARS = [
    r'(?:const|let|var)\s+(\w*(?:key|secret|token|pass|auth|cred|api)\w*)\s*=\s*["\']([^"\']{8,})["\']',
    r'(?:const|let|var)\s+(\w*(?:url|host|endpoint|base)\w*)\s*=\s*["\']([^"\']{10,})["\']',
    r'(?:const|let|var)\s+(\w*(?:admin|internal|private|debug)\w*)\s*=\s*(?:true|["\'][^"\']+["\'])',
]

def _minified_detect(js: str) -> bool:
    """Detect if JS is minified."""
    lines = js.split('\n')
    if not lines: return False
    avg_len = sum(len(l) for l in lines[:10]) / max(len(lines[:10]),1)
    return avg_len > 500

def _basic_beautify(js: str) -> str:
    """Basic JS beautification for analysis."""
    if not _minified_detect(js):
        return js
    # Add newlines after common statement endings
    js = re.sub(r';(?=[^\n])', ';\n', js)
    js = re.sub(r'\{(?=[^\n])', '{\n', js)
    js = re.sub(r'\}(?=[^\n])', '}\n', js)
    return js


def analyze_js(url: str, content: str = "") -> Dict:
    """
    Full JS analysis: secrets, API routes, interesting vars, comments.
    """
    result = {
        "url":      url,
        "secrets":  [],
        "routes":   [],
        "vars":     [],
        "comments": [],
        "subdomains": [],
        "emails":   [],
        "score":    0,
    }

    if not content:
        content = _get(url)
    if not content:
        return result

    js = _basic_beautify(content)

    # ── Secrets ───────────────────────────────────────────────────────────────
    for name, pattern in SECRET_PATTERNS.items():
        matches = re.findall(pattern, js)
        for match in matches[:3]:
            val = match if isinstance(match, str) else match[0] if match else ""
            if len(val) > 5:
                sev = "critical" if any(k in name for k in [
                    "AWS", "Private Key", "JWT", "Stripe Secret",
                    "GitHub PAT", "SendGrid", "GCP", "MongoDB URI",
                    "PostgreSQL", "MySQL", "Redis URI",
                ]) else "high"
                result["secrets"].append({
                    "type":    name,
                    "value":   val[:120],
                    "line":    _find_line(js, val),
                    "severity":sev,
                })
                result["score"] += 10 if sev == "critical" else 5

    # ── API Routes ────────────────────────────────────────────────────────────
    routes_seen = set()
    for pattern in API_ROUTE_PATTERNS:
        for m in re.findall(pattern, js):
            route = m if isinstance(m, str) else (m[0] if m else "")
            route = route.strip()
            if route and route not in routes_seen and len(route) > 2:
                routes_seen.add(route)
                result["routes"].append(route)
                result["score"] += 1

    # ── Interesting Variables ─────────────────────────────────────────────────
    for pattern in INTERESTING_VARS:
        for m in re.findall(pattern, js, re.IGNORECASE):
            name, val = (m[0], m[1]) if len(m) >= 2 else (m, "")
            if val and len(val) > 3:
                result["vars"].append({"name": name, "value": val[:80]})
                result["score"] += 2

    # ── Comments ──────────────────────────────────────────────────────────────
    for pattern in COMMENT_PATTERNS:
        for m in re.findall(pattern, js, re.IGNORECASE):
            comment = m.strip() if isinstance(m, str) else (m[0].strip() if m else "")
            if comment and len(comment) > 5:
                result["comments"].append(comment[:200])

    # ── Subdomains ────────────────────────────────────────────────────────────
    base_domain = _extract_base(url)
    if base_domain:
        sub_pattern = r'([a-zA-Z0-9._-]+\.' + re.escape(base_domain) + r')'
        for m in re.findall(sub_pattern, js):
            if m not in result["subdomains"] and len(m) < 100:
                result["subdomains"].append(m)

    # ── Emails ────────────────────────────────────────────────────────────────
    email_pattern = r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}'
    result["emails"] = list(set(re.findall(email_pattern, js)))[:20]

    # ── Deduplicate ───────────────────────────────────────────────────────────
    result["routes"] = list(dict.fromkeys(result["routes"]))[:100]
    result["subdomains"] = list(dict.fromkeys(result["subdomains"]))[:50]

    log.info(f"[js] {url}: {len(result['secrets'])} secrets, "
             f"{len(result['routes'])} routes, score={result['score']}")
    return result


def _find_line(content: str, value: str) -> int:
    """Find line number of a value in content."""
    try:
        idx = content.find(value[:30])
        if idx == -1: return 0
        return content[:idx].count('\n') + 1
    except: return 0


def _extract_base(url: str) -> str:
    """Extract base domain from URL."""
    try:
        host = urllib.parse.urlparse(url).netloc
        parts = host.split('.')
        if len(parts) >= 2:
            return '.'.join(parts[-2:])
    except: pass
    return ""


def analyze_all_js(endpoints: List[str], base_domain: str = "") -> List[Dict]:
    """Analyze all JS files from endpoint list."""
    js_urls = [e for e in endpoints if re.search(r'\.js(\?|#|$)', e, re.I)]
    results = []
    for url in js_urls[:100]:
        try:
            r = analyze_js(url)
            if r["score"] > 0:
                results.append(r)
        except Exception as e:
            log.debug(f"js analyze {url}: {e}")
    # Sort by score descending
    results.sort(key=lambda x: x["score"], reverse=True)
    return results


def extract_endpoints_from_js(content: str, base_url: str) -> List[str]:
    """Extract all potential API endpoints from JS content."""
    endpoints = []
    base_domain = urllib.parse.urlparse(base_url).netloc

    for pattern in API_ROUTE_PATTERNS:
        for m in re.findall(pattern, content):
            route = m if isinstance(m, str) else (m[0] if m else "")
            route = route.strip()
            if not route: continue
            if route.startswith("http"):
                endpoints.append(route)
            elif route.startswith("/"):
                scheme = urllib.parse.urlparse(base_url).scheme
                endpoints.append(f"{scheme}://{base_domain}{route}")

    return list(dict.fromkeys(endpoints))[:200]
