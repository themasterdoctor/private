"""
TheMasterRecon AI — AI Security Chat Engine
Real-time Claude-powered security assistant with full scan context injection.
"""
import os, json, ssl, urllib.request, logging, time
from typing import Optional, List, Dict

log  = logging.getLogger("elite.ai_chat")
API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL   = "claude-sonnet-4-6"

SYSTEM_PROMPT = """You are TheMasterRecon AI — an elite offensive security analyst embedded inside a live bug bounty scanner.
You have full context of the current scan: domain, findings, technology stack, WAF, exploit chains, and endpoints.
You give TACTICAL, SPECIFIC, ACTIONABLE advice. No generic security advice. No disclaimers.
You think like a top HackerOne hacker with 15 years experience.
When asked about findings, you cite exact URLs and parameters from the scan data.
Format: concise markdown. Use code blocks for payloads and commands. Max 600 tokens per reply unless asked for more."""

def _ssl():
    c = ssl.create_default_context()
    c.check_hostname = False
    c.verify_mode    = ssl.CERT_NONE
    return c

def _call_claude(messages: list, system: str = SYSTEM_PROMPT,
                 max_tokens: int = 600, stream_q=None) -> str:
    """Call Claude API with optional SSE streaming."""
    if not API_KEY:
        msg = "ANTHROPIC_API_KEY not set — add it to .env"
        if stream_q:
            stream_q.put({"type":"ai_chunk","text":msg})
        return msg

    body = json.dumps({
        "model":      MODEL,
        "max_tokens": max_tokens,
        "stream":     stream_q is not None,
        "system":     system,
        "messages":   messages,
    }).encode()

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages", data=body,
        headers={"x-api-key": API_KEY, "anthropic-version": "2023-06-01",
                 "content-type": "application/json"},
        method="POST")

    full = []
    try:
        with urllib.request.urlopen(req, timeout=120, context=_ssl()) as r:
            if stream_q:
                for raw in r:
                    line = raw.decode("utf-8","ignore").strip()
                    if not line.startswith("data:"): continue
                    ds = line[5:].strip()
                    if ds == "[DONE]": break
                    try:
                        ev = json.loads(ds)
                        chunk = ev.get("delta",{}).get("text","")
                        if chunk:
                            full.append(chunk)
                            stream_q.put({"type":"ai_chunk","text":chunk})
                    except Exception: pass
            else:
                d = json.loads(r.read())
                for block in d.get("content",[]):
                    if block.get("type") == "text":
                        return block["text"].strip()
    except Exception as e:
        log.warning(f"[ai_chat] API error: {e}")
        if stream_q:
            stream_q.put({"type":"ai_chunk","text":f"\n\n⚠ AI Error: {e}"})
    return "".join(full)


def _build_context(domain: str, findings: list, tech: list,
                   waf: str, chains: list, endpoints: int) -> str:
    """Build scan context string for injection into every message."""
    ctx = [f"CURRENT TARGET: {domain}"]
    if tech:
        ctx.append(f"TECH STACK: {', '.join(tech[:15])}")
    if waf:
        ctx.append(f"WAF DETECTED: {waf}")
    ctx.append(f"ENDPOINTS: {endpoints} discovered")
    if findings:
        crits = [f for f in findings if f.get("severity")=="critical"]
        highs = [f for f in findings if f.get("severity")=="high"]
        ctx.append(f"FINDINGS: {len(findings)} total — {len(crits)} Critical, {len(highs)} High")
        ctx.append("TOP FINDINGS:")
        for f in (crits+highs)[:8]:
            sev = f.get("severity","").upper()
            bug = f.get("bug","").upper()
            url = f.get("url","")[:80]
            poc = f.get("poc","")[:100]
            ctx.append(f"  [{sev}] {bug} @ {url}")
            if poc:
                ctx.append(f"    PoC: {poc}")
    if chains:
        ctx.append(f"EXPLOIT CHAINS ({len(chains)}):")
        for c in chains[:4]:
            ctx.append(f"  - {c.get('name','')} [{c.get('severity','')}]")
    return "\n".join(ctx)


def chat(user_msg: str, history: list, domain: str = "",
         findings: list = None, tech: list = None, waf: str = "",
         chains: list = None, endpoints: int = 0,
         stream_q=None) -> str:
    """
    Main chat function — injects full scan context into every message.
    history: list of {"role":"user/assistant","content":"..."}
    """
    findings = findings or []
    tech     = tech     or []
    chains   = chains   or []

    ctx = _build_context(domain, findings, tech, waf, chains, endpoints)

    # Build messages with context prepended to first user message
    messages = []
    for i, msg in enumerate(history[-10:]):  # keep last 10 for context
        messages.append({"role": msg["role"], "content": msg["content"]})

    # Add current message with context
    full_user = f"[SCAN CONTEXT]\n{ctx}\n\n[QUESTION]\n{user_msg}" if ctx else user_msg
    messages.append({"role":"user","content":full_user})

    return _call_claude(messages, max_tokens=800, stream_q=stream_q)


def generate_attack_plan(domain: str, findings: list, tech: list,
                         waf: str, chains: list, endpoints: int,
                         stream_q=None) -> str:
    """Generate a tactical attack plan based on all findings."""
    ctx = _build_context(domain, findings, tech, waf, chains, endpoints)

    prompt = f"""{ctx}

Generate a TACTICAL ATTACK PLAN with:

1. **Priority Attack Queue** (ranked by exploitability + impact)
   - For each: exact URL, attack vector, expected outcome, estimated time

2. **Exploit Chain Paths** (how to escalate to critical impact)
   - Step-by-step chain from your highest-confidence findings

3. **Quick Wins** (≤15 min each, ready to submit)
   - Easy P2-P3 findings that are confirmed

4. **WAF Bypass Strategy** (if WAF detected)
   - Specific bypass techniques for the detected WAF

5. **Recommended Tool Commands**
   - Exact commands to run next (sqlmap, dalfox, ffuf, etc.)

Be SPECIFIC — use exact URLs and parameters from the scan data."""

    messages = [{"role":"user","content":prompt}]
    return _call_claude(messages, max_tokens=2000, stream_q=stream_q)


def explain_finding(finding: dict, domain: str = "",
                    tech: list = None, stream_q=None) -> str:
    """Deep technical explanation of a specific finding."""
    tech = tech or []
    sev  = finding.get("severity","").upper()
    bug  = finding.get("bug","").upper()
    url  = finding.get("url","")
    poc  = finding.get("poc","")
    payload = finding.get("payload","")
    impact  = finding.get("impact","")

    prompt = f"""Analyze this security finding in depth:

**Finding:** [{sev}] {bug}
**URL:** {url}
**PoC:** {poc}
**Payload:** {payload}
**Tech Stack:** {', '.join(tech[:10]) if tech else 'Unknown'}
**Target:** {domain}

Provide:
1. **What exactly was found** (technical explanation)
2. **Exploitation steps** (exact step-by-step, ready to run)
3. **Best payload** (optimized for this specific URL/context)
4. **Maximum impact** (what an attacker can achieve)
5. **CVSS 3.1 score** with vector string
6. **One-line fix** for the developer
7. **HackerOne report title** (ready to copy-paste)"""

    messages = [{"role":"user","content":prompt}]
    return _call_claude(messages, max_tokens=1000, stream_q=stream_q)


def quick_triage(finding: dict) -> dict:
    """Fast triage scoring for a finding during live scan. Returns dict."""
    if not API_KEY:
        return {"priority":"P2","score":6.5,"tip":"Set ANTHROPIC_API_KEY for AI triage"}

    bug = finding.get("bug","").upper()
    url = finding.get("url","")
    sev = finding.get("severity","medium")
    poc = finding.get("poc","")[:200]

    prompt = f"""Rate this bug bounty finding in JSON only (no markdown, no explanation):
Bug: {bug}
URL: {url}
Severity: {sev}
PoC: {poc}

Respond with only valid JSON:
{{"priority":"P1","exploitability":9,"impact":8,"score":8.5,"tip":"one sentence","quick_win":true}}"""

    messages = [{"role":"user","content":prompt}]
    try:
        resp = _call_claude(messages, max_tokens=100)
        import re
        m = re.search(r'\{[^}]+\}', resp)
        if m:
            return json.loads(m.group())
    except Exception:
        pass
    return {"priority":"P2","score":6.0,"tip":"Manual review required"}


def generate_payloads(bug_type: str, url: str, param: str,
                      tech: list = None, waf: str = "") -> str:
    """Generate targeted payloads for a specific bug type and target."""
    tech = tech or []
    prompt = f"""Generate 10 targeted payloads for:
Bug type: {bug_type}
URL: {url}
Parameter: {param}
Tech stack: {', '.join(tech[:5]) if tech else 'Unknown'}
WAF: {waf or 'None detected'}

Format: one payload per line in a code block. Optimize for this specific tech stack.
Include WAF bypass variants if WAF is detected."""

    messages = [{"role":"user","content":prompt}]
    return _call_claude(messages, max_tokens=600)


def waf_bypass_strategy(waf_name: str, bug_type: str,
                        url: str, tech: list = None) -> str:
    """Get WAF-specific bypass strategies."""
    tech = tech or []
    prompt = f"""WAF bypass strategies for {waf_name}:
Attack type: {bug_type}
Target URL: {url}
Tech: {', '.join(tech[:5]) if tech else 'Unknown'}

Provide 5 specific bypass techniques with exact payloads. Include:
1. Encoding bypasses
2. Case variation
3. Comment injection
4. Alternative syntax
5. HTTP-level bypass (chunked encoding, method override, etc.)"""

    messages = [{"role":"user","content":prompt}]
    return _call_claude(messages, max_tokens=800)
