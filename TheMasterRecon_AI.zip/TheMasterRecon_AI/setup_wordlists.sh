#!/bin/bash
# ══════════════════════════════════════════════════════════
# TheMasterRecon — Wordlist Setup
# Installs kiterunner wordlists to ALL expected paths
# Run: chmod +x setup_wordlists.sh && ./setup_wordlists.sh
# ══════════════════════════════════════════════════════════

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "${GREEN}  ✔ $1${NC}"; }
warn() { echo -e "${YELLOW}  ⚠ $1${NC}"; }
info() { echo -e "${CYAN}  → $1${NC}"; }
fail() { echo -e "${RED}  ✗ $1${NC}"; }

# Primary path (where recon.py looks first)
PRIMARY="$HOME/Desktop/recon/kiterunner"
# Alternate path (setup_wordlists.sh legacy)
ALTERNATE="$HOME/wordlists/kiterunner"

mkdir -p "$PRIMARY" "$ALTERNATE"

dl() {
    local url="$1" dest="$2" label="$3"
    if [ -f "$dest" ] && [ "$(stat -c%s "$dest" 2>/dev/null || echo 0)" -gt 10000 ]; then
        ok "$label (already exists: $(du -sh "$dest" | cut -f1))"
        return 0
    fi
    info "Downloading $label..."
    wget -q --timeout=30 --tries=2 "$url" -O "$dest" 2>/dev/null
    if [ -s "$dest" ] && [ "$(stat -c%s "$dest")" -gt 1000 ]; then
        ok "$label ($(du -sh "$dest" | cut -f1))"
        return 0
    else
        rm -f "$dest"
        return 1
    fi
}

echo ""
echo "  TheMasterRecon — Wordlist Setup"
echo "══════════════════════════════════════════════════════"

# ── Step 1: Check what we already have ────────────────────
echo ""
echo "[*] Checking existing files..."
for f in "routes-large.kite" "routes-small.kite" "swagger-wordlist.txt" "apiroutes.txt"; do
    if [ -f "$PRIMARY/$f" ] && [ "$(stat -c%s "$PRIMARY/$f" 2>/dev/null || echo 0)" -gt 1000 ]; then
        ok "$f ($(du -sh "$PRIMARY/$f" | cut -f1)) ← in correct location"
    elif [ -f "$ALTERNATE/$f" ] && [ "$(stat -c%s "$ALTERNATE/$f" 2>/dev/null || echo 0)" -gt 1000 ]; then
        warn "$f found in ~/wordlists/kiterunner — symlinking to correct location"
        ln -sf "$ALTERNATE/$f" "$PRIMARY/$f"
        ok "$f symlinked to $PRIMARY/$f"
    else
        warn "$f — not found, will download"
    fi
done

# ── Step 2: Download missing .kite files ──────────────────
echo ""
echo "[*] Kiterunner .kite wordlists..."

for size_name in "routes-large" "routes-small"; do
    dest="$PRIMARY/${size_name}.kite"
    if [ -f "$dest" ] && [ "$(stat -c%s "$dest" 2>/dev/null || echo 0)" -gt 100000 ]; then
        ok "${size_name}.kite already present ($(du -sh "$dest" | cut -f1))"
        continue
    fi
    
    # Try multiple sources
    SOURCES=(
        "https://wordlists-cdn.assetnote.io/data/kiterunner/${size_name}.kite"
        "https://github.com/assetnote/kiterunner/releases/download/v1.0.2/${size_name}.kite"
    )
    downloaded=false
    for url in "${SOURCES[@]}"; do
        dl "$url" "$dest" "${size_name}.kite" && downloaded=true && break
    done
    
    if [ "$downloaded" = false ]; then
        warn "${size_name}.kite not available online"
        
        # Try to compile from text wordlist
        if command -v kr >/dev/null 2>&1; then
            txt_src=""
            for txt in "$PRIMARY/apiroutes.txt" "$ALTERNATE/apiroutes.txt" \
                       "/usr/share/seclists/Discovery/Web-Content/api/api-endpoints.txt" \
                       "/usr/share/wordlists/seclists/Discovery/Web-Content/api/api-endpoints.txt"; do
                [ -s "$txt" ] && txt_src="$txt" && break
            done
            if [ -n "$txt_src" ]; then
                info "Compiling ${size_name}.kite from $txt_src..."
                kr kb compile "$txt_src" -o "$dest" 2>/dev/null && \
                    ok "${size_name}.kite compiled ($(du -sh "$dest" | cut -f1))" || \
                    warn "kr kb compile failed"
            fi
        fi
    fi
done

# ── Step 3: Download text wordlists ───────────────────────
echo ""
echo "[*] API text wordlists..."

# apiroutes.txt
if ! dl "https://wordlists-cdn.assetnote.io/data/automated/httparchive_apiroutes_2023_09_28.txt" \
        "$PRIMARY/apiroutes.txt" "apiroutes.txt (CDN)"; then
    # Try SecLists
    for seclists in \
        "/usr/share/seclists/Discovery/Web-Content/api/api-endpoints.txt" \
        "/usr/share/wordlists/seclists/Discovery/Web-Content/api/api-endpoints.txt" \
        "$HOME/Desktop/recon/SecLists/Discovery/Web-Content/api/api-endpoints.txt"; do
        if [ -s "$seclists" ]; then
            cp "$seclists" "$PRIMARY/apiroutes.txt"
            ok "apiroutes.txt (from SecLists: $(du -sh "$PRIMARY/apiroutes.txt" | cut -f1))"
            break
        fi
    done
fi

# swagger
dl "https://wordlists-cdn.assetnote.io/data/automated/httparchive_swagger_all_2022_01_19.txt" \
   "$PRIMARY/swagger.txt" "swagger.txt"

# ── Step 4: Symlink to alternate path ─────────────────────
echo ""
echo "[*] Creating symlinks for alternate paths..."
for f in routes-large.kite routes-small.kite apiroutes.txt swagger-wordlist.txt swagger.txt; do
    if [ -f "$PRIMARY/$f" ] && [ ! -f "$ALTERNATE/$f" ]; then
        ln -sf "$PRIMARY/$f" "$ALTERNATE/$f"
        ok "Symlinked $f to $ALTERNATE/"
    fi
done

# ── Step 5: Summary ───────────────────────────────────────
echo ""
echo "══════════════════════════════════════════════════════"
echo "  Files in $PRIMARY:"
ls -lh "$PRIMARY/" 2>/dev/null | grep -v "^total" | awk '{print "    "$5"  "$9}'

echo ""
echo "  TheMasterRecon will automatically find:"
echo "    ✓ routes-large.kite  (183MB API routes — fastest)"
echo "    ✓ routes-small.kite  (1.8MB API routes — quick scan)"
echo "    ✓ swagger-wordlist   (28MB swagger endpoints)"
echo "    ✓ apiroutes.txt      (fallback text list)"
echo ""
echo "  Manual kr usage:"
echo "    kr scan https://target.com --routes $PRIMARY/routes-large.kite -x 20"
echo "    kr scan https://target.com --wordlist $PRIMARY/apiroutes.txt -x 20"
echo ""
