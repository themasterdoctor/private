#!/usr/bin/env bash
# BugScan ELITE — Tool Installer for Kali Linux
# Run once after unzipping: bash install_tools.sh

set -e
echo "=== BugScan ELITE Tool Installer ==="
echo ""

# Detect OS
if [ -f /etc/debian_version ]; then
    PKG="apt-get install -y"
    UPDATE="apt-get update -q"
else
    PKG="yum install -y"
    UPDATE="yum update -q"
fi

echo "[1/6] Updating package list..."
sudo $UPDATE 2>/dev/null || true

echo "[2/6] Installing system packages..."
sudo $PKG curl wget git python3-pip golang-go nmap masscan dnsutils \
          chromium chromium-driver 2>/dev/null || \
sudo $PKG curl wget git python3-pip nmap masscan dnsutils chromium 2>/dev/null || true

echo "[3/6] Installing Python packages..."
pip3 install requests flask dnspython beautifulsoup4 lxml \
             sseclient-py selenium colorama 2>/dev/null || \
pip3 install requests flask dnspython beautifulsoup4 lxml 2>/dev/null || true

echo "[4/6] Installing Go tools..."
export GOPATH=$HOME/go
export PATH=$PATH:$HOME/go/bin

GO_TOOLS=(
    "github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
    "github.com/projectdiscovery/httpx/cmd/httpx@latest"
    "github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"
    "github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"
    "github.com/projectdiscovery/katana/cmd/katana@latest"
    "github.com/hakluke/hakrawler@latest"
    "github.com/hahwul/dalfox/v2@latest"
    "github.com/tomnomnom/waybackurls@latest"
    "github.com/lc/gau/v2/cmd/gau@latest"
    "github.com/bp0lr/gauplus@latest"
    "github.com/tomnomnom/assetfinder@latest"
    "github.com/tomnomnom/anew@latest"
    "github.com/ffuf/ffuf/v2@latest"
    "github.com/OJ/gobuster/v3@latest"
)

for tool in "${GO_TOOLS[@]}"; do
    name=$(basename ${tool%@*})
    if ! command -v $name &>/dev/null; then
        echo "  Installing $name..."
        go install $tool 2>/dev/null && echo "  ✓ $name" || echo "  ✗ $name (failed)"
    else
        echo "  ✓ $name (already installed)"
    fi
done

echo "[5/6] Installing nuclei templates..."
nuclei -update-templates 2>/dev/null || true

echo "[6/6] Setting up PATH..."
PROFILE="$HOME/.bashrc"
if ! grep -q "go/bin" "$PROFILE" 2>/dev/null; then
    echo 'export PATH=$PATH:$HOME/go/bin' >> "$PROFILE"
fi

echo ""
echo "=== Installation Complete ==="
echo ""
echo "Tools installed:"
for t in subfinder httpx naabu nuclei katana hakrawler dalfox waybackurls gau gauplus ffuf gobuster nmap masscan; do
    path=$(which $t 2>/dev/null || echo "")
    [ -n "$path" ] && echo "  ✓ $t → $path" || echo "  ✗ $t (not found)"
done

echo ""
echo "Run: cd $(pwd) && ./start.sh"
