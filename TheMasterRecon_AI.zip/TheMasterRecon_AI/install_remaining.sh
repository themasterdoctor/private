#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════
# TheMasterRecon AI — Install Remaining Tools
# Specifically targets: cloudbrute, findomain, gowitness, 403jump,
#                       pacu, scoutsuite, jxscout
# Run: chmod +x install_remaining.sh && sudo ./install_remaining.sh
# ══════════════════════════════════════════════════════════════════════
set -uo pipefail
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "${GREEN}  ✔ $1${NC}"; }
warn() { echo -e "${YELLOW}  ⚠ $1${NC}"; }
fail() { echo -e "${RED}  ✗ $1${NC}"; }
info() { echo -e "${CYAN}  → $1${NC}"; }

export GOPATH="${GOPATH:-$HOME/go}"
export GOBIN="${GOBIN:-$HOME/go/bin}"
export PATH="$PATH:$GOBIN:/usr/local/go/bin:/usr/local/bin:$HOME/.local/bin"

INSTALLED=0; FAILED=0

_try_go() {
    local name="$1"; local pkg="$2"
    go install "$pkg" 2>/dev/null && ([ -f "$GOBIN/$name" ] || command -v "$name" &>/dev/null) && {
        cp "$GOBIN/$name" /usr/local/bin/ 2>/dev/null; return 0
    }
    return 1
}

_try_release() {
    local name="$1"; local repo="$2"
    ARCH=$(uname -m); [ "$ARCH" = "x86_64" ] && ARCH="amd64" || ARCH="arm64"
    TMP=$(mktemp -d)
    local URL
    URL=$(curl -s "https://api.github.com/repos/${repo}/releases/latest" 2>/dev/null | \
          grep browser_download_url | grep -i "linux.*${ARCH}\|${ARCH}.*linux" | \
          grep -v sha256 | head -1 | grep -o 'https://[^"]*' || echo "")
    [ -z "$URL" ] && { rm -rf "$TMP"; return 1; }
    wget -q --timeout=60 "$URL" -O "$TMP/dl" 2>/dev/null || { rm -rf "$TMP"; return 1; }
    # Extract
    if file "$TMP/dl" | grep -q "gzip\|tar"; then
        tar -xzf "$TMP/dl" -C "$TMP/" 2>/dev/null
    elif file "$TMP/dl" | grep -q -i "zip"; then
        unzip -q "$TMP/dl" -d "$TMP/" 2>/dev/null
    else
        # Might be raw binary
        cp "$TMP/dl" "$TMP/$name"
    fi
    local BIN=$(find "$TMP" -name "${name}*" -type f -executable 2>/dev/null | head -1)
    [ -z "$BIN" ] && BIN=$(find "$TMP" -maxdepth 3 -type f -executable 2>/dev/null | head -1)
    [ -n "$BIN" ] && cp "$BIN" "/usr/local/bin/$name" && chmod +x "/usr/local/bin/$name" && rm -rf "$TMP" && return 0
    rm -rf "$TMP"; return 1
}

_try_clone_build() {
    local name="$1"; local repo_url="$2"; local build_cmd="${3:-go build -o /usr/local/bin/$name .}"
    TMP=$(mktemp -d)
    git clone -q --depth 1 "$repo_url" "$TMP/src" 2>/dev/null || { rm -rf "$TMP"; return 1; }
    cd "$TMP/src"
    eval "$build_cmd" 2>/dev/null
    cd / && rm -rf "$TMP"
    command -v "$name" &>/dev/null && return 0 || return 1
}

echo ""
echo -e "  TheMasterRecon — Install Remaining Tools"
echo "═══════════════════════════════════════════════════════════════"

# ═══════════════════════════════════════════════════════════════
# 1. CLOUDBRUTE
# ═══════════════════════════════════════════════════════════════
echo ""
echo "[1/7] cloudbrute — Cloud bucket discovery"
if command -v cloudbrute &>/dev/null; then
    ok "cloudbrute already installed"
else
    info "Trying go install..."
    _try_go cloudbrute "github.com/0xsha/cloudbrute@latest" && ok "cloudbrute (go)" && INSTALLED=$((INSTALLED+1)) || {
        info "Trying GitHub release..."
        _try_release cloudbrute "0xsha/cloudbrute" && ok "cloudbrute (release)" && INSTALLED=$((INSTALLED+1)) || {
            info "Trying git clone + build..."
            _try_clone_build cloudbrute "https://github.com/0xsha/cloudbrute" \
                "go build -o /usr/local/bin/cloudbrute ./cmd/cloudbrute/ 2>/dev/null || go build -o /usr/local/bin/cloudbrute . 2>/dev/null" && \
                ok "cloudbrute (source)" && INSTALLED=$((INSTALLED+1)) || {
                fail "cloudbrute"
                warn "Manual: wget https://github.com/0xsha/cloudbrute/releases/latest/download/cloudbrute_Linux_amd64.tar.gz"
                warn "        tar xzf cloudbrute*.tar.gz && cp cloudbrute /usr/local/bin/"
                FAILED=$((FAILED+1))
            }
        }
    }
fi

# ═══════════════════════════════════════════════════════════════
# 2. FINDOMAIN
# ═══════════════════════════════════════════════════════════════
echo ""
echo "[2/7] findomain — Fast subdomain finder"
if command -v findomain &>/dev/null; then
    ok "findomain already installed"
else
    info "Downloading findomain release..."
    ARCH=$(uname -m)
    [ "$ARCH" = "x86_64" ] && FARCH="x86_64" || FARCH="aarch64"
    URL="https://github.com/Findomain/Findomain/releases/latest/download/findomain-linux-${FARCH}.zip"
    TMP=$(mktemp -d)
    wget -q --timeout=60 "$URL" -O "$TMP/f.zip" 2>/dev/null && \
    unzip -q "$TMP/f.zip" -d "$TMP/" 2>/dev/null && \
    BIN=$(find "$TMP" -name "findomain*" -type f 2>/dev/null | head -1) && \
    [ -n "$BIN" ] && cp "$BIN" /usr/local/bin/findomain && chmod +x /usr/local/bin/findomain && \
    ok "findomain installed" && INSTALLED=$((INSTALLED+1)) || {
        # Try direct binary URL
        wget -q --timeout=60 "https://github.com/Findomain/Findomain/releases/latest/download/findomain-linux" \
             -O /usr/local/bin/findomain 2>/dev/null && \
        chmod +x /usr/local/bin/findomain && \
        ok "findomain (binary)" && INSTALLED=$((INSTALLED+1)) || {
            fail "findomain"
            warn "Manual: wget https://github.com/Findomain/Findomain/releases/latest/download/findomain-linux -O /usr/local/bin/findomain && chmod +x /usr/local/bin/findomain"
            FAILED=$((FAILED+1))
        }
    }
    rm -rf "$TMP"
fi

# ═══════════════════════════════════════════════════════════════
# 3. GOWITNESS
# ═══════════════════════════════════════════════════════════════
echo ""
echo "[3/7] gowitness — Web screenshots"
if command -v gowitness &>/dev/null; then
    ok "gowitness already installed"
else
    info "Trying go install..."
    _try_go gowitness "github.com/sensepost/gowitness@latest" && ok "gowitness (go)" && INSTALLED=$((INSTALLED+1)) || {
        info "Trying GitHub release..."
        _try_release gowitness "sensepost/gowitness" && ok "gowitness (release)" && INSTALLED=$((INSTALLED+1)) || {
            fail "gowitness"
            warn "Manual: go install github.com/sensepost/gowitness@latest"
            FAILED=$((FAILED+1))
        }
    }
fi

# ═══════════════════════════════════════════════════════════════
# 4. 403JUMP
# ═══════════════════════════════════════════════════════════════
echo ""
echo "[4/7] 403jump — 403 bypass tool"
if command -v 403jump &>/dev/null || command -v trap-bytes &>/dev/null; then
    ok "403jump already installed"
else
    info "Trying go install..."
    _try_go 403jump "github.com/trap-bytes/403jump@latest" && ok "403jump (go)" && INSTALLED=$((INSTALLED+1)) || {
        info "Trying GitHub release..."
        _try_release 403jump "trap-bytes/403jump" && ok "403jump (release)" && INSTALLED=$((INSTALLED+1)) || {
            info "Trying clone + build..."
            _try_clone_build 403jump "https://github.com/trap-bytes/403jump" \
                "go build -o /usr/local/bin/403jump . 2>/dev/null" && \
                ok "403jump (source)" && INSTALLED=$((INSTALLED+1)) || {
                warn "403jump — byp4xx (already installed) covers 403 bypass"
                warn "Manual: go install github.com/trap-bytes/403jump@latest"
            }
        }
    }
fi

# ═══════════════════════════════════════════════════════════════
# 5. PACU
# ═══════════════════════════════════════════════════════════════
echo ""
echo "[5/7] pacu — AWS exploitation framework"
if command -v pacu &>/dev/null; then
    ok "pacu already installed"
else
    info "Trying pip3 install..."
    pip3 install pacu --break-system-packages -q 2>/dev/null && command -v pacu &>/dev/null && \
    ok "pacu (pip)" && INSTALLED=$((INSTALLED+1)) || {
        info "Trying pipx..."
        command -v pipx &>/dev/null || pip3 install pipx --break-system-packages -q 2>/dev/null
        pipx install pacu 2>/dev/null && ok "pacu (pipx)" && INSTALLED=$((INSTALLED+1)) || {
            info "Trying git clone + setup..."
            TMP=$(mktemp -d)
            git clone -q https://github.com/RhinoSecurityLabs/pacu "$TMP/pacu" 2>/dev/null && \
            pip3 install -e "$TMP/pacu" --break-system-packages -q 2>/dev/null && \
            ok "pacu (source)" && INSTALLED=$((INSTALLED+1)) || {
                fail "pacu — many deps conflict"
                warn "Try: pip3 install pacu --break-system-packages"
                warn "Or:  docker run -it rhinosecuritylabs/pacu"
                FAILED=$((FAILED+1))
            }
            rm -rf "$TMP"
        }
    }
fi

# ═══════════════════════════════════════════════════════════════
# 6. SCOUTSUITE
# ═══════════════════════════════════════════════════════════════
echo ""
echo "[6/7] scoutsuite — Multi-cloud security"
if command -v scout &>/dev/null || command -v scoutsuite &>/dev/null; then
    ok "scoutsuite already installed"
else
    info "Trying pip3 install..."
    pip3 install scoutsuite --break-system-packages -q 2>/dev/null && \
    (command -v scout &>/dev/null || command -v scoutsuite &>/dev/null) && \
    ok "scoutsuite (pip)" && INSTALLED=$((INSTALLED+1)) || {
        info "Trying pipx..."
        pipx install scoutsuite 2>/dev/null && ok "scoutsuite (pipx)" && INSTALLED=$((INSTALLED+1)) || {
            info "Trying git clone + setup..."
            TMP=$(mktemp -d)
            git clone -q https://github.com/nccgroup/ScoutSuite "$TMP/scoutsuite" 2>/dev/null && \
            pip3 install -e "$TMP/scoutsuite" --break-system-packages -q 2>/dev/null && \
            ok "scoutsuite (source)" && INSTALLED=$((INSTALLED+1)) || {
                fail "scoutsuite"
                warn "Docker: docker run -it nccgroup/scoutsuite"
                FAILED=$((FAILED+1))
            }
            rm -rf "$TMP"
        }
    }
fi

# ═══════════════════════════════════════════════════════════════
# 7. JXSCOUT (special — binary goes into app folder)
# ═══════════════════════════════════════════════════════════════
echo ""
echo "[7/7] jxscout — Advanced JS analysis"
APP_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ -f "$APP_DIR/jxscout" ] && [ -x "$APP_DIR/jxscout" ]; then
    ok "jxscout already in app dir"
elif command -v jxscout &>/dev/null; then
    cp "$(which jxscout)" "$APP_DIR/jxscout"
    ok "jxscout copied to app dir from PATH"
    INSTALLED=$((INSTALLED+1))
else
    info "Trying go install..."
    _try_go jxscout "github.com/jxscout/jxscout@latest" 2>/dev/null && {
        cp "$GOBIN/jxscout" "$APP_DIR/jxscout" 2>/dev/null || true
        ok "jxscout (go)"
        INSTALLED=$((INSTALLED+1))
    } || {
        info "Trying GitHub release..."
        _try_release jxscout "jxscout/jxscout" && {
            cp /usr/local/bin/jxscout "$APP_DIR/jxscout" 2>/dev/null || true
            ok "jxscout (release)"
            INSTALLED=$((INSTALLED+1))
        } || {
            warn "jxscout — not available from standard sources"
            warn "The app has built-in JS analysis without jxscout"
            warn "Get binary from: https://github.com/jxscout/jxscout/releases"
            warn "Place at: $APP_DIR/jxscout"
        }
    }
fi

# ═══════════════════════════════════════════════════════════════
# SYNC AND VERIFY
# ═══════════════════════════════════════════════════════════════
echo ""
echo "  Syncing Go binaries to /usr/local/bin..."
for b in "$GOBIN"/*; do
    [ -f "$b" ] && cp "$b" /usr/local/bin/ 2>/dev/null || true
done

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "  Results:"
echo ""
for tool in cloudbrute findomain gowitness 403jump pacu scoutsuite jxscout; do
    if command -v "$tool" &>/dev/null || [ -f "$APP_DIR/$tool" ]; then
        echo -e "  ${GREEN}✔ $tool${NC}"
    else
        echo -e "  ${RED}✗ $tool — still missing${NC}"
    fi
done
echo ""
echo -e "  Installed: $INSTALLED | Failed: $FAILED"
echo ""
echo "  Restart: pkill -f gunicorn && ./start.sh"
echo "═══════════════════════════════════════════════════════════════"
