# SecretHunter Binary Setup

TheMasterRecon AI has a **built-in license bypass** for SecretHunter — you do NOT need a license key.
The app automatically intercepts the license check via an internal HTTP proxy on port 19876.

## How to add the binary

1. Download the `secret_hunter` binary from the SecretHunter release page
2. Copy it to your app folder:
```bash
cp /path/to/secret_hunter /home/kali/Downloads/debug_app/bugsca123/secret_hunter
chmod +x /home/kali/Downloads/debug_app/bugsca123/secret_hunter
```
3. Restart the app — the license proxy starts automatically
4. Check status at: http://localhost:PORT/secret_hunter/status
   - `no_key_needed: true` confirms bypass is active

## What SecretHunter detects (65+ types)
- AWS / GCP / Azure credentials
- GitHub / GitLab tokens  
- Stripe / SendGrid / Mailgun API keys
- Firebase configs
- JWT tokens
- Private keys (RSA, EC, DSA)
- Slack / Discord / Telegram tokens
- And 50+ more...

## Alternative: Built-in JS analysis
Even without the binary, TheMasterRecon AI runs 3 layers of JS secret scanning:
1. Built-in regex (65+ patterns) — always active
2. SecretHunter binary (if present)
3. `engine/js_deep.py` SecretFinder (24 patterns, always active)
