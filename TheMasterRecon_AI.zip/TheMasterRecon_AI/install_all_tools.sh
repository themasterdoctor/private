#!/bin/bash
# ══════════════════════════════════════════════════════════════════════
# TheMasterRecon AI + Vigilant — Complete Tool Installer
# Covers every tool referenced by both TMR and Vigilant
# Run: chmod +x install_all_tools.sh && sudo ./install_all_tools.sh
# ══════════════════════════════════════════════════════════════════════

set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
RECON_DIR="$HOME/Desktop/recon"
TOOLS_DIR="/usr/local/bin"
export GOPATH="$HOME/go"
export GOBIN="$GOPATH/bin"
export PATH="$PATH:$GOBIN:/usr/local/go/bin"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { echo -e "${GREEN}  ✔ $1${NC}"; }
warn() { echo -e "${YELLOW}  ⚠ $1${NC}"; }
fail() { echo -e "${RED}  ✗ $1${NC}"; }
info() { echo -e "${YELLOW}[*] $1${NC}"; }

INSTALLED=0; FAILED=0
install_go_tool() {
    local pkg="$1"; local name="${2:-$(basename $pkg | cut -d@ -f1)}"
    go install "$pkg" 2>/dev/null && \
        { cp "$GOBIN/$name" "$TOOLS_DIR/" 2>/dev/null || true; ok "$name"; INSTALLED=$((INSTALLED+1)); } || \
        { fail "$name ($pkg)"; FAILED=$((FAILED+1)); }
}

echo ""
echo "  ████████╗██╗  ██╗███████╗███╗   ███╗ █████╗ "
echo "  ╚══██╔══╝██║  ██║██╔════╝████╗ ████║██╔══██╗"
echo "     ██║   ███████║█████╗  ██╔████╔██║███████║"
echo "     ██║   ██╔══██║██╔══╝  ██║╚██╔╝██║██╔══██║"
echo "     ██║   ██║  ██║███████╗██║ ╚═╝ ██║██║  ██║"
echo "     ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝╚═╝  ╚═╝"
echo "  TheMasterRecon + Vigilant — Full Tool Suite"
echo ""

# ── Go installation ──────────────────────────────────────────────────
info "Checking Go..."
if ! command -v go >/dev/null 2>&1; then
    info "Installing Go..."
    apt-get install -y golang-go 2>/dev/null || \
    (wget -q https://go.dev/dl/go1.21.0.linux-amd64.tar.gz -O /tmp/go.tar.gz && \
     rm -rf /usr/local/go && tar -C /usr/local -xzf /tmp/go.tar.gz && \
     echo 'export PATH=$PATH:/usr/local/go/bin' >> /etc/profile && \
     export PATH=$PATH:/usr/local/go/bin)
    ok "Go installed"
else
    ok "Go $(go version | cut -d' ' -f3)"
fi
mkdir -p "$GOPATH/bin"

# ── System packages ──────────────────────────────────────────────────
info "APT packages..."
apt-get update -qq 2>/dev/null || true
apt-get install -y \
    masscan massdns nikto nmap sqlmap whatweb wkhtmltopdf \
    python3-pip git curl wget ruby ruby-dev build-essential \
    libssl-dev libffi-dev python3-dev gcc make \
    npm nodejs lolcat \
    2>/dev/null || true
ok "APT packages"

# ── Ruby gems ────────────────────────────────────────────────────────
info "Ruby gems..."
gem install colorize 2>/dev/null && ok "colorize" || warn "colorize"
gem install public_suffix 2>/dev/null && ok "public_suffix" || warn "public_suffix"
# pwhois (from source — gem often fails)
if ! command -v pwhois >/dev/null 2>&1; then
    git clone -q https://github.com/Crosse/pwhois /tmp/pwhois 2>/dev/null && \
        cd /tmp/pwhois && gem build pwhois.gemspec 2>/dev/null && \
        gem install pwhois-*.gem 2>/dev/null && ok "pwhois" || warn "pwhois (manual: gem install pwhois)"
fi

# ── Python tools ─────────────────────────────────────────────────────
info "Python tools..."
PIP="pip3 install --break-system-packages -q"

# Core scanning libs
$PIP arjun dirsearch ghauri paramspider s3scanner wfuzz 2>/dev/null && ok "arjun/dirsearch/ghauri/paramspider/s3scanner/wfuzz" || warn "some pip tools failed"

# Vigilant dependencies
$PIP \
    mysql-connector-python requests-toolbelt grequests requests-futures \
    iptools python-crontab jsbeautifier Cerberus pymongo selenium \
    logutils 2>/dev/null && ok "Vigilant Python deps" || warn "some Vigilant deps failed"

# Security tools
$PIP \
    detect-secrets trufflehog 2>/dev/null && ok "detect-secrets/trufflehog" || warn "detect-secrets"

# libnmap (for Vigilant's nmap integration)
$PIP python-libnmap 2>/dev/null && ok "python-libnmap" || warn "python-libnmap"

# Altdns (subdomain permutation — used by Vigilant)
$PIP altdns 2>/dev/null && ok "altdns" || warn "altdns"

# CORScanner (used by Vigilant Cors module)
if [ ! -d "$RECON_DIR/CORScanner" ]; then
    git clone -q https://github.com/chenjj/CORScanner "$RECON_DIR/CORScanner" 2>/dev/null && \
        pip3 install --break-system-packages -q -r "$RECON_DIR/CORScanner/requirements.txt" 2>/dev/null && \
        ok "CORScanner" || warn "CORScanner"
fi

# retire (JS vulnerability scanner)
npm install -g retire 2>/dev/null && ok "retire.js" || warn "retire.js"
npm install -g broken-link-checker 2>/dev/null && ok "broken-link-checker" || warn "broken-link-checker"

# ── ProjectDiscovery tools ───────────────────────────────────────────
info "ProjectDiscovery suite..."
install_go_tool "github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"     subfinder
install_go_tool "github.com/projectdiscovery/httpx/cmd/httpx@latest"               httpx
install_go_tool "github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"          nuclei
install_go_tool "github.com/projectdiscovery/katana/cmd/katana@latest"             katana
install_go_tool "github.com/projectdiscovery/dnsx/cmd/dnsx@latest"                dnsx
install_go_tool "github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"           naabu
install_go_tool "github.com/projectdiscovery/alterx/cmd/alterx@latest"            alterx
install_go_tool "github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest"    shuffledns
install_go_tool "github.com/projectdiscovery/asnmap/cmd/asnmap@latest"           asnmap
install_go_tool "github.com/projectdiscovery/cdncheck/cmd/cdncheck@latest"       cdncheck
install_go_tool "github.com/projectdiscovery/tlsx/cmd/tlsx@latest"               tlsx
install_go_tool "github.com/projectdiscovery/uncover/cmd/uncover@latest"         uncover
install_go_tool "github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest" interactsh-client
install_go_tool "github.com/projectdiscovery/notify/cmd/notify@latest"           notify
install_go_tool "github.com/projectdiscovery/chaos-client/cmd/chaos@latest"      chaos

# ── Tomnomnom tools ──────────────────────────────────────────────────
info "Tomnomnom tools..."
install_go_tool "github.com/tomnomnom/assetfinder@latest"   assetfinder
install_go_tool "github.com/tomnomnom/waybackurls@latest"   waybackurls
install_go_tool "github.com/tomnomnom/httprobe@latest"      httprobe
install_go_tool "github.com/tomnomnom/anew@latest"          anew
install_go_tool "github.com/tomnomnom/qsreplace@latest"     qsreplace
install_go_tool "github.com/tomnomnom/gf@latest"            gf
install_go_tool "github.com/lc/subjs@latest"                subjs
install_go_tool "github.com/tomnomnom/unfurl@latest"        unfurl

# ── XSS / Injection tools ────────────────────────────────────────────
info "XSS + injection tools..."
install_go_tool "github.com/hahwul/dalfox/v2@latest"       dalfox
install_go_tool "github.com/Emoe/kxss@latest"              kxss
install_go_tool "github.com/ryandamour/ssrfuzz@latest"     ssrfuzz
install_go_tool "github.com/dwisiswant0/crlfuzz/cmd/crlfuzz@latest" crlfuzz

# ── Directory fuzzing ────────────────────────────────────────────────
info "Directory + parameter tools..."
install_go_tool "github.com/ffuf/ffuf/v2@latest"            ffuf
install_go_tool "github.com/OJ/gobuster/v3@latest"          gobuster
install_go_tool "github.com/ferreiraklet/Jeeves@latest"     jeeves 2>/dev/null || true
install_go_tool "github.com/bp0lr/gauplus@latest"           gauplus
install_go_tool "github.com/lc/gau/v2/cmd/gau@latest"      gau

# ── Recon tools ──────────────────────────────────────────────────────
info "Recon + discovery tools..."
install_go_tool "github.com/jaeles-project/gospider@latest"     gospider
install_go_tool "github.com/hakluke/hakrawler@latest"           hakrawler
install_go_tool "github.com/sa7mon/s3scanner@latest"            s3scanner
install_go_tool "github.com/sensepost/gowitness@latest"         gowitness
install_go_tool "github.com/gitleaks/gitleaks/v8@latest"        gitleaks
install_go_tool "github.com/assetnote/kiterunner/cmd/kr@latest" kr
install_go_tool "github.com/d3mondev/puredns/v2@latest"         puredns

# ── Subdomain takeover ───────────────────────────────────────────────
info "Subdomain takeover tools..."
install_go_tool "github.com/haccer/subjack@latest"          subjack
# tko-subs (Vigilant uses this)
if [ ! -f "$TOOLS_DIR/tko-subs" ]; then
    go install github.com/anshumanbh/tko-subs@latest 2>/dev/null && \
        cp "$GOBIN/tko-subs" "$TOOLS_DIR/" 2>/dev/null && ok "tko-subs" || warn "tko-subs"
fi

# ── 403 bypass ───────────────────────────────────────────────────────
info "403 bypass tools..."
install_go_tool "github.com/iamj0ker/bypass-403@latest"     bypass-403 bypass-403
# byp4xx (used by Vigilant Access_Denied module)
if [ ! -f "$TOOLS_DIR/byp4xx" ]; then
    go install github.com/lobuhi/byp4xx@latest 2>/dev/null && \
        cp "$GOBIN/byp4xx" "$TOOLS_DIR/" 2>/dev/null && ok "byp4xx" || warn "byp4xx"
fi

# ── Wordlists and repos ──────────────────────────────────────────────
info "Setting up recon directory: $RECON_DIR"
mkdir -p "$RECON_DIR"

# SecLists — critical for dns_brute and directory fuzzing
if [ ! -d "$RECON_DIR/SecLists" ]; then
    info "Cloning SecLists (~500MB, this will take a few minutes)..."
    git clone -q --depth=1 https://github.com/danielmiessler/SecLists "$RECON_DIR/SecLists" && \
        ok "SecLists" || warn "SecLists clone failed — retry: git clone https://github.com/danielmiessler/SecLists ~/Desktop/recon/SecLists"
else
    ok "SecLists (already present)"
fi

# Nuclei templates
if [ ! -d "$RECON_DIR/nuclei-templates" ]; then
    git clone -q --depth=1 https://github.com/projectdiscovery/nuclei-templates "$RECON_DIR/nuclei-templates" && \
        ok "nuclei-templates" || warn "nuclei-templates"
else
    ok "nuclei-templates (already present)"
fi

# Vigilant-specific repos
info "Cloning Vigilant support repos..."

clone_repo() {
    local name="$1"; local url="$2"
    if [ ! -d "$RECON_DIR/$name" ]; then
        git clone -q --depth=1 "$url" "$RECON_DIR/$name" 2>/dev/null && ok "$name" || warn "$name"
    else
        ok "$name (present)"
    fi
}

clone_repo "aws-s3-bucket-wordlist" "https://github.com/koaj/aws-s3-bucket-wordlist"
clone_repo "gitGraber"              "https://github.com/hisxo/gitGraber"
clone_repo "LinkFinder"             "https://github.com/GerbenJavado/LinkFinder"
clone_repo "git-hound"              "https://github.com/tillson/git-hound"
clone_repo "altdns"                 "https://github.com/infosec-au/altdns"
clone_repo "dirsearch"              "https://github.com/maurosoria/dirsearch"
clone_repo "changeme"               "https://github.com/ztgrace/changeme"
clone_repo "dvcs-ripper"            "https://github.com/kost/dvcs-ripper"
clone_repo "subjack"                "https://github.com/haccer/subjack"
clone_repo "Gf-Patterns"            "https://github.com/1ndianl33t/Gf-Patterns"

# GF patterns setup
if [ -d "$RECON_DIR/Gf-Patterns" ]; then
    mkdir -p "$HOME/.gf"
    cp "$RECON_DIR/Gf-Patterns/"*.json "$HOME/.gf/" 2>/dev/null && ok "GF patterns installed" || warn "GF patterns"
fi

# BBTz scripts (used in JS analysis)
info "Downloading BBTz scripts..."
for script in getsrc.py collector.py getjswords.py antiburl.py jsbeautify.py availableForPurchase.py; do
    if [ ! -f "$RECON_DIR/$script" ]; then
        wget -q "https://raw.githubusercontent.com/m4ll0k/BBTz/master/$script" \
            -O "$RECON_DIR/$script" 2>/dev/null && ok "$script" || warn "$script"
    fi
done

# gitdorks.sh
cp /mnt/user-data/uploads/gitdorks.sh "$RECON_DIR/gitdorks.sh" 2>/dev/null || \
    wget -q "https://raw.githubusercontent.com/eslam3kl/3klector/master/gitdorks.sh" \
        -O "$RECON_DIR/gitdorks.sh" 2>/dev/null || true
chmod +x "$RECON_DIR/gitdorks.sh" 2>/dev/null || true
ok "gitdorks.sh"

# ── Vigilant framework ───────────────────────────────────────────────
info "Setting up Vigilant framework..."
VIGILANT_DIR="/root/vigilant"
mkdir -p "$VIGILANT_DIR/scripts"

if [ -f "/mnt/user-data/uploads/vigilant__2_.rb" ]; then
    cp "/mnt/user-data/uploads/vigilant__2_.rb"  "$VIGILANT_DIR/vigilant.rb"
    cp "/mnt/user-data/uploads/functions__2_.rb" "$VIGILANT_DIR/scripts/functions.rb"
    chmod +x "$VIGILANT_DIR/vigilant.rb"
    # Create wrapper
    cat > /usr/local/bin/vigilant << 'WRAPPER'
#!/bin/bash
cd /root/vigilant && ruby vigilant.rb "$@"
WRAPPER
    chmod +x /usr/local/bin/vigilant
    ok "Vigilant installed → /root/vigilant/ (run: vigilant --help)"
else
    warn "Upload vigilant.rb and functions.rb to install Vigilant"
fi

# ── Subjack fingerprints ─────────────────────────────────────────────
if command -v subjack >/dev/null 2>&1; then
    SUBJACK_DIR="/root/vigilant"
    mkdir -p "$SUBJACK_DIR"
    if [ ! -f "$SUBJACK_DIR/fingerprints.json" ]; then
        wget -q "https://raw.githubusercontent.com/haccer/subjack/master/fingerprints.json" \
            -O "$SUBJACK_DIR/fingerprints.json" 2>/dev/null && ok "subjack fingerprints" || warn "subjack fingerprints"
    fi
fi

# ── Copy all Go bins to /usr/local/bin ───────────────────────────────
info "Copying Go binaries to $TOOLS_DIR..."
for src in "$GOBIN"/* "$HOME/go/bin"/* "/root/go/bin"/* "/home/kali/go/bin"/*; do
    [ -f "$src" ] && cp "$src" "$TOOLS_DIR/" 2>/dev/null || true
done
ok "Binaries copied"

# ── nuclei templates update ──────────────────────────────────────────
info "Updating nuclei templates..."
nuclei -update-templates 2>/dev/null || true

# ── Final report ─────────────────────────────────────────────────────
echo ""
echo "══════════════════════════════════════════════════════"
echo "  Installation Summary"
echo "══════════════════════════════════════════════════════"

CORE_TOOLS="subfinder amass httpx katana nuclei ffuf sqlmap dalfox nmap masscan \
            trufflehog gitleaks gowitness anew qsreplace gf waybackurls gau \
            dnsx subjack crlfuzz ssrfuzz gospider puredns shuffledns \
            assetfinder httprobe subjs alterx asnmap naabu s3scanner \
            interactsh-client byp4xx kxss chaos uncover"

READY=0; MISSING=()
for tool in $CORE_TOOLS; do
    if command -v "$tool" >/dev/null 2>&1; then
        READY=$((READY+1))
    else
        MISSING+=("$tool")
    fi
done

TOTAL=$(echo "$CORE_TOOLS" | wc -w)
echo -e "  ${GREEN}Tools ready: $READY/$TOTAL${NC}"

if [ ${#MISSING[@]} -gt 0 ]; then
    echo -e "  ${YELLOW}Missing: ${MISSING[*]}${NC}"
fi

echo ""
echo "  Recon workspace: $RECON_DIR"
echo "  SecLists: $([ -d "$RECON_DIR/SecLists" ] && echo '✅' || echo '❌ run: git clone https://github.com/danielmiessler/SecLists ~/Desktop/recon/SecLists')"
echo "  Nuclei templates: $([ -d "$RECON_DIR/nuclei-templates" ] && echo '✅' || echo '❌')"
echo "  GF patterns: $([ -f "$HOME/.gf/xss.json" ] && echo '✅' || echo '⚠ run: mkdir ~/.gf && cp ~/Desktop/recon/Gf-Patterns/*.json ~/.gf/')"
echo "  Vigilant: $(command -v vigilant >/dev/null 2>&1 && echo '✅ run: vigilant --help' || echo '⚠ copy vigilant.rb + functions.rb to /root/vigilant/')"
echo ""
echo "  Next: edit .env with your API keys, then ./start.sh"
echo "══════════════════════════════════════════════════════"
