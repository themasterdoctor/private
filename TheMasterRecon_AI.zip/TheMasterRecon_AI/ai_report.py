"""BugScan PRO — AI Report Generator"""
import os, json, time, logging, urllib.request
log = logging.getLogger("bugscan.ai")
API_KEY = os.environ.get("ANTHROPIC_API_KEY","")
MODEL   = "claude-sonnet-4-20250514"

def generate_report(payload):
    if not API_KEY:
        return _template(payload)
    try:
        body = json.dumps({
            "model": MODEL, "max_tokens": 4096,
            "system": "You are an elite penetration tester. Write a professional security report in Markdown with CVSS scores, PoC steps, and remediation for each finding. Be technical and precise.",
            "messages": [{"role":"user","content":_prompt(payload)}],
        }).encode()
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages", data=body,
            headers={"x-api-key":API_KEY,"anthropic-version":"2023-06-01",
                     "content-type":"application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=120) as r:
            d = json.loads(r.read())
            for block in d.get("content",[]):
                if block.get("type")=="text": return block["text"]
    except Exception as e:
        log.error(f"AI report: {e}")
    return _template(payload)

def _prompt(p):
    domain   = p.get("domain","")
    findings = p.get("findings",[])
    crits    = [f for f in findings if f.get("severity")=="critical"]
    highs    = [f for f in findings if f.get("severity")=="high"]
    meds     = [f for f in findings if f.get("severity")=="medium"]
    def fmt(f):
        d = f.get("details",{})
        return f"- **{f.get('type','').upper()}** @ `{f.get('url','')}` — {d.get('description','')[:200]}"
    return f"""Generate a comprehensive penetration test report for {domain}.

Target: {domain}
Subdomains: {p.get('subcount',0)} | Live: {p.get('activecount',0)} | Endpoints: {p.get('endcount',0)}
Tech: {', '.join(p.get('tech',[])[:10])}

Findings: {len(crits)} critical, {len(highs)} high, {len(meds)} medium

CRITICAL:
{chr(10).join(fmt(f) for f in crits[:10]) or 'None'}

HIGH:
{chr(10).join(fmt(f) for f in highs[:10]) or 'None'}

Write: Executive Summary, Attack Surface, Critical Findings (with CVSS, PoC, curl commands, remediation), High Findings, Remediation Roadmap. Format for bug bounty submission."""

def _template(p):
    domain   = p.get("domain","")
    findings = p.get("findings",[])
    ts       = time.strftime("%Y-%m-%d %H:%M UTC")
    crits    = [f for f in findings if f.get("severity")=="critical"]
    highs    = [f for f in findings if f.get("severity")=="high"]
    meds     = [f for f in findings if f.get("severity")=="medium"]
    lows     = [f for f in findings if f.get("severity") not in ("critical","high","medium")]
    risk     = "CRITICAL" if crits else "HIGH" if highs else "MEDIUM" if meds else "LOW"

    def block(f, i):
        d   = f.get("details",{})
        sev = f.get("severity","").upper()
        cvss= {"critical":"9.0–10.0","high":"7.0–8.9","medium":"4.0–6.9"}.get(f.get("severity",""),"—")
        b = f"""
### {i}. {f.get('type','').upper()} — `{f.get('url','')}`
| Field | Value |
|-------|-------|
| **Severity** | {sev} |
| **CVSS** | {cvss} |
| **URL** | `{f.get('url','')}` |
| **Template** | `{d.get('template','')}` |

**Description**: {d.get('description','Vulnerability detected.')}
"""
        if d.get("extracted"): b += f"\n**Extracted**: `{d['extracted'][:300]}`\n"
        if d.get("curl"):      b += f"\n**PoC**:\n```bash\n{d['curl'][:500]}\n```\n"
        if d.get("preview"):   b += f"\n**Preview**: `{d['preview'][:200]}`\n"
        b += f"\n**Remediation**: {d.get('remediation','Review and patch the affected component.')}\n"
        return b

    crit_sec = "\n".join(block(f,i+1) for i,f in enumerate(crits[:15]))
    high_sec = "\n".join(block(f,i+1) for i,f in enumerate(highs[:15]))
    med_rows = "\n".join(f"| {f.get('type','').upper()} | `{f.get('url','')[:80]}` | {f.get('severity','').upper()} |" for f in meds[:20])

    return f"""# Security Assessment Report — {domain}
**Date**: {ts} | **Risk**: {risk}

---
## Executive Summary
Assessment of **{domain}**: **{len(findings)} total findings** — **{len(crits)} critical**, **{len(highs)} high**, **{len(meds)} medium**.

| Metric | Count |
|--------|-------|
| Subdomains | {p.get('subcount',0)} |
| Live Hosts | {p.get('activecount',0)} |
| Endpoints | {p.get('endcount',0)} |
| Critical | **{len(crits)}** |
| High | **{len(highs)}** |
| Medium | **{len(meds)}** |
| Low/Info | **{len(lows)}** |

---
## Tech Stack
{', '.join(p.get('tech',[])[:20]) or 'Unknown'}

---
## Critical Findings
{crit_sec or '_None_'}

---
## High Findings
{high_sec or '_None_'}

---
## Medium Findings
| Type | URL | Severity |
|------|-----|----------|
{med_rows or '| — | None | — |'}

---
## Remediation Roadmap
- **Immediate (0–7d)**: Patch all critical findings
- **Short-term (7–30d)**: Address high severity, review API endpoints
- **Mid-term (30–90d)**: WAF rules, CSP headers, security headers audit

---
*Generated by BugScan PRO · {ts}*
> Set `ANTHROPIC_API_KEY` for AI-enhanced reports.
""".strip()
