require 'socket'
require 'colorize'
require 'public_suffix'
require 'etc'

home = "/home/"+Etc.getlogin

class Cron
  def cron_save(vigilant_path,project,domain,cron_output,username,final_subdomains,home,github_wordlist)
    system("crontab -l > #{cron_output}")
    system("echo \"*/5 * * * * sudo -u #{username} subfinder -d #{domain} -t 100 | sort -u | grep -v '\\\\' | anew #{final_subdomains} | httprobe -c 50 | notify\" >> #{cron_output}")
    system("echo \"*/5 * * * * assetfinder --subs-only #{domain} | sort -u | grep -v '\\\\' | anew #{final_subdomains} | httprobe | notify\" >> #{cron_output}")
    system("echo \"*/5 * * * * curl -s \\\"https://crt.sh/?q=%.#{domain}&output=json\\\" | jq '.[].name_value' | sed 's/\\\"//g' | sed 's/\*\.//g' | sort -u | grep -v '\\\\' | anew #{final_subdomains} | httprobe | notify\" >> #{cron_output}")
    system("echo \"*/5 * * * * curl -s \\\"https://api.certspotter.com/v1/issuances?domain=#{domain}&expand=dns_names&expand=issuer\\\" | jq '.[].dns_names[]' | sed 's/\\\"//g' | sed 's/\*\.//g' | sort -u | grep -v '\\\\' | anew #{final_subdomains} | httprobe | notify\" >> #{cron_output}")
    system("echo \"*/30 * * * * /usr/bin/python3 #{home}/Desktop/recon/gitGraber/gitGraber.py -q \\\"\\\"#{domain}\\\"\\\" -s -k #{github_wordlist}\" >> #{cron_output}")
    system("sudo crontab #{cron_output}")
    system("rm #{cron_output}")
  end
  
  def cron_execute(username,domain,final_subdomains)
    system("sudo -u #{username} subfinder -d #{domain} -t 100 | sort -u | grep -v '\\\\' | anew #{final_subdomains} | httprobe -c 50 | notify")
    system("assetfinder --subs-only #{domain} | sort -u | grep -v '\\\\' | anew #{final_subdomains} | httprobe -c 50 | notify")
    system("curl -s \"https://crt.sh/?q=%.#{domain}&output=json\" | jq '.[].name_value' | sed 's/\"//g' | sed 's/\*\.//g' | sort -u | grep -v '\\\\' | anew #{final_subdomains} | httprobe -c 50 | notify")
  system("curl -s \"https://api.certspotter.com/v1/issuances?domain=#{domain}&expand=dns_names&expand=issuer\" | jq '.[].dns_names[]' | sed 's/\"//g' | sed 's/\*\.//g' | sort -u | grep -v '\\\\' | anew #{final_subdomains} | httprobe -c 50 | notify")
  end
end

class Subdomain_Bruteforce
  def start(spf_path,final_subdomains,final_ips,sub_list,sub_path,username,domain,threads,workflow,root_domain,output,findomain_config,cloudflare_token,cloudflare_email,censys_api_key,censys_api_secret,wordlist,all,home,resolvers,amass_config)
    Subdomain_Bruteforce.new.subfinder(username,domain,threads,workflow,root_domain,output,all,sub_list)
     #Subdomain_Bruteforce.new.asset_finder(username,domain,threads,workflow,root_domain,output,all,sub_list)
    #Subdomain_Bruteforce.new.crt(username,domain,threads,workflow,root_domain,output,all,sub_list,sub_path)
   #Subdomain_Bruteforce.new.censys(home,username,domain,threads,workflow,root_domain,output,all,sub_list,censys_api_key,censys_api_secret)
    #Subdomain_Bruteforce.new.cfenum(home,username,domain,threads,workflow,root_domain,output,all,sub_list,cloudflare_token,cloudflare_email,sub_path,spf_path,final_subdomains,final_ips)
    
    #Subdomain_Bruteforce.new.parse(workflow,root_domain,sub_path,spf_path,final_subdomains,final_ips)
   
  end

  def subfinder(username,domain,threads,workflow,root_domain,output,all,sub_list)
    puts "#{'[!] Subfinder Started...'.light_blue}"
    if all == true
      line_num=0
      text=File.open("#{sub_list}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
          
        line_new = line.strip
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        if File.file?("#{output}/#{line_new}/subfinder.txt")
          puts("#{'[*] Already Scanned'.red}")
        else
          system("mkdir -p #{output}/#{line_new}")
          system("sudo -u #{username} subfinder -d #{line_new} -t #{threads} | sort -u | anew #{output}/#{line_new}/subfinder.txt")
        end
      end
    else
        system("mkdir -p #{output}/#{domain}")
        system("sudo -u #{username} subfinder -d #{domain} -t #{threads} | anew #{output}/#{domain}/subfinder.txt")
        puts "#{'[*] Subfinder Ended...'.cyan}"
    end
  end
  
  def aquatone_discover(username,domain,threads,workflow,root_domain,all) 
    puts "#{'[!] Aquatone-Discover Started...'.light_blue}"
    system("aquatone-discover -d #{domain} -t #{threads}")
    puts
    puts "#{'[*] Aquatone-Discover Ended...'.cyan}"
  end
  
  def passive(domain,home) 
    nuclei_templates = "#{home}/Desktop/recon/nuclei-templates/"
    system("while true; do subfinder -d #{domain} | httprobe -c 50 | nuclei -t #{nuclei_templates} | notify ; sleep 3600; done")
  end
  
  def gau(home,username,domain,threads,workflow,root_domain,output,all,sub_list,sub_path)
    if all == true
      puts "#{'[!] GAU Started...'.light_blue}"
  
      line_num=0
      text=File.open("#{sub_list}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
  
        line_new = line.strip
  
        puts("#{'[*] Executing on '}#{line_new}".yellow)
  
        system("mkdir -p #{output}/#{line_new}")
        system("gau -subs #{line_new} | cut -d / -f 3 | sed 's/:.*//' | sed 's/\\\.*//' | sed 's/\\/.*//' | sort -u | anew #{sub_path}/raw/#{line_new}/gau.txt")
      end
    else
      puts "#{'[!] GAU Started...'.light_blue}"
      system("gau -subs #{domain} | cut -d / -f 3 | sed 's/:.*//' | sed 's/\\\.*//' | sed 's/\\/.*//' | sort -u | anew #{sub_path}/raw/#{domain}/gau.txt")
    end
  end
  
  def parse(workflow,root_domain,sub_path,spf_path,subdomains,ips,sub_raw)
    puts "#{'[+] Combining Information...'.light_blue}"
    puts "#{'[*] Searching Subdomains...'.cyan}"
    system("cat #{sub_raw}/*.txt | perl -n -e '\/\\b\\S+\\.(com|org|edu|net|eu)\\b\/ && print $&,\"\\n\"; ' | sort -u | qsreplace | /usr/local/bin/httpx | cut -d : -f2 | cut -c 3- | sort -u | anew #{subdomains}")
  
    if File.file?("#{sub_raw}/cfenum.json")
      system("cat #{sub_raw}/cfenum.json | grep -Po '\"subdomain\":.*?[^\\\\]\",' | perl -n -e '\/\\b\\S+\\.(com|org|edu|net|eu)\\b\/ && print $&,\"\\n\"; ' | grep -v '\\\\' | qsreplace | /usr/local/bin/httpx | cut -d : -f2 | cut -c 3- | sort -u | anew #{subdomains}")
  
      system("cat #{sub_raw}/cfenum.json | grep -Po '\"IP\":.*?[^\\\\]\",' | perl -n -e '\/\\b\\S+\\.(com|org|edu|net|eu)\\b\/ && print $&,\"\\n\"; ' | grep -v '\\\\' | qsreplace | /usr/local/bin/httpx | cut -d : -f2 | cut -c 3- | sort -u | grep -v '\\\\' | anew #{subdomains}")
    end
    
    if File.file?("#{sub_raw}/*#{root_domain}*.json")
      system("cat #{sub_raw}/*#{root_domain}*.json | perl -n -e '\/\\b\\S+\\.(com|org|edu|net|eu)\\b\/ && print $&,\"\\n\"; ' | sort -u | qsreplace | /usr/local/bin/httpx | cut -d : -f2 | cut -c 3- | sort -u | anew #{subdomains}")
    end
  
    puts "#{'[*] Searching IPs...'.cyan}"
  
    system("cat #{sub_raw}/*.txt | grep -oE \"\\b([0-9]{1,3}\\.){3}[0-9]{1,3}\\b\" | qsreplace | /usr/local/bin/httpx | cut -d : -f2 | cut -c 3- | sort -u | anew #{ips}")
    if File.file?("#{sub_path}/raw/*/cfenum.json")
      system("cat #{sub_raw}/cfenum.json | grep -Po '\"IP\":.*?[^\\\\]\",' | grep -oE \"\\b([0-9]{1,3}\\.){3}[0-9]{1,3}\\b\" | sed '/^$/d' | qsreplace | /usr/local/bin/httpx | cut -d : -f2 | cut -c 3- | sort -u | anew #{ips}")
    
    if File.file?("#{sub_raw}/*#{root_domain}*.json")
      system("cat #{sub_raw}/*#{root_domain}*.json | grep -oE \"\\b([0-9]{1,3}\\.){3}[0-9]{1,3}\\b\" | sort -u | qsreplace | /usr/local/bin/httpx | cut -d : -f2 | cut -c 3- | sort -u | anew #{ips}")
    end
      
    system("cat #{subdomains} | grep -v #{root_domain} | grep -v amazonaws.com | sort -u | anew #{workflow}/root-domains.txt")
    system("cat #{subdomains} | grep amazonaws.com | perl -n -e '/\\b\\S+\\.(com|org|edu|net|eu)\\b/ && print $&,\"\\n\"; ' | sed 's/\\\.amazonaws.com//' | sort -u | anew #{aws_path}/s3-buckets.txt")
    end
  
    puts "#{'[*] Mixing Everything... Done'.cyan}"
  end

end

class Resolve_Hosts
  def start(resolvers,final_subdomains,final_ips,wordlist_path,sub_path,ip_path,home)
    puts "#{'[!] MassDNS Started...'.light_blue}"
  
    system("cat #{final_subdomains} | sort -u | sed '/^$/d' | sort -u | anew #{sub_path}/wl-subdomains.txt")
  
    system("#{home}/Desktop/recon/massdns/bin/massdns -r #{resolvers} -q -t A -o S -w #{ip_path}/massdns.raw #{sub_path}/wl-subdomains.txt")
  
    system("cat #{ip_path}/massdns.raw | grep -e ' A ' |  cut -d 'A' -f 1 | tr -d ' ' | sed 's/.$//' | sort -u | anew #{sub_path}/massdns.txt")
  
    system("cat #{ip_path}/massdns.raw | grep -e ' A ' |  cut -d 'A' -f 2 | tr -d ' ' | sort -u | anew #{ip_path}/massdns.txt")
  
    system("cat #{ip_path}/*.txt | sort -V | sed 's/https:\\/\\///' | sed 's/http:\\/\\///' | sort -u | anew #{final_ips}")
    system("cat #{sub_path}/massdns.txt | sort -u | grep -v '\\\\' | anew #{final_subdomains}")
  
  puts "#{'[*] MassDNS Ended...'.cyan}"
  end
end

class Port_Scan
  def start(final_ips,final_masscan,portscan_path,home,final_subdomains,final_nmap)
    puts "#{'[*] Port Scanning...'.light_blue}"
    puts "#{'[!] Masscan Started...'.light_blue}"
    
    if File.file?("#{portscan_path}/masscan.xml")
    else
     system("masscan -p 1-65535 --rate 10000 --wait 0 --open -iL #{final_ips} -oX #{portscan_path}/masscan.xml")
      system("xsltproc -o #{final_masscan} #{home}/Desktop/recon/nmap-bootstrap-xsl/nmap-bootstrap.xsl #{portscan_path}/masscan.xml")
    end
    open_ports = `cat #{portscan_path}/masscan.xml | grep portid | cut -d "\\"" -f 10 | sort -n | uniq | paste -s | sed -e 's/\\s\\+/,/g'`
    puts "#{'[*] Masscan Ended...'.cyan}"
    puts("#{'[*] HTML Report on '.yellow}#{final_masscan}".yellow)
  
    puts "#{'[*] Service Enumeration...'.light_blue}"
    puts "#{'[!] Nmap Started...'.light_blue}"
  
    system("nmap -sVC -p #{open_ports.strip} -v -T4 -Pn -iL #{final_subdomains} -oX #{portscan_path}/nmap.xml")
    system("xsltproc -o #{final_nmap} #{portscan_path}/nmap.xml")
    puts "#{'[*] Nmap Ended...'.cyan}"
    puts("#{'[*] HTML Report on '.yellow}#{final_nmap}".yellow)
  end
end

class Port_Scan_New
  def start(portscan_path,home,final_subdomains,domain,all)
    puts "#{'[!] Port Scanning...'.light_blue}"
    puts "#{'[*] Nmap'.cyan}"
    system("mkdir -p #{portscan_path}/raw")
    system("touch #{portscan_path}/ports-scan.txt")
    if all == true
      line_num=0
      text=File.open("#{final_subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
        line_new = line.strip
        
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        if File.file?("#{portscan_path}/raw/#{line_new}.txt")
          puts "#{'[*] Already Scanned'.red}"
        else
          system("nmap -T4 #{line_new} | sed '/^\\(Nmap scan\\|PORT\\|[0-9]\\)/!d' | tee -a #{portscan_path}/raw/#{line_new}.txt")
          system("if grep \" #{line_new}\" #{portscan_path}/ports-scan.txt 
then touch #{portscan_path}/raw
else cat #{portscan_path}/raw/#{line_new}.txt >> #{portscan_path}/ports-scan.txt 
fi")
        end
      end
    else
        system("nmap -T4 #{domain} | sed '/^\\(Nmap scan\\|PORT\\|[0-9]\\)/!d' | tee -a #{portscan_path}/raw/#{domain}.txt")
        system("if grep \" #{domain}\" #{portscan_path}/ports-scan.txt 
then touch #{portscan_path}/raw
else cat #{portscan_path}/raw/#{domain}.txt >> #{portscan_path}/ports-scan.txt 
fi")
    end
  end
end

class Known_URLs
  def start(aws_path,home,username,domain,threads,workflow,root_domain,all,sub_path,url_path,final_urls,final_js,final_swf,spf_path,final_subdomains,final_ips)
         Known_URLs.new.waybackurls(username,domain,threads,workflow,root_domain,final_subdomains,final_urls,all,url_path,aws_path,sub_path,final_js,final_swf,home)
    Known_URLs.new.js_files(home,domain,workflow,root_domain,sub_path,final_js,final_subdomains,all)
  end
  
  def waybackurls(username,domain,threads,workflow,root_domain,final_subdomains,final_urls,all,url_path,aws_path,sub_path,final_js,final_swf,home)
    if all == true
      line_num=0
      text=File.open("#{final_subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
        line_new = line.strip
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        
        if File.file?("#{url_path}/wayback/#{line_new}.txt")
          puts("#{'[*] Already Scanned'}".red)
        else
          puts "#{'[!] Waybackurls Started...'.light_blue}"
          puts "#{'[*] Finding URLs...'.cyan}"
          system("echo \"#{line_new}\" | waybackurls | grep -v -e .css -e .jpg -e .jpeg -e png -e ico -e svg > #{url_path}/wayback.txt")
          puts "#{'[!] GAU Started...'.light_blue}"
          puts "#{'[*] Finding URLs...'.cyan}"
          system("echo \"#{line_new}\" | gau | grep -v -e .css -e .jpg -e .jpeg -e png -e ico -e svg >> #{url_path}/wayback.txt")
      
          system("cat #{url_path}/wayback.txt | anew #{url_path}/wayback/#{line_new}.txt")
          system("cat #{url_path}/wayback/#{line_new}.txt | anew #{final_urls}")
          
          system("rm #{url_path}/wayback.txt")
          
          system("cat #{final_urls} | perl -n -e '/\\b\\S+\\.(com|org|edu|net|eu)\\b/ && print $&,\"\\n\"; ' | cut -f3 -d\"/\" | sort -u | anew #{url_path}/subs.txt") 
          system("cat #{url_path}/subs.txt | grep -v #{root_domain} | anew #{url_path}/root-domains.txt")
          system("cat #{url_path}/subs.txt | grep amazonaws.com | sed 's/\\\.amazonaws.com//' | anew #{aws_path}/s3-buckets.txt")
          
          Known_URLs.new.parse(workflow,root_domain,sub_path,final_urls,final_js,final_swf,final_subdomains,home,url_path,username)
        end
      end
    else
        puts "#{'[!] Waybackurls Started...'.light_blue}"
        puts "#{'[*] Finding URLs...'.cyan}"
  
        system("echo \"#{domain}\" | waybackurls | grep -v -e .css -e .jpg -e .jpeg -e png -e ico -e svg > #{url_path}/wayback.txt")
        system("rm #{url_path}/wayback.txt")
        
        system("cat #{final_urls} | perl -n -e '/\\b\\S+\\.(com|org|edu|net|eu)\\b/ && print $&,\"\\n\"; ' | cut -f3 -d\"/\" | sort -u | anew #{url_path}/subs.txt") 
        system("cat #{url_path}/subs.txt | grep -v #{root_domain} | anew #{url_path}/root-domains.txt")
        system("cat #{url_path}/subs.txt | grep amazonaws.com | sed 's/\\\.amazonaws.com//' | anew #{aws_path}/s3-buckets.txt")
        
        Known_URLs.new.parse(workflow,root_domain,sub_path,final_urls,final_js,final_swf,final_subdomains,home,url_path,username)
    end
  end
  
  def js_files(home,domain,workflow,root_domain,sub_path,final_js,sub_list,all)
    if all == true
      puts "#{'[!] Executing \'getsrc.py\' script...'.light_blue}"
      puts "#{'[*] Finding JS files...'.cyan}"
    
      line_num=0
      text=File.open("#{sub_list}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
  
      line_new = line.strip
  
      if line_new["#{root_domain}"]
        system("mkdir -p #{sub_path}/raw/#{line_new}")
      
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        system("python3 #{home}/Desktop/recon/getsrc.py http://#{line_new} | grep -oE '(http|https)://(.*)' | tr -d '()' | tr -d '[]' | sed '/^$/d' | sort -u | anew #{final_js}")
      end
      end
    else
      puts "#{'[!] Executing \'getsrc.py\' script...'.light_blue}"
      puts "#{'[*] Finding JS files...'.cyan}"
  
      system("python3 #{home}/Desktop/recon/getsrc.py https://#{domain} | grep -oE '(http|https)://(.*)' | tr -d '()' | tr -d '[]' | sed '/^$/d' | sort -u | anew #{final_js}")
  
      puts "#{'[*] Script Ended...'.cyan}"
    end
    puts("#{'[*] Saved on '.yellow}#{final_js}".yellow)
  end
  
  def parse(workflow,root_domain,sub_path,final_urls,final_js,final_swf,final_subdomains,home,url_path,username)
    puts "#{'[*] Parsing...'.cyan}"
    
    system("cat #{final_urls} | grep \".json\" | tr -d '()' | tr -d '[]' | sed '/^$/d' | sort -u | anew #{final_js}")
    system("cat #{final_urls} | grep \".js\" | tr -d '()' | tr -d '[]' | sed '/^$/d' | sort -u | anew #{final_js}")
    system("cat #{final_urls} | grep \".swf\" | tr -d '()' | tr -d '[]' | sed '/^$/d' | sort -u | anew #{final_swf}")
    
    puts "#{'[*] Spidering...'.cyan}"
        system("cat #{final_urls} | grep = | sudo -u #{username} gf ssrf | sort -u | anew #{url_path}/vulnerable/ssrf/urls.txt")
        system("cat #{final_urls} | grep = | sudo -u #{username} gf sqli | sort -u | anew #{url_path}/vulnerable/sqli/urls.txt")
        system("cat #{final_urls} | grep = | sudo -u #{username} gf xss | sort -u | anew #{url_path}/vulnerable/xss/urls.txt")
        system("cat #{final_urls} | grep = | sudo -u #{username} gf lfi | sort -u | anew #{url_path}/vulnerable/lfi/urls.txt")
        system("cat #{final_urls} | grep = | sudo -u #{username} gf idor | sort -u | anew #{url_path}/vulnerable/idor/urls.txt")
        system("cat #{final_urls} | grep = | sudo -u #{username} gf redirect | sort -u | anew #{url_path}/vulnerable/redirect/urls.txt")
        system("cat #{final_urls} | grep = | sudo -u #{username} gf rce | sort -u | anew #{url_path}/vulnerable/rce/urls.txt")
    #end
  end
end

class Subdomain_Takeover
  def start(workflow,root_domain,threads,fingerprints,subdomains,tko_providers,final_takeover,tko_result,tmp)
    if File.file?(tmp)
      system(tmp)
    end
    Subdomain_Takeover.new.subjack(workflow,root_domain,threads,tmp,fingerprints,subdomains)
    Subdomain_Takeover.new.parse(workflow,root_domain,tmp,final_takeover)
    #Subdomain_Takeover.new.tko_subs(workflow,root_domain,tko_result,tko_providers,subdomains)
  end
  
  def subjack(workflow,root_domain,threads,output,fingerprints,subdomains)
    puts "#{'[!] Subjack Started...'.light_blue}"
    system("subjack -w #{subdomains} -a -ssl -t #{threads} -v -o #{output} -c #{fingerprints}")
    puts "#{'[*] Subjack Ended...'.cyan}"
  end
  
  def tko_subs(workflow,root_domain,output,tko_providers,subdomains)
    puts "#{'[!] TKO-Subs Started...'.light_blue}"
    system("tko-subs -domains #{subdomains} -data=#{tko_providers} -output=#{output} -takeover -githubtoken=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 -herokuusername=middleman87123891 -herokuapikey=762499d7-8d12-414e-986a-a53487aa770a -herokuappname=bugbounty1234324123")
    puts "#{'[*] TKO-Subs Ended...'.cyan}"
  end
  
  def parse(workflow,root_domain,output,final_takeover)
    system("cat #{output} | grep -v \"Not Vulnerable\" > #{final_takeover}")
    system("rm #{output}")
  end
end

class Access_Denied
  def start(home,workflow,root_domain,sub_list,url_path,ip_ranges,enumxff_out,threads,domain)
    system("echo \"https://#{domain}\" | anew #{sub_list}")
    line_num=0
    text=File.open("#{sub_list}").read
    text.gsub!(/\\r\\n/, "\\n")
    #tmp = "#{url_path}/access-denied/tamper.tmp"
  
    #if File.file?(tmp)
    #  system("rm #{tmp}")
    #end
  
    text.each_line do |line|
  
      url = line.strip
  
      puts "#{'[*] URL: '.cyan}#{url.cyan}"
      #enumxff(home,url,ip_ranges,enumxff_out,threads)
      byp4xx(home,url,threads)
      
exit
      #system("cat #{tmp} | sort -u | grep curl | sort -u | anew #{url_path}/access-denied/url-bypass.txt")
      #if File.file?(tmp)
      #  system("rm #{tmp}")
      #end
    end
  end
  
  def enumxff(home,url,ip_ranges,output,threads)
    puts "#{'[!] EnumXFF Started...'.light_blue}"
    system("python3 #{home}/Desktop/recon/XFFenum/xffenum.py -u #{url} -i 192.168.0.0/16 -t #{threads} ")
  end

  def byp4xx(home,url,threads)
    puts "#{'[!] Byp4xx Started...'.light_blue}"
    system("byp4xx --all -t #{threads} https://#{url}")
  end
end

class Github
  def start(github_token,org_name,secrets,threads,session,root_domain,graber,github_wordlist,home,all,final_subdomains,git_config,github_path,domain)
    #git_all_secrets(github_token,org_name,secrets)
    #gitrob(github_token,threads,org_name,session)
    
    git_graber(graber,github_wordlist,root_domain,home,threads)
    #git_hound(all,final_subdomains,git_config,github_path,domain)
    #git_dorks(all,final_subdomains,github_path,domain)
  end
  
  def git_hound(all,final_subdomains,git_config,github_path,domain)
    if all == true
      puts "#{'[!] Start Searching at GitHub...'.light_blue}"
      system("cat #{final_subdomains} | git-hound --config-file #{git_config} --dig-files --dig-commits | tee #{github_path}/secrets/secrets.txt")
    else
      puts "#{'[!] Start Searching at GitHub...'.light_blue}"
      system("mkdir -p #{github_path}/secrets/#{domain}")
      system("echo \"#{domain}\" | git-hound --config-file #{git_config} --dig-files --dig-commits | tee #{github_path}/secrets/#{domain}/secrets.txt")
    end
  end
  
  def git_dorks(all,final_subdomains,github_path,domain)
    puts "#{'[!] Github Dork Links...'.light_blue}"
    
    line_num=0
    text=File.open("#{final_subdomains}").read
    text.gsub!(/\\r\\n/, "\\n")
  
    text.each_line do |line|
      url = line.strip
      system("scripts/gitdorks.sh #{url} >> #{github_path}/dorks/links.txt")
    end
  end
  
  def git_all_secrets(github_token,org_name,secrets)
    puts "#{'[!] Starting Git-Secrets...'.light_blue}"
  
    system("docker run -it abhartiya/tools_gitallsecrets -token=#{github_token} -org=#{org_name} -output=results.txt")
    container_id = `docker ps -a | grep gitallsecrets | awk 'FNR <= 1' | head -n1 | awk '{print $1;}'`
    system("docker cp #{container_id.strip}:/root/results.txt #{secrets}")
  
    puts("#{'[*] Final Report on '.yellow}#{secrets}".yellow)
    puts "#{'[*] Git-Secrets Ended...'.cyan}"
  end
  
  def gitrob(github_token,threads,org_name,session)
    puts "#{'[!] Starting Gitrob...'.light_blue}"
  
    if File.file?("#{session}")
      system("gitrob -github-access-token=#{github_token} -load=#{session} -threads #{threads}")  
    else
      system("gitrob -github-access-token=#{github_token} -save=#{session} -threads #{threads} #{org_name}")
    end
    puts("#{'[*] Session Saved on '.yellow}#{session}".yellow)
    puts "#{'[*] Git-Secrets Ended...'.cyan}"
  end
  
  def git_graber(graber,github_wordlist,root_domain,home,threads)
    puts "#{'[!] Starting GitGraber...'.light_blue}"
  
    system("python3 #{home}/Desktop/recon/gitGraber/gitGraber.py -t #{threads} -k #{github_wordlist} -q \\\"#{root_domain}\\\" -s -m | anew #{graber}")
  
    puts("#{'[*] Final Report on '.yellow}#{graber}".yellow)
    puts "#{'[*] GitGraber Ended...'.cyan}"
  end
end

class SWF_Research
  def start(final_swf,swf_path,home,root_domain,final_urls,final_subdomains,workflow)
    download(final_swf,swf_path)
    parrot_ng(home,swf_path)
    decompress(home,final_swf,swf_path)
    parse(final_swf,root_domain,final_urls,final_subdomains,workflow)
  end
  
  def download(final_swf,swf_path)
    puts "#{'[!] Downloading SWF Files...'.light_blue}"
  
    line_num=0
    text=File.open("#{final_swf}").read
    text.gsub!(/\\r\\n/, "\\n")
    text.each_line do |line|
  
      line_new = line.strip
      uri = URI.parse(line_new).host
  
      swf_file = line_new.split('/')[-1]
  
      system("mkdir -p #{swf_path}/source/#{uri}")
  
      Dir.chdir(''+swf_path+'/source/'+uri+'') do
        system("wget #{line_new}")
      end
    end
    puts "#{'[*] Done...'.cyan}"
  end
  
  def decompress(home,final_swf,swf_path)
    puts "#{'[!] Decompressing SWF Files...'.light_blue}"
 
    line_num=0
    text=File.open("#{final_swf}").read
    text.gsub!(/\\r\\n/, "\\n")
    text.each_line do |line|
  
      line_new = line.strip
      uri = URI.parse(line_new).host
  
      swf_file = line_new.split('/')[-1]
  
      system("mkdir -p #{swf_path}/decompress/#{uri}")
  
      system("ffdec -cli -export all #{swf_path}/decompress/#{uri}/#{swf_file} #{swf_path}/source/#{uri}/#{swf_file}")
    end
    
    puts "#{'[*] Looking for apikeys, passwords, jwt, etc...'.cyan}"
    system("node #{home}/Desktop/recon/repo-supervisor/dist/cli.js #{swf_path} | anew #{swf_path}/swf-secrets.txt")
  end
  
  def parrot_ng(home,swf_path)
    puts "#{'[!] Parrot-NG Started...'.light_blue}"
    puts "#{'[*] Looking for CVEs...'.cyan}"
    system("java -jar #{home}/Desktop/recon/parrotng_v0.2.jar #{swf_path}/source/* | anew #{swf_path}/parrot-ng.txt")
  end
  
  def parse(final_swf,root_domain,final_urls,final_subdomains,workflow)
    puts "#{'[*] Combining Information...'.yellow}"
    system("cat #{final_swf} | grep #{root_domain} | sed '/^$/d' | sort -u | anew #{final_urls}")
    system("cat #{final_swf} | grep #{root_domain} | perl -n -e '/\\b\\S+\\.(com|org|edu|net|eu)\\b/ && print $&,\"\\n\"; ' | cut -f3 -d\"/\" | sort -u | qsreplace | /usr/local/bin/httpx | cut -d : -f2 | cut -c 3- | sort -u | anew #{final_subdomains}")
    system("cat #{final_swf} | grep -v #{root_domain} | grep -v amazonaws.com | anew #{workflow}/root-domains.txt")
  end
end

class Httprobe
  def start(subdomains,final_subdomains,final_ips,final_vhosts,final_urls,workflow,root_domain)
    puts "#{'[!] Quick Test for HTTP Hosts...'.light_blue}"  
    puts "#{'[*] Scanning Subdomains...'.cyan}"
    system("cat #{subdomains} | sed 's/https:\\/\\///' | sed 's/http:\\/\\///' | sort -u | httprobe -c 50 | anew #{final_subdomains}")
  exit
    #puts "#{'[*] Scanning IPs...'.cyan}"
    #system("cat #{ips} | sed 's/https:\\/\\///' | sed 's/http:\\/\\///' | sort -u | httprobe -c 50 -prefer-https | anew #{final_ips}")
  
    puts "#{'[*] Scanning VHosts...'.cyan}"
    system("cat #{vhosts} | sed 's/https:\\/\\///' | sed 's/http:\\/\\///' | sort -u | httprobe -c 50 -prefer-https | anew #{final_vhosts}")
  
    system("cat #{workflow}/#{root_domain}/*/online-*.txt | sed 's/$/\\//' | sort -u | anew #{final_urls}")
  
    puts "#{'[*] Done...'.cyan}"
  end
end

class XSScanner
  def start(final_urls,output)
    puts "#{'[!] Dalfox Started...'.light_blue}"
    system("cat #{final_urls} | dalfox pipe -o #{output}")
    puts "#{'[*] Dalfox Ended...'.cyan}"
  end
end

class CRLFScanner
  def start(final_subdomains,final_crlf,all,root_domain,url_path,domain)
    system("mkdir -p #{url_path}/crlf/raw")
    if all == true
      line_num=0
      text=File.open("#{final_subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
      text.each_line do |line|
        line_new = line.strip
        
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        if File.file?("#{url_path}/crlf/raw/#{line_new}.txt")
          puts "#{'[*] Already Scanned'.red}"
        else
          system("crlfuzz -u https://#{line_new} -o #{url_path}/crlf/raw/#{line_new}.txt")
          system("cat #{url_path}/crlf/raw/#{line_new}.txt | anew #{final_crlf}")
        end
      end
    else
        system("crlfuzz -u https://#{domain} -o #{url_path}/crlf/raw/#{domain}.txt")
        system("cat #{url_path}/crlf/raw/#{domain}.txt | anew #{final_crlf}")
    end
  end
end

class SSRFScanner
  def start(home,threads,urls,url_path,burp_collaborator)
    system("cat #{urls} | qsreplace \"http://#{burp_collaborator}\" > #{url_path}/vulnerable/ssrf/ssrfuzz.txt")
    system("ffuf -c -w #{url_path}/vulnerable/ssrf/ssrfuzz.txt -u FUZZ -t 200")
  end
end

class JS_Research
  def start(home,final_subdomains,final_js,secrets_output,js_path,final_urls,threads,root_domain,workflow)
    #find_js_files(final_subdomains,final_js,home)
    puts
    #find_words(final_js,home,js_path)
    puts
    #linkfinder(final_js,js_path,home,final_urls)
    puts
    #NOT - http_JS(final_js,home,threads,js_path)
    #puts
    #beautify(final_js,js_path,home,root_domain)

    #puts
    #old_code(final_js,js_path,root_domain)
    puts
    scan_js(js_path)
    puts
    secret_finder(final_subdomains,secrets_output,home)
    parse(final_js,final_urls,final_subdomains,root_domain,workflow)
  end
  
  def find_js_files(final_subdomains,final_js,home)
    puts "#{'[!] Executing \'getsrc.py\' script...'.light_blue}"
  
    line_num=0
    text=File.open("#{final_subdomains}").read
    text.gsub!(/\\r\\n/, "\\n")
    text.each_line do |line|
  
      line_new = line.strip
      
      puts("#{'[*] Executing on '}#{line_new}".yellow)
      system("python3 #{home}/Desktop/recon/getsrc.py http://#{line_new} | grep -oE '(http|https)://(.*)' | sed '/^$/d' | sort -u | anew #{final_js}")
    end
    puts "#{'[*] Done...'.cyan}"
  end

  def secret_finder(final_subdomains,secrets_output,home)
    puts "#{'[!] Secret Finder Started...'.light_blue}"
    puts "#{'[*] Looking for apikeys, access tokens, jwt, etc...'.cyan}"
  
    system("cat #{final_subdomains} |xargs -n2 -I @ bash -c 'echo -e \"\\n[URL] @\\n\";python3 #{home}/Desktop/recon/LinkFinder/linkfinder.py -i @ -o cli' >> #{secrets_output}")
  
    #Repo-Supervisor
    system("node #{home}/Desktop/recon/repo-supervisor/dist/cli.js #{js_path} | anew #{secrets_output}")
  
    puts "#{'[*] Secret Finder Ended...'.cyan}"
  end

  def linkfinder(final_js,js_path,home,final_urls)
    puts "#{'[!] Linkfinder Started...'.light_blue}"
    puts "#{'[*] Looking for new hosts...'.cyan}"
  
    #system("cat #{final_js} |xargs -n2 -I @ bash -c 'echo -e \"\\n[URL] @\\n\";python3 #{home}/Desktop/recon/LinkFinder/linkfinder.py -o cli -i @' >> #{js_path}/js_paths_with_url.txt")
 
    system("cat #{js_path}/js_paths_with_url.txt | grep -iv '[URL]'| sort -u | anew #{js_path}/js_paths_with_nourl.txt")

    system("cat #{js_path}/js_paths_with_*.txt | grep -oE '(http|https)://(.*).js' | anew #{final_js}")
  
    puts "#{'[*] Executing \'collector.py\' script...'.cyan}"
  
    system("cat #{js_path}/js_paths_with_nourl.txt | python3 #{home}/Desktop/recon/collector.py #{js_path}/js_collector")
  
    puts "#{'[*] Executing \'availableForPurchase.py\' script...'.cyan}"
    system("cat #{js_path}/js_collector/urls.txt #{final_urls} | sort -u | python3 #{home}/Desktop/recon/availableForPurchase.py")
  
    puts "#{'[*] Linkfinder Ended...'.cyan}"
  end

  def find_words(final_js,home,js_path)
    puts "#{'[*] Finding Words on JS...'.cyan}"
    system("cat #{final_js} | python3 #{home}/Desktop/recon/getjswords.py >> #{js_path}/js_words.txt")
    puts "#{'[*] Words Found...'.cyan}"
  end

  def http_JS(final_js,home,threads,js_path)
    puts "#{'[!] Finding Live JS...'.light_blue}"
    system("cat #{final_js} | python3 #{home}/Desktop/recon/antiburl.py -T #{threads} >> #{js_path}/js_online.txt")
    puts "#{'[*] Live JS Found...'.cyan}"
  end

  def beautify(final_js,js_path,home,root_domain)
    puts "#{'[!] Executing \'jsbeautify.py\' script...'.light_blue}"
    puts "#{'[*] Doing Manual Analyzis on JS...'.cyan}"
  
    line_num=0
    text=File.open("#{final_js}").read
    text.gsub!(/\\r\\n/, "\\n")
    text.each_line do |line|
  
      line_new = line.strip
      uri = URI.parse(line_new).host
      
      js_file = line_new.split('/')[-1]
  
      if uri["#{root_domain}"]
        system("mkdir -p #{js_path}/source/#{uri}")
  
        system("python3 #{home}/Desktop/recon/jsbeautify.py #{line_new} #{js_path}/source/#{uri}/#{js_file}")
      end
    end
    puts "#{'[*] Done...'.cyan}"
  end

  def old_code(final_js,js_path,root_domain)
    puts "#{'[!] Waybackunifier Started...'.light_blue}"
    puts "#{'[*] Finding Old JS...'.cyan}"
  
    line_num=0
    text=File.open("#{final_js}").read
    text.gsub!(/\\r\\n/, "\\n")
    text.each_line do |line|
  
      line_new = line.strip
      uri = URI.parse(line_new).host
      
      js_file = line_new.split('/')[-1]
  
      if uri["#{root_domain}"]
        system("mkdir -p #{js_path}/old-js/#{uri}")
  
        system("waybackunifier -concurrency 5 -url #{line_new} -output #{js_path}/old-js/#{uri}/#{js_file}")
      end
    end
  end

  def scan_js(js_path)
    puts "#{'[*] Scanning JS Code...'.light_blue}"
    puts "#{'[!] Retire.js Started...'.light_blue}"
    system("retire --jspath #{js_path}/*/* --outputformat text --outputpath #{js_path}/known-cve.txt")
  end

  def parse(final_js,final_urls,final_subdomains,root_domain,workflow)
    puts "#{'[*] Combining Information...'.yellow}"
    system("cat #{final_js} | grep #{root_domain} | sed '/^$/d' | sort -u | anew #{final_urls}")
    system("cat #{final_js} | grep #{root_domain} | grep #{root_domain} | perl -n -e '/\\b\\S+\\.(com|org|edu|net|eu)\\b/ && print $&,\"\\n\"; ' | cut -f3 -d\"/\" | sort -u | qsreplace | /usr/local/bin/httpx | cut -d : -f2 | cut -c 3- | sort -u | anew #{final_subdomains}")
    system("cat #{final_js} | grep -v #{root_domain} | grep -v amazonaws.com | anew #{workflow}/root-domains.txt")
  end
end

class Apache_Scan
  def start(all,home,url_path,final_directories,output,domain)
    puts "#{'[!] Struts-PWN Started...'.light_blue}"
    system("mkdir -p #{url_path}/apache/raw")
    if all == true
      line_num=0
      text=File.open("#{final_directories}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
        line_new = line.strip
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        
        if File.file?("#{url_path}/apache/raw/#{line_new}.txt")
          puts("#{'[*] Already Scanned'}".red)
        else
          system("python #{home}/Desktop/recon/struts-pwn/struts-pwn.py --check -u https://#{line_new} | tee -a #{url_path}/apache/raw/#{line_new}.txt")
          system("cat #{url_path}/apache/raw/#{line_new}.txt >> #{output}")
        end
      end
    else
        system("python #{home}/Desktop/recon/struts-pwn/struts-pwn.py --check -u https://#{domain} | tee -a #{url_path}/apache/raw/#{domain}.txt")
        system("cat #{url_path}/apache/raw/#{domain}.txt >> #{output}")
    end
  end
end

class Backup_Checker
  def start(home,git_endpoints,svn_endpoints,git_path,svn_path,all,final_directories,root_domain,git_output,svn_output,final_output,domain,tmp,threads)
    puts "#{'[!] BFAC Started...'.light_blue}"
    if File.file?(tmp)
      system("rm #{tmp}")
    end
    
    if all == true
      system("bfac -L #{final_directories} -o #{tmp}")
      parse(git_output,svn_output,final_output,tmp)
      rip_git(home,git_endpoints,git_path)
      rip_svn(home,svn_endpoints,svn_path)
    else
      line_num=0
      text=File.open("#{final_directories}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
  
        line_new = line.strip
  
        if line_new["//#{root_domain}"]
          system("bfac -u #{line_new} -o #{tmp} --threads #{threads}")
        end
      end
      parse(git_output,svn_output,final_output,tmp)
      if File.zero?(git_output)
        puts("#{'[!] Couldn\'t find Git Backups'}".red)
      else
        rip_git(home,git_endpoints,git_path)
      end
      if File.zero?(svn_output)
        puts("#{'[!] Couldn\'t find Svn Backups'}".red)
      else
        rip_svn(home,svn_endpoints,svn_path)
      end
    end
  end
  
  def parse(git_output,svn_output,final_output,tmp)
    if File.file?(tmp)
      puts "#{'[*] Searching: .git / .svn'.cyan}"
      system("cat #{tmp} | grep \"/.git\" | sort -u | anew #{git_output}")
      system("cat #{tmp} | grep \"/.svn\" | sort -u | anew #{svn_output}")
      system("cat #{tmp} | sort -u | anew #{final_output}")
      system("rm #{tmp}")
    end
  end
  
  def rip_git(home,git_endpoints,git_path)
    line_num=0
    text=File.open("#{git_endpoints}").read
    text.gsub!(/\\r\\n/, "\\n")
  
    text.each_line do |line|
  
      line_new = line.strip
      
      system("#{home}/Desktop/recon/dvcs-ripper/rip-git.pl -v -u #{line_new} -o #{git_path}")
    end
  end
  
  def rip_svn(home,svn_endpoints,svn_path)
    line_num=0
    text=File.open("#{svn_endpoints}").read
    text.gsub!(/\\r\\n/, "\\n")
  
    text.each_line do |line|
  
      line_new = line.strip
      
      system("#{home}/Desktop/recon/dvcs-ripper/rip-svn.pl -v -u #{line_new} -o #{svn_path}")
    end
  end
end

class WPScan
  def start(all,final_subdomains,root_domain,scanners_path,wp_api_key,wordlist,threads,domain)
    puts "#{'[*] WordPress Security Scanner...'.light_blue}"
    puts "#{'[!] WPScan Started...'.light_blue}"
    system("mkdir -p #{scanners_path}/wpscan/raw")
    if all == true
      line_num=0
      text=File.open("#{final_subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
  
        line_new = line.strip
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        
        if File.file?("#{scanners_path}/wpscan/raw/#{line_new}.txt")
          puts "#{'[*] Already Scanned'.red}"
        else
          system("wpscan --disable-tls-checks --ignore-main-redirect --url http://#{line_new} -o #{scanners_path}/wpscan/raw/#{line_new}.txt --api-token #{wp_api_key} -t #{threads}")
          system("cat #{scanners_path}/wpscan/raw/#{line_new}.txt | anew #{scanners_path}/wpscan/vulnerable.txt")
        end
      end
    else
        system("wpscan --ignore-main-redirect --url https://#{domain} -o #{scanners_path}/wpscan/raw/#{domain}.txt --api-token #{wp_api_key} -t #{threads}")
        system("cat #{scanners_path}/wpscan/raw/#{domain}.txt | anew #{scanners_path}/wpscan/vulnerable.txt")
    end
  end
end

class Wapiti
  def start(all,final_subdomains,scanners_path,domain)
    if all == true
      line_num=0
      text=File.open("#{final_subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
        line_new = line.strip
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        
        if File.directory?("#{scanners_path}/wapiti/#{line_new}")
          puts("#{'[*] Already Scanned'}".red)
        else
          system("mkdir -p #{scanners_path}/wapiti/#{line_new}")
          system("wapiti -u https://#{line_new} -o #{scanners_path}/wapiti/#{line_new}")
        end
      end
    else
        system("mkdir -p #{scanners_path}/wapiti/#{domain}")
        system("wapiti -u https://#{domain} -o #{scanners_path}/wapiti/#{domain}")
    end
  end
end

class Crossdomain
  def start(final_takeover,subjack_fingerprints,tko_providers,tko_result,tmp_takeover,spf_path,final_subdomains,final_ips,final_urls,urls,url_path,sub_path,username,domain,threads,workflow,root_domain,output,findomain_config,cloudflare_token,cloudflare_email,censys_api_key,censys_api_secret,wordlist,all,home,resolvers,amass_config)
    tmp = "#{url_path}/crossdomain/online-subdomains.tmp"
    
    if File.file?("#{tmp}")
      system("rm #{tmp}")
    end
    if all == true
      search_crossdomain(final_urls,final_subdomains,urls)
      line_num=0
      text=File.open("#{urls}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
  
        line_new = line.strip
        cross_policy = `curl -s https://#{line_new}/crossdomain.xml | grep "cross-domain-policy"`
  
        if cross_policy.include? "cross-domain-policy"
          puts("#{'[*] URL: https://'}#{line_new}".cyan)
          puts "#{'[*] Finding Wildcards...'.light_blue}"
          system("mkdir -p #{url_path}/crossdomain/data/#{line_new}")
          system("curl -s https://#{line_new}/crossdomain.xml | grep -oP '(?<=domain\\=\\\").*?(?=\\\")' | anew #{url_path}/crossdomain/data/#{line_new}/wildcards.txt")
          system("cat #{url_path}/crossdomain/data/*/wildcards.txt | perl -n -e '\/\\b\\S+\\.(com|org|edu|net|eu)\\b\/ && print $&,\"\\n\"; ' | httprobe -c 50 | anew #{tmp}")
          expired_domain(home,line_new,url_path)
          parse(tmp,final_urls,line_new,final_subdomains,url_path)
          subs = "#{url_path}/crossdomain/data/#{line_new}/subdomains.txt"
          if File.file?(subs)
        sub_enum(spf_path,final_subdomains,final_ips,subs,url_path,sub_path,username,line_new,threads,workflow,root_domain,output,findomain_config,cloudflare_token,cloudflare_email,censys_api_key,censys_api_secret,wordlist,"true",home,resolvers,amass_config)
          end
          final_subs = "#{url_path}/crossdomain/final-subdomains.txt"
          if File.file?(final_subs)
            #Subdomain_Bruteforce.new.parse(workflow,root_domain,sub_path,spf_path,final_subdomains,final_ips)
            parse_subdomains(final_subs,sub_path)
            takeover(final_subs,subjack_result,sub_path,workflow,root_domain,threads,subjack_fingerprints,final_subdomains,tko_providers,final_takeover,tko_result,tmp_takeover)
          end
        else 
          puts("#{'[!] Couldn\'t find crossdomain.xml on '}#{line_new}".red)
        end
      end
    else
      cross_policy = `curl -s https://#{domain}/crossdomain.xml | grep "cross-domain-policy"`
      if cross_policy.include? "cross-domain-policy"
        puts "#{'[*] URL: https://'.cyan}#{domain.cyan}"
        puts "#{'[*] Finding Wildcards...'.light_blue}"
        system("mkdir -p #{url_path}/crossdomain/data/#{domain}")
        system("curl -s https://#{domain}/crossdomain.xml | grep -oP '(?<=domain\\=\\\").*?(?=\\\")' | anew #{url_path}/crossdomain/data/#{domain}/wildcards.txt")
        system("cat #{url_path}/crossdomain/data/*/wildcards.txt | perl -n -e '\/\\b\\S+\\.(com|org|edu|net|eu)\\b\/ && print $&,\"\\n\"; ' | httprobe -c 50 | anew #{tmp}")
        expired_domain(home,domain,url_path)
        parse(tmp,final_urls,domain,final_subdomains,url_path)
        subs = "#{url_path}/crossdomain/data/#{domain}/subdomains.txt"
        if File.file?(subs)
          sub_enum(spf_path,final_subdomains,final_ips,subs,url_path,sub_path,username,domain,threads,workflow,root_domain,output,findomain_config,cloudflare_token,cloudflare_email,censys_api_key,censys_api_secret,wordlist,"true",home,resolvers,amass_config)
        end
        final_subs = "#{url_path}/crossdomain/final-subdomains.txt"
        if File.file?(final_subs)
          #Subdomain_Bruteforce.new.parse(workflow,root_domain,sub_path,spf_path,final_subdomains,final_ips)
          parse_subdomains(final_subs,sub_path)
          takeover(final_subs,sub_path,workflow,root_domain,threads,subjack_fingerprints,final_subdomains,tko_providers,final_takeover,tko_result,tmp_takeover)
        end
      else 
        puts "#{'[!] Couldn\'t find crossdomain.xml on '.red}#{domain.red}"
      end
    end
  end
  
  def search_crossdomain(final_urls,final_subdomains,urls)
    system("cat #{final_urls} | grep \"crossdomain.xml\" | anew #{urls}")
    
    line_num=0
    text=File.open("#{final_subdomains}").read
    text.gsub!(/\\r\\n/, "\\n")
  
    text.each_line do |line|
      line_new = line.strip
      cross_policy = `curl -s https://#{line_new}/crossdomain.xml | grep "cross-domain-policy"`
  
      if cross_policy.include? "cross-domain-policy"
        system("echo \"https://#{line_new}/crossdomain.xml\" | anew #{urls}")
      end
    end
  end 
  
  def expired_domain(home,domain,url_path)
    Dir.chdir(''+home+'/Desktop/recon/crossdomainscanner') do
      puts "#{'[*] Finding Expired Domains...'.light_blue}"
      system("python3 scanner.py https://#{domain} -v -o #{url_path}/crossdomain/data/#{domain}/expired-domains.txt")
    end
  end 
  
  def sub_enum(spf_path,final_subdomains,final_ips,sub_list,url_path,sub_path,username,domain,threads,workflow,root_domain,output,findomain_config,cloudflare_token,cloudflare_email,censys_api_key,censys_api_secret,wordlist,all,home,resolvers,amass_config)
    puts "#{'[>] Subdomains Enumeration'.green}"
    Subdomain_Bruteforce.new.start(spf_path,final_subdomains,final_ips,sub_list,sub_path,username,domain,threads,workflow,root_domain,output,findomain_config,cloudflare_token,cloudflare_email,censys_api_key,censys_api_secret,wordlist,all,home,resolvers,amass_config)
 
    puts "#{'[>] Subdomains Enumeration Ended...'.green}"
  end 
  
  def takeover(subs_takeover,sub_path,workflow,root_domain,threads,subjack_fingerprints,final_subdomains,tko_providers,final_takeover,tko_result,tmp)
    puts "#{'[>] Subdomain Takeover'.green}"
  Subdomain_Takeover.new.start(workflow,root_domain,threads,subjack_fingerprints,subs_takeover,tko_providers,final_takeover,tko_result,tmp)
    puts("#{'[*] Final Report on '.yellow}#{final_takeover}".yellow)
    puts "#{'[>] Subdomain Takeover Ended...'.green}"
  end
  
  def parse(tmp,final_urls,domain,final_subdomains,url_path)
    system("cat #{tmp} | sort -u | anew #{final_urls}")
    system("cat #{tmp} | sort -u | anew #{final_urls}")
    system("cat #{tmp} | sed 's/https:\\/\\///' | sed 's/http:\\/\\///' | sort -u | sed -e 's/^/https:\\\/\\\//' | sort -u | anew #{url_path}/crossdomain/data/#{domain}/subdomains.txt")
    system("cat #{url_path}/crossdomain/data/*/subdomains.txt | sort -u | anew #{url_path}/crossdomain/final-subdomains.txt")
    system("awk 'BEGIN{}NR==FNR{a[$0]++}!($0 in a)' #{url_path}/crossdomain/data/*/subdomains.txt #{url_path}/crossdomain/data/*/wildcards.txt | sed 's/https:\\/\\///' | sed 's/http:\\/\\///' | sed '/*/d' | anew #{url_path}/crossdomain/data/#{domain}/non-subdomains.txt")
    #system("cat #{url_path}/crossdomain/final-subdomains.txt | sort -u | anew #{final_subdomains}")
    #system("cat #{url_path}/crossdomain/final-subdomains.txt | sort -u | anew #{final_urls}")
    system("cat #{url_path}/crossdomain/final-subdomains.txt | sed 's/https:\\/\\///' | sed 's/http:\\/\\///' | sort -u | grep -v '\\\\' | anew #{final_subdomains}")
    if File.file?(tmp)
      system("rm #{tmp}")
    end
  end
  
  def parse_subdomains(subdomains,sub_path)
    system("cat #{sub_path}/crossdomain/*/*.txt | perl -n -e '\/\\b\\S+\\.(com|org|edu|net|eu)\\b\/ && print $&,\"\\n\"; ' | sed '/^$/d' | sort -u | grep -v '\\\\' | anew #{subdomains}")
  
    if File.file?("#{sub_path}/crossdomain/*/cfenum.json")
      system("cat #{sub_path}/crossdomain/*/cfenum.json | grep -Po '\"subdomain\":.*?[^\\\\]\",' | perl -n -e '\/\\b\\S+\\.(com|org|edu|net|eu)\\b\/ && print $&,\"\\n\"; ' | sed '/^$/d' | sort -u | grep -v '\\\\' | anew #{subdomains}")
  
      system("cat #{sub_path}/crossdomain/*/cfenum.json | grep -Po '\"IP\":.*?[^\\\\]\",' | perl -n -e '\/\\b\\S+\\.(com|org|edu|net|eu)\\b\/ && print $&,\"\\n\"; ' | sed '/^$/d' | sort -u | grep -v '\\\\' | anew #{subdomains}")
    end
  end 
end

class Patterns
  def start(all,final_subdomains,domain,wordlist_path,altdns_location,wordlist,sub_path,threads)
    altdns(all,final_subdomains,domain,wordlist_path,altdns_location,wordlist,sub_path,threads)
    #dnsgen(all,final_subdomains,domain,wordlist_path,sub_path)
    parse(sub_path,final_subdomains)
  end
  
  def altdns(all,final_subdomains,domain,wordlist_path,altdns_location,wordlist,sub_path,threads)
    puts "#{'[!] Starting AltDNS...'.light_blue}"
    puts "#{'[*] Generating Quick Wordlist...'.cyan}"
    if all == true
      line_num=0
      text=File.open("#{final_subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
  
        line_new = line.strip
  
        if uri["#{root_domain}"]
          puts("#{'[*] Executing on '}#{line_new}".yellow)
          
          word_target = line_new.split(".")[0]
          system("echo \"#{word_target}\" > #{wordlist_path}/patterns/altdns/#{line_new}.txt")
  
          system("python3 #{altdns_location} -t #{threads} -i #{final_subdomains} -o #{sub_path}/patterns/altdns/#{line_new}.txt -w #{wordlist_path}/patterns/altdns/#{line_new}.txt")
        end
      end
    else
      word_target = domain.split(".")[0]
      system("echo \"#{word_target}\" > #{wordlist_path}/patterns/altdns/#{domain}.txt")
      
      system("python3 #{altdns_location} -t #{threads} -i #{final_subdomains} -o #{sub_path}/patterns/altdns/#{domain}.txt -w #{wordlist_path}/patterns/altdns/#{domain}.txt")
    end
    puts "#{'[*] AltDNS Ended...'.cyan}"
  end
  
  def dnsgen(all,final_subdomains,domain,wordlist_path,sub_path)
    puts "#{'[!] Starting DNSGen...'.light_blue}" 
    puts "#{'[*] Generating Quick Wordlist...'.cyan}"
    if all == true
      line_num=0
      text=File.open("#{final_subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
  
        line_new = line.strip
  
        if uri["#{root_domain}"]
          puts("#{'[*] Executing on '}#{line_new}".yellow)
  
          system("echo \"#{line_new}\" | dnsgen - | sort -u | anew #{sub_path}/patterns/dnsgen/#{line_new}.txt")
        end
      end
    else
      system("echo \"#{domain}\" | dnsgen - | sort -u | anew #{sub_path}/patterns/dnsgen/#{domain}.txt")
    end
    puts "#{'[*] DNSGen Ended...'.cyan}"
  end
  
  def parse(sub_path,final_subdomains)
    system("cat #{sub_path}/patterns/altdns/*.txt | sort -u > #{sub_path}/wl-subdomains.txt")
  end
end

class VHost_Enumeration
  def start(all,final_subdomains,root_domain,threads,vhost_path,wordlist,final_vhosts,final_ips,domain)
    if all == true
      line_num=0
      text=File.open("#{final_subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
  
        line_new = line.strip
  
        if line_new["#{root_domain}"]
          puts("#{'[*] Executing on '}#{line_new}".yellow)
          if File.file?("#{vhost_path}/raw/#{line_new}.txt")
            puts "#{'[*] Already Scanned'.red}"
          else
            system("mkdir -p #{vhost_path}/raw/#{line_new}")
            fs = `curl -s -H "Host: nonexistent.#{line_new}" https://#{line_new} |wc -c`
            system("ffuf -c -w #{wordlist} -u https://#{line_new} -H \"Host: FUZZ.#{line_new}\" -fs #{fs} -o #{vhost_path}/raw/#{line_new}.txt -of csv")
          end
        end
      end
    else
        fs = `curl -s -H "Host: nonexistent.#{domain}" https://#{domain} |wc -c`
        #system("ffuf -c -w #{wordlist} -u https://#{domain} -H \"Host: FUZZ.#{domain}\" -o #{vhost_path}/raw/#{domain}.txt -of csv -fs #{fs}")
      system("gobuster vhost -u #{domain} -t #{threads} -w #{wordlist} -o #{vhost_path}/raw/#{domain}.txt")
    end
    puts "#{'[*] Ffuf Ended...'.cyan}"
    puts "#{'[*] Combining vhosts...'.cyan}"
    system("/usr/local/bin/httpx -l #{vhost_path}/raw/#{domain}.txt | cut -d : -f2 | cut -c 3- | sort -u | anew #{final_vhosts}")
    
    system("cat #{final_vhosts} | anew #{final_subdomains}")

    #puts("cat #{vhost_path}/*/*.txt | sed -E 's/^\\s*.*:\\/\\///g' | /usr/local/bin/httpx | cut -d : -f2 | cut -c 3- | sort -u | anew #{vhost_path}/vhosts-ips.txt")
  
    #system("cat #{vhost_path}/vhosts-ips.txt | anew #{final_ips}")
  end
end

class Visual
  def start(final_subdomains,final_urls,final_js,final_swf,threads,screenshot_path,org_name)
    puts "#{'[!] Aquatone Started...'.light_blue}"
    
    system("cat #{final_subdomains} | awk '{ printf \"https://\"; print }' > subs.tmp")
    
    system("cat subs.tmp | aquatone -out #{screenshot_path}/aquatone")
    system("rm subs.tmp")
  
    system("cat #{screenshot_path}/aquatone/aquatone_urls.txt | sort -u | anew #{final_urls}")
    system("cat #{final_urls} | grep -oE '(http|https)://(.*).js' | sort -u | sort -u | anew #{final_js}")
    system("cat #{final_urls} | grep -oE '(http|https)://(.*).json' | sort -u | sort -u | anew #{final_js}")
    system("cat #{final_urls} | grep -oE '(http|https)://(.*).swf' | sort -u | sort -u | anew #{final_swf}")
  
    puts "#{'[*] Aquatone Ended...'.cyan}"
    puts "#{'[*] Combining Information...'.yellow}"
  
    puts "#{'[*] Servers'.cyan}"
  
    system("cat #{screenshot_path}/aquatone/headers/* | grep 'Server:' | sort | uniq -c | sort -nr | sort -u | anew #{screenshot_path}/aquatone/servers.txt")
  
    puts "#{'[*] Subdomains'.cyan}"
  
    system("cat #{screenshot_path}/aquatone/html/* | grep -v @ | egrep -o '[a-z0-9\\-\\_\\.]+\\/*.\\#{org_name}\\.com' -a | perl -n -e '/\\b\\S+\\.(com|org|edu|net|eu)\\b/ && print $&,\"\\n\"; ' | sort -u  > #{screenshot_path}/aquatone/subdomains.txt")
    system("cat #{screenshot_path}/aquatone/subdomains.txt | qsreplace | /usr/local/bin/httpx | cut -d : -f2 | cut -c 3- | sort -u | anew #{final_subdomains}")
    
    puts "#{'[*] URLs'.cyan}"
    system("cat #{screenshot_path}/aquatone/aquatone_urls.txt | qsreplace | /usr/local/bin/httpx | sort -u | anew #{final_urls}")
  
    puts "#{'[*] HTML Comments'.cyan}"
    system("cat #{screenshot_path}/aquatone/html/* | egrep -o '<!--.*-->' -a | sort | uniq -c | sort -nr | sort -u | anew #{screenshot_path}/aquatone/html-comments.txt")
  
    puts "#{'[*] Password Fields'.cyan}"
    system("grep 'type=\"password\"' -a #{screenshot_path}/aquatone/html/* | sort -u | anew #{screenshot_path}/aquatone/password-fields.txt")
  end
end

class Wafw00f
  def start(all,subdomains,waf_path,domain,final_waf)
    system("mkdir -p #{waf_path}/raw")
    if all == true
      line_num=0
      text=File.open("#{subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
        line_new = line.strip
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        
        if File.file?("#{waf_path}/raw/#{line_new}.txt")
          puts("#{'[*] Already Scanned'}".red)
        else
          system("wafw00f https://#{line_new} -r -o #{waf_path}/raw/#{line_new}.txt")
          system("cat #{waf_path}/raw/#{line_new}.txt | anew #{final_waf}")
        end
      end
    else
        system("wafw00f https://#{domain} -r -o #{waf_path}/raw/#{domain}.txt")
        system("cat #{waf_path}/raw/#{domain}.txt | anew #{final_waf}")
    end
  end
end

class Shocker
  def start(all,home,subdomains,threads,domain,scanners_path)
    system("mkdir -p #{scanners_path}/shocker/raw")
    if all == true
      line_num=0
      text=File.open("#{subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
        line_new = line.strip
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        
        if File.file?("#{scanners_path}/shocker/raw/#{line_new}.txt")
          puts("#{'[*] Already Scanned'}".red)
        else
          system("python #{home}/Desktop/recon/shocker/shocker.py -H #{line_new} -s -t #{threads} | tee -a #{scanners_path}/shocker/raw/#{line_new}.txt")
          system("cat #{scanners_path}/shocker/raw/#{line_new}.txt >> #{scanners_path}/shocker/vulnerable.txt")
        end
      end
    else
        puts("python3 #{home}/Desktop/recon/shocker/shocker.py -H #{domain} -s -t #{threads} | tee -a #{scanners_path}/shocker/raw/#{domain}.txt")
        system("cat #{scanners_path}/shocker/raw/#{domain}.txt >> #{scanners_path}/shocker/vulnerable.txt")
    end
  end
end

class S3_Recon
  def start(org_name,aws_wordlist,final_subdomains,aws_path,threads,home)
    aws_list = "#{aws_path}/s3-list.txt"
    
    s3_wordlist(org_name,aws_list,aws_wordlist,final_subdomains)
    #s3_finder(home,org_name,aws_list,aws_path)
    s3_scanner(home,threads,aws_path)
  end
  
  def s3_wordlist(org_name,aws_list,aws_wordlist,final_subdomains)
    puts "#{'[*] Generating Quick Wordlist...'.cyan}"
  
    system("echo #{org_name} | anew #{aws_list}")
    system("cat #{aws_wordlist} | sed 's/$/-#{org_name}/' | sort -u | anew #{aws_list}")
    system("cat #{final_subdomains} | sed 's/https:\\/\\///' | sed 's/http:\\/\\///' | sort -u | anew #{aws_list}")
  end
  
  def s3_finder(home,org_name,aws_list,aws_path)
    puts "#{'[*] Finding AWS Buckets...'.light_blue}"
    puts "#{'[!] Starting Bucket Finder...'.light_blue}"
  
    system("#{home}/Desktop/recon/bucket_finder/bucket_finder.rb -v #{aws_list} | anew #{aws_path}/s3-list.raw")
    
    system("cat #{aws_path}/s3-list.raw | grep -v \"Bucket does not exist\" | cut -d ":" -f2 | anew #{aws_path}/s3-buckets.txt")
    puts "#{'[!] Bucket Finder Ended...'.cyan}"
  end
  
  def s3_scanner(home,threads,aws_path)
    puts "#{'[*] Scanning AWS Buckets...'.light_blue}"
    puts "#{'[!] Starting S3Scanner...'.light_blue}"
    puts("s3scanner -threads #{threads} -bucket-file #{aws_path}/s3-buckets.txt -enumerate")
    puts "#{'[!] S3Scanner Ended...'.cyan}"
  end
end

class Spider
  def start(final_urls,url_path,threads,root_domain,final_js,final_swf,final_subdomains)
    puts "#{'[!] GoSpider Started...'.light_blue}"
  
    system("gospider -S #{final_urls} -o #{url_path}/spider -c 3 --depth 3 --no-redirect -t #{threads} -w -r")
  
    puts "#{'[*] Combining Information...'.yellow}"
  
    system("cat #{url_path}/spider/* | grep #{root_domain} | grep -oE '(http|https)://(.*)' | sort -u | anew #{final_urls}")
  
    system("cat #{url_path}/spider/* | grep #{root_domain} | grep -oE '(http|https)://(.*).js' | sort -u | anew #{final_js}")
    system("cat #{url_path}/spider/* | grep #{root_domain} | grep -oE '(http|https)://(.*).json' | sort -u | anew #{final_js}")
    system("cat #{url_path}/spider/* | grep #{root_domain} | grep -oE '(http|https)://(.*).swf' | sort -u | anew #{final_swf}")
  
    system("cat #{url_path}/spider/* | grep #{root_domain} | perl -n -e '/\\b\\S+\\.(com|org|edu|net|eu)\\b/ && print $&,\"\\n\"; ' | sed 's/https:\\/\\///' | sed 's/http:\\/\\///' | sort -u | grep -v '\\\\' | anew #{final_subdomains}")
    system("cat #{url_path}/spider/* | grep #{root_domain} | perl -n -e '/\\b\\S+\\.(com|org|edu|net|eu)\\b/ && print $&,\"\\n\"; ' | sort -u | anew #{final_subdomains}")
  
    #Access Denied
    system("cat #{url_path}/spider/* | | grep \"\\[code-403\\]\" | grep -oE '(http|https)://(.*)' | sort -u | anew #{url_path}/access-denied/endpoints.txt")
  
    puts "#{'[*] GoSpider Ended...'.cyan}"
  end
end

class Changeme_Scan
  def start(home,all,domain,root_domain,sub_list,scanners_path,threads)
    if all == true
      puts "#{'[*] Default Credential Scanner...'.light_blue}"
      puts "#{'[!] Changeme Started...'.light_blue}"
  
      line_num=0
      text=File.open("#{sub_list}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
  
        line_new = line.strip
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        
        if File.file?("#{scanners_path}/changeme/#{line_new}/vulnerable.csv")
          puts "#{'[*] Already Scanned'.red}"
        else
          system("mkdir -p #{scanners_path}/changeme/#{line_new}")
          system("python3 #{home}/Desktop/recon/changeme/changeme.py #{line_new} -v --all -t #{threads} -o #{scanners_path}/changeme/#{line_new}/vulnerable --oa")
          system("cat #{scanners_path}/changeme/#{line_new}/vulnerable.csv | anew #{scanners_path}/changeme/vulnerable.csv")
        end
      end
    else
      puts "#{'[*] Default Credential Scanner...'.light_blue}"
      puts "#{'[!] Changeme Started...'.light_blue}"
      
        system("mkdir -p #{scanners_path}/changeme/#{domain}")
        system("python3 #{home}/Desktop/recon/changeme/changeme.py #{domain} -v --all -t #{threads} -o #{scanners_path}/changeme/#{domain}/vulnerable --oa")
        system("cat #{scanners_path}/changeme/#{domain}/vulnerable.csv | anew #{scanners_path}/changeme/vulnerable.csv")
    end
  end
end

class CMSMap
  def start(home,all,domain,root_domain,final_subdomains,sub_path,portscan_path,output,threads,scanners_path)
    puts "#{'[*] CMS Scanner...'.light_blue}"
    puts "#{'[!] CMSMap Started...'.light_blue}"
    system("mkdir -p #{scanners_path}/cmsmap/raw")
    if all == true
      line_num=0
      text=File.open("#{final_subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
  
        line_new = line.strip
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        
        if File.file?("#{scanners_path}/cmsmap/raw/#{line_new}.txt")
          puts "#{'[*] Already Scanned'.red}"
        else
          system("cmsmap https://#{line_new} -F -o #{scanners_path}/cmsmap/raw/#{line_new}.txt -s -t #{threads}")
          system("cat #{scanners_path}/cmsmap/raw/#{line_new}.txt >> #{scanners_path}/cmsmap/vulnerable.txt")
        end
      end
    else
        system("cmsmap https://#{domain} -F -o #{scanners_path}/cmsmap/raw/#{domain}.txt -t #{threads}")
        system("cat #{scanners_path}/cmsmap/raw/#{domain}.txt >> #{scanners_path}/cmsmap/vulnerable.txt")
    end
  end
end

class Nuclei
  def start(all,urls,nuclei_templates,output,scanners_path,domain)
    if all == true
      system("mkdir -p #{scanners_path}/nuclei/#{domain}/")
      
      puts "#{'[*] DNS Exploits'.light_blue}"
      system("nuclei -l #{final_subdomains} -t #{nuclei_templates}/dns -o #{scanners_path}/nuclei/dns.txt")
      
      puts "#{'[*] Subdomain Takeover'.light_blue}"
      system("nuclei -l #{final_subdomains} -t #{nuclei_templates}/subdomain-takeover/ -o #{scanners_path}/nuclei/takeover.txt")
      
      puts "#{'[*] Services Info & Technologies'.light_blue}"
      system("nuclei -l #{final_subdomains} -t #{nuclei_templates}/technologies -o #{scanners_path}/nuclei/technologies.txt")
      
      puts "#{'[*] Security Misconfiguration'.light_blue}"
      system("nuclei -l #{final_subdomains} -t #{nuclei_templates}/security-misconfiguration -o #{scanners_path}/nuclei/misconfiguration.txt")
      
      puts "#{'[*] Vulnerabilities, Generic Detection, CVEs & Payload'.light_blue}"
      system("nuclei -l #{final_subdomains} -t #{nuclei_templates}/cves/ -t #{nuclei_templates}/brute-force/ -t #{nuclei_templates}/vulnerabilities/ -o #{scanners_path}/nuclei/#{domain}vulnerabilities.txt")
    else

      system("mkdir -p #{scanners_path}/nuclei/#{domain}/")
      
      puts "#{'[*] DNS Exploits'.light_blue}"
      system("nuclei -u https://#{domain} -t #{nuclei_templates}/dns -o #{scanners_path}/nuclei/#{domain}/dns.txt")
      
      puts "#{'[*] Subdomain Takeover'.light_blue}"
      system("nuclei -u https://#{domain} -t #{nuclei_templates}/subdomain-takeover/ -o #{scanners_path}/nuclei/#{domain}/takeover.txt")
      
      puts "#{'[*] Services Info & Technologies'.light_blue}"
      system("nuclei -u https://#{domain} -t #{nuclei_templates}/technologies -o #{scanners_path}/nuclei/#{domain}/technologies.txt")
      
      puts "#{'[*] Security Misconfiguration'.light_blue}"
      system("nuclei -u https://#{domain} -t #{nuclei_templates}/security-misconfiguration -o #{scanners_path}/nuclei/#{domain}/misconfiguration.txt")
      
      puts "#{'[*] Vulnerabilities, Generic Detection, CVEs & Payload'.light_blue}"
      system("nuclei -u https://#{domain} -t #{nuclei_templates}/cves/ -t #{nuclei_templates}/brute-force/ -t #{nuclei_templates}/vulnerabilities/ -o #{scanners_path}/nuclei/#{domain}/vulnerabilities.txt")
    end
  end
end

class Zigoo
  def start(home,scanners_path,final_urls)
    puts "#{'[*] Finding...'.light_blue}"
    system("python3 #{home}/Desktop/recon/webpwn3r/scan.py -m 2 -u #{final_urls} | tee #{scanners_path}/zigoo/output.txt")
    system("cat #{scanners_path}/zigoo/output.txt | grep POC > #{scanners_path}/zigoo/POC.txt")
  end
end

class Yasuo
  def start(home,all,subdomains,threads,domain,scanners_path)
    puts "#{'[*] Finding Vulnerable Applications...'.light_blue}"
    puts "#{'[!] Yasuo Started...'.light_blue}"
    if all == true
      Dir.chdir(''+home+'/Desktop/recon/yasuo') do
        system("bundler exec \"./yasuo.rb -s signatures_top.yaml -l #{subdomains} -p 80,8080,443,8443 -t #{threads} -b all\"")
      end
    else
      Dir.chdir(''+home+'/Desktop/recon/yasuo') do
        system("bundler exec \"./yasuo.rb -s signatures_top.yaml -r #{domain} -p 80,8080,443,8443 -t #{threads} -b all\"")
      end 
    end
    system("cp -nf #{home}/Desktop/recon/yasuo/logs/yasuo*.db #{scanners_path}/yasuo")
    system("cp -nf #{home}/Desktop/recon/yasuo/logs/yasuo*.log #{scanners_path}/yasuo")
  end
end

class Passive_DNS
  def start(all,final_subdomains,root_domain,wordlist,domain,threads,dns_path,final_ips,final_dns,workflow,aws_path)
    dnsrecon(all,final_subdomains,root_domain,wordlist,domain,threads,dns_path)
    puts
    dnsenum(all,final_subdomains,root_domain,wordlist,domain,threads,dns_path)
    #puts
    #nmap(all,final_subdomains,root_domain,wordlist,domain,threads,dns_path)
    parse(dns_path,final_subdomains,final_ips,final_dns,workflow,root_domain,aws_path)
  end
  def dnsrecon(all,final_subdomains,root_domain,wordlist,domain,threads,dns_path)
    puts "#{'[!] DNSRecon Started...'.light_blue}"
    if all == true
      line_num=0
      text=File.open("#{final_subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
      text.each_line do |line|
        line_new = line.strip
        
        if line_new["#{root_domain}"]
          puts("#{'[*] Executing on '}#{line_new}".yellow)
          system("mkdir -p #{dns_path}/raw/#{line_new}/")
          system("dnsrecon -d #{line_new} -D #{wordlist} --threads #{threads} --iw -a --csv #{dns_path}/raw/#{line_new}/dnsrecon.txt")
        end
      end
    else
      system("mkdir -p #{dns_path}/raw/#{domain}")
      system("dnsrecon -d #{domain} -D #{wordlist} --threads #{threads} --iw -a --csv #{dns_path}/raw/#{domain}/dnsrecon.txt")
    end
    puts "#{'[!] DNSRecon Ended...'.light_blue}"
  end
  
  def dnsenum(all,final_subdomains,root_domain,wordlist,domain,threads,dns_path)
    puts "#{'[!] DNSEnum Started...'.light_blue}"
    if all == true
      line_num=0
      text=File.open("#{final_subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
      text.each_line do |line|
        line_new = line.strip
        
        if line_new["#{root_domain}"]
          puts("#{'[*] Executing on '}#{line_new}".yellow)
          if File.file?("#{dns_path}/raw/#{line_new}/dnsenum.txt")
            puts "#{'[*] Already Scanned'.red}"
          else
            system("mkdir -p #{dns_path}/raw/#{line_new}/")
            system("dnsenum --noreverse #{line_new} --threads #{threads} > #{dns_path}/raw/#{line_new}/dnsenum.txt")
          end
        end
      end
    else
        system("mkdir -p #{dns_path}/raw/#{domain}")
        system("dnsenum --noreverse #{domain} --threads #{threads} > #{dns_path}/raw/#{domain}/dnsenum.txt")
    end
    puts "#{'[!] DNSEnum Ended...'.light_blue}"
  end
  
  def nmap(all,final_subdomains,root_domain,wordlist,domain,threads,dns_path)
    puts "#{'[!] Nmap Started...'.light_blue}"
    if all == true
      line_num=0
      text=File.open("#{final_subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
      text.each_line do |line|
        line_new = line.strip
        
        if line_new["#{root_domain}"]
          puts("#{'[*] Executing on '}#{line_new}".yellow)
          system("mkdir -p #{dns_path}/raw/#{line_new}/")
          system("nmap -T4 -p 53 --script dns-brute -o #{dns_path}/raw/#{line_new}/nmap.txt #{line_new} -Pn")
        end
      end
    else
      system("mkdir -p #{dns_path}/raw/#{domain}")
      system("nmap -T4 -p 53 --script dns-brute -o #{dns_path}/raw/#{domain}/nmap.txt #{domain} -Pn")
    end
    puts "#{'[!] DNSEnum Ended...'.light_blue}"
  end
  
  def parse(dns_path,final_subdomains,final_ips,final_dns,workflow,root_domain,aws_path)
    puts "#{'[*] Combining Information...'.cyan}"
    puts "#{'[*] Searching Subdomains...'.yellow}"
    system("cat #{dns_path}/*/*/dnsenum.txt | sed \"s/[\\/]//g\" | perl -n -e '\/\\b\\S+\\.(com|org|edu|net|eu)\\b\/ && print $&,\"\\n\"; ' | sort -u | grep -v '\\\\' | qsreplace | /usr/local/bin/httpx | cut -d : -f2 | cut -c 3- | anew #{final_subdomains}")
    #puts "#{'[*] Searching IPs...'.yellow}"
    #system("cat *_ips.txt | grep -oE \"\\b([0-9]{1,3}\\.){3}[0-9]{1,3}\\b\" | sort -u | qsreplace | httpx -follow-redirects -silent | cut -d : -f2 | cut -c 3- | sort -u | anew #{final_ips}")
    #puts("rm *_ips.txt")
    puts "#{'[*] Saving Output...'.yellow}"
    system("cat #{workflow}/#{root_domain}/info/*/*.txt #{dns_path}/raw/*/dnsenum.txt | grep -a IN > #{final_dns}")
    system("cat #{final_dns} | grep -v #{root_domain} | grep -v amazonaws.com | anew #{workflow}/root-domains.txt")
    system("cat #{final_dns} | grep amazonaws.com | perl -n -e '/\\b\\S+\\.(com|org|edu|net|eu)\\b/ && print $&,\"\\n\"; ' | sed 's/\\\.amazonaws.com//' | anew #{aws_path}/s3-buckets.txt")
  end
end

class Joomla
  def start(home,all,domain,sub_list,root_domain,output,scanners_path,url_path)
    #joom_scan_reports = "/usr/share/joomscan/reports"
    puts "#{'[*] Joom Vulnerability Scanner...'.light_blue}"
    puts "#{'[!] JoomScan Started...'.light_blue}"
    
    if all == true
      line_num=0
      text=File.open("#{sub_list}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
        line_new = line.strip
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        
        if File.directory?("#{scanners_path}/joom/#{line_new}")
          puts "#{'[*] Already Scanned'.red}"
        else
          system("perl #{home}/Desktop/recon/joomscan/joomscan.pl -u http://#{line_new} -ec")
          #system("cp -r #{joom_scan_reports}/#{line_new} #{output}")
          #system("cat #{output}/*/*.txt | anew #{url_path}/access-denied/endpoints.txt")
        end
      end
    else
        system("perl #{home}/Desktop/recon/joomscan/joomscan.pl -u https://#{domain} -ec")
        #system("cp -r #{joom_scan_reports}/#{domain} #{output}")
        #system("cat #{output}/*/*.txt | anew #{url_path}/access-denied/endpoints.txt")
    end
  end
end

class Directory_Fuzz
  def start(home,all,root_domain,sub_list,final_urls,final_directories,directory_path,wordlist,threads,domain)
    system("mkdir -p #{directory_path}/dirsearch/raw")
    if all == true
      line_num=0
      text=File.open("#{sub_list}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
  
        line_new = line.strip
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        
        if File.file?("#{directory_path}/dirsearch/raw/#{line_new}.txt")
          puts "#{'[*] Already Scanned'.red}"
        else
          system("#{home}/Desktop/recon/dirsearch/dirsearch.py -u https://#{line_new} -w #{wordlist} -e js,php,bak,txt,asp,aspx,jsp,html,zip,jar,sql,json,old,gz,shtml,log,swp,yaml,yml,config,save,rsa,ppk,tar --format simple -o #{directory_path}/dirsearch/dirsearch_output.txt | tee #{directory_path}/dirsearch/subdomains_content_discovery.txt")
  
         system("cat #{directory_path}/dirsearch/dirsearch_output.txt | awk -Fhttp '{print $NF}' | awk '$0=\"http\"$0' | sed 's/:80//' | sed 's/:443//' | sort -u | anew #{directory_path}/dirsearch/raw/#{line_new}.txt")
         system("cat #{directory_path}/dirsearch/raw/#{line_new}.txt | anew #{final_directories}")
         system("rm #{directory_path}/dirsearch/dirsearch_output.txt")
       
         system("cat #{directory_path}/dirsearch/raw/#{line_new}.txt | anew #{final_urls}")
       end
     end
    else
      puts("#{home}/Desktop/recon/dirsearch/dirsearch.py -u https://#{domain} -w #{wordlist} -e js,php,bak,txt,asp,aspx,jsp,html,zip,jar,sql,json,old,gz,shtml,log,swp,yaml,yml,config,save,rsa,ppk,tar --format simple -o #{directory_path}/dirsearch/dirsearch_output.txt | tee #{directory_path}/dirsearch/subdomains_content_discovery.txt")
  exit
      system("cat #{directory_path}/dirsearch/dirsearch_output.txt | awk -Fhttp '{print $NF}' | awk '$0=\"http\"$0' | sed 's/:80//' | sed 's/:443//' | sort -u | anew #{directory_path}/dirsearch/raw/#{domain}.txt")
      system("cat #{directory_path}/dirsearch/raw/#{domain}.txt | anew #{final_directories}")
      system("rm #{directory_path}/dirsearch/dirsearch_output.txt")
       
      system("cat #{directory_path}/dirsearch/raw/#{domain}.txt | anew #{final_urls}")
    end
  end
end

class Files_Fuzz
  def start(all,root_domain,sub_list,final_urls,final_directories,directory_path,wordlist,threads,domain)
    if all == true
      line_num=0
      text=File.open("#{sub_list}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
  
       url = line.strip
       fqdn = `echo #{url} | sed -e 's;https\\?://;;' | sed -e 's;/.*$;;' | sort -u` 
       tmp = "#{directory_path}/dirsearch/file/#{fqdn.strip}.tmp"
  
       system("dirsearch -b -t #{threads} -e php,asp,aspx,jsp,html,zip,jar,sql -x 500,503 -r -w #{wordlist} -o #{tmp} --format plain -u #{url}")
  
       system("cat #{tmp} | sort -u | grep \"   \" | anew #{directory_path}/dirsearch/file/#{fqdn.strip}.txt")
       system("cat #{directory_path}/dirsearch/file/*.txt | awk -Fhttp '{print $NF}' | awk '$0=\"http\"$0' | sed 's/:80//' | sed 's/:443//' | sort -u | anew #{directory_path}/dirsearch/files.txt")
       system("cat #{directory_path}/dirsearch/*.txt | anew #{final_directories}")
  
       system("cat #{final_directories} | sort -u | anew #{final_urls}")
  
       if File.file? (tmp)
         system("rm #{tmp}")
       end
     end
    else
      line_num=0
      text=File.open("#{sub_list}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
  
        url = line.strip
        if url["//#{domain}"]
          tmp = "#{directory_path}/dirsearch/file/#{line_new}.tmp"
          system("dirsearch -b -t #{threads} -e php,asp,aspx,jsp,html,zip,jar,sql -x 500,503 -r -w #{wordlist} -o #{tmp} --format plain -u #{url}")
          system("cat #{tmp} | sort -u | grep \"   \" | anew #{directory_path}/dirsearch/file/#{line_new}.txt")
          system("cat #{directory_path}/dirsearch/file/*.txt | awk -Fhttp '{print $NF}' | awk '$0=\"http\"$0' | sed 's/:80//' | sed 's/:443//' | sort -u | anew #{directory_path}/dirsearch/files.txt")
  
          system("cat #{directory_path}/dirsearch/*.txt | anew #{final_directories}")
    
          system("cat #{final_directories} | sort -u | anew #{final_urls}")
          if File.file? (tmp)
            system("rm #{tmp}")
          end
        end
      end
    end
  end
end

class Get_Info
  def start(home,all,sub_list,info_path,spf_path,threads,final_js,final_swf,final_urls,domain,root_domain)
    pid = "/root/.local/share/finalrecon/finalrecon.pid"
    if File.file?(pid)
      system("rm #{pid}")
    end
    finalrecon_dumps = "/root/.local/share/finalrecon/dumps"
    assets_from_spf_location = "#{home}/Desktop/recon/assets-from-spf"
    if all == true
      line_num=0
      text=File.open("#{sub_list}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
  
        line_new = line.strip
  
        if line_new["#{root_domain}"]
          if File.file?("#{info_path}/dns/#{line_new}.txt")
            puts "#{'[*] Already Scanned'.red}"
          else
            puts("#{'[*] Executing on '}#{line_new}".yellow)
          
            puts("#{'[*] Doing WHOIS...'.cyan}")
            system("pwhois -o list #{line_new} > #{info_path}/whois/#{line_new}.txt")
            puts("#{'[*] Finding ASN...'.cyan}")
            system("asn -n #{line_new} | anew #{info_path}/asn/#{line_new}.txt")
            puts("#{'[*] Standard DNS...'.cyan}")
            system("finalrecon --url https://#{line_new} -T #{threads} --headers --sslinfo --crawl --dns --ps -o txt && mv -f #{finalrecon_dumps}/*#{line_new}*/* #{info_path}/dns/")
  
            parse(info_path,final_js,final_swf,final_urls)
          end 
        end
      end
    else
        puts("#{'[*] Doing WHOIS...'.cyan}")
        system("pwhois -o list #{domain} > #{info_path}/whois/#{domain}.txt")
        puts("#{'[*] Finding ASN...'.cyan}")
        system("asn -n #{domain} | anew #{info_path}/asn/#{domain}.txt")
        puts("#{'[*] Standard DNS...'.cyan}")
        system("finalrecon --url https://#{domain} -T #{threads} --headers --sslinfo --crawl --dns --ps -o txt && mv -f #{finalrecon_dumps}/*#{domain}*/* #{info_path}/dns/")
  
        parse(info_path,final_js,final_swf,final_urls)
    end
  end
  
  def parse(info_path,final_js,final_swf,final_urls)
    puts ("#{'[*] Finding URLs...'.cyan}")
    system("cat #{info_path}/*/*.txt | grep -oE '(http|https)://(.*)' | sed s/\"'\"/\"\"/g | sed '/^$/d' | tr -d '()' | tr -d '[]' | sort -u | anew #{final_urls}")
    
  
    puts("#{'[*] Finding JS Files...'.cyan}")
    system("cat #{info_path}/*/*.txt | grep -oE '(http|https)://(.*).js' | sed s/\"'\"/\"\"/g | sed '/^$/d' | tr -d '[]' | tr -d '()' | sort -u | anew #{final_js}") 
  
    puts("#{'[*] Finding SWF Files...'.cyan}")
    system("cat #{info_path}/*/*.txt | grep -oE '(http|https)://(.*).swf' | sed s/\"'\"/\"\"/g | sed '/^$/d' | tr -d '[]' | tr -d '()' | sort -u | anew #{final_swf}") 
  end
end

class Params_Discovery
  def start(final_urls,threads,final_params)
    puts "#{'[!] Arjun Started...'.light_blue}"
    puts "#{'[*] Finding Parameters...'.cyan}"
    system("arjun -i #{final_urls} -t #{threads} -m GET,POST -d 2 -oT #{final_params}") 
    puts "#{'[*] Arjun Ended...'.cyan}"
  end
end

class Cors
  def start(home,final_subdomains,threads,cors_path,final_cors,all,domain)
    puts "#{'[!] CORScanner Started...'.light_blue}"
    system("mkdir -p #{cors_path}/raw")
    if all == true
      line_num=0
      text=File.open("#{final_subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
        line_new = line.strip
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        
        if File.file?("#{cors_path}/raw/#{line_new}.txt")
          puts "#{'[*] Already Scanned'.red}"
        else
          system("python3 #{home}/Desktop/recon/CORScanner/cors_scan.py -u #{line_new} -t #{threads} -o #{cors_path}/raw/#{line_new}.txt")
          system("cat #{cors_path}/raw/#{line_new}.txt | anew #{final_cors}")
        end
      end
    else 
        system("python3 #{home}/Desktop/recon/CORScanner/cors_scan.py -u #{domain} -t #{threads} -o #{cors_path}/raw/#{domain}.txt")
        system("cat #{cors_path}/raw/#{domain}.txt | anew #{final_cors}")
    end
  end
end

class Broken_Links
  def start(final_subdomains,final_urls,final_js,final_swf,broken_links,url_path,all,domain,root_domain,workflow,aws_path)
    puts "#{'[!] BLC Started...'.light_blue}"
    system("mkdir -p #{url_path}/links/raw")
    
    if all == true
      line_num=0
      text=File.open("#{final_subdomains}").read
      text.gsub!(/\\r\\n/, "\\n")
  
      text.each_line do |line|
        line_new = line.strip
        puts("#{'[*] Executing on '}#{line_new}".yellow)
        blc_raw = "#{url_path}/links/raw/#{line_new}.txt"
        if File.file?("#{blc_raw}")
          puts "#{'[*] Already Scanned'.red}"
        else
          system("blc http://#{line_new} --filter-level 3 | sort -u | tee -a #{blc_raw}")
          parse(blc_raw,final_subdomains,final_urls,final_js,final_swf,broken_links,url_path,root_domain,workflow,aws_path)
        end
      end
    else
      blc_raw = "#{url_path}/links/raw/#{domain}.txt"

      system("blc https://#{domain} --filter-level 3 | sort -u | tee -a #{blc_raw}")
        parse(blc_raw,final_subdomains,final_urls,final_js,final_swf,broken_links,url_path,root_domain,workflow,aws_path)
    end
    puts "#{'[*] BLC Ended...'.cyan}"
  end
  
  def parse(blc_raw,final_subdomains,final_urls,final_js,final_swf,broken_links,url_path,root_domain,workflow,aws_path)
    puts "#{'[*] Combining Information...'.light_blue}"
    
    system("cat #{blc_raw} | grep amazonaws.com | perl -n -e '/\\b\\S+\\.(com|org|edu|net|eu)\\b/ && print $&,\"\\n\"; ' | sed 's/\\\.amazonaws.com//' | sort -u | anew #{aws_path}/s3-buckets.txt")
  
    puts "#{'[*] Finding URLs...'.cyan}"
    puts("cat #{blc_raw} | grep -oE '(http|https)://(.*)' | sort -u | anew #{final_urls}")
  
    puts "#{'[*] Finding JS...'.cyan}"
    system("cat #{blc_raw} | grep -oE '(http|https)://(.*).js' | sort -u | anew #{final_js}")
    system("cat #{blc_raw} | grep -oE '(http|https)://(.*).json' | sort -u | anew #{final_js}")
  
    puts "#{'[*] Finding SWF...'.cyan}"
    system("cat #{blc_raw} | grep -oE '(http|https)://(.*).swf' | sort -u | anew #{final_swf}")
  
    puts "#{'[*] Finding Broken Links...'.cyan}"
    system("cat #{blc_raw} | grep BROKEN | grep -oE '(http|https)://(.*)' | sort -u | anew #{broken_links}")
  end
end
