#!/bin/bash
# TheMasterRecon AI — SecretHunter Binary Installer
# Run from your app directory

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
BIN="$APP_DIR/secret_hunter"

echo "=== SecretHunter Binary Installer ==="
echo "App dir: $APP_DIR"

# Check if already exists
if [ -f "$BIN" ] && [ -x "$BIN" ]; then
    echo "✓ secret_hunter already installed at $BIN"
    exit 0
fi

# Try to find it in common locations
for loc in \
    ~/Downloads/secret_hunter \
    ~/secret_hunter \
    /opt/secret_hunter \
    /usr/local/bin/secret_hunter; do
    if [ -f "$loc" ]; then
        cp "$loc" "$BIN"
        chmod +x "$BIN"
        echo "✓ Copied from $loc"
        exit 0
    fi
done

echo ""
echo "SecretHunter binary not found automatically."
echo ""
echo "Manual steps:"
echo "  1. Download secret_hunter binary"
echo "  2. Run: cp /path/to/secret_hunter $BIN"
echo "  3. Run: chmod +x $BIN"
echo "  4. Restart TheMasterRecon AI"
echo ""
echo "NOTE: The app has a built-in license bypass — NO KEY NEEDED"
echo "      3-layer JS scanning works even without this binary"
