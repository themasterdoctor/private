#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════
# TheMasterRecon — Manual Install for Failing Tools
# Run: chmod +x install_manual.sh && sudo ./install_manual.sh
# ══════════════════════════════════════════════════════════

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "${GREEN}  ✔ $1${NC}"; }
warn() { echo -e "${YELLOW}  ⚠ $1${NC}"; }
fail() { echo -e "${RED}  ✗ $1${NC}"; }
info() { echo -e "${CYAN}  → $1${NC}"; }

export GOPATH="$HOME/go"
export GOBIN="$HOME/go/bin"
export PATH="$PATH:$GOBIN:/usr/local/go/bin"
mkdir -p "$GOBIN"

echo ""
echo "  TheMasterRecon — Manual Tool Installer"
echo "══════════════════════════════════════════════════════"

# ══════════════════════════════════════════════════════════
# 1. CLOUDBRUTE
# ══════════════════════════════════════════════════════════
echo ""
echo "[1] cloudbrute — Cloud bucket discovery"
if command -v cloudbrute &>/dev/null; then
    ok "cloudbrute already installed"
else
    info "Trying go install..."
    go install github.com/0xsha/cloudbrute@latest 2>/dev/null
    if command -v cloudbrute &>/dev/null || [ -f "$GOBIN/cloudbrute" ]; then
        cp "$GOBIN/cloudbrute" /usr/local/bin/ 2>/dev/null
        ok "cloudbrute installed via go"
    else
        info "Trying from GitHub releases..."
        ARCH=$(uname -m)
        [ "$ARCH" = "x86_64" ] && ARCH="amd64" || ARCH="arm64"
        URL="https://github.com/0xsha/cloudbrute/releases/latest/download/cloudbrute_linux_${ARCH}"
        wget -q --timeout=30 "$URL" -O /usr/local/bin/cloudbrute 2>/dev/null
        chmod +x /usr/local/bin/cloudbrute 2>/dev/null
        if command -v cloudbrute &>/dev/null; then
            ok "cloudbrute installed from releases"
        else
            info "Trying git clone + build..."
            cd /tmp
            git clone -q https://github.com/0xsha/cloudbrute 2>/dev/null
            if [ -d cloudbrute ]; then
                cd cloudbrute
                go build -o /usr/local/bin/cloudbrute ./cmd/cloudbrute 2>/dev/null || \
                go build -o /usr/local/bin/cloudbrute . 2>/dev/null
                cd /tmp && rm -rf cloudbrute
            fi
            command -v cloudbrute &>/dev/null && ok "cloudbrute built from source" || fail "cloudbrute — check Go installation: go version"
        fi
    fi
fi

# ══════════════════════════════════════════════════════════
# 2. KITERUNNER WORDLISTS
# ══════════════════════════════════════════════════════════
echo ""
echo "[2] Kiterunner wordlists"
KR_DIR="$HOME/Desktop/recon/kiterunner"
mkdir -p "$KR_DIR"

# routes-large.kite — try multiple sources
if [ ! -f "$KR_DIR/routes-large.kite" ] || [ "$(stat -c%s "$KR_DIR/routes-large.kite" 2>/dev/null || echo 0)" -lt 1000000 ]; then
    info "Downloading routes-large.kite..."
    
    SOURCES_LARGE=(
        "https://wordlists-cdn.assetnote.io/data/kiterunner/routes-large.kite"
        "https://github.com/assetnote/kiterunner/releases/download/v1.0.2/routes-large.kite"
        "https://github.com/assetnote/kiterunner/releases/latest/download/routes-large.kite"
    )
    for url in "${SOURCES_LARGE[@]}"; do
        info "  Trying $url ..."
        wget -q --timeout=60 --tries=2 --continue "$url" -O "$KR_DIR/routes-large.kite" 2>/dev/null
        SIZE=$(stat -c%s "$KR_DIR/routes-large.kite" 2>/dev/null || echo 0)
        if [ "$SIZE" -gt 1000000 ]; then
            ok "routes-large.kite ($(du -sh "$KR_DIR/routes-large.kite" | cut -f1))"
            break
        else
            rm -f "$KR_DIR/routes-large.kite"
        fi
    done
    
    # If still missing, compile from text list
    if [ ! -f "$KR_DIR/routes-large.kite" ] && command -v kr &>/dev/null; then
        info "Compiling routes-large.kite from API text list..."
        # Find or download a text list
        TEXT_SRC=""
        for p in \
            "$KR_DIR/apiroutes.txt" \
            "/usr/share/seclists/Discovery/Web-Content/api/api-endpoints.txt" \
            "/usr/share/wordlists/seclists/Discovery/Web-Content/api/api-endpoints.txt"; do
            [ -s "$p" ] && TEXT_SRC="$p" && break
        done
        if [ -z "$TEXT_SRC" ]; then
            info "Downloading API text list for compilation..."
            wget -q --timeout=30 \
                "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/Web-Content/api/api-endpoints.txt" \
                -O "$KR_DIR/apiroutes.txt" 2>/dev/null
            [ -s "$KR_DIR/apiroutes.txt" ] && TEXT_SRC="$KR_DIR/apiroutes.txt"
        fi
        if [ -n "$TEXT_SRC" ]; then
            kr kb compile "$TEXT_SRC" -o "$KR_DIR/routes-large.kite" 2>/dev/null && \
                ok "routes-large.kite compiled from $TEXT_SRC ($(du -sh "$KR_DIR/routes-large.kite" | cut -f1))" || \
                warn "kr kb compile failed"
        fi
    fi
    
    # Final fallback: use routes-small if large unavailable
    if [ ! -f "$KR_DIR/routes-large.kite" ]; then
        warn "routes-large.kite unavailable — kr will use apiroutes.txt as fallback"
        warn "  To get it later: kr kb compile $KR_DIR/apiroutes.txt -o $KR_DIR/routes-large.kite"
    fi
else
    ok "routes-large.kite already exists ($(du -sh "$KR_DIR/routes-large.kite" | cut -f1))"
fi

# routes-small.kite
if [ ! -f "$KR_DIR/routes-small.kite" ] || [ "$(stat -c%s "$KR_DIR/routes-small.kite" 2>/dev/null || echo 0)" -lt 10000 ]; then
    info "Downloading routes-small.kite..."
    SOURCES_SMALL=(
        "https://wordlists-cdn.assetnote.io/data/kiterunner/routes-small.kite"
        "https://github.com/assetnote/kiterunner/releases/download/v1.0.2/routes-small.kite"
    )
    for url in "${SOURCES_SMALL[@]}"; do
        wget -q --timeout=60 --tries=2 "$url" -O "$KR_DIR/routes-small.kite" 2>/dev/null
        SIZE=$(stat -c%s "$KR_DIR/routes-small.kite" 2>/dev/null || echo 0)
        if [ "$SIZE" -gt 10000 ]; then
            ok "routes-small.kite ($(du -sh "$KR_DIR/routes-small.kite" | cut -f1))"
            break
        else
            rm -f "$KR_DIR/routes-small.kite"
        fi
    done
    [ ! -f "$KR_DIR/routes-small.kite" ] && warn "routes-small.kite unavailable"
else
    ok "routes-small.kite already exists ($(du -sh "$KR_DIR/routes-small.kite" | cut -f1))"
fi

# swagger wordlist
if [ ! -f "$KR_DIR/swagger-wordlist.txt" ] && [ ! -f "$KR_DIR/swagger.txt" ]; then
    info "Downloading swagger wordlist..."
    SWAGGER_SOURCES=(
        "https://wordlists-cdn.assetnote.io/data/automated/httparchive_swagger_all_2022_01_19.txt"
        "https://wordlists-cdn.assetnote.io/data/automated/httparchive_swagger_all_2021_11_04.txt"
        "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/Web-Content/swagger.txt"
    )
    for url in "${SWAGGER_SOURCES[@]}"; do
        wget -q --timeout=60 --tries=2 "$url" -O "$KR_DIR/swagger-wordlist.txt" 2>/dev/null
        SIZE=$(stat -c%s "$KR_DIR/swagger-wordlist.txt" 2>/dev/null || echo 0)
        if [ "$SIZE" -gt 1000 ]; then
            ok "swagger-wordlist.txt ($(du -sh "$KR_DIR/swagger-wordlist.txt" | cut -f1))"
            break
        else
            rm -f "$KR_DIR/swagger-wordlist.txt"
        fi
    done
    [ ! -f "$KR_DIR/swagger-wordlist.txt" ] && warn "swagger-wordlist.txt unavailable — not critical"
else
    ok "swagger wordlist already exists"
fi

# ══════════════════════════════════════════════════════════
# 3. PACU — AWS exploitation framework
# ══════════════════════════════════════════════════════════
echo ""
echo "[3] pacu — AWS exploitation framework"
if command -v pacu &>/dev/null; then
    ok "pacu already installed"
else
    info "Installing pacu..."
    # pacu often has dependency conflicts - use a virtual approach
    pip3 install pacu --break-system-packages -q 2>/dev/null
    if command -v pacu &>/dev/null; then
        ok "pacu installed"
    else
        # Try pipx (cleaner for tools with conflicts)
        if command -v pipx &>/dev/null; then
            pipx install pacu 2>/dev/null && ok "pacu installed via pipx" || \
            warn "pacu install failed — try: pipx install pacu"
        else
            # Install pipx then pacu
            pip3 install pipx --break-system-packages -q 2>/dev/null
            python3 -m pipx install pacu 2>/dev/null && ok "pacu installed via pipx" || \
            warn "pacu install failed — it has many deps, try: pip3 install pacu --break-system-packages"
        fi
    fi
fi

# ══════════════════════════════════════════════════════════
# 4. SCOUTSUITE — Multi-cloud security auditing
# ══════════════════════════════════════════════════════════
echo ""
echo "[4] scoutsuite — Multi-cloud security auditing"
if command -v scout &>/dev/null || command -v scoutsuite &>/dev/null; then
    ok "scoutsuite already installed"
else
    info "Installing scoutsuite..."
    pip3 install scoutsuite --break-system-packages -q 2>/dev/null
    if command -v scout &>/dev/null || command -v scoutsuite &>/dev/null; then
        ok "scoutsuite installed"
    else
        # Try pipx
        pipx install scoutsuite 2>/dev/null && ok "scoutsuite installed via pipx" || \
        warn "scoutsuite install failed — large package with many deps"
        info "  Alternative: pip3 install scoutsuite --break-system-packages"
        info "  Or: docker run -it nccgroup/scoutsuite (Docker version)"
    fi
fi

# ══════════════════════════════════════════════════════════
# 5. KNOCKPY — Subdomain scanner
# ══════════════════════════════════════════════════════════
echo ""
echo "[5] knockpy — Subdomain scanner"
if command -v knockpy &>/dev/null; then
    ok "knockpy already installed"
else
    info "Installing knockpy..."
    # Try pip first
    pip3 install knockpy --break-system-packages -q 2>/dev/null
    if command -v knockpy &>/dev/null; then
        ok "knockpy installed via pip"
    else
        # Try from GitHub directly (knockpy can be finicky with pip)
        info "Trying GitHub install..."
        cd /tmp
        git clone -q https://github.com/guelfoweb/knock 2>/dev/null
        if [ -d knock ]; then
            cd knock
            pip3 install -r requirements.txt --break-system-packages -q 2>/dev/null
            cp knockpy/knockpy.py /usr/local/bin/knockpy 2>/dev/null
            chmod +x /usr/local/bin/knockpy 2>/dev/null
            # Or install as module
            python3 setup.py install 2>/dev/null || pip3 install . --break-system-packages -q 2>/dev/null
            cd /tmp && rm -rf knock
        fi
        command -v knockpy &>/dev/null && ok "knockpy installed from GitHub" || \
        warn "knockpy failed — try: pip3 install knockpy --break-system-packages"
    fi
fi

# ══════════════════════════════════════════════════════════
# SUMMARY
# ══════════════════════════════════════════════════════════
echo ""
echo "══════════════════════════════════════════════════════"
echo "  Results:"
echo ""

for tool_check in "cloudbrute" "pacu" "scout:scoutsuite" "knockpy" "kr"; do
    display="${tool_check%%:*}"
    check="${tool_check##*:}"
    [ "$check" = "$tool_check" ] && check="$tool_check"
    if command -v "$display" &>/dev/null || command -v "$check" &>/dev/null || \
       [ -f "$GOBIN/$display" ] || [ -f "/usr/local/bin/$display" ]; then
        echo -e "  ${GREEN}✔ $display${NC}"
    else
        echo -e "  ${RED}✗ $display — not installed${NC}"
    fi
done

# Kiterunner wordlists
echo ""
echo "  Kiterunner wordlists in $KR_DIR:"
for wl in routes-large.kite routes-small.kite apiroutes.txt swagger-wordlist.txt; do
    f="$KR_DIR/$wl"
    if [ -f "$f" ] && [ "$(stat -c%s "$f" 2>/dev/null || echo 0)" -gt 1000 ]; then
        echo -e "  ${GREEN}✔ $wl ($(du -sh "$f" | cut -f1))${NC}"
    else
        echo -e "  ${RED}✗ $wl — missing${NC}"
    fi
done

echo ""
echo "  Restart app to pick up changes: ./start.sh"
echo ""
