# TheMasterRecon AI v3.0 — Install Guide

## Quick Start

```bash
# 1. Extract the zip
unzip TheMasterRecon_AI.zip
cd bugscan_work

# 2. Install Python dependencies
pip install flask flask-cors requests python-dotenv --break-system-packages

# 3. Start the tool
./start.sh
```

## Access
- URL: http://127.0.0.1:9865
- Login: admin / TheMasterRecon2024!

## ⚠️ IMPORTANT
- Always run from `bugscan_work/` — NOT `bugscan_chatgpt/`
- If you see 404 errors for /bxss_config or /monitor/alerts, you're running the OLD version

## Nuclei Setup (optional but recommended)
1. Click ⚡ Nuclei in the topbar
2. Click "↓ Install Nuclei Binary"  
3. Click "⟳ Update 9,000+ Templates"
4. Every scan now runs 9,000+ CVE checks automatically

## AI Setup (optional)
Add your Anthropic API key to `.env`:
```
ANTHROPIC_API_KEY=sk-ant-...
```
