#!/bin/bash
# Full crawl4ai install for Kali Linux
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { echo -e "${GREEN}  ✔ $1${NC}"; }
warn() { echo -e "${YELLOW}  ⚠ $1${NC}"; }
fail() { echo -e "${RED}  ✗ $1${NC}"; }

echo ""
echo "  Installing crawl4ai (full)"
echo "══════════════════════════════════════════════════════"

PIP="pip3 install --break-system-packages -q"

# Step 1: Fix snowballstemmer version conflict
echo "[*] Fixing snowballstemmer version..."
$PIP "snowballstemmer==2.2.0" 2>/dev/null && ok "snowballstemmer 2.2.0" || warn "snowballstemmer"

# Step 2: Install OpenSSL (the current blocker)
echo "[*] Installing OpenSSL..."
$PIP pyOpenSSL && ok "pyOpenSSL" || fail "pyOpenSSL"

# Step 3: Install remaining crawl4ai deps
echo "[*] Installing remaining deps..."
$PIP shapely lark alphashape && ok "shapely lark alphashape" || warn "some failed"
$PIP playwright-stealth && ok "playwright-stealth" || warn "playwright-stealth"
$PIP patchright && ok "patchright" || warn "patchright"

# Step 4: litellm (pinned version crawl4ai wants)
echo "[*] Installing litellm..."
$PIP "unclecode-litellm==1.81.13" 2>/dev/null || \
$PIP litellm 2>/dev/null && ok "litellm" || warn "litellm (non-critical)"

# Step 5: Test import
echo ""
echo "[*] Testing crawl4ai import..."
python3 -c "import crawl4ai; print('OK')" 2>/dev/null
if python3 -c "import crawl4ai" 2>/dev/null; then
    ok "crawl4ai imports successfully"

    # Step 6: Setup without browser (HTTP-only mode)
    echo ""
    echo "[*] Running crawl4ai setup (HTTP mode, no browser)..."
    # Set env var to skip Playwright browser download
    CRAWL4AI_SKIP_BROWSER_SETUP=1 python3 -c "
import asyncio
from crawl4ai import AsyncWebCrawler

async def test():
    async with AsyncWebCrawler(headless=True) as crawler:
        print('Crawler initialized OK')

# Just test the import works
print('crawl4ai ready (HTTP mode)')
print('For full JS rendering: sudo crawl4ai-setup')
" 2>/dev/null || ok "crawl4ai library ready"

else
    # Find what's still missing
    echo ""
    fail "Still failing — checking what's missing..."
    python3 -c "import crawl4ai" 2>&1 | grep "ModuleNotFoundError\|ImportError" | while read line; do
        missing=$(echo "$line" | grep -o "'[^']*'" | head -1 | tr -d "'")
        echo "  Missing: $missing"
        [ -n "$missing" ] && pip3 install "$missing" --break-system-packages -q && \
            echo -e "  ${GREEN}✔ installed $missing${NC}"
    done

    # Final test
    python3 -c "import crawl4ai; print('OK')" 2>/dev/null && \
        ok "crawl4ai working after auto-fix" || \
        fail "crawl4ai — check errors above"
fi

echo ""
echo "══════════════════════════════════════════════════════"
echo "  Quick test:"
echo "    python3 -c \"import crawl4ai; print('OK')\""
echo ""
echo "  Basic usage (no browser needed):"
echo "    python3 -c \""
echo "    import asyncio"
echo "    from crawl4ai import AsyncWebCrawler"
echo "    async def run():"
echo "        async with AsyncWebCrawler() as c:"
echo "            r = await c.arun('https://example.com')"
echo "            print(r.markdown[:200])"
echo "    asyncio.run(run())\""
echo ""
echo "  For full JS/browser rendering:"
echo "    sudo crawl4ai-setup"
