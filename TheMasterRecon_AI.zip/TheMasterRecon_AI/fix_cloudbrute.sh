#!/usr/bin/env bash
# Fix cloudbrute - go install fails due to module issues
# Try 4 different methods

GREEN='\033[0;32m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "${GREEN}  ✔ $1${NC}"; }
fail() { echo -e "${RED}  ✗ $1${NC}"; }
info() { echo -e "${CYAN}  → $1${NC}"; }

export GOPATH="${GOPATH:-$HOME/go}"
export GOBIN="${GOBIN:-$HOME/go/bin}"
export PATH="$PATH:$GOBIN:/usr/local/go/bin"

echo ""
echo "  Fixing cloudbrute..."
echo "══════════════════════"

# Check if already installed
if command -v cloudbrute &>/dev/null; then
    ok "cloudbrute already installed at $(which cloudbrute)"
    exit 0
fi

# Method 1: go install with correct module path
info "Method 1: go install (correct path)..."
go install github.com/0xsha/cloudbrute@latest 2>/dev/null
if [ -f "$GOBIN/cloudbrute" ]; then
    cp "$GOBIN/cloudbrute" /usr/local/bin/ 2>/dev/null
    ok "cloudbrute installed via go"
    exit 0
fi

# Method 2: Try with GONOSUMCHECK
info "Method 2: go install with GONOSUMCHECK..."
GONOSUMCHECK=* GOFLAGS=-insecure go install github.com/0xsha/cloudbrute@latest 2>/dev/null
if [ -f "$GOBIN/cloudbrute" ]; then
    cp "$GOBIN/cloudbrute" /usr/local/bin/
    ok "cloudbrute installed"
    exit 0
fi

# Method 3: Clone and build from source
info "Method 3: git clone + go build..."
cd /tmp
rm -rf cloudbrute_src
git clone https://github.com/0xsha/cloudbrute cloudbrute_src 2>/dev/null
if [ -d cloudbrute_src ]; then
    cd cloudbrute_src
    go build -o /usr/local/bin/cloudbrute ./cmd/cloudbrute/ 2>/dev/null || \
    go build -o /usr/local/bin/cloudbrute ./... 2>/dev/null || \
    go build -o /usr/local/bin/cloudbrute . 2>/dev/null
    cd /tmp && rm -rf cloudbrute_src
    if command -v cloudbrute &>/dev/null; then
        ok "cloudbrute built from source"
        exit 0
    fi
fi

# Method 4: Download pre-built binary from releases
info "Method 4: GitHub releases binary..."
ARCH=$(uname -m)
[ "$ARCH" = "x86_64" ] && GOARCH="amd64" || GOARCH="arm64"
OS="Linux"

# Try to get latest release URL
LATEST=$(curl -s https://api.github.com/repos/0xsha/cloudbrute/releases/latest 2>/dev/null | \
         grep -o '"tag_name": *"[^"]*"' | head -1 | grep -o 'v[0-9.]*')

if [ -n "$LATEST" ]; then
    URL="https://github.com/0xsha/cloudbrute/releases/download/${LATEST}/cloudbrute_${LATEST#v}_${OS}_${GOARCH}.tar.gz"
    info "Downloading $URL..."
    TMP=$(mktemp -d)
    wget -q --timeout=30 "$URL" -O "$TMP/cb.tar.gz" 2>/dev/null
    if [ -s "$TMP/cb.tar.gz" ]; then
        tar -xzf "$TMP/cb.tar.gz" -C "$TMP/" 2>/dev/null
        BIN=$(find "$TMP" -name "cloudbrute" -type f 2>/dev/null | head -1)
        if [ -n "$BIN" ]; then
            cp "$BIN" /usr/local/bin/cloudbrute && chmod +x /usr/local/bin/cloudbrute
            rm -rf "$TMP"
            ok "cloudbrute installed from binary"
            exit 0
        fi
    fi
    rm -rf "$TMP"
fi

# Method 5: Alternative - use cloudbrute via Python (cloud-enum is similar)
info "Method 5: Installing cloud-enum as cloudbrute alternative..."
pip3 install cloud-enum --break-system-packages -q 2>/dev/null
if command -v cloud_enum &>/dev/null || python3 -c "import cloud_enum" 2>/dev/null; then
    # Create a wrapper that works as cloudbrute
    cat > /usr/local/bin/cloudbrute << 'WRAPPER'
#!/usr/bin/env python3
"""cloudbrute wrapper — uses cloud-enum under the hood"""
import sys, subprocess
# Pass through to cloud_enum with compatible args
if len(sys.argv) > 1:
    domain = sys.argv[1]
    subprocess.run(["cloud_enum", "-k", domain] + sys.argv[2:])
else:
    print("Usage: cloudbrute <domain>")
WRAPPER
    chmod +x /usr/local/bin/cloudbrute
    ok "cloudbrute wrapper installed (uses cloud-enum)"
    exit 0
fi

fail "cloudbrute — all methods failed"
echo ""
echo "  Manual install:"
echo "  1. Download from: https://github.com/0xsha/cloudbrute/releases"
echo "  2. chmod +x cloudbrute && cp cloudbrute /usr/local/bin/"
