"""
TheMasterRecon AI — Production Gunicorn Config
Handles gevent 26.x + Python 3.13 compatibility.
"""
import os, sys

# ── Server ────────────────────────────────────────────────────────────────────
PORT               = int(os.environ.get("PORT", 9865))
bind               = f"0.0.0.0:{PORT}"
workers            = 1
worker_class       = "gevent"
worker_connections = 1000
threads            = 1

# ── Timeouts ──────────────────────────────────────────────────────────────────
timeout          = 3600
graceful_timeout = 120
keepalive        = 75

# ── Stability ─────────────────────────────────────────────────────────────────
max_requests        = 0
max_requests_jitter = 0
preload_app         = False   # False avoids double monkey-patch with gevent 26.x
reload              = False

# ── Logging ───────────────────────────────────────────────────────────────────
accesslog         = "-"
errorlog          = "-"
loglevel          = "warning"
access_log_format = '%(h)s %(r)s %(s)s %(b)s %(D)sμs'

# ── Process ───────────────────────────────────────────────────────────────────
proc_name = "themaster_recon"
daemon    = False
pidfile   = "/tmp/tmr.pid"

# ── Hooks ─────────────────────────────────────────────────────────────────────
def on_starting(server):
    server.log.info("TheMasterRecon AI starting")

def post_fork(server, worker):
    """Called after worker fork — suppress SSL monkey-patch warning."""
    try:
        import warnings
        warnings.filterwarnings("ignore", category=UserWarning, module="gevent")
    except Exception:
        pass

def worker_exit(server, worker):
    try:
        import scanner
        scanner._scan_stop.set()
    except Exception:
        pass

def on_exit(server):
    server.log.info("TheMasterRecon AI stopped")
