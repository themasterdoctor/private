#!/bin/bash
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║   TheMasterRecon AI — Tool Installer for Kali Linux                     ║
# ║   Run as root: sudo bash fix_failed_tools.sh                            ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

set -e
export GOPATH="$HOME/go"
export PATH="$PATH:$HOME/go/bin:/usr/local/go/bin"
GONOSUMDB="*"
GOPROXY="direct"

echo "=== TheMasterRecon AI — Installing Tools ==="
echo ""

# ── Go tools (ProjectDiscovery) ───────────────────────────────────────────────
install_go_tool() {
    local name="$1"
    local pkg="$2"
    if which "$name" &>/dev/null; then
        echo "  OK   $name (already installed)"
        return
    fi
    echo -n "  Installing $name... "
    if GONOSUMDB="*" GOPROXY="direct" go install "$pkg" 2>/dev/null; then
        echo "OK"
    else
        echo "FAIL (try: go install $pkg)"
    fi
}

echo "--- Go tools (requires: go install) ---"
install_go_tool subfinder    "github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
install_go_tool httpx        "github.com/projectdiscovery/httpx/cmd/httpx@latest"
install_go_tool nuclei       "github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"
install_go_tool dnsx         "github.com/projectdiscovery/dnsx/cmd/dnsx@latest"
install_go_tool katana       "github.com/projectdiscovery/katana/cmd/katana@latest"
install_go_tool naabu        "github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"
install_go_tool chaos-client "github.com/projectdiscovery/chaos-client/cmd/chaos@latest"
install_go_tool alterx       "github.com/projectdiscovery/alterx/cmd/alterx@latest"
install_go_tool interactsh-client "github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest"
install_go_tool asnmap       "github.com/projectdiscovery/asnmap/cmd/asnmap@latest"
install_go_tool cdncheck     "github.com/projectdiscovery/cdncheck/cmd/cdncheck@latest"
install_go_tool tlsx         "github.com/projectdiscovery/tlsx/cmd/tlsx@latest"
install_go_tool uncover      "github.com/projectdiscovery/uncover/cmd/uncover@latest"
install_go_tool notify       "github.com/projectdiscovery/notify/cmd/notify@latest"
install_go_tool shuffledns   "github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest"
install_go_tool gau          "github.com/lc/gau/v2/cmd/gau@latest"
install_go_tool anew         "github.com/tomnomnom/anew@latest"
install_go_tool qsreplace    "github.com/tomnomnom/qsreplace@latest"
install_go_tool waybackurls  "github.com/tomnomnom/waybackurls@latest"
install_go_tool gf           "github.com/tomnomnom/gf@latest"
install_go_tool dalfox       "github.com/hahwul/dalfox/v2@latest"
install_go_tool kxss         "github.com/Emoe/kxss@latest"
install_go_tool gospider     "github.com/jaeles-project/gospider@latest"
install_go_tool hakrawler    "github.com/hakluke/hakrawler@latest"
install_go_tool feroxbuster  "github.com/epi052/feroxbuster@latest"  # has binary
install_go_tool crlfuzz      "github.com/dwisiswant0/crlfuzz/cmd/crlfuzz@latest"
install_go_tool amass        "github.com/owasp-amass/amass/v4/...@latest"
install_go_tool gobuster     "github.com/OJ/gobuster/v3@latest"
install_go_tool assetfinder  "github.com/tomnomnom/assetfinder@latest"
install_go_tool findomain    "github.com/Edu4rdSHL/findomain@latest"
install_go_tool puredns      "github.com/d3mondev/puredns/v2@latest"
install_go_tool csprecon     "github.com/edoardottt/csprecon/cmd/csprecon@latest"
install_go_tool analyticsrelationships "github.com/Josue87/analyticsrelationships@latest"
install_go_tool mx-takeover  "github.com/musana/mx-takeover@latest"

echo ""
echo "--- After go install: update nuclei templates ---"
if which nuclei &>/dev/null; then
    echo -n "  nuclei -update-templates... "
    nuclei -update-templates -silent 2>/dev/null && echo "OK" || echo "FAIL"
fi

echo ""
echo "--- pip tools ---"
pip3 install waymore arjun sublist3r theHarvester truffleHog --break-system-packages -q 2>/dev/null
echo "  pip tools: OK"

echo ""
echo "--- apt tools ---"
apt-get install -y -q --no-install-recommends \
    nmap masscan sqlmap nikto gobuster ffuf wfuzz whatweb \
    dirsearch dirb wordlists whois dnsutils jq 2>/dev/null
echo "  apt tools: OK"

echo ""
echo "=== Install complete. Run: ./start.sh ==="
