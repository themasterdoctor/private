# Private Security Review — <Protocol> 

**Engagement type:** private-audit | bug-bounty | competitive-audit | remediation-review  
**Reviewer:** Hermes Private Contract Auditor (+ human sign-off)  
**Repository:** <url>  **Commit:** <hash>  **Branch/tag:** <ref>  
**Chains:** <name (chain id), ...>  
**Dates:** <start> – <end>  
**Disclosure destination:** <where this report goes>

> Confidential. Do not redistribute outside the disclosure destination. This
> report reflects the scoped commit only; later changes are out of scope.

## 1. Scope
- In-scope contracts: <list>
- Out-of-scope: <list>
- Privileged identities assumed trusted: <list>
- Known issues / prior audits excluded: <list>
- Testing permitted: <fork / testnet / etc.>

## 2. Summary of results

| ID | Title | Severity | Confidence | Status |
|----|-------|----------|------------|--------|
| F-001 |  |  |  | reported |

<One-paragraph narrative: what the protocol does, what was examined, the
headline risk posture. Direct and factual.>

## 3. Methodology
Scope lock → build verification → architecture & trust-boundary mapping →
invariant extraction → attack-tree generation → manual code review → automated
analysis (classified, not auto-promoted) → testing (unit → invariant → fuzz →
fork) → independent validation → economic-impact modeling → skeptic review.
Every claim below is labeled: [observed fact] / [source-code fact] /
[test result] / [inference] / [uncertainty].

## 4. Findings
<Insert each finding using templates/FINDING.md, ordered by severity.>

## 5. Coverage and negative knowledge
What was examined and cleared (summarized from `NEGATIVE_KNOWLEDGE.md`): areas
reviewed, attack classes considered and dismissed, and why. This bounds the
review and tells the client what is *not* a concern.

## 6. Limitations
- Components not reviewed and why.
- Assumptions made (oracle honesty, governance trust, token standards, etc.).
- Anything that could not be reproduced or validated, marked as such.

## 7. Appendix
- Build/test output references (`BUILD_STATUS.md`)
- Tool versions and configuration
- Invariant list (`INVARIANTS.md`)
- Reproduction commands and pinned fork blocks
