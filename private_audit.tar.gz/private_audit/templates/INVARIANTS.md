# INVARIANTS (instantiated)

> Derived from `references/invariants-catalog.md` with concrete names. Each must
> be testable. Tag where it's enforced (test file / property).

## Authorization
- INV-A1: <statement> — asset/authority: <x> — test: <file::test>

## Accounting
- INV-C1: sum(userBalances) <= token.balanceOf(<vault>) — test:

## Solvency
- INV-S1: realizableAssets >= liabilities at all times — test:

## State Transitions
- INV-T1: <one-time action> executes at most once — test:

## External Interactions
- INV-E1: oracle price is fresh and not atomically manipulable — test:

## Upgradeability
- INV-U1: storage layout append-only across upgrades — test:
