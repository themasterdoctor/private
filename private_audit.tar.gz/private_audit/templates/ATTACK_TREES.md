# ATTACK_TREES (ranked)

> One section per asset/authority. Rank per `references/attack-trees.md`.

## Asset: <name>
### Path: <attack path from catalog>
- Target invariant:
- Attacker access:
- Reachability: reachable | guarded | unreachable
- Required capital / timing / permissions:
- Expected impact:
- Detection probability:
- Evidence cost:
- Candidate function(s):
- → Hypothesis id (if kept): H-___   | Cleared (why): see NEGATIVE_KNOWLEDGE.md
