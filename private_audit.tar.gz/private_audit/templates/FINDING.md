# [F-XXX] <Finding title>

- **Severity:** Critical | High | Medium | Low | Informational
- **Confidence:** Confirmed | Probable | Theoretical
- **Affected contracts:** <Contract.sol>
- **Affected functions:** <function()>
- **Commit:** <hash>
- **Deployment addresses:** <if applicable>
- **Validation record:** <validation id — must be CONFIRMED or PARTIALLY_CONFIRMED>

## Violated invariant
<The exact invariant from INVARIANTS.md this breaks.>

## Attacker prerequisites
<Who, with what access / capital / timing / permissions / tokens.>

## Summary
<2–4 sentences: what breaks and why it matters. No marketing language.>

## Root cause
<The specific code-level reason. Label statements: [source-code fact] / [inference].>

## Detailed attack path
1. <step — tx>
2. <step — tx>
3. <observable result>

## Reproduction
```bash
# exact, reproducible commands (repo + commit pinned)
```
Steps: <ordered, deterministic where possible.>

## Proof of concept
<Path to PoC under POC/. Summarize what it sets up and asserts.>

## Result (evidence)
- **Actual result:** <captured output — [test result]>
- **Baseline result:** <behavior on unmodified scoped code>
- **Before/after state or balances:** <snapshot delta — [observed fact]>
- **Evidence refs:** <EVIDENCE/...>

## Impact
- **Class:** accounting-discrepancy | recoverable-user-loss | permanent-fund-loss | protocol-insolvency | temporary-dos | permanent-dos | privilege-takeover
- **Maximum possible loss:** <ceiling>
- **Practically extractable value:** <after liquidity/slippage/gas/MEV>
- **Protocol / user loss / bad debt:** <as applicable>

## Economic analysis
Required capital · flash-loan feasibility · gas · available liquidity · oracle
movement required · repeatability · MEV competition · limiting conditions.

## Likelihood
<Realistic conditions; state any downgrade reason.>

## Recommended remediation
<Root-cause fix, specific to this code. Not generic advice.>

## Regression test
<Test that fails on the vulnerable commit and passes after the fix.>

## Scope confirmation
<Why this is in scope per SCOPE.json.>

## Known limitations
<What remains unproven (required if Confidence is Probable / outcome PARTIALLY_CONFIRMED).>
