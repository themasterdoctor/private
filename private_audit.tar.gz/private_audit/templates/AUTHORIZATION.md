# AUTHORIZATION

> Fill before any active work. Until this is complete, only passive source-code
> analysis is permitted — no interaction with live deployments.

- Engagement name:
- Type: private-audit | bug-bounty | competitive-audit | remediation-review | research
- Client / program:
- Ruleset / program URL:
- Authorized by (name + role):
- Authorization date:
- Disclosure destination (where confirmed findings go):

## Explicit permissions
- [ ] Local build and test
- [ ] Static / fuzzing tools
- [ ] Mainnet-fork simulation (read-only RPC)
- [ ] Testnet validation
- [ ] DoS testing (rarely — requires written permission)
- [ ] Mainnet state-changing transactions (almost always NO)

## Restrictions
-

## Confirmation
By recording this I confirm the work is authorized and limited to the scope in
`SCOPE.json`. Reports are never auto-submitted; findings go to a human for
sign-off before disclosure.
