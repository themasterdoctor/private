# ROLE_MATRIX

| Role / identity | Address or label | Granted by | Powers (functions) | Can it move value? | Two-step transfer? | Notes |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

## Privileged functions
| Contract.function | Required role | Guard / modifier | Dangerous? | Notes |
|---|---|---|---|---|
|  |  |  |  |  |

## Emergency controls
- Pause/unpause: who, what it restricts, does it lock user funds?
- Upgrade authority: who, mechanism, timelock?
