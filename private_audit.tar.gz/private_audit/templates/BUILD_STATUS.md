# BUILD_STATUS

Repository: <url>  ·  Commit: <hash>  ·  Framework: <foundry|hardhat|...>

## Environment
- Package manager:
- Compiler (solc) versions:
- Optimizer / runs / via_ir:
- EVM version:
- Required env vars (names only, no secrets):
- Tool versions (forge, slither, ...):

## Results (capture real command output — never claim a pass without it)
- Dependency install: `<command>` → <result>
- Build: `<command>` → <result>
- Existing tests: `<command>` → <pass/fail counts>
- Failing baseline tests:
- Coverage (if available): `<command>` → <result>
- Fork configuration (chain id, pinned block):

## Blockers / missing source or deps
-
