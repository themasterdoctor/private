# Hermes Private Contract Auditor

An installable package for running **authorized** Web3 private audits as a
disciplined, evidence-first pipeline — not a scanner that prints alerts. It turns
the Hermes spec into concrete, reusable artifacts: a controller, lane
definitions, an invariant/attack-tree library, machine-readable evidence
schemas, Foundry/Echidna PoC templates, and a private report format.

## What's in here

```
hermes-private-contract-auditor/
├── SKILL.md            # controller: the 12-stage workflow + gates (entry point)
├── SOUL.md             # constitution: authorization boundary, honesty + never-do rules
├── AGENTS.md           # the 9 lanes, their I/O contracts, the independence rule
├── routing.json        # machine-readable triggers, lanes, stage gates, capability flags
├── references/         # loaded as needed
│   ├── lifecycle.md            # per-stage detail
│   ├── invariants-catalog.md   # invariant library (6 families)
│   ├── attack-trees.md         # attack-path catalog + ranking rubric
│   ├── severity-rubric.md      # severity / confidence / impact taxonomy
│   └── tooling.md              # toolchain + hard capability boundary
├── schemas/            # JSON Schemas for the evidence trail
│   ├── scope.schema.json  repository_lock.schema.json  hypothesis.schema.json
│   ├── validation.schema.json  evidence.schema.json  finding.schema.json
├── templates/          # fill-in audit artifacts + FINDING.md + FINAL_REPORT.md
├── foundry/            # Forge config + unit / invariant / fork PoC templates
├── echidna/            # Echidna/Medusa property template + config
└── scripts/
    └── init_engagement.sh      # scaffolds the audit/ tree for a new engagement
```

## Install / use

**As a Claude skill (Claude.ai or Claude Code):** install the packaged
`hermes-private-contract-auditor.skill`. It triggers on audit / review / invariant
/ PoC / Foundry / "is this safe" style requests and routes through scope-lock
first. `SKILL.md` is the entry point; the rest loads on demand.

**In your existing Hermes runtime:** keep `Hermes Apex Commander` as the control
plane and register this as the `hermes-private-contract-auditor` mission
controller. Map the nine lanes in `AGENTS.md` to your specialist agents
(`hermes-solguard`, `hermes-onchain`, `hermes-mev`, etc.). Use `routing.json` to
wire triggers and stage gates. `SOUL.md` is the behavioral contract every lane
inherits.

**Standalone:** run `scripts/init_engagement.sh <name>` to scaffold an `audit/`
workspace, then work the lifecycle in `references/lifecycle.md`, validating
records against `schemas/` as you go.

## The one rule that matters most

Scanner output, suspicious patterns, and attack ideas are **leads**. A lead
becomes a finding only with: the exact vulnerable path, the violated invariant, a
realistic attacker model, a reachable transaction sequence, a reproducible test,
before/after evidence, independent validation, defensible severity, a root-cause
fix, and a regression test. Anything less stays in `HYPOTHESES.jsonl`. And every
result is labeled observed / source / test / inference / uncertainty — nothing is
fabricated.

## Boundaries

Operates only inside an authorized, locked scope. Never broadcasts production
transactions, moves funds, modifies production state, uses real keys, or
auto-submits a report. See `SOUL.md` and `references/tooling.md`.

> The Foundry/Echidna files are **templates**, not executed results. Run them in
> your own sandbox and capture real output into `EVIDENCE/` — don't record a
> result you didn't produce.
