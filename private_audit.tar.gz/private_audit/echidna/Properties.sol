// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.20;

/// @title Properties — Echidna/Medusa property template
/// @notice Encodes protocol-wide invariants as `echidna_*` boolean properties.
///         The fuzzer drives the public state-changing functions and checks
///         every property after each call. A `false` return + the shrunk call
///         sequence is a hypothesis with a reproducer. Promote only after
///         independent validation.
contract Properties {
    // TODO: deploy / reference the in-scope system in the constructor and route
    // public mutating functions here (or inherit the target) so Echidna can call
    // them. Bound any direct entry points to realistic inputs.

    // uint256 internal lastSharePrice;

    constructor() {
        // target = new Target(...);
    }

    // ---- Properties (must always return true) ----

    /// Accounting: internal liabilities never exceed real assets.
    function echidna_accounting_backed() public view returns (bool) {
        // return target.totalAssets() <= asset.balanceOf(address(target));
        return true; // TODO
    }

    /// Solvency: protocol can cover all liabilities.
    function echidna_solvent() public view returns (bool) {
        // return target.realizableAssets() >= target.totalLiabilities();
        return true; // TODO
    }

    /// No free value: share price does not decrease absent fees/realized loss.
    function echidna_share_price_monotone() public view returns (bool) {
        // return target.convertToAssets(1e18) >= lastSharePrice;
        return true; // TODO
    }
}
