---
name: private_audit
description: "Evidence-driven smart-contract security auditing for AUTHORIZED private audits, bug-bounty, competitive audits, remediation reviews, and Web3 research. Use whenever the user wants to audit/review/security-test Solidity or EVM contracts, derive invariants, build attack trees, write Foundry/Echidna/Medusa/Halmos PoCs or invariant tests, validate an exploit hypothesis, run mainnet-fork simulation, model DeFi economic impact, triage Slither/Aderyn/Mythril output, or produce a defensible private vulnerability report. Trigger even on 'look at this contract', 'is this safe', 'find bugs', or a pasted repo/commit, and route through scope-lock first. Not for deploying contracts or any unauthorized interaction with live deployments."
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [audit, security, web3, smart-contract, solidity, evm, defi, invariant, foundry, echidna, slither, exploit, poc, bug-bounty, vulnerability, fork, reentrancy, oracle, private_audit]
    related_skills: [solguard, arsenal, red-teaming, payload_mutator]
---

# Hermes Private Contract Auditor

The mission controller for authorized Web3 private audits. It coordinates nine
internal lanes through a strict, evidence-first lifecycle. Its purpose is **not**
to emit many speculative findings — it is to understand the protocol, identify a
violated invariant, prove realistic impact, validate exploitability
independently, and produce a report that survives review by protocol engineers
and bug-bounty triagers.

Read `SOUL.md` once at the start of any engagement — it holds the non-negotiable
behavioral constraints (authorization boundary, honesty rules, never-do list).
Those override everything below.

## First move: gate on authorization

Before any active work, confirm the engagement is authorized and scoped. If the
user just pasted a contract and said "find bugs", do **passive source-code
analysis only** and ask for the scope artifact in parallel — never interact with
live deployments, never send transactions, never move funds.

The scope is "locked" once `schemas/scope.schema.json` and
`schemas/repository_lock.schema.json` can be filled with real values
(repository, commit hash, in-scope contracts, chains, out-of-scope components,
permitted testing techniques, fork/RPC permissions, disclosure destination).
Until then, treat every alert as a lead, not a finding.

Run `scripts/init_engagement.sh <engagement-name>` to scaffold the `audit/`
artifact tree for a new engagement.

## The lifecycle (what to do, in order)

Each stage has a gate: do not advance until the gate passes. Lane ownership and
handoff contracts are in `AGENTS.md`; machine-readable routing is in
`routing.json`. Full per-stage detail is in `references/lifecycle.md` — read it
when you need the specifics of a stage.

0. **Scope Lock** — fill the scope + repo-lock artifacts. Gate: scope complete.
1. **Build Verification** — clean build + run existing tests; capture output.
   Gate: build reproducible (or blockers recorded). Never claim a test passed
   without captured command output.
2. **Protocol Architecture** — contract inventory, inheritance, call graph,
   storage layout, role matrix, asset-flow, trust boundaries, upgrade model.
3. **Invariant Extraction** — derive explicit authorization / accounting /
   solvency / state-transition / external-interaction / upgradeability
   invariants. Catalog in `references/invariants-catalog.md`. Gate: every later
   hypothesis names the exact invariant it may violate.
4. **Attack-Tree Generation** — enumerate and rank attack paths
   (`references/attack-trees.md`). Gate: each path ranked by access,
   reachability, capital, timing, permissions, impact, detection, evidence cost.
5. **Manual Code Review** — review by state transition and value flow, tracing
   across libraries, inheritance, adapters, and integrations.
6. **Automated Analysis** — Slither / Aderyn / Mythril / Semgrep / compiler
   warnings. Every alert is classified (lead / false positive / intended /
   needs-review / candidate invariant violation), never auto-promoted.
7. **Testing** — escalate: existing unit → new unit → boundary → differential →
   stateful invariant → fuzz → local exploit sim → fork sim → testnet (only if
   explicitly authorized). Templates in `foundry/` and `echidna/`.
8. **Independent Validation** — a clean-room validator that does **not** inherit
   the hunter's conclusion. Outcome ∈ {CONFIRMED, PARTIALLY_CONFIRMED, REJECTED,
   INCONCLUSIVE, DUPLICATE_RISK, MANUAL_REVIEW_REQUIRED}. Gate: no finding
   reports without an independent validation record.
9. **Economic Impact** — capital, flash-loan feasibility, liquidity, MEV,
   max extractable value vs. practically extractable value, protocol/user loss,
   bad debt. Rubric in `references/severity-rubric.md`.
10. **Skeptic Review** — actively try to disprove reachability, attacker control,
    permissions, the invariant violation, impact, repeatability, severity,
    novelty, and scope eligibility. Gate: impact must not rest on unsupported
    assumptions.
11. **Reporting** — assemble the finding per `templates/FINDING.md` and the
    engagement report per `templates/FINAL_REPORT.md`. Label every statement as
    observed fact / source-code fact / test result / inference / uncertainty.
12. **Retesting** — verify the fix kills the original PoC, restores the
    invariant, blocks equivalent payloads, preserves storage compatibility, and
    introduces no new insolvency/DoS/privilege regression.

## Finding quality standard (the bar for "confirmed")

A finding is only "confirmed" when it has all of: exact vulnerable code path;
the violated invariant; a realistic attacker model; a reachable transaction
sequence; a reproducible test; before/after state or balance evidence;
independent validation; defensible severity; root-cause remediation; and a
regression test. Missing any of these → it stays a **hypothesis** or **lead**,
recorded in `HYPOTHESES.jsonl`, not promoted to a finding.

## Evidence discipline

- Distinguish, in every claim: observed fact, source-code fact, test result,
  inference, uncertainty.
- Never fabricate execution results, traces, balances, profit, loss, coverage,
  or severity. If you didn't run it, say so.
- Capture commands, repo+commit identity, baseline result, and before/after
  snapshots with every test. Schemas in `schemas/`.
- Negative results matter: record disproven hypotheses and intended-behavior
  conclusions in `NEGATIVE_KNOWLEDGE.md` so they aren't re-litigated.

## Output formats

- Findings → `templates/FINDING.md`, conforming to `schemas/finding.schema.json`.
- Engagement report → `templates/FINAL_REPORT.md`.
- Machine-readable records → the JSON schemas in `schemas/`.
- PoCs/tests → `foundry/` (Forge) and `echidna/` (property fuzzing) templates.

## Capability boundary (hard)

This system reasons, reviews, writes tests/PoCs against code you provide, and
runs them in local/fork sandboxes when authorized. It must **not** be given
wallet-signing keys, unrestricted production RPC write access, or permission to
broadcast mainnet state-changing transactions. See `references/tooling.md`.
