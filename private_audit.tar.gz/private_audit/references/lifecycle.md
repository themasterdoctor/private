# Lifecycle — per-stage detail

The controller (`SKILL.md`) gives the ordered summary. This file is the detail to
consult when executing a specific stage.

## Stage 0 — Scope Lock
Record into `SCOPE.json` / `REPOSITORY_LOCK.json` / `AUTHORIZATION.md`:
repository, commit hash, branch/tag, compiler versions, dependency versions,
deployment addresses, networks, in-scope contracts, out-of-scope contracts,
known issues, previous audits, privileged identities, testing restrictions.
**Do not begin active validation until the scope artifact is complete.** With
incomplete authorization, restrict to passive source analysis.

## Stage 1 — Build Verification
Confirm the repo builds and tests from a clean environment. Record package
manager, framework, compiler (pin with `solc-select` / `foundry.toml`), required
env vars, dependency install result, existing test result, failing baseline
tests, coverage when available, fork configuration, and any missing
dependencies/source files. **Never claim a test passed without captured command
output.** A red baseline is itself information — record it.

## Stage 2 — Protocol Architecture
Build: contract inventory; inheritance graph; library dependencies; external
call graph; privileged-function list; upgradeability model; storage layout; role
matrix; asset inventory; asset-flow graph; oracle/bridge/keeper/relayer
dependencies; signature & permit flows; governance pathways; emergency controls;
deployment & initialization sequence. Mark **every trust boundary** — each place
where value, authority, pricing data, or execution control crosses between
parties of differing trust.

## Stage 3 — Invariant Extraction
Derive explicit, testable invariants across the six families in
`references/invariants-catalog.md`. Each must be tied to a concrete asset or
authority and expressed so it can be encoded as a property test. Every later
hypothesis cites the exact invariant it may violate.

## Stage 4 — Attack-Tree Generation
For each invariant and asset, enumerate attack paths from the catalog in
`references/attack-trees.md`. Rank each by attacker access, reachability,
required capital, required timing, required permissions, expected impact,
detection probability, and evidence cost. Rank decides review order.

## Stage 5 — Manual Code Review
Review by state transition and value flow, not file order. For every externally
reachable function determine: caller requirements; input control; state read;
state written; assets transferred; external calls; callback opportunities;
oracle reads; rounding behavior; failure behavior; event behavior;
cross-contract assumptions; upgrade implications; interaction with adjacent
functions. Trace across internal calls, libraries, inherited contracts,
adapters, and external integrations.

## Stage 6 — Automated Analysis
Run Slither, Aderyn, Mythril, Semgrep, compiler warnings, storage-layout diff,
coverage. Classify each alert as: lead / false positive / intended behavior /
requires manual review / candidate invariant violation. **No alert becomes a
finding without contextual analysis and validation.** Keep raw output in
`STATIC_ANALYSIS/`; never dump it into a report.

## Stage 7 — Testing
Escalate only as far as needed:
1. existing unit test
2. new deterministic unit test
3. boundary-value test
4. differential test
5. stateful invariant test
6. fuzz test
7. local exploit simulation
8. mainnet-fork simulation
9. testnet validation (only if explicitly authorized)
Preserve determinism where possible, minimal attacker assumptions, clear
preconditions, baseline comparison, balance/state snapshots, relevant logs,
reproducible commands, and repo+commit identity. **No real funds, no production
state changes.** Templates in `foundry/` and `echidna/`.

## Stage 8 — Independent Validation
Clean-room reproduction that does not inherit the hunter's conclusion. See the
independence rule in `AGENTS.md`. Assign one outcome and record the evidence that
supports it.

## Stage 9 — Economic Impact
For financial findings compute: required attacker capital; capital-lock duration;
flash-loan feasibility; gas/execution cost; slippage; oracle-movement
requirement; available liquidity; maximum extractable value; protocol loss; user
loss; bad debt; repeatability; competition/front-running risk; limiting
conditions. Separate theoretical discrepancy, recoverable user loss, protocol
insolvency, temporary DoS, permanent fund loss, privilege takeover, max-possible
loss, and practically extractable value. Rubric: `references/severity-rubric.md`.

## Stage 10 — Skeptic Review
Adversarially attempt to disprove: exploit reachability, attacker control,
absence of required permission, the claimed invariant violation, balance/state
impact, repeatability, severity, novelty, scope eligibility. If primary impact
rests on an unsupported assumption, the finding cannot proceed.

## Stage 11 — Reporting
Assemble each finding per `templates/FINDING.md` (schema:
`schemas/finding.schema.json`) and the engagement report per
`templates/FINAL_REPORT.md`. Label every statement: observed fact / source-code
fact / test result / inference / uncertainty. Never exaggerate impact.

## Stage 12 — Retesting
Verify: original PoC no longer succeeds; original invariant restored; nearby
functions don't retain the same root cause; equivalent payloads/paths blocked;
storage compatibility preserved; remediation introduces no insolvency/DoS/
privilege problem; existing functionality and invariants still pass. Outcome ∈
`FIXED | PARTIALLY_FIXED | MITIGATED | STILL_VULNERABLE | REGRESSION_FOUND |
INCONCLUSIVE`.
