# Attack-Tree Catalog and Ranking

Reference for Stage 4. For each in-scope asset/authority, walk this catalog,
keep paths that are plausibly reachable in the scoped version, and rank them.

## Catalog (path → invariant family it attacks)

- Unauthorized asset withdrawal → accounting / authorization
- Unauthorized minting → accounting
- Share-price manipulation → accounting / solvency
- Donation / inflation attack (first-depositor) → accounting
- Oracle manipulation (spot vs TWAP, stale price, sequencer down) → external
- Flash-loan-assisted state manipulation → solvency / external
- Reentrancy (single-function) → state transitions / external
- Cross-function reentrancy → state transitions
- Read-only reentrancy (integrator reads mid-tx) → external
- Rounding extraction → accounting
- Precision loss (decimals, order of ops, division-before-mult) → accounting
- Liquidation manipulation → solvency
- Bad-debt creation / socialization abuse → solvency
- Front-running / transaction-order dependence → state transitions
- Signature replay (cross-chain, cross-contract, missing nonce/deadline) → auth
- Permit misuse (front-run permit, allowance griefing) → authorization
- Initialization takeover (uninitialized proxy, re-init) → authorization /
  upgradeability
- Upgrade takeover (unguarded `_authorizeUpgrade`, admin slot) → upgradeability
- Governance capture (flash-loan voting, timelock bypass) → authorization
- Bridge-message forgery → authorization / external
- Cross-chain replay → authorization
- Adapter / integration abuse (untrusted return values, arbitrary call) → external
- Denial of service (unbounded loop, gas griefing, revert-on-transfer) → state
- Forced token transfers (selfdestruct, direct send) → accounting
- Fee-on-transfer token behavior → external / accounting
- Rebasing token behavior → external / accounting
- ERC-777 / hook-based callbacks → external / state transitions
- Malicious token contract (in permissionless listing) → external
- Malicious oracle / keeper behavior → external / authorization
- Privileged-role compromise (over-broad role, missing two-step) → authorization
- Incorrect emergency behavior (pause locks funds, unpause unguarded) → state

## Ranking rubric

Score each candidate path on these axes; use them to order manual review and to
decide how much evidence to spend. Low evidence-cost + high impact paths first.

| Axis | Question | Scale |
|------|----------|-------|
| Attacker access | Who can call it? | anonymous > token holder > privileged |
| Reachability | Is the path callable in the scoped version? | reachable / guarded / unreachable |
| Required capital | How much to stage it? | none/flash-loan > small > large |
| Required timing | Specific block/ordering/state needed? | any tx > specific window > rare |
| Required permissions | Roles needed? | none > user role > admin |
| Expected impact | Worst realistic outcome | insolvency/takeover > fund loss > griefing |
| Detection probability | Visible before/during? | silent > observable > obvious |
| Evidence cost | Effort to prove with a PoC | unit test > fork sim > multi-step chain |

## Output

Record ranked paths in `templates/ATTACK_TREES.md`. Each path that survives
becomes one or more rows in `HYPOTHESES.jsonl`, each naming its target invariant
and a candidate vulnerable function. Paths cleared at this stage (and why) go to
`NEGATIVE_KNOWLEDGE.md`.
