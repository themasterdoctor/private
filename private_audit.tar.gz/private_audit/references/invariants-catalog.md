# Invariant Catalog

Reference library for Stage 3. Each engagement instantiates the relevant items
into `INVARIANTS.md` with concrete contract/asset names and a property test.
Phrase every invariant so it can be encoded (an assertion that must always hold).

## Authorization
- Only authorized identities can perform privileged state transitions.
- Ownership, governance, and role transfers follow the intended (often two-step)
  process; pending roles cannot act.
- Signatures cannot be replayed across users, chains, contracts, or nonces
  (check EIP-712 domain separator: includes chainId and verifying contract;
  nonce consumed atomically; deadline enforced).
- Initialization cannot be repeated or front-run (initializer guarded;
  implementation cannot be initialized by an unauthorized party).

## Accounting
- Internal accounting equals or conservatively under-represents actual
  controlled assets (`sum(userBalances) <= token.balanceOf(contract)`).
- Shares and assets cannot be created without corresponding value
  (mint requires deposit; redeem burns proportional shares).
- Withdrawals cannot exceed the caller's entitlement.
- Fees cannot exceed configured bounds; fee math cannot underflow the principal.
- Rounding always favors the protocol, never systematically extracts value from
  it (deposits round shares down, withdrawals round assets down).
- Debt and collateral calculations remain internally consistent across all
  state transitions.

## Solvency
- The protocol remains solvent after every permitted state transition
  (`realizableAssets >= liabilities`).
- Bad debt cannot be transferred to unrelated users except through the intended
  socialization mechanism.
- Liquidations cannot create unbounded protocol loss; liquidation incentives are
  bounded and cannot be gamed to drain reserves.
- Exchange-rate / share-price cannot be manipulated atomically (donation/
  inflation resistance: virtual shares/assets or minimum-liquidity lock).

## State Transitions
- Invalid states are unreachable; enums/flags cannot reach undefined values.
- Paused states enforce the intended restrictions (and unpause is correctly
  authorized; pausing doesn't lock user funds beyond intent).
- State changes occur before dangerous external interactions (checks-effects-
  interactions) wherever reentrancy could observe inconsistent state.
- One-time actions cannot execute more than once (claims, finalizations,
  initializations).
- Cancellation and finalization paths are mutually exclusive and consistent
  (an order/withdrawal cannot be both cancelled and executed).

## External Interactions
- Token callbacks (ERC-777/ERC-721 hooks, ERC-1363) cannot violate internal
  state assumptions or re-enter into inconsistent state.
- Non-standard ERC-20 behavior is handled safely: missing return values
  (use SafeERC20), fee-on-transfer (measure balance delta, don't trust amount),
  rebasing, blocklists, double-entry tokens.
- Oracle prices satisfy freshness (staleness check, `updatedAt`), bounds
  (min/max, L2 sequencer uptime), and manipulation assumptions (TWAP vs spot;
  not a manipulable AMM spot price).
- External protocol return values are checked (success booleans, returned
  amounts, low-level call success).
- A failed transfer cannot be interpreted as success.
- Reentrancy (single-function, cross-function, read-only) cannot observe or
  manipulate inconsistent state; view functions used by integrators are also
  protected or consistent mid-transaction.

## Upgradeability
- Proxy and implementation storage layouts remain compatible across upgrades
  (no slot collisions; gap variables preserved; append-only).
- Implementations cannot be initialized by unauthorized users; the logic
  contract is locked (`_disableInitializers`).
- Upgrade authorization cannot be bypassed (UUPS `_authorizeUpgrade` guarded;
  admin ≠ user-callable).
- Upgrade operations cannot brick the protocol or seize assets.
- Immutable and constructor assumptions remain valid behind a proxy (immutables
  live in bytecode, not proxy storage — verify intent).

## Encoding hint
For each instantiated invariant, write the property as: precondition(s) →
action(s) (the handler) → assertion that must hold. Put authorization/accounting/
solvency invariants into stateful invariant tests (`foundry/test/InvariantBase.t.sol`)
and protocol-wide ones into Echidna/Medusa (`echidna/Properties.sol`).
