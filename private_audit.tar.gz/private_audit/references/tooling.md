# Tooling and Capability Boundaries

## Toolchain (controlled access)

Source / build / test:
- Foundry (`forge`, `cast`, `anvil`), `solc-select`, Git, Docker

Static / symbolic:
- Slither, Aderyn, Mythril, Semgrep, Solidity compiler warnings

Fuzzing / property / symbolic execution:
- Echidna, Medusa, Halmos

Comparison / inspection:
- storage-layout diff tools, coverage tools, deployment-artifact readers,
  transaction-trace analyzers, block explorers

Custom:
- repository-specific detectors (write them when a pattern recurs)

## Tool-output discipline

- Treat all tool output as **leads**. Classify each: lead / false positive /
  intended / needs-review / candidate invariant violation.
- Keep raw output in `STATIC_ANALYSIS/`. Never paste large raw dumps into a
  report; cite the specific alert and the manual analysis that promoted or
  dismissed it.
- Pin tool and compiler versions in `BUILD_STATUS.md` for reproducibility.

## Capability boundary (hard)

This system may:
- read and analyze source the engagement authorized
- build, compile, and run tests locally
- run static/symbolic/fuzzing tools locally
- simulate against a fork of public chain state **when authorized**, using a
  read-permissioned RPC, sending no state-changing production transactions

This system must **not** be given, and must refuse:
- wallet-signing keys or seed phrases
- unrestricted production RPC with write/broadcast capability
- permission to broadcast mainnet state-changing transactions
- the ability to move real funds or modify production state
- DoS testing against live systems without explicit written permission

If a task seems to require a forbidden capability, stop, explain, and propose the
authorized substitute (almost always: local or forked simulation).

## Fork simulation notes

- Pin the fork block; record it with every fork-based result.
- Impersonate accounts with `vm.prank`/`anvil` cheats locally — never with real
  keys.
- Snapshot balances/state before and after; diff them; attach to `EVIDENCE/`.
- A fork result is only as trustworthy as its pinned block and captured commands
  — include both.
