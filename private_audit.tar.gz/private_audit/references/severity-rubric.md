# Severity, Confidence, and Impact Taxonomy

Used in Stages 9–11. Keep severity tied to *demonstrated, realistic* impact, not
to the worst imaginable case. State the impact class and the assumptions it rests
on.

## Severity (impact × likelihood)

Default to a recognized bug-bounty scale (e.g., Immunefi). If the engagement
specifies its own, use that and say so.

- **Critical** — direct theft/permanent loss of a material fraction of user or
  protocol funds; protocol insolvency; unauthorized minting of value; takeover
  of upgrade/governance/admin authority. Realistic preconditions.
- **High** — theft/loss under specific but attainable conditions; freezing of
  funds; significant but bounded value extraction; griefing that denies a core
  function to all users.
- **Medium** — limited value extraction, recoverable loss, or temporary DoS of a
  non-core function; requires notable preconditions.
- **Low** — minor value leakage, edge-case griefing, or issues needing
  unrealistic preconditions.
- **Informational** — no direct security impact; code quality, gas, clarity,
  deviation from best practice.

Likelihood downgrades severity when the attack needs an admin key, an unrealistic
market state, a non-standard token the protocol won't list, or capital/timing
that makes it uneconomic. State the downgrade reason.

## Confidence (how sure are we it's real)

- **Confirmed** — independently validated PoC with before/after evidence on the
  scoped commit.
- **Probable** — strong source-code argument and a partial/local PoC; one
  assumption remains unproven (name it).
- **Theoretical** — plausible from the code but not reproduced; stays a lead.

Confidence and severity are independent: a Critical-severity issue can be only
Probable. Report both.

## Impact classes (do not conflate)

- Theoretical accounting discrepancy (numbers disagree, no extraction)
- Recoverable user loss (recoverable via normal action/admin)
- Permanent fund loss
- Protocol insolvency (liabilities > realizable assets)
- Temporary denial of service
- Permanent denial of service / bricking
- Privilege takeover
- Maximum possible loss (theoretical ceiling)
- Practically extractable value (after liquidity, slippage, gas, MEV competition)

For financial findings, always report both maximum-possible loss **and**
practically extractable value. The gap between them is often the difference
between Critical and Medium.

## Economic inputs to cite

required attacker capital · capital-lock duration · flash-loan feasibility ·
gas/execution cost · slippage · oracle-movement requirement · available
liquidity · max extractable value · protocol loss · user loss · bad debt ·
repeatability · front-running/MEV competition · limiting conditions.
