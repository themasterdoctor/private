#!/usr/bin/env bash
# init_engagement.sh — scaffold the audit/ artifact tree for a new engagement.
#
# Usage: scripts/init_engagement.sh <engagement-name> [target-dir]
#
# Creates the mandatory artifact layout, copies the fill-in templates and
# schemas, and stubs the JSON/JSONL records. It does NOT touch any network and
# creates nothing executable against a live system.
set -euo pipefail

NAME="${1:-}"
if [[ -z "$NAME" ]]; then
  echo "usage: $0 <engagement-name> [target-dir]" >&2
  exit 1
fi
TARGET_DIR="${2:-.}"
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$TARGET_DIR/audit-$NAME"

mkdir -p "$OUT"/{STATIC_ANALYSIS,TESTS,POC,EVIDENCE,FINDINGS}

# Copy fill-in templates as working artifacts.
cp "$SKILL_DIR/templates/AUTHORIZATION.md"      "$OUT/AUTHORIZATION.md"
cp "$SKILL_DIR/templates/BUILD_STATUS.md"       "$OUT/BUILD_STATUS.md"
cp "$SKILL_DIR/templates/ROLE_MATRIX.md"        "$OUT/ROLE_MATRIX.md"
cp "$SKILL_DIR/templates/INVARIANTS.md"         "$OUT/INVARIANTS.md"
cp "$SKILL_DIR/templates/ATTACK_TREES.md"       "$OUT/ATTACK_TREES.md"
cp "$SKILL_DIR/templates/NEGATIVE_KNOWLEDGE.md" "$OUT/NEGATIVE_KNOWLEDGE.md"
cp "$SKILL_DIR/templates/FINAL_REPORT.md"       "$OUT/FINAL_REPORT.md"

# Architecture artifacts the Protocol Architect fills in.
for f in CONTRACT_INVENTORY.json INHERITANCE_GRAPH.md CALL_GRAPH.md \
         STORAGE_LAYOUT.md ASSET_FLOW.md TRUST_BOUNDARIES.md EXTERNAL_DEPENDENCIES.md; do
  [[ "$f" == *.json ]] && echo "[]" > "$OUT/$f" || echo "# ${f%.md}" > "$OUT/$f"
done

# Stub the schema-bound records (empty but valid).
echo "{}" > "$OUT/SCOPE.json"
echo "{}" > "$OUT/REPOSITORY_LOCK.json"
: > "$OUT/HYPOTHESES.jsonl"

# Point back at the schemas for validation.
ln -s "$SKILL_DIR/schemas" "$OUT/_schemas" 2>/dev/null || cp -r "$SKILL_DIR/schemas" "$OUT/_schemas"

cat > "$OUT/README.md" <<EOF
# Audit workspace: $NAME

Scaffolded by Hermes Private Contract Auditor. Fill artifacts in lifecycle order.
NO active validation until AUTHORIZATION.md and SCOPE.json are complete.

Schemas: ./_schemas/  (validate SCOPE.json, REPOSITORY_LOCK.json, findings, etc.)
Lifecycle: see the skill's references/lifecycle.md
EOF

echo "Scaffolded engagement at: $OUT"
find "$OUT" -maxdepth 1 | sort
