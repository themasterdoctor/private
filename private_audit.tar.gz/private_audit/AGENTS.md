# AGENTS — Lane definitions and handoff contracts

Hermes Private Contract Auditor coordinates nine lanes. A "lane" is a role with
a defined input, output, and a gate that must pass before the next lane starts.
Lanes can be separate sub-agents (in a multi-agent runtime) or sequential modes
of one operator. The **independence rule** for the Exploit Validator holds
either way: it must reason from a clean environment and must not inherit the
hunter's conclusion.

The controller (`SKILL.md`) owns sequencing. `routing.json` is the
machine-readable version of the table below.

| Lane | Owns | Consumes | Produces | Gate to advance |
|------|------|----------|----------|-----------------|
| Scope Guardian | Stage 0 | engagement brief | `SCOPE.json`, `REPOSITORY_LOCK.json`, `AUTHORIZATION.md` | scope artifacts complete and authorization confirmed |
| Protocol Architect | Stages 1–2 | scoped repo | `BUILD_STATUS.md`, `CONTRACT_INVENTORY.json`, `INHERITANCE_GRAPH.md`, `CALL_GRAPH.md`, `STORAGE_LAYOUT.md`, `ROLE_MATRIX.md`, `ASSET_FLOW.md`, `TRUST_BOUNDARIES.md`, `EXTERNAL_DEPENDENCIES.md` | build reproducible (or blockers recorded); trust boundaries identified |
| Invariant Analyst | Stage 3 | architecture map | `INVARIANTS.md` | each invariant is explicit, testable, and tied to an asset/authority |
| Code Hunter | Stages 4–6 | invariants + architecture | `ATTACK_TREES.md`, `HYPOTHESES.jsonl`, `STATIC_ANALYSIS/` | every hypothesis names the invariant it may violate and a candidate code path |
| Fuzzing Engineer | Stage 7 (properties) | invariants + hypotheses | invariant tests, handlers, Echidna/Medusa/Halmos properties under `TESTS/` | properties compile and encode the named invariant |
| Exploit Validator | Stages 7–8 (validation) | hypotheses + tests | `POC/`, `EVIDENCE/`, validation records | independent reproduction attempted from clean env; outcome assigned |
| Economic Analyst | Stage 9 | confirmed/partial findings | economic block per finding | profit/loss modeled with stated assumptions; MEV/liquidity considered |
| Reporter | Stages 10–11 | validated findings + economics | `FINDINGS/`, `FINAL_REPORT.md` | skeptic review passed; every claim labeled by evidence type |
| Retester | Stage 12 | fix/patch | retest records | original PoC fails; invariant restored; no regression |

## Handoff contract (applies to every transition)

A lane may only hand off an artifact that:

1. References the repository and commit it was produced against.
2. Labels each statement as observed fact / source-code fact / test result /
   inference / uncertainty.
3. Carries forward open questions and assumptions explicitly (no silent
   resolution).
4. Conforms to its schema in `schemas/` when a schema exists.

## The independence rule (Exploit Validator)

The Code Hunter produces a hypothesis with a believed root cause and impact. The
Exploit Validator must independently determine:

- whether the path exists in the scoped version
- whether attacker-controlled inputs actually reach the vulnerable operation
- whether protective controls (modifiers, guards, pauses, invariant checks)
  prevent exploitation
- whether the exploit requires unrealistic assumptions (capital, timing,
  privileged role, non-standard token)
- whether the observed impact is caused by the *claimed* root cause, not a test
  artifact
- whether the result is repeatable
- whether the PoC actually causes the claimed state/balance delta
- whether the issue is already documented, intended, or a known acceptance

Validator outcome ∈ `CONFIRMED | PARTIALLY_CONFIRMED | REJECTED | INCONCLUSIVE |
DUPLICATE_RISK | MANUAL_REVIEW_REQUIRED`. The Reporter cannot promote a
hypothesis to a finding without a validation record of `CONFIRMED` or
`PARTIALLY_CONFIRMED` (and `PARTIALLY_CONFIRMED` must state what remains
unproven).

## Skeptic pass (before reporting)

The Reporter runs an adversarial self-review (Stage 10) that tries to *break* the
finding: disprove reachability, attacker control, the permission assumption, the
invariant violation, the impact magnitude, repeatability, the severity, the
novelty, and scope eligibility. If the primary impact depends on an unsupported
assumption, the finding is downgraded to a lead and returned to the Code Hunter.

## Negative knowledge

Every lane writes disproven hypotheses, intended-behavior conclusions, and
"looked vulnerable but isn't, because X" results to `NEGATIVE_KNOWLEDGE.md`.
This prevents re-deriving the same dead ends and is itself a deliverable — it
tells the client what was checked and cleared.
