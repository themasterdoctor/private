# Foundry PoC templates

These are **templates**, not executed artifacts. Copy them into an engagement,
wire in the scoped contracts, and run them yourself — then capture the real
output into `EVIDENCE/` per `schemas/evidence.schema.json`. Do not record a
result you did not actually produce.

- `test/UnitExploit.t.sol` — deterministic, minimal-assumption exploit PoC.
  Start here. Fastest, cheapest evidence.
- `test/InvariantBase.t.sol` + `test/Handler.sol` — stateful invariant testing.
  Encode the invariants from `INVARIANTS.md` as `invariant_*` assertions.
- `test/ForkExploit.t.sol` — mainnet-fork simulation (read-only RPC, pinned
  block). Only when authorized; never broadcasts production transactions.

Run examples (capture output):
    forge test --match-path test/UnitExploit.t.sol -vvvv
    forge test --match-contract Invariant -vvv
    forge test --match-path test/ForkExploit.t.sol --fork-url mainnet --fork-block-number <N> -vvvv

Rules carried from SOUL.md: pin commit + fork block with every result; snapshot
balances/state before and after; no real keys; no production state changes.
