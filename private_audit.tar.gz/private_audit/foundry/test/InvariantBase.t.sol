// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.20;

import {Test} from "forge-std/Test.sol";
import {Handler} from "./Handler.sol";

/// @title InvariantBase — stateful invariant testing scaffold
/// @notice Encodes invariants from INVARIANTS.md as `invariant_*` assertions
///         that must hold after every randomized handler call sequence.
///         A failing invariant + the shrunk call sequence is a hypothesis with
///         a built-in repro. Promote only after independent validation.
contract InvariantBaseTest is Test {
    Handler internal handler;
    // Target internal target;

    function setUp() public {
        // TODO: deploy the scoped system.
        // target = new Target(...);
        handler = new Handler(/* target */);

        // Only fuzz through the handler's bounded entry points.
        targetContract(address(handler));

        bytes4[] memory selectors = new bytes4[](2);
        selectors[0] = Handler.deposit.selector;
        selectors[1] = Handler.withdraw.selector;
        targetSelector(FuzzSelector({addr: address(handler), selectors: selectors}));
    }

    /// INV-C1 (accounting): internal accounting never exceeds real assets.
    function invariant_accountingBackedByAssets() public view {
        // uint256 realAssets = token.balanceOf(address(target));
        // uint256 internalLiabilities = target.totalAssets();
        // assertLe(internalLiabilities, realAssets, "INV-C1: under-collateralized");
    }

    /// INV-S1 (solvency): every depositor can be made whole.
    function invariant_solvent() public view {
        // assertGe(target.realizableAssets(), target.totalLiabilities(), "INV-S1");
    }

    /// INV-C-share (no free value): share price is non-decreasing absent fees/loss.
    function invariant_sharePriceMonotone() public view {
        // assertGe(target.convertToAssets(1e18), lastSharePrice, "INV: share price dropped");
    }

    /// @dev Surfaces the handler's call distribution in the run summary.
    function invariant_callSummary() public view {
        // console2.log("deposited", handler.ghost_depositedSum());
    }
}
