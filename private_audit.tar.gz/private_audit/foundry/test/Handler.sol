// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.20;

import {Test} from "forge-std/Test.sol";

/// @title Handler — bounded actor for stateful invariant testing
/// @notice The invariant fuzzer calls these functions in random order with
///         random inputs. Bound inputs to realistic ranges and use ghost
///         variables to track expected accounting so invariants can compare
///         expected vs actual. Keep actions to legitimate protocol operations
///         (the point is to find a sequence of *valid* calls that breaks an
///         invariant), unless you are specifically modeling an adversary.
contract Handler is Test {
    // TODO: reference to the system under test.
    // Target internal target;

    // Ghost accounting — what the protocol *should* believe.
    uint256 public ghost_depositedSum;
    uint256 public ghost_withdrawnSum;

    // A small set of actors keeps state coherent and counterexamples readable.
    address[] internal actors;
    address internal currentActor;

    modifier useActor(uint256 seed) {
        currentActor = actors[bound(seed, 0, actors.length - 1)];
        vm.startPrank(currentActor);
        _;
        vm.stopPrank();
    }

    constructor(/* Target _target */) {
        // target = _target;
        actors.push(makeAddr("alice"));
        actors.push(makeAddr("bob"));
        actors.push(makeAddr("carol"));
    }

    function deposit(uint256 actorSeed, uint256 amount) external useActor(actorSeed) {
        amount = bound(amount, 0, 1e24);
        // TODO: target.deposit(amount);
        ghost_depositedSum += amount;
    }

    function withdraw(uint256 actorSeed, uint256 amount) external useActor(actorSeed) {
        amount = bound(amount, 0, 1e24);
        // TODO: target.withdraw(amount);
        ghost_withdrawnSum += amount;
    }

    // Add the protocol's other state-changing entry points here.
}
