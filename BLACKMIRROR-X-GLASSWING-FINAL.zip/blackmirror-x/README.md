# BLACKMIRROR-X GLASSWING

**Autonomous AI-Powered Vulnerability Research Operating System**

Elite offensive security platform for bug bounty hunters, red teamers, and AppSec teams. Combines autonomous recon pipelines, multi-agent AI reasoning, real-time attack surface analysis, and professional reporting.

---

## Quick Deploy (VPS)

```bash
# On your VPS (Ubuntu 22.04+):
cd ~/private
unzip BLACKMIRROR-X-GLASSWING.zip
cd blackmirror-x

# ONE COMMAND to deploy + fix all runtime bugs:
bash scripts/fix_now.sh
```

After completion:
- **UI:** `http://<YOUR_IP>:3000`
- **Login:** `admin@blackmirror.io` / `BlackMirrorX2025!`
- **API Docs:** `http://<YOUR_IP>:8000/api/docs`

---

## Local Development

```bash
# Prerequisites: Docker, Docker Compose, Git

git clone <repo> blackmirror-x
cd blackmirror-x

# Configure environment
cp .env.example .env
# Edit .env — required:
#   ANTHROPIC_API_KEY=sk-ant-YOUR-KEY
#   SERVER_IP=localhost  (or your VPS IP)

# Start everything
docker compose up -d

# Verify
curl http://localhost:8000/health
open http://localhost:3000
```

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                   BLACKMIRROR-X GLASSWING                   │
├─────────────────┬───────────────┬───────────────────────────┤
│  Frontend       │  Backend      │  Workers                  │
│  Next.js 14     │  FastAPI      │  Celery + Redis           │
│  React 18       │  SQLAlchemy   │  Scan Pipeline            │
│  TailwindCSS    │  PostgreSQL   │  Report Generation        │
│  Framer Motion  │  pgvector     │  Intelligence Agents      │
│  shadcn/ui      │  JWT Auth     │  Continuous Monitor       │
└─────────────────┴───────────────┴───────────────────────────┘
```

**Service endpoints:**
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000
- Swagger Docs: http://localhost:8000/api/docs
- Celery Flower: http://localhost:5555
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3001

---

## Platform Capabilities

### Recon Engine
- Subdomain enumeration (subfinder, dnsx)
- HTTP probing (httpx — title, tech detection, status codes)
- Port scanning (naabu)
- URL discovery (katana active crawler + gau passive)
- All tools gracefully degrade if not installed

### Vulnerability Research
- XSS, SQLi, SSRF, SSTI, IDOR, CORS, Open Redirect, CRLF
- GraphQL introspection and abuse
- JWT algorithm confusion testing
- Auth bypass indicators
- File upload testing
- Differential response analysis
- AI-generated context-aware payloads

### AI Intelligence Layer
| System | Description |
|--------|-------------|
| **Hypothesis Engine** | Autonomous vuln hypothesis formation from scan signals |
| **Validation Court** | 5-agent adversarial validation (prosecution / defense / judge) |
| **Workspace Memory** | Persistent learning from past scans, false positive tracking |
| **Attack Chain Composer** | Multi-step attack path composition with probability scoring |
| **Payload Intelligence** | WAF-aware payload selection for XSS/SQLi/SSRF/SSTI |
| **JS Reverse Engineer** | AST analysis, secret extraction, DOM XSS source→sink mapping |
| **Browser Intelligence** | Playwright authenticated crawling, SPA route discovery |
| **Exploitability Simulator** | Safe ATO/data exposure/cloud compromise simulation |
| **Copilot Agent** | Conversational AI security analyst with context injection |
| **RAG Intelligence** | Vector search over CVEs, HackerOne reports, writeups |

### Reporting
- Markdown / JSON / PDF-ready reports
- HackerOne-style submission format
- Executive summaries
- CVSS/CWE auto-mapping
- Evidence sections with reproduction steps

---

## Frontend Pages

| Route | Description |
|-------|-------------|
| `/dashboard` | Mission control — scan stats, quick launch, recent findings |
| `/recon` | Subdomain map, technology fingerprints, URL inventory |
| `/vulns` | Vulnerability cards with severity filter, evidence expansion |
| `/graph` | D3 attack graph — hosts, APIs, JS, vulnerability nodes |
| `/scans/[id]` | Live scan detail with streaming SSE log terminal |
| `/mission` | AI Mission Control — hypothesis board + reasoning trace |
| `/court` | AI Courtroom — 5-agent adversarial verdict system |
| `/evidence` | Evidence Vault — request/response proof browser |
| `/monitor` | Continuous monitoring with change detection alerts |
| `/replay` | HTTP request replay lab with diff comparison |
| `/copilot` | AI security analyst chat with workspace context |
| `/reports` | Generate and download professional security reports |
| `/settings` | Workspace management, API key creation, account |
| `/workers` | Celery worker status, task queue monitoring |
| `/demo` | Demo mode with pre-seeded data |

---

## AI Agents

### Recon Agent (`app/agents/recon/agent.py`)
Orchestrates subfinder → dnsx → httpx → naabu → katana + gau pipeline.
All tool failures gracefully logged, scan continues.

### Vulnerability Research Agent (`app/agents/vuln_research/agent.py`)
Safe testing modules for XSS, SQLi, SSRF, SSTI, IDOR, CORS, Open Redirect, CRLF, GraphQL, auth bypass, file upload. Rate-limited, scope-enforced, WAF-aware.

### JS Intelligence Agent (`app/agents/js_analysis/agent.py`)
Bundle analysis, secret detection, endpoint extraction, AST-based DOM XSS source/sink mapping. Uses Claude for semantic analysis.

### Copilot Agent (`app/agents/copilot/agent.py`)
Streaming conversational AI analyst. Inject scan context, ask for payloads, attack chains, report drafts. Powered by Claude.

### Report Writer Agent (`app/agents/report_writer/agent.py`)
Generates professional Markdown and HackerOne-style reports with AI executive summaries, CVSS/CWE mapping, reproduction steps.

### RAG Intelligence Agent (`app/agents/rag/agent.py`)
Vector search over security knowledge base. Recommends payloads, similar CVEs, attack paths.

---

## Backend API

Base URL: `http://localhost:8000/api/v1`

### Authentication
```
POST /auth/register          Register new user
POST /auth/login             Login (returns JWT)
POST /auth/refresh           Refresh access token
GET  /auth/me                Current user profile
```

### Workspaces
```
POST   /workspaces           Create workspace
GET    /workspaces           List my workspaces
GET    /workspaces/{id}      Get workspace
```

### Scans
```
POST   /scans                Launch scan (accepts target URL or domain)
GET    /scans                List scans for workspace
GET    /scans/{id}           Get scan detail
POST   /scans/{id}/cancel    Cancel running scan
GET    /scans/{id}/logs      Get scan logs
GET    /scans/{id}/stream    SSE live log stream
```

### Vulnerabilities
```
GET    /vulns                List vulns (filter by workspace, scan, severity)
GET    /vulns/{id}           Get vulnerability detail
PATCH  /vulns/{id}           Update status/notes
GET    /vulns/{id}/hackerone-report  HackerOne-style report
```

### Recon
```
GET    /recon/subdomains     List discovered subdomains
GET    /recon/urls           List discovered URLs
```

### Reports
```
POST   /reports/generate/{scan_id}  Generate report (async)
GET    /reports              List reports
GET    /reports/{id}         Get report with content
```

### API Keys
```
POST   /apikeys              Create API key (raw key shown once)
GET    /apikeys              List active keys
DELETE /apikeys/{id}         Revoke key
```

### AI Copilot
```
POST   /copilot/chat/stream  Streaming AI chat
GET    /copilot/sessions     List sessions
```

### Intelligence
```
POST   /intel/hypotheses/generate/{scan_id}   Generate vuln hypotheses
GET    /intel/hypotheses/stream/{scan_id}     Stream hypothesis generation
POST   /intel/court/adjudicate/{vuln_id}      AI court verdict
GET    /intel/memory/{workspace_id}           Workspace memory
POST   /intel/simulate/{vuln_id}              Exploitability simulation
GET    /intel/payloads/{vuln_type}            Get payloads for vuln type
POST   /intel/monitor/start                   Start continuous monitoring
```

---

## Environment Variables

Copy `.env.example` to `.env` and configure:

```bash
# Required
ANTHROPIC_API_KEY=sk-ant-...    # Your Claude API key
SECRET_KEY=<32+ random chars>
JWT_SECRET_KEY=<32+ random chars>
POSTGRES_PASSWORD=<choose>
BMX_VAULT_KEY=<32+ random chars>

# Optional (defaults work for local dev)
NEXT_PUBLIC_API_URL=http://localhost:8000
SERVER_IP=localhost
OPENAI_API_KEY=                 # Optional OpenAI fallback
```

---

## Database Schema

Key tables:
- `users` — authentication, RBAC
- `workspaces` + `workspace_members` — multi-tenant isolation
- `scan_jobs` — scan state, config, celery task ID
- `scan_logs` — streaming log entries
- `subdomains` — discovered hosts with tech fingerprints
- `discovered_urls` — crawled endpoints with parameters
- `vulnerabilities` — findings with CVSS/CWE, AI scoring
- `reports` — generated reports with content
- `copilot_messages` — conversation history
- `knowledge_chunks` — RAG vector store (pgvector)
- `api_keys` — hashed API keys with scopes
- `audit_logs` — full activity audit trail

---

## Deployment Notes

### VPS (Recommended: Ubuntu 22.04, 4GB+ RAM)

```bash
# Install Docker
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER

# Deploy
bash scripts/fix_now.sh
```

### Production Hardening
1. Set `DEBUG=false` in `.env`
2. Change all default passwords
3. Put Nginx reverse proxy in front (see `infrastructure/nginx/nginx.conf`)
4. Configure firewall: only expose ports 80/443
5. Enable Prometheus + Grafana for monitoring

---

## Troubleshooting

**Scans not starting (stuck QUEUED)**
```bash
docker compose logs worker --tail=50
# Should show: "Starting scan pipeline for domain.com"
# If not: docker compose restart worker
```

**Login fails**
```bash
docker compose logs backend --tail=20
# Check for migration errors
docker compose exec backend alembic upgrade head
docker compose exec backend python scripts/seed.py
```

**Frontend shows CORS errors**
```bash
# Verify .env has correct IP
grep CORS_ORIGINS .env
grep NEXT_PUBLIC_API_URL .env
# Then rebuild: docker compose build --no-cache frontend && docker compose up -d frontend
```

**Full reset**
```bash
docker compose down -v  # Destroys all data
bash scripts/fix_now.sh
```

---

## Security

- All scanning requires explicit user authentication
- Workspace isolation: users only see their own data
- Rate limiting on all endpoints (configurable)
- Audit log on every action
- API keys hashed with SHA-256
- JWT tokens with configurable expiry
- Never scan targets you don't own or have explicit permission to test

---

## License

For authorized security testing only. Users are responsible for ensuring all scanning activity is authorized by target system owners.

---

*BLACKMIRROR-X GLASSWING — Built for elite security researchers.*
