#!/usr/bin/env bash
# verify_ui_actions.sh — Tests every critical UI button action via API
# Usage: bash scripts/verify_ui_actions.sh
set -uo pipefail

BACKEND="${BACKEND_URL:-http://localhost:8000}"
PASS=0; FAIL=0

GREEN='\033[0;32m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "  ${GREEN}✓${NC}  $1"; PASS=$((PASS+1)); }
fail() { echo -e "  ${RED}✗${NC}  $1"; FAIL=$((FAIL+1)); }
info() { echo -e "  ${CYAN}→${NC}  $1"; }

echo ""
echo "═══════════════════════════════════════════════════════"
echo "  BLACKMIRROR-X UI Action Verification"
echo "═══════════════════════════════════════════════════════"
echo ""

# ── 1. Backend reachable ──────────────────────────────────────────
echo "── 1. Connectivity ──────────────────────────────────────"
HEALTH=$(curl -s -o /dev/null -w "%{http_code}" "$BACKEND/health" 2>/dev/null)
[ "$HEALTH" = "200" ] && ok "Backend: $BACKEND" || { fail "Backend unreachable: $HEALTH"; exit 1; }

# ── 2. Login ──────────────────────────────────────────────────────
echo ""
echo "── 2. Authentication ────────────────────────────────────"
TOKEN=$(curl -s -X POST "$BACKEND/api/v1/auth/login" \
  --data-urlencode "username=admin@blackmirror.io" \
  --data-urlencode "password=BlackMirrorX2025!" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('access_token',''))" 2>/dev/null)

if [ -n "$TOKEN" ] && [ "$TOKEN" != "None" ]; then
  ok "Login POST /auth/login → JWT token"
else
  fail "Login failed — token not returned"
  exit 1
fi

# Verify token works
ME=$(curl -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: Bearer $TOKEN" "$BACKEND/api/v1/auth/me")
[ "$ME" = "200" ] && ok "GET /auth/me → 200" || fail "GET /auth/me → $ME"

# ── 3. Workspace ──────────────────────────────────────────────────
echo ""
echo "── 3. Workspace & Data ──────────────────────────────────"
WS=$(curl -s -H "Authorization: Bearer $TOKEN" "$BACKEND/api/v1/workspaces" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print(d[0]['id'] if d else '')" 2>/dev/null)
[ -n "$WS" ] && ok "GET /workspaces → ${WS:0:8}" || fail "GET /workspaces → no workspace"

# ── 4. Scans ──────────────────────────────────────────────────────
SCANS=$(curl -s -H "Authorization: Bearer $TOKEN" "$BACKEND/api/v1/scans?workspace_id=$WS")
SCAN_ID=$(echo "$SCANS" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d[0]['id'] if d else '')" 2>/dev/null)
HAS_TARGET=$(echo "$SCANS" | python3 -c "import sys,json; d=json.load(sys.stdin); print('ok' if d and 'target' in d[0] else 'missing')" 2>/dev/null)
[ "$HAS_TARGET" = "ok" ] && ok "GET /scans → has target field" || fail "GET /scans → missing target field"

# Scan create (the fixed payload)
NEW_SCAN=$(curl -s -X POST "$BACKEND/api/v1/scans" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"workspace_id\":\"$WS\",\"name\":\"UI Test Scan\",\"scan_type\":\"recon\",\"config\":{\"domain\":\"localhost\"}}" \
  | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null)
[ -n "$NEW_SCAN" ] && ok "POST /scans create → ${NEW_SCAN:0:8}" || fail "POST /scans create → no id"

# ── 5. Vulnerabilities ────────────────────────────────────────────
echo ""
echo "── 4. Vulnerabilities ───────────────────────────────────"
VULN_ID=$(curl -s -H "Authorization: Bearer $TOKEN" "$BACKEND/api/v1/vulns?workspace_id=$WS" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print(d[0]['id'] if d else '')" 2>/dev/null)
[ -n "$VULN_ID" ] && ok "GET /vulns → ${VULN_ID:0:8}" || fail "GET /vulns → empty"

if [ -n "$VULN_ID" ]; then
  UPD=$(curl -s -o /dev/null -w "%{http_code}" -X PATCH \
    -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
    -d '{"status":"in_progress"}' "$BACKEND/api/v1/vulns/$VULN_ID")
  [ "$UPD" = "200" ] && ok "PATCH /vulns/:id status=in_progress → 200" || fail "PATCH /vulns/:id → $UPD"
  
  # Restore
  curl -s -X PATCH -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
    -d '{"status":"open"}' "$BACKEND/api/v1/vulns/$VULN_ID" -o /dev/null
fi

# ── 6. Intelligence ───────────────────────────────────────────────
echo ""
echo "── 5. Intelligence ──────────────────────────────────────"
if [ -n "$SCAN_ID" ]; then
  HYP=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
    -H "Authorization: Bearer $TOKEN" "$BACKEND/api/v1/intel/hypotheses/generate/$SCAN_ID")
  [ "$HYP" = "200" ] && ok "POST /intel/hypotheses/generate → 200" || fail "POST /intel/hypotheses/generate → $HYP"
fi

if [ -n "$VULN_ID" ]; then
  COURT=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
    -H "Authorization: Bearer $TOKEN" "$BACKEND/api/v1/intel/court/adjudicate/$VULN_ID")
  [ "$COURT" = "200" ] && ok "POST /intel/court/adjudicate → 200" || fail "POST /intel/court/adjudicate → $COURT"

  SIM=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
    -H "Authorization: Bearer $TOKEN" "$BACKEND/api/v1/intel/simulate/$VULN_ID")
  [ "$SIM" = "200" ] && ok "POST /intel/simulate → 200" || fail "POST /intel/simulate → $SIM"
fi

# ── 7. Reports ────────────────────────────────────────────────────
echo ""
echo "── 6. Reports ───────────────────────────────────────────"
if [ -n "$SCAN_ID" ]; then
  RPT=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
    -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
    -d '{"format":"markdown"}' "$BACKEND/api/v1/reports/generate/$SCAN_ID")
  [ "$RPT" = "202" ] || [ "$RPT" = "200" ] && ok "POST /reports/generate → $RPT" || fail "POST /reports/generate → $RPT"
fi

# ── 8. Demo ───────────────────────────────────────────────────────
echo ""
echo "── 7. Demo Mode ─────────────────────────────────────────"
DEMO=$(curl -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: Bearer $TOKEN" "$BACKEND/api/v1/demo/status")
[ "$DEMO" = "200" ] && ok "GET /demo/status → 200" || fail "GET /demo/status → $DEMO"

RESET=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
  -H "Authorization: Bearer $TOKEN" "$BACKEND/api/v1/demo/reset")
[ "$RESET" = "200" ] && ok "POST /demo/reset → 200" || fail "POST /demo/reset → $RESET"

# ── 9. Workers ────────────────────────────────────────────────────
echo ""
echo "── 8. Workers ───────────────────────────────────────────"
WRK=$(curl -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: Bearer $TOKEN" "$BACKEND/api/v1/workers/status")
[ "$WRK" = "200" ] && ok "GET /workers/status → 200" || fail "GET /workers/status → $WRK"

STOP=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
  -H "Authorization: Bearer $TOKEN" "$BACKEND/api/v1/workers/emergency-stop")
[ "$STOP" = "200" ] && ok "POST /workers/emergency-stop → 200" || fail "POST /workers/emergency-stop → $STOP"

RESUME=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
  -H "Authorization: Bearer $TOKEN" "$BACKEND/api/v1/workers/resume-all")
[ "$RESUME" = "200" ] && ok "POST /workers/resume-all → 200" || fail "POST /workers/resume-all → $RESUME"

# ── 10. Settings: API keys ────────────────────────────────────────
echo ""
echo "── 9. Settings ──────────────────────────────────────────"
KEY_RESP=$(curl -s -X POST "$BACKEND/api/v1/apikeys" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"name":"verify-test","scopes":["read"]}')
KEY_ID=$(echo "$KEY_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null)
HAS_RAW=$(echo "$KEY_RESP" | python3 -c "import sys,json; print('ok' if json.load(sys.stdin).get('raw_key') else 'missing')" 2>/dev/null)
[ -n "$KEY_ID" ] && [ "$HAS_RAW" = "ok" ] && ok "POST /apikeys → key_prefix + raw_key present" || fail "POST /apikeys → $KEY_RESP"

if [ -n "$KEY_ID" ]; then
  REVOKE=$(curl -s -o /dev/null -w "%{http_code}" -X DELETE \
    -H "Authorization: Bearer $TOKEN" "$BACKEND/api/v1/apikeys/$KEY_ID")
  [ "$REVOKE" = "200" ] || [ "$REVOKE" = "204" ] && ok "DELETE /apikeys/:id → $REVOKE" || fail "DELETE /apikeys/:id → $REVOKE"
fi

# ── 11. AVROS ────────────────────────────────────────────────────
echo ""
echo "── 10. AVROS Endpoints ──────────────────────────────────"
CHAINS=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BACKEND/api/v1/chains/build-from-vulns" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '[{"id":"v1","vuln_type":"xss","severity":"high","url":"/s","title":"XSS"}]')
[ "$CHAINS" = "200" ] && ok "POST /chains/build-from-vulns → 200" || fail "POST /chains/build-from-vulns → $CHAINS"

BI=$(curl -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: Bearer $TOKEN" "$BACKEND/api/v1/browser-intel/status")
[ "$BI" = "200" ] && ok "GET /browser-intel/status → 200" || fail "GET /browser-intel/status → $BI"

IDOR=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BACKEND/api/v1/api-intel/observe" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"method":"GET","url":"/api/users/1","response":{"id":"1"}}')
[ "$IDOR" = "200" ] && ok "POST /api-intel/observe → 200" || fail "POST /api-intel/observe → $IDOR"

REPLAY=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
  -H "Authorization: Bearer $TOKEN" \
  "$BACKEND/api/v1/replay/replay?method=GET&url=$BACKEND/health")
[ "$REPLAY" = "200" ] && ok "POST /replay/replay → 200" || fail "POST /replay/replay → $REPLAY"

# ── 12. Security boundary ──────────────────────────────────────────
echo ""
echo "── 11. Security ─────────────────────────────────────────"
NOAUTH=$(curl -s -o /dev/null -w "%{http_code}" "$BACKEND/api/v1/workspaces")
[ "$NOAUTH" = "401" ] && ok "Unauthenticated request → 401" || fail "Unauthenticated → $NOAUTH (expected 401)"

# ── Summary ───────────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════"
echo -e "  UI Action Verification: ${GREEN}$PASS passed${NC}  |  ${RED}$FAIL failed${NC}"
echo "═══════════════════════════════════════════════════════"
echo ""

[ $FAIL -eq 0 ]
