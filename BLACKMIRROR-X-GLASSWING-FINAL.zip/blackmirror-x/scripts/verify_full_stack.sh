#!/usr/bin/env bash
# verify_full_stack.sh — BLACKMIRROR-X live + static verification
# Static (no backend needed): bash scripts/verify_full_stack.sh
# Live:  BACKEND_URL=http://76.13.30.226:8000 FRONTEND_URL=http://76.13.30.226:3000 bash scripts/verify_full_stack.sh
# From inside container: bash scripts/verify_full_stack.sh (auto-detects)

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Find project root
if   [ -f "$SCRIPT_DIR/../backend/app/main.py" ]; then ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
elif [ -f "backend/app/main.py" ]; then ROOT="$(pwd)"
elif [ -f "/app/main.py" ]; then ROOT="/app"; INSIDE_DOCKER=1
else echo "Run from ~/private/blackmirror-x"; exit 1; fi
cd "$ROOT"

PASS=0; FAIL=0; WARN=0
pass() { echo "  ✓ $1"; PASS=$((PASS+1)); }
fail() { echo "  ✗ FAIL: $1"; FAIL=$((FAIL+1)); }
warn() { echo "  ⚠ $1"; WARN=$((WARN+1)); }

BACKEND_URL="${BACKEND_URL:-http://localhost:8000}"
FRONTEND_URL="${FRONTEND_URL:-http://localhost:3000}"
LIVE=false
curl -sf --max-time 3 "${BACKEND_URL}/health" >/dev/null 2>&1 && LIVE=true

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Full-Stack Verification            ║"
echo "╚══════════════════════════════════════════════════════╝"
echo "  Backend:  $BACKEND_URL  (live=$LIVE)"
echo "  Frontend: $FRONTEND_URL"
echo ""

# ── [1] Source files ────────────────────────────────────────
echo "[1/8] Source file checks..."
PY_COUNT=$(find "${ROOT}/backend/app" -name "*.py" 2>/dev/null | wc -l || echo 0)
[ "$PY_COUNT" -gt 100 ] && pass "$PY_COUNT Python source files" || fail "Python files missing (found $PY_COUNT)"

MIGS=$(ls "${ROOT}/backend/alembic/versions/"*.py 2>/dev/null | wc -l)
[ "$MIGS" -ge 4 ] && pass "$MIGS migration files (001→004)" || fail "Need 4 migrations, found $MIGS"

[ -f "${ROOT}/backend/app/enterprise/scope_engine.py" ] && pass "Enterprise modules present" || fail "backend/app/enterprise/ missing"

# ── [2] Backend static (run inside Docker if available) ─────
echo ""
echo "[2/8] Backend static verification..."
if docker compose exec -T backend python3 - << 'PYEOF' 2>/dev/null | grep -q "STATIC_PASS"
import sys, os, logging
sys.path.insert(0, '.')
import structlog
structlog.configure(wrapper_class=structlog.make_filtering_bound_logger(logging.CRITICAL))
os.environ.setdefault('DATABASE_URL','postgresql+asyncpg://x:x@localhost/x')
os.environ.setdefault('REDIS_URL','redis://localhost:6379/0')
os.environ.setdefault('CELERY_BROKER_URL','redis://localhost:6379/1')
os.environ.setdefault('CELERY_RESULT_BACKEND','redis://localhost:6379/2')
os.environ.setdefault('ANTHROPIC_API_KEY','test')
os.environ.setdefault('SECRET_KEY','test32chars_aaaaaaaaaaaaaaaaaaaaa')
os.environ.setdefault('JWT_SECRET_KEY','test32chars_aaaaaaaaaaaaaaaaaaaaa')
try:
    from app.main import app
    routes = [r for r in app.routes if hasattr(r,'path')]
    from app.enterprise.scope_engine import ScopeEngine
    from app.enterprise.confidence_scoring import score_finding
    from app.enterprise.approval_gates import ApprovalGate
    from app.enterprise.payload_library import get_auto_safe_payloads, PayloadTier
    from app.enterprise.plugin_sdk import registry
    from app.enterprise.team_features import check_permission
    from app.enterprise.evidence_engine import HttpEvidence
    from app.core.security import hash_password, verify_password, create_access_token, decode_token
    e=ScopeEngine('w'); e.add_scope('*.x.com')
    assert e.check_target('api.x.com').allowed
    p=score_finding('xss','high'); assert 0<p.overall_score<=1
    assert all(pl.tier!=PayloadTier.BLOCKED for pl in get_auto_safe_payloads('sqli'))
    assert len(registry.list_plugins())>=2
    assert check_permission('admin','scan:create') and not check_permission('viewer','scan:create')
    ev=HttpEvidence(method='POST',url='https://t.com',status_code=200,payload_used='t',indicator_found='x')
    assert 'curl' in ev.to_curl()
    assert verify_password('pw', hash_password('pw'))
    print(f"STATIC_PASS:{len(routes)}_routes")
except Exception as e:
    import traceback; traceback.print_exc()
    print(f"STATIC_FAIL:{e}")
PYEOF
then
    ROUTE_COUNT=$(docker compose exec -T backend python3 -c "
import sys,os,logging; sys.path.insert(0,'.')
import structlog; structlog.configure(wrapper_class=structlog.make_filtering_bound_logger(logging.CRITICAL))
os.environ.update({'DATABASE_URL':'postgresql+asyncpg://x:x@localhost/x','REDIS_URL':'redis://localhost:6379/0',
'CELERY_BROKER_URL':'redis://localhost:6379/1','CELERY_RESULT_BACKEND':'redis://localhost:6379/2',
'ANTHROPIC_API_KEY':'test','SECRET_KEY':'test32chars_aaaaaaaaaaaaaaaaaaaaa',
'JWT_SECRET_KEY':'test32chars_aaaaaaaaaaaaaaaaaaaaa'})
from app.main import app; print(len([r for r in app.routes if hasattr(r,'path')]))" 2>/dev/null || echo "?")
    pass "Inside-container: app imports OK — $ROUTE_COUNT routes, all enterprise modules functional"
else
    # Fall back to local Python check
    python3 - << 'PYEOF' 2>/dev/null | grep -q "OK" && pass "Local Python: app.main imports OK" || warn "Backend static check skipped (Python deps not installed locally — OK, runs in Docker)"
import sys,os; sys.path.insert(0,'backend')
os.environ.setdefault('DATABASE_URL','postgresql+asyncpg://x:x@localhost/x')
os.environ.setdefault('REDIS_URL','redis://localhost:6379/0')
os.environ.setdefault('CELERY_BROKER_URL','redis://localhost:6379/1')
os.environ.setdefault('CELERY_RESULT_BACKEND','redis://localhost:6379/2')
os.environ.setdefault('ANTHROPIC_API_KEY','test')
os.environ.setdefault('SECRET_KEY','test32chars_aaaaaaaaaaaaaaaaaaaaaa')
os.environ.setdefault('JWT_SECRET_KEY','test32chars_aaaaaaaaaaaaaaaaaaaaaa')
try:
    from app.main import app; print("OK")
except: print("MISSING_DEPS")
PYEOF
fi

# ── [3] Nav links → page files ──────────────────────────────
echo ""
echo "[3/8] Nav link → page consistency..."
python3 - << 'PYEOF' 2>/dev/null
import re,os,sys
try:
    layout=open("frontend/src/app/dashboard/layout.tsx").read()
    hrefs=re.findall(r'href:\s*"(/[^"]*)"',layout)
    missing=[h for h in hrefs if not os.path.exists(f"frontend/src/app{h}/page.tsx")]
    if missing: print(f"FAIL:{missing}"); sys.exit(1)
    print(f"PASS:{len(hrefs)}_links")
except Exception as e: print(f"ERR:{e}"); sys.exit(1)
PYEOF
[ $? -eq 0 ] && pass "All nav links have page files" || fail "Nav link → page mismatch"

# ── [4] API route consistency ────────────────────────────────
echo ""
echo "[4/8] API route consistency..."
python3 - << 'PYEOF' 2>/dev/null
import re,os,sys
rd="backend/app/api/routes"
if not os.path.exists(rd): print("SKIP"); sys.exit(0)
pm={"auth":"/api/v1/auth","workspaces":"/api/v1/workspaces","scans":"/api/v1/scans",
    "recon":"/api/v1/recon","vulns":"/api/v1/vulns","reports":"/api/v1/reports",
    "copilot":"/api/v1/copilot","enterprise":"/api/v1/enterprise","intelligence":"/api/v1/intel"}
bp=set()
for f in os.listdir(rd):
    if not f.endswith(".py"): continue
    pfx=pm.get(f[:-3],f"/api/v1/{f[:-3]}")
    for m in re.finditer(r'@(?:router|app)\.(get|post|patch|delete|put)\s*\(\s*["\']([^"\']*)["\']',open(f"{rd}/{f}").read()):
        bp.add(pfx+m.group(2))
crit=["/api/v1/auth/login","/api/v1/workspaces","/api/v1/scans","/api/v1/vulns",
      "/api/v1/recon/subdomains","/api/v1/enterprise/scope/{workspace_id}",
      "/api/v1/enterprise/approvals/{request_id}/approve","/api/v1/enterprise/plugins"]
miss=[ep for ep in crit if not any(b.startswith(ep.split("{")[0]) for b in bp)]
if miss: print(f"FAIL:{miss}"); sys.exit(1)
print(f"PASS:{len(bp)}_routes")
PYEOF
[ $? -eq 0 ] && pass "All critical API routes present in backend" || fail "Missing backend routes"

# ── [5] requirements.txt ─────────────────────────────────────
echo ""
echo "[5/8] requirements.txt completeness..."
python3 -c "
r=open('backend/requirements.txt').read().lower()
m=[p for p in ['fastapi','uvicorn','sqlalchemy','asyncpg','alembic','pydantic','python-jose',
   'passlib','redis','celery','anthropic','structlog','httpx'] if p not in r]
print('FAIL:'+str(m) if m else 'PASS')
" 2>/dev/null | grep -q PASS && pass "requirements.txt complete" || fail "requirements.txt missing packages"

# ── [6] .env.example ─────────────────────────────────────────
echo ""
echo "[6/8] .env.example documentation..."
python3 -c "
e=open('.env.example').read()
m=[v for v in ['ANTHROPIC_API_KEY','SECRET_KEY','JWT_SECRET_KEY','POSTGRES_PASSWORD',
   'DATABASE_URL','REDIS_URL','CORS_ORIGINS','NEXT_PUBLIC_API_URL'] if v not in e]
print('FAIL:'+str(m) if m else 'PASS')
" 2>/dev/null | grep -q PASS && pass ".env.example documents all required vars" || fail ".env.example incomplete"

# ── [7] Pytest inside container ──────────────────────────────
echo ""
echo "[7/8] Test suite (inside Docker)..."
# Check .env exists (required for docker compose commands)
if [ ! -f ".env" ] && [ ! -f ".env.vps" ]; then
    warn "Tests skipped: .env not found (run fix_running_vps.sh first)"
elif docker compose ps 2>/dev/null | grep -q "backend"; then
    # Ensure .env exists for docker compose
    [ -f ".env" ] || cp .env.vps .env 2>/dev/null || true
    # Check container is actually up
    BACKEND_UP=$(docker compose ps 2>/dev/null | grep backend | grep -c "Up\|running" || echo 0)
    if [ "$BACKEND_UP" -gt 0 ]; then
        docker compose exec -T backend pip install pytest pytest-asyncio -q 2>/dev/null | tail -1
        TEST_OUT=$(docker compose exec -T backend python -m pytest tests/test_production_readiness.py -q --tb=line 2>&1)
        PASSED=$(echo "$TEST_OUT" | grep -oP '\d+ passed' | grep -oP '\d+' || echo 0)
        FAILED=$(echo "$TEST_OUT" | grep -oP '\d+ failed' | grep -oP '\d+' || echo 0)
        echo "$TEST_OUT" | tail -3
        [ "$FAILED" -eq 0 ] && [ "$PASSED" -gt 0 ] && pass "$PASSED tests passed inside container" || fail "Tests: $PASSED passed, $FAILED failed"
    else
        warn "Backend container not running — run: bash scripts/fix_now.sh"
    fi
else
    warn "Docker not available — tests skipped"
fi

# ── [8] Live stack ───────────────────────────────────────────
echo ""
echo "[8/8] Live stack tests..."
if [ "$LIVE" = "true" ]; then

    # Health
    H=$(curl -s --max-time 5 "${BACKEND_URL}/health" 2>/dev/null)
    echo "$H" | grep -q "healthy" && pass "/health → healthy" || fail "/health: $H"

    # Login — form data (CRITICAL: must be x-www-form-urlencoded, NOT JSON)
    LOGIN=$(curl -s --max-time 10 -X POST "${BACKEND_URL}/api/v1/auth/login" \
        -H "Content-Type: application/x-www-form-urlencoded" \
        -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" 2>/dev/null)
    TOKEN=$(echo "$LOGIN" | python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))" 2>/dev/null || echo "")

    if [ -n "$TOKEN" ]; then
        pass "Login: JWT obtained"

        # /auth/me
        ME=$(curl -s --max-time 5 "${BACKEND_URL}/api/v1/auth/me" -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
            python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('email',''))" 2>/dev/null || echo "")
        [ -n "$ME" ] && pass "/auth/me: $ME" || fail "/auth/me failed"

        # Workspaces
        WS=$(curl -s --max-time 5 "${BACKEND_URL}/api/v1/workspaces" -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
            python3 -c "import sys,json; ws=json.load(sys.stdin); print(ws[0]['id'] if ws else '')" 2>/dev/null || echo "")
        [ -n "$WS" ] && pass "GET /workspaces: found ${WS:0:8}..." || warn "No workspaces (seed may not have run)"

        # Create workspace
        CW=$(curl -s --max-time 10 -X POST "${BACKEND_URL}/api/v1/workspaces" \
            -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
            -d '{"name":"verify-test","description":"auto"}' 2>/dev/null | \
            python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('id',''))" 2>/dev/null || echo "")
        [ -n "$CW" ] && pass "POST /workspaces: created ${CW:0:8}..." || fail "Workspace creation failed"
        USE_WS="${CW:-$WS}"

        if [ -n "$USE_WS" ]; then
            # Create scan
            SC=$(curl -s --max-time 10 -X POST "${BACKEND_URL}/api/v1/scans" \
                -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
                -d "{\"name\":\"verify\",\"workspace_id\":\"$USE_WS\",\"scan_type\":\"recon\",\"target\":\"https://testphp.vulnweb.com\"}" 2>/dev/null | \
                python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('id','')+'|'+d.get('status',''))" 2>/dev/null || echo "")
            [ -n "$SC" ] && pass "POST /scans: created ($(echo $SC | cut -d'|' -f1 | cut -c1-8)... status=$(echo $SC | cut -d'|' -f2))" || fail "Scan creation failed"

            # Enterprise scope
            SCOPE=$(curl -s --max-time 5 "${BACKEND_URL}/api/v1/enterprise/scope/${USE_WS}" \
                -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
                python3 -c "import sys,json; d=json.load(sys.stdin); print('OK' if 'workspace_id' in d else 'FAIL:'+str(d)[:100])" 2>/dev/null || echo "FAIL:curl_error")
            [ "$SCOPE" = "OK" ] && pass "GET /enterprise/scope: OK" || fail "Enterprise scope: $SCOPE"

            # Enterprise plugins
            PC=$(curl -s --max-time 5 "${BACKEND_URL}/api/v1/enterprise/plugins" \
                -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
                python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d.get('plugins',[])))" 2>/dev/null || echo 0)
            [ "$PC" -ge 2 ] && pass "GET /enterprise/plugins: $PC plugins" || fail "Enterprise plugins: $PC (expected ≥2)"

            # Emergency stop + resume
            ES=$(curl -s --max-time 5 -X POST "${BACKEND_URL}/api/v1/enterprise/emergency-stop/${USE_WS}" \
                -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" 2>/dev/null | \
                python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('emergency_stopped',''))" 2>/dev/null || echo "")
            [ "$ES" = "True" ] && pass "POST /enterprise/emergency-stop: activated" || warn "Emergency stop: $ES"
            curl -s -X POST "${BACKEND_URL}/api/v1/enterprise/emergency-stop/${USE_WS}/resume" \
                -H "Authorization: Bearer $TOKEN" >/dev/null 2>&1 && echo "  ✓ Emergency stop resumed"
        fi

        # Vuln list
        VL=$(curl -s --max-time 5 "${BACKEND_URL}/api/v1/vulns?workspace_id=${WS:-$USE_WS}" \
            -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
            python3 -c "import sys,json; print(len(json.load(sys.stdin)))" 2>/dev/null || echo 0)
        pass "GET /vulns: $VL findings"

    else
        fail "Login failed. Response: ${LOGIN:0:200}"
        warn "Fix: docker compose exec backend python scripts/seed.py"
        warn "Then: docker compose exec backend alembic upgrade head"
    fi

    # Unauthenticated → 401 (use -s not -sf to get status even on 4xx)
    UNAUTH=$(curl -s --max-time 5 -o /dev/null -w "%{http_code}" "${BACKEND_URL}/api/v1/workspaces" 2>/dev/null || echo "000")
    [ "$UNAUTH" = "401" ] && pass "Auth guard: unauthenticated → HTTP 401" || warn "Auth guard: expected 401, got $UNAUTH"

    # CORS on error response
    CORS=$(curl -si --max-time 5 "${BACKEND_URL}/api/v1/workspaces" \
        -H "Origin: ${FRONTEND_URL}" 2>/dev/null | grep -i "access-control-allow-origin" | tr -d '\r\n')
    [ -n "$CORS" ] && pass "CORS on 401: $CORS" || fail "CORS missing on error responses"

    # CORS preflight
    CORS_PRE=$(curl -si --max-time 5 -X OPTIONS "${BACKEND_URL}/api/v1/workspaces" \
        -H "Origin: ${FRONTEND_URL}" \
        -H "Access-Control-Request-Method: POST" \
        -H "Access-Control-Request-Headers: authorization,content-type" 2>/dev/null | \
        grep -i "access-control-allow-origin" | tr -d '\r\n')
    [ -n "$CORS_PRE" ] && pass "CORS preflight: $CORS_PRE" || fail "CORS preflight failed"

    # Frontend
    FE=$(curl -s --max-time 10 -o /dev/null -w "%{http_code}" "${FRONTEND_URL}/" 2>/dev/null || echo "000")
    case "$FE" in
        200) pass "Frontend: HTTP 200" ;;
        307|301|302) pass "Frontend: HTTP $FE (redirect to /auth/login — correct behavior)" ;;
        000) warn "Frontend not responding (may still be starting)" ;;
        *) fail "Frontend: HTTP $FE" ;;
    esac

else
    warn "Live tests skipped — backend not reachable at $BACKEND_URL"
    echo "  To run live: BACKEND_URL=http://76.13.30.226:8000 FRONTEND_URL=http://76.13.30.226:3000 bash scripts/verify_full_stack.sh"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Results: ${PASS} passed, ${FAIL} failed, ${WARN} warnings"
[ "$FAIL" -eq 0 ] && echo "✓ FULL-STACK VERIFICATION: PASS" && exit 0 || echo "✗ FULL-STACK VERIFICATION: FAIL" && exit 1
