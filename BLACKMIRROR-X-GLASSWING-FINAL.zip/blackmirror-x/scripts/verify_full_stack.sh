#!/usr/bin/env bash
# verify_full_stack.sh — BLACKMIRROR-X full-stack verification
# Run from project root: bash scripts/verify_full_stack.sh
# Run live:  BACKEND_URL=http://76.13.30.226:8000 bash scripts/verify_full_stack.sh

# Locate project root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$SCRIPT_DIR/../backend/app/main.py" ]; then
    ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
elif [ -f "backend/app/main.py" ]; then
    ROOT="$(pwd)"
else
    echo "Run from project root directory (blackmirror-x/)"
    exit 1
fi
cd "$ROOT"

PASS=0; FAIL=0; WARN=0
pass()  { echo "  ✓ $1"; PASS=$((PASS+1)); }
fail()  { echo "  ✗ FAIL: $1"; FAIL=$((FAIL+1)); }
warn()  { echo "  ⚠ WARN: $1"; WARN=$((WARN+1)); }
info()  { echo "  ℹ $1"; }

BACKEND_URL="${BACKEND_URL:-http://localhost:8000}"
FRONTEND_URL="${FRONTEND_URL:-http://localhost:3000}"
LIVE_TEST=false

echo ""
echo "╔═══════════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Full-Stack Verification     ║"
echo "╚═══════════════════════════════════════════════╝"
echo "  Backend:  $BACKEND_URL"
echo "  Frontend: $FRONTEND_URL"

if curl -sf --max-time 3 "${BACKEND_URL}/health" >/dev/null 2>&1; then
    LIVE_TEST=true
    info "Live backend detected"
else
    info "No live backend — running static checks only"
fi
echo ""

# ── [1] Backend code ───────────────────────────────────────────
echo "[1/8] Backend static verification..."
bash "$ROOT/scripts/verify_backend.sh" 2>/dev/null
[ $? -eq 0 ] && pass "Backend: 6/6 checks pass" || fail "Backend verification failed"

# ── [2] Frontend build ─────────────────────────────────────────
echo ""
echo "[2/8] Frontend build..."
if [ -d "frontend/.next" ]; then
    PAGES=$(find frontend/.next/server/app -name "page.js" 2>/dev/null | wc -l)
    [ "$PAGES" -gt 15 ] && pass "Frontend built — $PAGES pages" || warn "Build may be stale (run verify_frontend.sh)"
else
    warn "frontend/.next not found — run: cd frontend && npm run build"
fi

# ── [3] Nav → page consistency ─────────────────────────────────
echo ""
echo "[3/8] Nav links → page files..."
RESULT=$(python3 - << 'PYEOF' 2>/dev/null
import re, os, sys
try:
    layout = open("frontend/src/app/dashboard/layout.tsx").read()
    hrefs = re.findall(r'href:\s*"(/[^"]*)"', layout)
    missing = [h for h in hrefs
               if not os.path.exists(f"frontend/src/app{h}/page.tsx")
               and not os.path.exists(f"frontend/src/app{h.lstrip('/')}/page.tsx")]
    print(f"LINKS={len(hrefs)},MISSING={len(missing)}")
    if missing: print(f"MISSING: {missing}")
except Exception as e:
    print(f"ERROR: {e}")
PYEOF
)
LINKS=$(echo "$RESULT" | grep -oP 'LINKS=\K[0-9]+' || echo 0)
MISSING=$(echo "$RESULT" | grep -oP 'MISSING=\K[0-9]+' || echo 1)
[ "$MISSING" -eq 0 ] && pass "All $LINKS nav links have pages" || fail "Missing pages: $(echo "$RESULT" | grep MISSING:)"

# ── [4] API route consistency ──────────────────────────────────
echo ""
echo "[4/8] API route consistency..."
python3 - << 'PYEOF' 2>/dev/null
import re, os, sys
routes_dir = "backend/app/api/routes"
backend_paths = set()
prefix_map = {
    "auth":"/api/v1/auth","workspaces":"/api/v1/workspaces","scans":"/api/v1/scans",
    "recon":"/api/v1/recon","vulns":"/api/v1/vulns","reports":"/api/v1/reports",
    "copilot":"/api/v1/copilot","apikeys":"/api/v1/apikeys","intelligence":"/api/v1/intel",
    "enterprise":"/api/v1/enterprise","demo":"/api/v1/demo","orchestrator":"/api/v1/orchestrator",
    "agents":"/api/v1/agents",
}
if not os.path.exists(routes_dir):
    print("SKIP: routes dir not found")
    sys.exit(0)
for f in os.listdir(routes_dir):
    if not f.endswith(".py"): continue
    name = f.replace(".py","")
    prefix = prefix_map.get(name, f"/api/v1/{name}")
    content = open(f"{routes_dir}/{f}").read()
    for m in re.finditer(r'@(?:router|app)\.(get|post|patch|delete|put)\s*\(\s*["\']([^"\']*)["\']', content):
        backend_paths.add(prefix + m.group(2))
critical = [
    "/api/v1/auth/login","/api/v1/auth/me","/api/v1/workspaces",
    "/api/v1/scans","/api/v1/vulns","/api/v1/recon/subdomains",
    "/api/v1/reports","/api/v1/enterprise/scope/{workspace_id}",
    "/api/v1/enterprise/approvals/{request_id}/approve",
    "/api/v1/enterprise/emergency-stop/{workspace_id}",
]
missing = [ep for ep in critical if not any(b.startswith(ep.split("{")[0]) for b in backend_paths)]
if missing:
    print(f"FAIL: {len(missing)} missing: {missing}")
    sys.exit(1)
print(f"PASS: {len(backend_paths)} backend routes, all {len(critical)} critical endpoints present")
PYEOF
[ $? -eq 0 ] && pass "API routes consistent" || fail "API route mismatch"

# ── [5] requirements.txt ───────────────────────────────────────
echo ""
echo "[5/8] requirements.txt..."
python3 - << 'PYEOF' 2>/dev/null
import sys
if not __import__('os').path.exists("backend/requirements.txt"):
    print("SKIP"); sys.exit(0)
reqs = open("backend/requirements.txt").read().lower()
missing = [p for p in ["fastapi","uvicorn","sqlalchemy","asyncpg","alembic","pydantic",
           "python-jose","passlib","redis","celery","anthropic","structlog","httpx"] if p not in reqs]
if missing: print(f"FAIL: {missing}"); sys.exit(1)
print("PASS")
PYEOF
[ $? -eq 0 ] && pass "requirements.txt has all critical packages" || fail "requirements.txt incomplete"

# ── [6] .env.example ──────────────────────────────────────────
echo ""
echo "[6/8] .env.example..."
python3 - << 'PYEOF' 2>/dev/null
import sys
env = open(".env.example").read() if __import__('os').path.exists(".env.example") else ""
missing = [v for v in ["ANTHROPIC_API_KEY","SECRET_KEY","JWT_SECRET_KEY","POSTGRES_PASSWORD",
           "DATABASE_URL","REDIS_URL","CORS_ORIGINS","NEXT_PUBLIC_API_URL"] if v not in env]
if missing: print(f"FAIL: {missing}"); sys.exit(1)
print("PASS")
PYEOF
[ $? -eq 0 ] && pass ".env.example documents all required vars" || fail ".env.example missing vars"

# ── [7] Migration chain ────────────────────────────────────────
echo ""
echo "[7/8] Migration files..."
MIGS=$(ls backend/alembic/versions/*.py 2>/dev/null | wc -l)
[ "$MIGS" -ge 4 ] && pass "$MIGS migration files (001→004 chain)" || fail "Expected 4+ migrations, found $MIGS"

# ── [8] Live stack tests ───────────────────────────────────────
echo ""
echo "[8/8] Live stack tests..."
if [ "$LIVE_TEST" = "true" ]; then
    # Health
    HEALTH=$(curl -sf --max-time 5 "${BACKEND_URL}/health" 2>/dev/null)
    echo "$HEALTH" | grep -q "healthy" && pass "Backend /health → {status: healthy}" || fail "Backend /health failed: $HEALTH"

    # Docs
    DOCS=$(curl -sf --max-time 5 "${BACKEND_URL}/api/docs" 2>/dev/null | head -1)
    [ -n "$DOCS" ] && pass "API docs at ${BACKEND_URL}/api/docs" || warn "API docs unreachable"

    # Login
    LOGIN_RESP=$(curl -sf --max-time 10 -X POST "${BACKEND_URL}/api/v1/auth/login" \
        -H "Content-Type: application/json" \
        -d '{"email":"admin@blackmirror.io","password":"BlackMirrorX2025!"}' 2>/dev/null)
    TOKEN=$(echo "$LOGIN_RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('access_token',''))" 2>/dev/null || echo "")

    if [ -n "$TOKEN" ] && [ "$TOKEN" != "null" ]; then
        pass "Login → JWT obtained"

        # Auth/me
        ME=$(curl -sf --max-time 5 "${BACKEND_URL}/api/v1/auth/me" \
            -H "Authorization: Bearer $TOKEN" 2>/dev/null)
        echo "$ME" | grep -q "email" && pass "GET /auth/me → user profile" || fail "GET /auth/me failed"

        # Workspaces
        WS=$(curl -sf --max-time 5 "${BACKEND_URL}/api/v1/workspaces" \
            -H "Authorization: Bearer $TOKEN" 2>/dev/null)
        WS_COUNT=$(echo "$WS" | python3 -c "import sys,json; print(len(json.load(sys.stdin)))" 2>/dev/null || echo 0)
        [ "$WS_COUNT" -gt 0 ] && pass "GET /workspaces → $WS_COUNT workspace(s)" || warn "No workspaces (DB may not be seeded)"

        # Create workspace
        NEW_WS=$(curl -sf --max-time 10 -X POST "${BACKEND_URL}/api/v1/workspaces" \
            -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
            -d '{"name":"Verify Test WS","description":"Auto-created by verify_full_stack.sh"}' 2>/dev/null)
        WS_ID=$(echo "$NEW_WS" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null || echo "")
        [ -n "$WS_ID" ] && pass "POST /workspaces → created ($WS_ID)" || fail "Workspace creation failed: $NEW_WS"

        if [ -n "$WS_ID" ]; then
            # Create scan
            SCAN=$(curl -sf --max-time 10 -X POST "${BACKEND_URL}/api/v1/scans" \
                -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
                -d "{\"workspace_id\":\"$WS_ID\",\"name\":\"Verify Scan\",\"scan_type\":\"recon\",\"target\":\"https://verify-test.blackmirror.io\"}" 2>/dev/null)
            SCAN_ID=$(echo "$SCAN" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null || echo "")
            [ -n "$SCAN_ID" ] && pass "POST /scans → created ($SCAN_ID)" || fail "Scan creation failed: $SCAN"

            # Enterprise: scope check
            SCOPE=$(curl -sf --max-time 5 "${BACKEND_URL}/api/v1/enterprise/scope/${WS_ID}" \
                -H "Authorization: Bearer $TOKEN" 2>/dev/null)
            echo "$SCOPE" | grep -q "workspace_id" && pass "GET /enterprise/scope → OK" || fail "Enterprise scope route failed"

            # Enterprise: plugins
            PLUGINS=$(curl -sf --max-time 5 "${BACKEND_URL}/api/v1/enterprise/plugins" \
                -H "Authorization: Bearer $TOKEN" 2>/dev/null)
            echo "$PLUGINS" | grep -q "plugins" && pass "GET /enterprise/plugins → OK" || fail "Enterprise plugins route failed"

            # Emergency stop
            STOP=$(curl -sf --max-time 5 -X POST "${BACKEND_URL}/api/v1/enterprise/emergency-stop/${WS_ID}" \
                -H "Authorization: Bearer $TOKEN" 2>/dev/null)
            echo "$STOP" | grep -q "true" && pass "POST /enterprise/emergency-stop → OK" || warn "Emergency stop response: $STOP"

            # Resume
            curl -sf --max-time 5 -X POST "${BACKEND_URL}/api/v1/enterprise/emergency-stop/${WS_ID}/resume" \
                -H "Authorization: Bearer $TOKEN" >/dev/null 2>&1
        fi

        # Unauthenticated check
        UNAUTH=$(curl -sf --max-time 5 -o /dev/null -w "%{http_code}" "${BACKEND_URL}/api/v1/workspaces" 2>/dev/null)
        [ "$UNAUTH" = "401" ] && pass "Unauthenticated request → 401" || warn "Expected 401, got $UNAUTH"

        # CORS preflight
        CORS=$(curl -sf --max-time 5 -X OPTIONS "${BACKEND_URL}/api/v1/workspaces" \
            -H "Origin: ${FRONTEND_URL}" \
            -H "Access-Control-Request-Method: POST" \
            -H "Access-Control-Request-Headers: authorization,content-type" \
            -i 2>/dev/null | grep -i "access-control-allow-origin" | head -1)
        [ -n "$CORS" ] && pass "CORS preflight → $CORS" || warn "CORS preflight missing ACAO header"

    else
        warn "Login failed — run: docker compose exec backend python scripts/seed.py"
        warn "Login response: $LOGIN_RESP"
        warn "Then re-run: docker compose exec backend alembic upgrade head"
    fi

    # Frontend
    FE=$(curl -sf --max-time 10 -o /dev/null -w "%{http_code}" "${FRONTEND_URL}/" 2>/dev/null)
    [ "$FE" = "200" ] && pass "Frontend → HTTP $FE" || warn "Frontend returned HTTP $FE (may still be starting)"

else
    info "Skipping live tests — BACKEND_URL not reachable"
    info "To run live: BACKEND_URL=http://76.13.30.226:8000 FRONTEND_URL=http://76.13.30.226:3000 bash scripts/verify_full_stack.sh"
    pass "Static verification complete"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Results: ${PASS} passed, ${FAIL} failed, ${WARN} warnings"
[ "$FAIL" -eq 0 ] && echo "✓ FULL-STACK VERIFICATION: PASS" && exit 0 || echo "✗ FULL-STACK VERIFICATION: FAIL" && exit 1
