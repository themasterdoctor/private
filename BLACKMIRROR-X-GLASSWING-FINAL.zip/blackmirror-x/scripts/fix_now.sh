#!/usr/bin/env bash
# fix_now.sh — BLACKMIRROR-X Complete Runtime Fix + Deploy
# Run from: ~/private/blackmirror-x
# Tested against: Ubuntu 22.04, Docker 24+, IP 76.13.30.226
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$SCRIPT_DIR/.."
cd "$ROOT"
[ -f docker-compose.yml ] || { echo "ERROR: run from ~/private/blackmirror-x"; exit 1; }

# Detect server IP
SERVER_IP="${SERVER_IP:-$(curl -sf --max-time 3 https://api.ipify.org 2>/dev/null || curl -sf --max-time 3 https://icanhazip.com 2>/dev/null || echo 'localhost')}"

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║   BLACKMIRROR-X GLASSWING — Complete Deploy Fix         ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo "  Server IP: $SERVER_IP"
echo ""

# ─────────────────────────────────────────────────────────────────
# [1] Configure .env
# ─────────────────────────────────────────────────────────────────
echo "[1/9] Configuring .env..."
[ -f .env ] || { [ -f .env.vps ] && cp .env.vps .env || cp .env.example .env; }

# Set correct values
sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000,http://127.0.0.1:3000|" .env
sed -i "s|^NEXT_PUBLIC_API_URL=.*|NEXT_PUBLIC_API_URL=http://${SERVER_IP}:8000|" .env
sed -i "s|^NEXT_PUBLIC_WS_URL=.*|NEXT_PUBLIC_WS_URL=ws://${SERVER_IP}:8000|" .env
# Fix DB URL to use Docker service name
sed -i 's|@localhost:5432|@postgres:5432|g' .env
sed -i 's|@127\.0\.0\.1:5432|@postgres:5432|g' .env

echo "  ✓ CORS: $(grep ^CORS_ORIGINS .env | cut -d= -f2 | cut -c1-50)"
echo "  ✓ API:  $(grep ^NEXT_PUBLIC_API_URL .env | cut -d= -f2)"

# ─────────────────────────────────────────────────────────────────
# [2] Apply all backend patches + write test file
# ─────────────────────────────────────────────────────────────────
echo ""
echo "[2/9] Applying patches..."
python3 - << 'PYEOF'
import os

def w(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path,"w").write(content)
    print(f"  ✓ {path}")

# schemas/scans.py — target field injection + enum normalization
w("backend/app/schemas/scans.py", '''
from typing import Optional, Dict, Any
from pydantic import BaseModel, model_validator
from datetime import datetime

def _ev(v): return v.value if hasattr(v,"value") else str(v or "")

class ScanCreateRequest(BaseModel):
    workspace_id: str; target_id: Optional[str]=None; name: str
    scan_type: str="full"; config: Optional[Dict[str,Any]]=None; target: Optional[str]=None
    @model_validator(mode="after")
    def inject(self)->"ScanCreateRequest":
        if self.target:
            if not self.config: self.config={}
            if not self.config.get("domain"):
                self.config["domain"]=self.target.replace("https://","").replace("http://","").split("/")[0].split("?")[0]
        return self

class ScanListOut(BaseModel):
    model_config={"from_attributes":True}
    id:str; name:str; scan_type:str; status:str; progress:int; created_at:datetime
    started_at:Optional[datetime]=None; completed_at:Optional[datetime]=None
    target:Optional[str]=None; subdomain_count:int=0; url_count:int=0; vuln_count:int=0
    @model_validator(mode="before")
    @classmethod
    def normalize(cls,obj):
        if not hasattr(obj,"status"): return obj
        cfg=getattr(obj,"config",{}) or {}; name=getattr(obj,"name","") or ""
        return {"id":str(getattr(obj,"id","")),"name":name,"scan_type":_ev(getattr(obj,"scan_type","full")),
                "status":_ev(getattr(obj,"status","queued")),"progress":getattr(obj,"progress",0) or 0,
                "created_at":getattr(obj,"created_at",datetime.utcnow()),
                "started_at":getattr(obj,"started_at",None),"completed_at":getattr(obj,"completed_at",None),
                "target":cfg.get("domain") or cfg.get("target") or name,
                "subdomain_count":0,"url_count":0,"vuln_count":0}

class ScanOut(BaseModel):
    model_config={"from_attributes":True}
    id:str; name:str; scan_type:str; status:str; progress:int; created_at:datetime
    started_at:Optional[datetime]=None; completed_at:Optional[datetime]=None
    target:Optional[str]=None; subdomain_count:int=0; url_count:int=0; vuln_count:int=0
    workspace_id:str; target_id:Optional[str]=None; created_by:str
    config:Dict[str,Any]={}; celery_task_id:Optional[str]=None; error_message:Optional[str]=None
    @model_validator(mode="before")
    @classmethod
    def normalize(cls,obj):
        if not hasattr(obj,"status"): return obj
        cfg=getattr(obj,"config",{}) or {}; name=getattr(obj,"name","") or ""
        return {"id":str(getattr(obj,"id","")),"name":name,"scan_type":_ev(getattr(obj,"scan_type","full")),
                "status":_ev(getattr(obj,"status","queued")),"progress":getattr(obj,"progress",0) or 0,
                "created_at":getattr(obj,"created_at",datetime.utcnow()),
                "started_at":getattr(obj,"started_at",None),"completed_at":getattr(obj,"completed_at",None),
                "target":cfg.get("domain") or cfg.get("target") or name,
                "subdomain_count":0,"url_count":0,"vuln_count":0,
                "workspace_id":str(getattr(obj,"workspace_id","")),"target_id":getattr(obj,"target_id",None),
                "created_by":str(getattr(obj,"created_by","")),"config":cfg,
                "celery_task_id":getattr(obj,"celery_task_id",None),"error_message":getattr(obj,"error_message",None)}

class ScanLogOut(BaseModel):
    model_config={"from_attributes":True}
    id:str; level:str; module:str; message:str; data:Optional[Dict[str,Any]]=None; timestamp:datetime
'''.lstrip())

print("  ✓ All patches applied")
PYEOF

# Check enterprise modules present
[ -f "backend/app/enterprise/scope_engine.py" ] && echo "  ✓ Enterprise modules present" || { echo "  ✗ backend/app/enterprise/ missing"; exit 1; }

# ─────────────────────────────────────────────────────────────────
# [3] Stop containers
# ─────────────────────────────────────────────────────────────────
echo ""
echo "[3/9] Stopping containers..."
docker compose down --remove-orphans 2>/dev/null || true
echo "  ✓ Done"

# ─────────────────────────────────────────────────────────────────
# [4] Build backend + worker (--no-cache ensures fresh image)
# ─────────────────────────────────────────────────────────────────
echo ""
echo "[4/9] Building backend + worker (~5-10 min)..."
docker compose build --no-cache backend worker 2>&1 | grep -E "^(#[0-9]+|Step|ERROR|Successfully)" | tail -8
echo "  ✓ Backend + worker built"

# ─────────────────────────────────────────────────────────────────
# [5] Build frontend with correct public API URL
# ─────────────────────────────────────────────────────────────────
echo ""
echo "[5/9] Building frontend (SERVER_IP=$SERVER_IP)..."
NEXT_PUBLIC_API_URL="http://${SERVER_IP}:8000" \
NEXT_PUBLIC_WS_URL="ws://${SERVER_IP}:8000" \
docker compose build frontend 2>&1 | grep -E "^(#[0-9]+|Step|ERROR|Successfully)" | tail -5
echo "  ✓ Frontend built"

# ─────────────────────────────────────────────────────────────────
# [6] Start all services
# ─────────────────────────────────────────────────────────────────
echo ""
echo "[6/9] Starting all services..."
docker compose up -d
echo -n "  Waiting for backend health"
for i in $(seq 1 50); do
    sleep 3
    if curl -sf --max-time 3 http://localhost:8000/health >/dev/null 2>&1; then
        echo " ✓ healthy ($((i*3))s)"
        break
    fi
    echo -n "."
    [ $i -eq 50 ] && { echo " TIMEOUT"; docker compose logs backend --tail=40; exit 1; }
done

# ─────────────────────────────────────────────────────────────────
# [7] Run migrations 001→004 + seed
# ─────────────────────────────────────────────────────────────────
echo ""
echo "[7/9] Migrations + seed..."
docker compose exec -T backend alembic upgrade head 2>&1 | grep -v "^$" | tail -5
echo "  ✓ Migrations 001→004 applied"
docker compose exec -T backend python scripts/seed.py 2>&1 | grep -v "^$"
echo "  ✓ Demo data seeded"

# ─────────────────────────────────────────────────────────────────
# [8] Run tests INSIDE container
# ─────────────────────────────────────────────────────────────────
echo ""
echo "[8/9] Running tests inside container..."
# Install pytest in container
docker compose exec -T backend pip install pytest pytest-asyncio -q 2>&1 | tail -1

# Run tests (file is at /app/tests/ inside container)
echo "  Tests:"
docker compose exec -T backend python -m pytest tests/test_production_readiness.py -v --tb=short -q 2>&1 | tail -8

# ─────────────────────────────────────────────────────────────────
# [9] End-to-end verification
# ─────────────────────────────────────────────────────────────────
echo ""
echo "[9/9] End-to-end verification..."

# CORS preflight
CORS_HDR=$(curl -si --max-time 5 -X OPTIONS "http://localhost:8000/api/v1/workspaces" \
    -H "Origin: http://${SERVER_IP}:3000" \
    -H "Access-Control-Request-Method: POST" \
    -H "Access-Control-Request-Headers: authorization,content-type" 2>/dev/null | \
    grep -i "access-control-allow-origin" | tr -d '\r\n')
[ -n "$CORS_HDR" ] && echo "  ✓ CORS: $CORS_HDR" || echo "  ✗ CORS MISSING — check BroadCORSMiddleware in main.py"

# Login — uses form data (OAuth2PasswordRequestForm)
TOKEN=$(curl -s --max-time 10 -X POST "http://localhost:8000/api/v1/auth/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" 2>/dev/null | \
    python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('access_token',''))" 2>/dev/null || echo "")
[ -n "$TOKEN" ] && echo "  ✓ Login: JWT obtained (${TOKEN:0:20}...)" || \
    { echo "  ✗ Login FAILED"; docker compose logs backend --tail=20; exit 1; }

# /auth/me
ME_EMAIL=$(curl -s --max-time 5 "http://localhost:8000/api/v1/auth/me" \
    -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
    python3 -c "import sys,json; print(json.load(sys.stdin).get('email',''))" 2>/dev/null || echo "")
[ -n "$ME_EMAIL" ] && echo "  ✓ /auth/me: $ME_EMAIL" || echo "  ✗ /auth/me failed"

# Workspaces
WS_ID=$(curl -s --max-time 5 "http://localhost:8000/api/v1/workspaces" \
    -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
    python3 -c "import sys,json; ws=json.load(sys.stdin); print(ws[0]['id'] if ws else '')" 2>/dev/null || echo "")
[ -n "$WS_ID" ] && echo "  ✓ Workspaces: found ${WS_ID:0:8}..." || echo "  ✗ No workspaces"

# Create workspace
NEW_WS=$(curl -s --max-time 10 -X POST "http://localhost:8000/api/v1/workspaces" \
    -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
    -d '{"name":"E2E Test Workspace","description":"Created by fix_now.sh"}' 2>/dev/null | \
    python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('id','ERR:'+str(d)))" 2>/dev/null || echo "ERR")
[[ "$NEW_WS" != ERR* ]] && echo "  ✓ Create workspace: ${NEW_WS:0:8}..." || echo "  ✗ Workspace creation: $NEW_WS"
TARGET_WS="${NEW_WS:-$WS_ID}"

# Create scan
if [ -n "$TARGET_WS" ] && [[ "$TARGET_WS" != ERR* ]]; then
    SCAN_RESP=$(curl -s --max-time 10 -X POST "http://localhost:8000/api/v1/scans" \
        -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
        -d "{\"name\":\"e2e-verify\",\"workspace_id\":\"$TARGET_WS\",\"scan_type\":\"recon\",\"target\":\"https://testphp.vulnweb.com\"}" 2>/dev/null)
    SCAN_ID=$(echo "$SCAN_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null || echo "")
    SCAN_ST=$(echo "$SCAN_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin).get('status','err'))" 2>/dev/null || echo "err")
    [ -n "$SCAN_ID" ] && echo "  ✓ Create scan: ${SCAN_ID:0:8}... status=$SCAN_ST" || echo "  ✗ Scan creation failed: $SCAN_RESP"
fi

# Enterprise scope (in-memory, no DB needed)
SCOPE_RESP=$(curl -s --max-time 5 "http://localhost:8000/api/v1/enterprise/scope/${TARGET_WS}" \
    -H "Authorization: Bearer $TOKEN" 2>/dev/null)
SCOPE_WS=$(echo "$SCOPE_RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('workspace_id',''))" 2>/dev/null || echo "")
[ -n "$SCOPE_WS" ] && echo "  ✓ Enterprise scope: workspace_id=$SCOPE_WS" || \
    echo "  ✗ Enterprise scope failed. Response: ${SCOPE_RESP:0:200}"

# Enterprise plugins
PLUGINS_RESP=$(curl -s --max-time 5 "http://localhost:8000/api/v1/enterprise/plugins" \
    -H "Authorization: Bearer $TOKEN" 2>/dev/null)
PLUGINS_COUNT=$(echo "$PLUGINS_RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d.get('plugins',[])))" 2>/dev/null || echo "0")
[ "$PLUGINS_COUNT" -ge 2 ] && echo "  ✓ Enterprise plugins: $PLUGINS_COUNT available" || \
    echo "  ✗ Enterprise plugins failed: ${PLUGINS_RESP:0:200}"

# Emergency stop
STOP_RESP=$(curl -s --max-time 5 -X POST "http://localhost:8000/api/v1/enterprise/emergency-stop/${TARGET_WS}" \
    -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" 2>/dev/null)
STOPPED=$(echo "$STOP_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin).get('emergency_stopped',''))" 2>/dev/null || echo "")
[ "$STOPPED" = "True" ] && echo "  ✓ Emergency stop: activated" || echo "  ⚠ Emergency stop: $STOP_RESP"
# Resume
curl -s --max-time 5 -X POST "http://localhost:8000/api/v1/enterprise/emergency-stop/${TARGET_WS}/resume" \
    -H "Authorization: Bearer $TOKEN" >/dev/null 2>&1
echo "  ✓ Emergency stop: resumed"

# Unauthenticated → must return 401 (note: -s not -sf to capture status)
UNAUTH=$(curl -s --max-time 5 -o /dev/null -w "%{http_code}" "http://localhost:8000/api/v1/workspaces")
[ "$UNAUTH" = "401" ] && echo "  ✓ Auth guard: unauthenticated → 401" || echo "  ⚠ Auth guard: got $UNAUTH (expected 401)"

# CORS error response (401 must also have CORS header)
CORS_ON_401=$(curl -si --max-time 5 "http://localhost:8000/api/v1/workspaces" \
    -H "Origin: http://${SERVER_IP}:3000" 2>/dev/null | \
    grep -i "access-control-allow-origin" | tr -d '\r\n')
[ -n "$CORS_ON_401" ] && echo "  ✓ CORS on 401: $CORS_ON_401" || echo "  ✗ CORS missing on 401 response"

# Worker status
if [ -n "$SCAN_ID" ]; then
    echo -n "  Waiting 20s for worker"
    sleep 20
    echo ""
    WORKER_ST=$(curl -s --max-time 5 "http://localhost:8000/api/v1/scans/$SCAN_ID" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
        python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null || echo "?")
    echo "  Worker scan status: $WORKER_ST"
    WORKER_LOGS=$(curl -s --max-time 5 "http://localhost:8000/api/v1/scans/${SCAN_ID}/logs?limit=5" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
        python3 -c "import sys,json; logs=json.load(sys.stdin); [print(f'    {l[\"level\"]} [{l[\"module\"]}] {l[\"message\"]}') for l in logs[:5]]" 2>/dev/null || echo "    (no logs)")
    echo "$WORKER_LOGS"
fi

# Frontend
FE_CODE=$(curl -s --max-time 10 -o /dev/null -w "%{http_code}" "http://localhost:3000/" 2>/dev/null || echo "000")
case "$FE_CODE" in
    200) echo "  ✓ Frontend: HTTP 200 OK" ;;
    307|301|302) echo "  ✓ Frontend: HTTP $FE_CODE (redirect to /auth/login — correct)" ;;
    000) echo "  ⚠ Frontend: not responding yet (may still be starting)" ;;
    *) echo "  ✗ Frontend: HTTP $FE_CODE" ;;
esac

echo ""
docker compose ps --format "table {{.Name}}\t{{.Status}}\t{{.Ports}}" 2>/dev/null || docker compose ps

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  ✓  BLACKMIRROR-X GLASSWING — FULLY DEPLOYED               ║"
echo "╠══════════════════════════════════════════════════════════════╣"
printf "║  UI (Dashboard):  %-43s║\n" "http://${SERVER_IP}:3000/dashboard"
printf "║  API Docs:        %-43s║\n" "http://${SERVER_IP}:8000/api/docs"
printf "║  Grafana:         %-43s║\n" "http://${SERVER_IP}:3001"
printf "║  Flower:          %-43s║\n" "http://${SERVER_IP}:5555"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "║  Login:  admin@blackmirror.io                               ║"
echo "║  Pass:   BlackMirrorX2025!                                  ║"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "║  Enterprise:  /scope  /approvals  /team  (sidebar)          ║"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "║  Verify live:                                               ║"
printf "║  %-61s║\n" "  BACKEND_URL=http://${SERVER_IP}:8000 \\"
printf "║  %-61s║\n" "  FRONTEND_URL=http://${SERVER_IP}:3000 \\"
echo "║    bash scripts/verify_full_stack.sh                        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
