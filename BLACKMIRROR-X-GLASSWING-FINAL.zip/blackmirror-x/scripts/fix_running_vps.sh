#!/usr/bin/env bash
# fix_running_vps.sh — BLACKMIRROR-X Complete Live Hot-Fix
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f docker-compose.yml ] || { echo "ERROR: run from ~/private/blackmirror-x"; exit 1; }

SERVER_IP="${SERVER_IP:-$(curl -sf --max-time 3 https://api.ipify.org 2>/dev/null || echo '76.13.30.226')}"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Complete Live Hot-Fix              ║"
echo "╚══════════════════════════════════════════════════════╝"
echo "  Server IP: $SERVER_IP"

# ── STEP 0: .env ──────────────────────────────────────────────────────────────
echo ""
echo "[0/7] Ensuring .env exists..."
if [ ! -f .env ]; then
    [ -f .env.vps ] || { echo "  ✗ No .env or .env.vps found"; exit 1; }
    cp .env.vps .env
fi
sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000,http://127.0.0.1:3000|" .env
sed -i 's|@localhost:5432|@postgres:5432|g' .env
sed -i 's|@127\.0\.0\.1:5432|@postgres:5432|g' .env
echo "  ✓ .env OK"

# ── STEP 1: Stop crash loop ───────────────────────────────────────────────────
echo ""
echo "[1/7] Stopping backend + worker..."
docker compose stop backend worker 2>/dev/null || true
echo "  ✓ Stopped"

# ── STEP 2: Fix DB schema via psql directly in postgres container ─────────────
echo ""
echo "[2/7] Fixing database schema..."

POSTGRES_CONTAINER=$(docker compose ps -q postgres 2>/dev/null | head -1)
[ -z "$POSTGRES_CONTAINER" ] && { echo "  ✗ Postgres not running!"; docker compose up -d postgres; sleep 8; POSTGRES_CONTAINER=$(docker compose ps -q postgres 2>/dev/null | head -1); }
echo "  ✓ Postgres: ${POSTGRES_CONTAINER:0:12}"

DB_USER=$(grep ^POSTGRES_USER .env 2>/dev/null | cut -d= -f2 | tr -d '"' || echo "bmx")
DB_PASS=$(grep ^POSTGRES_PASSWORD .env 2>/dev/null | cut -d= -f2 | tr -d '"' || echo "bmxsecret2025")
DB_NAME=$(grep ^POSTGRES_DB .env 2>/dev/null | cut -d= -f2 | tr -d '"' || echo "blackmirror")

# Write SQL to a temp file and copy into postgres container (avoids heredoc issues)
cat > /tmp/bmx_fix.sql << 'SQLEOF'
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS cvss_vector VARCHAR(100);
ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS confidence_score FLOAT;
ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS cvss_score FLOAT;
ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS cwe_id VARCHAR(50);
ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS cve_id VARCHAR(50);
ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS court_confidence FLOAT;
ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS needs_manual_review BOOLEAN DEFAULT false;
CREATE TABLE IF NOT EXISTS workspace_scope (
    id UUID DEFAULT uuid_generate_v4() NOT NULL,
    workspace_id UUID NOT NULL UNIQUE,
    include_rules JSON DEFAULT '[]',
    exclude_rules JSON DEFAULT '[]',
    authorization_confirmed BOOLEAN DEFAULT false,
    authorization_token TEXT,
    program_profile JSON,
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (id),
    FOREIGN KEY(workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS monitoring_alerts (
    id UUID DEFAULT uuid_generate_v4() NOT NULL,
    workspace_id UUID NOT NULL,
    target VARCHAR(255) NOT NULL,
    alert_type VARCHAR(100) NOT NULL,
    severity VARCHAR(50) DEFAULT 'medium',
    title VARCHAR(500) NOT NULL,
    description TEXT,
    old_value TEXT,
    new_value TEXT,
    acknowledged BOOLEAN DEFAULT false,
    acknowledged_by UUID,
    created_at TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (id),
    FOREIGN KEY(workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS approval_requests (
    id UUID DEFAULT uuid_generate_v4() NOT NULL,
    workspace_id UUID NOT NULL,
    action_type VARCHAR(100) NOT NULL,
    action_payload JSON DEFAULT '{}',
    risk_tier VARCHAR(50) DEFAULT 'medium',
    requested_by UUID,
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (id)
);
CREATE TABLE IF NOT EXISTS alembic_version (
    version_num VARCHAR(32) NOT NULL,
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);
DELETE FROM alembic_version;
INSERT INTO alembic_version (version_num) VALUES ('005_add_cvss_vector');
SELECT 'cvss_vector: ' || count(*) FROM information_schema.columns
WHERE table_name='vulnerabilities' AND column_name='cvss_vector';
SELECT 'cvss_vector: ' || count(*) FROM information_schema.columns WHERE table_name='vulnerabilities' AND column_name='cvss_vector';
SELECT 'alembic: ' || version_num FROM alembic_version;
SQLEOF
docker cp /tmp/bmx_fix.sql "${POSTGRES_CONTAINER}:/tmp/bmx_fix.sql"
docker exec -e PGPASSWORD="$DB_PASS" "$POSTGRES_CONTAINER" \
    psql -U "$DB_USER" -d "$DB_NAME" -v ON_ERROR_STOP=0 -f /tmp/bmx_fix.sql 2>&1 | grep -E "ALTER|CREATE|INSERT|DELETE|cvss|alembic|ERROR" | head -20
echo "  ✓ Database schema fixed"

# ── STEP 3: Copy ALL files to both containers ─────────────────────────────────
echo ""
echo "[3/7] Copying updated files..."

# Start containers so we can copy into them
docker compose start backend worker 2>/dev/null || docker compose up -d backend worker 2>/dev/null || true
sleep 5

BACKEND_CONTAINER=$(docker compose ps -q backend 2>/dev/null | head -1)
WORKER_CONTAINER=$(docker compose ps -q worker 2>/dev/null | head -1)
[ -z "$BACKEND_CONTAINER" ] && { echo "  ✗ Backend container not found"; exit 1; }
echo "  ✓ Backend: ${BACKEND_CONTAINER:0:12}"
[ -n "$WORKER_CONTAINER" ] && echo "  ✓ Worker:  ${WORKER_CONTAINER:0:12}"

cpb() {
    docker cp "$1" "${BACKEND_CONTAINER}:$2" 2>/dev/null || true
    [ -n "$WORKER_CONTAINER" ] && docker cp "$1" "${WORKER_CONTAINER}:$2" 2>/dev/null || true
}

# Migration files (ALL 5)
for MIG in \
    "backend/alembic/versions/54aca6331712_initial_full_schema.py" \
    "backend/alembic/versions/173cd281e294_intelligence_tables.py" \
    "backend/alembic/versions/003_avros_completion.py" \
    "backend/alembic/versions/004_enterprise_features.py" \
    "backend/alembic/versions/005_add_cvss_vector.py"
do
    BASENAME=$(basename "$MIG")
    docker cp "$MIG" "${BACKEND_CONTAINER}:/app/alembic/versions/${BASENAME}" 2>/dev/null && \
        echo "  ✓ $BASENAME" || true
done

# Core app files → BOTH containers
cpb backend/app/main.py                         /app/app/main.py
cpb backend/app/workers/tasks.py                /app/app/workers/tasks.py
cpb backend/app/workers/celery_app.py           /app/app/workers/celery_app.py
cpb backend/app/models/models.py                /app/app/models/models.py
cpb backend/app/schemas/scans.py                /app/app/schemas/scans.py
cpb backend/app/api/deps/auth.py                /app/app/api/deps/auth.py
cpb backend/app/api/routes/scans.py             /app/app/api/routes/scans.py
cpb backend/app/api/routes/auth.py              /app/app/api/routes/auth.py
cpb backend/app/api/routes/health.py            /app/app/api/routes/health.py
cpb backend/app/api/routes/copilot.py           /app/app/api/routes/copilot.py
cpb backend/app/api/routes/enterprise.py        /app/app/api/routes/enterprise.py
cpb backend/app/api/routes/reports.py           /app/app/api/routes/reports.py
echo "  ✓ Core + routes"

docker cp backend/app/enterprise/. "${BACKEND_CONTAINER}:/app/app/enterprise/" 2>/dev/null || true
[ -n "$WORKER_CONTAINER" ] && docker cp backend/app/enterprise/. "${WORKER_CONTAINER}:/app/app/enterprise/" 2>/dev/null || true
echo "  ✓ Enterprise modules"

cpb backend/app/agents/recon/agent.py           /app/app/agents/recon/agent.py
cpb backend/app/agents/vuln_research/agent.py   /app/app/agents/vuln_research/agent.py
cpb backend/app/agents/rag/agent.py             /app/app/agents/rag/agent.py
cpb backend/app/agents/copilot/agent.py         /app/app/agents/copilot/agent.py
echo "  ✓ Agents (recon with passive HTTP, vuln research, rag, copilot)"

cpb backend/app/intelligence/hypothesis/engine.py      /app/app/intelligence/hypothesis/engine.py
cpb backend/app/intelligence/court/validation_court.py  /app/app/intelligence/court/validation_court.py
cpb backend/app/core/tool_manager.py                   /app/app/core/tool_manager.py
echo "  ✓ Intelligence + tool manager"

# New operator route
docker cp backend/app/api/routes/operator.py "${BACKEND_CONTAINER}:/app/app/api/routes/operator.py" 2>/dev/null || true
echo "  ✓ Operator route"

docker cp backend/scripts/seed.py "${BACKEND_CONTAINER}:/app/scripts/seed.py" 2>/dev/null || true
docker cp backend/scripts/db_fix.py "${BACKEND_CONTAINER}:/app/scripts/db_fix.py" 2>/dev/null || true
echo "  ✓ Scripts"

# ── STEP 4: Restart cleanly ───────────────────────────────────────────────────
echo ""
echo "[4/7] Restarting backend + worker..."
docker compose restart backend worker

echo -n "  Waiting for backend"
for i in $(seq 1 40); do
    sleep 3
    if curl -sf --max-time 3 http://localhost:8000/health >/dev/null 2>&1; then
        echo " ✓ ($((i*3))s)"
        break
    fi
    echo -n "."
    [ $i -eq 40 ] && { echo " TIMEOUT"; docker compose logs backend --tail=30; exit 1; }
done

# Verify worker is running
sleep 5
WORKER_STATUS=$(docker compose ps worker 2>/dev/null | grep -c "Up" || echo 0)
[ "$WORKER_STATUS" -gt 0 ] && echo "  ✓ Worker: Up" || echo "  ⚠ Worker may not be running"

# ── STEP 5: Seed demo data ────────────────────────────────────────────────────
echo ""
echo "[5/7] Seeding demo data..."
docker compose exec -T backend python scripts/seed.py 2>&1 | \
    grep -E "✓|Seed|error|Error" | head -5 | sed 's/^/  /' || echo "  ⚠ Seed done"

# ── STEP 6: Verify everything ─────────────────────────────────────────────────
echo ""
echo "[6/7] Verification..."

HEALTH=$(curl -sf --max-time 5 http://localhost:8000/health 2>/dev/null || echo '{}')
STATUS=$(echo "$HEALTH" | python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null || echo "?")
VERSION=$(echo "$HEALTH" | python3 -c "import sys,json; print(json.load(sys.stdin).get('version','?'))" 2>/dev/null || echo "?")
[ "$STATUS" = "healthy" ] && echo "  ✓ Backend healthy (v$VERSION)" || { echo "  ✗ Backend: $STATUS"; exit 1; }

TOKEN=$(curl -s --max-time 10 -X POST "http://localhost:8000/api/v1/auth/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" 2>/dev/null | \
    python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))" 2>/dev/null || echo "")
[ -n "$TOKEN" ] && echo "  ✓ Login OK" || { echo "  ✗ Login FAILED"; exit 1; }

WS=$(curl -s --max-time 5 "http://localhost:8000/api/v1/workspaces" \
    -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
    python3 -c "import sys,json; ws=json.load(sys.stdin); print(ws[0]['id'] if ws else '')" 2>/dev/null || echo "")
[ -n "$WS" ] && echo "  ✓ Workspace: ${WS:0:8}..." || echo "  ⚠ No workspace"

if [ -n "$WS" ]; then
    VC=$(curl -s --max-time 5 "http://localhost:8000/api/v1/vulns?workspace_id=$WS" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
        python3 -c "import sys,json; d=json.load(sys.stdin); print(str(len(d))+' findings' if isinstance(d,list) else 'error')" 2>/dev/null || echo "?")
    echo "  ✓ Vulnerabilities query: $VC (cvss_vector works)"

    # Launch a REAL test scan
    echo ""
    echo "  Launching test scan against testphp.vulnweb.com..."
    SCAN=$(curl -s --max-time 15 -X POST "http://localhost:8000/api/v1/scans" \
        -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
        -d "{\"name\":\"fix-verify-$(date +%s)\",\"workspace_id\":\"$WS\",\"scan_type\":\"recon\",\"target\":\"https://testphp.vulnweb.com\",\"config\":{\"domain\":\"testphp.vulnweb.com\",\"nuclei\":false}}" 2>/dev/null)
    SCAN_ID=$(echo "$SCAN" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null || echo "")
    [ -n "$SCAN_ID" ] && echo "  ✓ Scan launched: ${SCAN_ID:0:8}..." || echo "  ✗ Scan failed: $SCAN"

    if [ -n "$SCAN_ID" ]; then
        echo -n "  Waiting 45s for scan to start"
        for i in $(seq 1 9); do
            sleep 5
            echo -n "."
            ST=$(curl -s "http://localhost:8000/api/v1/scans/$SCAN_ID" \
                -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
                python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null || echo "?")
            [ "$ST" = "running" ] && { echo " RUNNING ✓"; break; }
            [ "$ST" = "completed" ] && { echo " COMPLETED ✓"; break; }
            [ "$ST" = "failed" ] && { echo " FAILED"; docker compose logs worker --tail=20; break; }
        done
    fi
fi

# ── STEP 7: pytest ────────────────────────────────────────────────────────────
echo ""
echo "[7/7] Running pytest..."
docker compose exec -T backend pip install pytest pytest-asyncio anyio -q --break-system-packages 2>/dev/null || true
docker compose exec -T backend bash -c "cd /app && python -m pytest tests/test_production_readiness.py -q --tb=no 2>&1" | tail -3 | sed 's/^/  /'

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  ✓ BLACKMIRROR-X is LIVE                                     ║"
echo "╠══════════════════════════════════════════════════════════════╣"
printf "║  UI:    %-51s║\n" "http://${SERVER_IP}:3000/dashboard"
printf "║  API:   %-51s║\n" "http://${SERVER_IP}:8000/api/docs"
echo "║  Login: admin@blackmirror.io / BlackMirrorX2025!             ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "  If scan shows QUEUED after 30s → check worker:"
echo "  docker compose logs worker --tail=50"
