#!/usr/bin/env bash
# fix_running_vps.sh — BLACKMIRROR-X Complete Live Hot-Fix
# Patches a running VPS stack without rebuilding Docker images.
# Run from: ~/private/blackmirror-x
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f docker-compose.yml ] || { echo "ERROR: run from ~/private/blackmirror-x"; exit 1; }

SERVER_IP="${SERVER_IP:-$(curl -sf --max-time 3 https://api.ipify.org 2>/dev/null || echo '76.13.30.226')}"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Complete Live Hot-Fix              ║"
echo "╚══════════════════════════════════════════════════════╝"
echo "  Server IP: $SERVER_IP"

# ── STEP 0: .env ──────────────────────────────────────────────────────────────
echo ""
echo "[0/8] Ensuring .env exists..."
if [ ! -f .env ]; then
    [ -f .env.vps ] || { echo "  ✗ ERROR: No .env or .env.vps found"; exit 1; }
    cp .env.vps .env
    echo "  ✓ Created .env from .env.vps"
else
    echo "  ✓ .env exists"
fi
sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000,http://127.0.0.1:3000|" .env
sed -i 's|@localhost:5432|@postgres:5432|g' .env
sed -i 's|@127\.0\.0\.1:5432|@postgres:5432|g' .env
echo "  ✓ CORS: $(grep ^CORS_ORIGINS .env | cut -d= -f2 | cut -c1-55)"

# ── STEP 1: Container status ──────────────────────────────────────────────────
echo ""
echo "[1/8] Container status..."
docker compose ps

# ── STEP 2: Backend health check ─────────────────────────────────────────────
echo ""
echo "[2/8] Backend health..."
for i in 1 2 3 4 5; do
    if curl -sf --max-time 5 http://localhost:8000/health >/dev/null 2>&1; then
        echo "  ✓ Backend is healthy"
        break
    fi
    [ $i -eq 5 ] && { echo "  ✗ Backend not responding"; docker compose logs backend --tail=20; exit 1; }
    echo "  Waiting... ($i/5)"; sleep 5
done

# ── STEP 3: Get container IDs ─────────────────────────────────────────────────
echo ""
echo "[3/8] Getting container IDs..."
BACKEND_CONTAINER=$(docker compose ps -q backend)
WORKER_CONTAINER=$(docker compose ps -q worker)
[ -z "$BACKEND_CONTAINER" ] && { echo "  ✗ Backend container not found"; exit 1; }
echo "  ✓ Backend: ${BACKEND_CONTAINER:0:12}"
[ -n "$WORKER_CONTAINER" ] && echo "  ✓ Worker:  ${WORKER_CONTAINER:0:12}" || echo "  ⚠ Worker container not found"

# ── STEP 4: Copy ALL updated files into containers ───────────────────────────
echo ""
echo "[4/8] Injecting all updated files..."

# Helper: copy to backend (required) and worker (if running)
cp_both() {
    local src="$1" dst="$2"
    docker cp "$src" "${BACKEND_CONTAINER}:${dst}"
    [ -n "$WORKER_CONTAINER" ] && docker cp "$src" "${WORKER_CONTAINER}:${dst}" 2>/dev/null || true
}
cp_dir_both() {
    local src="$1" dst="$2"
    docker cp "$src" "${BACKEND_CONTAINER}:${dst}"
    [ -n "$WORKER_CONTAINER" ] && docker cp "$src" "${WORKER_CONTAINER}:${dst}" 2>/dev/null || true
}

# Core app files
cp_both backend/app/main.py                         /app/app/main.py
cp_both backend/app/workers/tasks.py                /app/app/workers/tasks.py
cp_both backend/app/models/models.py                /app/app/models/models.py
cp_both backend/app/schemas/scans.py                /app/app/schemas/scans.py
cp_both backend/app/api/deps/auth.py                /app/app/api/deps/auth.py
echo "  ✓ Core: main.py, tasks.py, models.py, schemas.py, auth.py"

# API routes
cp_both backend/app/api/routes/scans.py             /app/app/api/routes/scans.py
cp_both backend/app/api/routes/auth.py              /app/app/api/routes/auth.py
cp_both backend/app/api/routes/health.py            /app/app/api/routes/health.py
cp_both backend/app/api/routes/copilot.py           /app/app/api/routes/copilot.py
cp_both backend/app/api/routes/enterprise.py        /app/app/api/routes/enterprise.py
echo "  ✓ Routes: scans, health, copilot, enterprise"

# Enterprise modules (directory)
cp_dir_both backend/app/enterprise/.                /app/app/enterprise/
echo "  ✓ Enterprise modules (7 files)"

# Agents (all run in worker)
cp_both backend/app/agents/recon/agent.py           /app/app/agents/recon/agent.py
cp_both backend/app/agents/vuln_research/agent.py   /app/app/agents/vuln_research/agent.py
cp_both backend/app/agents/rag/agent.py             /app/app/agents/rag/agent.py
echo "  ✓ Agents: recon (11 tools), vuln_research (14 tests), rag"

# Scripts
docker cp backend/scripts/seed.py                   "${BACKEND_CONTAINER}:/app/scripts/seed.py"
echo "  ✓ scripts/seed.py"

# Tests
docker cp backend/tests/test_production_readiness.py "${BACKEND_CONTAINER}:/app/tests/test_production_readiness.py" 2>/dev/null || true

# ── STEP 5: Restart backend + worker ─────────────────────────────────────────
echo ""
echo "[5/8] Restarting backend + worker..."
docker compose restart backend worker

echo -n "  Waiting for backend"
for i in $(seq 1 30); do
    sleep 2
    if curl -sf --max-time 3 http://localhost:8000/health >/dev/null 2>&1; then
        echo " ✓ (${i}x2=${i*2 <&-}$(echo $((i*2)))s)"
        break
    fi
    echo -n "."
    [ $i -eq 30 ] && { echo " TIMEOUT"; docker compose logs backend --tail=30; exit 1; }
done

# ── STEP 6: Run migrations ────────────────────────────────────────────────────
echo ""
echo "[6/8] Running migrations (001→005)..."

# Re-get container ID after restart (ID can change)
BACKEND_CONTAINER=$(docker compose ps -q backend)
[ -z "$BACKEND_CONTAINER" ] && { echo "  ✗ Backend container not found after restart"; exit 1; }

# Copy ALL 5 migration files into the container
# The container image may only have 001-002; we need the full chain for alembic
for MIG in \
    "backend/alembic/versions/54aca6331712_initial_full_schema.py" \
    "backend/alembic/versions/173cd281e294_intelligence_tables.py" \
    "backend/alembic/versions/003_avros_completion.py" \
    "backend/alembic/versions/004_enterprise_features.py" \
    "backend/alembic/versions/005_add_cvss_vector.py"
do
    BASENAME=$(basename "$MIG")
    docker cp "$MIG" "${BACKEND_CONTAINER}:/app/alembic/versions/${BASENAME}"
    echo "  ✓ $BASENAME"
done

# Copy alembic env.py too
docker cp backend/alembic/env.py "${BACKEND_CONTAINER}:/app/alembic/env.py" 2>/dev/null || true

# Verify chain before running
echo "  Verifying alembic revision chain..."
HEADS=$(docker compose exec -T backend alembic heads 2>&1 || true)
if echo "$HEADS" | grep -qi "keyerror\|error\|traceback"; then
    echo "  ⚠ Chain error detected, stamping at 004..."
    docker compose exec -T backend alembic stamp 004_enterprise_features 2>/dev/null || true
fi

# Run the migration
echo "  Running alembic upgrade head..."
docker compose exec -T backend alembic upgrade head 2>&1 | tail -6
echo "  ✓ Migrations complete (001→005, cvss_vector added)"

# ── STEP 7: Seed demo data ────────────────────────────────────────────────────
echo ""
echo "[7/8] Seeding demo data..."
docker compose exec -T backend python scripts/seed.py 2>&1
echo "  ✓ Seed complete"

# ── STEP 8: Verify everything works ──────────────────────────────────────────
echo ""
echo "[8/8] Verification..."

# Health
HEALTH=$(curl -sf --max-time 5 http://localhost:8000/health 2>/dev/null || echo '{}')
STATUS=$(echo "$HEALTH" | python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null || echo "?")
VERSION=$(echo "$HEALTH" | python3 -c "import sys,json; print(json.load(sys.stdin).get('version','?'))" 2>/dev/null || echo "?")
[ "$STATUS" = "healthy" ] && echo "  ✓ Backend healthy (v${VERSION})" || echo "  ✗ Backend: $STATUS"

# Login
TOKEN=$(curl -s --max-time 10 -X POST "http://localhost:8000/api/v1/auth/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" 2>/dev/null | \
    python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))" 2>/dev/null || echo "")
[ -n "$TOKEN" ] && echo "  ✓ Login OK" || { echo "  ✗ Login FAILED"; docker compose logs backend --tail=20; exit 1; }

# Workspace
WS=$(curl -s --max-time 5 "http://localhost:8000/api/v1/workspaces" \
    -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
    python3 -c "import sys,json; ws=json.load(sys.stdin); print(ws[0]['id'] if ws else '')" 2>/dev/null || echo "")
[ -n "$WS" ] && echo "  ✓ Workspace: ${WS:0:8}..." || echo "  ⚠ No workspace"

if [ -n "$WS" ]; then
    # Enterprise scope
    SC=$(curl -s --max-time 5 "http://localhost:8000/api/v1/enterprise/scope/$WS" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
        python3 -c "import sys,json; d=json.load(sys.stdin); print('OK' if 'workspace_id' in d else 'FAIL')" 2>/dev/null || echo "FAIL")
    [ "$SC" = "OK" ] && echo "  ✓ Enterprise scope: OK" || echo "  ✗ Enterprise scope: $SC"

    # Plugins
    PC=$(curl -s --max-time 5 "http://localhost:8000/api/v1/enterprise/plugins" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
        python3 -c "import sys,json; print(len(json.load(sys.stdin).get('plugins',[])))" 2>/dev/null || echo 0)
    [ "$PC" -ge 2 ] && echo "  ✓ Plugins: $PC registered" || echo "  ✗ Plugins: $PC"

    # Vuln count (tests cvss_vector query works)
    VC=$(curl -s --max-time 5 "http://localhost:8000/api/v1/vulns?workspace_id=$WS" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
        python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d) if isinstance(d,list) else d.get('total',0))" 2>/dev/null || echo "?")
    echo "  ✓ Vulnerabilities accessible: $VC (cvss_vector column works)"

    # Launch test scan with explicit domain
    echo ""
    echo "  Launching scan pipeline test..."
    SCAN_ID=$(curl -s --max-time 10 -X POST "http://localhost:8000/api/v1/scans" \
        -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
        -d "{\"name\":\"verify-$(date +%s)\",\"workspace_id\":\"$WS\",\"scan_type\":\"recon\",\"target\":\"https://testphp.vulnweb.com\",\"config\":{\"domain\":\"testphp.vulnweb.com\"}}" 2>/dev/null | \
        python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null || echo "")

    [ -n "$SCAN_ID" ] && echo "  ✓ Scan created: ${SCAN_ID:0:8}..." || echo "  ✗ Scan creation failed"

    if [ -n "$SCAN_ID" ]; then
        echo -n "  Waiting 30s for scan status"
        sleep 30
        ST=$(curl -s --max-time 5 "http://localhost:8000/api/v1/scans/$SCAN_ID" \
            -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
            python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null || echo "?")
        echo ""
        case "$ST" in
            running|completed) echo "  ✓ Scan pipeline WORKING! Status: $ST" ;;
            failed)
                echo "  ✗ Scan FAILED — worker logs:"
                docker compose logs worker --tail=15
                ;;
            queued) echo "  ⚠ Still queued — worker may still be starting (normal)" ;;
            *) echo "  ⚠ Status: $ST" ;;
        esac
    fi
fi

# Run pytest inside container
echo ""
echo "  Running pytest..."
docker compose exec -T backend pip install pytest pytest-asyncio -q 2>/dev/null | tail -1
TRES=$(docker compose exec -T backend python -m pytest tests/test_production_readiness.py -q --tb=line 2>&1)
echo "$TRES" | tail -3
PASSED=$(echo "$TRES" | grep -oP '\d+ passed' | grep -oP '\d+' || echo 0)
FAILED_T=$(echo "$TRES" | grep -oP '\d+ failed' | grep -oP '\d+' || echo 0)
[ "$FAILED_T" -eq 0 ] && [ "$PASSED" -gt 0 ] && echo "  ✓ Tests: ${PASSED} passed" || echo "  ✗ Tests: ${PASSED} passed, ${FAILED_T} failed"

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  ✓ Hot-fix complete                                          ║"
echo "╠══════════════════════════════════════════════════════════════╣"
printf "║  UI:    %-51s║\n" "http://${SERVER_IP}:3000/dashboard"
printf "║  API:   %-51s║\n" "http://${SERVER_IP}:8000/api/docs"
echo "║  Login: admin@blackmirror.io / BlackMirrorX2025!             ║"
echo "╚══════════════════════════════════════════════════════════════╝"
