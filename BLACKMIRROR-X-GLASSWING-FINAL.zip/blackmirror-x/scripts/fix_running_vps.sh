#!/usr/bin/env bash
# fix_running_vps.sh — Fix a RUNNING VPS stack
# Use this when containers are up but enterprise routes are 404
# or migrations haven't run or .env is missing.
# Run from: ~/private/blackmirror-x
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f docker-compose.yml ] || { echo "ERROR: run from ~/private/blackmirror-x"; exit 1; }

SERVER_IP="${SERVER_IP:-$(curl -sf --max-time 3 https://api.ipify.org 2>/dev/null || echo '76.13.30.226')}"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Live Stack Hot-Fix                 ║"
echo "╚══════════════════════════════════════════════════════╝"
echo "  Server IP: $SERVER_IP"

# ── STEP 0: Create .env FIRST (required for all docker compose commands) ──────
echo ""
echo "[0/7] Ensuring .env exists..."
if [ ! -f .env ]; then
    if [ -f .env.vps ]; then
        cp .env.vps .env
        echo "  ✓ Created .env from .env.vps"
    else
        echo "  ✗ ERROR: No .env or .env.vps found"
        echo "  Fix: cp .env.example .env && nano .env"
        exit 1
    fi
else
    echo "  ✓ .env exists"
fi

# Fix CORS + DB URL in .env
sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000,http://127.0.0.1:3000|" .env
sed -i 's|@localhost:5432|@postgres:5432|g' .env
sed -i 's|@127\.0\.0\.1:5432|@postgres:5432|g' .env
echo "  ✓ CORS: $(grep ^CORS_ORIGINS .env | cut -d= -f2 | cut -c1-55)"

# ── STEP 1: Verify containers are running ─────────────────────────────────────
echo ""
echo "[1/7] Container status..."
docker compose ps

# ── STEP 2: Verify backend health ─────────────────────────────────────────────
echo ""
echo "[2/7] Backend health..."
for i in 1 2 3 4 5; do
    if curl -sf --max-time 5 http://localhost:8000/health >/dev/null 2>&1; then
        echo "  ✓ Backend is healthy"
        break
    fi
    [ $i -eq 5 ] && { echo "  ✗ Backend not responding"; docker compose logs backend --tail=20; exit 1; }
    echo "  Waiting... ($i/5)"; sleep 5
done

# ── STEP 3: Inject enterprise files directly into running container ────────────
# This avoids a full rebuild. docker cp copies from host into container.
echo ""
echo "[3/7] Injecting enterprise files into running container..."

BACKEND_CONTAINER=$(docker compose ps -q backend)
if [ -z "$BACKEND_CONTAINER" ]; then
    echo "  ✗ Backend container not found"
    exit 1
fi

# Copy enterprise module directory
docker cp backend/app/enterprise/. "${BACKEND_CONTAINER}:/app/app/enterprise/"
echo "  ✓ app/enterprise/ (7 files)"

# Copy enterprise routes
docker cp backend/app/api/routes/enterprise.py "${BACKEND_CONTAINER}:/app/app/api/routes/enterprise.py"
echo "  ✓ app/api/routes/enterprise.py"

# Copy updated main.py (has enterprise router registered)
docker cp backend/app/main.py "${BACKEND_CONTAINER}:/app/app/main.py"
echo "  ✓ app/main.py"

# Copy test file
mkdir -p backend/tests
docker cp backend/tests/test_production_readiness.py "${BACKEND_CONTAINER}:/app/tests/test_production_readiness.py" 2>/dev/null && \
    echo "  ✓ tests/test_production_readiness.py" || \
    echo "  ⚠ Test file not found on host (non-fatal)"

# CRITICAL: Fix Celery worker scan pipeline (run_async asyncio fix)
docker cp backend/app/workers/tasks.py "${BACKEND_CONTAINER}:/app/app/workers/tasks.py"
echo "  ✓ app/workers/tasks.py (run_async fix)"

# Fix SSE stream auth (accept token via query param for EventSource)
docker cp backend/app/api/deps/auth.py "${BACKEND_CONTAINER}:/app/app/api/deps/auth.py"
echo "  ✓ app/api/deps/auth.py (token query param support)"

# Fix SSE stream signature (token query param)
docker cp backend/app/api/routes/scans.py "${BACKEND_CONTAINER}:/app/app/api/routes/scans.py"
echo "  ✓ app/api/routes/scans.py (stream auth fix)"

# schemas/scans.py — inject_target validator (CRITICAL: domain extraction)
docker cp backend/app/schemas/scans.py "${BACKEND_CONTAINER}:/app/app/schemas/scans.py"
echo "  ✓ app/schemas/scans.py (inject_target → config.domain)"

# models/models.py — confidence_score + cvss_vector columns
docker cp backend/app/models/models.py "${BACKEND_CONTAINER}:/app/app/models/models.py"
echo "  ✓ app/models/models.py (confidence_score, cvss_vector fields)"

# All updated agent files (recon + vuln_research + rag)
docker cp backend/app/agents/recon/agent.py "${BACKEND_CONTAINER}:/app/app/agents/recon/agent.py"
docker cp backend/app/agents/vuln_research/agent.py "${BACKEND_CONTAINER}:/app/app/agents/vuln_research/agent.py"
docker cp backend/app/agents/rag/agent.py "${BACKEND_CONTAINER}:/app/app/agents/rag/agent.py"
echo "  ✓ agents: recon (11 tools), vuln_research (14 tests), rag (pgvector fallback)"

# scripts/seed.py — domain key fix
docker cp backend/scripts/seed.py "${BACKEND_CONTAINER}:/app/scripts/seed.py"
echo "  ✓ scripts/seed.py (config.domain fix)"

# Copy into worker too
WORKER_CONTAINER=$(docker compose ps -q worker)
if [ -n "$WORKER_CONTAINER" ]; then
    docker cp backend/app/enterprise/. "${WORKER_CONTAINER}:/app/app/enterprise/" 2>/dev/null || true
    docker cp backend/app/api/routes/enterprise.py "${WORKER_CONTAINER}:/app/app/api/routes/enterprise.py" 2>/dev/null || true
    docker cp backend/app/main.py "${WORKER_CONTAINER}:/app/app/main.py" 2>/dev/null || true
    docker cp backend/app/workers/tasks.py "${WORKER_CONTAINER}:/app/app/workers/tasks.py" 2>/dev/null || true
    docker cp backend/app/api/deps/auth.py "${WORKER_CONTAINER}:/app/app/api/deps/auth.py" 2>/dev/null || true
    echo "  ✓ Worker container updated (enterprise + scan pipeline + auth fixes)"
fi

# ── STEP 4: Restart backend + worker (picks up new files) ─────────────────────
echo ""
echo "[4/7] Restarting backend + worker..."
docker compose restart backend worker

echo -n "  Waiting for backend health"
for i in $(seq 1 30); do
    sleep 2
    if curl -sf --max-time 3 http://localhost:8000/health >/dev/null 2>&1; then
        echo " ✓ ($((i*2))s)"
        break
    fi
    echo -n "."
    [ $i -eq 30 ] && { echo " TIMEOUT"; docker compose logs backend --tail=30; exit 1; }
done

# ── STEP 5: Run ALL migrations (001→004) ──────────────────────────────────────
echo ""
echo "[5/7] Running migrations (001→004)..."
docker compose exec -T backend alembic upgrade head 2>&1 | grep -v "^$" | tail -8
echo "  ✓ Migrations applied"

# ── STEP 6: Seed demo data ─────────────────────────────────────────────────────
echo ""
echo "[6/7] Seeding demo data..."
docker compose exec -T backend python scripts/seed.py 2>&1 | grep -v "^$"
echo "  ✓ Seed complete"

# ── STEP 7: Verify enterprise routes work ─────────────────────────────────────
echo ""
echo "[7/7] Verifying enterprise routes..."

# Login
TOKEN=$(curl -s --max-time 10 -X POST "http://localhost:8000/api/v1/auth/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" 2>/dev/null | \
    python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))" 2>/dev/null || echo "")
[ -n "$TOKEN" ] && echo "  ✓ Login OK" || { echo "  ✗ Login FAILED"; docker compose logs backend --tail=20; exit 1; }

# Workspace
WS=$(curl -s --max-time 5 "http://localhost:8000/api/v1/workspaces" \
    -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
    python3 -c "import sys,json; ws=json.load(sys.stdin); print(ws[0]['id'] if ws else '')" 2>/dev/null || echo "")
[ -n "$WS" ] && echo "  ✓ Workspace: ${WS:0:8}..." || echo "  ⚠ No workspace found"

# Enterprise scope
if [ -n "$WS" ]; then
    SCOPE=$(curl -s --max-time 5 "http://localhost:8000/api/v1/enterprise/scope/$WS" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null)
    HAS_WS=$(echo "$SCOPE" | python3 -c "import sys,json; d=json.load(sys.stdin); print('YES' if 'workspace_id' in d else 'NO')" 2>/dev/null || echo "NO")
    [ "$HAS_WS" = "YES" ] && echo "  ✓ GET /enterprise/scope: OK" || \
        echo "  ✗ Enterprise scope FAILED: ${SCOPE:0:200}"

    # Enterprise plugins
    PC=$(curl -s --max-time 5 "http://localhost:8000/api/v1/enterprise/plugins" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
        python3 -c "import sys,json; print(len(json.load(sys.stdin).get('plugins',[])))" 2>/dev/null || echo 0)
    [ "$PC" -ge 2 ] && echo "  ✓ Enterprise plugins: $PC" || echo "  ✗ Enterprise plugins: $PC (expected ≥2)"

    # Emergency stop
    ES=$(curl -s --max-time 5 -X POST "http://localhost:8000/api/v1/enterprise/emergency-stop/$WS" \
        -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" 2>/dev/null | \
        python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('emergency_stopped',''))" 2>/dev/null || echo "")
    [ "$ES" = "True" ] && echo "  ✓ Emergency stop: works" || echo "  ✗ Emergency stop: $ES"
    curl -s -X POST "http://localhost:8000/api/v1/enterprise/emergency-stop/$WS/resume" \
        -H "Authorization: Bearer $TOKEN" >/dev/null 2>&1

    # Scope add + check
    curl -s -X POST "http://localhost:8000/api/v1/enterprise/scope/$WS/include" \
        -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
        -d '{"pattern":"*.testphp.vulnweb.com","notes":"test scope"}' >/dev/null 2>&1
    SC=$(curl -s --max-time 5 -X POST "http://localhost:8000/api/v1/enterprise/scope/$WS/check" \
        -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
        -d '{"target":"api.testphp.vulnweb.com"}' 2>/dev/null | \
        python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('allowed',''))" 2>/dev/null || echo "")
    [ "$SC" = "True" ] && echo "  ✓ Scope check: in-scope target allowed" || echo "  ⚠ Scope check: $SC"
fi

# Verify scan pipeline fix
echo ""
echo "  Waiting 25s to verify scan pipeline works..."
TEST_SCAN=$(curl -s --max-time 10 -X POST "http://localhost:8000/api/v1/scans" \
    -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
    -d "{\"name\":\"pipeline-verify\",\"workspace_id\":\"$WS\",\"scan_type\":\"recon\",\"target\":\"https://testphp.vulnweb.com\",\"config\":{\"domain\":\"testphp.vulnweb.com\"}}" 2>/dev/null | \
    python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('id','')+'|'+d.get('status',''))" 2>/dev/null || echo "")
TEST_SCAN_ID=$(echo "$TEST_SCAN" | cut -d'|' -f1)
[ -n "$TEST_SCAN_ID" ] && echo "  ✓ Test scan created: ${TEST_SCAN_ID:0:8}..."
sleep 25
if [ -n "$TEST_SCAN_ID" ]; then
    FINAL_ST=$(curl -s --max-time 5 "http://localhost:8000/api/v1/scans/$TEST_SCAN_ID" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
        python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null || echo "?")
    case "$FINAL_ST" in
        running|completed) echo "  ✓ Scan pipeline WORKING! Status: $FINAL_ST" ;;
        failed) echo "  ✗ Scan still FAILED — check: docker compose logs worker --tail=30" ; docker compose logs worker --tail=20 ;;
        queued) echo "  ⚠ Still queued — worker restarting (wait 30s and re-check)" ;;
        *) echo "  ⚠ Status: $FINAL_ST" ;;
    esac
fi

# Run tests
echo ""
echo "  Running tests inside container..."
docker compose exec -T backend pip install pytest pytest-asyncio -q 2>/dev/null | tail -1
TRESULT=$(docker compose exec -T backend python -m pytest tests/test_production_readiness.py -q --tb=line 2>&1)
PASSED=$(echo "$TRESULT" | grep -oP '\d+ passed' | grep -oP '\d+' || echo 0)
FAILED=$(echo "$TRESULT" | grep -oP '\d+ failed' | grep -oP '\d+' || echo 0)
echo "$TRESULT" | tail -3
[ "$FAILED" -eq 0 ] && [ "$PASSED" -gt 0 ] && echo "  ✓ Tests: $PASSED passed" || echo "  ✗ Tests: $PASSED passed, $FAILED failed"

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  ✓ Hot-fix complete — no rebuild required                    ║"
echo "╠══════════════════════════════════════════════════════════════╣"
printf "║  UI:    %-51s║\n" "http://${SERVER_IP}:3000/dashboard"
printf "║  Docs:  %-51s║\n" "http://${SERVER_IP}:8000/api/docs"
echo "║  Login: admin@blackmirror.io / BlackMirrorX2025!             ║"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "║  Enterprise UI pages:  /scope  /approvals  /team             ║"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "║  Now run full verification:                                   ║"
printf "║  %-62s║\n" "  BACKEND_URL=http://${SERVER_IP}:8000 \\"
printf "║  %-62s║\n" "  FRONTEND_URL=http://${SERVER_IP}:3000 \\"
echo "║    bash scripts/verify_full_stack.sh                         ║"
echo "╚══════════════════════════════════════════════════════════════╝"
