#!/usr/bin/env bash
# fix_running_vps.sh — Fix a RUNNING VPS stack without full rebuild
# Use this when: docker compose ps shows services running, but
#   - Login fails (seed not run)
#   - Enterprise routes return errors (migration 004 not applied)
#   - Verification script fails
#   - Frontend can't reach backend
#
# Run from: ~/private/blackmirror-x
set -e
cd "$(dirname "$0")/.."
[ -f docker-compose.yml ] || { echo "ERROR: run from ~/private/blackmirror-x"; exit 1; }

# Detect IP
SERVER_IP=$(curl -sf --max-time 3 https://api.ipify.org 2>/dev/null || echo "76.13.30.226")

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Running Stack Fix                  ║"
echo "╚══════════════════════════════════════════════════════╝"
echo "  Server IP: $SERVER_IP"

# ── Step 1: Check what's running ──────────────────────────────
echo ""
echo "[1/6] Container status..."
docker compose ps

# ── Step 2: Verify backend is responding ──────────────────────
echo ""
echo "[2/6] Backend health check..."
for i in 1 2 3 4 5; do
    if curl -sf --max-time 5 http://localhost:8000/health >/dev/null 2>&1; then
        echo "  ✓ Backend is healthy"
        break
    fi
    echo "  Waiting for backend... ($i/5)"
    sleep 5
    [ $i -eq 5 ] && { echo "  ✗ Backend not responding. Run: docker compose logs backend --tail=50"; exit 1; }
done

# ── Step 3: Run ALL migrations (safe to run multiple times) ───
echo ""
echo "[3/6] Running database migrations (001→004)..."
docker compose exec backend alembic upgrade head 2>&1
echo "  ✓ Migrations applied"

# ── Step 4: Re-seed (idempotent) ──────────────────────────────
echo ""
echo "[4/6] Seeding demo data (idempotent)..."
docker compose exec backend python scripts/seed.py 2>&1
echo "  ✓ Seed complete"

# ── Step 5: Fix CORS .env if needed ───────────────────────────
echo ""
echo "[5/6] Fixing .env for server IP $SERVER_IP..."
CURRENT_CORS=$(grep "^CORS_ORIGINS=" .env | cut -d= -f2)
if echo "$CURRENT_CORS" | grep -q "$SERVER_IP"; then
    echo "  ✓ CORS already includes $SERVER_IP"
else
    sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000,http://127.0.0.1:3000|" .env
    echo "  ✓ CORS updated: $(grep ^CORS_ORIGINS .env | cut -d= -f2)"
    echo "  ℹ CORS change requires backend restart to take effect"
    docker compose restart backend
    echo "  Waiting for backend restart..."
    sleep 8
fi

# ── Step 6: End-to-end verification ───────────────────────────
echo ""
echo "[6/6] End-to-end verification..."

# Health
HEALTH=$(curl -sf --max-time 5 http://localhost:8000/health 2>/dev/null)
echo "$HEALTH" | grep -q "healthy" && echo "  ✓ /health OK" || echo "  ✗ /health: $HEALTH"

# CORS preflight
CORS=$(curl -si --max-time 5 -X OPTIONS "http://localhost:8000/api/v1/workspaces" \
    -H "Origin: http://${SERVER_IP}:3000" \
    -H "Access-Control-Request-Method: POST" \
    -H "Access-Control-Request-Headers: authorization,content-type" 2>/dev/null | \
    grep -i "access-control-allow-origin" | tr -d '\r')
[ -n "$CORS" ] && echo "  ✓ CORS: $CORS" || echo "  ✗ CORS MISSING"

# Login
TOKEN=$(curl -sf --max-time 10 -X POST "http://localhost:8000/api/v1/auth/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" 2>/dev/null | \
    python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))" 2>/dev/null || echo "")
[ -n "$TOKEN" ] && echo "  ✓ Login: OK" || { echo "  ✗ Login FAILED — check docker compose logs backend"; }

if [ -n "$TOKEN" ]; then
    # Get workspace
    WS=$(curl -sf --max-time 5 "http://localhost:8000/api/v1/workspaces" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
        python3 -c "import sys,json; ws=json.load(sys.stdin); print(ws[0]['id'] if ws else '')" 2>/dev/null || echo "")
    echo "  $([ -n "$WS" ] && echo "✓ Workspace: ${WS:0:8}..." || echo "✗ No workspace")"

    if [ -n "$WS" ]; then
        # Create scan
        SCAN=$(curl -sf --max-time 10 -X POST "http://localhost:8000/api/v1/scans" \
            -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
            -d "{\"name\":\"Fix-Verify\",\"workspace_id\":\"$WS\",\"scan_type\":\"recon\",\"target\":\"testphp.vulnweb.com\"}" 2>/dev/null | \
            python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('id',''))" 2>/dev/null || echo "")
        echo "  $([ -n "$SCAN" ] && echo "✓ Scan created: ${SCAN:0:8}..." || echo "✗ Scan creation failed")"

        # Enterprise
        ENT=$(curl -sf --max-time 5 "http://localhost:8000/api/v1/enterprise/scope/$WS" \
            -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
            python3 -c "import sys,json; d=json.load(sys.stdin); print('OK' if 'workspace_id' in d else 'FAIL')" 2>/dev/null || echo "FAIL")
        echo "  $([ "$ENT" = "OK" ] && echo "✓ Enterprise scope route" || echo "✗ Enterprise scope FAILED (migration 004 may not have run)")"

        PLUGINS=$(curl -sf --max-time 5 "http://localhost:8000/api/v1/enterprise/plugins" \
            -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
            python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d.get('plugins',[])))" 2>/dev/null || echo "0")
        echo "  ✓ Enterprise plugins: $PLUGINS available"
    fi
fi

# Install pytest for future use
echo ""
echo "  Installing pytest in container..."
docker compose exec backend pip install pytest pytest-asyncio -q 2>/dev/null && echo "  ✓ pytest ready" || echo "  ⚠ pytest install failed (non-fatal)"

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  ✓ Running stack fixed!                                  ║"
echo "╠══════════════════════════════════════════════════════════╣"
printf "║  UI:    %-50s║\n" "http://${SERVER_IP}:3000"
printf "║  Docs:  %-50s║\n" "http://${SERVER_IP}:8000/api/docs"
echo "║  Login: admin@blackmirror.io / BlackMirrorX2025!         ║"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║  NEXT STEPS:                                             ║"
echo "║  Run full verification:                                  ║"
printf "║  %-58s║\n" "  BACKEND_URL=http://${SERVER_IP}:8000 \\"
printf "║  %-58s║\n" "  FRONTEND_URL=http://${SERVER_IP}:3000 \\"
echo "║    bash scripts/verify_full_stack.sh                     ║"
echo "╚══════════════════════════════════════════════════════════╝"
