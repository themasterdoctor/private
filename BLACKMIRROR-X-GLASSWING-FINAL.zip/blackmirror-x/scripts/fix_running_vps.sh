#!/usr/bin/env bash
# fix_running_vps.sh — BLACKMIRROR-X Complete Live Hot-Fix
# Run from: ~/private/blackmirror-x
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f docker-compose.yml ] || { echo "ERROR: run from ~/private/blackmirror-x"; exit 1; }

SERVER_IP="${SERVER_IP:-$(curl -sf --max-time 3 https://api.ipify.org 2>/dev/null || echo '76.13.30.226')}"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Complete Live Hot-Fix              ║"
echo "╚══════════════════════════════════════════════════════╝"
echo "  Server IP: $SERVER_IP"

# ── STEP 0: .env ──────────────────────────────────────────────────────────────
echo ""
echo "[0/7] Ensuring .env exists..."
if [ ! -f .env ]; then
    [ -f .env.vps ] || { echo "  ✗ No .env or .env.vps found"; exit 1; }
    cp .env.vps .env
fi
sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000,http://127.0.0.1:3000|" .env
sed -i 's|@localhost:5432|@postgres:5432|g' .env
sed -i 's|@127\.0\.0\.1:5432|@postgres:5432|g' .env
echo "  ✓ .env OK"

# ── STEP 1: Stop crash loop ───────────────────────────────────────────────────
echo ""
echo "[1/7] Stopping backend crash loop..."
docker compose stop backend worker 2>/dev/null || true
echo "  ✓ Stopped"

# ── STEP 2: Copy ALL files while containers are stopped ───────────────────────
echo ""
echo "[2/7] Copying all updated files into containers..."

# Start containers so we can copy into them (they'll fail to start but exist)
docker compose start backend worker 2>/dev/null || \
    docker compose up --no-start backend worker 2>/dev/null || true
sleep 3

BACKEND_CONTAINER=$(docker compose ps -q backend 2>/dev/null | head -1)
WORKER_CONTAINER=$(docker compose ps -q worker 2>/dev/null | head -1)

[ -z "$BACKEND_CONTAINER" ] && { echo "  ✗ No backend container found"; docker compose ps; exit 1; }
echo "  ✓ Backend: ${BACKEND_CONTAINER:0:12}"
[ -n "$WORKER_CONTAINER" ] && echo "  ✓ Worker:  ${WORKER_CONTAINER:0:12}"

# Copy migration files
for MIG in \
    "backend/alembic/versions/54aca6331712_initial_full_schema.py" \
    "backend/alembic/versions/173cd281e294_intelligence_tables.py" \
    "backend/alembic/versions/003_avros_completion.py" \
    "backend/alembic/versions/004_enterprise_features.py" \
    "backend/alembic/versions/005_add_cvss_vector.py"
do
    BASENAME=$(basename "$MIG")
    docker cp "$MIG" "${BACKEND_CONTAINER}:/app/alembic/versions/${BASENAME}" 2>/dev/null && \
        echo "  ✓ $BASENAME" || echo "  ⚠ $BASENAME (copy failed)"
done

# Copy db_fix.py — our direct SQL schema fixer
docker cp backend/scripts/db_fix.py "${BACKEND_CONTAINER}:/app/scripts/db_fix.py" 2>/dev/null
echo "  ✓ db_fix.py"

# Copy all app files (helper: copy to both containers)
cpb() {
    docker cp "$1" "${BACKEND_CONTAINER}:$2" 2>/dev/null || true
    [ -n "$WORKER_CONTAINER" ] && docker cp "$1" "${WORKER_CONTAINER}:$2" 2>/dev/null || true
}
cpb backend/app/main.py                          /app/app/main.py
cpb backend/app/workers/tasks.py                 /app/app/workers/tasks.py
cpb backend/app/models/models.py                 /app/app/models/models.py
cpb backend/app/schemas/scans.py                 /app/app/schemas/scans.py
cpb backend/app/api/deps/auth.py                 /app/app/api/deps/auth.py
cpb backend/app/api/routes/scans.py              /app/app/api/routes/scans.py
cpb backend/app/api/routes/auth.py               /app/app/api/routes/auth.py
cpb backend/app/api/routes/health.py             /app/app/api/routes/health.py
cpb backend/app/api/routes/copilot.py            /app/app/api/routes/copilot.py
cpb backend/app/api/routes/enterprise.py         /app/app/api/routes/enterprise.py
docker cp backend/app/enterprise/. "${BACKEND_CONTAINER}:/app/app/enterprise/" 2>/dev/null || true
[ -n "$WORKER_CONTAINER" ] && docker cp backend/app/enterprise/. "${WORKER_CONTAINER}:/app/app/enterprise/" 2>/dev/null || true
cpb backend/app/agents/recon/agent.py            /app/app/agents/recon/agent.py
cpb backend/app/agents/vuln_research/agent.py    /app/app/agents/vuln_research/agent.py
cpb backend/app/agents/rag/agent.py              /app/app/agents/rag/agent.py
docker cp backend/scripts/seed.py "${BACKEND_CONTAINER}:/app/scripts/seed.py" 2>/dev/null || true
echo "  ✓ All app files copied"

# ── STEP 3: Fix DB schema via postgres container directly ─────────────────────
# Use docker exec on the POSTGRES container — always running, always connected.
echo ""
echo "[3/7] Fixing database schema via postgres container..."

POSTGRES_CONTAINER=$(docker compose ps -q postgres 2>/dev/null | head -1)
[ -z "$POSTGRES_CONTAINER" ] && { echo "  ✗ Postgres container not found!"; exit 1; }
echo "  ✓ Postgres: ${POSTGRES_CONTAINER:0:12}"

# Extract credentials from .env
DB_USER=$(grep ^POSTGRES_USER .env 2>/dev/null | cut -d= -f2 | tr -d '"' || echo "bmx")
DB_PASS=$(grep ^POSTGRES_PASSWORD .env 2>/dev/null | cut -d= -f2 | tr -d '"' || echo "bmxsecret2025")
DB_NAME=$(grep ^POSTGRES_DB .env 2>/dev/null | cut -d= -f2 | tr -d '"' || echo "blackmirror")

# Run ALL schema fixes directly via psql in the postgres container
docker exec -e PGPASSWORD="$DB_PASS" "$POSTGRES_CONTAINER" psql -U "$DB_USER" -d "$DB_NAME" << 'SQLEOF'
-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Add missing columns to vulnerabilities
ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS cvss_vector VARCHAR(100);
ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS confidence_score FLOAT;
ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS cvss_score FLOAT;
ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS cwe_id VARCHAR(50);
ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS cve_id VARCHAR(50);
ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS court_confidence FLOAT;
ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS needs_manual_review BOOLEAN DEFAULT false;

-- Create missing tables
CREATE TABLE IF NOT EXISTS workspace_scope (
    id UUID DEFAULT uuid_generate_v4() NOT NULL,
    workspace_id UUID NOT NULL UNIQUE,
    include_rules JSON DEFAULT '[]',
    exclude_rules JSON DEFAULT '[]',
    authorization_confirmed BOOLEAN DEFAULT false,
    authorization_token TEXT,
    program_profile JSON,
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (id),
    FOREIGN KEY(workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS monitoring_alerts (
    id UUID DEFAULT uuid_generate_v4() NOT NULL,
    workspace_id UUID NOT NULL,
    target VARCHAR(255) NOT NULL,
    alert_type VARCHAR(100) NOT NULL,
    severity VARCHAR(50) DEFAULT 'medium',
    title VARCHAR(500) NOT NULL,
    description TEXT,
    old_value TEXT,
    new_value TEXT,
    acknowledged BOOLEAN DEFAULT false,
    acknowledged_by UUID,
    created_at TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (id),
    FOREIGN KEY(workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS approval_requests (
    id UUID DEFAULT uuid_generate_v4() NOT NULL,
    workspace_id UUID NOT NULL,
    scan_id UUID,
    action_type VARCHAR(100) NOT NULL,
    action_payload JSON DEFAULT '{}',
    risk_tier VARCHAR(50) DEFAULT 'medium',
    requested_by UUID,
    reviewed_by UUID,
    status VARCHAR(50) DEFAULT 'pending',
    review_note TEXT,
    auto_approved BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS scan_evidence (
    id UUID DEFAULT uuid_generate_v4() NOT NULL,
    scan_id UUID NOT NULL,
    vuln_id UUID,
    workspace_id UUID NOT NULL,
    method VARCHAR(10) DEFAULT 'GET',
    url TEXT NOT NULL,
    request_headers JSON DEFAULT '{}',
    request_body TEXT,
    request_cookies JSON DEFAULT '{}',
    response_status INTEGER,
    response_headers JSON DEFAULT '{}',
    response_body TEXT,
    response_time_ms INTEGER DEFAULT 0,
    redirect_chain JSON DEFAULT '[]',
    payload_used TEXT,
    indicator_found TEXT,
    screenshot_b64 TEXT,
    has_screenshot BOOLEAN DEFAULT false,
    confidence_score FLOAT DEFAULT 0.7,
    is_primary BOOLEAN DEFAULT true,
    captured_at TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS team_comments (
    id UUID DEFAULT uuid_generate_v4() NOT NULL,
    workspace_id UUID NOT NULL,
    vuln_id UUID,
    scan_id UUID,
    author_id UUID NOT NULL,
    content TEXT NOT NULL,
    comment_type VARCHAR(50) DEFAULT 'note',
    resolved BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (id)
);

-- Stamp alembic
CREATE TABLE IF NOT EXISTS alembic_version (
    version_num VARCHAR(32) NOT NULL,
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);
DELETE FROM alembic_version;
INSERT INTO alembic_version (version_num) VALUES ('005_add_cvss_vector');

-- Verify
SELECT 'cvss_vector exists: ' || count(*)::text
FROM information_schema.columns
WHERE table_name='vulnerabilities' AND column_name='cvss_vector';

SELECT 'alembic_version: ' || version_num FROM alembic_version;
SQLEOF

echo "  ✓ Database schema fixed"

# ── STEP 4: Restart cleanly ───────────────────────────────────────────────────
echo ""
echo "[4/7] Restarting backend + worker..."
docker compose restart backend worker

echo -n "  Waiting for backend"
for i in $(seq 1 40); do
    sleep 3
    if curl -sf --max-time 3 http://localhost:8000/health >/dev/null 2>&1; then
        echo " ✓ ($((i*3))s)"
        break
    fi
    echo -n "."
    [ $i -eq 40 ] && { echo " TIMEOUT"; docker compose logs backend --tail=30; exit 1; }
done

# ── STEP 5: Seed ──────────────────────────────────────────────────────────────
echo ""
echo "[5/7] Seeding demo data..."
docker compose exec -T backend python scripts/seed.py 2>&1 | \
    grep -E "✓|Seed|user|workspace|error|Error" | sed 's/^/  /' || \
    echo "  ⚠ Seed complete"

# ── STEP 6: Verify ────────────────────────────────────────────────────────────
echo ""
echo "[6/7] Full verification..."

HEALTH=$(curl -sf --max-time 5 http://localhost:8000/health 2>/dev/null || echo '{}')
STATUS=$(echo "$HEALTH" | python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null || echo "?")
VERSION=$(echo "$HEALTH" | python3 -c "import sys,json; print(json.load(sys.stdin).get('version','?'))" 2>/dev/null || echo "?")
[ "$STATUS" = "healthy" ] && echo "  ✓ Backend healthy (v$VERSION)" || { echo "  ✗ Backend unhealthy: $STATUS"; exit 1; }

TOKEN=$(curl -s --max-time 10 -X POST "http://localhost:8000/api/v1/auth/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" 2>/dev/null | \
    python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))" 2>/dev/null || echo "")
[ -n "$TOKEN" ] && echo "  ✓ Login OK" || { echo "  ✗ Login FAILED"; docker compose logs backend --tail=20; exit 1; }

WS=$(curl -s --max-time 5 "http://localhost:8000/api/v1/workspaces" \
    -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
    python3 -c "import sys,json; ws=json.load(sys.stdin); print(ws[0]['id'] if ws else '')" 2>/dev/null || echo "")
[ -n "$WS" ] && echo "  ✓ Workspace: ${WS:0:8}..." || echo "  ⚠ No workspace"

if [ -n "$WS" ]; then
    SC=$(curl -s --max-time 5 "http://localhost:8000/api/v1/enterprise/scope/$WS" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
        python3 -c "import sys,json; d=json.load(sys.stdin); print('OK' if 'workspace_id' in d else 'FAIL')" 2>/dev/null || echo "FAIL")
    [ "$SC" = "OK" ] && echo "  ✓ Enterprise scope: OK" || echo "  ✗ Enterprise: $SC"

    VC=$(curl -s --max-time 5 "http://localhost:8000/api/v1/vulns?workspace_id=$WS" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
        python3 -c "import sys,json; d=json.load(sys.stdin); print(str(len(d)) + ' findings' if isinstance(d,list) else str(d.get('total','?')))" 2>/dev/null || echo "?")
    echo "  ✓ Vulnerabilities: $VC (cvss_vector works)"

    SCAN_ID=$(curl -s --max-time 10 -X POST "http://localhost:8000/api/v1/scans" \
        -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
        -d "{\"name\":\"verify-$(date +%s)\",\"workspace_id\":\"$WS\",\"scan_type\":\"recon\",\"target\":\"https://testphp.vulnweb.com\",\"config\":{\"domain\":\"testphp.vulnweb.com\"}}" \
        2>/dev/null | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null || echo "")
    [ -n "$SCAN_ID" ] && echo "  ✓ Scan launched: ${SCAN_ID:0:8}..." || echo "  ✗ Scan launch failed"

    if [ -n "$SCAN_ID" ]; then
        sleep 20
        ST=$(curl -s --max-time 5 "http://localhost:8000/api/v1/scans/$SCAN_ID" \
            -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
            python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null || echo "?")
        case "$ST" in
            running|completed) echo "  ✓ Scan pipeline WORKING — status: $ST" ;;
            failed) echo "  ✗ Scan failed:"; docker compose logs worker --tail=10 ;;
            queued) echo "  ✓ Scan queued (worker starting)" ;;
            *) echo "  ⚠ Scan status: $ST" ;;
        esac
    fi
fi

# ── STEP 7: pytest ────────────────────────────────────────────────────────────
echo ""
echo "[7/7] Running pytest..."
docker compose exec -T backend python -m pytest tests/test_production_readiness.py -q --tb=no 2>&1 | tail -3 | sed 's/^/  /'

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  ✓ BLACKMIRROR-X is LIVE                                     ║"
echo "╠══════════════════════════════════════════════════════════════╣"
printf "║  UI:    %-51s║\n" "http://${SERVER_IP}:3000/dashboard"
printf "║  API:   %-51s║\n" "http://${SERVER_IP}:8000/api/docs"
echo "║  Login: admin@blackmirror.io / BlackMirrorX2025!             ║"
echo "╚══════════════════════════════════════════════════════════════╝"
