#!/usr/bin/env bash
# fix_running_vps.sh — BLACKMIRROR-X Complete Live Hot-Fix
# Run from: ~/private/blackmirror-x
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f docker-compose.yml ] || { echo "ERROR: run from ~/private/blackmirror-x"; exit 1; }

SERVER_IP="${SERVER_IP:-$(curl -sf --max-time 3 https://api.ipify.org 2>/dev/null || echo '76.13.30.226')}"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Complete Live Hot-Fix              ║"
echo "╚══════════════════════════════════════════════════════╝"
echo "  Server IP: $SERVER_IP"

# ── STEP 0: .env ──────────────────────────────────────────────────────────────
echo ""
echo "[0/7] Ensuring .env exists..."
if [ ! -f .env ]; then
    [ -f .env.vps ] || { echo "  ✗ No .env or .env.vps found"; exit 1; }
    cp .env.vps .env
    echo "  ✓ Created .env from .env.vps"
else
    echo "  ✓ .env exists"
fi
sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000,http://127.0.0.1:3000|" .env
sed -i 's|@localhost:5432|@postgres:5432|g' .env
sed -i 's|@127\.0\.0\.1:5432|@postgres:5432|g' .env
echo "  ✓ CORS: $(grep ^CORS_ORIGINS .env | cut -d= -f2 | cut -c1-55)"

# ── STEP 1: Container status ──────────────────────────────────────────────────
echo ""
echo "[1/7] Container status..."
docker compose ps

# ── STEP 2: Get container IDs (BEFORE any restart) ────────────────────────────
echo ""
echo "[2/7] Getting container IDs..."
BACKEND_CONTAINER=$(docker compose ps -q backend)
WORKER_CONTAINER=$(docker compose ps -q worker)
[ -z "$BACKEND_CONTAINER" ] && { echo "  ✗ Backend container not found"; exit 1; }
echo "  ✓ Backend: ${BACKEND_CONTAINER:0:12}"
[ -n "$WORKER_CONTAINER" ] && echo "  ✓ Worker:  ${WORKER_CONTAINER:0:12}" || echo "  ⚠ Worker not found"

# ── STEP 3: Copy ALL migration files FIRST (before restart!) ─────────────────
# CRITICAL: entrypoint.sh runs "alembic upgrade head" on every restart.
# The container image is missing newer migrations (004, 005).
# We MUST copy them in BEFORE restarting or alembic will fail with KeyError.
echo ""
echo "[3/7] Copying migration files BEFORE restart..."

for MIG in \
    "backend/alembic/versions/54aca6331712_initial_full_schema.py" \
    "backend/alembic/versions/173cd281e294_intelligence_tables.py" \
    "backend/alembic/versions/003_avros_completion.py" \
    "backend/alembic/versions/004_enterprise_features.py" \
    "backend/alembic/versions/005_add_cvss_vector.py"
do
    BASENAME=$(basename "$MIG")
    docker cp "$MIG" "${BACKEND_CONTAINER}:/app/alembic/versions/${BASENAME}"
    docker cp "$MIG" "${WORKER_CONTAINER}:/app/alembic/versions/${BASENAME}" 2>/dev/null || true
    echo "  ✓ $BASENAME"
done
docker cp backend/alembic/env.py "${BACKEND_CONTAINER}:/app/alembic/env.py" 2>/dev/null || true

# ── STEP 4: Copy ALL updated app files (before restart) ──────────────────────
echo ""
echo "[4/7] Injecting all updated files..."

# Helper: copy to both containers
cp_both() {
    docker cp "$1" "${BACKEND_CONTAINER}:$2"
    [ -n "$WORKER_CONTAINER" ] && docker cp "$1" "${WORKER_CONTAINER}:$2" 2>/dev/null || true
}

# Core
cp_both backend/app/main.py                          /app/app/main.py
cp_both backend/app/workers/tasks.py                 /app/app/workers/tasks.py
cp_both backend/app/models/models.py                 /app/app/models/models.py
cp_both backend/app/schemas/scans.py                 /app/app/schemas/scans.py
cp_both backend/app/api/deps/auth.py                 /app/app/api/deps/auth.py
echo "  ✓ Core: main.py, tasks.py, models.py, schemas.py, auth.py"

# Routes
cp_both backend/app/api/routes/scans.py              /app/app/api/routes/scans.py
cp_both backend/app/api/routes/auth.py               /app/app/api/routes/auth.py
cp_both backend/app/api/routes/health.py             /app/app/api/routes/health.py
cp_both backend/app/api/routes/copilot.py            /app/app/api/routes/copilot.py
cp_both backend/app/api/routes/enterprise.py         /app/app/api/routes/enterprise.py
echo "  ✓ Routes: scans, auth, health, copilot, enterprise"

# Enterprise modules
docker cp backend/app/enterprise/. "${BACKEND_CONTAINER}:/app/app/enterprise/"
[ -n "$WORKER_CONTAINER" ] && docker cp backend/app/enterprise/. "${WORKER_CONTAINER}:/app/app/enterprise/" 2>/dev/null || true
echo "  ✓ Enterprise modules (7 files)"

# Agents (run in worker)
cp_both backend/app/agents/recon/agent.py            /app/app/agents/recon/agent.py
cp_both backend/app/agents/vuln_research/agent.py    /app/app/agents/vuln_research/agent.py
cp_both backend/app/agents/rag/agent.py              /app/app/agents/rag/agent.py
echo "  ✓ Agents: recon, vuln_research, rag"

# Scripts & tests
docker cp backend/scripts/seed.py                    "${BACKEND_CONTAINER}:/app/scripts/seed.py"
docker cp backend/tests/test_production_readiness.py "${BACKEND_CONTAINER}:/app/tests/test_production_readiness.py" 2>/dev/null || true
echo "  ✓ scripts/seed.py"

# entrypoint.sh — idempotent: handles DuplicateTable by stamping alembic
docker cp backend/entrypoint.sh "${BACKEND_CONTAINER}:/app/entrypoint.sh"
docker exec "${BACKEND_CONTAINER}" chmod +x /app/entrypoint.sh 2>/dev/null || true
echo "  ✓ entrypoint.sh (idempotent migration + stamp fallback)"

# ── STEP 5: Restart backend + worker ─────────────────────────────────────────
# Now safe to restart: migration files are already in place.
# entrypoint.sh will run alembic upgrade head and find all 5 files.
echo ""
echo "[5/7] Restarting backend + worker (migrations will run automatically)..."
docker compose restart backend worker

echo -n "  Waiting for backend"
for i in $(seq 1 40); do
    sleep 3
    if curl -sf --max-time 3 http://localhost:8000/health >/dev/null 2>&1; then
        SECS=$((i * 3))
        echo " ✓ (${SECS}s)"
        break
    fi
    echo -n "."
    if [ $i -eq 40 ]; then
        echo " TIMEOUT"
        echo ""
        echo "  Backend logs:"
        docker compose logs backend --tail=40
        exit 1
    fi
done

# ── STEP 6: Seed demo data ────────────────────────────────────────────────────
echo ""
echo "[6/7] Seeding demo data..."
# Re-get container ID after restart
BACKEND_CONTAINER=$(docker compose ps -q backend)
docker compose exec -T backend python scripts/seed.py 2>&1
echo "  ✓ Seed complete"

# ── STEP 7: Verify everything works ──────────────────────────────────────────
echo ""
echo "[7/7] Verification..."

# Health
HEALTH=$(curl -sf --max-time 5 http://localhost:8000/health 2>/dev/null || echo '{}')
STATUS=$(echo "$HEALTH" | python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null || echo "?")
VERSION=$(echo "$HEALTH" | python3 -c "import sys,json; print(json.load(sys.stdin).get('version','?'))" 2>/dev/null || echo "?")
[ "$STATUS" = "healthy" ] && echo "  ✓ Backend healthy (v${VERSION})" || echo "  ✗ Backend: $STATUS"

# Login
TOKEN=$(curl -s --max-time 10 -X POST "http://localhost:8000/api/v1/auth/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" 2>/dev/null | \
    python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))" 2>/dev/null || echo "")
[ -n "$TOKEN" ] && echo "  ✓ Login OK" || { echo "  ✗ Login FAILED"; docker compose logs backend --tail=20; exit 1; }

# Workspace
WS=$(curl -s --max-time 5 "http://localhost:8000/api/v1/workspaces" \
    -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
    python3 -c "import sys,json; ws=json.load(sys.stdin); print(ws[0]['id'] if ws else '')" 2>/dev/null || echo "")
[ -n "$WS" ] && echo "  ✓ Workspace: ${WS:0:8}..." || echo "  ⚠ No workspace"

if [ -n "$WS" ]; then
    # Enterprise scope
    SC=$(curl -s --max-time 5 "http://localhost:8000/api/v1/enterprise/scope/$WS" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
        python3 -c "import sys,json; d=json.load(sys.stdin); print('OK' if 'workspace_id' in d else 'FAIL')" 2>/dev/null || echo "FAIL")
    [ "$SC" = "OK" ] && echo "  ✓ Enterprise scope: OK" || echo "  ✗ Enterprise scope: $SC"

    # Plugins
    PC=$(curl -s --max-time 5 "http://localhost:8000/api/v1/enterprise/plugins" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
        python3 -c "import sys,json; print(len(json.load(sys.stdin).get('plugins',[])))" 2>/dev/null || echo 0)
    [ "${PC:-0}" -ge 2 ] && echo "  ✓ Plugins: $PC registered" || echo "  ✗ Plugins: $PC"

    # Vulnerabilities (tests cvss_vector column works)
    VC=$(curl -s --max-time 5 "http://localhost:8000/api/v1/vulns?workspace_id=$WS" \
        -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
        python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d) if isinstance(d,list) else d.get('total',0))" 2>/dev/null || echo "?")
    echo "  ✓ Vulnerabilities query works: $VC findings (cvss_vector column OK)"

    # Launch test scan
    echo ""
    echo "  Launching scan pipeline test..."
    SCAN_ID=$(curl -s --max-time 10 -X POST "http://localhost:8000/api/v1/scans" \
        -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
        -d "{\"name\":\"verify-$(date +%s)\",\"workspace_id\":\"$WS\",\"scan_type\":\"recon\",\"target\":\"https://testphp.vulnweb.com\",\"config\":{\"domain\":\"testphp.vulnweb.com\"}}" \
        2>/dev/null | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null || echo "")
    [ -n "$SCAN_ID" ] && echo "  ✓ Scan created: ${SCAN_ID:0:8}..." || echo "  ✗ Scan creation failed"

    if [ -n "$SCAN_ID" ]; then
        echo -n "  Waiting 30s for scan"
        sleep 30
        ST=$(curl -s --max-time 5 "http://localhost:8000/api/v1/scans/$SCAN_ID" \
            -H "Authorization: Bearer $TOKEN" 2>/dev/null | \
            python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null || echo "?")
        echo ""
        case "$ST" in
            running|completed) echo "  ✓ Scan pipeline WORKING — status: $ST" ;;
            failed) echo "  ✗ Scan FAILED — worker logs:"; docker compose logs worker --tail=15 ;;
            queued) echo "  ⚠ Still queued (worker may be warming up — normal)" ;;
            *) echo "  ⚠ Status: $ST" ;;
        esac
    fi
fi

# pytest
echo ""
echo "  Running pytest..."
docker compose exec -T backend pip install pytest pytest-asyncio -q 2>/dev/null | tail -1
TRES=$(docker compose exec -T backend python -m pytest tests/test_production_readiness.py -q --tb=line 2>&1)
echo "$TRES" | tail -3
PASSED=$(echo "$TRES" | grep -oP '\d+ passed' | grep -oP '\d+' || echo 0)
FAILED_T=$(echo "$TRES" | grep -oP '\d+ failed' | grep -oP '\d+' || echo 0)
[ "${FAILED_T:-0}" -eq 0 ] && [ "${PASSED:-0}" -gt 0 ] && \
    echo "  ✓ Tests: ${PASSED} passed" || \
    echo "  ✗ Tests: ${PASSED} passed, ${FAILED_T} failed"

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  ✓ Hot-fix complete                                          ║"
echo "╠══════════════════════════════════════════════════════════════╣"
printf "║  UI:    %-51s║\n" "http://${SERVER_IP}:3000/dashboard"
printf "║  API:   %-51s║\n" "http://${SERVER_IP}:8000/api/docs"
echo "║  Login: admin@blackmirror.io / BlackMirrorX2025!             ║"
echo "╚══════════════════════════════════════════════════════════════╝"
