#!/usr/bin/env bash
# deploy_and_verify.sh — BLACKMIRROR-X VPS Fix and Verify
#
# Run from the project root:
#   SERVER_IP=76.13.30.226 bash scripts/deploy_and_verify.sh
#
set -euo pipefail

CYAN='\033[0;36m'; GREEN='\033[0;32m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { echo -e "  ${GREEN}✓${NC}  $1"; }
fail() { echo -e "  ${RED}✗${NC}  $1"; FAILURES=$((FAILURES+1)); }
info() { echo -e "  ${CYAN}→${NC}  $1"; }
FAILURES=0

echo ""
echo -e "${CYAN}════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}  BLACKMIRROR-X — Deploy and Verify${NC}"
echo -e "${CYAN}════════════════════════════════════════════════════════${NC}"
echo ""

# ── Detect server IP ──────────────────────────────────────────────────────────
if [ -z "${SERVER_IP:-}" ]; then
  SERVER_IP=$(curl -s --max-time 5 https://api.ipify.org 2>/dev/null || \
              curl -s --max-time 5 https://ifconfig.me 2>/dev/null || echo "")
  if [ -z "$SERVER_IP" ]; then
    echo -e "${RED}ERROR: Set SERVER_IP=x.x.x.x and rerun${NC}"
    exit 1
  fi
fi
BACKEND="http://${SERVER_IP}:8000"
FRONTEND="http://${SERVER_IP}:3000"
info "Server IP: $SERVER_IP"
info "Backend:   $BACKEND"
info "Frontend:  $FRONTEND"

# ── Step 1: Fix .env ──────────────────────────────────────────────────────────
echo ""
echo "── Step 1: Fix .env ─────────────────────────────────────"
[ ! -f .env ] && { cp .env.example .env; info "Created .env from .env.example"; }

sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000|" .env
sed -i "s|^NEXT_PUBLIC_API_URL=.*|NEXT_PUBLIC_API_URL=http://${SERVER_IP}:8000|" .env
sed -i "s|^NEXT_PUBLIC_WS_URL=.*|NEXT_PUBLIC_WS_URL=ws://${SERVER_IP}:8000|" .env
ok "CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000"
ok "NEXT_PUBLIC_API_URL=http://${SERVER_IP}:8000"

echo "Current .env values:"
grep "CORS_ORIGINS\|NEXT_PUBLIC_API_URL\|NEXT_PUBLIC_WS_URL" .env | sed 's/^/  /'

# ── Step 2: Rebuild ───────────────────────────────────────────────────────────
echo ""
echo "── Step 2: Rebuild Docker images ────────────────────────"
info "Building backend..."
docker compose build --no-cache backend
ok "Backend built"

info "Building frontend (API URL baked in: http://${SERVER_IP}:8000)..."
docker compose build --no-cache frontend
ok "Frontend built"

# ── Step 3: Restart ───────────────────────────────────────────────────────────
echo ""
echo "── Step 3: Restart services ─────────────────────────────"
docker compose down --remove-orphans 2>/dev/null || true
docker compose up -d
ok "Services started"

# ── Step 4: Wait for health ────────────────────────────────────────────────────
echo ""
echo "── Step 4: Wait for backend health ──────────────────────"
TRIES=0
until curl -sf "$BACKEND/health" > /dev/null 2>&1; do
  TRIES=$((TRIES+1))
  [ $TRIES -gt 40 ] && { fail "Backend not healthy after 120s"; docker compose logs backend --tail=30; exit 1; }
  [ $((TRIES % 5)) -eq 0 ] && info "Still waiting... (${TRIES}/40)"
  sleep 3
done
ok "Backend healthy after $((TRIES*3))s"

# ── Step 5: docker compose ps ─────────────────────────────────────────────────
echo ""
echo "── Step 5: docker compose ps ────────────────────────────"
docker compose ps

# ── Step 6: CORS verification ─────────────────────────────────────────────────
echo ""
echo "── Step 6: CORS Verification ────────────────────────────"
echo ""
echo "$ curl -i -X OPTIONS $BACKEND/api/v1/workspaces \\"
echo "    -H 'Origin: $FRONTEND' \\"
echo "    -H 'Access-Control-Request-Method: POST' \\"
echo "    -H 'Access-Control-Request-Headers: authorization,content-type'"
echo ""

CORS_OUT=$(curl -si -X OPTIONS "$BACKEND/api/v1/workspaces" \
  -H "Origin: $FRONTEND" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: authorization,content-type" \
  --max-time 10 2>/dev/null)

echo "$CORS_OUT" | head -15

CORS_STATUS=$(echo "$CORS_OUT" | head -1 | awk '{print $2}')
CORS_ACAO=$(echo "$CORS_OUT" | grep -i "access-control-allow-origin" | head -1 | tr -d '\r')

if echo "$CORS_ACAO" | grep -q "$SERVER_IP"; then
  ok "Preflight: HTTP $CORS_STATUS — $CORS_ACAO"
else
  fail "CORS preflight FAILED — $CORS_ACAO (expected http://${SERVER_IP}:3000)"
fi

echo ""
echo "$ curl -si $BACKEND/api/v1/workspaces -H 'Origin: $FRONTEND'"
CORS_401=$(curl -si "$BACKEND/api/v1/workspaces" \
  -H "Origin: $FRONTEND" --max-time 10 2>/dev/null | grep -i "access-control-allow-origin" | head -1 | tr -d '\r')
echo "  $CORS_401"
if [ -n "$CORS_401" ]; then
  ok "CORS on 401: $CORS_401"
else
  fail "CORS header MISSING on 401 — browser will block all auth errors"
fi

# ── Step 7: fix_and_verify_live.sh ─────────────────────────────────────────────
echo ""
echo "── Step 7: API Verification (fix_and_verify_live.sh) ────"
bash scripts/fix_and_verify_live.sh "$BACKEND" "$FRONTEND"

# ── Step 8: Frontend check ────────────────────────────────────────────────────
echo ""
echo "── Step 8: Frontend Reachable ───────────────────────────"
FE_HTTP=$(curl -s -o /dev/null -w "%{http_code}" "$FRONTEND" --max-time 10 2>/dev/null)
if [[ "$FE_HTTP" =~ ^[23] ]]; then
  ok "Frontend: HTTP $FE_HTTP at $FRONTEND"
else
  fail "Frontend not reachable: HTTP $FE_HTTP"
fi

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}════════════════════════════════════════════════════════${NC}"
if [ "$FAILURES" -eq 0 ]; then
  echo -e "  ${GREEN}✓ ALL CHECKS PASSED — App is functional${NC}"
  echo ""
  echo "  Open:  $FRONTEND"
  echo "  Login: admin@blackmirror.io / BlackMirrorX2025!"
  echo ""
  echo "  To run browser tests (from this server):"
  echo "  npm install -g @playwright/test && npx playwright install chromium"
  echo "  FRONTEND=$FRONTEND BACKEND=$BACKEND npx playwright test tests/e2e/live-ui.spec.ts"
else
  echo -e "  ${RED}$FAILURES FAILURE(S) — see errors above${NC}"
  echo ""
  echo "  Debug: docker compose logs backend --tail=50"
fi
echo -e "${CYAN}════════════════════════════════════════════════════════${NC}"
echo ""
exit $FAILURES
