#!/bin/bash
# diagnose.sh - Run on VPS to find exactly what's broken
cd ~/private/blackmirror-x

echo "=== BLACKMIRROR-X DIAGNOSIS ==="
echo ""

# 1. Container status
echo "[1] Container status:"
docker compose ps --format "table {{.Name}}\t{{.Status}}"
echo ""

# 2. Backend health
echo "[2] Backend health:"
curl -sf http://localhost:8000/health 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'  status={d[\"status\"]} version={d[\"version\"]}')" 2>/dev/null || echo "  BACKEND DOWN"
echo ""

# 3. What code is ACTUALLY running in the worker
echo "[3] Worker code versions:"
docker compose exec -T worker python3 -c "
import sys; sys.path.insert(0, '.')
from app.workers.tasks import _run_vuln_testing
import inspect
sig = inspect.signature(_run_vuln_testing)
params = list(sig.parameters.keys())
print('  _run_vuln_testing params:', params)
print('  has db_urls:', 'db_urls' in params)
" 2>&1 | head -5

docker compose exec -T worker python3 -c "
from app.intelligence.chain.chain_composer import AttackChainComposer
import inspect
sig = inspect.signature(AttackChainComposer.compose_chains)
params = list(sig.parameters.keys())
print('  compose_chains params:', params)
" 2>&1 | head -5
echo ""

# 4. Test if target is reachable
echo "[4] Target reachability:"
curl -sf --max-time 5 "http://testphp.vulnweb.com/" -o /dev/null -w "  testphp.vulnweb.com: HTTP %{http_code}\n" 2>/dev/null || echo "  testphp.vulnweb.com: UNREACHABLE"
docker compose exec -T worker python3 -c "
import httpx, asyncio
async def t():
    async with httpx.AsyncClient(verify=False, timeout=5) as c:
        try:
            r = await c.get('http://testphp.vulnweb.com/listproducts.php?cat=1')
            print(f'  Worker→vulnweb: HTTP {r.status_code} ({len(r.text)} bytes)')
            if 'sql' in r.text.lower() or 'error' in r.text.lower()[:200]:
                print('  SQL/error in response: YES')
        except Exception as e:
            print(f'  Worker→vulnweb: FAILED: {e}')
asyncio.run(t())
" 2>&1 | head -5
echo ""

# 5. Last worker logs
echo "[5] Last 30 worker log lines:"
docker compose logs worker --tail=30 2>&1
echo ""

# 6. Check what files are in worker container
echo "[6] Key files in worker:"
for f in \
    "app/workers/tasks.py" \
    "app/agents/vuln_research/agent.py" \
    "app/intelligence/chain/chain_composer.py" \
    "app/intelligence/court/validation_court.py"
do
    SIZE=$(docker compose exec -T worker wc -l < /app/$f 2>/dev/null || echo "MISSING")
    echo "  $f: $SIZE lines"
done
echo ""

# 7. Run a quick live vuln test from inside the worker
echo "[7] Live vuln test from worker:"
docker compose exec -T worker python3 -c "
import asyncio, sys
sys.path.insert(0, '.')

async def test():
    from app.agents.vuln_research.agent import VulnResearchAgent
    findings = []
    def log(l, m, msg, d=None):
        print(f'  [{l}] {msg[:80]}')
    
    agent = VulnResearchAgent('test', 'test', log_fn=log, rate_limit=0.1)
    findings = await agent.test_url(
        'http://testphp.vulnweb.com/listproducts.php?cat=1',
        ['cat', 'searchFor', 'id'],
        {'tests': ['sqli','xss','missing_headers','info_disclosure']}
    )
    await agent.close()
    print(f'  FINDINGS: {len(findings)}')
    for f in findings:
        print(f'  [{f[\"severity\"].upper()}] {f[\"title\"]}')
        print(f'    evidence: {f.get(\"evidence\",\"\")[:100]}')

asyncio.run(test())
" 2>&1 | head -30
