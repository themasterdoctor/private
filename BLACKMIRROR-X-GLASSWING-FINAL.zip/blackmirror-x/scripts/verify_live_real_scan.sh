#!/usr/bin/env bash
# verify_live_real_scan.sh — Live end-to-end verification
# Tests: login → workspace → scan → wait → verify DB → report
# Target: testphp.vulnweb.com (authorized by Acunetix for testing)
set -euo pipefail

BASE="${BASE:-http://localhost:8000}"
EMAIL="${EMAIL:-admin@blackmirror.io}"
PASS="${PASS:-BlackMirrorX2025!}"
TARGET="${TARGET:-testphp.vulnweb.com}"
WAIT="${WAIT:-60}"  # seconds to wait for scan

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Live Real Scan Verification        ║"
echo "╚══════════════════════════════════════════════════════╝"
echo "  Base: $BASE"
echo "  Target: $TARGET"
echo ""

fail() { echo "  ✗ FAIL: $1"; exit 1; }
pass() { echo "  ✓ $1"; }

# Step 1: Health check
echo "[1/8] Health check..."
HEALTH=$(curl -sf --max-time 5 "$BASE/health" 2>/dev/null || fail "Backend not responding")
STATUS=$(echo "$HEALTH" | python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null)
[ "$STATUS" = "healthy" ] && pass "Backend healthy" || fail "Backend status: $STATUS"

# Step 2: Login
echo "[2/8] Login..."
LOGIN=$(curl -s --max-time 10 -X POST "$BASE/api/v1/auth/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "username=$EMAIL&password=$PASS" 2>/dev/null)
TOKEN=$(echo "$LOGIN" | python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))" 2>/dev/null)
[ -n "$TOKEN" ] && pass "Login OK (token: ${TOKEN:0:20}...)" || fail "Login failed: $LOGIN"

AUTH="Authorization: Bearer $TOKEN"

# Step 3: Get or create workspace
echo "[3/8] Workspace..."
WS_LIST=$(curl -s --max-time 5 "$BASE/api/v1/workspaces" -H "$AUTH" 2>/dev/null)
WS_ID=$(echo "$WS_LIST" | python3 -c "
import sys,json
ws=json.load(sys.stdin)
print(ws[0]['id'] if ws else '')" 2>/dev/null)

if [ -z "$WS_ID" ]; then
    echo "  Creating workspace..."
    WS=$(curl -s --max-time 10 -X POST "$BASE/api/v1/workspaces" \
        -H "$AUTH" -H "Content-Type: application/json" \
        -d '{"name":"Verify Workspace","description":"Verification workspace"}' 2>/dev/null)
    WS_ID=$(echo "$WS" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null)
fi
[ -n "$WS_ID" ] && pass "Workspace: ${WS_ID:0:8}..." || fail "No workspace"

# Step 4: Tool status
echo "[4/8] Tool status..."
TOOLS=$(curl -s --max-time 5 "$BASE/api/v1/tools" -H "$AUTH" 2>/dev/null || echo '{}')
AVAIL=$(echo "$TOOLS" | python3 -c "
import sys,json
d=json.load(sys.stdin)
t=d.get('tools',{})
avail=[k for k,v in t.items() if isinstance(v,dict) and v.get('available')]
print(len(avail))" 2>/dev/null || echo "?")
pass "Tools available: $AVAIL"

# Step 5: Launch scan
echo "[5/8] Launching scan..."
SCAN=$(curl -s --max-time 15 -X POST "$BASE/api/v1/scans" \
    -H "$AUTH" -H "Content-Type: application/json" \
    -d "{
        \"name\": \"verify-$(date +%s)\",
        \"workspace_id\": \"$WS_ID\",
        \"scan_type\": \"recon\",
        \"target\": \"https://$TARGET\",
        \"config\": {\"domain\": \"$TARGET\", \"nuclei\": false}
    }" 2>/dev/null)
SCAN_ID=$(echo "$SCAN" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null)
[ -n "$SCAN_ID" ] && pass "Scan launched: ${SCAN_ID:0:8}..." || fail "Scan creation failed: $SCAN"

# Step 6: Wait for completion
echo "[6/8] Waiting up to ${WAIT}s for scan..."
ELAPSED=0
while [ $ELAPSED -lt $WAIT ]; do
    sleep 5; ELAPSED=$((ELAPSED+5))
    SCAN_STATUS=$(curl -s --max-time 5 "$BASE/api/v1/scans/$SCAN_ID" \
        -H "$AUTH" 2>/dev/null | \
        python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('status','?'))" 2>/dev/null)
    echo -n "  ${ELAPSED}s: $SCAN_STATUS  "
    case "$SCAN_STATUS" in
        completed) echo ""; pass "Scan completed!"; break ;;
        failed)    echo ""; fail "Scan failed" ;;
        running|queued) : ;;
        *) echo "" ;;
    esac
done
echo ""

# Step 7: Verify DB assets
echo "[7/8] Verifying saved assets..."
SCAN_DATA=$(curl -s --max-time 5 "$BASE/api/v1/scans/$SCAN_ID" -H "$AUTH" 2>/dev/null)

SUBS=$(curl -s --max-time 5 "$BASE/api/v1/recon/subdomains?workspace_id=$WS_ID&scan_id=$SCAN_ID&limit=5" \
    -H "$AUTH" 2>/dev/null | python3 -c "
import sys,json; d=json.load(sys.stdin)
print(len(d) if isinstance(d,list) else d.get('total',0))" 2>/dev/null || echo 0)
pass "Subdomains in DB: $SUBS"

URLS=$(curl -s --max-time 5 "$BASE/api/v1/recon/urls?workspace_id=$WS_ID&scan_id=$SCAN_ID&limit=5" \
    -H "$AUTH" 2>/dev/null | python3 -c "
import sys,json; d=json.load(sys.stdin)
print(len(d) if isinstance(d,list) else d.get('total',0))" 2>/dev/null || echo 0)
pass "URLs in DB: $URLS"

VULNS=$(curl -s --max-time 5 "$BASE/api/v1/vulns?workspace_id=$WS_ID" \
    -H "$AUTH" 2>/dev/null | python3 -c "
import sys,json; d=json.load(sys.stdin)
print(len(d) if isinstance(d,list) else d.get('total',0))" 2>/dev/null || echo 0)
pass "Findings in DB: $VULNS"

# Step 8: Generate report
echo "[8/8] Generating report..."
REPORT=$(curl -s --max-time 15 -X POST "$BASE/api/v1/reports/generate/$SCAN_ID?report_type=markdown" \
    -H "$AUTH" -H "Content-Type: application/json" \
    -d '{}' 2>/dev/null)
TASK_ID=$(echo "$REPORT" | python3 -c "import sys,json; print(json.load(sys.stdin).get('task_id',''))" 2>/dev/null)
[ -n "$TASK_ID" ] && pass "Report queued: $TASK_ID" || pass "Report: $REPORT"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  ✓ VERIFICATION COMPLETE                            ║"
echo "╠══════════════════════════════════════════════════════╣"
echo "  Scan ID:     $SCAN_ID"
echo "  Subdomains:  $SUBS"
echo "  URLs:        $URLS"
echo "  Findings:    $VULNS"
echo "  Status:      $SCAN_STATUS"
echo "╚══════════════════════════════════════════════════════╝"
