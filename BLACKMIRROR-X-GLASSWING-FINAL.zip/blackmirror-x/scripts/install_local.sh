#!/usr/bin/env bash
# install_local.sh — First-time local setup for BLACKMIRROR-X
# Works on macOS, Linux, Ubuntu VPS
# Run from the blackmirror-x directory
set -e
cd "$(dirname "$0")/.."

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X GLASSWING — First-Time Setup             ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# Detect OS
OS="$(uname -s)"
ARCH="$(uname -m)"
echo "Platform: $OS $ARCH"

# ── Require Docker ────────────────────────────────────────────
if ! command -v docker &>/dev/null; then
  echo "ERROR: Docker not found. Install from https://docs.docker.com/get-docker/"
  exit 1
fi
if ! docker compose version &>/dev/null 2>&1; then
  echo "ERROR: Docker Compose v2 required. Update Docker Desktop or install plugin."
  exit 1
fi
echo "✓ Docker $(docker --version | cut -d' ' -f3 | tr -d ',')"

# ── Generate .env if missing ──────────────────────────────────
if [ ! -f .env ]; then
  echo ""
  echo "Generating .env from template..."
  cp .env.example .env

  # Generate secrets
  SECRET_KEY=$(openssl rand -hex 32 2>/dev/null || python3 -c "import secrets; print(secrets.token_hex(32))")
  JWT_KEY=$(openssl rand -hex 32 2>/dev/null || python3 -c "import secrets; print(secrets.token_hex(32))")
  PG_PASS=$(openssl rand -hex 16 2>/dev/null || python3 -c "import secrets; print(secrets.token_hex(16))")
  VAULT_KEY=$(openssl rand -hex 32 2>/dev/null || python3 -c "import secrets; print(secrets.token_hex(32))")

  sed -i.bak "s|^SECRET_KEY=.*|SECRET_KEY=$SECRET_KEY|" .env
  sed -i.bak "s|^JWT_SECRET_KEY=.*|JWT_SECRET_KEY=$JWT_KEY|" .env
  sed -i.bak "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=$PG_PASS|" .env
  sed -i.bak "s|^BMX_VAULT_KEY=.*|BMX_VAULT_KEY=$VAULT_KEY|" .env
  # Update DATABASE_URL with new password
  sed -i.bak "s|postgresql+asyncpg://bmx:CHANGE_ME_strong_password|postgresql+asyncpg://bmx:$PG_PASS|g" .env
  sed -i.bak "s|postgresql://bmx:CHANGE_ME_strong_password|postgresql://bmx:$PG_PASS|g" .env
  rm -f .env.bak
  echo "✓ .env generated with secure random secrets"
  echo ""
  echo "  ⚠ IMPORTANT: Set your ANTHROPIC_API_KEY in .env before starting:"
  echo "  echo 'ANTHROPIC_API_KEY=sk-ant-...' >> .env"
  echo ""
fi

# ── Detect SERVER_IP ──────────────────────────────────────────
CURRENT_IP=$(grep "^NEXT_PUBLIC_API_URL" .env | cut -d= -f2 | sed 's|http://||' | cut -d: -f1)
if [ "$CURRENT_IP" = "localhost" ] || [ "$CURRENT_IP" = "127.0.0.1" ]; then
  # Try to detect VPS IP
  VPS_IP=$(curl -sf --max-time 3 https://api.ipify.org 2>/dev/null || echo "")
  if [ -n "$VPS_IP" ] && [ "$VPS_IP" != "127.0.0.1" ]; then
    echo "Detected public IP: $VPS_IP"
    echo -n "Use this IP for the platform URL? [Y/n]: "
    read -r USE_IP
    if [ "$USE_IP" != "n" ] && [ "$USE_IP" != "N" ]; then
      sed -i "s|^NEXT_PUBLIC_API_URL=.*|NEXT_PUBLIC_API_URL=http://$VPS_IP:8000|" .env
      sed -i "s|^NEXT_PUBLIC_WS_URL=.*|NEXT_PUBLIC_WS_URL=ws://$VPS_IP:8000|" .env
      sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://$VPS_IP:3000,http://localhost:3000|" .env
      echo "✓ Configured for http://$VPS_IP:3000"
    fi
  fi
fi

# ── Pull images and build ─────────────────────────────────────
echo ""
echo "Building Docker images (first run takes 5-10 minutes)..."
docker compose build --no-cache backend worker
docker compose build frontend

# ── Start services ────────────────────────────────────────────
echo ""
echo "Starting services..."
docker compose up -d

# ── Wait for backend ──────────────────────────────────────────
echo "Waiting for backend to be ready..."
for i in $(seq 1 40); do
  sleep 3
  if curl -sf http://localhost:8000/health &>/dev/null; then
    echo "✓ Backend ready after $((i*3))s"
    break
  fi
  [ $((i % 5)) -eq 0 ] && echo "  Still starting... ($((i*3))s)"
  [ $i -eq 40 ] && { echo "✗ Backend failed to start"; docker compose logs backend --tail=20; exit 1; }
done

# ── Run migrations + seed ─────────────────────────────────────
echo ""
echo "Running database migrations..."
docker compose exec backend alembic upgrade head

echo "Seeding demo data..."
docker compose exec backend python scripts/seed.py

# ── Show status ───────────────────────────────────────────────
echo ""
FRONTEND_URL=$(grep "^NEXT_PUBLIC_API_URL" .env | cut -d= -f2 | sed 's|:8000|:3000|')

docker compose ps
echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  ✓ BLACKMIRROR-X is running!                            ║"
echo "╠══════════════════════════════════════════════════════════╣"
printf "║  Platform:  %-43s║\n" "$FRONTEND_URL"
echo "║  Login:     admin@blackmirror.io                        ║"
echo "║  Password:  BlackMirrorX2025!                           ║"
echo "║                                                          ║"
printf "║  API Docs:  %-43s║\n" "$(echo $FRONTEND_URL | sed 's|:3000|:8000/api/docs|')"
printf "║  Flower:    %-43s║\n" "$(echo $FRONTEND_URL | sed 's|:3000|:5555|')"
echo "╚══════════════════════════════════════════════════════════╝"
