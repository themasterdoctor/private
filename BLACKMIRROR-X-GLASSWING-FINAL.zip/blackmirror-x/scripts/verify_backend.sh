#!/usr/bin/env bash
# verify_backend.sh — BLACKMIRROR-X backend verification
# Can be run from:
#   - ~/private/blackmirror-x/  (project root)
#   - ~/private/blackmirror-x/backend/
#   - inside Docker container at /app/
#   - docker compose exec backend bash scripts/verify_backend.sh

# Locate project root and backend dir
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# The script lives in: <root>/scripts/ or <root>/backend/scripts/
# Figure out where backend/ is
if [ -f "$SCRIPT_DIR/../app/main.py" ]; then
    # We're in backend/scripts/
    BACKEND_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
elif [ -f "$SCRIPT_DIR/../backend/app/main.py" ]; then
    # We're in project root scripts/
    BACKEND_DIR="$(cd "$SCRIPT_DIR/../backend" && pwd)"
elif [ -f "/app/main.py" ]; then
    # Inside Docker container
    BACKEND_DIR="/app"
elif [ -f "app/main.py" ]; then
    # CWD is backend/
    BACKEND_DIR="$(pwd)"
elif [ -f "backend/app/main.py" ]; then
    # CWD is project root
    BACKEND_DIR="$(pwd)/backend"
else
    echo "ERROR: Cannot locate backend/app/main.py"
    echo "Run from: project root, backend/, or inside Docker container"
    exit 1
fi

cd "$BACKEND_DIR"
echo "Backend dir: $BACKEND_DIR"

PASS=0; FAIL=0
pass() { echo "  ✓ $1"; PASS=$((PASS+1)); }
fail() { echo "  ✗ FAIL: $1"; FAIL=$((FAIL+1)); }

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Backend Verification   ║"
echo "╚══════════════════════════════════════════╝"

# ── 1. Python compile ─────────────────────────────────────────
echo "[1/6] Python compile..."
if python3 -m compileall app -q 2>/dev/null; then
    COUNT=$(find app -name "*.py" | wc -l)
    pass "All $COUNT Python files compile"
else
    fail "Python compile error"
fi

# ── 2. App import + routes ────────────────────────────────────
echo "[2/6] App import + routes..."
ROUTES=$(python3 - << 'PYEOF' 2>/dev/null
import sys, os
sys.path.insert(0, '.')
# Provide minimal env so config loads without crashing
for k, v in {
    'DATABASE_URL': 'postgresql+asyncpg://x:x@localhost/x',
    'REDIS_URL': 'redis://localhost:6379/0',
    'CELERY_BROKER_URL': 'redis://localhost:6379/1',
    'CELERY_RESULT_BACKEND': 'redis://localhost:6379/2',
    'ANTHROPIC_API_KEY': 'test',
    'SECRET_KEY': 'test32chars_aaaaaaaaaaaaaaaaaaaaa',
    'JWT_SECRET_KEY': 'test32chars_aaaaaaaaaaaaaaaaaaaaa',
}.items():
    os.environ.setdefault(k, v)
try:
    from app.main import app
    routes = [r for r in app.routes if hasattr(r, 'path')]
    print(len(routes))
except Exception as e:
    import traceback
    sys.stderr.write(f"ERROR: {e}\n")
    traceback.print_exc(file=sys.stderr)
    print("0")
PYEOF
)
if [ -n "$ROUTES" ] && [ "$ROUTES" -gt 100 ] 2>/dev/null; then
    pass "App imports OK — $ROUTES routes registered"
else
    fail "App import failed (routes=$ROUTES) — check: python3 -c 'from app.main import app'"
fi

# ── 3. SQLAlchemy models ──────────────────────────────────────
echo "[3/6] SQLAlchemy models..."
RESULT=$(python3 - << 'PYEOF' 2>/dev/null
import sys, os
sys.path.insert(0, '.')
os.environ.setdefault('DATABASE_URL', 'postgresql+asyncpg://x:x@localhost/x')
try:
    from app.models.models import (
        User, Workspace, WorkspaceMember, APIKey, Target,
        ScanJob, ScanLog, Subdomain, DiscoveredURL, Vulnerability,
        AgentRun, Report, CopilotMessage, KnowledgeChunk, AuditLog,
        ScanStatus, ScanType, Severity, VulnStatus
    )
    assert User.__tablename__ == 'users'
    assert ScanStatus.QUEUED.value == 'queued'
    print("OK")
except Exception as e:
    import traceback; traceback.print_exc(file=sys.stderr)
    print("FAIL")
PYEOF
)
[ "$RESULT" = "OK" ] && pass "All SQLAlchemy models import and validate" || fail "Model import failed"

# ── 4. Migration chain ────────────────────────────────────────
echo "[4/6] Alembic migration chain..."
MIGS=$(ls alembic/versions/*.py 2>/dev/null | wc -l)
CHAIN=$(python3 - << 'PYEOF' 2>/dev/null
import sys, os
sys.path.insert(0, '.')
os.environ.setdefault('DATABASE_URL', 'postgresql+asyncpg://x:x@localhost/x')
try:
    from alembic.config import Config
    from alembic.script import ScriptDirectory
    cfg = Config('alembic.ini')
    s = ScriptDirectory.from_config(cfg)
    revs = list(s.walk_revisions())
    print(len(revs))
except ImportError:
    print("no_alembic")
except Exception as e:
    print(f"err_{e}")
PYEOF
)
if [ "$MIGS" -ge 4 ] && [[ "$CHAIN" =~ ^[0-9]+$ ]] && [ "$CHAIN" -ge 4 ]; then
    pass "$MIGS migration files, $CHAIN-revision chain valid"
elif [ "$CHAIN" = "no_alembic" ]; then
    pass "$MIGS migration files (alembic not installed locally — OK inside Docker)"
else
    fail "Migration chain issue (files=$MIGS, chain=$CHAIN)"
fi

# ── 5. Security module ────────────────────────────────────────
echo "[5/6] Security module..."
RESULT=$(python3 - << 'PYEOF' 2>/dev/null
import sys, os
sys.path.insert(0, '.')
os.environ.setdefault('JWT_SECRET_KEY', 'test32chars_aaaaaaaaaaaaaaaaaaaaa')
try:
    from app.core.security import hash_password, verify_password, create_access_token, decode_token, generate_api_key, verify_api_key
    assert verify_password('test', hash_password('test'))
    tok = create_access_token('uid-123')
    payload = decode_token(tok)
    assert payload and payload['sub'] == 'uid-123'
    raw, hashed = generate_api_key()
    assert raw.startswith('bmx_')
    assert verify_api_key(raw, hashed)
    print("OK")
except Exception as e:
    import traceback; traceback.print_exc(file=sys.stderr)
    print("FAIL")
PYEOF
)
[ "$RESULT" = "OK" ] && pass "JWT + bcrypt + API keys functional" || fail "Security module broken"

# ── 6. Enterprise modules ─────────────────────────────────────
echo "[6/6] Enterprise modules..."
RESULT=$(python3 - 2>/dev/null << 'PYEOF'
import sys, os, logging
sys.path.insert(0, '.')
# Silence structlog output so only our PASS/FAIL prints
import structlog
structlog.configure(wrapper_class=structlog.make_filtering_bound_logger(logging.CRITICAL))
try:
    from app.enterprise.scope_engine import ScopeEngine, ProgramProfile
    from app.enterprise.confidence_scoring import score_finding
    from app.enterprise.approval_gates import ApprovalGate, list_pending_approvals
    from app.enterprise.payload_library import get_auto_safe_payloads, PAYLOAD_LIBRARY, PayloadTier
    from app.enterprise.plugin_sdk import registry
    from app.enterprise.team_features import check_permission, SLAPolicy
    from app.enterprise.evidence_engine import HttpEvidence, EvidencePackage

    e = ScopeEngine('ws'); e.add_scope('*.example.com')
    assert e.check_target('api.example.com').allowed
    assert not e.check_target('evil.com').allowed
    for vt in ['xss','sqli','ssrf','idor']:
        p = score_finding(vt, 'high')
        assert 0 < p.overall_score <= 1
    safe = get_auto_safe_payloads('sqli')
    assert all(p.tier != PayloadTier.BLOCKED for p in safe)
    assert len(safe) > 0
    assert len(registry.list_plugins()) >= 2
    assert check_permission('admin', 'scan:create')
    assert not check_permission('viewer', 'scan:create')
    ev = HttpEvidence(method='POST', url='https://t.com/api', status_code=200, payload_used="test", indicator_found="alert")
    assert 'curl' in ev.to_curl()
    assert '## Proof' in ev.to_proof_section()
    gate = ApprovalGate('ws-test')
    gate.emergency_stop('admin')
    assert gate.is_emergency_stopped()
    gate.resume_after_stop()
    assert not gate.is_emergency_stopped()
    print("ALL_PASS")
except Exception as e:
    import traceback; traceback.print_exc(file=sys.stderr)
    print(f"FAIL: {e}")
PYEOF
)
[ "$RESULT" = "ALL_PASS" ] && pass "All 7 enterprise modules functional" || fail "Enterprise: $RESULT"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Results: ${PASS} passed, ${FAIL} failed"
[ "$FAIL" -eq 0 ] && echo "✓ BACKEND VERIFICATION: PASS" && exit 0 || echo "✗ BACKEND VERIFICATION: FAIL" && exit 1
