#!/usr/bin/env bash
# fix_and_verify_live.sh
# Tests every critical API action on the live VPS.
# Usage: bash scripts/fix_and_verify_live.sh [BACKEND_URL] [FRONTEND_URL]
# Example: bash scripts/fix_and_verify_live.sh http://76.13.30.226:8000 http://76.13.30.226:3000

set -euo pipefail

BACKEND="${1:-http://76.13.30.226:8000}"
FRONTEND="${2:-http://76.13.30.226:3000}"
EMAIL="admin@blackmirror.io"
PASSWORD="BlackMirrorX2025!"

GREEN='\033[0;32m'; RED='\033[0;31m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok()   { echo -e "  ${GREEN}✓${NC}  $1"; }
fail() { echo -e "  ${RED}✗${NC}  $1"; FAILURES=$((FAILURES+1)); }
info() { echo -e "  ${CYAN}→${NC}  $1"; }

FAILURES=0

echo ""
echo "═══════════════════════════════════════════════════════"
echo "  BLACKMIRROR-X Live Verification"
echo "  Backend:  $BACKEND"
echo "  Frontend: $FRONTEND"
echo "═══════════════════════════════════════════════════════"
echo ""

# ── 1. CORS preflight ─────────────────────────────────────────────────────────
echo "── 1. CORS Preflight ────────────────────────────────────"
CORS_RESP=$(curl -si -X OPTIONS "$BACKEND/api/v1/workspaces" \
  -H "Origin: $FRONTEND" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: authorization,content-type" \
  --max-time 10 2>/dev/null)

CORS_ORIGIN=$(echo "$CORS_RESP" | grep -i "access-control-allow-origin" | head -1 | tr -d '\r')
CORS_STATUS=$(echo "$CORS_RESP" | head -1 | awk '{print $2}')

if echo "$CORS_ORIGIN" | grep -q "$FRONTEND\|*"; then
  ok "CORS preflight: HTTP $CORS_STATUS, $CORS_ORIGIN"
else
  fail "CORS preflight FAILED: HTTP $CORS_STATUS"
  echo "  Expected: Access-Control-Allow-Origin: $FRONTEND"
  echo "  Got: '$CORS_ORIGIN'"
  echo "  Fix: Add CORS_ORIGINS=$FRONTEND to .env and rebuild backend"
fi

# ── 2. Health ──────────────────────────────────────────────────────────────────
echo ""
echo "── 2. Backend Health ────────────────────────────────────"
HEALTH=$(curl -s "$BACKEND/health" --max-time 10 2>/dev/null)
if echo "$HEALTH" | grep -q "healthy"; then
  ok "Backend health: $HEALTH"
else
  fail "Backend not healthy: '$HEALTH'"
fi

# ── 3. Frontend reachable ─────────────────────────────────────────────────────
echo ""
echo "── 3. Frontend ──────────────────────────────────────────"
FE_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$FRONTEND" --max-time 10 2>/dev/null)
if [ "$FE_STATUS" = "200" ] || [ "$FE_STATUS" = "307" ] || [ "$FE_STATUS" = "308" ]; then
  ok "Frontend reachable: HTTP $FE_STATUS"
else
  fail "Frontend not reachable: HTTP $FE_STATUS"
fi

# ── 4. Login ──────────────────────────────────────────────────────────────────
echo ""
echo "── 4. Authentication ────────────────────────────────────"
LOGIN_RESP=$(curl -s -X POST "$BACKEND/api/v1/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "Origin: $FRONTEND" \
  --data-urlencode "username=$EMAIL" \
  --data-urlencode "password=$PASSWORD" \
  --max-time 15 2>/dev/null)

TOKEN=$(echo "$LOGIN_RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('access_token',''))" 2>/dev/null || echo "")

if [ -n "$TOKEN" ] && [ "$TOKEN" != "None" ]; then
  ok "Login: token received (${TOKEN:0:20}...)"
else
  fail "Login FAILED"
  echo "  Response: $LOGIN_RESP"
  exit 1
fi

# ── 5. Auth /me ───────────────────────────────────────────────────────────────
ME=$(curl -s "$BACKEND/api/v1/auth/me" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Origin: $FRONTEND" \
  --max-time 10 2>/dev/null)
EMAIL_GOT=$(echo "$ME" | python3 -c "import sys,json; print(json.load(sys.stdin).get('email','FAIL'))" 2>/dev/null || echo "FAIL")
if [ "$EMAIL_GOT" = "$EMAIL" ]; then
  ok "GET /auth/me: $EMAIL_GOT"
else
  fail "GET /auth/me failed: $ME"
fi

# ── 6. List workspaces ────────────────────────────────────────────────────────
echo ""
echo "── 5. Workspaces ────────────────────────────────────────"
WS_LIST=$(curl -s "$BACKEND/api/v1/workspaces" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Origin: $FRONTEND" \
  --max-time 10 2>/dev/null)
WS_COUNT=$(echo "$WS_LIST" | python3 -c "import sys,json; print(len(json.load(sys.stdin)))" 2>/dev/null || echo "0")
ok "GET /workspaces: $WS_COUNT workspace(s)"

# ── 7. Create workspace ───────────────────────────────────────────────────────
TS=$(date +%s)
WS_RESP=$(curl -s -X POST "$BACKEND/api/v1/workspaces" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -H "Origin: $FRONTEND" \
  -d "{\"name\":\"Verify Test $TS\",\"description\":\"Created by fix_and_verify_live.sh\"}" \
  --max-time 15 2>/dev/null)
WS_ID=$(echo "$WS_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null || echo "")
WS_NAME=$(echo "$WS_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin).get('name',''))" 2>/dev/null || echo "")

if [ -n "$WS_ID" ]; then
  ok "POST /workspaces: created '$WS_NAME' (${WS_ID:0:8})"
else
  fail "POST /workspaces FAILED"
  echo "  Response: $WS_RESP"
fi

# Use the workspace we just created (or first existing one)
if [ -z "$WS_ID" ]; then
  WS_ID=$(echo "$WS_LIST" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d[0]['id'] if d else '')" 2>/dev/null || echo "")
  WS_NAME=$(echo "$WS_LIST" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d[0]['name'] if d else '')" 2>/dev/null || echo "")
fi
info "Using workspace: '$WS_NAME' (${WS_ID:0:8})"

# ── 8. Create scan ────────────────────────────────────────────────────────────
echo ""
echo "── 6. Scan Creation ─────────────────────────────────────"
SCAN_RESP=$(curl -s -X POST "$BACKEND/api/v1/scans" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -H "Origin: $FRONTEND" \
  -d "{\"name\":\"Verify Scan $TS\",\"workspace_id\":\"$WS_ID\",\"scan_type\":\"recon\",\"config\":{\"domain\":\"localhost\"}}" \
  --max-time 15 2>/dev/null)
SCAN_ID=$(echo "$SCAN_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null || echo "")
SCAN_STATUS=$(echo "$SCAN_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin).get('status',''))" 2>/dev/null || echo "")

if [ -n "$SCAN_ID" ]; then
  ok "POST /scans: created (${SCAN_ID:0:8}), status=$SCAN_STATUS"
else
  fail "POST /scans FAILED"
  echo "  Response: $SCAN_RESP"
fi

# ── 9. List scans ─────────────────────────────────────────────────────────────
SCAN_LIST=$(curl -s "$BACKEND/api/v1/scans?workspace_id=$WS_ID" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Origin: $FRONTEND" \
  --max-time 10 2>/dev/null)
SCAN_COUNT=$(echo "$SCAN_LIST" | python3 -c "import sys,json; print(len(json.load(sys.stdin)))" 2>/dev/null || echo "0")
ok "GET /scans: $SCAN_COUNT scan(s) in workspace"

# Verify scan has target field
HAS_TARGET=$(echo "$SCAN_LIST" | python3 -c "
import sys,json
d=json.load(sys.stdin)
if d and 'target' in d[0]: print('YES')
else: print('NO')
" 2>/dev/null || echo "NO")
if [ "$HAS_TARGET" = "YES" ]; then
  ok "Scan response has 'target' field (required for dashboard display)"
else
  fail "Scan response missing 'target' field"
fi

# ── 10. Cancel scan ───────────────────────────────────────────────────────────
if [ -n "$SCAN_ID" ]; then
  CANCEL_RESP=$(curl -s -X POST "$BACKEND/api/v1/scans/$SCAN_ID/cancel" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Origin: $FRONTEND" \
    --max-time 10 2>/dev/null)
  ok "POST /scans/:id/cancel: done"
fi

# ── 11. Generate report ───────────────────────────────────────────────────────
echo ""
echo "── 7. Reports ───────────────────────────────────────────"
if [ -n "$SCAN_ID" ]; then
  RPT_RESP=$(curl -s -X POST "$BACKEND/api/v1/reports/generate/$SCAN_ID" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -H "Origin: $FRONTEND" \
    -d '{"format":"markdown"}' \
    --max-time 20 2>/dev/null)
  RPT_STATUS=$(echo "$RPT_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin).get('status',''))" 2>/dev/null || echo "")
  if [ -n "$RPT_STATUS" ]; then
    ok "POST /reports/generate: status=$RPT_STATUS"
  else
    fail "POST /reports/generate FAILED: $RPT_RESP"
  fi
fi

# ── 12. CORS on error response ────────────────────────────────────────────────
echo ""
echo "── 8. CORS on Error Responses ───────────────────────────"
ERR_RESP=$(curl -si "$BACKEND/api/v1/workspaces" \
  -H "Origin: $FRONTEND" \
  --max-time 10 2>/dev/null)
ERR_STATUS=$(echo "$ERR_RESP" | head -1 | awk '{print $2}')
ERR_CORS=$(echo "$ERR_RESP" | grep -i "access-control-allow-origin" | head -1 | tr -d '\r')
if [ -n "$ERR_CORS" ]; then
  ok "CORS header on 401 response: $ERR_CORS"
else
  fail "CORS header MISSING on 401 response — browser will block this"
fi

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo "═══════════════════════════════════════════════════════"
if [ "$FAILURES" -eq 0 ]; then
  echo -e "  ${GREEN}ALL CHECKS PASSED${NC} — App is functional"
  echo ""
  echo "  Login:    $EMAIL / $PASSWORD"
  echo "  Workspace: $WS_NAME ($WS_ID)"
  echo "  Scan ID:   $SCAN_ID"
else
  echo -e "  ${RED}$FAILURES CHECK(S) FAILED${NC}"
  echo ""
  echo "  To fix CORS on VPS:"
  echo "  1. Edit .env: CORS_ORIGINS=http://76.13.30.226:3000,http://localhost:3000"
  echo "  2. Rebuild:   docker compose build --no-cache backend"
  echo "  3. Restart:   docker compose up -d backend"
  echo ""
  echo "  To fix frontend API URL:"
  echo "  1. Edit .env: NEXT_PUBLIC_API_URL=http://76.13.30.226:8000"
  echo "  2. Rebuild:   docker compose build --no-cache frontend"
  echo "  3. Restart:   docker compose up -d frontend"
fi
echo "═══════════════════════════════════════════════════════"
echo ""
exit $FAILURES
