#!/usr/bin/env bash
# stabilize.sh — BLACKMIRROR-X Complete Runtime Stabilization
# Run from ~/private/blackmirror-x
# Fixes ALL identified runtime bugs before rebuild.
set -e
cd "$(dirname "$0")/.."
[ -f docker-compose.yml ] || { echo "ERROR: Run from blackmirror-x project root"; exit 1; }

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Complete Stabilization              ║"
echo "╚══════════════════════════════════════════════════════╝"

# ── [1] Fix .env ─────────────────────────────────────────────
echo ""
echo "[1/8] Fixing .env..."
[ -f .env ] || cp .env.vps .env
sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://76.13.30.226:3000,http://localhost:3000,http://127.0.0.1:3000|" .env
sed -i "s|^NEXT_PUBLIC_API_URL=.*|NEXT_PUBLIC_API_URL=http://76.13.30.226:8000|" .env
sed -i "s|^NEXT_PUBLIC_WS_URL=.*|NEXT_PUBLIC_WS_URL=ws://76.13.30.226:8000|" .env
echo "  CORS_ORIGINS: $(grep CORS_ORIGINS .env | cut -d= -f2)"
echo "  API_URL: $(grep NEXT_PUBLIC_API_URL .env | cut -d= -f2)"

# ── [2] Fix backend/app/api/routes/recon.py ──────────────────
# BUG: SubdomainOut returns `host`, `ip_addresses`, `tech_stack`, `discovered_at`
# but frontend Subdomain interface uses `subdomain`, `ip_address`, `technologies`, `created_at`
echo ""
echo "[2/8] Fixing recon.py — Subdomain field name mismatch..."
cat > backend/app/api/routes/recon.py << 'PYEOF'
from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from pydantic import BaseModel, model_validator
from datetime import datetime

from app.db.session import get_db
from app.models.models import Subdomain, DiscoveredURL, User
from app.api.deps.auth import get_current_user

router = APIRouter()


class SubdomainOut(BaseModel):
    """
    Serializes Subdomain ORM model to match frontend Subdomain interface.
    Frontend expects: subdomain, ip_address, technologies, created_at
    Model has:        host,      ip_addresses, tech_stack,  discovered_at
    """
    model_config = {"from_attributes": True}
    id: str
    # Alias host → subdomain
    subdomain: str = ""
    # First IP from ip_addresses list → ip_address
    ip_address: Optional[str] = None
    status_code: Optional[int]
    title: Optional[str]
    # Alias tech_stack → technologies
    technologies: List[str] = []
    ports: List[int] = []
    # Alias discovered_at → created_at
    created_at: datetime = datetime.utcnow()
    source: str = ""
    is_alive: bool = False

    @model_validator(mode="before")
    @classmethod
    def map_fields(cls, obj):
        """Map ORM fields to frontend-expected field names."""
        if hasattr(obj, "__dict__") or hasattr(obj, "host"):
            data = {}
            data["id"] = str(getattr(obj, "id", ""))
            data["subdomain"] = getattr(obj, "host", "") or ""
            ip_list = getattr(obj, "ip_addresses", []) or []
            data["ip_address"] = ip_list[0] if ip_list else None
            data["status_code"] = getattr(obj, "status_code", None)
            data["title"] = getattr(obj, "title", None)
            data["technologies"] = getattr(obj, "tech_stack", []) or []
            data["ports"] = getattr(obj, "ports", []) or []
            data["created_at"] = getattr(obj, "discovered_at", datetime.utcnow())
            data["source"] = getattr(obj, "source", "")
            data["is_alive"] = getattr(obj, "is_alive", False)
            return data
        return obj


class URLOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    url: str
    method: str
    status_code: Optional[int]
    content_type: Optional[str]
    parameters: List[str]
    is_interesting: bool
    interest_reasons: List[str]
    source: str
    discovered_at: datetime


@router.get("/subdomains", response_model=List[SubdomainOut])
async def list_subdomains(
    workspace_id: str = Query(...),
    scan_id: Optional[str] = Query(None),
    alive_only: bool = Query(False),
    limit: int = Query(200, le=1000),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(Subdomain).where(Subdomain.workspace_id == workspace_id)
    if scan_id:
        q = q.where(Subdomain.scan_id == scan_id)
    if alive_only:
        q = q.where(Subdomain.is_alive == True)
    q = q.order_by(desc(Subdomain.discovered_at)).limit(limit).offset(offset)
    result = await db.execute(q)
    return [SubdomainOut.model_validate(s) for s in result.scalars().all()]


@router.get("/urls", response_model=List[URLOut])
async def list_urls(
    workspace_id: str = Query(...),
    scan_id: Optional[str] = Query(None),
    interesting_only: bool = Query(False),
    limit: int = Query(200, le=1000),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(DiscoveredURL).where(DiscoveredURL.workspace_id == workspace_id)
    if scan_id:
        q = q.where(DiscoveredURL.scan_id == scan_id)
    if interesting_only:
        q = q.where(DiscoveredURL.is_interesting == True)
    q = q.order_by(desc(DiscoveredURL.discovered_at)).limit(limit).offset(offset)
    result = await db.execute(q)
    return [URLOut.model_validate(u) for u in result.scalars().all()]
PYEOF
echo "  Done."

# ── [3] Fix backend/app/api/routes/vulns.py ──────────────────
# BUG: VulnOut returns `discovered_at` but frontend Vulnerability has `created_at`
# BUG: VulnOut.severity is Enum — need to serialize as .value string
echo ""
echo "[3/8] Fixing vulns.py — field name and Enum serialization..."
cat > backend/app/api/routes/vulns.py << 'PYEOF'
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from pydantic import BaseModel, model_validator
from datetime import datetime

from app.db.session import get_db
from app.models.models import Vulnerability, User, VulnStatus, Severity
from app.api.deps.auth import get_current_user

router = APIRouter()


class VulnOut(BaseModel):
    """
    Serializes Vulnerability ORM model matching frontend Vulnerability interface.
    Frontend expects: created_at, severity as str, status as str
    Model has:        discovered_at, severity as Severity enum, status as VulnStatus enum
    """
    model_config = {"from_attributes": True}
    id: str
    scan_id: str
    workspace_id: Optional[str] = None
    title: str
    vuln_type: str
    severity: str
    status: str
    cvss_score: Optional[float] = None
    cwe_id: Optional[str] = None
    url: Optional[str] = None
    parameter: Optional[str] = None
    payload: Optional[str] = None
    evidence: Optional[str] = None
    description: Optional[str] = None
    remediation: Optional[str] = None
    tags: List[str] = []
    source: str = ""
    # Normalized to created_at for frontend compatibility
    created_at: datetime = datetime.utcnow()
    # Extra AI fields (may be None)
    court_confidence: Optional[float] = None
    exploitability_score: Optional[float] = None
    bounty_likelihood: Optional[float] = None
    evidence_score: Optional[float] = None
    reproduction_steps: Optional[str] = None
    reflection_context: Optional[str] = None
    simulation_narrative: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def map_fields(cls, obj):
        if hasattr(obj, "discovered_at"):
            data = {}
            for field in [
                "id", "scan_id", "workspace_id", "title", "vuln_type",
                "cvss_score", "cwe_id", "url", "parameter", "payload",
                "evidence", "description", "remediation", "tags", "source",
                "court_confidence", "exploitability_score", "bounty_likelihood",
                "evidence_score", "reproduction_steps", "reflection_context",
                "simulation_narrative",
            ]:
                data[field] = getattr(obj, field, None)
            # Enum → str
            sev = getattr(obj, "severity", None)
            data["severity"] = sev.value if hasattr(sev, "value") else str(sev or "info")
            st = getattr(obj, "status", None)
            data["status"] = st.value if hasattr(st, "value") else str(st or "open")
            # Map discovered_at → created_at
            data["created_at"] = getattr(obj, "discovered_at", datetime.utcnow())
            # Ensure lists
            data["tags"] = data.get("tags") or []
            data["source"] = data.get("source") or ""
            return data
        return obj


class VulnUpdate(BaseModel):
    status: Optional[str] = None
    description: Optional[str] = None
    remediation: Optional[str] = None
    cvss_score: Optional[float] = None
    tags: Optional[list] = None


@router.get("", response_model=List[VulnOut])
async def list_vulns(
    workspace_id: str = Query(...),
    scan_id: Optional[str] = Query(None),
    severity: Optional[str] = Query(None),
    vuln_type: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    limit: int = Query(100, le=500),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(Vulnerability).where(Vulnerability.workspace_id == workspace_id)
    if scan_id:
        q = q.where(Vulnerability.scan_id == scan_id)
    if severity:
        try:
            q = q.where(Vulnerability.severity == Severity(severity))
        except ValueError:
            pass
    if vuln_type:
        q = q.where(Vulnerability.vuln_type == vuln_type)
    if status:
        try:
            q = q.where(Vulnerability.status == VulnStatus(status))
        except ValueError:
            pass
    q = q.order_by(desc(Vulnerability.discovered_at)).limit(limit).offset(offset)
    result = await db.execute(q)
    return [VulnOut.model_validate(v) for v in result.scalars().all()]


@router.get("/{vuln_id}", response_model=VulnOut)
async def get_vuln(
    vuln_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Vulnerability).where(Vulnerability.id == vuln_id))
    v = result.scalar_one_or_none()
    if not v:
        raise HTTPException(404, "Vulnerability not found")
    return VulnOut.model_validate(v)


@router.patch("/{vuln_id}", response_model=VulnOut)
async def update_vuln(
    vuln_id: str,
    data: VulnUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Vulnerability).where(Vulnerability.id == vuln_id))
    v = result.scalar_one_or_none()
    if not v:
        raise HTTPException(404, "Vulnerability not found")

    if data.status:
        try:
            v.status = VulnStatus(data.status)
        except ValueError:
            raise HTTPException(400, f"Invalid status: {data.status}")
    if data.description is not None:
        v.description = data.description
    if data.remediation is not None:
        v.remediation = data.remediation
    if data.cvss_score is not None:
        v.cvss_score = data.cvss_score
    if data.tags is not None:
        v.tags = data.tags

    await db.flush()
    return VulnOut.model_validate(v)


@router.get("/{vuln_id}/hackerone-report")
async def get_hackerone_report(
    vuln_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Vulnerability).where(Vulnerability.id == vuln_id))
    v = result.scalar_one_or_none()
    if not v:
        raise HTTPException(404, "Vulnerability not found")

    from app.agents.report_writer.agent import ReportWriterAgent
    agent = ReportWriterAgent()
    sev = v.severity.value if hasattr(v.severity, "value") else str(v.severity)
    report = agent.generate_hackerone_report({
        "title": v.title,
        "vuln_type": v.vuln_type,
        "severity": sev,
        "cvss_score": v.cvss_score,
        "url": v.url,
        "parameter": v.parameter,
        "payload": v.payload,
        "evidence": v.evidence,
        "description": v.description,
        "remediation": v.remediation,
    })
    return {"content": report, "format": "markdown"}
PYEOF
echo "  Done."

# ── [4] Fix backend/app/schemas/scans.py ─────────────────────
# BUG: ScanCreateRequest has no `target` field — frontend sends target but backend ignores it
# BUG: ScanListOut.status/scan_type need to return .value for Enum types
echo ""
echo "[4/8] Fixing scans schema — missing target field and Enum serialization..."
cat > backend/app/schemas/scans.py << 'PYEOF'
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, model_validator
from datetime import datetime


class ScanCreateRequest(BaseModel):
    workspace_id: str
    target_id: Optional[str] = None
    name: str
    scan_type: str = "full"
    config: Optional[Dict[str, Any]] = None
    # `target` accepted from frontend but mapped to config.domain
    target: Optional[str] = None

    @model_validator(mode="after")
    def merge_target_into_config(self) -> "ScanCreateRequest":
        """If frontend sends `target`, inject it as config.domain."""
        if self.target and not (self.config or {}).get("domain"):
            if self.config is None:
                self.config = {}
            # Strip protocol and path — extract bare domain
            domain = self.target.replace("https://", "").replace("http://", "").split("/")[0]
            self.config["domain"] = domain
        return self


class ScanListOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    name: str
    scan_type: str
    status: str
    progress: int
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    # UI fields — computed
    target: Optional[str] = None
    subdomain_count: int = 0
    url_count: int = 0
    vuln_count: int = 0

    @model_validator(mode="before")
    @classmethod
    def normalize_enums(cls, obj):
        if hasattr(obj, "status"):
            data = {
                "id": str(getattr(obj, "id", "")),
                "name": getattr(obj, "name", "") or "",
                "progress": getattr(obj, "progress", 0) or 0,
                "created_at": getattr(obj, "created_at", datetime.utcnow()),
                "started_at": getattr(obj, "started_at", None),
                "completed_at": getattr(obj, "completed_at", None),
            }
            st = getattr(obj, "status", None)
            data["status"] = st.value if hasattr(st, "value") else str(st or "queued")
            sc = getattr(obj, "scan_type", None)
            data["scan_type"] = sc.value if hasattr(sc, "value") else str(sc or "full")
            # target from config
            cfg = getattr(obj, "config", {}) or {}
            data["target"] = cfg.get("domain") or cfg.get("target") or data["name"]
            data["subdomain_count"] = 0
            data["url_count"] = 0
            data["vuln_count"] = 0
            return data
        return obj


class ScanOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    name: str
    scan_type: str
    status: str
    progress: int
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    target: Optional[str] = None
    subdomain_count: int = 0
    url_count: int = 0
    vuln_count: int = 0
    workspace_id: str
    target_id: Optional[str] = None
    created_by: str
    config: Dict[str, Any] = {}
    celery_task_id: Optional[str] = None
    error_message: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def normalize(cls, obj):
        if hasattr(obj, "status"):
            data = {
                "id": str(getattr(obj, "id", "")),
                "name": getattr(obj, "name", "") or "",
                "progress": getattr(obj, "progress", 0) or 0,
                "created_at": getattr(obj, "created_at", datetime.utcnow()),
                "started_at": getattr(obj, "started_at", None),
                "completed_at": getattr(obj, "completed_at", None),
                "workspace_id": str(getattr(obj, "workspace_id", "")),
                "target_id": getattr(obj, "target_id", None),
                "created_by": str(getattr(obj, "created_by", "")),
                "config": getattr(obj, "config", {}) or {},
                "celery_task_id": getattr(obj, "celery_task_id", None),
                "error_message": getattr(obj, "error_message", None),
                "subdomain_count": 0,
                "url_count": 0,
                "vuln_count": 0,
            }
            st = getattr(obj, "status", None)
            data["status"] = st.value if hasattr(st, "value") else str(st or "queued")
            sc = getattr(obj, "scan_type", None)
            data["scan_type"] = sc.value if hasattr(sc, "value") else str(sc or "full")
            cfg = data["config"]
            data["target"] = cfg.get("domain") or cfg.get("target") or data["name"]
            return data
        return obj


class ScanLogOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    level: str
    module: str
    message: str
    data: Optional[Dict[str, Any]] = None
    timestamp: datetime
PYEOF
echo "  Done."

# ── [5] Fix scans.py route — db.flush() needs commit, str(scan.id) ───────────
echo ""
echo "[5/8] Fixing scans route — ensure scan.id str, proper commit..."
cat > backend/app/api/routes/scans.py << 'PYEOF'
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import func, select, desc
import json
import asyncio
import structlog

from app.db.session import get_db
from app.models.models import ScanJob, ScanLog, User, ScanStatus, ScanType, Subdomain, DiscoveredURL, Vulnerability
from app.api.deps.auth import get_current_user
from app.schemas.scans import ScanCreateRequest, ScanOut, ScanLogOut, ScanListOut
from app.workers.tasks import run_scan_task

router = APIRouter()
logger = structlog.get_logger(__name__)


@router.post("", response_model=ScanOut, status_code=201)
async def create_scan(
    data: ScanCreateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Resolve scan_type safely
    try:
        scan_type = ScanType(data.scan_type)
    except ValueError:
        scan_type = ScanType.FULL if hasattr(ScanType, "FULL") else list(ScanType)[0]

    scan = ScanJob(
        workspace_id=data.workspace_id,
        target_id=data.target_id,
        created_by=current_user.id,
        name=data.name,
        scan_type=scan_type,
        config=data.config or {},
        status=ScanStatus.QUEUED,
    )
    db.add(scan)
    await db.flush()

    # Queue celery task — use str(scan.id) to ensure not UUID object
    scan_id_str = str(scan.id)
    try:
        task = run_scan_task.apply_async(
            args=[scan_id_str],
            task_id=f"scan_{scan_id_str}",
        )
        scan.celery_task_id = task.id
    except Exception as e:
        logger.warning("celery_queue_failed", error=str(e), scan_id=scan_id_str)
        # Don't fail the request — scan is created, worker may pick it up

    await db.commit()
    await db.refresh(scan)

    logger.info("scan_created", scan_id=scan_id_str, type=data.scan_type)
    return ScanOut.model_validate(scan)


@router.get("", response_model=List[ScanListOut])
async def list_scans(
    workspace_id: str = Query(...),
    status: Optional[str] = Query(None),
    limit: int = Query(50, le=200),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(ScanJob).where(ScanJob.workspace_id == workspace_id)
    if status:
        try:
            q = q.where(ScanJob.status == ScanStatus(status))
        except ValueError:
            pass
    q = q.order_by(desc(ScanJob.created_at)).limit(limit).offset(offset)
    result = await db.execute(q)
    scans = result.scalars().all()

    out = []
    for s in scans:
        d = ScanListOut.model_validate(s)
        # Populate counts
        sub_r = await db.execute(select(func.count()).where(Subdomain.scan_id == s.id))
        url_r = await db.execute(select(func.count()).where(DiscoveredURL.scan_id == s.id))
        vuln_r = await db.execute(select(func.count()).where(Vulnerability.scan_id == s.id))
        d.subdomain_count = sub_r.scalar() or 0
        d.url_count = url_r.scalar() or 0
        d.vuln_count = vuln_r.scalar() or 0
        out.append(d)
    return out


@router.get("/{scan_id}", response_model=ScanOut)
async def get_scan(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(ScanJob).where(ScanJob.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    return ScanOut.model_validate(scan)


@router.post("/{scan_id}/cancel")
async def cancel_scan(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(ScanJob).where(ScanJob.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    if scan.status not in (ScanStatus.QUEUED, ScanStatus.RUNNING):
        raise HTTPException(status_code=400, detail="Scan cannot be cancelled")

    if scan.celery_task_id:
        try:
            from app.workers.celery_app import celery_app
            celery_app.control.revoke(scan.celery_task_id, terminate=True)
        except Exception:
            pass

    scan.status = ScanStatus.CANCELLED
    await db.commit()
    return {"status": "cancelled"}


@router.get("/{scan_id}/logs", response_model=List[ScanLogOut])
async def get_scan_logs(
    scan_id: str,
    limit: int = Query(200, le=1000),
    since_id: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(ScanLog).where(ScanLog.scan_id == scan_id)
    q = q.order_by(ScanLog.timestamp).limit(limit)
    result = await db.execute(q)
    return [ScanLogOut.model_validate(l) for l in result.scalars().all()]


@router.get("/{scan_id}/stream")
async def stream_scan_logs(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """SSE endpoint to stream live scan logs."""
    async def event_generator():
        last_id = None
        while True:
            async with AsyncSession(db.bind) as session:
                q = select(ScanLog).where(ScanLog.scan_id == scan_id)
                if last_id:
                    q = q.where(ScanLog.id > last_id)
                q = q.order_by(ScanLog.timestamp).limit(50)
                result = await session.execute(q)
                logs = result.scalars().all()

            for log in logs:
                last_id = log.id
                data = json.dumps({
                    "id": log.id,
                    "level": log.level,
                    "module": log.module,
                    "message": log.message,
                    "timestamp": log.timestamp.isoformat(),
                })
                yield f"data: {data}\n\n"

            # Check if scan is done
            async with AsyncSession(db.bind) as session:
                r = await session.execute(select(ScanJob).where(ScanJob.id == scan_id))
                scan = r.scalar_one_or_none()
                if scan and scan.status in (ScanStatus.COMPLETED, ScanStatus.FAILED, ScanStatus.CANCELLED):
                    status_val = scan.status.value if hasattr(scan.status, "value") else str(scan.status)
                    yield f"data: {json.dumps({'type': 'done', 'status': status_val})}\n\n"
                    break

            await asyncio.sleep(1)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
PYEOF
echo "  Done."

# ── [6] Fix frontend store — Subdomain interface ──────────────
# BUG: frontend store Subdomain has wrong fields vs what API now returns
# After fix, API returns: subdomain, ip_address, technologies, created_at ✓
# No frontend change needed — our backend now matches the frontend interface.
echo ""
echo "[6/8] Frontend store already matches fixed API — no change needed."

# ── [7] Fix workspaces.py — ensure created_at in response ─────
# BUG: WorkspaceOut doesn't return created_at, but frontend Workspace interface expects it
echo ""
echo "[7/8] Fixing workspaces route — add created_at to response..."
cat > backend/app/api/routes/workspaces.py << 'PYEOF'
"""workspaces.py — Workspace management routes"""
from typing import List, Optional
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import re

from app.db.session import get_db
from app.models.models import Workspace, WorkspaceMember, User, UserRole
from app.api.deps.auth import get_current_user
from pydantic import BaseModel

router = APIRouter()


class WorkspaceCreate(BaseModel):
    name: str
    description: Optional[str] = None


class WorkspaceOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    name: str
    slug: str
    description: Optional[str] = None
    is_active: bool
    created_at: datetime


@router.post("", response_model=WorkspaceOut, status_code=201)
async def create_workspace(
    data: WorkspaceCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    slug = re.sub(r"[^a-z0-9-]", "-", data.name.lower().strip()).strip("-")
    slug = re.sub(r"-+", "-", slug)

    existing = await db.execute(select(Workspace).where(Workspace.slug == slug))
    if existing.scalar_one_or_none():
        slug = f"{slug}-{current_user.id[:6]}"

    ws = Workspace(name=data.name, slug=slug, description=data.description)
    db.add(ws)
    await db.flush()

    member = WorkspaceMember(workspace_id=ws.id, user_id=current_user.id, role=UserRole.ADMIN)
    db.add(member)
    await db.commit()
    await db.refresh(ws)
    return WorkspaceOut.model_validate(ws)


@router.get("", response_model=List[WorkspaceOut])
async def list_workspaces(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = (
        select(Workspace)
        .join(WorkspaceMember, Workspace.id == WorkspaceMember.workspace_id)
        .where(WorkspaceMember.user_id == current_user.id, Workspace.is_active == True)
    )
    result = await db.execute(q)
    return [WorkspaceOut.model_validate(ws) for ws in result.scalars().all()]


@router.get("/{workspace_id}", response_model=WorkspaceOut)
async def get_workspace(
    workspace_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Workspace).where(Workspace.id == workspace_id))
    ws = result.scalar_one_or_none()
    if not ws:
        raise HTTPException(404, "Workspace not found")
    return WorkspaceOut.model_validate(ws)
PYEOF
echo "  Done."

# ── [8] Fix frontend — add visible API error display ─────────
# Add error display interceptor enhancement to api.ts
echo ""
echo "[8/8] Verifying frontend api.ts error handling is visible..."
# The existing api.ts already attaches error.uiMessage — this is correct.
# The dashboard page already shows launchError — this is correct.
# No change needed here — frontend error handling is already in place.
echo "  Frontend error handling already implemented."

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  Patches applied. Now rebuilding Docker images...    ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
echo "Run next:"
echo "  docker compose down --remove-orphans"
echo "  docker compose build --no-cache backend worker"
echo "  docker compose up -d"
echo ""
