#!/usr/bin/env bash
# verify_vulnweb_detection.sh — Verify vulnerability detection
# Uses local testlab (always reachable) or testphp.vulnweb.com if available
set -euo pipefail

BASE="${BASE:-http://localhost:8000}"
EMAIL="${EMAIL:-admin@blackmirror.io}"
PASS="${PASS:-BlackMirrorX2025!}"
WAIT="${WAIT:-180}"

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  GLASSWING — Vulnerability Detection Verification          ║"
echo "╚══════════════════════════════════════════════════════════════╝"

# Pick target: testlab if vulnweb unreachable
if curl -sf --max-time 5 http://testphp.vulnweb.com/ >/dev/null 2>&1; then
    TARGET="https://testphp.vulnweb.com"
    DOMAIN="testphp.vulnweb.com"
    echo "  Target: $TARGET (Acunetix authorized)"
elif curl -sf --max-time 3 http://localhost:9001/ >/dev/null 2>&1; then
    TARGET="http://localhost:9001"
    DOMAIN="localhost:9001"
    echo "  Target: $TARGET (local testlab)"
else
    echo "  ✗ No target reachable. Start testlab: docker compose -f docker-compose.testlab.yml up -d"
    exit 1
fi
echo ""

fail() { echo "  ✗ $1"; exit 1; }
ok()   { echo "  ✓ $1"; }

echo "[1/8] Health..."
H=$(curl -sf "$BASE/health" 2>/dev/null || fail "Backend down")
[ "$(echo "$H"|python3 -c "import sys,json;print(json.load(sys.stdin).get('status',''))" 2>/dev/null)" = "healthy" ] && ok "healthy" || fail "unhealthy"

echo "[2/8] Login..."
R=$(curl -s -X POST "$BASE/api/v1/auth/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "username=$EMAIL&password=$PASS")
TOKEN=$(echo "$R"|python3 -c "import sys,json;print(json.load(sys.stdin).get('access_token',''))" 2>/dev/null)
[ -n "$TOKEN" ] && ok "Login OK" || fail "Login failed"
AUTH="Authorization: Bearer $TOKEN"

echo "[3/8] Workspace..."
WS=$(curl -s "$BASE/api/v1/workspaces" -H "$AUTH" | \
    python3 -c "import sys,json; ws=json.load(sys.stdin); print(ws[0]['id'] if ws else '')" 2>/dev/null)
[ -n "$WS" ] && ok "${WS:0:8}..." || fail "No workspace"

echo "[4/8] Launch scan..."
SCAN=$(curl -s -X POST "$BASE/api/v1/scans" \
    -H "$AUTH" -H "Content-Type: application/json" \
    -d "{\"name\":\"vuln-verify-$(date +%s)\",\"workspace_id\":\"$WS\",
         \"scan_type\":\"recon\",\"target\":\"$TARGET\",
         \"config\":{\"domain\":\"$DOMAIN\",\"nuclei\":false}}")
SCAN_ID=$(echo "$SCAN"|python3 -c "import sys,json;print(json.load(sys.stdin).get('id',''))" 2>/dev/null)
[ -n "$SCAN_ID" ] && ok "Scan: ${SCAN_ID:0:8}..." || fail "Launch failed: $SCAN"

echo "[5/8] Waiting up to ${WAIT}s..."
STATUS="unknown"
for i in $(seq 1 $((WAIT/5))); do
    sleep 5
    D=$(curl -s "$BASE/api/v1/scans/$SCAN_ID" -H "$AUTH" 2>/dev/null)
    STATUS=$(echo "$D"|python3 -c "import sys,json;print(json.load(sys.stdin).get('status','?'))" 2>/dev/null)
    PROG=$(echo "$D"|python3 -c "import sys,json;print(json.load(sys.stdin).get('progress',0))" 2>/dev/null)
    echo -n "  $((i*5))s: $STATUS ($PROG%) "
    [ "$STATUS" = "completed" ] && { echo "✓"; break; }
    [ "$STATUS" = "failed" ]    && { echo "✗"; break; }
    echo ""
done
echo ""

echo "[6/8] URLs..."
URLS=$(curl -s "$BASE/api/v1/recon/urls?workspace_id=$WS&scan_id=$SCAN_ID&limit=5" \
    -H "$AUTH"|python3 -c "import sys,json;d=json.load(sys.stdin);print(len(d) if isinstance(d,list) else 0)" 2>/dev/null||echo 0)
ok "$URLS URLs discovered"

echo "[7/8] Findings..."
VULNS=$(curl -s "$BASE/api/v1/vulns?workspace_id=$WS" -H "$AUTH")
COUNT=$(echo "$VULNS"|python3 -c "
import sys,json
d=json.load(sys.stdin)
vulns=d if isinstance(d,list) else []
print(len(vulns))
for v in vulns[:5]:
    print(f'  [{v.get(\"severity\",\"?\").upper()}] {v.get(\"title\",\"?\")}')
    print(f'    url: {v.get(\"url\",\"?\")}')
    print(f'    evidence: {(v.get(\"evidence\") or \"\")[:80]}')
" 2>/dev/null)
echo "$COUNT"
REAL=$(echo "$COUNT"|head -1)
[ "${REAL:-0}" -gt 0 ] && ok "$REAL findings!" || echo "  ⚠ 0 findings (check worker logs)"

echo "[8/8] Report..."
RPT=$(curl -s -X POST "$BASE/api/v1/reports/generate/$SCAN_ID?report_type=hackerone" \
    -H "$AUTH" -H "Content-Type: application/json" -d "{}")
ok "Report: $(echo "$RPT"|python3 -c "import sys,json;print(json.load(sys.stdin).get('task_id','queued'))" 2>/dev/null)"

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  DONE — Target: $TARGET"
echo "╚══════════════════════════════════════════════════════════════╝"
