#!/usr/bin/env bash
# verify_vulnweb_detection.sh — Verify vuln detection on testphp.vulnweb.com
# Authorized Acunetix training target
set -euo pipefail

BASE="${BASE:-http://localhost:8000}"
EMAIL="${EMAIL:-admin@blackmirror.io}"
PASS="${PASS:-BlackMirrorX2025!}"
TARGET="https://testphp.vulnweb.com"
WAIT="${WAIT:-120}"

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  GLASSWING — VulnWeb Detection Verification                 ║"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "║  Target: $TARGET"
echo "║  Authorized: Acunetix training environment"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

fail() { echo "  ✗ FAIL: $1"; exit 1; }
ok()   { echo "  ✓ $1"; }
warn() { echo "  ⚠ $1"; }

# Step 1: Health
echo "[1/9] Backend health..."
H=$(curl -sf "$BASE/health" 2>/dev/null || fail "Backend not responding")
[ "$(echo "$H" | python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null)" = "healthy" ] && ok "healthy" || fail "unhealthy"

# Step 2: Login
echo "[2/9] Login..."
R=$(curl -s -X POST "$BASE/api/v1/auth/login" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "username=$EMAIL&password=$PASS")
TOKEN=$(echo "$R" | python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))" 2>/dev/null)
[ -n "$TOKEN" ] && ok "Login OK" || fail "Login failed"
AUTH="Authorization: Bearer $TOKEN"

# Step 3: Workspace
echo "[3/9] Workspace..."
WS=$(curl -s "$BASE/api/v1/workspaces" -H "$AUTH" | \
    python3 -c "import sys,json; ws=json.load(sys.stdin); print(ws[0]['id'] if ws else '')" 2>/dev/null)
[ -n "$WS" ] && ok "Workspace: ${WS:0:8}..." || fail "No workspace"

# Step 4: Launch scan against testphp.vulnweb.com
echo "[4/9] Launching scan against $TARGET..."
SCAN=$(curl -s -X POST "$BASE/api/v1/scans" \
    -H "$AUTH" -H "Content-Type: application/json" \
    -d "{
        \"name\": \"vulnweb-verify-$(date +%s)\",
        \"workspace_id\": \"$WS\",
        \"scan_type\": \"recon\",
        \"target\": \"$TARGET\",
        \"config\": {
            \"domain\": \"testphp.vulnweb.com\",
            \"nuclei\": false,
            \"vuln_tests\": [\"xss\",\"sqli\",\"open_redirect\",\"path_traversal\",
                             \"info_disclosure\",\"missing_headers\",\"cors\"]
        }
    }")
SCAN_ID=$(echo "$SCAN" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null)
[ -n "$SCAN_ID" ] && ok "Scan launched: ${SCAN_ID:0:8}..." || fail "Scan failed: $SCAN"

# Step 5: Wait for completion
echo "[5/9] Waiting up to ${WAIT}s..."
FINAL_STATUS="unknown"
for i in $(seq 1 $((WAIT / 5))); do
    sleep 5
    ST=$(curl -s "$BASE/api/v1/scans/$SCAN_ID" -H "$AUTH" | \
        python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null)
    PROG=$(curl -s "$BASE/api/v1/scans/$SCAN_ID" -H "$AUTH" | \
        python3 -c "import sys,json; print(json.load(sys.stdin).get('progress',0))" 2>/dev/null || echo 0)
    echo -n "  $((i*5))s: $ST ($PROG%) "
    case "$ST" in
        completed) echo "✓"; FINAL_STATUS="completed"; break ;;
        failed)    echo "✗"; FINAL_STATUS="failed"; break ;;
        running)   echo "" ;;
        queued)    echo "(waiting for worker)" ;;
    esac
done
echo ""

if [ "$FINAL_STATUS" = "failed" ]; then
    echo "  Scan failed. Worker logs:"
    docker compose logs worker --tail=20 2>/dev/null || true
    fail "Scan failed"
fi

if [ "$FINAL_STATUS" != "completed" ]; then
    warn "Scan did not complete in ${WAIT}s (status: $FINAL_STATUS)"
    warn "This is OK — checking partial results..."
fi

# Step 6: Verify URLs discovered
echo "[6/9] Checking discovered URLs..."
URLS=$(curl -s "$BASE/api/v1/recon/urls?workspace_id=$WS&scan_id=$SCAN_ID&limit=10" \
    -H "$AUTH" | \
    python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d) if isinstance(d,list) else 0)" 2>/dev/null || echo 0)
[ "$URLS" -gt 0 ] && ok "$URLS URLs discovered" || warn "0 URLs found (recon may not have run)"

# Step 7: Verify parameterized URLs
echo "[7/9] Checking parameterized URLs..."
PARAM_URLS=$(curl -s "$BASE/api/v1/recon/urls?workspace_id=$WS&scan_id=$SCAN_ID&limit=100" \
    -H "$AUTH" | \
    python3 -c "
import sys, json, urllib.parse
d = json.load(sys.stdin)
urls = d if isinstance(d,list) else []
param_urls = [u.get('url','') for u in urls if '?' in u.get('url','')]
print(len(param_urls))
for u in param_urls[:3]:
    print('  ', u)
" 2>/dev/null || echo 0)
PARAM_COUNT=$(echo "$PARAM_URLS" | head -1)
echo "$PARAM_URLS"
[ "$PARAM_COUNT" -gt 0 ] && ok "$PARAM_COUNT parameterized URLs found" || warn "0 parameterized URLs (may need more crawl time)"

# Step 8: Verify findings
echo "[8/9] Checking vulnerability findings..."
VULNS=$(curl -s "$BASE/api/v1/vulns?workspace_id=$WS" -H "$AUTH")
VULN_COUNT=$(echo "$VULNS" | python3 -c "
import sys, json
d = json.load(sys.stdin)
vulns = d if isinstance(d,list) else []
print(len(vulns))
for v in vulns[:5]:
    print(f'  [{v.get(\"severity\",\"?\").upper()}] {v.get(\"title\",\"?\")} @ {v.get(\"url\",\"?\")[:60]}')
" 2>/dev/null || echo 0)
echo "$VULN_COUNT" | head -1 | read -r CNT 2>/dev/null || CNT=0
echo "$VULN_COUNT"

REAL_COUNT=$(echo "$VULN_COUNT" | head -1)
if [ "$REAL_COUNT" -gt 0 ]; then
    ok "$REAL_COUNT findings discovered"
else
    warn "0 findings yet"
    echo ""
    echo "  Diagnosis:"
    echo "  1. Check if worker is running: docker compose ps worker"
    echo "  2. Check worker logs: docker compose logs worker --tail=50"
    echo "  3. Check scan logs: curl \$BASE/api/v1/scans/\$SCAN_ID/logs -H '\$AUTH'"
    echo "  4. testphp.vulnweb.com must be reachable from the VPS"
    echo "  5. Run: curl http://testphp.vulnweb.com/listproducts.php?cat=1"
    echo "     Expected: MySQL error in response"
fi

# Step 9: Generate report
echo "[9/9] Generating report..."
RPT=$(curl -s -X POST "$BASE/api/v1/reports/generate/$SCAN_ID?report_type=hackerone" \
    -H "$AUTH" -H "Content-Type: application/json" -d "{}")
TASK=$(echo "$RPT" | python3 -c "import sys,json; print(json.load(sys.stdin).get('task_id',''))" 2>/dev/null || echo "")
[ -n "$TASK" ] && ok "Report queued: $TASK" || warn "Report: $RPT"

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  VERIFICATION COMPLETE                                       ║"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "  Scan ID:  $SCAN_ID"
echo "  Status:   $FINAL_STATUS"
echo "  URLs:     $URLS"
echo "╚══════════════════════════════════════════════════════════════╝"
