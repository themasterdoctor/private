"""Patch recon.py — fixes Subdomain field name mismatches between API and frontend."""
import os

content = '''from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from pydantic import BaseModel, model_validator
from datetime import datetime

from app.db.session import get_db
from app.models.models import Subdomain, DiscoveredURL, User
from app.api.deps.auth import get_current_user

router = APIRouter()


class SubdomainOut(BaseModel):
    """
    Maps ORM Subdomain fields to frontend Subdomain interface.
    ORM:      host, ip_addresses, tech_stack, discovered_at
    Frontend: subdomain, ip_address, technologies, created_at
    """
    model_config = {"from_attributes": True}
    id: str
    subdomain: str = ""
    ip_address: Optional[str] = None
    status_code: Optional[int] = None
    title: Optional[str] = None
    technologies: List[str] = []
    ports: List[int] = []
    created_at: datetime
    source: str = ""
    is_alive: bool = False

    @model_validator(mode="before")
    @classmethod
    def map_orm_fields(cls, obj):
        if not hasattr(obj, "host"):
            return obj
        ip_list = getattr(obj, "ip_addresses", []) or []
        return {
            "id": str(getattr(obj, "id", "")),
            "subdomain": getattr(obj, "host", "") or "",
            "ip_address": ip_list[0] if ip_list else None,
            "status_code": getattr(obj, "status_code", None),
            "title": getattr(obj, "title", None),
            "technologies": getattr(obj, "tech_stack", []) or [],
            "ports": getattr(obj, "ports", []) or [],
            "created_at": getattr(obj, "discovered_at", datetime.utcnow()),
            "source": getattr(obj, "source", "") or "",
            "is_alive": getattr(obj, "is_alive", False),
        }


class URLOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    url: str
    method: str
    status_code: Optional[int] = None
    content_type: Optional[str] = None
    parameters: List[str] = []
    is_interesting: bool = False
    interest_reasons: List[str] = []
    source: str
    discovered_at: datetime


@router.get("/subdomains", response_model=List[SubdomainOut])
async def list_subdomains(
    workspace_id: str = Query(...),
    scan_id: Optional[str] = Query(None),
    alive_only: bool = Query(False),
    limit: int = Query(200, le=1000),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(Subdomain).where(Subdomain.workspace_id == workspace_id)
    if scan_id:
        q = q.where(Subdomain.scan_id == scan_id)
    if alive_only:
        q = q.where(Subdomain.is_alive == True)
    q = q.order_by(desc(Subdomain.discovered_at)).limit(limit).offset(offset)
    result = await db.execute(q)
    return [SubdomainOut.model_validate(s) for s in result.scalars().all()]


@router.get("/urls", response_model=List[URLOut])
async def list_urls(
    workspace_id: str = Query(...),
    scan_id: Optional[str] = Query(None),
    interesting_only: bool = Query(False),
    limit: int = Query(200, le=1000),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(DiscoveredURL).where(DiscoveredURL.workspace_id == workspace_id)
    if scan_id:
        q = q.where(DiscoveredURL.scan_id == scan_id)
    if interesting_only:
        q = q.where(DiscoveredURL.is_interesting == True)
    q = q.order_by(desc(DiscoveredURL.discovered_at)).limit(limit).offset(offset)
    result = await db.execute(q)
    return [URLOut.model_validate(u) for u in result.scalars().all()]
'''

path = "backend/app/api/routes/recon.py"
with open(path, "w") as f:
    f.write(content)
print(f"✓ Wrote {path}")
