#!/usr/bin/env bash
# patch_worker.sh — patches tasks.py directly into the running worker container
# Run from ~/private/blackmirror-x
# No rebuild needed — takes effect in ~10 seconds

set -e
echo "=== Patching worker container directly ==="

WORKER=$(docker ps --filter name=worker -q | head -1)
if [ -z "$WORKER" ]; then
  echo "ERROR: Worker container not running. Run: docker compose up -d worker"
  exit 1
fi
echo "Worker container: $WORKER"

# Write the fixed tasks.py directly into the container
docker exec "$WORKER" python3 -c "
content = '''
import asyncio
from datetime import datetime, timezone
from typing import Dict, Any, List

from sqlalchemy.orm import Session
from sqlalchemy import create_engine

from app.core.config import settings
from app.workers.celery_app import celery_app

sync_engine = create_engine(settings.DATABASE_URL_SYNC)

def get_sync_session():
    from sqlalchemy.orm import sessionmaker
    return sessionmaker(bind=sync_engine)()

def run_async(coro):
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                return pool.submit(asyncio.run, coro).result()
        return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)

def add_log(db, scan_id, level, module, message, data=None):
    from app.models.models import ScanLog
    log = ScanLog(scan_id=scan_id, level=level, module=module, message=message, data=data)
    db.add(log)
    try: db.commit()
    except: db.rollback()

@celery_app.task(bind=True, name=\"app.workers.tasks.run_scan_task\", max_retries=1)
def run_scan_task(self, scan_id):
    from app.models.models import ScanJob, ScanStatus, Target, Subdomain, DiscoveredURL, Vulnerability
    db = get_sync_session()
    try:
        scan = db.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return {\"error\": \"Scan not found\"}
        scan.status = ScanStatus.RUNNING
        scan.started_at = datetime.now(timezone.utc)
        db.commit()

        domain = scan.config.get(\"domain\", \"\")
        if not domain and scan.target_id:
            target = db.query(Target).filter(Target.id == scan.target_id).first()
            if target:
                domain = target.domain
        if not domain:
            scan.status = ScanStatus.FAILED
            scan.error_message = \"No target domain\"
            db.commit()
            return {\"error\": \"No domain\"}

        def log(level, module, msg, data=None):
            add_log(db, scan_id, level, module, msg, data)

        log(\"info\", \"pipeline\", f\"Starting scan: {domain}\")

        # Phase 1: Recon
        scan.progress = 10; db.commit()
        try:
            recon = run_async(_run_recon(scan_id, str(scan.workspace_id), domain, scan.config.get(\"recon\", {}), log))
        except Exception as e:
            log(\"warn\", \"recon\", f\"Recon error: {e}\")
            recon = {\"subdomains\": [], \"live_hosts\": [], \"urls\": []}

        for h in recon.get(\"subdomains\", [])[:500]:
            if h:
                db.add(Subdomain(scan_id=scan_id, workspace_id=scan.workspace_id, host=h, source=\"recon_agent\"))
        for u in recon.get(\"urls\", [])[:2000]:
            if u:
                db.add(DiscoveredURL(scan_id=scan_id, workspace_id=scan.workspace_id, url=u, source=\"crawler\"))
        db.commit()
        scan.progress = 40; db.commit()
        log(\"success\", \"recon\", f\"Recon done: {len(recon.get(\'subdomains\',[]))} subs, {len(recon.get(\'urls\',[]))} urls\")

        # Phase 2: Nuclei
        if scan.config.get(\"nuclei\", True):
            scan.progress = 50; db.commit()
            try:
                findings = run_async(_run_nuclei(scan_id, domain, recon.get(\"live_hosts\", []), log))
                for f in findings:
                    db.add(Vulnerability(scan_id=scan_id, workspace_id=scan.workspace_id, source=\"nuclei\", **f))
                db.commit()
                log(\"success\", \"nuclei\", f\"Nuclei: {len(findings)} findings\")
            except Exception as e:
                log(\"warn\", \"nuclei\", f\"Nuclei error: {e}\")

        # Complete
        scan.status = ScanStatus.COMPLETED
        scan.progress = 100
        scan.completed_at = datetime.now(timezone.utc)
        db.commit()
        log(\"success\", \"pipeline\", \"Scan completed!\")
        return {\"status\": \"completed\", \"scan_id\": scan_id}

    except Exception as e:
        import traceback; traceback.print_exc()
        db.rollback()
        try:
            from app.models.models import ScanStatus as SS
            s = db.query(ScanJob).filter(ScanJob.id == scan_id).first()
            if s:
                s.status = SS.FAILED
                s.error_message = str(e)[:500]
                db.commit()
            add_log(db, scan_id, \"error\", \"pipeline\", f\"Scan failed: {e}\")
        except: pass
        raise
    finally:
        db.close()

async def _run_recon(scan_id, workspace_id, domain, config, log_fn):
    from app.agents.recon.agent import ReconAgent
    agent = ReconAgent(scan_id=scan_id, workspace_id=workspace_id)
    return await agent.run_full_recon(domain, config)

async def _run_nuclei(scan_id, domain, hosts, log_fn):
    import json as _json
    findings = []
    host_list = hosts[:5] or [domain]
    cmd = [settings.NUCLEI_PATH, \"-t\", \"cves,exposures,misconfiguration\",
           \"-severity\", \"critical,high,medium\", \"-json\", \"-silent\",
           \"-rate-limit\", \"50\", \"-timeout\", \"10\", \"-no-color\"] + \
          [x for h in host_list for x in [\"-u\", h]]
    try:
        proc = await asyncio.create_subprocess_exec(*cmd,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=300)
        for line in out.decode().splitlines():
            try:
                it = _json.loads(line)
                findings.append({
                    \"title\": it.get(\"info\",{}).get(\"name\",\"Nuclei Finding\"),
                    \"vuln_type\": it.get(\"type\",\"unknown\"),
                    \"severity\": it.get(\"info\",{}).get(\"severity\",\"info\"),
                    \"url\": it.get(\"matched-at\",\"\"),
                    \"evidence\": str(it.get(\"extracted-results\",\"\"))[:500],
                    \"description\": it.get(\"info\",{}).get(\"description\",\"\"),
                })
            except: pass
    except FileNotFoundError:
        log_fn(\"warn\", \"nuclei\", \"Nuclei not installed\")
    except asyncio.TimeoutError:
        log_fn(\"warn\", \"nuclei\", \"Nuclei timed out\")
    except Exception as e:
        log_fn(\"warn\", \"nuclei\", f\"Nuclei error: {e}\")
    return findings

@celery_app.task(name=\"app.workers.tasks.generate_report_task\")
def generate_report_task(scan_id, report_type=\"markdown\"):
    from app.models.models import ScanJob, Vulnerability, Subdomain, DiscoveredURL, Report
    db = get_sync_session()
    try:
        scan = db.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan: return {\"error\": \"Scan not found\"}
        vulns = db.query(Vulnerability).filter(Vulnerability.scan_id == scan_id).all()
        subs = db.query(Subdomain).filter(Subdomain.scan_id == scan_id).all()
        urls = db.query(DiscoveredURL).filter(DiscoveredURL.scan_id == scan_id).all()
        from app.agents.report_writer.agent import ReportWriterAgent
        agent = ReportWriterAgent()
        scan_data = {\"scan_id\": scan_id,
            \"target\": scan.config.get(\"domain\", scan.name or \"Unknown\"),
            \"scan_date\": scan.created_at.strftime(\"%Y-%m-%d\"),
            \"subdomains_count\": len(subs), \"live_hosts_count\": 0, \"urls_count\": len(urls)}
        vuln_dicts = [{\"title\": v.title, \"vuln_type\": v.vuln_type,
            \"severity\": v.severity.value if hasattr(v.severity, \"value\") else str(v.severity),
            \"url\": v.url, \"parameter\": v.parameter, \"payload\": v.payload,
            \"evidence\": v.evidence, \"description\": v.description, \"remediation\": v.remediation}
            for v in vulns]
        result = run_async(agent.generate_full_report(scan_data, vuln_dicts, report_type))
        report = Report(scan_id=scan_id, workspace_id=scan.workspace_id,
            title=f\"Report — {scan_data[\'target\']} — {scan_data[\'scan_date\']}\",
            report_type=report_type, content=result[\"content\"],
            extra_metadata=result.get(\"metadata\", {}), generated_by_ai=True)
        db.add(report); db.commit()
        return {\"status\": \"done\", \"report_id\": str(report.id)}
    except Exception as e:
        import traceback; traceback.print_exc()
        return {\"error\": str(e)}
    finally:
        db.close()

@celery_app.task(name=\"app.workers.tasks.cleanup_old_logs\")
def cleanup_old_logs():
    from app.models.models import ScanLog
    from datetime import timedelta
    db = get_sync_session()
    try:
        cutoff = datetime.now(timezone.utc) - timedelta(days=30)
        deleted = db.query(ScanLog).filter(ScanLog.timestamp < cutoff).delete()
        db.commit()
        return {\"deleted\": deleted}
    finally:
        db.close()
'''.lstrip()
open('/app/app/workers/tasks.py', 'w').write(content)
print('tasks.py patched successfully')
print('Lines:', len(content.splitlines()))
# Verify no old broken pattern
if 'asyncio.get_event_loop().is_running() else asyncio.run(' in content:
    print('ERROR: old pattern still present!')
else:
    print('VERIFIED: old broken pattern removed')
"

echo ""
echo "=== Restarting worker ==="
docker compose restart worker
sleep 8
echo ""
echo "=== Worker logs (should show ready, no errors) ==="
docker compose logs worker --tail=15

echo ""
echo "=== Test: create a scan and watch worker pick it up ==="
TOKEN=$(curl -sf -X POST http://localhost:8000/api/v1/auth/login \
  -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" | \
  python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")
WS=$(curl -sf -H "Authorization: Bearer $TOKEN" \
  http://localhost:8000/api/v1/workspaces | \
  python3 -c "import sys,json; print(json.load(sys.stdin)[0]['id'])")
SCAN=$(curl -sf -X POST http://localhost:8000/api/v1/scans \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"name\":\"Patch Test\",\"workspace_id\":\"$WS\",\"scan_type\":\"recon\",\"config\":{\"domain\":\"testphp.vulnweb.com\"}}" | \
  python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
echo "Scan created: $SCAN"
echo "Waiting 20s for worker..."
sleep 20
STATUS=$(curl -sf -H "Authorization: Bearer $TOKEN" \
  "http://localhost:8000/api/v1/scans/$SCAN" | \
  python3 -c "import sys,json; print(json.load(sys.stdin)['status'])" 2>/dev/null)
echo "Scan status: $STATUS"

if [ "$STATUS" = "RUNNING" ] || [ "$STATUS" = "COMPLETED" ]; then
  echo ""
  echo "SUCCESS! Worker is executing scans."
  echo "Open http://76.13.30.226:3000 — scans will now run."
else
  docker compose logs worker --tail=20
fi
