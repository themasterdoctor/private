#!/usr/bin/env bash
# fix_vps_cors.sh — Quick fix for CORS and API URL on a running VPS
# Run this if buttons don't work after initial deploy.
# Usage: SERVER_IP=76.13.30.226 bash scripts/fix_vps_cors.sh

set -euo pipefail

SERVER_IP="${SERVER_IP:-$(curl -s --max-time 5 https://api.ipify.org 2>/dev/null || echo '76.13.30.226')}"
echo "Server IP: $SERVER_IP"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [ ! -f .env ]; then
  echo "ERROR: .env not found. Run install_local.sh first."
  exit 1
fi

echo ""
echo "── Updating .env for VPS IP: $SERVER_IP ────────────────"

# Update CORS to include the VPS IP
sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000,http://127.0.0.1:3000|" .env
echo "  ✓ CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000,http://127.0.0.1:3000"

# Update frontend API URL
sed -i "s|^NEXT_PUBLIC_API_URL=.*|NEXT_PUBLIC_API_URL=http://${SERVER_IP}:8000|" .env
sed -i "s|^NEXT_PUBLIC_WS_URL=.*|NEXT_PUBLIC_WS_URL=ws://${SERVER_IP}:8000|" .env
echo "  ✓ NEXT_PUBLIC_API_URL=http://${SERVER_IP}:8000"

echo ""
echo "── Rebuilding and restarting ────────────────────────────"
docker compose build --no-cache backend frontend
docker compose up -d backend frontend

echo ""
echo "── Waiting for backend health ───────────────────────────"
for i in $(seq 1 30); do
  sleep 3
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" "http://${SERVER_IP}:8000/health" 2>/dev/null)
  if [ "$STATUS" = "200" ]; then
    echo "  ✓ Backend healthy"
    break
  fi
  echo "  Waiting... ($i/30)"
done

echo ""
echo "── Verifying CORS ───────────────────────────────────────"
CORS=$(curl -si -X OPTIONS "http://${SERVER_IP}:8000/api/v1/workspaces" \
  -H "Origin: http://${SERVER_IP}:3000" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: authorization,content-type" \
  --max-time 10 2>/dev/null | grep -i "access-control-allow-origin" | head -1 | tr -d '\r')

if [ -n "$CORS" ]; then
  echo "  ✓ $CORS"
else
  echo "  ✗ CORS header missing — check docker logs"
fi

echo ""
echo "── Run full verification ────────────────────────────────"
echo "  bash scripts/fix_and_verify_live.sh http://${SERVER_IP}:8000 http://${SERVER_IP}:3000"
