#!/usr/bin/env bash
# verify_frontend.sh — BLACKMIRROR-X frontend verification
# Run from: project root OR frontend/

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$SCRIPT_DIR/../frontend/package.json" ]; then
    FE_DIR="$(cd "$SCRIPT_DIR/../frontend" && pwd)"
elif [ -f "package.json" ] && grep -q "blackmirror" package.json 2>/dev/null; then
    FE_DIR="$(pwd)"
elif [ -f "frontend/package.json" ]; then
    FE_DIR="$(pwd)/frontend"
else
    echo "ERROR: Cannot locate frontend/package.json"
    exit 1
fi
cd "$FE_DIR"

PASS=0; FAIL=0
pass() { echo "  ✓ $1"; PASS=$((PASS+1)); }
fail() { echo "  ✗ FAIL: $1"; FAIL=$((FAIL+1)); }

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  BLACKMIRROR-X — Frontend Verification  ║"
echo "╚══════════════════════════════════════════╝"
echo "  Frontend dir: $FE_DIR"

echo "[1/5] Node/npm..."
NODE_VER=$(node --version 2>/dev/null || echo "missing")
NPM_VER=$(npm --version 2>/dev/null || echo "missing")
[ "$NODE_VER" != "missing" ] && pass "Node $NODE_VER, npm $NPM_VER" || fail "Node not found — install from nodejs.org"

echo "[2/5] npm install..."
npm install --prefer-offline --silent 2>/dev/null || npm install --silent 2>/dev/null
MODS=$(ls node_modules 2>/dev/null | wc -l)
[ "$MODS" -gt 100 ] && pass "Dependencies: $MODS packages" || fail "npm install failed"

echo "[3/5] ESLint..."
LINT_OUT=$(npm run lint 2>&1)
LINT_EXIT=$?
ERRORS=$(echo "$LINT_OUT" | grep -c "^.*[Ee]rror:" || true)
WARNINGS=$(echo "$LINT_OUT" | grep -c "[Ww]arning:" || true)
[ "$LINT_EXIT" -eq 0 ] && pass "Lint: 0 errors, $WARNINGS warnings" || fail "Lint: $ERRORS errors (run npm run lint to see)"

echo "[4/5] TypeScript type check..."
TSC_OUT=$(npx tsc --noEmit 2>&1)
TSC_EXIT=$?
TS_ERRORS=$(echo "$TSC_OUT" | grep -c "error TS" || true)
[ "$TSC_EXIT" -eq 0 ] && pass "TypeScript: 0 type errors" || fail "TypeScript: $TS_ERRORS errors"
if [ "$TSC_EXIT" -ne 0 ]; then
    echo "$TSC_OUT" | grep "error TS" | head -5
fi

echo "[5/5] Next.js build..."
export NEXT_PUBLIC_API_URL="${NEXT_PUBLIC_API_URL:-http://localhost:8000}"
export NEXT_PUBLIC_WS_URL="${NEXT_PUBLIC_WS_URL:-ws://localhost:8000}"
BUILD_OUT=$(npm run build 2>&1)
BUILD_EXIT=$?
ROUTES=$(echo "$BUILD_OUT" | grep -c "^[├└]" || true)
if [ "$BUILD_EXIT" -eq 0 ]; then
    pass "Build succeeded — $ROUTES routes compiled"
else
    fail "Build failed"
    echo "$BUILD_OUT" | grep -i "error" | grep -v "^>" | head -10
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Results: ${PASS} passed, ${FAIL} failed"
[ "$FAIL" -eq 0 ] && echo "✓ FRONTEND: PASS" && exit 0 || echo "✗ FRONTEND: FAIL" && exit 1
