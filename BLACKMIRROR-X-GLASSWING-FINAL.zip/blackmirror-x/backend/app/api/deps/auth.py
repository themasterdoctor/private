from typing import Optional
from fastapi import Depends, HTTPException, Query, Request, status, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials, OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from datetime import datetime, timezone

from app.db.session import get_db
from app.models.models import User, APIKey
from app.core.security import decode_token, verify_api_key

bearer_scheme = HTTPBearer(auto_error=False)
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)


async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Security(bearer_scheme),
    db: AsyncSession = Depends(get_db),
    request: Request = None,
) -> User:
    # Extract token from Authorization header OR ?token= query param (for SSE/WebSocket)
    token = None
    if credentials:
        token = credentials.credentials
    elif request:
        token = request.query_params.get("token")

    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")

    # Try JWT first
    payload = decode_token(token)
    if payload and payload.get("type") == "access":
        result = await db.execute(select(User).where(User.id == payload["sub"]))
        user = result.scalar_one_or_none()
        if user and user.is_active:
            return user

    # Try API key
    if token.startswith("bmx_"):
        from app.core.security import hash_api_key
        key_hash = hash_api_key(token)
        result = await db.execute(
            select(APIKey).where(APIKey.key_hash == key_hash, APIKey.is_active == True)
        )
        api_key = result.scalar_one_or_none()
        if api_key:
            if api_key.expires_at and api_key.expires_at < datetime.now(timezone.utc):
                raise HTTPException(status_code=401, detail="API key expired")
            # Update last used
            await db.execute(
                update(APIKey).where(APIKey.id == api_key.id)
                .values(last_used_at=datetime.now(timezone.utc))
            )
            result = await db.execute(select(User).where(User.id == api_key.user_id))
            user = result.scalar_one_or_none()
            if user and user.is_active:
                return user

    raise HTTPException(status_code=401, detail="Invalid or expired credentials")


async def require_admin(current_user: User = Depends(get_current_user)) -> User:
    if current_user.role.value != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user


async def get_optional_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Security(bearer_scheme),
    db: AsyncSession = Depends(get_db),
) -> Optional[User]:
    try:
        return await get_current_user(credentials, db)
    except HTTPException:
        return None
