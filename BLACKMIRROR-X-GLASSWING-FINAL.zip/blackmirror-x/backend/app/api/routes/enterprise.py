"""
Enterprise API Routes — BLACKMIRROR-X GLASSWING
Handles all 20 enterprise features:
- Scope enforcement
- Evidence engine
- Confidence scoring
- Approval gates
- Replay lab (enhanced)
- Team management
- Plugin SDK
- Payload library
- Program intelligence
- Emergency stop
- Report quality checks
"""
from __future__ import annotations

from typing import Any, Optional, List
from fastapi import APIRouter, Depends, HTTPException, Body, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from datetime import datetime

from app.db.session import get_db
from app.models.models import User, Workspace, WorkspaceMember, Vulnerability, ScanJob
from app.api.deps.auth import get_current_user

router = APIRouter()


# ─── Scope Enforcement ────────────────────────────────────────────────────────

class ScopeRuleIn(BaseModel):
    pattern: str
    notes: str = ""
    source: str = "manual"


class ProgramImportIn(BaseModel):
    program_name: str
    platform: str = "manual"
    program_url: str = ""
    scope_domains: List[str] = []
    out_of_scope: List[str] = []
    rules: str = ""
    rewards: dict = {}
    forbidden_testing: List[str] = []
    rate_limits: dict = {}
    report_preferences: str = ""
    known_duplicate_patterns: List[str] = []


@router.get("/scope/{workspace_id}")
async def get_scope(
    workspace_id: str,
    current_user: User = Depends(get_current_user),
):
    """Get current scope configuration for a workspace."""
    from app.enterprise.scope_engine import get_scope_engine
    engine = get_scope_engine(workspace_id)
    scope_data = engine.to_dict()
    return {
        "workspace_id": workspace_id,
        "include_rules": [vars(r) for r in engine.include_rules],
        "exclude_rules": [vars(r) for r in engine.exclude_rules],
        "authorization_confirmed": engine.authorization_confirmed,
        "program_profile": engine.program_profile.to_dict() if engine.program_profile else None,
        "total_rules": len(engine.include_rules) + len(engine.exclude_rules),
    }


@router.post("/scope/{workspace_id}/include")
async def add_scope_rule(
    workspace_id: str,
    data: ScopeRuleIn,
    current_user: User = Depends(get_current_user),
):
    """Add an in-scope domain/IP/CIDR rule."""
    from app.enterprise.scope_engine import get_scope_engine, invalidate_scope_cache
    engine = get_scope_engine(workspace_id)
    engine.add_scope(data.pattern, source=data.source, notes=data.notes)
    return {"added": data.pattern, "total_include_rules": len(engine.include_rules)}


@router.post("/scope/{workspace_id}/exclude")
async def add_exclusion_rule(
    workspace_id: str,
    data: ScopeRuleIn,
    current_user: User = Depends(get_current_user),
):
    """Add an out-of-scope exclusion rule."""
    from app.enterprise.scope_engine import get_scope_engine
    engine = get_scope_engine(workspace_id)
    engine.add_exclusion(data.pattern, source=data.source, notes=data.notes)
    return {"excluded": data.pattern, "total_exclude_rules": len(engine.exclude_rules)}


@router.post("/scope/{workspace_id}/check")
async def check_target_scope(
    workspace_id: str,
    target: str = Body(..., embed=True),
    current_user: User = Depends(get_current_user),
):
    """Check if a target is in scope (with audit logging)."""
    from app.enterprise.scope_engine import get_scope_engine
    engine = get_scope_engine(workspace_id)
    result = engine.check_target(target, user_id=str(current_user.id), action="scope_check")
    return result.__dict__


@router.post("/scope/{workspace_id}/import-program")
async def import_program(
    workspace_id: str,
    data: ProgramImportIn,
    current_user: User = Depends(get_current_user),
):
    """Import a bug bounty program profile into workspace scope."""
    from app.enterprise.scope_engine import get_scope_engine
    from app.enterprise.scope_engine import ProgramProfile
    engine = get_scope_engine(workspace_id)
    profile = ProgramProfile(
        program_name=data.program_name,
        platform=data.platform,
        program_url=data.program_url,
        scope_domains=data.scope_domains,
        out_of_scope=data.out_of_scope,
        rules=data.rules,
        rewards=data.rewards,
        forbidden_testing=data.forbidden_testing,
        rate_limits=data.rate_limits,
        report_preferences=data.report_preferences,
        known_duplicate_patterns=data.known_duplicate_patterns,
    )
    engine.import_program(profile)
    return {
        "imported": data.program_name,
        "scope_rules_added": len(data.scope_domains),
        "exclusions_added": len(data.out_of_scope),
    }


@router.post("/scope/{workspace_id}/confirm-authorization")
async def confirm_authorization(
    workspace_id: str,
    confirmed: bool = Body(..., embed=True),
    authorization_note: str = Body("", embed=True),
    current_user: User = Depends(get_current_user),
):
    """User confirms they have authorization to test this scope."""
    from app.enterprise.scope_engine import get_scope_engine
    engine = get_scope_engine(workspace_id)
    engine.authorization_confirmed = confirmed
    engine.authorization_token = f"confirmed_by_{current_user.id}_at_{datetime.utcnow().isoformat()}"
    return {"authorization_confirmed": confirmed, "confirmed_by": current_user.email}


@router.get("/scope/{workspace_id}/audit-log")
async def get_scope_audit_log(
    workspace_id: str,
    limit: int = Query(100, le=500),
    current_user: User = Depends(get_current_user),
):
    """Get scope audit log — every target that was checked."""
    from app.enterprise.scope_engine import get_scope_engine
    engine = get_scope_engine(workspace_id)
    return {"audit_log": engine.get_audit_log(limit=limit)}


# ─── Confidence Scoring ───────────────────────────────────────────────────────

class ScoreRequest(BaseModel):
    vuln_type: str
    severity: str = "medium"
    indicators: dict = {}
    evidence_count: int = 1
    has_screenshot: bool = False
    has_request_response: bool = False
    waf_detected: bool = False
    requires_auth: bool = False
    scope_confirmed: bool = True


@router.post("/scoring/score-finding")
async def score_finding(
    data: ScoreRequest,
    current_user: User = Depends(get_current_user),
):
    """Score a vulnerability finding."""
    from app.enterprise.confidence_scoring import score_finding as _score
    profile = _score(
        vuln_type=data.vuln_type,
        severity=data.severity,
        indicators=data.indicators,
        evidence_count=data.evidence_count,
        has_screenshot=data.has_screenshot,
        has_request_response=data.has_request_response,
        waf_detected=data.waf_detected,
        requires_auth=data.requires_auth,
        scope_confirmed=data.scope_confirmed,
    )
    return profile.to_dict()


@router.post("/scoring/score-vuln/{vuln_id}")
async def score_existing_vuln(
    vuln_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Score an existing vulnerability from the database."""
    from app.enterprise.confidence_scoring import score_finding as _score
    result = await db.execute(select(Vulnerability).where(Vulnerability.id == vuln_id))
    v = result.scalar_one_or_none()
    if not v:
        raise HTTPException(404, "Vulnerability not found")

    sev = v.severity.value if hasattr(v.severity, "value") else str(v.severity)
    profile = _score(
        vuln_type=v.vuln_type,
        severity=sev,
        evidence_count=1 + (1 if v.evidence else 0) + (1 if v.payload else 0),
        has_request_response=bool(v.request and v.response),
        scope_confirmed=True,
    )
    profile.vuln_id = vuln_id

    # Persist scores back to vulnerability
    v.ai_analysis = v.ai_analysis or {}
    v.ai_analysis.update({
        "confidence_score": profile.confidence_score,
        "exploitability_score": profile.exploitability_score,
        "business_impact_score": profile.business_impact_score,
        "false_positive_risk": profile.false_positive_risk,
        "overall_score": profile.overall_score,
        "recommended_action": profile.recommended_action.value,
    })
    await db.commit()

    return profile.to_dict()


# ─── Approval Gates ───────────────────────────────────────────────────────────

@router.get("/approvals/{workspace_id}/pending")
async def list_pending_approvals(
    workspace_id: str,
    current_user: User = Depends(get_current_user),
):
    """List all pending approval requests for a workspace."""
    from app.enterprise.approval_gates import list_pending_approvals as _list
    return {"pending": _list(workspace_id), "count": len(_list(workspace_id))}


@router.post("/approvals/{request_id}/approve")
async def approve_action(
    request_id: str,
    reason: str = Body("", embed=True),
    current_user: User = Depends(get_current_user),
):
    """Approve a pending action request."""
    from app.enterprise.approval_gates import approve_request
    approved = approve_request(request_id, str(current_user.id), reason)
    if not approved:
        raise HTTPException(400, "Request not found or already resolved")
    return {"approved": True, "request_id": request_id, "by": current_user.email}


@router.post("/approvals/{request_id}/reject")
async def reject_action(
    request_id: str,
    reason: str = Body(..., embed=True),
    current_user: User = Depends(get_current_user),
):
    """Reject a pending action request."""
    from app.enterprise.approval_gates import reject_request
    rejected = reject_request(request_id, str(current_user.id), reason)
    if not rejected:
        raise HTTPException(400, "Request not found or already resolved")
    return {"rejected": True, "request_id": request_id, "reason": reason}


@router.get("/approvals/{workspace_id}/history")
async def get_approval_history(
    workspace_id: str,
    limit: int = Query(50, le=200),
    current_user: User = Depends(get_current_user),
):
    """Get approval history for audit purposes."""
    from app.enterprise.approval_gates import get_approval_history
    return {"history": get_approval_history(workspace_id, limit=limit)}


# ─── Emergency Stop ───────────────────────────────────────────────────────────

@router.post("/emergency-stop/{workspace_id}")
async def emergency_stop(
    workspace_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    EMERGENCY STOP — immediately halts all scanning for this workspace.
    Cancels all running scans and rejects all pending approvals.
    """
    from app.enterprise.approval_gates import ApprovalGate
    gate = ApprovalGate(workspace_id)
    gate.emergency_stop(user_id=str(current_user.id))

    # Also cancel all running/queued scans in DB
    from app.models.models import ScanStatus
    from sqlalchemy import update
    await db.execute(
        update(ScanJob)
        .where(ScanJob.workspace_id == workspace_id)
        .where(ScanJob.status.in_([ScanStatus.QUEUED, ScanStatus.RUNNING]))
        .values(status=ScanStatus.CANCELLED, error_message=f"Emergency stop by {current_user.email}")
    )
    await db.commit()

    return {
        "emergency_stopped": True,
        "workspace_id": workspace_id,
        "stopped_by": current_user.email,
        "timestamp": datetime.utcnow().isoformat(),
    }


@router.post("/emergency-stop/{workspace_id}/resume")
async def resume_scanning(
    workspace_id: str,
    current_user: User = Depends(get_current_user),
):
    """Resume scanning after emergency stop."""
    from app.enterprise.approval_gates import ApprovalGate
    gate = ApprovalGate(workspace_id)
    gate.resume_after_stop(user_id=str(current_user.id))
    return {"resumed": True, "workspace_id": workspace_id, "by": current_user.email}


@router.get("/emergency-stop/{workspace_id}/status")
async def get_emergency_status(
    workspace_id: str,
    current_user: User = Depends(get_current_user),
):
    """Check if emergency stop is active."""
    from app.enterprise.approval_gates import _emergency_stops
    return {
        "stopped": workspace_id in _emergency_stops,
        "workspace_id": workspace_id,
    }


# ─── Payload Library ──────────────────────────────────────────────────────────

@router.get("/payloads/{vuln_type}")
async def get_payloads(
    vuln_type: str,
    tier: str = Query("low_risk"),
    context: str = Query(""),
    limit: int = Query(20, le=100),
    current_user: User = Depends(get_current_user),
):
    """Get payloads for a vulnerability type."""
    from app.enterprise.payload_library import get_payloads as _get, PayloadTier
    try:
        max_tier = PayloadTier(tier)
    except ValueError:
        max_tier = PayloadTier.LOW_RISK
    payloads = _get(vuln_type, max_tier=max_tier, context=context, limit=limit)
    return {
        "vuln_type": vuln_type,
        "tier": tier,
        "payloads": [p.to_dict() for p in payloads],
        "count": len(payloads),
    }


@router.get("/payloads/summary/all")
async def get_payload_summary(
    current_user: User = Depends(get_current_user),
):
    """Get summary of entire payload library."""
    from app.enterprise.payload_library import get_payload_tiers_summary
    return get_payload_tiers_summary()


# ─── Team Management ─────────────────────────────────────────────────────────

class FindingCommentIn(BaseModel):
    content: str
    comment_type: str = "note"


@router.get("/team/{workspace_id}/members")
async def list_team_members(
    workspace_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """List all team members in a workspace with their roles."""
    from app.models.models import User as UserModel
    result = await db.execute(
        select(WorkspaceMember, UserModel)
        .join(UserModel, WorkspaceMember.user_id == UserModel.id)
        .where(WorkspaceMember.workspace_id == workspace_id)
    )
    rows = result.all()
    return {
        "members": [
            {
                "user_id": str(member.user_id),
                "email": user.email,
                "full_name": user.full_name or "",
                "role": member.role.value if hasattr(member.role, "value") else str(member.role),
                "joined_at": member.joined_at.isoformat() if member.joined_at else "",
            }
            for member, user in rows
        ],
        "count": len(rows),
    }


@router.get("/team/{workspace_id}/permissions")
async def get_permissions(
    workspace_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get permissions for current user in workspace."""
    from app.enterprise.team_features import check_permission, ROLE_PERMISSIONS, TeamRole
    result = await db.execute(
        select(WorkspaceMember)
        .where(WorkspaceMember.workspace_id == workspace_id)
        .where(WorkspaceMember.user_id == current_user.id)
    )
    member = result.scalar_one_or_none()
    if not member:
        return {"role": "none", "permissions": []}

    role = member.role.value if hasattr(member.role, "value") else str(member.role)
    try:
        team_role = TeamRole(role)
        permissions = list(ROLE_PERMISSIONS.get(team_role, set()))
    except ValueError:
        permissions = []

    return {"role": role, "permissions": sorted(permissions)}


@router.post("/team/{workspace_id}/comments/{vuln_id}")
async def add_finding_comment(
    workspace_id: str,
    vuln_id: str,
    data: FindingCommentIn,
    current_user: User = Depends(get_current_user),
):
    """Add a comment to a vulnerability finding."""
    from app.enterprise.team_features import FindingComment
    comment = FindingComment(
        vuln_id=vuln_id,
        workspace_id=workspace_id,
        user_id=str(current_user.id),
        user_email=current_user.email,
        content=data.content,
        comment_type=data.comment_type,
    )
    # In production: persist to database
    return comment.to_dict()


@router.get("/team/{workspace_id}/sla")
async def get_sla_policy(
    workspace_id: str,
    current_user: User = Depends(get_current_user),
):
    """Get SLA policy for workspace."""
    from app.enterprise.team_features import SLAPolicy
    # Default SLA policy
    policy = SLAPolicy(workspace_id=workspace_id)
    return policy.to_dict()


@router.post("/team/{workspace_id}/sla-check/{vuln_id}")
async def check_sla_status(
    workspace_id: str,
    vuln_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Check SLA status for a specific vulnerability."""
    from app.enterprise.team_features import SLAPolicy
    result = await db.execute(select(Vulnerability).where(Vulnerability.id == vuln_id))
    v = result.scalar_one_or_none()
    if not v:
        raise HTTPException(404, "Vulnerability not found")

    policy = SLAPolicy(workspace_id=workspace_id)
    sev = v.severity.value if hasattr(v.severity, "value") else str(v.severity)
    sla_status = policy.get_sla_status(sev, v.discovered_at)
    return sla_status


# ─── Plugin SDK ────────────────────────────────────────────────────────────────

@router.get("/plugins")
async def list_plugins(
    plugin_type: Optional[str] = Query(None),
    current_user: User = Depends(get_current_user),
):
    """List all registered plugins."""
    from app.enterprise.plugin_sdk import registry, PluginType
    if plugin_type:
        try:
            ptype = PluginType(plugin_type)
            return {"plugins": registry.list_plugins(ptype)}
        except ValueError:
            pass
    return {"plugins": registry.list_plugins()}


@router.post("/plugins/{plugin_name}/run")
async def run_plugin(
    plugin_name: str,
    target: str = Body(..., embed=True),
    config: dict = Body({}, embed=True),
    current_user: User = Depends(get_current_user),
):
    """Run a specific plugin against a target."""
    from app.enterprise.plugin_sdk import registry
    plugin = registry.get(plugin_name, config)
    if not plugin:
        raise HTTPException(404, f"Plugin '{plugin_name}' not found or disabled")
    try:
        result = await plugin.run(target, config)
        return result.to_dict()
    except Exception as e:
        raise HTTPException(500, f"Plugin execution failed: {str(e)}")


# ─── Report Quality Checks ────────────────────────────────────────────────────

@router.post("/report-quality/{scan_id}")
async def check_report_quality(
    scan_id: str,
    report_content: str = Body("", embed=True),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Run AI quality checks on a report before export."""
    from app.enterprise.team_features import ReportQualityChecker
    from sqlalchemy import select

    # Get vulnerabilities for the scan
    result = await db.execute(
        select(Vulnerability).where(Vulnerability.scan_id == scan_id)
    )
    vulns = result.scalars().all()

    vuln_dicts = [
        {
            "title": v.title,
            "severity": v.severity.value if hasattr(v.severity, "value") else str(v.severity),
            "vuln_type": v.vuln_type,
            "url": v.url,
            "payload": v.payload,
            "evidence": v.evidence,
            "reproduction_steps": v.reproduction_steps,
            "cvss_score": v.cvss_score,
        }
        for v in vulns
    ]

    checker = ReportQualityChecker()
    checks = await checker.check_report(report_content, vuln_dicts)
    return checks


# ─── Safety & Legal Layer ─────────────────────────────────────────────────────

class AuthorizationAgreementIn(BaseModel):
    workspace_id: str
    target_domain: str
    tester_name: str
    organization: str = ""
    authorization_type: str = "bug_bounty"  # bug_bounty, pentest, internal, ctf
    program_url: str = ""
    testing_period_start: str = ""
    testing_period_end: str = ""
    confirmed: bool = False
    acknowledgments: List[str] = []


@router.post("/safety/confirm-authorization")
async def confirm_testing_authorization(
    data: AuthorizationAgreementIn,
    current_user: User = Depends(get_current_user),
):
    """
    Record testing authorization confirmation.
    Required before scanning any target.
    """
    if not data.confirmed:
        raise HTTPException(400, "Authorization must be explicitly confirmed")

    required_acks = [
        "I have explicit written authorization to test this target",
        "I understand that unauthorized testing is illegal",
        "I will only test within the defined scope",
        "I will not cause service disruption or data loss",
    ]

    if len(data.acknowledgments) < len(required_acks):
        return {
            "authorized": False,
            "reason": "Please acknowledge all authorization requirements",
            "required_acknowledgments": required_acks,
        }

    from app.enterprise.scope_engine import get_scope_engine
    engine = get_scope_engine(data.workspace_id)
    engine.authorization_confirmed = True
    engine.authorization_token = (
        f"authorized:{data.tester_name}:{data.target_domain}:"
        f"{data.authorization_type}:{datetime.utcnow().isoformat()}"
    )

    return {
        "authorized": True,
        "workspace_id": data.workspace_id,
        "target": data.target_domain,
        "authorization_type": data.authorization_type,
        "tester": data.tester_name,
        "confirmed_at": datetime.utcnow().isoformat(),
        "agreement_id": f"AUTH-{data.workspace_id[:8].upper()}-{int(datetime.utcnow().timestamp())}",
        "disclaimer": (
            "BLACKMIRROR-X is for authorized security testing only. "
            "All scanning activity is logged. Unauthorized use is prohibited."
        ),
    }


@router.get("/safety/rate-limit-status/{workspace_id}")
async def get_rate_limit_status(
    workspace_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get current rate limiting status — prevents accidental DoS."""
    from sqlalchemy import func
    from app.models.models import ScanStatus

    running_scans = await db.execute(
        select(func.count()).where(
            ScanJob.workspace_id == workspace_id,
            ScanJob.status == ScanStatus.RUNNING
        )
    )
    running_count = running_scans.scalar() or 0

    from app.core.config import settings
    return {
        "running_scans": running_count,
        "max_concurrent": settings.MAX_CONCURRENT_SCANS,
        "rate_limit_per_minute": settings.RATE_LIMIT_PER_MINUTE,
        "can_start_new_scan": running_count < settings.MAX_CONCURRENT_SCANS,
        "no_dos_policy": "Automatic rate limiting is active. Maximum 50 requests/second per scan.",
        "emergency_stop_available": True,
    }
