"""
BLACKMIRROR-X Reports — Bug Bounty Export Engine

Formats:
  - markdown:    Full technical report
  - hackerone:   H1 submission format with CVSS, steps, impact
  - yeswehack:   YWH submission format
  - json:        Machine-readable export
  - executive:   Non-technical summary for management
"""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.db.session import get_db
from app.api.deps.auth import get_current_user
from app.models.models import User, ScanJob, Vulnerability, Report, Severity

router = APIRouter()


@router.post("/generate/{scan_id}")
async def generate_report(
    scan_id: str,
    report_type: str = Query("markdown", enum=["markdown","hackerone","yeswehack","json","executive"]),
    verified_only: bool = Query(False, description="Only include [VERIFIED] findings"),
    min_severity: str = Query("low", enum=["critical","high","medium","low","info"]),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Generate a bug bounty report for a scan."""
    from app.workers.tasks import generate_report_task
    task = generate_report_task.apply_async(
        args=[scan_id, report_type],
        kwargs={"verified_only": verified_only, "min_severity": min_severity}
    )
    return {"task_id": task.id, "status": "queued", "report_type": report_type}


@router.get("/export/{scan_id}")
async def export_report(
    scan_id: str,
    format: str = Query("hackerone", enum=["hackerone","yeswehack","markdown","json","executive"]),
    verified_only: bool = Query(False),
    min_severity: str = Query("medium", enum=["critical","high","medium","low","info"]),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Direct export — returns formatted report content immediately.
    This is the bug bounty hunter's main export tool.
    """
    # Get scan
    scan_result = await db.execute(select(ScanJob).where(ScanJob.id == scan_id))
    scan = scan_result.scalar_one_or_none()
    if not scan:
        raise HTTPException(404, "Scan not found")

    # Get vulnerabilities
    query = select(Vulnerability).where(Vulnerability.scan_id == scan_id)

    # Severity filter
    SEV_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    min_sev_num = SEV_ORDER.get(min_severity, 3)

    result = await db.execute(query)
    all_vulns = result.scalars().all()

    vulns = [v for v in all_vulns
             if SEV_ORDER.get(
                 v.severity.value if hasattr(v.severity, "value") else str(v.severity),
                 4
             ) <= min_sev_num]

    if verified_only:
        vulns = [v for v in vulns if "[VERIFIED]" in (v.evidence or "")]

    if not vulns:
        return {"content": "No findings matching the specified criteria.", "count": 0}

    # Generate report
    target = scan.config.get("domain", scan.name or "Unknown") if scan.config else (scan.name or "Unknown")
    scan_date = scan.created_at.strftime("%Y-%m-%d") if scan.created_at else "Unknown"

    if format == "hackerone":
        content = _generate_hackerone(target, scan_date, vulns)
    elif format == "yeswehack":
        content = _generate_yeswehack(target, scan_date, vulns)
    elif format == "json":
        content = _generate_json(target, scan_date, vulns)
    elif format == "executive":
        content = _generate_executive(target, scan_date, vulns)
    else:
        content = _generate_markdown(target, scan_date, vulns)

    return {
        "format": format,
        "target": target,
        "scan_date": scan_date,
        "total_findings": len(vulns),
        "verified_findings": sum(1 for v in vulns if "[VERIFIED]" in (v.evidence or "")),
        "content": content,
    }


@router.get("")
async def list_reports(
    workspace_id: str = Query(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Report).where(Report.workspace_id == workspace_id)
        .order_by(Report.created_at.desc()).limit(50)
    )
    reports = result.scalars().all()
    return [{"id": str(r.id), "title": r.title, "report_type": r.report_type,
             "created_at": r.created_at.isoformat() if r.created_at else None}
            for r in reports]


@router.get("/{report_id}")
async def get_report(
    report_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Report).where(Report.id == report_id))
    report = result.scalar_one_or_none()
    if not report:
        raise HTTPException(404, "Report not found")
    return {"id": str(report.id), "title": report.title,
            "report_type": report.report_type, "content": report.content,
            "created_at": report.created_at.isoformat() if report.created_at else None}


# ── Report formatters ─────────────────────────────────────────────────────────

def _sev(v) -> str:
    return v.severity.value if hasattr(v.severity, "value") else str(v.severity)


def _is_verified(v) -> bool:
    return "[VERIFIED]" in (v.evidence or "")


def _generate_hackerone(target: str, date: str, vulns) -> str:
    """HackerOne-style submission format."""
    lines = [
        f"# Security Research Report — {target}",
        f"**Date:** {date}  ",
        f"**Researcher:** BLACKMIRROR-X GLASSWING  ",
        f"**Total Findings:** {len(vulns)}  ",
        f"**Verified Findings:** {sum(1 for v in vulns if _is_verified(v))}",
        "",
        "---",
        "",
    ]

    for i, v in enumerate(sorted(vulns,
            key=lambda x: {"critical":0,"high":1,"medium":2,"low":3,"info":4}.get(_sev(x),4)), 1):
        sev = _sev(v).upper()
        verified_badge = " ✅ VERIFIED" if _is_verified(v) else " ⚠️ NEEDS REVIEW"
        lines += [
            f"## Finding #{i}: {v.title or 'Untitled'}",
            f"**Severity:** {sev}{verified_badge}  ",
            f"**Vulnerability Class:** {(v.vuln_type or '').replace('_',' ').title()}  ",
            f"**Affected URL:** `{v.url or 'N/A'}`  ",
            "",
            "### Summary",
            v.description or "No description provided.",
            "",
            "### Steps to Reproduce",
            "```",
        ]
        if v.payload:
            lines.append(f"Payload: {v.payload}")
        if v.parameter:
            lines.append(f"Parameter: {v.parameter}")
        lines += ["```", ""]

        if v.evidence:
            lines += ["### Evidence", "```", v.evidence[:600], "```", ""]

        if v.remediation:
            lines += ["### Remediation", v.remediation, ""]

        # Confidence
        conf = getattr(v, "confidence_score", None)
        if conf:
            lines += [f"**Confidence Score:** {conf:.0%}  ", ""]

        lines += ["---", ""]

    return "\n".join(lines)


def _generate_yeswehack(target: str, date: str, vulns) -> str:
    """YesWeHack-style submission format."""
    lines = [
        f"# Vulnerability Report — {target}",
        f"Date: {date}",
        f"Tool: BLACKMIRROR-X GLASSWING",
        "",
    ]
    for v in sorted(vulns,
            key=lambda x: {"critical":0,"high":1,"medium":2,"low":3}.get(_sev(x),4)):
        sev = _sev(v).upper()
        lines += [
            f"## {v.title or 'Finding'}",
            f"- **Severity:** {sev}",
            f"- **Type:** {v.vuln_type or 'Unknown'}",
            f"- **URL:** {v.url or 'N/A'}",
            f"- **Parameter:** {v.parameter or 'N/A'}",
            f"- **Verified:** {'Yes' if _is_verified(v) else 'No'}",
            "",
            "**Description:**",
            v.description or "N/A",
            "",
            "**Proof:**",
            f"```\n{(v.evidence or 'No evidence')[:500]}\n```",
            "",
            "**Fix:**",
            v.remediation or "See OWASP guidelines.",
            "",
            "---",
            "",
        ]
    return "\n".join(lines)


def _generate_markdown(target: str, date: str, vulns) -> str:
    """Full technical markdown report."""
    by_sev = {"critical": [], "high": [], "medium": [], "low": [], "info": []}
    for v in vulns:
        by_sev.setdefault(_sev(v), []).append(v)

    lines = [
        f"# BLACKMIRROR-X Security Assessment",
        f"**Target:** {target}  ",
        f"**Date:** {date}  ",
        f"**Platform:** BLACKMIRROR-X GLASSWING  ",
        "",
        "## Executive Summary",
        "",
        f"| Severity | Count | Verified |",
        f"|----------|-------|---------|",
    ]
    for sev, vlist in by_sev.items():
        verified = sum(1 for v in vlist if _is_verified(v))
        if vlist:
            lines.append(f"| {sev.upper()} | {len(vlist)} | {verified} |")

    lines += ["", "## Findings", ""]

    for sev in ["critical", "high", "medium", "low", "info"]:
        for v in by_sev.get(sev, []):
            verified_str = " [VERIFIED]" if _is_verified(v) else ""
            lines += [
                f"### {_sev(v).upper()}{verified_str} — {v.title or 'Finding'}",
                f"- **URL:** `{v.url or 'N/A'}`",
                f"- **Class:** {v.vuln_type or 'N/A'}",
                f"- **Parameter:** {v.parameter or 'N/A'}",
                "",
                v.description or "",
                "",
                "**Evidence:**",
                f"```\n{(v.evidence or 'None')[:400]}\n```",
                "",
                f"**Remediation:** {v.remediation or 'N/A'}",
                "",
            ]
    return "\n".join(lines)


def _generate_json(target: str, date: str, vulns) -> str:
    import json
    data = {
        "target": target,
        "date": date,
        "generator": "BLACKMIRROR-X GLASSWING",
        "findings": [{
            "id": str(v.id),
            "title": v.title,
            "severity": _sev(v),
            "vuln_type": v.vuln_type,
            "url": v.url,
            "parameter": v.parameter,
            "payload": v.payload,
            "evidence": (v.evidence or "")[:500],
            "description": v.description,
            "remediation": v.remediation,
            "verified": _is_verified(v),
            "confidence_score": getattr(v, "confidence_score", None),
            "cvss_score": getattr(v, "cvss_score", None),
        } for v in vulns]
    }
    return json.dumps(data, indent=2, default=str)


def _generate_executive(target: str, date: str, vulns) -> str:
    """Non-technical summary for management."""
    criticals = sum(1 for v in vulns if _sev(v) == "critical")
    highs = sum(1 for v in vulns if _sev(v) == "high")
    verified = sum(1 for v in vulns if _is_verified(v))

    risk = "CRITICAL" if criticals else "HIGH" if highs else "MEDIUM"

    return f"""# Security Assessment Executive Summary

**Target:** {target}
**Date:** {date}
**Overall Risk:** {risk}

## Key Findings

- **{len(vulns)}** total security issues discovered
- **{criticals}** critical severity (require immediate action)
- **{highs}** high severity (require urgent attention)
- **{verified}** findings independently verified with captured evidence

## Risk Summary

{f"⚠️ **{criticals} CRITICAL issues** were found that could lead to immediate system compromise." if criticals else ""}
{f"🔴 **{highs} HIGH severity issues** were identified that pose significant risk." if highs else ""}

## Recommendations

1. Address all critical findings within 24 hours
2. Schedule high severity remediation within 1 week
3. Retest after fixes are deployed

---
*Report generated by BLACKMIRROR-X GLASSWING — Authorized Security Research Platform*
"""
