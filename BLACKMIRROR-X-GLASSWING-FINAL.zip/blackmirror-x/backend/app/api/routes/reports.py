"""reports.py"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from pydantic import BaseModel
from datetime import datetime

from app.db.session import get_db
from app.models.models import Report, User, ScanJob
from app.api.deps.auth import get_current_user

router = APIRouter()


class ReportOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    scan_id: str
    title: str
    report_type: str
    summary: Optional[str]
    generated_by_ai: bool
    created_at: datetime


class ReportDetailOut(ReportOut):
    content: Optional[str]
    metadata: Optional[dict]


@router.post("/generate/{scan_id}", status_code=202)
async def generate_report(
    scan_id: str,
    report_type: str = "markdown",
    background_tasks: BackgroundTasks = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(ScanJob).where(ScanJob.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(404, "Scan not found")

    from app.workers.tasks import generate_report_task
    task = generate_report_task.apply_async(args=[scan_id, report_type])
    return {"task_id": task.id, "status": "queued"}


@router.get("", response_model=List[ReportOut])
async def list_reports(
    workspace_id: str = Query(...),
    scan_id: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(Report).where(Report.workspace_id == workspace_id)
    if scan_id:
        q = q.where(Report.scan_id == scan_id)
    q = q.order_by(desc(Report.created_at))
    result = await db.execute(q)
    return [ReportOut.model_validate(r) for r in result.scalars().all()]


@router.get("/{report_id}", response_model=ReportDetailOut)
async def get_report(
    report_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Report).where(Report.id == report_id))
    r = result.scalar_one_or_none()
    if not r:
        raise HTTPException(404, "Report not found")
    return ReportDetailOut.model_validate(r)
