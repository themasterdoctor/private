"""apikeys.py"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from datetime import datetime

from app.db.session import get_db
from app.models.models import APIKey, User
from app.api.deps.auth import get_current_user
from app.core.security import generate_api_key

router = APIRouter()


class APIKeyCreate(BaseModel):
    name: str
    workspace_id: Optional[str] = None
    scopes: List[str] = ["read", "write"]
    expires_at: Optional[datetime] = None


class APIKeyOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    name: str
    key_prefix: str
    scopes: list
    is_active: bool
    last_used_at: Optional[datetime]
    expires_at: Optional[datetime]
    created_at: datetime


class APIKeyCreated(APIKeyOut):
    raw_key: str = ""  # Only shown once — populated at creation


@router.post("", response_model=APIKeyCreated, status_code=201)
async def create_api_key(
    data: APIKeyCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    raw, hashed = generate_api_key()
    prefix = raw[:10]

    key = APIKey(
        user_id=current_user.id,
        workspace_id=data.workspace_id,
        name=data.name,
        key_hash=hashed,
        key_prefix=prefix,
        scopes=data.scopes,
        expires_at=data.expires_at,
    )
    db.add(key)
    await db.flush()

    out = APIKeyCreated.model_validate(key)
    out.raw_key = raw
    return out


@router.get("", response_model=List[APIKeyOut])
async def list_api_keys(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(APIKey).where(APIKey.user_id == current_user.id, APIKey.is_active == True)
    )
    return [APIKeyOut.model_validate(k) for k in result.scalars().all()]


@router.delete("/{key_id}", status_code=204)
async def revoke_api_key(
    key_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(APIKey).where(APIKey.id == key_id, APIKey.user_id == current_user.id)
    )
    key = result.scalar_one_or_none()
    if not key:
        raise HTTPException(404, "API key not found")
    key.is_active = False
