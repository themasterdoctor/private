"""
vulns.py — Vulnerability routes
Fixes:
  - VulnOut.discovered_at → created_at (frontend expects created_at)
  - Severity/VulnStatus enums serialized as .value strings
  - Missing workspace_id, AI scoring fields
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from pydantic import BaseModel, model_validator
from datetime import datetime

from app.db.session import get_db
from app.models.models import Vulnerability, User, VulnStatus, Severity
from app.api.deps.auth import get_current_user

router = APIRouter()


class VulnOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    scan_id: str
    workspace_id: Optional[str] = None
    title: str
    vuln_type: str
    severity: str
    status: str
    cvss_score: Optional[float] = None
    cwe_id: Optional[str] = None
    url: Optional[str] = None
    parameter: Optional[str] = None
    payload: Optional[str] = None
    evidence: Optional[str] = None
    description: Optional[str] = None
    remediation: Optional[str] = None
    tags: List[str] = []
    source: str = ""
    # Frontend uses created_at; ORM column is discovered_at
    created_at: datetime
    # AI scoring fields
    court_confidence: Optional[float] = None
    exploitability_score: Optional[float] = None
    bounty_likelihood: Optional[float] = None
    evidence_score: Optional[float] = None
    reproduction_steps: Optional[str] = None
    reflection_context: Optional[str] = None
    simulation_narrative: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def map_orm(cls, obj):
        if not hasattr(obj, "discovered_at"):
            return obj
        sev = getattr(obj, "severity", None)
        st = getattr(obj, "status", None)
        return {
            "id": str(getattr(obj, "id", "")),
            "scan_id": str(getattr(obj, "scan_id", "")),
            "workspace_id": str(getattr(obj, "workspace_id", "") or ""),
            "title": getattr(obj, "title", "") or "",
            "vuln_type": getattr(obj, "vuln_type", "") or "",
            "severity": sev.value if hasattr(sev, "value") else str(sev or "info"),
            "status": st.value if hasattr(st, "value") else str(st or "open"),
            "cvss_score": getattr(obj, "cvss_score", None),
            "cwe_id": getattr(obj, "cwe_id", None),
            "url": getattr(obj, "url", None) or "",
            "parameter": getattr(obj, "parameter", None),
            "payload": getattr(obj, "payload", None),
            "evidence": getattr(obj, "evidence", None),
            "description": getattr(obj, "description", None),
            "remediation": getattr(obj, "remediation", None),
            "tags": getattr(obj, "tags", []) or [],
            "source": getattr(obj, "source", "") or "",
            "created_at": getattr(obj, "discovered_at", datetime.utcnow()),
            "court_confidence": getattr(obj, "court_confidence", None),
            "exploitability_score": getattr(obj, "exploitability_score", None),
            "bounty_likelihood": getattr(obj, "bounty_likelihood", None),
            "evidence_score": getattr(obj, "evidence_score", None),
            "reproduction_steps": getattr(obj, "reproduction_steps", None),
            "reflection_context": getattr(obj, "reflection_context", None),
            "simulation_narrative": getattr(obj, "simulation_narrative", None),
        }


class VulnUpdate(BaseModel):
    status: Optional[str] = None
    description: Optional[str] = None
    remediation: Optional[str] = None
    cvss_score: Optional[float] = None
    tags: Optional[list] = None


@router.get("", response_model=List[VulnOut])
async def list_vulns(
    workspace_id: str = Query(...),
    scan_id: Optional[str] = Query(None),
    severity: Optional[str] = Query(None),
    vuln_type: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    limit: int = Query(100, le=500),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(Vulnerability).where(Vulnerability.workspace_id == workspace_id)
    if scan_id:
        q = q.where(Vulnerability.scan_id == scan_id)
    if severity:
        try:
            q = q.where(Vulnerability.severity == Severity(severity))
        except ValueError:
            pass
    if vuln_type:
        q = q.where(Vulnerability.vuln_type == vuln_type)
    if status:
        try:
            q = q.where(Vulnerability.status == VulnStatus(status))
        except ValueError:
            pass
    q = q.order_by(desc(Vulnerability.discovered_at)).limit(limit).offset(offset)
    result = await db.execute(q)
    return [VulnOut.model_validate(v) for v in result.scalars().all()]


@router.get("/{vuln_id}", response_model=VulnOut)
async def get_vuln(
    vuln_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Vulnerability).where(Vulnerability.id == vuln_id))
    v = result.scalar_one_or_none()
    if not v:
        raise HTTPException(404, "Vulnerability not found")
    return VulnOut.model_validate(v)


@router.patch("/{vuln_id}", response_model=VulnOut)
async def update_vuln(
    vuln_id: str,
    data: VulnUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Vulnerability).where(Vulnerability.id == vuln_id))
    v = result.scalar_one_or_none()
    if not v:
        raise HTTPException(404, "Vulnerability not found")
    if data.status:
        try:
            v.status = VulnStatus(data.status)
        except ValueError:
            raise HTTPException(400, f"Invalid status: {data.status}")
    if data.description is not None:
        v.description = data.description
    if data.remediation is not None:
        v.remediation = data.remediation
    if data.cvss_score is not None:
        v.cvss_score = data.cvss_score
    if data.tags is not None:
        v.tags = data.tags
    await db.flush()
    await db.commit()
    await db.refresh(v)
    return VulnOut.model_validate(v)


@router.get("/{vuln_id}/hackerone-report")
async def get_hackerone_report(
    vuln_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Vulnerability).where(Vulnerability.id == vuln_id))
    v = result.scalar_one_or_none()
    if not v:
        raise HTTPException(404, "Vulnerability not found")
    from app.agents.report_writer.agent import ReportWriterAgent
    sev = v.severity.value if hasattr(v.severity, "value") else str(v.severity)
    report = ReportWriterAgent().generate_hackerone_report({
        "title": v.title, "vuln_type": v.vuln_type, "severity": sev,
        "cvss_score": v.cvss_score, "url": v.url, "parameter": v.parameter,
        "payload": v.payload, "evidence": v.evidence,
        "description": v.description, "remediation": v.remediation,
    })
    return {"content": report, "format": "markdown"}
