from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import func, select, desc
import json, asyncio, structlog

from app.db.session import get_db
from app.models.models import (
    ScanJob, ScanLog, User, ScanStatus, ScanType,
    Subdomain, DiscoveredURL, Vulnerability,
)
from app.api.deps.auth import get_current_user
from app.schemas.scans import ScanCreateRequest, ScanOut, ScanLogOut, ScanListOut
from app.workers.tasks import run_scan_task

router = APIRouter()
logger = structlog.get_logger(__name__)


@router.post("", response_model=ScanOut, status_code=201)
async def create_scan(
    data: ScanCreateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    try:
        scan_type = ScanType(data.scan_type)
    except ValueError:
        scan_type = ScanType.FULL

    scan = ScanJob(
        workspace_id=data.workspace_id,
        target_id=data.target_id,
        created_by=current_user.id,
        name=data.name,
        scan_type=scan_type,
        config=data.config or {},
        status=ScanStatus.QUEUED,
    )
    db.add(scan)
    # MUST commit before queueing so worker can find the scan row
    await db.commit()
    await db.refresh(scan)

    scan_id_str = str(scan.id)
    try:
        task = run_scan_task.apply_async(
            args=[scan_id_str],
            task_id=f"scan_{scan_id_str}",
        )
        scan.celery_task_id = task.id
        await db.commit()
    except Exception as e:
        # Celery unavailable — scan stays QUEUED, worker can pick up via beat
        logger.warning("celery_queue_failed", error=str(e), scan_id=scan_id_str)

    logger.info("scan_created", scan_id=scan_id_str, type=data.scan_type)
    return ScanOut.model_validate(scan)


@router.get("", response_model=List[ScanListOut])
async def list_scans(
    workspace_id: str = Query(...),
    status: Optional[str] = Query(None),
    limit: int = Query(50, le=200),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(ScanJob).where(ScanJob.workspace_id == workspace_id)
    if status:
        try:
            q = q.where(ScanJob.status == ScanStatus(status))
        except ValueError:
            pass
    q = q.order_by(desc(ScanJob.created_at)).limit(limit).offset(offset)
    result = await db.execute(q)
    scans = result.scalars().all()
    out = []
    for s in scans:
        d = ScanListOut.model_validate(s)
        d.subdomain_count = (await db.execute(select(func.count()).where(Subdomain.scan_id == s.id))).scalar() or 0
        d.url_count = (await db.execute(select(func.count()).where(DiscoveredURL.scan_id == s.id))).scalar() or 0
        d.vuln_count = (await db.execute(select(func.count()).where(Vulnerability.scan_id == s.id))).scalar() or 0
        out.append(d)
    return out


@router.get("/{scan_id}", response_model=ScanOut)
async def get_scan(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(ScanJob).where(ScanJob.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    return ScanOut.model_validate(scan)


@router.post("/{scan_id}/cancel")
async def cancel_scan(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(ScanJob).where(ScanJob.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    if scan.status not in (ScanStatus.QUEUED, ScanStatus.RUNNING):
        raise HTTPException(status_code=400, detail="Scan cannot be cancelled in current state")
    if scan.celery_task_id:
        try:
            from app.workers.celery_app import celery_app
            celery_app.control.revoke(scan.celery_task_id, terminate=True)
        except Exception:
            pass
    scan.status = ScanStatus.CANCELLED
    await db.commit()
    return {"status": "cancelled"}


@router.get("/{scan_id}/logs", response_model=List[ScanLogOut])
async def get_scan_logs(
    scan_id: str,
    limit: int = Query(200, le=1000),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(ScanLog).where(ScanLog.scan_id == scan_id).order_by(ScanLog.timestamp).limit(limit)
    result = await db.execute(q)
    return [ScanLogOut.model_validate(l) for l in result.scalars().all()]


@router.get("/{scan_id}/stream")
async def stream_scan_logs(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """SSE endpoint — streams live scan log events."""
    async def event_generator():
        last_id = None
        while True:
            async with AsyncSession(db.bind) as session:
                q = select(ScanLog).where(ScanLog.scan_id == scan_id)
                if last_id:
                    q = q.where(ScanLog.id > last_id)
                q = q.order_by(ScanLog.timestamp).limit(50)
                logs = (await session.execute(q)).scalars().all()
            for log in logs:
                last_id = log.id
                yield f"data: {json.dumps({'id': log.id, 'level': log.level, 'module': log.module, 'message': log.message, 'timestamp': log.timestamp.isoformat()})}\n\n"

            async with AsyncSession(db.bind) as session:
                scan = (await session.execute(select(ScanJob).where(ScanJob.id == scan_id))).scalar_one_or_none()
                if scan and scan.status in (ScanStatus.COMPLETED, ScanStatus.FAILED, ScanStatus.CANCELLED):
                    sv = scan.status.value if hasattr(scan.status, "value") else str(scan.status)
                    yield f"data: {json.dumps({'type': 'done', 'status': sv})}\n\n"
                    break
            await asyncio.sleep(1)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
