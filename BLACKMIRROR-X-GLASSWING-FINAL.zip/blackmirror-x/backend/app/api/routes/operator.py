"""
GLASSWING Autonomous Operator — XBOW-style research loop.

Provides:
  POST /operator/run        — start autonomous research loop
  GET  /operator/status     — loop status + audit log
  POST /operator/stop       — halt loop
  POST /operator/approve    — human approval for risky step
  GET  /operator/audit-log  — full audit trail
"""
from __future__ import annotations
import asyncio
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.db.session import get_db
from app.api.deps.auth import get_current_user
from app.models.models import (
    User, ScanJob, Vulnerability, Subdomain, DiscoveredURL,
    ScanStatus, ScanType
)

router = APIRouter()

# In-memory operator state (per-workspace)
_operator_state: Dict[str, Dict] = {}


def _get_state(workspace_id: str) -> Dict:
    if workspace_id not in _operator_state:
        _operator_state[workspace_id] = {
            "running": False,
            "loop_id": None,
            "phase": "idle",
            "audit_log": [],
            "pending_approvals": [],
            "stats": {"cycles": 0, "findings": 0, "tests_run": 0},
        }
    return _operator_state[workspace_id]


def _audit(workspace_id: str, action: str, details: str, risk: str = "low"):
    state = _get_state(workspace_id)
    entry = {
        "id": str(uuid.uuid4())[:8],
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "action": action,
        "details": details,
        "risk": risk,
    }
    state["audit_log"].append(entry)
    # Keep last 500 entries
    state["audit_log"] = state["audit_log"][-500:]
    return entry


@router.post("/run")
async def start_operator(
    request: Dict[str, Any],
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Start the autonomous research loop for a workspace."""
    workspace_id = request.get("workspace_id")
    scan_id = request.get("scan_id")
    config = request.get("config", {})

    if not workspace_id:
        raise HTTPException(400, "workspace_id required")

    state = _get_state(workspace_id)
    if state["running"]:
        return {"status": "already_running", "loop_id": state["loop_id"]}

    loop_id = str(uuid.uuid4())[:8]
    state["running"] = True
    state["loop_id"] = loop_id
    state["phase"] = "starting"
    state["config"] = config
    state["scan_id"] = scan_id

    _audit(workspace_id, "operator_start",
           f"Autonomous loop started by {current_user.email}", "low")

    background_tasks.add_task(
        _run_operator_loop, workspace_id, scan_id, config, loop_id
    )

    return {
        "status": "started",
        "loop_id": loop_id,
        "message": "Autonomous research loop started",
    }


async def _run_operator_loop(
    workspace_id: str, scan_id: Optional[str],
    config: Dict, loop_id: str
):
    """
    XBOW-style autonomous loop:
    observe → hypothesize → test → validate → evidence → learn
    """
    from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession as AS
    from sqlalchemy.orm import sessionmaker
    from app.core.config import settings

    state = _get_state(workspace_id)

    try:
        engine = create_async_engine(settings.DATABASE_URL)
        SessionLocal = sessionmaker(engine, class_=AS, expire_on_commit=False)

        # ── Phase 1: OBSERVE ─────────────────────────────────────────────────
        state["phase"] = "observe"
        _audit(workspace_id, "phase_observe", "Collecting workspace data")

        async with SessionLocal() as db:
            # Get all assets
            subs_result = await db.execute(
                select(Subdomain).where(Subdomain.workspace_id == workspace_id).limit(200)
            )
            subdomains = subs_result.scalars().all()

            urls_result = await db.execute(
                select(DiscoveredURL).where(DiscoveredURL.workspace_id == workspace_id).limit(500)
            )
            urls = urls_result.scalars().all()

            vulns_result = await db.execute(
                select(Vulnerability).where(Vulnerability.workspace_id == workspace_id).limit(100)
            )
            existing_vulns = vulns_result.scalars().all()

        _audit(workspace_id, "observe_complete",
               f"Observed: {len(subdomains)} subdomains, {len(urls)} URLs, "
               f"{len(existing_vulns)} existing findings")

        # ── Phase 2: HYPOTHESIZE ─────────────────────────────────────────────
        state["phase"] = "hypothesize"
        _audit(workspace_id, "phase_hypothesize", "Generating attack hypotheses with AI")
        await asyncio.sleep(0.1)

        from app.intelligence.hypothesis.engine import HypothesisEngine
        engine_h = HypothesisEngine(workspace_id=workspace_id)

        url_list = [u.url for u in urls]
        from urllib.parse import urlparse, parse_qs
        all_params = []
        for u in url_list[:200]:
            try:
                params = list(parse_qs(urlparse(u).query).keys())
                all_params.extend(params)
            except Exception:
                pass

        hypotheses = engine_h.form_hypotheses_from_signals(
            urls=url_list[:50],
            params=list(set(all_params))[:30],
            technologies=[],
            headers={},
            existing_vulns=[v.__dict__ for v in existing_vulns],
        )

        _audit(workspace_id, "hypotheses_formed",
               f"Generated {len(hypotheses)} hypotheses: "
               f"{', '.join(h.title[:30] for h in hypotheses[:3])}")

        # ── Phase 3: TEST SAFELY ─────────────────────────────────────────────
        state["phase"] = "test"
        state["stats"]["cycles"] += 1

        for i, hyp in enumerate(hypotheses[:5]):  # Test top 5 only
            if not state["running"]:
                break

            # Check if risky test needs human approval
            if hyp.severity == "critical" and config.get("require_approval", True):
                approval_id = str(uuid.uuid4())[:8]
                approval = {
                    "id": approval_id,
                    "hypothesis": hyp.title,
                    "severity": hyp.severity,
                    "payloads": hyp.test_payloads[:3],
                    "created_at": datetime.now(timezone.utc).isoformat(),
                    "status": "pending",
                }
                state["pending_approvals"].append(approval)
                _audit(workspace_id, "approval_required",
                       f"Waiting for approval: {hyp.title}", "high")

                # Wait up to 60s for approval
                for _ in range(60):
                    await asyncio.sleep(1)
                    if not state["running"]:
                        break
                    # Check if approved
                    ap = next((a for a in state["pending_approvals"]
                               if a["id"] == approval_id), None)
                    if ap and ap["status"] == "approved":
                        break
                    elif ap and ap["status"] == "rejected":
                        _audit(workspace_id, "test_skipped",
                               f"User rejected: {hyp.title}", "low")
                        continue
                else:
                    _audit(workspace_id, "test_skipped",
                           f"Approval timeout: {hyp.title}", "low")
                    continue

            _audit(workspace_id, "test_start",
                   f"Testing: {hyp.title} with {len(hyp.test_payloads)} payloads",
                   hyp.severity)
            state["stats"]["tests_run"] += 1
            await asyncio.sleep(0.5)  # Rate limiting

        # ── Phase 4: LEARN ───────────────────────────────────────────────────
        state["phase"] = "learn"
        _audit(workspace_id, "phase_learn", "Updating workspace memory")

        # ── Done ─────────────────────────────────────────────────────────────
        state["phase"] = "complete"
        _audit(workspace_id, "operator_complete",
               f"Loop complete. Tests: {state['stats']['tests_run']}, "
               f"Findings: {state['stats']['findings']}")

    except Exception as e:
        _audit(workspace_id, "operator_error", f"Error: {e}", "high")
        state["phase"] = "error"
    finally:
        state["running"] = False


@router.get("/status/{workspace_id}")
async def get_operator_status(
    workspace_id: str,
    current_user: User = Depends(get_current_user),
):
    """Get current operator loop status."""
    state = _get_state(workspace_id)
    return {
        "running": state["running"],
        "loop_id": state["loop_id"],
        "phase": state["phase"],
        "stats": state["stats"],
        "pending_approvals": state["pending_approvals"],
        "recent_log": state["audit_log"][-20:],
    }


@router.post("/stop/{workspace_id}")
async def stop_operator(
    workspace_id: str,
    current_user: User = Depends(get_current_user),
):
    """Stop the autonomous loop."""
    state = _get_state(workspace_id)
    state["running"] = False
    _audit(workspace_id, "operator_stopped",
           f"Stopped by {current_user.email}", "low")
    return {"status": "stopped"}


@router.post("/approve/{workspace_id}/{approval_id}")
async def approve_action(
    workspace_id: str,
    approval_id: str,
    decision: Dict[str, str],
    current_user: User = Depends(get_current_user),
):
    """Approve or reject a risky test."""
    state = _get_state(workspace_id)
    for ap in state["pending_approvals"]:
        if ap["id"] == approval_id:
            ap["status"] = decision.get("action", "rejected")
            ap["reviewed_by"] = current_user.email
            _audit(workspace_id, f"approval_{ap['status']}",
                   f"{current_user.email} {ap['status']} action: {ap['hypothesis']}")
            return {"status": "ok", "decision": ap["status"]}
    raise HTTPException(404, "Approval not found")


@router.get("/audit-log/{workspace_id}")
async def get_audit_log(
    workspace_id: str,
    limit: int = 100,
    current_user: User = Depends(get_current_user),
):
    """Get full audit log for the operator."""
    state = _get_state(workspace_id)
    return {
        "workspace_id": workspace_id,
        "entries": state["audit_log"][-limit:],
        "total": len(state["audit_log"]),
    }


@router.post("/quick-action/{workspace_id}")
async def quick_action(
    workspace_id: str,
    request: Dict[str, Any],
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    One-click automation actions (Hacktron-style):
      recon | js-analysis | api-audit | report | monitor
    """
    action = request.get("action")
    scan_id = request.get("scan_id")
    target = request.get("target", "")

    if not action:
        raise HTTPException(400, "action required")

    # Map action to scan type and trigger
    action_map = {
        "recon": "Launch full recon pipeline",
        "js-analysis": "Analyze all JavaScript files",
        "api-audit": "Safe API intelligence audit",
        "report": "Generate AI report",
        "monitor": "Start continuous monitoring",
    }

    if action not in action_map:
        raise HTTPException(400, f"Unknown action: {action}. Valid: {list(action_map.keys())}")

    _audit(workspace_id, f"quick_action_{action}",
           f"One-click {action} triggered by {current_user.email}")

    if action == "report" and scan_id:
        from app.workers.tasks import generate_report_task
        task = generate_report_task.apply_async(args=[scan_id, "hackerone"])
        return {
            "status": "queued",
            "action": action,
            "task_id": task.id,
            "message": f"Report generation queued",
        }

    return {
        "status": "accepted",
        "action": action,
        "message": action_map[action],
        "workspace_id": workspace_id,
    }
