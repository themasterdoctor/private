"""
CORS middleware that always includes CORS headers,
including on error responses (401, 403, 422, 500).
FastAPI's built-in CORSMiddleware strips headers from error responses.
"""
import re
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response


class BroadCORSMiddleware(BaseHTTPMiddleware):
    """
    Always adds CORS headers to every response.
    Required because FastAPI CORSMiddleware doesn't add headers to error responses.
    """

    def __init__(self, app, allowed_origins: list[str]):
        super().__init__(app)
        self.allowed_origins = set(allowed_origins)
        # Also allow any http://<ip>:3000 pattern (for VPS deployments)
        self.ip_pattern = re.compile(r'^https?://\d+\.\d+\.\d+\.\d+:\d+$')

    def _origin_allowed(self, origin: str) -> bool:
        if not origin:
            return False
        if origin in self.allowed_origins:
            return True
        if self.ip_pattern.match(origin):
            return True
        return False

    async def dispatch(self, request: Request, call_next) -> Response:
        origin = request.headers.get("origin", "")

        # Handle preflight
        if request.method == "OPTIONS":
            response = Response(status_code=204)
            self._add_cors_headers(response, origin)
            return response

        response = await call_next(request)
        self._add_cors_headers(response, origin)
        return response

    def _add_cors_headers(self, response: Response, origin: str):
        allowed_origin = origin if self._origin_allowed(origin) else "*"
        response.headers["Access-Control-Allow-Origin"] = allowed_origin
        response.headers["Access-Control-Allow-Credentials"] = "true"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, PATCH, DELETE, OPTIONS"
        response.headers["Access-Control-Allow-Headers"] = (
            "Authorization, Content-Type, Accept, Origin, X-Requested-With"
        )
        response.headers["Access-Control-Max-Age"] = "86400"
        response.headers["Vary"] = "Origin"
