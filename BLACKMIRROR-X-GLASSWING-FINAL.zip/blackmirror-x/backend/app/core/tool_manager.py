"""
ToolManager — detects external security tools, installs missing ones.
Every capability is either available or clearly disabled with install instructions.
"""
from __future__ import annotations
import asyncio
import os
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Any, Dict, List
import structlog

logger = structlog.get_logger(__name__)


@dataclass
class ToolInfo:
    name: str
    binary: str
    category: str
    install_cmd: str
    version: str = ""
    available: bool = False
    path: str = ""
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "binary": self.binary,
            "category": self.category,
            "available": self.available,
            "version": self.version,
            "path": self.path,
            "install_cmd": self.install_cmd,
            "error": self.error,
        }


TOOLS = [
    ToolInfo("subfinder",   "subfinder",   "recon",   "go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"),
    ToolInfo("amass",       "amass",       "recon",   "go install github.com/owasp-amass/amass/v4/...@master"),
    ToolInfo("assetfinder", "assetfinder", "recon",   "go install github.com/tomnomnom/assetfinder@latest"),
    ToolInfo("dnsx",        "dnsx",        "recon",   "go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest"),
    ToolInfo("httpx",       "httpx",       "recon",   "go install github.com/projectdiscovery/httpx/cmd/httpx@latest"),
    ToolInfo("naabu",       "naabu",       "recon",   "go install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"),
    ToolInfo("katana",      "katana",      "crawler", "go install github.com/projectdiscovery/katana/cmd/katana@latest"),
    ToolInfo("gau",         "gau",         "crawler", "go install github.com/lc/gau/v2/cmd/gau@latest"),
    ToolInfo("waybackurls", "waybackurls", "crawler", "go install github.com/tomnomnom/waybackurls@latest"),
    ToolInfo("hakrawler",   "hakrawler",   "crawler", "go install github.com/hakluke/hakrawler@latest"),
    ToolInfo("nuclei",      "nuclei",      "scanner", "go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"),
    ToolInfo("ffuf",        "ffuf",        "fuzzer",  "go install github.com/ffuf/ffuf/v2@latest"),
]


class ToolManager:
    _instance: "ToolManager | None" = None
    _tools: Dict[str, ToolInfo] = {}
    _checked: bool = False

    def __new__(cls) -> "ToolManager":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def check_all(self) -> Dict[str, ToolInfo]:
        """Detect all tools."""
        go_paths = [
            "/root/go/bin", "/usr/local/go/bin",
            os.path.expanduser("~/go/bin"),
            "/go/bin",
        ]
        env_path = os.environ.get("PATH", "")
        for gp in go_paths:
            if gp not in env_path:
                os.environ["PATH"] = gp + ":" + env_path

        for tool in TOOLS:
            self._check_tool(tool)
            self._tools[tool.name] = tool
        self._checked = True

        available = [t.name for t in self._tools.values() if t.available]
        missing = [t.name for t in self._tools.values() if not t.available]
        logger.info("tools_checked", available=available, missing=missing)
        return self._tools

    def _check_tool(self, tool: ToolInfo) -> None:
        path = shutil.which(tool.binary)
        if not path:
            tool.available = False
            tool.error = f"Not found in PATH. Install: {tool.install_cmd}"
            return
        try:
            result = subprocess.run(
                [tool.binary, "-version"],
                capture_output=True, text=True, timeout=5
            )
            version_out = (result.stdout + result.stderr)[:80].strip()
            tool.available = True
            tool.path = path
            tool.version = version_out.split("\n")[0] if version_out else "unknown"
        except subprocess.TimeoutExpired:
            tool.available = True
            tool.path = path
            tool.version = "timeout"
        except FileNotFoundError:
            tool.available = False
            tool.error = f"Binary not found: {tool.binary}"
        except Exception as e:
            tool.available = True  # Binary exists, version check failed
            tool.path = path
            tool.error = str(e)

    def get_status(self) -> Dict[str, Any]:
        if not self._checked:
            self.check_all()
        tools_dict = {name: t.to_dict() for name, t in self._tools.items()}
        available = [n for n, t in self._tools.items() if t.available]
        missing = [n for n, t in self._tools.items() if not t.available]
        return {
            "tools": tools_dict,
            "available": available,
            "missing": missing,
            "total": len(self._tools),
            "available_count": len(available),
            "missing_count": len(missing),
        }

    def is_available(self, name: str) -> bool:
        if not self._checked:
            self.check_all()
        return self._tools.get(name, ToolInfo("", "", "", "")).available

    async def install_tool(self, name: str) -> Dict[str, Any]:
        """Attempt to install a missing tool."""
        tool = self._tools.get(name)
        if not tool:
            return {"success": False, "error": f"Unknown tool: {name}"}
        if tool.available:
            return {"success": True, "message": f"{name} already installed"}

        go_paths = "/usr/local/go/bin:/root/go/bin:" + os.environ.get("PATH", "")
        env = {**os.environ, "PATH": go_paths, "GOPATH": "/root/go"}

        try:
            cmd = tool.install_cmd.split()
            proc = await asyncio.create_subprocess_exec(
                *cmd, env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=300)
            if proc.returncode == 0:
                self._check_tool(tool)
                return {"success": tool.available, "output": stdout.decode()[-500:]}
            return {"success": False, "error": stderr.decode()[-500:]}
        except asyncio.TimeoutError:
            return {"success": False, "error": "Installation timed out (300s)"}
        except Exception as e:
            return {"success": False, "error": str(e)}


tool_manager = ToolManager()
