from typing import List, Optional, Union
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import AnyHttpUrl, field_validator
import secrets


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # App
    APP_NAME: str = "BLACKMIRROR-X GLASSWING"
    APP_ENV: str = "development"
    SECRET_KEY: str = secrets.token_hex(32)
    DEBUG: bool = False
    LOG_LEVEL: str = "INFO"

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://bmx:bmx_secret@localhost:5432/blackmirror"
    DATABASE_URL_SYNC: str = "postgresql://bmx:bmx_secret@localhost:5432/blackmirror"

    # Redis & Celery
    REDIS_URL: str = "redis://localhost:6379/0"
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"

    # JWT
    JWT_SECRET_KEY: str = secrets.token_hex(32)
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    JWT_REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    # AI
    AI_PROVIDER: str = "anthropic"
    ANTHROPIC_API_KEY: str = ""
    OPENAI_API_KEY: str = ""
    AI_MODEL: str = "claude-sonnet-4-20250514"
    AI_MAX_TOKENS: int = 8192
    AI_TEMPERATURE: float = 0.3

    # CORS
    CORS_ORIGINS: Union[List[str], str] = ["http://localhost:3000", "http://127.0.0.1:3000"]

    # Rate limiting
    RATE_LIMIT_PER_MINUTE: int = 300
    SCAN_RATE_LIMIT_PER_HOUR: int = 10

    # Scan
    SCAN_TIMEOUT_SECONDS: int = 3600
    MAX_CONCURRENT_SCANS: int = 5
    SCAN_ARTIFACTS_DIR: str = "/app/artifacts"
    MAX_SUBDOMAINS_PER_SCAN: int = 500
    MAX_URLS_PER_SCAN: int = 2000

    # Tool paths
    SUBFINDER_PATH: str = "subfinder"
    HTTPX_PATH: str = "httpx"
    DNSX_PATH: str = "dnsx"
    NAABU_PATH: str = "naabu"
    KATANA_PATH: str = "katana"
    NUCLEI_PATH: str = "nuclei"
    GAU_PATH: str = "gau"
    HAKRAWLER_PATH: str = "hakrawler"

    # Vector Store
    VECTOR_STORE: str = "pgvector"
    EMBEDDING_MODEL: str = "text-embedding-3-small"
    EMBEDDING_DIMENSIONS: int = 1536

    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def parse_cors(cls, v):
        if isinstance(v, str):
            return [i.strip() for i in v.split(",")]
        return v


settings = Settings()
