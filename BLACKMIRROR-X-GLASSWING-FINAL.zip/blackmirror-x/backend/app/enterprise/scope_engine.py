"""
Scope Enforcement Engine — BLACKMIRROR-X GLASSWING
Enforces authorized testing scope for every scan operation.

Features:
- Domain/IP/CIDR scope matching
- Out-of-scope automatic blocking
- Bug bounty program profiles import
- Full audit trail for every target checked
"""
from __future__ import annotations

import ipaddress
import re
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional
import fnmatch
import tldextract
import structlog

logger = structlog.get_logger(__name__)


@dataclass
class ScopeRule:
    """A single scope inclusion or exclusion rule."""
    pattern: str          # domain, *.domain.com, IP, or CIDR
    rule_type: str        # "include" | "exclude"
    source: str           # "manual" | "h1_import" | "ywh_import" | "intigriti"
    notes: str = ""
    added_at: float = field(default_factory=lambda: datetime.now(timezone.utc).timestamp())

    def matches(self, target: str) -> bool:
        """Check if target matches this rule pattern."""
        target = target.lower().strip()
        pattern = self.pattern.lower().strip()

        # Try CIDR match first
        try:
            network = ipaddress.ip_network(pattern, strict=False)
            try:
                addr = ipaddress.ip_address(target)
                return addr in network
            except ValueError:
                pass
        except ValueError:
            pass

        # Exact match
        if target == pattern:
            return True

        # Wildcard / glob match (*.example.com)
        if fnmatch.fnmatch(target, pattern):
            return True

        # Subdomain match: pattern=example.com matches api.example.com
        if target.endswith(f".{pattern}"):
            return True

        return False


@dataclass
class ProgramProfile:
    """Bug bounty program profile."""
    program_name: str
    platform: str          # hackerone, yeswehack, intigriti, bugcrowd, private
    program_url: str = ""
    scope_domains: list[str] = field(default_factory=list)
    out_of_scope: list[str] = field(default_factory=list)
    rules: str = ""        # Program rules text
    rewards: dict = field(default_factory=dict)   # { "critical": "$5000", ... }
    forbidden_testing: list[str] = field(default_factory=list)
    rate_limits: dict = field(default_factory=dict)
    report_preferences: str = ""
    known_duplicate_patterns: list[str] = field(default_factory=list)
    safe_harbor: bool = True
    created_at: float = field(default_factory=lambda: datetime.now(timezone.utc).timestamp())

    def to_dict(self) -> dict[str, Any]:
        return {
            "program_name": self.program_name,
            "platform": self.platform,
            "program_url": self.program_url,
            "scope_domains": self.scope_domains,
            "out_of_scope": self.out_of_scope,
            "rules": self.rules,
            "rewards": self.rewards,
            "forbidden_testing": self.forbidden_testing,
            "rate_limits": self.rate_limits,
            "report_preferences": self.report_preferences,
            "known_duplicate_patterns": self.known_duplicate_patterns,
            "safe_harbor": self.safe_harbor,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ProgramProfile":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class ScopeCheckResult:
    """Result of a scope check."""
    target: str
    allowed: bool
    reason: str
    matching_rule: Optional[str] = None
    risk_tier: str = "low"   # low, medium, high, blocked


class ScopeEngine:
    """
    Enforces authorized testing scope.
    Every target must pass through check_target() before scanning.
    """

    def __init__(self, workspace_id: str):
        self.workspace_id = workspace_id
        self.include_rules: list[ScopeRule] = []
        self.exclude_rules: list[ScopeRule] = []
        self.authorization_confirmed = False
        self.authorization_token: Optional[str] = None
        self.program_profile: Optional[ProgramProfile] = None
        self._audit_log: list[dict] = []

    def load_from_dict(self, data: dict) -> None:
        """Load scope configuration from database JSON."""
        self.include_rules = [
            ScopeRule(**r) for r in data.get("include_rules", [])
        ]
        self.exclude_rules = [
            ScopeRule(**r) for r in data.get("exclude_rules", [])
        ]
        self.authorization_confirmed = data.get("authorization_confirmed", False)
        self.authorization_token = data.get("authorization_token")
        if pp := data.get("program_profile"):
            self.program_profile = ProgramProfile.from_dict(pp)

    def to_dict(self) -> dict:
        return {
            "workspace_id": self.workspace_id,
            "include_rules": [vars(r) for r in self.include_rules],
            "exclude_rules": [vars(r) for r in self.exclude_rules],
            "authorization_confirmed": self.authorization_confirmed,
            "authorization_token": self.authorization_token,
            "program_profile": self.program_profile.to_dict() if self.program_profile else None,
        }

    def add_scope(self, pattern: str, source: str = "manual", notes: str = "") -> None:
        """Add an in-scope domain/IP/CIDR."""
        self.include_rules.append(ScopeRule(pattern=pattern, rule_type="include", source=source, notes=notes))
        logger.info("scope_added", pattern=pattern, workspace_id=self.workspace_id)

    def add_exclusion(self, pattern: str, source: str = "manual", notes: str = "") -> None:
        """Add an out-of-scope exclusion."""
        self.exclude_rules.append(ScopeRule(pattern=pattern, rule_type="exclude", source=source, notes=notes))
        logger.info("scope_excluded", pattern=pattern, workspace_id=self.workspace_id)

    def import_program(self, profile: ProgramProfile) -> None:
        """Import a bug bounty program profile into scope."""
        self.program_profile = profile
        for domain in profile.scope_domains:
            self.add_scope(domain, source=f"{profile.platform}_import", notes=f"From {profile.program_name}")
        for domain in profile.out_of_scope:
            self.add_exclusion(domain, source=f"{profile.platform}_import", notes=f"OOS from {profile.program_name}")
        logger.info("program_imported", program=profile.program_name, workspace_id=self.workspace_id)

    def check_target(self, target: str, user_id: str = "", action: str = "scan") -> ScopeCheckResult:
        """
        Check if a target is in scope. MUST be called before any scan action.
        Logs every check to the audit trail.
        """
        # Extract just the hostname/IP from a URL
        clean_target = self._extract_host(target)

        result = self._check(clean_target)

        # Audit log every check
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "user_id": user_id,
            "action": action,
            "target": target,
            "clean_target": clean_target,
            "allowed": result.allowed,
            "reason": result.reason,
            "workspace_id": self.workspace_id,
        }
        self._audit_log.append(entry)
        logger.info("scope_check", **entry)

        return result

    def _check(self, target: str) -> ScopeCheckResult:
        """Internal scope check logic."""
        # If no scope rules defined — allow by default (open scope)
        if not self.include_rules and not self.exclude_rules:
            return ScopeCheckResult(
                target=target,
                allowed=True,
                reason="no_scope_configured",
                risk_tier="medium",
            )

        # Check exclusions first — exclusions always win
        for rule in self.exclude_rules:
            if rule.matches(target):
                return ScopeCheckResult(
                    target=target,
                    allowed=False,
                    reason=f"out_of_scope: matches exclusion rule '{rule.pattern}'",
                    matching_rule=rule.pattern,
                    risk_tier="blocked",
                )

        # Check inclusions
        if self.include_rules:
            for rule in self.include_rules:
                if rule.matches(target):
                    return ScopeCheckResult(
                        target=target,
                        allowed=True,
                        reason=f"in_scope: matches rule '{rule.pattern}'",
                        matching_rule=rule.pattern,
                        risk_tier="low",
                    )
            # Inclusion rules defined but nothing matched
            return ScopeCheckResult(
                target=target,
                allowed=False,
                reason="not_in_scope: no matching inclusion rule",
                risk_tier="blocked",
            )

        return ScopeCheckResult(target=target, allowed=True, reason="default_allow", risk_tier="low")

    def _extract_host(self, target: str) -> str:
        """Extract hostname from URL or return as-is for IP/domain."""
        if "://" in target:
            from urllib.parse import urlparse
            parsed = urlparse(target)
            return parsed.hostname or target
        return target.split("/")[0].split(":")[0].lower()

    def get_audit_log(self, limit: int = 100) -> list[dict]:
        """Return recent audit log entries."""
        return self._audit_log[-limit:]

    @classmethod
    def parse_h1_program_json(cls, data: dict) -> ProgramProfile:
        """Parse a HackerOne program scope JSON export."""
        scope_domains = []
        out_of_scope = []

        for asset in data.get("relationships", {}).get("structured_scopes", {}).get("data", []):
            attrs = asset.get("attributes", {})
            identifier = attrs.get("asset_identifier", "")
            asset_type = attrs.get("asset_type", "")
            eligible = attrs.get("eligible_for_submission", True)
            in_scope = attrs.get("max_severity") is not None

            if asset_type in ("URL", "WILDCARD") and identifier:
                # Clean up identifier
                clean = identifier.replace("https://", "").replace("http://", "").rstrip("/")
                if in_scope and eligible:
                    scope_domains.append(clean)
                else:
                    out_of_scope.append(clean)

        return ProgramProfile(
            program_name=data.get("attributes", {}).get("name", "Unknown H1 Program"),
            platform="hackerone",
            program_url=f"https://hackerone.com/{data.get('attributes', {}).get('handle', '')}",
            scope_domains=scope_domains,
            out_of_scope=out_of_scope,
            rules=data.get("attributes", {}).get("policy", ""),
        )


# Global registry of workspace scope engines (in-memory, loaded from DB)
_scope_engines: dict[str, ScopeEngine] = {}


def get_scope_engine(workspace_id: str) -> ScopeEngine:
    """Get or create a scope engine for a workspace."""
    if workspace_id not in _scope_engines:
        _scope_engines[workspace_id] = ScopeEngine(workspace_id)
    return _scope_engines[workspace_id]


def invalidate_scope_cache(workspace_id: str) -> None:
    """Force reload of scope engine on next access."""
    _scope_engines.pop(workspace_id, None)
