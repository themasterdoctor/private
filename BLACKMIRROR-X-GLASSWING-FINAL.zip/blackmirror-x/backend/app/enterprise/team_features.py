"""
Team / Enterprise Features — BLACKMIRROR-X GLASSWING
Multi-user workspace management, RBAC, finding collaboration,
SLA tracking, and report approval workflows.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from enum import Enum
from typing import Any, Optional
import uuid
import structlog

logger = structlog.get_logger(__name__)


class TeamRole(str, Enum):
    OWNER = "owner"           # Full control, billing
    ADMIN = "admin"           # Manage team, all scan operations
    ANALYST = "analyst"       # Launch scans, triage findings
    VIEWER = "viewer"         # Read-only access
    REPORTER = "reporter"     # Can generate reports, no scanning


# Role permission matrix
ROLE_PERMISSIONS: dict[TeamRole, set[str]] = {
    TeamRole.OWNER: {
        "scan:create", "scan:cancel", "scan:delete",
        "vuln:triage", "vuln:assign", "vuln:override_severity",
        "vuln:mark_duplicate", "vuln:mark_fp",
        "report:create", "report:approve", "report:export",
        "workspace:manage", "workspace:delete",
        "team:manage", "team:invite", "team:remove",
        "apikey:manage", "billing:manage",
        "approval:approve", "approval:reject",
        "scope:manage", "emergency:stop",
    },
    TeamRole.ADMIN: {
        "scan:create", "scan:cancel",
        "vuln:triage", "vuln:assign", "vuln:override_severity",
        "vuln:mark_duplicate", "vuln:mark_fp",
        "report:create", "report:approve", "report:export",
        "workspace:manage",
        "team:manage", "team:invite",
        "apikey:manage",
        "approval:approve", "approval:reject",
        "scope:manage", "emergency:stop",
    },
    TeamRole.ANALYST: {
        "scan:create", "scan:cancel",
        "vuln:triage", "vuln:assign",
        "vuln:mark_duplicate", "vuln:mark_fp",
        "report:create", "report:export",
        "approval:approve",
    },
    TeamRole.VIEWER: {
        "report:export",
    },
    TeamRole.REPORTER: {
        "report:create", "report:export",
        "vuln:triage",
    },
}


def check_permission(role: str, permission: str) -> bool:
    """Check if a role has a specific permission."""
    try:
        team_role = TeamRole(role)
    except ValueError:
        return False
    return permission in ROLE_PERMISSIONS.get(team_role, set())


@dataclass
class FindingComment:
    """A comment on a vulnerability finding."""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:12])
    vuln_id: str = ""
    workspace_id: str = ""
    user_id: str = ""
    user_email: str = ""
    content: str = ""
    comment_type: str = "note"   # note, question, decision, fp_flag
    resolved: bool = False
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "vuln_id": self.vuln_id,
            "workspace_id": self.workspace_id,
            "user_id": self.user_id,
            "user_email": self.user_email,
            "content": self.content,
            "comment_type": self.comment_type,
            "resolved": self.resolved,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


@dataclass
class FindingAssignment:
    """Assignment of a vulnerability finding to a team member."""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:12])
    vuln_id: str = ""
    workspace_id: str = ""
    assigned_to: str = ""       # user_id
    assigned_by: str = ""       # user_id
    assigned_to_email: str = ""
    priority: str = "normal"    # low, normal, high, urgent
    due_date: Optional[str] = None
    notes: str = ""
    completed: bool = False
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "vuln_id": self.vuln_id,
            "workspace_id": self.workspace_id,
            "assigned_to": self.assigned_to,
            "assigned_by": self.assigned_by,
            "assigned_to_email": self.assigned_to_email,
            "priority": self.priority,
            "due_date": self.due_date,
            "notes": self.notes,
            "completed": self.completed,
            "created_at": self.created_at,
        }


@dataclass
class SLAPolicy:
    """SLA policy for vulnerability remediation tracking."""
    workspace_id: str = ""
    name: str = "Default SLA"

    # Days to remediate per severity
    critical_days: int = 1
    high_days: int = 7
    medium_days: int = 30
    low_days: int = 90
    info_days: int = 180

    # Notification thresholds (% of SLA remaining before alert)
    warning_threshold: float = 0.25   # warn at 25% remaining
    critical_threshold: float = 0.10  # critical alert at 10% remaining

    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def get_deadline(self, severity: str, discovered_at: datetime) -> datetime:
        """Calculate remediation deadline for a finding."""
        days_map = {
            "critical": self.critical_days,
            "high": self.high_days,
            "medium": self.medium_days,
            "low": self.low_days,
            "info": self.info_days,
        }
        days = days_map.get(severity.lower(), self.medium_days)
        return discovered_at + timedelta(days=days)

    def get_sla_status(self, severity: str, discovered_at: datetime, now: datetime = None) -> dict:
        """Get SLA status for a finding."""
        now = now or datetime.now(timezone.utc)
        deadline = self.get_deadline(severity, discovered_at)
        remaining = deadline - now
        days_remaining = remaining.days
        total_days = (deadline - discovered_at).days
        percent_remaining = max(0, remaining.total_seconds()) / max(1, (deadline - discovered_at).total_seconds())

        if days_remaining < 0:
            status = "breached"
        elif percent_remaining <= self.critical_threshold:
            status = "critical"
        elif percent_remaining <= self.warning_threshold:
            status = "warning"
        else:
            status = "on_track"

        return {
            "status": status,
            "deadline": deadline.isoformat(),
            "days_remaining": days_remaining,
            "percent_remaining": round(percent_remaining * 100, 1),
            "total_sla_days": total_days,
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "critical_days": self.critical_days,
            "high_days": self.high_days,
            "medium_days": self.medium_days,
            "low_days": self.low_days,
            "info_days": self.info_days,
        }


@dataclass
class ReportApprovalWorkflow:
    """Report approval workflow before export."""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:12])
    report_id: str = ""
    workspace_id: str = ""
    status: str = "draft"    # draft, in_review, approved, rejected, published
    submitted_by: str = ""
    submitted_at: Optional[str] = None
    reviewed_by: str = ""
    reviewed_at: Optional[str] = None
    approval_notes: str = ""
    rejection_reason: str = ""
    ai_quality_checks: dict = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "report_id": self.report_id,
            "workspace_id": self.workspace_id,
            "status": self.status,
            "submitted_by": self.submitted_by,
            "submitted_at": self.submitted_at,
            "reviewed_by": self.reviewed_by,
            "reviewed_at": self.reviewed_at,
            "approval_notes": self.approval_notes,
            "rejection_reason": self.rejection_reason,
            "ai_quality_checks": self.ai_quality_checks,
            "created_at": self.created_at,
        }


class ReportQualityChecker:
    """
    AI-powered report quality checker.
    Validates reports before export or submission.
    """

    async def check_report(self, report_content: str, vulns: list[dict]) -> dict[str, Any]:
        """Run all quality checks on a report."""
        checks = {}

        # Reproducibility check
        checks["reproducibility"] = self._check_reproducibility(vulns)

        # Clarity check
        checks["clarity"] = self._check_clarity(report_content)

        # Impact check
        checks["impact"] = self._check_impact(report_content, vulns)

        # Evidence strength check
        checks["evidence_strength"] = self._check_evidence(vulns)

        # Scope compliance
        checks["scope_compliance"] = self._check_scope_compliance(report_content)

        # Duplicate risk
        checks["duplicate_risk"] = self._check_duplicate_risk(vulns)

        # Overall quality score
        scores = [c["score"] for c in checks.values() if "score" in c]
        checks["overall_score"] = round(sum(scores) / max(len(scores), 1), 2)
        checks["ready_to_submit"] = checks["overall_score"] >= 0.70

        return checks

    def _check_reproducibility(self, vulns: list[dict]) -> dict:
        issues = []
        score = 1.0
        for v in vulns:
            if not v.get("reproduction_steps") and not v.get("payload"):
                issues.append(f"'{v.get('title', 'Unknown')}' missing reproduction steps")
                score -= 0.15
            if not v.get("url"):
                issues.append(f"'{v.get('title', 'Unknown')}' missing affected URL")
                score -= 0.10
        return {
            "score": max(0.0, score),
            "passed": score >= 0.7,
            "issues": issues,
            "message": "All findings reproducible" if not issues else f"{len(issues)} findings need reproduction steps",
        }

    def _check_clarity(self, content: str) -> dict:
        score = 1.0
        issues = []
        word_count = len(content.split())
        if word_count < 100:
            issues.append("Report is too brief (under 100 words)")
            score -= 0.30
        if "TODO" in content or "PLACEHOLDER" in content:
            issues.append("Report contains unfilled placeholders")
            score -= 0.40
        sections = ["Summary", "Impact", "Remediation"]
        for section in sections:
            if section.lower() not in content.lower():
                issues.append(f"Missing '{section}' section")
                score -= 0.10
        return {
            "score": max(0.0, score),
            "passed": score >= 0.7,
            "issues": issues,
            "message": "Report is clear and complete" if not issues else f"{len(issues)} clarity issues",
        }

    def _check_impact(self, content: str, vulns: list[dict]) -> dict:
        score = 0.8
        issues = []
        critical_vulns = [v for v in vulns if v.get("severity") in ("critical", "high")]
        if critical_vulns and "impact" not in content.lower():
            issues.append("Critical/high findings should have explicit impact description")
            score -= 0.20
        if not any(v.get("cvss_score") for v in vulns):
            issues.append("No CVSS scores assigned to findings")
            score -= 0.10
        return {
            "score": max(0.0, score),
            "passed": score >= 0.6,
            "issues": issues,
            "message": "Impact clearly described" if not issues else f"{len(issues)} impact gaps",
        }

    def _check_evidence(self, vulns: list[dict]) -> dict:
        score = 1.0
        issues = []
        for v in vulns:
            if v.get("severity") in ("critical", "high"):
                if not v.get("evidence") and not v.get("payload"):
                    issues.append(f"Critical/high finding '{v.get('title', '')}' lacks evidence")
                    score -= 0.20
        return {
            "score": max(0.0, score),
            "passed": score >= 0.6,
            "issues": issues,
            "message": "Evidence adequate" if not issues else f"{len(issues)} findings need more evidence",
        }

    def _check_scope_compliance(self, content: str) -> dict:
        issues = []
        score = 1.0
        if "out of scope" in content.lower():
            issues.append("Report mentions out-of-scope items — verify scope compliance")
            score -= 0.30
        return {
            "score": score,
            "passed": score >= 0.7,
            "issues": issues,
            "message": "Scope compliant" if not issues else "Scope issues detected",
        }

    def _check_duplicate_risk(self, vulns: list[dict]) -> dict:
        score = 0.8
        issues = []
        common_dupes = ["missing hsts", "clickjacking", "server header", "x-powered-by"]
        for v in vulns:
            title_lower = v.get("title", "").lower()
            if any(d in title_lower for d in common_dupes):
                if v.get("severity") in ("critical", "high"):
                    issues.append(f"'{v.get('title')}' is often a known duplicate — verify novelty")
                    score -= 0.10
        return {
            "score": max(0.0, score),
            "passed": True,  # just informational
            "issues": issues,
            "message": "Low duplicate risk" if not issues else f"{len(issues)} possible duplicates",
        }
