"""
Evidence Engine — BLACKMIRROR-X GLASSWING
Captures, stores, and structures proof for vulnerability findings.

Captures:
- Full HTTP request/response pairs
- Screenshots (base64 PNG)
- curl command reconstruction
- Timestamps and timing
- Headers and cookies
- Redirect chains
- Auto-builds proof sections for reports
"""
from __future__ import annotations

import base64
import hashlib
import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional
import structlog

logger = structlog.get_logger(__name__)


@dataclass
class HttpEvidence:
    """Captured HTTP request/response pair."""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:12])
    vuln_id: str = ""
    scan_id: str = ""
    workspace_id: str = ""

    # Request
    method: str = "GET"
    url: str = ""
    request_headers: dict = field(default_factory=dict)
    request_body: str = ""
    request_cookies: dict = field(default_factory=dict)

    # Response
    status_code: int = 0
    response_headers: dict = field(default_factory=dict)
    response_body: str = ""
    response_time_ms: int = 0
    redirect_chain: list[dict] = field(default_factory=list)

    # Proof
    payload_used: str = ""
    reflection_context: str = ""
    indicator_found: str = ""  # what triggered the finding
    screenshot_b64: str = ""   # PNG screenshot if available
    screenshot_url: str = ""   # URL that was screenshotted

    # Metadata
    captured_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    evidence_hash: str = ""
    confidence_score: float = 0.7
    is_primary: bool = True     # primary PoC vs supporting evidence

    def __post_init__(self):
        if not self.evidence_hash:
            content = f"{self.method}{self.url}{self.status_code}{self.indicator_found}"
            self.evidence_hash = hashlib.sha256(content.encode()).hexdigest()[:16]

    def to_curl(self) -> str:
        """Generate reproducible curl command."""
        parts = [f"curl -v -X {self.method}"]
        for k, v in self.request_headers.items():
            if k.lower() not in ("host", "content-length", "connection"):
                safe_v = v.replace("'", "\\'")
                parts.append(f"-H '{k}: {safe_v}'")
        if self.request_cookies:
            cookie_str = "; ".join(f"{k}={v}" for k, v in self.request_cookies.items())
            parts.append(f"--cookie '{cookie_str}'")
        if self.request_body:
            escaped = self.request_body.replace("'", "\\'")
            parts.append(f"--data '{escaped}'")
        parts.append(f"'{self.url}'")
        return " \\\n  ".join(parts)

    def to_proof_section(self) -> str:
        """Generate formatted proof section for reports."""
        lines = [
            f"## Proof of Concept",
            f"",
            f"**Captured:** {self.captured_at}",
            f"**Payload:** `{self.payload_used}`",
            f"**Indicator:** {self.indicator_found}",
            f"**Evidence Hash:** `{self.evidence_hash}`",
            f"",
            f"### Request",
            f"```http",
            f"{self.method} {self.url}",
        ]
        for k, v in self.request_headers.items():
            lines.append(f"{k}: {v}")
        if self.request_body:
            lines.extend(["", self.request_body])
        lines.extend(["```", ""])

        lines.extend([
            f"### Response",
            f"```http",
            f"HTTP/1.1 {self.status_code}",
        ])
        for k, v in list(self.response_headers.items())[:10]:
            lines.append(f"{k}: {v}")
        if self.response_body:
            preview = self.response_body[:500]
            if len(self.response_body) > 500:
                preview += f"\n... [{len(self.response_body) - 500} bytes truncated]"
            lines.extend(["", preview])
        lines.extend(["```", ""])

        if self.redirect_chain:
            lines.append("### Redirect Chain")
            for i, hop in enumerate(self.redirect_chain, 1):
                lines.append(f"{i}. `{hop.get('url', '')}` → {hop.get('status', '')}")
            lines.append("")

        lines.extend([
            f"### curl Reproduction",
            f"```bash",
            self.to_curl(),
            f"```",
        ])

        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "vuln_id": self.vuln_id,
            "scan_id": self.scan_id,
            "workspace_id": self.workspace_id,
            "method": self.method,
            "url": self.url,
            "request_headers": self.request_headers,
            "request_body": self.request_body,
            "request_cookies": self.request_cookies,
            "status_code": self.status_code,
            "response_headers": self.response_headers,
            "response_body": self.response_body[:2000] if self.response_body else "",
            "response_time_ms": self.response_time_ms,
            "redirect_chain": self.redirect_chain,
            "payload_used": self.payload_used,
            "reflection_context": self.reflection_context,
            "indicator_found": self.indicator_found,
            "has_screenshot": bool(self.screenshot_b64),
            "screenshot_url": self.screenshot_url,
            "captured_at": self.captured_at,
            "evidence_hash": self.evidence_hash,
            "confidence_score": self.confidence_score,
            "is_primary": self.is_primary,
        }


@dataclass
class EvidencePackage:
    """Complete evidence package for a vulnerability."""
    vuln_id: str
    scan_id: str
    workspace_id: str
    primary_evidence: Optional[HttpEvidence] = None
    supporting_evidence: list[HttpEvidence] = field(default_factory=list)
    screenshots: list[str] = field(default_factory=list)  # base64 PNGs
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def add_evidence(self, evidence: HttpEvidence, primary: bool = False) -> None:
        evidence.vuln_id = self.vuln_id
        evidence.scan_id = self.scan_id
        evidence.workspace_id = self.workspace_id
        if primary or self.primary_evidence is None:
            evidence.is_primary = True
            self.primary_evidence = evidence
        else:
            evidence.is_primary = False
            self.supporting_evidence.append(evidence)

    def add_screenshot(self, b64_png: str, url: str = "") -> None:
        self.screenshots.append(b64_png)
        if self.primary_evidence:
            self.primary_evidence.screenshot_b64 = b64_png
            self.primary_evidence.screenshot_url = url

    def build_report_section(self) -> str:
        """Build complete evidence section for report."""
        parts = []
        if self.primary_evidence:
            parts.append(self.primary_evidence.to_proof_section())
        for i, ev in enumerate(self.supporting_evidence[:3], 1):
            parts.append(f"### Supporting Evidence #{i}")
            parts.append(ev.to_proof_section())
        return "\n\n".join(parts)

    def to_dict(self) -> dict[str, Any]:
        return {
            "vuln_id": self.vuln_id,
            "scan_id": self.scan_id,
            "workspace_id": self.workspace_id,
            "primary_evidence": self.primary_evidence.to_dict() if self.primary_evidence else None,
            "supporting_evidence": [e.to_dict() for e in self.supporting_evidence],
            "screenshot_count": len(self.screenshots),
            "created_at": self.created_at,
        }


class EvidenceCapture:
    """
    Captures HTTP evidence during scanning.
    Integrates with httpx to record full request/response pairs.
    """

    @staticmethod
    async def capture_from_httpx(
        response,  # httpx.Response
        payload: str = "",
        indicator: str = "",
        reflection_context: str = "",
    ) -> HttpEvidence:
        """Capture evidence from an httpx response object."""
        try:
            import httpx
            req = response.request

            evidence = HttpEvidence(
                method=req.method,
                url=str(req.url),
                request_headers=dict(req.headers),
                request_body=req.content.decode("utf-8", errors="replace") if req.content else "",
                status_code=response.status_code,
                response_headers=dict(response.headers),
                response_body=response.text[:5000] if hasattr(response, "text") else "",
                response_time_ms=int(response.elapsed.total_seconds() * 1000) if hasattr(response, "elapsed") and response.elapsed else 0,
                payload_used=payload,
                indicator_found=indicator,
                reflection_context=reflection_context,
            )

            # Capture redirect chain
            if hasattr(response, "history") and response.history:
                for hop in response.history:
                    evidence.redirect_chain.append({
                        "url": str(hop.url),
                        "status": hop.status_code,
                        "location": hop.headers.get("location", ""),
                    })

            return evidence
        except Exception as e:
            logger.warning("evidence_capture_failed", error=str(e))
            return HttpEvidence(
                method="GET",
                url=str(response.request.url) if hasattr(response, "request") else "",
                status_code=getattr(response, "status_code", 0),
                payload_used=payload,
                indicator_found=indicator,
            )

    @staticmethod
    def capture_manual(
        method: str, url: str,
        request_headers: dict = None,
        request_body: str = "",
        status_code: int = 0,
        response_headers: dict = None,
        response_body: str = "",
        response_time_ms: int = 0,
        payload: str = "",
        indicator: str = "",
    ) -> HttpEvidence:
        """Manually construct evidence from raw data."""
        return HttpEvidence(
            method=method,
            url=url,
            request_headers=request_headers or {},
            request_body=request_body,
            status_code=status_code,
            response_headers=response_headers or {},
            response_body=response_body[:5000],
            response_time_ms=response_time_ms,
            payload_used=payload,
            indicator_found=indicator,
        )
