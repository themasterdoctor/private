"""
Confidence Scoring System — BLACKMIRROR-X GLASSWING
Every finding gets a complete score profile:
- confidence_score: how certain are we this is real
- exploitability_score: how easy to exploit
- business_impact_score: severity of business consequence
- false_positive_risk: probability of being a false positive
- recommended_action: next step for the researcher
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional
import structlog

logger = structlog.get_logger(__name__)


class RecommendedAction(str, Enum):
    REPORT_IMMEDIATELY = "report_immediately"
    MANUAL_VERIFY = "manual_verify"
    NEEDS_MORE_EVIDENCE = "needs_more_evidence"
    INVESTIGATE_FURTHER = "investigate_further"
    LIKELY_FALSE_POSITIVE = "likely_false_positive"
    LAB_ONLY = "lab_only"
    MONITOR = "monitor"


@dataclass
class ConfidenceProfile:
    """Complete confidence profile for a vulnerability finding."""
    vuln_id: str = ""
    vuln_type: str = ""
    severity: str = "medium"

    # Core scores (0.0 - 1.0)
    confidence_score: float = 0.5           # How certain the finding is real
    exploitability_score: float = 0.5       # How easy to exploit in practice
    business_impact_score: float = 0.5      # Business/revenue impact if exploited
    false_positive_risk: float = 0.3        # Probability this is a false positive
    evidence_strength: float = 0.5          # Quality and quantity of evidence
    reproducibility_score: float = 0.5      # Can be reliably reproduced

    # Derived scores
    overall_score: float = 0.0             # Weighted composite
    bounty_likelihood: float = 0.5         # Probability of bounty acceptance

    # Action
    recommended_action: RecommendedAction = RecommendedAction.MANUAL_VERIFY
    action_reason: str = ""

    # Context
    waf_detected: bool = False
    requires_auth: bool = False
    user_interaction_required: bool = False
    scope_confirmed: bool = False
    duplicate_risk: float = 0.1            # Probability already reported

    # Scoring breakdown
    scoring_factors: dict = field(default_factory=dict)

    def __post_init__(self):
        if self.overall_score == 0.0:
            self.calculate_overall()

    def calculate_overall(self) -> float:
        """Calculate weighted overall score."""
        weights = {
            "confidence_score": 0.30,
            "exploitability_score": 0.25,
            "business_impact_score": 0.20,
            "evidence_strength": 0.15,
            "reproducibility_score": 0.10,
        }
        total = sum(
            getattr(self, field) * weight
            for field, weight in weights.items()
        )
        # Penalize false positive risk
        fp_penalty = self.false_positive_risk * 0.3
        self.overall_score = max(0.0, min(1.0, total - fp_penalty))
        return self.overall_score

    def determine_action(self) -> RecommendedAction:
        """Determine recommended next action based on scores."""
        if self.false_positive_risk > 0.7:
            action = RecommendedAction.LIKELY_FALSE_POSITIVE
            reason = f"High false positive risk ({self.false_positive_risk:.0%})"
        elif self.overall_score >= 0.80 and self.confidence_score >= 0.75:
            action = RecommendedAction.REPORT_IMMEDIATELY
            reason = "High confidence, strong evidence — ready for submission"
        elif self.overall_score >= 0.65 and self.evidence_strength < 0.5:
            action = RecommendedAction.NEEDS_MORE_EVIDENCE
            reason = "Promising finding but needs stronger proof-of-concept"
        elif self.overall_score >= 0.60:
            action = RecommendedAction.MANUAL_VERIFY
            reason = "Verify manually before reporting"
        elif self.waf_detected and self.exploitability_score < 0.4:
            action = RecommendedAction.LAB_ONLY
            reason = "WAF detected — test in lab environment first"
        else:
            action = RecommendedAction.INVESTIGATE_FURTHER
            reason = "Needs further investigation to confirm impact"

        self.recommended_action = action
        self.action_reason = reason
        return action

    def to_dict(self) -> dict[str, Any]:
        return {
            "vuln_id": self.vuln_id,
            "vuln_type": self.vuln_type,
            "severity": self.severity,
            "confidence_score": round(self.confidence_score, 3),
            "exploitability_score": round(self.exploitability_score, 3),
            "business_impact_score": round(self.business_impact_score, 3),
            "false_positive_risk": round(self.false_positive_risk, 3),
            "evidence_strength": round(self.evidence_strength, 3),
            "reproducibility_score": round(self.reproducibility_score, 3),
            "overall_score": round(self.overall_score, 3),
            "bounty_likelihood": round(self.bounty_likelihood, 3),
            "recommended_action": self.recommended_action.value,
            "action_reason": self.action_reason,
            "waf_detected": self.waf_detected,
            "requires_auth": self.requires_auth,
            "user_interaction_required": self.user_interaction_required,
            "scope_confirmed": self.scope_confirmed,
            "duplicate_risk": round(self.duplicate_risk, 3),
            "scoring_factors": self.scoring_factors,
        }


# Scoring rules per vulnerability type
VULN_SCORING_RULES: dict[str, dict] = {
    "xss": {
        "base_confidence": 0.60,
        "base_exploitability": 0.70,
        "base_business_impact": 0.65,
        "base_fp_risk": 0.25,
        "indicators": {
            "dom_execution_confirmed": +0.25,
            "csp_present": -0.20,
            "stored_xss": +0.15,
            "only_alert_reflection": -0.10,
        },
    },
    "sqli": {
        "base_confidence": 0.55,
        "base_exploitability": 0.75,
        "base_business_impact": 0.90,
        "base_fp_risk": 0.30,
        "indicators": {
            "boolean_blind_confirmed": +0.30,
            "time_based_confirmed": +0.25,
            "error_based": +0.20,
            "waf_detected": -0.25,
        },
    },
    "ssrf": {
        "base_confidence": 0.50,
        "base_exploitability": 0.65,
        "base_business_impact": 0.85,
        "base_fp_risk": 0.35,
        "indicators": {
            "internal_response_received": +0.35,
            "metadata_accessed": +0.40,
            "out_of_band_confirmed": +0.30,
        },
    },
    "idor": {
        "base_confidence": 0.65,
        "base_exploitability": 0.80,
        "base_business_impact": 0.80,
        "base_fp_risk": 0.20,
        "indicators": {
            "different_user_data_accessed": +0.30,
            "sequential_ids": +0.10,
            "uuid_ids": -0.05,
        },
    },
    "ssti": {
        "base_confidence": 0.55,
        "base_exploitability": 0.80,
        "base_business_impact": 0.95,
        "base_fp_risk": 0.30,
        "indicators": {
            "rce_payload_executed": +0.40,
            "math_expression_evaluated": +0.25,
        },
    },
    "cors": {
        "base_confidence": 0.70,
        "base_exploitability": 0.55,
        "base_business_impact": 0.60,
        "base_fp_risk": 0.20,
        "indicators": {
            "credentials_allowed": +0.25,
            "sensitive_endpoint": +0.15,
            "preflight_misconfigured": +0.10,
        },
    },
    "open_redirect": {
        "base_confidence": 0.75,
        "base_exploitability": 0.60,
        "base_business_impact": 0.50,
        "base_fp_risk": 0.15,
        "indicators": {
            "oauth_callback": +0.20,
            "post_login": +0.15,
        },
    },
    "missing_security_header": {
        "base_confidence": 0.90,
        "base_exploitability": 0.30,
        "base_business_impact": 0.30,
        "base_fp_risk": 0.05,
        "indicators": {},
    },
    "jwt": {
        "base_confidence": 0.60,
        "base_exploitability": 0.75,
        "base_business_impact": 0.90,
        "base_fp_risk": 0.25,
        "indicators": {
            "none_alg_accepted": +0.35,
            "hs_rs_confusion": +0.35,
            "weak_secret": +0.20,
        },
    },
}


def score_finding(
    vuln_type: str,
    severity: str,
    indicators: dict[str, bool] = None,
    evidence_count: int = 1,
    has_screenshot: bool = False,
    has_request_response: bool = False,
    waf_detected: bool = False,
    requires_auth: bool = False,
    scope_confirmed: bool = True,
) -> ConfidenceProfile:
    """
    Score a vulnerability finding using type-specific rules.
    Returns a complete ConfidenceProfile.
    """
    indicators = indicators or {}
    rules = VULN_SCORING_RULES.get(vuln_type, {
        "base_confidence": 0.50,
        "base_exploitability": 0.50,
        "base_business_impact": 0.50,
        "base_fp_risk": 0.35,
        "indicators": {},
    })

    confidence = rules["base_confidence"]
    exploitability = rules["base_exploitability"]
    business_impact = rules["base_business_impact"]
    fp_risk = rules["base_fp_risk"]
    scoring_factors = {}

    # Apply indicator adjustments
    for indicator_name, adjustment in rules.get("indicators", {}).items():
        if indicators.get(indicator_name):
            if "confidence" in indicator_name.lower() or adjustment > 0:
                confidence += adjustment * 0.5
                exploitability += adjustment * 0.3
            fp_risk -= adjustment * 0.2
            scoring_factors[indicator_name] = adjustment

    # Evidence quality boosts
    if has_screenshot:
        confidence += 0.05
        scoring_factors["has_screenshot"] = +0.05
    if has_request_response:
        confidence += 0.08
        scoring_factors["request_response_captured"] = +0.08
    if evidence_count >= 3:
        confidence += 0.05
        scoring_factors["multiple_evidence"] = +0.05

    # WAF penalty
    if waf_detected:
        exploitability -= 0.20
        fp_risk += 0.10
        scoring_factors["waf_detected"] = -0.20

    # Auth requirement (reduces exploitability slightly)
    if requires_auth:
        exploitability -= 0.10
        scoring_factors["requires_auth"] = -0.10

    # Scope confirmation
    if not scope_confirmed:
        fp_risk += 0.15
        scoring_factors["scope_not_confirmed"] = -0.15

    # Severity-based business impact override
    severity_impact_map = {
        "critical": 0.95, "high": 0.80, "medium": 0.55, "low": 0.30, "info": 0.10,
    }
    business_impact = max(business_impact, severity_impact_map.get(severity, 0.50))

    # Evidence strength
    evidence_strength = min(1.0, (
        (0.3 if has_request_response else 0.0) +
        (0.2 if has_screenshot else 0.0) +
        (0.3 if evidence_count >= 2 else 0.15) +
        (0.2 * min(evidence_count / 5, 1.0))
    ))

    # Clamp all scores
    def clamp(v): return max(0.0, min(1.0, v))

    profile = ConfidenceProfile(
        vuln_type=vuln_type,
        severity=severity,
        confidence_score=clamp(confidence),
        exploitability_score=clamp(exploitability),
        business_impact_score=clamp(business_impact),
        false_positive_risk=clamp(fp_risk),
        evidence_strength=clamp(evidence_strength),
        reproducibility_score=clamp(confidence * 0.8),
        waf_detected=waf_detected,
        requires_auth=requires_auth,
        scope_confirmed=scope_confirmed,
        scoring_factors=scoring_factors,
    )
    profile.calculate_overall()
    profile.determine_action()

    # Bounty likelihood
    profile.bounty_likelihood = clamp(
        profile.overall_score * 0.8 +
        profile.exploitability_score * 0.1 +
        (0.1 if scope_confirmed else -0.2)
    )

    return profile
