"""
Plugin SDK — BLACKMIRROR-X GLASSWING
Framework for custom scanner plugins, payload generators, report templates,
enrichment sources, and scoring logic.

Plugin types:
- ScannerPlugin: custom vulnerability scanners
- PayloadPlugin: custom payload generators
- ReportPlugin: custom report templates
- EnrichmentPlugin: custom data enrichment
- ScoringPlugin: custom risk scoring

Usage:
    @register_plugin("my_scanner", PluginType.SCANNER)
    class MyScanner(ScannerPlugin):
        async def run(self, target, config): ...
"""
from __future__ import annotations

import abc
import inspect
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Optional, Type
import structlog

logger = structlog.get_logger(__name__)


class PluginType(str, Enum):
    SCANNER = "scanner"
    PAYLOAD = "payload"
    REPORT = "report"
    ENRICHMENT = "enrichment"
    SCORING = "scoring"


@dataclass
class PluginManifest:
    """Plugin metadata and configuration."""
    name: str
    plugin_type: PluginType
    version: str = "1.0.0"
    description: str = ""
    author: str = ""
    tags: list[str] = field(default_factory=list)
    config_schema: dict = field(default_factory=dict)   # JSON schema for config
    is_enabled: bool = True
    requires: list[str] = field(default_factory=list)   # dependencies
    registered_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "plugin_type": self.plugin_type.value,
            "version": self.version,
            "description": self.description,
            "author": self.author,
            "tags": self.tags,
            "is_enabled": self.is_enabled,
            "registered_at": self.registered_at,
        }


@dataclass
class PluginResult:
    """Standardized result from any plugin execution."""
    plugin_name: str
    success: bool
    findings: list[dict] = field(default_factory=list)
    enrichments: dict = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)
    executed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return {
            "plugin_name": self.plugin_name,
            "success": self.success,
            "findings": self.findings,
            "enrichments": self.enrichments,
            "errors": self.errors,
            "metadata": self.metadata,
            "executed_at": self.executed_at,
        }


# ─── Base Plugin Classes ───────────────────────────────────────────────────────

class BasePlugin(abc.ABC):
    """Base class for all plugins."""
    manifest: PluginManifest

    def __init__(self, config: dict = None):
        self.config = config or {}

    @abc.abstractmethod
    async def run(self, *args, **kwargs) -> PluginResult:
        """Execute the plugin."""
        ...

    def validate_config(self) -> tuple[bool, str]:
        """Validate plugin configuration. Override to add validation."""
        return True, ""

    def describe(self) -> dict:
        return self.manifest.to_dict()


class ScannerPlugin(BasePlugin):
    """Custom vulnerability scanner plugin."""

    @abc.abstractmethod
    async def run(self, target: str, config: dict = None) -> PluginResult:
        """
        Run the scanner against a target.
        target: URL or domain to scan
        Returns findings as list of dicts with: title, vuln_type, severity, url, payload, evidence
        """
        ...


class PayloadPlugin(BasePlugin):
    """Custom payload generator plugin."""

    @abc.abstractmethod
    async def run(self, vuln_type: str, context: dict = None) -> PluginResult:
        """
        Generate payloads for a vulnerability type.
        Returns enrichments.payloads as list of payload strings.
        """
        ...


class ReportPlugin(BasePlugin):
    """Custom report template plugin."""

    @abc.abstractmethod
    async def run(self, scan_data: dict, vuln_data: list[dict]) -> PluginResult:
        """
        Generate a report from scan and vulnerability data.
        Returns enrichments.report_content as string.
        """
        ...


class EnrichmentPlugin(BasePlugin):
    """Custom data enrichment plugin (CVE lookups, Shodan, etc.)."""

    @abc.abstractmethod
    async def run(self, target: str, findings: list[dict]) -> PluginResult:
        """
        Enrich findings with additional context.
        Returns enrichments dict with additional data per finding.
        """
        ...


class ScoringPlugin(BasePlugin):
    """Custom risk scoring plugin."""

    @abc.abstractmethod
    async def run(self, finding: dict) -> PluginResult:
        """
        Score a finding.
        Returns enrichments with: confidence, exploitability, impact, recommended_action
        """
        ...


# ─── Plugin Registry ─────────────────────────────────────────────────────────

class PluginRegistry:
    """Central registry for all plugins."""

    def __init__(self):
        self._plugins: dict[str, tuple[Type[BasePlugin], PluginManifest]] = {}
        self._instances: dict[str, BasePlugin] = {}

    def register(self, plugin_class: Type[BasePlugin], manifest: PluginManifest) -> None:
        """Register a plugin class."""
        if not hasattr(plugin_class, "manifest"):
            plugin_class.manifest = manifest
        self._plugins[manifest.name] = (plugin_class, manifest)
        logger.info("plugin_registered", name=manifest.name, type=manifest.plugin_type.value)

    def get(self, name: str, config: dict = None) -> Optional[BasePlugin]:
        """Get a plugin instance by name."""
        if name not in self._plugins:
            return None
        plugin_class, manifest = self._plugins[name]
        if not manifest.is_enabled:
            return None
        return plugin_class(config or {})

    def list_plugins(self, plugin_type: Optional[PluginType] = None) -> list[dict]:
        """List all registered plugins, optionally filtered by type."""
        result = []
        for name, (cls, manifest) in self._plugins.items():
            if plugin_type is None or manifest.plugin_type == plugin_type:
                result.append(manifest.to_dict())
        return result

    def list_scanners(self) -> list[dict]:
        return self.list_plugins(PluginType.SCANNER)

    def list_payload_plugins(self) -> list[dict]:
        return self.list_plugins(PluginType.PAYLOAD)

    def enable(self, name: str) -> bool:
        if name in self._plugins:
            self._plugins[name][1].is_enabled = True
            return True
        return False

    def disable(self, name: str) -> bool:
        if name in self._plugins:
            self._plugins[name][1].is_enabled = False
            return True
        return False

    async def run_all_scanners(self, target: str, config: dict = None) -> list[PluginResult]:
        """Run all enabled scanner plugins against a target."""
        results = []
        for name, (cls, manifest) in self._plugins.items():
            if manifest.plugin_type == PluginType.SCANNER and manifest.is_enabled:
                try:
                    plugin = cls(config or {})
                    result = await plugin.run(target, config)
                    results.append(result)
                except Exception as e:
                    logger.warning("plugin_error", name=name, error=str(e))
                    results.append(PluginResult(
                        plugin_name=name, success=False,
                        errors=[str(e)],
                    ))
        return results

    async def enrich_finding(self, finding: dict) -> dict:
        """Run all enrichment plugins on a finding."""
        enriched = dict(finding)
        for name, (cls, manifest) in self._plugins.items():
            if manifest.plugin_type == PluginType.ENRICHMENT and manifest.is_enabled:
                try:
                    plugin = cls({})
                    result = await plugin.run(finding.get("url", ""), [finding])
                    enriched.update(result.enrichments)
                except Exception as e:
                    logger.warning("enrichment_plugin_error", name=name, error=str(e))
        return enriched


# Global registry
registry = PluginRegistry()


def register_plugin(name: str, plugin_type: PluginType, **manifest_kwargs):
    """Decorator to register a plugin class."""
    def decorator(cls: Type[BasePlugin]):
        manifest = PluginManifest(name=name, plugin_type=plugin_type, **manifest_kwargs)
        registry.register(cls, manifest)
        return cls
    return decorator


# ─── Built-in Example Plugins ────────────────────────────────────────────────

@register_plugin(
    "passive_headers_scanner",
    PluginType.SCANNER,
    description="Checks for missing security headers",
    version="1.0.0",
    tags=["passive", "headers", "security"],
)
class PassiveHeadersScanner(ScannerPlugin):
    """Checks for missing security headers — passive, no active testing."""

    SECURITY_HEADERS = {
        "strict-transport-security": ("Missing HSTS", "low"),
        "x-content-type-options": ("Missing X-Content-Type-Options", "low"),
        "x-frame-options": ("Missing Clickjacking Protection", "low"),
        "content-security-policy": ("Missing Content-Security-Policy", "medium"),
        "permissions-policy": ("Missing Permissions-Policy", "low"),
    }

    async def run(self, target: str, config: dict = None) -> PluginResult:
        findings = []
        try:
            import httpx
            async with httpx.AsyncClient(verify=False, timeout=10, follow_redirects=True) as client:
                resp = await client.get(target)
                resp_headers = {k.lower(): v for k, v in resp.headers.items()}

                for header, (title, severity) in self.SECURITY_HEADERS.items():
                    if header not in resp_headers:
                        findings.append({
                            "title": title,
                            "vuln_type": "missing_security_header",
                            "severity": severity,
                            "url": target,
                            "evidence": f"Header '{header}' not present in response",
                            "description": f"The {header} security header is missing.",
                            "remediation": f"Add '{header}' header to all responses.",
                        })
        except Exception as e:
            return PluginResult(plugin_name="passive_headers_scanner", success=False, errors=[str(e)])

        return PluginResult(
            plugin_name="passive_headers_scanner",
            success=True,
            findings=findings,
        )


@register_plugin(
    "cve_enricher",
    PluginType.ENRICHMENT,
    description="Enriches findings with CVE references",
    version="1.0.0",
    tags=["enrichment", "cve", "cwe"],
)
class CVEEnricher(EnrichmentPlugin):
    """Adds CVE/CWE mappings to findings."""

    CVE_MAP = {
        "xss": {"cwe": "CWE-79", "owasp": "A03:2021", "references": ["https://owasp.org/www-community/attacks/xss/"]},
        "sqli": {"cwe": "CWE-89", "owasp": "A03:2021", "references": ["https://owasp.org/www-community/attacks/SQL_Injection"]},
        "ssrf": {"cwe": "CWE-918", "owasp": "A10:2021", "references": ["https://owasp.org/www-community/attacks/Server_Side_Request_Forgery"]},
        "idor": {"cwe": "CWE-639", "owasp": "A01:2021", "references": ["https://owasp.org/API-Security/editions/2023/en/0xa1-broken-object-level-authorization/"]},
        "ssti": {"cwe": "CWE-94", "owasp": "A03:2021", "references": ["https://portswigger.net/web-security/server-side-template-injection"]},
        "cors": {"cwe": "CWE-942", "owasp": "A07:2021", "references": ["https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS"]},
    }

    async def run(self, target: str, findings: list[dict]) -> PluginResult:
        enrichments = {}
        for finding in findings:
            vtype = finding.get("vuln_type", "")
            if vtype in self.CVE_MAP:
                enrichments[f"cwe_{vtype}"] = self.CVE_MAP[vtype]
        return PluginResult(plugin_name="cve_enricher", success=True, enrichments=enrichments)
