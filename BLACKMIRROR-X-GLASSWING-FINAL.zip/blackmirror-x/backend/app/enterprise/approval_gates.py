"""
Human Approval Gates — BLACKMIRROR-X GLASSWING
Requires manual user approval before executing risky scan actions.

Features:
- Risk-tiered gates (low/medium/high/critical)
- Shows exact payload and target before execution
- Logs user approval with timestamp and user ID
- Emergency stop button (kills all active scans instantly)
- Configurable per workspace
"""
from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Optional
import structlog

logger = structlog.get_logger(__name__)


class RiskTier(str, Enum):
    PASSIVE = "passive"        # No gate needed
    LOW = "low"                # Informational gate only
    MEDIUM = "medium"          # Requires user acknowledgment
    HIGH = "high"              # Requires explicit approval with reason
    CRITICAL = "critical"      # Blocked unless override provided
    BLOCKED = "blocked"        # Never execute


class ApprovalStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"
    AUTO_APPROVED = "auto_approved"


@dataclass
class ApprovalRequest:
    """Pending approval request for a risky action."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    workspace_id: str = ""
    scan_id: str = ""
    user_id: str = ""

    # What needs approval
    action_type: str = ""         # "payload_test", "auth_bypass", "ssrf_probe", etc.
    risk_tier: RiskTier = RiskTier.MEDIUM
    title: str = ""
    description: str = ""

    # Exact details shown to user
    target_url: str = ""
    payload: str = ""
    expected_behavior: str = ""
    potential_impact: str = ""

    # Status
    status: ApprovalStatus = ApprovalStatus.PENDING
    approved_by: Optional[str] = None
    approval_reason: Optional[str] = None
    rejected_by: Optional[str] = None
    rejection_reason: Optional[str] = None

    # Timing
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    expires_at: Optional[str] = None
    resolved_at: Optional[str] = None

    # Audit
    ip_address: str = ""
    user_agent: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "workspace_id": self.workspace_id,
            "scan_id": self.scan_id,
            "action_type": self.action_type,
            "risk_tier": self.risk_tier.value if hasattr(self.risk_tier, "value") else self.risk_tier,
            "title": self.title,
            "description": self.description,
            "target_url": self.target_url,
            "payload": self.payload,
            "expected_behavior": self.expected_behavior,
            "potential_impact": self.potential_impact,
            "status": self.status.value if hasattr(self.status, "value") else self.status,
            "approved_by": self.approved_by,
            "approval_reason": self.approval_reason,
            "rejected_by": self.rejected_by,
            "rejection_reason": self.rejection_reason,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "resolved_at": self.resolved_at,
        }


# In-memory store for pending approvals (real implementation uses DB/Redis)
_pending_approvals: dict[str, ApprovalRequest] = {}
_approval_futures: dict[str, asyncio.Future] = {}

# Emergency stop state per workspace
_emergency_stops: set[str] = set()


class ApprovalGate:
    """
    Enforces human approval before risky scan actions.
    Workers wait asynchronously for user approval via the API.
    """

    # Risk tier thresholds by action type
    ACTION_RISK_MAP: dict[str, RiskTier] = {
        # Passive/recon
        "subdomain_enum": RiskTier.PASSIVE,
        "dns_resolution": RiskTier.PASSIVE,
        "http_probe": RiskTier.PASSIVE,
        "screenshot": RiskTier.PASSIVE,
        "js_analysis": RiskTier.PASSIVE,
        "url_crawl": RiskTier.LOW,

        # Low risk testing
        "xss_reflection_check": RiskTier.LOW,
        "header_injection": RiskTier.LOW,
        "open_redirect_test": RiskTier.LOW,
        "cors_test": RiskTier.LOW,
        "missing_headers_check": RiskTier.PASSIVE,

        # Medium risk
        "sqli_error_based": RiskTier.MEDIUM,
        "ssti_probe": RiskTier.MEDIUM,
        "idor_test": RiskTier.MEDIUM,
        "auth_bypass_test": RiskTier.MEDIUM,
        "file_upload_test": RiskTier.MEDIUM,

        # High risk
        "sqli_time_based": RiskTier.HIGH,
        "ssrf_internal": RiskTier.HIGH,
        "rce_probe": RiskTier.HIGH,
        "xxe_test": RiskTier.HIGH,
        "deserialization_test": RiskTier.HIGH,
        "privilege_escalation": RiskTier.HIGH,

        # Always blocked
        "dos_test": RiskTier.BLOCKED,
        "data_deletion": RiskTier.BLOCKED,
        "destructive_payload": RiskTier.BLOCKED,
        "account_takeover_live": RiskTier.CRITICAL,
    }

    def __init__(self, workspace_id: str, auto_approve_threshold: RiskTier = RiskTier.LOW):
        self.workspace_id = workspace_id
        self.auto_approve_threshold = auto_approve_threshold

    def is_emergency_stopped(self) -> bool:
        return self.workspace_id in _emergency_stops

    def emergency_stop(self, user_id: str = "") -> None:
        """Kill all pending scans for this workspace immediately."""
        _emergency_stops.add(self.workspace_id)
        # Reject all pending approvals
        for req_id, req in list(_pending_approvals.items()):
            if req.workspace_id == self.workspace_id and req.status == ApprovalStatus.PENDING:
                req.status = ApprovalStatus.REJECTED
                req.rejection_reason = f"EMERGENCY STOP by user {user_id}"
                req.resolved_at = datetime.now(timezone.utc).isoformat()
                if req_id in _approval_futures:
                    fut = _approval_futures.pop(req_id)
                    if not fut.done():
                        fut.set_result(False)
        logger.warning("emergency_stop_activated", workspace_id=self.workspace_id, user_id=user_id)

    def resume_after_stop(self, user_id: str = "") -> None:
        """Resume scanning after emergency stop."""
        _emergency_stops.discard(self.workspace_id)
        logger.info("emergency_stop_cleared", workspace_id=self.workspace_id, user_id=user_id)

    def get_risk_tier(self, action_type: str) -> RiskTier:
        return self.ACTION_RISK_MAP.get(action_type, RiskTier.MEDIUM)

    async def request_approval(
        self,
        action_type: str,
        target_url: str,
        payload: str = "",
        expected_behavior: str = "",
        potential_impact: str = "",
        scan_id: str = "",
        user_id: str = "",
        timeout_seconds: int = 300,
    ) -> tuple[bool, str]:
        """
        Request human approval for an action.
        Returns (approved: bool, reason: str).
        Blocks until approved, rejected, or timed out.
        """
        # Check emergency stop
        if self.is_emergency_stopped():
            return False, "Emergency stop active — all scanning halted"

        risk_tier = self.get_risk_tier(action_type)

        # Blocked actions never execute
        if risk_tier == RiskTier.BLOCKED:
            return False, f"Action '{action_type}' is permanently blocked — destructive operations are not permitted"

        # Auto-approve passive/low actions if threshold allows
        tier_order = [RiskTier.PASSIVE, RiskTier.LOW, RiskTier.MEDIUM, RiskTier.HIGH, RiskTier.CRITICAL]
        if tier_order.index(risk_tier) <= tier_order.index(self.auto_approve_threshold):
            return True, f"Auto-approved ({risk_tier.value} tier below threshold)"

        # Create approval request
        req = ApprovalRequest(
            workspace_id=self.workspace_id,
            scan_id=scan_id,
            user_id=user_id,
            action_type=action_type,
            risk_tier=risk_tier,
            title=f"Approval Required: {action_type.replace('_', ' ').title()}",
            description=f"A {risk_tier.value}-risk action requires your authorization",
            target_url=target_url,
            payload=payload,
            expected_behavior=expected_behavior,
            potential_impact=potential_impact,
        )

        _pending_approvals[req.id] = req

        # Create a future that the API endpoint will resolve
        loop = asyncio.get_event_loop()
        future: asyncio.Future = loop.create_future()
        _approval_futures[req.id] = future

        logger.info("approval_requested", request_id=req.id, action=action_type,
                   target=target_url, risk_tier=risk_tier.value)

        try:
            # Wait for approval or timeout
            result = await asyncio.wait_for(future, timeout=timeout_seconds)
            reason = req.approval_reason or req.rejection_reason or ""
            return result, reason
        except asyncio.TimeoutError:
            req.status = ApprovalStatus.EXPIRED
            req.resolved_at = datetime.now(timezone.utc).isoformat()
            logger.warning("approval_timeout", request_id=req.id)
            return False, "Approval timed out — action was not authorized in time"
        finally:
            _approval_futures.pop(req.id, None)


def approve_request(request_id: str, approved_by: str, reason: str = "") -> bool:
    """Called by API endpoint when user approves a request."""
    req = _pending_approvals.get(request_id)
    if not req or req.status != ApprovalStatus.PENDING:
        return False

    req.status = ApprovalStatus.APPROVED
    req.approved_by = approved_by
    req.approval_reason = reason
    req.resolved_at = datetime.now(timezone.utc).isoformat()

    future = _approval_futures.get(request_id)
    if future and not future.done():
        future.set_result(True)

    logger.info("approval_granted", request_id=request_id, by=approved_by)
    return True


def reject_request(request_id: str, rejected_by: str, reason: str = "") -> bool:
    """Called by API endpoint when user rejects a request."""
    req = _pending_approvals.get(request_id)
    if not req or req.status != ApprovalStatus.PENDING:
        return False

    req.status = ApprovalStatus.REJECTED
    req.rejected_by = rejected_by
    req.rejection_reason = reason
    req.resolved_at = datetime.now(timezone.utc).isoformat()

    future = _approval_futures.get(request_id)
    if future and not future.done():
        future.set_result(False)

    logger.info("approval_rejected", request_id=request_id, by=rejected_by, reason=reason)
    return True


def list_pending_approvals(workspace_id: str) -> list[dict]:
    """Get all pending approval requests for a workspace."""
    return [
        req.to_dict()
        for req in _pending_approvals.values()
        if req.workspace_id == workspace_id and req.status == ApprovalStatus.PENDING
    ]


def get_approval_history(workspace_id: str, limit: int = 50) -> list[dict]:
    """Get approval history for audit purposes."""
    all_reqs = [
        req.to_dict()
        for req in _pending_approvals.values()
        if req.workspace_id == workspace_id
    ]
    return sorted(all_reqs, key=lambda x: x.get("created_at", ""), reverse=True)[:limit]
