"""
GLASSWING Copilot Agent — Real Claude API integration.
Powers the /copilot chat interface with actual AI reasoning about findings.
"""
from __future__ import annotations
import json
from typing import Any, AsyncIterator, Dict

import httpx

from app.core.config import settings

SYSTEM_PROMPT = """You are GLASSWING, an elite bug bounty research assistant with the mindset of XBOW, Mythos AI, and a world-class penetration tester.

Your capabilities:
- Analyze vulnerabilities with surgical precision
- Suggest exploitation techniques for authorized testing
- Explain attack chains and business impact
- Help craft bug bounty reports that maximize payout
- Identify false positives vs real findings
- Suggest next steps for any finding

Your principles:
- Proof over probability. Never confirm without evidence.
- Always frame testing in authorized, responsible disclosure context
- Be specific: exact payloads, exact steps, exact impact
- Think in attack chains, not isolated bugs
- Prioritize by business impact and exploitability

When analyzing a finding, always address:
1. Is this a real vulnerability or false positive? Why?
2. What's the exact exploitation path?
3. What's the business impact?
4. What's the realistic bug bounty value?
5. What's the recommended remediation?"""


class CopilotAgent:
    def __init__(self):
        self.api_key = settings.ANTHROPIC_API_KEY

    async def stream(
        self,
        message: str,
        conversation_history: list[dict],
        context: Dict[str, Any] | None = None,
    ) -> AsyncIterator[str]:
        """Stream a response from Claude."""
        if not self.api_key or self.api_key == "test":
            yield self._fallback_response(message, context)
            return

        # Build messages
        system = SYSTEM_PROMPT
        if context:
            system += f"\n\nCURRENT CONTEXT:\n{self._build_context(context)}"

        messages = []
        for h in conversation_history[-10:]:  # last 10 messages
            messages.append({"role": h["role"], "content": h["content"]})
        messages.append({"role": "user", "content": message})

        try:
            async with httpx.AsyncClient(timeout=60) as client:
                async with client.stream(
                    "POST",
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key": self.api_key,
                        "anthropic-version": "2023-06-01",
                        "content-type": "application/json",
                    },
                    json={
                        "model": "claude-sonnet-4-6",
                        "max_tokens": 2000,
                        "system": system,
                        "messages": messages,
                        "stream": True,
                    }
                ) as resp:
                    if resp.status_code != 200:
                        yield f"API error {resp.status_code}"
                        return
                    async for line in resp.aiter_lines():
                        if line.startswith("data: "):
                            data = line[6:]
                            if data == "[DONE]":
                                break
                            try:
                                chunk = json.loads(data)
                                if chunk.get("type") == "content_block_delta":
                                    delta = chunk.get("delta", {})
                                    if delta.get("type") == "text_delta":
                                        yield delta.get("text", "")
                            except json.JSONDecodeError:
                                continue
        except Exception as e:
            yield f"\n\n[Connection error: {e}]"

    def _build_context(self, context: Dict[str, Any]) -> str:
        parts = []
        if context.get("workspace_name"):
            parts.append(f"Workspace: {context['workspace_name']}")
        if context.get("active_scan"):
            s = context["active_scan"]
            parts.append(f"Active scan: {s.get('name')} ({s.get('status')})")
        if context.get("recent_vulns"):
            vulns = context["recent_vulns"][:5]
            parts.append(f"Recent findings ({len(vulns)}):")
            for v in vulns:
                sev = v.get('severity','?').upper()
                parts.append(f"  - [{sev}] {v.get('title','?')} @ {v.get('url','?')}")
        if context.get("subdomain_count"):
            parts.append(f"Subdomains discovered: {context['subdomain_count']}")
        return "\n".join(parts)

    def _fallback_response(self, message: str, context: Any) -> str:
        """Heuristic fallback when Claude API unavailable."""
        msg_lower = message.lower()
        if any(w in msg_lower for w in ["xss", "cross-site"]):
            return ("**XSS Analysis**\n\nTo confirm XSS:\n1. Check if payload reflects unencoded\n"
                    "2. Test `<img src=x onerror=alert(1)>` in all parameters\n"
                    "3. Look for DOM-based sinks (innerHTML, document.write)\n"
                    "4. Use `<script>alert(document.domain)</script>` as proof\n\n"
                    "For bug bounty: document the exact parameter, show unencoded reflection, "
                    "prove JS execution with alert(document.cookie).")
        if any(w in msg_lower for w in ["sqli", "sql", "injection"]):
            return ("**SQLi Analysis**\n\nVerification steps:\n1. Try `'` — look for SQL error\n"
                    "2. Try `' OR '1'='1` — check response difference\n"
                    "3. Try `' AND SLEEP(2)--` — time-based confirmation\n"
                    "4. Use sqlmap with `--level=3 --risk=2` for automated testing\n\n"
                    "For bug bounty: show DB error message or timing proof.")
        if any(w in msg_lower for w in ["ssrf", "server-side"]):
            return ("**SSRF Analysis**\n\nProof chain:\n1. Test `http://169.254.169.254/` — AWS metadata\n"
                    "2. Test `http://localhost/` — local services\n"
                    "3. Use Burp Collaborator or interactsh for blind SSRF\n"
                    "4. Try `http://[::1]/` — IPv6 bypass\n\n"
                    "Critical finding if cloud metadata accessible.")
        return (f"I analyzed your request about: **{message[:100]}**\n\n"
                "To get full AI-powered analysis, configure your `ANTHROPIC_API_KEY` "
                "in the backend `.env` file.\n\n"
                "Current mode: heuristic fallback only.")

    async def analyze_vulnerability(self, vuln_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze a single vulnerability with Claude."""
        message = f"""Analyze this vulnerability finding:

Title: {vuln_data.get('title')}
Type: {vuln_data.get('vuln_type')}
Severity: {vuln_data.get('severity')}
URL: {vuln_data.get('url')}
Parameter: {vuln_data.get('parameter')}
Payload: {vuln_data.get('payload')}
Evidence: {(vuln_data.get('evidence') or '')[:300]}

Provide:
1. Is this real or false positive? (confidence %)
2. Exact exploitation steps
3. Business impact
4. Bug bounty value range
5. Remediation (2 sentences)"""

        response_parts = []
        async for chunk in self.stream(message, []):
            response_parts.append(chunk)

        return {
            "analysis": "".join(response_parts),
            "vuln_id": vuln_data.get("id"),
        }
