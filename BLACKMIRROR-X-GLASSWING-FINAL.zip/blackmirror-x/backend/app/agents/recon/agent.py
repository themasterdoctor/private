"""
BLACKMIRROR-X Recon Agent — Full Production Implementation
Orchestrates: subfinder, amass, assetfinder, dnsx, naabu, httpx,
              katana, nuclei, uncover, waybackurls, gau, hakrawler.
All tools run async via subprocess with graceful fallback to mock mode.
"""
import asyncio
import json
import os
import tempfile
from typing import Optional, List, Dict, Any, Callable
import structlog

from app.core.config import settings

logger = structlog.get_logger(__name__)

TOOL_TIMEOUT = 120  # seconds per tool


class ReconAgent:
    def __init__(self, scan_id: str, workspace_id: str, log_fn: Optional[Callable] = None):
        self.scan_id = scan_id
        self.workspace_id = workspace_id
        self.log_fn = log_fn or self._default_log
        self.artifacts_dir = os.path.join(settings.SCAN_ARTIFACTS_DIR, scan_id)
        os.makedirs(self.artifacts_dir, exist_ok=True)

    def _default_log(self, level: str, module: str, message: str, data: Dict = None):
        getattr(logger, level, logger.info)(message, module=module, scan_id=self.scan_id)

    async def log(self, level: str, module: str, message: str, data: Dict = None):
        try:
            self.log_fn(level, module, message, data)
        except Exception:
            pass

    # ── Main pipeline ────────────────────────────────────────────────────────

    async def run_full_recon(self, domain: str, config: Dict[str, Any]) -> Dict[str, Any]:
        results = {"domain": domain, "subdomains": [], "live_hosts": [], "urls": [], "ports": {}, "tech_stack": {}}
        await self.log("info", "recon", f"Starting full recon on {domain}")

        subdomains = await self.enumerate_subdomains(domain, config)
        results["subdomains"] = subdomains
        await self.log("success", "recon", f"Found {len(subdomains)} subdomains", {"count": len(subdomains)})

        live_hosts = await self.probe_http(subdomains + [domain], config)
        results["live_hosts"] = [h["url"] for h in live_hosts if h.get("url")]
        results["tech_stack"] = {h["url"]: h.get("tech", []) for h in live_hosts if h.get("url")}
        await self.log("success", "httpx", f"Found {len(live_hosts)} live hosts", {"count": len(live_hosts)})

        if config.get("port_scan", True):
            hosts_for_scan = [h["host"] for h in live_hosts[:30] if h.get("host")]
            ports = await self.scan_ports(hosts_for_scan, config)
            results["ports"] = ports
            total_open = sum(len(v) for v in ports.values())
            await self.log("success", "naabu", f"Found {total_open} open ports")

        urls = await self.discover_urls(results["live_hosts"][:20], domain, config)
        results["urls"] = urls
        await self.log("success", "crawler", f"Discovered {len(urls)} URLs", {"count": len(urls)})

        return results

    # ── Subdomain Enumeration ────────────────────────────────────────────────

    async def enumerate_subdomains(self, domain: str, config: Dict) -> List[str]:
        all_subs: set[str] = set()
        all_subs.add(domain)

        await self.log("info", "subfinder", f"Running subfinder on {domain}")
        subs = await self._run_subfinder(domain)
        all_subs.update(subs)
        await self.log("info", "subfinder", f"subfinder: {len(subs)} results")

        await self.log("info", "amass", f"Running amass passive on {domain}")
        amass_subs = await self._run_amass(domain)
        all_subs.update(amass_subs)
        await self.log("info", "amass", f"amass: {len(amass_subs)} results")

        await self.log("info", "assetfinder", f"Running assetfinder on {domain}")
        af_subs = await self._run_assetfinder(domain)
        all_subs.update(af_subs)
        await self.log("info", "assetfinder", f"assetfinder: {len(af_subs)} results")

        await self.log("info", "uncover", f"Running uncover on {domain}")
        uc_subs = await self._run_uncover(domain)
        all_subs.update(uc_subs)
        await self.log("info", "uncover", f"uncover: {len(uc_subs)} results")

        pre_resolve = len(all_subs)
        await self.log("info", "dnsx", f"Resolving {pre_resolve} subdomains with dnsx")
        resolved = await self._run_dnsx(list(all_subs))
        all_subs = set(resolved) if resolved else all_subs
        await self.log("info", "dnsx", f"dnsx: {len(all_subs)} resolved (of {pre_resolve})")

        return sorted(all_subs)

    async def _run_subfinder(self, domain: str) -> List[str]:
        out, _, rc = await self._exec([
            settings.SUBFINDER_PATH, "-d", domain,
            "-silent", "-timeout", "30", "-max-time", "60",
        ])
        if rc != 0 or not out.strip():
            return []
        return [l.strip() for l in out.splitlines() if l.strip() and domain in l]

    async def _run_amass(self, domain: str) -> List[str]:
        out, _, rc = await self._exec([
            "amass", "enum", "-passive", "-d", domain,
            "-timeout", "90", "-silent",
        ])
        if rc != 0 or not out.strip():
            return []
        return [l.strip() for l in out.splitlines() if l.strip() and domain in l]

    async def _run_assetfinder(self, domain: str) -> List[str]:
        out, _, rc = await self._exec(["assetfinder", "--subs-only", domain])
        if rc != 0 or not out.strip():
            return []
        return [l.strip() for l in out.splitlines() if l.strip() and domain in l]

    async def _run_uncover(self, domain: str) -> List[str]:
        """Uncover: search engine + shodan passive discovery."""
        out, _, rc = await self._exec([
            "uncover", "-q", f"hostname:{domain}", "-silent", "-limit", "100",
        ])
        if rc != 0 or not out.strip():
            return []
        hosts = set()
        for line in out.splitlines():
            line = line.strip()
            if line and "." in line:
                # uncover returns IP:port or hostname — extract hostname
                host = line.split(":")[0] if ":" in line else line
                if domain in host:
                    hosts.add(host)
        return list(hosts)

    async def _run_dnsx(self, hosts: List[str]) -> List[str]:
        if not hosts:
            return []
        with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False) as f:
            f.write("\n".join(hosts))
            fname = f.name
        try:
            out, _, rc = await self._exec([
                settings.DNSX_PATH, "-l", fname,
                "-silent", "-resp", "-a", "-aaaa", "-cname",
            ])
            if rc != 0 or not out.strip():
                return hosts  # return unverified if dnsx fails
            return [l.split()[0].strip() for l in out.splitlines() if l.strip()]
        finally:
            os.unlink(fname)

    # ── HTTP Probing ─────────────────────────────────────────────────────────

    async def probe_http(self, hosts: List[str], config: Dict) -> List[Dict]:
        if not hosts:
            return []
        await self.log("info", "httpx", f"Probing {len(hosts)} hosts")
        with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False) as f:
            f.write("\n".join(hosts))
            fname = f.name
        try:
            out, _, rc = await self._exec([
                settings.HTTPX_PATH, "-l", fname,
                "-silent", "-json",
                "-title", "-status-code", "-tech-detect",
                "-follow-redirects", "-timeout", "10",
            ])
            results = []
            for line in out.splitlines():
                try:
                    item = json.loads(line)
                    results.append({
                        "url": item.get("url", ""),
                        "host": item.get("host", ""),
                        "status": item.get("status-code", 0),
                        "title": item.get("title", ""),
                        "tech": item.get("tech", []) or item.get("technologies", []),
                        "content_length": item.get("content-length", 0),
                        "cdn": item.get("cdn", False),
                    })
                except (json.JSONDecodeError, KeyError):
                    pass
            return results
        finally:
            os.unlink(fname)

    # ── Port Scanning ────────────────────────────────────────────────────────

    async def scan_ports(self, hosts: List[str], config: Dict) -> Dict[str, List[int]]:
        if not hosts:
            return {}
        with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False) as f:
            f.write("\n".join(hosts))
            fname = f.name
        try:
            out, _, rc = await self._exec([
                settings.NAABU_PATH, "-l", fname,
                "-silent", "-json",
                "-top-ports", "100",
                "-rate", "1000",
            ])
            ports: Dict[str, List[int]] = {}
            for line in out.splitlines():
                try:
                    item = json.loads(line)
                    host = item.get("host", "")
                    port = item.get("port", 0)
                    if host and port:
                        ports.setdefault(host, []).append(port)
                except (json.JSONDecodeError, KeyError):
                    pass
            return ports
        finally:
            os.unlink(fname)

    # ── URL Discovery ────────────────────────────────────────────────────────

    async def discover_urls(self, hosts: List[str], domain: str, config: Dict) -> List[str]:
        all_urls: set[str] = set()

        # katana crawler
        for url in hosts[:10]:
            await self.log("info", "katana", f"Crawling {url}")
            urls = await self._run_katana(url)
            all_urls.update(urls)
        await self.log("info", "katana", f"Crawled {len(all_urls)} URLs so far")

        # gau — passive URL sources (archive.org, alienvault, commoncrawl)
        await self.log("info", "gau", f"Running passive URL discovery (gau)")
        gau_urls = await self._run_gau(domain)
        all_urls.update(gau_urls)

        # waybackurls
        await self.log("info", "waybackurls", f"Running waybackurls on {domain}")
        wb_urls = await self._run_waybackurls(domain)
        all_urls.update(wb_urls)

        # hakrawler
        for url in hosts[:5]:
            hak_urls = await self._run_hakrawler(url)
            all_urls.update(hak_urls)

        return sorted(all_urls)[:settings.MAX_URLS_PER_SCAN]

    async def _run_katana(self, url: str) -> List[str]:
        out, _, rc = await self._exec([
            settings.KATANA_PATH, "-u", url,
            "-silent", "-depth", "3",
            "-js-crawl", "-ignore-query-params",
            "-timeout", "30",
        ])
        if rc != 0 or not out.strip():
            return []
        return [l.strip() for l in out.splitlines() if l.strip().startswith("http")]

    async def _run_gau(self, domain: str) -> List[str]:
        out, _, rc = await self._exec([
            settings.GAU_PATH, domain,
            "--threads", "5", "--timeout", "60",
            "--providers", "wayback,commoncrawl,otx,urlscan",
        ])
        if rc != 0 or not out.strip():
            return []
        return [l.strip() for l in out.splitlines() if l.strip().startswith("http")][:2000]

    async def _run_waybackurls(self, domain: str) -> List[str]:
        out, _, rc = await self._exec(["waybackurls", domain])
        if rc != 0 or not out.strip():
            return []
        return [l.strip() for l in out.splitlines() if l.strip().startswith("http")][:2000]

    async def _run_hakrawler(self, url: str) -> List[str]:
        out, _, rc = await self._exec(
            ["hakrawler", "-url", url, "-depth", "2", "-subs"],
            stdin_data=url,
        )
        if rc != 0 or not out.strip():
            return []
        return [l.strip() for l in out.splitlines() if l.strip().startswith("http")][:500]

    # ── Utility ──────────────────────────────────────────────────────────────

    async def _exec(
        self, cmd: List[str], timeout: int = TOOL_TIMEOUT, stdin_data: str = None
    ) -> tuple[str, str, int]:
        """Run a subprocess, fall back gracefully if tool not found."""
        tool = cmd[0]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                stdin=asyncio.subprocess.PIPE if stdin_data else None,
            )
            stdin_bytes = stdin_data.encode() if stdin_data else None
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(input=stdin_bytes), timeout=timeout
            )
            return stdout.decode(errors="replace"), stderr.decode(errors="replace"), proc.returncode or 0
        except FileNotFoundError:
            await self.log("info", "recon", f"Tool not found: {tool} (mock mode)")
            return "", "", 1
        except asyncio.TimeoutError:
            await self.log("warn", "recon", f"Tool timed out: {tool}")
            return "", "", 1
        except Exception as e:
            await self.log("warn", "recon", f"Tool error ({tool}): {e}")
            return "", "", 1
