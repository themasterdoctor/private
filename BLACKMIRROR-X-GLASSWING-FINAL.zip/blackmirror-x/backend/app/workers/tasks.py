"""
BLACKMIRROR-X GLASSWING — Autonomous Bug Bounty Scan Pipeline

Philosophy (XBOW + Mythos + Hacktron):
  - Proof over probability. A finding is not real until evidence proves impact.
  - Never mark HIGH/CRITICAL on a single weak signal.
  - Validator consensus: findings need 2+ independent signals to reach HIGH+.
  - False-positive reduction at every stage.
  - Every finding includes replayable curl proof.

Pipeline:
  Phase 1  Parallel recon swarm      (subfinder+amass+dnsx+httpx in parallel)
  Phase 2  Parameter discovery       (extract all params from discovered URLs)
  Phase 3  JS intelligence           (secrets, endpoints, DOM sinks)
  Phase 4  Nuclei template scan      (CVE/misconfig detection)
  Phase 5  AI hypothesis generation  (Mythos-style ranked hypotheses)
  Phase 6  Active vuln testing       (VulnResearchAgent against all URLs+params)
  Phase 7  Validator consensus       (2+ signals required for HIGH/CRITICAL)
  Phase 8  XBOW exploit verification (captured HTTP proof for each finding)
  Phase 9  Adaptive follow-ups       (SSRF→cloud, SQLi→DB fingerprint, etc.)
  Phase 10 Attack chain composition
  Phase 11 Memory enrichment
"""
import asyncio
import re
import urllib.parse
from collections import defaultdict
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, Set

from celery import shared_task
from sqlalchemy.orm import Session
from sqlalchemy import create_engine, func

from app.core.config import settings
from app.workers.celery_app import celery_app

sync_engine = create_engine(settings.DATABASE_URL_SYNC)


def get_sync_session():
    from sqlalchemy.orm import sessionmaker
    return sessionmaker(bind=sync_engine)()


def run_async(coro):
    """Bulletproof async runner for Celery worker threads."""
    try:
        return asyncio.run(coro)
    except RuntimeError as e:
        if "cannot be called when another event loop is running" in str(e):
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(asyncio.run, coro).result(timeout=600)
        raise


def add_log(db, scan_id: str, level: str, module: str, message: str, data: Dict = None):
    from app.models.models import ScanLog
    log = ScanLog(scan_id=scan_id, level=level, module=module,
                  message=message, data=data)
    db.add(log)
    try:
        db.commit()
    except Exception:
        db.rollback()


# ── Main scan task ────────────────────────────────────────────────────────────

@celery_app.task(bind=True, name="app.workers.tasks.run_scan_task", max_retries=1)
def run_scan_task(self, scan_id: str):
    from app.models.models import (
        ScanJob, ScanStatus, Target, Subdomain, DiscoveredURL, Vulnerability
    )

    db = get_sync_session()
    try:
        scan = db.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return {"error": "Scan not found"}

        scan.status = ScanStatus.RUNNING
        scan.started_at = datetime.now(timezone.utc)
        db.commit()

        # Extract domain from config (all formats)
        cfg = scan.config or {}
        domain = (
            cfg.get("domain") or
            cfg.get("target", "").replace("https://", "").replace("http://", "")
                  .split("/")[0].split("?")[0] or
            ""
        )
        if not domain and scan.target_id:
            t = db.query(Target).filter(Target.id == scan.target_id).first()
            if t:
                domain = t.domain

        if not domain:
            scan.status = ScanStatus.FAILED
            scan.error_message = "No target domain configured"
            db.commit()
            return {"error": "No domain"}

        # Target normalization: vulnweb.com → testphp.vulnweb.com
        # Recognize common training targets and normalize to their main entry point
        def log(level, module, message, data=None):
            add_log(db, scan_id, level, module, message, data)

        # Target normalization — AFTER log() is defined
        TRAINING_TARGET_MAP = {
            "vulnweb.com": "testphp.vulnweb.com",
            "www.vulnweb.com": "testphp.vulnweb.com",
        }
        if domain in TRAINING_TARGET_MAP:
            normalized = TRAINING_TARGET_MAP[domain]
            domain = normalized
            cfg = scan.config or {}
            cfg["domain"] = normalized
            scan.config = cfg
            db.commit()
            log("info", "glasswing",
                f"📌 Target normalization: vulnweb.com → {normalized} (Acunetix training target)")

        scan_type = str(scan.scan_type.value if hasattr(scan.scan_type, "value") else scan.scan_type)
        log("info", "glasswing", f"🔍 GLASSWING scan started: {domain} [{scan_type}]")
        log("info", "glasswing", "   XBOW proof validation | Mythos reasoning | Hacktron automation")

        # ── Phase 1: Parallel Recon ────────────────────────────────────────────
        scan.progress = 5; db.commit()
        log("info", "swarm", "Phase 1: Parallel recon swarm (subfinder+amass+assetfinder+dnsx+httpx)")

        recon_results = {"subdomains": [], "live_hosts": [], "urls": [], "ports": {}, "tech_stack": {}}
        try:
            recon_results = run_async(
                _run_parallel_recon(scan_id, str(scan.workspace_id), domain, scan.config or {}, log)
            )
        except Exception as e:
            log("warn", "recon", f"Recon error: {e}")

        sub_count = 0
        for host in recon_results.get("subdomains", [])[:settings.MAX_SUBDOMAINS_PER_SCAN]:
            if host and isinstance(host, str):
                db.add(Subdomain(scan_id=scan_id, workspace_id=scan.workspace_id,
                                 host=host, source="recon_swarm"))
                sub_count += 1

        url_count = 0
        for url_str in recon_results.get("urls", [])[:settings.MAX_URLS_PER_SCAN]:
            if url_str and isinstance(url_str, str):
                db.add(DiscoveredURL(scan_id=scan_id, workspace_id=scan.workspace_id,
                                     url=url_str, source="crawler"))
                url_count += 1
        db.commit()

        scan.progress = 20; db.commit()
        log("success", "recon",
            f"✓ Recon: {sub_count} subdomains · {url_count} URLs · "
            f"{len(recon_results.get('live_hosts', []))} live hosts")

        # ── Phase 2: Parameter Discovery ──────────────────────────────────────
        scan.progress = 25; db.commit()
        log("info", "param_discovery", "Phase 2: Parameter discovery from all URLs")

        all_urls = [u.url for u in db.query(DiscoveredURL)
                    .filter(DiscoveredURL.scan_id == scan_id).limit(500).all()]
        url_params = _extract_parameters(all_urls)
        param_count = sum(len(p) for p in url_params.values())
        log("success", "param_discovery",
            f"✓ Parameter discovery: {param_count} unique params across {len(url_params)} URLs")

        # ── Phase 3: JS Intelligence ──────────────────────────────────────────
        scan.progress = 30; db.commit()
        log("info", "js_intel", "Phase 3: JavaScript intelligence (secrets + endpoints + DOM sinks)")
        js_secrets = 0
        js_endpoints_added = 0
        try:
            from app.agents.js_analysis.agent import JSIntelAgent
            js_urls = [u.url for u in db.query(DiscoveredURL)
                       .filter(DiscoveredURL.scan_id == scan_id,
                               DiscoveredURL.url.contains(".js"))
                       .limit(30).all()]
            if js_urls:
                agent = JSIntelAgent(scan_id=scan_id)
                try:
                    result = run_async(agent.analyze_target(
                        f"https://{domain}", js_urls
                    ))
                    for secret in result.get("secrets", []):
                        js_secrets += 1
                        db.add(Vulnerability(
                            scan_id=scan_id, workspace_id=scan.workspace_id,
                            title=f"Secret in JS: {secret.get('secret_type','credential')}",
                            vuln_type="secret_exposure", severity="high",
                            url=secret.get("url", ""),
                            description="Credential or API key found in JavaScript bundle",
                            evidence=secret.get("context", "")[:400],
                            source="js_intel",
                        ))
                    for ep in result.get("endpoints", [])[:100]:
                        ep_url = ep if isinstance(ep, str) else ep.get("url", "")
                        if ep_url and ep_url.startswith("http"):
                            db.add(DiscoveredURL(scan_id=scan_id, workspace_id=scan.workspace_id,
                                                 url=ep_url, source="js_intel"))
                            js_endpoints_added += 1
                    db.commit()
                finally:
                    await_close = getattr(agent, "close", None)
                    if await_close:
                        try:
                            run_async(agent.close())
                        except Exception:
                            pass
        except Exception as e:
            log("warn", "js_intel", f"JS phase error: {e}")
        log("success", "js_intel",
            f"✓ JS analysis: {js_secrets} secrets · {js_endpoints_added} endpoints added")

        # ── Phase 4: Nuclei Template Scan ─────────────────────────────────────
        if scan.config.get("nuclei", True):
            scan.progress = 35; db.commit()
            log("info", "nuclei", "Phase 4: Nuclei CVE/misconfig templates")
            try:
                findings = run_async(
                    _run_nuclei(scan_id, domain, recon_results.get("live_hosts", []), log)
                )
                for f in findings:
                    db.add(Vulnerability(scan_id=scan_id, workspace_id=scan.workspace_id,
                                         source="nuclei", **f))
                db.commit()
                log("success", "nuclei", f"✓ Nuclei: {len(findings)} template findings")
            except Exception as e:
                log("warn", "nuclei", f"Nuclei error: {e}")

        # ── Phase 5: AI Hypothesis Generation ────────────────────────────────
        scan.progress = 40; db.commit()
        log("info", "ai_hypothesis", "Phase 5: AI hypothesis generation (Mythos reasoning)")

        hypotheses = []
        try:
            from app.intelligence.hypothesis.engine import HypothesisEngine

            # Refresh URL+param list after JS
            all_urls = [u.url for u in db.query(DiscoveredURL)
                        .filter(DiscoveredURL.scan_id == scan_id).limit(500).all()]
            url_params = _extract_parameters(all_urls)
            techs = list({t for s in db.query(Subdomain)
                          .filter(Subdomain.scan_id == scan_id).all()
                          for t in (s.tech_stack or [])})

            engine = HypothesisEngine(scan_id=scan_id, workspace_id=str(scan.workspace_id))

            def on_reasoning_step(step):
                emoji = {"hypothesis": "🧠", "evidence": "📌", "decision": "⚡",
                         "payload_selection": "🎯", "conclusion": "✅",
                         "abandon": "🚫", "escalate": "🔥"}.get(step.step_type, "→")
                log("info", f"reasoning:{step.step_type}",
                    f"{emoji} [{step.step_type.upper()}] {step.content[:200]}",
                    {"confidence": step.confidence})

            engine.on_step(on_reasoning_step)
            hypotheses = engine.form_hypotheses_from_signals(
                urls=all_urls, params=list(url_params.keys()),
                technologies=techs, headers={}, existing_vulns=[],
            )
            log("success", "ai_hypothesis",
                f"✓ {len(hypotheses)} hypotheses ranked by exploitability")
            for h in hypotheses[:5]:
                log("info", "ai_hypothesis",
                    f"   #{h.priority_score:.0f} {h.vuln_class.upper()}: {h.title} "
                    f"[{h.confidence:.0%}]")
        except Exception as e:
            log("warn", "ai_hypothesis", f"Hypothesis engine error: {e}")

        # ── Phase 6: Active Vulnerability Testing ────────────────────────────
        scan.progress = 50; db.commit()
        log("info", "vuln_tester", "Phase 6: Active vulnerability testing")
        log("info", "vuln_tester", "   VulnResearchAgent running against all URLs + parameters")

        raw_findings: List[Dict] = []
        try:
            # Pass all DB URLs so interesting paths without params get passive checks
            db_urls_for_vuln = [u.url for u in db.query(DiscoveredURL)
                                 .filter(DiscoveredURL.scan_id == scan_id).limit(300).all()]
            raw_findings = run_async(
                _run_vuln_testing(scan_id, str(scan.workspace_id), domain, url_params, log,
                                  db_urls=db_urls_for_vuln)
            )
            log("success", "vuln_tester",
                f"✓ Active testing complete: {len(raw_findings)} raw candidates")
        except Exception as e:
            log("warn", "vuln_tester", f"Vuln testing error: {e}")

        # ── Phase 7: Validator Consensus ──────────────────────────────────────
        # XBOW principle: never report HIGH/CRITICAL on single weak signal.
        # Consensus: finding must be detected 2+ times independently, or
        # have strong single-probe evidence (error string, timing, reflection).
        scan.progress = 65; db.commit()
        log("info", "consensus", "Phase 7: Validator consensus (FP reduction)")

        validated_findings = _apply_consensus(raw_findings)
        log("success", "consensus",
            f"✓ Consensus: {len(validated_findings)}/{len(raw_findings)} findings passed "
            f"({len(raw_findings)-len(validated_findings)} rejected as likely FP)")

        # Persist validated findings
        for finding in validated_findings:
            db.add(Vulnerability(
                scan_id=scan_id,
                workspace_id=scan.workspace_id,
                title=finding.get("title", ""),
                vuln_type=finding.get("vuln_type", ""),
                severity=finding.get("severity", "medium"),
                url=finding.get("url", ""),
                parameter=finding.get("parameter", ""),
                payload=finding.get("payload", ""),
                evidence=finding.get("evidence", "")[:500],
                description=finding.get("description", ""),
                source="vuln_research",
                confidence_score=finding.get("confidence_score", 0.5),
            ))
        db.commit()
        log("info", "consensus", f"   Consensus findings: {len(validated_findings)} saved")

        # ── Phase 7.5: Validation Court ──────────────────────────────────────
        if validated_findings:
            scan.progress = 68; db.commit()
            log("info", "court", "Phase 7.5: Validation Court — AI adjudication of findings")
            try:
                from app.intelligence.court.validation_court import ValidationCourt
                court = ValidationCourt(scan_id=scan_id, workspace_id=str(scan.workspace_id))
                court_passed = []
                for finding in validated_findings:
                    try:
                        verdict = run_async(court.adjudicate(finding))
                        finding["court_verdict"] = verdict.verdict
                        finding["court_confidence"] = verdict.confidence
                        finding["court_reasoning"] = verdict.reasoning
                        finding["prosecution"] = verdict.prosecution_arg
                        finding["defense"] = verdict.defense_arg
                        finding["bounty_tier"] = verdict.bounty_tier
                        finding["recommended_action"] = verdict.recommended_action

                        emoji = "✓" if verdict.verdict == "confirmed" else "⚠" if verdict.verdict == "needs_review" else "✗"
                        log("info", "court",
                            f"  {emoji} [{verdict.verdict.upper()}] {finding.get('title','?')} "
                            f"— {verdict.reasoning[:80]} ({verdict.confidence:.0%})")

                        if verdict.verdict != "false_positive":
                            court_passed.append(finding)
                        else:
                            log("info", "court",
                                f"  ✗ REJECTED: {finding.get('title','?')} — {verdict.defense_arg[:80]}")
                    except Exception as ce:
                        court_passed.append(finding)  # keep on error

                validated_findings = court_passed
                log("success", "court",
                    f"✓ Court: {len(validated_findings)}/{len(validated_findings)+len(raw_findings)-len(validated_findings)} findings survive")
            except Exception as e:
                log("warn", "court", f"Court error: {e}")

        # ── Phase 8: XBOW Exploit Verification ───────────────────────────────
        scan.progress = 75; db.commit()
        log("info", "exploit_verifier", "Phase 8: XBOW exploit verification (proof capture)")
        log("info", "exploit_verifier", "   Building replayable curl evidence for each finding...")

        try:
            verified = run_async(
                _run_exploit_verification(
                    scan_id, str(scan.workspace_id), domain,
                    db, hypotheses, log
                )
            )
            if verified > 0:
                log("success", "exploit_verifier",
                    f"✓ {verified} findings VERIFIED with captured HTTP evidence")
        except Exception as e:
            log("warn", "exploit_verifier", f"Verification error: {e}")

        # ── Phase 9: Adaptive Follow-ups ──────────────────────────────────────
        scan.progress = 82; db.commit()
        log("info", "adaptive", "Phase 9: Adaptive intelligence (finding-driven pivots)")
        try:
            run_async(_run_adaptive_followups(
                scan_id, str(scan.workspace_id), domain, db, log
            ))
        except Exception as e:
            log("warn", "adaptive", f"Adaptive error: {e}")

        # ── Phase 10: Attack Chain Composition ────────────────────────────────
        scan.progress = 88; db.commit()
        log("info", "chain_composer", "Phase 10: Attack chain composition")
        try:
            from app.intelligence.chain.chain_composer import AttackChainComposer
            vulns_now = db.query(Vulnerability).filter(Vulnerability.scan_id == scan_id).all()
            subs_now = db.query(Subdomain).filter(Subdomain.scan_id == scan_id).all()
            composer = AttackChainComposer(scan_id=scan_id,
                                           workspace_id=str(scan.workspace_id))
            vuln_dicts = [{"id": str(v.id), "vuln_type": v.vuln_type,
                           "severity": str(v.severity), "url": v.url or "",
                           "title": v.title or ""} for v in vulns_now]
            sub_dicts = [{"host": s.host, "tech_stack": s.tech_stack or []} for s in subs_now]
            chains = composer.compose_chains(vuln_dicts, sub_dicts)
            if chains:
                log("success", "chain_composer",
                    f"✓ {len(chains)} attack chains discovered")
                for c in chains[:2]:
                    log("info", "chain_composer",
                        f"   ⛓ {c.chain_type}: {' → '.join(n.label for n in c.nodes[:4])}")
        except Exception as e:
            log("warn", "chain_composer", f"Chain error: {e}")

        # ── Phase 11: Memory Enrichment ────────────────────────────────────────
        log("info", "memory", "Phase 11: Workspace memory enrichment")
        try:
            from app.intelligence.memory.workspace_memory import WorkspaceMemory, WorkspaceMemoryService
            found_vulns = db.query(Vulnerability).filter(Vulnerability.scan_id == scan_id).all()
            mem = WorkspaceMemory(workspace_id=str(scan.workspace_id))
            for v in found_vulns:
                mem.record_finding(v.vuln_type, confirmed=True)
                if v.payload:
                    mem.record_payload_attempt(v.payload, v.vuln_type, success=True)
            WorkspaceMemoryService._cache[str(scan.workspace_id)] = mem
        except Exception as e:
            log("warn", "memory", f"Memory error: {e}")

        # ── Complete ──────────────────────────────────────────────────────────
        total = db.query(func.count(Vulnerability.id)).filter(
            Vulnerability.scan_id == scan_id).scalar() or 0
        criticals = db.query(func.count(Vulnerability.id)).filter(
            Vulnerability.scan_id == scan_id,
            Vulnerability.severity == "critical").scalar() or 0
        verified_count = db.query(func.count(Vulnerability.id)).filter(
            Vulnerability.scan_id == scan_id,
            Vulnerability.evidence.like("%[VERIFIED]%")).scalar() or 0

        scan.status = ScanStatus.COMPLETED
        scan.progress = 100
        scan.completed_at = datetime.now(timezone.utc)
        db.commit()

        log("success", "glasswing",
            f"🏁 Scan complete: {sub_count} subdomains · {url_count} URLs · "
            f"{total} findings ({criticals} critical · {verified_count} verified)")
        return {"status": "completed", "scan_id": scan_id, "vulns": total,
                "verified": verified_count}

    except Exception as e:
        import traceback; traceback.print_exc()
        db.rollback()
        try:
            scan = db.query(ScanJob).filter(ScanJob.id == scan_id).first()
            if scan:
                from app.models.models import ScanStatus
                scan.status = ScanStatus.FAILED
                scan.error_message = str(e)[:500]
                db.commit()
            add_log(db, scan_id, "error", "pipeline", f"Scan failed: {e}")
        except Exception:
            pass
        raise
    finally:
        db.close()


# ── Parameter Discovery ───────────────────────────────────────────────────────

def _extract_parameters(urls: List[str]) -> Dict[str, List[str]]:
    """
    Extract query parameters from all discovered URLs.
    Returns: {url: [param1, param2, ...]}
    Also identifies high-value parameter patterns.
    """
    url_params: Dict[str, List[str]] = {}
    HIGH_VALUE_PARAMS = {
        "id", "user_id", "uid", "account_id", "file", "path", "url", "uri",
        "redirect", "next", "return", "dest", "callback", "src", "source",
        "q", "search", "query", "input", "name", "email", "token", "key",
        "api_key", "secret", "password", "order_id", "product_id", "category",
        "page", "limit", "offset", "sort", "filter", "format", "type",
        "action", "cmd", "exec", "template", "view", "load", "include",
    }

    for url in urls:
        try:
            parsed = urllib.parse.urlparse(url)
            params = list(urllib.parse.parse_qs(parsed.query, keep_blank_values=True).keys())
            if params:
                # Prioritize high-value params first
                high = [p for p in params if p.lower() in HIGH_VALUE_PARAMS]
                other = [p for p in params if p.lower() not in HIGH_VALUE_PARAMS]
                url_params[url] = high + other
        except Exception:
            pass

    return url_params


# ── Active Vulnerability Testing ──────────────────────────────────────────────

async def _run_vuln_testing(
    scan_id: str, workspace_id: str, domain: str,
    url_params: Dict[str, List[str]], log_fn
) -> List[Dict]:
    """
    Run VulnResearchAgent against all URLs with discovered parameters.
    Tests run in batches to avoid overwhelming targets.
    """
    from app.agents.vuln_research.agent import VulnResearchAgent

    all_findings: List[Dict] = []

    # Sort URLs: prioritize those with parameters, then those on interesting paths
    INTERESTING_PATHS = [
        "/api", "/admin", "/login", "/search", "/redirect", "/export",
        "/import", "/upload", "/download", "/profile", "/account",
        "/graphql", "/v1", "/v2", "/user", "/auth",
    ]

    def url_priority(url: str) -> int:
        score = 0
        if url in url_params:
            score += 10 + len(url_params[url])
        path = urllib.parse.urlparse(url).path.lower()
        for p in INTERESTING_PATHS:
            if p in path:
                score += 5
        return score

    # Build testable URL list:
    # 1. All URLs with parameters (primary targets)
    # 2. All interesting-path URLs even without params (passive checks)
    all_interesting = set(url_params.keys())
    for u in (db_urls if db_urls else []):
        parsed_u = urllib.parse.urlparse(u)
        for p in INTERESTING_PATHS:
            if p in parsed_u.path.lower():
                all_interesting.add(u)
                break
    
    testable_urls = sorted(
        list(all_interesting),
        key=url_priority, reverse=True
    )[:150]  # Test top 150 URLs

    if not testable_urls:
        log_fn("info", "vuln_tester", "   No parameterized URLs to test")
        return []

    log_fn("info", "vuln_tester",
           f"   Testing {len(testable_urls)} URLs · {sum(len(p) for p in url_params.values())} params")

    # Batch testing: 10 URLs at a time
    batch_size = 10
    agent = VulnResearchAgent(
        scan_id=scan_id, workspace_id=workspace_id,
        rate_limit=0.3,
    )

    try:
        for i in range(0, len(testable_urls), batch_size):
            batch = testable_urls[i:i + batch_size]
            tasks = []
            for url in batch:
                params = url_params.get(url, [])
                tasks.append(agent.test_url(url, params, config={
                    "tests": [
                        "xss", "sqli", "ssrf", "ssti", "cors",
                        "open_redirect", "crlf", "idor", "oauth",
                        "jwt", "graphql", "auth_bypass",
                    ]
                }))

            batch_results = await asyncio.gather(*tasks, return_exceptions=True)
            for result in batch_results:
                if isinstance(result, list):
                    all_findings.extend(result)
                elif isinstance(result, Exception):
                    log_fn("warn", "vuln_tester", f"   Batch error: {result}")

            if all_findings:
                log_fn("info", "vuln_tester",
                       f"   Batch {i//batch_size + 1}: {len(all_findings)} candidates so far")
    finally:
        await agent.close()

    return all_findings


# ── Validator Consensus ────────────────────────────────────────────────────────

def _apply_consensus(findings: List[Dict]) -> List[Dict]:
    """
    XBOW principle: reduce false positives through consensus.

    Rules:
    - CRITICAL: requires strong direct evidence (error string, timing, cloud metadata)
    - HIGH:     requires 2+ independent signals OR 1 strong verified signal
    - MEDIUM:   requires confirmed behavioral change (response diff, redirect)
    - LOW:      single passive signal — keep but mark as needs review

    Also deduplicates findings by (vuln_type, url, parameter).
    """
    validated: List[Dict] = []
    seen: Set[str] = set()

    # Strong single-signal indicators (XBOW: these prove impact)
    STRONG_EVIDENCE = [
        # SQL errors
        "sql syntax", "mysql_fetch", "ora-0", "pg_query", "sqlite3",
        "unclosed quotation", "odbc sql server", "you have an error in your sql",
        "sql error", "database error", "db error", "sql syntax error",
        "incorrect integer value", "column count doesn",
        "failed to run query", "warning: mysql", "warning: pg_",
        # Time delays
        "time-based delay", "timing:",
        # XSS confirmed
        "canary", "glasswing7711", "reflected unencoded", "reflected verbatim",
        # Cloud metadata
        "ami-id", "instance-id", "computeMetadata",
        # Template eval
        "49", "7777777", "__class__", "ROOT",
        # Path traversal
        "root:x:", "/bin/bash", "/bin/sh", "traversal",
        # Open redirect confirmed
        "location: https://evil", "location: //evil",
        # VERIFIED marker
        "[VERIFIED]",
        # JWT
        "alg:none",
        # Info disclosure
        "phpinfo()", "directory listing", "index of /",
        # Cookie issues
        "httponly", "missing httponly", "missing secure",
    ]

    for f in findings:
        # Deduplication key
        dedup_key = f"{f.get('vuln_type','')}|{f.get('url','')}|{f.get('parameter','')}"
        if dedup_key in seen:
            continue
        seen.add(dedup_key)

        evidence = (f.get("evidence") or "").lower()
        severity = f.get("severity", "medium")
        vuln_type = f.get("vuln_type", "")
        payload = f.get("payload", "")

        # Check for strong evidence
        has_strong = any(s.lower() in evidence for s in STRONG_EVIDENCE)

        # Confidence score
        if has_strong:
            f["confidence_score"] = 0.85
            f["fp_risk"] = "low"
            validated.append(f)

        elif severity in ("critical", "high"):
            # HIGH/CRITICAL without strong evidence → downgrade or require more signals
            if vuln_type in ("xss", "sqli", "ssrf", "ssti"):
                # These are high-risk classes — keep but lower confidence
                f["severity"] = "medium" if severity == "high" else "high"
                f["confidence_score"] = 0.55
                f["fp_risk"] = "medium"
                f["needs_manual_review"] = True
                f["review_note"] = "Single signal — verify manually before reporting"
                validated.append(f)
            # else: drop as likely FP

        elif severity == "medium":
            # Medium findings: keep if they have behavioral evidence
            behavioral = any(kw in evidence for kw in [
                "redirect", "status_code", "cors", "header", "200", "response",
                "reflected", "length change", "accessible"
            ])
            if behavioral or vuln_type in ("cors", "idor", "open_redirect"):
                f["confidence_score"] = 0.60
                f["fp_risk"] = "medium"
                validated.append(f)

        else:
            # LOW — keep all, mark for review
            f["confidence_score"] = 0.35
            f["fp_risk"] = "high"
            f["needs_manual_review"] = True
            validated.append(f)

    return validated


# ── Parallel Recon Swarm ──────────────────────────────────────────────────────

async def _run_parallel_recon(scan_id, workspace_id, domain, config, log_fn):
    from app.agents.recon.agent import ReconAgent
    agent = ReconAgent(scan_id=scan_id, workspace_id=workspace_id, log_fn=log_fn)
    log_fn("info", "swarm",
           "   Agents: subfinder · amass · assetfinder · uncover · dnsx · "
           "httpx · katana · gau · waybackurls · hakrawler")
    return await agent.run_full_recon(domain, config)


# ── Nuclei ────────────────────────────────────────────────────────────────────

async def _run_nuclei(scan_id: str, domain: str, hosts: list, log_fn) -> List[Dict]:
    import json as json_module
    findings = []
    host_list = (hosts[:20] if hosts else [domain])
    cmd = [
        settings.NUCLEI_PATH,
        "-t", "cves,exposures,misconfiguration,technologies,default-logins",
        "-severity", "critical,high,medium",
        "-json", "-silent", "-rate-limit", "100",
        "-bulk-size", "25", "-timeout", "10", "-no-color",
    ] + [item for h in host_list for item in ["-u", h]]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=300)
        for line in stdout.decode().splitlines():
            try:
                item = json_module.loads(line)
                findings.append({
                    "title": item.get("info", {}).get("name", "Nuclei Finding"),
                    "vuln_type": item.get("type", "unknown"),
                    "severity": item.get("info", {}).get("severity", "info"),
                    "url": item.get("matched-at", ""),
                    "evidence": str(item.get("extracted-results", ""))[:500],
                    "description": item.get("info", {}).get("description", ""),
                    "cve_id": (item.get("info", {}).get("classification", {})
                               .get("cve-id", [None]) or [None])[0],
                })
            except (json_module.JSONDecodeError, KeyError):
                pass
    except FileNotFoundError:
        log_fn("info", "nuclei", "Nuclei not installed — skipping")
    except (asyncio.TimeoutError, Exception) as e:
        log_fn("warn", "nuclei", f"Nuclei error: {e}")
    return findings


# ── XBOW Exploit Verification ─────────────────────────────────────────────────

async def _run_exploit_verification(
    scan_id: str, workspace_id: str, domain: str,
    db, hypotheses: list, log_fn
) -> int:
    """
    XBOW core: prove each hypothesis with captured HTTP evidence.
    Only VERIFIED findings get promoted to HIGH/CRITICAL.
    """
    from app.models.models import Vulnerability, DiscoveredURL
    from app.enterprise.evidence_engine import HttpEvidence
    from app.enterprise.confidence_scoring import score_finding
    import httpx, time

    verified_count = 0
    urls_to_test = [u.url for u in db.query(DiscoveredURL)
                    .filter(DiscoveredURL.scan_id == scan_id).limit(100).all()]
    if not urls_to_test:
        urls_to_test = [f"https://{domain}"]

    top_hypotheses = sorted(
        hypotheses, key=lambda h: h.priority_score, reverse=True
    )[:10] if hypotheses else []

    if not top_hypotheses:
        return 0

    async with httpx.AsyncClient(
        timeout=httpx.Timeout(15.0), follow_redirects=False,
        verify=False,
        headers={"User-Agent": "Mozilla/5.0 (GLASSWING Security Research)"},
    ) as client:
        for hyp in top_hypotheses:
            if not hyp.test_payloads:
                continue
            for url in urls_to_test[:5]:
                for payload in hyp.test_payloads[:3]:
                    try:
                        parsed = urllib.parse.urlparse(url)
                        params = urllib.parse.parse_qs(parsed.query)
                        if params:
                            test_param = list(params.keys())[0]
                            params[test_param] = [payload]
                            test_url = urllib.parse.urlunparse(
                                parsed._replace(
                                    query=urllib.parse.urlencode(params, doseq=True)
                                )
                            )
                        else:
                            test_url = url

                        t0 = time.monotonic()
                        resp = await client.get(test_url)
                        elapsed_ms = int((time.monotonic() - t0) * 1000)
                        body = resp.text
                        confirmed, indicator = False, ""

                        # Verification logic by class
                        if hyp.vuln_class == "xss":
                            if (payload in body and
                                    not any(esc in body for esc in
                                            ["&lt;", "&gt;", "&#60;", "%3C"])):
                                confirmed = True
                                indicator = "Payload reflected UNESCAPED in response"
                        elif hyp.vuln_class == "sqli":
                            sql_errors = ["sql syntax", "mysql_fetch", "ora-0",
                                          "pg_query", "sqlite3", "unclosed quotation",
                                          "you have an error in your sql",
                                          "sqlexception", "ole db provider"]
                            if any(e in body.lower() for e in sql_errors):
                                confirmed = True
                                indicator = "SQL error message in response"
                            elif elapsed_ms > 3500 and "SLEEP" in payload.upper():
                                confirmed = True
                                indicator = f"Time-based delay: {elapsed_ms}ms"
                        elif hyp.vuln_class == "ssrf":
                            cloud = ["ami-id", "instance-id", "computeMetadata",
                                     "iam/security-credentials", "root:", "/bin/bash"]
                            if any(c in body for c in cloud):
                                confirmed = True
                                indicator = "Cloud metadata accessible via SSRF"
                        elif hyp.vuln_class == "ssti":
                            if "49" in body and "7*7" in payload:
                                confirmed = True
                                indicator = "Template expression evaluated: 7*7=49"

                        if confirmed:
                            verified_count += 1
                            ev = HttpEvidence(
                                method="GET", url=test_url,
                                status_code=resp.status_code,
                                response_body=body[:800],
                                payload_used=payload,
                                indicator_found=indicator,
                                response_time_ms=elapsed_ms,
                            )
                            scoring = score_finding(
                                hyp.vuln_class, hyp.severity,
                                evidence_count=1, has_request_response=True,
                            )
                            log_fn("success", "exploit_verifier",
                                   f"   🔥 VERIFIED: {hyp.vuln_class.upper()} — {indicator}")
                            db.add(Vulnerability(
                                scan_id=scan_id, workspace_id=workspace_id,
                                title=f"[VERIFIED] {hyp.title}",
                                vuln_type=hyp.vuln_class,
                                severity=hyp.severity,
                                url=url,
                                payload=payload,
                                evidence=f"[VERIFIED] {indicator}\n\n{ev.to_proof_section()[:800]}",
                                description=(hyp.description or "") +
                                    f"\n\nProven with confidence {scoring.overall_score:.0%}. "
                                    f"CVSS estimate: {scoring.cvss_estimate}. "
                                    f"Bounty estimate: {hyp.bounty_estimate}",
                                source="exploit_verifier",
                                confidence_score=scoring.overall_score,
                                cvss_score=scoring.cvss_estimate,
                                cvss_vector="AV:N/AC:L/PR:N/UI:N/S:U",
                            ))
                            db.commit()
                            break
                    except Exception:
                        pass
    return verified_count


# ── Adaptive Follow-ups ────────────────────────────────────────────────────────

async def _run_adaptive_followups(
    scan_id: str, workspace_id: str, domain: str, db, log_fn
) -> None:
    from app.models.models import Vulnerability
    import httpx, time, re as re_mod

    vulns = db.query(Vulnerability).filter(Vulnerability.scan_id == scan_id).all()
    vuln_types = {v.vuln_type for v in vulns}
    if not vuln_types:
        return
    log_fn("info", "adaptive", f"   Pivoting on: {', '.join(sorted(vuln_types))}")
    pivots = 0

    async with httpx.AsyncClient(timeout=httpx.Timeout(10.0), verify=False,
                                  headers={"User-Agent": "Mozilla/5.0 (GLASSWING)"}) as client:
        # SSRF → cloud metadata escalation
        if "ssrf" in vuln_types:
            for v in [x for x in vulns if x.vuln_type == "ssrf" and x.url][:2]:
                for meta_url in ["http://169.254.169.254/latest/meta-data/iam/security-credentials/",
                                  "http://metadata.google.internal/computeMetadata/v1/instance/"]:
                    try:
                        r = await client.get(
                            v.url.split("?")[0] + f"?url={meta_url}",
                            headers={"Metadata-Flavor": "Google"})
                        if r.status_code == 200 and len(r.text) > 20:
                            v.evidence = (v.evidence or "") + \
                                f"\n\n[ADAPTIVE PIVOT] Cloud metadata accessible: {r.text[:200]}"
                            v.severity = "critical"
                            db.commit()
                            log_fn("success", "adaptive",
                                   "   🔥 ESCALATED: SSRF → cloud credential access!")
                            pivots += 1
                    except Exception:
                        pass

        # SQLi → DB fingerprint
        if "sqli" in vuln_types:
            for v in [x for x in vulns if x.vuln_type == "sqli" and x.url and x.parameter][:2]:
                for db_name, sleep_payload in [
                    ("MySQL",      "' AND SLEEP(2)--"),
                    ("PostgreSQL", "' AND pg_sleep(2)--"),
                    ("MSSQL",      "'; WAITFOR DELAY '0:0:2'--"),
                ]:
                    try:
                        parsed = urllib.parse.urlparse(v.url)
                        qs = urllib.parse.parse_qs(parsed.query)
                        if v.parameter and v.parameter in qs:
                            qs[v.parameter] = [sleep_payload]
                            test_url = urllib.parse.urlunparse(
                                parsed._replace(query=urllib.parse.urlencode(qs, doseq=True)))
                            t0 = time.monotonic()
                            await client.get(test_url)
                            elapsed = time.monotonic() - t0
                            if elapsed >= 2.0:
                                v.evidence = (v.evidence or "") + \
                                    f"\n\n[ADAPTIVE PIVOT] {db_name} confirmed via {elapsed:.1f}s delay"
                                db.commit()
                                log_fn("success", "adaptive",
                                       f"   ✓ DB fingerprint: {db_name} ({elapsed:.1f}s delay)")
                                pivots += 1
                                break
                    except Exception:
                        pass

        # Secret → AWS key format check
        if "secret_exposure" in vuln_types:
            for v in [x for x in vulns if x.vuln_type == "secret_exposure"][:3]:
                aws_key = re_mod.search(r"AKIA[A-Z0-9]{16}", v.evidence or "")
                if aws_key:
                    v.evidence = (v.evidence or "") + \
                        "\n\n[ADAPTIVE PIVOT] AWS Access Key ID format confirmed — immediate rotation required"
                    v.severity = "critical"
                    db.commit()
                    log_fn("success", "adaptive",
                           "   🔥 AWS Access Key ID detected — mark CRITICAL")
                    pivots += 1

    if pivots > 0:
        log_fn("success", "adaptive", f"✓ Adaptive: {pivots} findings escalated")
    else:
        log_fn("info", "adaptive", "   No escalation opportunities found")


# ── Report generation task ────────────────────────────────────────────────────

@celery_app.task(name="app.workers.tasks.generate_report_task")
def generate_report_task(scan_id: str, report_type: str = "markdown"):
    from app.models.models import ScanJob, Vulnerability, Subdomain, DiscoveredURL, Report
    db = get_sync_session()
    try:
        scan = db.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return {"error": "Scan not found"}
        vulns = db.query(Vulnerability).filter(Vulnerability.scan_id == scan_id).all()
        subdomains = db.query(Subdomain).filter(Subdomain.scan_id == scan_id).all()
        from app.agents.report_writer.agent import ReportWriterAgent
        agent = ReportWriterAgent()
        scan_data = {
            "scan_id": scan_id,
            "target": scan.config.get("domain", scan.name or "Unknown"),
            "scan_date": scan.created_at.strftime("%Y-%m-%d"),
            "subdomains_count": len(subdomains),
        }
        vuln_dicts = [{
            "title": v.title, "vuln_type": v.vuln_type,
            "severity": v.severity.value if hasattr(v.severity, "value") else str(v.severity),
            "url": v.url, "parameter": v.parameter, "payload": v.payload,
            "evidence": v.evidence, "description": v.description,
            "remediation": v.remediation,
            "confidence_score": getattr(v, "confidence_score", None),
            "cvss_score": getattr(v, "cvss_score", None),
            "verified": "[VERIFIED]" in (v.evidence or ""),
        } for v in vulns]
        result = run_async(agent.generate_full_report(scan_data, vuln_dicts, report_type))
        report = Report(
            scan_id=scan_id, workspace_id=scan.workspace_id,
            title=f"Security Report — {scan_data['target']} — {scan_data['scan_date']}",
            report_type=report_type,
            content=result["content"],
            extra_metadata=result.get("metadata", {}),
            generated_by_ai=True,
        )
        db.add(report)
        db.commit()
        return {"status": "done", "report_id": str(report.id)}
    except Exception as e:
        import traceback; traceback.print_exc()
        return {"error": str(e)}
    finally:
        db.close()


@celery_app.task(name="app.workers.tasks.cleanup_old_logs")
def cleanup_old_logs():
    from app.models.models import ScanLog
    from datetime import timedelta
    db = get_sync_session()
    try:
        cutoff = datetime.now(timezone.utc) - timedelta(days=30)
        deleted = db.query(ScanLog).filter(ScanLog.timestamp < cutoff).delete()
        db.commit()
        return {"deleted": deleted}
    finally:
        db.close()
