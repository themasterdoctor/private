"""
BLACKMIRROR-X Celery Tasks
Main scan pipeline + agent runners.
"""
import asyncio
from datetime import datetime, timezone
from typing import Dict, Any, List

from celery import shared_task
from sqlalchemy.orm import Session
from sqlalchemy import create_engine

from app.core.config import settings
from app.workers.celery_app import celery_app

# Sync engine for Celery workers
sync_engine = create_engine(settings.DATABASE_URL_SYNC)


def get_sync_session():
    from sqlalchemy.orm import sessionmaker
    SessionLocal = sessionmaker(bind=sync_engine)
    return SessionLocal()


def run_async(coro):
    """Run an async coroutine from sync context (Celery worker)."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(asyncio.run, coro)
                return future.result()
        else:
            return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


def add_log(db, scan_id: str, level: str, module: str, message: str, data: Dict = None):
    from app.models.models import ScanLog
    log = ScanLog(scan_id=scan_id, level=level, module=module, message=message, data=data)
    db.add(log)
    try:
        db.commit()
    except Exception:
        db.rollback()


@celery_app.task(bind=True, name="app.workers.tasks.run_scan_task", max_retries=1)
def run_scan_task(self, scan_id: str):
    """Main scan pipeline task."""
    from app.models.models import ScanJob, ScanStatus, Target, Subdomain, DiscoveredURL, Vulnerability

    db = get_sync_session()

    try:
        scan = db.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return {"error": "Scan not found"}

        scan.status = ScanStatus.RUNNING
        scan.started_at = datetime.now(timezone.utc)
        db.commit()

        # Get target domain
        domain = scan.config.get("domain", "")
        if not domain and scan.target_id:
            target = db.query(Target).filter(Target.id == scan.target_id).first()
            if target:
                domain = target.domain

        if not domain:
            scan.status = ScanStatus.FAILED
            scan.error_message = "No target domain configured"
            db.commit()
            return {"error": "No domain"}

        def log_sync(level, module, message, data=None):
            add_log(db, scan_id, level, module, message, data)

        log_sync("info", "pipeline", f"Starting scan pipeline for {domain}")

        # ── Phase 1: Recon ────────────────────────────────────
        scan.progress = 10
        db.commit()
        log_sync("info", "pipeline", "Phase 1: Reconnaissance")

        recon_config = scan.config.get("recon", {})
        try:
            recon_results = run_async(
                _run_recon(scan_id, str(scan.workspace_id), domain, recon_config, log_sync)
            )
        except Exception as e:
            log_sync("warn", "recon", f"Recon phase error: {e}")
            recon_results = {"subdomains": [], "live_hosts": [], "urls": []}

        # Persist subdomains
        sub_count = 0
        for subdomain_host in recon_results.get("subdomains", [])[:settings.MAX_SUBDOMAINS_PER_SCAN]:
            if subdomain_host and isinstance(subdomain_host, str):
                sub = Subdomain(
                    scan_id=scan_id,
                    workspace_id=scan.workspace_id,
                    host=subdomain_host,
                    source="recon_agent",
                )
                db.add(sub)
                sub_count += 1

        # Persist URLs
        url_count = 0
        for url_str in recon_results.get("urls", [])[:settings.MAX_URLS_PER_SCAN]:
            if url_str and isinstance(url_str, str):
                url = DiscoveredURL(
                    scan_id=scan_id,
                    workspace_id=scan.workspace_id,
                    url=url_str,
                    source="crawler",
                )
                db.add(url)
                url_count += 1

        db.commit()
        scan.progress = 40
        db.commit()
        log_sync("success", "pipeline", f"Recon complete: {sub_count} subdomains, {url_count} URLs")

        # ── Phase 2: Nuclei scan ──────────────────────────────
        if scan.config.get("nuclei", True):
            scan.progress = 50
            db.commit()
            log_sync("info", "nuclei", "Phase 2: Running Nuclei templates")

            try:
                nuclei_findings = run_async(
                    _run_nuclei(scan_id, domain, recon_results.get("live_hosts", []), log_sync)
                )
                for finding in nuclei_findings:
                    vuln = Vulnerability(
                        scan_id=scan_id,
                        workspace_id=scan.workspace_id,
                        source="nuclei",
                        **finding,
                    )
                    db.add(vuln)
                db.commit()
                log_sync("success", "nuclei", f"Nuclei found {len(nuclei_findings)} issues")
            except Exception as e:
                log_sync("warn", "nuclei", f"Nuclei phase error: {e}")

        # ── Phase 3: JS Analysis ──────────────────────────────
        scan.progress = 60
        db.commit()
        log_sync("info", "js_intel", "Phase 3: JavaScript Intelligence Analysis")

        js_secrets_found = 0
        try:
            from app.intelligence.js_ast.js_reverse import JSReverseEngineer
            for url_obj in db.query(DiscoveredURL).filter(
                DiscoveredURL.scan_id == scan_id,
                DiscoveredURL.url.like("%.js"),
            ).limit(20).all():
                try:
                    eng = JSReverseEngineer(scan_id=scan_id)
                    result = run_async(eng.analyze_url(url_obj.url))
                    for secret in result.get("secrets", []):
                        js_secrets_found += 1
                        vuln = Vulnerability(
                            scan_id=scan_id, workspace_id=scan.workspace_id,
                            title=f"Secret in JS: {secret['secret_type']}",
                            vuln_type="secret_exposure", severity="high",
                            url=url_obj.url,
                            description=f"Found {secret['secret_type']} in JavaScript bundle",
                            evidence=secret.get("context", "")[:200],
                            source="js_intel",
                        )
                        db.add(vuln)
                    db.commit()
                except Exception as e:
                    log_sync("warn", "js_intel", f"JS analysis error for {url_obj.url}: {e}")
        except Exception as e:
            log_sync("warn", "js_intel", f"JS analysis phase error: {e}")

        log_sync("success", "js_intel", f"JS analysis complete: {js_secrets_found} secrets found")

        # ── Phase 4: Hypothesis generation ───────────────────
        scan.progress = 75
        db.commit()
        log_sync("info", "vuln", "Phase 4: Hypothesis generation")

        try:
            from app.intelligence.hypothesis.engine import HypothesisEngine
            urls_for_hyp = [u.url for u in db.query(DiscoveredURL).filter(
                DiscoveredURL.scan_id == scan_id).limit(200).all()]
            subs_for_hyp = [s.host for s in db.query(Subdomain).filter(
                Subdomain.scan_id == scan_id).all()]
            techs = []
            for s in db.query(Subdomain).filter(Subdomain.scan_id == scan_id).all():
                techs.extend(s.tech_stack or [])

            engine = HypothesisEngine(scan_id=scan_id, workspace_id=str(scan.workspace_id))
            hypotheses = engine.form_hypotheses_from_signals(
                urls=urls_for_hyp, params=[],
                technologies=list(set(techs)), headers={}, existing_vulns=[]
            )
            log_sync("info", "vuln", f"Generated {len(hypotheses)} vulnerability hypotheses")
        except Exception as e:
            log_sync("warn", "vuln", f"Hypothesis generation error: {e}")

        # ── Phase 5: Intelligence enrichment ─────────────────
        scan.progress = 90
        db.commit()
        log_sync("info", "ai", "Phase 5: Intelligence enrichment")

        try:
            from app.intelligence.memory.workspace_memory import WorkspaceMemory, WorkspaceMemoryService
            found_vulns = db.query(Vulnerability).filter(Vulnerability.scan_id == scan_id).all()
            mem = WorkspaceMemory(workspace_id=str(scan.workspace_id))
            for v in found_vulns:
                mem.record_finding(v.vuln_type, confirmed=True)
                if v.payload:
                    mem.record_payload_attempt(v.payload, v.vuln_type, success=True)
            WorkspaceMemoryService._cache[str(scan.workspace_id)] = mem
            log_sync("info", "ai", f"Enrichment complete: {len(found_vulns)} findings recorded")
        except Exception as e:
            log_sync("warn", "ai", f"Intelligence enrichment error: {e}")

        # ── Complete ──────────────────────────────────────────
        scan.status = ScanStatus.COMPLETED
        scan.progress = 100
        scan.completed_at = datetime.now(timezone.utc)
        db.commit()

        log_sync("success", "pipeline", "Scan completed successfully!")
        return {"status": "completed", "scan_id": scan_id}

    except Exception as e:
        import traceback
        traceback.print_exc()
        db.rollback()
        try:
            scan = db.query(ScanJob).filter(ScanJob.id == scan_id).first()
            if scan:
                from app.models.models import ScanStatus
                scan.status = ScanStatus.FAILED
                scan.error_message = str(e)[:500]
                db.commit()
            add_log(db, scan_id, "error", "pipeline", f"Scan failed: {e}")
        except Exception:
            pass
        raise

    finally:
        db.close()


async def _run_recon(scan_id, workspace_id, domain, config, log_fn):
    """Async recon wrapper."""
    from app.agents.recon.agent import ReconAgent
    agent = ReconAgent(scan_id=scan_id, workspace_id=workspace_id)
    return await agent.run_full_recon(domain, config)


async def _run_nuclei(scan_id: str, domain: str, hosts: list, log_fn) -> List[Dict]:
    """Run nuclei against discovered hosts."""
    import json as json_module

    findings = []
    host_list = hosts[:5] if hosts else [domain]

    cmd = [
        settings.NUCLEI_PATH,
        "-t", "cves,exposures,misconfiguration",
        "-severity", "critical,high,medium",
        "-json", "-silent", "-rate-limit", "50",
        "-timeout", "10", "-no-color",
    ] + [item for h in host_list for item in ["-u", h]]

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=300)

        for line in stdout.decode().splitlines():
            try:
                item = json_module.loads(line)
                findings.append({
                    "title": item.get("info", {}).get("name", "Nuclei Finding"),
                    "vuln_type": item.get("type", "unknown"),
                    "severity": item.get("info", {}).get("severity", "info"),
                    "url": item.get("matched-at", ""),
                    "evidence": str(item.get("extracted-results", ""))[:500],
                    "description": item.get("info", {}).get("description", ""),
                })
            except (json_module.JSONDecodeError, KeyError):
                pass
    except FileNotFoundError:
        log_fn("warn", "nuclei", "Nuclei not installed — skipping (scan continues)")
    except asyncio.TimeoutError:
        log_fn("warn", "nuclei", "Nuclei timed out — skipping")
    except Exception as e:
        log_fn("warn", "nuclei", f"Nuclei error: {e}")

    return findings


@celery_app.task(name="app.workers.tasks.generate_report_task")
def generate_report_task(scan_id: str, report_type: str = "markdown"):
    """Generate a report for a completed scan."""
    from app.models.models import ScanJob, Vulnerability, Subdomain, DiscoveredURL, Report

    db = get_sync_session()
    try:
        scan = db.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return {"error": "Scan not found"}

        vulns = db.query(Vulnerability).filter(Vulnerability.scan_id == scan_id).all()
        subdomains = db.query(Subdomain).filter(Subdomain.scan_id == scan_id).all()
        urls = db.query(DiscoveredURL).filter(DiscoveredURL.scan_id == scan_id).all()

        from app.agents.report_writer.agent import ReportWriterAgent
        agent = ReportWriterAgent()

        scan_data = {
            "scan_id": scan_id,
            "target": scan.config.get("domain", scan.name or "Unknown"),
            "scan_date": scan.created_at.strftime("%Y-%m-%d"),
            "subdomains_count": len(subdomains),
            "live_hosts_count": len([s for s in subdomains if getattr(s, 'is_alive', False)]),
            "urls_count": len(urls),
        }

        vuln_dicts = [
            {
                "title": v.title, "vuln_type": v.vuln_type,
                "severity": v.severity.value if hasattr(v.severity, 'value') else str(v.severity),
                "url": v.url, "parameter": v.parameter, "payload": v.payload,
                "evidence": v.evidence, "description": v.description,
                "remediation": v.remediation,
            }
            for v in vulns
        ]

        result = run_async(agent.generate_full_report(scan_data, vuln_dicts, report_type))

        report = Report(
            scan_id=scan_id,
            workspace_id=scan.workspace_id,
            title=f"Security Report — {scan_data['target']} — {scan_data['scan_date']}",
            report_type=report_type,
            content=result["content"],
            extra_metadata=result.get("metadata", {}),
            generated_by_ai=True,
        )
        db.add(report)
        db.commit()

        return {"status": "done", "report_id": str(report.id)}
    except Exception as e:
        import traceback
        traceback.print_exc()
        return {"error": str(e)}
    finally:
        db.close()


@celery_app.task(name="app.workers.tasks.cleanup_old_logs")
def cleanup_old_logs():
    """Clean up old scan logs (>30 days)."""
    from app.models.models import ScanLog
    from datetime import timedelta

    db = get_sync_session()
    try:
        cutoff = datetime.now(timezone.utc) - timedelta(days=30)
        deleted = db.query(ScanLog).filter(ScanLog.timestamp < cutoff).delete()
        db.commit()
        return {"deleted": deleted}
    finally:
        db.close()
