from typing import Optional, Dict, Any
from pydantic import BaseModel, model_validator
from datetime import datetime


class ScanCreateRequest(BaseModel):
    workspace_id: str
    target_id: Optional[str] = None
    name: str
    scan_type: str = "full"
    config: Optional[Dict[str, Any]] = None
    # Frontend sends `target` URL; we extract domain → config.domain
    target: Optional[str] = None

    @model_validator(mode="after")
    def inject_target_into_config(self) -> "ScanCreateRequest":
        if self.target:
            if self.config is None:
                self.config = {}
            if not self.config.get("domain"):
                domain = (
                    self.target
                    .replace("https://", "")
                    .replace("http://", "")
                    .split("/")[0]
                    .split("?")[0]
                )
                self.config["domain"] = domain
        return self


def _ev(v):
    """Extract .value from an enum, or return str."""
    return v.value if hasattr(v, "value") else str(v or "")


class ScanListOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    name: str
    scan_type: str
    status: str
    progress: int
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    target: Optional[str] = None
    subdomain_count: int = 0
    url_count: int = 0
    vuln_count: int = 0

    @model_validator(mode="before")
    @classmethod
    def normalize(cls, obj):
        if not hasattr(obj, "status"):
            return obj
        cfg = getattr(obj, "config", {}) or {}
        name = getattr(obj, "name", "") or ""
        return {
            "id": str(getattr(obj, "id", "")),
            "name": name,
            "scan_type": _ev(getattr(obj, "scan_type", "full")),
            "status": _ev(getattr(obj, "status", "queued")),
            "progress": getattr(obj, "progress", 0) or 0,
            "created_at": getattr(obj, "created_at", datetime.utcnow()),
            "started_at": getattr(obj, "started_at", None),
            "completed_at": getattr(obj, "completed_at", None),
            "target": cfg.get("domain") or cfg.get("target") or name,
            "subdomain_count": 0,
            "url_count": 0,
            "vuln_count": 0,
        }


class ScanOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    name: str
    scan_type: str
    status: str
    progress: int
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    target: Optional[str] = None
    subdomain_count: int = 0
    url_count: int = 0
    vuln_count: int = 0
    workspace_id: str
    target_id: Optional[str] = None
    created_by: str
    config: Dict[str, Any] = {}
    celery_task_id: Optional[str] = None
    error_message: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def normalize(cls, obj):
        if not hasattr(obj, "status"):
            return obj
        cfg = getattr(obj, "config", {}) or {}
        name = getattr(obj, "name", "") or ""
        return {
            "id": str(getattr(obj, "id", "")),
            "name": name,
            "scan_type": _ev(getattr(obj, "scan_type", "full")),
            "status": _ev(getattr(obj, "status", "queued")),
            "progress": getattr(obj, "progress", 0) or 0,
            "created_at": getattr(obj, "created_at", datetime.utcnow()),
            "started_at": getattr(obj, "started_at", None),
            "completed_at": getattr(obj, "completed_at", None),
            "target": cfg.get("domain") or cfg.get("target") or name,
            "subdomain_count": 0,
            "url_count": 0,
            "vuln_count": 0,
            "workspace_id": str(getattr(obj, "workspace_id", "")),
            "target_id": getattr(obj, "target_id", None),
            "created_by": str(getattr(obj, "created_by", "")),
            "config": cfg,
            "celery_task_id": getattr(obj, "celery_task_id", None),
            "error_message": getattr(obj, "error_message", None),
        }


class ScanLogOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    level: str
    module: str
    message: str
    data: Optional[Dict[str, Any]] = None
    timestamp: datetime
