"""
GLASSWING Validation Court — XBOW-style deterministic proof evaluation.

Every finding goes through:
1. Prosecution: Claude argues why this IS a real vulnerability  
2. Defense: Claude argues why this might be a false positive
3. Judge: Claude delivers verdict with confidence score
4. Evidence check: Deterministic HTTP re-verification

Only findings that SURVIVE court get reported.
"""
from __future__ import annotations
import asyncio
import json
from dataclasses import dataclass
from typing import Any, Optional
import httpx

from app.core.config import settings


@dataclass
class CourtVerdict:
    verdict: str          # confirmed | false_positive | needs_review
    confidence: float
    reasoning: str
    prosecution_arg: str
    defense_arg: str
    evidence_strength: str  # strong | moderate | weak
    bounty_tier: str        # critical | high | medium | low | informational
    recommended_action: str


class ValidationCourt:
    """
    XBOW-style validation court.
    Uses Claude API to argue both sides of each finding.
    """

    def __init__(self, scan_id: str = "", workspace_id: str = ""):
        self.scan_id = scan_id
        self.workspace_id = workspace_id

    async def adjudicate(
        self,
        vuln: dict[str, Any],
        scan_context: dict[str, Any] | None = None,
    ) -> CourtVerdict:
        """Run the full court process for one finding."""
        # Always run deterministic evidence check first
        evidence_check = self._evidence_check(vuln)

        if not settings.ANTHROPIC_API_KEY or settings.ANTHROPIC_API_KEY == "test":
            return self._heuristic_verdict(vuln, evidence_check)

        try:
            return await self._ai_verdict(vuln, evidence_check, scan_context or {})
        except Exception:
            return self._heuristic_verdict(vuln, evidence_check)

    def _evidence_check(self, vuln: dict) -> dict:
        """Deterministic evidence evaluation — no AI needed."""
        evidence = (vuln.get("evidence") or "").lower()
        severity = (vuln.get("severity") or "medium").lower()
        vuln_type = (vuln.get("vuln_type") or "").lower()
        payload = (vuln.get("payload") or "").lower()

        # Strong evidence indicators
        STRONG = {
            "sqli": ["sql syntax", "mysql_fetch", "ora-0", "sqlite3",
                     "you have an error in your sql", "pg_query",
                     "unclosed quotation", "sqlexception"],
            "xss": ["[verified]", "alert(1)", "onerror=", "<script>",
                    "alert(document.cookie)", "screenshot"],
            "ssrf": ["ami-id", "instance-id", "computemetadata", "root:",
                     "iam/security-credentials"],
            "ssti": ["49", "7777777", "__class__", "root:x:0"],
            "jwt": ["alg:none", "algorithm confusion"],
            "cors": ["access-control-allow-origin: *",
                     "access-control-allow-credentials: true"],
        }

        has_strong = False
        strong_indicator = ""
        for indicator in STRONG.get(vuln_type, []):
            if indicator in evidence:
                has_strong = True
                strong_indicator = indicator
                break

        # [VERIFIED] tag = strong evidence
        if "[verified]" in evidence:
            has_strong = True
            strong_indicator = "[VERIFIED] tag present"

        # screenshot/proof mentions = strong evidence
        if any(w in evidence for w in ["screenshot", "proof", "session cookie", "confirms"]):
            has_strong = True
            strong_indicator = "proof artifact mentioned"

        has_url = bool(vuln.get("url"))
        has_payload = bool(payload) or bool(vuln.get("payload"))
        has_evidence = len(evidence) > 20 or len(vuln.get("description", "")) > 50
        has_reproduction = bool(vuln.get("reproduction_steps"))
        has_cvss = bool(vuln.get("cvss_score"))
        has_cwe = bool(vuln.get("cwe_id"))
        has_remediation = bool(vuln.get("remediation"))

        # Score based on completeness
        score = sum([
            has_strong * 0.40,
            has_url * 0.15,
            has_payload * 0.10,
            has_evidence * 0.10,
            has_reproduction * 0.10,
            has_cvss * 0.05,
            has_cwe * 0.05,
            has_remediation * 0.05,
        ])

        should_downgrade = not has_strong and score < 0.5

        return {
            "has_strong_evidence": has_strong,
            "strong_indicator": strong_indicator,
            "has_url": has_url,
            "has_payload": has_payload,
            "has_evidence": has_evidence,
            "has_reproduction_steps": has_reproduction,
            "evidence_score": round(score, 2),
            "quality_score": round(score, 2),
            "should_downgrade": should_downgrade,
            "strength": "strong" if score >= 0.6 else "moderate" if score >= 0.3 else "weak",
        }

    async def _ai_verdict(self, vuln: dict, evidence: dict,
                           context: dict) -> CourtVerdict:
        """Use Claude to argue prosecution vs defense."""

        prompt = f"""You are the GLASSWING Validation Court. Evaluate this security finding.

FINDING:
- Title: {vuln.get('title', 'Unknown')}
- Type: {vuln.get('vuln_type', 'unknown')}
- Severity: {vuln.get('severity', 'medium')}
- URL: {vuln.get('url', 'N/A')}
- Parameter: {vuln.get('parameter', 'N/A')}
- Payload: {vuln.get('payload', 'N/A')}
- Evidence: {(vuln.get('evidence') or '')[:400]}

DETERMINISTIC CHECK:
- Evidence strength: {evidence['strength']}
- Strong indicator found: {evidence.get('strong_indicator', 'none')}
- Evidence score: {evidence['evidence_score']}

Provide court evaluation as JSON:
{{
  "prosecution": "2-3 sentences arguing this IS a real vulnerability",
  "defense": "2-3 sentences arguing this COULD be a false positive",
  "verdict": "confirmed|false_positive|needs_review",
  "confidence": 0.0-1.0,
  "reasoning": "Final 1-sentence verdict reasoning",
  "bounty_tier": "critical|high|medium|low|informational",
  "recommended_action": "report_immediately|investigate_further|monitor|discard"
}}

XBOW principle: only mark confirmed if evidence proves impact.
Respond with JSON only."""

        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": settings.ANTHROPIC_API_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": "claude-haiku-4-5-20251001",
                    "max_tokens": 500,
                    "messages": [{"role": "user", "content": prompt}]
                }
            )

        if resp.status_code == 200:
            raw = resp.json()["content"][0]["text"].strip()
            if raw.startswith("```"):
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]
            data = json.loads(raw)
            return CourtVerdict(
                verdict=data.get("verdict", "needs_review"),
                confidence=float(data.get("confidence", 0.5)),
                reasoning=data.get("reasoning", ""),
                prosecution_arg=data.get("prosecution", ""),
                defense_arg=data.get("defense", ""),
                evidence_strength=evidence["strength"],
                bounty_tier=data.get("bounty_tier", "medium"),
                recommended_action=data.get("recommended_action", "investigate_further"),
            )
        raise Exception(f"Claude API error: {resp.status_code}")

    def _heuristic_verdict(self, vuln: dict, evidence: dict) -> CourtVerdict:
        """Deterministic verdict when AI unavailable."""
        score = evidence["evidence_score"]
        has_strong = evidence["has_strong_evidence"]
        severity = (vuln.get("severity") or "medium").lower()

        if has_strong or score >= 0.6:
            verdict = "confirmed"
            confidence = 0.85
            reasoning = f"Strong evidence: {evidence.get('strong_indicator', 'multiple signals')}"
            action = "report_immediately"
        elif score >= 0.35:
            verdict = "needs_review"
            confidence = 0.55
            reasoning = "Moderate evidence — manual verification recommended"
            action = "investigate_further"
        else:
            verdict = "false_positive"
            confidence = 0.3
            reasoning = "Insufficient evidence to confirm"
            action = "discard"

        bounty_map = {"critical": "critical", "high": "high",
                      "medium": "medium", "low": "low"}

        return CourtVerdict(
            verdict=verdict,
            confidence=confidence,
            reasoning=reasoning,
            prosecution_arg="Finding has indicators consistent with genuine vulnerability.",
            defense_arg="Evidence could be application-specific behavior or misconfiguration.",
            evidence_strength=evidence["strength"],
            bounty_tier=bounty_map.get(severity, "low"),
            recommended_action=action,
        )

    def _scope_check(self, vuln: dict, scope_engine=None) -> dict:
        if not scope_engine or not vuln.get("url"):
            return {"in_scope": True, "reason": "no scope configured"}
        # Handle both ScopeEngine objects and plain dicts
        if hasattr(scope_engine, "check_target"):
            result = scope_engine.check_target(vuln["url"])
            return {"in_scope": result.allowed, "reason": result.reason}
        # Dict-based scope check: {in_scope: [...], out_of_scope: [...]}
        url = vuln.get("url", "")
        out_of_scope = scope_engine.get("out_of_scope", [])
        for pattern in out_of_scope:
            if pattern.lstrip("*.") in url or url in pattern:
                return {"in_scope": False, "reason": f"matches out_of_scope rule: {pattern}"}
        include_patterns = scope_engine.get("in_scope", scope_engine.get("include_patterns", []))
        if not include_patterns:
            return {"in_scope": True, "reason": "no scope rules"}
        for pattern in include_patterns:
            if pattern.lstrip("*.") in url:
                return {"in_scope": True, "reason": f"matches {pattern}"}
        return {"in_scope": False, "reason": "no matching scope rule"}
