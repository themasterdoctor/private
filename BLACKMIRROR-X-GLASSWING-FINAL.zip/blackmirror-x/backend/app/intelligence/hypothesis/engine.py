"""
GLASSWING Hypothesis Engine — Mythos-style reasoning with real Claude API.

Every hypothesis is formed by Claude, ranked by exploitability, 
and verified with deterministic HTTP proof.
"""
from __future__ import annotations
import asyncio
import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, List, Optional
import httpx

from app.core.config import settings


class HypothesisStatus(str, Enum):
    PENDING = "pending"
    TESTING = "testing"
    CONFIRMED = "confirmed"
    REFUTED = "refuted"
    NEEDS_MANUAL = "needs_manual"


@dataclass
class ReasoningStep:
    step_type: str   # hypothesis|evidence|decision|payload_selection|conclusion|abandon|escalate
    content: str
    confidence: float = 0.5
    data: dict = field(default_factory=dict)


@dataclass
class Hypothesis:
    id: str
    title: str
    vuln_class: str
    description: str
    reasoning: str
    confidence: float
    priority_score: float
    severity: str
    test_payloads: List[str] = field(default_factory=list)
    bounty_estimate: str = "$0"
    status: HypothesisStatus = HypothesisStatus.PENDING
    proof: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "vuln_class": self.vuln_class,
            "description": self.description,
            "reasoning": self.reasoning,
            "confidence": self.confidence,
            "priority_score": self.priority_score,
            "severity": self.severity,
            "test_payloads": self.test_payloads,
            "bounty_estimate": self.bounty_estimate,
            "status": self.status.value,
        }


class HypothesisEngine:
    """
    Mythos-style AI hypothesis engine.
    Uses Claude API to form, rank, and reason about attack hypotheses.
    """

    def __init__(self, scan_id: str = "", workspace_id: str = ""):
        self.scan_id = scan_id
        self.workspace_id = workspace_id
        self._on_step: Optional[Callable] = None
        self._reasoning_steps: List[ReasoningStep] = []

    def on_step(self, callback: Callable) -> None:
        self._on_step = callback

    def _emit(self, step_type: str, content: str, confidence: float = 0.5, **data):
        step = ReasoningStep(step_type=step_type, content=content,
                             confidence=confidence, data=data)
        self._reasoning_steps.append(step)
        if self._on_step:
            try:
                self._on_step(step)
            except Exception:
                pass

    def form_hypotheses_from_signals(
        self,
        urls: List[str],
        params: List[str],
        technologies: List[str],
        headers: dict,
        existing_vulns: List[dict],
    ) -> List[Hypothesis]:
        """
        Form hypotheses synchronously (Celery worker context).
        Uses Claude API if available, falls back to heuristic engine.
        """
        try:
            return asyncio.run(self._form_with_ai(urls, params, technologies, headers, existing_vulns))
        except Exception:
            return self._form_heuristic(urls, params, technologies, headers)

    async def _form_with_ai(
        self,
        urls: List[str],
        params: List[str],
        technologies: List[str],
        headers: dict,
        existing_vulns: List[dict],
    ) -> List[Hypothesis]:
        """Call Claude API to generate ranked hypotheses."""
        if not settings.ANTHROPIC_API_KEY or settings.ANTHROPIC_API_KEY == "test":
            return self._form_heuristic(urls, params, technologies, headers)

        # Build target profile for Claude
        sample_urls = urls[:20]
        sample_params = list(set(params))[:20]
        tech_str = ", ".join(technologies[:10]) if technologies else "unknown"

        prompt = f"""You are GLASSWING, an expert bug bounty security researcher.
Analyze this target and generate ranked vulnerability hypotheses.

TARGET PROFILE:
- Sample URLs: {json.dumps(sample_urls, indent=2)}
- Parameters found: {json.dumps(sample_params)}
- Technologies: {tech_str}
- Known findings: {len(existing_vulns)} existing

Generate 5-8 specific, actionable vulnerability hypotheses ranked by:
1. Exploitability (can we prove it with an HTTP request?)
2. Business impact (data exposure, auth bypass, RCE)
3. Likelihood based on the tech stack and URL patterns

For each hypothesis provide:
- title: specific and actionable
- vuln_class: xss|sqli|ssrf|ssti|idor|cors|jwt|oauth|graphql|auth_bypass|open_redirect|secret_exposure
- description: what the vulnerability is and why it likely exists
- reasoning: step-by-step why this target is vulnerable
- confidence: 0.0-1.0
- severity: critical|high|medium|low
- test_payloads: list of 3 specific payloads to test
- bounty_estimate: realistic bug bounty range like "$500-$2000"

Think like XBOW: only hypothesize what you can PROVE with an HTTP request.
Respond with valid JSON array only, no other text."""

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key": settings.ANTHROPIC_API_KEY,
                        "anthropic-version": "2023-06-01",
                        "content-type": "application/json",
                    },
                    json={
                        "model": "claude-haiku-4-5-20251001",
                        "max_tokens": 2000,
                        "messages": [{"role": "user", "content": prompt}]
                    }
                )

            if resp.status_code == 200:
                data = resp.json()
                raw = data["content"][0]["text"].strip()
                # Strip markdown code blocks if present
                if raw.startswith("```"):
                    raw = raw.split("```")[1]
                    if raw.startswith("json"):
                        raw = raw[4:]
                items = json.loads(raw)
                hypotheses = []
                for i, item in enumerate(items[:8]):
                    h = Hypothesis(
                        id=f"hyp-{i+1}",
                        title=item.get("title", "Unknown"),
                        vuln_class=item.get("vuln_class", "unknown"),
                        description=item.get("description", ""),
                        reasoning=item.get("reasoning", ""),
                        confidence=float(item.get("confidence", 0.5)),
                        priority_score=float(item.get("confidence", 0.5)) * 100,
                        severity=item.get("severity", "medium"),
                        test_payloads=item.get("test_payloads", [])[:5],
                        bounty_estimate=item.get("bounty_estimate", "unknown"),
                    )
                    self._emit("hypothesis", f"🧠 {h.title} [{h.severity}] — {h.reasoning[:120]}",
                               confidence=h.confidence)
                    hypotheses.append(h)

                self._emit("conclusion",
                           f"✓ AI generated {len(hypotheses)} hypotheses ranked by exploitability",
                           confidence=0.9)
                return sorted(hypotheses, key=lambda x: x.priority_score, reverse=True)
        except Exception as e:
            self._emit("abandon", f"Claude API error: {e} — using heuristic fallback", confidence=0.3)

        return self._form_heuristic(urls, params, technologies, headers)

    def _form_heuristic(
        self,
        urls: List[str],
        params: List[str],
        technologies: List[str],
        headers: dict = None,
    ) -> List[Hypothesis]:
        """Fast heuristic hypothesis formation without AI."""
        import uuid
        if headers is None:
            headers = {}
        hypotheses = []
        url_text = " ".join(urls).lower()
        param_text = " ".join(params).lower()
        tech_text = " ".join(technologies).lower()

        RULES = [
            # (condition, hypothesis_data)
            (
                any(p in param_text for p in ["id","user_id","uid","account","order"]),
                dict(vuln_class="idor", severity="high", confidence=0.7,
                     title="IDOR via numeric/UUID parameter",
                     description="Numeric or UUID parameters suggest object-level authorization may be missing.",
                     reasoning="Parameters like id/user_id commonly lack per-object permission checks.",
                     test_payloads=["replace with another user's ID","0","1","2","99999"],
                     bounty_estimate="$500-$3000")
            ),
            (
                any(p in param_text for p in ["redirect","next","return","dest","url","callback","src"]),
                dict(vuln_class="ssrf", severity="critical", confidence=0.8,
                     title="SSRF via URL/redirect parameter",
                     description="URL-accepting parameter may not validate destination.",
                     reasoning="redirect/url/callback params are classic SSRF entry points.",
                     test_payloads=["http://169.254.169.254/latest/meta-data/",
                                    "http://127.0.0.1:80/","http://internal/"],
                     bounty_estimate="$1000-$10000")
            ),
            (
                any(p in param_text for p in ["q","search","query","input","text","name","title"]),
                dict(vuln_class="xss", severity="high", confidence=0.65,
                     title="Reflected XSS in search/input parameter",
                     description="User input reflected in response may lack encoding.",
                     reasoning="Input parameters that reflect content are prime XSS targets.",
                     test_payloads=['<script>alert(1)</script>', '"><img src=x onerror=alert(1)>',
                                    "javascript:alert(1)", '<svg onload=alert(1)>'],
                     bounty_estimate="$300-$2000")
            ),
            (
                any(p in param_text for p in ["id","user","order","product","item",
                                               "search","q","filter","query","input"]) or
                any(u in url_text for u in ["/api/","/v1/","/v2/","/users/","/accounts/"]),
                dict(vuln_class="sqli", severity="critical", confidence=0.6,
                     title="SQL Injection in API endpoint",
                     description="API endpoints with ID parameters may lack parameterization.",
                     reasoning="Unparameterized queries in API backends are common.",
                     test_payloads=["'", "' OR '1'='1", "1 AND SLEEP(2)", "' UNION SELECT 1--"],
                     bounty_estimate="$500-$5000")
            ),
            (
                any(u in url_text for u in ["/graphql", "/api/graphql", "/__graphql"]),
                dict(vuln_class="graphql", severity="medium", confidence=0.9,
                     title="GraphQL introspection enabled",
                     description="GraphQL endpoint may expose full schema via introspection.",
                     reasoning="GraphQL introspection is often left enabled in production.",
                     test_payloads=['{"query":"{__schema{types{name}}}"}'],
                     bounty_estimate="$100-$500")
            ),
            (
                any(t in tech_text for t in ["jinja2","flask","django","tornado","mako","twig","smarty","freemarker","velocity"]),
                dict(vuln_class="ssti", severity="critical", confidence=0.85,
                     title="Server-Side Template Injection (SSTI)",
                     description="Template engine detected — may evaluate user input as template expressions.",
                     reasoning="Flask/Jinja2/Django template engines are commonly vulnerable to SSTI when user input is directly rendered.",
                     test_payloads=["{{7*7}}","${7*7}","<%=7*7%>","{{config}}","{{''.__class__.__mro__[1].__subclasses__()}}"],
                     bounty_estimate="$2000-$20000")
            ),
            (
                "access-control-allow-origin" in " ".join(f"{k}: {v}" for k,v in headers.items()).lower() or
                any("cors" in u or "api" in u for u in url_text.split()),
                dict(vuln_class="cors", severity="high", confidence=0.8,
                     title="CORS Misconfiguration",
                     description="CORS headers detected — may allow unauthorized cross-origin requests.",
                     reasoning="Wildcard or overly permissive CORS headers can lead to data theft.",
                     test_payloads=["Origin: https://evil.com","Origin: null"],
                     bounty_estimate="$200-$2000")
            ),
            (
                "next" in tech_text or "react" in tech_text or "vue" in tech_text,
                dict(vuln_class="secret_exposure", severity="high", confidence=0.55,
                     title="API keys/secrets in JavaScript bundles",
                     description="SPA frameworks may bundle environment variables in client JS.",
                     reasoning="Build process mistakes commonly expose secrets in JS bundles.",
                     test_payloads=["Download and grep all .js files for key patterns"],
                     bounty_estimate="$200-$2000")
            ),
            (
                any(u in url_text for u in ["/login","/auth","/token","/oauth","/jwt"]),
                dict(vuln_class="auth_bypass", severity="critical", confidence=0.6,
                     title="Authentication bypass via parameter manipulation",
                     description="Auth endpoints may be vulnerable to token/session manipulation.",
                     reasoning="Auth logic bugs are frequent in custom implementations.",
                     test_payloads=["Remove JWT signature","Set alg:none","Modify role claim"],
                     bounty_estimate="$1000-$15000")
            ),
        ]

        for condition, data in RULES:
            if condition:
                h = Hypothesis(
                    id=f"hyp-{len(hypotheses)+1}",
                    priority_score=data["confidence"] * 100,
                    **data
                )
                self._emit("hypothesis",
                           f"🎯 [{h.severity.upper()}] {h.title} — {h.reasoning[:100]}",
                           confidence=h.confidence)
                hypotheses.append(h)

        return sorted(hypotheses, key=lambda x: x.priority_score, reverse=True)

    async def refine_hypothesis(self, h: Hypothesis, test_response: dict) -> Hypothesis:
        """Use AI to evaluate test results and refine hypothesis."""
        if not settings.ANTHROPIC_API_KEY or settings.ANTHROPIC_API_KEY == "test":
            return h
        # Simple heuristic refinement for now
        if test_response.get("status_code") in (200, 302):
            h.confidence = min(h.confidence + 0.1, 1.0)
        return h

    async def ai_rank_hypotheses(self, hypotheses: List[Hypothesis]) -> List[Hypothesis]:
        return sorted(hypotheses, key=lambda x: x.priority_score, reverse=True)

    def get_next_tests(self, h: Hypothesis) -> List[str]:
        return h.test_payloads[:3]
