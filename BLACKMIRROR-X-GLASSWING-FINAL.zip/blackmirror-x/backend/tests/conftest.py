import os
import sys

os.environ.setdefault("DATABASE_URL", "postgresql+asyncpg://bmx:test@localhost/blackmirror")
os.environ.setdefault("SECRET_KEY", "test-secret-key-32-chars-minimum-xx")
os.environ.setdefault("JWT_SECRET_KEY", "test-jwt-secret-key-32-chars-min-x")
os.environ.setdefault("ANTHROPIC_API_KEY", "sk-ant-test-000000")
os.environ.setdefault("REDIS_URL", "redis://localhost:6379/0")
os.environ.setdefault("CELERY_BROKER_URL", "redis://localhost:6379/1")
os.environ.setdefault("CELERY_RESULT_BACKEND", "redis://localhost:6379/2")
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pytest


@pytest.fixture(scope="session")
def anyio_backend():
    return "asyncio"


@pytest.fixture(scope="session")
async def client():
    """
    Session-scoped async HTTP client.
    Session scope avoids the 'task attached to different loop' error
    that occurs when asyncpg connections are created in one loop but
    torn down in another.
    """
    from httpx import AsyncClient, ASGITransport
    from app.main import app

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as ac:
        yield ac
