"""
BLACKMIRROR-X GLASSWING — Production Readiness Tests
These tests verify the core platform without needing a database connection.
Run: pytest tests/test_production_readiness.py -v
"""
import os
import sys
import pytest

# Set required env vars before any imports
os.environ.setdefault("DATABASE_URL", "postgresql+asyncpg://x:x@localhost/x")
os.environ.setdefault("REDIS_URL", "redis://localhost:6379/0")
os.environ.setdefault("CELERY_BROKER_URL", "redis://localhost:6379/1")
os.environ.setdefault("CELERY_RESULT_BACKEND", "redis://localhost:6379/2")
os.environ.setdefault("ANTHROPIC_API_KEY", "test-key")
os.environ.setdefault("SECRET_KEY", "test_secret_key_32chars_aaaaaaaaaa")
os.environ.setdefault("JWT_SECRET_KEY", "test_jwt_key_32chars_aaaaaaaaaaaaa")

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))


# ── Security Module ───────────────────────────────────────────────────────────

class TestSecurityModule:
    def test_password_hash_and_verify(self):
        from app.core.security import hash_password, verify_password
        h = hash_password("mypassword123")
        assert verify_password("mypassword123", h)
        assert not verify_password("wrongpassword", h)

    def test_jwt_create_and_decode(self):
        from app.core.security import create_access_token, decode_token
        token = create_access_token("user-123")
        payload = decode_token(token)
        assert payload is not None
        assert payload["sub"] == "user-123"
        assert payload["type"] == "access"

    def test_jwt_refresh_token(self):
        from app.core.security import create_refresh_token, decode_token
        token = create_refresh_token("user-456")
        payload = decode_token(token)
        assert payload["sub"] == "user-456"
        assert payload["type"] == "refresh"

    def test_api_key_generate_and_hash(self):
        from app.core.security import generate_api_key, hash_api_key, verify_api_key
        raw, hashed = generate_api_key()
        assert raw.startswith("bmx_")
        assert verify_api_key(raw, hashed)
        assert not verify_api_key("bmx_wrong", hashed)

    def test_invalid_jwt_returns_none(self):
        from app.core.security import decode_token
        assert decode_token("not.a.token") is None
        assert decode_token("") is None


# ── SQLAlchemy Models ─────────────────────────────────────────────────────────

class TestModels:
    def test_all_models_import(self):
        from app.models.models import (
            User, Workspace, WorkspaceMember, APIKey, Target,
            ScanJob, ScanLog, Subdomain, DiscoveredURL, Vulnerability,
            AgentRun, Report, CopilotMessage, KnowledgeChunk, AuditLog
        )
        # Just verify they're classes
        assert User.__tablename__ == "users"
        assert Workspace.__tablename__ == "workspaces"
        assert ScanJob.__tablename__ == "scan_jobs"
        assert Vulnerability.__tablename__ == "vulnerabilities"

    def test_enums(self):
        from app.models.models import ScanStatus, ScanType, Severity, VulnStatus, UserRole
        assert ScanStatus.QUEUED.value == "queued"
        assert ScanStatus.COMPLETED.value == "completed"
        assert Severity.CRITICAL.value == "critical"
        assert VulnStatus.OPEN.value == "open"
        assert UserRole.ADMIN.value == "admin"


# ── Configuration ─────────────────────────────────────────────────────────────

class TestConfig:
    def test_settings_load(self):
        from app.core.config import settings
        assert settings.APP_NAME == "BLACKMIRROR-X GLASSWING"
        assert settings.JWT_ALGORITHM == "HS256"
        assert isinstance(settings.CORS_ORIGINS, list)

    def test_cors_origins_parsed(self):
        from app.core.config import Settings
        s = Settings(CORS_ORIGINS="http://a.com,http://b.com")
        assert "http://a.com" in s.CORS_ORIGINS
        assert "http://b.com" in s.CORS_ORIGINS


# ── Schema Validation ─────────────────────────────────────────────────────────

class TestSchemas:
    def test_scan_create_request_target_injection(self):
        from app.schemas.scans import ScanCreateRequest
        req = ScanCreateRequest(
            workspace_id="ws-1",
            name="Test",
            target="https://example.com/path?q=test"
        )
        assert req.config is not None
        assert req.config["domain"] == "example.com"

    def test_scan_create_request_no_target(self):
        from app.schemas.scans import ScanCreateRequest
        req = ScanCreateRequest(workspace_id="ws-1", name="Test")
        # Should work without target
        assert req.workspace_id == "ws-1"

    def test_scan_out_enum_normalization(self):
        """Enum values must serialize as strings not repr."""
        from app.schemas.scans import ScanOut
        from datetime import datetime
        # Simulate what model_validator does
        data = ScanOut.model_validate({
            "id": "scan-1", "name": "Test", "scan_type": "full",
            "status": "queued", "progress": 0,
            "created_at": datetime.utcnow(),
            "workspace_id": "ws-1", "created_by": "user-1",
        })
        assert data.status == "queued"  # not "<ScanStatus.QUEUED: 'queued'>"
        assert data.scan_type == "full"


# ── Enterprise: Scope Engine ──────────────────────────────────────────────────

class TestScopeEngine:
    def test_basic_scope_check(self):
        from app.enterprise.scope_engine import ScopeEngine
        engine = ScopeEngine("ws-test")
        engine.add_scope("*.example.com")
        engine.add_scope("example.com")

        assert engine.check_target("api.example.com").allowed
        assert engine.check_target("www.example.com").allowed
        assert engine.check_target("example.com").allowed
        assert not engine.check_target("google.com").allowed

    def test_exclusion_wins(self):
        from app.enterprise.scope_engine import ScopeEngine
        engine = ScopeEngine("ws-test")
        engine.add_scope("*.example.com")
        engine.add_exclusion("admin.example.com")

        assert engine.check_target("api.example.com").allowed
        assert not engine.check_target("admin.example.com").allowed

    def test_no_scope_allows_all(self):
        from app.enterprise.scope_engine import ScopeEngine
        engine = ScopeEngine("ws-empty")
        result = engine.check_target("anything.com")
        assert result.allowed  # open scope by default

    def test_cidr_scope(self):
        from app.enterprise.scope_engine import ScopeEngine
        engine = ScopeEngine("ws-cidr")
        engine.add_scope("10.0.0.0/8")
        assert engine.check_target("10.1.2.3").allowed
        assert not engine.check_target("192.168.1.1").allowed

    def test_url_extraction(self):
        from app.enterprise.scope_engine import ScopeEngine
        engine = ScopeEngine("ws-url")
        engine.add_scope("example.com")
        assert engine.check_target("https://example.com/path?q=1").allowed

    def test_audit_log(self):
        from app.enterprise.scope_engine import ScopeEngine
        engine = ScopeEngine("ws-audit")
        engine.check_target("example.com", user_id="user1", action="test")
        log = engine.get_audit_log()
        assert len(log) == 1
        assert log[0]["user_id"] == "user1"

    def test_program_import(self):
        from app.enterprise.scope_engine import ScopeEngine, ProgramProfile
        engine = ScopeEngine("ws-prog")
        profile = ProgramProfile(
            program_name="Test Program",
            platform="hackerone",
            scope_domains=["*.testcorp.com"],
            out_of_scope=["admin.testcorp.com"],
        )
        engine.import_program(profile)
        assert engine.check_target("api.testcorp.com").allowed
        assert not engine.check_target("admin.testcorp.com").allowed


# ── Enterprise: Confidence Scoring ───────────────────────────────────────────

class TestConfidenceScoring:
    def test_xss_scoring(self):
        from app.enterprise.confidence_scoring import score_finding
        p = score_finding("xss", "high", evidence_count=2, has_request_response=True, scope_confirmed=True)
        assert 0 < p.confidence_score <= 1
        assert 0 < p.exploitability_score <= 1
        assert 0 < p.business_impact_score <= 1
        assert 0 <= p.false_positive_risk <= 1
        assert 0 < p.overall_score <= 1
        assert p.recommended_action is not None

    def test_sqli_high_impact(self):
        from app.enterprise.confidence_scoring import score_finding
        p = score_finding("sqli", "critical", evidence_count=3, has_screenshot=True)
        assert p.business_impact_score >= 0.7  # SQLi critical should have high impact

    def test_fp_risk_penalizes_score(self):
        from app.enterprise.confidence_scoring import score_finding
        p_low_fp = score_finding("idor", "high", scope_confirmed=True)
        p_high_fp = score_finding("idor", "high", scope_confirmed=False)
        assert p_low_fp.overall_score >= p_high_fp.overall_score

    def test_waf_reduces_exploitability(self):
        from app.enterprise.confidence_scoring import score_finding
        p_no_waf = score_finding("xss", "medium", waf_detected=False)
        p_waf = score_finding("xss", "medium", waf_detected=True)
        assert p_no_waf.exploitability_score >= p_waf.exploitability_score

    def test_all_vuln_types_score(self):
        from app.enterprise.confidence_scoring import score_finding
        for vtype in ["xss", "sqli", "ssrf", "ssti", "idor", "cors", "open_redirect", "jwt"]:
            p = score_finding(vtype, "medium")
            assert 0 < p.overall_score <= 1, f"{vtype} score out of range: {p.overall_score}"


# ── Enterprise: Payload Library ───────────────────────────────────────────────

class TestPayloadLibrary:
    def test_get_auto_safe_payloads(self):
        from app.enterprise.payload_library import get_auto_safe_payloads, PayloadTier
        payloads = get_auto_safe_payloads("xss")
        assert len(payloads) > 0
        for p in payloads:
            assert p.tier in (PayloadTier.PASSIVE, PayloadTier.LOW_RISK)

    def test_blocked_payloads_excluded(self):
        from app.enterprise.payload_library import get_auto_safe_payloads, get_payloads, PayloadTier, PAYLOAD_LIBRARY
        # Verify blocked payloads exist in library
        sqli_payloads = PAYLOAD_LIBRARY.get("sqli", [])
        blocked = [p for p in sqli_payloads if p.tier == PayloadTier.BLOCKED]
        assert len(blocked) > 0, "Expected blocked payloads in SQLi library"

        # Verify they're excluded from auto-safe
        safe = get_auto_safe_payloads("sqli")
        for p in safe:
            assert p.tier != PayloadTier.BLOCKED, f"Blocked payload {p.value} in safe list"

    def test_payload_summary(self):
        from app.enterprise.payload_library import get_payload_tiers_summary
        summary = get_payload_tiers_summary()
        assert "xss" in summary
        assert "sqli" in summary
        for vtype, data in summary.items():
            assert data["auto_safe"] <= data["total"]

    def test_payload_has_expected_fields(self):
        from app.enterprise.payload_library import PAYLOAD_LIBRARY
        for vtype, payloads in PAYLOAD_LIBRARY.items():
            for p in payloads:
                assert p.value, f"{vtype} payload has empty value"
                assert p.vuln_type == vtype
                assert p.tier is not None
                d = p.to_dict()
                assert "value" in d and "tier" in d


# ── Enterprise: Plugin SDK ────────────────────────────────────────────────────

class TestPluginSDK:
    def test_built_in_plugins_registered(self):
        from app.enterprise.plugin_sdk import registry, PluginType
        plugins = registry.list_plugins()
        assert len(plugins) >= 2
        names = [p["name"] for p in plugins]
        assert "passive_headers_scanner" in names
        assert "cve_enricher" in names

    def test_scanner_plugin_type(self):
        from app.enterprise.plugin_sdk import registry, PluginType
        scanners = registry.list_scanners()
        assert len(scanners) >= 1
        for s in scanners:
            assert s["plugin_type"] == "scanner"

    def test_plugin_enable_disable(self):
        from app.enterprise.plugin_sdk import registry
        registry.enable("passive_headers_scanner")
        plugin = registry.get("passive_headers_scanner")
        assert plugin is not None

        registry.disable("passive_headers_scanner")
        plugin = registry.get("passive_headers_scanner")
        assert plugin is None  # disabled

        registry.enable("passive_headers_scanner")  # restore


# ── Enterprise: Team Features ─────────────────────────────────────────────────

class TestTeamFeatures:
    def test_rbac_permissions(self):
        from app.enterprise.team_features import check_permission
        # Owner can do everything
        assert check_permission("owner", "scan:create")
        assert check_permission("owner", "billing:manage")
        assert check_permission("owner", "emergency:stop")

        # Viewer cannot scan or manage
        assert not check_permission("viewer", "scan:create")
        assert not check_permission("viewer", "team:manage")

        # Analyst can triage but not manage team
        assert check_permission("analyst", "vuln:triage")
        assert not check_permission("analyst", "team:manage")

    def test_sla_policy_deadlines(self):
        from app.enterprise.team_features import SLAPolicy
        from datetime import datetime, timezone
        policy = SLAPolicy()
        now = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        discovered = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)

        critical_status = policy.get_sla_status("critical", discovered, now=now)
        # 1 day SLA, 12h elapsed = 50% remaining = on_track (not yet in warning zone)
        assert critical_status["status"] in ("on_track", "warning", "critical")
        assert critical_status["days_remaining"] >= 0

        # Test on-track
        fresh = datetime(2026, 1, 1, 11, 59, 0, tzinfo=timezone.utc)
        status = policy.get_sla_status("high", fresh, now=now)  # 7 days
        assert status["days_remaining"] >= 6

    async def test_report_quality_checker(self):
        from app.enterprise.team_features import ReportQualityChecker
        checker = ReportQualityChecker()
        vulns = [
            {"title": "SQL Injection", "severity": "critical", "url": "https://t.com/api",
             "payload": "' OR 1=1--", "evidence": "error based", "reproduction_steps": "1. ...",
             "cvss_score": 9.1}
        ]
        result = await checker.check_report("## Summary\n\nThis report covers XSS.\n## Impact\nHigh.\n## Remediation\nFix it.", vulns)
        assert "overall_score" in result
        assert 0 <= result["overall_score"] <= 1


# ── Enterprise: Evidence Engine ───────────────────────────────────────────────

class TestEvidenceEngine:
    def test_http_evidence_curl_generation(self):
        from app.enterprise.evidence_engine import HttpEvidence
        ev = HttpEvidence(
            method="POST",
            url="https://target.com/api/login",
            request_headers={"Content-Type": "application/json", "Authorization": "Bearer tok"},
            request_body='{"username":"admin","password":"pass"}',
            status_code=200,
            payload_used="' OR 1=1--",
            indicator_found="welcome admin",
        )
        curl = ev.to_curl()
        assert "curl" in curl
        assert "POST" in curl
        assert "target.com" in curl
        assert "Authorization" in curl

    def test_proof_section_generation(self):
        from app.enterprise.evidence_engine import HttpEvidence
        ev = HttpEvidence(
            method="GET", url="https://target.com/admin",
            status_code=200, payload_used="test",
            indicator_found="admin panel",
        )
        proof = ev.to_proof_section()
        assert "## Proof of Concept" in proof
        assert "curl" in proof
        assert "GET" in proof

    def test_evidence_package(self):
        from app.enterprise.evidence_engine import HttpEvidence, EvidencePackage
        pkg = EvidencePackage(vuln_id="v1", scan_id="s1", workspace_id="w1")
        ev1 = HttpEvidence(method="GET", url="https://t.com", status_code=200)
        ev2 = HttpEvidence(method="POST", url="https://t.com/api", status_code=200)
        pkg.add_evidence(ev1, primary=True)
        pkg.add_evidence(ev2)
        assert pkg.primary_evidence == ev1
        assert len(pkg.supporting_evidence) == 1

    def test_evidence_hash_generation(self):
        from app.enterprise.evidence_engine import HttpEvidence
        ev1 = HttpEvidence(method="GET", url="https://a.com", status_code=200, indicator_found="test")
        ev2 = HttpEvidence(method="GET", url="https://b.com", status_code=200, indicator_found="test")
        assert ev1.evidence_hash != ev2.evidence_hash  # Different URLs → different hashes
        assert len(ev1.evidence_hash) == 16


# ── Approval Gates ────────────────────────────────────────────────────────────

class TestApprovalGates:
    def test_risk_tier_classification(self):
        from app.enterprise.approval_gates import ApprovalGate, RiskTier
        gate = ApprovalGate("ws-1")
        assert gate.get_risk_tier("subdomain_enum") == RiskTier.PASSIVE
        assert gate.get_risk_tier("sqli_time_based") == RiskTier.HIGH
        assert gate.get_risk_tier("dos_test") == RiskTier.BLOCKED
        assert gate.get_risk_tier("xss_reflection_check") == RiskTier.LOW

    def test_emergency_stop(self):
        from app.enterprise.approval_gates import ApprovalGate, _emergency_stops
        gate = ApprovalGate("ws-emergency")
        assert not gate.is_emergency_stopped()
        gate.emergency_stop(user_id="admin")
        assert gate.is_emergency_stopped()
        gate.resume_after_stop()
        assert not gate.is_emergency_stopped()

    def test_list_pending_initially_empty(self):
        from app.enterprise.approval_gates import list_pending_approvals
        pending = list_pending_approvals("ws-new-empty-workspace")
        assert isinstance(pending, list)
        assert len(pending) == 0


# ── App Routes ────────────────────────────────────────────────────────────────

class TestAppRoutes:
    def test_route_count(self):
        from app.main import app
        routes = [r for r in app.routes if hasattr(r, "path") and "/api/" in r.path]
        assert len(routes) >= 100, f"Expected >=100 API routes, got {len(routes)}"

    def test_critical_routes_exist(self):
        from app.main import app
        paths = set(r.path for r in app.routes if hasattr(r, "path"))
        required = [
            "/api/v1/auth/login",
            "/api/v1/auth/register",
            "/api/v1/auth/me",
            "/api/v1/workspaces",
            "/api/v1/scans",
            "/api/v1/vulns",
            "/api/v1/recon/subdomains",
            "/api/v1/reports",
            "/api/v1/copilot/chat/stream",
            "/api/v1/enterprise/scope/{workspace_id}",
            "/api/v1/enterprise/approvals/{request_id}/approve",
            "/api/v1/enterprise/emergency-stop/{workspace_id}",
            "/api/v1/enterprise/payloads/{vuln_type}",
            "/api/v1/enterprise/plugins",
            "/api/v1/enterprise/report-quality/{scan_id}",
        ]
        for ep in required:
            assert ep in paths, f"Missing route: {ep}"

    def test_health_endpoint(self):
        from app.main import app
        paths = set(r.path for r in app.routes if hasattr(r, "path"))
        assert "/health" in paths
