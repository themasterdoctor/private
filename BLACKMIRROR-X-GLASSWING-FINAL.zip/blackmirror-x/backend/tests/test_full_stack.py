"""BLACKMIRROR-X GLASSWING — Backend Test Suite.

Tests:
- Health endpoint
- Auth (register/login/me)
- Workspace creation
- Scan creation
- Intelligence routes (hypotheses, court, memory, simulation, payloads)
- Route consistency (every frontend API call has a matching backend route)
"""
import os
import sys
import pytest

# Set env before any app imports
os.environ.setdefault("DATABASE_URL", "postgresql+asyncpg://bmx:test@localhost/blackmirror")
os.environ.setdefault("DATABASE_URL_SYNC", "postgresql+psycopg2://bmx:test@localhost/blackmirror")
os.environ.setdefault("SECRET_KEY", "test-secret-key-32-chars-minimum-xx")
os.environ.setdefault("JWT_SECRET_KEY", "test-jwt-secret-key-32-chars-min-x")
os.environ.setdefault("ANTHROPIC_API_KEY", "sk-ant-test-000000")
os.environ.setdefault("REDIS_URL", "redis://localhost:6379/0")
os.environ.setdefault("CELERY_BROKER_URL", "redis://localhost:6379/1")
os.environ.setdefault("CELERY_RESULT_BACKEND", "redis://localhost:6379/2")

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from fastapi.testclient import TestClient


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def client():
    """TestClient that doesn't need a real DB for import/route tests."""
    from app.main import app
    return TestClient(app, raise_server_exceptions=False)


@pytest.fixture(scope="session")
def all_routes(client):
    """Collect all registered route paths."""
    from app.main import app
    return {
        (tuple(sorted(list(r.methods or []))), r.path)
        for r in app.routes
        if hasattr(r, "path") and hasattr(r, "methods")
    }


# ── 1. Import / Startup Tests ─────────────────────────────────────────────────

class TestImports:
    def test_config_imports(self):
        from app.core.config import settings
        assert settings.APP_NAME == "BLACKMIRROR-X GLASSWING"

    def test_models_import(self):
        from app.models.models import (
            User, Workspace, ScanJob, Vulnerability,
            Subdomain, DiscoveredURL, Report, CopilotMessage
        )
        assert User.__tablename__ == "users"
        assert Vulnerability.__tablename__ == "vulnerabilities"

    def test_intelligence_reasoning_import(self):
        from app.intelligence.reasoning import ReasoningAgentBase, ReasoningTrace, ReasoningStep
        agent = ReasoningAgentBase(scan_id="test", workspace_id="ws1")
        step = agent.think("test thought", confidence=0.8)
        assert step.confidence == 0.8
        assert len(agent.trace.steps) == 1

    def test_hypothesis_engine_import(self):
        from app.intelligence.hypothesis.engine import HypothesisEngine
        engine = HypothesisEngine(scan_id="test")
        hypotheses = engine.form_hypotheses_from_signals(
            urls=["https://api.example.com/users/123", "https://example.com/search?q=test"],
            params=["q", "id", "user_id"],
            technologies=["React", "Node.js"],
            headers={},
            existing_vulns=[],
        )
        assert len(hypotheses) > 0
        assert all(h.confidence > 0 for h in hypotheses)

    def test_payload_intel_import(self):
        from app.intelligence.payloads.payload_intel import (
            PayloadIntelligenceSystem, ReflectionContext, WAFSignature
        )
        system = PayloadIntelligenceSystem()
        payloads = system.select_payloads("xss", ReflectionContext.HTML_TEXT, WAFSignature.NONE)
        assert len(payloads) > 0
        assert any("<script>" in p or "onerror=" in p for p in payloads)

    def test_exploitability_simulator_import(self):
        from app.intelligence.simulator.exploitability import ExploitabilitySimulator
        sim = ExploitabilitySimulator()
        report = sim.simulate({
            "id": "test-vuln-1",
            "vuln_type": "xss",
            "severity": "high",
            "url": "https://example.com/search",
        })
        assert report.account_takeover_likelihood > 0
        assert report.overall_impact_score() > 0

    def test_workspace_memory_import(self):
        from app.intelligence.memory.workspace_memory import WorkspaceMemory
        mem = WorkspaceMemory(workspace_id="ws-test")
        mem.record_payload_attempt("<script>alert(1)</script>", "xss", success=True)
        mem.record_finding("xss", confirmed=True)
        mem.add_technology("React", confidence=0.9)
        assert mem.successful_vuln_types.get("xss") == 1
        assert "React" in mem.technologies
        best = mem.best_payloads_for("xss")
        assert len(best) >= 0  # may be 0 if attempt_count < 2

    def test_vault_import(self):
        from app.vault.vault import SecretsVault
        vault = SecretsVault(master_key="test-master-key-for-unit-tests")
        sid = vault.store("test_key", "super-secret-value", "api_key", "ws-001")
        retrieved = vault.retrieve(sid, "ws-001")
        assert retrieved == "super-secret-value"
        # Wrong workspace should return None
        assert vault.retrieve(sid, "ws-wrong") is None

    def test_chain_composer_import(self):
        from app.intelligence.chain.chain_composer import AttackChainComposer
        composer = AttackChainComposer()
        chains = composer.compose_chains(
            vulns=[{"vuln_type": "xss", "severity": "high", "title": "XSS in bio", "url": "https://example.com/profile"}],
            subdomains=[],
            js_findings=[],
        )
        assert len(chains) > 0
        assert chains[0].chain_probability > 0

    def test_js_reverse_import(self):
        from app.intelligence.js_ast.js_reverse import JSReverseEngineer
        eng = JSReverseEngineer()
        # AIza + exactly 35 alphanumeric chars = valid Google API key format
        result = eng._extract_secrets(
            'const API_KEY = "AIzaSyTestKeyForUnitTestOnly12345678901";',
            "test.js"
        )
        assert any(s.secret_type == "GOOGLE_API_KEY" for s in result)

    def test_metrics_import(self):
        from app.metrics.prometheus_metrics import MetricsCollector
        # Should not raise even without Prometheus installed
        MetricsCollector.scan_started("ws-test", "full")
        MetricsCollector.vuln_found("ws-test", "high", "xss")
        data, content_type = MetricsCollector.get_metrics_text()
        assert data is not None


# ── 2. FastAPI App Tests ───────────────────────────────────────────────────────

class TestAppRoutes:
    def test_app_loads(self, client):
        """App should load without crashing."""
        assert client is not None

    def test_health_endpoint(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data.get("status") in ("ok", "healthy", "degraded")

    def test_root_redirects(self, client):
        resp = client.get("/", follow_redirects=False)
        assert resp.status_code in (200, 301, 302, 307, 308)

    def test_openapi_available(self, client):
        resp = client.get("/api/openapi.json")
        assert resp.status_code == 200
        schema = resp.json()
        assert "paths" in schema
        assert len(schema["paths"]) > 0

    def test_all_intel_routes_registered(self, all_routes):
        """Every intelligence endpoint must be registered."""
        paths = {r[1] for r in all_routes}
        required = [
            "/api/v1/intel/hypotheses/generate/{scan_id}",
            "/api/v1/intel/hypotheses/stream/{scan_id}",
            "/api/v1/intel/court/adjudicate/{vuln_id}",
            "/api/v1/intel/memory/{workspace_id}",
            "/api/v1/intel/memory/{workspace_id}/false-positive",
            "/api/v1/intel/simulate/{vuln_id}",
            "/api/v1/intel/payloads/{vuln_type}",
            "/api/v1/intel/monitor/start",
            "/api/v1/intel/monitor/active",
            "/api/v1/intel/monitor/{workspace_id}/{target:path}",
            "/api/v1/intel/metrics",
        ]
        for path in required:
            assert path in paths, f"Missing route: {path}"

    def test_core_routes_registered(self, all_routes):
        paths = {r[1] for r in all_routes}
        required = [
            "/api/v1/auth/login",
            "/api/v1/auth/register",
            "/api/v1/auth/me",
            "/api/v1/workspaces",
            "/api/v1/scans",
            "/api/v1/vulns",
            "/api/v1/recon/subdomains",
            "/api/v1/reports",
            "/health",
        ]
        for path in required:
            assert path in paths, f"Missing route: {path}"

    def test_auth_register_returns_422_for_bad_input(self, client):
        """Register with no body → 422 validation error (not 500)."""
        resp = client.post("/api/v1/auth/register", json={})
        assert resp.status_code == 422

    def test_auth_login_returns_422_for_bad_input(self, client):
        resp = client.post("/api/v1/auth/login", data={})
        assert resp.status_code == 422

    def test_protected_routes_return_401(self, client):
        """Protected routes must return 401/403 without auth, not 500."""
        protected = [
            ("GET", "/api/v1/workspaces"),
            ("GET", "/api/v1/scans"),
            ("GET", "/api/v1/vulns"),
        ]
        for method, path in protected:
            resp = client.request(method, path)
            assert resp.status_code in (401, 403, 422), (
                f"{method} {path} returned {resp.status_code} — expected 401/403"
            )

    def test_intel_payloads_no_auth(self, client):
        """Payloads endpoint requires auth."""
        resp = client.get("/api/v1/intel/payloads/xss")
        assert resp.status_code in (401, 403, 422)

    def test_metrics_no_auth_required(self, client):
        """Metrics endpoint is public (for Prometheus scraping)."""
        resp = client.get("/api/v1/intel/metrics")
        assert resp.status_code == 200


# ── 3. Route Consistency Tests ────────────────────────────────────────────────

class TestRouteConsistency:
    """Verify every frontend API call in api.ts has a matching backend route."""

    FRONTEND_CALLS = [
        # (method, path_template)
        ("POST", "/auth/register"),
        ("POST", "/auth/login"),
        ("GET", "/auth/me"),
        ("POST", "/auth/refresh"),
        ("GET", "/workspaces"),
        ("POST", "/workspaces"),
        ("GET", "/scans"),
        ("POST", "/scans"),
        ("GET", "/scans/{scan_id}"),
        ("POST", "/scans/{scan_id}/cancel"),
        ("GET", "/vulns"),
        ("GET", "/vulns/{vuln_id}"),
        ("PATCH", "/vulns/{vuln_id}"),
        ("GET", "/recon/subdomains"),
        ("GET", "/recon/urls"),
        ("GET", "/reports"),
        ("POST", "/reports/generate/{scan_id}"),
        ("POST", "/intel/hypotheses/generate/{scan_id}"),
        ("POST", "/intel/court/adjudicate/{vuln_id}"),
        ("GET", "/intel/memory/{workspace_id}"),
        ("POST", "/intel/memory/{workspace_id}/false-positive"),
        ("POST", "/intel/simulate/{vuln_id}"),
        ("GET", "/intel/payloads/{vuln_type}"),
        ("POST", "/intel/monitor/start"),
        ("GET", "/intel/monitor/active"),
        ("DELETE", "/intel/monitor/{workspace_id}/{target}"),
        ("GET", "/intel/metrics"),
    ]

    def test_all_frontend_calls_have_backend_routes(self, all_routes):
        paths = {r[1] for r in all_routes}
        # Normalize path params for comparison
        def normalize(path: str) -> str:
            import re
            return re.sub(r"\{[^}]+\}", "{param}", path)

        normalized_backend = {normalize(p) for p in paths}
        missing = []
        for method, path in self.FRONTEND_CALLS:
            full = f"/api/v1{path}"
            norm = normalize(full)
            if norm not in normalized_backend:
                missing.append(f"{method} {full}")

        assert not missing, f"Frontend calls with no backend route:\n" + "\n".join(f"  {m}" for m in missing)


# ── 4. Unit Logic Tests ───────────────────────────────────────────────────────

class TestIntelligenceLogic:
    def test_hypothesis_ssrf_pattern_detected(self):
        from app.intelligence.hypothesis.engine import HypothesisEngine
        engine = HypothesisEngine()
        hyps = engine.form_hypotheses_from_signals(
            urls=["https://api.example.com/import-document"],
            params=["import_url", "proxy", "fetch_url"],  # param names that trigger SSRF
            technologies=[],
            headers={},
            existing_vulns=[],
        )
        vuln_classes = [h.vuln_class for h in hyps]
        assert "ssrf" in vuln_classes, f"Expected ssrf in {vuln_classes}"

    def test_hypothesis_sqli_param_detected(self):
        from app.intelligence.hypothesis.engine import HypothesisEngine
        engine = HypothesisEngine()
        hyps = engine.form_hypotheses_from_signals(
            urls=[],
            params=["search", "q", "filter"],
            technologies=[],
            headers={},
            existing_vulns=[],
        )
        vuln_classes = [h.vuln_class for h in hyps]
        assert "sqli" in vuln_classes

    def test_hypothesis_tech_ssti_boost(self):
        from app.intelligence.hypothesis.engine import HypothesisEngine
        engine = HypothesisEngine()
        hyps = engine.form_hypotheses_from_signals(
            urls=[], params=[],
            technologies=["Jinja2", "Flask"],
            headers={}, existing_vulns=[],
        )
        ssti = [h for h in hyps if h.vuln_class == "ssti"]
        assert ssti, "Should detect SSTI for Flask/Jinja2"
        assert ssti[0].confidence >= 0.8

    def test_cors_wildcard_detected(self):
        from app.intelligence.hypothesis.engine import HypothesisEngine
        engine = HypothesisEngine()
        hyps = engine.form_hypotheses_from_signals(
            urls=[], params=[], technologies=[],
            headers={"Access-Control-Allow-Origin": "*"},
            existing_vulns=[],
        )
        cors = [h for h in hyps if h.vuln_class == "cors"]
        assert cors
        assert cors[0].confidence >= 0.8

    def test_payload_context_selection_html(self):
        from app.intelligence.payloads.payload_intel import (
            PayloadIntelligenceSystem, ReflectionContext, WAFSignature
        )
        system = PayloadIntelligenceSystem()
        payloads = system.select_payloads("xss", ReflectionContext.HTML_TEXT, WAFSignature.NONE)
        assert len(payloads) >= 3
        # Should contain script or event handler payloads
        joined = " ".join(payloads)
        assert "alert" in joined or "onerror" in joined

    def test_payload_waf_evasion_cloudflare(self):
        from app.intelligence.payloads.payload_intel import (
            PayloadIntelligenceSystem, ReflectionContext, WAFSignature
        )
        system = PayloadIntelligenceSystem()
        base = system.select_payloads("xss", ReflectionContext.HTML_TEXT, WAFSignature.NONE)
        with_waf = system.select_payloads("xss", ReflectionContext.HTML_TEXT, WAFSignature.CLOUDFLARE)
        # WAF evasion payloads should differ from base
        assert with_waf != base or len(with_waf) > 0

    def test_waf_detection_cloudflare(self):
        from app.intelligence.payloads.payload_intel import PayloadIntelligenceSystem, WAFSignature
        system = PayloadIntelligenceSystem()
        sig = system.detect_waf({"headers": {"cf-ray": "abc123"}, "body": "", "status_code": 200})
        assert sig == WAFSignature.CLOUDFLARE

    def test_js_reverse_secret_extraction(self):
        from app.intelligence.js_ast.js_reverse import JSReverseEngineer
        eng = JSReverseEngineer()
        # AKIA + exactly 16 uppercase alphanumeric chars (no placeholder words)
        secrets = eng._extract_secrets('const awsKey = "AKIAQM7YCA2FTZTEST12";', "app.js")
        assert any(s.secret_type == "AWS_ACCESS_KEY" for s in secrets)

    def test_js_dom_xss_detection(self):
        from app.intelligence.js_ast.js_reverse import JSReverseEngineer
        eng = JSReverseEngineer()
        code = """
        var q = location.search;
        document.getElementById('result').innerHTML = q;
        """
        risks = eng._analyze_dom_xss(code)
        assert len(risks) > 0
        assert any(r["sink"] == "innerHTML" for r in risks)

    def test_exploitability_ssrf_high_impact(self):
        from app.intelligence.simulator.exploitability import ExploitabilitySimulator
        sim = ExploitabilitySimulator()
        report = sim.simulate({"id": "v1", "vuln_type": "ssrf", "severity": "critical", "url": "https://api.example.com/fetch"})
        assert report.cloud_compromise_potential >= 0.9
        assert report.lateral_movement_potential >= 0.8

    def test_vault_encrypt_decrypt_roundtrip(self):
        from app.vault.vault import SecretsVault
        vault = SecretsVault(master_key="unit-test-master-key-secure")
        sid = vault.store("db_cred", "postgres://admin:pass@db:5432/prod", "credential", "ws-1")
        assert vault.retrieve(sid, "ws-1") == "postgres://admin:pass@db:5432/prod"

    def test_vault_key_rotation(self):
        from app.vault.vault import SecretsVault
        vault = SecretsVault(master_key="old-master-key-for-testing-only")
        sid = vault.store("token", "my-secret-token-value", "api_key", "ws-1")
        rotated = vault.rotate_key("new-master-key-for-testing-only")
        assert rotated == 1
        assert vault.retrieve(sid, "ws-1") == "my-secret-token-value"

    def test_workspace_memory_priority_matrix(self):
        from app.intelligence.memory.workspace_memory import WorkspaceMemory
        mem = WorkspaceMemory(workspace_id="ws-test")
        # Simulate history: XSS succeeds 4x, SQLi rejected 3x
        for _ in range(4):
            mem.record_finding("xss", confirmed=True)
        for _ in range(3):
            mem.record_finding("sqli", confirmed=False)
        matrix = mem.scan_priority_matrix()
        assert matrix["xss"] > matrix["sqli"]

    def test_attack_chain_covers_xss_ato(self):
        from app.intelligence.chain.chain_composer import AttackChainComposer
        composer = AttackChainComposer()
        chains = composer.compose_chains(
            vulns=[{"vuln_type": "xss_stored", "severity": "high", "title": "Stored XSS", "url": "https://app.com/bio"}],
            subdomains=[],
            js_findings=[],
        )
        titles = [c.title for c in chains]
        assert any("XSS" in t for t in titles)

    def test_monitoring_alert_on_new_subdomain(self):
        import asyncio
        from app.monitoring.continuous_monitor import (
            ContinuousMonitorAgent, MonitoringSnapshot
        )
        agent = ContinuousMonitorAgent(workspace_id="ws-test")
        prev = MonitoringSnapshot(target="example.com", workspace_id="ws-test")
        prev.subdomains = {"api.example.com", "www.example.com"}
        curr = MonitoringSnapshot(target="example.com", workspace_id="ws-test")
        curr.subdomains = {"api.example.com", "www.example.com", "staging.example.com"}

        alerts = asyncio.run(agent.compare_snapshots(curr, prev))
        new_sub_alerts = [a for a in alerts if a.alert_type == "new_subdomain"]
        assert len(new_sub_alerts) == 1
        assert "staging.example.com" in new_sub_alerts[0].new_value

    def test_monitoring_alert_on_removed_subdomain(self):
        import asyncio
        from app.monitoring.continuous_monitor import (
            ContinuousMonitorAgent, MonitoringSnapshot
        )
        agent = ContinuousMonitorAgent(workspace_id="ws-test")
        prev = MonitoringSnapshot(target="example.com", workspace_id="ws-test")
        prev.subdomains = {"api.example.com", "old-app.example.com"}
        curr = MonitoringSnapshot(target="example.com", workspace_id="ws-test")
        curr.subdomains = {"api.example.com"}

        alerts = asyncio.run(agent.compare_snapshots(curr, prev))
        removed = [a for a in alerts if a.alert_type == "subdomain_removed"]
        assert len(removed) == 1
        assert "old-app.example.com" in removed[0].old_value

    def test_scope_check_in_scope(self):
        from app.intelligence.court.validation_court import ValidationCourt
        court = ValidationCourt()
        result = court._scope_check(
            {"url": "https://api.target.com/users"},
            {"in_scope": ["api.target.com"], "out_of_scope": []}
        )
        assert result["in_scope"] is True

    def test_scope_check_out_of_scope(self):
        from app.intelligence.court.validation_court import ValidationCourt
        court = ValidationCourt()
        result = court._scope_check(
            {"url": "https://partner.other.com/admin"},
            {"in_scope": ["target.com"], "out_of_scope": ["partner.other.com"]}
        )
        assert result["in_scope"] is False

    def test_evidence_check_strong(self):
        from app.intelligence.court.validation_court import ValidationCourt
        court = ValidationCourt()
        result = court._evidence_check({
            "description": "Attacker can inject JavaScript into the bio field that executes in other users browsers.",
            "url": "https://app.target.com/profile",
            "payload": "<script>alert(document.cookie)</script>",
            "reproduction_steps": "1. Log in 2. Set bio to payload 3. View as victim",
            "evidence": "Screenshot showing alert box with session cookie",
            "remediation": "Encode user input using htmlspecialchars() before rendering",
            "cvss_score": 8.8,
            "cwe_id": "CWE-79",
        })
        assert result["quality_score"] >= 0.8
        assert result["should_downgrade"] is False

    def test_evidence_check_insufficient(self):
        from app.intelligence.court.validation_court import ValidationCourt
        court = ValidationCourt()
        result = court._evidence_check({"description": "XSS"})
        assert result["quality_score"] < 0.4
        assert result["should_downgrade"] is True


class TestPhase10AVROSModules:
    """Phase 10 — AVROS module import and basic function tests."""

    def test_agent_bus_import(self):
        from app.orchestrator.agent_bus import AgentBus, EventType, AgentEvent, bus
        assert isinstance(bus, AgentBus)
        assert EventType.VULN_CONFIRMED

    def test_task_graph_import(self):
        from app.orchestrator.task_graph import TaskGraph, Task, TaskStatus, RiskTier
        g = TaskGraph("scan-1", "ws-1")
        t = g.create_task("test_task", "recon", priority=1)
        assert t.status == TaskStatus.PENDING
        assert len(g) == 1

    def test_policies_import(self):
        from app.orchestrator.policies import (
            ScopePolicy, RateLimitPolicy, ApprovalPolicy,
            EmergencyStopPolicy, PolicyEngine
        )
        engine = PolicyEngine()
        assert engine.scope is not None
        assert engine.rate_limit is not None

    def test_orchestrator_import(self):
        from app.orchestrator.orchestrator import (
            Orchestrator, create_orchestrator, get_orchestrator, list_orchestrators
        )
        orch = Orchestrator("test-scan", "test-ws")
        assert orch.scan_id == "test-scan"

    def test_orchestrator_plan_scan(self):
        from app.orchestrator.orchestrator import Orchestrator
        orch = Orchestrator("test-scan-2", "test-ws-2")
        graph = orch.plan_scan({"domain": "example.com", "scan_type": "recon"})
        assert len(graph) >= 3  # recon + probe + js + api + report

    def test_browser_session_manager_import(self):
        from app.browser.session_manager import SessionManager, BrowserSession, PLAYWRIGHT_AVAILABLE
        sm = SessionManager()
        status = sm.capability_status
        assert "playwright_available" in status
        assert isinstance(status["playwright_available"], bool)

    def test_spa_mapper_import(self):
        from app.browser.spa_mapper import extract_routes_from_js, SPARoute
        js = "path: '/dashboard', path: '/api/users/:id', href='/settings'"
        routes = extract_routes_from_js(js)
        assert len(routes) >= 2
        paths = [r.path for r in routes]
        assert "/dashboard" in paths

    def test_ws_capture_import(self):
        from app.browser.ws_capture import WSCapture, WSFrame, PLAYWRIGHT_AVAILABLE
        cap = WSCapture(url="ws://test")
        assert cap.to_dict()["frame_count"] == 0

    def test_dom_monitor_import(self):
        from app.browser.dom_monitor import DOMSnapshot, _find_dom_xss_sinks
        # Test with two clearly separated sinks
        sinks = _find_dom_xss_sinks("<div></div>\nvar a = 1;\nel.innerHTML = userInput;\n// 50 chars of code here to separate\nvar b = 2;\neval(data);")
        assert len(sinks) >= 1  # at least innerHTML or eval detected

    def test_object_mapper_import(self):
        from app.api_intel.object_mapper import (
            ObjectMapper, extract_ids_from_url, extract_ids_from_json
        )
        ids = extract_ids_from_url("/api/users/123/orders/456")
        assert "123" in ids and "456" in ids
        obj_ids = extract_ids_from_json({"user_id": "abc", "name": "test"})
        assert ("user_id", "abc") in obj_ids

    def test_object_mapper_idor_candidates(self):
        from app.api_intel.object_mapper import ObjectMapper
        mapper = ObjectMapper()
        mapper.observe_request("GET", "/api/users/100",
                               {"id": "100", "user_id": "100", "email": "a@b.com"})
        mapper.observe_request("GET", "/api/users/101",
                               {"id": "101", "user_id": "101", "email": "c@d.com"})
        candidates = mapper.generate_idor_candidates()
        assert len(candidates) >= 1

    def test_role_diff_import(self):
        from app.api_intel.role_diff import (
            RoleCredential, RoleDiffResult, diff_roles, summarize_diff_results
        )
        r = RoleCredential("admin", token="tok1")
        assert r.auth_headers["Authorization"] == "Bearer tok1"

    def test_graphql_analyzer_import(self):
        from app.api_intel.graphql_analyzer import (
            GQLFinding, GQLSchema, analyze_graphql, HTTPX_AVAILABLE
        )
        schema = GQLSchema(query_fields=["users", "me"])
        assert schema.to_dict()["query_fields"] == ["users", "me"]

    def test_openapi_analyzer_import(self):
        from app.api_intel.openapi_analyzer import analyze_openapi_spec, OpenAPIFinding
        spec = {
            "openapi": "3.0.0",
            "paths": {
                "/admin/users": {
                    "delete": {"operationId": "deleteUser", "responses": {"200": {}}}
                }
            }
        }
        result = analyze_openapi_spec(spec)
        assert result["finding_count"] >= 1
        assert any(f["finding_type"] == "no_auth" for f in result["findings"])

    def test_workflow_replay_import(self):
        from app.api_intel.workflow_replay import WorkflowStep, replay_workflow
        step = WorkflowStep("GET", "http://example.com")
        assert step.method == "GET"

    def test_graph_reasoner_import(self):
        from app.chain.graph_reasoner import GraphReasoner, AttackChain, ChainNode
        reasoner = GraphReasoner()
        vulns = [
            {"id": "v1", "vuln_type": "xss", "severity": "high",
             "url": "http://t.com/search", "title": "Reflected XSS"},
            {"id": "v2", "vuln_type": "idor", "severity": "high",
             "url": "http://t.com/api/users/1", "title": "IDOR"},
        ]
        chains = reasoner.build_chains(vulns)
        assert len(chains) >= 1
        assert chains[0].chain_probability > 0

    def test_chain_ranker_import(self):
        from app.chain.chain_ranker import rank_chains, analyze_proof_gaps, ProofGap
        chains = [
            {"chain_id": "c1", "chain_probability": 0.7, "final_impact": "account_takeover",
             "severity": "critical", "evidence_quality": 0.6, "nodes": [], "missing_links": []},
            {"chain_id": "c2", "chain_probability": 0.3, "final_impact": "data_exfil",
             "severity": "high", "evidence_quality": 0.4, "nodes": [], "missing_links": []},
        ]
        ranked = rank_chains(chains)
        assert ranked[0]["rank"] == 1
        assert ranked[0]["composite_score"] >= ranked[1]["composite_score"]

    def test_chain_reporter_import(self):
        from app.chain.chain_reporter import chain_to_hackerone_report, chain_to_executive_summary
        chain = {"title": "XSS → ATO", "nodes": [{"vuln_type": "xss", "url": "/search",
                 "title": "XSS"}], "final_impact": "account_takeover",
                 "chain_probability": 0.65, "estimated_bounty": "$3,000",
                 "next_steps": ["Test it"]}
        report = chain_to_hackerone_report(chain)
        assert "XSS → ATO" in report
        assert "account_takeover" in report.lower() or "Account Takeover" in report

    def test_http_replay_import(self):
        from app.replay.http_replay import (
            ReplayRequest, ReplayResponse, parse_har, export_har,
            diff_responses, build_timeline
        )
        req = ReplayRequest(method="GET", url="http://example.com")
        assert req.to_curl().startswith("curl -X GET")
        # Test mutation
        req2 = req.mutate({"example.com": "evil.com"})
        assert "evil.com" in req2.url

    def test_har_parse(self):
        from app.replay.http_replay import parse_har
        har = {"log": {"entries": [
            {"startedDateTime": "2024-01-01T00:00:00Z",
             "request": {"method": "GET", "url": "http://example.com/api",
                        "headers": [{"name": "Auth", "value": "Bearer tok"}],
                        "postData": None}}
        ]}}
        reqs = parse_har(har)
        assert len(reqs) == 1
        assert reqs[0].method == "GET"
        assert reqs[0].url == "http://example.com/api"

    def test_strategic_memory_import(self):
        from app.memory.strategic_memory import (
            StrategicMemory, ProgramProfile, FindingFeedback, get_memory
        )
        mem = get_memory("test-ws-123")
        mem.record_technology("example.com", ["nginx", "react", "node"])
        assert "nginx" in mem.get_known_technologies("example.com")

    def test_program_profile_scope(self):
        from app.memory.strategic_memory import ProgramProfile
        profile = ProgramProfile(
            in_scope=["*.example.com", "api.example.com"],
            out_of_scope=["admin.example.com"],
        )
        assert profile.is_in_scope("app.example.com") is True
        assert profile.is_in_scope("admin.example.com") is False
        assert profile.is_in_scope("evil.com") is False

    def test_feedback_rejection_patterns(self):
        from app.memory.strategic_memory import get_memory, FindingFeedback
        mem = get_memory("test-ws-feedback")
        mem.record_feedback(FindingFeedback("f1", "self_xss", "low", "rejected",
                                            reason="self-xss not in scope"))
        mem.record_feedback(FindingFeedback("f2", "self_xss", "low", "rejected",
                                            reason="not reproducible"))
        patterns = mem.get_rejection_patterns()
        assert patterns[0]["vuln_type"] == "self_xss"
        assert patterns[0]["rejection_count"] == 2

    def test_control_plane_import(self):
        from app.execution.control_plane import (
            ControlPlane, CheckpointStore, RetryPolicy,
            HeartbeatMonitor, ScanCheckpoint,
            checkpoint_store, heartbeat_monitor, control_plane
        )
        assert isinstance(control_plane, ControlPlane)
        assert isinstance(checkpoint_store, CheckpointStore)
        assert isinstance(heartbeat_monitor, HeartbeatMonitor)

    def test_checkpoint_save_load(self):
        from app.execution.control_plane import CheckpointStore, ScanCheckpoint
        store = CheckpointStore()
        cp = ScanCheckpoint(scan_id="test-scan", phase="recon", progress=40,
                            completed_task_ids=["t1", "t2"])
        store.save(cp)
        loaded = store.load_latest("test-scan")
        assert loaded is not None
        assert loaded.progress == 40
        assert loaded.phase == "recon"

    def test_retry_policy(self):
        from app.execution.control_plane import RetryPolicy, get_retry_policy
        policy = RetryPolicy(max_retries=3, base_delay_s=1.0)
        assert policy.should_retry(0) is True
        assert policy.should_retry(2) is True
        assert policy.should_retry(3) is False
        delay = policy.delay_for(0)
        assert delay >= 0.5  # jitter can reduce by 50%
        delay2 = policy.delay_for(2)
        assert delay2 > delay  # exponential growth

    def test_worker_heartbeat(self):
        from app.execution.control_plane import HeartbeatMonitor
        monitor = HeartbeatMonitor(timeout_s=30)
        monitor.register("worker-1", "host-a")
        monitor.beat("worker-1", current_scan="scan-1")
        alive = monitor.get_alive_workers()
        assert len(alive) == 1
        assert alive[0].worker_id == "worker-1"

    def test_emergency_stop(self):
        from app.execution.control_plane import ControlPlane
        cp = ControlPlane()
        cp.emergency_stop_all()
        assert cp.is_stopped("any-scan-id") is True
        cp.resume_all()
        assert cp.is_stopped("any-scan-id") is False

    def test_phase10_routes_registered(self):
        from app.main import app
        paths = [r.path for r in app.routes if hasattr(r, 'path')]
        avros_prefixes = [
            "/api/v1/orchestrator",
            "/api/v1/browser-intel",
            "/api/v1/api-intel",
            "/api/v1/chains",
            "/api/v1/replay",
            "/api/v1/memory",
            "/api/v1/workers",
        ]
        for prefix in avros_prefixes:
            matching = [p for p in paths if p.startswith(prefix)]
            assert len(matching) >= 1, f"No routes found for prefix {prefix}"


class TestPhase11LaunchHardening:
    """Phase 11 — Demo mode, operator workflows, launch hardening."""

    def test_demo_route_registered(self):
        """Demo router must be registered under /api/v1/demo."""
        from app.main import app
        paths = [r.path for r in app.routes if hasattr(r, 'path')]
        demo_routes = [p for p in paths if p.startswith("/api/v1/demo")]
        assert len(demo_routes) >= 3, f"Expected ≥3 demo routes, got {len(demo_routes)}: {demo_routes}"

    def test_demo_report_structure(self):
        """Prebuilt demo report has required fields."""
        from app.api.routes.demo import DEMO_REPORT
        assert "title" in DEMO_REPORT
        assert "severity_counts" in DEMO_REPORT
        assert "findings" in DEMO_REPORT
        assert len(DEMO_REPORT["findings"]) >= 3
        assert DEMO_REPORT["risk_score"] > 0

    def test_demo_chain_structure(self):
        """Prebuilt demo chain has required fields."""
        from app.api.routes.demo import DEMO_CHAIN
        assert "chain_id" in DEMO_CHAIN
        assert "title" in DEMO_CHAIN
        assert "nodes" in DEMO_CHAIN
        assert len(DEMO_CHAIN["nodes"]) >= 1
        assert "chain_probability" in DEMO_CHAIN
        assert DEMO_CHAIN["chain_probability"] > 0
        assert "estimated_bounty" in DEMO_CHAIN

    def test_demo_verdict_structure(self):
        """Prebuilt demo verdict has required fields."""
        from app.api.routes.demo import DEMO_VERDICT
        assert "verdict" in DEMO_VERDICT
        assert DEMO_VERDICT["verdict"] in ("CONFIRMED", "REJECTED", "UNCONFIRMED")
        assert "confidence" in DEMO_VERDICT
        assert 0 <= DEMO_VERDICT["confidence"] <= 1
        assert "reasoning" in DEMO_VERDICT

    def test_demo_endpoints_require_auth(self, client):
        """Demo endpoints must require authentication."""
        for path in ["/api/v1/demo/status", "/api/v1/demo/report",
                     "/api/v1/demo/chain", "/api/v1/demo/verdict"]:
            r = client.get(path)
            assert r.status_code in (401, 403, 422), \
                f"{path} should require auth, got {r.status_code}"

    def test_demo_reset_endpoint_exists(self, client):
        """Demo reset endpoint must exist (even if requires auth)."""
        r = client.post("/api/v1/demo/reset")
        assert r.status_code in (401, 403, 422), \
            f"Reset should require auth, got {r.status_code}"

    def test_all_docs_exist(self):
        """Required documentation files must exist and be non-empty."""
        import os
        docs = [
            "QUICKSTART.md",
            "DEMO_GUIDE.md",
            "OPERATOR_MANUAL.md",
            "TROUBLESHOOTING.md",
            "SECURITY_MODEL.md",
            "RELEASE_CHECKLIST.md",
            "PHASE10_AVROS_COMPLETION.md",
        ]
        _f = os.path.abspath(__file__)
        root = os.path.dirname(_f)
        for _ in range(5):
            root = os.path.dirname(root)
            if os.path.exists(os.path.join(root, "docker-compose.yml")):
                break
        if not os.path.exists(os.path.join(root, "docker-compose.yml")):
            return  # Not in repo context (container) — skip
        for doc in docs:
            path = os.path.join(root, doc)
            assert os.path.exists(path), f"Missing: {doc}"
            size = os.path.getsize(path)
            assert size > 200, f"{doc} too small ({size} bytes)"

    def test_scripts_exist_and_executable(self):
        """Required scripts must exist."""
        import os, stat
        scripts = [
            "scripts/install_local.sh",
            "scripts/demo_run.sh",
            "scripts/run_e2e_testlab.sh",
            "scripts/verify_full_stack.sh",
            "scripts/backup.sh",
        ]
        _f = os.path.abspath(__file__)
        root = os.path.dirname(_f)
        for _ in range(5):
            root = os.path.dirname(root)
            if os.path.exists(os.path.join(root, "docker-compose.yml")):
                break
        if not os.path.exists(os.path.join(root, "docker-compose.yml")):
            return  # Not in repo context (container) — skip
        for script in scripts:
            path = os.path.join(root, script)
            assert os.path.exists(path), f"Missing script: {script}"
            st = os.stat(path)
            assert st.st_size > 100, f"{script} is too small ({st.st_size} bytes)"

    def test_release_checklist_has_known_limitations(self):
        """Release checklist must document known limitations."""
        import os
        _f = os.path.abspath(__file__)
        root = os.path.dirname(os.path.dirname(_f))
        if not any(os.path.exists(os.path.join(root, f)) for f in ["SECURITY_MODEL.md", ".env.example", "README.md", "docker-compose.yml"]):
            root = os.path.dirname(root)
        _fp = os.path.join(root, "RELEASE_CHECKLIST.md")
        if not os.path.exists(_fp):
            return  # File not found in container — skip
        content = open(_fp).read()
        assert "Known Limitations" in content
        assert "Orchestrator" in content
        assert "Playwright" in content

    def test_security_model_has_scope_policy(self):
        """Security model must document scope enforcement."""
        import os
        _f = os.path.abspath(__file__)
        root = os.path.dirname(_f)
        sm = None
        for _ in range(5):
            root = os.path.dirname(root)
            candidate = os.path.join(root, "SECURITY_MODEL.md")
            if os.path.exists(candidate):
                sm = candidate
                break
        if sm is None:
            return  # File not found in container — skip
        content = open(sm).read()
        assert "ScopePolicy" in content or "Scope Policy" in content
        assert "EmergencyStop" in content or "Emergency Stop" in content
        assert "Risk Tier" in content or "risk tier" in content.lower()

    def test_env_example_exists_and_safe(self):
        """env.example must exist and not contain real secrets."""
        import os
        _f = os.path.abspath(__file__)
        root = os.path.dirname(_f)
        path = None
        for _ in range(5):
            root = os.path.dirname(root)
            candidate = os.path.join(root, ".env.example")
            if os.path.exists(candidate):
                path = candidate
                break
        if path is None:
            return  # File not found in container — skip
        path = path
        assert os.path.exists(path), ".env.example missing"
        content = open(path).read()
        # Must not contain real API keys (starts with real sk-ant prefix + real key)
        import re
        real_key = re.search(r'sk-ant-api03-[A-Za-z0-9_-]{20,}', content)
        assert not real_key, f".env.example contains what looks like a real API key"

    def test_demo_module_importable(self):
        """Demo module imports without errors."""
        from app.api.routes.demo import router, DEMO_REPORT, DEMO_CHAIN, DEMO_VERDICT
        assert router is not None
        assert isinstance(DEMO_REPORT, dict)
        assert isinstance(DEMO_CHAIN, dict)
        assert isinstance(DEMO_VERDICT, dict)

    def test_total_route_count(self):
        """Ensure Phase 11 demo routes are registered (total ≥80)."""
        from app.main import app
        total = len([r for r in app.routes if hasattr(r, 'path')])
        assert total >= 80, f"Expected ≥80 routes after Phase 11, got {total}"
