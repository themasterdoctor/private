"""
UI Button Action Tests
Verifies every frontend button/form action works by testing
the exact API calls those buttons make.

These are INTEGRATION tests that require a running backend.
Run with:
  BACKEND_URL=http://localhost:8000 pytest tests/test_ui_actions.py -v

Or run against TestClient (no live server needed) — routes that don't
touch the DB are tested here, DB-dependent actions are in verify_ui_actions.sh
"""
import pytest
import os
import random
import requests
from fastapi.testclient import TestClient

BACKEND_URL = os.environ.get("BACKEND_URL", "")


# ── Helpers ───────────────────────────────────────────────────────────────────

def get_client():
    """Return either a live requests session or TestClient depending on env."""
    if BACKEND_URL:
        s = requests.Session()
        s.base_url = BACKEND_URL
        return s, BACKEND_URL
    from app.main import app
    client = TestClient(app, raise_server_exceptions=False)
    return client, ""


# ── Route-level tests (no DB required, use TestClient) ────────────────────────

@pytest.fixture(scope="session")
def app_client():
    from app.main import app
    return TestClient(app, raise_server_exceptions=False)


class TestLoginPageRoutes:
    """Test that the login route exists and validates correctly."""

    def test_login_route_exists(self, app_client):
        """POST /auth/login exists — not 404."""
        r = app_client.post("/api/v1/auth/login", data={})
        assert r.status_code != 404, "Login route missing"

    def test_login_requires_credentials(self, app_client):
        """Empty login body returns 422 validation error, not 500."""
        r = app_client.post("/api/v1/auth/login", data={})
        assert r.status_code == 422

    def test_wrong_password_returns_401(self, app_client):
        """Wrong credentials return 401, not 500."""
        r = app_client.post("/api/v1/auth/login", data={
            "username": "notreal@example.com",
            "password": "wrongpassword"
        })
        assert r.status_code == 401

    def test_unauthenticated_workspaces_returns_401(self, app_client):
        """Any protected route without token → 401 (not 500)."""
        r = app_client.get("/api/v1/workspaces")
        assert r.status_code == 401

    def test_unauthenticated_scans_returns_401(self, app_client):
        r = app_client.get("/api/v1/scans")
        assert r.status_code in (401, 422)

    def test_unauthenticated_vulns_returns_401(self, app_client):
        r = app_client.get("/api/v1/vulns")
        assert r.status_code in (401, 422)


class TestAPIRoutePresence:
    """Every button's API endpoint must exist (not 404)."""

    def test_scan_create_route_exists(self, app_client):
        r = app_client.post("/api/v1/scans", json={})
        assert r.status_code != 404

    def test_vulns_list_route_exists(self, app_client):
        r = app_client.get("/api/v1/vulns")
        assert r.status_code != 404

    def test_reports_generate_route_exists(self, app_client):
        r = app_client.post("/api/v1/reports/generate/fake-id", json={})
        assert r.status_code != 404

    def test_intel_hypotheses_route_exists(self, app_client):
        r = app_client.post("/api/v1/intel/hypotheses/generate/fake-id")
        assert r.status_code != 404

    def test_intel_court_route_exists(self, app_client):
        r = app_client.post("/api/v1/intel/court/adjudicate/fake-id")
        assert r.status_code != 404

    def test_intel_simulate_route_exists(self, app_client):
        r = app_client.post("/api/v1/intel/simulate/fake-id")
        assert r.status_code != 404

    def test_demo_reset_route_exists(self, app_client):
        r = app_client.post("/api/v1/demo/reset")
        assert r.status_code != 404

    def test_demo_status_route_exists(self, app_client):
        r = app_client.get("/api/v1/demo/status")
        assert r.status_code != 404

    def test_demo_report_route_exists(self, app_client):
        r = app_client.get("/api/v1/demo/report")
        assert r.status_code != 404

    def test_workers_emergency_stop_route_exists(self, app_client):
        r = app_client.post("/api/v1/workers/emergency-stop")
        assert r.status_code != 404

    def test_workers_resume_all_route_exists(self, app_client):
        r = app_client.post("/api/v1/workers/resume-all")
        assert r.status_code != 404

    def test_orchestrator_start_route_exists(self, app_client):
        r = app_client.post("/api/v1/orchestrator/start/fake-id")
        assert r.status_code != 404

    def test_chains_build_route_exists(self, app_client):
        r = app_client.post("/api/v1/chains/build-from-vulns", json=[])
        assert r.status_code != 404

    def test_browser_intel_status_route_exists(self, app_client):
        r = app_client.get("/api/v1/browser-intel/status")
        assert r.status_code != 404

    def test_api_intel_observe_route_exists(self, app_client):
        r = app_client.post("/api/v1/api-intel/observe", json={})
        assert r.status_code != 404

    def test_replay_route_exists(self, app_client):
        r = app_client.post("/api/v1/replay/replay", params={"method": "GET", "url": "http://x"})
        assert r.status_code != 404

    def test_memory_route_exists(self, app_client):
        r = app_client.get("/api/v1/memory/fake-ws")
        assert r.status_code != 404

    def test_apikeys_create_route_exists(self, app_client):
        r = app_client.post("/api/v1/apikeys", json={})
        assert r.status_code != 404

    def test_monitor_start_route_exists(self, app_client):
        r = app_client.post("/api/v1/intel/monitor/start", json={})
        assert r.status_code != 404

    def test_copilot_sessions_route_exists(self, app_client):
        r = app_client.get("/api/v1/copilot/sessions")
        assert r.status_code != 404

    def test_workspaces_create_route_exists(self, app_client):
        r = app_client.post("/api/v1/workspaces", json={})
        assert r.status_code != 404


class TestScanAPIContract:
    """Scan create validates the correct payload shape."""

    def test_scan_create_requires_name_not_target(self, app_client):
        """Backend requires 'name' field — not 'target'. Sending only target returns 422."""
        r = app_client.post("/api/v1/scans",
            headers={"Authorization": "Bearer fake"},
            json={"workspace_id": "ws-1", "target": "example.com"})
        # 401 (auth) or 422 (validation) — but NOT 200/201 with wrong payload
        assert r.status_code in (401, 422)

    def test_scan_create_accepts_name_field(self, app_client):
        """Correct payload with 'name' field is accepted (auth is separate concern)."""
        r = app_client.post("/api/v1/scans",
            headers={"Authorization": "Bearer fake"},
            json={"workspace_id": "ws-1", "name": "Test Scan", "scan_type": "recon",
                  "config": {"domain": "localhost"}})
        # 401 (bad token) is fine — means validation passed
        assert r.status_code in (401, 403, 422)
        # Must NOT be 422 (validation error) — that would mean 'name' is rejected
        if r.status_code == 422:
            detail = r.json().get("detail", "")
            assert "name" not in str(detail), f"'name' field rejected: {detail}"


class TestAPIKeyContract:
    """API key endpoints have correct field names."""

    def test_apikeys_endpoint_requires_auth(self, app_client):
        """POST /apikeys without token → 401, not 404 or 500."""
        r = app_client.post("/api/v1/apikeys", json={"name": "test"})
        assert r.status_code in (401, 403)

    def test_apikeys_list_requires_auth(self, app_client):
        r = app_client.get("/api/v1/apikeys")
        assert r.status_code in (401, 403)

    def test_apikeys_revoke_requires_auth(self, app_client):
        r = app_client.delete("/api/v1/apikeys/fake-id")
        assert r.status_code in (401, 403)


class TestVulnStatusContract:
    """VulnStatus enum includes all values the frontend sends."""

    def test_vuln_update_endpoint_exists(self, app_client):
        """PATCH /vulns/:id exists."""
        r = app_client.patch("/api/v1/vulns/fake-id", json={"status": "open"})
        assert r.status_code not in (404, 405)

    def test_vuln_status_values_are_valid(self):
        """VulnStatus enum includes in_progress, resolved, wont_fix (were missing → 500)."""
        from app.models.models import VulnStatus
        required = ["open", "in_progress", "resolved", "wont_fix", "false_positive"]
        enum_values = [v.value for v in VulnStatus]
        for val in required:
            assert val in enum_values, f"VulnStatus missing '{val}' — frontend status dropdown will 500"


class TestScanListResponseFields:
    """Scan list response must include fields the dashboard needs."""

    def test_scan_schema_has_target_field(self):
        """ScanListOut must have target field for dashboard display."""
        from app.schemas.scans import ScanListOut
        fields = ScanListOut.model_fields
        assert "target" in fields, "ScanListOut missing 'target' field — dashboard shows blank"

    def test_scan_schema_has_subdomain_count(self):
        from app.schemas.scans import ScanListOut
        assert "subdomain_count" in ScanListOut.model_fields

    def test_scan_schema_has_vuln_count(self):
        from app.schemas.scans import ScanListOut
        assert "vuln_count" in ScanListOut.model_fields


class TestAPIKeySchema:
    """API key response must use key_prefix not prefix."""

    def test_apikey_response_has_key_prefix_field(self):
        """APIKeyOut must use key_prefix (not prefix) — frontend reads key_prefix."""
        from app.api.routes.apikeys import APIKeyOut
        fields = APIKeyOut.model_fields
        assert "key_prefix" in fields, "APIKeyOut missing key_prefix — settings page shows empty"
        assert "prefix" not in fields, "APIKeyOut has old 'prefix' field — should be key_prefix"

    def test_apikey_created_has_raw_key_with_default(self):
        """APIKeyCreated.raw_key must have a default value (was causing 500)."""
        from app.api.routes.apikeys import APIKeyCreated
        field = APIKeyCreated.model_fields.get("raw_key")
        assert field is not None
        # Should have a default (not required)
        assert not field.is_required(), "raw_key is required — will cause 500 on model_validate"

    def test_apikey_prefix_length_constraint(self):
        """Prefix must be ≤ 10 chars to fit String(10) column."""
        from app.core.security import generate_api_key
        raw, _ = generate_api_key()
        prefix = raw[:10]
        assert len(prefix) <= 10, f"prefix '{prefix}' exceeds String(10) column"


class TestLoginEndpointPath:
    """Login must call /auth/login not /auth/token."""

    def test_auth_login_path_exists(self, app_client):
        """POST /auth/login must exist — was /auth/token before fix."""
        r = app_client.post("/api/v1/auth/login", data={
            "username": "test@test.com", "password": "test"
        })
        assert r.status_code != 404, "/auth/login route not found — was it renamed to /auth/token?"
        assert r.status_code != 405, "Method not allowed on /auth/login"

    def test_auth_token_path_does_not_exist(self, app_client):
        """POST /auth/token must NOT exist — frontend was calling the wrong path."""
        r = app_client.post("/api/v1/auth/token", data={
            "username": "test@test.com", "password": "test"
        })
        # Should 404 — this path is wrong
        assert r.status_code == 404, f"/auth/token exists but should not — path is /auth/login"


class TestRateLimitConfig:
    """Rate limit must be high enough for normal usage."""

    def test_rate_limit_is_at_least_300(self):
        """Rate limit default must be ≥ 300 to allow real usage (was 60)."""
        from app.core.config import settings
        assert settings.RATE_LIMIT_PER_MINUTE >= 300, \
            f"Rate limit {settings.RATE_LIMIT_PER_MINUTE} too low — users hit 429 during normal use"


class TestIntelMetricsNotJSON:
    """intel/metrics returns Prometheus text, not JSON — frontend must handle."""

    def test_intel_metrics_returns_text(self, app_client):
        """GET /intel/metrics returns Prometheus text format (not JSON)."""
        r = app_client.get("/api/v1/intel/metrics",
                           headers={"Authorization": "Bearer fake"})
        # With fake token, still checks content type
        ct = r.headers.get("content-type", "")
        # Either 401 (correct — needs auth) or text/plain (metrics)
        assert r.status_code in (200, 401)
        if r.status_code == 200:
            assert "text/" in ct or "text/plain" in ct, \
                f"intel/metrics should return text/plain, got {ct}"
