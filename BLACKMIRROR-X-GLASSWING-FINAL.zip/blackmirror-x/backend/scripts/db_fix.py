#!/usr/bin/env python3
"""
BLACKMIRROR-X Database Schema Fix
Adds all missing columns and tables directly via psycopg2.
Safe to run any number of times (all operations use IF NOT EXISTS / IF EXISTS).
"""
import psycopg2, os, re, sys

url = os.environ.get("DATABASE_URL_SYNC", os.environ.get("DATABASE_URL", ""))
url = re.sub(r"^\w+\+\w+://", "postgresql://", url)

print(f"Connecting to: {re.sub(r':([^@]+)@', ':***@', url)}")
try:
    conn = psycopg2.connect(url)
except Exception as e:
    print(f"ERROR: Cannot connect: {e}")
    sys.exit(1)

conn.autocommit = True
cur = conn.cursor()

# Extensions
for ext in ["vector", "pg_trgm", '"uuid-ossp"']:
    try:
        cur.execute(f"CREATE EXTENSION IF NOT EXISTS {ext}")
        print(f"  ✓ extension {ext}")
    except Exception as e:
        print(f"  ⚠ extension {ext}: {e}")

# Missing columns on vulnerabilities table
for col, sql in [
    ("cvss_vector",         "ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS cvss_vector VARCHAR(100)"),
    ("confidence_score",    "ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS confidence_score FLOAT"),
    ("cvss_score",          "ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS cvss_score FLOAT"),
    ("cwe_id",              "ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS cwe_id VARCHAR(50)"),
    ("cve_id",              "ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS cve_id VARCHAR(50)"),
    ("court_confidence",    "ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS court_confidence FLOAT"),
    ("needs_manual_review", "ALTER TABLE vulnerabilities ADD COLUMN IF NOT EXISTS needs_manual_review BOOLEAN DEFAULT false"),
]:
    try:
        cur.execute(sql)
        print(f"  ✓ vulnerabilities.{col}")
    except Exception as e:
        print(f"  ⚠ vulnerabilities.{col}: {e}")

# Missing tables
tables = {
    "workspace_scope": """
        CREATE TABLE IF NOT EXISTS workspace_scope (
            id UUID DEFAULT uuid_generate_v4() NOT NULL,
            workspace_id UUID NOT NULL UNIQUE,
            include_rules JSON DEFAULT '[]',
            exclude_rules JSON DEFAULT '[]',
            authorization_confirmed BOOLEAN DEFAULT false,
            authorization_token TEXT,
            program_profile JSON,
            created_by UUID,
            created_at TIMESTAMPTZ DEFAULT now(),
            updated_at TIMESTAMPTZ DEFAULT now(),
            PRIMARY KEY (id),
            FOREIGN KEY(workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE
        )""",
    "monitoring_alerts": """
        CREATE TABLE IF NOT EXISTS monitoring_alerts (
            id UUID DEFAULT uuid_generate_v4() NOT NULL,
            workspace_id UUID NOT NULL,
            target VARCHAR(255) NOT NULL,
            alert_type VARCHAR(100) NOT NULL,
            severity VARCHAR(50) DEFAULT 'medium',
            title VARCHAR(500) NOT NULL,
            description TEXT,
            old_value TEXT,
            new_value TEXT,
            acknowledged BOOLEAN DEFAULT false,
            acknowledged_by UUID,
            created_at TIMESTAMPTZ DEFAULT now(),
            PRIMARY KEY (id),
            FOREIGN KEY(workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE
        )""",
    "approval_requests": """
        CREATE TABLE IF NOT EXISTS approval_requests (
            id UUID DEFAULT uuid_generate_v4() NOT NULL,
            workspace_id UUID NOT NULL,
            scan_id UUID,
            action_type VARCHAR(100) NOT NULL,
            action_payload JSON DEFAULT '{}',
            risk_tier VARCHAR(50) DEFAULT 'medium',
            requested_by UUID,
            reviewed_by UUID,
            status VARCHAR(50) DEFAULT 'pending',
            review_note TEXT,
            auto_approved BOOLEAN DEFAULT false,
            created_at TIMESTAMPTZ DEFAULT now(),
            updated_at TIMESTAMPTZ DEFAULT now(),
            PRIMARY KEY (id)
        )""",
    "scan_evidence": """
        CREATE TABLE IF NOT EXISTS scan_evidence (
            id UUID DEFAULT uuid_generate_v4() NOT NULL,
            scan_id UUID NOT NULL,
            vuln_id UUID,
            workspace_id UUID NOT NULL,
            method VARCHAR(10) DEFAULT 'GET',
            url TEXT NOT NULL,
            request_headers JSON DEFAULT '{}',
            request_body TEXT,
            request_cookies JSON DEFAULT '{}',
            response_status INTEGER,
            response_headers JSON DEFAULT '{}',
            response_body TEXT,
            response_time_ms INTEGER DEFAULT 0,
            redirect_chain JSON DEFAULT '[]',
            payload_used TEXT,
            indicator_found TEXT,
            screenshot_b64 TEXT,
            has_screenshot BOOLEAN DEFAULT false,
            confidence_score FLOAT DEFAULT 0.7,
            is_primary BOOLEAN DEFAULT true,
            captured_at TIMESTAMPTZ DEFAULT now(),
            PRIMARY KEY (id)
        )""",
    "team_comments": """
        CREATE TABLE IF NOT EXISTS team_comments (
            id UUID DEFAULT uuid_generate_v4() NOT NULL,
            workspace_id UUID NOT NULL,
            vuln_id UUID,
            scan_id UUID,
            author_id UUID NOT NULL,
            content TEXT NOT NULL,
            comment_type VARCHAR(50) DEFAULT 'note',
            resolved BOOLEAN DEFAULT false,
            created_at TIMESTAMPTZ DEFAULT now(),
            updated_at TIMESTAMPTZ DEFAULT now(),
            PRIMARY KEY (id)
        )""",
}

for table_name, sql in tables.items():
    try:
        cur.execute(sql)
        print(f"  ✓ table {table_name}")
    except Exception as e:
        print(f"  ⚠ table {table_name}: {e}")

# Stamp alembic
try:
    cur.execute("""
        CREATE TABLE IF NOT EXISTS alembic_version (
            version_num VARCHAR(32) NOT NULL,
            CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
        )
    """)
    cur.execute("DELETE FROM alembic_version")
    cur.execute("INSERT INTO alembic_version (version_num) VALUES ('005_add_cvss_vector')")
    print("  ✓ alembic stamped → 005_add_cvss_vector")
except Exception as e:
    print(f"  ⚠ alembic stamp: {e}")

# Verify cvss_vector exists
cur.execute("""
    SELECT column_name FROM information_schema.columns
    WHERE table_name='vulnerabilities' AND column_name='cvss_vector'
""")
if cur.fetchone():
    print("  ✓ VERIFIED: vulnerabilities.cvss_vector EXISTS in database")
else:
    print("  ✗ CRITICAL: cvss_vector still missing!")
    sys.exit(1)

cur.close()
conn.close()
print("\n✓ Database schema is fully up to date")
