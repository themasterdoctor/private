"""Add cvss_vector column to vulnerabilities

Revision ID: 005_add_cvss_vector
Revises: 004_enterprise_features
Create Date: 2026-05-18 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa

revision = "005_add_cvss_vector"
down_revision = "004_enterprise_features"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Add cvss_vector column (safe to run multiple times via try/except)
    conn = op.get_bind()

    # cvss_vector - not in any previous migration
    try:
        op.add_column("vulnerabilities",
            sa.Column("cvss_vector", sa.String(100), nullable=True))
        print("  ✓ Added vulnerabilities.cvss_vector")
    except Exception:
        print("  ⚠ vulnerabilities.cvss_vector already exists (skipping)")

    # confidence_score - added in 004 but verify it's there
    # (some DBs may have had 004 run before the column was in it)
    try:
        # Check if confidence_score column exists
        result = conn.execute(sa.text(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_name='vulnerabilities' AND column_name='confidence_score'"
        ))
        if not result.fetchone():
            op.add_column("vulnerabilities",
                sa.Column("confidence_score", sa.Float, nullable=True))
            print("  ✓ Added vulnerabilities.confidence_score")
        else:
            print("  ✓ vulnerabilities.confidence_score already exists")
    except Exception as e:
        print(f"  ⚠ confidence_score check: {e}")


def downgrade() -> None:
    try:
        op.drop_column("vulnerabilities", "cvss_vector")
    except Exception:
        pass
