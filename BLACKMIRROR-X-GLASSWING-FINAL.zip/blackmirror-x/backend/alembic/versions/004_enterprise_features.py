"""004_enterprise_features — Scope, Evidence, Approvals, Team, Monitoring tables.

Revision ID: 004_enterprise_features
Revises: 003_avros_completion
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "004_enterprise_features"
down_revision = "003_avros_completion"
branch_labels = None
depends_on = None

UUID = postgresql.UUID(as_uuid=False)
JSONB = sa.JSON
now_ = sa.text("now()")
uuid_ = sa.text("uuid_generate_v4()::text")


def upgrade():
    op.execute('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"')

    # ── Scope Configuration ───────────────────────────────────────────────────
    op.create_table("workspace_scope",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("workspace_id", UUID, sa.ForeignKey("workspaces.id", ondelete="CASCADE"),
                  nullable=False, unique=True),
        sa.Column("include_rules", JSONB, server_default=sa.text("'[]'")),
        sa.Column("exclude_rules", JSONB, server_default=sa.text("'[]'")),
        sa.Column("authorization_confirmed", sa.Boolean, server_default=sa.text("false")),
        sa.Column("authorization_token", sa.Text),
        sa.Column("program_profile", JSONB),
        sa.Column("created_by", UUID),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # ── Scope Audit Log ───────────────────────────────────────────────────────
    op.create_table("scope_audit_log",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("workspace_id", UUID, sa.ForeignKey("workspaces.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("user_id", UUID),
        sa.Column("action", sa.String(100), nullable=False),
        sa.Column("target", sa.Text, nullable=False),
        sa.Column("allowed", sa.Boolean, nullable=False),
        sa.Column("reason", sa.Text),
        sa.Column("matching_rule", sa.String(255)),
        sa.Column("ip_address", sa.String(50)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # ── Evidence Records ──────────────────────────────────────────────────────
    op.create_table("evidence_records",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("vuln_id", UUID, sa.ForeignKey("vulnerabilities.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("scan_id", UUID, sa.ForeignKey("scan_jobs.id", ondelete="CASCADE")),
        sa.Column("workspace_id", UUID, sa.ForeignKey("workspaces.id", ondelete="CASCADE")),
        sa.Column("method", sa.String(10), server_default=sa.text("'GET'")),
        sa.Column("url", sa.Text, nullable=False),
        sa.Column("request_headers", JSONB, server_default=sa.text("'{}'")),
        sa.Column("request_body", sa.Text),
        sa.Column("request_cookies", JSONB, server_default=sa.text("'{}'")),
        sa.Column("status_code", sa.Integer),
        sa.Column("response_headers", JSONB, server_default=sa.text("'{}'")),
        sa.Column("response_body", sa.Text),
        sa.Column("response_time_ms", sa.Integer, server_default="0"),
        sa.Column("redirect_chain", JSONB, server_default=sa.text("'[]'")),
        sa.Column("payload_used", sa.Text),
        sa.Column("reflection_context", sa.String(100)),
        sa.Column("indicator_found", sa.Text),
        sa.Column("has_screenshot", sa.Boolean, server_default=sa.text("false")),
        sa.Column("screenshot_url", sa.String(500)),
        sa.Column("evidence_hash", sa.String(32)),
        sa.Column("confidence_score", sa.Float, server_default="0.7"),
        sa.Column("is_primary", sa.Boolean, server_default=sa.text("true")),
        sa.Column("captured_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # ── Approval Requests ──────────────────────────────────────────────────────
    op.create_table("approval_requests",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("workspace_id", UUID, sa.ForeignKey("workspaces.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("scan_id", UUID, sa.ForeignKey("scan_jobs.id", ondelete="SET NULL")),
        sa.Column("requested_by", UUID, sa.ForeignKey("users.id")),
        sa.Column("action_type", sa.String(100), nullable=False),
        sa.Column("risk_tier", sa.String(50), server_default=sa.text("'medium'")),
        sa.Column("title", sa.String(255)),
        sa.Column("description", sa.Text),
        sa.Column("target_url", sa.Text),
        sa.Column("payload", sa.Text),
        sa.Column("expected_behavior", sa.Text),
        sa.Column("potential_impact", sa.Text),
        sa.Column("status", sa.String(50), server_default=sa.text("'pending'")),
        sa.Column("approved_by", UUID),
        sa.Column("approval_reason", sa.Text),
        sa.Column("rejected_by", UUID),
        sa.Column("rejection_reason", sa.Text),
        sa.Column("expires_at", sa.DateTime(timezone=True)),
        sa.Column("resolved_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # ── Finding Comments ───────────────────────────────────────────────────────
    op.create_table("finding_comments",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("vuln_id", UUID, sa.ForeignKey("vulnerabilities.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("workspace_id", UUID, sa.ForeignKey("workspaces.id", ondelete="CASCADE")),
        sa.Column("user_id", UUID, sa.ForeignKey("users.id")),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("comment_type", sa.String(50), server_default=sa.text("'note'")),
        sa.Column("resolved", sa.Boolean, server_default=sa.text("false")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # ── Finding Assignments ────────────────────────────────────────────────────
    op.create_table("finding_assignments",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("vuln_id", UUID, sa.ForeignKey("vulnerabilities.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("workspace_id", UUID, sa.ForeignKey("workspaces.id", ondelete="CASCADE")),
        sa.Column("assigned_to", UUID, sa.ForeignKey("users.id")),
        sa.Column("assigned_by", UUID, sa.ForeignKey("users.id")),
        sa.Column("priority", sa.String(20), server_default=sa.text("'normal'")),
        sa.Column("due_date", sa.DateTime(timezone=True)),
        sa.Column("notes", sa.Text),
        sa.Column("completed", sa.Boolean, server_default=sa.text("false")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # ── SLA Policies ───────────────────────────────────────────────────────────
    op.create_table("sla_policies",
        sa.Column("workspace_id", UUID, primary_key=True),
        sa.Column("name", sa.String(255), server_default=sa.text("'Default SLA'")),
        sa.Column("critical_days", sa.Integer, server_default="1"),
        sa.Column("high_days", sa.Integer, server_default="7"),
        sa.Column("medium_days", sa.Integer, server_default="30"),
        sa.Column("low_days", sa.Integer, server_default="90"),
        sa.Column("info_days", sa.Integer, server_default="180"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # ── Report Approval Workflow ───────────────────────────────────────────────
    op.create_table("report_approvals",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("report_id", UUID, sa.ForeignKey("reports.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("workspace_id", UUID, sa.ForeignKey("workspaces.id", ondelete="CASCADE")),
        sa.Column("status", sa.String(50), server_default=sa.text("'draft'")),
        sa.Column("submitted_by", UUID),
        sa.Column("submitted_at", sa.DateTime(timezone=True)),
        sa.Column("reviewed_by", UUID),
        sa.Column("reviewed_at", sa.DateTime(timezone=True)),
        sa.Column("approval_notes", sa.Text),
        sa.Column("rejection_reason", sa.Text),
        sa.Column("ai_quality_checks", JSONB),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # ── Monitoring Baselines ───────────────────────────────────────────────────
    op.create_table("monitoring_baselines",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("workspace_id", UUID, sa.ForeignKey("workspaces.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("target", sa.String(255), nullable=False),
        sa.Column("baseline_type", sa.String(100), nullable=False),
        sa.Column("baseline_data", JSONB, nullable=False),
        sa.Column("hash", sa.String(64)),
        sa.Column("last_checked_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # ── Monitoring Alerts ─────────────────────────────────────────────────────
    op.create_table("monitoring_alerts",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("workspace_id", UUID, sa.ForeignKey("workspaces.id", ondelete="CASCADE"),
                  nullable=False),
        sa.Column("target", sa.String(255), nullable=False),
        sa.Column("alert_type", sa.String(100), nullable=False),
        sa.Column("severity", sa.String(50), server_default=sa.text("'medium'")),
        sa.Column("title", sa.String(500), nullable=False),
        sa.Column("description", sa.Text),
        sa.Column("old_value", sa.Text),
        sa.Column("new_value", sa.Text),
        sa.Column("acknowledged", sa.Boolean, server_default=sa.text("false")),
        sa.Column("acknowledged_by", UUID),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # Add vulnerability scoring columns
    op.add_column("vulnerabilities",
        sa.Column("confidence_score", sa.Float, nullable=True))
    op.add_column("vulnerabilities",
        sa.Column("exploitability_score", sa.Float, nullable=True))
    op.add_column("vulnerabilities",
        sa.Column("business_impact_score", sa.Float, nullable=True))
    op.add_column("vulnerabilities",
        sa.Column("false_positive_risk", sa.Float, nullable=True))
    op.add_column("vulnerabilities",
        sa.Column("court_confidence", sa.Float, nullable=True))
    op.add_column("vulnerabilities",
        sa.Column("bounty_likelihood", sa.Float, nullable=True))
    op.add_column("vulnerabilities",
        sa.Column("evidence_score", sa.Float, nullable=True))
    op.add_column("vulnerabilities",
        sa.Column("simulation_narrative", sa.Text, nullable=True))
    op.add_column("vulnerabilities",
        sa.Column("reflection_context", sa.Text, nullable=True))
    op.add_column("vulnerabilities",
        sa.Column("duplicate_of", UUID, nullable=True))
    op.add_column("vulnerabilities",
        sa.Column("is_duplicate", sa.Boolean, server_default=sa.text("false")))

    # Indexes
    op.create_index("idx_scope_audit_ws", "scope_audit_log", ["workspace_id"])
    op.create_index("idx_evidence_vuln", "evidence_records", ["vuln_id"])
    op.create_index("idx_approvals_ws", "approval_requests", ["workspace_id", "status"])
    op.create_index("idx_comments_vuln", "finding_comments", ["vuln_id"])
    op.create_index("idx_assignments_vuln", "finding_assignments", ["vuln_id"])
    op.create_index("idx_mon_alerts_ws", "monitoring_alerts", ["workspace_id"])


def downgrade():
    for col in ["confidence_score", "exploitability_score", "business_impact_score",
                "false_positive_risk", "court_confidence", "bounty_likelihood",
                "evidence_score", "simulation_narrative", "reflection_context",
                "duplicate_of", "is_duplicate"]:
        try:
            op.drop_column("vulnerabilities", col)
        except Exception:
            pass

    for table in ["monitoring_alerts", "monitoring_baselines", "report_approvals",
                  "sla_policies", "finding_assignments", "finding_comments",
                  "approval_requests", "evidence_records", "scope_audit_log",
                  "workspace_scope"]:
        op.drop_table(table)
