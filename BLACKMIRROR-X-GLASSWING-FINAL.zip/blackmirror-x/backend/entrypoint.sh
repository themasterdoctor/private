#!/bin/bash
set -e

# ── Wait for PostgreSQL ───────────────────────────────────────────────────────
echo "⏳ Waiting for PostgreSQL..."
until pg_isready \
  -h "${POSTGRES_HOST:-postgres}" \
  -p "${POSTGRES_PORT:-5432}" \
  -U "${POSTGRES_USER:-bmx}" \
  -d "${POSTGRES_DB:-blackmirror}" -q 2>/dev/null; do
  echo "  PostgreSQL not ready, retrying in 3s..."
  sleep 3
done
echo "✅ PostgreSQL ready"

# ── Enable required extensions ────────────────────────────────────────────────
echo "⏳ Enabling PostgreSQL extensions..."
python - << 'PYEOF'
import psycopg2, os, re
url = os.environ.get("DATABASE_URL", "")
url = re.sub(r"^\w+\+\w+://", "postgresql://", url)
conn = psycopg2.connect(url)
conn.autocommit = True
cur = conn.cursor()
for ext in ("vector", "pg_trgm", '"uuid-ossp"'):
    cur.execute(f"CREATE EXTENSION IF NOT EXISTS {ext}")
    print(f"  ✓ extension {ext}")
cur.close()
conn.close()
PYEOF
echo "✅ Extensions enabled"

# ── Run migrations (idempotent) ───────────────────────────────────────────────
echo "⏳ Running database migrations..."

# Strategy: try upgrade head. If tables already exist (DuplicateTable),
# the DB schema is ahead of alembic's tracking — stamp to head and we're done.
# This handles: fresh DB, partially migrated DB, fully migrated DB.

MIGRATION_OUTPUT=$(alembic upgrade head 2>&1)
MIGRATION_EXIT=$?

echo "$MIGRATION_OUTPUT"

if [ $MIGRATION_EXIT -ne 0 ]; then
    if echo "$MIGRATION_OUTPUT" | grep -q "DuplicateTable\|already exists\|duplicate table"; then
        echo "⚠️  Tables already exist — stamping alembic to current head..."
        alembic stamp head
        echo "✅ Alembic stamp complete — migrations already applied"
    else
        echo "❌ Migration failed with unexpected error"
        echo "$MIGRATION_OUTPUT"
        exit 1
    fi
else
    echo "✅ Migrations complete"
fi

# ── Seed demo data ────────────────────────────────────────────────────────────
echo "⏳ Seeding demo data..."
python scripts/seed.py && echo "✅ Seed complete" || echo "  ℹ️  Seed skipped (already seeded or error)"

# ── Start backend ─────────────────────────────────────────────────────────────
echo "🚀 Starting BLACKMIRROR-X backend on :8000"
exec uvicorn app.main:app --host 0.0.0.0 --port 8000
