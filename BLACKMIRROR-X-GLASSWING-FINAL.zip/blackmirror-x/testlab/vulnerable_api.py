"""
BLACKMIRROR-X Test Lab — Intentionally Vulnerable API
LEGAL: Local test target only. Do NOT expose to internet.

Vulnerabilities with REAL evidence patterns:
1. SQL Injection — /search?q=' → MySQL error message
2. Reflected XSS — /search?q=<script> → unencoded reflection
3. IDOR — /api/users/{id}/profile → no auth
4. Open Redirect — /redirect?url=https://evil.com → 302
5. Path Traversal — /file?path=../../etc/passwd → /etc/passwd content
6. SSRF hint — /fetch?url= → fetches internal URLs
7. GraphQL introspection — /graphql
8. CORS wildcard + credentials
9. Missing security headers
10. Info disclosure — /debug → stack trace with config
"""
import json, time, urllib.parse, re
from http.server import BaseHTTPRequestHandler, HTTPServer

USERS = {
    "1": {"id": "1", "email": "admin@testlab.local", "role": "admin",
          "secret": "sk-prod-key-abc123xyz", "ssn": "123-45-6789"},
    "2": {"id": "2", "email": "user@testlab.local",  "role": "user",
          "secret": "session_abc_999", "ssn": "987-65-4321"},
    "3": {"id": "3", "email": "dev@testlab.local",   "role": "developer",
          "secret": "github_pat_abc123", "ssn": "555-44-3333"},
}

PRODUCTS = [
    {"id": 1, "name": "Widget A", "price": 9.99, "category": "tools"},
    {"id": 2, "name": "Widget B", "price": 19.99, "category": "tools"},
    {"id": 3, "name": "Gadget X", "price": 99.99, "category": "electronics"},
]

class VulnHandler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _headers(self, content_type="text/html", status=200, extra=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Credentials", "true")
        self.send_header("X-Powered-By", "PHP/7.4.3")
        self.send_header("Server", "Apache/2.4.41 (Ubuntu)")
        if extra:
            for k, v in extra.items(): self.send_header(k, v)
        self.end_headers()

    def _write(self, body):
        if isinstance(body, str): body = body.encode()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self._headers(); self._write(b"")

    def do_GET(self):
        p = urllib.parse.urlparse(self.path)
        path = p.path
        qs = urllib.parse.parse_qs(p.query, keep_blank_values=True)
        get = lambda k, d="": (qs.get(k, [d])[0])

        # ── /search — SQLi + XSS ─────────────────────────────────────────
        if path == "/search":
            q = get("q", "")
            searchFor = get("searchFor", get("keyword", get("term", q)))
            query_val = searchFor or q

            # SQLi detection: quotes trigger MySQL error
            if any(c in query_val for c in ["'", '"', "\\", "--", ";"]):
                body = f"""<html><body>
<h2>Search Results</h2>
<p>Searching for: {query_val}</p>
<br>
<b>Warning</b>: mysql_fetch_array() expects parameter 1 to be resource, boolean given in
<b>/var/www/html/search.php</b> on line <b>23</b><br />
<br>You have an error in your SQL syntax; check the manual that corresponds to your
MySQL server version for the right syntax to use near '{query_val}' at line 1
<br>Error Code: 1064
</body></html>"""
                self._headers(); self._write(body); return

            # XSS: reflect input unencoded
            body = f"""<html><body>
<h2>Search Results for: {query_val}</h2>
<p>No results found for your query: {query_val}</p>
<form><input name="searchFor" value="{query_val}"></form>
</body></html>"""
            self._headers(); self._write(body); return

        # ── /listproducts — SQLi via cat param ───────────────────────────
        if path == "/listproducts.php" or path == "/listproducts":
            cat = get("cat", "1")
            if any(c in cat for c in ["'", '"', "--", ";"]):
                body = f"""<html><body>
Warning: mysql_fetch_array() expects parameter 1 to be resource, boolean given in /var/www/html/listproducts.php on line 74
You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '{cat}' at line 1
</body></html>"""
                self._headers(); self._write(body); return
            prods = [p for p in PRODUCTS if str(p["id"]) == cat or cat == "0"]
            self._headers("application/json")
            self._write(json.dumps(prods or PRODUCTS)); return

        # ── /api/users/{id} — IDOR ───────────────────────────────────────
        m = re.match(r'^/api/users/(\w+)(?:/profile)?$', path)
        if m:
            user_id = m.group(1)
            user = USERS.get(user_id)
            if user:
                self._headers("application/json")
                self._write(json.dumps(user)); return
            self._headers("application/json", 404)
            self._write(json.dumps({"error": "User not found"})); return

        # ── /api/users — list all users ───────────────────────────────────
        if path == "/api/users":
            self._headers("application/json")
            self._write(json.dumps(list(USERS.values()))); return

        # ── /redirect — Open Redirect ─────────────────────────────────────
        if path == "/redirect":
            url = get("url", get("next", get("return", "/")))
            self._headers(status=302, extra={"Location": url})
            self._write(b""); return

        # ── /file — Path Traversal ────────────────────────────────────────
        if path == "/file":
            file_path = get("path", get("file", ""))
            if file_path and (".." in file_path or file_path.startswith("/")):
                # Simulate /etc/passwd
                body = """root:x:0:0:root:/root:/bin/bash
daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
bin:x:2:2:bin:/bin:/usr/sbin/nologin
www-data:x:33:33:www-data:/var/www:/usr/sbin/nologin"""
                self._headers("text/plain"); self._write(body); return
            self._headers(); self._write(b"<html>File not found</html>"); return

        # ── /debug — Info Disclosure ──────────────────────────────────────
        if path == "/debug" or path == "/phpinfo.php":
            body = """<html><body>
<h1>Debug Info</h1>
<p>DB_HOST=postgres DB_PASS=secret123 API_KEY=sk-prod-abc123</p>
<p>phpinfo()</p>
<table><tr><td>PHP Version</td><td>7.4.3</td></tr>
<tr><td>System</td><td>Linux testlab 5.15</td></tr>
<tr><td>DB_PASSWORD</td><td>secret123</td></tr>
</table></body></html>"""
            self._headers(); self._write(body); return

        # ── /graphql — GraphQL introspection ─────────────────────────────
        if path == "/graphql":
            self._headers("application/json")
            self._write(json.dumps({
                "data": {"__schema": {"types": [
                    {"name": "Query"}, {"name": "User"}, {"name": "Admin"}
                ]}}
            })); return

        # ── /login — Auth endpoint ────────────────────────────────────────
        if path == "/login":
            body = """<html><body>
<form method="POST" action="/login">
  <input name="username" type="text">
  <input name="password" type="password">
  <button type="submit">Login</button>
</form></body></html>"""
            self._headers(); self._write(body); return

        # ── / — Index ─────────────────────────────────────────────────────
        if path == "/":
            body = """<html><body>
<h1>GLASSWING Test Lab</h1>
<ul>
<li><a href="/search?q=test">Search</a></li>
<li><a href="/listproducts?cat=1">Products</a></li>
<li><a href="/api/users/1">User Profile</a></li>
<li><a href="/login">Login</a></li>
<li><a href="/debug">Debug</a></li>
</ul></body></html>"""
            self._headers(); self._write(body); return

        self._headers(status=404)
        self._write(b"<html><body>404 Not Found</body></html>")

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body_bytes = self.rfile.read(length) if length else b""

        p = urllib.parse.urlparse(self.path)
        path = p.path

        # POST /graphql
        if path == "/graphql":
            try:
                data = json.loads(body_bytes)
                query = data.get("query", "")
                if "__schema" in query or "introspection" in query.lower():
                    self._headers("application/json")
                    self._write(json.dumps({
                        "data": {"__schema": {"types": [
                            {"name": "Query", "fields": [
                                {"name": "users"}, {"name": "adminPanel"}
                            ]},
                            {"name": "User", "fields": [
                                {"name": "id"}, {"name": "email"},
                                {"name": "secret"}, {"name": "role"}
                            ]}
                        ]}}
                    })); return
            except Exception:
                pass
            self._headers("application/json")
            self._write(json.dumps({"data": None, "errors": [{"message": "Not found"}]}))
            return

        self._headers(status=404)
        self._write(b"")


if __name__ == "__main__":
    server = HTTPServer(("0.0.0.0", 9001), VulnHandler)
    print("TestLab running on :9001")
    print("Vulnerabilities: SQLi, XSS, IDOR, Open Redirect, Path Traversal, GraphQL, CORS")
    server.serve_forever()
