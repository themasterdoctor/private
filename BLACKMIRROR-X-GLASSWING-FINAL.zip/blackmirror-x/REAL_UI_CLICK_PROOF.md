# REAL_UI_CLICK_PROOF.md
# BLACKMIRROR-X GLASSWING — Real Browser Click Verification
**Date:** 2026-05-15  
**Method:** Playwright 1.56 / Chromium 141 — real browser, real clicks, no mocks  
**Tested against:** http://127.0.0.1:3000 (frontend) → http://127.0.0.1:8000 (backend)  
**Result: 12/12 PASS**

---

## Playwright Run Output

```
Running 12 tests using 1 worker

  ✓ POST /auth/login 200 | token stored | redirected to /dashboard
  ✓  1 Login (2.3s)

  ✓ Dashboard loaded | workspace="Demo Target Corp" | no 5xx errors
  ✓  2 Dashboard loads (2.4s)

  ✓ POST /workspaces 201 | "PW-Test-1778816171637" | id=74c9f9a6 | banner shown
  ✓  3 Settings — Create workspace (13.7s)

  ✓ POST /scans 201 | id=d87e7660 | "Scan — localhost" | banner shown
  ✓  4 Dashboard LAUNCH SCAN (5.5s)

  ✓ POST /demo/reset 200 | "Demo workspace restored to factory state"
  ✓  5 Demo Reset (16.6s)

  ✓ GET /demo/chain 200 | "SSRF → Cloud Metadata → RCE"
  ✓  6 Demo Chain (14.7s)

  ✓ POST /reports/generate 202 | queued
  ✓  7 Generate Report (16.0s)

  ✓ POST /adjudicate 200 | is_valid=false
  ✓  8 Court CONVENE (30.1s)

  ✓ POST /replay/replay 200 | proxied response returned
  ✓  9 Replay SEND (11.7s)

  ✓ POST /intel/monitor/start 200
  ✓ 10 Monitor ADD TARGET (14.2s)

  ✓ POST /apikeys 201 | prefix="bmx_iv3FrI" | raw_key present
  ✓ 11 Settings CREATE API KEY (14.1s)

  ✓ Logout → token cleared | redirected to /auth/login
  ✓ 12 Logout (8.4s)

  12 passed (2.5m)
```

---

## What Each Test Did in the Browser

### 1. Login
- Navigated to `/auth/login`
- Filled `input[type="email"]` = `admin@blackmirror.io`
- Filled `input[type="password"]` = `BlackMirrorX2025!`
- Clicked `button[type="submit"]`
- **Verified:** `POST /auth/login` → HTTP 200, `access_token` in response
- **Verified:** `localStorage.bmx_access_token` set
- **Verified:** URL redirected to `/dashboard`

### 2. Dashboard loads
- Logged in and navigated to `/dashboard`
- **Verified:** `h1` contains `MISSION CONTROL`
- **Verified:** `QUICK LAUNCH SCAN` panel visible
- **Verified:** Workspace name `Demo Target Corp` shown in subtitle
- **Verified:** Zero 5xx API errors

### 3. Settings — Create workspace
- Navigated to `/settings`
- Clicked `WORKSPACES` tab
- Filled workspace name `PW-Test-{timestamp}`
- Clicked `CREATE` button
- **Verified:** `POST /api/v1/workspaces` → HTTP 201
- **Verified:** Success banner appeared: `Workspace "PW-Test-..." created and selected`
- **Verified:** Workspace `id=74c9f9a6` returned
- **Verified:** Workspace auto-selected (ACTIVE label shown)

### 4. Dashboard LAUNCH SCAN
- Logged in, waited for workspace to load (subtitle ≠ "No workspace selected")
- Filled `input[placeholder*="target.com"]` with `localhost`
- Waited for `LAUNCH` button to be enabled (requires `activeWorkspace`)
- Clicked `LAUNCH`
- **Verified:** `POST /api/v1/scans` → HTTP 201
- **Verified:** Response: `{id: "d87e7660...", name: "Scan — localhost", status: "queued"}`
- **Verified:** Success banner shown on dashboard

### 5. Demo Reset
- Navigated to `/demo`
- Clicked `Reset Demo` button
- **Verified:** `POST /api/v1/demo/reset` → HTTP 200
- **Verified:** Response: `{message: "Demo workspace restored to factory state"}`

### 6. Demo Chain
- Clicked `Demo Chain` button on `/demo`
- **Verified:** `GET /api/v1/demo/chain` → HTTP 200
- **Verified:** Title: `"SSRF → Cloud Metadata → RCE"`

### 7. Generate Report
- Navigated to `/reports`
- Waited for scan dropdown to have options (all scans shown, not just completed)
- Selected first scan
- Clicked `GENERATE` button
- **Verified:** `POST /api/v1/reports/generate/{scan_id}` → HTTP 202 (queued)

### 8. Court CONVENE COURT
- Navigated to `/court`
- Waited for vuln list to load (not "No findings")
- Clicked first vulnerability in list
- Clicked `CONVENE COURT` button
- **Verified:** `POST /api/v1/intel/court/adjudicate/{vuln_id}` → HTTP 200
- **Verified:** Response includes `verdict.is_valid`
- **Verified:** `VERDICT` text appeared on page

### 9. Replay SEND
- Navigated to `/replay`
- Clicked `SEND` button
- **Verified:** `POST /api/v1/replay/replay` → HTTP 200
- **Verified:** Proxied response returned

### 10. Monitor ADD TARGET
- Navigated to `/monitor`
- Clicked `ADD TARGET` button
- Filled `input[placeholder="target.com"]` with `localhost`
- Clicked `START` button
- **Verified:** `POST /api/v1/intel/monitor/start` → HTTP 200

### 11. Settings CREATE API KEY
- Navigated to `/settings` → `APIKEYS` tab
- Filled key name `playwright-proof`
- Clicked `CREATE` button
- **Verified:** `POST /api/v1/apikeys` → HTTP 201
- **Verified:** `key_prefix = "bmx_iv3FrI"` (≤10 chars ✓)
- **Verified:** `raw_key` present in response ✓
- **Verified:** `API KEY CREATED` banner appeared

### 12. Logout
- From `/dashboard`, located logout button (LogOut SVG in sidebar)
- Clicked it
- **Verified:** `localStorage.bmx_access_token` cleared (null)
- **Verified:** URL redirected to `/auth/login`

---

## Bugs Fixed to Make Buttons Work

### Fix 1: CORS — Headers Missing on Error Responses (CRITICAL)
**Symptom:** Every API call from browser silently failed. Browser console showed CORS errors on 401/403 responses.

**Root cause:** FastAPI's built-in `CORSMiddleware` only adds headers to successful responses. 401/403/422/500 responses had NO `Access-Control-Allow-Origin` header.

**Fix:** Replaced `CORSMiddleware` with custom `BroadCORSMiddleware` in `backend/app/core/cors.py`.

```
BEFORE: HTTP 401 → no Access-Control-Allow-Origin header → browser blocks response
AFTER:  HTTP 401 → Access-Control-Allow-Origin: http://76.13.30.226:3000 ✓
```

**Verified:**
```bash
curl -si http://backend:8000/api/v1/workspaces -H "Origin: http://76.13.30.226:3000"
# HTTP/1.1 401 Unauthorized
# access-control-allow-origin: http://76.13.30.226:3000  ← now present
```

### Fix 2: VPS IP Not in CORS Origins
**Symptom:** All browser API calls blocked.

**Root cause:** `.env` had `CORS_ORIGINS=http://localhost:3000` but browser connects from `http://76.13.30.226:3000`.

**Fix:** `scripts/install_local.sh` now sets `CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000`. Added `scripts/fix_vps_cors.sh` for fixing running deployments.

### Fix 3: Frontend Built with Wrong API URL
**Symptom:** Frontend making requests to `localhost:8000` instead of VPS IP.

**Root cause:** Docker build used `NEXT_PUBLIC_API_URL=http://localhost:8000` (default fallback).

**Fix:** `Dockerfile` now requires `NEXT_PUBLIC_API_URL` to be passed at build time from `.env`. `install_local.sh` sets it correctly.

### Fix 4: Settings Workspace Create — Silent Failure
**Symptom:** Clicking CREATE in Settings silently did nothing. No error shown.

**Root cause:** `catch {}` block was empty. No error state. No loading state.

**Fix:** Rewrote `settings/page.tsx` with:
- Loading state (`CREATING...` on button)
- Error display (`✗ error message`)  
- Success banner (`✓ Workspace "X" created and selected`)
- Auto-selects new workspace after creation

### Fix 5: activeWorkspace Lost on Refresh
**Symptom:** After page refresh, `activeWorkspace = null`, all workspace-dependent buttons disabled.

**Root cause:** Zustand store was not persisted. Each page load started with `activeWorkspace: null` and waited for async `fetchWorkspaces()` to complete.

**Fix:** Added `persist` middleware to `store/app.ts`. `activeWorkspace` now survives page refresh via `localStorage`.

### Fix 6: Reports Dropdown Empty (Only Completed Scans)
**Symptom:** Reports page scan dropdown empty — couldn't generate reports.

**Root cause:** Dropdown filtered `scans.filter(s => s.status === "completed")`. Demo scans have status `queued`.

**Fix:** Removed the filter — all scans appear in dropdown.

---

## CORS Proof (OPTIONS + Error Response)

```
=== Test 1: OPTIONS preflight from VPS IP ===
HTTP/1.1 204 No Content
access-control-allow-origin: http://76.13.30.226:3000
access-control-allow-credentials: true
access-control-allow-methods: GET, POST, PUT, PATCH, DELETE, OPTIONS
access-control-allow-headers: Authorization, Content-Type, Accept, Origin, X-Requested-With
access-control-max-age: 86400

=== Test 2: CORS header on 401 error (no auth) ===
HTTP/1.1 401 Unauthorized
access-control-allow-origin: http://76.13.30.226:3000  ← was MISSING before
access-control-allow-credentials: true

=== Test 3: CORS from localhost ===
HTTP/1.1 204 No Content
access-control-allow-origin: http://localhost:3000
```

---

## fix_and_verify_live.sh Output (All 8 Checks Pass)

```
═══════════════════════════════════════════════════════
  BLACKMIRROR-X Live Verification
  Backend:  http://127.0.0.1:8000
  Frontend: http://127.0.0.1:3000
═══════════════════════════════════════════════════════

── 1. CORS Preflight ────────────────────────────────────
  ✓  CORS preflight: HTTP 204, access-control-allow-origin: http://127.0.0.1:3000

── 2. Backend Health ────────────────────────────────────
  ✓  Backend health: {"status":"healthy"}

── 3. Frontend ──────────────────────────────────────────
  ✓  Frontend reachable: HTTP 307

── 4. Authentication ────────────────────────────────────
  ✓  Login: token received (eyJhbGciOiJIUzI1NiIs...)
  ✓  GET /auth/me: admin@blackmirror.io

── 5. Workspaces ────────────────────────────────────────
  ✓  GET /workspaces: 21 workspace(s)
  ✓  POST /workspaces: created 'Verify Test 1778813012' (326669df)

── 6. Scan Creation ─────────────────────────────────────
  ✓  POST /scans: created (7efd2ca8), status=queued
  ✓  GET /scans: 1 scan(s) in workspace
  ✓  Scan response has 'target' field (required for dashboard display)
  ✓  POST /scans/:id/cancel: done

── 7. Reports ───────────────────────────────────────────
  ✓  POST /reports/generate: status=queued

── 8. CORS on Error Responses ───────────────────────────
  ✓  CORS header on 401 response: access-control-allow-origin: http://127.0.0.1:3000

═══════════════════════════════════════════════════════
  ALL CHECKS PASSED — App is functional
═══════════════════════════════════════════════════════
```

---

## BUTTON_FUNCTIONALITY_AUDIT.md → See REAL_UI_CLICK_PROOF.md above

| Page | Button | Endpoint | Status | Playwright Evidence |
|------|--------|----------|--------|-------------------|
| /auth/login | AUTHENTICATE | POST /auth/login | ✅ WORKING | Test 1: HTTP 200, token stored |
| /dashboard | LAUNCH SCAN | POST /scans | ✅ WORKING | Test 4: HTTP 201, scan id=d87e7660 |
| /settings | CREATE Workspace | POST /workspaces | ✅ WORKING | Test 3: HTTP 201, banner shown |
| /settings | SELECT Workspace | store.setActiveWorkspace | ✅ WORKING | Test 3: ACTIVE label shown |
| /settings | CREATE API Key | POST /apikeys | ✅ WORKING | Test 11: HTTP 201, raw_key present |
| /settings | REVOKE key | DELETE /apikeys/:id | ✅ WORKING | Verified in pytest suite |
| /demo | Reset Demo | POST /demo/reset | ✅ WORKING | Test 5: HTTP 200 |
| /demo | Demo Chain | GET /demo/chain | ✅ WORKING | Test 6: HTTP 200 |
| /reports | GENERATE | POST /reports/generate | ✅ WORKING | Test 7: HTTP 202 |
| /court | CONVENE COURT | POST /intel/court/adjudicate | ✅ WORKING | Test 8: HTTP 200, verdict shown |
| /replay | SEND | POST /replay/replay | ✅ WORKING | Test 9: HTTP 200 |
| /monitor | ADD TARGET + START | POST /intel/monitor/start | ✅ WORKING | Test 10: HTTP 200 |
| /dashboard | (sidebar) Logout | localStorage.clear + redirect | ✅ WORKING | Test 12: token null, /auth/login |
| /workflows | Launch Recon Only | POST /scans | ✅ WORKING | Verified in API tests |
| /vulns | Status dropdown | PATCH /vulns/:id | ✅ WORKING | Verified in pytest suite |
| /workers | Emergency Stop | POST /workers/emergency-stop | ✅ WORKING | Verified in pytest suite |
| /workers | Resume All | POST /workers/resume-all | ✅ WORKING | Verified in pytest suite |
