# UI_ACTION_AUDIT.md
# BLACKMIRROR-X GLASSWING — Complete UI Button & Action Audit
**Date:** 2026-05-14  
**Audited:** Every button, form, and API action across all 21 pages  
**Status after fixes:** All critical actions verified working

---

## Summary of Bugs Found and Fixed

| # | Page | Button/Action | Bug | Fix |
|---|------|--------------|-----|-----|
| 1 | Login | AUTHENTICATE | Called `/auth/token` — route doesn't exist | Changed to `/auth/login` |
| 2 | Dashboard | LAUNCH SCAN | Sent `{target}` — backend requires `{name}` | Fixed payload to `{name, scan_type, config}` |
| 3 | Dashboard | LAUNCH SCAN | No error/success feedback | Added error + success toast messages |
| 4 | Dashboard | LAUNCH SCAN | No warning when no workspace | Added workspace-missing warning |
| 5 | All pages | Data display | `/scans` response missing `target`, `subdomain_count`, `vuln_count` | Extended `ScanListOut` schema + computed in endpoint |
| 6 | Vulns | Status dropdown | Sent `in_progress`/`resolved`/`wont_fix` — not in `VulnStatus` enum | Added missing enum values |
| 7 | Settings | CREATE API KEY | `APIKeyCreated.raw_key` had no default — Pydantic crash | Made `raw_key` optional with default `""` |
| 8 | Settings | CREATE API KEY | `prefix = raw[:12]` exceeded `String(10)` column | Fixed to `raw[:10]` |
| 9 | Settings | API key list | Frontend read `.prefix` but backend returns `.key_prefix` | Fixed interface field name |
| 10 | All pages | Rate limiting | Default 60 req/min too low for active use | Raised to 300 req/min |
| 11 | api.ts | All requests | Used FormData for login — backend expects urlencoded | Changed to `URLSearchParams` |
| 12 | api.ts | All errors | Errors swallowed silently | Added `.uiMessage` to every error |

---

## Page-by-Page Audit

### /auth/login
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| AUTHENTICATE | `handleSubmit` | POST `/auth/login` | **Fixed** — was calling `/auth/token` |
| REQUEST ACCESS link | navigate | `/auth/register` | OK |

### /dashboard
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| LAUNCH SCAN | `launchScan()` | POST `/scans` | **Fixed** — payload now `{name, scan_type, config}` |
| Recent scan links | navigate | `/scans/:id` | OK |
| VIEW ALL / RECON DASHBOARD | navigate | `/vulns`, `/recon` | OK |

### /recon
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| APPLY filter | `applyFilter()` | GET `/recon/subdomains`, GET `/recon/urls` | OK |
| Tab buttons | state | local | OK |
| External links | window.open | target domain | OK |

### /vulns
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| Severity filter pills | state | local | OK |
| Status dropdown | `updateVuln()` | PATCH `/vulns/:id` | **Fixed** — enum missing `in_progress`, `resolved`, `wont_fix` |
| COPY URL | `copyPoc()` | clipboard | OK |

### /mission (Mission Control)
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| RUN INTELLIGENCE | `generateHypotheses()` | POST `/intel/hypotheses/generate/:scan_id` | OK |
| Hypothesis select | state | local | OK |
| Tab buttons | state | local | OK |
| Attack chain display | static data | local | OK — hardcoded demo chains |

### /court (AI Courtroom)
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| CONVENE COURT | `adjudicate()` | POST `/intel/court/adjudicate/:vuln_id` + POST `/intel/simulate/:vuln_id` | OK |
| Vulnerability search | state | local | OK |

### /evidence (Evidence Vault)
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| Evidence item select | state | local | OK — transforms vulns to evidence items |
| COPY button | `copyToClipboard()` | clipboard | OK |
| Export button | inline `<a>` click | client-side blob download | OK |
| Copy as Report | `copyToClipboard()` | clipboard | OK |

### /monitor (Continuous Monitoring)
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| ADD TARGET | `setShowAddForm(true)` | local | OK |
| START | `addMonitor()` | POST `/intel/monitor/start` | OK |
| Remove (trash icon) | `removeMonitor()` | DELETE `/intel/monitor/:ws/:target` | OK |

### /replay (Replay Lab)
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| SEND | `sendRequest()` | POST `/replay/replay` | OK — uses backend proxy |
| Request list select | state | local | OK |
| Header add/remove | state | local | OK |

### /reports
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| GENERATE | `generate()` | POST `/reports/generate/:scan_id` | OK |
| VIEW | `viewReport()` | GET `/reports/:id` | OK |
| DL (download) | `downloadReport()` | client-side blob | OK |

### /orchestrator (AVROS Orchestrator)
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| Start Orchestrator | `startOrchestrator()` | POST `/orchestrator/start/:scan_id` | OK |
| Stop | `stopOrchestrator()` | POST `/orchestrator/stop/:scan_id` | OK |
| Refresh | `pollStatus()` | GET `/orchestrator/tasks/:id`, events, pending | OK |
| Approve task | `approveTask()` | POST `/orchestrator/approve/:id` | OK |

### /browser-intel
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| Run DOM Snapshot | `runDomSnapshot()` | POST `/browser-intel/dom-snapshot?url=...` | OK |
| Map SPA Routes | `runSpaMapper()` | POST `/browser-intel/spa-routes?url=...` | OK |
| Storage/WS tabs | static message | N/A | OK — shows "requires playwright" |

### /api-intel
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| Detect IDOR Candidates | `runIdorScan()` | POST `/api-intel/observe` | OK |
| Run Role Diff | `runRoleDiff()` | POST `/api-intel/role-diff` | OK |
| Analyze GraphQL | `runGraphQLAnalysis()` | POST `/api-intel/graphql-analyze` | OK |
| Analyze OpenAPI | `runOpenAPIAnalysis()` | POST `/api-intel/openapi-analyze` | OK |

### /chains (Attack Chain Reasoner)
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| Build Attack Chains | `buildChains()` | POST `/chains/build-from-vulns` | OK |
| Chain expand/collapse | state | local | OK |

### /memory (Strategic Memory)
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| Refresh | `fetchMemory()` | GET `/memory/:ws` | OK |
| Record Feedback | `submitFeedback()` | POST `/memory/:ws/feedback` | OK |

### /workers (Distributed Workers)
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| Emergency Stop | `action("emergency-stop")` | POST `/workers/emergency-stop` | OK |
| Resume All | `action("resume-all")` | POST `/workers/resume-all` | OK |
| Pause | `pauseScan()` | POST `/workers/pause/:scan_id` | OK |
| Resume | `resumeScan()` | POST `/workers/resume/:scan_id` | OK |

### /workflows (Guided Workflows)
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| Workflow cards | state | local | OK |
| Launch button | `launchWorkflow()` | POST `/scans` | OK — sends `{name, scan_type, config, workspace_id}` |
| Authorization checkbox | state | local | OK — required before launch |

### /demo (Demo Control Panel)
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| Reset Demo | `resetDemo()` | POST `/demo/reset` | OK |
| Refresh | `fetchStatus()` | GET `/demo/status` | OK |
| Demo Report | `loadDemo("report")` | GET `/demo/report` | OK |
| Demo Chain | `loadDemo("chain")` | GET `/demo/chain` | OK |
| Demo Verdict | `loadDemo("verdict")` | GET `/demo/verdict` | OK |

### /copilot (Glasswing Copilot)
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| SEND / Enter | `sendMessage()` | POST `/copilot/chat/stream` (SSE) | OK |
| Suggested prompts | `sendMessage(text)` | same | OK |
| NEW SESSION | `newSession()` | local state clear | OK |

### /settings
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| CREATE workspace | `createWorkspace()` | POST `/workspaces` | OK |
| SELECT workspace | `setActiveWorkspace()` | local state | OK |
| CREATE API key | `createKey()` | POST `/apikeys` | **Fixed** — was 500 (raw_key + prefix length) |
| REVOKE key | `revokeKey()` | DELETE `/apikeys/:id` | OK — returns 204 |
| Tab nav | state | local | OK |

### /onboarding
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| Continue/Back | step navigation | local | OK |
| Check Status (testlab) | `startTestlab()` | GET `/demo/status` | OK |
| Open Dashboard | `finish()` | navigate | OK |

### /scans/[id]
| Button | Handler | Endpoint | Fix |
|--------|---------|----------|-----|
| CANCEL | `cancelScan()` | POST `/scans/:id/cancel` | OK |
| AUTO-SCROLL toggle | state | local | OK |
| WebSocket live logs | `new WebSocket(wsUrl)` | WS `/ws/scan/:id` | OK |

---

## API Wrapper Changes (api.ts)

```typescript
// BEFORE (broken)
login: (email, password) => {
  const form = new FormData()
  form.append("username", email)
  return getApi().post("/auth/token", form)  // ← /auth/token DOESN'T EXIST
}

// AFTER (fixed)
login: (email, password) => {
  const form = new URLSearchParams()
  form.append("username", email)
  form.append("password", password)
  return getApi().post("/auth/login", form, {  // ← correct endpoint
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
  })
}
```

All errors now attach `error.uiMessage` with the backend detail string, which pages can display directly.

---

## Known Limitations (Not Bugs)

1. **Replay Lab**: Uses backend proxy at POST `/replay/replay`. Browser direct-fetch is disabled (no `mode: no-cors`). Response body is available.

2. **Browser Intel Storage/WS tabs**: Show "requires playwright" message. Not a bug — Playwright must be installed inside the Docker image to enable these.

3. **Copilot**: Requires `ANTHROPIC_API_KEY` for streaming responses. Without it, returns a heuristic fallback message.

4. **Reports**: `POST /reports/generate` returns 202 (queued). The Celery worker executes it asynchronously. With `docker-compose up` running the worker, reports complete within ~30 seconds.

5. **Orchestrator**: Requires an active scan (`status=queued` or `running`). Using a completed demo scan still works but the agents will find 0 new items.

6. **Monitor alerts**: The alert feed shows mock/static alerts for demo purposes. Real monitoring runs via Celery beat (background scheduler).
