"use client";
import { useState } from "react";
import { Layers, TrendingUp, AlertTriangle, FileText, ChevronDown, ChevronRight } from "lucide-react";

const API = process.env.NEXT_PUBLIC_API_URL || "";

interface ChainNode {
  node_id: string; vuln_type: string; title: string; url: string; severity: string;
}
interface AttackChain {
  chain_id: string; title: string; nodes: ChainNode[]; final_impact: string;
  chain_probability: number; impact_score: number; missing_links: string[];
  next_steps: string[]; estimated_bounty: string; rank?: number;
  composite_score?: number;
}
interface ProofGap {
  gap_type: string; description: string; chain_id: string;
  test_suggestion: string; safe_to_test: boolean;
}

const SEVERITY_COLORS: Record<string, string> = {
  critical: "text-bmx-red", high: "text-bmx-orange",
  medium: "text-bmx-yellow", low: "text-blue-400", info: "text-gray-400",
};

export default function ChainsPage() {
  const [vulnsInput, setVulnsInput] = useState(
    JSON.stringify([
      { id: "v1", vuln_type: "xss", severity: "high", url: "/search?q=", title: "Reflected XSS" },
      { id: "v2", vuln_type: "idor", severity: "high", url: "/api/users/1", title: "IDOR on user profile" },
      { id: "v3", vuln_type: "cors", severity: "medium", url: "/api/data", title: "CORS misconfiguration" },
    ], null, 2)
  );
  const [chains, setChains] = useState<AttackChain[]>([]);
  const [gaps, setGaps] = useState<ProofGap[]>([]);
  const [summary, setSummary] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  const getToken = () => localStorage.getItem("bmx_access_token") || "";

  async function buildChains() {
    setLoading(true); setError("");
    try {
      const vulns = JSON.parse(vulnsInput);
      const r = await fetch(`${API}/api/v1/chains/build-from-vulns`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken()}`, "Content-Type": "application/json" },
        body: JSON.stringify(vulns),
      });
      if (!r.ok) throw new Error(await r.text());
      const data = await r.json();
      setChains(data.chains || []);
      setGaps(data.proof_gaps || []);
      setSummary(data.executive_summary || "");
    } catch (e: unknown) { setError(String(e)); } finally { setLoading(false); }
  }

  function toggleExpand(id: string) {
    setExpanded((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id); else n.add(id);
      return n;
    });
  }

  const probColor = (p: number) =>
    p > 0.7 ? "text-bmx-red" : p > 0.5 ? "text-bmx-orange" : p > 0.3 ? "text-bmx-yellow" : "text-gray-400";

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Layers className="w-6 h-6 text-bmx-red" />
        <div>
          <h1 className="text-xl font-bold text-white font-mono">Attack Chain Reasoner</h1>
          <p className="text-xs text-bmx-muted">Dynamic graph reasoning from real findings</p>
        </div>
      </div>

      {/* Input */}
      <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4 space-y-3">
        <label className="text-xs text-bmx-muted block">Vulnerability JSON Array</label>
        <textarea
          value={vulnsInput}
          onChange={(e) => setVulnsInput(e.target.value)}
          rows={8}
          className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-xs text-white font-mono focus:border-bmx-red outline-none resize-none"
        />
        <button
          onClick={buildChains}
          disabled={loading}
          className="px-4 py-2 text-sm font-mono bg-bmx-red/10 text-bmx-red border border-bmx-red/30 rounded hover:bg-bmx-red/20 disabled:opacity-40 transition-colors"
        >
          {loading ? "Reasoning..." : "Build Attack Chains"}
        </button>
        {error && <p className="text-xs text-bmx-red">{error}</p>}
      </div>

      {/* Executive Summary */}
      {summary && (
        <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <FileText className="w-4 h-4 text-bmx-cyan" />
            <span className="text-sm font-mono text-white">Executive Summary</span>
          </div>
          <div className="text-xs text-bmx-muted whitespace-pre-line leading-relaxed">{summary}</div>
        </div>
      )}

      {/* Chain list */}
      {chains.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-bmx-orange" />
            <span className="text-sm font-mono text-white">
              {chains.length} Attack Chain{chains.length > 1 ? "s" : ""} Identified
            </span>
          </div>

          {chains.map((chain) => (
            <div key={chain.chain_id} className="bg-bmx-dark border border-bmx-border rounded-lg overflow-hidden">
              {/* Chain header */}
              <button
                onClick={() => toggleExpand(chain.chain_id)}
                className="w-full px-4 py-3 flex items-center gap-3 hover:bg-white/5 transition-colors text-left"
              >
                {expanded.has(chain.chain_id)
                  ? <ChevronDown className="w-4 h-4 text-bmx-muted flex-shrink-0" />
                  : <ChevronRight className="w-4 h-4 text-bmx-muted flex-shrink-0" />}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    {chain.rank && (
                      <span className="text-xs bg-bmx-red/10 text-bmx-red border border-bmx-red/20 rounded px-1.5 py-0.5 font-mono">
                        #{chain.rank}
                      </span>
                    )}
                    <span className="text-sm font-mono text-white">{chain.title}</span>
                  </div>
                  <div className="flex items-center gap-3 mt-0.5 text-xs text-bmx-muted">
                    <span>{chain.nodes.length} step{chain.nodes.length > 1 ? "s" : ""}</span>
                    <span>→</span>
                    <span className="text-bmx-orange">{chain.final_impact.replace(/_/g, " ")}</span>
                  </div>
                </div>
                <div className="flex items-center gap-4 flex-shrink-0 text-right">
                  <div>
                    <div className={`text-sm font-bold font-mono ${probColor(chain.chain_probability)}`}>
                      {(chain.chain_probability * 100).toFixed(0)}%
                    </div>
                    <div className="text-xs text-bmx-muted">probability</div>
                  </div>
                  <div>
                    <div className="text-sm font-bold font-mono text-bmx-green">{chain.estimated_bounty}</div>
                    <div className="text-xs text-bmx-muted">est. bounty</div>
                  </div>
                </div>
              </button>

              {/* Expanded detail */}
              {expanded.has(chain.chain_id) && (
                <div className="border-t border-bmx-border px-4 py-4 space-y-4">
                  {/* Chain steps */}
                  <div className="space-y-2">
                    {chain.nodes.map((node, i) => (
                      <div key={node.node_id} className="flex items-start gap-3 text-xs">
                        <div className="flex-shrink-0 w-5 h-5 rounded-full bg-bmx-border/30 flex items-center justify-center text-bmx-muted font-mono text-xs">
                          {i + 1}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className={`font-mono font-semibold uppercase text-xs ${SEVERITY_COLORS[node.severity] || "text-white"}`}>
                              {node.vuln_type}
                            </span>
                            <span className="text-white">{node.title}</span>
                          </div>
                          <div className="text-bmx-muted mt-0.5 font-mono">{node.url}</div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Next steps */}
                  {chain.next_steps?.length > 0 && (
                    <div>
                      <div className="text-xs font-mono text-bmx-muted mb-1.5">Next Steps</div>
                      <ul className="space-y-1">
                        {chain.next_steps.map((step, i) => (
                          <li key={i} className="text-xs text-white flex items-start gap-1.5">
                            <span className="text-bmx-cyan mt-0.5">→</span>
                            {step}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Missing links */}
                  {chain.missing_links?.length > 0 && (
                    <div className="bg-bmx-yellow/5 border border-bmx-yellow/20 rounded p-3">
                      <div className="text-xs font-mono text-bmx-yellow mb-1.5 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" /> Missing Proof
                      </div>
                      {chain.missing_links.map((link, i) => (
                        <div key={i} className="text-xs text-bmx-muted">• {link}</div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Proof gaps */}
      {gaps.length > 0 && (
        <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4 space-y-3">
          <div className="text-sm font-mono text-white flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-bmx-yellow" />
            Proof Gaps ({gaps.length})
          </div>
          <div className="space-y-2">
            {gaps.slice(0, 8).map((gap, i) => (
              <div key={i} className="bg-bmx-black rounded p-3 text-xs space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-bmx-yellow font-mono">{gap.gap_type}</span>
                  {!gap.safe_to_test && (
                    <span className="text-bmx-red text-xs">⚠ requires approval</span>
                  )}
                </div>
                <div className="text-bmx-muted">{gap.description}</div>
                <div className="text-bmx-cyan">Test: {gap.test_suggestion}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
