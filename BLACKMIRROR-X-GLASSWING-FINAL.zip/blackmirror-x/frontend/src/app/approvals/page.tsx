"use client";
import { useEffect, useState, useCallback } from "react";
import { useAppStore } from "@/store/app";
import { AlertTriangle, CheckCircle, XCircle, Clock, Zap, Shield, StopCircle } from "lucide-react";
import getApi from "@/lib/api";

interface ApprovalRequest {
  id: string;
  action_type: string;
  risk_tier: string;
  title: string;
  description: string;
  target_url: string;
  payload: string;
  expected_behavior: string;
  potential_impact: string;
  status: string;
  created_at: string;
}

const TIER_STYLES: Record<string, { border: string; badge: string; icon: string }> = {
  high:     { border: "border-bmx-red/40",    badge: "bg-bmx-red/10 text-bmx-red border-bmx-red/30",    icon: "text-bmx-red" },
  medium:   { border: "border-bmx-yellow/40", badge: "bg-bmx-yellow/10 text-bmx-yellow border-bmx-yellow/30", icon: "text-bmx-yellow" },
  low:      { border: "border-bmx-green/40",  badge: "bg-bmx-green/10 text-bmx-green border-bmx-green/30", icon: "text-bmx-green" },
  critical: { border: "border-red-600/60",    badge: "bg-red-600/10 text-red-400 border-red-600/30",    icon: "text-red-400" },
};

export default function ApprovalsPage() {
  const { activeWorkspace, fetchWorkspaces } = useAppStore();
  const [pending, setPending] = useState<ApprovalRequest[]>([]);
  const [history, setHistory] = useState<ApprovalRequest[]>([]);
  const [stopped, setStopped] = useState(false);
  const [tab, setTab] = useState<"pending" | "history">("pending");
  const [approveReason, setApproveReason] = useState<Record<string, string>>({});
  const [rejectReason, setRejectReason] = useState<Record<string, string>>({});
  const [expanded, setExpanded] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const api = getApi();
  const wid = activeWorkspace?.id || "";

  const loadData = useCallback(async () => {
    if (!wid) return;
    try {
      const [pendingR, histR, stopR] = await Promise.all([
        api.get(`/enterprise/approvals/${wid}/pending`),
        api.get(`/enterprise/approvals/${wid}/history`),
        api.get(`/enterprise/emergency-stop/${wid}/status`),
      ]);
      setPending(pendingR.data.pending || []);
      setHistory(histR.data.history || []);
      setStopped(stopR.data.stopped || false);
    } catch {}
  }, [wid]);

  useEffect(() => {
    if (!activeWorkspace) fetchWorkspaces();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 5000);
    return () => clearInterval(interval);
  }, [loadData]);

  async function approve(reqId: string) {
    setLoading(true);
    try {
      await api.post(`/enterprise/approvals/${reqId}/approve`, { reason: approveReason[reqId] || "" });
      await loadData();
    } catch (e: any) { setError(e.uiMessage || "Failed"); }
    finally { setLoading(false); }
  }

  async function reject(reqId: string) {
    if (!rejectReason[reqId]?.trim()) { setError("Rejection reason required"); return; }
    setLoading(true);
    try {
      await api.post(`/enterprise/approvals/${reqId}/reject`, { reason: rejectReason[reqId] });
      await loadData();
    } catch (e: any) { setError(e.uiMessage || "Failed"); }
    finally { setLoading(false); }
  }

  async function toggleEmergencyStop() {
    try {
      if (stopped) {
        await api.post(`/enterprise/emergency-stop/${wid}/resume`);
        setStopped(false);
      } else {
        await api.post(`/enterprise/emergency-stop/${wid}`);
        setStopped(true);
        await loadData();
      }
    } catch (e: any) { setError(e.uiMessage || "Failed"); }
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white font-mono text-xl font-bold flex items-center gap-2">
            <Shield className="w-5 h-5 text-bmx-cyan" />
            HUMAN APPROVAL GATES
          </h1>
          <p className="text-bmx-muted text-sm font-mono mt-0.5">
            Review and authorize risky scan actions before execution
          </p>
        </div>
        <button onClick={toggleEmergencyStop}
          className={`flex items-center gap-2 px-4 py-2 rounded border font-mono font-bold text-sm transition-colors ${
            stopped
              ? "bg-bmx-green/10 border-bmx-green/40 text-bmx-green hover:bg-bmx-green/20"
              : "bg-bmx-red/10 border-bmx-red/40 text-bmx-red hover:bg-bmx-red/20"
          }`}>
          <StopCircle className="w-4 h-4" />
          {stopped ? "RESUME SCANNING" : "⚠ EMERGENCY STOP"}
        </button>
      </div>

      {stopped && (
        <div className="bmx-panel rounded-lg border border-bmx-red/50 bg-bmx-red/5 p-4">
          <div className="flex items-center gap-2">
            <StopCircle className="w-5 h-5 text-bmx-red" />
            <span className="text-bmx-red font-mono font-bold">EMERGENCY STOP ACTIVE — All scanning is halted</span>
          </div>
        </div>
      )}

      {pending.length > 0 && (
        <div className="bmx-panel rounded-lg border border-bmx-yellow/30 bg-bmx-yellow/5 p-3 flex items-center gap-2">
          <Clock className="w-4 h-4 text-bmx-yellow animate-pulse" />
          <span className="text-bmx-yellow text-xs font-mono">
            {pending.length} action{pending.length > 1 ? "s" : ""} waiting for approval — scan is paused
          </span>
        </div>
      )}

      {error && <div className="text-bmx-red text-xs font-mono bg-bmx-red/10 border border-bmx-red/30 rounded px-3 py-2">✗ {error}</div>}

      <div className="flex gap-1 border-b border-bmx-border">
        {[["pending", `PENDING (${pending.length})`], ["history", "HISTORY"]] .map(([id, label]) => (
          <button key={id} onClick={() => setTab(id as any)}
            className={`px-4 py-2 text-xs font-mono tracking-wider ${
              tab === id ? "text-bmx-cyan border-b-2 border-bmx-cyan" : "text-bmx-muted hover:text-white"
            }`}>{label}</button>
        ))}
      </div>

      {tab === "pending" && (
        <div className="space-y-4">
          {pending.length === 0 ? (
            <div className="text-center py-12 text-bmx-muted">
              <CheckCircle className="w-8 h-8 mx-auto mb-2 text-bmx-green/50" />
              <p className="font-mono text-sm">No pending approvals — all actions are proceeding automatically</p>
            </div>
          ) : pending.map(req => {
            const style = TIER_STYLES[req.risk_tier] || TIER_STYLES.medium;
            const isExpanded = expanded === req.id;
            return (
              <div key={req.id} className={`bmx-panel rounded-lg border ${style.border} overflow-hidden`}>
                <div className="p-4 cursor-pointer" onClick={() => setExpanded(isExpanded ? null : req.id)}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className={`w-4 h-4 mt-0.5 ${style.icon}`} />
                      <div>
                        <p className="text-white font-mono text-sm font-bold">{req.title}</p>
                        <p className="text-bmx-muted text-xs font-mono mt-0.5">{req.description}</p>
                        <div className="flex items-center gap-2 mt-1.5">
                          <span className={`text-xs font-mono px-2 py-0.5 rounded border ${style.badge}`}>
                            {req.risk_tier.toUpperCase()} RISK
                          </span>
                          <span className="text-bmx-muted text-xs font-mono">{req.action_type}</span>
                          <span className="text-bmx-muted text-xs font-mono">{new Date(req.created_at).toLocaleTimeString()}</span>
                        </div>
                      </div>
                    </div>
                    <Zap className="w-4 h-4 text-bmx-muted" />
                  </div>
                </div>

                {isExpanded && (
                  <div className="border-t border-bmx-border p-4 space-y-4 bg-bmx-dark/30">
                    <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                      <div>
                        <p className="text-bmx-muted mb-1">TARGET URL</p>
                        <code className="text-bmx-cyan bg-bmx-black px-2 py-1 rounded block">{req.target_url}</code>
                      </div>
                      <div>
                        <p className="text-bmx-muted mb-1">PAYLOAD</p>
                        <code className="text-bmx-orange bg-bmx-black px-2 py-1 rounded block break-all">{req.payload || "None"}</code>
                      </div>
                      <div>
                        <p className="text-bmx-muted mb-1">EXPECTED BEHAVIOR</p>
                        <p className="text-white">{req.expected_behavior}</p>
                      </div>
                      <div>
                        <p className="text-bmx-muted mb-1">POTENTIAL IMPACT</p>
                        <p className="text-white">{req.potential_impact}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <input
                          value={approveReason[req.id] || ""}
                          onChange={e => setApproveReason(p => ({ ...p, [req.id]: e.target.value }))}
                          placeholder="Approval reason (optional)"
                          className="w-full bg-bmx-black border border-bmx-green/30 rounded px-3 py-2 text-white font-mono text-xs" />
                        <button onClick={() => approve(req.id)} disabled={loading}
                          className="w-full flex items-center justify-center gap-2 bg-bmx-green/10 border border-bmx-green/40 text-bmx-green font-mono font-bold text-xs px-4 py-2 rounded hover:bg-bmx-green/20 disabled:opacity-40">
                          <CheckCircle className="w-4 h-4" /> APPROVE — EXECUTE ACTION
                        </button>
                      </div>
                      <div className="space-y-2">
                        <input
                          value={rejectReason[req.id] || ""}
                          onChange={e => setRejectReason(p => ({ ...p, [req.id]: e.target.value }))}
                          placeholder="Rejection reason (required)"
                          className="w-full bg-bmx-black border border-bmx-red/30 rounded px-3 py-2 text-white font-mono text-xs" />
                        <button onClick={() => reject(req.id)} disabled={loading || !rejectReason[req.id]?.trim()}
                          className="w-full flex items-center justify-center gap-2 bg-bmx-red/10 border border-bmx-red/40 text-bmx-red font-mono font-bold text-xs px-4 py-2 rounded hover:bg-bmx-red/20 disabled:opacity-40">
                          <XCircle className="w-4 h-4" /> REJECT — SKIP ACTION
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {tab === "history" && (
        <div className="bmx-panel rounded-lg border border-bmx-border overflow-hidden">
          <table className="w-full text-xs font-mono">
            <thead>
              <tr className="border-b border-bmx-border bg-bmx-dark">
                {["TIME", "ACTION", "RISK", "TARGET", "STATUS", "BY"].map(h => (
                  <th key={h} className="px-3 py-2 text-left text-bmx-muted tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {history.map((req, i) => (
                <tr key={i} className="border-b border-bmx-border/30 hover:bg-bmx-dark/50">
                  <td className="px-3 py-1.5 text-bmx-muted">{new Date(req.created_at).toLocaleTimeString()}</td>
                  <td className="px-3 py-1.5 text-white">{req.action_type}</td>
                  <td className={`px-3 py-1.5 font-bold ${TIER_STYLES[req.risk_tier]?.icon || "text-white"}`}>
                    {req.risk_tier?.toUpperCase()}
                  </td>
                  <td className="px-3 py-1.5 text-bmx-muted truncate max-w-[200px]">{req.target_url}</td>
                  <td className={`px-3 py-1.5 font-bold ${
                    req.status === "approved" ? "text-bmx-green" :
                    req.status === "rejected" ? "text-bmx-red" : "text-bmx-muted"
                  }`}>{req.status?.toUpperCase()}</td>
                  <td className="px-3 py-1.5 text-bmx-muted">{req.status === "approved" ? "✓ Approved" : "✗ Rejected"}</td>
                </tr>
              ))}
              {!history.length && (
                <tr><td colSpan={6} className="px-3 py-6 text-center text-bmx-muted">No approval history</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
