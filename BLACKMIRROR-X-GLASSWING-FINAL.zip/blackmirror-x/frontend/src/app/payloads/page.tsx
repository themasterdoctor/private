"use client";
/**
 * Payload Inspector — BLACKMIRROR-X GLASSWING
 * Browse, test, and generate payloads. JWT decoder. GraphQL explorer.
 * AI-assisted payload customization via Copilot.
 */
import { useState, useCallback } from "react";
import { enterprisePayloadApi, getToken } from "@/lib/api";
import {
  Code, Copy, Check, ChevronDown, ChevronUp, Zap, Key,
  Search, Filter, AlertTriangle, Shield, Globe, Database,
  RefreshCw, Play, Lock, Unlock, Eye
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────

type VulnType = "xss" | "sqli" | "ssrf" | "ssti" | "idor" | "cors" | "crlf" | "jwt" | "graphql" | "xxe" | "rce";
type PayloadTier = "passive" | "low_risk" | "manual_review" | "lab_only" | "blocked";

interface Payload {
  value: string;
  tier: PayloadTier;
  description: string;
  context?: string;
  cve?: string;
}

interface JWTDecoded {
  header: Record<string, unknown>;
  payload: Record<string, unknown>;
  signature: string;
  raw: string;
  issues: string[];
}

// ── Built-in payload library (subset — full library is in the backend) ────────

const VULN_TYPES: { id: VulnType; label: string; color: string; count: number }[] = [
  { id: "xss",     label: "Cross-Site Scripting",      color: "text-red-400",    count: 47 },
  { id: "sqli",    label: "SQL Injection",              color: "text-orange-400", count: 38 },
  { id: "ssrf",    label: "SSRF",                       color: "text-yellow-400", count: 22 },
  { id: "ssti",    label: "Template Injection",         color: "text-purple-400", count: 18 },
  { id: "idor",    label: "IDOR",                       color: "text-blue-400",   count: 12 },
  { id: "cors",    label: "CORS Misconfiguration",      color: "text-bmx-teal",   count: 8  },
  { id: "crlf",    label: "CRLF Injection",             color: "text-bmx-cyan",   count: 10 },
  { id: "jwt",     label: "JWT Attacks",                color: "text-bmx-green",  count: 15 },
  { id: "graphql", label: "GraphQL Abuse",              color: "text-pink-400",   count: 11 },
  { id: "xxe",     label: "XXE Injection",              color: "text-red-300",    count: 9  },
  { id: "rce",     label: "RCE / Command Injection",    color: "text-bmx-red",    count: 24 },
];

const TIER_CONFIG: Record<PayloadTier, { color: string; label: string; icon: React.ElementType }> = {
  passive:       { color: "text-bmx-green  border-bmx-green/30  bg-bmx-green/5",   label: "PASSIVE",       icon: Shield },
  low_risk:      { color: "text-bmx-cyan   border-bmx-cyan/30   bg-bmx-cyan/5",    label: "LOW RISK",      icon: Shield },
  manual_review: { color: "text-bmx-yellow border-bmx-yellow/30 bg-bmx-yellow/5",  label: "REVIEW",        icon: Eye },
  lab_only:      { color: "text-bmx-orange border-bmx-orange/30 bg-bmx-orange/5",  label: "LAB ONLY",      icon: Lock },
  blocked:       { color: "text-bmx-red    border-bmx-red/30    bg-bmx-red/5",     label: "BLOCKED",       icon: AlertTriangle },
};

const TABS = ["payloads", "jwt", "graphql", "encoder"] as const;
type Tab = typeof TABS[number];

// ── JWT Decoder ───────────────────────────────────────────────────────────────

function decodeJWT(token: string): JWTDecoded | null {
  try {
    const parts = token.trim().split(".");
    if (parts.length !== 3) return null;
    const decode = (s: string) => JSON.parse(atob(s.replace(/-/g, "+").replace(/_/g, "/")));
    const header = decode(parts[0]);
    const payload = decode(parts[1]);
    const issues: string[] = [];
    if (header.alg === "none" || header.alg === "None") issues.push("⚠ Algorithm 'none' — signature not verified!");
    if (header.alg === "HS256") issues.push("ℹ HS256 — test for weak secret (jwt-cracker, hashcat)");
    if (header.alg?.startsWith("RS")) issues.push("ℹ RSA — test for RS→HS256 algorithm confusion");
    if (payload.exp && Date.now() / 1000 > payload.exp) issues.push("⚠ Token is EXPIRED");
    if (!payload.exp) issues.push("⚠ No expiry (exp) claim — token never expires");
    if (payload.iss) issues.push(`ℹ Issuer: ${payload.iss}`);
    if (payload.sub) issues.push(`ℹ Subject: ${payload.sub}`);
    return { header, payload, signature: parts[2], raw: token, issues };
  } catch {
    return null;
  }
}

// ── GraphQL Queries ───────────────────────────────────────────────────────────

const GRAPHQL_QUERIES = [
  {
    label: "Introspection (full schema dump)",
    query: `{ __schema { queryType { name } mutationType { name } types { name kind fields { name type { name kind } } } } }`,
    risk: "medium",
    description: "Dumps the complete GraphQL schema. Should be disabled in production.",
  },
  {
    label: "Type enumeration",
    query: `{ __schema { types { name kind description } } }`,
    risk: "low",
    description: "Lists all types — useful for finding hidden objects.",
  },
  {
    label: "Batching attack (100x __typename)",
    query: JSON.stringify(Array(100).fill({ query: "{ __typename }" }), null, 2),
    risk: "medium",
    description: "Tests for GraphQL batching support — can bypass rate limits.",
  },
  {
    label: "IDOR via user query",
    query: `{ user(id: 1) { id email password role createdAt } }`,
    risk: "high",
    description: "Attempts to fetch user 1's data — test for IDOR.",
  },
  {
    label: "Alias-based DoS",
    query: `{ a1: __typename a2: __typename a3: __typename }`,
    risk: "medium",
    description: "Tests alias support which can be used for rate limit bypass.",
  },
  {
    label: "Fragment injection",
    query: `fragment F on User { id email } { user(id: 1) { ...F } }`,
    risk: "medium",
    description: "Tests fragment support.",
  },
];

// ── Encoder/Decoder ───────────────────────────────────────────────────────────

function encodePayload(input: string, mode: string): string {
  try {
    switch (mode) {
      case "url":     return encodeURIComponent(input);
      case "url2x":   return encodeURIComponent(encodeURIComponent(input));
      case "html":    return input.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
      case "base64":  return btoa(input);
      case "hex":     return Array.from(input).map(c => "%" + c.charCodeAt(0).toString(16).padStart(2,"0")).join("");
      case "unicode": return Array.from(input).map(c => "\\u" + c.charCodeAt(0).toString(16).padStart(4,"0")).join("");
      case "decimal": return Array.from(input).map(c => `&#${c.charCodeAt(0)};`).join("");
      default:        return input;
    }
  } catch { return input; }
}

// ── Main Component ────────────────────────────────────────────────────────────

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(()=>setCopied(false),2000); }}
      className="text-bmx-muted hover:text-bmx-cyan transition-colors p-1">
      {copied ? <Check className="w-3 h-3 text-bmx-green" /> : <Copy className="w-3 h-3" />}
    </button>
  );
}

export default function PayloadsPage() {
  const [activeTab, setActiveTab] = useState<Tab>("payloads");
  const [selectedType, setSelectedType] = useState<VulnType>("xss");
  const [tierFilter, setTierFilter] = useState<PayloadTier | "">("");
  const [search, setSearch] = useState("");
  const [payloads, setPayloads] = useState<Payload[]>([]);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState<Set<number>>(new Set());

  // JWT decoder state
  const [jwtInput, setJwtInput] = useState("");
  const [jwtDecoded, setJwtDecoded] = useState<JWTDecoded | null>(null);

  // GraphQL state
  const [gqlEndpoint, setGqlEndpoint] = useState("");
  const [gqlQuery, setGqlQuery] = useState(GRAPHQL_QUERIES[0].query);
  const [gqlResponse, setGqlResponse] = useState("");
  const [gqlLoading, setGqlLoading] = useState(false);

  // Encoder state
  const [encodeInput, setEncodeInput] = useState("");
  const [encodeMode, setEncodeMode] = useState("url");

  const fetchPayloads = useCallback(async (type: VulnType) => {
    setLoading(true);
    setPayloads([]);
    try {
      const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
      const token = getToken();
      const resp = await fetch(`${BASE}/api/v1/enterprise/payloads/${type}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (resp.ok) {
        const data = await resp.json();
        setPayloads(data.payloads || []);
      }
    } catch {
      setPayloads([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleTypeSelect = (type: VulnType) => {
    setSelectedType(type);
    fetchPayloads(type);
  };

  const runGQL = async () => {
    if (!gqlEndpoint) return;
    setGqlLoading(true);
    setGqlResponse("");
    try {
      let body: object;
      try { body = JSON.parse(gqlQuery); } catch { body = { query: gqlQuery }; }
      const resp = await fetch(gqlEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const text = await resp.text();
      try { setGqlResponse(JSON.stringify(JSON.parse(text), null, 2)); }
      catch { setGqlResponse(text); }
    } catch (e: unknown) {
      setGqlResponse(`Error: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setGqlLoading(false);
    }
  };

  const toggleExpand = (i: number) => {
    setExpanded(prev => {
      const next = new Set(prev);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });
  };

  const filtered = payloads.filter(p => {
    if (tierFilter && p.tier !== tierFilter) return false;
    if (search && !p.value.toLowerCase().includes(search.toLowerCase()) &&
        !p.description.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="shrink-0 border-b border-bmx-border px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-white font-mono text-lg font-bold flex items-center gap-2">
              <Code className="w-5 h-5 text-bmx-cyan" />
              PAYLOAD INSPECTOR
            </h1>
            <p className="text-bmx-muted font-mono text-xs mt-0.5">
              Browse payloads · Decode JWTs · Explore GraphQL · Encode inputs
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono text-bmx-muted">
            <Shield className="w-3.5 h-3.5 text-bmx-green" />
            <span>Safe payload tiers auto-enforced by scope engine</span>
          </div>
        </div>

        {/* Tab bar */}
        <div className="flex gap-1 mt-4">
          {([
            ["payloads", <Code key="c" className="w-3.5 h-3.5" />, "Payload Library"],
            ["jwt",      <Key  key="k" className="w-3.5 h-3.5" />, "JWT Decoder"],
            ["graphql",  <Globe key="g" className="w-3.5 h-3.5" />, "GraphQL Explorer"],
            ["encoder",  <Database key="d" className="w-3.5 h-3.5" />, "Encoder / Decoder"],
          ] as const).map(([tab, icon, label]) => (
            <button key={tab} onClick={() => setActiveTab(tab as Tab)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono tracking-wider border-b-2 transition-colors ${
                activeTab === tab
                  ? "text-bmx-cyan border-bmx-cyan"
                  : "text-bmx-muted border-transparent hover:text-white"
              }`}>
              {icon} {label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">

        {/* ── PAYLOAD LIBRARY ── */}
        {activeTab === "payloads" && (
          <div className="h-full flex">
            {/* Left: type list */}
            <div className="w-56 shrink-0 border-r border-bmx-border overflow-y-auto py-2">
              {VULN_TYPES.map(vt => (
                <button key={vt.id} onClick={() => handleTypeSelect(vt.id)}
                  className={`w-full flex items-center justify-between px-4 py-2.5 text-left transition-colors ${
                    selectedType === vt.id
                      ? "bg-bmx-border/60 text-white"
                      : "text-bmx-muted/70 hover:text-white hover:bg-bmx-border/30"
                  }`}>
                  <span className={`font-mono text-xs ${selectedType === vt.id ? vt.color : ""}`}>{vt.label}</span>
                  <span className="text-[10px] font-mono text-bmx-muted/40">{vt.count}</span>
                </button>
              ))}
            </div>

            {/* Right: payload list */}
            <div className="flex-1 overflow-hidden flex flex-col">
              {/* Filters */}
              <div className="shrink-0 flex items-center gap-3 px-4 py-3 border-b border-bmx-border">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-bmx-muted" />
                  <input value={search} onChange={e => setSearch(e.target.value)}
                    placeholder="Filter payloads..."
                    className="w-full bg-bmx-black border border-bmx-border rounded pl-9 pr-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-bmx-cyan" />
                </div>
                <select value={tierFilter} onChange={e => setTierFilter(e.target.value as PayloadTier | "")}
                  className="bg-bmx-black border border-bmx-border rounded px-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-bmx-cyan">
                  <option value="">All tiers</option>
                  {(Object.keys(TIER_CONFIG) as PayloadTier[]).map(t => (
                    <option key={t} value={t}>{TIER_CONFIG[t].label}</option>
                  ))}
                </select>
                <button onClick={() => fetchPayloads(selectedType)} disabled={loading}
                  className="flex items-center gap-1.5 border border-bmx-border text-bmx-muted hover:text-white px-3 py-1.5 rounded text-xs font-mono transition-colors">
                  <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin" : ""}`} /> Reload
                </button>
              </div>

              {/* Payload list */}
              <div className="flex-1 overflow-y-auto p-4 space-y-2">
                {loading && (
                  <div className="text-center py-8 text-bmx-muted font-mono text-sm">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2" />
                    Loading payloads from API...
                  </div>
                )}
                {!loading && filtered.length === 0 && (
                  <div className="text-center py-12 text-bmx-muted font-mono text-sm">
                    <Code className="w-6 h-6 mx-auto mb-2 opacity-40" />
                    {payloads.length === 0
                      ? "Select a vulnerability type to load payloads"
                      : "No payloads match filters"}
                  </div>
                )}
                {filtered.map((p, i) => {
                  const tc = TIER_CONFIG[p.tier];
                  const TierIcon = tc.icon;
                  const isExpanded = expanded.has(i);
                  return (
                    <div key={i} className="border border-bmx-border rounded-lg overflow-hidden hover:border-bmx-border/80 transition-colors">
                      <div className="flex items-center gap-3 px-4 py-2.5 bg-bmx-dark/40">
                        <code className="flex-1 font-mono text-xs text-white break-all">{p.value}</code>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className={`flex items-center gap-1 text-[9px] font-mono border px-1.5 py-0.5 rounded ${tc.color}`}>
                            <TierIcon className="w-2.5 h-2.5" /> {tc.label}
                          </span>
                          <CopyButton text={p.value} />
                          <button onClick={() => toggleExpand(i)}
                            className="text-bmx-muted/40 hover:text-bmx-muted transition-colors">
                            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>
                      {isExpanded && (
                        <div className="px-4 py-3 border-t border-bmx-border bg-bmx-black/30 space-y-1.5">
                          <p className="text-bmx-muted font-mono text-xs">{p.description}</p>
                          {p.context && <p className="text-bmx-cyan/60 font-mono text-xs">Context: {p.context}</p>}
                          {p.cve && <p className="text-bmx-orange/70 font-mono text-xs">CVE: {p.cve}</p>}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ── JWT DECODER ── */}
        {activeTab === "jwt" && (
          <div className="p-6 space-y-4">
            <div className="space-y-2">
              <label className="text-bmx-muted font-mono text-xs tracking-wider">JWT TOKEN</label>
              <div className="flex gap-3">
                <textarea
                  value={jwtInput}
                  onChange={e => setJwtInput(e.target.value)}
                  placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                  rows={3}
                  className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-bmx-cyan resize-none"
                />
                <button
                  onClick={() => setJwtDecoded(decodeJWT(jwtInput))}
                  className="flex items-center gap-2 bg-bmx-cyan text-bmx-black font-mono font-bold text-xs px-4 py-2 rounded hover:bg-bmx-cyan/90 transition-colors self-start"
                >
                  <Key className="w-4 h-4" /> DECODE
                </button>
              </div>
            </div>

            {jwtDecoded && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {/* Header */}
                <div className="bmx-panel rounded-lg border border-bmx-border p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-bmx-teal font-mono text-xs tracking-wider">HEADER</span>
                    <CopyButton text={JSON.stringify(jwtDecoded.header, null, 2)} />
                  </div>
                  <pre className="text-white font-mono text-xs leading-relaxed whitespace-pre-wrap">
                    {JSON.stringify(jwtDecoded.header, null, 2)}
                  </pre>
                </div>

                {/* Payload */}
                <div className="bmx-panel rounded-lg border border-bmx-border p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-bmx-cyan font-mono text-xs tracking-wider">PAYLOAD</span>
                    <CopyButton text={JSON.stringify(jwtDecoded.payload, null, 2)} />
                  </div>
                  <pre className="text-white font-mono text-xs leading-relaxed whitespace-pre-wrap">
                    {JSON.stringify(jwtDecoded.payload, null, 2)}
                  </pre>
                </div>

                {/* Issues */}
                <div className="bmx-panel rounded-lg border border-bmx-border p-4">
                  <span className="text-bmx-orange font-mono text-xs tracking-wider block mb-3">SECURITY ANALYSIS</span>
                  {jwtDecoded.issues.length === 0 ? (
                    <p className="text-bmx-muted font-mono text-xs">No obvious issues detected.</p>
                  ) : (
                    <div className="space-y-2">
                      {jwtDecoded.issues.map((issue, i) => (
                        <div key={i} className={`font-mono text-xs p-2 rounded border ${
                          issue.startsWith("⚠")
                            ? "text-bmx-red border-bmx-red/30 bg-bmx-red/5"
                            : "text-bmx-muted border-bmx-border"
                        }`}>
                          {issue}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Signature */}
                  <div className="mt-4 pt-4 border-t border-bmx-border">
                    <span className="text-bmx-muted font-mono text-xs block mb-1">SIGNATURE</span>
                    <code className="text-bmx-muted/60 font-mono text-xs break-all">{jwtDecoded.signature.slice(0, 40)}...</code>
                  </div>
                </div>
              </div>
            )}

            {jwtInput && !jwtDecoded && (
              <div className="bmx-panel rounded border border-bmx-red/30 bg-bmx-red/5 px-4 py-3">
                <p className="text-bmx-red font-mono text-xs">Invalid JWT format. Expected: header.payload.signature</p>
              </div>
            )}
          </div>
        )}

        {/* ── GRAPHQL EXPLORER ── */}
        {activeTab === "graphql" && (
          <div className="h-full flex flex-col p-6 gap-4">
            {/* Endpoint + run */}
            <div className="flex gap-3 shrink-0">
              <input value={gqlEndpoint} onChange={e => setGqlEndpoint(e.target.value)}
                placeholder="https://target.com/graphql"
                className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan" />
              <button onClick={runGQL} disabled={gqlLoading || !gqlEndpoint}
                className="flex items-center gap-2 bg-bmx-cyan text-bmx-black font-mono font-bold text-sm px-4 py-2 rounded hover:bg-bmx-cyan/90 transition-colors disabled:opacity-50">
                {gqlLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
                RUN
              </button>
            </div>

            {/* Preset queries */}
            <div className="shrink-0">
              <p className="text-bmx-muted font-mono text-xs mb-2 tracking-wider">PRESET ATTACKS</p>
              <div className="flex gap-2 flex-wrap">
                {GRAPHQL_QUERIES.map((q, i) => (
                  <button key={i} onClick={() => setGqlQuery(q.query)}
                    className={`text-xs font-mono border rounded px-2.5 py-1 transition-colors ${
                      q.risk === "high" ? "border-bmx-red/30 text-bmx-red hover:bg-bmx-red/10" :
                      q.risk === "medium" ? "border-bmx-yellow/30 text-bmx-yellow hover:bg-bmx-yellow/10" :
                      "border-bmx-border text-bmx-muted hover:text-white"
                    }`}>
                    {q.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Query / Response split */}
            <div className="flex-1 grid grid-cols-2 gap-4 min-h-0">
              <div className="flex flex-col min-h-0">
                <div className="flex items-center justify-between mb-2 shrink-0">
                  <span className="text-bmx-muted font-mono text-xs tracking-wider">QUERY</span>
                  <CopyButton text={gqlQuery} />
                </div>
                <textarea value={gqlQuery} onChange={e => setGqlQuery(e.target.value)}
                  className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-bmx-cyan resize-none" />
              </div>
              <div className="flex flex-col min-h-0">
                <div className="flex items-center justify-between mb-2 shrink-0">
                  <span className="text-bmx-muted font-mono text-xs tracking-wider">RESPONSE</span>
                  {gqlResponse && <CopyButton text={gqlResponse} />}
                </div>
                <div className="flex-1 overflow-y-auto bg-bmx-black border border-bmx-border rounded px-3 py-2">
                  {gqlLoading ? (
                    <div className="flex items-center gap-2 text-bmx-muted font-mono text-xs">
                      <RefreshCw className="w-3 h-3 animate-spin" /> Running query...
                    </div>
                  ) : gqlResponse ? (
                    <pre className="text-white font-mono text-xs whitespace-pre-wrap">{gqlResponse}</pre>
                  ) : (
                    <p className="text-bmx-muted/40 font-mono text-xs">Response will appear here...</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── ENCODER / DECODER ── */}
        {activeTab === "encoder" && (
          <div className="p-6 space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div>
                <label className="text-bmx-muted font-mono text-xs tracking-wider block mb-2">INPUT</label>
                <textarea value={encodeInput} onChange={e => setEncodeInput(e.target.value)}
                  placeholder={`<script>alert(1)</script>`}
                  rows={6}
                  className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan resize-none" />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-bmx-muted font-mono text-xs tracking-wider">OUTPUT</label>
                  <CopyButton text={encodePayload(encodeInput, encodeMode)} />
                </div>
                <div className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 font-mono text-sm text-white min-h-[144px] break-all whitespace-pre-wrap">
                  {encodeInput ? encodePayload(encodeInput, encodeMode) : <span className="text-bmx-muted/40">Encoded output...</span>}
                </div>
              </div>
            </div>

            <div className="flex gap-2 flex-wrap">
              {[
                ["url",     "URL Encode"],
                ["url2x",   "Double URL"],
                ["html",    "HTML Entities"],
                ["base64",  "Base64"],
                ["hex",     "Hex (%xx)"],
                ["unicode", "Unicode \\uXXXX"],
                ["decimal", "HTML Decimal"],
              ].map(([mode, label]) => (
                <button key={mode} onClick={() => setEncodeMode(mode)}
                  className={`text-xs font-mono border rounded px-3 py-1.5 transition-colors ${
                    encodeMode === mode
                      ? "border-bmx-cyan text-bmx-cyan bg-bmx-cyan/10"
                      : "border-bmx-border text-bmx-muted hover:text-white"
                  }`}>
                  {label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
