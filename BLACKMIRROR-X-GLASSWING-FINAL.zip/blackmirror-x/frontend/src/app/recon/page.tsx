"use client";
import { useEffect, useState } from "react";
import { useAppStore } from "@/store/app";
import { reconApi } from "@/lib/api";
import { Globe, Link2, Server, Search, ExternalLink, Filter } from "lucide-react";

interface ReconUrl { id: string; url: string; status_code?: number; content_type?: string; created_at: string; }

const STATUS_BADGE: Record<number, string> = {};
function statusColor(code?: number) {
  if (!code) return "text-bmx-muted";
  if (code < 300) return "text-bmx-green";
  if (code < 400) return "text-yellow-400";
  if (code < 500) return "text-bmx-orange";
  return "text-bmx-red";
}

export default function ReconPage() {
  const { subdomains, fetchSubdomains, fetchScans, scans, activeWorkspace , fetchWorkspaces} = useAppStore();
  const [urls, setUrls] = useState<ReconUrl[]>([]);
  const [tab, setTab] = useState<"subdomains" | "urls">("subdomains");
  const [search, setSearch] = useState("");
  const [selectedScan, setSelectedScan] = useState("");
  const [loading, setLoading] = useState(false);


  useEffect(() => {
    if (!activeWorkspace) fetchWorkspaces();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (!activeWorkspace) return;
    fetchScans(activeWorkspace.id);
    fetchSubdomains({ workspace_id: activeWorkspace.id });
    reconApi.urls({ workspace_id: activeWorkspace.id, limit: 500 }).then((r) => setUrls(r.data));
  }, [activeWorkspace]);

  const applyFilter = async () => {
    setLoading(true);
    try {
      const params = { workspace_id: activeWorkspace?.id, scan_id: selectedScan || undefined, limit: 500 };
      fetchSubdomains(params);
      const r = await reconApi.urls(params);
      setUrls(r.data);
    } finally {
      setLoading(false);
    }
  };

  const filteredSubs = subdomains.filter((s) =>
    !search || s.subdomain.includes(search)
  );
  const filteredUrls = urls.filter((u) =>
    !search || u.url.includes(search)
  );

  return (
    <div className="p-6 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white font-mono text-xl font-bold">RECON DASHBOARD</h1>
          <p className="text-bmx-muted text-sm font-mono mt-0.5">Attack surface enumeration results</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-xs font-mono">
            <Globe className="w-3.5 h-3.5 text-bmx-teal" />
            <span className="text-bmx-teal">{subdomains.length} subdomains</span>
            <span className="text-bmx-muted">•</span>
            <Link2 className="w-3.5 h-3.5 text-bmx-cyan" />
            <span className="text-bmx-cyan">{urls.length} URLs</span>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-bmx-muted" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter by domain/URL..."
            className="w-full bg-bmx-black border border-bmx-border rounded pl-9 pr-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan transition-colors"
          />
        </div>
        <select
          value={selectedScan}
          onChange={(e) => setSelectedScan(e.target.value)}
          className="bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan"
        >
          <option value="">All Scans</option>
          {scans.map((s) => (
            <option key={s.id} value={s.id}>{s.target}</option>
          ))}
        </select>
        <button
          onClick={applyFilter}
          className="flex items-center gap-2 border border-bmx-border text-bmx-muted hover:text-white hover:border-bmx-cyan text-xs font-mono px-3 py-2 rounded transition-colors"
        >
          <Filter className="w-3.5 h-3.5" /> APPLY
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 border-b border-bmx-border">
        {(["subdomains", "urls"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`pb-3 text-xs font-mono tracking-wider transition-colors ${
              tab === t ? "text-bmx-cyan border-b-2 border-bmx-cyan" : "text-bmx-muted hover:text-white"
            }`}
          >
            {t.toUpperCase()} ({t === "subdomains" ? filteredSubs.length : filteredUrls.length})
          </button>
        ))}
      </div>

      {/* Subdomains Table */}
      {tab === "subdomains" && (
        <div className="bmx-panel rounded-lg border border-bmx-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-bmx-border">
                  {["SUBDOMAIN", "IP", "STATUS", "TITLE", "TECH", "PORTS"].map((h) => (
                    <th key={h} className="text-left px-4 py-2.5 text-bmx-muted text-xs font-mono">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-bmx-border">
                {filteredSubs.map((sub) => (
                  <tr key={sub.id} className="hover:bg-bmx-panel/50 transition-colors">
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <Server className="w-3.5 h-3.5 text-bmx-teal shrink-0" />
                        <a
                          href={`https://${sub.subdomain}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-white font-mono text-xs hover:text-bmx-cyan flex items-center gap-1"
                        >
                          {sub.subdomain}
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-bmx-muted font-mono text-xs">{sub.ip_address || "-"}</td>
                    <td className="px-4 py-2.5">
                      <span className={`font-mono text-xs ${statusColor(sub.status_code)}`}>
                        {sub.status_code || "-"}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-bmx-muted font-mono text-xs max-w-48 truncate">{sub.title || "-"}</td>
                    <td className="px-4 py-2.5">
                      <div className="flex gap-1 flex-wrap">
                        {sub.technologies?.slice(0, 3).map((t) => (
                          <span key={t} className="bg-bmx-border text-bmx-muted text-xs font-mono px-1.5 py-0.5 rounded">
                            {t}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-bmx-muted font-mono text-xs">
                      {sub.ports?.join(", ") || "-"}
                    </td>
                  </tr>
                ))}
                {filteredSubs.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-bmx-muted font-mono text-sm">
                      No subdomains found. Run a scan to enumerate.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* URLs Table */}
      {tab === "urls" && (
        <div className="bmx-panel rounded-lg border border-bmx-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-bmx-border">
                  {["URL", "STATUS", "CONTENT-TYPE"].map((h) => (
                    <th key={h} className="text-left px-4 py-2.5 text-bmx-muted text-xs font-mono">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-bmx-border">
                {filteredUrls.slice(0, 200).map((u) => (
                  <tr key={u.id} className="hover:bg-bmx-panel/50 transition-colors">
                    <td className="px-4 py-2">
                      <a
                        href={u.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-bmx-teal font-mono text-xs hover:text-bmx-cyan flex items-center gap-1 max-w-xl truncate"
                      >
                        {u.url} <ExternalLink className="w-3 h-3 shrink-0" />
                      </a>
                    </td>
                    <td className="px-4 py-2">
                      <span className={`font-mono text-xs ${statusColor(u.status_code)}`}>
                        {u.status_code || "-"}
                      </span>
                    </td>
                    <td className="px-4 py-2 text-bmx-muted font-mono text-xs">{u.content_type || "-"}</td>
                  </tr>
                ))}
                {filteredUrls.length === 0 && (
                  <tr>
                    <td colSpan={3} className="px-4 py-8 text-center text-bmx-muted font-mono text-sm">
                      No URLs discovered yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
