"use client";
/**
 * Vulnerabilities — BLACKMIRROR-X GLASSWING
 *
 * XBOW-style validated findings view.
 * Default: shows VERIFIED findings first.
 * Every finding shows: severity, confidence score, FP risk, curl proof.
 */
import { useEffect, useState, useCallback } from "react";
import { useAppStore } from "@/store/app";
import { getToken } from "@/lib/api";
import {
  Bug, Shield, AlertTriangle, CheckCircle, Eye, Copy, Check,
  ExternalLink, Filter, ChevronDown, ChevronUp, Download,
  Clock, Search, Zap, XCircle, Info
} from "lucide-react";
import Link from "next/link";

// ── Types ─────────────────────────────────────────────────────────────────────
interface Vuln {
  id: string;
  title: string;
  severity: string;
  vuln_type: string;
  url: string;
  parameter?: string;
  payload?: string;
  evidence?: string;
  description?: string;
  remediation?: string;
  confidence_score?: number;
  cvss_score?: number;
  status: string;
  source?: string;
  discovered_at?: string;
}

// ── Config ────────────────────────────────────────────────────────────────────
const SEV_CONFIG: Record<string, { color: string; bg: string; border: string; order: number }> = {
  critical: { color: "text-red-400",    bg: "bg-red-400/10",    border: "border-red-400/30",    order: 0 },
  high:     { color: "text-orange-400", bg: "bg-orange-400/10", border: "border-orange-400/30", order: 1 },
  medium:   { color: "text-yellow-400", bg: "bg-yellow-400/10", border: "border-yellow-400/30", order: 2 },
  low:      { color: "text-blue-400",   bg: "bg-blue-400/10",   border: "border-blue-400/30",   order: 3 },
  info:     { color: "text-gray-400",   bg: "bg-gray-400/10",   border: "border-gray-400/30",   order: 4 },
};

const VULN_TYPE_LABELS: Record<string, string> = {
  xss: "Cross-Site Scripting", sqli: "SQL Injection",
  ssrf: "SSRF", ssti: "Template Injection", idor: "IDOR",
  cors: "CORS Misconfiguration", crlf: "CRLF Injection",
  jwt_vulnerability: "JWT Attack", open_redirect: "Open Redirect",
  oauth_misconfiguration: "OAuth Misconfiguration",
  secret_exposure: "Secret Exposure", graphql_introspection: "GraphQL Introspection",
  auth_bypass: "Auth Bypass", race_condition: "Race Condition",
  cloud_misconfiguration: "Cloud Misconfiguration",
};

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
      className="p-1 text-bmx-muted hover:text-bmx-cyan transition-colors">
      {copied ? <Check className="w-3 h-3 text-bmx-green" /> : <Copy className="w-3 h-3" />}
    </button>
  );
}

function ConfidenceBadge({ score, fpRisk }: { score?: number; fpRisk?: string }) {
  if (!score) return null;
  const pct = Math.round(score * 100);
  const color = pct >= 80 ? "text-bmx-green border-bmx-green/30" :
                pct >= 60 ? "text-bmx-yellow border-bmx-yellow/30" :
                            "text-bmx-muted border-bmx-border";
  return (
    <span className={`text-[9px] font-mono border px-1.5 py-0.5 rounded ${color}`}>
      {pct}% conf
    </span>
  );
}

export default function VulnsPage() {
  const { vulns, fetchVulns, activeWorkspace } = useAppStore();
  const [search, setSearch] = useState("");
  const [sevFilter, setSevFilter] = useState<string[]>([]);
  const [typeFilter, setTypeFilter] = useState("");
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [needsReviewOnly, setNeedsReviewOnly] = useState(false);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [exporting, setExporting] = useState(false);
  const [sortBy, setSortBy] = useState<"severity" | "confidence" | "date">("severity");

  useEffect(() => {
    if (activeWorkspace) {
      fetchVulns({ workspace_id: activeWorkspace.id });
    }
  }, [activeWorkspace]); // eslint-disable-line

  const toggleExpand = (id: string) => {
    setExpanded(prev => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  };

  const toggleSev = (sev: string) => {
    setSevFilter(prev => prev.includes(sev) ? prev.filter(s => s !== sev) : [...prev, sev]);
  };

  const isVerified = (v: Vuln) => (v.evidence || "").includes("[VERIFIED]");
  const needsReview = (v: Vuln) =>
    !isVerified(v) && (v.confidence_score || 0) < 0.7;

  // Filter + sort
  const filtered = vulns
    .filter((v: Vuln) => {
      if (verifiedOnly && !isVerified(v)) return false;
      if (needsReviewOnly && !needsReview(v)) return false;
      if (sevFilter.length && !sevFilter.includes(v.severity)) return false;
      if (typeFilter && v.vuln_type !== typeFilter) return false;
      if (search) {
        const s = search.toLowerCase();
        return (v.title || "").toLowerCase().includes(s) ||
               (v.url || "").toLowerCase().includes(s) ||
               (v.vuln_type || "").toLowerCase().includes(s);
      }
      return true;
    })
    .sort((a: Vuln, b: Vuln) => {
      if (sortBy === "severity") {
        return (SEV_CONFIG[a.severity]?.order ?? 5) - (SEV_CONFIG[b.severity]?.order ?? 5);
      }
      if (sortBy === "confidence") {
        return (b.confidence_score || 0) - (a.confidence_score || 0);
      }
      return new Date(b.discovered_at || 0).getTime() - new Date(a.discovered_at || 0).getTime();
    });

  const exportReport = async (format: string) => {
    if (!activeWorkspace) return;
    setExporting(true);
    try {
      const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
      const token = getToken();
      // Get the most recent scan
      const scansRes = await fetch(
        `${BASE}/api/v1/scans?workspace_id=${activeWorkspace.id}&limit=1`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const scans = await scansRes.json();
      if (!scans?.length) return;

      const scanId = scans[0].id;
      const res = await fetch(
        `${BASE}/api/v1/reports/export/${scanId}?format=${format}&verified_only=${verifiedOnly}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const data = await res.json();

      // Download as file
      const blob = new Blob([data.content], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `glasswing-report-${format}-${new Date().toISOString().split("T")[0]}.${format === "json" ? "json" : "md"}`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error("Export failed:", e);
    } finally {
      setExporting(false);
    }
  };

  const stats = {
    total: vulns.length,
    critical: vulns.filter((v: Vuln) => v.severity === "critical").length,
    high: vulns.filter((v: Vuln) => v.severity === "high").length,
    verified: vulns.filter((v: Vuln) => isVerified(v)).length,
    needsReview: vulns.filter((v: Vuln) => needsReview(v)).length,
  };

  return (
    <div className="h-full flex flex-col">
      {/* ── Header ── */}
      <div className="shrink-0 border-b border-bmx-border px-6 py-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h1 className="text-white font-mono text-lg font-bold flex items-center gap-2">
              <Bug className="w-5 h-5 text-bmx-red" />
              FINDINGS
            </h1>
            <p className="text-bmx-muted font-mono text-xs mt-0.5">
              XBOW proof validation · consensus scoring · FP reduction
            </p>
          </div>

          {/* Export buttons */}
          <div className="flex items-center gap-2">
            {["hackerone","yeswehack","markdown","json"].map(fmt => (
              <button key={fmt} onClick={() => exportReport(fmt)}
                disabled={exporting || !vulns.length}
                className="flex items-center gap-1.5 border border-bmx-border text-bmx-muted hover:text-white hover:border-bmx-cyan/40 px-2.5 py-1.5 rounded text-[10px] font-mono tracking-wider transition-colors disabled:opacity-40">
                <Download className="w-3 h-3" />
                {fmt === "hackerone" ? "H1" : fmt === "yeswehack" ? "YWH" : fmt.toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        {/* Stats row */}
        <div className="flex items-center gap-4 mb-3">
          {[
            { label: "Total",         val: stats.total,       color: "text-white" },
            { label: "Critical",      val: stats.critical,    color: "text-red-400" },
            { label: "High",          val: stats.high,        color: "text-orange-400" },
            { label: "✓ Verified",    val: stats.verified,    color: "text-bmx-green" },
            { label: "⚠ Needs Review",val: stats.needsReview, color: "text-bmx-yellow" },
          ].map(s => (
            <div key={s.label} className="text-center">
              <div className={`text-xl font-mono font-bold ${s.color}`}>{s.val}</div>
              <div className="text-bmx-muted/50 font-mono text-[9px]">{s.label}</div>
            </div>
          ))}
          <div className="flex-1" />
          <div className="text-bmx-muted/40 font-mono text-[10px]">
            {filtered.length} showing
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-bmx-muted" />
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search findings..."
              className="bg-bmx-black border border-bmx-border rounded pl-8 pr-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-bmx-cyan w-48" />
          </div>

          {/* Severity filters */}
          {["critical","high","medium","low"].map(sev => {
            const sc = SEV_CONFIG[sev];
            return (
              <button key={sev} onClick={() => toggleSev(sev)}
                className={`text-[10px] font-mono px-2.5 py-1.5 rounded border transition-colors ${
                  sevFilter.includes(sev)
                    ? `${sc.color} ${sc.bg} ${sc.border}`
                    : "text-bmx-muted border-bmx-border hover:text-white"
                }`}>
                {sev.toUpperCase()}
              </button>
            );
          })}

          {/* Verified only */}
          <button onClick={() => setVerifiedOnly(!verifiedOnly)}
            className={`flex items-center gap-1.5 text-[10px] font-mono px-2.5 py-1.5 rounded border transition-colors ${
              verifiedOnly
                ? "text-bmx-green bg-bmx-green/10 border-bmx-green/30"
                : "text-bmx-muted border-bmx-border hover:text-white"
            }`}>
            <CheckCircle className="w-3 h-3" />
            VERIFIED ONLY
          </button>

          {/* Needs review */}
          <button onClick={() => setNeedsReviewOnly(!needsReviewOnly)}
            className={`flex items-center gap-1.5 text-[10px] font-mono px-2.5 py-1.5 rounded border transition-colors ${
              needsReviewOnly
                ? "text-bmx-yellow bg-bmx-yellow/10 border-bmx-yellow/30"
                : "text-bmx-muted border-bmx-border hover:text-white"
            }`}>
            <Eye className="w-3 h-3" />
            NEEDS REVIEW
          </button>

          {/* Sort */}
          <select value={sortBy} onChange={e => setSortBy(e.target.value as typeof sortBy)}
            className="bg-bmx-black border border-bmx-border text-bmx-muted font-mono text-[10px] px-2 py-1.5 rounded focus:outline-none">
            <option value="severity">Sort: Severity</option>
            <option value="confidence">Sort: Confidence</option>
            <option value="date">Sort: Date</option>
          </select>

          {(sevFilter.length || search || verifiedOnly || needsReviewOnly) && (
            <button onClick={() => { setSevFilter([]); setSearch(""); setVerifiedOnly(false); setNeedsReviewOnly(false); }}
              className="text-bmx-muted hover:text-bmx-red font-mono text-[10px] transition-colors">
              Clear filters
            </button>
          )}
        </div>
      </div>

      {/* ── Findings list ── */}
      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-2">
        {filtered.length === 0 && (
          <div className="text-center py-16 space-y-2">
            <Bug className="w-8 h-8 text-bmx-muted/20 mx-auto" />
            <p className="text-bmx-muted/40 font-mono text-sm">
              {vulns.length === 0 ? "No findings yet — run a scan first" : "No findings match current filters"}
            </p>
          </div>
        )}

        {filtered.map((v: Vuln) => {
          const sc = SEV_CONFIG[v.severity] || SEV_CONFIG.info;
          const verified = isVerified(v);
          const needsRev = needsReview(v);
          const isExpanded = expanded.has(v.id);
          const typeLabel = VULN_TYPE_LABELS[v.vuln_type] || (v.vuln_type || "Unknown").replace(/_/g, " ");

          return (
            <div key={v.id}
              className={`border rounded-lg overflow-hidden transition-colors ${sc.border} ${verified ? "bg-bmx-green/3" : "bg-bmx-dark/30"}`}>

              {/* Header row */}
              <div className="flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-white/3"
                onClick={() => toggleExpand(v.id)}>

                {/* Severity badge */}
                <span className={`shrink-0 text-[10px] font-mono font-bold px-2 py-0.5 rounded ${sc.color} ${sc.bg} ${sc.border} border`}>
                  {v.severity.toUpperCase()}
                </span>

                {/* Verified / review badge */}
                {verified ? (
                  <span className="shrink-0 flex items-center gap-1 text-[9px] font-mono text-bmx-green border border-bmx-green/30 bg-bmx-green/10 px-1.5 py-0.5 rounded">
                    <CheckCircle className="w-2.5 h-2.5" /> VERIFIED
                  </span>
                ) : needsRev ? (
                  <span className="shrink-0 flex items-center gap-1 text-[9px] font-mono text-bmx-yellow border border-bmx-yellow/30 bg-bmx-yellow/10 px-1.5 py-0.5 rounded">
                    <Eye className="w-2.5 h-2.5" /> REVIEW
                  </span>
                ) : null}

                {/* Title */}
                <div className="flex-1 min-w-0">
                  <p className="text-white font-mono text-sm truncate">{v.title || "Untitled"}</p>
                  <p className="text-bmx-muted/50 font-mono text-[10px] truncate">
                    {typeLabel} · {v.url || "No URL"}
                  </p>
                </div>

                {/* Confidence */}
                <ConfidenceBadge score={v.confidence_score} />

                {/* Source */}
                {v.source && (
                  <span className="shrink-0 text-[9px] font-mono text-bmx-muted/40 border border-bmx-border px-1.5 py-0.5 rounded">
                    {v.source}
                  </span>
                )}

                {/* Expand icon */}
                <span className="shrink-0 text-bmx-muted/30">
                  {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </span>
              </div>

              {/* Expanded detail */}
              {isExpanded && (
                <div className="border-t border-bmx-border/50 px-4 py-4 space-y-4 bg-bmx-black/30">

                  {/* URL + param */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <p className="text-bmx-muted/50 font-mono text-[9px] tracking-wider mb-1">URL</p>
                      <div className="flex items-center gap-1">
                        <code className="text-bmx-cyan font-mono text-xs break-all flex-1">{v.url || "N/A"}</code>
                        {v.url && <><CopyButton text={v.url} /><a href={v.url} target="_blank" rel="noreferrer" className="text-bmx-muted hover:text-bmx-cyan transition-colors"><ExternalLink className="w-3 h-3" /></a></>}
                      </div>
                    </div>
                    {v.parameter && (
                      <div>
                        <p className="text-bmx-muted/50 font-mono text-[9px] tracking-wider mb-1">PARAMETER</p>
                        <code className="text-bmx-orange font-mono text-xs">{v.parameter}</code>
                      </div>
                    )}
                  </div>

                  {/* Description */}
                  {v.description && (
                    <div>
                      <p className="text-bmx-muted/50 font-mono text-[9px] tracking-wider mb-1">DESCRIPTION</p>
                      <p className="text-bmx-muted/80 font-mono text-xs leading-relaxed">{v.description.replace("[VERIFIED] ", "").slice(0, 400)}</p>
                    </div>
                  )}

                  {/* Payload */}
                  {v.payload && (
                    <div>
                      <p className="text-bmx-muted/50 font-mono text-[9px] tracking-wider mb-1">PAYLOAD</p>
                      <div className="flex items-center gap-1">
                        <code className="text-bmx-red font-mono text-xs bg-bmx-red/5 border border-bmx-red/20 px-2 py-1 rounded flex-1 break-all">{v.payload}</code>
                        <CopyButton text={v.payload} />
                      </div>
                    </div>
                  )}

                  {/* Evidence */}
                  {v.evidence && (
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <p className="text-bmx-muted/50 font-mono text-[9px] tracking-wider">EVIDENCE / PROOF</p>
                        <CopyButton text={v.evidence} />
                      </div>
                      <pre className="text-bmx-muted/70 font-mono text-[10px] bg-bmx-black border border-bmx-border rounded px-3 py-2 overflow-x-auto max-h-48 leading-relaxed whitespace-pre-wrap">
                        {v.evidence.slice(0, 600)}
                      </pre>
                    </div>
                  )}

                  {/* Remediation */}
                  {v.remediation && (
                    <div>
                      <p className="text-bmx-muted/50 font-mono text-[9px] tracking-wider mb-1">REMEDIATION</p>
                      <p className="text-bmx-green/70 font-mono text-xs leading-relaxed">{v.remediation}</p>
                    </div>
                  )}

                  {/* Scores */}
                  <div className="flex items-center gap-4 pt-2 border-t border-bmx-border/30">
                    {v.confidence_score != null && (
                      <div>
                        <p className="text-bmx-muted/40 font-mono text-[9px]">CONFIDENCE</p>
                        <p className="text-white font-mono text-xs">{Math.round(v.confidence_score * 100)}%</p>
                      </div>
                    )}
                    {v.cvss_score != null && (
                      <div>
                        <p className="text-bmx-muted/40 font-mono text-[9px]">CVSS</p>
                        <p className="text-white font-mono text-xs">{v.cvss_score}</p>
                      </div>
                    )}
                    <div>
                      <p className="text-bmx-muted/40 font-mono text-[9px]">SOURCE</p>
                      <p className="text-white font-mono text-xs">{v.source || "unknown"}</p>
                    </div>
                    {!verified && (
                      <div className="ml-auto">
                        <p className="text-bmx-yellow/60 font-mono text-[9px]">
                          ⚠ Unverified — confirm manually before reporting
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
