"use client";
import { useEffect, useState } from "react";
import { useAppStore, Vulnerability } from "@/store/app";
import { vulnApi } from "@/lib/api";
import {
  AlertTriangle, Search, Filter, ChevronDown, ChevronUp,
  ExternalLink, Copy, Check
} from "lucide-react";

const SEV_ORDER = ["critical", "high", "medium", "low", "info"];
const SEV_STYLES: Record<string, { border: string; badge: string; dot: string }> = {
  critical: { border: "border-red-500/30", badge: "sev-critical", dot: "bg-red-500" },
  high: { border: "border-orange-500/30", badge: "sev-high", dot: "bg-orange-500" },
  medium: { border: "border-yellow-500/30", badge: "sev-medium", dot: "bg-yellow-500" },
  low: { border: "border-blue-500/30", badge: "sev-low", dot: "bg-blue-500" },
  info: { border: "border-gray-500/30", badge: "sev-info", dot: "bg-gray-500" },
};

function VulnCard({ vuln }: { vuln: Vulnerability }) {
  const [expanded, setExpanded] = useState(false);
  const [copied, setCopied] = useState(false);
  const { updateVuln } = useAppStore();
  const sty = SEV_STYLES[vuln.severity] || SEV_STYLES.info;

  const copyPoc = () => {
    navigator.clipboard.writeText(vuln.url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={`bmx-panel rounded-lg border ${sty.border} overflow-hidden`}>
      <div
        className="flex items-start gap-3 p-4 cursor-pointer hover:bg-bmx-panel/50 transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${sty.dot}`} />
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <p className="text-white font-mono text-sm font-medium truncate">{vuln.title}</p>
            <div className="flex items-center gap-2 shrink-0">
              <span className={`severity-badge ${sty.badge}`}>{vuln.severity.toUpperCase()}</span>
              {vuln.cvss_score && (
                <span className="text-bmx-muted text-xs font-mono">CVSS {vuln.cvss_score.toFixed(1)}</span>
              )}
              {vuln.court_confidence != null && (
                <span className="text-bmx-teal text-xs font-mono border border-bmx-teal/30 px-1.5 rounded">
                  {Math.round(vuln.court_confidence * 100)}% conf
                </span>
              )}
              {vuln.exploitability_score != null && (
                <span className="text-bmx-orange text-xs font-mono border border-bmx-orange/30 px-1.5 rounded">
                  {Math.round(vuln.exploitability_score * 100)}% exploit
                </span>
              )}
              {expanded ? (
                <ChevronUp className="w-3.5 h-3.5 text-bmx-muted" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5 text-bmx-muted" />
              )}
            </div>
          </div>
          <div className="flex items-center gap-3 mt-1.5 flex-wrap">
            <span className="text-bmx-orange text-xs font-mono">{vuln.vuln_type}</span>
            {vuln.cwe_id && <span className="text-bmx-muted text-xs font-mono">{vuln.cwe_id}</span>}
            <a
              href={vuln.url}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="text-bmx-teal text-xs font-mono truncate max-w-xs hover:text-bmx-cyan flex items-center gap-1"
            >
              {vuln.url.length > 60 ? vuln.url.slice(0, 60) + "…" : vuln.url}
              <ExternalLink className="w-3 h-3 shrink-0" />
            </a>
          </div>
        </div>
      </div>

      {expanded && (
        <div className="border-t border-bmx-border px-4 py-4 space-y-4">
          <div>
            <p className="text-bmx-muted text-xs font-mono mb-1.5 tracking-wider">DESCRIPTION</p>
            <p className="text-white text-sm font-mono leading-relaxed">{vuln.description}</p>
          </div>

          {vuln.parameter && (
            <div>
              <p className="text-bmx-muted text-xs font-mono mb-1.5 tracking-wider">PARAMETER</p>
              <code className="text-bmx-cyan text-xs font-mono bg-bmx-black px-2 py-1 rounded border border-bmx-border">
                {vuln.parameter}
              </code>
            </div>
          )}

          <div className="flex items-center gap-3 flex-wrap">
            <button
              onClick={copyPoc}
              className="flex items-center gap-1.5 text-xs font-mono border border-bmx-border px-3 py-1.5 rounded hover:border-bmx-cyan hover:text-white text-bmx-muted transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? "COPIED" : "COPY URL"}
            </button>

            <select
              value={vuln.status}
              onChange={(e) => updateVuln(vuln.id, { status: e.target.value })}
              onClick={(e) => e.stopPropagation()}
              className="bg-bmx-black border border-bmx-border text-bmx-muted text-xs font-mono px-2 py-1.5 rounded focus:outline-none focus:border-bmx-cyan"
            >
              {["open", "in_progress", "resolved", "false_positive", "wont_fix"].map((s) => (
                <option key={s} value={s}>{s.replace("_", " ").toUpperCase()}</option>
              ))}
            </select>

            <span className={`text-xs font-mono px-2 py-1.5 rounded border ${
              vuln.status === "resolved" ? "text-bmx-green border-bmx-green/30 bg-bmx-green/10" :
              vuln.status === "false_positive" ? "text-bmx-muted border-bmx-border" :
              "text-bmx-orange border-bmx-orange/30 bg-bmx-orange/10"
            }`}>
              {vuln.status.toUpperCase()}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

export default function VulnsPage() {
  const { vulns, fetchVulns, isLoadingVulns, activeWorkspace, scans, fetchWorkspaces } = useAppStore();
  const [search, setSearch] = useState("");
  const [sevFilter, setSevFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");


  useEffect(() => {
    if (!activeWorkspace) fetchWorkspaces();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (activeWorkspace) fetchVulns({ workspace_id: activeWorkspace.id });
  }, [activeWorkspace]);

  const filtered = vulns.filter((v) => {
    if (search && !v.title.toLowerCase().includes(search.toLowerCase()) && !v.url.includes(search)) return false;
    if (sevFilter && v.severity !== sevFilter) return false;
    if (typeFilter && v.vuln_type !== typeFilter) return false;
    if (statusFilter && v.status !== statusFilter) return false;
    return true;
  });

  const sorted = [...filtered].sort(
    (a, b) => SEV_ORDER.indexOf(a.severity) - SEV_ORDER.indexOf(b.severity)
  );

  const vulnTypes = Array.from(new Set(vulns.map((v) => v.vuln_type)));

  return (
    <div className="p-6 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white font-mono text-xl font-bold">VULNERABILITIES</h1>
          <p className="text-bmx-muted text-sm font-mono mt-0.5">
            {filtered.length} findings • {vulns.filter((v) => v.severity === "critical").length} critical
          </p>
        </div>
      </div>

      {/* Severity summary bar */}
      <div className="flex gap-2 flex-wrap">
        {SEV_ORDER.map((sev) => {
          const count = vulns.filter((v) => v.severity === sev).length;
          if (!count) return null;
          return (
            <button
              key={sev}
              onClick={() => setSevFilter(sevFilter === sev ? "" : sev)}
              className={`px-3 py-1.5 rounded border text-xs font-mono transition-colors ${
                sevFilter === sev
                  ? SEV_STYLES[sev].badge + " border-current"
                  : "border-bmx-border text-bmx-muted hover:text-white"
              }`}
            >
              {sev.toUpperCase()} ({count})
            </button>
          );
        })}
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-bmx-muted" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search vulnerabilities..."
            className="w-full bg-bmx-black border border-bmx-border rounded pl-9 pr-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan transition-colors"
          />
        </div>
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan"
        >
          <option value="">All Types</option>
          {vulnTypes.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan"
        >
          <option value="">All Status</option>
          {["open", "in_progress", "resolved", "false_positive"].map((s) => (
            <option key={s} value={s}>{s.replace("_", " ")}</option>
          ))}
        </select>
      </div>

      {/* Vuln list */}
      {isLoadingVulns ? (
        <div className="text-bmx-muted font-mono text-sm text-center py-12">Loading vulnerabilities...</div>
      ) : (
        <div className="space-y-3">
          {sorted.map((v) => <VulnCard key={v.id} vuln={v} />)}
          {sorted.length === 0 && (
            <div className="bmx-panel rounded-lg border border-bmx-border px-4 py-12 text-center">
              <AlertTriangle className="w-8 h-8 text-bmx-muted/30 mx-auto mb-3" />
              <p className="text-bmx-muted font-mono text-sm">No vulnerabilities found matching filters.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
