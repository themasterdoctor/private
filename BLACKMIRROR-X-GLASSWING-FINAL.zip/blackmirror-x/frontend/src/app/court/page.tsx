"use client";
import { useEffect, useState } from "react";
import { useAppStore } from "@/store/app";
import {
  Scale, Shield, AlertTriangle, CheckCircle, XCircle,
  Eye, Gavel, User, Search
} from "lucide-react";

interface CourtVerdict {
  is_valid: boolean;
  is_in_scope: boolean;
  final_confidence: number;
  exploitability_score: number;
  bounty_likelihood: number;
  duplicate_risk: number;
  evidence_quality: number;
  severity_recommendation: string;
  downgrade_reason: string;
  prosecution_summary: string;
  defense_summary: string;
  scope_verdict: string;
  evidence_verdict: string;
  judge_reasoning: string;
  recommended_actions: string[];
}

interface Simulation {
  account_takeover_likelihood: number;
  data_exposure_scale: number;
  lateral_movement_potential: number;
  cloud_compromise_potential: number;
  privilege_escalation_probability: number;
  overall_impact_score: number;
  business_impact_score: number;
  recommended_severity: string;
  bounty_range_estimate: string;
  affected_users_estimate: string;
  attack_chain_steps: string[];
  simulation_narrative: string;
  skill_level_required: string;
  time_to_exploit_estimate: string;
}

const SEV_STYLES: Record<string, string> = {
  critical: "text-red-400",
  high: "text-bmx-orange",
  medium: "text-bmx-yellow",
  low: "text-blue-400",
  info: "text-bmx-muted",
};

function ScoreBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div>
      <div className="flex justify-between mb-1">
        <span className="text-bmx-muted text-xs font-mono">{label}</span>
        <span className={`text-xs font-mono ${color}`}>{Math.round(value * 100)}%</span>
      </div>
      <div className="h-1.5 bg-bmx-border rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{ width: `${value * 100}%`, backgroundColor: color === "text-red-400" ? "#ff3366" : color === "text-bmx-orange" ? "#ff6b35" : "#00e5ff" }}
        />
      </div>
    </div>
  );
}

export default function CourtroomPage() {
  const { vulns, fetchVulns, activeWorkspace , fetchWorkspaces} = useAppStore();
  const [selectedVulnId, setSelectedVulnId] = useState<string>("");
  const [verdict, setVerdict] = useState<CourtVerdict | null>(null);
  const [simulation, setSimulation] = useState<Simulation | null>(null);
  const [loading, setLoading] = useState(false);
  const [simLoading, setSimLoading] = useState(false);
  const [search, setSearch] = useState("");


  useEffect(() => {
    if (!activeWorkspace) fetchWorkspaces();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (activeWorkspace) fetchVulns({ workspace_id: activeWorkspace.id });
  }, [activeWorkspace]);

  const adjudicate = async () => {
    if (!selectedVulnId) return;
    setLoading(true);
    setVerdict(null);
    setSimulation(null);
    try {
      const token = localStorage.getItem("bmx_access_token");
      const base = process.env.NEXT_PUBLIC_API_URL || "";

      const [vRes, sRes] = await Promise.all([
        fetch(`${base}/api/v1/intel/court/adjudicate/${selectedVulnId}`, {
          method: "POST",
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch(`${base}/api/v1/intel/simulate/${selectedVulnId}`, {
          method: "POST",
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      if (vRes.ok) {
        const data = await vRes.json();
        setVerdict(data.verdict);
      }
      if (sRes.ok) {
        const data = await sRes.json();
        setSimulation(data.simulation);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const filteredVulns = vulns.filter((v) =>
    !search || v.title.toLowerCase().includes(search.toLowerCase())
  );

  const selectedVuln = vulns.find((v) => v.id === selectedVulnId);

  return (
    <div className="p-6 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white font-mono text-xl font-bold flex items-center gap-2">
            <Scale className="w-5 h-5 text-bmx-cyan" />
            AI VALIDATION COURT
          </h1>
          <p className="text-bmx-muted text-sm font-mono mt-0.5">
            5-agent adversarial validation · Prosecution · Defense · Judge
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Vuln selector */}
        <div className="bmx-panel rounded-lg border border-bmx-border">
          <div className="p-3 border-b border-bmx-border">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-bmx-muted" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search findings..."
                className="w-full bg-bmx-black border border-bmx-border rounded pl-8 pr-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-bmx-cyan"
              />
            </div>
          </div>
          <div className="overflow-y-auto max-h-[500px] divide-y divide-bmx-border">
            {filteredVulns.map((v) => (
              <div
                key={v.id}
                onClick={() => setSelectedVulnId(v.id)}
                className={`px-3 py-2.5 cursor-pointer transition-colors ${
                  selectedVulnId === v.id ? "bg-bmx-cyan/5 border-l-2 border-bmx-cyan" : "hover:bg-bmx-panel/50"
                }`}
              >
                <p className="text-white font-mono text-xs truncate">{v.title}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className={`text-xs font-mono ${SEV_STYLES[v.severity]}`}>
                    {v.severity}
                  </span>
                  <span className="text-bmx-muted text-xs font-mono">{v.vuln_type}</span>
                </div>
              </div>
            ))}
            {filteredVulns.length === 0 && (
              <div className="px-3 py-8 text-center text-bmx-muted font-mono text-xs">No findings</div>
            )}
          </div>
          <div className="p-3 border-t border-bmx-border">
            <button
              onClick={adjudicate}
              disabled={loading || !selectedVulnId}
              className="w-full bg-bmx-cyan text-bmx-black font-mono font-bold text-xs py-2 rounded hover:bg-bmx-cyan/90 transition-colors disabled:opacity-50"
            >
              {loading ? "COURT IN SESSION..." : "CONVENE COURT →"}
            </button>
          </div>
        </div>

        {/* Court verdict */}
        <div className="lg:col-span-2 space-y-4">
          {loading && (
            <div className="bmx-panel rounded-lg border border-bmx-border px-4 py-12 text-center">
              <Scale className="w-8 h-8 text-bmx-cyan/30 mx-auto mb-3 animate-pulse" />
              <p className="text-bmx-cyan font-mono text-sm animate-pulse">Court in session...</p>
              <p className="text-bmx-muted font-mono text-xs mt-1">5 agents deliberating</p>
            </div>
          )}

          {verdict && !loading && (
            <>
              {/* Verdict banner */}
              <div className={`bmx-panel rounded-lg border p-4 ${
                verdict.is_valid ? "border-bmx-green/30 bg-bmx-green/5" : "border-bmx-red/30 bg-bmx-red/5"
              }`}>
                <div className="flex items-center gap-3 mb-3">
                  {verdict.is_valid
                    ? <CheckCircle className="w-5 h-5 text-bmx-green" />
                    : <XCircle className="w-5 h-5 text-bmx-red" />
                  }
                  <span className={`font-mono text-lg font-bold ${verdict.is_valid ? "text-bmx-green" : "text-bmx-red"}`}>
                    VERDICT: {verdict.is_valid ? "VALID FINDING" : "INVALID / FALSE POSITIVE"}
                  </span>
                </div>
                {verdict.downgrade_reason && (
                  <div className="bg-bmx-yellow/10 border border-bmx-yellow/30 rounded px-3 py-2 text-bmx-yellow text-xs font-mono">
                    ⚠ AUTO-DOWNGRADED: {verdict.downgrade_reason}
                  </div>
                )}
              </div>

              {/* Score cards */}
              <div className="grid grid-cols-4 gap-3">
                {[
                  { label: "CONFIDENCE", value: verdict.final_confidence, color: "text-bmx-cyan", fmt: (v: number) => `${Math.round(v * 100)}%` },
                  { label: "EXPLOITABILITY", value: verdict.exploitability_score / 10, color: "text-bmx-red", fmt: (v: number) => `${(v * 10).toFixed(1)}/10` },
                  { label: "BOUNTY LIKELY", value: verdict.bounty_likelihood, color: "text-bmx-green", fmt: (v: number) => `${Math.round(v * 100)}%` },
                  { label: "DUP RISK", value: verdict.duplicate_risk, color: "text-bmx-yellow", fmt: (v: number) => `${Math.round(v * 100)}%` },
                ].map((s) => (
                  <div key={s.label} className="bmx-panel rounded-lg border border-bmx-border p-3 text-center">
                    <div className={`text-xl font-mono font-bold ${s.color}`}>{s.fmt(s.value)}</div>
                    <div className="text-bmx-muted text-xs font-mono mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>

              {/* Court arguments */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bmx-panel rounded-lg border border-bmx-green/20 p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <User className="w-3.5 h-3.5 text-bmx-green" />
                    <span className="text-bmx-green font-mono text-xs tracking-wider">PROSECUTION</span>
                  </div>
                  <p className="text-white font-mono text-xs leading-relaxed">{verdict.prosecution_summary}</p>
                </div>
                <div className="bmx-panel rounded-lg border border-bmx-red/20 p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Shield className="w-3.5 h-3.5 text-bmx-red" />
                    <span className="text-bmx-red font-mono text-xs tracking-wider">DEFENSE</span>
                  </div>
                  <p className="text-white font-mono text-xs leading-relaxed">{verdict.defense_summary}</p>
                </div>
              </div>

              {/* Judge's ruling */}
              <div className="bmx-panel rounded-lg border border-bmx-cyan/20 p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Gavel className="w-4 h-4 text-bmx-cyan" />
                  <span className="text-bmx-cyan font-mono text-xs tracking-wider">JUDGE&apos;S RULING</span>
                  <span className={`ml-auto text-xs font-mono ${SEV_STYLES[verdict.severity_recommendation]}`}>
                    → {verdict.severity_recommendation.toUpperCase()}
                  </span>
                </div>
                <p className="text-white font-mono text-xs leading-relaxed">{verdict.judge_reasoning}</p>
                {verdict.recommended_actions.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-bmx-border">
                    <p className="text-bmx-muted text-xs font-mono mb-1.5">REQUIRED ACTIONS:</p>
                    <ul className="space-y-1">
                      {verdict.recommended_actions.map((a, i) => (
                        <li key={i} className="text-bmx-yellow text-xs font-mono flex items-center gap-1.5">
                          <AlertTriangle className="w-3 h-3 shrink-0" />{a}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </>
          )}

          {simulation && !loading && (
            <div className="bmx-panel rounded-lg border border-bmx-border p-4">
              <div className="flex items-center gap-2 mb-4">
                <Eye className="w-4 h-4 text-bmx-orange" />
                <span className="text-white font-mono text-xs tracking-wider">EXPLOITABILITY SIMULATION</span>
                <span className="ml-auto text-bmx-green text-xs font-mono">{simulation.bounty_range_estimate}</span>
              </div>

              <div className="space-y-2 mb-4">
                <ScoreBar label="Account Takeover" value={simulation.account_takeover_likelihood} color="text-red-400" />
                <ScoreBar label="Data Exposure" value={simulation.data_exposure_scale} color="text-bmx-orange" />
                <ScoreBar label="Lateral Movement" value={simulation.lateral_movement_potential} color="text-bmx-yellow" />
                <ScoreBar label="Cloud Compromise" value={simulation.cloud_compromise_potential} color="text-bmx-red" />
                <ScoreBar label="Privilege Escalation" value={simulation.privilege_escalation_probability} color="text-bmx-orange" />
              </div>

              {simulation.simulation_narrative && (
                <div className="bg-bmx-black/50 rounded border border-bmx-border p-3">
                  <p className="text-white font-mono text-xs leading-relaxed">{simulation.simulation_narrative}</p>
                  <p className="text-bmx-muted text-xs font-mono mt-2">
                    Skill: {simulation.skill_level_required} · Time: {simulation.time_to_exploit_estimate} · Affected: {simulation.affected_users_estimate}
                  </p>
                </div>
              )}
            </div>
          )}

          {!verdict && !loading && (
            <div className="bmx-panel rounded-lg border border-bmx-border px-4 py-12 text-center">
              <Scale className="w-8 h-8 text-bmx-muted/20 mx-auto mb-3" />
              <p className="text-bmx-muted font-mono text-sm">Select a finding and convene the court</p>
              <p className="text-bmx-muted/50 text-xs font-mono mt-1">5 AI agents will debate validity, scope, evidence, and impact</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
