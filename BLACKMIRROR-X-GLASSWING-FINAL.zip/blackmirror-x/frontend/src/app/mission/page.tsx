"use client";
/**
 * Mission Control — BLACKMIRROR-X GLASSWING
 *
 * Mythos AI-inspired: live streaming AI reasoning trace.
 * The agent's thinking process is visible token-by-token as it runs.
 * Shows: hypotheses, reasoning steps, attack chains, bounty estimates.
 *
 * XBOW-inspired: shows verified vs possible findings with confidence scores.
 * Hacktron-inspired: shows which agents are running in parallel.
 */
import { useEffect, useRef, useState, useCallback } from "react";
import { useAppStore } from "@/store/app";
import { getToken } from "@/lib/api";
import {
  Brain, Target, Shield, Zap, Eye, ChevronRight,
  TrendingUp, AlertCircle, CheckCircle, XCircle,
  Activity, Cpu, GitBranch, Layers, Play, RefreshCw,
  Wifi, WifiOff, ArrowRight, Terminal, Lock, Unlock
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────

interface Hypothesis {
  id: string;
  title: string;
  description: string;
  vuln_class: string;
  confidence: number;
  priority_score: number;
  status: string;
  bounty_estimate: string;
  reasoning: string;
  evidence: string[];
  assumptions: string[];
}

interface ReasoningStep {
  id: string;
  step_type: string;
  content: string;
  confidence: number;
  payload_rationale?: string;
  target_rationale?: string;
  assumptions?: string[];
  evidence_refs?: string[];
  agent_id: string;
  timestamp: number;
}

// Parsed from scan logs tagged with "reasoning:" module prefix
interface ParsedThought {
  id: string;
  type: string;
  content: string;
  confidence?: number;
  timestamp: string;
  agent: string;
  verified?: boolean;
}

// ── Config ────────────────────────────────────────────────────────────────────

const STEP_STYLES: Record<string, string> = {
  hypothesis:           "text-bmx-cyan   border-bmx-cyan/30   bg-bmx-cyan/5",
  evidence:             "text-bmx-green  border-bmx-green/30  bg-bmx-green/5",
  decision:             "text-bmx-yellow border-bmx-yellow/30 bg-bmx-yellow/5",
  escalate:             "text-red-400    border-red-400/30    bg-red-400/5",
  abandon:              "text-bmx-muted  border-bmx-border    bg-transparent",
  payload_selection:    "text-bmx-orange border-bmx-orange/30 bg-bmx-orange/5",
  target_prioritization:"text-bmx-teal   border-bmx-teal/30   bg-bmx-teal/5",
  conclusion:           "text-bmx-green  border-bmx-green/50  bg-bmx-green/10",
  observation:          "text-gray-400   border-bmx-border    bg-transparent",
  verified:             "text-bmx-green  border-bmx-green/60  bg-bmx-green/10",
};

const STEP_EMOJI: Record<string, string> = {
  hypothesis: "🧠", evidence: "📌", decision: "⚡", escalate: "🔥",
  abandon: "🚫", payload_selection: "🎯", conclusion: "✅",
  observation: "→", verified: "✓✓", target_prioritization: "🗺",
};

const STATUS_CONFIG: Record<string, { icon: React.ReactNode; color: string }> = {
  active:    { icon: <Activity className="w-3 h-3 text-bmx-cyan animate-pulse" />, color: "text-bmx-cyan" },
  confirmed: { icon: <CheckCircle className="w-3 h-3 text-bmx-green" />, color: "text-bmx-green" },
  verified:  { icon: <Shield className="w-3 h-3 text-bmx-green" />, color: "text-bmx-green" },
  abandoned: { icon: <XCircle className="w-3 h-3 text-bmx-muted" />, color: "text-bmx-muted" },
  escalated: { icon: <Zap className="w-3 h-3 text-red-400" />, color: "text-red-400" },
  testing:   { icon: <Eye className="w-3 h-3 text-bmx-yellow animate-pulse" />, color: "text-bmx-yellow" },
};

const VULN_COLORS: Record<string, string> = {
  xss: "text-red-400", sqli: "text-orange-400", ssrf: "text-yellow-400",
  ssti: "text-purple-400", idor: "text-blue-400", cors: "text-bmx-teal",
  jwt_vulnerability: "text-bmx-green", race_condition: "text-pink-400",
  auth_bypass: "text-bmx-red", graphql: "text-pink-300",
  secret_exposure: "text-bmx-orange", oauth_misconfiguration: "text-yellow-300",
};

// ── Parsing helpers ───────────────────────────────────────────────────────────

function parseLogAsThought(log: {
  id: string; module: string; message: string;
  level: string; timestamp?: string;
}): ParsedThought | null {
  if (!log.module?.startsWith("reasoning:") && !log.module?.startsWith("ai_hypothesis")) {
    return null;
  }
  const type = log.module.startsWith("reasoning:")
    ? log.module.replace("reasoning:", "")
    : "hypothesis";
  return {
    id: log.id,
    type,
    content: log.message.replace(/^[🧠📌⚡🔥🚫🎯✅→✓✓🗺]\s*/, ""),
    timestamp: log.timestamp || new Date().toISOString(),
    agent: "glasswing_ai",
    verified: type === "verified" || log.message.includes("VERIFIED"),
  };
}

// ── Main component ────────────────────────────────────────────────────────────

export default function MissionControlPage() {
  const { scans, activeWorkspace, fetchScans, fetchWorkspaces } = useAppStore();
  const [selectedScan, setSelectedScan] = useState("");
  const [hypotheses, setHypotheses] = useState<Hypothesis[]>([]);
  const [reasoningSteps, setReasoningSteps] = useState<ReasoningStep[]>([]);
  const [thoughts, setThoughts] = useState<ParsedThought[]>([]);
  const [logs, setLogs] = useState<{ id: string; module: string; message: string; level: string; timestamp?: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const [streaming, setStreaming] = useState(false);
  const [activeTab, setActiveTab] = useState<"thinking" | "hypotheses" | "reasoning" | "chains">("thinking");
  const [chains, setChains] = useState<{ title: string; steps: string[]; severity: string }[]>([]);
  const [agentsRunning, setAgentsRunning] = useState<string[]>([]);
  const thoughtsRef = useRef<HTMLDivElement>(null);
  const esRef = useRef<EventSource | null>(null);
  const alive = useRef(true);

  useEffect(() => {
    alive.current = true;
    if (!activeWorkspace) fetchWorkspaces();
    return () => { alive.current = false; esRef.current?.close(); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (activeWorkspace) fetchScans(activeWorkspace.id);
  }, [activeWorkspace]); // eslint-disable-line react-hooks/exhaustive-deps

  // Auto-scroll thinking panel
  useEffect(() => {
    if (thoughtsRef.current) {
      thoughtsRef.current.scrollTop = thoughtsRef.current.scrollHeight;
    }
  }, [thoughts]);

  // Start streaming thinking trace from running scan
  const streamThinking = useCallback((scanId: string) => {
    esRef.current?.close();
    if (!scanId) return;

    const token = getToken();
    const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    const url = `${BASE}/api/v1/scans/${scanId}/stream?token=${encodeURIComponent(token || "")}`;

    const es = new EventSource(url);
    esRef.current = es;
    setStreaming(true);

    es.onmessage = (e) => {
      if (!alive.current) return;
      try {
        const data = JSON.parse(e.data);
        if (data.type === "done") {
          setStreaming(false);
          es.close();
          esRef.current = null;
          loadScanData(scanId);
          return;
        }
        if (data.message || data.level) {
          const log = {
            id: data.id || String(Date.now()),
            module: data.module || "",
            message: data.message || "",
            level: data.level || "info",
            timestamp: data.timestamp,
          };
          setLogs(prev => [...prev.slice(-999), log]);

          // Parse reasoning thoughts
          const thought = parseLogAsThought(log);
          if (thought) {
            setThoughts(prev => [...prev.slice(-199), thought]);
          }

          // Track active agents from module names
          if (data.module) {
            const agent = data.module.split(":")[0];
            setAgentsRunning(prev =>
              prev.includes(agent) ? prev : [...prev.slice(-7), agent]
            );
          }
        }
      } catch {}
    };

    es.onerror = () => {
      setStreaming(false);
      es.close();
      esRef.current = null;
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const loadScanData = useCallback(async (scanId: string) => {
    if (!scanId) return;
    setLoading(true);
    const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    const token = getToken();
    const headers = { Authorization: `Bearer ${token}` };

    try {
      // Load hypotheses
      const hyp = await fetch(`${BASE}/api/v1/intel/hypotheses/generate/${scanId}`, { method: "POST", headers });
      if (hyp.ok) {
        const data = await hyp.json();
        setHypotheses(data.hypotheses || []);
        setReasoningSteps(data.reasoning_steps || []);
      }

      // Load scan logs to extract thinking
      const logsRes = await fetch(`${BASE}/api/v1/scans/${scanId}/logs?limit=500`, { headers });
      if (logsRes.ok) {
        const logsData = await logsRes.json();
        setLogs(logsData);
        const extracted = logsData
          .map((l: { id: string; module: string; message: string; level: string; timestamp?: string }) => parseLogAsThought(l))
          .filter(Boolean) as ParsedThought[];
        setThoughts(extracted);
      }

      // Build attack chains from hypotheses
      if (hypotheses.length > 1) {
        const chainGroups: Record<string, Hypothesis[]> = {};
        for (const h of hypotheses) {
          const g = h.vuln_class.includes("xss") || h.vuln_class.includes("sqli") ? "webattack" : "recon";
          if (!chainGroups[g]) chainGroups[g] = [];
          chainGroups[g].push(h);
        }
        setChains(Object.entries(chainGroups).map(([type, hyps]) => ({
          title: type === "webattack" ? "Web Application Attack Chain" : "Recon → Exploitation Chain",
          steps: hyps.slice(0, 4).map(h => h.title),
          severity: hyps[0].vuln_class,
        })));
      }
    } catch {}
    setLoading(false);
  }, [hypotheses]);

  const handleScanSelect = (scanId: string) => {
    setSelectedScan(scanId);
    setHypotheses([]);
    setReasoningSteps([]);
    setThoughts([]);
    setLogs([]);
    setAgentsRunning([]);

    const scan = scans.find(s => s.id === scanId);
    if (scan?.status === "running" || scan?.status === "queued") {
      streamThinking(scanId);
    } else {
      loadScanData(scanId);
    }
  };

  const selectedScanData = scans.find(s => s.id === selectedScan);
  const isActive = selectedScanData?.status === "running" || selectedScanData?.status === "queued";

  const TABS = [
    { id: "thinking",   label: "AI THINKING",    icon: <Brain className="w-3.5 h-3.5" />,   count: thoughts.length },
    { id: "hypotheses", label: "HYPOTHESES",      icon: <Target className="w-3.5 h-3.5" />,  count: hypotheses.length },
    { id: "reasoning",  label: "REASONING TRACE", icon: <Layers className="w-3.5 h-3.5" />, count: reasoningSteps.length },
    { id: "chains",     label: "ATTACK CHAINS",   icon: <GitBranch className="w-3.5 h-3.5" />, count: chains.length },
  ] as const;

  return (
    <div className="h-full flex flex-col">
      {/* ── Header ──────────────────────────────────────────────── */}
      <div className="shrink-0 border-b border-bmx-border px-6 py-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h1 className="text-white font-mono text-lg font-bold flex items-center gap-2">
              <Brain className="w-5 h-5 text-bmx-cyan" />
              MISSION CONTROL
            </h1>
            <p className="text-bmx-muted font-mono text-xs mt-0.5">
              Live AI reasoning · Hypothesis board · Attack chain discovery
            </p>
          </div>
          <div className="flex items-center gap-3">
            {streaming && (
              <div className="flex items-center gap-1.5 border border-bmx-green/30 bg-bmx-green/5 rounded px-3 py-1.5">
                <Wifi className="w-3.5 h-3.5 text-bmx-green" />
                <span className="text-bmx-green font-mono text-xs">AI THINKING LIVE</span>
              </div>
            )}
            {agentsRunning.length > 0 && (
              <div className="flex items-center gap-1.5 text-xs font-mono text-bmx-muted/60">
                <Cpu className="w-3.5 h-3.5 text-bmx-cyan" />
                {agentsRunning.slice(-3).join(" · ")}
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={selectedScan}
            onChange={e => handleScanSelect(e.target.value)}
            className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan"
          >
            <option value="">Select a scan to analyze...</option>
            {scans.map(s => (
              <option key={s.id} value={s.id}>
                {s.target || s.name} — {s.status.toUpperCase()} · {new Date(s.created_at).toLocaleDateString()}
              </option>
            ))}
          </select>
          {selectedScan && !loading && (
            <button
              onClick={() => loadScanData(selectedScan)}
              className="flex items-center gap-1.5 border border-bmx-border text-bmx-muted hover:text-white px-3 py-2 rounded text-xs font-mono transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Reload
            </button>
          )}
        </div>

        {/* Tab bar */}
        <div className="flex gap-1 mt-3">
          {TABS.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono tracking-wider border-b-2 transition-colors ${
                activeTab === tab.id
                  ? "text-bmx-cyan border-bmx-cyan"
                  : "text-bmx-muted border-transparent hover:text-white"
              }`}>
              {tab.icon}
              {tab.label}
              {tab.count > 0 && (
                <span className="text-[9px] bg-bmx-border text-bmx-muted px-1 rounded">
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* ── Content ─────────────────────────────────────────────── */}
      <div className="flex-1 overflow-hidden">

        {/* ══ AI THINKING TAB (Mythos-style live reasoning) ══ */}
        {activeTab === "thinking" && (
          <div className="h-full flex flex-col">
            <div className="shrink-0 px-6 py-2 flex items-center justify-between border-b border-bmx-border/50">
              <span className="text-bmx-muted/50 font-mono text-[10px] tracking-wider">
                GLASSWING AI REASONING TRACE — {thoughts.length} thoughts
              </span>
              {isActive && (
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-bmx-green animate-pulse" />
                  <span className="text-bmx-green font-mono text-[10px]">LIVE</span>
                </div>
              )}
            </div>

            <div ref={thoughtsRef}
              className="flex-1 overflow-y-auto px-6 py-4 space-y-2 font-mono text-xs">

              {!selectedScan && (
                <div className="text-center py-16 space-y-3">
                  <Brain className="w-10 h-10 text-bmx-cyan/20 mx-auto" />
                  <p className="text-bmx-muted/40">
                    Select a scan to watch GLASSWING AI think in real-time
                  </p>
                  <p className="text-bmx-muted/20 text-[10px]">
                    Inspired by Mythos AI — every reasoning step streamed live
                  </p>
                </div>
              )}

              {selectedScan && thoughts.length === 0 && !isActive && (
                <div className="text-center py-16 space-y-2">
                  <Terminal className="w-8 h-8 text-bmx-muted/20 mx-auto" />
                  <p className="text-bmx-muted/40">
                    No reasoning trace for this scan yet.
                  </p>
                  <p className="text-bmx-muted/20 text-[10px]">
                    Reasoning trace is generated during active scans.
                    Start a new scan to see live AI thinking.
                  </p>
                </div>
              )}

              {/* Live scan log feed when streaming (shows ALL logs, highlights reasoning) */}
              {isActive && logs.length > 0 && (
                <div className="space-y-1 mb-4">
                  {logs.slice(-100).map((log, i) => {
                    const isThought = log.module?.startsWith("reasoning:") ||
                      log.module?.startsWith("ai_hypothesis");
                    const isSuccess = log.level === "success";
                    const isError = log.level === "error" || log.level === "warn";
                    return (
                      <div key={log.id || i}
                        className={`flex gap-2 items-start py-0.5 px-2 rounded -mx-2 ${
                          isThought ? "bg-bmx-cyan/5 border border-bmx-cyan/10" : ""
                        }`}>
                        <span className="text-bmx-muted/30 shrink-0 w-14 text-right tabular-nums text-[10px]">
                          {log.timestamp ? new Date(log.timestamp).toLocaleTimeString([], {hour12: false}) : "──:──:──"}
                        </span>
                        <span className={`shrink-0 w-20 truncate text-[10px] ${
                          isThought ? "text-bmx-cyan/50" :
                          isSuccess ? "text-bmx-green/50" :
                          isError ? "text-bmx-red/50" : "text-bmx-muted/30"
                        }`}>[{(log.module || "").slice(0, 16)}]</span>
                        <span className={`flex-1 break-all leading-5 ${
                          isThought ? "text-bmx-cyan" :
                          isSuccess ? "text-bmx-green" :
                          isError ? "text-bmx-yellow" : "text-gray-400"
                        }`}>{log.message}</span>
                      </div>
                    );
                  })}
                  <div className="flex items-center gap-1.5 text-bmx-cyan/30 py-1">
                    <span className="inline-block w-1.5 h-4 bg-bmx-cyan/50 animate-pulse rounded-sm" />
                    <span className="text-[10px]">thinking...</span>
                  </div>
                </div>
              )}

              {/* Post-scan: extracted thoughts only */}
              {!isActive && thoughts.map((t, i) => {
                const style = STEP_STYLES[t.type] || STEP_STYLES.observation;
                const emoji = STEP_EMOJI[t.type] || "→";
                return (
                  <div key={t.id || i}
                    className={`border rounded px-3 py-2 ${style}`}>
                    <div className="flex items-start gap-2">
                      <span className="shrink-0 text-sm mt-0.5">{emoji}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[9px] tracking-wider opacity-60 uppercase">{t.type}</span>
                          {t.confidence != null && (
                            <span className="text-[9px] opacity-50">
                              {Math.round(t.confidence * 100)}%
                            </span>
                          )}
                          {t.verified && (
                            <span className="text-[9px] text-bmx-green border border-bmx-green/30 px-1 rounded">
                              VERIFIED
                            </span>
                          )}
                        </div>
                        <p className="leading-5 break-all">{t.content}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ══ HYPOTHESES TAB (ranked vuln predictions) ══ */}
        {activeTab === "hypotheses" && (
          <div className="h-full overflow-y-auto p-6 space-y-3">
            {loading && (
              <div className="text-center py-12 text-bmx-muted font-mono text-sm">
                <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2" />
                Generating hypotheses...
              </div>
            )}
            {!loading && hypotheses.length === 0 && (
              <div className="text-center py-12 space-y-2">
                <Brain className="w-8 h-8 text-bmx-muted/20 mx-auto" />
                <p className="text-bmx-muted/40 font-mono text-sm">
                  {selectedScan ? "No hypotheses generated yet" : "Select a scan first"}
                </p>
              </div>
            )}
            {hypotheses.map(h => {
              const sc = STATUS_CONFIG[h.status] || STATUS_CONFIG.active;
              const vcolor = VULN_COLORS[h.vuln_class] || "text-bmx-muted";
              return (
                <div key={h.id}
                  className="bmx-panel rounded-xl border border-bmx-border p-5 hover:border-bmx-cyan/20 transition-colors">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <span className={sc.color}>{sc.icon}</span>
                      <h3 className="text-white font-mono text-sm font-medium truncate">{h.title}</h3>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className={`text-xs font-mono font-bold ${vcolor}`}>
                        {h.vuln_class.toUpperCase()}
                      </span>
                      <span className="text-bmx-muted font-mono text-xs">
                        {Math.round(h.confidence * 100)}%
                      </span>
                    </div>
                  </div>

                  <p className="text-bmx-muted/70 font-mono text-xs leading-relaxed mb-3">
                    {h.description}
                  </p>

                  {/* Evidence + bounty */}
                  <div className="flex items-center justify-between pt-3 border-t border-bmx-border/50">
                    <div className="flex gap-3 text-[10px] font-mono text-bmx-muted/50">
                      <span>Priority: #{h.priority_score?.toFixed(0)}</span>
                      {h.evidence?.length > 0 && <span>{h.evidence.length} evidence</span>}
                    </div>
                    {h.bounty_estimate && (
                      <span className="text-bmx-green font-mono text-xs font-bold border border-bmx-green/30 px-2 py-0.5 rounded bg-bmx-green/5">
                        {h.bounty_estimate}
                      </span>
                    )}
                  </div>

                  {h.reasoning && (
                    <div className="mt-3 pt-3 border-t border-bmx-border/50">
                      <p className="text-bmx-cyan/50 font-mono text-[10px] mb-1 tracking-wider">
                        AI REASONING
                      </p>
                      <p className="text-bmx-muted/60 font-mono text-xs leading-relaxed">
                        {h.reasoning}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* ══ REASONING TRACE TAB ══ */}
        {activeTab === "reasoning" && (
          <div className="h-full overflow-y-auto p-6 space-y-2 font-mono text-xs">
            {reasoningSteps.length === 0 && (
              <div className="text-center py-12 text-bmx-muted/40">
                {selectedScan ? "No reasoning trace available" : "Select a scan first"}
              </div>
            )}
            {reasoningSteps.map((step, i) => {
              const style = STEP_STYLES[step.step_type] || STEP_STYLES.observation;
              const emoji = STEP_EMOJI[step.step_type] || "→";
              return (
                <div key={step.id || i} className={`border rounded px-3 py-2.5 ${style}`}>
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-sm">{emoji}</span>
                    <span className="tracking-wider text-[9px] opacity-60 uppercase">{step.step_type}</span>
                    <span className="ml-auto text-[9px] opacity-40">
                      {Math.round(step.confidence * 100)}% conf
                    </span>
                    <span className="text-[9px] opacity-30">{step.agent_id}</span>
                  </div>
                  <p className="leading-relaxed break-all">{step.content}</p>
                  {step.payload_rationale && (
                    <p className="mt-1.5 text-[10px] opacity-60 italic">
                      Payload: {step.payload_rationale}
                    </p>
                  )}
                  {step.assumptions && step.assumptions.length > 0 && (
                    <div className="mt-1.5 flex gap-1 flex-wrap">
                      {step.assumptions.map((a, j) => (
                        <span key={j} className="text-[9px] border border-current/20 px-1.5 py-0.5 rounded opacity-50">
                          {a}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* ══ ATTACK CHAINS TAB ══ */}
        {activeTab === "chains" && (
          <div className="h-full overflow-y-auto p-6 space-y-4">
            {chains.length === 0 ? (
              <div className="text-center py-12 space-y-2">
                <GitBranch className="w-8 h-8 text-bmx-muted/20 mx-auto" />
                <p className="text-bmx-muted/40 font-mono text-sm">
                  {selectedScan
                    ? "No attack chains discovered — run a scan with multiple findings"
                    : "Select a scan to see attack chains"}
                </p>
              </div>
            ) : chains.map((chain, i) => (
              <div key={i} className="bmx-panel rounded-xl border border-bmx-border p-5">
                <div className="flex items-center gap-2 mb-4">
                  <GitBranch className="w-4 h-4 text-bmx-orange" />
                  <h3 className="text-white font-mono text-sm font-bold">{chain.title}</h3>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {chain.steps.map((step, j) => (
                    <div key={j} className="flex items-center gap-2">
                      <div className="border border-bmx-cyan/30 bg-bmx-cyan/5 rounded px-3 py-1.5">
                        <p className="text-white font-mono text-xs">{step}</p>
                      </div>
                      {j < chain.steps.length - 1 && (
                        <ArrowRight className="w-3.5 h-3.5 text-bmx-muted/40 shrink-0" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
