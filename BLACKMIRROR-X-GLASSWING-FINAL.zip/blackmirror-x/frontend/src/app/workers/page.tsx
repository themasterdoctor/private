"use client";
import { useEffect, useState } from "react";
import { Server, AlertTriangle, Play, Square, Activity, Clock } from "lucide-react";
import { useAppStore } from "@/store/app";

const API = process.env.NEXT_PUBLIC_API_URL || "";

interface WorkerStatus {
  worker_id: string; hostname: string; is_alive: boolean;
  current_scan_id: string; current_task: string;
  tasks_completed: number; tasks_failed: number;
  last_seen_ago_s: number; uptime_s: number;
}

interface ControlStatus {
  global_stop: boolean;
  paused_scans: string[];
  stopped_scans: string[];
  alive_workers: number;
  dead_workers: number;
  recent_actions: Array<{ action: string; scan_id?: string; timestamp: string }>;
}

export default function WorkersPage() {
  const { scans, activeWorkspace, fetchScans , fetchWorkspaces} = useAppStore();
  const [workers, setWorkers] = useState<WorkerStatus[]>([]);
  const [control, setControl] = useState<ControlStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");
  const [pauseScanId, setPauseScanId] = useState("");

  const getToken = () => localStorage.getItem("bmx_access_token") || "";


  useEffect(() => {
    if (!activeWorkspace) fetchWorkspaces();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (activeWorkspace) fetchScans(activeWorkspace.id);
    fetchStatus();
    const interval = setInterval(fetchStatus, 5000);
    return () => clearInterval(interval);
  }, [activeWorkspace]);

  async function fetchStatus() {
    try {
      const r = await fetch(`${API}/api/v1/workers/status`, {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      if (r.ok) {
        const d = await r.json();
        setWorkers(d.workers || []);
        setControl(d.control || null);
      }
    } catch {/* */}
  }

  async function action(endpoint: string, method = "POST") {
    setLoading(true); setMsg("");
    try {
      const r = await fetch(`${API}/api/v1/workers/${endpoint}`, {
        method,
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      const d = await r.json();
      setMsg(d.status || JSON.stringify(d));
      fetchStatus();
    } catch (e: unknown) { setMsg(String(e)); } finally { setLoading(false); }
  }

  async function pauseScan() {
    if (!pauseScanId) return;
    await action(`pause/${pauseScanId}`);
  }
  async function resumeScan() {
    if (!pauseScanId) return;
    await action(`resume/${pauseScanId}`);
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Server className="w-6 h-6 text-bmx-green" />
        <div>
          <h1 className="text-xl font-bold text-white font-mono">Distributed Workers</h1>
          <p className="text-xs text-bmx-muted">Worker health, scan control, emergency stop</p>
        </div>
      </div>

      {/* Global status */}
      {control && (
        <div className={`border rounded-lg p-4 ${control.global_stop
          ? "border-bmx-red/40 bg-bmx-red/5"
          : "border-bmx-green/30 bg-bmx-green/5"}`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {control.global_stop
                ? <AlertTriangle className="w-5 h-5 text-bmx-red" />
                : <Activity className="w-5 h-5 text-bmx-green" />}
              <div>
                <div className={`text-sm font-mono font-bold ${control.global_stop ? "text-bmx-red" : "text-bmx-green"}`}>
                  {control.global_stop ? "⚠ EMERGENCY STOP ACTIVE" : "System Operational"}
                </div>
                <div className="text-xs text-bmx-muted">
                  {control.alive_workers} alive · {control.dead_workers} dead ·
                  {control.paused_scans.length} paused · {control.stopped_scans.length} stopped
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => action("emergency-stop")}
                disabled={loading || control.global_stop}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono bg-bmx-red/10 text-bmx-red border border-bmx-red/30 rounded hover:bg-bmx-red/20 disabled:opacity-40 transition-colors"
              >
                <Square className="w-3 h-3" /> Emergency Stop
              </button>
              <button
                onClick={() => action("resume-all")}
                disabled={loading || !control.global_stop}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono bg-bmx-green/10 text-bmx-green border border-bmx-green/30 rounded hover:bg-bmx-green/20 disabled:opacity-40 transition-colors"
              >
                <Play className="w-3 h-3" /> Resume All
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Per-scan controls */}
      <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4 space-y-3">
        <div className="text-sm font-mono text-white">Per-Scan Control</div>
        <div className="flex gap-3">
          <select
            value={pauseScanId}
            onChange={(e) => setPauseScanId(e.target.value)}
            className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white focus:border-bmx-green outline-none"
          >
            <option value="">— select scan —</option>
            {scans.map((s) => (
              <option key={s.id} value={s.id}>{s.name || s.id.slice(0, 8)}</option>
            ))}
          </select>
          <button onClick={pauseScan} disabled={!pauseScanId || loading}
            className="px-3 py-2 text-xs font-mono bg-bmx-yellow/10 text-bmx-yellow border border-bmx-yellow/30 rounded hover:bg-bmx-yellow/20 disabled:opacity-40">
            Pause
          </button>
          <button onClick={resumeScan} disabled={!pauseScanId || loading}
            className="px-3 py-2 text-xs font-mono bg-bmx-green/10 text-bmx-green border border-bmx-green/30 rounded hover:bg-bmx-green/20 disabled:opacity-40">
            Resume
          </button>
        </div>
        {msg && <div className="text-xs text-bmx-green font-mono">{msg}</div>}
      </div>

      {/* Worker list */}
      <div className="bg-bmx-dark border border-bmx-border rounded-lg">
        <div className="px-4 py-3 border-b border-bmx-border flex items-center gap-2">
          <Server className="w-4 h-4 text-bmx-green" />
          <span className="text-sm font-mono text-white">Workers</span>
          <span className="text-xs text-bmx-muted ml-auto">{workers.length} registered</span>
        </div>
        {workers.length === 0 ? (
          <div className="text-center py-12">
            <Server className="w-8 h-8 text-bmx-border mx-auto mb-3" />
            <p className="text-bmx-muted text-sm">No workers registered</p>
            <p className="text-xs text-bmx-muted mt-1">
              Start a Celery worker: <span className="font-mono">celery -A app.workers.celery_app worker</span>
            </p>
          </div>
        ) : (
          <div className="divide-y divide-bmx-border">
            {workers.map((w) => (
              <div key={w.worker_id} className="px-4 py-3 flex items-center gap-4">
                <div className={`w-2 h-2 rounded-full flex-shrink-0 ${w.is_alive ? "bg-bmx-green" : "bg-bmx-red"}`} />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-mono text-white truncate">{w.worker_id}</div>
                  <div className="text-xs text-bmx-muted">
                    {w.hostname} · {w.current_task || "idle"}
                  </div>
                </div>
                <div className="flex items-center gap-4 text-xs text-right flex-shrink-0">
                  <div>
                    <div className="text-bmx-green font-mono">{w.tasks_completed}</div>
                    <div className="text-bmx-muted">completed</div>
                  </div>
                  <div>
                    <div className={`font-mono ${w.tasks_failed > 0 ? "text-bmx-red" : "text-bmx-muted"}`}>
                      {w.tasks_failed}
                    </div>
                    <div className="text-bmx-muted">failed</div>
                  </div>
                  <div className="flex items-center gap-1 text-bmx-muted">
                    <Clock className="w-3 h-3" />
                    {w.last_seen_ago_s.toFixed(0)}s ago
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Recent audit actions */}
      {control?.recent_actions && control.recent_actions.length > 0 && (
        <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4">
          <div className="text-sm font-mono text-white mb-3">Recent Control Actions</div>
          <div className="space-y-1 font-mono">
            {[...control.recent_actions].reverse().slice(0, 8).map((a, i) => (
              <div key={i} className="flex items-center gap-3 text-xs">
                <span className="text-bmx-muted">{a.timestamp.slice(11, 19)}</span>
                <span className="text-bmx-cyan">{a.action}</span>
                {a.scan_id && <span className="text-bmx-muted">{a.scan_id.slice(0, 8)}</span>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
