"use client";
import { useState } from "react";
import { Link2, Users, Code2, FileCode, AlertTriangle, CheckCircle } from "lucide-react";

const API = process.env.NEXT_PUBLIC_API_URL || "";

export default function APIIntelPage() {
  const [activeTab, setActiveTab] = useState<"idor" | "rolediff" | "graphql" | "openapi">("idor");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState("");

  // IDOR state
  const [observeMethod, setObserveMethod] = useState("GET");
  const [observeUrl, setObserveUrl] = useState("/api/users/1");
  const [observeBody, setObserveBody] = useState('{"id":"1","email":"user@test.com"}');

  // Role diff state
  const [diffUrls, setDiffUrls] = useState("/api/users/1\n/api/admin/users");
  const [adminToken, setAdminToken] = useState("");
  const [userToken, setUserToken] = useState("");
  const [baseUrl, setBaseUrl] = useState("http://localhost:9001");

  // GraphQL state
  const [gqlUrl, setGqlUrl] = useState("http://localhost:9001/api/graphql");

  // OpenAPI state
  const [specUrl, setSpecUrl] = useState("/openapi.json");

  const getToken = () => localStorage.getItem("bmx_access_token") || "";

  async function runIdorScan() {
    setLoading(true); setError(""); setResult(null);
    try {
      let responseBody: unknown = {};
      try { responseBody = JSON.parse(observeBody); } catch { responseBody = {}; }
      const r = await fetch(`${API}/api/v1/api-intel/observe`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken()}`, "Content-Type": "application/json" },
        body: JSON.stringify({ method: observeMethod, url: observeUrl, response: responseBody }),
      });
      if (!r.ok) throw new Error(await r.text());
      setResult(await r.json());
    } catch (e: unknown) { setError(String(e)); } finally { setLoading(false); }
  }

  async function runRoleDiff() {
    setLoading(true); setError(""); setResult(null);
    try {
      const urls = diffUrls.split("\n").map((u) => u.trim()).filter(Boolean);
      const tokens: Record<string, string> = {};
      if (adminToken) tokens.admin = adminToken;
      if (userToken) tokens.user = userToken;
      if (Object.keys(tokens).length < 2) throw new Error("Need both admin and user tokens");
      const r = await fetch(`${API}/api/v1/api-intel/role-diff`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken()}`, "Content-Type": "application/json" },
        body: JSON.stringify({ urls, tokens, base_url: baseUrl }),
      });
      if (!r.ok) throw new Error(await r.text());
      setResult(await r.json());
    } catch (e: unknown) { setError(String(e)); } finally { setLoading(false); }
  }

  async function runGraphQLAnalysis() {
    setLoading(true); setError(""); setResult(null);
    try {
      const r = await fetch(`${API}/api/v1/api-intel/graphql-analyze?url=${encodeURIComponent(gqlUrl)}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      if (!r.ok) throw new Error(await r.text());
      setResult(await r.json());
    } catch (e: unknown) { setError(String(e)); } finally { setLoading(false); }
  }

  async function runOpenAPIAnalysis() {
    setLoading(true); setError(""); setResult(null);
    try {
      const fullUrl = specUrl.startsWith("http") ? specUrl : `${baseUrl}${specUrl}`;
      const r = await fetch(`${API}/api/v1/api-intel/openapi-analyze?spec_url=${encodeURIComponent(fullUrl)}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      if (!r.ok) throw new Error(await r.text());
      setResult(await r.json());
    } catch (e: unknown) { setError(String(e)); } finally { setLoading(false); }
  }

  const tabs = [
    { id: "idor", label: "IDOR Detection", icon: AlertTriangle },
    { id: "rolediff", label: "Role Diff", icon: Users },
    { id: "graphql", label: "GraphQL", icon: Code2 },
    { id: "openapi", label: "OpenAPI", icon: FileCode },
  ] as const;

  const findings = (result as { findings?: unknown[] })?.findings as unknown[] | undefined;
  const candidates = (result as { idor_candidates?: unknown[] })?.idor_candidates as unknown[] | undefined;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Link2 className="w-6 h-6 text-bmx-orange" />
        <div>
          <h1 className="text-xl font-bold text-white font-mono">API Intelligence</h1>
          <p className="text-xs text-bmx-muted">IDOR detection, role diff, GraphQL & OpenAPI analysis</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-bmx-border flex gap-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => { setActiveTab(tab.id); setResult(null); setError(""); }}
            className={`flex items-center gap-1.5 px-4 py-2 text-sm font-mono border-b-2 transition-colors ${
              activeTab === tab.id ? "border-bmx-orange text-bmx-orange" : "border-transparent text-bmx-muted hover:text-white"
            }`}
          >
            <tab.icon className="w-3.5 h-3.5" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* IDOR */}
      {activeTab === "idor" && (
        <div className="space-y-4">
          <p className="text-xs text-bmx-muted">Observe API responses to map object relationships and generate IDOR test candidates.</p>
          <div className="grid grid-cols-3 gap-3">
            <select value={observeMethod} onChange={(e) => setObserveMethod(e.target.value)}
              className="bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-bmx-orange outline-none">
              {["GET","POST","PUT","PATCH","DELETE"].map((m) => <option key={m}>{m}</option>)}
            </select>
            <input value={observeUrl} onChange={(e) => setObserveUrl(e.target.value)}
              className="col-span-2 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-bmx-orange outline-none"
              placeholder="/api/users/1" />
          </div>
          <textarea value={observeBody} onChange={(e) => setObserveBody(e.target.value)}
            rows={3}
            className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-bmx-orange outline-none resize-none"
            placeholder='{"id":"1","email":"user@test.com"}' />
          <button onClick={runIdorScan} disabled={loading}
            className="px-4 py-2 text-sm font-mono bg-bmx-orange/10 text-bmx-orange border border-bmx-orange/30 rounded hover:bg-bmx-orange/20 disabled:opacity-40 transition-colors">
            {loading ? "Analyzing..." : "Detect IDOR Candidates"}
          </button>

          {candidates && candidates.length > 0 && (
            <div className="bg-bmx-dark border border-bmx-red/20 rounded-lg p-4 space-y-3">
              <div className="text-sm font-mono text-bmx-red">⚠ {candidates.length} IDOR Candidate{candidates.length > 1 ? "s" : ""}</div>
              {(candidates as Array<{ url_template: string; object_type: string; test_id: string; rationale: string; risk: string }>).map((c, i) => (
                <div key={i} className="bg-bmx-black rounded p-3 text-xs space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-bmx-orange font-mono">{c.url_template}</span>
                    <span className="text-bmx-muted">({c.object_type})</span>
                    <span className={`ml-auto px-1.5 py-0.5 rounded text-xs ${c.risk === "high" ? "bg-bmx-red/10 text-bmx-red" : "bg-bmx-yellow/10 text-bmx-yellow"}`}>
                      {c.risk}
                    </span>
                  </div>
                  <div className="text-bmx-muted">{c.rationale}</div>
                  <div className="text-bmx-cyan">Test with ID: <span className="font-mono">{c.test_id}</span></div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Role Diff */}
      {activeTab === "rolediff" && (
        <div className="space-y-4">
          <p className="text-xs text-bmx-muted">Compare API responses across privilege levels to detect authorization failures.</p>
          <input value={baseUrl} onChange={(e) => setBaseUrl(e.target.value)}
            className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-bmx-orange outline-none"
            placeholder="http://target.example.com" />
          <textarea value={diffUrls} onChange={(e) => setDiffUrls(e.target.value)} rows={3}
            className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-bmx-orange outline-none resize-none"
            placeholder="/api/users/1&#10;/api/admin/users" />
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-bmx-muted mb-1 block">Admin Token</label>
              <input value={adminToken} onChange={(e) => setAdminToken(e.target.value)}
                className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-bmx-orange outline-none"
                placeholder="eyJhbGci..." />
            </div>
            <div>
              <label className="text-xs text-bmx-muted mb-1 block">User Token</label>
              <input value={userToken} onChange={(e) => setUserToken(e.target.value)}
                className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-bmx-orange outline-none"
                placeholder="eyJhbGci..." />
            </div>
          </div>
          <button onClick={runRoleDiff} disabled={loading}
            className="px-4 py-2 text-sm font-mono bg-bmx-orange/10 text-bmx-orange border border-bmx-orange/30 rounded hover:bg-bmx-orange/20 disabled:opacity-40 transition-colors">
            {loading ? "Running diff..." : "Run Role Diff"}
          </button>

          {result && (
            <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4 space-y-3">
              <div className="grid grid-cols-3 gap-3 text-center">
                {[
                  { label: "Tested", val: (result as { total_tested?: number }).total_tested || 0 },
                  { label: "Findings", val: (result as { findings?: number }).findings || 0 },
                  { label: "Critical", val: (result as { critical?: number }).critical || 0 },
                ].map((s) => (
                  <div key={s.label} className="bg-bmx-black rounded p-2">
                    <div className="text-lg font-bold font-mono text-white">{s.val}</div>
                    <div className="text-xs text-bmx-muted">{s.label}</div>
                  </div>
                ))}
              </div>
              {findings && findings.length > 0 && (
                <div className="space-y-2">
                  {(findings as Array<{ url: string; role_a: string; role_b: string; finding_type: string; severity: string; description: string }>).map((f, i) => (
                    <div key={i} className="bg-bmx-black rounded p-3 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="text-bmx-orange font-mono">{f.url}</span>
                        <span className={`ml-auto px-1.5 py-0.5 rounded text-xs ${
                          f.severity === "critical" ? "bg-bmx-red/10 text-bmx-red" : "bg-bmx-yellow/10 text-bmx-yellow"
                        }`}>{f.severity}</span>
                      </div>
                      <div className="text-bmx-muted mt-1">{f.description}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* GraphQL */}
      {activeTab === "graphql" && (
        <div className="space-y-4">
          <p className="text-xs text-bmx-muted">Test GraphQL endpoints for introspection, depth limits, and batch queries.</p>
          <input value={gqlUrl} onChange={(e) => setGqlUrl(e.target.value)}
            className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-bmx-orange outline-none"
            placeholder="http://target.com/graphql" />
          <button onClick={runGraphQLAnalysis} disabled={loading}
            className="px-4 py-2 text-sm font-mono bg-bmx-orange/10 text-bmx-orange border border-bmx-orange/30 rounded hover:bg-bmx-orange/20 disabled:opacity-40 transition-colors">
            {loading ? "Analyzing..." : "Analyze GraphQL"}
          </button>
          {result && renderFindings(result as { findings?: unknown[]; capabilities?: Record<string, boolean>; finding_count?: number })}
        </div>
      )}

      {/* OpenAPI */}
      {activeTab === "openapi" && (
        <div className="space-y-4">
          <p className="text-xs text-bmx-muted">Analyze an OpenAPI 3.x spec for missing auth, mass assignment, and sensitive response fields.</p>
          <div className="grid grid-cols-2 gap-3">
            <input value={baseUrl} onChange={(e) => setBaseUrl(e.target.value)}
              className="bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-bmx-orange outline-none"
              placeholder="http://target.com" />
            <input value={specUrl} onChange={(e) => setSpecUrl(e.target.value)}
              className="bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-bmx-orange outline-none"
              placeholder="/openapi.json" />
          </div>
          <button onClick={runOpenAPIAnalysis} disabled={loading}
            className="px-4 py-2 text-sm font-mono bg-bmx-orange/10 text-bmx-orange border border-bmx-orange/30 rounded hover:bg-bmx-orange/20 disabled:opacity-40 transition-colors">
            {loading ? "Fetching spec..." : "Analyze OpenAPI Spec"}
          </button>
          {result && renderFindings(result as { findings?: unknown[]; capabilities?: Record<string, boolean>; finding_count?: number })}
        </div>
      )}

      {error && <p className="text-xs text-bmx-red bg-bmx-red/5 border border-bmx-red/20 rounded p-3">{error}</p>}
    </div>
  );
}

function renderFindings(result: { findings?: unknown[]; capabilities?: Record<string, boolean>; finding_count?: number }) {
  const findings = result.findings || [];
  return (
    <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4 space-y-3">
      <div className="flex items-center gap-3 text-sm">
        <span className="text-white font-bold font-mono">{result.finding_count || findings.length}</span>
        <span className="text-bmx-muted">findings</span>
        {result.capabilities && (
          <div className="ml-auto flex gap-2">
            {Object.entries(result.capabilities).map(([k, v]) => (
              <span key={k} className={`text-xs px-1.5 py-0.5 rounded border font-mono ${
                v ? "text-bmx-red border-bmx-red/30" : "text-bmx-green border-bmx-green/30"
              }`}>{k.replace(/_/g, " ")}: {v ? "YES" : "no"}</span>
            ))}
          </div>
        )}
      </div>
      {findings.length === 0 ? (
        <div className="flex items-center gap-2 text-bmx-green text-sm">
          <CheckCircle className="w-4 h-4" /> No security issues detected
        </div>
      ) : (
        <div className="space-y-2">
          {(findings as Array<{ title: string; severity: string; description: string; test?: string; finding_type?: string }>).map((f, i) => (
            <div key={i} className="bg-bmx-black rounded p-3 text-xs space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-white font-mono">{f.title}</span>
                <span className={`ml-auto px-1.5 py-0.5 rounded text-xs ${
                  f.severity === "high" || f.severity === "critical" ? "bg-bmx-red/10 text-bmx-red"
                  : f.severity === "medium" ? "bg-bmx-yellow/10 text-bmx-yellow"
                  : "bg-gray-500/10 text-gray-400"
                }`}>{f.severity}</span>
              </div>
              <div className="text-bmx-muted">{f.description}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
