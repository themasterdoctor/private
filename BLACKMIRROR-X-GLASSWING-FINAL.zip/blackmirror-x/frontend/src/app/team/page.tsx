"use client";
import { useEffect, useState } from "react";
import { useAppStore } from "@/store/app";
import { Users, Shield, CheckCircle, AlertTriangle, Clock, BarChart2, Zap } from "lucide-react";
import getApi from "@/lib/api";

interface TeamMember { user_id: string; email: string; full_name: string; role: string; joined_at: string; }
interface Permission { role: string; permissions: string[]; }

const ROLE_COLORS: Record<string, string> = {
  owner: "text-yellow-400 bg-yellow-400/10 border-yellow-400/30",
  admin: "text-bmx-cyan bg-bmx-cyan/10 border-bmx-cyan/30",
  analyst: "text-bmx-green bg-bmx-green/10 border-bmx-green/30",
  viewer: "text-bmx-muted bg-bmx-muted/10 border-bmx-muted/30",
  reporter: "text-blue-400 bg-blue-400/10 border-blue-400/30",
};

export default function TeamPage() {
  const { activeWorkspace, fetchWorkspaces, vulns } = useAppStore();
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [myPerms, setMyPerms] = useState<Permission | null>(null);
  const [slaStatus, setSlaStatus] = useState<Record<string, any>>({});
  const [tab, setTab] = useState<"members" | "permissions" | "sla" | "plugins">("members");
  const [plugins, setPlugins] = useState<any[]>([]);

  const api = getApi();
  const wid = activeWorkspace?.id || "";

  useEffect(() => {
    if (!activeWorkspace) fetchWorkspaces();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!wid) return;
    loadTeam();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wid]);

  async function loadTeam() {
    try {
      const [membersR, permsR, pluginsR] = await Promise.all([
        api.get(`/enterprise/team/${wid}/members`),
        api.get(`/enterprise/team/${wid}/permissions`),
        api.get(`/enterprise/plugins`),
      ]);
      setMembers(membersR.data.members || []);
      setMyPerms(permsR.data);
      setPlugins(pluginsR.data.plugins || []);
    } catch {}
  }

  async function checkSLA(vulnId: string) {
    try {
      const r = await api.post(`/enterprise/team/${wid}/sla-check/${vulnId}`);
      setSlaStatus(prev => ({ ...prev, [vulnId]: r.data }));
    } catch {}
  }

  const slaVulns = vulns.filter(v => ["critical", "high"].includes(v.severity)).slice(0, 10);

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-white font-mono text-xl font-bold flex items-center gap-2">
          <Users className="w-5 h-5 text-bmx-cyan" />
          TEAM / ENTERPRISE MANAGEMENT
        </h1>
        <p className="text-bmx-muted text-sm font-mono mt-0.5">
          Multi-user workspace, RBAC roles, SLA tracking, and plugin management
        </p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bmx-panel rounded-lg border border-bmx-border p-4">
          <div className="text-2xl font-mono font-bold text-bmx-cyan">{members.length}</div>
          <div className="text-bmx-muted text-xs font-mono mt-1">Team Members</div>
        </div>
        <div className="bmx-panel rounded-lg border border-bmx-border p-4">
          <div className="text-2xl font-mono font-bold text-bmx-green">{myPerms?.permissions.length || 0}</div>
          <div className="text-bmx-muted text-xs font-mono mt-1">Your Permissions</div>
        </div>
        <div className="bmx-panel rounded-lg border border-bmx-border p-4">
          <div className="text-2xl font-mono font-bold text-bmx-orange">{plugins.length}</div>
          <div className="text-bmx-muted text-xs font-mono mt-1">Active Plugins</div>
        </div>
      </div>

      <div className="flex gap-1 border-b border-bmx-border">
        {[["members","TEAM MEMBERS"],["permissions","MY PERMISSIONS"],["sla","SLA TRACKER"],["plugins","PLUGINS"]].map(([id, label]) => (
          <button key={id} onClick={() => setTab(id as any)}
            className={`px-4 py-2 text-xs font-mono tracking-wider ${
              tab === id ? "text-bmx-cyan border-b-2 border-bmx-cyan" : "text-bmx-muted hover:text-white"
            }`}>{label}</button>
        ))}
      </div>

      {tab === "members" && (
        <div className="space-y-2">
          {members.map(m => (
            <div key={m.user_id} className="bmx-panel rounded-lg border border-bmx-border p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-bmx-cyan/10 border border-bmx-cyan/30 flex items-center justify-center">
                  <span className="text-bmx-cyan font-mono text-xs">{m.email[0]?.toUpperCase()}</span>
                </div>
                <div>
                  <p className="text-white font-mono text-sm">{m.full_name || m.email}</p>
                  <p className="text-bmx-muted text-xs font-mono">{m.email}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className={`text-xs font-mono px-2 py-0.5 rounded border ${ROLE_COLORS[m.role] || ROLE_COLORS.viewer}`}>
                  {m.role.toUpperCase()}
                </span>
                <span className="text-bmx-muted text-xs font-mono">
                  Joined {new Date(m.joined_at).toLocaleDateString()}
                </span>
              </div>
            </div>
          ))}
          {!members.length && (
            <p className="text-center text-bmx-muted text-sm font-mono py-8">No team members loaded</p>
          )}
        </div>
      )}

      {tab === "permissions" && myPerms && (
        <div className="space-y-4">
          <div className={`bmx-panel rounded-lg border p-4 ${ROLE_COLORS[myPerms.role] || ROLE_COLORS.viewer}`}>
            <p className="font-mono text-sm font-bold">Your Role: {myPerms.role.toUpperCase()}</p>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {myPerms.permissions.sort().map(perm => (
              <div key={perm} className="flex items-center gap-2 text-xs font-mono">
                <CheckCircle className="w-3.5 h-3.5 text-bmx-green" />
                <span className="text-white">{perm}</span>
              </div>
            ))}
          </div>
          {/* Role comparison table */}
          <div className="bmx-panel rounded-lg border border-bmx-border overflow-hidden mt-4">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="border-b border-bmx-border bg-bmx-dark">
                  <th className="px-3 py-2 text-left text-bmx-muted">PERMISSION</th>
                  {["OWNER","ADMIN","ANALYST","VIEWER"].map(r => (
                    <th key={r} className="px-3 py-2 text-center text-bmx-muted">{r}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[
                  ["Launch Scans", true, true, true, false],
                  ["Triage Findings", true, true, true, false],
                  ["Manage Team", true, true, false, false],
                  ["Approve Actions", true, true, true, false],
                  ["Generate Reports", true, true, true, true],
                  ["Override Severity", true, true, false, false],
                  ["Emergency Stop", true, true, false, false],
                  ["Manage Scope", true, true, false, false],
                  ["Billing/Settings", true, false, false, false],
                ].map(([perm, ...roles]) => (
                  <tr key={String(perm)} className="border-b border-bmx-border/30">
                    <td className="px-3 py-2 text-white">{perm}</td>
                    {roles.map((has, i) => (
                      <td key={i} className="px-3 py-2 text-center">
                        {has ? <CheckCircle className="w-3.5 h-3.5 text-bmx-green mx-auto" />
                             : <span className="text-bmx-muted">—</span>}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === "sla" && (
        <div className="space-y-4">
          <div className="bmx-panel rounded-lg border border-bmx-border p-4">
            <p className="text-white font-mono text-xs tracking-wider mb-3">DEFAULT SLA POLICY</p>
            <div className="grid grid-cols-5 gap-3 text-xs font-mono">
              {[["CRITICAL", "1 day", "text-red-400"], ["HIGH", "7 days", "text-bmx-orange"],
                ["MEDIUM", "30 days", "text-bmx-yellow"], ["LOW", "90 days", "text-blue-400"],
                ["INFO", "180 days", "text-bmx-muted"]].map(([sev, days, color]) => (
                <div key={sev} className="text-center">
                  <div className={`font-bold ${color}`}>{days}</div>
                  <div className="text-bmx-muted mt-0.5">{sev}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-bmx-muted text-xs font-mono tracking-wider">CRITICAL/HIGH FINDING SLA STATUS</p>
            {slaVulns.map(v => {
              const sl = slaStatus[v.id];
              return (
                <div key={v.id} className="bmx-panel rounded-lg border border-bmx-border p-3 flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-mono text-xs truncate">{v.title}</p>
                    <span className={`text-xs font-mono ${v.severity === "critical" ? "text-red-400" : "text-bmx-orange"}`}>
                      {v.severity.toUpperCase()}
                    </span>
                  </div>
                  {sl ? (
                    <div className={`text-xs font-mono px-2 py-1 rounded ${
                      sl.status === "breached" ? "bg-red-900/30 text-bmx-red" :
                      sl.status === "critical" ? "bg-bmx-orange/10 text-bmx-orange" :
                      sl.status === "warning" ? "bg-bmx-yellow/10 text-bmx-yellow" :
                      "bg-bmx-green/10 text-bmx-green"
                    }`}>
                      {sl.status === "breached" ? `BREACHED ${Math.abs(sl.days_remaining)}d ago` :
                       `${sl.days_remaining}d remaining (${sl.status})`}
                    </div>
                  ) : (
                    <button onClick={() => checkSLA(v.id)}
                      className="text-bmx-cyan text-xs font-mono hover:underline">Check SLA</button>
                  )}
                </div>
              );
            })}
            {!slaVulns.length && (
              <p className="text-bmx-muted text-xs font-mono italic text-center py-4">No critical/high findings to track</p>
            )}
          </div>
        </div>
      )}

      {tab === "plugins" && (
        <div className="space-y-3">
          {plugins.map((p: any) => (
            <div key={p.name} className="bmx-panel rounded-lg border border-bmx-border p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-mono text-sm font-bold">{p.name}</p>
                  <p className="text-bmx-muted text-xs font-mono mt-0.5">{p.description}</p>
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className="text-bmx-cyan text-xs font-mono">{p.plugin_type}</span>
                    <span className="text-bmx-muted text-xs font-mono">v{p.version}</span>
                    {p.tags?.map((tag: string) => (
                      <span key={tag} className="text-xs font-mono px-1.5 py-0.5 bg-bmx-dark border border-bmx-border rounded text-bmx-muted">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                <div className={`flex items-center gap-1 text-xs font-mono ${p.is_enabled ? "text-bmx-green" : "text-bmx-muted"}`}>
                  {p.is_enabled ? <CheckCircle className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                  {p.is_enabled ? "ENABLED" : "DISABLED"}
                </div>
              </div>
            </div>
          ))}
          <div className="bmx-panel rounded-lg border border-bmx-border border-dashed p-6 text-center">
            <Zap className="w-8 h-8 mx-auto mb-2 text-bmx-muted/50" />
            <p className="text-bmx-muted text-xs font-mono">
              Add custom plugins by implementing the Plugin SDK interface.<br />
              See <code className="text-bmx-cyan">app/enterprise/plugin_sdk.py</code> for documentation.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
