"use client";
import { useState, useEffect } from "react";
import { useAppStore } from "@/store/app";
import { Play, Shield, Search, Code2, Link2, FileText, Layers, Film, AlertTriangle, CheckCircle, Square } from "lucide-react";

const API = process.env.NEXT_PUBLIC_API_URL || "";

interface Workflow {
  id: string;
  name: string;
  icon: React.ElementType;
  iconStr: string;
  desc: string;
  risk: string;
  tools: string[];
  approvalRequired: boolean;
  steps: string[];
  scanType: string;
  estimatedTime: string;
  rateLimit: string;
}

const WORKFLOWS: Workflow[] = [
  {
    id: "recon",
    name: "Recon Only",
    icon: Search,
    iconStr: "🔍",
    desc: "Subdomain enumeration, HTTP probing, tech stack detection. Zero active testing. Safe to run against any authorized target.",
    risk: "passive",
    tools: ["subfinder", "amass", "dnsx", "httpx"],
    approvalRequired: false,
    steps: ["Subdomain enumeration", "DNS resolution", "HTTP probe", "Tech stack detection", "Report"],
    scanType: "recon",
    estimatedTime: "5–15 min",
    rateLimit: "10 req/s",
  },
  {
    id: "js",
    name: "JS Analysis Only",
    icon: Code2,
    iconStr: "🔮",
    desc: "Downloads and analyzes JavaScript bundles. Finds secrets, hidden endpoints, DOM XSS sinks, and exposed API keys.",
    risk: "passive",
    tools: ["httpx", "katana"],
    approvalRequired: false,
    steps: ["Crawl JS files", "Extract endpoints", "Detect secrets", "Find DOM XSS sinks", "Report"],
    scanType: "js_analysis",
    estimatedTime: "3–10 min",
    rateLimit: "5 req/s",
  },
  {
    id: "api_audit",
    name: "API Audit",
    icon: Link2,
    iconStr: "🔗",
    desc: "API security audit: OpenAPI analysis, GraphQL introspection, IDOR candidate generation, role diff (requires test credentials).",
    risk: "low",
    tools: ["httpx"],
    approvalRequired: false,
    steps: ["Discover API endpoints", "Fetch OpenAPI spec", "Test GraphQL", "Map objects", "Generate IDOR candidates", "Report"],
    scanType: "api_audit",
    estimatedTime: "10–20 min",
    rateLimit: "3 req/s",
  },
  {
    id: "full_safe",
    name: "Full Safe Scan",
    icon: Shield,
    iconStr: "🛡️",
    desc: "All passive + low-risk active modules. No destructive tests. Appropriate for authorized bug bounty targets.",
    risk: "medium",
    tools: ["subfinder", "httpx", "katana", "nuclei"],
    approvalRequired: false,
    steps: ["Recon", "JS analysis", "API discovery", "Vulnerability detection", "Chain analysis", "Court validation", "Report"],
    scanType: "full",
    estimatedTime: "20–60 min",
    rateLimit: "5 req/s",
  },
  {
    id: "bounty",
    name: "Bug Bounty Builder",
    icon: FileText,
    iconStr: "💰",
    desc: "Optimizes for bug bounty report quality. Adds court validation, evidence capture, chain reasoning, and HackerOne-format output.",
    risk: "medium",
    tools: ["subfinder", "httpx", "katana"],
    approvalRequired: false,
    steps: ["Scan", "Chain analysis", "Court validation", "Evidence vault", "HackerOne report"],
    scanType: "full",
    estimatedTime: "30–90 min",
    rateLimit: "3 req/s",
  },
  {
    id: "chain_investigation",
    name: "Chain Investigation",
    icon: Layers,
    iconStr: "⛓️",
    desc: "Load existing vulnerabilities and reason about multi-step attack chains. No new scanning — analysis only.",
    risk: "passive",
    tools: [],
    approvalRequired: false,
    steps: ["Load existing findings", "Build chain graph", "Score chains", "Identify proof gaps", "Export report"],
    scanType: "chain_only",
    estimatedTime: "2–5 min",
    rateLimit: "N/A",
  },
  {
    id: "evidence_replay",
    name: "Evidence Replay",
    icon: Film,
    iconStr: "▶️",
    desc: "Replay previous requests with mutations. Compare responses to validate findings. Import from HAR, export curl commands.",
    risk: "passive",
    tools: [],
    approvalRequired: false,
    steps: ["Import HAR or enter request", "Replay baseline", "Apply mutations", "Diff responses", "Export evidence"],
    scanType: "replay_only",
    estimatedTime: "5–30 min",
    rateLimit: "2 req/s",
  },
];

const RISK_STYLE: Record<string, string> = {
  passive: "text-bmx-green border-bmx-green/30 bg-bmx-green/5",
  low:     "text-bmx-cyan border-bmx-cyan/30 bg-bmx-cyan/5",
  medium:  "text-bmx-yellow border-bmx-yellow/30 bg-bmx-yellow/5",
  high:    "text-bmx-red border-bmx-red/30 bg-bmx-red/5",
};

export default function WorkflowsPage() {
  const { scans, activeWorkspace, fetchScans, fetchWorkspaces } = useAppStore();
  const [selected, setSelected] = useState<Workflow | null>(null);
  const [targetDomain, setTargetDomain] = useState("localhost:9001");
  const [confirmed, setConfirmed] = useState(false);
  const [launching, setLaunching] = useState(false);
  const [launched, setLaunched] = useState<{ scanId: string; name: string } | null>(null);
  const [error, setError] = useState("");

  // Ensure workspace is loaded (page may be accessed directly without going through dashboard)
  useEffect(() => {
    if (!activeWorkspace) fetchWorkspaces();
  }, []);

  const getToken = () => localStorage.getItem("bmx_access_token") || "";

  async function launchWorkflow() {
    if (!selected || !activeWorkspace || !confirmed) return;
    setLaunching(true);
    setError("");
    try {
      const r = await fetch(`${API}/api/v1/scans`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken()}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          workspace_id: activeWorkspace.id,
          name: `${selected.name} — ${targetDomain}`,
          scan_type: selected.scanType,
          config: {
            domain: targetDomain.split(":")[0],
            target: `http://${targetDomain}`,
            workflow: selected.id,
            risk_tier: selected.risk,
            rate_limit_rps: parseFloat(selected.rateLimit.split(" ")[0]) || 5,
            passive_only: selected.risk === "passive",
          },
        }),
      });
      if (!r.ok) throw new Error(await r.text());
      const data = await r.json();
      setLaunched({ scanId: data.id, name: data.name || selected.name });
    } catch (e: unknown) { setError(String(e)); } finally { setLaunching(false); }
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Play className="w-6 h-6 text-bmx-cyan" />
        <div>
          <h1 className="text-xl font-bold text-white font-mono">Guided Workflows</h1>
          <p className="text-xs text-bmx-muted">Pre-configured scan workflows with built-in safety controls</p>
        </div>
      </div>

      {launched && (
        <div className="bg-bmx-green/5 border border-bmx-green/30 rounded-lg p-4 flex items-center gap-3">
          <CheckCircle className="w-5 h-5 text-bmx-green flex-shrink-0" />
          <div>
            <div className="text-sm font-mono text-bmx-green">Workflow launched successfully</div>
            <div className="text-xs text-bmx-muted mt-0.5">
              Scan: {launched.name} · ID: {launched.scanId.slice(0, 8)}...
            </div>
          </div>
          <button onClick={() => setLaunched(null)} className="ml-auto text-bmx-muted hover:text-white text-xs">✕</button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Workflow list */}
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
          {WORKFLOWS.map((wf) => (
            <button
              key={wf.id}
              onClick={() => { setSelected(wf); setConfirmed(false); setLaunched(null); }}
              className={`text-left rounded-lg border p-4 transition-all hover:border-bmx-border/80 ${
                selected?.id === wf.id
                  ? "border-bmx-cyan bg-bmx-cyan/5"
                  : "border-bmx-border bg-bmx-dark hover:bg-white/5"
              }`}
            >
              <div className="flex items-start gap-3">
                <span className="text-2xl">{wf.iconStr}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-mono text-white">{wf.name}</span>
                    <span className={`text-xs px-1.5 py-0.5 rounded border font-mono ml-auto flex-shrink-0 ${RISK_STYLE[wf.risk]}`}>
                      {wf.risk}
                    </span>
                  </div>
                  <p className="text-xs text-bmx-muted mt-1 leading-relaxed">{wf.desc}</p>
                  <div className="flex items-center gap-3 mt-2 text-xs text-bmx-muted">
                    <span>⏱ {wf.estimatedTime}</span>
                    {wf.tools.length > 0 && <span>🔧 {wf.tools.length} tools</span>}
                    {wf.approvalRequired && <span className="text-bmx-yellow">⚠ approval</span>}
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Launch panel */}
        <div className="space-y-4">
          {!selected ? (
            <div className="bg-bmx-dark border border-bmx-border rounded-lg p-6 text-center">
              <Play className="w-8 h-8 text-bmx-border mx-auto mb-3" />
              <p className="text-bmx-muted text-sm">Select a workflow to configure and launch</p>
            </div>
          ) : (
            <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4 space-y-4 sticky top-6">
              <div className="flex items-center gap-2">
                <span className="text-xl">{selected.iconStr}</span>
                <div>
                  <div className="text-sm font-mono text-white">{selected.name}</div>
                  <div className={`text-xs font-mono mt-0.5 ${RISK_STYLE[selected.risk].split(" ")[0]}`}>
                    risk: {selected.risk}
                  </div>
                </div>
              </div>

              {/* Safety panel */}
              <div className="bg-bmx-black rounded-lg p-3 border border-bmx-border space-y-2">
                <div className="text-xs font-mono text-bmx-muted mb-1">Safety Controls</div>
                {[
                  { label: "Rate Limit", val: selected.rateLimit, ok: true },
                  { label: "Risk Tier", val: selected.risk, ok: selected.risk !== "high" },
                  { label: "Human Approval", val: selected.approvalRequired ? "required" : "not required", ok: !selected.approvalRequired },
                  { label: "Emergency Stop", val: "always available", ok: true },
                  { label: "Scope", val: targetDomain || "not set", ok: !!targetDomain },
                ].map((s) => (
                  <div key={s.label} className="flex items-center gap-2 text-xs">
                    <span className={s.ok ? "text-bmx-green" : "text-bmx-red"}>
                      {s.ok ? "✓" : "✗"}
                    </span>
                    <span className="text-bmx-muted">{s.label}:</span>
                    <span className="text-white font-mono">{s.val}</span>
                  </div>
                ))}
              </div>

              {/* Steps */}
              <div>
                <div className="text-xs text-bmx-muted mb-1.5">Steps</div>
                <div className="space-y-1">
                  {selected.steps.map((s, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-bmx-muted">
                      <span className="text-bmx-cyan font-mono w-4">{i + 1}.</span>
                      {s}
                    </div>
                  ))}
                </div>
              </div>

              {/* Target */}
              <div>
                <label className="text-xs text-bmx-muted block mb-1">Target Domain</label>
                <input
                  value={targetDomain}
                  onChange={(e) => setTargetDomain(e.target.value)}
                  placeholder="example.com"
                  className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-bmx-cyan outline-none"
                />
              </div>

              {/* Legal confirmation */}
              <label className="flex items-start gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={confirmed}
                  onChange={(e) => setConfirmed(e.target.checked)}
                  className="mt-0.5 accent-bmx-green"
                />
                <span className="text-xs text-bmx-muted">
                  I have authorization to test this target
                </span>
              </label>

              {error && <p className="text-xs text-bmx-red bg-bmx-red/5 rounded p-2">{error}</p>}

              {/* Launch button */}
              <button
                onClick={launchWorkflow}
                disabled={!confirmed || !targetDomain || !activeWorkspace || launching}
                className="w-full flex items-center justify-center gap-2 py-2.5 text-sm font-mono bg-bmx-cyan/10 text-bmx-cyan border border-bmx-cyan/30 rounded hover:bg-bmx-cyan/20 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <Play className="w-4 h-4" />
                {launching ? "Launching..." : `Launch ${selected.name}`}
              </button>

              {!activeWorkspace && (
                <p className="text-xs text-bmx-yellow text-center">
                  No active workspace — select one in Settings
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
