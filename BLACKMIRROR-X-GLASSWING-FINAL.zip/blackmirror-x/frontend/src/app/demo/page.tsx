"use client";
import { useState, useEffect } from "react";
import { Zap, RefreshCw, Play, CheckCircle, AlertTriangle, FileText, Layers, Scale, ChevronRight } from "lucide-react";

const API = process.env.NEXT_PUBLIC_API_URL || "";

interface DemoStatus {
  demo_mode: boolean;
  testlab_running: boolean;
  testlab_url: string;
  demo_workspace_exists: boolean;
  demo_vulnerability_count: number;
  demo_credentials: { email: string; password: string };
}

export default function DemoPage() {
  const [status, setStatus] = useState<DemoStatus | null>(null);
  const [resetting, setResetting] = useState(false);
  const [resetMsg, setResetMsg] = useState("");
  const [report, setReport] = useState<Record<string, unknown> | null>(null);
  const [chain, setChain] = useState<Record<string, unknown> | null>(null);
  const [verdict, setVerdict] = useState<Record<string, unknown> | null>(null);
  const [activePanel, setActivePanel] = useState<"report" | "chain" | "verdict" | null>(null);

  const getToken = () => localStorage.getItem("bmx_access_token") || "";

  async function fetchStatus() {
    try {
      const r = await fetch(`${API}/api/v1/demo/status`, {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      if (r.ok) setStatus(await r.json());
    } catch {/* */}
  }

  async function resetDemo() {
    setResetting(true); setResetMsg("");
    try {
      const r = await fetch(`${API}/api/v1/demo/reset`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      const d = await r.json();
      setResetMsg(d.message || "Done");
      await fetchStatus();
    } catch (e: unknown) { setResetMsg(String(e)); } finally { setResetting(false); }
  }

  async function loadDemo(type: "report" | "chain" | "verdict") {
    setActivePanel(type);
    try {
      const r = await fetch(`${API}/api/v1/demo/${type}`, {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      const d = await r.json();
      if (type === "report") setReport(d);
      if (type === "chain") setChain(d);
      if (type === "verdict") setVerdict(d);
    } catch {/* */}
  }

  useEffect(() => { fetchStatus(); }, []);

  const findings = report?.findings as Array<{ title: string; severity: string; cvss: number }> | undefined;
  const chainNodes = chain?.nodes as Array<{ vuln_type: string; title: string }> | undefined;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Zap className="w-6 h-6 text-bmx-yellow" />
          <div>
            <h1 className="text-xl font-bold text-white font-mono">Demo Control Panel</h1>
            <p className="text-xs text-bmx-muted">10-minute demo mode · prebuilt data · one-click reset</p>
          </div>
        </div>
        <button onClick={fetchStatus} className="text-xs text-bmx-muted border border-bmx-border rounded px-3 py-1.5 hover:text-white flex items-center gap-1.5">
          <RefreshCw className="w-3 h-3" /> Refresh
        </button>
      </div>

      {/* Status card */}
      {status && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "Testlab", val: status.testlab_running ? "running" : "stopped",
              color: status.testlab_running ? "text-bmx-green" : "text-bmx-red" },
            { label: "Demo Workspace", val: status.demo_workspace_exists ? "exists" : "missing",
              color: status.demo_workspace_exists ? "text-bmx-green" : "text-bmx-yellow" },
            { label: "Demo Vulns", val: String(status.demo_vulnerability_count),
              color: "text-white" },
            { label: "Testlab URL", val: status.testlab_url, color: "text-bmx-cyan" },
          ].map((s) => (
            <div key={s.label} className="bg-bmx-dark border border-bmx-border rounded-lg p-3">
              <div className="text-xs text-bmx-muted mb-1">{s.label}</div>
              <div className={`text-sm font-mono font-bold ${s.color} truncate`}>{s.val}</div>
            </div>
          ))}
        </div>
      )}

      {/* One-click actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">

        {/* Reset */}
        <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4 space-y-3">
          <div className="flex items-center gap-2">
            <RefreshCw className="w-4 h-4 text-bmx-cyan" />
            <span className="text-sm font-mono text-white">Reset Demo Data</span>
          </div>
          <p className="text-xs text-bmx-muted">
            Wipes and re-seeds the demo workspace with 8 vulnerabilities, 3 subdomains, and demo scan data.
          </p>
          <button
            onClick={resetDemo}
            disabled={resetting}
            className="w-full py-2 text-sm font-mono bg-bmx-cyan/10 text-bmx-cyan border border-bmx-cyan/30 rounded hover:bg-bmx-cyan/20 disabled:opacity-40 transition-colors"
          >
            {resetting ? "Resetting..." : "Reset Demo"}
          </button>
          {resetMsg && <p className="text-xs text-bmx-green">{resetMsg}</p>}
        </div>

        {/* Testlab */}
        <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4 space-y-3">
          <div className="flex items-center gap-2">
            <Play className="w-4 h-4 text-bmx-green" />
            <span className="text-sm font-mono text-white">Testlab</span>
          </div>
          <p className="text-xs text-bmx-muted">
            Intentionally vulnerable Flask API with 8 real vulns (IDOR, XSS, SQLi, GraphQL, CORS, etc.)
          </p>
          <div className="text-xs font-mono space-y-1">
            <div className="text-bmx-muted">Start manually:</div>
            <div className="bg-bmx-black rounded px-2 py-1 text-bmx-cyan">
              cd testlab/vuln-api && python app.py
            </div>
            <div className="text-bmx-muted mt-1">Or run full demo:</div>
            <div className="bg-bmx-black rounded px-2 py-1 text-bmx-cyan">
              bash scripts/demo_run.sh
            </div>
          </div>
        </div>

        {/* Credentials */}
        <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4 space-y-3">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-bmx-green" />
            <span className="text-sm font-mono text-white">Demo Credentials</span>
          </div>
          {status?.demo_credentials && (
            <div className="space-y-2 font-mono text-sm">
              <div>
                <div className="text-xs text-bmx-muted">Email</div>
                <div className="text-bmx-cyan">{status.demo_credentials.email}</div>
              </div>
              <div>
                <div className="text-xs text-bmx-muted">Password</div>
                <div className="text-bmx-cyan">{status.demo_credentials.password}</div>
              </div>
            </div>
          )}
          <p className="text-xs text-bmx-muted">Pre-seeded admin user with demo workspace access.</p>
        </div>
      </div>

      {/* Prebuilt demos */}
      <div className="space-y-3">
        <h2 className="text-sm font-mono text-bmx-muted">Prebuilt Demo Assets</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">

          {/* Report */}
          <div className="bg-bmx-dark border border-bmx-border rounded-lg overflow-hidden">
            <button
              onClick={() => loadDemo("report")}
              className="w-full px-4 py-3 flex items-center gap-2 hover:bg-white/5 transition-colors text-left"
            >
              <FileText className="w-4 h-4 text-bmx-green" />
              <span className="text-sm font-mono text-white">Demo Report</span>
              <ChevronRight className={`w-3.5 h-3.5 text-bmx-muted ml-auto transition-transform ${activePanel === "report" ? "rotate-90" : ""}`} />
            </button>
            {activePanel === "report" && report && (
              <div className="px-4 pb-4 space-y-2 border-t border-bmx-border">
                <div className="text-xs text-white font-mono mt-2">{report.title as string}</div>
                <div className="grid grid-cols-4 gap-1 mt-2">
                  {Object.entries((report.severity_counts as Record<string, number>) || {}).map(([k, v]) => (
                    <div key={k} className="text-center bg-bmx-black rounded p-1">
                      <div className="text-sm font-bold text-white font-mono">{v}</div>
                      <div className="text-xs text-bmx-muted capitalize">{k.slice(0, 4)}</div>
                    </div>
                  ))}
                </div>
                <div className="space-y-1 mt-2 max-h-40 overflow-y-auto">
                  {findings?.slice(0, 3).map((f, i) => (
                    <div key={i} className="text-xs flex items-center gap-2">
                      <span className={f.severity === "critical" ? "text-bmx-red" : f.severity === "high" ? "text-bmx-orange" : "text-bmx-yellow"}>
                        {f.severity.toUpperCase()}
                      </span>
                      <span className="text-bmx-muted truncate">{f.title}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Chain */}
          <div className="bg-bmx-dark border border-bmx-border rounded-lg overflow-hidden">
            <button
              onClick={() => loadDemo("chain")}
              className="w-full px-4 py-3 flex items-center gap-2 hover:bg-white/5 transition-colors text-left"
            >
              <Layers className="w-4 h-4 text-bmx-red" />
              <span className="text-sm font-mono text-white">Demo Chain</span>
              <ChevronRight className={`w-3.5 h-3.5 text-bmx-muted ml-auto transition-transform ${activePanel === "chain" ? "rotate-90" : ""}`} />
            </button>
            {activePanel === "chain" && chain && (
              <div className="px-4 pb-4 space-y-2 border-t border-bmx-border">
                <div className="text-xs font-mono text-white mt-2">{chain.title as string}</div>
                <div className="flex items-center gap-3 text-xs mt-1">
                  <span className="text-bmx-red">{((chain.chain_probability as number) * 100).toFixed(0)}% probability</span>
                  <span className="text-bmx-green">{chain.estimated_bounty as string}</span>
                </div>
                <div className="space-y-1 mt-2">
                  {chainNodes?.map((n, i) => (
                    <div key={i} className="text-xs flex items-center gap-1.5 text-bmx-muted">
                      <span className="text-bmx-cyan font-mono">{i + 1}.</span>
                      <span className="text-bmx-orange uppercase font-mono">{n.vuln_type}</span>
                      <span>→ {n.title}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Verdict */}
          <div className="bg-bmx-dark border border-bmx-border rounded-lg overflow-hidden">
            <button
              onClick={() => loadDemo("verdict")}
              className="w-full px-4 py-3 flex items-center gap-2 hover:bg-white/5 transition-colors text-left"
            >
              <Scale className="w-4 h-4 text-purple-400" />
              <span className="text-sm font-mono text-white">Demo Verdict</span>
              <ChevronRight className={`w-3.5 h-3.5 text-bmx-muted ml-auto transition-transform ${activePanel === "verdict" ? "rotate-90" : ""}`} />
            </button>
            {activePanel === "verdict" && verdict && (
              <div className="px-4 pb-4 space-y-2 border-t border-bmx-border">
                <div className="text-xs font-mono text-white mt-2">{verdict.finding_title as string}</div>
                <div className={`text-sm font-bold font-mono mt-1 ${verdict.verdict === "CONFIRMED" ? "text-bmx-green" : "text-bmx-yellow"}`}>
                  {verdict.verdict as string}
                </div>
                <div className="text-xs text-bmx-muted leading-relaxed">
                  {(verdict.reasoning as string)?.slice(0, 150)}...
                </div>
                <div className="text-xs text-bmx-green mt-1">
                  Confidence: {((verdict.confidence as number) * 100).toFixed(0)}%
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
