"use client";
import { useEffect, useState } from "react";
import { useAppStore } from "@/store/app";
import { Shield, Plus, Trash2, CheckCircle, XCircle, AlertTriangle, Upload, Lock, Globe } from "lucide-react";
import getApi from "@/lib/api";

interface ScopeRule { pattern: string; rule_type: string; source: string; notes: string; }
interface ProgramProfile { program_name: string; platform: string; scope_domains: string[]; out_of_scope: string[]; }
interface ScopeData {
  include_rules: ScopeRule[];
  exclude_rules: ScopeRule[];
  authorization_confirmed: boolean;
  program_profile?: ProgramProfile;
  total_rules: number;
}

export default function ScopePage() {
  const { activeWorkspace, fetchWorkspaces } = useAppStore();
  const [scope, setScope] = useState<ScopeData | null>(null);
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState<"rules" | "program" | "check" | "audit">("rules");
  const [newPattern, setNewPattern] = useState("");
  const [newNotes, setNewNotes] = useState("");
  const [isExclusion, setIsExclusion] = useState(false);
  const [checkTarget, setCheckTarget] = useState("");
  const [checkResult, setCheckResult] = useState<any>(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [auditLog, setAuditLog] = useState<any[]>([]);

  // Program import form
  const [programName, setProgramName] = useState("");
  const [programPlatform, setProgramPlatform] = useState("hackerone");
  const [programScopes, setProgramScopes] = useState("*.example.com\nexample.com");
  const [programOOS, setProgramOOS] = useState("admin.example.com");
  const [programRules, setProgramRules] = useState("");
  const [importing, setImporting] = useState(false);

  // Auth confirmation
  const [authConfirmed, setAuthConfirmed] = useState(false);
  const [testerName, setTesterName] = useState("");
  const [authType, setAuthType] = useState("bug_bounty");
  const [acks, setAcks] = useState<string[]>([]);
  const REQUIRED_ACKS = [
    "I have explicit written authorization to test this target",
    "I understand that unauthorized testing is illegal",
    "I will only test within the defined scope",
    "I will not cause service disruption or data loss",
  ];

  useEffect(() => {
    if (!activeWorkspace) fetchWorkspaces();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (activeWorkspace) loadScope();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeWorkspace]);

  const api = getApi();
  const wid = activeWorkspace?.id || "";

  async function loadScope() {
    if (!wid) return;
    try {
      const r = await api.get(`/enterprise/scope/${wid}`);
      setScope(r.data);
    } catch {}
  }

  async function addRule() {
    if (!newPattern.trim()) return;
    setLoading(true); setError(""); setSuccess("");
    try {
      const endpoint = isExclusion ? `/enterprise/scope/${wid}/exclude` : `/enterprise/scope/${wid}/include`;
      await api.post(endpoint, { pattern: newPattern.trim(), notes: newNotes.trim() });
      setNewPattern(""); setNewNotes("");
      await loadScope();
      setSuccess(`${isExclusion ? "Exclusion" : "Inclusion"} rule added`);
    } catch (e: any) { setError(e.uiMessage || "Failed to add rule"); }
    finally { setLoading(false); }
  }

  async function checkTargetScope() {
    if (!checkTarget.trim()) return;
    try {
      const r = await api.post(`/enterprise/scope/${wid}/check`, { target: checkTarget.trim() });
      setCheckResult(r.data);
    } catch (e: any) { setError(e.uiMessage || "Check failed"); }
  }

  async function importProgram() {
    if (!programName.trim()) return;
    setImporting(true); setError("");
    try {
      const scopeDomains = programScopes.split("\n").map(s => s.trim()).filter(Boolean);
      const outOfScope = programOOS.split("\n").map(s => s.trim()).filter(Boolean);
      await api.post(`/enterprise/scope/${wid}/import-program`, {
        program_name: programName,
        platform: programPlatform,
        scope_domains: scopeDomains,
        out_of_scope: outOfScope,
        rules: programRules,
      });
      await loadScope();
      setSuccess(`Program "${programName}" imported — ${scopeDomains.length} in-scope, ${outOfScope.length} excluded`);
    } catch (e: any) { setError(e.uiMessage || "Import failed"); }
    finally { setImporting(false); }
  }

  async function confirmAuth() {
    if (!testerName.trim() || acks.length < REQUIRED_ACKS.length) return;
    try {
      await api.post(`/enterprise/scope/${wid}/confirm-authorization`, {
        confirmed: true,
        authorization_note: `Confirmed by ${testerName} for ${authType}`,
      });
      await api.post(`/enterprise/safety/confirm-authorization`, {
        workspace_id: wid,
        target_domain: scope?.program_profile?.scope_domains?.[0] || "*.target.com",
        tester_name: testerName,
        authorization_type: authType,
        confirmed: true,
        acknowledgments: acks,
      });
      setAuthConfirmed(true);
      await loadScope();
      setSuccess("Authorization confirmed — scanning is authorized");
    } catch (e: any) { setError(e.uiMessage || "Failed to confirm authorization"); }
  }

  async function loadAuditLog() {
    try {
      const r = await api.get(`/enterprise/scope/${wid}/audit-log?limit=50`);
      setAuditLog(r.data.audit_log || []);
    } catch {}
  }

  const tabs = [
    { id: "rules", label: "SCOPE RULES" },
    { id: "program", label: "PROGRAM IMPORT" },
    { id: "check", label: "TARGET CHECK" },
    { id: "audit", label: "AUDIT LOG" },
  ] as const;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white font-mono text-xl font-bold flex items-center gap-2">
            <Shield className="w-5 h-5 text-bmx-cyan" />
            SCOPE ENFORCEMENT ENGINE
          </h1>
          <p className="text-bmx-muted text-sm font-mono mt-0.5">
            Define authorized targets — only in-scope domains can be scanned
          </p>
        </div>
        <div className={`flex items-center gap-2 px-3 py-1.5 rounded border ${
          scope?.authorization_confirmed
            ? "bg-bmx-green/10 border-bmx-green/30 text-bmx-green"
            : "bg-bmx-yellow/10 border-bmx-yellow/30 text-bmx-yellow"
        }`}>
          {scope?.authorization_confirmed ? <CheckCircle className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
          <span className="text-xs font-mono">
            {scope?.authorization_confirmed ? "AUTHORIZED" : "AUTHORIZATION NEEDED"}
          </span>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "In-Scope Rules", value: scope?.include_rules.length || 0, color: "text-bmx-green" },
          { label: "Exclusions", value: scope?.exclude_rules.length || 0, color: "text-bmx-red" },
          { label: "Program", value: scope?.program_profile?.program_name || "None", color: "text-bmx-cyan", isText: true },
        ].map(s => (
          <div key={s.label} className="bmx-panel rounded-lg border border-bmx-border p-4">
            <div className={`${s.isText ? "text-sm" : "text-2xl"} font-mono font-bold ${s.color}`}>{s.value}</div>
            <div className="text-bmx-muted text-xs font-mono mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Authorization Banner */}
      {!scope?.authorization_confirmed && (
        <div className="bmx-panel rounded-lg border border-bmx-yellow/40 bg-bmx-yellow/5 p-5">
          <div className="flex items-start gap-3">
            <Lock className="w-5 h-5 text-bmx-yellow mt-0.5 shrink-0" />
            <div className="flex-1">
              <p className="text-bmx-yellow font-mono text-sm font-bold">AUTHORIZATION REQUIRED</p>
              <p className="text-bmx-muted text-xs font-mono mt-1 mb-4">
                You must confirm written authorization before scanning any target.
              </p>
              <div className="space-y-3">
                <input value={testerName} onChange={e => setTesterName(e.target.value)}
                  placeholder="Your name / handle"
                  className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm" />
                <select value={authType} onChange={e => setAuthType(e.target.value)}
                  className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm">
                  <option value="bug_bounty">Bug Bounty Program</option>
                  <option value="pentest">Authorized Penetration Test</option>
                  <option value="internal">Internal Security Assessment</option>
                  <option value="ctf">CTF / Lab Environment</option>
                </select>
                <div className="space-y-2">
                  {REQUIRED_ACKS.map(ack => (
                    <label key={ack} className="flex items-start gap-2 cursor-pointer">
                      <input type="checkbox" checked={acks.includes(ack)}
                        onChange={e => setAcks(prev => e.target.checked ? [...prev, ack] : prev.filter(a => a !== ack))}
                        className="mt-0.5" />
                      <span className="text-xs font-mono text-bmx-muted">{ack}</span>
                    </label>
                  ))}
                </div>
                <button onClick={confirmAuth}
                  disabled={!testerName.trim() || acks.length < REQUIRED_ACKS.length}
                  className="bg-bmx-yellow text-bmx-black font-mono font-bold text-sm px-4 py-2 rounded disabled:opacity-40">
                  CONFIRM AUTHORIZATION
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 border-b border-bmx-border">
        {tabs.map(t => (
          <button key={t.id} onClick={() => { setTab(t.id); if (t.id === "audit") loadAuditLog(); }}
            className={`px-4 py-2 text-xs font-mono tracking-wider transition-colors ${
              tab === t.id ? "text-bmx-cyan border-b-2 border-bmx-cyan" : "text-bmx-muted hover:text-white"
            }`}>
            {t.label}
          </button>
        ))}
      </div>

      {error && <div className="text-bmx-red text-xs font-mono bg-bmx-red/10 border border-bmx-red/30 rounded px-3 py-2">✗ {error}</div>}
      {success && <div className="text-bmx-green text-xs font-mono bg-bmx-green/10 border border-bmx-green/30 rounded px-3 py-2">✓ {success}</div>}

      {/* Rules Tab */}
      {tab === "rules" && (
        <div className="space-y-4">
          <div className="bmx-panel rounded-lg border border-bmx-border p-4 space-y-3">
            <p className="text-white font-mono text-xs tracking-wider">ADD SCOPE RULE</p>
            <div className="flex gap-3">
              <input value={newPattern} onChange={e => setNewPattern(e.target.value)}
                placeholder="*.example.com, example.com, 192.168.1.0/24"
                className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm" />
              <input value={newNotes} onChange={e => setNewNotes(e.target.value)}
                placeholder="Notes (optional)"
                className="w-48 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm" />
            </div>
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="radio" checked={!isExclusion} onChange={() => setIsExclusion(false)} />
                <span className="text-bmx-green text-xs font-mono">Include (in-scope)</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="radio" checked={isExclusion} onChange={() => setIsExclusion(true)} />
                <span className="text-bmx-red text-xs font-mono">Exclude (out-of-scope)</span>
              </label>
              <button onClick={addRule} disabled={loading || !newPattern.trim()}
                className="flex items-center gap-2 bg-bmx-cyan text-bmx-black font-mono font-bold text-xs px-4 py-2 rounded disabled:opacity-40">
                <Plus className="w-3.5 h-3.5" /> ADD
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <p className="text-bmx-green text-xs font-mono tracking-wider flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> IN-SCOPE ({scope?.include_rules.length || 0})
              </p>
              {(scope?.include_rules || []).map((r, i) => (
                <div key={i} className="bmx-panel rounded border border-bmx-green/20 px-3 py-2 flex items-center justify-between">
                  <div>
                    <span className="text-white font-mono text-xs">{r.pattern}</span>
                    {r.notes && <span className="text-bmx-muted text-xs font-mono ml-2">— {r.notes}</span>}
                    <span className="text-bmx-muted text-xs font-mono ml-2">[{r.source}]</span>
                  </div>
                </div>
              ))}
              {!scope?.include_rules.length && (
                <p className="text-bmx-muted text-xs font-mono italic">No inclusion rules — all targets allowed</p>
              )}
            </div>
            <div className="space-y-2">
              <p className="text-bmx-red text-xs font-mono tracking-wider flex items-center gap-1">
                <XCircle className="w-3.5 h-3.5" /> OUT-OF-SCOPE ({scope?.exclude_rules.length || 0})
              </p>
              {(scope?.exclude_rules || []).map((r, i) => (
                <div key={i} className="bmx-panel rounded border border-bmx-red/20 px-3 py-2 flex items-center justify-between">
                  <div>
                    <span className="text-white font-mono text-xs">{r.pattern}</span>
                    {r.notes && <span className="text-bmx-muted text-xs font-mono ml-2">— {r.notes}</span>}
                  </div>
                </div>
              ))}
              {!scope?.exclude_rules.length && (
                <p className="text-bmx-muted text-xs font-mono italic">No exclusions configured</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Program Import Tab */}
      {tab === "program" && (
        <div className="bmx-panel rounded-lg border border-bmx-border p-5 space-y-4">
          <p className="text-white font-mono text-xs tracking-wider">IMPORT BUG BOUNTY PROGRAM SCOPE</p>
          <div className="grid grid-cols-2 gap-3">
            <input value={programName} onChange={e => setProgramName(e.target.value)}
              placeholder="Program name (e.g. HackerOne — Acme Corp)"
              className="bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm" />
            <select value={programPlatform} onChange={e => setProgramPlatform(e.target.value)}
              className="bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm">
              <option value="hackerone">HackerOne</option>
              <option value="yeswehack">YesWeHack</option>
              <option value="intigriti">Intigriti</option>
              <option value="bugcrowd">Bugcrowd</option>
              <option value="private">Private Program</option>
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="text-bmx-green text-xs font-mono mb-1">IN-SCOPE DOMAINS (one per line)</p>
              <textarea value={programScopes} onChange={e => setProgramScopes(e.target.value)}
                rows={5} placeholder="*.example.com&#10;app.example.com&#10;api.example.com"
                className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-xs resize-none" />
            </div>
            <div>
              <p className="text-bmx-red text-xs font-mono mb-1">OUT-OF-SCOPE (one per line)</p>
              <textarea value={programOOS} onChange={e => setProgramOOS(e.target.value)}
                rows={5} placeholder="admin.example.com&#10;internal.example.com"
                className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-xs resize-none" />
            </div>
          </div>
          <textarea value={programRules} onChange={e => setProgramRules(e.target.value)}
            rows={3} placeholder="Program rules / special instructions (optional)"
            className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-xs resize-none" />
          <button onClick={importProgram} disabled={importing || !programName.trim()}
            className="flex items-center gap-2 bg-bmx-cyan text-bmx-black font-mono font-bold text-sm px-4 py-2 rounded disabled:opacity-40">
            <Upload className="w-4 h-4" /> {importing ? "IMPORTING..." : "IMPORT PROGRAM"}
          </button>
        </div>
      )}

      {/* Target Check Tab */}
      {tab === "check" && (
        <div className="space-y-4">
          <div className="bmx-panel rounded-lg border border-bmx-border p-4">
            <p className="text-white font-mono text-xs tracking-wider mb-3">CHECK TARGET SCOPE</p>
            <div className="flex gap-3">
              <input value={checkTarget} onChange={e => setCheckTarget(e.target.value)}
                onKeyDown={e => e.key === "Enter" && checkTargetScope()}
                placeholder="https://target.com or api.target.com or 192.168.1.1"
                className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm" />
              <button onClick={checkTargetScope}
                className="bg-bmx-cyan text-bmx-black font-mono font-bold text-sm px-4 py-2 rounded">
                CHECK
              </button>
            </div>
          </div>
          {checkResult && (
            <div className={`bmx-panel rounded-lg border p-5 ${
              checkResult.allowed ? "border-bmx-green/40 bg-bmx-green/5" : "border-bmx-red/40 bg-bmx-red/5"
            }`}>
              <div className="flex items-center gap-3 mb-3">
                {checkResult.allowed
                  ? <CheckCircle className="w-5 h-5 text-bmx-green" />
                  : <XCircle className="w-5 h-5 text-bmx-red" />}
                <span className={`font-mono font-bold ${checkResult.allowed ? "text-bmx-green" : "text-bmx-red"}`}>
                  {checkResult.allowed ? "IN SCOPE — SCANNING AUTHORIZED" : "OUT OF SCOPE — BLOCKED"}
                </span>
              </div>
              <div className="space-y-1 text-xs font-mono">
                <div><span className="text-bmx-muted">Target:</span> <span className="text-white">{checkResult.target}</span></div>
                <div><span className="text-bmx-muted">Reason:</span> <span className="text-white">{checkResult.reason}</span></div>
                {checkResult.matching_rule && (
                  <div><span className="text-bmx-muted">Matched rule:</span> <span className="text-bmx-cyan">{checkResult.matching_rule}</span></div>
                )}
                <div><span className="text-bmx-muted">Risk tier:</span> <span className="text-white">{checkResult.risk_tier}</span></div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Audit Log Tab */}
      {tab === "audit" && (
        <div className="bmx-panel rounded-lg border border-bmx-border overflow-hidden">
          <table className="w-full text-xs font-mono">
            <thead>
              <tr className="border-b border-bmx-border bg-bmx-dark">
                {["TIME", "TARGET", "ALLOWED", "REASON", "USER"].map(h => (
                  <th key={h} className="px-3 py-2 text-left text-bmx-muted tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {auditLog.map((entry, i) => (
                <tr key={i} className="border-b border-bmx-border/30 hover:bg-bmx-dark/50">
                  <td className="px-3 py-1.5 text-bmx-muted">{new Date(entry.timestamp).toLocaleTimeString()}</td>
                  <td className="px-3 py-1.5 text-white">{entry.target}</td>
                  <td className={`px-3 py-1.5 font-bold ${entry.allowed ? "text-bmx-green" : "text-bmx-red"}`}>
                    {entry.allowed ? "✓" : "✗"}
                  </td>
                  <td className="px-3 py-1.5 text-bmx-muted">{entry.reason}</td>
                  <td className="px-3 py-1.5 text-bmx-muted">{entry.user_id?.slice(0, 8)}</td>
                </tr>
              ))}
              {!auditLog.length && (
                <tr><td colSpan={5} className="px-3 py-6 text-center text-bmx-muted">No audit entries yet</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
