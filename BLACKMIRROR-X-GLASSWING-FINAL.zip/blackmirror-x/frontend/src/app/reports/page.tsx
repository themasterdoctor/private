"use client";
import { useEffect, useState } from "react";
import { useAppStore } from "@/store/app";
import { reportApi } from "@/lib/api";
import { FileText, Plus, Download, Eye, Clock, CheckCircle } from "lucide-react";

interface Report {
  id: string;
  title: string;
  format: string;
  status: string;
  scan_id: string;
  created_at: string;
  content?: string;
}

export default function ReportsPage() {
  const { activeWorkspace, scans, fetchScans , fetchWorkspaces} = useAppStore();
  const [reports, setReports] = useState<Report[]>([]);
  const [generating, setGenerating] = useState(false);
  const [selectedScan, setSelectedScan] = useState("");
  const [selectedFormat, setSelectedFormat] = useState("markdown");
  const [viewingReport, setViewingReport] = useState<Report | null>(null);


  useEffect(() => {
    if (!activeWorkspace) fetchWorkspaces();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (activeWorkspace) {
      reportApi.list(activeWorkspace.id).then((r) => setReports(r.data)).catch(() => {});
      fetchScans(activeWorkspace.id);
    }
  }, [activeWorkspace]);

  const generate = async () => {
    if (!selectedScan) return;
    setGenerating(true);
    try {
      const res = await reportApi.generate(selectedScan, selectedFormat);
      setReports((prev) => [res.data, ...prev]);
    } finally {
      setGenerating(false);
    }
  };

  const viewReport = async (report: Report) => {
    if (report.content) {
      setViewingReport(report);
      return;
    }
    const res = await reportApi.get(report.id);
    setViewingReport(res.data);
  };

  const downloadReport = (report: Report) => {
    const content = report.content || "";
    const ext = report.format === "json" ? "json" : "md";
    const blob = new Blob([content], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `report-${report.id.slice(0, 8)}.${ext}`;
    a.click();
  };

  return (
    <div className="p-6 space-y-4">
      <div>
        <h1 className="text-white font-mono text-xl font-bold">REPORTS</h1>
        <p className="text-bmx-muted text-sm font-mono mt-0.5">Generate and manage security reports</p>
      </div>

      {/* Generate panel */}
      <div className="bmx-panel rounded-lg border border-bmx-border p-4">
        <div className="flex items-center gap-2 mb-4">
          <Plus className="w-4 h-4 text-bmx-cyan" />
          <span className="text-white font-mono text-xs tracking-wider">GENERATE REPORT</span>
        </div>
        <div className="flex gap-3 flex-wrap">
          <select
            value={selectedScan}
            onChange={(e) => setSelectedScan(e.target.value)}
            className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan min-w-48"
          >
            <option value="">Select a scan...</option>
            {scans.map((s) => (
              <option key={s.id} value={s.id}>{s.target} — {new Date(s.created_at).toLocaleDateString()}</option>
            ))}
          </select>
          <select
            value={selectedFormat}
            onChange={(e) => setSelectedFormat(e.target.value)}
            className="bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan"
          >
            <option value="markdown">Markdown</option>
            <option value="json">JSON</option>
            <option value="hackerone">HackerOne</option>
            <option value="executive">Executive Summary</option>
          </select>
          <button
            onClick={generate}
            disabled={generating || !selectedScan}
            className="flex items-center gap-2 bg-bmx-cyan text-bmx-black font-mono font-bold text-sm px-4 py-2 rounded hover:bg-bmx-cyan/90 transition-colors disabled:opacity-50"
          >
            <FileText className="w-4 h-4" />
            {generating ? "GENERATING..." : "GENERATE"}
          </button>
        </div>
      </div>

      {/* Report list */}
      <div className="bmx-panel rounded-lg border border-bmx-border">
        <div className="p-4 border-b border-bmx-border">
          <span className="text-white font-mono text-xs tracking-wider">REPORT HISTORY</span>
        </div>
        <div className="divide-y divide-bmx-border">
          {reports.map((r) => (
            <div key={r.id} className="flex items-center gap-4 px-4 py-3">
              <div className={`p-2 rounded border ${
                r.status === "completed" ? "border-bmx-green/30 bg-bmx-green/10" : "border-bmx-border"
              }`}>
                {r.status === "completed"
                  ? <CheckCircle className="w-4 h-4 text-bmx-green" />
                  : <Clock className="w-4 h-4 text-bmx-muted animate-spin" />
                }
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white font-mono text-sm truncate">{r.title || `Report ${r.id.slice(0, 8)}`}</p>
                <p className="text-bmx-muted text-xs font-mono mt-0.5">
                  {r.format.toUpperCase()} • {new Date(r.created_at).toLocaleString()}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs font-mono border border-bmx-border text-bmx-muted px-2 py-0.5 rounded">
                  {r.format.toUpperCase()}
                </span>
                <button
                  onClick={() => viewReport(r)}
                  className="flex items-center gap-1.5 text-bmx-muted hover:text-white text-xs font-mono border border-bmx-border px-3 py-1.5 rounded hover:border-bmx-cyan transition-colors"
                >
                  <Eye className="w-3.5 h-3.5" /> VIEW
                </button>
                <button
                  onClick={() => downloadReport(r)}
                  className="flex items-center gap-1.5 text-bmx-muted hover:text-white text-xs font-mono border border-bmx-border px-3 py-1.5 rounded hover:border-bmx-cyan transition-colors"
                >
                  <Download className="w-3.5 h-3.5" /> DL
                </button>
              </div>
            </div>
          ))}
          {reports.length === 0 && (
            <div className="px-4 py-12 text-center text-bmx-muted font-mono text-sm">
              No reports generated yet.
            </div>
          )}
        </div>
      </div>

      {/* Report viewer modal */}
      {viewingReport && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-6">
          <div className="bmx-panel rounded-lg border border-bmx-border w-full max-w-4xl max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-bmx-border shrink-0">
              <span className="text-white font-mono text-sm">
                {viewingReport.title || "REPORT"}
              </span>
              <button
                onClick={() => setViewingReport(null)}
                className="text-bmx-muted hover:text-white text-xs font-mono"
              >
                ✕ CLOSE
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              <pre className="text-white font-mono text-xs leading-relaxed whitespace-pre-wrap">
                {viewingReport.content || "No content available."}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
