"use client";
import { useState, useEffect } from "react";
import { Plus, Key, User, Check, Copy, Trash2, Eye, EyeOff } from "lucide-react";
import { useAppStore } from "@/store/app";
import { workspaceApi, apiKeyApi } from "@/lib/api";

export default function SettingsPage() {
  const { workspaces, fetchWorkspaces, activeWorkspace, setActiveWorkspace } = useAppStore();

  const [tab, setTab] = useState<"workspaces" | "apikeys" | "account">("workspaces");

  // Workspace state
  const [newWsName, setNewWsName] = useState("");
  const [newWsDesc, setNewWsDesc] = useState("");
  const [wsLoading, setWsLoading] = useState(false);
  const [wsError, setWsError] = useState("");
  const [wsSuccess, setWsSuccess] = useState("");

  // API key state
  const [keys, setKeys] = useState<Array<{id: string; name: string; key_prefix: string; scopes: string[]; created_at: string}>>([]);
  const [newKeyName, setNewKeyName] = useState("");
  const [keyLoading, setKeyLoading] = useState(false);
  const [keyError, setKeyError] = useState("");
  const [createdKey, setCreatedKey] = useState("");
  const [copied, setCopied] = useState(false);
  const [showKey, setShowKey] = useState(false);

  useEffect(() => {
    fetchWorkspaces();
    loadKeys();
  }, []);

  const loadKeys = async () => {
    try {
      const r = await apiKeyApi.list();
      setKeys(r.data || []);
    } catch (e: unknown) {
      console.error("[Settings] Failed to load API keys:", e);
    }
  };

  const createWorkspace = async () => {
    if (!newWsName.trim()) {
      setWsError("Workspace name is required");
      return;
    }
    setWsLoading(true);
    setWsError("");
    setWsSuccess("");
    try {
      const r = await workspaceApi.create({ name: newWsName.trim(), description: newWsDesc.trim() || undefined });
      const created = r.data;
      setNewWsName("");
      setNewWsDesc("");
      await fetchWorkspaces();
      // Auto-select the new workspace
      setActiveWorkspace(created);
      setWsSuccess(`Workspace "${created.name}" created and selected`);
      setTimeout(() => setWsSuccess(""), 4000);
    } catch (err: unknown) {
      const e = err as { uiMessage?: string; message?: string };
      const msg = e.uiMessage || e.message || "Failed to create workspace";
      setWsError(msg);
      console.error("[Settings] Workspace create failed:", msg);
    } finally {
      setWsLoading(false);
    }
  };

  const createKey = async () => {
    if (!newKeyName.trim()) {
      setKeyError("Key name is required");
      return;
    }
    setKeyLoading(true);
    setKeyError("");
    setCreatedKey("");
    try {
      const r = await apiKeyApi.create({ name: newKeyName.trim(), scopes: ["read", "write"] });
      const data = r.data;
      setCreatedKey(data.raw_key || "");
      setShowKey(true);
      setNewKeyName("");
      await loadKeys();
    } catch (err: unknown) {
      const e = err as { uiMessage?: string; message?: string };
      const msg = e.uiMessage || e.message || "Failed to create API key";
      setKeyError(msg);
      console.error("[Settings] API key create failed:", msg);
    } finally {
      setKeyLoading(false);
    }
  };

  const revokeKey = async (id: string, name: string) => {
    if (!confirm(`Revoke key "${name}"?`)) return;
    try {
      await apiKeyApi.revoke(id);
      await loadKeys();
    } catch (err: unknown) {
      const e = err as { uiMessage?: string; message?: string };
      alert(`Failed to revoke: ${e.uiMessage || e.message}`);
    }
  };

  const copyKey = () => {
    if (createdKey) {
      navigator.clipboard.writeText(createdKey).catch(() => {});
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="p-6 space-y-4">
      <div>
        <h1 className="text-white font-mono text-xl font-bold">SETTINGS</h1>
        <p className="text-bmx-muted text-sm font-mono mt-0.5">Configure workspaces, API keys, and account</p>
      </div>

      <div className="flex gap-4 border-b border-bmx-border">
        {(["workspaces", "apikeys", "account"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`pb-3 text-xs font-mono tracking-wider transition-colors ${
              tab === t ? "text-bmx-cyan border-b-2 border-bmx-cyan" : "text-bmx-muted hover:text-white"
            }`}
          >
            {t.toUpperCase()}
          </button>
        ))}
      </div>

      {/* ── Workspaces ──────────────────────────────────────────────────────── */}
      {tab === "workspaces" && (
        <div className="space-y-4">

          {/* Create workspace */}
          <div className="bmx-panel rounded-lg border border-bmx-border p-4">
            <div className="flex items-center gap-2 mb-4">
              <Plus className="w-4 h-4 text-bmx-cyan" />
              <span className="text-white font-mono text-xs tracking-wider">NEW WORKSPACE</span>
            </div>

            <div className="space-y-3">
              <div className="flex gap-3">
                <input
                  value={newWsName}
                  onChange={(e) => setNewWsName(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && createWorkspace()}
                  placeholder="Workspace name (e.g. Acme Corp)"
                  className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan"
                />
                <input
                  value={newWsDesc}
                  onChange={(e) => setNewWsDesc(e.target.value)}
                  placeholder="Description (optional)"
                  className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan"
                />
                <button
                  onClick={createWorkspace}
                  disabled={wsLoading || !newWsName.trim()}
                  className="bg-bmx-cyan text-bmx-black font-mono font-bold text-sm px-4 py-2 rounded hover:bg-bmx-cyan/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {wsLoading ? "CREATING..." : "CREATE"}
                </button>
              </div>

              {wsError && (
                <div className="text-bmx-red text-xs font-mono bg-bmx-red/10 border border-bmx-red/30 rounded px-3 py-2">
                  ✗ {wsError}
                </div>
              )}
              {wsSuccess && (
                <div className="text-bmx-green text-xs font-mono bg-bmx-green/10 border border-bmx-green/30 rounded px-3 py-2">
                  ✓ {wsSuccess}
                </div>
              )}
            </div>
          </div>

          {/* Workspace list */}
          <div className="bmx-panel rounded-lg border border-bmx-border">
            <div className="px-4 py-3 border-b border-bmx-border">
              <span className="text-white font-mono text-xs tracking-wider">YOUR WORKSPACES</span>
            </div>
            <div className="divide-y divide-bmx-border">
              {workspaces.length === 0 && (
                <div className="p-4 text-bmx-muted text-sm font-mono">
                  No workspaces yet. Create one above.
                </div>
              )}
              {workspaces.map((ws) => (
                <div key={ws.id} className="flex items-center justify-between p-4">
                  <div>
                    <div className="text-white font-mono text-sm">{ws.name}</div>
                    {ws.description && (
                      <div className="text-bmx-muted text-xs font-mono mt-0.5">{ws.description}</div>
                    )}
                    <div className="text-bmx-muted/50 text-xs font-mono mt-0.5">{ws.id.slice(0, 8)}...</div>
                  </div>
                  <div className="flex items-center gap-3">
                    {activeWorkspace?.id === ws.id ? (
                      <span className="text-bmx-green text-xs font-mono flex items-center gap-1">
                        <Check className="w-3 h-3" /> ACTIVE
                      </span>
                    ) : (
                      <button
                        onClick={() => {
                          setActiveWorkspace(ws);
                          setWsSuccess(`Switched to "${ws.name}"`);
                          setTimeout(() => setWsSuccess(""), 2000);
                        }}
                        className="text-bmx-cyan text-xs font-mono border border-bmx-cyan/30 px-3 py-1 rounded hover:bg-bmx-cyan/10 transition-colors"
                      >
                        SELECT
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Active workspace indicator */}
          {activeWorkspace && (
            <div className="text-bmx-green text-xs font-mono bg-bmx-green/5 border border-bmx-green/20 rounded px-3 py-2">
              ✓ Active workspace: <strong>{activeWorkspace.name}</strong> ({activeWorkspace.id.slice(0, 8)})
              — dashboard Launch button is now enabled
            </div>
          )}
        </div>
      )}

      {/* ── API Keys ────────────────────────────────────────────────────────── */}
      {tab === "apikeys" && (
        <div className="space-y-4">

          {/* Create key */}
          <div className="bmx-panel rounded-lg border border-bmx-border p-4">
            <div className="flex items-center gap-2 mb-4">
              <Key className="w-4 h-4 text-bmx-orange" />
              <span className="text-white font-mono text-xs tracking-wider">CREATE API KEY</span>
            </div>
            <div className="space-y-3">
              <div className="flex gap-3">
                <input
                  value={newKeyName}
                  onChange={(e) => setNewKeyName(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && createKey()}
                  placeholder="Key name (e.g. CI Pipeline)"
                  className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-orange"
                />
                <button
                  onClick={createKey}
                  disabled={keyLoading || !newKeyName.trim()}
                  className="bg-bmx-orange text-bmx-black font-mono font-bold text-sm px-4 py-2 rounded hover:bg-bmx-orange/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {keyLoading ? "CREATING..." : "CREATE"}
                </button>
              </div>

              {keyError && (
                <div className="text-bmx-red text-xs font-mono bg-bmx-red/10 border border-bmx-red/30 rounded px-3 py-2">
                  ✗ {keyError}
                </div>
              )}

              {createdKey && (
                <div className="bg-bmx-green/10 border border-bmx-green/30 rounded p-3 space-y-2">
                  <div className="text-bmx-green text-xs font-mono">✓ API KEY CREATED — copy it now, it won&apos;t be shown again</div>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 text-xs font-mono text-white bg-bmx-black rounded px-2 py-1 break-all">
                      {showKey ? createdKey : "•".repeat(Math.min(createdKey.length, 40))}
                    </code>
                    <button onClick={() => setShowKey(!showKey)} className="text-bmx-muted hover:text-white">
                      {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                    <button onClick={copyKey} className="text-bmx-muted hover:text-bmx-green flex items-center gap-1 text-xs font-mono">
                      {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      {copied ? "Copied" : "Copy"}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Key list */}
          <div className="bmx-panel rounded-lg border border-bmx-border">
            <div className="px-4 py-3 border-b border-bmx-border">
              <span className="text-white font-mono text-xs tracking-wider">ACTIVE KEYS</span>
            </div>
            <div className="divide-y divide-bmx-border">
              {keys.length === 0 && (
                <div className="p-4 text-bmx-muted text-sm font-mono">No API keys. Create one above.</div>
              )}
              {keys.map((k) => (
                <div key={k.id} className="flex items-center justify-between p-4">
                  <div>
                    <div className="text-white font-mono text-sm">{k.name}</div>
                    <div className="text-bmx-muted text-xs font-mono mt-0.5">
                      {k.key_prefix}•••• · {k.scopes?.join(", ")}
                    </div>
                  </div>
                  <button
                    onClick={() => revokeKey(k.id, k.name)}
                    className="text-bmx-red hover:text-bmx-red/80 text-xs font-mono flex items-center gap-1"
                  >
                    <Trash2 className="w-3 h-3" /> REVOKE
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── Account ─────────────────────────────────────────────────────────── */}
      {tab === "account" && (
        <div className="bmx-panel rounded-lg border border-bmx-border p-4 space-y-3">
          <div className="flex items-center gap-2 mb-4">
            <User className="w-4 h-4 text-bmx-teal" />
            <span className="text-white font-mono text-xs tracking-wider">ACCOUNT</span>
          </div>
          <p className="text-bmx-muted text-sm font-mono">
            Logged in as admin. Change password and user settings coming soon.
          </p>
        </div>
      )}
    </div>
  );
}
