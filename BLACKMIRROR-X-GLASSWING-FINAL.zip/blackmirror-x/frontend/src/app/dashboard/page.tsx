"use client";
/**
 * BLACKMIRROR-X GLASSWING — Mission Control Dashboard
 * Real-time platform overview with AI recommendations, live scan tracking,
 * vulnerability breakdown, and quick launch panel.
 */
import { useEffect, useState, useCallback } from "react";
import { useAppStore } from "@/store/app";
import { getToken } from "@/lib/api";
import {
  Activity, AlertTriangle, Globe, Shield, Plus, ArrowRight,
  TrendingUp, Zap, Brain, ChevronRight, RefreshCw, Target,
  Clock, CheckCircle, XCircle, Wifi, Bug, Code2, Search
} from "lucide-react";
import Link from "next/link";

interface AIRecommendation {
  id: string;
  priority: "critical" | "high" | "medium";
  title: string;
  description: string;
  action_label: string;
  action_href: string;
  confidence: number;
}

const SEV_COLORS: Record<string, string> = {
  critical: "text-red-400 bg-red-400/10 border-red-400/20",
  high:     "text-orange-400 bg-orange-400/10 border-orange-400/20",
  medium:   "text-yellow-400 bg-yellow-400/10 border-yellow-400/20",
  low:      "text-blue-400 bg-blue-400/10 border-blue-400/20",
  info:     "text-gray-400 bg-gray-400/10 border-gray-400/20",
};

const STATUS_CONFIG: Record<string, { color: string; icon: React.ReactNode }> = {
  running:   { color: "text-bmx-cyan",  icon: <Activity className="w-3 h-3 animate-pulse" /> },
  completed: { color: "text-bmx-green", icon: <CheckCircle className="w-3 h-3" /> },
  failed:    { color: "text-bmx-red",   icon: <XCircle className="w-3 h-3" /> },
  queued:    { color: "text-bmx-yellow",icon: <Clock className="w-3 h-3" /> },
};

// AI recommendations generated from workspace state
function buildRecommendations(scans: unknown[], vulns: unknown[], subdomains: unknown[]): AIRecommendation[] {
  const recs: AIRecommendation[] = [];
  const typedVulns = vulns as Array<{severity: string; status: string; vuln_type: string}>;
  const typedScans = scans as Array<{status: string; completed_at?: string}>;

  const criticals = typedVulns.filter(v => v.severity === "critical" && v.status === "open");
  if (criticals.length > 0) {
    recs.push({
      id: "critical-open",
      priority: "critical",
      title: `${criticals.length} critical finding${criticals.length > 1 ? "s" : ""} need immediate triage`,
      description: `${criticals.length} open critical vulnerabilities detected. Prioritize exploitation analysis and remediation validation.`,
      action_label: "Triage Now",
      action_href: "/vulns?severity=critical",
      confidence: 0.99,
    });
  }

  const recentScans = typedScans.filter(s => s.status === "completed" && s.completed_at);
  if (recentScans.length > 0 && subdomains.length > 50) {
    recs.push({
      id: "large-surface",
      priority: "high",
      title: `${subdomains.length} subdomains discovered — run attack chain analysis`,
      description: "Large attack surface detected. AI can correlate subdomains with vulnerabilities to identify multi-hop attack paths.",
      action_label: "Build Attack Chains",
      action_href: "/chains",
      confidence: 0.87,
    });
  }

  const xssVulns = typedVulns.filter(v => v.vuln_type === "xss" && v.status === "open");
  const ssrfVulns = typedVulns.filter(v => v.vuln_type === "ssrf" && v.status === "open");
  if (xssVulns.length > 0 && ssrfVulns.length > 0) {
    recs.push({
      id: "xss-ssrf-chain",
      priority: "high",
      title: "XSS + SSRF chain opportunity detected",
      description: `${xssVulns.length} XSS and ${ssrfVulns.length} SSRF findings may be chainable. Ask Copilot to build an exploit chain.`,
      action_label: "Analyze with Copilot",
      action_href: "/copilot",
      confidence: 0.72,
    });
  }

  if (typedScans.filter(s => s.status === "completed").length > 0 && recs.length < 3) {
    recs.push({
      id: "js-analysis",
      priority: "medium",
      title: "Run JavaScript Intelligence Analysis",
      description: "Deep JS bundle analysis can reveal API endpoints, secrets, and DOM XSS sinks that scanners miss.",
      action_label: "Launch JS Scan",
      action_href: "/workflows",
      confidence: 0.65,
    });
  }

  if (recs.length === 0) {
    recs.push({
      id: "first-scan",
      priority: "medium",
      title: "Launch your first scan to get AI insights",
      description: "GLASSWING AI analyzes your findings and generates actionable attack path recommendations in real time.",
      action_label: "Launch Scan",
      action_href: "/workflows",
      confidence: 1.0,
    });
  }

  return recs.slice(0, 4);
}

const PRIORITY_STYLE = {
  critical: "border-red-500/40 bg-red-500/5 hover:border-red-500/60",
  high:     "border-orange-500/30 bg-orange-500/5 hover:border-orange-500/50",
  medium:   "border-bmx-border bg-bmx-dark/30 hover:border-bmx-border/80",
};

const PRIORITY_DOT = {
  critical: "bg-red-500",
  high:     "bg-orange-400",
  medium:   "bg-bmx-muted",
};

export default function DashboardPage() {
  const { scans, vulns, subdomains, fetchScans, fetchVulns, fetchSubdomains, activeWorkspace, createScan } = useAppStore();
  const [newTarget, setNewTarget] = useState("");
  const [launching, setLaunching] = useState(false);
  const [scanType, setScanType] = useState("recon");
  const [launchMsg, setLaunchMsg] = useState<{ type: "ok"|"err"; text: string } | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const refresh = useCallback(async (silent = false) => {
    if (!activeWorkspace) return;
    if (!silent) setRefreshing(true);
    await Promise.all([
      fetchScans(activeWorkspace.id),
      fetchVulns({ workspace_id: activeWorkspace.id }),
      fetchSubdomains({ workspace_id: activeWorkspace.id }),
    ]);
    if (!silent) setRefreshing(false);
  }, [activeWorkspace, fetchScans, fetchVulns, fetchSubdomains]);

  useEffect(() => {
    if (activeWorkspace) {
      refresh(true);
      // Poll every 30s for live updates
      const interval = setInterval(() => refresh(true), 30000);
      return () => clearInterval(interval);
    }
  }, [activeWorkspace]); // eslint-disable-line react-hooks/exhaustive-deps

  const launchScan = async () => {
    if (!newTarget.trim() || !activeWorkspace) return;
    setLaunching(true);
    setLaunchMsg(null);
    try {
      const domain = newTarget.trim().replace(/^https?:\/\//, "").split("/")[0].split("?")[0];
      await createScan({
        name: `Scan — ${domain}`,
        target: newTarget.trim(),
        workspace_id: activeWorkspace.id,
        scan_type: scanType,
        config: { domain },
      });
      setNewTarget("");
      setLaunchMsg({ type: "ok", text: `Scan launched: ${domain}` });
      await fetchScans(activeWorkspace.id);
      setTimeout(() => setLaunchMsg(null), 4000);
    } catch (err: unknown) {
      const e = err as { uiMessage?: string; message?: string };
      setLaunchMsg({ type: "err", text: e.uiMessage || e.message || "Failed to launch scan" });
    } finally {
      setLaunching(false);
    }
  };

  const totalVulns = vulns.length;
  const criticals  = vulns.filter(v => v.severity === "critical").length;
  const highs      = vulns.filter(v => v.severity === "high").length;
  const running    = scans.filter(s => s.status === "running").length;
  const completed  = scans.filter(s => s.status === "completed").length;
  const recs       = buildRecommendations(scans, vulns, subdomains);

  const STATS = [
    { label: "Active Scans",     value: running,           icon: Activity,      color: "text-bmx-cyan",   bg: "bg-bmx-cyan/5 border-bmx-cyan/20" },
    { label: "Vulnerabilities",  value: totalVulns,        icon: AlertTriangle, color: "text-bmx-orange", bg: "bg-bmx-orange/5 border-bmx-orange/20" },
    { label: "Subdomains",       value: subdomains.length, icon: Globe,         color: "text-bmx-teal",   bg: "bg-bmx-teal/5 border-bmx-teal/20" },
    { label: "Critical Findings",value: criticals,         icon: Shield,        color: "text-bmx-red",    bg: "bg-bmx-red/5 border-bmx-red/20" },
  ];

  return (
    <div className="p-6 space-y-5 max-w-screen-2xl mx-auto">

      {/* ── Header ──────────────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white font-mono text-xl font-bold tracking-tight">MISSION CONTROL</h1>
          <p className="text-bmx-muted font-mono text-xs mt-0.5">
            {activeWorkspace?.name || "No workspace"} · {new Date().toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" })}
          </p>
        </div>
        <div className="flex items-center gap-3">
          {running > 0 && (
            <div className="flex items-center gap-1.5 border border-bmx-cyan/30 bg-bmx-cyan/5 rounded px-3 py-1.5">
              <Wifi className="w-3 h-3 text-bmx-cyan animate-pulse" />
              <span className="text-bmx-cyan font-mono text-xs">{running} scanning</span>
            </div>
          )}
          <button onClick={() => refresh()} disabled={refreshing}
            className="flex items-center gap-1.5 border border-bmx-border text-bmx-muted hover:text-white px-3 py-1.5 rounded text-xs font-mono transition-colors">
            <RefreshCw className={`w-3 h-3 ${refreshing ? "animate-spin" : ""}`} />
            Refresh
          </button>
        </div>
      </div>

      {!activeWorkspace && (
        <div className="border border-bmx-yellow/30 bg-bmx-yellow/5 rounded-lg p-4 font-mono text-bmx-yellow text-sm">
          ⚠ No workspace selected.{" "}
          <Link href="/settings" className="underline text-bmx-cyan">Create one in Settings →</Link>
        </div>
      )}

      {/* ── Quick Launch ─────────────────────────────────────── */}
      <div className="bmx-panel rounded-xl border border-bmx-border p-5 bg-gradient-to-br from-bmx-dark to-bmx-black">
        <div className="flex items-center gap-2 mb-4">
          <Zap className="w-4 h-4 text-bmx-cyan" />
          <span className="text-white font-mono text-xs font-bold tracking-wider">QUICK LAUNCH</span>
        </div>
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Target className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-bmx-muted" />
            <input
              value={newTarget}
              onChange={e => setNewTarget(e.target.value)}
              onKeyDown={e => e.key === "Enter" && launchScan()}
              placeholder="target.com or https://app.target.com"
              className="w-full bg-bmx-black border border-bmx-border rounded-lg pl-9 pr-3 py-2.5 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan transition-colors placeholder:text-bmx-muted/40"
            />
          </div>
          <select value={scanType} onChange={e => setScanType(e.target.value)}
            className="bg-bmx-black border border-bmx-border rounded-lg px-3 py-2.5 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan">
            <option value="recon">Full Recon</option>
            <option value="js_analysis">JS Analysis</option>
            <option value="api_audit">API Audit</option>
            <option value="full">Full Scan</option>
          </select>
          <button onClick={launchScan} disabled={launching || !newTarget.trim() || !activeWorkspace}
            className="flex items-center gap-2 bg-bmx-cyan text-bmx-black font-mono font-bold text-sm px-5 py-2.5 rounded-lg hover:bg-bmx-cyan/90 transition-colors disabled:opacity-50 shrink-0">
            <Plus className="w-4 h-4" />
            {launching ? "LAUNCHING..." : "LAUNCH"}
          </button>
        </div>
        {launchMsg && (
          <div className={`mt-3 text-xs font-mono rounded px-3 py-2 border ${
            launchMsg.type === "ok"
              ? "text-bmx-green bg-bmx-green/5 border-bmx-green/30"
              : "text-bmx-red bg-bmx-red/5 border-bmx-red/30"
          }`}>
            {launchMsg.type === "ok" ? "✓" : "✗"} {launchMsg.text}
          </div>
        )}
        <div className="flex gap-3 mt-3">
          {[
            { href: "/workflows", icon: <Play className="w-3 h-3" />, label: "Workflow Launcher" },
            { href: "/copilot",   icon: <Brain className="w-3 h-3" />, label: "Ask AI Copilot" },
            { href: "/scope",     icon: <Shield className="w-3 h-3" />, label: "Manage Scope" },
          ].map(l => (
            <Link key={l.href} href={l.href}
              className="flex items-center gap-1.5 text-bmx-muted/60 hover:text-bmx-cyan font-mono text-xs transition-colors">
              {l.icon} {l.label} <ChevronRight className="w-2.5 h-2.5" />
            </Link>
          ))}
        </div>
      </div>

      {/* ── Stats ────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
        {STATS.map(s => (
          <div key={s.label} className={`bmx-panel rounded-xl border p-4 ${s.bg}`}>
            <div className="flex items-center justify-between mb-3">
              <s.icon className={`w-5 h-5 ${s.color}`} />
              <TrendingUp className="w-3.5 h-3.5 text-bmx-muted/30" />
            </div>
            <div className={`text-3xl font-mono font-bold ${s.color}`}>{s.value}</div>
            <div className="text-bmx-muted text-xs font-mono mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      {/* ── Main grid: AI Recs + Vuln Summary + Recent Scans ── */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">

        {/* AI Recommendations — spans 1 col */}
        <div className="bmx-panel rounded-xl border border-bmx-border overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-bmx-border bg-gradient-to-r from-bmx-dark to-transparent">
            <Brain className="w-4 h-4 text-bmx-cyan" />
            <span className="text-white font-mono text-xs font-bold tracking-wider">AI RECOMMENDATIONS</span>
            <span className="ml-auto text-[9px] font-mono border border-bmx-cyan/30 text-bmx-cyan px-1.5 py-0.5 rounded bg-bmx-cyan/5">
              GLASSWING AI
            </span>
          </div>
          <div className="p-3 space-y-2">
            {recs.map(rec => (
              <Link key={rec.id} href={rec.action_href}
                className={`block border rounded-lg p-3 transition-colors group ${PRIORITY_STYLE[rec.priority]}`}>
                <div className="flex items-start gap-2">
                  <span className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${PRIORITY_DOT[rec.priority]}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-mono text-xs font-medium leading-tight">{rec.title}</p>
                    <p className="text-bmx-muted/60 font-mono text-[10px] mt-1 leading-relaxed">{rec.description}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between mt-2 pt-2 border-t border-bmx-border/50">
                  <span className="text-bmx-cyan/70 font-mono text-[10px] group-hover:text-bmx-cyan transition-colors">
                    {rec.action_label} →
                  </span>
                  <span className="text-bmx-muted/30 font-mono text-[9px]">
                    {Math.round(rec.confidence * 100)}% confidence
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Vulnerability Breakdown */}
        <div className="bmx-panel rounded-xl border border-bmx-border overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-bmx-border">
            <AlertTriangle className="w-4 h-4 text-bmx-orange" />
            <span className="text-white font-mono text-xs font-bold tracking-wider">VULN BREAKDOWN</span>
            <Link href="/vulns" className="ml-auto flex items-center gap-1 text-bmx-cyan text-xs font-mono hover:underline">
              VIEW ALL <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="p-4 space-y-3">
            {["critical","high","medium","low","info"].map(sev => {
              const count = vulns.filter(v => v.severity === sev).length;
              const pct = totalVulns > 0 ? (count / totalVulns) * 100 : 0;
              return (
                <div key={sev}>
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-xs font-mono ${sev === "critical" ? "text-red-400" : sev === "high" ? "text-orange-400" : sev === "medium" ? "text-yellow-400" : sev === "low" ? "text-blue-400" : "text-gray-400"}`}>
                      {sev.toUpperCase()}
                    </span>
                    <span className="text-bmx-muted font-mono text-xs">{count}</span>
                  </div>
                  <div className="h-1.5 bg-bmx-border rounded-full overflow-hidden">
                    <div className={`h-full rounded-full transition-all duration-500 ${
                      sev === "critical" ? "bg-red-500" : sev === "high" ? "bg-orange-400" :
                      sev === "medium" ? "bg-yellow-400" : sev === "low" ? "bg-blue-400" : "bg-gray-500"
                    }`} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
            {totalVulns === 0 && (
              <p className="text-bmx-muted/40 font-mono text-xs text-center py-4">No vulnerabilities found yet.</p>
            )}
          </div>

          {/* Quick links */}
          <div className="border-t border-bmx-border px-4 py-3 space-y-1.5">
            {[
              { href: "/vulns", icon: Bug, label: "Browse all findings" },
              { href: "/evidence", icon: Code2, label: "Evidence vault" },
              { href: "/reports", icon: Search, label: "Generate report" },
            ].map(l => (
              <Link key={l.href} href={l.href}
                className="flex items-center gap-2 text-bmx-muted/60 hover:text-white font-mono text-xs transition-colors">
                <l.icon className="w-3 h-3" /> {l.label}
              </Link>
            ))}
          </div>
        </div>

        {/* Recent Scans */}
        <div className="bmx-panel rounded-xl border border-bmx-border overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-bmx-border">
            <Clock className="w-4 h-4 text-bmx-cyan" />
            <span className="text-white font-mono text-xs font-bold tracking-wider">RECENT SCANS</span>
            <Link href="/recon" className="ml-auto flex items-center gap-1 text-bmx-cyan text-xs font-mono hover:underline">
              ALL <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="divide-y divide-bmx-border/50">
            {scans.slice(0, 6).map(scan => {
              const sc = STATUS_CONFIG[scan.status] || { color: "text-bmx-muted", icon: null };
              return (
                <Link key={scan.id} href={`/scans/${scan.id}`}
                  className="flex items-center gap-3 px-4 py-3 hover:bg-bmx-dark/40 transition-colors group">
                  <div className={`shrink-0 ${sc.color}`}>{sc.icon}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-mono text-xs truncate">{scan.target || scan.name}</p>
                    <p className="text-bmx-muted/50 font-mono text-[10px] mt-0.5">
                      {scan.scan_type} · {new Date(scan.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0 text-[10px] font-mono">
                    <span className="text-bmx-muted/40">{scan.subdomain_count ?? 0}s</span>
                    <span className={scan.vuln_count ? "text-bmx-orange" : "text-bmx-muted/40"}>{scan.vuln_count ?? 0}v</span>
                    <ArrowRight className="w-3 h-3 text-bmx-muted opacity-0 group-hover:opacity-60 transition-opacity" />
                  </div>
                </Link>
              );
            })}
            {scans.length === 0 && (
              <div className="px-4 py-8 text-center text-bmx-muted/40 font-mono text-xs">
                No scans yet. Launch one above.
              </div>
            )}
          </div>
          {/* Scan stats footer */}
          <div className="border-t border-bmx-border px-4 py-2 flex gap-4 text-[10px] font-mono text-bmx-muted/40">
            <span>{scans.length} total</span>
            <span className="text-bmx-green">{completed} completed</span>
            {running > 0 && <span className="text-bmx-cyan">{running} running</span>}
          </div>
        </div>
      </div>
    </div>
  );
}
// missing import
function Play({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M5 3l14 9-14 9V3z"/></svg>;
}
