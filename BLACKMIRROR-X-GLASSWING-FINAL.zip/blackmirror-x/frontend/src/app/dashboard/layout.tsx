"use client";
import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard, Search, Bug, Network, FileText,
  Users, CheckCircle, Settings, MessageSquare, ChevronLeft, ChevronRight,
  Shield, LogOut, Activity, Brain, Scale, Database, Rss, Zap,
  User, Cpu, Globe, Link2, Layers, Server, Play, Command, Code2
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuthStore } from "@/store/auth";
import { useAppStore } from "@/store/app";
import { CommandPalette } from "@/components/ui/command-palette";

interface NavItem { href: string; icon: React.ElementType; label: string; color: string; badge?: string; }
interface NavSection { label: string; items: NavItem[]; }

const NAV_SECTIONS: NavSection[] = [
  {
    label: "CORE",
    items: [
      { href: "/dashboard",  icon: LayoutDashboard, label: "Dashboard",      color: "text-bmx-cyan" },
      { href: "/recon",      icon: Search,          label: "Recon",          color: "text-bmx-teal" },
      { href: "/vulns",      icon: Bug,             label: "Vulnerabilities",color: "text-bmx-red" },
      { href: "/graph",      icon: Network,         label: "Attack Graph",   color: "text-bmx-orange" },
    ],
  },
  {
    label: "INTELLIGENCE",
    items: [
      { href: "/mission",    icon: Brain,           label: "Mission Control",color: "text-bmx-cyan",   badge: "AI" },
      { href: "/court",      icon: Scale,           label: "AI Courtroom",  color: "text-purple-400", badge: "AI" },
      { href: "/evidence",   icon: Database,        label: "Evidence Vault", color: "text-bmx-green" },
      { href: "/monitor",    icon: Rss,             label: "Monitor",        color: "text-bmx-orange" },
      { href: "/replay",     icon: Zap,             label: "Replay Lab",     color: "text-bmx-yellow" },
    ],
  },
  {
    label: "WORKSPACE",
    items: [
      { href: "/copilot",    icon: MessageSquare,   label: "AI Copilot",    color: "text-bmx-green" },
      { href: "/workflows",  icon: Play,            label: "Workflows",     color: "text-bmx-cyan" },
      { href: "/reports",    icon: FileText,        label: "Reports",       color: "text-blue-400" },
      { href: "/settings",   icon: Settings,        label: "Settings",      color: "text-gray-400" },
    ],
  },
  {
    label: "AVROS",
    items: [
      { href: "/orchestrator",  icon: Cpu,    label: "Orchestrator",  color: "text-bmx-cyan",   badge: "AI" },
      { href: "/browser-intel", icon: Globe,  label: "Browser Intel", color: "text-bmx-teal" },
      { href: "/api-intel",     icon: Link2,  label: "API Intel",     color: "text-bmx-orange" },
      { href: "/chains",        icon: Layers, label: "Attack Chains", color: "text-bmx-red" },
      { href: "/memory",        icon: Database,label: "Memory",       color: "text-purple-400" },
      { href: "/workers",       icon: Server, label: "Workers",       color: "text-bmx-green" },
      { href: "/payloads",      icon: Code2,  label: "Payload Lab",   color: "text-bmx-yellow" },
    ],
  },
  {
    label: "ENTERPRISE",
    items: [
      { href: "/scope",      icon: Shield,       label: "Scope Engine", color: "text-bmx-yellow", badge: "ENT" },
      { href: "/approvals",  icon: CheckCircle,  label: "Approvals",    color: "text-bmx-orange", badge: "ENT" },
      { href: "/team",       icon: Users,        label: "Team",         color: "text-bmx-cyan",   badge: "ENT" },
    ],
  },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [cmdOpen, setCmdOpen] = useState(false);
  const pathname = usePathname();
  const { user, logout } = useAuthStore();
  const { fetchWorkspaces, activeWorkspace, scans } = useAppStore();

  useEffect(() => { fetchWorkspaces(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ⌘K / Ctrl+K to open command palette
  const handleGlobalKey = useCallback((e: KeyboardEvent) => {
    if ((e.metaKey || e.ctrlKey) && e.key === "k") {
      e.preventDefault();
      setCmdOpen(prev => !prev);
    }
  }, []);

  useEffect(() => {
    window.addEventListener("keydown", handleGlobalKey);
    return () => window.removeEventListener("keydown", handleGlobalKey);
  }, [handleGlobalKey]);

  const runningCount = scans.filter(s => s.status === "running").length;

  return (
    <div className="flex h-screen bg-bmx-black overflow-hidden">
      {/* Command Palette */}
      <CommandPalette open={cmdOpen} onClose={() => setCmdOpen(false)} />

      {/* Sidebar */}
      <motion.aside
        animate={{ width: collapsed ? 56 : 220 }}
        transition={{ duration: 0.18, ease: "easeInOut" }}
        className="flex-shrink-0 bg-bmx-dark border-r border-bmx-border flex flex-col relative z-10"
      >
        {/* Logo */}
        <div className="h-13 flex items-center px-3 py-3 border-b border-bmx-border overflow-hidden gap-2.5">
          <div className="w-7 h-7 rounded bg-bmx-cyan/10 border border-bmx-cyan/30 flex items-center justify-center shrink-0">
            <Shield className="w-3.5 h-3.5 text-bmx-cyan" />
          </div>
          <AnimatePresence>
            {!collapsed && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="overflow-hidden leading-none">
                <div className="text-[11px] font-bold text-bmx-cyan tracking-[0.2em] font-mono">BLACKMIRROR</div>
                <div className="text-[9px] text-bmx-teal/80 tracking-[0.25em] font-mono mt-0.5">GLASSWING v2</div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Search / Command Palette trigger */}
        {!collapsed && (
          <button
            onClick={() => setCmdOpen(true)}
            className="mx-2 mt-2 mb-1 flex items-center gap-2 px-2.5 py-1.5 rounded border border-bmx-border text-bmx-muted/50 hover:text-bmx-muted hover:border-bmx-border/80 transition-colors text-xs font-mono group"
          >
            <Search className="w-3 h-3" />
            <span className="flex-1 text-left">Search...</span>
            <kbd className="text-[9px] border border-bmx-border/50 rounded px-1 py-0.5 group-hover:border-bmx-muted/30">⌘K</kbd>
          </button>
        )}
        {collapsed && (
          <button onClick={() => setCmdOpen(true)}
            className="mx-auto mt-2 mb-1 flex items-center justify-center w-8 h-8 rounded border border-bmx-border text-bmx-muted/50 hover:text-bmx-cyan hover:border-bmx-cyan/30 transition-colors">
            <Command className="w-3.5 h-3.5" />
          </button>
        )}

        {/* Nav */}
        <nav className="flex-1 py-2 overflow-y-auto overflow-x-hidden scrollbar-thin">
          {NAV_SECTIONS.map((section) => (
            <div key={section.label} className="mb-1.5">
              <AnimatePresence>
                {!collapsed && (
                  <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                    className="px-3 py-0.5 text-[9px] font-mono tracking-[0.2em] text-bmx-muted/30 uppercase">
                    {section.label}
                  </motion.p>
                )}
              </AnimatePresence>
              <div className="space-y-px px-1.5">
                {section.items.map((item) => {
                  const isActive = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href));
                  const Icon = item.icon;
                  return (
                    <Link key={item.href} href={item.href}>
                      <div className={cn(
                        "flex items-center gap-2 px-2 py-1.5 rounded text-xs transition-all duration-100 cursor-pointer",
                        collapsed ? "justify-center" : "",
                        isActive
                          ? "bg-bmx-border/80 text-white"
                          : "text-bmx-muted/60 hover:text-white hover:bg-bmx-border/30"
                      )}>
                        <Icon className={cn("w-3.5 h-3.5 shrink-0", isActive ? item.color : "")} />
                        <AnimatePresence>
                          {!collapsed && (
                            <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                              className="font-mono truncate flex-1 text-[11px]">
                              {item.label}
                            </motion.span>
                          )}
                        </AnimatePresence>
                        {!collapsed && item.badge && (
                          <span className="text-[8px] font-mono bg-bmx-cyan/10 text-bmx-cyan border border-bmx-cyan/20 px-1 py-0.5 rounded shrink-0">
                            {item.badge}
                          </span>
                        )}
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* User footer */}
        <div className="border-t border-bmx-border p-1.5">
          <AnimatePresence>
            {!collapsed && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-bmx-border/30 transition-colors">
                <div className="w-5 h-5 rounded-full bg-bmx-cyan/10 border border-bmx-cyan/20 flex items-center justify-center shrink-0">
                  <User className="w-2.5 h-2.5 text-bmx-cyan" />
                </div>
                <p className="text-white font-mono text-[11px] truncate flex-1">
                  {user?.email?.split("@")[0] || "admin"}
                </p>
                <button onClick={logout} title="Logout"
                  className="text-bmx-muted/40 hover:text-bmx-red transition-colors p-0.5">
                  <LogOut className="w-3 h-3" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
          <button onClick={() => setCollapsed(!collapsed)}
            className="w-full flex items-center justify-center py-1.5 text-bmx-muted/30 hover:text-bmx-muted transition-colors rounded hover:bg-bmx-border/20">
            {collapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
          </button>
        </div>
      </motion.aside>

      {/* Main */}
      <main className="flex-1 overflow-hidden flex flex-col min-w-0">
        {/* Top bar */}
        <div className="h-11 border-b border-bmx-border flex items-center px-5 gap-3 bg-bmx-dark/40 flex-shrink-0">
          {/* Workspace indicator */}
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-1.5 h-1.5 rounded-full bg-bmx-green animate-pulse shrink-0" />
            <span className="text-bmx-muted font-mono text-[11px] truncate">
              {activeWorkspace?.name || "No workspace"}
            </span>
          </div>

          <div className="flex-1" />

          {/* Running scans indicator */}
          {runningCount > 0 && (
            <div className="flex items-center gap-1.5 px-2 py-1 rounded border border-bmx-cyan/20 bg-bmx-cyan/5">
              <Activity className="w-3 h-3 text-bmx-cyan animate-pulse" />
              <span className="text-bmx-cyan font-mono text-[10px]">{runningCount} SCANNING</span>
            </div>
          )}

          {/* Command palette shortcut */}
          <button onClick={() => setCmdOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded border border-bmx-border text-bmx-muted/40 hover:text-bmx-muted hover:border-bmx-border/80 transition-colors text-[10px] font-mono">
            <Command className="w-3 h-3" />
            <span className="hidden sm:inline">⌘K</span>
          </button>

          {/* AI status */}
          <div className="flex items-center gap-1.5 text-[10px] font-mono text-bmx-muted/40">
            <span className="w-1.5 h-1.5 rounded-full bg-bmx-green" />
            <span>GLASSWING AI</span>
          </div>
        </div>

        {/* Page content */}
        <div className="flex-1 overflow-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
