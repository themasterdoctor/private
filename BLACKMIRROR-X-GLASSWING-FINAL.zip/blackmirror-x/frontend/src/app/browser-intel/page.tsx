"use client";
import { useEffect, useState } from "react";
import { Globe, AlertCircle, CheckCircle, Camera, Code2, Link2, Wifi } from "lucide-react";

const API = process.env.NEXT_PUBLIC_API_URL || "";

interface CapabilityStatus {
  playwright_available: boolean;
  browser_started: boolean;
  active_sessions: number;
  install_cmd?: string;
}

interface DOMSnapshot {
  url: string;
  title: string;
  form_count: number;
  forms: Array<{ action: string; method: string; field_count: number; has_csrf_token: boolean }>;
  input_count: number;
  link_count: number;
  script_count: number;
  dom_xss_sinks: string[];
  inline_event_handlers: string[];
}

interface SPAResult {
  url: string;
  static_routes: Array<{ path: string; params: string[]; discovered_via: string }>;
  dynamic_routes: Array<{ path: string; params: string[]; discovered_via: string }>;
  total_unique_paths: number;
  playwright_used: boolean;
}

export default function BrowserIntelPage() {
  const [status, setStatus] = useState<CapabilityStatus | null>(null);
  const [targetUrl, setTargetUrl] = useState("http://localhost:9001");
  const [domResult, setDomResult] = useState<DOMSnapshot | null>(null);
  const [spaResult, setSpaResult] = useState<SPAResult | null>(null);
  const [loading, setLoading] = useState<string>("");
  const [activeTab, setActiveTab] = useState<"dom" | "spa" | "storage" | "ws">("dom");

  const getToken = () => localStorage.getItem("bmx_access_token") || "";

  async function fetchStatus() {
    try {
      const r = await fetch(`${API}/api/v1/browser-intel/status`, {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      if (r.ok) setStatus(await r.json());
    } catch {/* */}
  }

  useEffect(() => { fetchStatus(); }, []);

  async function runDomSnapshot() {
    setLoading("dom");
    try {
      const r = await fetch(`${API}/api/v1/browser-intel/dom-snapshot?url=${encodeURIComponent(targetUrl)}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      if (r.ok) setDomResult(await r.json());
    } catch {/* */} finally { setLoading(""); }
  }

  async function runSpaMapper() {
    setLoading("spa");
    try {
      const r = await fetch(`${API}/api/v1/browser-intel/spa-routes?url=${encodeURIComponent(targetUrl)}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      if (r.ok) setSpaResult(await r.json());
    } catch {/* */} finally { setLoading(""); }
  }

  const tabs = [
    { id: "dom", label: "DOM Snapshot", icon: Code2 },
    { id: "spa", label: "SPA Routes", icon: Link2 },
    { id: "storage", label: "Storage", icon: Globe },
    { id: "ws", label: "WebSocket", icon: Wifi },
  ] as const;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Globe className="w-6 h-6 text-bmx-teal" />
        <div>
          <h1 className="text-xl font-bold text-white font-mono">Browser Intelligence</h1>
          <p className="text-xs text-bmx-muted">Authenticated sessions, DOM analysis, SPA route discovery</p>
        </div>
      </div>

      {/* Capability Status */}
      {status && (
        <div className={`border rounded-lg p-4 ${status.playwright_available
          ? "border-bmx-green/30 bg-bmx-green/5"
          : "border-bmx-yellow/30 bg-bmx-yellow/5"}`}
        >
          <div className="flex items-start gap-3">
            {status.playwright_available
              ? <CheckCircle className="w-5 h-5 text-bmx-green flex-shrink-0 mt-0.5" />
              : <AlertCircle className="w-5 h-5 text-bmx-yellow flex-shrink-0 mt-0.5" />}
            <div>
              <div className={`text-sm font-mono font-semibold ${status.playwright_available ? "text-bmx-green" : "text-bmx-yellow"}`}>
                {status.playwright_available ? "Playwright Available" : "Playwright Not Installed"}
              </div>
              <div className="text-xs text-bmx-muted mt-1">
                {status.playwright_available
                  ? `Browser ready · ${status.active_sessions} active sessions`
                  : `Static analysis only · Install: ${status.install_cmd || "playwright install chromium"}`}
              </div>
              <div className="grid grid-cols-2 gap-4 mt-2 text-xs">
                <span className="text-bmx-muted">DOM snapshot: <span className="text-bmx-green">✓ works (static parsing)</span></span>
                <span className="text-bmx-muted">SPA routes: <span className={status.playwright_available ? "text-bmx-green" : "text-bmx-yellow"}>
                  {status.playwright_available ? "✓ dynamic + static" : "⚠ static only"}
                </span></span>
                <span className="text-bmx-muted">Screenshots: <span className={status.playwright_available ? "text-bmx-green" : "text-bmx-yellow"}>
                  {status.playwright_available ? "✓ available" : "⚠ requires playwright"}
                </span></span>
                <span className="text-bmx-muted">WS capture: <span className={status.playwright_available ? "text-bmx-green" : "text-bmx-yellow"}>
                  {status.playwright_available ? "✓ available" : "⚠ requires playwright"}
                </span></span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* URL Input */}
      <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4">
        <label className="block text-xs text-bmx-muted mb-2">Target URL</label>
        <div className="flex gap-3">
          <input
            value={targetUrl}
            onChange={(e) => setTargetUrl(e.target.value)}
            className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-bmx-cyan outline-none"
            placeholder="https://target.example.com"
          />
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-bmx-border flex gap-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-4 py-2 text-sm font-mono border-b-2 transition-colors ${
              activeTab === tab.id
                ? "border-bmx-cyan text-bmx-cyan"
                : "border-transparent text-bmx-muted hover:text-white"
            }`}
          >
            <tab.icon className="w-3.5 h-3.5" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {activeTab === "dom" && (
        <div className="space-y-4">
          <button
            onClick={runDomSnapshot}
            disabled={loading === "dom"}
            className="px-4 py-2 text-sm font-mono bg-bmx-teal/10 text-bmx-teal border border-bmx-teal/30 rounded hover:bg-bmx-teal/20 disabled:opacity-40 transition-colors"
          >
            {loading === "dom" ? "Analyzing..." : "Run DOM Snapshot"}
          </button>

          {domResult && (
            <div className="space-y-4">
              <div className="grid grid-cols-4 gap-3">
                {[
                  { label: "Forms", val: domResult.form_count, color: "text-bmx-cyan" },
                  { label: "Inputs", val: domResult.input_count, color: "text-white" },
                  { label: "Links", val: domResult.link_count, color: "text-bmx-teal" },
                  { label: "XSS Sinks", val: domResult.dom_xss_sinks?.length || 0, color: "text-bmx-red" },
                ].map((s) => (
                  <div key={s.label} className="bg-bmx-dark border border-bmx-border rounded-lg p-3 text-center">
                    <div className={`text-xl font-bold font-mono ${s.color}`}>{s.val}</div>
                    <div className="text-xs text-bmx-muted mt-1">{s.label}</div>
                  </div>
                ))}
              </div>

              {domResult.dom_xss_sinks?.length > 0 && (
                <div className="bg-bmx-dark border border-bmx-red/20 rounded-lg p-4">
                  <div className="text-sm font-mono text-bmx-red mb-2">⚠ DOM XSS Sinks Detected</div>
                  <div className="space-y-1 font-mono text-xs">
                    {domResult.dom_xss_sinks.slice(0, 10).map((sink, i) => (
                      <div key={i} className="text-bmx-muted bg-black/30 rounded px-2 py-1 truncate">{sink}</div>
                    ))}
                  </div>
                </div>
              )}

              {domResult.forms?.length > 0 && (
                <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4">
                  <div className="text-sm font-mono text-white mb-3">Forms Discovered</div>
                  <div className="space-y-2">
                    {domResult.forms.map((form, i) => (
                      <div key={i} className="flex items-center justify-between text-xs bg-bmx-black rounded px-3 py-2">
                        <div>
                          <span className="text-bmx-cyan font-mono">{form.method}</span>
                          <span className="text-bmx-muted mx-2">→</span>
                          <span className="text-white">{form.action}</span>
                        </div>
                        <div className="flex items-center gap-3 text-bmx-muted">
                          <span>{form.field_count} fields</span>
                          {!form.has_csrf_token && (
                            <span className="text-bmx-yellow">⚠ no CSRF</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {activeTab === "spa" && (
        <div className="space-y-4">
          <button
            onClick={runSpaMapper}
            disabled={loading === "spa"}
            className="px-4 py-2 text-sm font-mono bg-bmx-teal/10 text-bmx-teal border border-bmx-teal/30 rounded hover:bg-bmx-teal/20 disabled:opacity-40 transition-colors"
          >
            {loading === "spa" ? "Mapping..." : "Map SPA Routes"}
          </button>

          {spaResult && (
            <div className="space-y-4">
              <div className="flex items-center gap-4 text-sm text-bmx-muted">
                <span className="text-white font-bold font-mono">{spaResult.total_unique_paths}</span> unique routes
                <span className={`text-xs px-2 py-0.5 rounded border ${
                  spaResult.playwright_used
                    ? "text-bmx-green border-bmx-green/30"
                    : "text-bmx-yellow border-bmx-yellow/30"
                }`}>
                  {spaResult.playwright_used ? "dynamic + static" : "static only"}
                </span>
              </div>

              <div className="bg-bmx-dark border border-bmx-border rounded-lg">
                <div className="px-4 py-2 border-b border-bmx-border text-xs text-bmx-muted font-mono">
                  Discovered Routes
                </div>
                <div className="divide-y divide-bmx-border max-h-64 overflow-y-auto">
                  {[...spaResult.static_routes, ...spaResult.dynamic_routes].map((r, i) => (
                    <div key={i} className="flex items-center gap-3 px-4 py-2 text-xs hover:bg-white/5">
                      <span className="text-white font-mono">{r.path}</span>
                      {r.params?.length > 0 && (
                        <span className="text-bmx-yellow">{r.params.map((p) => `:${p}`).join(" ")}</span>
                      )}
                      <span className="ml-auto text-bmx-muted">{r.discovered_via}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {(activeTab === "storage" || activeTab === "ws") && (
        <div className="bg-bmx-dark border border-bmx-border rounded-lg p-8 text-center">
          <Camera className="w-8 h-8 text-bmx-border mx-auto mb-3" />
          <p className="text-bmx-muted text-sm">
            {activeTab === "storage"
              ? "Storage capture requires an authenticated browser session."
              : "WebSocket capture requires an authenticated browser session."}
          </p>
          <p className="text-xs text-bmx-muted mt-1">
            {status?.playwright_available
              ? "Create a session first, then use the session ID."
              : "Requires: playwright install chromium"}
          </p>
        </div>
      )}
    </div>
  );
}
