"use client";
import { useEffect, useRef, useState, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import { scanApi, vulnApi, reconApi } from "@/lib/api";
import {
  Activity, XCircle, ChevronDown, ChevronUp, RefreshCw,
  CheckCircle, AlertTriangle, Clock, Bug, Globe, Link,
  Terminal, Wifi, WifiOff, ArrowLeft, ExternalLink, Copy, Check
} from "lucide-react";

interface ScanLog {
  id: string;
  level: string;
  module?: string;
  message: string;
  timestamp?: string;
}

interface ScanDetail {
  id: string;
  name?: string;
  target: string;
  status: string;
  scan_type: string;
  created_at: string;
  completed_at?: string;
  subdomain_count: number;
  url_count: number;
  vuln_count: number;
  progress?: number;
  error_message?: string;
}

interface Vuln {
  id: string;
  title: string;
  severity: string;
  vuln_type: string;
  url?: string;
  status: string;
}

const SEV_DOT: Record<string, string> = {
  critical: "bg-red-500",
  high:     "bg-orange-500",
  medium:   "bg-yellow-500",
  low:      "bg-blue-400",
  info:     "bg-gray-500",
};

const SEV_TEXT: Record<string, string> = {
  critical: "text-red-400",
  high:     "text-orange-400",
  medium:   "text-yellow-400",
  low:      "text-blue-400",
  info:     "text-gray-400",
};

const LOG_COLOR: Record<string, string> = {
  info:    "text-bmx-teal",
  success: "text-bmx-green",
  warning: "text-bmx-yellow",
  warn:    "text-bmx-yellow",
  error:   "text-bmx-red",
  debug:   "text-gray-500",
};

const STATUS_CONFIG: Record<string, { color: string; bg: string; icon: React.ReactNode; label: string }> = {
  running:   { color: "text-bmx-cyan",  bg: "bg-bmx-cyan/10 border-bmx-cyan/30",  icon: <Activity className="w-3 h-3 animate-pulse" />, label: "RUNNING" },
  queued:    { color: "text-bmx-yellow",bg: "bg-bmx-yellow/10 border-bmx-yellow/30", icon: <Clock className="w-3 h-3" />, label: "QUEUED" },
  completed: { color: "text-bmx-green", bg: "bg-bmx-green/10 border-bmx-green/30", icon: <CheckCircle className="w-3 h-3" />, label: "COMPLETED" },
  failed:    { color: "text-bmx-red",   bg: "bg-bmx-red/10 border-bmx-red/30",    icon: <XCircle className="w-3 h-3" />, label: "FAILED" },
  cancelled: { color: "text-gray-400",  bg: "bg-gray-400/10 border-gray-400/30",  icon: <XCircle className="w-3 h-3" />, label: "CANCELLED" },
};

function fmtTime(iso?: string): string {
  if (!iso) return "──:──:──";
  try {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "──:──:──";
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
  } catch {
    return "──:──:──";
  }
}

function fmtDuration(start?: string, end?: string): string {
  if (!start) return "";
  const s = new Date(start);
  const e = end ? new Date(end) : new Date();
  if (isNaN(s.getTime())) return "";
  const ms = e.getTime() - s.getTime();
  const secs = Math.floor(ms / 1000);
  if (secs < 60) return `${secs}s`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ${secs % 60}s`;
  return `${Math.floor(mins / 60)}h ${mins % 60}m`;
}

export default function ScanDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [scan, setScan] = useState<ScanDetail | null>(null);
  const [logs, setLogs] = useState<ScanLog[]>([]);
  const [vulns, setVulns] = useState<Vuln[]>([]);
  const [subdomains, setSubdomains] = useState<string[]>([]);
  const [autoScroll, setAutoScroll] = useState(true);
  const [connected, setConnected] = useState(false);
  const [activeTab, setActiveTab] = useState<"logs" | "vulns" | "recon">("logs");
  const [copied, setCopied] = useState(false);
  const logRef = useRef<HTMLDivElement>(null);
  const esRef = useRef<EventSource | null>(null);
  const alive = useRef(true);

  const fetchAll = useCallback(async () => {
    if (!id) return;
    try {
      const scanRes = await scanApi.get(id);
      if (alive.current) setScan(scanRes.data);
    } catch {}

    try {
      const logsRes = await scanApi.logs(id, 500);
      if (alive.current) setLogs(logsRes.data || []);
    } catch {}
  }, [id]);

  const fetchVulnsAndRecon = useCallback(async (scanData: ScanDetail) => {
    if (!id) return;
    if (scanData.vuln_count > 0) {
      try {
        const vr = await vulnApi.list({ scan_id: id, limit: 50 });
        if (alive.current) setVulns(vr.data || []);
      } catch {}
    }
    if (scanData.subdomain_count > 0) {
      try {
        const sr = await reconApi.subdomains({ scan_id: id, limit: 100 });
        if (alive.current) setSubdomains((sr.data || []).map((s: { subdomain: string }) => s.subdomain));
      } catch {}
    }
  }, [id]);

  const startStream = useCallback(() => {
    if (!id || esRef.current) return;
    const token = localStorage.getItem("bmx_access_token") || "";
    const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    const url = `${BASE}/api/v1/scans/${id}/stream?token=${encodeURIComponent(token)}`;

    const es = new EventSource(url);
    esRef.current = es;

    es.onopen = () => alive.current && setConnected(true);

    es.onmessage = (e) => {
      if (!alive.current) return;
      try {
        const data = JSON.parse(e.data);
        if (data.type === "done") {
          setConnected(false);
          es.close(); esRef.current = null;
          // Refresh everything when scan finishes
          setTimeout(fetchAll, 800);
          return;
        }
        if (data.message || data.level) {
          const log: ScanLog = {
            id: data.id || `${Date.now()}-${Math.random()}`,
            level: data.level || "info",
            module: data.module,
            message: data.message || "",
            timestamp: data.timestamp,
          };
          setLogs(prev => prev.some(l => l.id === log.id) ? prev : [...prev.slice(-999), log]);
        }
        if (data.status) setScan(p => p ? { ...p, status: data.status, progress: data.progress ?? p.progress } : p);
      } catch {}
    };

    es.onerror = () => {
      setConnected(false);
      es.close(); esRef.current = null;
    };
  }, [id, fetchAll]);

  useEffect(() => {
    alive.current = true;
    fetchAll().then(() => startStream());

    // Poll every 8s when stream is down (for counts update)
    const poll = setInterval(() => {
      if (!esRef.current && alive.current) fetchAll();
    }, 8000);

    return () => {
      alive.current = false;
      esRef.current?.close(); esRef.current = null;
      clearInterval(poll);
    };
  }, [id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Fetch vulns/subdomains when scan data updates
  useEffect(() => {
    if (scan && (scan.status === "completed" || scan.status === "failed")) {
      fetchVulnsAndRecon(scan);
    }
  }, [scan?.status, scan?.vuln_count, scan?.subdomain_count]); // eslint-disable-line react-hooks/exhaustive-deps

  // Auto-scroll logs
  useEffect(() => {
    if (autoScroll && logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const cancel = async () => {
    try {
      await scanApi.cancel(id!);
      setScan(p => p ? { ...p, status: "cancelled" } : p);
      esRef.current?.close(); esRef.current = null;
      setConnected(false);
    } catch {}
  };

  const copyId = () => {
    navigator.clipboard.writeText(id || "");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!scan) {
    return (
      <div className="p-8 flex items-center gap-3 text-bmx-muted font-mono text-sm">
        <RefreshCw className="w-4 h-4 animate-spin text-bmx-cyan" />
        Loading scan data...
      </div>
    );
  }

  const sc = STATUS_CONFIG[scan.status] || STATUS_CONFIG.cancelled;
  const isActive = scan.status === "running" || scan.status === "queued";
  const duration = fmtDuration(scan.created_at, scan.completed_at);

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* ── Top bar ──────────────────────────────────────────── */}
      <div className="shrink-0 border-b border-bmx-border px-6 py-3 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <button onClick={() => router.back()} className="text-bmx-muted hover:text-white transition-colors">
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h1 className="text-white font-mono text-base font-bold truncate">
                {scan.target || scan.name || id}
              </h1>
              <button onClick={copyId} className="text-bmx-muted hover:text-bmx-cyan transition-colors shrink-0">
                {copied ? <Check className="w-3.5 h-3.5 text-bmx-green" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
            <p className="text-bmx-muted font-mono text-xs">
              {scan.scan_type} scan
              {duration && <> &nbsp;·&nbsp; <span className="text-bmx-cyan/70">{duration}</span></>}
              &nbsp;·&nbsp; {new Date(scan.created_at).toLocaleString()}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {/* Live indicator */}
          {connected ? (
            <div className="flex items-center gap-1.5 text-bmx-green">
              <Wifi className="w-3.5 h-3.5" />
              <span className="text-xs font-mono">LIVE</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-bmx-muted/50">
              <WifiOff className="w-3.5 h-3.5" />
              <span className="text-xs font-mono">STREAM OFF</span>
            </div>
          )}

          {/* Progress bar when running */}
          {isActive && scan.progress != null && scan.progress > 0 && (
            <div className="flex items-center gap-2">
              <div className="w-24 h-1.5 bg-bmx-border rounded-full overflow-hidden">
                <div
                  className="h-full bg-bmx-cyan rounded-full transition-all duration-500"
                  style={{ width: `${scan.progress}%` }}
                />
              </div>
              <span className="text-bmx-cyan text-xs font-mono">{scan.progress}%</span>
            </div>
          )}

          {/* Status badge */}
          <span className={`flex items-center gap-1.5 text-xs font-mono px-3 py-1.5 rounded border ${sc.bg} ${sc.color}`}>
            {sc.icon} {sc.label}
          </span>

          {/* Actions */}
          {isActive && (
            <button onClick={cancel}
              className="flex items-center gap-1.5 border border-bmx-red/40 text-bmx-red text-xs font-mono px-3 py-1.5 rounded hover:bg-bmx-red/10 transition-colors">
              <XCircle className="w-3.5 h-3.5" /> CANCEL
            </button>
          )}
          <button onClick={fetchAll} className="text-bmx-muted hover:text-white transition-colors p-1.5" title="Refresh">
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* ── Stats row ─────────────────────────────────────────── */}
      <div className="shrink-0 grid grid-cols-3 gap-px bg-bmx-border border-b border-bmx-border">
        {[
          { label: "Subdomains", value: scan.subdomain_count, icon: <Globe className="w-4 h-4" />, color: "text-bmx-teal", tab: "recon" as const },
          { label: "URLs",       value: scan.url_count,       icon: <Link  className="w-4 h-4" />, color: "text-bmx-cyan", tab: "recon" as const },
          { label: "Findings",   value: scan.vuln_count,      icon: <Bug   className="w-4 h-4" />,
            color: scan.vuln_count > 0 ? "text-bmx-orange" : "text-bmx-green", tab: "vulns" as const },
        ].map((s) => (
          <button key={s.label} onClick={() => setActiveTab(s.tab)}
            className="bg-bmx-dark/60 hover:bg-bmx-dark transition-colors px-6 py-4 flex items-center gap-4">
            <span className={`${s.color} opacity-60`}>{s.icon}</span>
            <div className="text-left">
              <div className={`text-2xl font-mono font-bold ${s.color}`}>{s.value}</div>
              <div className="text-bmx-muted text-xs font-mono">{s.label}</div>
            </div>
          </button>
        ))}
      </div>

      {/* ── Error banner ──────────────────────────────────────── */}
      {scan.error_message && (
        <div className="shrink-0 mx-6 mt-4 bg-bmx-red/5 border border-bmx-red/30 rounded-lg px-4 py-3 flex items-start gap-3">
          <AlertTriangle className="w-4 h-4 text-bmx-red shrink-0 mt-0.5" />
          <div>
            <p className="text-bmx-red text-xs font-mono font-bold">Scan Error</p>
            <p className="text-bmx-red/80 text-xs font-mono mt-0.5">{scan.error_message}</p>
          </div>
        </div>
      )}

      {/* ── Tab bar ───────────────────────────────────────────── */}
      <div className="shrink-0 flex gap-1 px-6 pt-4 border-b border-bmx-border">
        {([
          ["logs",  <Terminal key="t" className="w-3.5 h-3.5" />, `Logs (${logs.length})`],
          ["vulns", <Bug      key="b" className="w-3.5 h-3.5" />, `Findings (${scan.vuln_count})`],
          ["recon", <Globe    key="g" className="w-3.5 h-3.5" />, `Recon (${scan.subdomain_count})`],
        ] as const).map(([tab, icon, label]) => (
          <button key={tab} onClick={() => setActiveTab(tab as typeof activeTab)}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-mono tracking-wider border-b-2 transition-colors ${
              activeTab === tab
                ? "text-bmx-cyan border-bmx-cyan"
                : "text-bmx-muted border-transparent hover:text-white"
            }`}>
            {icon} {label}
          </button>
        ))}
      </div>

      {/* ── Content area ─────────────────────────────────────── */}
      <div className="flex-1 overflow-hidden">

        {/* LOGS TAB */}
        {activeTab === "logs" && (
          <div className="h-full flex flex-col">
            <div className="flex items-center justify-between px-6 py-2 shrink-0">
              <span className="text-bmx-muted text-xs font-mono">{logs.length} entries</span>
              <button onClick={() => setAutoScroll(!autoScroll)}
                className={`flex items-center gap-1 text-xs font-mono ${autoScroll ? "text-bmx-cyan" : "text-bmx-muted"}`}>
                {autoScroll ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
                AUTO-SCROLL
              </button>
            </div>
            <div ref={logRef} className="flex-1 overflow-y-auto px-6 pb-4 space-y-0.5 font-mono text-xs"
              onScroll={e => {
                const el = e.currentTarget;
                setAutoScroll(el.scrollHeight - el.scrollTop - el.clientHeight < 40);
              }}>
              {logs.map((log, i) => (
                <div key={log.id || i} className="flex gap-3 items-start py-0.5 hover:bg-bmx-dark/30 rounded px-1 -mx-1 group">
                  <span className="text-bmx-muted/30 shrink-0 w-16 text-right tabular-nums group-hover:text-bmx-muted/60 transition-colors">
                    {fmtTime(log.timestamp)}
                  </span>
                  {log.module && (
                    <span className="text-bmx-cyan/40 shrink-0 w-16 truncate">[{log.module}]</span>
                  )}
                  <span className={`${LOG_COLOR[log.level] || "text-gray-300"} break-all flex-1 leading-5`}>
                    {log.message}
                  </span>
                </div>
              ))}

              {logs.length === 0 && (
                <div className="flex items-center gap-2 text-bmx-muted/40 py-8 justify-center">
                  <Terminal className="w-4 h-4" />
                  {isActive ? "Waiting for scan logs..." : "No logs recorded for this scan."}
                </div>
              )}
              {isActive && (
                <div className="flex items-center gap-1.5 text-bmx-cyan/30 py-1 px-1">
                  <span className="inline-block w-1.5 h-4 bg-bmx-cyan/50 animate-pulse rounded-sm" />
                </div>
              )}
            </div>
          </div>
        )}

        {/* FINDINGS TAB */}
        {activeTab === "vulns" && (
          <div className="h-full overflow-y-auto p-6 space-y-2">
            {vulns.length === 0 && scan.status === "completed" && (
              <div className="text-center py-12">
                <CheckCircle className="w-8 h-8 text-bmx-green/40 mx-auto mb-2" />
                <p className="text-bmx-muted font-mono text-sm">No vulnerabilities found</p>
              </div>
            )}
            {vulns.length === 0 && isActive && (
              <div className="text-center py-12 text-bmx-muted font-mono text-sm">
                <Activity className="w-8 h-8 mx-auto mb-2 animate-pulse" />
                Scanning in progress...
              </div>
            )}
            {vulns.map(v => (
              <div key={v.id} className="bmx-panel rounded-lg border border-bmx-border p-4 flex items-start gap-3 hover:border-bmx-cyan/20 transition-colors">
                <span className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${SEV_DOT[v.severity] || "bg-gray-500"}`} />
                <div className="flex-1 min-w-0">
                  <p className="text-white font-mono text-sm">{v.title}</p>
                  {v.url && <p className="text-bmx-muted font-mono text-xs mt-0.5 truncate">{v.url}</p>}
                </div>
                <span className={`text-xs font-mono shrink-0 ${SEV_TEXT[v.severity] || "text-gray-400"}`}>
                  {v.severity.toUpperCase()}
                </span>
              </div>
            ))}
          </div>
        )}

        {/* RECON TAB */}
        {activeTab === "recon" && (
          <div className="h-full overflow-y-auto p-6">
            {subdomains.length > 0 ? (
              <div className="space-y-1">
                <p className="text-bmx-muted text-xs font-mono mb-3 tracking-wider">
                  {subdomains.length} SUBDOMAINS DISCOVERED
                </p>
                {subdomains.map(sub => (
                  <div key={sub} className="flex items-center gap-2 py-1.5 px-2 rounded hover:bg-bmx-dark/50 group">
                    <span className="w-1.5 h-1.5 rounded-full bg-bmx-teal/60 shrink-0" />
                    <span className="text-white font-mono text-xs">{sub}</span>
                    <a href={`https://${sub}`} target="_blank" rel="noopener noreferrer"
                      className="ml-auto text-bmx-muted/0 group-hover:text-bmx-muted hover:text-bmx-cyan transition-colors">
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-bmx-muted font-mono text-sm">
                <Globe className="w-8 h-8 mx-auto mb-2 opacity-30" />
                {isActive ? "Recon in progress..." : "No subdomains recorded."}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
