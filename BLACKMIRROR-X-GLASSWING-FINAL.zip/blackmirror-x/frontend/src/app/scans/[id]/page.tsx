"use client";
/**
 * Scan Detail — BLACKMIRROR-X GLASSWING
 * XBOW-style live scan view with:
 * - Real-time log stream (SSE)
 * - Phase progress tracking
 * - Live subdomain/URL/vuln counters
 * - AI reasoning steps highlighted
 * - Tool status indicators
 * - Verified findings display
 */
import { useEffect, useRef, useState, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import { useAppStore } from "@/store/app";
import { getToken } from "@/lib/api";
import {
  Activity, CheckCircle, XCircle, Clock, ArrowLeft,
  Globe, Link2, Bug, Brain, Zap, Shield, Terminal,
  ChevronDown, ChevronUp, Copy, Check, RefreshCw,
  AlertTriangle, Eye, Cpu, Search
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────
interface LogEntry {
  id: string;
  level: string;
  module: string;
  message: string;
  timestamp?: string;
}

interface ScanData {
  id: string;
  name: string;
  target?: string;
  status: string;
  scan_type: string;
  progress: number;
  created_at: string;
  completed_at?: string;
  subdomain_count?: number;
  url_count?: number;
  vuln_count?: number;
  config?: Record<string, unknown>;
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function fmtTime(iso?: string): string {
  if (!iso) return "──:──:──";
  try {
    // Handle both ISO strings and timestamps
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "──:──:──";
    return d.toLocaleTimeString([], {
      hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false
    });
  } catch {
    return "──:──:──";
  }
}

function fmtDuration(start?: string, end?: string): string {
  if (!start) return "";
  const s = new Date(start).getTime();
  const e = end ? new Date(end).getTime() : Date.now();
  if (isNaN(s)) return "";
  const secs = Math.floor((e - s) / 1000);
  if (secs < 60) return `${secs}s`;
  if (secs < 3600) return `${Math.floor(secs / 60)}m ${secs % 60}s`;
  return `${Math.floor(secs / 3600)}h ${Math.floor((secs % 3600) / 60)}m`;
}

const PHASE_NAMES: Record<string, string> = {
  swarm: "Recon Swarm", subfinder: "Subfinder", amass: "Amass",
  assetfinder: "Assetfinder", uncover: "Uncover", dnsx: "DNS Resolve",
  httpx: "HTTP Probe", naabu: "Port Scan", katana: "Crawler",
  gau: "GAU", waybackurls: "Wayback", hakrawler: "Hakrawler",
  param_discovery: "Param Discovery", js_intel: "JS Analysis",
  nuclei: "Nuclei Templates", ai_hypothesis: "AI Hypotheses",
  vuln_tester: "Vuln Testing", consensus: "Consensus Filter",
  exploit_verifier: "XBOW Verify", adaptive: "Adaptive Pivots",
  chain_composer: "Attack Chains", memory: "Memory",
  glasswing: "GLASSWING", recon: "Recon",
};

const LOG_COLORS: Record<string, string> = {
  error: "text-red-400",
  warn: "text-yellow-400",
  warning: "text-yellow-400",
  success: "text-bmx-green",
  info: "text-gray-300",
};

function getLogColor(level: string, module: string, message: string): string {
  if (level === "error") return "text-red-400";
  if (level === "success" || message.startsWith("✓") || message.startsWith("🏁")) return "text-bmx-green";
  if (level === "warn") return "text-yellow-400";
  if (module.startsWith("reasoning:")) return "text-bmx-cyan";
  if (message.includes("🔥") || message.includes("VERIFIED") || message.includes("CRITICAL")) return "text-red-400";
  if (message.includes("🧠") || message.includes("⚡") || message.includes("🎯")) return "text-bmx-cyan";
  if (message.includes("Phase")) return "text-bmx-teal";
  if (message.includes("Tool not found") || message.includes("mock mode")) return "text-bmx-muted/40";
  return LOG_COLORS[level] || "text-gray-400";
}

function getModuleIcon(module: string): string {
  if (module.startsWith("reasoning:")) return "🧠";
  if (module === "glasswing") return "🔍";
  if (module === "exploit_verifier") return "⚡";
  if (module === "adaptive") return "🎯";
  if (module === "chain_composer") return "⛓";
  if (module === "nuclei") return "🔬";
  if (module === "js_intel") return "📜";
  if (module === "consensus") return "⚖️";
  if (module === "vuln_tester") return "🐛";
  if (["subfinder","amass","dnsx","httpx","katana","gau"].includes(module)) return "🌐";
  return "→";
}

// ── Main component ────────────────────────────────────────────────────────────
export default function ScanDetailPage() {
  const params = useParams();
  const router = useRouter();
  const scanId = params?.id as string;

  const [scan, setScan] = useState<ScanData | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [streaming, setStreaming] = useState(false);
  const [elapsed, setElapsed] = useState("");
  const [autoScroll, setAutoScroll] = useState(true);
  const [filter, setFilter] = useState<"all" | "reasoning" | "findings" | "errors">("all");
  const [subdomains, setSubdomains] = useState(0);
  const [urls, setUrls] = useState(0);
  const [vulns, setVulns] = useState(0);
  const [verifiedCount, setVerifiedCount] = useState(0);
  const [activePhase, setActivePhase] = useState("");
  const [toolStatuses, setToolStatuses] = useState<Record<string, "ok" | "mock" | "running">>({});

  const logsEndRef = useRef<HTMLDivElement>(null);
  const logsContainerRef = useRef<HTMLDivElement>(null);
  const esRef = useRef<EventSource | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const alive = useRef(true);

  // Fetch scan metadata
  const fetchScan = useCallback(async () => {
    if (!scanId) return;
    const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    const token = getToken();
    try {
      const r = await fetch(`${BASE}/api/v1/scans/${scanId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (r.ok) {
        const data = await r.json();
        setScan(data);
        setSubdomains(data.subdomain_count ?? 0);
        setUrls(data.url_count ?? 0);
        setVulns(data.vuln_count ?? 0);
      }
    } catch { /* ignore */ }
  }, [scanId]);

  // Process log entry to update stats
  const processLog = useCallback((log: LogEntry) => {
    const msg = log.message || "";
    // Track subdomains
    const subMatch = msg.match(/(\d+)\s+subdomains?\b/i);
    if (subMatch) setSubdomains(n => Math.max(n, parseInt(subMatch[1])));
    // Track URLs
    const urlMatch = msg.match(/(\d+)\s+URLs?\b/i);
    if (urlMatch) setUrls(n => Math.max(n, parseInt(urlMatch[1])));
    // Track vulns
    const vulnMatch = msg.match(/(\d+)\s+(?:raw candidates|findings|vulns?)\b/i);
    if (vulnMatch) setVulns(n => Math.max(n, parseInt(vulnMatch[1])));
    // Track verified
    if (msg.includes("[VERIFIED]") || msg.includes("VERIFIED:")) {
      setVerifiedCount(n => n + 1);
    }
    // Track active phase
    const phaseMatch = msg.match(/Phase \d+:/);
    if (phaseMatch) setActivePhase(msg.split(":")[0].trim());
    // Track tool status
    if (msg.includes("mock mode") || msg.includes("Tool not found")) {
      const toolMatch = msg.match(/Tool not found:\s*(\w+)/);
      if (toolMatch) {
        setToolStatuses(prev => ({ ...prev, [toolMatch[1]]: "mock" }));
      }
    } else if (msg.includes("results") && log.module) {
      setToolStatuses(prev => ({ ...prev, [log.module]: "ok" }));
    }
  }, []);

  // Start SSE stream
  const startStream = useCallback(() => {
    if (!scanId || esRef.current) return;
    const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
    const token = getToken();
    const url = `${BASE}/api/v1/scans/${scanId}/stream?token=${encodeURIComponent(token || "")}`;

    const es = new EventSource(url);
    esRef.current = es;
    setStreaming(true);

    es.onmessage = (e) => {
      if (!alive.current) return;
      try {
        const data = JSON.parse(e.data);
        if (data.type === "done") {
          setStreaming(false);
          es.close();
          esRef.current = null;
          fetchScan();
          return;
        }
        if (data.level || data.message) {
          // Ensure timestamp is valid
          const entry: LogEntry = {
            id: data.id || `${Date.now()}-${Math.random()}`,
            level: data.level || "info",
            module: data.module || "",
            message: data.message || "",
            timestamp: data.timestamp || new Date().toISOString(),
          };
          setLogs(prev => [...prev.slice(-499), entry]);
          processLog(entry);
        }
      } catch { /* ignore parse errors */ }
    };

    es.onerror = () => {
      setStreaming(false);
      es.close();
      esRef.current = null;
    };
  }, [scanId, fetchScan, processLog]);

  useEffect(() => {
    alive.current = true;
    fetchScan().then(() => {
      if (scan?.status === "running" || scan?.status === "queued") {
        startStream();
      }
    });
    return () => {
      alive.current = false;
      esRef.current?.close();
      if (timerRef.current) clearInterval(timerRef.current);
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []); // eslint-disable-line

  // Start stream once we know scan is running
  useEffect(() => {
    if (scan?.status === "running" || scan?.status === "queued") {
      startStream();
      timerRef.current = setInterval(() => {
        setElapsed(fmtDuration(scan.created_at));
      }, 1000);
      pollRef.current = setInterval(fetchScan, 10000);
    } else if (scan?.status === "completed" || scan?.status === "failed") {
      setElapsed(fmtDuration(scan.created_at, scan.completed_at));
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [scan?.status]); // eslint-disable-line

  // Auto-scroll
  useEffect(() => {
    if (autoScroll && logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [logs, autoScroll]);

  const filteredLogs = logs.filter(l => {
    if (filter === "reasoning") return l.module?.startsWith("reasoning:");
    if (filter === "findings") return l.message?.includes("VERIFIED") ||
      l.message?.includes("finding") || l.level === "success";
    if (filter === "errors") return l.level === "error" || l.level === "warn";
    return true;
  });

  const isRunning = scan?.status === "running" || scan?.status === "queued";
  const domain = (scan?.config as Record<string,string>)?.domain || scan?.target || scan?.name || "";

  const STATUS_CONFIG: Record<string, { icon: React.ReactNode; color: string; label: string }> = {
    running: { icon: <Activity className="w-4 h-4 animate-pulse" />, color: "text-bmx-cyan", label: "SCANNING" },
    queued:  { icon: <Clock className="w-4 h-4" />, color: "text-bmx-yellow", label: "QUEUED" },
    completed: { icon: <CheckCircle className="w-4 h-4" />, color: "text-bmx-green", label: "COMPLETE" },
    failed: { icon: <XCircle className="w-4 h-4" />, color: "text-bmx-red", label: "FAILED" },
  };
  const statusCfg = STATUS_CONFIG[scan?.status || ""] || STATUS_CONFIG.queued;

  return (
    <div className="h-full flex flex-col bg-bmx-black">
      {/* ── Header ── */}
      <div className="shrink-0 border-b border-bmx-border px-6 py-4 bg-bmx-dark/60">
        <div className="flex items-center gap-3 mb-3">
          <button onClick={() => router.back()}
            className="text-bmx-muted hover:text-white transition-colors p-1">
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3">
              <h1 className="text-white font-mono font-bold text-base truncate">{domain}</h1>
              <span className={`flex items-center gap-1.5 text-xs font-mono font-bold ${statusCfg.color}`}>
                {statusCfg.icon} {statusCfg.label}
              </span>
              {isRunning && (
                <span className="text-bmx-muted/50 font-mono text-xs">{elapsed}</span>
              )}
              {!isRunning && elapsed && (
                <span className="text-bmx-muted/50 font-mono text-xs">
                  completed in {elapsed}
                </span>
              )}
            </div>
            <p className="text-bmx-muted/50 font-mono text-xs mt-0.5">
              {scan?.scan_type?.toUpperCase()} · Started {scan?.created_at ? new Date(scan.created_at).toLocaleString() : "—"}
            </p>
          </div>
          <button onClick={fetchScan}
            className="text-bmx-muted hover:text-white transition-colors p-1">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: "SUBDOMAINS", value: subdomains, icon: <Globe className="w-4 h-4" />, color: "text-bmx-teal" },
            { label: "URLS", value: urls, icon: <Link2 className="w-4 h-4" />, color: "text-bmx-cyan" },
            { label: "FINDINGS", value: vulns, icon: <Bug className="w-4 h-4" />, color: "text-bmx-orange" },
            { label: "VERIFIED", value: verifiedCount, icon: <Shield className="w-4 h-4" />, color: "text-bmx-green" },
          ].map(s => (
            <div key={s.label}
              className="border border-bmx-border rounded-lg p-3 bg-bmx-dark/40 flex items-center gap-3">
              <span className={s.color}>{s.icon}</span>
              <div>
                <div className={`text-2xl font-mono font-bold ${s.color}`}>{s.value}</div>
                <div className="text-bmx-muted/50 font-mono text-[9px] tracking-wider">{s.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Progress bar */}
        {isRunning && scan?.progress !== undefined && (
          <div className="mt-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-bmx-muted/50 font-mono text-[10px]">
                {activePhase || "Scanning..."}
              </span>
              <span className="text-bmx-cyan font-mono text-[10px]">{scan.progress}%</span>
            </div>
            <div className="h-1 bg-bmx-border rounded-full overflow-hidden">
              <div className="h-full bg-bmx-cyan rounded-full transition-all duration-1000"
                style={{ width: `${scan.progress}%` }} />
            </div>
          </div>
        )}

        {/* Tool status indicators */}
        {Object.keys(toolStatuses).length > 0 && (
          <div className="flex gap-2 mt-2 flex-wrap">
            {Object.entries(toolStatuses).map(([tool, status]) => (
              <span key={tool}
                className={`text-[9px] font-mono border rounded px-1.5 py-0.5 ${
                  status === "mock"
                    ? "text-bmx-muted/30 border-bmx-border/30"
                    : "text-bmx-green border-bmx-green/30"
                }`}>
                {tool} {status === "mock" ? "○" : "✓"}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* ── Log stream ── */}
      <div className="flex-1 flex flex-col min-h-0">
        {/* Log controls */}
        <div className="shrink-0 flex items-center gap-2 px-4 py-2 border-b border-bmx-border/50 bg-bmx-dark/30">
          <Terminal className="w-3.5 h-3.5 text-bmx-muted/40" />
          <span className="text-bmx-muted/40 font-mono text-[10px] tracking-wider">LIVE LOGS</span>
          <span className="text-bmx-muted/30 font-mono text-[10px]">{logs.length} entries</span>

          <div className="flex gap-1 ml-2">
            {(["all","reasoning","findings","errors"] as const).map(f => (
              <button key={f} onClick={() => setFilter(f)}
                className={`text-[9px] font-mono px-2 py-0.5 rounded transition-colors ${
                  filter === f
                    ? "bg-bmx-cyan/20 text-bmx-cyan border border-bmx-cyan/30"
                    : "text-bmx-muted/40 hover:text-bmx-muted border border-transparent"
                }`}>
                {f.toUpperCase()}
              </button>
            ))}
          </div>

          <div className="flex-1" />

          {isRunning && (
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-bmx-green animate-pulse" />
              <span className="text-bmx-green font-mono text-[10px]">LIVE</span>
            </div>
          )}

          <button onClick={() => setAutoScroll(!autoScroll)}
            className={`text-[10px] font-mono border rounded px-2 py-0.5 transition-colors ${
              autoScroll
                ? "text-bmx-cyan border-bmx-cyan/30"
                : "text-bmx-muted/40 border-bmx-border"
            }`}>
            AUTO-SCROLL
          </button>
        </div>

        {/* Log entries */}
        <div ref={logsContainerRef}
          className="flex-1 overflow-y-auto px-4 py-2 font-mono text-xs"
          onScroll={e => {
            const el = e.currentTarget;
            const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 50;
            setAutoScroll(atBottom);
          }}>

          {filteredLogs.length === 0 && (
            <div className="text-center py-12 text-bmx-muted/30">
              {logs.length === 0
                ? "Waiting for scan to start..."
                : "No logs match this filter"}
            </div>
          )}

          {filteredLogs.map((log) => {
            const color = getLogColor(log.level, log.module, log.message);
            const icon = getModuleIcon(log.module);
            const isReasoning = log.module?.startsWith("reasoning:");
            const isVerified = log.message?.includes("VERIFIED") || log.message?.includes("🔥");
            const isMock = log.message?.includes("mock mode") || log.message?.includes("Tool not found");

            return (
              <div key={log.id}
                className={`flex gap-2 items-start py-0.5 group ${
                  isReasoning ? "bg-bmx-cyan/3 rounded px-1 -mx-1 my-0.5" :
                  isVerified ? "bg-bmx-red/5 rounded px-1 -mx-1 my-0.5" : ""
                }`}>
                <span className="shrink-0 text-bmx-muted/25 w-16 text-right tabular-nums text-[10px] mt-0.5">
                  {fmtTime(log.timestamp)}
                </span>
                <span className="shrink-0 text-[10px] mt-0.5 w-4 text-center">{icon}</span>
                <span className={`shrink-0 w-24 text-[9px] mt-0.5 truncate ${
                  isMock ? "text-bmx-muted/20" :
                  isReasoning ? "text-bmx-cyan/50" : "text-bmx-muted/30"
                }`}>
                  {PHASE_NAMES[log.module] || log.module}
                </span>
                <span className={`flex-1 leading-5 break-words ${color} ${isMock ? "opacity-30" : ""}`}>
                  {log.message}
                </span>
              </div>
            );
          })}

          {isRunning && (
            <div className="flex items-center gap-2 py-1 text-bmx-muted/30">
              <span className="w-16" />
              <span className="w-4" />
              <span className="w-24" />
              <span className="flex items-center gap-1.5">
                <span className="inline-block w-1.5 h-4 bg-bmx-cyan/60 animate-pulse rounded-sm" />
                <span className="text-bmx-cyan/40">scanning...</span>
              </span>
            </div>
          )}

          <div ref={logsEndRef} />
        </div>
      </div>
    </div>
  );
}
