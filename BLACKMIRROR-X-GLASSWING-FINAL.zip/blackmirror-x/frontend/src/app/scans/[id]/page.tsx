"use client";
import { useEffect, useRef, useState } from "react";
import { useParams } from "next/navigation";
import { scanApi } from "@/lib/api";
import { Activity, XCircle, ChevronDown, ChevronUp } from "lucide-react";

interface ScanLog { id: string; level: string; message: string; created_at: string; agent?: string; }
interface ScanDetail {
  id: string; target: string; status: string; scan_type: string;
  created_at: string; completed_at?: string;
  subdomain_count: number; url_count: number; vuln_count: number;
}

const LOG_COLORS: Record<string, string> = {
  info: "text-bmx-teal",
  success: "text-bmx-green",
  warning: "text-bmx-yellow",
  error: "text-bmx-red",
  debug: "text-bmx-muted",
};

export default function ScanDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [scan, setScan] = useState<ScanDetail | null>(null);
  const [logs, setLogs] = useState<ScanLog[]>([]);
  const [autoScroll, setAutoScroll] = useState(true);
  const logRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!id) return;
    // Initial data
    scanApi.get(id).then((res) => setScan(res.data));
    scanApi.logs(id, 200).then((res) => setLogs(res.data));

    // WebSocket for live updates
    const token = localStorage.getItem("bmx_access_token");
    const wsUrl = (process.env.NEXT_PUBLIC_WS_URL || "") + `/api/v1/ws/scan/${id}?token=${token}`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onmessage = (e) => {
      const data = JSON.parse(e.data);
      if (data.type === "log") {
        setLogs((prev) => [...prev.slice(-499), data.log]);
      } else if (data.type === "status") {
        setScan((prev) => prev ? { ...prev, status: data.status } : prev);
      } else if (data.type === "stats") {
        setScan((prev) => prev ? { ...prev, ...data.stats } : prev);
      }
    };

    return () => ws.close();
  }, [id]);

  useEffect(() => {
    if (autoScroll && logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const cancelScan = async () => {
    if (!id) return;
    await scanApi.cancel(id);
    setScan((prev) => prev ? { ...prev, status: "cancelled" } : prev);
  };

  if (!scan) return (
    <div className="p-6 text-bmx-muted font-mono text-sm">Loading scan...</div>
  );

  const isRunning = scan.status === "running" || scan.status === "pending";

  return (
    <div className="p-6 space-y-4 h-full flex flex-col">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-white font-mono text-lg font-bold">{scan.target}</h1>
          <p className="text-bmx-muted font-mono text-xs mt-1">
            {scan.scan_type} • Started {new Date(scan.created_at).toLocaleString()}
          </p>
        </div>
        <div className="flex items-center gap-3">
          {isRunning && (
            <>
              <div className="flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-bmx-cyan animate-pulse" />
                <span className="text-bmx-cyan text-xs font-mono">SCANNING</span>
              </div>
              <button
                onClick={cancelScan}
                className="flex items-center gap-1.5 border border-bmx-red/40 text-bmx-red text-xs font-mono px-3 py-1.5 rounded hover:bg-bmx-red/10 transition-colors"
              >
                <XCircle className="w-3.5 h-3.5" /> CANCEL
              </button>
            </>
          )}
          {!isRunning && (
            <span className={`text-xs font-mono px-3 py-1.5 rounded border ${
              scan.status === "completed" ? "text-bmx-green border-bmx-green/30 bg-bmx-green/10" :
              scan.status === "failed" ? "text-bmx-red border-bmx-red/30 bg-bmx-red/10" :
              "text-bmx-muted border-bmx-border"
            }`}>
              {scan.status.toUpperCase()}
            </span>
          )}
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "SUBDOMAINS", value: scan.subdomain_count, color: "text-bmx-teal" },
          { label: "URLS", value: scan.url_count, color: "text-bmx-cyan" },
          { label: "VULNS", value: scan.vuln_count, color: scan.vuln_count > 0 ? "text-bmx-orange" : "text-bmx-green" },
        ].map((s) => (
          <div key={s.label} className="bmx-panel rounded border border-bmx-border p-3 text-center">
            <div className={`text-2xl font-mono font-bold ${s.color}`}>{s.value}</div>
            <div className="text-bmx-muted text-xs font-mono mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Log viewer */}
      <div className="flex-1 bmx-panel rounded-lg border border-bmx-border flex flex-col min-h-0">
        <div className="flex items-center justify-between px-4 py-2 border-b border-bmx-border shrink-0">
          <span className="text-white font-mono text-xs tracking-wider">LIVE LOGS</span>
          <div className="flex items-center gap-3">
            <span className="text-bmx-muted text-xs font-mono">{logs.length} entries</span>
            <button
              onClick={() => setAutoScroll(!autoScroll)}
              className={`flex items-center gap-1 text-xs font-mono transition-colors ${autoScroll ? "text-bmx-cyan" : "text-bmx-muted"}`}
            >
              {autoScroll ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
              AUTO-SCROLL
            </button>
          </div>
        </div>
        <div
          ref={logRef}
          className="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-1 terminal"
          onScroll={(e) => {
            const el = e.currentTarget;
            const isBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 20;
            setAutoScroll(isBottom);
          }}
        >
          {logs.map((log, i) => (
            <div key={log.id || i} className="flex gap-3 items-start">
              <span className="text-bmx-muted/50 shrink-0 w-20 truncate">
                {new Date(log.created_at).toLocaleTimeString()}
              </span>
              {log.agent && (
                <span className="text-bmx-cyan/60 shrink-0 w-20 truncate">[{log.agent}]</span>
              )}
              <span className={`${LOG_COLORS[log.level] || "text-white"} break-all`}>
                {log.message}
              </span>
            </div>
          ))}
          {logs.length === 0 && (
            <div className="text-bmx-muted/40">Waiting for logs...</div>
          )}
          {isRunning && (
            <div className="flex items-center gap-2 text-bmx-cyan/60 mt-2">
              <span className="cursor-blink">▌</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
