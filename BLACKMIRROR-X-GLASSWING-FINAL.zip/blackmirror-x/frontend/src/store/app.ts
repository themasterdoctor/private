/* eslint-disable */
import { create } from "zustand";
import { persist } from "zustand/middleware";
import { workspaceApi, scanApi, vulnApi, reconApi } from "@/lib/api";

export interface Workspace { id: string; name: string; description: string; slug: string; created_at: string; }
export interface ScanJob {
  id: string; name?: string; target: string; status: string; scan_type: string;
  created_at: string; completed_at?: string; workspace_id: string;
  subdomain_count: number; url_count: number; vuln_count: number;
  progress?: number; config?: Record<string, unknown>;
}
export interface Vulnerability {
  id: string; title: string; vuln_type: string; severity: string;
  status: string; url: string; parameter?: string; description: string;
  cvss_score?: number; cwe_id?: string; created_at: string; scan_id: string;
  workspace_id?: string; payload?: string; evidence?: string;
  evidence_score?: number; reproduction_steps?: string; remediation?: string;
  court_confidence?: number; exploitability_score?: number;
  bounty_likelihood?: number; reflection_context?: string; simulation_narrative?: string;
}
export interface Subdomain {
  id: string; subdomain: string; ip_address?: string; status_code?: number;
  title?: string; technologies?: string[]; ports?: number[]; created_at: string;
}

interface AppState {
  workspaces: Workspace[];
  activeWorkspace: Workspace | null;
  scans: ScanJob[];
  vulns: Vulnerability[];
  subdomains: Subdomain[];
  isLoadingWorkspaces: boolean;
  isLoadingScans: boolean;
  isLoadingVulns: boolean;

  fetchWorkspaces: () => Promise<void>;
  setActiveWorkspace: (ws: Workspace) => void;
  fetchScans: (workspaceId?: string) => Promise<void>;
  createScan: (data: {
    target?: string; name?: string; workspace_id: string;
    scan_type?: string; config?: Record<string, unknown>;
  }) => Promise<ScanJob>;
  fetchVulns: (params?: { workspace_id?: string; scan_id?: string; severity?: string }) => Promise<void>;
  fetchSubdomains: (params?: { scan_id?: string; workspace_id?: string }) => Promise<void>;
  updateVuln: (id: string, data: { status?: string; notes?: string }) => Promise<void>;
}

export const useAppStore = create<AppState>()(
  persist(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    (set, get) => ({
      workspaces: [],
      activeWorkspace: null,
      scans: [],
      vulns: [],
      subdomains: [],
      isLoadingWorkspaces: false,
      isLoadingScans: false,
      isLoadingVulns: false,

      fetchWorkspaces: async () => {
        set({ isLoadingWorkspaces: true });
        try {
          const res = await workspaceApi.list();
          const workspaces: Workspace[] = res.data || [];
          set((s) => ({
            workspaces,
            // Keep current activeWorkspace if still in list, otherwise pick first
            activeWorkspace: s.activeWorkspace
              ? (workspaces.find((w) => w.id === s.activeWorkspace!.id) || workspaces[0] || null)
              : (workspaces[0] || null),
          }));
        } catch (e) {
          console.error("[AppStore] fetchWorkspaces failed:", e);
        } finally {
          set({ isLoadingWorkspaces: false });
        }
      },

      setActiveWorkspace: (ws) => {
        set({ activeWorkspace: ws });
        // Also store in localStorage directly for cross-tab awareness
        if (typeof window !== "undefined") {
          localStorage.setItem("bmx_active_workspace_id", ws.id);
        }
      },

      fetchScans: async (workspaceId) => {
        set({ isLoadingScans: true });
        try {
          const wid = workspaceId || get().activeWorkspace?.id;
          if (!wid) return;
          const res = await scanApi.list(wid);
          set({ scans: res.data || [] });
        } catch (e) {
          console.error("[AppStore] fetchScans failed:", e);
        } finally {
          set({ isLoadingScans: false });
        }
      },

      createScan: async (data) => {
        const res = await scanApi.create(data);
        const scan: ScanJob = res.data;
        set((s) => ({ scans: [scan, ...s.scans] }));
        return scan;
      },

      fetchVulns: async (params) => {
        set({ isLoadingVulns: true });
        try {
          const wid = get().activeWorkspace?.id;
          const res = await vulnApi.list({ workspace_id: wid, ...params });
          set({ vulns: res.data || [] });
        } catch (e) {
          console.error("[AppStore] fetchVulns failed:", e);
        } finally {
          set({ isLoadingVulns: false });
        }
      },

      fetchSubdomains: async (params) => {
        try {
          const wid = get().activeWorkspace?.id;
          const res = await reconApi.subdomains({ workspace_id: wid, ...params });
          set({ subdomains: res.data || [] });
        } catch (e) {
          console.error("[AppStore] fetchSubdomains failed:", e);
        }
      },

      updateVuln: async (id, data) => {
        await vulnApi.update(id, data);
        set((s) => ({
          vulns: s.vulns.map((v) => (v.id === id ? { ...v, ...data } : v)),
        }));
      },
    }),
    {
      name: "bmx-app",
      // Only persist activeWorkspace — the rest is fetched fresh from API
      partialize: (state) => ({ activeWorkspace: state.activeWorkspace }),
    }
  )
);
