"use client";
/**
 * Command Palette — ⌘K / Ctrl+K global launcher
 * Inspired by Linear, Vercel, Raycast
 * Searchable nav, quick scan launch, recent items, AI actions
 */
import { useEffect, useRef, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { useAppStore } from "@/store/app";
import {
  Search, LayoutDashboard, Bug, Network, MessageSquare,
  FileText, Shield, Play, Brain, Scale, Database, Globe,
  Link2, Layers, Server, Rss, Zap, Settings, CheckCircle,
  Users, Cpu, ArrowRight, Activity, Terminal
} from "lucide-react";

interface CommandItem {
  id: string;
  label: string;
  description?: string;
  icon: React.ElementType;
  color: string;
  action: () => void;
  category: string;
  keywords?: string;
}

interface CommandPaletteProps {
  open: boolean;
  onClose: () => void;
}

export function CommandPalette({ open, onClose }: CommandPaletteProps) {
  const router = useRouter();
  const { scans, vulns, activeWorkspace } = useAppStore();
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const go = useCallback((href: string) => {
    router.push(href);
    onClose();
  }, [router, onClose]);

  const allCommands: CommandItem[] = [
    // Navigation
    { id: "dashboard",    label: "Dashboard",       description: "Overview & scan launcher",       icon: LayoutDashboard, color: "text-bmx-cyan",    action: () => go("/dashboard"),    category: "Navigate",  keywords: "home overview" },
    { id: "recon",        label: "Recon",            description: "Subdomain & surface map",        icon: Search,          color: "text-bmx-teal",    action: () => go("/recon"),        category: "Navigate",  keywords: "subdomains attack surface" },
    { id: "vulns",        label: "Vulnerabilities",  description: `${vulns.length} findings`,       icon: Bug,             color: "text-bmx-red",     action: () => go("/vulns"),        category: "Navigate",  keywords: "findings bugs security" },
    { id: "graph",        label: "Attack Graph",     description: "Visual attack surface",          icon: Network,         color: "text-bmx-orange",  action: () => go("/graph"),        category: "Navigate",  keywords: "graph visual nodes" },
    { id: "copilot",      label: "AI Copilot",       description: "Chat with GLASSWING AI",         icon: MessageSquare,   color: "text-bmx-green",   action: () => go("/copilot"),      category: "Navigate",  keywords: "chat ai assistant ask" },
    { id: "mission",      label: "Mission Control",  description: "Hypothesis board + live reasoning", icon: Brain,        color: "text-bmx-cyan",    action: () => go("/mission"),      category: "Intelligence", keywords: "hypothesis ai reasoning" },
    { id: "court",        label: "AI Courtroom",     description: "Adversarial vuln validation",    icon: Scale,           color: "text-purple-400",  action: () => go("/court"),        category: "Intelligence", keywords: "validate court verdict" },
    { id: "evidence",     label: "Evidence Vault",   description: "Request/response proof",         icon: Database,        color: "text-bmx-green",   action: () => go("/evidence"),     category: "Intelligence", keywords: "proof request response" },
    { id: "monitor",      label: "Monitor",          description: "Continuous change detection",    icon: Rss,             color: "text-bmx-orange",  action: () => go("/monitor"),      category: "Intelligence", keywords: "monitoring alerts changes" },
    { id: "replay",       label: "Replay Lab",       description: "HTTP request replay & diff",     icon: Zap,             color: "text-bmx-yellow",  action: () => go("/replay"),       category: "Intelligence", keywords: "replay request test" },
    { id: "reports",      label: "Reports",          description: "Generate & export reports",      icon: FileText,        color: "text-blue-400",    action: () => go("/reports"),      category: "Navigate",  keywords: "export pdf hackerone" },
    { id: "workflows",    label: "Workflows",        description: "Launch autonomous pipelines",    icon: Play,            color: "text-bmx-cyan",    action: () => go("/workflows"),    category: "Navigate",  keywords: "pipeline automation scan" },
    { id: "scope",        label: "Scope Engine",     description: "Authorized targets & rules",     icon: Shield,          color: "text-bmx-yellow",  action: () => go("/scope"),        category: "Enterprise", keywords: "scope authorization rules" },
    { id: "approvals",    label: "Approvals",        description: "Human gate for risky actions",   icon: CheckCircle,     color: "text-bmx-orange",  action: () => go("/approvals"),    category: "Enterprise", keywords: "approval gate risk" },
    { id: "team",         label: "Team",             description: "Members, RBAC, SLA tracking",    icon: Users,           color: "text-bmx-cyan",    action: () => go("/team"),         category: "Enterprise", keywords: "team roles permissions" },
    { id: "orchestrator", label: "Orchestrator",     description: "Agent task control plane",       icon: Cpu,             color: "text-bmx-cyan",    action: () => go("/orchestrator"), category: "AVROS",     keywords: "agents orchestrate tasks" },
    { id: "browser",      label: "Browser Intel",    description: "Playwright authenticated crawl", icon: Globe,           color: "text-bmx-teal",    action: () => go("/browser-intel"),category: "AVROS",     keywords: "browser playwright crawl" },
    { id: "api-intel",    label: "API Intel",        description: "GraphQL / OpenAPI analysis",     icon: Link2,           color: "text-bmx-orange",  action: () => go("/api-intel"),    category: "AVROS",     keywords: "api graphql swagger" },
    { id: "chains",       label: "Attack Chains",    description: "Multi-hop attack paths",         icon: Layers,          color: "text-bmx-red",     action: () => go("/chains"),       category: "AVROS",     keywords: "chain path attack hop" },
    { id: "memory",       label: "Memory",           description: "Workspace learning & history",   icon: Database,        color: "text-purple-400",  action: () => go("/memory"),       category: "AVROS",     keywords: "memory learning history" },
    { id: "workers",      label: "Workers",          description: "Celery queue & task status",     icon: Server,          color: "text-bmx-green",   action: () => go("/workers"),      category: "AVROS",     keywords: "celery queue worker" },
    { id: "settings",     label: "Settings",         description: "Workspaces & API keys",          icon: Settings,        color: "text-gray-400",    action: () => go("/settings"),     category: "Navigate",  keywords: "api key workspace" },

    // Quick actions
    { id: "new-scan",     label: "Launch New Scan",  description: `Scan ${activeWorkspace?.name || "active workspace"}`, icon: Activity, color: "text-bmx-cyan", action: () => { go("/dashboard"); }, category: "Quick Action", keywords: "scan start launch" },
    { id: "ask-ai",       label: "Ask AI Copilot",   description: "Open chat with GLASSWING AI",    icon: MessageSquare,   color: "text-bmx-green",   action: () => go("/copilot"),      category: "Quick Action", keywords: "ask question ai chat" },
  ];

  // Recent scans as commands
  const recentCommands: CommandItem[] = scans.slice(0, 3).map(s => ({
    id: `scan-${s.id}`,
    label: s.target || s.name || "Scan",
    description: `${s.status} · ${new Date(s.created_at).toLocaleDateString()}`,
    icon: Terminal,
    color: s.status === "completed" ? "text-bmx-green" : s.status === "failed" ? "text-bmx-red" : "text-bmx-cyan",
    action: () => go(`/scans/${s.id}`),
    category: "Recent Scans",
    keywords: s.target || "",
  }));

  const allItems = [...recentCommands, ...allCommands];

  const filtered = query.trim()
    ? allItems.filter(c =>
        c.label.toLowerCase().includes(query.toLowerCase()) ||
        (c.description || "").toLowerCase().includes(query.toLowerCase()) ||
        (c.keywords || "").toLowerCase().includes(query.toLowerCase())
      )
    : allItems;

  // Group by category
  const grouped = filtered.reduce<Record<string, CommandItem[]>>((acc, item) => {
    if (!acc[item.category]) acc[item.category] = [];
    acc[item.category].push(item);
    return acc;
  }, {});

  const flatFiltered = Object.values(grouped).flat();

  useEffect(() => {
    if (open) {
      setQuery("");
      setSelected(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  useEffect(() => {
    setSelected(0);
  }, [query]);

  const handleKey = useCallback((e: KeyboardEvent) => {
    if (!open) return;
    if (e.key === "Escape") { onClose(); return; }
    if (e.key === "ArrowDown") { e.preventDefault(); setSelected(s => Math.min(s + 1, flatFiltered.length - 1)); }
    if (e.key === "ArrowUp") { e.preventDefault(); setSelected(s => Math.max(s - 1, 0)); }
    if (e.key === "Enter") {
      e.preventDefault();
      flatFiltered[selected]?.action();
      onClose();
    }
  }, [open, flatFiltered, selected, onClose]);

  useEffect(() => {
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [handleKey]);

  // Scroll selected into view
  useEffect(() => {
    const el = listRef.current?.querySelector(`[data-idx="${selected}"]`);
    el?.scrollIntoView({ block: "nearest" });
  }, [selected]);

  if (!open) return null;

  let globalIdx = 0;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-[15vh]"
      onClick={onClose}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />

      {/* Palette */}
      <div
        className="relative w-full max-w-2xl mx-4 bg-bmx-dark border border-bmx-border rounded-xl shadow-2xl shadow-black/60 overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Search input */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-bmx-border">
          <Search className="w-4 h-4 text-bmx-muted shrink-0" />
          <input
            ref={inputRef}
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search commands, pages, scans..."
            className="flex-1 bg-transparent text-white font-mono text-sm placeholder:text-bmx-muted/50 outline-none"
          />
          <kbd className="text-bmx-muted/40 text-xs font-mono border border-bmx-border rounded px-1.5 py-0.5">ESC</kbd>
        </div>

        {/* Results */}
        <div ref={listRef} className="max-h-[60vh] overflow-y-auto py-2">
          {Object.entries(grouped).map(([category, items]) => (
            <div key={category} className="mb-1">
              <p className="px-4 py-1 text-[10px] font-mono tracking-[0.15em] text-bmx-muted/40 uppercase">
                {category}
              </p>
              {items.map((item) => {
                const idx = globalIdx++;
                const isSelected = idx === selected;
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    data-idx={idx}
                    onClick={() => { item.action(); onClose(); }}
                    onMouseEnter={() => setSelected(idx)}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors ${
                      isSelected ? "bg-bmx-border/60" : "hover:bg-bmx-border/30"
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isSelected ? item.color : "text-bmx-muted"}`} />
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm font-mono ${isSelected ? "text-white" : "text-bmx-muted/80"}`}>
                        {item.label}
                      </p>
                      {item.description && (
                        <p className="text-xs font-mono text-bmx-muted/40 truncate">{item.description}</p>
                      )}
                    </div>
                    {isSelected && <ArrowRight className="w-3.5 h-3.5 text-bmx-muted/40 shrink-0" />}
                  </button>
                );
              })}
            </div>
          ))}

          {filtered.length === 0 && (
            <div className="px-4 py-8 text-center text-bmx-muted/40 font-mono text-sm">
              No results for &ldquo;{query}&rdquo;
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-bmx-border px-4 py-2 flex items-center gap-4 text-[10px] font-mono text-bmx-muted/30">
          <span><kbd className="border border-bmx-border/50 rounded px-1">↑↓</kbd> navigate</span>
          <span><kbd className="border border-bmx-border/50 rounded px-1">↵</kbd> open</span>
          <span><kbd className="border border-bmx-border/50 rounded px-1">esc</kbd> close</span>
          <span className="ml-auto">{filtered.length} results</span>
        </div>
      </div>
    </div>
  );
}
