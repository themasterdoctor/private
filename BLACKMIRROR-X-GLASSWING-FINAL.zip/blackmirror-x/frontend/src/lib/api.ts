import axios, { AxiosInstance, InternalAxiosRequestConfig } from "axios";

// BASE_URL must NOT include /api/v1 — it's the root of the API server
// The path segments (/api/v1/...) are appended per-request
const BASE_URL = (process.env.NEXT_PUBLIC_API_URL || "") + "/api/v1";

let api: AxiosInstance;

export function getToken(): string {
  if (typeof window === "undefined") return "";
  return localStorage.getItem("bmx_access_token") || "";
}

function getApi(): AxiosInstance {
  if (!api) {
    api = axios.create({ baseURL: BASE_URL, timeout: 60000 });

    api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
      const token = getToken();
      if (token) config.headers.Authorization = `Bearer ${token}`;
      return config;
    });

    api.interceptors.response.use(
      (r) => r,
      async (error) => {
        const status = error.response?.status;
        const path = error.config?.url || "unknown";
        const body = JSON.stringify(error.response?.data || {});

        if (process.env.NODE_ENV === "development") {
          console.error(`[BMX API] ${status} ${path}`, error.response?.data);
        }

        if (status === 401) {
          const refresh = localStorage.getItem("bmx_refresh_token");
          if (refresh) {
            try {
              const res = await axios.post(`${BASE_URL}/auth/refresh`, { refresh_token: refresh });
              localStorage.setItem("bmx_access_token", res.data.access_token);
              error.config.headers.Authorization = `Bearer ${res.data.access_token}`;
              return api.request(error.config);
            } catch {
              localStorage.clear();
              window.location.href = "/auth/login";
            }
          } else {
            localStorage.clear();
            window.location.href = "/auth/login";
          }
        }

        // Attach readable message for UI
        const detail = error.response?.data?.detail || error.response?.data?.message || body;
        error.uiMessage = typeof detail === "string" ? detail : JSON.stringify(detail);
        return Promise.reject(error);
      }
    );
  }
  return api;
}

// ─── Auth ────────────────────────────────────────────────────────────────────
export const authApi = {
  register: (data: { email: string; password: string; full_name: string }) =>
    getApi().post("/auth/register", data),
  // Backend route is /auth/login (NOT /auth/token)
  login: (email: string, password: string) => {
    const form = new URLSearchParams();
    form.append("username", email);
    form.append("password", password);
    return getApi().post("/auth/login", form, {
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    });
  },
  me: () => getApi().get("/auth/me"),
};

// ─── Workspaces ───────────────────────────────────────────────────────────────
export const workspaceApi = {
  list: () => getApi().get("/workspaces"),
  create: (data: { name: string; description?: string }) =>
    getApi().post("/workspaces", data),
  get: (id: string) => getApi().get(`/workspaces/${id}`),
};

// ─── Scans ────────────────────────────────────────────────────────────────────
export const scanApi = {
  list: (workspaceId?: string) =>
    getApi().get("/scans", { params: { workspace_id: workspaceId } }),
  create: (data: {
    target?: string;
    name?: string;
    workspace_id: string;
    scan_type?: string;
    config?: Record<string, unknown>;
  }) => getApi().post("/scans", data),
  get: (id: string) => getApi().get(`/scans/${id}`),
  cancel: (id: string) => getApi().post(`/scans/${id}/cancel`),
  logs: (id: string, limit = 100) =>
    getApi().get(`/scans/${id}/logs`, { params: { limit } }),
};

// ─── Vulnerabilities ──────────────────────────────────────────────────────────
export const vulnApi = {
  list: (params?: {
    workspace_id?: string;
    scan_id?: string;
    severity?: string;
    status?: string;
    type?: string;
    page?: number;
    limit?: number;
  }) => getApi().get("/vulns", { params }),
  get: (id: string) => getApi().get(`/vulns/${id}`),
  update: (id: string, data: { status?: string; notes?: string }) =>
    getApi().patch(`/vulns/${id}`, data),
  hackeroneReport: (id: string) => getApi().get(`/vulns/${id}/hackerone-report`),
};

// ─── Recon ────────────────────────────────────────────────────────────────────
export const reconApi = {
  subdomains: (params?: { scan_id?: string; workspace_id?: string; limit?: number }) =>
    getApi().get("/recon/subdomains", { params }),
  urls: (params?: { scan_id?: string; workspace_id?: string; limit?: number }) =>
    getApi().get("/recon/urls", { params }),
};

// ─── Reports ──────────────────────────────────────────────────────────────────
export const reportApi = {
  list: (workspaceId?: string) =>
    getApi().get("/reports", { params: { workspace_id: workspaceId } }),
  get: (id: string) => getApi().get(`/reports/${id}`),
  generate: (scanId: string, format?: string) =>
    getApi().post(`/reports/generate/${scanId}`, { format }),
};

// ─── Copilot ──────────────────────────────────────────────────────────────────
export const copilotApi = {
  sessions: (workspaceId?: string) =>
    getApi().get("/copilot/sessions", { params: { workspace_id: workspaceId } }),
  messages: (sessionId: string) =>
    getApi().get(`/copilot/sessions/${sessionId}/messages`),
};

// ─── API Keys ─────────────────────────────────────────────────────────────────
export const apiKeyApi = {
  list: () => getApi().get("/apikeys"),
  create: (data: { name: string; scopes?: string[] }) =>
    getApi().post("/apikeys", data),
  revoke: (id: string) => getApi().delete(`/apikeys/${id}`),
};

// ─── Agents ───────────────────────────────────────────────────────────────────
export const agentApi = {
  runs: (scanId?: string) =>
    getApi().get("/agents/runs", { params: { scan_id: scanId } }),
};

// ─── SSE / Stream helpers ─────────────────────────────────────────────────────
export function createScanStream(scanId: string, onMessage: (data: unknown) => void) {
  const token = getToken();
  const url = `${BASE_URL}/scans/${scanId}/stream?token=${token}`;
  const es = new EventSource(url);
  es.onmessage = (e) => {
    try { onMessage(JSON.parse(e.data)); } catch { /* ignore */ }
  };
  return es;
}

export function createCopilotStream(
  message: string,
  workspaceId: string,
  sessionId: string | null,
  onChunk: (text: string) => void,
  onDone: (sessionId: string) => void
) {
  const token = getToken();
  const body = JSON.stringify({ message, workspace_id: workspaceId, session_id: sessionId });
  const controller = new AbortController();

  fetch(`${BASE_URL}/copilot/chat/stream`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body,
    signal: controller.signal,
  }).then(async (res) => {
    if (!res.ok) {
      onDone(sessionId || "");
      return;
    }
    const reader = res.body?.getReader();
    if (!reader) return;
    const decoder = new TextDecoder();
    let buffer = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        if (line.startsWith("data: ")) {
          const data = line.slice(6).trim();
          if (data === "[DONE]") {
            onDone(sessionId || "");
          } else {
            try {
              const parsed = JSON.parse(data);
              if (parsed.text) onChunk(parsed.text);
              if (parsed.session_id) onDone(parsed.session_id);
            } catch { /* ignore */ }
          }
        }
      }
    }
  }).catch(() => { /* aborted */ });

  return () => controller.abort();
}

export default getApi;

// ─── Intelligence Layer API ───────────────────────────────────────────────────
export const intelligenceAPI = {
  generateHypotheses: (scanId: string) =>
    getApi().post(`/intel/hypotheses/generate/${scanId}`),
  streamHypotheses: (scanId: string) =>
    `${BASE_URL}/intel/hypotheses/stream/${scanId}`,
  adjudicateVuln: (vulnId: string) =>
    getApi().post(`/intel/court/adjudicate/${vulnId}`),
  getMemory: (workspaceId: string) =>
    getApi().get(`/intel/memory/${workspaceId}`),
  addFalsePositive: (workspaceId: string, signature: string) =>
    getApi().post(`/intel/memory/${workspaceId}/false-positive`, { signature }),
  simulateExploitability: (vulnId: string) =>
    getApi().post(`/intel/simulate/${vulnId}`),
  getPayloads: (vulnType: string, context?: string, waf?: string, param?: string) =>
    getApi().get(`/intel/payloads/${vulnType}`, { params: { context, waf, param } }),
  startMonitoring: (target: string, workspaceId: string, intervalHours = 24) =>
    getApi().post(`/intel/monitor/start`, { target, workspace_id: workspaceId, interval_hours: intervalHours }),
  listMonitors: () =>
    getApi().get(`/intel/monitor/active`),
  stopMonitoring: (workspaceId: string, target: string) =>
    getApi().delete(`/intel/monitor/${workspaceId}/${target}`),
  getMetrics: () =>
    getApi().get(`/intel/metrics`),
};

// ─── Enterprise Features API ─────────────────────────────────────────────────
export const scopeApi = {
  get: (workspaceId: string) => getApi().get(`/enterprise/scope/${workspaceId}`),
  addInclude: (workspaceId: string, pattern: string, notes?: string) =>
    getApi().post(`/enterprise/scope/${workspaceId}/include`, { pattern, notes }),
  addExclude: (workspaceId: string, pattern: string, notes?: string) =>
    getApi().post(`/enterprise/scope/${workspaceId}/exclude`, { pattern, notes }),
  check: (workspaceId: string, target: string) =>
    getApi().post(`/enterprise/scope/${workspaceId}/check`, { target }),
  importProgram: (workspaceId: string, data: Record<string, unknown>) =>
    getApi().post(`/enterprise/scope/${workspaceId}/import-program`, data),
  confirmAuth: (workspaceId: string, confirmed: boolean, note?: string) =>
    getApi().post(`/enterprise/scope/${workspaceId}/confirm-authorization`, { confirmed, authorization_note: note }),
  auditLog: (workspaceId: string, limit?: number) =>
    getApi().get(`/enterprise/scope/${workspaceId}/audit-log`, { params: { limit } }),
  confirmTesting: (data: Record<string, unknown>) =>
    getApi().post(`/enterprise/safety/confirm-authorization`, data),
};

export const approvalApi = {
  listPending: (workspaceId: string) =>
    getApi().get(`/enterprise/approvals/${workspaceId}/pending`),
  approve: (requestId: string, reason?: string) =>
    getApi().post(`/enterprise/approvals/${requestId}/approve`, { reason }),
  reject: (requestId: string, reason: string) =>
    getApi().post(`/enterprise/approvals/${requestId}/reject`, { reason }),
  history: (workspaceId: string, limit?: number) =>
    getApi().get(`/enterprise/approvals/${workspaceId}/history`, { params: { limit } }),
  emergencyStop: (workspaceId: string) =>
    getApi().post(`/enterprise/emergency-stop/${workspaceId}`),
  resumeScanning: (workspaceId: string) =>
    getApi().post(`/enterprise/emergency-stop/${workspaceId}/resume`),
  stopStatus: (workspaceId: string) =>
    getApi().get(`/enterprise/emergency-stop/${workspaceId}/status`),
};

export const scoringApi = {
  scoreVuln: (vulnId: string) =>
    getApi().post(`/enterprise/scoring/score-vuln/${vulnId}`),
  scoreFinding: (data: Record<string, unknown>) =>
    getApi().post(`/enterprise/scoring/score-finding`, data),
};

export const teamApi = {
  members: (workspaceId: string) =>
    getApi().get(`/enterprise/team/${workspaceId}/members`),
  permissions: (workspaceId: string) =>
    getApi().get(`/enterprise/team/${workspaceId}/permissions`),
  addComment: (workspaceId: string, vulnId: string, content: string, type?: string) =>
    getApi().post(`/enterprise/team/${workspaceId}/comments/${vulnId}`, { content, comment_type: type }),
  slaCheck: (workspaceId: string, vulnId: string) =>
    getApi().post(`/enterprise/team/${workspaceId}/sla-check/${vulnId}`),
  slaPolicy: (workspaceId: string) =>
    getApi().get(`/enterprise/team/${workspaceId}/sla`),
};

export const enterprisePayloadApi = {
  get: (vulnType: string, tier?: string, context?: string, limit?: number) =>
    getApi().get(`/enterprise/payloads/${vulnType}`, { params: { tier, context, limit } }),
  summary: () => getApi().get(`/enterprise/payloads/summary/all`),
};

export const pluginApi = {
  list: (pluginType?: string) =>
    getApi().get(`/enterprise/plugins`, { params: { plugin_type: pluginType } }),
  run: (pluginName: string, target: string, config?: Record<string, unknown>) =>
    getApi().post(`/enterprise/plugins/${pluginName}/run`, { target, config }),
};

export const reportQualityApi = {
  check: (scanId: string, reportContent?: string) =>
    getApi().post(`/enterprise/report-quality/${scanId}`, { report_content: reportContent }),
};

export const safetyApi = {
  rateLimitStatus: (workspaceId: string) =>
    getApi().get(`/enterprise/safety/rate-limit-status/${workspaceId}`),
};
