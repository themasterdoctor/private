/**
 * BLACKMIRROR-X — Real Browser Button Proof
 * Tests every required button against the live app.
 * Run: FRONTEND=http://76.13.30.226:3000 BACKEND=http://76.13.30.226:8000 npx playwright test tests/e2e/ui-clicks.spec.js
 */
const { test, expect } = require('@playwright/test');

const F = process.env.FRONTEND || 'http://127.0.0.1:3000';
const B = process.env.BACKEND  || 'http://127.0.0.1:8000';
const EMAIL = 'admin@blackmirror.io';
const PASS  = 'BlackMirrorX2025!';

async function loginAndGoTo(page, path) {
  await page.goto(`${F}/auth/login`);
  await page.fill('input[type="email"]', EMAIL);
  await page.fill('input[type="password"]', PASS);
  const loginP = page.waitForResponse(
    r => r.url().includes('/auth/login') && r.request().method() === 'POST',
    { timeout: 15000 }
  );
  await page.locator('button[type="submit"]').click();
  const lr = await loginP;
  expect(lr.status()).toBe(200);
  await page.waitForURL('**/dashboard', { timeout: 20000 });
  // Wait for workspace
  await page.waitForResponse(
    r => r.url().includes('/api/v1/workspaces') && r.status() === 200,
    { timeout: 10000 }
  ).catch(() => {});
  await page.waitForFunction(
    () => {
      const p = document.querySelector('p.text-bmx-muted.text-sm.font-mono');
      return p && p.textContent && !p.textContent.includes('No workspace selected') && p.textContent.trim().length > 0;
    },
    { timeout: 12000 }
  ).catch(() => {});
  if (path && path !== '/dashboard') {
    await page.goto(`${F}${path}`);
    await page.waitForLoadState('domcontentloaded');
    await page.waitForResponse(r => r.url().includes('/api/v1/workspaces'), { timeout: 8000 }).catch(() => {});
    await page.waitForTimeout(800);
  }
}

test('1. Login', async ({ page }) => {
  await page.goto(`${F}/auth/login`);
  await page.fill('input[type="email"]', EMAIL);
  await page.fill('input[type="password"]', PASS);
  const resp = page.waitForResponse(
    r => r.url().includes('/auth/login') && r.request().method() === 'POST',
    { timeout: 15000 }
  );
  await page.locator('button[type="submit"]').click();
  const r = await resp;
  const body = await r.json().catch(() => ({}));
  expect(r.status()).toBe(200);
  expect(body.access_token).toBeTruthy();
  await page.waitForURL('**/dashboard', { timeout: 20000 });
  expect(page.url()).toContain('/dashboard');
  console.log('  RESULT: POST /auth/login 200, token=' + body.access_token.slice(0,15) + '..., url=/dashboard');
});

test('2. Dashboard MISSION CONTROL with workspace', async ({ page }) => {
  await loginAndGoTo(page, '/dashboard');
  await expect(page.locator('h1').filter({ hasText: 'MISSION CONTROL' })).toBeVisible({ timeout: 8000 });
  const subtitle = page.locator('p.text-bmx-muted.text-sm.font-mono').first();
  await expect(subtitle).not.toHaveText('No workspace selected');
  await expect(page.locator('button').filter({ hasText: 'LAUNCH' })).toBeEnabled({ timeout: 5000 });
  const ws = await subtitle.textContent();
  console.log('  RESULT: MISSION CONTROL visible, workspace="' + ws?.trim() + '", LAUNCH enabled');
});

test('3. Settings Create Workspace', async ({ page }) => {
  await loginAndGoTo(page, '/settings');
  await page.waitForSelector('text=SETTINGS', { timeout: 8000 });
  const wsInput = page.locator('input[placeholder*="Workspace name"]');
  await expect(wsInput).toBeVisible({ timeout: 5000 });
  await wsInput.fill('PW Test ' + Date.now());
  const respP = page.waitForResponse(
    r => r.url().includes('/api/v1/workspaces') && r.request().method() === 'POST',
    { timeout: 15000 }
  );
  await page.locator('button').filter({ hasText: 'CREATE' }).first().click();
  const resp = await respP;
  const body = await resp.json().catch(() => ({}));
  expect(resp.status()).toBe(201);
  expect(body.id).toBeTruthy();
  await expect(page.locator('text=created and selected')).toBeVisible({ timeout: 5000 });
  console.log('  RESULT: POST /workspaces 201, id=' + body.id?.slice(0,8) + ' "' + body.name + '", success banner shown');
});

test('4. Dashboard LAUNCH creates scan', async ({ page }) => {
  await loginAndGoTo(page, '/dashboard');
  await page.fill('input[placeholder*="target.com"]', 'authorized-target.com');
  const launchBtn = page.locator('button').filter({ hasText: 'LAUNCH' });
  await expect(launchBtn, 'LAUNCH must be enabled').toBeEnabled({ timeout: 10000 });
  const respP = page.waitForResponse(
    r => r.url().includes('/api/v1/scans') && r.request().method() === 'POST',
    { timeout: 15000 }
  );
  await launchBtn.click();
  const resp = await respP;
  const body = await resp.json().catch(() => ({}));
  expect(resp.status()).toBe(201);
  expect(body.id).toBeTruthy();
  await expect(page.locator('text=Scan launched successfully')).toBeVisible({ timeout: 8000 });
  console.log('  RESULT: POST /scans 201, id=' + body.id?.slice(0,8) + ', "Scan launched successfully" shown');
});

test('5. No workspace warning when workspace active', async ({ page }) => {
  await loginAndGoTo(page, '/dashboard');
  await expect(page.locator('text=No workspace selected')).not.toBeVisible({ timeout: 5000 });
  const ws = await page.locator('p.text-bmx-muted.text-sm.font-mono').first().textContent();
  expect(ws).not.toContain('No workspace selected');
  console.log('  RESULT: No workspace warning absent. Active: "' + ws?.trim() + '"');
});

test('6. Demo Reset button', async ({ page }) => {
  await loginAndGoTo(page, '/demo');
  await page.waitForSelector('text=Demo Control Panel', { timeout: 8000 });
  const respP = page.waitForResponse(
    r => r.url().includes('/api/v1/demo/reset') && r.request().method() === 'POST',
    { timeout: 20000 }
  );
  await page.locator('button').filter({ hasText: 'Reset Demo' }).click();
  const resp = await respP;
  const body = await resp.json().catch(() => ({}));
  expect(resp.status()).toBe(200);
  console.log('  RESULT: POST /demo/reset 200: "' + body.message + '"');
});

test('7. Reports GENERATE button', async ({ page }) => {
  await loginAndGoTo(page, '/reports');
  await page.waitForSelector('text=GENERATE REPORT', { timeout: 8000 });
  await page.waitForFunction(
    () => document.querySelectorAll('select option').length > 1,
    { timeout: 15000 }
  );
  await page.locator('select').first().selectOption({ index: 1 });
  await page.waitForTimeout(300);
  const respP = page.waitForResponse(
    r => r.url().includes('/reports/generate') && r.request().method() === 'POST',
    { timeout: 20000 }
  );
  await page.locator('button').filter({ hasText: 'GENERATE' }).click();
  const resp = await respP;
  const body = await resp.json().catch(() => ({}));
  expect(resp.status()).toBeGreaterThanOrEqual(200);
  expect(resp.status()).toBeLessThan(300);
  console.log('  RESULT: POST /reports/generate ' + resp.status() + ', id=' + body.id?.slice(0,8));
});

test('8. Settings CREATE API KEY', async ({ page }) => {
  await loginAndGoTo(page, '/settings');
  await page.waitForSelector('text=SETTINGS', { timeout: 8000 });
  await page.locator('button').filter({ hasText: 'APIKEYS' }).click();
  await page.waitForTimeout(500);
  await page.locator('input[placeholder*="Key name"]').fill('playwright-' + Date.now());
  const respP = page.waitForResponse(
    r => r.url().includes('/api/v1/apikeys') && r.request().method() === 'POST',
    { timeout: 10000 }
  );
  await page.locator('button').filter({ hasText: 'CREATE' }).last().click();
  const resp = await respP;
  const body = await resp.json().catch(() => ({}));
  expect(resp.status()).toBe(201);
  expect(body.raw_key).toBeTruthy();
  expect(body.key_prefix.length).toBeLessThanOrEqual(10);
  await expect(page.locator('text=API KEY CREATED')).toBeVisible({ timeout: 5000 });
  console.log('  RESULT: POST /apikeys 201, prefix=' + body.key_prefix + ', raw_key shown');
});

test('9. Logout clears token', async ({ page }) => {
  await loginAndGoTo(page, '/dashboard');
  const before = await page.evaluate(() => localStorage.getItem('bmx_access_token'));
  expect(before).toBeTruthy();
  await page.evaluate(() => {
    const btns = [...document.querySelectorAll('aside button')];
    const lb = btns.find(b => b.innerHTML.includes('log-out'));
    if (lb) lb.click();
  });
  await page.waitForURL('**/auth/login', { timeout: 10000 });
  expect(page.url()).toContain('/auth/login');
  const after = await page.evaluate(() => localStorage.getItem('bmx_access_token'));
  expect(after).toBeNull();
  console.log('  RESULT: Token cleared, redirected to /auth/login');
});
