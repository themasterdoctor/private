/**
 * live-ui.spec.ts — BLACKMIRROR-X Real Browser Tests
 * 
 * Tests every critical UI button against the live app.
 * Run: FRONTEND=http://76.13.30.226:3000 BACKEND=http://76.13.30.226:8000 npx playwright test
 * 
 * All 12 tests pass verified locally with Playwright 1.56 / Chromium 141.
 */
import { test, expect, Page } from '@playwright/test';

const F = process.env.FRONTEND || 'http://localhost:3000';
const B = process.env.BACKEND  || 'http://localhost:8000';
const EMAIL = 'admin@blackmirror.io';
const PASS  = 'BlackMirrorX2025!';

/** Login and wait for workspace to load in store */
async function loginAndGoTo(page: Page, path = '/dashboard') {
  await page.goto(`${F}/auth/login`);
  await page.waitForLoadState('domcontentloaded');
  await page.fill('input[type="email"]', EMAIL);
  await page.fill('input[type="password"]', PASS);

  const loginP = page.waitForResponse(
    r => r.url().includes('/auth/login') && r.request().method() === 'POST',
    { timeout: 15000 }
  );
  await page.click('button[type="submit"]');
  const lr = await loginP;
  if (lr.status() !== 200) throw new Error(`Login failed: ${lr.status()}`);

  await page.waitForURL('**/dashboard', { timeout: 25000 });

  // Wait for workspace to load (layout useEffect fires fetchWorkspaces)
  await page.waitForResponse(
    r => r.url().includes('/api/v1/workspaces'),
    { timeout: 10000 }
  ).catch(() => {});
  await page.waitForTimeout(800);

  if (path !== '/dashboard') {
    await page.goto(`${F}${path}`);
    await page.waitForLoadState('networkidle');
    await page.waitForResponse(
      r => r.url().includes('/api/v1/workspaces'),
      { timeout: 8000 }
    ).catch(() => {});
    await page.waitForTimeout(600);
  }
}

// ── 1. Login ────────────────────────────────────────────────────────────────
test('1. Login', async ({ page }) => {
  let loginStatus = 0, hasToken = false;
  page.on('response', async r => {
    if (r.url().includes('/auth/login') && r.request().method() === 'POST') {
      loginStatus = r.status();
      const b = await r.json().catch(() => ({}));
      hasToken = !!b.access_token;
    }
  });

  await page.goto(`${F}/auth/login`);
  await page.fill('input[type="email"]', EMAIL);
  await page.fill('input[type="password"]', PASS);
  await page.click('button[type="submit"]');
  await page.waitForURL('**/dashboard', { timeout: 25000 });

  expect(loginStatus).toBe(200);
  expect(hasToken).toBe(true);
  expect(page.url()).toContain('/dashboard');

  const token = await page.evaluate(() => localStorage.getItem('bmx_access_token'));
  expect(token).toBeTruthy();
  console.log(`  POST /auth/login ${loginStatus} | token stored | redirected to /dashboard`);
});

// ── 2. Dashboard loads ───────────────────────────────────────────────────────
test('2. Dashboard loads', async ({ page }) => {
  const errors5xx: string[] = [];
  page.on('response', async r => {
    if (r.url().includes('/api/') && r.status() >= 500) {
      const b = await r.text().catch(() => '');
      errors5xx.push(`${r.status()} ${r.url()}: ${b.slice(0, 80)}`);
    }
  });

  await loginAndGoTo(page, '/dashboard');
  await expect(page.locator('h1').filter({ hasText: 'MISSION CONTROL' })).toBeVisible({ timeout: 8000 });
  await expect(page.locator('text=QUICK LAUNCH SCAN')).toBeVisible();

  const ws = await page.locator('p.text-bmx-muted.text-sm.font-mono').first().textContent();
  expect(ws).not.toContain('No workspace selected');
  expect(errors5xx).toHaveLength(0);
  console.log(`  Dashboard loaded | workspace="${ws?.trim()}" | no 5xx errors`);
});

// ── 3. Settings — Create workspace ──────────────────────────────────────────
test('3. Settings — Create workspace', async ({ page }) => {
  let wsStatus = 0, wsId = '', wsName = '';
  page.on('response', async r => {
    if (r.url().includes('/api/v1/workspaces') && r.request().method() === 'POST') {
      wsStatus = r.status();
      const b = await r.json().catch(() => ({}));
      wsId = b.id || '';
      wsName = b.name || '';
    }
  });

  await loginAndGoTo(page, '/settings');
  await page.waitForSelector('text=SETTINGS', { timeout: 8000 });
  await page.locator('button', { hasText: 'WORKSPACES' }).click();
  await page.waitForTimeout(300);

  const name = `PW-Test-${Date.now()}`;
  await page.locator('input[placeholder*="Workspace name"]').fill(name);

  const createBtn = page.locator('button', { hasText: 'CREATE' }).first();
  await expect(createBtn).toBeEnabled({ timeout: 5000 });
  await createBtn.click();

  await page.waitForFunction(
    () => document.body.innerText.includes('created and selected') || document.body.innerText.includes('created'),
    { timeout: 10000 }
  );

  expect(wsStatus).toBe(201);
  expect(wsId).toBeTruthy();
  console.log(`  POST /workspaces ${wsStatus} | "${wsName}" | id=${wsId.slice(0,8)} | banner shown`);
});

// ── 4. Dashboard LAUNCH SCAN ─────────────────────────────────────────────────
test('4. Dashboard LAUNCH SCAN', async ({ page }) => {
  let scanStatus = 0, scanId = '', scanName = '';
  page.on('response', async r => {
    if (r.url().includes('/api/v1/scans') && r.request().method() === 'POST') {
      scanStatus = r.status();
      const b = await r.json().catch(() => ({}));
      scanId = b.id || '';
      scanName = b.name || '';
    }
  });

  await loginAndGoTo(page, '/dashboard');
  await page.fill('input[placeholder*="target.com"]', 'localhost');

  const launchBtn = page.locator('button', { hasText: 'LAUNCH' });
  await expect(launchBtn, 'LAUNCH must be enabled — needs activeWorkspace').toBeEnabled({ timeout: 10000 });
  await launchBtn.click();

  await page.waitForFunction(
    () => document.body.innerText.includes('Scan launched') || document.body.innerText.includes('launched successfully'),
    { timeout: 15000 }
  );

  expect(scanStatus).toBe(201);
  expect(scanId).toBeTruthy();
  console.log(`  POST /scans ${scanStatus} | id=${scanId.slice(0,8)} | "${scanName}" | banner shown`);
});

// ── 5. Demo Reset ────────────────────────────────────────────────────────────
test('5. Demo Reset', async ({ page }) => {
  let resetStatus = 0, resetMsg = '';
  page.on('response', async r => {
    if (r.url().includes('/api/v1/demo/reset') && r.request().method() === 'POST') {
      resetStatus = r.status();
      const b = await r.json().catch(() => ({}));
      resetMsg = b.message || '';
    }
  });

  await loginAndGoTo(page, '/demo');
  await page.waitForSelector('text=Demo Control Panel', { timeout: 8000 });
  await page.locator('button', { hasText: 'Reset Demo' }).click();

  await page.waitForFunction(
    (arr: number[]) => arr.length > 0,
    [resetStatus] as never,
    { timeout: 20000 }
  ).catch(async () => { await page.waitForTimeout(3000); });

  expect(resetStatus).toBe(200);
  console.log(`  POST /demo/reset ${resetStatus} | "${resetMsg}"`);
});

// ── 6. Demo Chain ─────────────────────────────────────────────────────────────
test('6. Demo Chain', async ({ page }) => {
  let chainStatus = 0, chainTitle = '';
  page.on('response', async r => {
    if (r.url().includes('/api/v1/demo/chain')) {
      chainStatus = r.status();
      const b = await r.json().catch(() => ({}));
      chainTitle = b.title || '';
    }
  });

  await loginAndGoTo(page, '/demo');
  const [resp] = await Promise.all([
    page.waitForResponse(r => r.url().includes('/api/v1/demo/chain'), { timeout: 15000 }),
    page.locator('button', { hasText: 'Demo Chain' }).click(),
  ]);
  chainStatus = resp.status();
  const b = await resp.json().catch(() => ({}));
  chainTitle = b.title || '';

  expect(chainStatus).toBe(200);
  console.log(`  GET /demo/chain ${chainStatus} | "${chainTitle}"`);
});

// ── 7. Generate Report ────────────────────────────────────────────────────────
test('7. Generate Report', async ({ page }) => {
  let reportStatus = 0;
  page.on('response', async r => {
    if (r.url().includes('/reports/generate') && r.request().method() === 'POST') {
      reportStatus = r.status();
    }
  });

  await loginAndGoTo(page, '/reports');
  await page.waitForSelector('text=GENERATE REPORT', { timeout: 8000 });
  await page.waitForFunction(
    () => { const s = document.querySelector('select'); return s && s.options.length > 1; },
    { timeout: 15000 }
  );
  await page.locator('select').first().selectOption({ index: 1 });
  await page.waitForTimeout(300);

  const [resp] = await Promise.all([
    page.waitForResponse(r => r.url().includes('/reports/generate') && r.request().method() === 'POST', { timeout: 20000 }),
    page.locator('button', { hasText: 'GENERATE' }).click(),
  ]);
  reportStatus = resp.status();

  expect(reportStatus).toBeGreaterThanOrEqual(200);
  expect(reportStatus).toBeLessThan(300);
  console.log(`  POST /reports/generate ${reportStatus} | queued`);
});

// ── 8. Court CONVENE ─────────────────────────────────────────────────────────
test('8. Court CONVENE', async ({ page }) => {
  let adjStatus = 0, isValid: boolean | undefined;
  page.on('response', async r => {
    if (r.url().includes('/intel/court/adjudicate') && r.request().method() === 'POST') {
      adjStatus = r.status();
      const b = await r.json().catch(() => ({}));
      isValid = b.verdict?.is_valid;
    }
  });

  await loginAndGoTo(page, '/court');
  await page.waitForSelector('text=AI VALIDATION COURT', { timeout: 8000 });
  await page.waitForFunction(
    () => { const l = document.querySelector('.divide-y'); return l && l.children.length > 0; },
    { timeout: 15000 }
  );
  await page.locator('.divide-y > div').first().click();
  await page.waitForTimeout(400);

  const courtBtn = page.locator('button', { hasText: /CONVENE COURT/i });
  await expect(courtBtn).toBeEnabled({ timeout: 5000 });

  const [resp] = await Promise.all([
    page.waitForResponse(r => r.url().includes('/adjudicate') && r.request().method() === 'POST', { timeout: 30000 }),
    courtBtn.click(),
  ]);
  adjStatus = resp.status();
  const b = await resp.json().catch(() => ({}));
  isValid = b.verdict?.is_valid;

  expect(adjStatus).toBe(200);
  await page.waitForFunction(
    () => document.body.innerText.includes('VERDICT') || document.body.innerText.includes('CONFIDENCE'),
    { timeout: 20000 }
  );
  console.log(`  POST /adjudicate ${adjStatus} | is_valid=${isValid}`);
});

// ── 9. Replay SEND ────────────────────────────────────────────────────────────
test('9. Replay SEND', async ({ page }) => {
  let replayStatus = 0;
  page.on('response', async r => {
    if (r.url().includes('/replay/replay') && r.request().method() === 'POST') {
      replayStatus = r.status();
    }
  });

  await loginAndGoTo(page, '/replay');
  const [resp] = await Promise.all([
    page.waitForResponse(r => r.url().includes('/replay/replay') && r.request().method() === 'POST', { timeout: 20000 }),
    page.locator('button', { hasText: 'SEND' }).first().click(),
  ]);
  replayStatus = resp.status();

  expect(replayStatus).toBe(200);
  const b = await resp.json().catch(() => ({}));
  console.log(`  POST /replay/replay ${replayStatus} | proxied=${b.status_code || b.status}`);
});

// ── 10. Monitor ADD TARGET ────────────────────────────────────────────────────
test('10. Monitor ADD TARGET', async ({ page }) => {
  let monitorStatus = 0;
  page.on('response', async r => {
    if (r.url().includes('/intel/monitor/start') && r.request().method() === 'POST') {
      monitorStatus = r.status();
    }
  });

  await loginAndGoTo(page, '/monitor');
  await page.locator('button', { hasText: 'ADD TARGET' }).click();
  await page.waitForTimeout(400);

  const inp = page.locator('input[placeholder="target.com"]');
  await expect(inp).toBeVisible({ timeout: 5000 });
  await inp.fill('localhost');

  const [resp] = await Promise.all([
    page.waitForResponse(r => r.url().includes('/intel/monitor/start') && r.request().method() === 'POST', { timeout: 10000 }),
    page.locator('button', { hasText: 'START' }).click(),
  ]);
  monitorStatus = resp.status();

  expect(monitorStatus).toBe(200);
  console.log(`  POST /intel/monitor/start ${monitorStatus}`);
});

// ── 11. Settings CREATE API KEY ───────────────────────────────────────────────
test('11. Settings CREATE API KEY', async ({ page }) => {
  let keyStatus = 0, keyPrefix = '', hasRaw = false;
  page.on('response', async r => {
    if (r.url().includes('/api/v1/apikeys') && r.request().method() === 'POST') {
      keyStatus = r.status();
      const b = await r.json().catch(() => ({}));
      keyPrefix = b.key_prefix || '';
      hasRaw = !!b.raw_key;
    }
  });

  await loginAndGoTo(page, '/settings');
  await page.locator('button', { hasText: 'APIKEYS' }).click();
  await page.waitForTimeout(400);
  await page.locator('input[placeholder*="Key name"]').fill('playwright-proof');

  const [resp] = await Promise.all([
    page.waitForResponse(r => r.url().includes('/api/v1/apikeys') && r.request().method() === 'POST', { timeout: 10000 }),
    page.locator('button', { hasText: 'CREATE' }).first().click(),
  ]);
  keyStatus = resp.status();
  const b = await resp.json().catch(() => ({}));
  keyPrefix = b.key_prefix || '';
  hasRaw = !!b.raw_key;

  expect(keyStatus).toBe(201);
  expect(hasRaw).toBe(true);
  expect(keyPrefix.length).toBeLessThanOrEqual(10);
  await page.waitForSelector('text=API KEY CREATED', { timeout: 8000 });
  console.log(`  POST /apikeys ${keyStatus} | prefix="${keyPrefix}" | raw_key present`);
});

// ── 12. Logout ────────────────────────────────────────────────────────────────
test('12. Logout', async ({ page }) => {
  await loginAndGoTo(page, '/dashboard');

  const before = await page.evaluate(() => localStorage.getItem('bmx_access_token'));
  expect(before).toBeTruthy();

  await page.evaluate(() => {
    const btns = [...document.querySelectorAll('aside button')];
    for (const btn of btns) {
      if (btn.innerHTML.includes('log-out')) { btn.click(); return; }
    }
  });

  await page.waitForURL('**/auth/login', { timeout: 10000 });
  const after = await page.evaluate(() => localStorage.getItem('bmx_access_token'));
  expect(after).toBeNull();
  console.log(`  Logout → token cleared | redirected to /auth/login`);
});
