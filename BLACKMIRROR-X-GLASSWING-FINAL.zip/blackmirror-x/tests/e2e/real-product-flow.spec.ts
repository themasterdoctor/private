/**
 * real-product-flow.spec.ts
 * Playwright E2E: clicks real browser UI to verify the full product flow.
 * Run: npx playwright test tests/e2e/real-product-flow.spec.ts
 */
import { test, expect, Page } from "@playwright/test";

const BASE_URL = process.env.BASE_URL || "http://76.13.30.226:3000";
const API_URL = process.env.API_URL || "http://76.13.30.226:8000";
const EMAIL = "admin@blackmirror.io";
const PASSWORD = "BlackMirrorX2025!";

test.describe("BLACKMIRROR-X Full Product Flow", () => {
  let page: Page;
  let workspaceId: string;
  let scanId: string;

  test.beforeAll(async ({ browser }) => {
    page = await browser.newPage();
    // Monitor console errors
    page.on("console", msg => {
      if (msg.type() === "error") {
        console.log(`[Browser Error] ${msg.text()}`);
      }
    });
    // Monitor network failures
    page.on("response", resp => {
      if (resp.status() >= 500) {
        console.log(`[API Error] ${resp.status()} ${resp.url()}`);
      }
    });
  });

  test.afterAll(async () => {
    await page.close();
  });

  test("1. Backend health check", async () => {
    const resp = await page.request.get(`${API_URL}/health`);
    expect(resp.ok()).toBeTruthy();
    const body = await resp.json();
    expect(body.status).toBe("healthy");
    expect(body.version).toBeDefined();
  });

  test("2. Login page loads", async () => {
    await page.goto(`${BASE_URL}/auth/login`);
    await expect(page.locator("input[type=email], input[name=email]")).toBeVisible({ timeout: 10000 });
    await expect(page).toHaveTitle(/BLACKMIRROR|login|auth/i);
  });

  test("3. Login with valid credentials", async () => {
    await page.goto(`${BASE_URL}/auth/login`);
    await page.locator("input[type=email], input[name=email]").fill(EMAIL);
    await page.locator("input[type=password]").fill(PASSWORD);
    await page.locator("button[type=submit], button:has-text('Login'), button:has-text('Sign in')").click();
    // Should redirect to dashboard
    await expect(page).toHaveURL(/dashboard/, { timeout: 15000 });
    console.log("✓ Login successful, redirected to dashboard");
  });

  test("4. Dashboard loads with real data", async () => {
    await page.goto(`${BASE_URL}/dashboard`);
    await page.waitForLoadState("networkidle", { timeout: 15000 });
    // No CORS errors
    const errors = await page.evaluate(() =>
      window.__console_errors || []
    );
    // Dashboard should have key UI elements
    const body = await page.content();
    expect(body).toContain("BLACKMIRROR");
    console.log("✓ Dashboard loaded");
  });

  test("5. Create workspace via API", async () => {
    // Login via API to get token
    const loginResp = await page.request.post(`${API_URL}/api/v1/auth/login`, {
      form: { username: EMAIL, password: PASSWORD },
    });
    const loginData = await loginResp.json();
    const token = loginData.access_token;
    expect(token).toBeTruthy();

    // Create workspace
    const wsResp = await page.request.post(`${API_URL}/api/v1/workspaces`, {
      headers: { Authorization: `Bearer ${token}` },
      data: { name: `E2E-${Date.now()}`, description: "Playwright test workspace" },
    });
    if (wsResp.status() === 201 || wsResp.status() === 200) {
      const ws = await wsResp.json();
      workspaceId = ws.id;
      console.log(`✓ Workspace created: ${workspaceId}`);
    } else {
      // Get existing workspace
      const listResp = await page.request.get(`${API_URL}/api/v1/workspaces`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const workspaces = await listResp.json();
      expect(workspaces.length).toBeGreaterThan(0);
      workspaceId = workspaces[0].id;
      console.log(`✓ Using existing workspace: ${workspaceId}`);
    }
    expect(workspaceId).toBeTruthy();
  });

  test("6. Launch scan via API", async () => {
    const loginResp = await page.request.post(`${API_URL}/api/v1/auth/login`, {
      form: { username: EMAIL, password: PASSWORD },
    });
    const { access_token: token } = await loginResp.json();

    const scanResp = await page.request.post(`${API_URL}/api/v1/scans`, {
      headers: { Authorization: `Bearer ${token}` },
      data: {
        name: `e2e-scan-${Date.now()}`,
        workspace_id: workspaceId,
        scan_type: "recon",
        target: "https://testphp.vulnweb.com",
        config: { domain: "testphp.vulnweb.com", nuclei: false },
      },
    });

    expect([200, 201]).toContain(scanResp.status());
    const scan = await scanResp.json();
    scanId = scan.id;
    expect(scanId).toBeTruthy();
    console.log(`✓ Scan launched: ${scanId}`);
  });

  test("7. Scan detail page loads with live logs", async () => {
    await page.goto(`${BASE_URL}/scans/${scanId}`);
    await page.waitForLoadState("networkidle", { timeout: 10000 });

    // Should show scan status
    const body = await page.content();
    const hasContent = body.includes("SCANNING") || body.includes("QUEUED") ||
                       body.includes("COMPLETE") || body.includes("recon");
    expect(hasContent).toBeTruthy();
    console.log("✓ Scan detail page loaded");
  });

  test("8. Findings page loads", async () => {
    await page.goto(`${BASE_URL}/vulns`);
    await page.waitForLoadState("networkidle", { timeout: 10000 });
    // Page should load (even if 0 findings)
    const body = await page.content();
    expect(body).toContain("FINDINGS");
    console.log("✓ Findings page loaded");
  });

  test("9. Reports page loads", async () => {
    await page.goto(`${BASE_URL}/reports`);
    await page.waitForLoadState("networkidle", { timeout: 10000 });
    const body = await page.content();
    expect(body).toContain("report");
    console.log("✓ Reports page loaded");
  });

  test("10. No CORS/API errors on dashboard", async () => {
    const apiErrors: string[] = [];
    page.on("response", resp => {
      if (resp.url().includes(API_URL) && resp.status() >= 400) {
        apiErrors.push(`${resp.status()} ${resp.url()}`);
      }
    });

    await page.goto(`${BASE_URL}/dashboard`);
    await page.waitForLoadState("networkidle", { timeout: 15000 });

    // Filter out expected 401s (unauthenticated requests)
    const realErrors = apiErrors.filter(e => !e.startsWith("401"));
    console.log(`API errors (excluding 401): ${realErrors.length}`);
    if (realErrors.length > 0) {
      console.log("Errors:", realErrors);
    }
    // Allow some errors but not 5xx
    const serverErrors = apiErrors.filter(e => /^5\d\d/.test(e));
    expect(serverErrors.length).toBe(0);
    console.log("✓ No 5xx errors on dashboard");
  });
});
