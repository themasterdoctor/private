#!/usr/bin/env bash
# install_local.sh — BLACKMIRROR-X local installation script
# Usage: bash scripts/install_local.sh
# Installs, configures, and seeds BLACKMIRROR-X on a local machine.
set -uo pipefail

PASS=0; FAIL=0; WARN=0
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
RED='\033[0;31m'; WHITE='\033[1;37m'; NC='\033[0m'

ok()   { echo -e "  ${GREEN}✓${NC}  $1"; PASS=$((PASS+1)); }
fail() { echo -e "  ${RED}✗${NC}  $1"; FAIL=$((FAIL+1)); }
warn() { echo -e "  ${YELLOW}⚠${NC}  $1"; WARN=$((WARN+1)); }
info() { echo -e "  ${CYAN}→${NC}  $1"; }

echo ""
echo -e "${WHITE}════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}  BLACKMIRROR-X GLASSWING — Local Install${NC}"
echo -e "${WHITE}════════════════════════════════════════════════════════════${NC}"
echo ""

# ── 1. Preflight checks ───────────────────────────────────────────────────────
echo "── 1. Preflight Checks ──────────────────────────────────────"

command -v docker &>/dev/null     && ok "Docker: $(docker --version | head -1)" \
                                  || { fail "Docker not found — install from https://docs.docker.com/get-docker/"; FAIL=$((FAIL+1)); }
command -v docker-compose &>/dev/null || command -v "docker compose" &>/dev/null \
  && ok "Docker Compose: available" || warn "docker-compose not found (may use 'docker compose' syntax)"

command -v node &>/dev/null       && ok "Node.js: $(node --version)" \
                                  || fail "Node.js not found — install v18+ from https://nodejs.org"
command -v python3 &>/dev/null    && ok "Python: $(python3 --version)" \
                                  || fail "Python 3 not found"
command -v git &>/dev/null        && ok "Git: $(git --version)" \
                                  || warn "Git not found"

[ $FAIL -gt 0 ] && { echo ""; echo -e "${RED}  ✗ Preflight failed — fix the above before continuing${NC}"; echo ""; exit 1; }

# ── 2. Environment setup ──────────────────────────────────────────────────────
echo ""
echo "── 2. Environment Setup ─────────────────────────────────────"

if [ ! -f "$ROOT/.env" ]; then
  cp "$ROOT/.env.example" "$ROOT/.env"
  ok "Copied .env.example → .env"
else
  ok ".env already exists (skipping copy)"
fi

# Generate fresh secrets
SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))" 2>/dev/null || openssl rand -hex 32)
JWT_SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))" 2>/dev/null || openssl rand -hex 32)

python3 << PYEOF
import re
with open("$ROOT/.env") as f: content = f.read()
content = re.sub(r'SECRET_KEY=.*', f'SECRET_KEY={SECRET_PLACEHOLDER}', content)
content = re.sub(r'JWT_SECRET_KEY=.*', f'JWT_SECRET_KEY={JWT_PLACEHOLDER}', content)
with open("$ROOT/.env", "w") as f: f.write(content)
print("✓ Fresh secrets generated")
PYEOF
# Use sed for reliability across platforms
sed -i "s|^SECRET_KEY=.*|SECRET_KEY=${SECRET}|" "$ROOT/.env"
sed -i "s|^JWT_SECRET_KEY=.*|JWT_SECRET_KEY=${JWT_SECRET}|" "$ROOT/.env"
ok "Secrets generated and written to .env"

# ── 3. Docker build ────────────────────────────────────────────────────────────
echo ""
echo "── 3. Docker Build ──────────────────────────────────────────"
cd "$ROOT"

if command -v docker-compose &>/dev/null; then
  COMPOSE="docker-compose"
else
  COMPOSE="docker compose"
fi

info "Building containers (this may take 2-3 min on first run)..."
$COMPOSE build --quiet 2>&1 | tail -3
[ ${PIPESTATUS[0]} -eq 0 ] && ok "Docker containers built" || { fail "Docker build failed"; exit 1; }

info "Starting services..."
$COMPOSE up -d postgres redis 2>&1 | tail -2
sleep 5
ok "PostgreSQL and Redis started"

# ── 4. Database setup ──────────────────────────────────────────────────────────
echo ""
echo "── 4. Database Setup ────────────────────────────────────────"

info "Running migrations..."
$COMPOSE exec -T backend alembic upgrade head 2>&1 | tail -3
[ ${PIPESTATUS[0]} -eq 0 ] && ok "Database migrations applied" || { fail "Migration failed"; }

info "Seeding demo data..."
$COMPOSE exec -T backend python scripts/seed.py 2>&1
ok "Demo data seeded"

# ── 5. Optional: Security tools ───────────────────────────────────────────────
echo ""
echo "── 5. Optional Security Tools ───────────────────────────────"

for tool in subfinder httpx nuclei amass katana; do
  command -v "$tool" &>/dev/null \
    && ok "$tool detected at $(command -v $tool)" \
    || warn "$tool not found (scans will use passive-only mode without it)"
done

info "Install security tools: go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
info "Or: bash scripts/setup.sh (installs all security tools)"

# ── 6. Start all services ──────────────────────────────────────────────────────
echo ""
echo "── 6. Starting All Services ─────────────────────────────────"
$COMPOSE up -d 2>&1 | tail -3
sleep 8

# Health check
HEALTH=$(curl -s -m 5 http://localhost:8000/health 2>/dev/null || echo "")
echo "$HEALTH" | grep -q "healthy" \
  && ok "Backend API: http://localhost:8000" \
  || warn "Backend may still be starting (check: docker-compose logs backend)"
ok "Frontend: http://localhost:3000"
ok "API Docs: http://localhost:8000/api/docs"

# ── Summary ────────────────────────────────────────────────────────────────────
echo ""
echo -e "${WHITE}════════════════════════════════════════════════════════════${NC}"
echo -e "  ${GREEN}✅ BLACKMIRROR-X installed successfully${NC}"
echo ""
echo -e "  ${CYAN}Dashboard:${NC}   http://localhost:3000"
echo -e "  ${CYAN}API:${NC}         http://localhost:8000/api/docs"
echo -e "  ${CYAN}Grafana:${NC}     http://localhost:3001"
echo ""
echo -e "  ${WHITE}Login credentials:${NC}"
echo -e "  ${CYAN}Email:${NC}    admin@blackmirror.io"
echo -e "  ${CYAN}Password:${NC} BlackMirrorX2025!"
echo ""
echo -e "  Run demo: ${YELLOW}bash scripts/demo_run.sh${NC}"
echo -e "${WHITE}════════════════════════════════════════════════════════════${NC}"
echo ""
