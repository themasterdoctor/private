const http = require('http');
const https = require('https');
const PORT = 3001;

const log = (msg, color='') => {
  const colors = {red:'\x1b[31m',green:'\x1b[32m',yellow:'\x1b[33m',cyan:'\x1b[36m',reset:'\x1b[0m',bold:'\x1b[1m'};
  console.log(`${colors[color]||''}${msg}${colors.reset}`);
};

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin','*');
  res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers','Content-Type,x-api-key,Authorization');
  if(req.method==='OPTIONS'){res.writeHead(204);res.end();return;}

  if(req.method==='GET'&&req.url==='/health'){
    res.writeHead(200,{'Content-Type':'application/json'});
    res.end(JSON.stringify({status:'ok',server:'SecureNet Elite Proxy',port:PORT,ts:Date.now()}));
    return;
  }

  if(req.method==='POST'&&req.url==='/api/chat'){
    let body='';
    req.on('data',c=>body+=c.toString());
    req.on('end',()=>{
      let parsed;
      try{parsed=JSON.parse(body);}
      catch{res.writeHead(400,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'Invalid JSON'}));return;}
      const {apiKey,...anthropicBody}=parsed;
      if(!apiKey){res.writeHead(401,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'No API key'}));return;}
      const bodyStr=JSON.stringify(anthropicBody);
      const options={
        hostname:'api.anthropic.com',path:'/v1/messages',method:'POST',
        headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(bodyStr),'x-api-key':apiKey,'anthropic-version':'2023-06-01'},
      };
      log(`  → AI request: ${anthropicBody.messages?.[anthropicBody.messages.length-1]?.content?.slice(0,60)}...`,'cyan');
      const proxyReq=https.request(options,(proxyRes)=>{
        let rb='';
        proxyRes.on('data',c=>rb+=c);
        proxyRes.on('end',()=>{
          log(`  ← Response: ${proxyRes.statusCode}`,'green');
          res.writeHead(proxyRes.statusCode,{'Content-Type':'application/json'});
          res.end(rb);
        });
      });
      proxyReq.on('error',err=>{
        log(`  ✗ Upstream error: ${err.message}`,'red');
        res.writeHead(502,{'Content-Type':'application/json'});
        res.end(JSON.stringify({error:'Upstream error: '+err.message}));
      });
      proxyReq.write(bodyStr);proxyReq.end();
    });
    return;
  }

  res.writeHead(404,{'Content-Type':'application/json'});
  res.end(JSON.stringify({error:'Not found'}));
});

server.listen(PORT,()=>{
  console.log('');
  log('  ╔════════════════════════════════════════╗','bold');
  log('  ║   SecureNet Elite — AI Proxy Server   ║','bold');
  log(`  ║   http://localhost:${PORT}              ║`,'bold');
  log('  ╚════════════════════════════════════════╝','bold');
  console.log('');
  log('  ✓ Health:  GET  /health','green');
  log('  ✓ AI Chat: POST /api/chat','green');
  console.log('');
  log('  Ready. Start the React app in another terminal:','yellow');
  log('  cd .. && npm install && npm start','cyan');
  console.log('');
});
server.on('error',err=>{
  if(err.code==='EADDRINUSE'){log(`\n  ✗ Port ${PORT} in use. Run: lsof -ti:${PORT} | xargs kill\n`,'red');}
  else log('\n  ✗ '+err.message,'red');
  process.exit(1);
});
