# SecureNet Elite — Setup & Startup

## Every time you start the app — 3 steps

### Step 1: Terminal 1 — Start the proxy (REQUIRED for AI)
```bash
cd securenet_elite/server
node proxy.js
```
Keep this terminal open. You'll see: "SecureNet Elite — AI Proxy Server · Running on http://localhost:3001"

### Step 2: Terminal 2 — First time only (install dependencies)
```bash
cd securenet_elite
npm install
```
This takes 2-3 minutes. Only needed once.

### Step 3: Terminal 2 — Start the app
```bash
npm start
```
Opens at http://localhost:3000

### Step 4: Set your API key
- Click "Settings" in the sidebar
- Paste your Anthropic API key (get one at console.anthropic.com → API Keys)
- Save — AI is now live

---

## What's in SecureNet Elite

### Mission Control (Dashboard)
- Live severity distribution bar chart
- Scope coverage donut chart  
- Findings by area horizontal bar chart
- Activity timeline with all events
- Phase progress bars
- Critical finding alert banner

### Elite AI Assistant
- Full engagement context (all findings, targets, scope)
- 10 pre-built power prompts (MITRE mapping, escalation messages, attack chains, compliance analysis)
- Persistent chat history
- CVSS vector generation, client narratives, compliance impact

### Findings Register
- Full CRUD — add, edit, escalate, delete
- 4-tab detail view: Detail | Evidence | MITRE ATT&CK | Remediation
- CVSS vector display per finding
- MITRE ATT&CK mappings pre-loaded for all 7 current findings
- Search + filter by severity/area/status
- Sort by CVSS/severity/ID
- Live note editing
- Remediation owner + due date tracking

### Recon & Targets
- Add domains, subdomains, IPs, CIDR ranges, URLs, AWS regions
- In-scope / out-of-scope toggle
- Feeds directly into AI context
- Summary counts by type

### Reports & Deliverables
- One-click PDF: Executive Summary
- One-click PDF: Technical Findings Report (with CVSS vectors, MITRE, evidence, PoC)
- One-click PDF: Remediation Roadmap
- One-click PDF: Compliance Impact Report
- 11 deliverables status tracker

### Scope Tracker
- All 27 Security Scan Update items
- Inline status dropdowns
- Per-item notes + assignee
- Filter by area and status

### Investigation Notes
- Tagged notes (aws/dns/web/critical/client/follow-up/evidence)
- Link notes to specific findings
- Persistent across sessions

### Settings
- Live proxy status with instructions
- API key management
- Engagement detail editing
- Full data export/import (JSON)
- Reset to defaults

---

## Project structure
```
securenet_elite/
├── src/
│   ├── App.jsx      Full app — all views, charts, AI, reports (1179 lines)
│   ├── data.js      Engagement data, CVSS vectors, MITRE mappings
│   ├── store.js     Persistence layer — localStorage state
│   ├── pdf.js       Elite PDF report generator
│   └── index.js     Entry point
├── server/
│   └── proxy.js     AI proxy server (no npm install needed)
├── public/
│   └── index.html
└── package.json
```

---
Built for Christian — Independent Security Consultant
christian@themasterdoctor1.com | (347) 413-4257
