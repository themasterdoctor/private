import { CVSS_VECTORS, MITRE_MAP } from './data';

export async function downloadEliteReports(eng, findings, scopeItems, type = 'executive') {
  const { default: jsPDF } = await import('jspdf');
  const { default: autoTable } = await import('jspdf-autotable');

  const doc = new jsPDF({ unit:'mm', format:'a4' });
  const W=210, M=15, CW=W-M*2;
  let y=0;

  const navy=[20,28,40], blue=[0,150,190], darkBlue=[10,20,35];
  const red=[200,40,40], amber=[200,130,0], green=[16,120,80], gray=[80,90,100], lgray=[220,225,230];
  const white=[255,255,255], black=[15,20,28];
  const sevColor={critical:red,high:amber,medium:[0,150,190],low:green,info:gray};

  const nb = () => { doc.addPage(); y=20; footer(); };
  const ck = (n=20) => { if(y+n>270) nb(); };
  const footer = () => {
    doc.setFontSize(7.5); doc.setTextColor(...gray);
    doc.text(`CONFIDENTIAL — ${eng?.client} Security Assessment — SecureNet Elite`,M,290);
    doc.text(`Page ${doc.internal.getNumberOfPages()}`,W-M,290,{align:'right'});
    doc.setDrawColor(...lgray); doc.line(M,285,W-M,285);
  };

  const h1 = (t) => { ck(14); doc.setFillColor(...navy); doc.rect(M,y,CW,9,'F'); doc.setFontSize(11); doc.setFont('helvetica','bold'); doc.setTextColor(...white); doc.text(t,M+4,y+6.2); y+=13; };
  const h2 = (t,col=blue) => { ck(12); doc.setFontSize(10); doc.setFont('helvetica','bold'); doc.setTextColor(...col); doc.text(t,M,y); doc.setDrawColor(...col); doc.line(M,y+2,M+CW,y+2); y+=8; };
  const body = (t,indent=0) => { ck(8); doc.setFontSize(9); doc.setFont('helvetica','normal'); doc.setTextColor(...black); const lines=doc.splitTextToSize(t,CW-indent); doc.text(lines,M+indent,y); y+=lines.length*4.8+2; };
  const bullet = (t,col=black) => { ck(7); doc.setFontSize(8.5); doc.setFont('helvetica','normal'); doc.setTextColor(...col); const lines=doc.splitTextToSize(t,CW-8); doc.text('•',M,y); doc.text(lines,M+5,y); y+=lines.length*4.5+1.5; };
  const sp = (n=6) => { y+=n; };
  const lv = (l,v,col=gray) => { ck(6); doc.setFontSize(8.5); doc.setFont('helvetica','bold'); doc.setTextColor(...col); doc.text(l+':',M,y); doc.setFont('helvetica','normal'); doc.setTextColor(...black); doc.text(String(v||''),M+38,y); y+=5.5; };

  // ── COVER ────────────────────────────────────────────────────────────────────
  doc.setFillColor(...darkBlue); doc.rect(0,0,W,90,'F');
  doc.setFillColor(...blue); doc.rect(0,88,W,2,'F');
  doc.setFontSize(9); doc.setFont('helvetica','normal'); doc.setTextColor(0,180,220);
  doc.text('SECURENET ELITE — SECURITY ASSESSMENT PLATFORM',M,22);
  doc.setFontSize(26); doc.setFont('helvetica','bold'); doc.setTextColor(...white);
  doc.text(type==='executive'?'Executive Summary':type==='technical'?'Technical Findings':type==='remediation'?'Remediation Roadmap':'Compliance Impact',M,40);
  doc.setFontSize(13); doc.setFont('helvetica','normal'); doc.setTextColor(160,200,220);
  doc.text(`${eng?.client} — ${eng?.type}`,M,52);
  doc.setFontSize(9); doc.setTextColor(100,140,160);
  doc.text(`Generated: ${new Date().toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}`,M,62);
  doc.text(`Consultant: ${eng?.consultant} | ${eng?.email} | ${eng?.phone}`,M,70);

  // Stats boxes on cover
  const crit=findings.filter(f=>f.sev==='critical').length;
  const high=findings.filter(f=>f.sev==='high').length;
  const med=findings.filter(f=>f.sev==='medium').length;
  const stats=[{l:'Critical',v:crit,c:red},{l:'High',v:high,c:amber},{l:'Medium',v:med,c:blue},{l:'Total',v:findings.length,c:navy}];
  stats.forEach((s,i)=>{
    const bx=M+i*(CW/4); const by=100;
    doc.setFillColor(245,248,252); doc.roundedRect(bx,by,CW/4-4,24,2,2,'F');
    doc.setDrawColor(...s.c); doc.setLineWidth(1.2); doc.roundedRect(bx,by,CW/4-4,24,2,2,'S'); doc.setLineWidth(0.3);
    doc.setFontSize(18); doc.setFont('helvetica','bold'); doc.setTextColor(...s.c);
    doc.text(String(s.v),bx+(CW/4-4)/2,by+14,{align:'center'});
    doc.setFontSize(8); doc.setTextColor(...gray);
    doc.text(s.l.toUpperCase(),bx+(CW/4-4)/2,by+21,{align:'center'});
  });

  y=140;
  // Engagement details
  doc.setFillColor(248,250,252); doc.roundedRect(M,y,CW,52,3,3,'F');
  doc.setDrawColor(...lgray); doc.roundedRect(M,y,CW,52,3,3,'S');
  y+=8; doc.setFontSize(9); doc.setFont('helvetica','bold'); doc.setTextColor(...navy); doc.text('ENGAGEMENT DETAILS',M+4,y); y+=7;
  [[`Client`,eng?.client],[`Address`,eng?.address],[`Consultant`,`${eng?.consultant} | ${eng?.email}`],['Type',eng?.type],['Investment',eng?.investment],['Period',`${eng?.startDate} — ${eng?.endDate}`]].forEach(([l,v])=>lv(l,v||''));

  y=210;
  doc.setFontSize(8); doc.setTextColor(...gray); doc.setFont('helvetica','italic');
  doc.text('CONFIDENTIAL — This document contains sensitive security information for authorized personnel only.',M,y,{maxWidth:CW});
  footer();

  // ── EXECUTIVE SUMMARY ────────────────────────────────────────────────────────
  nb();
  if(type==='executive'||type==='technical') {
    h1('1. EXECUTIVE SUMMARY');sp(4);
    body(`This report presents findings from an authorized gray-box security assessment of ${eng?.client}'s AWS cloud infrastructure, DNS and domain configuration, and web application portfolio. The assessment was conducted under written authorization using a non-destructive, evidence-based methodology safe for production systems.`);
    sp(4);
    if(crit>0){
      doc.setFillColor(255,240,240); doc.roundedRect(M,y,CW,12,2,2,'F');
      doc.setDrawColor(...red); doc.roundedRect(M,y,CW,12,2,2,'S');
      doc.setFontSize(9.5); doc.setFont('helvetica','bold'); doc.setTextColor(...red);
      doc.text(`⚠ IMMEDIATE ACTION REQUIRED: ${crit} CRITICAL finding${crit>1?'s were':' was'} discovered requiring same-day remediation.`,M+4,y+7.5);
      y+=16;
    }

    h2('Finding Summary');
    autoTable(doc,{startY:y,head:[['Severity','Count','CVSS Range','Action Required']],
      body:[['CRITICAL',crit,'9.0–10.0','Immediate — same day'],['HIGH',high,'7.0–8.9','Fix within 1 week'],['MEDIUM',med,'4.0–6.9','Fix within 30 days'],['LOW+INFO',findings.filter(f=>f.sev==='low'||f.sev==='info').length,'0.1–3.9','Schedule next quarter']],
      headStyles:{fillColor:navy,textColor:white,fontSize:8.5},bodyStyles:{fontSize:8.5},
      didParseCell:d=>{if(d.section==='body'&&d.column.index===1){const n=parseInt(d.cell.raw);if(d.row.raw[0]==='CRITICAL'&&n>0)d.cell.styles.textColor=red;else if(d.row.raw[0]==='HIGH'&&n>0)d.cell.styles.textColor=amber;}},
      margin:{left:M,right:M}});
    y=doc.lastAutoTable.finalY+10;

    h2('Top Risk Findings');
    [...findings].sort((a,b)=>b.cvss-a.cvss).slice(0,5).forEach(f=>{
      ck(26);
      const c=sevColor[f.sev]||gray;
      doc.setFillColor(248,250,252); doc.roundedRect(M,y,CW,22,2,2,'F');
      doc.setFillColor(...c); doc.rect(M,y,2,22,'F');
      doc.setFontSize(7.5); doc.setFont('helvetica','bold'); doc.setTextColor(...c);
      doc.text(`${f.id} [${f.sev.toUpperCase()} — CVSS ${f.cvss}]`,M+5,y+5);
      doc.setFontSize(9.5); doc.setTextColor(...black);
      doc.text(f.title,M+5,y+11);
      doc.setFontSize(8); doc.setFont('helvetica','normal'); doc.setTextColor(...gray);
      const impLines=doc.splitTextToSize(f.impact||'',CW-12);
      doc.text(impLines[0]+(impLines.length>1?'...':''),M+5,y+17);
      y+=25;
    });
  }

  // ── TECHNICAL FINDINGS ───────────────────────────────────────────────────────
  if(type==='technical'||type==='executive') {
    nb(); h1('2. COMPLETE FINDINGS CATALOG'); sp(4);
    [...findings].sort((a,b)=>b.cvss-a.cvss).forEach(f=>{
      ck(70);
      const c=sevColor[f.sev]||gray;
      doc.setFillColor(...c); doc.rect(M,y,2,12,'F');
      doc.setFillColor(247,249,252); doc.rect(M+2,y,CW-2,12,'F');
      doc.setFontSize(11); doc.setFont('helvetica','bold'); doc.setTextColor(...navy); doc.text(`${f.id}: ${f.title}`,M+6,y+5);
      doc.setFontSize(7.5); doc.setFont('helvetica','bold'); doc.setTextColor(...c); doc.text(`${f.sev.toUpperCase()} | CVSS: ${f.cvss}`,M+6,y+10);
      doc.setTextColor(...gray); doc.text(`Area: ${f.area.toUpperCase()} | Asset: ${f.affectedAsset||'—'} | Status: ${f.status.toUpperCase()}`,M+60,y+10);
      y+=16;
      if(CVSS_VECTORS[f.id]){doc.setFontSize(7.5);doc.setFont('helvetica','normal');doc.setTextColor(...gray);doc.text('CVSS Vector: '+CVSS_VECTORS[f.id],M,y);y+=5;}
      if(f.cweId){doc.setFontSize(7.5);doc.text(`CWE: ${f.cweId} — ${f.cweTitle||''} | OWASP: ${f.owaspId||''} — ${f.owaspTitle||''}`,M,y);y+=6;}
      const sections=[['EVIDENCE',f.evidence],['PROOF OF CONCEPT',f.proofOfConcept],['BUSINESS IMPACT',f.impact],['REMEDIATION',f.remedy]];
      sections.filter(s=>s[1]).forEach(([l,v])=>{
        ck(16); doc.setFontSize(8); doc.setFont('helvetica','bold'); doc.setTextColor(...blue); doc.text(l+':',M,y); y+=4.5;
        doc.setFont('helvetica','normal'); doc.setTextColor(...black);
        const lines=doc.splitTextToSize(v||'',CW-4); ck(lines.length*4.5+3); doc.text(lines,M+3,y); y+=lines.length*4.5+4;
      });
      if((MITRE_MAP[f.id]||[]).length>0){
        doc.setFontSize(8); doc.setFont('helvetica','bold'); doc.setTextColor(...blue); doc.text('MITRE ATT&CK:',M,y); y+=4.5;
        (MITRE_MAP[f.id]||[]).forEach(t=>{doc.setFontSize(7.5);doc.setFont('helvetica','normal');doc.setTextColor(...black);doc.text('  ▸ '+t,M,y);y+=4.5;});
        y+=2;
      }
      doc.setDrawColor(...lgray); doc.line(M,y,M+CW,y); y+=7;
    });
  }

  // ── REMEDIATION ROADMAP ──────────────────────────────────────────────────────
  if(type==='remediation'||type==='executive') {
    nb(); h1(type==='remediation'?'REMEDIATION ROADMAP':'3. REMEDIATION ROADMAP'); sp(4);
    const tiers=[{l:'TIER 1 — Fix Immediately (Critical/High)',c:red,sevs:['critical','high']},{l:'TIER 2 — Fix This Sprint (Medium)',c:amber,sevs:['medium']},{l:'TIER 3 — Schedule (Low/Info)',c:green,sevs:['low','info']}];
    tiers.forEach(tier=>{
      const tf=findings.filter(f=>tier.sevs.includes(f.sev)); if(!tf.length) return;
      ck(12); doc.setFillColor(...tier.c); doc.rect(M,y,CW,7,'F');
      doc.setFontSize(8.5); doc.setFont('helvetica','bold'); doc.setTextColor(...white); doc.text(tier.l,M+3,y+5); y+=10;
      autoTable(doc,{startY:y,head:[['ID','Finding','Owner','Due','Est. Effort']],
        body:tf.map(f=>[f.id,f.title.slice(0,55),f.remediationOwner||'TBD',f.remediationDue||'TBD',f.sev==='critical'?'<1 day':f.sev==='high'?'1-3 days':'1-2 weeks']),
        headStyles:{fillColor:navy,textColor:white,fontSize:8},bodyStyles:{fontSize:8},margin:{left:M,right:M}});
      y=doc.lastAutoTable.finalY+10;
    });
  }

  // ── OWASP MATRIX ─────────────────────────────────────────────────────────────
  if(type==='technical') {
    nb(); h1('4. OWASP TOP 10 2021 — COVERAGE MATRIX'); sp(4);
    const owasps=[
      ['A01:2021','Broken Access Control','Queued — Phase 5','—'],
      ['A02:2021','Cryptographic Failures','Partial finding','F-007'],
      ['A03:2021','Injection','Queued — Phase 5','—'],
      ['A04:2021','Insecure Design','Queued — Phase 5','—'],
      ['A05:2021','Security Misconfiguration','Finding identified','F-001,F-002,F-003'],
      ['A06:2021','Vulnerable Components','Queued — Phase 5','—'],
      ['A07:2021','Auth Failures','Queued — Phase 6','—'],
      ['A08:2021','SW & Data Integrity Failures','Queued — Phase 5','—'],
      ['A09:2021','Logging & Monitoring Failures','Finding identified','F-003'],
      ['A10:2021','SSRF','Queued — Phase 5','—'],
    ];
    autoTable(doc,{startY:y,head:[['OWASP ID','Category','Status','Finding Ref']],body:owasps,
      headStyles:{fillColor:navy,textColor:white,fontSize:8.5},bodyStyles:{fontSize:8.5},
      didParseCell:d=>{if(d.section==='body'&&d.column.index===2){if(d.cell.raw.includes('Finding'))d.cell.styles.textColor=red;else if(d.cell.raw.includes('Partial'))d.cell.styles.textColor=amber;}},
      margin:{left:M,right:M}});
    y=doc.lastAutoTable.finalY+12;
    h2('AWS CIS Benchmark Summary');
    autoTable(doc,{startY:y,head:[['Area','Controls Tested','Pass','Failing','Status']],
      body:[['IAM Config',12,10,2,'Finding'],['Network Security',8,7,1,'Partial'],['Logging & Monitoring',7,5,2,'Finding'],['Encryption at Rest',6,4,2,'Finding'],['Data Exposure',5,2,3,'Finding'],['CloudFront & Edge',4,3,1,'Partial'],['VPC & Routing',6,5,1,'Partial']],
      headStyles:{fillColor:navy,textColor:white,fontSize:8.5},bodyStyles:{fontSize:8.5},
      didParseCell:d=>{if(d.section==='body'&&d.column.index===4){if(d.cell.raw==='Finding')d.cell.styles.textColor=red;else if(d.cell.raw==='Partial')d.cell.styles.textColor=amber;}},
      margin:{left:M,right:M}});
  }

  doc.save(`${eng?.client}_SecureNet_${type}_${new Date().toISOString().slice(0,10)}.pdf`);
}
