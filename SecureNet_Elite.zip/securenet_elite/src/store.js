import { useState, useCallback } from 'react';
import { v4 as uuid } from 'uuid';
import { DEFAULT_STATE } from './data';

const KEY = 'securenet_elite_v1';

function load() {
  try { const r = localStorage.getItem(KEY); return r ? { ...DEFAULT_STATE, ...JSON.parse(r) } : DEFAULT_STATE; }
  catch { return DEFAULT_STATE; }
}
function save(s) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch {} }

export function useStore() {
  const [state, setState] = useState(load);
  const update = useCallback((fn) => {
    setState(prev => { const next = fn(prev); save(next); return next; });
  }, []);

  const eng = state.engagements.find(e => e.id === state.activeEngagementId);
  const findings = state.findings.filter(f => f.engId === state.activeEngagementId);

  return {
    state, update,
    eng, findings,

    // Findings
    addFinding: (f) => update(s => ({ ...s, findings: [...s.findings, { ...f, id: 'F-' + String(Date.now()).slice(-4), engId: s.activeEngagementId, createdAt: new Date().toISOString(), status: 'open', escalatedAt: null, remediationStatus: 'pending', remediationOwner: '', remediationDue: '' }], timeline: [{ id: Date.now(), type: 'finding', title: `${f.id||'NEW'}: ${f.title}`, ts: new Date().toISOString(), sev: f.sev, user: 'Christian' }, ...s.timeline] })),
    updateFinding: (id, changes) => update(s => ({ ...s, findings: s.findings.map(f => f.id === id ? { ...f, ...changes } : f) })),
    deleteFinding: (id) => update(s => ({ ...s, findings: s.findings.filter(f => f.id !== id) })),
    escalateFinding: (id) => update(s => ({ ...s, findings: s.findings.map(f => f.id === id ? { ...f, status: 'escalated', escalatedAt: new Date().toISOString() } : f), timeline: [{ id: Date.now(), type: 'escalation', title: `${id} ESCALATED to client`, ts: new Date().toISOString(), sev: 'critical', user: 'Christian' }, ...s.timeline] })),

    // Scope
    updateScope: (id, changes) => update(s => ({ ...s, scopeItems: s.scopeItems.map(i => i.id === id ? { ...i, ...changes, lastUpdated: new Date().toISOString().slice(0, 10) } : i) })),

    // Notes
    addNote: (text, tag, findingRef) => update(s => ({ ...s, notes: [{ id: uuid(), text, tag: tag || 'general', findingRef: findingRef || '', createdAt: new Date().toISOString() }, ...s.notes] })),
    deleteNote: (id) => update(s => ({ ...s, notes: s.notes.filter(n => n.id !== id) })),

    // Chat
    addChat: (msg) => update(s => ({ ...s, chatHistory: [...s.chatHistory.slice(-59), { ...msg, ts: Date.now() }] })),
    clearChat: () => update(s => ({ ...s, chatHistory: [] })),

    // Checklist
    toggleCheck: (i) => update(s => ({ ...s, accessChecklist: { ...s.accessChecklist, [i]: !s.accessChecklist[i] } })),

    // API key
    setApiKey: (k) => update(s => ({ ...s, apiKey: k })),

    // Targets
    addTarget: (t) => update(s => ({ ...s, engagements: s.engagements.map(e => e.id === s.activeEngagementId ? { ...e, targets: [...(e.targets || []), { ...t, id: Date.now() }] } : e) })),
    removeTarget: (id) => update(s => ({ ...s, engagements: s.engagements.map(e => e.id === s.activeEngagementId ? { ...e, targets: e.targets.filter(t => t.id !== id) } : e) })),

    // Engagement
    updateEngagement: (changes) => update(s => ({ ...s, engagements: s.engagements.map(e => e.id === s.activeEngagementId ? { ...e, ...changes } : e) })),

    // Reset
    reset: () => { setState(DEFAULT_STATE); save(DEFAULT_STATE); },

    // Export
    exportJSON: () => {
      const b = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
      const u = URL.createObjectURL(b);
      const a = document.createElement('a'); a.href = u; a.download = `securenet_backup_${Date.now()}.json`; a.click();
    },
    importJSON: (file) => new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = ev => { try { update(() => JSON.parse(ev.target.result)); res(); } catch { rej(new Error('Invalid JSON')); } };
      r.readAsText(file);
    }),
  };
}
