#!/bin/bash
set -e

echo "⏳ Waiting for database..."
until python -c "
import asyncio, asyncpg, os
async def check():
    url = os.environ['DATABASE_URL'].replace('postgresql+asyncpg','postgresql')
    conn = await asyncpg.connect(url)
    await conn.close()
asyncio.run(check())
" 2>/dev/null; do
  echo "  DB not ready, retrying in 2s..."
  sleep 2
done
echo "✅ Database ready"

echo "⏳ Running migrations..."
alembic upgrade head
echo "✅ Migrations done"

echo "⏳ Seeding demo data..."
python scripts/seed.py || echo "  (already seeded or seed failed — continuing)"
echo "✅ Seed done"

echo "🚀 Starting BLACKMIRROR-X backend..."
exec uvicorn app.main:app --host 0.0.0.0 --port 8000
