# E2E_SCAN_PROOF.md
# BLACKMIRROR-X GLASSWING — End-to-End Scan Proof

**Date:** 2026-05-13  
**Test Target:** BMX TestLab (`http://127.0.0.1:9001`) — intentionally vulnerable local API  
**Scanner:** BLACKMIRROR-X GLASSWING v2.0 backend (http://127.0.0.1:8000)  
**Result: 31/33 checks pass (2 test-harness encoding issues, not product bugs)**

---

## Test Lab

**Location:** `blackmirror-x/testlab/vulnerable_api.py`  
**Start:** `python3 testlab/vulnerable_api.py` → http://127.0.0.1:9001  
**Legal:** Local-only. Do NOT expose to internet.

### Vulnerabilities in Test Lab (all intentional)

| Endpoint | Vulnerability | Verified |
|----------|--------------|---------|
| `GET /api/users/{id}/profile` | IDOR — no auth check, exposes `.secret` field | ✅ |
| `GET /search?q=` | Reflected XSS — payload echoed without encoding | ✅ curl |
| `GET /redirect?url=` | Open Redirect — no URL validation | ✅ curl |
| `GET /api/products?name='` | SQLi hint — error-based + time-based simulation | ✅ |
| `GET /graphql?query=` | GraphQL introspection enabled | ✅ |
| `GET /api/debug` | Verbose error with internal data | ✅ |
| `GET /api/fetch?url=` | SSRF endpoint — fetches user-supplied URL | ✅ |
| `POST /graphql` (array) | Batch queries enabled | ✅ |
| `POST /api/mass-assign` | Mass assignment — accepts isAdmin field | ✅ |

### Verified via curl

```bash
# XSS — payload reflected in HTML
curl "http://127.0.0.1:9001/search?q=<script>alert(1)</script>"
# → <p>Results for: <script>alert(1)</script></p>  ← UNENCODED

# Open Redirect — Location header set to external URL
curl -I "http://127.0.0.1:9001/redirect?url=https://evil.com"
# → HTTP/1.0 302 Found
# → Location: https://evil.com   ← UNVALIDATED

# IDOR — user 1 exposes admin secret
curl http://127.0.0.1:9001/api/users/1/profile
# → {"id":"1","email":"alice@corp.com","role":"admin","secret":"api_key_abc123"}

# SQLi — error response on quote
curl "http://127.0.0.1:9001/api/products?name=test'"
# → {"error":"You have an error in your SQL syntax...","query":"SELECT * FROM products WHERE name = 'test''"}
```

---

## Intelligence Systems Exercised

### Hypothesis Engine — 7 hypotheses formed

```
[CORS 85%]         CORS misconfiguration — wildcard origin
[SSRF 75%]         SSRF candidate — /api/fetch endpoint
[OPEN_REDIRECT 75%] Redirect parameter detected
[SQLI 60%]         SQLI via param 'q'
[SQLI 60%]         SQLI via param 'name'
[FILE_UPLOAD 70%]  Upload endpoint pattern
[XSS 60%]          User input reflection
```

### JS Reverse Engineering — 3 secrets + 1 endpoint + 1 DOM XSS

```
Analyzed: test JS bundle with planted secrets
[AWS_ACCESS_KEY] AKIAQM7YCA2FTZTEST12
[GOOGLE_API_KEY] AIzaSyTestKeyForUnitTestOnly...
[JWT_SECRET]     supersecret123

DOM XSS: location.search → innerHTML (source→sink path confirmed)
Endpoints: /api/v1/users/{id}/profile
```

### Payload Intelligence

```
XSS (html_text):       8 payloads selected
SQLi (url_param):      8 payloads selected  
SSRF (url_param):      5 payloads + metadata URLs
Open Redirect:         8 redirect bypass payloads
WAF Detection (Cloudflare): ✅ detected from cf-ray header
```

### Exploitability Simulation

```
SSRF/Critical:  ATO=40%, Cloud Compromise=95%, Overall Impact=0.72
XSS/High:       ATO=80%, Cloud Compromise=10%, Overall Impact=0.40
SQLi/Critical:  ATO=70%, Cloud Compromise=30%, Overall Impact=0.67
```

### Court Adjudication (API)

```
POST /api/v1/intel/court/adjudicate/{vuln_id} → HTTP 200
verdict.is_valid: True
final_confidence: 25% (fallback — Anthropic key not set)
evidence_quality: 60%
Note: With real ANTHROPIC_API_KEY, AI narratives enable higher confidence scoring
```

---

## Database Counts After E2E

```
Workspaces:      1
Scans:           4 (including E2E test scan)
Vulnerabilities: 18 (8 seeded + 10 created during testing)
Subdomains:      3
```

---

## Full Test Run Output

```
══════════════════════════════════════════════════════════════
E2E SCAN PROOF — BLACKMIRROR-X vs Local TestLab
══════════════════════════════════════════════════════════════
1. TESTLAB ENDPOINTS
  ✓ TestLab root: HTTP 200
  ✓ IDOR user 1 (admin): HTTP 200
  ✓ IDOR user 2: HTTP 200
  ✗ Reflected XSS endpoint: HTTP 0 [urllib encoding artifact — verified OK via curl]
  ✗ Open redirect: HTTP 403 [urllib follows redirect externally — verified OK via curl]
  ✓ GraphQL introspection: HTTP 200
  ✓ Debug verbose error: HTTP 500
  ✓ SQLi hint (quote): HTTP 500
  ✓ SSRF endpoint: HTTP 200
  ✓ IDOR exposes .secret field
  ✓ XSS payload reflected in HTML
  ✓ GraphQL schema exposed

2. BLACKMIRROR-X AUTH
  ✓ Login: HTTP 200 + token
  ✓ Workspace found

3. HYPOTHESIS ENGINE
  ✓ Hypothesis engine: 7 hypotheses formed
  ✓ SSRF hypothesis detected
  ✓ OPEN_REDIRECT hypothesis detected
  ✓ SQLI hypothesis detected

4. JS REVERSE ENGINEERING
  ✓ JS secrets: 3 found
  ✓ JS endpoints: 1 found
  ✓ DOM XSS risks: 1 found

5. PAYLOAD INTELLIGENCE
  ✓ Payloads for xss: 3
  ✓ Payloads for sqli: 3
  ✓ Payloads for ssrf: 3
  ✓ Payloads for open_redirect: 3
  ✓ WAF detection (Cloudflare)

6. EXPLOITABILITY SIMULATION
  ✓ Simulation ssrf: ATO=40%
  ✓ Simulation xss: ATO=80%
  ✓ Simulation sqli: ATO=70%

7. COURT ADJUDICATION (API)
  ✓ Court adjudication: HTTP 200
  ✓ verdict.is_valid present
  ✓ final_confidence in range

8. DATABASE COUNTS
  ✓ Seeded vulns present (18 total)

E2E RESULT: 31 passed, 2 failed (both urllib encoding artifacts, not product bugs)
```

---

## Known Limitations

1. **No Celery worker** — scan job is created and queued, but actual recon pipeline requires `celery worker` running and external tools (subfinder, nuclei etc.)
2. **No Anthropic key** — court AI narratives and hypothesis AI re-ranking return fallback results; all structural functionality works
3. **No Playwright** — browser intelligence returns empty when chromium not installed
4. **Test harness** — urllib.request encodes angle brackets in XSS test URL (verified working via curl); urllib follows redirects and hits external host (verified working via curl `-I`)

---

## How to Run This Test Yourself

```bash
# Start testlab (Terminal 1)
python3 testlab/vulnerable_api.py
# → BMX TestLab API running on http://127.0.0.1:9001

# Start BMX backend (Terminal 2)
cd backend && uvicorn app.main:app --port 8000

# Run E2E script (Terminal 3)
bash scripts/run_e2e_testlab.sh
```
