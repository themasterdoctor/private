# RUNTIME_TRUTH_AUDIT.md
# BLACKMIRROR-X GLASSWING — Runtime Truth Audit
**Date:** 2026-05-14
**Auditor:** Phase 12 — Runtime Truth Audit
**Method:** Fresh unzip at `/home/claude/runtime-audit/`, every command run for real

---

## Environment (honest)

This audit runs on a machine **without Docker**. Docker-dependent steps
(`install_local.sh` Docker sections, container orchestration) cannot be
executed here. All bare-metal backend, frontend build, and API tests are
real and unmodified.

```
Python:  3.12.3
Node.js: v22.22.2
PostgreSQL: 16.13
Redis: running (bare metal)
Docker: NOT AVAILABLE
```

---

## Bugs Found and Fixed

### Bug 1 — `GET /copilot/sessions` missing (404)
**Found by:** Live endpoint probe  
**Symptom:** `GET /api/v1/copilot/sessions?workspace_id=...` returned 404.  
Backend had `GET /copilot/sessions/{session_id}/messages` but no list endpoint.  
**Fix:** Added `GET /copilot/sessions` route to `app/api/routes/copilot.py`:
```python
@router.get("/sessions")
async def list_sessions(workspace_id: str, ...):
    # Returns distinct session_ids for the workspace
```

### Bug 2 — Redis password mismatch in `.env.example`
**Found by:** Config comparison between `.env.example` and `docker-compose.yml`  
**Symptom:** `.env.example` set `REDIS_URL=redis://:redis_secret_2024@redis:6379/0`
but the Redis container in `docker-compose.yml` has **no password configured**.
On fresh Docker deploy, backend and worker would fail to connect to Redis.  
**Fix:** Removed password from `.env.example` Redis/Celery URLs:
```
REDIS_URL=redis://redis:6379/0
CELERY_BROKER_URL=redis://redis:6379/1
CELERY_RESULT_BACKEND=redis://redis:6379/2
```

### Bug 3 — Worker `depends_on` didn't wait for healthy infra
**Found by:** docker-compose.yml inspection  
**Symptom:** `worker` service used `depends_on: [redis, postgres]` (list form = no healthcheck wait).
On slow machines, worker could start before postgres/redis were ready.  
**Fix:** Changed to explicit healthcheck conditions:
```yaml
depends_on:
  postgres: { condition: service_healthy }
  redis: { condition: service_healthy }
```

### Bug 4 — `install_local.sh` broken Python heredoc (fixed in previous session)
**Symptom:** Script contained Python heredoc with `{SECRET_PLACEHOLDER}` and
`{JWT_PLACEHOLDER}` — bash expanded these as empty strings before Python ran,
causing a crashed heredoc. Secrets were being set by the `sed` lines below,
but the script had an unnecessary broken Python block.  
**Fix:** Removed Python heredoc entirely. Secrets written with `sed` only.

### Bug 5 — Frontend pages used wrong localStorage token key (fixed in previous session)
**Symptom:** Auth store wrote JWT to `bmx_access_token`. Nine Phase 10/11 pages
read `bmx_token` → always got `null` → every API call returned 401.  
**Fix:** Standardized all pages to `bmx_access_token`.

### Bug 6 — Copilot and hypotheses used wrong HTTP methods/paths (fixed in previous session)
**Symptom:** Mission page called `GET /intel/hypotheses/generate` (backend is POST).
api.ts called `/chat/sessions` instead of `/copilot/sessions`.  
**Fix:** Corrected to POST and updated paths.

---

## What Cannot Be Tested Without Docker

The following require a running Docker environment with the full stack:

1. **`install_local.sh` Docker sections** — `docker compose down -v`, `docker compose build`,
   `docker compose up`. These commands cannot run here. The script logic has been
   verified syntactically and the sequence is correct (postgres+redis healthy → backend
   healthy → alembic → seed → frontend). The Redis password mismatch bug above would have
   caused failures on first Docker deploy; that is now fixed.

2. **Worker job processing** — Celery worker requires Docker networking (redis://redis:...).
   Imports verify correctly (`celery_app`, `run_scan_task`, etc.). Broker URL is correct.
   Actual task execution (`queued → running → completed`) requires a live worker process.

3. **Frontend container build** — `next build` + standalone output verified locally.
   Docker multi-stage build and `NEXT_PUBLIC_API_URL` bake-at-build-time logic is correct.

---

## Verification Gate Results (from clean unzip)

```
pytest tests/test_full_stack.py    → 85/85 passed ✅
verify_full_stack.sh               → 22/22 passed, 86 routes ✅  
run_e2e_testlab.sh                 → 21/21 passed ✅
demo_run.sh                        → 12/12 passed ✅
```

## Endpoint Probe Results (44 endpoints)

```
43/44 passed before fix
44/44 passed after adding GET /copilot/sessions
```

All 44 endpoints tested against live server started from clean unzip.

---

## Remaining Honest Limitations

1. **No Docker runtime proof.** `install_local.sh` has the correct sequence and the
   Redis/worker bugs are fixed, but a full Docker deploy test cannot be done on this machine.

2. **Celery worker job execution unverified.** The broker connection, task imports, and
   queue routing all check out. Actual `queued → running → completed` transition requires
   a live worker.

3. **Playwright browser features disabled.** DOM snapshot, SPA mapper, WS capture all
   gracefully return empty — no crash, but no browser intelligence without Playwright.

4. **AI narratives use heuristic fallback.** No Anthropic API key set — court adjudication,
   hypothesis generation, and copilot all work via heuristic path.

5. **Frontend tested via build only.** `npm run build` passes (27 routes, 0 TS errors).
   Browser rendering not testable without a display environment.
