# OPERATOR_MANUAL — BLACKMIRROR-X GLASSWING

Complete reference for security operators using BLACKMIRROR-X.

## Workflows

### Recon Only (passive)
**When to use:** First step on any target. Zero active testing.
**What it does:** Subfinder → DNS resolution → HTTP probe → tech detection → report
**Command:**
```bash
# Via UI: Workflows → Recon Only → enter domain → launch
# Via API:
curl -X POST .../api/v1/scans \
  -d '{"workspace_id":"...","scan_type":"recon","config":{"domain":"target.com"}}'
```

### JS Analysis (passive)
**When to use:** After recon, to find secrets and hidden endpoints in JS bundles.
**What it does:** Downloads JS → extracts secrets/endpoints/DOM XSS sinks → report
**Key finds:** AWS keys, API tokens, hidden routes, innerHTML sinks

### API Audit (low risk)
**When to use:** When you have API documentation or can discover endpoints.
**What it does:** OpenAPI analysis → GraphQL testing → IDOR candidate generation
**Requires:** Target URL, optionally an OpenAPI spec URL

### Full Safe Scan (medium risk)
**When to use:** Authorized bug bounty targets.
**What it does:** All passive + active modules at medium risk tier
**Rate limit:** 5 req/s, scope-enforced

### Bug Bounty Builder (medium risk)
**When to use:** When preparing a report for HackerOne/Bugcrowd.
**What it does:** Full scan + court validation + HackerOne-format export

### Chain Investigation (passive)
**When to use:** When you have findings and want to reason about attack paths.
**What it does:** Load existing vulns → chain graph → rank → proof gaps → report

### Evidence Replay (passive)
**When to use:** Validating findings, diffing authenticated vs unauthenticated responses.
**What it does:** Replay HTTP requests → mutate parameters → compare responses

## AVROS Orchestrator

The orchestrator runs agents in dependency order:

```
Recon → JS Agent → API Agent
              ↓
         Vuln Agent
              ↓
         Chain Agent → Court Agent → Report Agent
```

All agents communicate through the AgentBus. Events are published at each step.

**Start an orchestrated scan:**
```bash
# 1. Create a scan first
POST /api/v1/scans

# 2. Start orchestrator
POST /api/v1/orchestrator/start/{scan_id}

# 3. Monitor
GET /api/v1/orchestrator/status/{scan_id}

# 4. View task graph
GET /api/v1/orchestrator/tasks/{scan_id}
```

**Human approval flow:**
1. Orchestrator hits a CRITICAL task
2. Task goes into `BLOCKED` state
3. GET /api/v1/orchestrator/pending shows pending approvals
4. POST /api/v1/orchestrator/approve/{task_id} to unblock

## Strategic Memory

Strategic memory persists across scans within a workspace:

**Record what gets accepted/rejected:**
```bash
POST /api/v1/memory/{workspace_id}/feedback
  vuln_type=xss&severity=high&outcome=accepted&bounty_paid=$1500
```

**Get rejection patterns (avoid wasted work):**
```bash
GET /api/v1/memory/{workspace_id}/rejected-patterns
```

**Set program scope rules:**
```bash
POST /api/v1/memory/{workspace_id}/program
  program_name="HackerOne Target"&in_scope=*.target.com&out_of_scope=staging.target.com
```

## Attack Chain Workflow

1. Run a scan to populate vulnerabilities
2. Navigate to Chains page
3. Paste vulnerability JSON (or load from scan)
4. Click "Build Attack Chains"
5. Review ranked chains by probability
6. Check proof gaps for next test steps
7. Export HackerOne report via /api/v1/chains/report/{chain_id}

## Evidence Replay

1. Navigate to Replay Lab
2. Enter raw request details (method, URL, headers, body)
3. Click Replay to capture baseline
4. Mutate a parameter (e.g., change user ID)
5. Diff responses — check for auth bypass (403→200) or new fields

## Report Export

Reports are generated for each scan:
```bash
POST /api/v1/reports/generate/{scan_id}
GET  /api/v1/reports/{report_id}
```

Report contains:
- Executive summary
- Finding list with severity, CVSS, remediation
- Attack chain analysis
- Evidence screenshots (when Playwright available)
- HackerOne-ready format

## Emergency Procedures

**Stop all scanning immediately:**
```bash
curl -X POST .../api/v1/workers/emergency-stop \
  -H "Authorization: Bearer $TOKEN"
```
Or click the **Emergency Stop** button in Workers page.

**Stop a specific scan:**
```bash
POST /api/v1/workers/pause/{scan_id}
```

**Restore after false positive:**
```bash
POST /api/v1/workers/resume-all
```

## Environment Variables Reference

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `DATABASE_URL` | Yes | - | PostgreSQL async URL |
| `SECRET_KEY` | Yes | random | App secret (32+ chars) |
| `JWT_SECRET_KEY` | Yes | random | JWT signing key |
| `ANTHROPIC_API_KEY` | No | "" | Enable AI narratives |
| `REDIS_URL` | Yes | - | Celery broker |
| `BILLING_ENABLED` | No | false | Enable quota enforcement |
| `MAX_CONCURRENT_SCANS` | No | 5 | Parallel scan limit |
| `SCAN_TIMEOUT_SECONDS` | No | 3600 | Per-scan timeout |

## Troubleshooting

See [TROUBLESHOOTING.md](TROUBLESHOOTING.md) for common issues.
