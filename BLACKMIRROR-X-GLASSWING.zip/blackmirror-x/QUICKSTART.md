# QUICKSTART — BLACKMIRROR-X GLASSWING

Get from zero to first scan in under 10 minutes.

## Option A: Docker (recommended)

```bash
# 1. Clone
git clone https://github.com/your-org/blackmirror-x
cd blackmirror-x

# 2. Install
bash scripts/install_local.sh

# 3. Open browser
open http://localhost:3000
# Login: admin@blackmirror.io / BlackMirrorX2025!

# 4. Run demo
bash scripts/demo_run.sh
```

## Option B: Bare Metal (Python + Node)

```bash
# Prerequisites: Python 3.11+, Node 18+, PostgreSQL 16, Redis

# 1. Copy env
cp .env.example .env
# Edit .env — update DATABASE_URL, REDIS_URL, generate secrets

# 2. Backend
cd backend
pip install -r requirements.txt
alembic upgrade head
python scripts/seed.py
uvicorn app.main:app --host 0.0.0.0 --port 8000 &

# 3. Frontend
cd frontend
npm install
npm run build
npm start &

# 4. Open
open http://localhost:3000
```

## First Scan (5 minutes)

1. Log in at http://localhost:3000
2. Click **Workflows** in the sidebar
3. Select **Recon Only** (safest)
4. Enter target domain (or use `localhost:9001` for testlab)
5. Check the authorization checkbox
6. Click **Launch**
7. Watch progress in **Dashboard**

## Run Against Testlab

The local testlab has 8 intentional vulnerabilities — safe to scan:

```bash
# Terminal 1 — start testlab
cd testlab/vuln-api && python app.py

# Terminal 2 — run demo scan
bash scripts/demo_run.sh
```

## Key URLs

| URL | Purpose |
|-----|---------|
| http://localhost:3000 | Dashboard |
| http://localhost:3000/onboarding | First-run wizard |
| http://localhost:3000/workflows | Guided scan workflows |
| http://localhost:3000/orchestrator | AVROS agent task graph |
| http://localhost:8000/api/docs | API documentation |
| http://localhost:9001 | Local testlab |

## Credentials

- **Email:** admin@blackmirror.io
- **Password:** BlackMirrorX2025!

## Next Steps

- Read [OPERATOR_MANUAL.md](OPERATOR_MANUAL.md) for full workflow guide
- Read [DEMO_GUIDE.md](DEMO_GUIDE.md) for 10-minute demo instructions
- See [SECURITY_MODEL.md](SECURITY_MODEL.md) for safety architecture
