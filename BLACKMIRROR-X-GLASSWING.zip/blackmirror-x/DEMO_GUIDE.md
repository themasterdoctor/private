# DEMO_GUIDE — BLACKMIRROR-X 10-Minute Demo

Complete walkthrough for demos, sales calls, and onboarding sessions.

## Prerequisites

- BLACKMIRROR-X running (see QUICKSTART.md)
- Demo data seeded: `python3 backend/scripts/seed.py`
- Testlab running: `cd testlab/vuln-api && python app.py`

## Option 1: One-Command Demo

```bash
bash scripts/demo_run.sh
```

This automatically:
1. Starts the testlab
2. Authenticates to BLACKMIRROR-X
3. Runs passive vulnerability checks
4. Shows 7+ findings
5. Generates a report
6. Prints the attack chain and court verdict
7. Outputs the report file path

Expected output:
```
── 5. Running Passive Vulnerability Checks
  ⚠  [CRITICAL] Broken Access: Admin users accessible without auth
  ⚠  [HIGH] IDOR: User profile exposes api_token
  ⚠  [CRITICAL] SQLi: Error message leaks SQL
  ⚠  [HIGH] XSS: Search parameter reflection
  ⚠  [MEDIUM] GraphQL: Introspection enabled
  ⚠  [MEDIUM] CORS: Wildcard origin accepted

  ✓  Passive checks complete: 6 findings detected (2 critical)

DEMO RESULTS: 7 passed  |  0 failed
Findings detected:   6 vulnerabilities
Report path:         /tmp/bmx_demo_report_20260513_100000.json
```

## Option 2: Browser Demo (10 minutes)

### Minute 0–1: Login and Dashboard

1. Open http://localhost:3000
2. Login: admin@blackmirror.io / BlackMirrorX2025!
3. Dashboard shows: 8 vulnerabilities, 3 subdomains, 1 completed scan

### Minute 1–3: Attack Graph

1. Click **Attack Graph** (graph icon)
2. Shows force-directed graph: target → subdomains → vulnerabilities
3. Point out: nodes colored by severity, edges show relationships

### Minute 3–5: AVROS Orchestrator

1. Click **AVROS → Orchestrator**
2. Select the demo scan
3. Click **Start Orchestrator**
4. Watch task graph populate (recon → js → api → vuln → chain → court → report)
5. Show the Agent Bus event feed on the right

### Minute 5–7: AI Intelligence

1. Click **Mission Control**
2. Show: hypothesis engine generated 6 hypotheses from testlab URLs
3. Click **AI Courtroom** 
4. Show demo verdict: SSRF → CONFIRMED, 94% confidence

### Minute 7–8: Attack Chains

1. Click **AVROS → Chains**
2. Click **Build Attack Chains** (uses preloaded vulns)
3. Show chain: SSRF → Cloud Metadata → RCE
4. Expand chain: probability, bounty estimate, missing links, next steps

### Minute 8–9: Evidence Replay

1. Click **Replay Lab**
2. Show: replay a previous request
3. Show: diff two responses (authorized vs unauthorized)

### Minute 9–10: Report Export

1. Click **Reports**
2. Show the demo report: 8 findings, attack chains, executive summary
3. Point out: HackerOne-format ready

## Demo Mode API (for programmatic demos)

```bash
TOKEN=$(curl -s -X POST http://localhost:8000/api/v1/auth/login \
  -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" | jq -r .access_token)

# Reset demo workspace
curl -X POST http://localhost:8000/api/v1/demo/reset \
  -H "Authorization: Bearer $TOKEN"

# Get demo report
curl http://localhost:8000/api/v1/demo/report \
  -H "Authorization: Bearer $TOKEN" | jq .

# Get demo attack chain
curl http://localhost:8000/api/v1/demo/chain \
  -H "Authorization: Bearer $TOKEN" | jq .

# Get demo court verdict
curl http://localhost:8000/api/v1/demo/verdict \
  -H "Authorization: Bearer $TOKEN" | jq .
```

## Talking Points

**"What makes this different from other scanners?"**
> BLACKMIRROR-X reasons about attack chains, not just individual findings. It combines recon + JS analysis + API intelligence + court validation in one workflow. The AVROS orchestrator coordinates agents like an autonomous team.

**"Is it safe to run?"**
> By default, BLACKMIRROR-X runs in passive mode. Active tests require explicit authorization checkbox. Critical-risk tests require manual approval. Rate limits, scope validation, and emergency stop are always active.

**"Does it need an Anthropic API key?"**
> No — all intelligence features have heuristic fallbacks. The hypothesis engine, payload selection, chain reasoning, and court validation all work without AI. The key adds narrative quality and nuanced reasoning.

**"What's the testlab?"**
> It's a Flask app we included with 8 intentional vulnerabilities — IDOR, XSS, SQLi, GraphQL introspection, CORS, mass assignment, open redirect, version disclosure. Safe to scan, no real data.
