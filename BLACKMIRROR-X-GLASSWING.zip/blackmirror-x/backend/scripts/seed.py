"""Seed demo data. Login: admin@blackmirror.io / BlackMirrorX2025!"""
import asyncio, sys, os, uuid
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import select
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from app.core.config import settings
from app.core.security import hash_password
from app.models.models import User, Workspace, WorkspaceMember, ScanJob, Subdomain, Vulnerability


async def seed():
    engine = create_async_engine(settings.DATABASE_URL, echo=False)
    Session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    async with Session() as s:
        result = await s.execute(select(User).where(User.email == "admin@blackmirror.io"))
        if result.scalar_one_or_none():
            print("Already seeded"); return

        admin_id = str(uuid.uuid4())
        s.add(User(id=admin_id, email="admin@blackmirror.io", full_name="Admin Operator",
                   hashed_password=hash_password("BlackMirrorX2025!"), role="admin"))
        await s.flush()

        ws_id = str(uuid.uuid4())
        s.add(Workspace(id=ws_id, name="Demo Target Corp", slug="demo-target-corp",
                        description="Example workspace"))
        await s.flush()
        s.add(WorkspaceMember(workspace_id=ws_id, user_id=admin_id, role="admin"))

        scan_id = str(uuid.uuid4())
        s.add(ScanJob(id=scan_id, workspace_id=ws_id, created_by=admin_id,
                      name="Demo Scan — demo-target.com", scan_type="full",
                      status="completed", progress=100,
                      config={"target": "demo-target.com"}))
        await s.flush()

        for sub, ip, code, title, techs, ports in [
            ("api.demo-target.com", ["10.0.1.5"], 200, "API Gateway", ["Node.js","Express"], [80,443]),
            ("admin.demo-target.com",["10.0.1.6"], 302, "Admin Panel", ["React","Nginx"], [80,443]),
            ("app.demo-target.com", ["10.0.1.4"], 200, "Main App", ["React","FastAPI"], [80,443]),
        ]:
            s.add(Subdomain(id=str(uuid.uuid4()), scan_id=scan_id, workspace_id=ws_id,
                            host=sub, ip_addresses=ip, status_code=code,
                            title=title, tech_stack=techs, ports=ports, source="seed", is_alive=True))

        for title, vtype, sev, url, payload, desc, fix in [
            ("Reflected XSS in Search","xss","high","https://api.demo-target.com/search?q=test",
             "<script>alert(1)</script>","Unencoded user input reflected.","HTML-encode output."),
            ("IDOR — User Profile","idor","high","https://api.demo-target.com/api/users/123/profile",
             "Replace 123","Unauthorized access to user data.","Add object-level auth checks."),
            ("SQL Injection in Login","sqli","critical","https://api.demo-target.com/api/auth/login",
             "' OR 1=1--","Auth bypass via SQLi.","Use parameterized queries."),
            ("SSRF via Import URL","ssrf","critical","https://app.demo-target.com/api/import",
             "http://169.254.169.254/","Cloud metadata accessible.","Block RFC1918 + metadata IPs."),
            ("JWT Algorithm Confusion","jwt","critical","https://api.demo-target.com/api/auth/verify",
             "eyJ...","RS256→HS256 confusion.","Whitelist accepted algorithms."),
            ("GraphQL Introspection","graphql","medium","https://api.demo-target.com/graphql",
             '{"query":"{__schema{types{name}}}"}','Schema exposed.','Disable introspection in prod.'),
            ("Open Redirect in Login","open_redirect","medium","https://app.demo-target.com/login?next=https://evil.com",
             "https://evil.com","External redirect.","Allowlist redirect targets."),
            ("Missing HSTS Header","missing_security_header","low","https://demo-target.com",
             None,"No HSTS.","Add Strict-Transport-Security header."),
        ]:
            s.add(Vulnerability(id=str(uuid.uuid4()), scan_id=scan_id, workspace_id=ws_id,
                                title=title, vuln_type=vtype, severity=sev, status="confirmed",
                                url=url, payload=payload, description=desc, remediation=fix,
                                source="seed"))

        await s.commit()
        print("✓ Seeded: 1 user, 1 workspace, 1 scan, 3 subdomains, 8 vulns")
        print("  Login: admin@blackmirror.io / BlackMirrorX2025!")
    await engine.dispose()

if __name__ == "__main__":
    asyncio.run(seed())
