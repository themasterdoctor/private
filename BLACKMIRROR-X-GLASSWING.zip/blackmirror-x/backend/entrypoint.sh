#!/bin/bash
set -e

echo "⏳ Waiting for PostgreSQL..."
# Use pg_isready which is reliable and available in the image
until pg_isready -h "${POSTGRES_HOST:-postgres}" -p "${POSTGRES_PORT:-5432}" -U "${POSTGRES_USER:-bmx}" -d "${POSTGRES_DB:-blackmirror}" -q 2>/dev/null; do
  echo "  PostgreSQL not ready, retrying in 3s..."
  sleep 3
done
echo "✅ PostgreSQL ready"

echo "⏳ Running database migrations..."
alembic upgrade head
echo "✅ Migrations complete"

echo "⏳ Seeding demo data..."
python scripts/seed.py && echo "✅ Seed complete" || echo "  ℹ️  Seed skipped (already seeded)"

echo "🚀 Starting BLACKMIRROR-X backend on :8000"
exec uvicorn app.main:app --host 0.0.0.0 --port 8000
