#!/bin/bash
set -e

# ── Wait for PostgreSQL ───────────────────────────────────────────────────────
echo "⏳ Waiting for PostgreSQL..."
until pg_isready \
  -h "${POSTGRES_HOST:-postgres}" \
  -p "${POSTGRES_PORT:-5432}" \
  -U "${POSTGRES_USER:-bmx}" \
  -d "${POSTGRES_DB:-blackmirror}" -q 2>/dev/null; do
  echo "  PostgreSQL not ready, retrying in 3s..."
  sleep 3
done
echo "✅ PostgreSQL ready"

# ── Enable required extensions BEFORE migrations ──────────────────────────────
# Must be done here because the pgvector image does not enable uuid-ossp by default,
# and migration 173cd281e294 uses uuid_generate_v4() which requires it.
echo "⏳ Enabling PostgreSQL extensions..."
python - << 'PYEOF'
import psycopg2, os, re

# Parse connection details from DATABASE_URL
# Format: postgresql+asyncpg://user:pass@host:port/db  OR  postgresql://...
url = os.environ.get("DATABASE_URL", "")
url = re.sub(r"^\w+\+\w+://", "postgresql://", url)  # strip driver suffix

conn = psycopg2.connect(url)
conn.autocommit = True
cur = conn.cursor()
for ext in ("vector", "pg_trgm", '"uuid-ossp"'):
    cur.execute(f"CREATE EXTENSION IF NOT EXISTS {ext}")
    print(f"  ✓ extension {ext}")
cur.close()
conn.close()
PYEOF
echo "✅ Extensions enabled"

# ── Run migrations ────────────────────────────────────────────────────────────
echo "⏳ Running database migrations..."
alembic upgrade head
echo "✅ Migrations complete"

# ── Seed demo data ────────────────────────────────────────────────────────────
echo "⏳ Seeding demo data..."
python scripts/seed.py && echo "✅ Seed complete" || echo "  ℹ️  Seed skipped (already seeded)"

# ── Start backend ─────────────────────────────────────────────────────────────
echo "🚀 Starting BLACKMIRROR-X backend on :8000"
exec uvicorn app.main:app --host 0.0.0.0 --port 8000
