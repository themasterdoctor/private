"""003_avros_completion — AVROS Phase 10 schema tables."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "003_avros_completion"
down_revision = "173cd281e294"
branch_labels = None
depends_on = None

UUID = postgresql.UUID(as_uuid=True)
JSONB = postgresql.JSONB()
now_ = sa.text("now()")
uuid_ = sa.text("uuid_generate_v4()")


def upgrade():
    # ── Agent Tasks ──────────────────────────────────────────────────────────
    op.create_table("agent_tasks",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("scan_id", UUID, sa.ForeignKey("scan_jobs.id", ondelete="CASCADE"), nullable=False),
        sa.Column("workspace_id", UUID, nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("agent_type", sa.String(100), nullable=False),
        sa.Column("status", sa.String(32), server_default=sa.text("'pending'")),
        sa.Column("risk_tier", sa.String(32), server_default=sa.text("'low'")),
        sa.Column("priority", sa.Integer, server_default="5"),
        sa.Column("confidence", sa.Float, server_default="0.5"),
        sa.Column("parent_ids", JSONB, server_default=sa.text("'[]'::jsonb")),
        sa.Column("input_data", JSONB, server_default=sa.text("'{}'::jsonb")),
        sa.Column("result", JSONB, server_default=sa.text("'{}'::jsonb")),
        sa.Column("error", sa.Text),
        sa.Column("requires_approval", sa.Boolean, server_default=sa.text("false")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
        sa.Column("started_at", sa.DateTime(timezone=True)),
        sa.Column("completed_at", sa.DateTime(timezone=True)),
    )

    # ── Agent Events ──────────────────────────────────────────────────────────
    op.create_table("agent_events",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("scan_id", UUID, nullable=False),
        sa.Column("workspace_id", UUID, nullable=False),
        sa.Column("event_type", sa.String(100), nullable=False),
        sa.Column("source_agent", sa.String(100), nullable=False),
        sa.Column("payload", JSONB, server_default=sa.text("'{}'::jsonb")),
        sa.Column("confidence", sa.Float, server_default="0.5"),
        sa.Column("requires_human_approval", sa.Boolean, server_default=sa.text("false")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # ── Browser Sessions ─────────────────────────────────────────────────────
    op.create_table("browser_sessions",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("workspace_id", UUID, nullable=False),
        sa.Column("scan_id", UUID, sa.ForeignKey("scan_jobs.id", ondelete="SET NULL"), nullable=True),
        sa.Column("label", sa.String(255)),
        sa.Column("cookies", JSONB, server_default=sa.text("'[]'::jsonb")),
        sa.Column("headers", JSONB, server_default=sa.text("'{}'::jsonb")),
        sa.Column("local_storage", JSONB, server_default=sa.text("'{}'::jsonb")),
        sa.Column("session_storage", JSONB, server_default=sa.text("'{}'::jsonb")),
        sa.Column("screenshot_count", sa.Integer, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # ── API Workflows ─────────────────────────────────────────────────────────
    op.create_table("api_workflows",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("workspace_id", UUID, nullable=False),
        sa.Column("scan_id", UUID, sa.ForeignKey("scan_jobs.id", ondelete="SET NULL"), nullable=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("steps", JSONB, server_default=sa.text("'[]'::jsonb")),
        sa.Column("last_result", JSONB, server_default=sa.text("'{}'::jsonb")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
        sa.Column("last_run_at", sa.DateTime(timezone=True)),
    )

    # ── Replay Sessions ───────────────────────────────────────────────────────
    op.create_table("replay_sessions",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("workspace_id", UUID, nullable=False),
        sa.Column("scan_id", UUID, sa.ForeignKey("scan_jobs.id", ondelete="SET NULL"), nullable=True),
        sa.Column("label", sa.String(255)),
        sa.Column("requests", JSONB, server_default=sa.text("'[]'::jsonb")),
        sa.Column("responses", JSONB, server_default=sa.text("'[]'::jsonb")),
        sa.Column("diff_results", JSONB, server_default=sa.text("'[]'::jsonb")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # ── Strategic Memory ──────────────────────────────────────────────────────
    op.create_table("strategic_memory",
        sa.Column("workspace_id", UUID, primary_key=True),
        sa.Column("program_profile", JSONB, server_default=sa.text("'{}'::jsonb")),
        sa.Column("feedback_log", JSONB, server_default=sa.text("'[]'::jsonb")),
        sa.Column("tech_memory", JSONB, server_default=sa.text("'{}'::jsonb")),
        sa.Column("payload_performance", JSONB, server_default=sa.text("'{}'::jsonb")),
        sa.Column("endpoint_behavior", JSONB, server_default=sa.text("'{}'::jsonb")),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # ── Scan Checkpoints ──────────────────────────────────────────────────────
    op.create_table("scan_checkpoints",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("scan_id", UUID, sa.ForeignKey("scan_jobs.id", ondelete="CASCADE"), nullable=False),
        sa.Column("phase", sa.String(100)),
        sa.Column("progress", sa.Integer, server_default="0"),
        sa.Column("completed_task_ids", JSONB, server_default=sa.text("'[]'::jsonb")),
        sa.Column("partial_results", JSONB, server_default=sa.text("'{}'::jsonb")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
    )

    # ── Worker Heartbeats ─────────────────────────────────────────────────────
    op.create_table("worker_heartbeats",
        sa.Column("worker_id", sa.String(64), primary_key=True),
        sa.Column("hostname", sa.String(255)),
        sa.Column("current_scan_id", sa.String(64)),
        sa.Column("current_task", sa.String(255)),
        sa.Column("tasks_completed", sa.Integer, server_default="0"),
        sa.Column("tasks_failed", sa.Integer, server_default="0"),
        sa.Column("last_seen", sa.Float),
        sa.Column("started_at", sa.Float),
    )

    # Indexes
    op.create_index("idx_agent_tasks_scan_id", "agent_tasks", ["scan_id"])
    op.create_index("idx_agent_events_scan_id", "agent_events", ["scan_id"])
    op.create_index("idx_browser_sessions_ws", "browser_sessions", ["workspace_id"])
    op.create_index("idx_replay_sessions_ws", "replay_sessions", ["workspace_id"])
    op.create_index("idx_scan_checkpoints_scan", "scan_checkpoints", ["scan_id"])


def downgrade():
    for t in ["worker_heartbeats", "scan_checkpoints", "strategic_memory",
              "replay_sessions", "api_workflows", "browser_sessions",
              "agent_events", "agent_tasks"]:
        op.drop_table(t)
