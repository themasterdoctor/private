"""intelligence_tables — Phase 6 intelligence schema."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "173cd281e294"
down_revision = "54aca6331712"
branch_labels = None
depends_on = None

UUID = postgresql.UUID(as_uuid=True)
JSONB = postgresql.JSONB()
now_ = sa.text("now()")
uuid_ = sa.text("uuid_generate_v4()")
empty_ = sa.text("'[]'::jsonb")
emptyobj = sa.text("'{}'::jsonb")


def upgrade():
    op.execute('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"')
    op.create_table("workspace_memory",
        sa.Column("workspace_id", UUID, nullable=False, primary_key=True),
        sa.Column("memory_json", JSONB),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=now_),
    )
    op.create_table("hypotheses",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("scan_id", UUID, sa.ForeignKey("scan_jobs.id", ondelete="CASCADE"), nullable=False),
        sa.Column("workspace_id", UUID, nullable=False),
        sa.Column("title", sa.Text(), nullable=False),
        sa.Column("description", sa.Text()),
        sa.Column("vuln_class", sa.String(64), nullable=False),
        sa.Column("target_url", sa.Text()),
        sa.Column("target_param", sa.String(256)),
        sa.Column("confidence", sa.Float()),
        sa.Column("priority_score", sa.Float()),
        sa.Column("status", sa.String(32)),
        sa.Column("bounty_estimate", sa.String(64)),
        sa.Column("reasoning", sa.Text()),
        sa.Column("evidence", JSONB, server_default=empty_),
        sa.Column("assumptions", JSONB, server_default=empty_),
        sa.Column("test_results", JSONB, server_default=empty_),
        sa.Column("next_tests", JSONB, server_default=empty_),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=now_),
    )
    op.create_table("attack_chains",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("scan_id", UUID, sa.ForeignKey("scan_jobs.id", ondelete="CASCADE"), nullable=False),
        sa.Column("workspace_id", UUID, nullable=False),
        sa.Column("title", sa.Text(), nullable=False),
        sa.Column("chain_probability", sa.Float()),
        sa.Column("chain_impact", sa.String(32)),
        sa.Column("nodes", JSONB, server_default=empty_),
        sa.Column("edges", JSONB, server_default=empty_),
        sa.Column("missing_links", JSONB, server_default=empty_),
        sa.Column("recommended_next_steps", JSONB, server_default=empty_),
        sa.Column("ai_narrative", sa.Text()),
        sa.Column("evidence_quality", sa.Float()),
        sa.Column("estimated_bounty", sa.String(64)),
        sa.Column("owasp_categories", JSONB, server_default=empty_),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
    )
    op.create_table("monitoring_snapshots",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("workspace_id", UUID, nullable=False),
        sa.Column("target", sa.String(256), nullable=False),
        sa.Column("snapshot_json", JSONB),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
    )
    op.create_table("monitoring_alerts",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("workspace_id", UUID, nullable=False),
        sa.Column("target", sa.String(256), nullable=False),
        sa.Column("alert_type", sa.String(64), nullable=False),
        sa.Column("severity", sa.String(32)),
        sa.Column("title", sa.Text()),
        sa.Column("description", sa.Text()),
        sa.Column("old_value", sa.Text()),
        sa.Column("new_value", sa.Text()),
        sa.Column("is_read", sa.Boolean(), server_default=sa.text("false")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
    )
    op.create_table("court_verdicts",
        sa.Column("id", UUID, primary_key=True, server_default=uuid_),
        sa.Column("vuln_id", UUID, sa.ForeignKey("vulnerabilities.id", ondelete="CASCADE"), nullable=False),
        sa.Column("workspace_id", UUID, nullable=False),
        sa.Column("is_valid", sa.Boolean(), server_default=sa.text("true")),
        sa.Column("is_in_scope", sa.Boolean(), server_default=sa.text("true")),
        sa.Column("final_confidence", sa.Float()),
        sa.Column("exploitability_score", sa.Float()),
        sa.Column("bounty_likelihood", sa.Float()),
        sa.Column("duplicate_risk", sa.Float()),
        sa.Column("evidence_quality", sa.Float()),
        sa.Column("severity_recommendation", sa.String(32)),
        sa.Column("downgrade_reason", sa.Text()),
        sa.Column("prosecution_summary", sa.Text()),
        sa.Column("defense_summary", sa.Text()),
        sa.Column("judge_reasoning", sa.Text()),
        sa.Column("recommended_actions", JSONB, server_default=empty_),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=now_),
    )
    for col, typ in [
        ("court_confidence", sa.Float()),
        ("exploitability_score", sa.Float()),
        ("bounty_likelihood", sa.Float()),
        ("reflection_context", sa.String(64)),
        ("waf_detected", sa.String(64)),
        ("simulation_narrative", sa.Text()),
    ]:
        op.add_column("vulnerabilities", sa.Column(col, typ, nullable=True))


def downgrade():
    for col in ["court_confidence","exploitability_score","bounty_likelihood",
                "reflection_context","waf_detected","simulation_narrative"]:
        op.drop_column("vulnerabilities", col)
    for t in ["court_verdicts","monitoring_alerts","monitoring_snapshots",
              "attack_chains","hypotheses","workspace_memory"]:
        op.drop_table(t)
