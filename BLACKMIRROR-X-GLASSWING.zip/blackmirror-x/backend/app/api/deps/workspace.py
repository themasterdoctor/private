"""Workspace isolation dependency.

Provides `verify_workspace_member` FastAPI dependency that confirms
the current authenticated user has membership in the requested workspace.
Prevents cross-workspace data access.
"""
from fastapi import Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.db.session import get_db
from app.models.models import User, Workspace, WorkspaceMember
from app.api.deps.auth import get_current_user


async def verify_workspace_member(
    workspace_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> Workspace:
    """Verify current user is a member of workspace_id.
    
    Returns the Workspace object if member; raises 403 otherwise.
    Admin users bypass the membership check.
    """
    workspace = await db.get(Workspace, workspace_id)
    if not workspace:
        raise HTTPException(status_code=404, detail="Workspace not found")
    if not workspace.is_active:
        raise HTTPException(status_code=403, detail="Workspace is inactive")

    # Admins can access any workspace
    role_val = current_user.role if isinstance(current_user.role, str) else current_user.role.value
    if role_val == "admin":
        return workspace

    # Check membership
    result = await db.execute(
        select(WorkspaceMember).where(
            WorkspaceMember.workspace_id == workspace_id,
            WorkspaceMember.user_id == current_user.id,
        )
    )
    member = result.scalar_one_or_none()
    if not member:
        raise HTTPException(
            status_code=403,
            detail="You are not a member of this workspace",
        )
    return workspace
