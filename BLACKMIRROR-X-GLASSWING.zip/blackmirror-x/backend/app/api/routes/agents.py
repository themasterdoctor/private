"""agents.py"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from typing import List
from pydantic import BaseModel
from datetime import datetime
from typing import Optional

from app.db.session import get_db
from app.models.models import AgentRun, User
from app.api.deps.auth import get_current_user

router = APIRouter()


class AgentRunOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    agent_type: str
    status: str
    input_data: Optional[dict]
    output_data: Optional[dict]
    error: Optional[str]
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    created_at: datetime


@router.get("", response_model=List[AgentRunOut])
async def list_agent_runs(
    workspace_id: str = Query(...),
    scan_id: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(AgentRun).where(AgentRun.workspace_id == workspace_id)
    if scan_id:
        q = q.where(AgentRun.scan_id == scan_id)
    q = q.order_by(desc(AgentRun.created_at)).limit(50)
    result = await db.execute(q)
    return [AgentRunOut.model_validate(r) for r in result.scalars().all()]
