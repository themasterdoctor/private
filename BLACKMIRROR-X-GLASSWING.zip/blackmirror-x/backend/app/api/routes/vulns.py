from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from pydantic import BaseModel
from datetime import datetime

from app.db.session import get_db
from app.models.models import Vulnerability, User, VulnStatus, Severity
from app.api.deps.auth import get_current_user
from app.api.deps.workspace import verify_workspace_member

router = APIRouter()


class VulnOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    scan_id: str
    title: str
    vuln_type: str
    severity: str
    status: str
    cvss_score: Optional[float]
    cwe_id: Optional[str]
    url: Optional[str]
    parameter: Optional[str]
    payload: Optional[str]
    evidence: Optional[str]
    description: Optional[str]
    remediation: Optional[str]
    tags: list
    source: str
    discovered_at: datetime


class VulnUpdate(BaseModel):
    status: Optional[str] = None
    description: Optional[str] = None
    remediation: Optional[str] = None
    cvss_score: Optional[float] = None
    tags: Optional[list] = None


@router.get("", response_model=List[VulnOut])
async def list_vulns(
    workspace_id: str = Query(...),
    scan_id: Optional[str] = Query(None),
    severity: Optional[str] = Query(None),
    vuln_type: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    limit: int = Query(100, le=500),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(Vulnerability).where(Vulnerability.workspace_id == workspace_id)
    if scan_id:
        q = q.where(Vulnerability.scan_id == scan_id)
    if severity:
        q = q.where(Vulnerability.severity == severity)
    if vuln_type:
        q = q.where(Vulnerability.vuln_type == vuln_type)
    if status:
        q = q.where(Vulnerability.status == status)
    q = q.order_by(
        desc(Vulnerability.discovered_at)
    ).limit(limit).offset(offset)
    result = await db.execute(q)
    return [VulnOut.model_validate(v) for v in result.scalars().all()]


@router.get("/{vuln_id}", response_model=VulnOut)
async def get_vuln(
    vuln_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Vulnerability).where(Vulnerability.id == vuln_id))
    v = result.scalar_one_or_none()
    if not v:
        raise HTTPException(404, "Vulnerability not found")
    return VulnOut.model_validate(v)


@router.patch("/{vuln_id}", response_model=VulnOut)
async def update_vuln(
    vuln_id: str,
    data: VulnUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Vulnerability).where(Vulnerability.id == vuln_id))
    v = result.scalar_one_or_none()
    if not v:
        raise HTTPException(404, "Vulnerability not found")

    if data.status:
        v.status = VulnStatus(data.status)
    if data.description is not None:
        v.description = data.description
    if data.remediation is not None:
        v.remediation = data.remediation
    if data.cvss_score is not None:
        v.cvss_score = data.cvss_score
    if data.tags is not None:
        v.tags = data.tags

    return VulnOut.model_validate(v)


@router.get("/{vuln_id}/hackerone-report")
async def get_hackerone_report(
    vuln_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Vulnerability).where(Vulnerability.id == vuln_id))
    v = result.scalar_one_or_none()
    if not v:
        raise HTTPException(404, "Vulnerability not found")

    from app.agents.report_writer.agent import ReportWriterAgent
    agent = ReportWriterAgent()
    report = agent.generate_hackerone_report({
        "title": v.title,
        "vuln_type": v.vuln_type,
        "severity": v.severity.value,
        "cvss_score": v.cvss_score,
        "url": v.url,
        "parameter": v.parameter,
        "payload": v.payload,
        "evidence": v.evidence,
        "description": v.description,
        "remediation": v.remediation,
    })
    return {"content": report, "format": "markdown"}
