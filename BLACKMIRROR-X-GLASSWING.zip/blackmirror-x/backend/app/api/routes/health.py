from fastapi import APIRouter
from datetime import datetime, timezone

router = APIRouter()


@router.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "blackmirror-x",
        "version": "1.0.0",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

from fastapi import APIRouter as _AR
_tool_router = _AR()

@_tool_router.get("/tools")  
async def get_tool_status():
    """Get availability of all external security tools."""
    from app.core.tool_manager import tool_manager
    return tool_manager.get_status()
