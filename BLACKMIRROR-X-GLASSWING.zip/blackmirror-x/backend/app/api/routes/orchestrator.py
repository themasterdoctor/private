"""Orchestrator API routes — /api/v1/orchestrator/*

Endpoints:
  POST /orchestrator/start/{scan_id}     — plan + start orchestrated scan
  GET  /orchestrator/status/{scan_id}    — graph + running status
  GET  /orchestrator/events/{scan_id}    — agent bus events
  GET  /orchestrator/tasks/{scan_id}     — task list
  POST /orchestrator/stop/{scan_id}      — emergency stop
  POST /orchestrator/resume/{scan_id}    — resume stopped scan
  POST /orchestrator/approve/{task_id}   — approve a blocked task
  GET  /orchestrator/pending             — tasks awaiting approval
  GET  /orchestrator/list                — all active orchestrators
"""
from typing import Any
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.db.session import get_db
from app.models.models import ScanJob, User
from app.api.deps.auth import get_current_user
from app.orchestrator.orchestrator import (
    create_orchestrator, get_orchestrator, list_orchestrators
)
from app.orchestrator.agent_bus import bus, EventType

router = APIRouter()


@router.post("/start/{scan_id}")
async def start_orchestrated_scan(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> dict:
    """Plan and start an orchestrated scan using the agent task graph."""
    result = await db.execute(select(ScanJob).where(ScanJob.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")

    config = scan.config or {}
    orch = create_orchestrator(
        scan_id=scan_id,
        workspace_id=str(scan.workspace_id),
        scope_domains=[config.get("domain", "")] if config.get("domain") else [],
    )
    graph = orch.plan_scan(config)

    # Run in background (non-blocking)
    import asyncio
    asyncio.create_task(orch.run())

    return {
        "scan_id": scan_id,
        "message": "Orchestrated scan started",
        "task_count": len(graph),
        "graph_stats": graph.stats,
    }


@router.get("/status/{scan_id}")
async def get_orchestrator_status(
    scan_id: str,
    current_user: User = Depends(get_current_user),
) -> dict:
    orch = get_orchestrator(scan_id)
    if not orch:
        raise HTTPException(status_code=404, detail="No active orchestrator for this scan")
    return orch.get_status()


@router.get("/events/{scan_id}")
async def get_agent_events(
    scan_id: str,
    limit: int = 100,
    current_user: User = Depends(get_current_user),
) -> dict:
    events = bus.get_events(scan_id=scan_id, limit=limit)
    return {
        "scan_id": scan_id,
        "event_count": len(events),
        "events": events,
    }


@router.get("/tasks/{scan_id}")
async def get_task_graph(
    scan_id: str,
    current_user: User = Depends(get_current_user),
) -> dict:
    orch = get_orchestrator(scan_id)
    if not orch:
        raise HTTPException(status_code=404, detail="No active orchestrator for this scan")
    return orch.graph.to_graph()


@router.post("/stop/{scan_id}")
async def stop_scan(
    scan_id: str,
    current_user: User = Depends(get_current_user),
) -> dict:
    orch = get_orchestrator(scan_id)
    if not orch:
        raise HTTPException(status_code=404, detail="Orchestrator not found")
    orch.stop()
    return {"scan_id": scan_id, "status": "stopped"}


@router.post("/resume/{scan_id}")
async def resume_scan(
    scan_id: str,
    current_user: User = Depends(get_current_user),
) -> dict:
    orch = get_orchestrator(scan_id)
    if not orch:
        raise HTTPException(status_code=404, detail="Orchestrator not found")
    orch.resume()
    return {"scan_id": scan_id, "status": "resumed"}


@router.post("/approve/{task_id}")
async def approve_task(
    task_id: str,
    current_user: User = Depends(get_current_user),
) -> dict:
    # Approve across all active orchestrators
    for orch_status in list_orchestrators():
        scan_id = orch_status.get("scan_id", "")
        orch = get_orchestrator(scan_id)
        if orch:
            orch.policy.approval.approve(scan_id, task_id)
    await bus.approve(task_id)
    return {"task_id": task_id, "status": "approved"}


@router.get("/pending")
async def get_pending_approvals(
    current_user: User = Depends(get_current_user),
) -> dict:
    pending = bus.get_pending_approvals()
    return {"pending_count": len(pending), "items": pending}


@router.get("/list")
async def list_active_orchestrators(
    current_user: User = Depends(get_current_user),
) -> dict:
    items = list_orchestrators()
    return {"count": len(items), "orchestrators": items}


@router.get("/bus/stats")
async def get_bus_stats(
    current_user: User = Depends(get_current_user),
) -> dict:
    return bus.stats
