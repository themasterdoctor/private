"""websocket.py — WebSocket streaming for scan logs and live updates."""
import asyncio
import json
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.db.session import AsyncSessionLocal
from app.models.models import ScanLog, ScanJob, ScanStatus

router = APIRouter()


class ConnectionManager:
    def __init__(self):
        self.connections: dict[str, list[WebSocket]] = {}

    async def connect(self, scan_id: str, ws: WebSocket):
        await ws.accept()
        self.connections.setdefault(scan_id, []).append(ws)

    def disconnect(self, scan_id: str, ws: WebSocket):
        if scan_id in self.connections:
            self.connections[scan_id] = [c for c in self.connections[scan_id] if c != ws]

    async def broadcast(self, scan_id: str, message: dict):
        dead = []
        for ws in self.connections.get(scan_id, []):
            try:
                await ws.send_json(message)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(scan_id, ws)


manager = ConnectionManager()


@router.websocket("/scan/{scan_id}")
async def scan_websocket(ws: WebSocket, scan_id: str):
    await manager.connect(scan_id, ws)
    last_log_id = None

    try:
        while True:
            async with AsyncSessionLocal() as db:
                # Send new logs
                from datetime import datetime, timezone
                q = select(ScanLog).where(ScanLog.scan_id == scan_id)
                if last_log_id:
                    # Use created_at for ordered sequential streaming
                    q = q.where(ScanLog.created_at > last_log_id)
                q = q.order_by(ScanLog.created_at).limit(50)
                result = await db.execute(q)
                logs = result.scalars().all()

                for log in logs:
                    last_log_id = log.created_at  # track by timestamp
                    await ws.send_json({
                        "type": "log",
                        "id": str(log.id),
                        "level": log.level,
                        "module": log.module,
                        "message": log.message,
                        "timestamp": log.created_at.isoformat(),
                    })

                # Check scan status
                r = await db.execute(select(ScanJob).where(ScanJob.id == scan_id))
                scan = r.scalar_one_or_none()
                if scan:
                    await ws.send_json({
                        "type": "status",
                        "status": scan.status.value,
                        "progress": scan.progress,
                    })
                    if scan.status in (ScanStatus.COMPLETED, ScanStatus.FAILED, ScanStatus.CANCELLED):
                        await ws.send_json({"type": "done", "status": scan.status.value})
                        break

            await asyncio.sleep(1)

    except WebSocketDisconnect:
        manager.disconnect(scan_id, ws)
