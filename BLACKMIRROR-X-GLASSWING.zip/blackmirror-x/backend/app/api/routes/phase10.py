"""Phase 10 API Routes — browser-intel, api-intel, chains, replay, memory, workers.

All routes use graceful degradation — if a dependency is unavailable
(playwright, httpx, etc.) the endpoint returns a capability status response
rather than a 500 error.
"""
from typing import Any
from fastapi import APIRouter, Depends, HTTPException, Body
from pydantic import BaseModel

from app.models.models import User
from app.api.deps.auth import get_current_user

# ── Browser Intelligence ─────────────────────────────────────────────────────

browser_router = APIRouter()


@browser_router.get("/status")
async def browser_status(current_user: User = Depends(get_current_user)) -> dict:
    from app.browser.session_manager import session_manager
    return session_manager.capability_status


@browser_router.post("/sessions")
async def create_browser_session(
    label: str = "",
    cookies: list | None = None,
    headers: dict | None = None,
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.browser.session_manager import session_manager
    session = await session_manager.create_session(
        label=label, cookies=cookies or [], headers=headers or {},
    )
    return session.to_dict()


@browser_router.get("/sessions")
async def list_browser_sessions(
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.browser.session_manager import session_manager
    return {"sessions": session_manager.list_sessions()}


@browser_router.post("/screenshot")
async def take_screenshot(
    url: str,
    session_id: str = "",
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.browser.session_manager import session_manager, PLAYWRIGHT_AVAILABLE
    if not PLAYWRIGHT_AVAILABLE:
        return {"error": "Playwright not available", "fix": "playwright install chromium"}
    b64 = await session_manager.screenshot(session_id, url)
    return {"url": url, "screenshot_b64": b64[:100] + "..." if b64 else "",
            "captured": bool(b64)}


@browser_router.post("/dom-snapshot")
async def dom_snapshot(
    url: str,
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.browser.dom_monitor import snapshot_dom
    snapshot = await snapshot_dom(url)
    return snapshot.to_dict()


@browser_router.post("/spa-routes")
async def map_spa(
    url: str,
    js_content: str | None = None,
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.browser.spa_mapper import map_spa_routes
    return await map_spa_routes(url, js_content=js_content)


@browser_router.post("/ws-capture")
async def capture_ws(
    url: str,
    duration_ms: int = 3000,
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.browser.ws_capture import capture_websockets, PLAYWRIGHT_AVAILABLE
    if not PLAYWRIGHT_AVAILABLE:
        return {"error": "Playwright not available", "captures": []}
    captures = await capture_websockets(url, duration_ms=duration_ms)
    return {"url": url, "capture_count": len(captures),
            "captures": [c.to_dict() for c in captures]}


# ── API Intelligence ─────────────────────────────────────────────────────────

api_intel_router = APIRouter()


class ObserveRequestModel(BaseModel):
    method: str
    url: str
    response: dict | list | None = None
    user_context: str = ""


@api_intel_router.post("/observe")
async def observe_api_request(
    data: ObserveRequestModel,
    workspace_id: str = "",
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.api_intel.object_mapper import ObjectMapper
    # Use per-workspace mapper (simplified: new mapper per call)
    mapper = ObjectMapper()
    mapper.observe_request(data.method, data.url, data.response or {},
                           data.user_context)
    candidates = mapper.generate_idor_candidates()
    return {
        "object_map": mapper.get_object_map(),
        "idor_candidates": [c.to_dict() for c in candidates],
    }


@api_intel_router.post("/role-diff")
async def run_role_diff(
    urls: list[str] = Body(...),
    tokens: dict[str, str] = Body(...),   # {"admin": "tok1", "user": "tok2"}
    base_url: str = Body(""),
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.api_intel.role_diff import RoleCredential, diff_roles, summarize_diff_results
    roles = [RoleCredential(role_name=name, token=tok)
             for name, tok in tokens.items()]
    if len(roles) < 2:
        raise HTTPException(400, "Need at least 2 role tokens for diff")
    pairs = [(roles[i], roles[j]) for i in range(len(roles))
             for j in range(i+1, len(roles))]
    results = await diff_roles(urls, pairs, base_url=base_url)
    return summarize_diff_results(results)


@api_intel_router.post("/graphql-analyze")
async def analyze_gql(
    url: str,
    headers: dict | None = None,
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.api_intel.graphql_analyzer import analyze_graphql
    return await analyze_graphql(url, headers=headers)


@api_intel_router.post("/openapi-analyze")
async def analyze_openapi(
    spec_url: str | None = None,
    spec: dict | None = None,
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.api_intel.openapi_analyzer import fetch_and_analyze, analyze_openapi_spec
    if spec:
        return analyze_openapi_spec(spec)
    if spec_url:
        return await fetch_and_analyze(spec_url)
    raise HTTPException(400, "Provide either spec_url or spec body")


@api_intel_router.post("/workflow-replay")
async def workflow_replay(
    steps: list[dict] = Body(...),
    initial_vars: dict[str, str] = Body({}),
    base_url: str = Body(""),
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.api_intel.workflow_replay import WorkflowStep, replay_workflow
    workflow_steps = [WorkflowStep(**s) for s in steps]
    return await replay_workflow(workflow_steps, initial_vars, base_url)


# ── Attack Chains ────────────────────────────────────────────────────────────

chains_router = APIRouter()


@chains_router.post("/build/{scan_id}")
async def build_chains(
    scan_id: str,
    workspace_id: str,
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.chain.graph_reasoner import GraphReasoner
    from app.chain.chain_ranker import rank_chains, analyze_proof_gaps
    # In production: load vulns from DB for this scan
    # Here: return capability demonstration
    reasoner = GraphReasoner()
    chains_raw = reasoner.build_chains([])  # no vulns yet
    chain_dicts = [c.to_dict() for c in chains_raw]
    ranked = rank_chains(chain_dicts)
    gaps = analyze_proof_gaps(chain_dicts)
    return {
        "scan_id": scan_id,
        "chains": ranked,
        "proof_gaps": [g.to_dict() for g in gaps],
    }


@chains_router.post("/build-from-vulns")
async def build_chains_from_vulns(
    vulns: list[dict] = Body(...),
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.chain.graph_reasoner import GraphReasoner
    from app.chain.chain_ranker import rank_chains, analyze_proof_gaps
    from app.chain.chain_reporter import chain_to_hackerone_report, chain_to_executive_summary
    reasoner = GraphReasoner()
    chains_raw = reasoner.build_chains(vulns)
    chain_dicts = [c.to_dict() for c in chains_raw]
    ranked = rank_chains(chain_dicts)
    gaps = analyze_proof_gaps(chain_dicts)
    exec_summary = chain_to_executive_summary(chain_dicts)
    return {
        "chains": ranked,
        "proof_gaps": [g.to_dict() for g in gaps],
        "executive_summary": exec_summary,
    }


@chains_router.get("/report/{chain_id}")
async def chain_report(
    chain_id: str,
    current_user: User = Depends(get_current_user),
) -> dict:
    return {"chain_id": chain_id, "report": "Chain not found — use /build-from-vulns first"}


# ── Replay Lab ────────────────────────────────────────────────────────────────

replay_router = APIRouter()


@replay_router.post("/replay")
async def http_replay(
    method: str,
    url: str,
    headers: dict | None = None,
    body: str | None = None,
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.replay.http_replay import ReplayRequest, replay_request
    req = ReplayRequest(method=method, url=url,
                        headers=headers or {}, body=body or "")
    resp = await replay_request(req)
    return {"request": req.to_dict(), "response": resp.to_dict(),
            "curl": req.to_curl()}


@replay_router.post("/har/import")
async def import_har(
    har: dict = Body(...),
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.replay.http_replay import parse_har
    requests = parse_har(har)
    return {"imported": len(requests),
            "requests": [r.to_dict() for r in requests[:20]]}


@replay_router.post("/har/export")
async def export_har(
    requests: list[dict] = Body(...),
    responses: list[dict] = Body([]),
    current_user: User = Depends(get_current_user),
) -> dict:
    # Simple passthrough — real export needs actual ReplayRequest objects
    return {"har": {"log": {"version": "1.2", "entries": []}},
            "note": "Build requests via /replay then export"}


@replay_router.post("/diff")
async def diff_responses(
    url: str,
    request_a: dict = Body(...),
    request_b: dict = Body(...),
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.replay.http_replay import (ReplayRequest, replay_request,
                                         diff_responses as do_diff)
    req_a = ReplayRequest(**{k: request_a.get(k, "") for k in
                            ("method", "url", "body")},
                          headers=request_a.get("headers", {}))
    req_b = ReplayRequest(**{k: request_b.get(k, "") for k in
                            ("method", "url", "body")},
                          headers=request_b.get("headers", {}))
    resp_a = await replay_request(req_a)
    resp_b = await replay_request(req_b)
    diff = do_diff(resp_a, resp_b)
    return diff.to_dict()


# ── Strategic Memory ─────────────────────────────────────────────────────────

memory_router = APIRouter()


@memory_router.get("/{workspace_id}")
async def get_strategic_memory(
    workspace_id: str,
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.memory.strategic_memory import get_memory
    mem = get_memory(workspace_id)
    return mem.to_summary()


@memory_router.post("/{workspace_id}/program")
async def set_program_profile(
    workspace_id: str,
    program_name: str,
    in_scope: list[str] = Body([]),
    out_of_scope: list[str] = Body([]),
    bounty_table: dict[str, str] = Body({}),
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.memory.strategic_memory import get_memory, ProgramProfile
    mem = get_memory(workspace_id)
    mem.set_program(ProgramProfile(
        program_name=program_name,
        in_scope=in_scope,
        out_of_scope=out_of_scope,
        bounty_table=bounty_table,
    ))
    return {"status": "updated", "program": mem.program.to_dict()}


@memory_router.post("/{workspace_id}/feedback")
async def record_finding_feedback(
    workspace_id: str,
    finding_id: str,
    vuln_type: str,
    severity: str,
    outcome: str,
    reason: str = "",
    bounty_paid: str = "",
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.memory.strategic_memory import get_memory, FindingFeedback
    mem = get_memory(workspace_id)
    mem.record_feedback(FindingFeedback(
        finding_id=finding_id, vuln_type=vuln_type,
        severity=severity, outcome=outcome,
        reason=reason, bounty_paid=bounty_paid,
    ))
    return {"status": "recorded", "outcome": outcome}


@memory_router.get("/{workspace_id}/rejected-patterns")
async def rejected_patterns(
    workspace_id: str,
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.memory.strategic_memory import get_memory
    mem = get_memory(workspace_id)
    return {"patterns": mem.get_rejection_patterns()}


@memory_router.get("/{workspace_id}/accepted-patterns")
async def accepted_patterns(
    workspace_id: str,
    current_user: User = Depends(get_current_user),
) -> dict:
    from app.memory.strategic_memory import get_memory
    mem = get_memory(workspace_id)
    return {"patterns": mem.get_accepted_patterns()}


# ── Workers / Control Plane ──────────────────────────────────────────────────

workers_router = APIRouter()


@workers_router.get("/status")
async def worker_status(current_user: User = Depends(get_current_user)) -> dict:
    from app.execution.control_plane import control_plane, heartbeat_monitor
    return {
        "control": control_plane.get_status(),
        "workers": heartbeat_monitor.get_all(),
    }


@workers_router.post("/emergency-stop")
async def emergency_stop(current_user: User = Depends(get_current_user)) -> dict:
    from app.execution.control_plane import control_plane
    control_plane.emergency_stop_all()
    return {"status": "emergency_stop_activated"}


@workers_router.post("/resume-all")
async def resume_all(current_user: User = Depends(get_current_user)) -> dict:
    from app.execution.control_plane import control_plane
    control_plane.resume_all()
    return {"status": "resumed"}


@workers_router.post("/pause/{scan_id}")
async def pause_scan(
    scan_id: str, current_user: User = Depends(get_current_user),
) -> dict:
    from app.execution.control_plane import control_plane
    control_plane.pause_scan(scan_id)
    return {"scan_id": scan_id, "status": "paused"}


@workers_router.post("/resume/{scan_id}")
async def resume_scan(
    scan_id: str, current_user: User = Depends(get_current_user),
) -> dict:
    from app.execution.control_plane import control_plane
    control_plane.resume_scan(scan_id)
    return {"scan_id": scan_id, "status": "resumed"}


@workers_router.get("/checkpoints/{scan_id}")
async def get_checkpoints(
    scan_id: str, current_user: User = Depends(get_current_user),
) -> dict:
    from app.execution.control_plane import checkpoint_store
    latest = checkpoint_store.load_latest(scan_id)
    return {"scan_id": scan_id, "latest_checkpoint": latest.to_dict() if latest else None}
