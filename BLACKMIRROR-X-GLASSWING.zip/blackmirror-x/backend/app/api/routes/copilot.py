from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import json
import structlog

from app.db.session import get_db
from app.models.models import User, CopilotMessage
from app.api.deps.auth import get_current_user
from app.agents.copilot.agent import CopilotAgent
from app.schemas.copilot import CopilotRequest, CopilotSessionOut, MessageOut

router = APIRouter()
logger = structlog.get_logger(__name__)


@router.post("/chat/stream")
async def copilot_stream(
    data: CopilotRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Stream copilot response via SSE."""

    # Save user message
    user_msg = CopilotMessage(
        workspace_id=data.workspace_id,
        user_id=current_user.id,
        session_id=data.session_id,
        role="user",
        content=data.message,
        context=data.context,
    )
    db.add(user_msg)
    await db.flush()

    # Fetch conversation history
    history_q = (
        select(CopilotMessage)
        .where(
            CopilotMessage.session_id == data.session_id,
            CopilotMessage.workspace_id == data.workspace_id,
        )
        .order_by(CopilotMessage.created_at)
        .limit(20)
    )
    history_result = await db.execute(history_q)
    history = history_result.scalars().all()

    agent = CopilotAgent()

    async def generate():
        full_response = ""
        try:
            async for chunk in agent.stream(
                message=data.message,
                history=[{"role": m.role, "content": m.content} for m in history[:-1]],
                context=data.context or {},
                workspace_id=data.workspace_id,
            ):
                full_response += chunk
                yield f"data: {json.dumps({'type': 'chunk', 'content': chunk})}\n\n"

            # Save assistant response
            async with AsyncSession(db.bind) as session:
                assistant_msg = CopilotMessage(
                    workspace_id=data.workspace_id,
                    user_id=current_user.id,
                    session_id=data.session_id,
                    role="assistant",
                    content=full_response,
                )
                session.add(assistant_msg)
                await session.commit()

            yield f"data: {json.dumps({'type': 'done'})}\n\n"

        except Exception as e:
            logger.error("copilot_stream_error", error=str(e))
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.get("/sessions/{session_id}/messages")
async def get_session_messages(
    session_id: str,
    workspace_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = (
        select(CopilotMessage)
        .where(
            CopilotMessage.session_id == session_id,
            CopilotMessage.workspace_id == workspace_id,
        )
        .order_by(CopilotMessage.created_at)
    )
    result = await db.execute(q)
    messages = result.scalars().all()
    return [MessageOut.model_validate(m) for m in messages]
