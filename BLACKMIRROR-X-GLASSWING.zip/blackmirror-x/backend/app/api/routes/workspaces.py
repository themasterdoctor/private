"""workspaces.py — Workspace management routes"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import re

from app.db.session import get_db
from app.models.models import Workspace, WorkspaceMember, User, UserRole
from app.api.deps.auth import get_current_user
from pydantic import BaseModel

router = APIRouter()


class WorkspaceCreate(BaseModel):
    name: str
    description: Optional[str] = None


class WorkspaceOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    name: str
    slug: str
    description: Optional[str]
    is_active: bool


@router.post("", response_model=WorkspaceOut, status_code=201)
async def create_workspace(
    data: WorkspaceCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    slug = re.sub(r"[^a-z0-9-]", "-", data.name.lower().strip()).strip("-")
    slug = re.sub(r"-+", "-", slug)

    # Check slug uniqueness
    existing = await db.execute(select(Workspace).where(Workspace.slug == slug))
    if existing.scalar_one_or_none():
        slug = f"{slug}-{current_user.id[:6]}"

    ws = Workspace(name=data.name, slug=slug, description=data.description)
    db.add(ws)
    await db.flush()

    # Add creator as admin
    member = WorkspaceMember(workspace_id=ws.id, user_id=current_user.id, role=UserRole.ADMIN)
    db.add(member)
    return ws


@router.get("", response_model=List[WorkspaceOut])
async def list_workspaces(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = (
        select(Workspace)
        .join(WorkspaceMember, Workspace.id == WorkspaceMember.workspace_id)
        .where(WorkspaceMember.user_id == current_user.id, Workspace.is_active == True)
    )
    result = await db.execute(q)
    return [WorkspaceOut.model_validate(ws) for ws in result.scalars().all()]


@router.get("/{workspace_id}", response_model=WorkspaceOut)
async def get_workspace(
    workspace_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Workspace).where(Workspace.id == workspace_id))
    ws = result.scalar_one_or_none()
    if not ws:
        raise HTTPException(404, "Workspace not found")
    return ws
