from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from pydantic import BaseModel
from datetime import datetime

from app.db.session import get_db
from app.models.models import Subdomain, DiscoveredURL, User
from app.api.deps.auth import get_current_user

router = APIRouter()


class SubdomainOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    host: str
    ip_addresses: list
    is_alive: bool
    status_code: Optional[int]
    title: Optional[str]
    tech_stack: list
    ports: list
    source: str
    discovered_at: datetime


class URLOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    url: str
    method: str
    status_code: Optional[int]
    content_type: Optional[str]
    parameters: list
    is_interesting: bool
    interest_reasons: list
    source: str
    discovered_at: datetime


@router.get("/subdomains", response_model=List[SubdomainOut])
async def list_subdomains(
    workspace_id: str = Query(...),
    scan_id: Optional[str] = Query(None),
    alive_only: bool = Query(False),
    limit: int = Query(200, le=1000),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(Subdomain).where(Subdomain.workspace_id == workspace_id)
    if scan_id:
        q = q.where(Subdomain.scan_id == scan_id)
    if alive_only:
        q = q.where(Subdomain.is_alive == True)
    q = q.order_by(desc(Subdomain.discovered_at)).limit(limit).offset(offset)
    result = await db.execute(q)
    return [SubdomainOut.model_validate(s) for s in result.scalars().all()]


@router.get("/urls", response_model=List[URLOut])
async def list_urls(
    workspace_id: str = Query(...),
    scan_id: Optional[str] = Query(None),
    interesting_only: bool = Query(False),
    limit: int = Query(200, le=1000),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(DiscoveredURL).where(DiscoveredURL.workspace_id == workspace_id)
    if scan_id:
        q = q.where(DiscoveredURL.scan_id == scan_id)
    if interesting_only:
        q = q.where(DiscoveredURL.is_interesting == True)
    q = q.order_by(desc(DiscoveredURL.discovered_at)).limit(limit).offset(offset)
    result = await db.execute(q)
    return [URLOut.model_validate(u) for u in result.scalars().all()]
