from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
import json
import asyncio
import structlog

from app.db.session import get_db
from app.models.models import ScanJob, ScanLog, User, ScanStatus, ScanType
from app.api.deps.auth import get_current_user
from app.api.deps.workspace import verify_workspace_member
from app.schemas.scans import ScanCreateRequest, ScanOut, ScanLogOut, ScanListOut
from app.workers.tasks import run_scan_task

router = APIRouter()
logger = structlog.get_logger(__name__)


@router.post("", response_model=ScanOut, status_code=201)
async def create_scan(
    data: ScanCreateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    scan = ScanJob(
        workspace_id=data.workspace_id,
        target_id=data.target_id,
        created_by=current_user.id,
        name=data.name,
        scan_type=ScanType(data.scan_type),
        config=data.config or {},
        status=ScanStatus.QUEUED,
    )
    db.add(scan)
    await db.flush()

    # Queue celery task
    task = run_scan_task.apply_async(
        args=[scan.id],
        queue="scans",
        task_id=f"scan_{scan.id}",
    )
    scan.celery_task_id = task.id

    logger.info("scan_created", scan_id=scan.id, type=data.scan_type)
    return ScanOut.model_validate(scan)


@router.get("", response_model=List[ScanListOut])
async def list_scans(
    workspace_id: str = Query(...),
    status: Optional[str] = Query(None),
    limit: int = Query(50, le=200),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(ScanJob).where(ScanJob.workspace_id == workspace_id)
    if status:
        q = q.where(ScanJob.status == status)
    q = q.order_by(desc(ScanJob.created_at)).limit(limit).offset(offset)
    result = await db.execute(q)
    return [ScanListOut.model_validate(s) for s in result.scalars().all()]


@router.get("/{scan_id}", response_model=ScanOut)
async def get_scan(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(ScanJob).where(ScanJob.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    return ScanOut.model_validate(scan)


@router.post("/{scan_id}/cancel")
async def cancel_scan(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(ScanJob).where(ScanJob.id == scan_id))
    scan = result.scalar_one_or_none()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    if scan.status not in (ScanStatus.QUEUED, ScanStatus.RUNNING):
        raise HTTPException(status_code=400, detail="Scan cannot be cancelled")

    # Revoke celery task
    if scan.celery_task_id:
        from app.workers.celery_app import celery_app
        celery_app.control.revoke(scan.celery_task_id, terminate=True)

    scan.status = ScanStatus.CANCELLED
    return {"status": "cancelled"}


@router.get("/{scan_id}/logs", response_model=List[ScanLogOut])
async def get_scan_logs(
    scan_id: str,
    limit: int = Query(200, le=1000),
    since_id: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = select(ScanLog).where(ScanLog.scan_id == scan_id)
    q = q.order_by(ScanLog.timestamp).limit(limit)
    result = await db.execute(q)
    return [ScanLogOut.model_validate(l) for l in result.scalars().all()]


@router.get("/{scan_id}/stream")
async def stream_scan_logs(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """SSE endpoint to stream live scan logs."""
    async def event_generator():
        last_id = None
        while True:
            q = select(ScanLog).where(ScanLog.scan_id == scan_id)
            if last_id:
                q = q.where(ScanLog.id > last_id)
            q = q.order_by(ScanLog.timestamp).limit(50)

            async with AsyncSession(db.bind) as session:
                result = await session.execute(q)
                logs = result.scalars().all()

            for log in logs:
                last_id = log.id
                data = json.dumps({
                    "id": log.id,
                    "level": log.level,
                    "module": log.module,
                    "message": log.message,
                    "timestamp": log.timestamp.isoformat(),
                })
                yield f"data: {data}\n\n"

            # Check if scan is done
            async with AsyncSession(db.bind) as session:
                r = await session.execute(select(ScanJob).where(ScanJob.id == scan_id))
                scan = r.scalar_one_or_none()
                if scan and scan.status in (ScanStatus.COMPLETED, ScanStatus.FAILED, ScanStatus.CANCELLED):
                    yield f"data: {json.dumps({'type': 'done', 'status': scan.status.value})}\n\n"
                    break

            await asyncio.sleep(1)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
