"""Intelligence layer API routes."""
from __future__ import annotations

import asyncio
import json
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.db.session import get_db
from app.models.models import User, ScanJob, Vulnerability, Subdomain, DiscoveredURL
from app.api.deps.auth import get_current_user
from app.intelligence.hypothesis.engine import HypothesisEngine, Hypothesis
from app.intelligence.court.validation_court import ValidationCourt
from app.intelligence.memory.workspace_memory import WorkspaceMemoryService
from app.intelligence.simulator.exploitability import ExploitabilitySimulator
from app.intelligence.payloads.payload_intel import PayloadIntelligenceSystem
from app.intelligence.reasoning import ReasoningAgentBase
from app.core.logging import get_logger

router = APIRouter()
logger = get_logger(__name__)


# ─── Hypothesis Engine ────────────────────────────────────────────────────────

class HypothesisRequest(BaseModel):
    scan_id: str
    workspace_id: str


@router.post("/hypotheses/generate/{scan_id}")
async def generate_hypotheses(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Generate vulnerability hypotheses for a scan."""
    # Fetch scan data
    scan = await db.get(ScanJob, scan_id)
    if not scan:
        raise HTTPException(404, "Scan not found")

    subs_result = await db.execute(
        select(Subdomain).where(Subdomain.scan_id == scan_id).limit(200)
    )
    subdomains = subs_result.scalars().all()

    urls_result = await db.execute(
        select(DiscoveredURL).where(DiscoveredURL.scan_id == scan_id).limit(500)
    )
    urls = urls_result.scalars().all()

    # Gather technologies
    technologies: list[str] = []
    for sub in subdomains:
        if sub.tech_stack:
            technologies.extend(sub.tech_stack)

    engine = HypothesisEngine(scan_id=scan_id, workspace_id=str(scan.workspace_id))

    # Gather all params from URLs
    params: list[str] = []
    from urllib.parse import urlparse, parse_qs
    for url_obj in urls:
        try:
            parsed = urlparse(url_obj.url)
            params.extend(parse_qs(parsed.query).keys())
        except Exception:
            pass

    hypotheses = engine.form_hypotheses_from_signals(
        urls=[u.url for u in urls],
        params=list(set(params)),
        technologies=list(set(technologies)),
        headers={},
        existing_vulns=[],
    )

    # AI ranking
    target_ctx = {
        "target": scan.config.get("domain", scan.config.get("target", "unknown")),
        "technologies": list(set(technologies)),
        "subdomain_count": len(subdomains),
        "url_count": len(urls),
    }
    hypotheses = await engine.ai_rank_hypotheses(hypotheses, target_ctx)

    return {
        "scan_id": scan_id,
        "hypotheses": [h.to_dict() for h in hypotheses],
        "reasoning_steps": [s.to_dict() for s in engine.trace.steps],
        "total_confidence": engine.trace.overall_confidence,
    }


@router.get("/hypotheses/stream/{scan_id}")
async def stream_hypothesis_reasoning(
    scan_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """SSE stream of hypothesis reasoning."""
    # Run hypothesis engine and stream reasoning
    scan = await db.get(ScanJob, scan_id)
    if not scan:
        raise HTTPException(404, "Scan not found")

    async def generate():
        import asyncio as _aio
        engine = HypothesisEngine(scan_id=scan_id, workspace_id=str(scan.workspace_id))
        queue: asyncio.Queue = asyncio.Queue()

        def on_step_callback(step):
            asyncio.get_event_loop().call_soon_threadsafe(queue.put_nowait, step)

        engine.on_step(on_step_callback)

        yield f"data: {json.dumps({'type': 'start', 'scan_id': scan_id})}\n\n"

        # Run engine in background
        async def run_engine():
            subs_result = await db.execute(
                select(Subdomain).where(Subdomain.scan_id == scan_id).limit(200)
            )
            subs = subs_result.scalars().all()
            urls_result = await db.execute(
                select(DiscoveredURL).where(DiscoveredURL.scan_id == scan_id).limit(500)
            )
            urls = urls_result.scalars().all()
            from urllib.parse import urlparse, parse_qs
            params = []
            for u in urls:
                try: params.extend(parse_qs(urlparse(u.url).query).keys())
                except: pass
            techs = []
            for s in subs:
                techs.extend(s.tech_stack or [])
            engine.form_hypotheses_from_signals(
                urls=[u.url for u in urls], params=list(set(params)),
                technologies=list(set(techs)), headers={}, existing_vulns=[]
            )
            await queue.put(None)  # sentinel

        task = asyncio.create_task(run_engine())

        while True:
            try:
                item = await asyncio.wait_for(queue.get(), timeout=30.0)
                if item is None:
                    break
                yield item.to_sse()
            except asyncio.TimeoutError:
                break

        yield f"data: {json.dumps({'type': 'complete', 'confidence': engine.trace.overall_confidence})}\n\n"

    return StreamingResponse(generate(), media_type="text/event-stream")


# ─── Validation Court ────────────────────────────────────────────────────────

@router.post("/court/adjudicate/{vuln_id}")
async def adjudicate_vulnerability(
    vuln_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Run the 5-agent validation court for a vulnerability."""
    vuln = await db.get(Vulnerability, vuln_id)
    if not vuln:
        raise HTTPException(404, "Vulnerability not found")

    # Get workspace memory for context
    memory = await WorkspaceMemoryService.get_memory_for_api(
        str(vuln.workspace_id), db
    )

    court = ValidationCourt(
        scan_id=str(vuln.scan_id),
        workspace_id=str(vuln.workspace_id),
    )

    vuln_dict = {
        "id": str(vuln.id),
        "title": vuln.title,
        "vuln_type": vuln.vuln_type,
        "severity": vuln.severity,
        "url": vuln.url,
        "parameter": vuln.parameter,
        "payload": vuln.payload,
        "description": vuln.description,
        "evidence": vuln.evidence,
        "reproduction_steps": vuln.reproduction_steps,
        "remediation": vuln.remediation,
        "cvss_score": vuln.cvss_score,
        "cwe_id": vuln.cwe_id,
    }

    verdict = await court.adjudicate(vuln_dict, memory_context=memory)

    # Apply verdict — update severity if downgraded
    if verdict.downgrade_reason and verdict.severity_recommendation != vuln.severity:
        vuln.severity = verdict.severity_recommendation
        await db.commit()

    return {
        "vuln_id": vuln_id,
        "verdict": {
            "is_valid": verdict.is_valid,
            "is_in_scope": verdict.is_in_scope,
            "final_confidence": verdict.final_confidence,
            "exploitability_score": verdict.exploitability_score,
            "bounty_likelihood": verdict.bounty_likelihood,
            "duplicate_risk": verdict.duplicate_risk,
            "evidence_quality": verdict.evidence_quality,
            "severity_recommendation": verdict.severity_recommendation,
            "downgrade_reason": verdict.downgrade_reason,
            "prosecution_summary": verdict.prosecution_summary,
            "defense_summary": verdict.defense_summary,
            "scope_verdict": verdict.scope_verdict,
            "evidence_verdict": verdict.evidence_verdict,
            "judge_reasoning": verdict.judge_reasoning,
            "recommended_actions": verdict.recommended_actions,
        },
        "reasoning_steps": [s.to_dict() for s in court.trace.steps],
    }


# ─── Workspace Memory ────────────────────────────────────────────────────────

@router.get("/memory/{workspace_id}")
async def get_workspace_memory(
    workspace_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Get workspace intelligence memory."""
    return await WorkspaceMemoryService.get_memory_for_api(workspace_id, db)


@router.post("/memory/{workspace_id}/false-positive")
async def add_false_positive(
    workspace_id: str,
    data: dict[str, str],
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Record a false positive signature."""
    mem = await WorkspaceMemoryService.load(workspace_id, db)
    sig = data.get("signature", "")
    if sig and sig not in mem.false_positive_signatures:
        mem.false_positive_signatures.append(sig)
        await WorkspaceMemoryService.save(mem, db)
    return {"status": "recorded", "signature": sig}


# ─── Exploitability Simulation ───────────────────────────────────────────────

@router.post("/simulate/{vuln_id}")
async def simulate_exploitability(
    vuln_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Run exploitability simulation for a vulnerability."""
    vuln = await db.get(Vulnerability, vuln_id)
    if not vuln:
        raise HTTPException(404, "Vulnerability not found")

    simulator = ExploitabilitySimulator(
        scan_id=str(vuln.scan_id),
        workspace_id=str(vuln.workspace_id),
    )

    vuln_dict = {
        "id": str(vuln.id),
        "vuln_type": vuln.vuln_type,
        "severity": vuln.severity,
        "url": vuln.url,
        "description": vuln.description,
    }

    report = simulator.simulate(vuln_dict)
    report = await simulator.simulate_with_ai_narrative(vuln_dict, report)

    return {
        "vuln_id": vuln_id,
        "simulation": {
            "account_takeover_likelihood": report.account_takeover_likelihood,
            "data_exposure_scale": report.data_exposure_scale,
            "lateral_movement_potential": report.lateral_movement_potential,
            "cloud_compromise_potential": report.cloud_compromise_potential,
            "privilege_escalation_probability": report.privilege_escalation_probability,
            "overall_impact_score": report.overall_impact_score(),
            "business_impact_score": report.business_impact_score,
            "cvss_v3_estimate": report.cvss_v3_estimate,
            "recommended_severity": report.recommended_severity,
            "bounty_range_estimate": report.bounty_range_estimate,
            "affected_users_estimate": report.affected_users_estimate,
            "data_types_at_risk": report.data_types_at_risk,
            "attack_chain_steps": report.attack_chain_steps,
            "prerequisites": report.prerequisites,
            "time_to_exploit_estimate": report.time_to_exploit_estimate,
            "skill_level_required": report.skill_level_required,
            "simulation_narrative": report.simulation_narrative,
        },
        "reasoning_steps": [s.to_dict() for s in simulator.trace.steps],
    }


# ─── Payload Intelligence ─────────────────────────────────────────────────────

@router.get("/payloads/{vuln_type}")
async def get_payloads(
    vuln_type: str,
    context: Optional[str] = None,
    waf: Optional[str] = None,
    param: Optional[str] = None,
    user: User = Depends(get_current_user),
):
    """Get intelligent payload selection for a vuln type."""
    from app.intelligence.payloads.payload_intel import (
        PayloadIntelligenceSystem, ReflectionContext, WAFSignature
    )

    system = PayloadIntelligenceSystem()

    ctx = ReflectionContext(context) if context else ReflectionContext.UNKNOWN
    waf_sig = WAFSignature(waf) if waf else WAFSignature.NONE

    payloads = system.select_payloads(vuln_type, ctx, waf_sig, param_name=param or "", limit=15)

    return {
        "vuln_type": vuln_type,
        "context": ctx.value,
        "waf": waf_sig.value,
        "payloads": payloads,
        "reasoning_steps": [s.to_dict() for s in system.trace.steps],
    }


# ─── Monitoring ──────────────────────────────────────────────────────────────

class MonitorRequest(BaseModel):
    target: str
    workspace_id: str
    interval_hours: float = 24.0


@router.post("/monitor/start")
async def start_monitoring(
    req: MonitorRequest,
    background_tasks: BackgroundTasks,
    user: User = Depends(get_current_user),
):
    """Start continuous monitoring for a target."""
    from app.monitoring.continuous_monitor import monitor_scheduler
    background_tasks.add_task(
        monitor_scheduler.start_monitoring,
        req.workspace_id, req.target, req.interval_hours
    )
    return {"status": "monitoring_started", "target": req.target}


@router.get("/monitor/active")
async def list_active_monitors(user: User = Depends(get_current_user)):
    """List active monitoring targets."""
    from app.monitoring.continuous_monitor import monitor_scheduler
    return {"monitors": monitor_scheduler.active_monitors()}


@router.delete("/monitor/{workspace_id}/{target:path}")
async def stop_monitoring(
    workspace_id: str,
    target: str,
    user: User = Depends(get_current_user),
):
    """Stop monitoring for a target."""
    from app.monitoring.continuous_monitor import monitor_scheduler
    monitor_scheduler.stop_monitoring(workspace_id, target)
    return {"status": "monitoring_stopped"}


# ─── Metrics ─────────────────────────────────────────────────────────────────

@router.get("/metrics")
async def get_metrics():
    """Prometheus metrics endpoint."""
    from app.metrics.prometheus_metrics import MetricsCollector
    data, content_type = MetricsCollector.get_metrics_text()
    from fastapi.responses import Response
    return Response(content=data, media_type=content_type)


# ─── Tool Capabilities ────────────────────────────────────────────────────────

@router.get("/capabilities")
async def get_capabilities(user: User = Depends(get_current_user)):
    """Return which external tools are available and which capabilities are enabled."""
    from app.tools.tool_manager import tool_manager
    caps = tool_manager.get_capabilities()
    enabled = [name for name, info in caps.items() if info["available"]]
    disabled = [name for name, info in caps.items() if not info["available"]]
    return {
        "capabilities": caps,
        "enabled_count": len(enabled),
        "disabled_count": len(disabled),
        "enabled": enabled,
        "disabled": disabled,
        "summary": tool_manager.summary(),
    }
