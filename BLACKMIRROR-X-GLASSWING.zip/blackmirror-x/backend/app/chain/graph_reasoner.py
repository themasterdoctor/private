"""Graph Reasoner — builds attack chains dynamically from real findings.

Unlike template-based chains, this builds the graph from actual observed
vulnerabilities, evidence quality, and known exploitation patterns.

Works without Anthropic API key — uses a scoring matrix.
AI narratives are generated when key is available.
"""
from __future__ import annotations

import math
import uuid
from dataclasses import dataclass, field
from typing import Any
import structlog

logger = structlog.get_logger(__name__)


# How well different vuln types combine into attack chains
# (source_type, dest_type) → connection_probability
_CHAIN_MATRIX: dict[tuple[str, str], float] = {
    ("ssrf", "rce"):               0.45,
    ("ssrf", "credential_theft"):  0.60,
    ("sqli", "rce"):               0.35,
    ("sqli", "data_exfil"):        0.80,
    ("xss", "account_takeover"):   0.70,
    ("xss", "credential_theft"):   0.55,
    ("idor", "data_exfil"):        0.85,
    ("idor", "account_takeover"):  0.65,
    ("open_redirect", "phishing"): 0.75,
    ("open_redirect", "xss"):      0.40,
    ("cors", "credential_theft"):  0.60,
    ("cors", "account_takeover"):  0.50,
    ("mass_assignment", "privilege_escalation"): 0.80,
    ("broken_access_control", "data_exfil"):     0.75,
    ("broken_access_control", "privilege_escalation"): 0.70,
    ("jwt", "account_takeover"):   0.85,
    ("secret_exposure", "rce"):    0.50,
    ("secret_exposure", "cloud_compromise"): 0.70,
    ("graphql", "data_exfil"):     0.60,
    ("graphql", "idor"):           0.55,
    ("open_redirect", "oauth_hijack"): 0.55,
}

_IMPACT_LEVELS = {
    "rce":                   ("critical", 9.8),
    "cloud_compromise":      ("critical", 9.5),
    "account_takeover":      ("critical", 9.0),
    "privilege_escalation":  ("critical", 8.5),
    "data_exfil":            ("high",     8.0),
    "credential_theft":      ("high",     7.5),
    "phishing":              ("medium",   6.0),
    "oauth_hijack":          ("high",     7.8),
}


@dataclass
class ChainNode:
    """A node in the attack chain graph."""
    node_id: str
    vuln_type: str
    title: str
    url: str
    severity: str
    evidence_score: float = 0.5   # 0–1
    vuln_id: str = ""

    def to_dict(self) -> dict:
        return {
            "node_id": self.node_id,
            "vuln_type": self.vuln_type,
            "title": self.title,
            "url": self.url,
            "severity": self.severity,
            "evidence_score": self.evidence_score,
            "vuln_id": self.vuln_id,
        }


@dataclass
class ChainEdge:
    """An edge representing a possible exploitation step."""
    from_node: str
    to_node: str
    transition_type: str    # what action connects them
    probability: float      # 0–1
    missing_proof: str = "" # what evidence is needed

    def to_dict(self) -> dict:
        return {
            "from": self.from_node,
            "to": self.to_node,
            "transition": self.transition_type,
            "probability": round(self.probability, 2),
            "missing_proof": self.missing_proof,
        }


@dataclass
class AttackChain:
    """A complete multi-step attack chain."""
    chain_id: str = field(default_factory=lambda: str(uuid.uuid4())[:12])
    title: str = ""
    nodes: list[ChainNode] = field(default_factory=list)
    edges: list[ChainEdge] = field(default_factory=list)
    final_impact: str = ""
    chain_probability: float = 0.0
    impact_score: float = 0.0
    missing_links: list[str] = field(default_factory=list)
    next_steps: list[str] = field(default_factory=list)
    estimated_bounty: str = ""

    def to_dict(self) -> dict:
        return {
            "chain_id": self.chain_id,
            "title": self.title,
            "node_count": len(self.nodes),
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
            "final_impact": self.final_impact,
            "chain_probability": round(self.chain_probability, 2),
            "impact_score": round(self.impact_score, 1),
            "missing_links": self.missing_links,
            "next_steps": self.next_steps,
            "estimated_bounty": self.estimated_bounty,
        }


def _estimate_bounty(impact: str, probability: float) -> str:
    base = {
        "rce": 10000, "cloud_compromise": 15000, "account_takeover": 5000,
        "privilege_escalation": 3000, "data_exfil": 3000, "credential_theft": 2500,
    }.get(impact, 500)
    adjusted = int(base * probability)
    if adjusted > 5000:
        return f"${adjusted:,}+"
    elif adjusted > 1000:
        return f"${adjusted:,}"
    elif adjusted > 100:
        return f"${adjusted:,}–${adjusted*3:,}"
    return "< $500"


class GraphReasoner:
    """Builds attack chain graphs from observed vulnerability findings.

    Usage:
        reasoner = GraphReasoner()
        vulns = [{"id": ..., "vuln_type": "xss", ...}, ...]
        chains = reasoner.build_chains(vulns)
    """

    def build_chains(self, vulnerabilities: list[dict]) -> list[AttackChain]:
        """Build attack chains from a list of vulnerability dicts."""
        # Convert vulns to chain nodes
        nodes = [
            ChainNode(
                node_id=v.get("id", str(uuid.uuid4())[:8]),
                vuln_type=v.get("vuln_type", "unknown"),
                title=v.get("title", "Unknown Vulnerability"),
                url=v.get("url", ""),
                severity=v.get("severity", "medium"),
                evidence_score=float(v.get("evidence_score") or 0.5),
                vuln_id=v.get("id", ""),
            )
            for v in vulnerabilities
        ]

        chains: list[AttackChain] = []

        # Find all possible chains (n² pairs)
        for i, src_node in enumerate(nodes):
            for impact_type, (impact_sev, impact_score) in _IMPACT_LEVELS.items():
                prob = _CHAIN_MATRIX.get((src_node.vuln_type, impact_type), 0.0)
                if prob < 0.35:
                    continue

                # Find supporting nodes
                chain_nodes = [src_node]
                edges: list[ChainEdge] = []
                missing = []

                # Look for additional chain links
                for j, other in enumerate(nodes):
                    if j == i:
                        continue
                    link_prob = _CHAIN_MATRIX.get((other.vuln_type, impact_type), 0.0)
                    if link_prob > 0.3:
                        chain_nodes.append(other)
                        edges.append(ChainEdge(
                            from_node=other.node_id,
                            to_node=src_node.node_id,
                            transition_type=f"{other.vuln_type}_amplifies_{src_node.vuln_type}",
                            probability=min(prob * link_prob * 1.5, 0.95),
                        ))

                # Calculate chain probability from evidence scores
                avg_evidence = sum(n.evidence_score for n in chain_nodes) / len(chain_nodes)
                chain_prob = prob * avg_evidence

                # Identify missing proof
                if avg_evidence < 0.6:
                    missing.append("Additional exploit proof needed (low evidence score)")
                if prob < 0.6:
                    missing.append(f"Confirm {src_node.vuln_type}→{impact_type} transition is exploitable")

                next_steps = [
                    f"Verify {src_node.url} is in scope",
                    f"Test {src_node.vuln_type} payload against real parameter",
                    f"Document {impact_type} impact for report",
                ]

                chain = AttackChain(
                    title=f"{src_node.vuln_type.upper()} → {impact_type.replace('_', ' ').title()}",
                    nodes=chain_nodes,
                    edges=edges,
                    final_impact=impact_type,
                    chain_probability=chain_prob,
                    impact_score=impact_score * chain_prob,
                    missing_links=missing,
                    next_steps=next_steps,
                    estimated_bounty=_estimate_bounty(impact_type, chain_prob),
                )
                chains.append(chain)

        # Deduplicate and rank
        chains.sort(key=lambda c: c.chain_probability, reverse=True)
        # Remove near-duplicates (same src vuln_type + impact)
        seen: set[str] = set()
        deduped = []
        for c in chains:
            key = f"{c.nodes[0].vuln_type}→{c.final_impact}"
            if key not in seen:
                seen.add(key)
                deduped.append(c)

        return deduped[:10]  # top 10 chains
