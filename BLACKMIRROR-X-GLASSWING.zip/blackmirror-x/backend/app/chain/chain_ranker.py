"""Chain Ranker and Proof Gap Analyzer.

chain_ranker.py: ranks attack chains by bounty likelihood, evidence quality, and exploitability.
proof_gap_analyzer.py: identifies what evidence is missing to prove a chain.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
import structlog

logger = structlog.get_logger(__name__)


# ── Chain Ranker ─────────────────────────────────────────────────────────────

def rank_chains(chains: list[dict]) -> list[dict]:
    """Rank attack chains by composite score.

    Score = probability * impact * evidence_quality * (1 + bounty_factor)
    """
    _BOUNTY_MAP = {
        "rce": 1.0, "cloud_compromise": 1.0, "account_takeover": 0.9,
        "privilege_escalation": 0.8, "data_exfil": 0.7,
        "credential_theft": 0.65, "phishing": 0.3,
    }
    _IMPACT_MAP = {
        "critical": 10, "high": 7, "medium": 4, "low": 2, "info": 1,
    }

    def score(c: dict) -> float:
        prob = c.get("chain_probability", 0.1)
        impact = c.get("final_impact", "")
        severity = c.get("severity", "medium")
        evidence = c.get("evidence_quality", 0.5)
        bounty_factor = _BOUNTY_MAP.get(impact, 0.3)
        impact_score = _IMPACT_MAP.get(severity, 4)
        return prob * impact_score * evidence * (1 + bounty_factor)

    ranked = sorted(chains, key=score, reverse=True)
    for i, c in enumerate(ranked):
        c["rank"] = i + 1
        c["composite_score"] = round(score(c), 3)
    return ranked


# ── Proof Gap Analyzer ────────────────────────────────────────────────────────

@dataclass
class ProofGap:
    """A missing piece of evidence needed to complete a chain."""
    gap_type: str       # "exploit_proof" | "scope_confirmation" | "impact_evidence"
    description: str
    chain_id: str
    severity: str = "medium"
    test_suggestion: str = ""
    safe_to_test: bool = True

    def to_dict(self) -> dict:
        return {
            "gap_type": self.gap_type,
            "description": self.description,
            "chain_id": self.chain_id,
            "severity": self.severity,
            "test_suggestion": self.test_suggestion,
            "safe_to_test": self.safe_to_test,
        }


_PROOF_REQUIREMENTS: dict[str, list[dict]] = {
    "xss": [
        {"type": "exploit_proof",
         "description": "Demonstrate alert() or cookie exfil in a real browser context",
         "test": "Use XSS Hunter or Burp Collaborator to capture out-of-band execution",
         "safe": True},
        {"type": "scope_confirmation",
         "description": "Confirm the vulnerable parameter is user-controlled input",
         "test": "Check if the parameter appears in URL, form, or JSON body",
         "safe": True},
    ],
    "sqli": [
        {"type": "exploit_proof",
         "description": "Extract a row from the database (e.g., version() or user())",
         "test": "Use sqlmap --dump=table --safe-level=3 against target",
         "safe": True},
        {"type": "impact_evidence",
         "description": "Determine if the DB user has write or admin privileges",
         "test": "Run SELECT CURRENT_USER(), HAS_PRIVILEGE('...')",
         "safe": True},
    ],
    "ssrf": [
        {"type": "exploit_proof",
         "description": "Prove blind SSRF with out-of-band DNS/HTTP callback",
         "test": "Use Burp Collaborator: inject URL pointing to collaborator host",
         "safe": True},
        {"type": "impact_evidence",
         "description": "Confirm cloud metadata access (169.254.169.254)",
         "test": "Only test against declared in-scope instances",
         "safe": False},  # risky — requires approval
    ],
    "idor": [
        {"type": "exploit_proof",
         "description": "Access a second account's resource using account A credentials",
         "test": "Create two test accounts; access account B's object with account A's token",
         "safe": True},
    ],
    "jwt": [
        {"type": "exploit_proof",
         "description": "Forge a token with modified claims (e.g., role=admin)",
         "test": "Use jwt_tool or Burp to modify and re-sign the token",
         "safe": True},
    ],
}


def analyze_proof_gaps(chains: list[dict]) -> list[ProofGap]:
    """Identify missing evidence for a list of attack chain dicts."""
    gaps: list[ProofGap] = []

    for chain in chains:
        chain_id = chain.get("chain_id", "unknown")
        prob = chain.get("chain_probability", 0.5)
        evidence_score = chain.get("evidence_quality", 0.5)

        # Low evidence → need more proof
        if evidence_score < 0.5:
            gaps.append(ProofGap(
                gap_type="exploit_proof",
                description=f"Chain probability {prob:.0%} but evidence score is low ({evidence_score:.0%})",
                chain_id=chain_id,
                test_suggestion="Add request/response screenshots and curl reproduction steps",
            ))

        # Check per-node vuln type requirements
        for node in chain.get("nodes", []):
            vuln_type = node.get("vuln_type", "")
            requirements = _PROOF_REQUIREMENTS.get(vuln_type, [])
            for req in requirements:
                gaps.append(ProofGap(
                    gap_type=req["type"],
                    description=req["description"],
                    chain_id=chain_id,
                    test_suggestion=req["test"],
                    safe_to_test=req.get("safe", True),
                ))

        # Missing link gaps from chain data
        for missing in chain.get("missing_links", []):
            gaps.append(ProofGap(
                gap_type="missing_link",
                description=missing,
                chain_id=chain_id,
                test_suggestion="Investigate manual testing of this step",
            ))

    # Deduplicate identical gaps per chain
    seen: set[tuple] = set()
    deduped: list[ProofGap] = []
    for g in gaps:
        key = (g.chain_id, g.gap_type, g.description[:50])
        if key not in seen:
            seen.add(key)
            deduped.append(g)

    return deduped
