"""ToolManager — detects external security tools and manages capabilities.

Checks for: subfinder, amass, dnsx, httpx, naabu, katana, gau,
            waybackurls, nuclei, chromium/playwright

If a tool is missing:
- capability is marked disabled
- install instructions are logged and exposed via API
- dependent code receives empty results gracefully
"""
from __future__ import annotations

import shutil
import subprocess
import asyncio
from dataclasses import dataclass, field
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class ToolInfo:
    name: str
    binary: str
    category: str          # recon, scanner, crawler, browser
    install_cmd: str
    version: str = ""
    available: bool = False
    path: str = ""


TOOLS = [
    ToolInfo("subfinder",    "subfinder",    "recon",    "go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"),
    ToolInfo("amass",        "amass",        "recon",    "go install -v github.com/owasp-amass/amass/v4/...@master"),
    ToolInfo("dnsx",         "dnsx",         "recon",    "go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest"),
    ToolInfo("httpx",        "httpx",        "recon",    "go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest"),
    ToolInfo("naabu",        "naabu",        "recon",    "go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"),
    ToolInfo("katana",       "katana",       "crawler",  "go install github.com/projectdiscovery/katana/cmd/katana@latest"),
    ToolInfo("gau",          "gau",          "crawler",  "go install github.com/lc/gau/v2/cmd/gau@latest"),
    ToolInfo("waybackurls",  "waybackurls",  "crawler",  "go install github.com/tomnomnom/waybackurls@latest"),
    ToolInfo("nuclei",       "nuclei",       "scanner",  "go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"),
    ToolInfo("chromium",     "chromium",     "browser",  "playwright install chromium --with-deps"),
]


class ToolManager:
    """Singleton tool availability manager."""

    _instance: "ToolManager | None" = None
    _tools: dict[str, ToolInfo] = {}
    _checked: bool = False

    def __new__(cls) -> "ToolManager":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def check_all(self) -> dict[str, ToolInfo]:
        """Check availability of all tools."""
        for tool in TOOLS:
            self._check_tool(tool)
            self._tools[tool.name] = tool
        self._checked = True

        available = [t.name for t in self._tools.values() if t.available]
        missing = [t.name for t in self._tools.values() if not t.available]
        logger.info("tool_check_complete", available=available, missing=missing)
        return self._tools

    def _check_tool(self, tool: ToolInfo) -> None:
        """Check if a single tool is available."""
        # Special case: chromium via playwright
        if tool.name == "chromium":
            try:
                from playwright.sync_api import sync_playwright
                with sync_playwright() as p:
                    browser = p.chromium.launch(headless=True)
                    browser.close()
                tool.available = True
                tool.path = "playwright"
                tool.version = "playwright"
            except Exception:
                tool.available = False
            return

        # Standard binary check
        path = shutil.which(tool.binary)
        if path:
            tool.available = True
            tool.path = path
            # Try to get version
            try:
                result = subprocess.run(
                    [path, "-version"],
                    capture_output=True, text=True, timeout=3
                )
                out = result.stdout or result.stderr
                if out:
                    tool.version = out.strip().split("\n")[0][:50]
            except Exception:
                tool.version = "unknown"
        else:
            tool.available = False

    def is_available(self, tool_name: str) -> bool:
        if not self._checked:
            self.check_all()
        tool = self._tools.get(tool_name)
        return tool.available if tool else False

    def get_status(self) -> dict[str, Any]:
        if not self._checked:
            self.check_all()
        return {
            "tools": [
                {
                    "name": t.name,
                    "category": t.category,
                    "available": t.available,
                    "path": t.path,
                    "version": t.version,
                    "install_cmd": t.install_cmd if not t.available else None,
                }
                for t in self._tools.values()
            ],
            "recon_available": self.is_available("subfinder") or self.is_available("amass"),
            "http_probing_available": self.is_available("httpx"),
            "crawling_available": self.is_available("katana") or self.is_available("gau"),
            "scanning_available": self.is_available("nuclei"),
            "browser_available": self.is_available("chromium"),
            "missing_install_commands": [
                {"tool": t.name, "cmd": t.install_cmd}
                for t in self._tools.values()
                if not t.available
            ],
        }

    def capabilities_summary(self) -> str:
        """Human-readable capabilities string."""
        if not self._checked:
            self.check_all()
        available = [t.name for t in self._tools.values() if t.available]
        missing = [t.name for t in self._tools.values() if not t.available]
        lines = []
        if available:
            lines.append(f"Available ({len(available)}): {', '.join(available)}")
        if missing:
            lines.append(f"Missing ({len(missing)}): {', '.join(missing)}")
            lines.append("Install with: go install github.com/projectdiscovery/<tool>/cmd/<tool>@latest")
        return " | ".join(lines)


# Global singleton
tool_manager = ToolManager()
