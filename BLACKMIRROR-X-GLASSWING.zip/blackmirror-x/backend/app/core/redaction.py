"""Structlog secret redaction processor.

Masks values for known sensitive keys before log output.
Prevents API keys, tokens, passwords from appearing in logs.
"""
from __future__ import annotations
import re
from typing import Any

# Keys whose values should be fully masked
REDACT_KEYS = frozenset({
    "password", "passwd", "pwd", "secret", "token", "api_key", "apikey",
    "access_token", "refresh_token", "authorization", "bearer",
    "private_key", "secret_key", "jwt_secret", "bmx_vault_key",
    "client_secret", "anthropic_api_key", "openai_api_key",
    "aws_secret_access_key", "stripe_secret_key",
    "hashed_password", "key_hash",
})

# Regex patterns for values that look like secrets (regardless of key)
SECRET_PATTERNS = [
    re.compile(r"sk-ant-[A-Za-z0-9_\-]{20,}"),          # Anthropic keys
    re.compile(r"eyJ[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]{20,}"),  # JWTs
    re.compile(r"AKIA[0-9A-Z]{16}"),                      # AWS access keys
    re.compile(r"ghp_[A-Za-z0-9]{36}"),                   # GitHub tokens
]

MASK = "***REDACTED***"


def _redact_value(value: Any) -> Any:
    """Redact a single value if it looks like a secret."""
    if not isinstance(value, str):
        return value
    for pattern in SECRET_PATTERNS:
        if pattern.search(value):
            return MASK
    return value


def redact_secrets(logger: Any, method: str, event_dict: dict[str, Any]) -> dict[str, Any]:
    """Structlog processor that redacts sensitive values."""
    for key in list(event_dict.keys()):
        if key.lower() in REDACT_KEYS:
            event_dict[key] = MASK
        else:
            event_dict[key] = _redact_value(event_dict[key])
    return event_dict
