"""GraphQL Analyzer — security analysis of GraphQL endpoints.

Tests for:
- Introspection enabled (schema disclosure)
- Depth limit missing (DoS via deeply nested queries)
- Batch query support (amplification)
- Field suggestion leakage
- IDOR through node IDs
- Missing auth on mutations

Works with httpx (no browser needed). Returns empty results when httpx unavailable.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any
import structlog

logger = structlog.get_logger(__name__)

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False

INTROSPECTION_QUERY = """
{
  __schema {
    types {
      name
      kind
      fields { name type { name kind ofType { name kind } } }
    }
    mutationType { fields { name args { name type { name } } } }
    queryType { fields { name } }
  }
}
"""

DEPTH_TEST_QUERY = """
{a{b{c{d{e{f{g{h{i{j{__typename}}}}}}}}}}
"""

BATCH_TEST_QUERIES = [
    {"query": "{ __typename }"},
    {"query": "{ __typename }"},
    {"query": "{ __typename }"},
]


@dataclass
class GQLFinding:
    test: str
    severity: str
    title: str
    description: str
    evidence: str = ""

    def to_dict(self) -> dict:
        return {
            "test": self.test,
            "severity": self.severity,
            "title": self.title,
            "description": self.description,
            "evidence": self.evidence[:300],
        }


@dataclass
class GQLSchema:
    """Parsed GraphQL schema from introspection."""
    query_fields: list[str] = field(default_factory=list)
    mutation_fields: list[str] = field(default_factory=list)
    types: list[str] = field(default_factory=list)
    sensitive_fields: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "query_fields": self.query_fields[:30],
            "mutation_fields": self.mutation_fields[:30],
            "type_count": len(self.types),
            "sensitive_fields": self.sensitive_fields,
        }


def _parse_schema(introspection_data: dict) -> GQLSchema:
    schema = GQLSchema()
    data = introspection_data.get("data", {}).get("__schema", {})

    # Query fields
    qt = data.get("queryType", {})
    if qt and qt.get("fields"):
        schema.query_fields = [f["name"] for f in qt["fields"]]

    # Mutation fields
    mt = data.get("mutationType")
    if mt and mt.get("fields"):
        schema.mutation_fields = [f["name"] for f in mt["fields"]]

    # All types
    for t in data.get("types", []):
        if not t["name"].startswith("__"):
            schema.types.append(t["name"])
            # Scan for sensitive field names
            for f in (t.get("fields") or []):
                fname = f["name"].lower()
                if any(s in fname for s in ["password", "secret", "token", "key",
                                             "ssn", "credit", "private"]):
                    schema.sensitive_fields.append(f["name"])

    return schema


async def analyze_graphql(url: str,
                           headers: dict[str, str] | None = None,
                           timeout: float = 10.0) -> dict[str, Any]:
    """Full security analysis of a GraphQL endpoint.

    Returns findings dict with findings list, schema summary, and capability map.
    """
    if not HTTPX_AVAILABLE:
        return {
            "url": url,
            "error": "httpx not available",
            "findings": [],
            "fix": "pip install httpx",
        }

    findings: list[GQLFinding] = []
    schema: GQLSchema | None = None
    capabilities = {
        "introspection": False,
        "batch_queries": False,
        "depth_unlimited": False,
        "field_suggestions": False,
    }

    async with httpx.AsyncClient(timeout=timeout, verify=False,
                                  headers=headers or {}) as client:

        # ── Test 1: Introspection ───────────────────────────────────────
        try:
            r = await client.post(url, json={"query": INTROSPECTION_QUERY})
            data = r.json()
            if "data" in data and "__schema" in str(data):
                capabilities["introspection"] = True
                schema = _parse_schema(data)
                findings.append(GQLFinding(
                    test="introspection",
                    severity="medium",
                    title="GraphQL Introspection Enabled",
                    description=(
                        f"Full schema exposed via introspection. "
                        f"{len(schema.query_fields)} queries, "
                        f"{len(schema.mutation_fields)} mutations, "
                        f"{len(schema.types)} types discovered."
                    ),
                    evidence=json.dumps({"query_fields": schema.query_fields[:10]}),
                ))

                if schema.sensitive_fields:
                    findings.append(GQLFinding(
                        test="sensitive_fields_in_schema",
                        severity="high",
                        title="Sensitive Fields in Schema",
                        description=f"Schema exposes sensitive fields: {schema.sensitive_fields}",
                        evidence=str(schema.sensitive_fields),
                    ))
        except Exception as e:
            logger.debug("gql_introspection_error", error=str(e))

        # ── Test 2: Batch queries ───────────────────────────────────────
        try:
            r = await client.post(url, json=BATCH_TEST_QUERIES)
            if r.status_code == 200 and isinstance(r.json(), list):
                capabilities["batch_queries"] = True
                findings.append(GQLFinding(
                    test="batch_queries",
                    severity="medium",
                    title="Batch Query Support",
                    description="Server accepts batched GraphQL queries, enabling request amplification attacks.",
                    evidence=f"Batch of {len(BATCH_TEST_QUERIES)} returned {len(r.json())} results",
                ))
        except Exception:
            pass

        # ── Test 3: Depth limit ─────────────────────────────────────────
        try:
            r = await client.post(url, json={"query": DEPTH_TEST_QUERY})
            if r.status_code == 200 and "errors" not in r.text.lower():
                capabilities["depth_unlimited"] = True
                findings.append(GQLFinding(
                    test="depth_limit",
                    severity="low",
                    title="No Query Depth Limit",
                    description="Server accepts deeply nested queries (depth 10+), enabling DoS.",
                    evidence=DEPTH_TEST_QUERY.strip(),
                ))
        except Exception:
            pass

        # ── Test 4: Field suggestion ────────────────────────────────────
        try:
            r = await client.post(url, json={"query": "{ usr { id } }"})
            body = r.text
            if "Did you mean" in body or "did you mean" in body:
                capabilities["field_suggestions"] = True
                findings.append(GQLFinding(
                    test="field_suggestions",
                    severity="low",
                    title="Field Suggestions Enabled",
                    description="Server leaks field names via 'Did you mean?' error messages.",
                    evidence=body[:200],
                ))
        except Exception:
            pass

    return {
        "url": url,
        "findings": [f.to_dict() for f in findings],
        "schema": schema.to_dict() if schema else None,
        "capabilities": capabilities,
        "finding_count": len(findings),
        "critical_count": sum(1 for f in findings if f.severity in ("critical", "high")),
    }
