"""Role Diff — multi-user authorization comparison.

Makes the same API calls as multiple users (different roles) and
compares responses to find:
- Endpoints accessible to lower-privilege roles
- Data exposed to wrong roles
- Privilege escalation via parameter manipulation
- Horizontal privilege escalation (user A reading user B's data)

Works without Playwright — pure HTTP.
"""
from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass, field
from typing import Any
import structlog

logger = structlog.get_logger(__name__)

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False
    logger.warning("role_diff_no_httpx", fix="pip install httpx")


@dataclass
class RoleCredential:
    """Credentials for a single test role."""
    role_name: str         # "admin", "user", "guest", "unauthenticated"
    headers: dict[str, str] = field(default_factory=dict)
    cookies: dict[str, str] = field(default_factory=dict)
    token: str = ""

    @property
    def auth_headers(self) -> dict[str, str]:
        h = dict(self.headers)
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        return h


@dataclass
class RoleDiffResult:
    """Result of comparing two roles on the same endpoint."""
    url: str
    method: str
    role_a: str
    role_b: str
    status_a: int
    status_b: int
    body_a: str
    body_b: str
    finding_type: str = ""   # "privilege_escalation" | "data_exposure" | "same_response"
    severity: str = "info"
    description: str = ""
    fields_exposed_to_lower: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "url": self.url,
            "method": self.method,
            "role_a": self.role_a,
            "role_b": self.role_b,
            "status_a": self.status_a,
            "status_b": self.status_b,
            "finding_type": self.finding_type,
            "severity": self.severity,
            "description": self.description,
            "fields_exposed_to_lower": self.fields_exposed_to_lower,
            "has_finding": bool(self.finding_type and self.finding_type != "same_response"),
        }


def _compare_responses(url: str, method: str,
                       role_a: RoleCredential, body_a: str, status_a: int,
                       role_b: RoleCredential, body_b: str, status_b: int,
                       ) -> RoleDiffResult:
    """Compare two role responses and identify authorization issues."""
    result = RoleDiffResult(
        url=url, method=method,
        role_a=role_a.role_name, role_b=role_b.role_name,
        status_a=status_a, status_b=status_b,
        body_a=body_a[:500], body_b=body_b[:500],
    )

    # Both get same non-200 — no issue
    if status_a >= 400 and status_b >= 400:
        result.finding_type = "both_denied"
        return result

    # Higher-privilege role (a) gets 200, lower (b) also gets 200
    if status_a in (200, 201) and status_b in (200, 201):
        # Compare response content
        try:
            data_a = json.loads(body_a)
            data_b = json.loads(body_b)

            # Find fields in b that shouldn't be there
            if isinstance(data_a, dict) and isinstance(data_b, dict):
                sensitive_keys = {"password", "secret", "token", "ssn", "credit_card",
                                  "private", "internal", "admin", "role", "permissions"}
                exposed = [k for k in data_b if k.lower() in sensitive_keys]
                if exposed:
                    result.finding_type = "data_exposure"
                    result.severity = "high"
                    result.fields_exposed_to_lower = exposed
                    result.description = (
                        f"Sensitive fields {exposed} visible to role '{role_b.role_name}'"
                    )
                    return result

            if body_a.strip() and body_b.strip() and body_a.strip() == body_b.strip():
                result.finding_type = "same_response"
                return result

        except json.JSONDecodeError:
            pass

        result.finding_type = "same_access"
        result.severity = "medium"
        result.description = (
            f"Both '{role_a.role_name}' and '{role_b.role_name}' can access {url}"
        )
        return result

    # Lower role (b) gets 200 but higher (a) gets 4xx — unexpected escalation
    if status_b in (200, 201) and status_a >= 400:
        result.finding_type = "privilege_escalation"
        result.severity = "critical"
        result.description = (
            f"Role '{role_b.role_name}' can access {url} but '{role_a.role_name}' cannot"
        )
        return result

    # Lower role denied, higher allowed — expected, no finding
    if status_b >= 400 and status_a in (200, 201):
        result.finding_type = "correct_denial"
        return result

    result.finding_type = "status_diff"
    result.description = (
        f"Status differs: {role_a.role_name}={status_a}, {role_b.role_name}={status_b}"
    )
    return result


async def diff_roles(
    urls: list[str],
    role_pairs: list[tuple[RoleCredential, RoleCredential]],
    method: str = "GET",
    timeout: float = 10.0,
    base_url: str = "",
) -> list[RoleDiffResult]:
    """Test multiple URLs with multiple role pairs and return diff results.

    Returns empty list if httpx is unavailable.
    """
    if not HTTPX_AVAILABLE:
        return []

    results = []

    async with httpx.AsyncClient(timeout=timeout, follow_redirects=False,
                                  verify=False) as client:
        for url in urls:
            full_url = (base_url + url) if base_url and url.startswith("/") else url
            for role_a, role_b in role_pairs:
                try:
                    resp_a = await client.request(
                        method, full_url, headers=role_a.auth_headers,
                        cookies=role_a.cookies,
                    )
                    resp_b = await client.request(
                        method, full_url, headers=role_b.auth_headers,
                        cookies=role_b.cookies,
                    )
                    result = _compare_responses(
                        url=full_url, method=method,
                        role_a=role_a, body_a=resp_a.text,
                        status_a=resp_a.status_code,
                        role_b=role_b, body_b=resp_b.text,
                        status_b=resp_b.status_code,
                    )
                    results.append(result)
                except Exception as e:
                    logger.warning("role_diff_request_error",
                                  url=full_url, error=str(e))

    return results


def summarize_diff_results(results: list[RoleDiffResult]) -> dict:
    findings = [r for r in results if r.finding_type not in
                ("same_response", "correct_denial", "both_denied")]
    return {
        "total_tested": len(results),
        "findings": len(findings),
        "critical": sum(1 for r in findings if r.severity == "critical"),
        "high": sum(1 for r in findings if r.severity == "high"),
        "medium": sum(1 for r in findings if r.severity == "medium"),
        "finding_details": [r.to_dict() for r in findings],
    }
