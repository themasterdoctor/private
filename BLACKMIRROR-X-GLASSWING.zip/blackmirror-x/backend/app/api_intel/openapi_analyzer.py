"""OpenAPI Analyzer — security analysis of OpenAPI 3.x / Swagger 2.x specs.

Detects:
- Endpoints with no auth requirement
- Sensitive operations (DELETE, admin paths) without auth
- Mass assignment vectors (writable fields that shouldn't be)
- Missing input validation (no schema constraints)
- Broken object level auth (no path params but filtered by user)
- Overly permissive response schemas (returns too many fields)

Works on a parsed spec dict — no HTTP required.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any
import structlog

logger = structlog.get_logger(__name__)

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False


@dataclass
class OpenAPIFinding:
    path: str
    method: str
    finding_type: str
    severity: str
    title: str
    description: str

    def to_dict(self) -> dict:
        return {
            "path": self.path,
            "method": self.method,
            "finding_type": self.finding_type,
            "severity": self.severity,
            "title": self.title,
            "description": self.description,
        }


_SENSITIVE_PATHS = re.compile(
    r"(admin|internal|debug|backup|config|export|import|upload|delete|purge)",
    re.IGNORECASE,
)

_SENSITIVE_FIELDS = {"password", "secret", "token", "credit_card", "ssn",
                     "private_key", "api_key", "access_token"}


def analyze_openapi_spec(spec: dict) -> dict[str, Any]:
    """Analyze an OpenAPI spec dict for security issues."""
    findings: list[OpenAPIFinding] = []
    version = "3" if "openapi" in spec else "2"
    paths = spec.get("paths", {})
    global_security = spec.get("security", [])

    for path, path_item in paths.items():
        for method, operation in path_item.items():
            if method.lower() not in ("get", "post", "put", "patch", "delete",
                                      "options", "head"):
                continue

            op_security = operation.get("security", global_security)
            has_auth = bool(op_security)

            # ── No auth ─────────────────────────────────────────────────
            if not has_auth:
                severity = "info"
                if method.lower() in ("delete", "put", "patch"):
                    severity = "high"
                elif _SENSITIVE_PATHS.search(path):
                    severity = "high"
                elif method.lower() == "post":
                    severity = "medium"

                if severity != "info":
                    findings.append(OpenAPIFinding(
                        path=path, method=method.upper(),
                        finding_type="no_auth",
                        severity=severity,
                        title=f"{method.upper()} {path} — No Authentication",
                        description=(
                            f"Operation has no security requirement. "
                            f"{'Sensitive path' if _SENSITIVE_PATHS.search(path) else 'Mutating method'} "
                            f"without auth is a likely authorization bug."
                        ),
                    ))

            # ── Mass assignment ──────────────────────────────────────────
            req_body = operation.get("requestBody", {})
            content = req_body.get("content", {})
            for ct, ct_data in content.items():
                schema = ct_data.get("schema", {})
                props = schema.get("properties", {})
                # Look for writable privileged fields
                priv_fields = [k for k in props
                               if k.lower() in ("role", "is_admin", "admin",
                                                "permissions", "status", "verified")]
                if priv_fields and method.lower() in ("post", "put", "patch"):
                    findings.append(OpenAPIFinding(
                        path=path, method=method.upper(),
                        finding_type="mass_assignment",
                        severity="high",
                        title=f"Mass Assignment — {path}",
                        description=(
                            f"Request body allows writing privileged fields: {priv_fields}. "
                            f"Verify server-side filtering strips these."
                        ),
                    ))

            # ── Sensitive data in response ────────────────────────────────
            responses = operation.get("responses", {})
            for status, resp in responses.items():
                resp_content = resp.get("content", {})
                for ct, ct_data in resp_content.items():
                    resp_schema = ct_data.get("schema", {})
                    resp_props = resp_schema.get("properties", {})
                    exposed = [k for k in resp_props if k.lower() in _SENSITIVE_FIELDS]
                    if exposed:
                        findings.append(OpenAPIFinding(
                            path=path, method=method.upper(),
                            finding_type="sensitive_response_field",
                            severity="medium",
                            title=f"Sensitive Fields in Response Schema — {path}",
                            description=(
                                f"Response schema includes sensitive fields: {exposed}. "
                                f"Verify these are not returned to unprivileged users."
                            ),
                        ))
                        break

    return {
        "version": version,
        "path_count": len(paths),
        "operation_count": sum(
            len([m for m in ops if m in ("get","post","put","patch","delete")])
            for ops in paths.values()
        ),
        "findings": [f.to_dict() for f in findings],
        "finding_count": len(findings),
        "critical_count": sum(1 for f in findings if f.severity in ("critical", "high")),
    }


async def fetch_and_analyze(spec_url: str,
                             headers: dict | None = None) -> dict[str, Any]:
    """Fetch an OpenAPI spec from a URL and analyze it."""
    if not HTTPX_AVAILABLE:
        return {"error": "httpx not available", "findings": [],
                "fix": "pip install httpx"}

    try:
        async with httpx.AsyncClient(timeout=10, verify=False) as client:
            r = await client.get(spec_url, headers=headers or {})
            r.raise_for_status()
            spec = r.json()
            result = analyze_openapi_spec(spec)
            result["spec_url"] = spec_url
            return result
    except Exception as e:
        return {"error": str(e), "findings": [], "spec_url": spec_url}
