"""Object Mapper — discovers object relationships from API responses.

Builds a graph of: object types → IDs → relationships → ownership.
From this graph, generates IDOR/BOLA test candidates.

Requires no external tools — pure HTTP analysis.
"""
from __future__ import annotations

import re
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any
import structlog

logger = structlog.get_logger(__name__)


@dataclass
class ObjectNode:
    """A discovered API object."""
    object_type: str     # "user", "order", "document", etc.
    object_id: str
    discovered_at: str   # URL where found
    owner_id: str = ""
    attributes: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "type": self.object_type,
            "id": self.object_id,
            "discovered_at": self.discovered_at,
            "owner_id": self.owner_id,
        }


@dataclass
class IDORCandidate:
    """A potential IDOR vulnerability to test."""
    url_template: str    # e.g. "/api/users/{id}"
    object_type: str
    param_name: str
    known_ids: list[str]
    test_id: str         # ID to substitute for testing
    risk: str = "high"
    rationale: str = ""

    def to_dict(self) -> dict:
        return {
            "url_template": self.url_template,
            "object_type": self.object_type,
            "param_name": self.param_name,
            "known_ids": self.known_ids[:5],
            "test_id": self.test_id,
            "risk": self.risk,
            "rationale": self.rationale,
        }


# Patterns that look like object IDs in URLs
_ID_PATTERNS = [
    r'/(\d{1,10})(?:/|$)',               # numeric IDs
    r'/([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})(?:/|$)',  # UUIDs
    r'/([a-zA-Z0-9_-]{12,36})(?:/|$)',   # base64-ish IDs
]
_ID_RE = [re.compile(p) for p in _ID_PATTERNS]

# Common ID field names in JSON responses
_ID_FIELDS = {"id", "user_id", "userId", "account_id", "accountId", "object_id",
              "document_id", "profile_id", "order_id", "orderId", "resource_id"}

# Common resource type names in URLs
_RESOURCE_TYPES = {
    "users", "user", "accounts", "account", "orders", "order", "documents",
    "document", "files", "file", "profiles", "profile", "items", "item",
    "resources", "resource", "posts", "post", "comments", "comment",
    "messages", "message", "tickets", "ticket", "projects", "project",
}


def extract_object_type_from_url(url: str) -> str:
    """Best-effort: extract resource type from URL path."""
    parts = url.rstrip("/").split("/")
    # Walk backwards looking for known resource names
    for part in reversed(parts):
        clean = part.lower().rstrip("s")  # singularize
        if clean in _RESOURCE_TYPES or part.lower() in _RESOURCE_TYPES:
            return clean
    return "resource"


def extract_ids_from_url(url: str) -> list[str]:
    """Extract ID-like path segments from a URL."""
    ids = []
    for pattern in _ID_RE:
        for m in pattern.finditer(url):
            candidate = m.group(1)
            # Skip common false positives
            if candidate.lower() not in ("api", "v1", "v2", "v3", "www"):
                ids.append(candidate)
    return list(set(ids))


def extract_ids_from_json(data: Any, path: str = "") -> list[tuple[str, str]]:
    """Recursively extract (field_name, id_value) from JSON responses."""
    results = []
    if isinstance(data, dict):
        for k, v in data.items():
            full_key = f"{path}.{k}" if path else k
            if k.lower() in _ID_FIELDS and isinstance(v, (str, int)):
                results.append((k, str(v)))
            elif isinstance(v, (dict, list)):
                results.extend(extract_ids_from_json(v, full_key))
    elif isinstance(data, list):
        for item in data[:20]:  # limit recursion
            results.extend(extract_ids_from_json(item, path))
    return results


class ObjectMapper:
    """Builds an object relationship map from observed API traffic.

    Usage:
        mapper = ObjectMapper()
        mapper.observe_request("GET", "/api/users/123", response_body)
        candidates = mapper.generate_idor_candidates()
    """

    def __init__(self):
        self._objects: dict[str, dict[str, ObjectNode]] = defaultdict(dict)
        # type -> {id -> node}
        self._url_templates: dict[str, str] = {}
        # concrete_url -> template_url (/api/users/123 -> /api/users/{id})

    def observe_request(self, method: str, url: str, response: Any,
                        user_context: str = "") -> None:
        """Process an observed API request/response pair."""
        # Extract IDs from URL
        url_ids = extract_ids_from_url(url)
        obj_type = extract_object_type_from_url(url)

        for id_val in url_ids:
            node = ObjectNode(
                object_type=obj_type,
                object_id=id_val,
                discovered_at=url,
                owner_id=user_context,
            )
            self._objects[obj_type][id_val] = node

        # Extract IDs from JSON response
        if isinstance(response, (dict, list)):
            id_pairs = extract_ids_from_json(response)
            for field_name, id_val in id_pairs:
                inferred_type = field_name.replace("_id", "").replace("Id", "")
                if inferred_type not in self._objects:
                    inferred_type = obj_type
                node = ObjectNode(
                    object_type=inferred_type,
                    object_id=id_val,
                    discovered_at=url,
                    owner_id=user_context,
                )
                self._objects[inferred_type][id_val] = node

        # Build URL template
        template = self._templatize_url(url, url_ids)
        self._url_templates[url] = template

    def _templatize_url(self, url: str, ids: list[str]) -> str:
        """Replace IDs with {id} placeholder: /api/users/123 → /api/users/{id}"""
        template = url
        for id_val in ids:
            template = template.replace(f"/{id_val}", "/{id}", 1)
        return template

    def generate_idor_candidates(self) -> list[IDORCandidate]:
        """Generate IDOR test candidates from observed objects."""
        candidates = []

        for obj_type, nodes in self._objects.items():
            if len(nodes) < 1:
                continue

            # Find URLs that contain IDs of this type
            relevant_templates = set()
            for url, template in self._url_templates.items():
                ids_in_url = extract_ids_from_url(url)
                for id_val in ids_in_url:
                    if id_val in nodes:
                        relevant_templates.add(template)

            if not relevant_templates:
                continue

            known_ids = list(nodes.keys())[:10]
            # Generate a test ID: try adjacent numeric, or a different UUID
            test_id = self._generate_test_id(known_ids)

            for template in relevant_templates:
                candidates.append(IDORCandidate(
                    url_template=template,
                    object_type=obj_type,
                    param_name="id",
                    known_ids=known_ids,
                    test_id=test_id,
                    risk="high",
                    rationale=(
                        f"Found {len(known_ids)} {obj_type} objects. "
                        f"Testing with ID {test_id!r} may expose unauthorized access."
                    ),
                ))

        return candidates

    def _generate_test_id(self, known_ids: list[str]) -> str:
        """Generate a test ID that's adjacent to known IDs."""
        # Try numeric increment/decrement
        for kid in known_ids[:3]:
            try:
                n = int(kid)
                # Use an ID that's ±1 or ±100 — common IDOR targets
                return str(n - 1) if n > 1 else str(n + 1)
            except ValueError:
                pass
        # UUID-style: just return a random UUID
        return str(uuid.uuid4())

    def get_object_map(self) -> dict:
        return {
            "object_types": {
                obj_type: {
                    "count": len(nodes),
                    "sample_ids": list(nodes.keys())[:5],
                }
                for obj_type, nodes in self._objects.items()
            },
            "url_templates": list(set(self._url_templates.values()))[:20],
        }
