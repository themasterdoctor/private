"""Workflow Replay — stateful API workflow capture and replay.

Records a sequence of API calls (a workflow), then replays it
with modifications to test:
- Skipped authorization steps
- Token substitution (horizontal escalation)
- Parameter manipulation mid-workflow
- Race conditions

Pure HTTP — no browser required.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
import structlog

logger = structlog.get_logger(__name__)

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False


@dataclass
class WorkflowStep:
    """One HTTP request in a workflow."""
    method: str
    url: str
    headers: dict[str, str] = field(default_factory=dict)
    body: dict | str | None = None
    expected_status: int = 200
    extract_vars: dict[str, str] = field(default_factory=dict)
    # extract_vars: {"var_name": "json.path.to.value"}
    delay_ms: int = 0

    def to_dict(self) -> dict:
        return {
            "method": self.method,
            "url": self.url,
            "expected_status": self.expected_status,
            "has_body": self.body is not None,
            "extracts": list(self.extract_vars.keys()),
        }


@dataclass
class WorkflowResult:
    """Result of replaying a workflow step."""
    step_index: int
    url: str
    method: str
    status: int
    body: str
    duration_ms: float
    extracted_vars: dict[str, str] = field(default_factory=dict)
    passed: bool = True
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "step": self.step_index,
            "url": self.url,
            "method": self.method,
            "status": self.status,
            "body_preview": self.body[:200],
            "duration_ms": round(self.duration_ms, 1),
            "passed": self.passed,
            "extracted_vars": {k: v[:50] for k, v in self.extracted_vars.items()},
            "error": self.error,
        }


def _extract_value(body: str, path: str) -> str:
    """Extract a value from a JSON response using dot notation."""
    try:
        data = json.loads(body)
        parts = path.split(".")
        val = data
        for p in parts:
            if isinstance(val, dict):
                val = val.get(p)
            elif isinstance(val, list) and p.isdigit():
                val = val[int(p)]
            else:
                return ""
        return str(val) if val is not None else ""
    except Exception:
        return ""


def _substitute_vars(text: str, variables: dict[str, str]) -> str:
    """Replace {{var_name}} placeholders with variable values."""
    for k, v in variables.items():
        text = text.replace(f"{{{{{k}}}}}", v)
    return text


async def replay_workflow(
    steps: list[WorkflowStep],
    initial_vars: dict[str, str] | None = None,
    base_url: str = "",
    timeout: float = 10.0,
) -> dict[str, Any]:
    """Replay a workflow and return step results with extracted variables."""
    if not HTTPX_AVAILABLE:
        return {"error": "httpx unavailable", "results": [],
                "fix": "pip install httpx"}

    variables: dict[str, str] = dict(initial_vars or {})
    results: list[WorkflowResult] = []
    success = True

    async with httpx.AsyncClient(timeout=timeout, verify=False,
                                  follow_redirects=True) as client:
        for i, step in enumerate(steps):
            if step.delay_ms > 0:
                import asyncio
                await asyncio.sleep(step.delay_ms / 1000.0)

            # Substitute variables in URL and body
            url = _substitute_vars(step.url, variables)
            if base_url and url.startswith("/"):
                url = base_url + url

            body_str = json.dumps(step.body) if isinstance(step.body, dict) else (step.body or "")
            body_str = _substitute_vars(body_str, variables)

            try:
                headers = {k: _substitute_vars(v, variables)
                          for k, v in step.headers.items()}

                start = time.monotonic()
                if body_str:
                    resp = await client.request(
                        step.method.upper(), url,
                        headers=headers,
                        content=body_str.encode(),
                    )
                else:
                    resp = await client.request(step.method.upper(), url, headers=headers)

                duration = (time.monotonic() - start) * 1000

                # Extract variables from response
                extracted: dict[str, str] = {}
                for var_name, json_path in step.extract_vars.items():
                    val = _extract_value(resp.text, json_path)
                    if val:
                        variables[var_name] = val
                        extracted[var_name] = val

                passed = (resp.status_code == step.expected_status or
                         step.expected_status == 0)

                result = WorkflowResult(
                    step_index=i,
                    url=url,
                    method=step.method,
                    status=resp.status_code,
                    body=resp.text,
                    duration_ms=duration,
                    extracted_vars=extracted,
                    passed=passed,
                )
                results.append(result)

                if not passed:
                    success = False
                    logger.warning("workflow_step_unexpected_status",
                                  step=i, url=url,
                                  expected=step.expected_status,
                                  got=resp.status_code)

            except Exception as e:
                results.append(WorkflowResult(
                    step_index=i, url=url, method=step.method,
                    status=0, body="", duration_ms=0,
                    passed=False, error=str(e),
                ))
                success = False

    return {
        "total_steps": len(steps),
        "completed": len(results),
        "success": success,
        "final_vars": {k: v[:50] for k, v in variables.items()},
        "results": [r.to_dict() for r in results],
        "total_duration_ms": round(sum(r.duration_ms for r in results), 1),
    }
