"""Encrypted Secrets Vault.

HSM-style encrypted vault for:
- API keys
- session tokens
- found credentials
- scan targets auth
- workspace secrets

Uses Fernet symmetric encryption with key rotation support.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

try:
    from cryptography.fernet import Fernet, MultiFernet
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False
    logger.warning("cryptography_not_available")


@dataclass
class VaultSecret:
    id: str
    name: str
    secret_type: str        # api_key, token, credential, found_secret
    encrypted_value: str
    workspace_id: str
    created_at: float = field(default_factory=time.time)
    last_accessed: float = field(default_factory=time.time)
    access_count: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
    tags: list[str] = field(default_factory=list)


class SecretsVault:
    """Encrypted secrets vault with key rotation support."""

    def __init__(self, master_key: str | None = None):
        self._master_key = master_key or os.environ.get("BMX_VAULT_KEY", "")
        self._secrets: dict[str, VaultSecret] = {}
        self._fernet: Any = None

        if CRYPTO_AVAILABLE and self._master_key:
            # Derive a proper 32-byte key from master
            key_bytes = hashlib.sha256(self._master_key.encode()).digest()
            fernet_key = base64.urlsafe_b64encode(key_bytes)
            self._fernet = Fernet(fernet_key)

    def _encrypt(self, value: str) -> str:
        if self._fernet:
            return self._fernet.encrypt(value.encode()).decode()
        # Fallback: base64 (NOT secure, just for dev)
        return base64.b64encode(value.encode()).decode()

    def _decrypt(self, encrypted: str) -> str:
        if self._fernet:
            return self._fernet.decrypt(encrypted.encode()).decode()
        return base64.b64decode(encrypted.encode()).decode()

    def store(
        self,
        name: str,
        value: str,
        secret_type: str,
        workspace_id: str,
        metadata: dict[str, Any] | None = None,
        tags: list[str] | None = None,
    ) -> str:
        """Store an encrypted secret. Returns secret ID."""
        secret_id = hashlib.sha256(
            f"{workspace_id}:{name}:{time.time()}".encode()
        ).hexdigest()[:16]

        secret = VaultSecret(
            id=secret_id,
            name=name,
            secret_type=secret_type,
            encrypted_value=self._encrypt(value),
            workspace_id=workspace_id,
            metadata=metadata or {},
            tags=tags or [],
        )
        self._secrets[secret_id] = secret
        logger.info("vault_stored", id=secret_id, name=name, type=secret_type)
        return secret_id

    def retrieve(self, secret_id: str, workspace_id: str) -> str | None:
        """Retrieve and decrypt a secret."""
        secret = self._secrets.get(secret_id)
        if not secret:
            return None
        if secret.workspace_id != workspace_id:
            logger.warning("vault_unauthorized_access", id=secret_id, workspace=workspace_id)
            return None

        secret.last_accessed = time.time()
        secret.access_count += 1
        return self._decrypt(secret.encrypted_value)

    def list_secrets(
        self, workspace_id: str, secret_type: str | None = None
    ) -> list[dict[str, Any]]:
        """List secrets (metadata only, never values)."""
        return [
            {
                "id": s.id,
                "name": s.name,
                "secret_type": s.secret_type,
                "created_at": s.created_at,
                "last_accessed": s.last_accessed,
                "access_count": s.access_count,
                "tags": s.tags,
                "metadata": {k: v for k, v in s.metadata.items() if k != "value"},
            }
            for s in self._secrets.values()
            if s.workspace_id == workspace_id
            and (not secret_type or s.secret_type == secret_type)
        ]

    def delete(self, secret_id: str, workspace_id: str) -> bool:
        """Delete a secret."""
        secret = self._secrets.get(secret_id)
        if secret and secret.workspace_id == workspace_id:
            del self._secrets[secret_id]
            logger.info("vault_deleted", id=secret_id)
            return True
        return False

    def rotate_key(self, new_master_key: str) -> int:
        """Re-encrypt all secrets with a new master key."""
        if not CRYPTO_AVAILABLE:
            return 0

        # Decrypt all with old key
        decrypted: dict[str, str] = {}
        for sid, secret in self._secrets.items():
            try:
                decrypted[sid] = self._decrypt(secret.encrypted_value)
            except Exception:
                logger.warning("vault_rotate_decrypt_failed", id=sid)

        # Generate new Fernet
        new_key_bytes = hashlib.sha256(new_master_key.encode()).digest()
        new_fernet_key = base64.urlsafe_b64encode(new_key_bytes)
        self._fernet = Fernet(new_fernet_key)
        self._master_key = new_master_key

        # Re-encrypt all
        rotated = 0
        for sid, value in decrypted.items():
            if sid in self._secrets:
                self._secrets[sid].encrypted_value = self._encrypt(value)
                rotated += 1

        logger.info("vault_key_rotated", count=rotated)
        return rotated


# Global vault instance
_vault = SecretsVault()


def get_vault() -> SecretsVault:
    return _vault
