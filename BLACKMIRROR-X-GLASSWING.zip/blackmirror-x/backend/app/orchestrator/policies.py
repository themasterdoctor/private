"""Orchestration policies — safety, scope, rate limiting, approval gates.

Every active task passes through policy checks before execution.
No test runs outside scope. No high-risk test without approval.
"""
from __future__ import annotations

import re
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any
import structlog

from app.orchestrator.task_graph import Task, RiskTier

logger = structlog.get_logger(__name__)


@dataclass
class PolicyViolation:
    policy: str
    reason: str
    task_id: str
    task_name: str
    remediation: str = ""


@dataclass
class ScopePolicy:
    """Validates tasks against declared scope."""
    allowed_domains: list[str] = field(default_factory=list)
    excluded_patterns: list[str] = field(default_factory=list)
    allow_subdomains: bool = True

    def is_in_scope(self, url: str) -> bool:
        if not self.allowed_domains:
            return True  # no scope = allow all (dev mode)
        from urllib.parse import urlparse
        parsed = urlparse(url)
        host = parsed.netloc or parsed.path.split("/")[0]
        host = host.split(":")[0]  # strip port

        # Check exclusions
        for pattern in self.excluded_patterns:
            if re.search(pattern, host):
                return False

        # Check inclusions
        for domain in self.allowed_domains:
            domain = domain.lstrip("*. ")
            if host == domain:
                return True
            if self.allow_subdomains and host.endswith(f".{domain}"):
                return True
        return False

    def validate_task(self, task: Task) -> PolicyViolation | None:
        url = task.input_data.get("url", "")
        if url and not self.is_in_scope(url):
            return PolicyViolation(
                policy="scope",
                reason=f"URL {url!r} is outside declared scope",
                task_id=task.id,
                task_name=task.name,
                remediation="Add this domain to workspace scope or remove from test",
            )
        return None


class RateLimitPolicy:
    """Per-target request rate limiting."""

    def __init__(self, max_rps: float = 5.0, burst: int = 20):
        self.max_rps = max_rps
        self.burst = burst
        self._buckets: dict[str, list[float]] = defaultdict(list)

    def check(self, target: str) -> tuple[bool, float]:
        """Returns (allowed, wait_seconds)."""
        now = time.time()
        window = 1.0 / self.max_rps
        bucket = self._buckets[target]

        # Remove old tokens
        bucket[:] = [t for t in bucket if now - t < window * self.burst]

        if len(bucket) >= self.burst:
            oldest = min(bucket)
            wait = window * self.burst - (now - oldest)
            return False, max(0.0, wait)

        bucket.append(now)
        return True, 0.0

    def validate_task(self, task: Task) -> PolicyViolation | None:
        url = task.input_data.get("url", "")
        if not url:
            return None
        from urllib.parse import urlparse
        host = urlparse(url).netloc or url
        allowed, wait = self.check(host)
        if not allowed:
            return PolicyViolation(
                policy="rate_limit",
                reason=f"Rate limit exceeded for {host}: wait {wait:.1f}s",
                task_id=task.id,
                task_name=task.name,
                remediation=f"Task will be retried after {wait:.1f} seconds",
            )
        return None


@dataclass
class ApprovalPolicy:
    """Human approval gate for high/critical risk tasks."""
    require_approval_for_tier: set[RiskTier] = field(
        default_factory=lambda: {RiskTier.CRITICAL}
    )
    # Per-scan approval overrides: scan_id -> {task_name -> approved}
    _approvals: dict[str, dict[str, bool]] = field(default_factory=dict)

    def validate_task(self, task: Task) -> PolicyViolation | None:
        if task.risk_tier not in self.require_approval_for_tier:
            return None
        scan_approvals = self._approvals.get(task.scan_id, {})
        if not scan_approvals.get(task.name, False):
            task.requires_approval = True
            return PolicyViolation(
                policy="approval_required",
                reason=f"Task {task.name!r} is {task.risk_tier.value} risk and requires human approval",
                task_id=task.id,
                task_name=task.name,
                remediation="POST /api/v1/orchestrator/approve/{task_id} to approve",
            )
        return None

    def approve(self, scan_id: str, task_name: str) -> None:
        if scan_id not in self._approvals:
            self._approvals[scan_id] = {}
        self._approvals[scan_id][task_name] = True

    def revoke(self, scan_id: str, task_name: str) -> None:
        if scan_id in self._approvals:
            self._approvals[scan_id].pop(task_name, None)


class EmergencyStopPolicy:
    """Global + per-scan emergency stop."""

    def __init__(self):
        self._global_stop: bool = False
        self._scan_stops: set[str] = set()

    def stop_all(self) -> None:
        self._global_stop = True
        logger.warning("emergency_stop_global")

    def stop_scan(self, scan_id: str) -> None:
        self._scan_stops.add(scan_id)
        logger.warning("emergency_stop_scan", scan_id=scan_id)

    def resume_scan(self, scan_id: str) -> None:
        self._scan_stops.discard(scan_id)

    def resume_all(self) -> None:
        self._global_stop = False
        self._scan_stops.clear()

    def validate_task(self, task: Task) -> PolicyViolation | None:
        if self._global_stop:
            return PolicyViolation(
                policy="emergency_stop",
                reason="Global emergency stop is active",
                task_id=task.id,
                task_name=task.name,
                remediation="POST /api/v1/workers/resume to resume",
            )
        if task.scan_id in self._scan_stops:
            return PolicyViolation(
                policy="emergency_stop",
                reason=f"Scan {task.scan_id} has been stopped",
                task_id=task.id,
                task_name=task.name,
                remediation=f"POST /api/v1/orchestrator/resume/{task.scan_id}",
            )
        return None


class PolicyEngine:
    """Runs all policies against a task. Returns list of violations."""

    def __init__(
        self,
        scope: ScopePolicy | None = None,
        rate_limit: RateLimitPolicy | None = None,
        approval: ApprovalPolicy | None = None,
        emergency_stop: EmergencyStopPolicy | None = None,
    ):
        self.scope = scope or ScopePolicy()
        self.rate_limit = rate_limit or RateLimitPolicy()
        self.approval = approval or ApprovalPolicy()
        self.emergency_stop = emergency_stop or EmergencyStopPolicy()

    def check(self, task: Task) -> list[PolicyViolation]:
        """Run all policy checks. Returns violations (empty = OK to run)."""
        violations = []
        for policy in [self.emergency_stop, self.scope,
                       self.rate_limit, self.approval]:
            v = policy.validate_task(task)
            if v:
                violations.append(v)
        return violations

    def is_allowed(self, task: Task) -> bool:
        return len(self.check(task)) == 0

    def audit_log(self, task: Task, violations: list[PolicyViolation]) -> None:
        for v in violations:
            logger.warning("policy_violation",
                          policy=v.policy, reason=v.reason,
                          task_id=v.task_id, task_name=v.task_name)
