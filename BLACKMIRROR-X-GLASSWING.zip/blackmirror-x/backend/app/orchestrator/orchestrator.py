"""Orchestrator — Autonomous agent execution engine.

Manages the full scan lifecycle:
  1. Build initial task graph from scan config
  2. Execute tasks respecting dependencies and priorities
  3. Route events between agents via AgentBus
  4. Enforce scope, rate limits, and approval policies
  5. Branch/prune based on evidence confidence
  6. Checkpoint state for crash recovery

Inter-agent collaboration flow:
  ReconAgent → JS_AGENT → API_AGENT → CHAIN_AGENT → COURT_AGENT → REPORT_AGENT
       ↕            ↕           ↕           ↕
                AGENT_BUS (events published at each step)
"""
from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime, timezone
from typing import Any

import structlog

from app.orchestrator.agent_bus import AgentBus, AgentEvent, EventType, bus
from app.orchestrator.task_graph import Task, TaskGraph, TaskStatus, RiskTier
from app.orchestrator.policies import PolicyEngine, ScopePolicy

logger = structlog.get_logger(__name__)


class Orchestrator:
    """Runs agents in dependency order, routing events between them.

    Capabilities:
    - create tasks dynamically during execution
    - stop low-confidence branches
    - escalate high-value findings
    - enforce scope and safety policies
    - checkpoint state for recovery
    """

    MAX_CONCURRENT_TASKS = 3

    def __init__(
        self,
        scan_id: str,
        workspace_id: str,
        scope_domains: list[str] | None = None,
        policy_engine: PolicyEngine | None = None,
        event_bus: AgentBus | None = None,
    ):
        self.scan_id = scan_id
        self.workspace_id = workspace_id
        self.graph = TaskGraph(scan_id, workspace_id)
        self.policy = policy_engine or PolicyEngine(
            scope=ScopePolicy(allowed_domains=scope_domains or [])
        )
        self.bus = event_bus or bus
        self._running = False
        self._semaphore = asyncio.Semaphore(self.MAX_CONCURRENT_TASKS)
        self._completed_ids: set[str] = set()
        self._checkpoints: list[dict] = []

    def plan_scan(self, config: dict[str, Any]) -> TaskGraph:
        """Build initial task graph from scan configuration."""
        domain = config.get("domain", config.get("target", ""))
        scan_type = config.get("scan_type", "full")

        # Phase 1: Recon (always passive)
        t_recon = self.graph.create_task(
            "subdomain_enum", "recon",
            input_data={"domain": domain, "tools": ["subfinder", "amass"]},
            risk_tier=RiskTier.PASSIVE, priority=1, confidence=1.0,
        )

        t_probe = self.graph.create_task(
            "http_probe", "recon",
            input_data={"domain": domain},
            parent_ids=[t_recon.id],
            risk_tier=RiskTier.PASSIVE, priority=2, confidence=0.9,
        )

        # Phase 2: JS and API discovery (passive)
        t_js = self.graph.create_task(
            "js_intelligence", "js_agent",
            input_data={"domain": domain},
            parent_ids=[t_probe.id],
            risk_tier=RiskTier.PASSIVE, priority=3, confidence=0.8,
        )

        t_api = self.graph.create_task(
            "api_discovery", "api_agent",
            input_data={"domain": domain},
            parent_ids=[t_probe.id],
            risk_tier=RiskTier.PASSIVE, priority=3, confidence=0.8,
        )

        if scan_type in ("full", "vuln"):
            # Phase 3: Active vuln testing (medium risk)
            t_vuln = self.graph.create_task(
                "vuln_testing", "vuln_agent",
                input_data={"domain": domain},
                parent_ids=[t_js.id, t_api.id],
                risk_tier=RiskTier.MEDIUM, priority=4, confidence=0.7,
            )

            # Phase 4: Chain reasoning (passive — just analysis)
            t_chain = self.graph.create_task(
                "chain_analysis", "chain_agent",
                input_data={"domain": domain},
                parent_ids=[t_vuln.id],
                risk_tier=RiskTier.PASSIVE, priority=5, confidence=0.6,
            )

            # Phase 5: Court validation
            t_court = self.graph.create_task(
                "court_validation", "court_agent",
                input_data={"domain": domain},
                parent_ids=[t_chain.id],
                risk_tier=RiskTier.PASSIVE, priority=6, confidence=0.6,
            )

            # Phase 6: Report
            self.graph.create_task(
                "report_generation", "report_agent",
                input_data={"domain": domain},
                parent_ids=[t_court.id],
                risk_tier=RiskTier.PASSIVE, priority=7, confidence=0.5,
            )
        else:
            # Recon-only — skip vuln testing
            self.graph.create_task(
                "report_generation", "report_agent",
                input_data={"domain": domain},
                parent_ids=[t_js.id, t_api.id],
                risk_tier=RiskTier.PASSIVE, priority=5, confidence=0.8,
            )

        logger.info("scan_planned",
                   scan_id=self.scan_id, tasks=len(self.graph),
                   scan_type=scan_type, domain=domain)
        return self.graph

    async def run(self) -> dict[str, Any]:
        """Execute the task graph to completion."""
        self._running = True
        await self.bus.publish(AgentEvent(
            event_type=EventType.TASK_CREATED,
            source_agent="orchestrator",
            scan_id=self.scan_id,
            workspace_id=self.workspace_id,
            payload={"message": "Orchestrator started", "tasks": len(self.graph)},
        ))

        while not self.graph.is_complete() and self._running:
            ready = self.graph.get_ready_tasks()
            if not ready:
                await asyncio.sleep(0.5)
                continue

            # Run ready tasks concurrently up to MAX_CONCURRENT_TASKS
            coros = [self._execute_task(t) for t in ready[:self.MAX_CONCURRENT_TASKS]]
            await asyncio.gather(*coros, return_exceptions=True)
            self._checkpoint()

        self._running = False
        return self.graph.to_graph()

    async def _execute_task(self, task: Task) -> None:
        """Execute a single task through the policy engine and agent dispatcher."""
        async with self._semaphore:
            # Policy check
            violations = self.policy.check(task)
            if violations:
                self.policy.audit_log(task, violations)
                # Approval required — don't fail, just block
                approval_needed = any(v.policy == "approval_required" for v in violations)
                if approval_needed:
                    task.status = TaskStatus.BLOCKED
                    return
                # Hard violations (scope, emergency stop) — fail the task
                self.graph.mark_failed(task.id, violations[0].reason)
                return

            self.graph.mark_running(task.id)
            await self.bus.publish(AgentEvent(
                event_type=EventType.TASK_ASSIGNED,
                source_agent="orchestrator",
                scan_id=self.scan_id,
                workspace_id=self.workspace_id,
                payload={"task_id": task.id, "task_name": task.name,
                        "agent": task.agent_type},
            ))

            try:
                result = await self._dispatch(task)
                confidence = result.get("confidence", task.confidence)
                self.graph.mark_completed(task.id, result, confidence)
                self._completed_ids.add(task.id)

                # High confidence? Escalate any blocked children
                if confidence > 0.8:
                    for cid in task.child_ids:
                        self.graph.escalate(cid)

                await self.bus.publish(AgentEvent(
                    event_type=EventType.TASK_COMPLETED,
                    source_agent=task.agent_type,
                    scan_id=self.scan_id,
                    workspace_id=self.workspace_id,
                    payload={"task_id": task.id, "task_name": task.name,
                            "confidence": confidence},
                    confidence=confidence,
                ))

            except Exception as e:
                self.graph.mark_failed(task.id, str(e))
                logger.error("task_execution_failed",
                           task_id=task.id, name=task.name, error=str(e))

    async def _dispatch(self, task: Task) -> dict[str, Any]:
        """Route task to the appropriate agent handler."""
        handlers = {
            "recon":        self._run_recon,
            "js_agent":     self._run_js,
            "api_agent":    self._run_api,
            "vuln_agent":   self._run_vuln,
            "chain_agent":  self._run_chain,
            "court_agent":  self._run_court,
            "report_agent": self._run_report,
        }
        handler = handlers.get(task.agent_type, self._run_generic)
        return await handler(task)

    async def _run_recon(self, task: Task) -> dict:
        from app.agents.recon.agent import ReconAgent
        agent = ReconAgent(scan_id=self.scan_id, workspace_id=self.workspace_id)
        result = await agent.run_full_recon(task.input_data.get("domain", ""), {})
        # Publish discoveries to bus
        for sub in result.get("subdomains", []):
            await self.bus.publish(AgentEvent(
                event_type=EventType.SUBDOMAIN_DISCOVERED,
                source_agent="recon", scan_id=self.scan_id,
                workspace_id=self.workspace_id,
                payload={"host": sub},
            ))
        nsubs = len(result.get("subdomains", []))
        return {"subdomains": nsubs, "urls": len(result.get("urls", [])),
                "confidence": 0.9 if nsubs > 0 else 0.4}

    async def _run_js(self, task: Task) -> dict:
        from app.intelligence.js_ast.js_reverse import JSReverseEngineer
        eng = JSReverseEngineer(scan_id=self.scan_id)
        # JS agent runs against URLs from context — simplified for orchestrator
        findings = {"secrets": 0, "dom_xss": 0, "endpoints": 0}
        for url in task.input_data.get("js_urls", [])[:5]:
            try:
                r = await eng.analyze_url(url)
                findings["secrets"] += len(r.get("secrets", []))
                findings["dom_xss"] += len(r.get("dom_xss_risks", []))
                for secret in r.get("secrets", []):
                    await self.bus.publish(AgentEvent(
                        event_type=EventType.SECRET_FOUND,
                        source_agent="js_agent", scan_id=self.scan_id,
                        workspace_id=self.workspace_id,
                        payload={"url": url, "secret_type": secret.get("secret_type")},
                        confidence=0.8,
                    ))
            except Exception:
                pass
        total = sum(findings.values())
        return {**findings, "confidence": 0.8 if total > 0 else 0.5}

    async def _run_api(self, task: Task) -> dict:
        return {"endpoints_found": 0, "confidence": 0.6}

    async def _run_vuln(self, task: Task) -> dict:
        return {"findings": 0, "confidence": 0.5}

    async def _run_chain(self, task: Task) -> dict:
        return {"chains": 0, "confidence": 0.5}

    async def _run_court(self, task: Task) -> dict:
        return {"verdicts": 0, "confidence": 0.5}

    async def _run_report(self, task: Task) -> dict:
        return {"report_id": "", "confidence": 0.9}

    async def _run_generic(self, task: Task) -> dict:
        logger.warning("unknown_agent_type", agent_type=task.agent_type)
        return {"confidence": 0.3}

    def _checkpoint(self) -> None:
        """Save graph state snapshot for crash recovery."""
        snapshot = {
            "scan_id": self.scan_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "graph": self.graph.stats,
        }
        self._checkpoints.append(snapshot)
        # Keep only last 10
        self._checkpoints = self._checkpoints[-10:]

    def stop(self) -> None:
        """Emergency stop."""
        self._running = False
        self.policy.emergency_stop.stop_scan(self.scan_id)

    def resume(self) -> None:
        self.policy.emergency_stop.resume_scan(self.scan_id)
        self._running = True

    def get_status(self) -> dict:
        return {
            "scan_id": self.scan_id,
            "running": self._running,
            "graph": self.graph.to_graph(),
            "bus_stats": self.bus.stats,
            "checkpoints": len(self._checkpoints),
        }


# Registry of active orchestrators (scan_id -> Orchestrator)
_active: dict[str, Orchestrator] = {}


def get_orchestrator(scan_id: str) -> Orchestrator | None:
    return _active.get(scan_id)


def create_orchestrator(scan_id: str, workspace_id: str,
                        scope_domains: list[str] | None = None) -> Orchestrator:
    orch = Orchestrator(scan_id, workspace_id, scope_domains)
    _active[scan_id] = orch
    return orch


def list_orchestrators() -> list[dict]:
    return [o.get_status() for o in _active.values()]
