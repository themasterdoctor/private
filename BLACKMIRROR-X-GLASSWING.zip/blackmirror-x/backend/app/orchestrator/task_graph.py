"""TaskGraph — directed task dependency graph for agent orchestration.

Tasks are nodes. Dependencies are edges.
The scheduler walks the graph, running tasks whose dependencies are met,
stopping branches when confidence drops below threshold.
"""
from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Awaitable

import structlog

logger = structlog.get_logger(__name__)


class TaskStatus(str, Enum):
    PENDING   = "pending"
    READY     = "ready"      # all deps met
    RUNNING   = "running"
    COMPLETED = "completed"
    FAILED    = "failed"
    ABANDONED = "abandoned"  # low confidence pruned
    BLOCKED   = "blocked"    # waiting for human approval


class RiskTier(str, Enum):
    """Risk tier controls approval requirements and rate limits."""
    PASSIVE   = "passive"    # read-only, no approval needed
    LOW       = "low"        # safe active, no approval needed
    MEDIUM    = "medium"     # active test, no approval needed
    HIGH      = "high"       # destructive-adjacent, needs approval if configured
    CRITICAL  = "critical"   # always requires human approval


@dataclass
class Task:
    """A unit of agent work within the task graph."""
    name: str
    agent_type: str          # which agent handles this
    scan_id: str
    workspace_id: str
    input_data: dict[str, Any] = field(default_factory=dict)
    risk_tier: RiskTier = RiskTier.LOW
    requires_approval: bool = False

    id: str = field(default_factory=lambda: str(uuid.uuid4())[:12])
    status: TaskStatus = TaskStatus.PENDING
    parent_ids: list[str] = field(default_factory=list)   # dependencies
    child_ids: list[str] = field(default_factory=list)    # spawned by this task
    result: dict[str, Any] = field(default_factory=dict)
    error: str = ""
    confidence: float = 0.5
    priority: int = 5        # 1=highest, 10=lowest
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    started_at: str = ""
    completed_at: str = ""

    def is_ready(self, completed_ids: set[str]) -> bool:
        """True when all parent dependencies have completed."""
        return all(pid in completed_ids for pid in self.parent_ids)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "agent_type": self.agent_type,
            "scan_id": self.scan_id,
            "status": self.status.value,
            "risk_tier": self.risk_tier.value,
            "priority": self.priority,
            "confidence": self.confidence,
            "parent_ids": self.parent_ids,
            "child_ids": self.child_ids,
            "requires_approval": self.requires_approval,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "error": self.error,
        }


class TaskGraph:
    """Manages the agent task dependency graph for a scan.

    Supports:
    - Adding tasks with dependencies
    - Spawning child tasks at runtime
    - Priority-based scheduling
    - Confidence-based pruning (abandon low-confidence branches)
    - Graph visualization as adjacency list
    """

    MIN_CONFIDENCE = 0.15  # tasks below this are auto-abandoned

    def __init__(self, scan_id: str, workspace_id: str):
        self.scan_id = scan_id
        self.workspace_id = workspace_id
        self._tasks: dict[str, Task] = {}
        self._lock = asyncio.Lock()

    def add_task(self, task: Task) -> Task:
        """Add a task to the graph."""
        self._tasks[task.id] = task
        # Register as child of parents
        for pid in task.parent_ids:
            if pid in self._tasks:
                self._tasks[pid].child_ids.append(task.id)
        logger.debug("task_added", task_id=task.id, name=task.name,
                    agent=task.agent_type, priority=task.priority)
        return task

    def create_task(self, name: str, agent_type: str,
                    input_data: dict | None = None,
                    parent_ids: list[str] | None = None,
                    risk_tier: RiskTier = RiskTier.LOW,
                    priority: int = 5,
                    confidence: float = 0.5) -> Task:
        """Convenience factory: create and add a task."""
        task = Task(
            name=name,
            agent_type=agent_type,
            scan_id=self.scan_id,
            workspace_id=self.workspace_id,
            input_data=input_data or {},
            parent_ids=parent_ids or [],
            risk_tier=risk_tier,
            priority=priority,
            confidence=confidence,
        )
        return self.add_task(task)

    def get_ready_tasks(self) -> list[Task]:
        """Return tasks whose dependencies are all completed, sorted by priority."""
        completed = {t.id for t in self._tasks.values()
                    if t.status == TaskStatus.COMPLETED}
        ready = []
        for t in self._tasks.values():
            if t.status == TaskStatus.PENDING and t.is_ready(completed):
                if t.confidence < self.MIN_CONFIDENCE:
                    t.status = TaskStatus.ABANDONED
                    logger.info("task_abandoned_low_confidence",
                               task_id=t.id, confidence=t.confidence)
                    continue
                ready.append(t)
        return sorted(ready, key=lambda t: (t.priority, t.created_at))

    def mark_running(self, task_id: str) -> Task | None:
        t = self._tasks.get(task_id)
        if t:
            t.status = TaskStatus.RUNNING
            t.started_at = datetime.now(timezone.utc).isoformat()
        return t

    def mark_completed(self, task_id: str, result: dict | None = None,
                       confidence: float | None = None) -> Task | None:
        t = self._tasks.get(task_id)
        if t:
            t.status = TaskStatus.COMPLETED
            t.result = result or {}
            t.completed_at = datetime.now(timezone.utc).isoformat()
            if confidence is not None:
                t.confidence = confidence
        return t

    def mark_failed(self, task_id: str, error: str) -> Task | None:
        t = self._tasks.get(task_id)
        if t:
            t.status = TaskStatus.FAILED
            t.error = error
            t.completed_at = datetime.now(timezone.utc).isoformat()
            # Cascade: abandon children
            self._cascade_abandon(task_id, f"parent failed: {error}")
        return t

    def _cascade_abandon(self, task_id: str, reason: str) -> None:
        task = self._tasks.get(task_id)
        if not task:
            return
        for cid in task.child_ids:
            child = self._tasks.get(cid)
            if child and child.status in (TaskStatus.PENDING, TaskStatus.READY):
                child.status = TaskStatus.ABANDONED
                child.error = reason
                self._cascade_abandon(cid, reason)

    def update_confidence(self, task_id: str, new_confidence: float) -> None:
        """Update task confidence; abandon if below threshold."""
        t = self._tasks.get(task_id)
        if t:
            t.confidence = new_confidence
            if new_confidence < self.MIN_CONFIDENCE and t.status == TaskStatus.PENDING:
                t.status = TaskStatus.ABANDONED
                self._cascade_abandon(task_id, f"confidence too low: {new_confidence:.2f}")

    def escalate(self, task_id: str) -> None:
        """Boost task priority to highest."""
        t = self._tasks.get(task_id)
        if t:
            t.priority = 1
            logger.info("task_escalated", task_id=task_id, name=t.name)

    def is_complete(self) -> bool:
        """True when all tasks are in a terminal state."""
        return all(t.status in (TaskStatus.COMPLETED, TaskStatus.FAILED,
                                TaskStatus.ABANDONED)
                  for t in self._tasks.values())

    def to_graph(self) -> dict:
        """Return graph as adjacency list + node metadata."""
        return {
            "nodes": [t.to_dict() for t in self._tasks.values()],
            "edges": [
                {"from": pid, "to": t.id, "scan_id": self.scan_id}
                for t in self._tasks.values()
                for pid in t.parent_ids
            ],
            "stats": self.stats,
        }

    @property
    def stats(self) -> dict:
        counts: dict[str, int] = {}
        for t in self._tasks.values():
            counts[t.status.value] = counts.get(t.status.value, 0) + 1
        return {
            "total": len(self._tasks),
            **counts,
            "is_complete": self.is_complete(),
        }

    def __len__(self) -> int:
        return len(self._tasks)
