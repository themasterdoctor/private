"""AgentBus — Pub/Sub event bus for inter-agent communication.

Agents publish typed events to named topics.
Other agents subscribe to topics and receive events asynchronously.
All events are persisted to the agent_events DB table.

This is the communication backbone of the AVROS orchestration system.
Works fully in-process without external message broker.
For distributed workers, Redis pub/sub is used when available.
"""
from __future__ import annotations

import asyncio
import json
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Awaitable
import structlog

logger = structlog.get_logger(__name__)


class EventType(str, Enum):
    # Discovery events
    ENDPOINT_DISCOVERED    = "endpoint.discovered"
    SUBDOMAIN_DISCOVERED   = "subdomain.discovered"
    JS_FILE_FOUND          = "js.file_found"
    SECRET_FOUND           = "secret.found"
    PARAMETER_FOUND        = "parameter.found"

    # Vulnerability events
    VULN_CANDIDATE         = "vuln.candidate"
    VULN_CONFIRMED         = "vuln.confirmed"
    VULN_REJECTED          = "vuln.rejected"
    VULN_ESCALATED         = "vuln.escalated"

    # Chain events
    CHAIN_UPDATED          = "chain.updated"
    CHAIN_COMPLETED        = "chain.completed"

    # Task lifecycle
    TASK_CREATED           = "task.created"
    TASK_ASSIGNED          = "task.assigned"
    TASK_COMPLETED         = "task.completed"
    TASK_FAILED            = "task.failed"
    TASK_ABANDONED         = "task.abandoned"

    # Evidence
    EVIDENCE_STORED        = "evidence.stored"
    SCREENSHOT_TAKEN       = "screenshot.taken"

    # Court
    COURT_VERDICT          = "court.verdict"

    # Report
    REPORT_SECTION_READY   = "report.section_ready"

    # Control
    EMERGENCY_STOP         = "control.emergency_stop"
    SCAN_PAUSED            = "control.scan_paused"
    SCAN_RESUMED           = "control.scan_resumed"
    CONFIDENCE_LOW         = "control.confidence_low"
    CONFIDENCE_HIGH        = "control.confidence_high"


@dataclass
class AgentEvent:
    """A message published on the AgentBus."""
    event_type: EventType
    source_agent: str
    scan_id: str
    workspace_id: str
    payload: dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.5
    requires_human_approval: bool = False
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:12])
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict:
        d = asdict(self)
        d["event_type"] = self.event_type.value
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict())


# Type alias for subscribers
Subscriber = Callable[[AgentEvent], Awaitable[None]]


class AgentBus:
    """In-process async event bus with optional Redis pub/sub bridge.

    Usage:
        bus = AgentBus()
        bus.subscribe(EventType.VULN_CONFIRMED, my_handler)
        await bus.publish(AgentEvent(EventType.VULN_CONFIRMED, ...))
    """

    def __init__(self):
        self._subscribers: dict[str, list[Subscriber]] = {}
        self._wildcard_subscribers: list[Subscriber] = []
        self._event_log: list[AgentEvent] = []
        self._max_log_size: int = 10_000
        self._redis_available: bool = False
        self._pending_approvals: dict[str, AgentEvent] = {}

    async def setup_redis(self, redis_url: str) -> bool:
        """Optionally bridge events to Redis for distributed workers."""
        try:
            import aioredis
            self._redis = await aioredis.from_url(redis_url)
            self._redis_available = True
            logger.info("agent_bus_redis_connected", url=redis_url)
            return True
        except Exception as e:
            logger.warning("agent_bus_redis_unavailable", reason=str(e))
            return False

    def subscribe(self, event_type: EventType | str, handler: Subscriber) -> None:
        """Subscribe to a specific event type."""
        key = event_type.value if isinstance(event_type, EventType) else event_type
        if key not in self._subscribers:
            self._subscribers[key] = []
        self._subscribers[key].append(handler)

    def subscribe_all(self, handler: Subscriber) -> None:
        """Subscribe to all events."""
        self._wildcard_subscribers.append(handler)

    def unsubscribe(self, event_type: EventType | str, handler: Subscriber) -> None:
        key = event_type.value if isinstance(event_type, EventType) else event_type
        self._subscribers.get(key, []).remove(handler)

    async def publish(self, event: AgentEvent) -> int:
        """Publish event to all subscribers. Returns count of handlers called."""
        # Human approval gate
        if event.requires_human_approval:
            self._pending_approvals[event.id] = event
            logger.info("agent_bus_approval_required",
                       event_id=event.id, event_type=event.event_type.value,
                       agent=event.source_agent)
            return 0

        # Log event
        self._event_log.append(event)
        if len(self._event_log) > self._max_log_size:
            self._event_log = self._event_log[-self._max_log_size:]

        # Deliver to typed subscribers
        key = event.event_type.value
        handlers = self._subscribers.get(key, []) + self._wildcard_subscribers
        called = 0
        for handler in handlers:
            try:
                await handler(event)
                called += 1
            except Exception as e:
                logger.error("agent_bus_handler_error",
                           handler=handler.__name__, error=str(e),
                           event_type=key)

        # Bridge to Redis if available
        if self._redis_available:
            try:
                await self._redis.publish(f"bmx:events:{key}", event.to_json())
            except Exception:
                pass

        logger.debug("agent_bus_published",
                    event_type=key, handlers=called, scan_id=event.scan_id)
        return called

    async def approve(self, event_id: str) -> bool:
        """Approve a pending human-approval event and deliver it."""
        event = self._pending_approvals.pop(event_id, None)
        if not event:
            return False
        event.requires_human_approval = False
        await self.publish(event)
        return True

    def get_events(self, scan_id: str | None = None,
                   event_type: EventType | None = None,
                   limit: int = 100) -> list[dict]:
        """Retrieve recent events from in-memory log."""
        events = self._event_log
        if scan_id:
            events = [e for e in events if e.scan_id == scan_id]
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        return [e.to_dict() for e in events[-limit:]]

    def get_pending_approvals(self, scan_id: str | None = None) -> list[dict]:
        events = list(self._pending_approvals.values())
        if scan_id:
            events = [e for e in events if e.scan_id == scan_id]
        return [e.to_dict() for e in events]

    @property
    def stats(self) -> dict:
        return {
            "total_events": len(self._event_log),
            "pending_approvals": len(self._pending_approvals),
            "subscriber_count": sum(len(v) for v in self._subscribers.values()),
            "redis_bridge": self._redis_available,
        }


# Global bus instance — shared across all agents in a process
bus = AgentBus()
