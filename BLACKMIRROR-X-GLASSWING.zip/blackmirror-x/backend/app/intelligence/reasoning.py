"""Agent Reasoning Stream — base class that gives every agent
a structured, live-streamable reasoning trace."""
from __future__ import annotations

import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, AsyncGenerator, Callable

import structlog

logger = structlog.get_logger(__name__)


class ReasoningStepType(str, Enum):
    HYPOTHESIS   = "hypothesis"
    ASSUMPTION   = "assumption"
    EVIDENCE     = "evidence"
    DECISION     = "decision"
    PAYLOAD_SEL  = "payload_selection"
    TARGET_PRIO  = "target_prioritization"
    CONFIDENCE   = "confidence_update"
    BRANCH       = "branch"
    ABANDON      = "abandon"
    ESCALATE     = "escalate"
    CONCLUSION   = "conclusion"
    TOOL_CALL    = "tool_call"
    OBSERVATION  = "observation"


@dataclass
class ReasoningStep:
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    step_type: ReasoningStepType = ReasoningStepType.OBSERVATION
    content: str = ""
    confidence: float = 0.5          # 0.0–1.0
    evidence_refs: list[str] = field(default_factory=list)
    payload_rationale: str = ""
    target_rationale: str = ""
    assumptions: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    agent_id: str = ""
    scan_id: str = ""

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["step_type"] = self.step_type.value
        return d

    def to_sse(self) -> str:
        return f"data: {json.dumps(self.to_dict())}\n\n"


@dataclass
class ReasoningTrace:
    agent_id: str
    scan_id: str
    steps: list[ReasoningStep] = field(default_factory=list)
    overall_confidence: float = 0.5
    started_at: float = field(default_factory=time.time)
    completed_at: float | None = None

    def add(self, step: ReasoningStep) -> ReasoningStep:
        step.agent_id = self.agent_id
        step.scan_id = self.scan_id
        self.steps.append(step)
        return step

    def finalize(self) -> None:
        self.completed_at = time.time()
        if self.steps:
            # Overall confidence = weighted average of step confidences
            self.overall_confidence = sum(s.confidence for s in self.steps) / len(self.steps)


class ReasoningAgentBase:
    """
    Base class for all BLACKMIRROR-X agents.
    Provides:
    - Structured reasoning trace
    - Live SSE emission of reasoning steps
    - Confidence tracking
    - Assumption logging
    - Evidence reference tracking
    """

    agent_name: str = "base_agent"

    def __init__(self, scan_id: str = "", workspace_id: str = ""):
        self.scan_id = scan_id
        self.workspace_id = workspace_id
        self.trace = ReasoningTrace(agent_id=self.agent_name, scan_id=scan_id)
        self._stream_callbacks: list[Callable[[ReasoningStep], None]] = []
        self._redis_channel: str | None = None

    def on_step(self, callback: Callable[[ReasoningStep], None]) -> None:
        """Register a callback for each reasoning step (for SSE streaming)."""
        self._stream_callbacks.append(callback)

    def _emit(self, step: ReasoningStep) -> ReasoningStep:
        """Emit a reasoning step to all registered callbacks."""
        self.trace.add(step)
        for cb in self._stream_callbacks:
            try:
                cb(step)
            except Exception as e:
                logger.warning("reasoning_emit_failed", error=str(e))
        return step

    # ─── Convenience builders ─────────────────────────────────────────────────

    def think(self, content: str, confidence: float = 0.5,
               assumptions: list[str] | None = None) -> ReasoningStep:
        return self._emit(ReasoningStep(
            step_type=ReasoningStepType.OBSERVATION,
            content=content,
            confidence=confidence,
            assumptions=assumptions or [],
        ))

    def hypothesize(self, hypothesis: str, confidence: float = 0.5,
                    rationale: str = "", assumptions: list[str] | None = None) -> ReasoningStep:
        return self._emit(ReasoningStep(
            step_type=ReasoningStepType.HYPOTHESIS,
            content=hypothesis,
            confidence=confidence,
            target_rationale=rationale,
            assumptions=assumptions or [],
        ))

    def prioritize_target(self, target: str, rationale: str,
                           confidence: float = 0.7) -> ReasoningStep:
        return self._emit(ReasoningStep(
            step_type=ReasoningStepType.TARGET_PRIO,
            content=f"PRIORITIZING: {target}",
            target_rationale=rationale,
            confidence=confidence,
        ))

    def select_payload(self, payload: str, rationale: str,
                        context: str = "", confidence: float = 0.6) -> ReasoningStep:
        return self._emit(ReasoningStep(
            step_type=ReasoningStepType.PAYLOAD_SEL,
            content=f"PAYLOAD: {payload[:120]}",
            payload_rationale=rationale,
            confidence=confidence,
            metadata={"context": context, "full_payload": payload},
        ))

    def record_evidence(self, description: str, refs: list[str],
                         confidence: float = 0.8) -> ReasoningStep:
        return self._emit(ReasoningStep(
            step_type=ReasoningStepType.EVIDENCE,
            content=description,
            evidence_refs=refs,
            confidence=confidence,
        ))

    def decide(self, decision: str, rationale: str,
                confidence: float = 0.7) -> ReasoningStep:
        return self._emit(ReasoningStep(
            step_type=ReasoningStepType.DECISION,
            content=decision,
            target_rationale=rationale,
            confidence=confidence,
        ))

    def abandon_path(self, reason: str, path: str = "") -> ReasoningStep:
        return self._emit(ReasoningStep(
            step_type=ReasoningStepType.ABANDON,
            content=f"ABANDONING: {path or 'current path'} — {reason}",
            confidence=0.1,
        ))

    def escalate_path(self, reason: str, next_step: str = "") -> ReasoningStep:
        return self._emit(ReasoningStep(
            step_type=ReasoningStepType.ESCALATE,
            content=f"ESCALATING: {reason}",
            target_rationale=next_step,
            confidence=0.9,
        ))

    def conclude(self, conclusion: str, confidence: float,
                  evidence_refs: list[str] | None = None) -> ReasoningStep:
        step = self._emit(ReasoningStep(
            step_type=ReasoningStepType.CONCLUSION,
            content=conclusion,
            confidence=confidence,
            evidence_refs=evidence_refs or [],
        ))
        self.trace.finalize()
        return step

    async def stream_trace(self) -> AsyncGenerator[str, None]:
        """Yield SSE-formatted reasoning steps as they're added."""
        seen = 0
        while True:
            while seen < len(self.trace.steps):
                yield self.trace.steps[seen].to_sse()
                seen += 1
            await asyncio.sleep(0.05)
            if self.trace.completed_at:
                break
        yield "data: {\"type\": \"trace_complete\", \"confidence\": " + str(self.trace.overall_confidence) + "}\n\n"
