"""Workspace Intelligence Memory.

Persists and retrieves:
- discovered technologies
- historical findings
- false positives
- payload success rates per endpoint type
- accepted/rejected reports
- target-specific quirks (WAF, rate limits, auth patterns)
- authentication patterns
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field, asdict
from typing import Any

import structlog
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.dialects.postgresql import insert

from app.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class PayloadRecord:
    payload: str
    vuln_type: str
    success_count: int = 0
    attempt_count: int = 0
    waf_blocked_count: int = 0
    contexts: list[str] = field(default_factory=list)  # html, js, attr, url

    @property
    def success_rate(self) -> float:
        if not self.attempt_count:
            return 0.0
        return self.success_count / self.attempt_count

    @property
    def waf_block_rate(self) -> float:
        if not self.attempt_count:
            return 0.0
        return self.waf_blocked_count / self.attempt_count


@dataclass
class TargetQuirk:
    key: str
    value: str
    confidence: float = 0.8
    observed_at: float = field(default_factory=time.time)


@dataclass
class WorkspaceMemory:
    workspace_id: str
    technologies: dict[str, float] = field(default_factory=dict)  # tech -> confidence
    auth_patterns: list[str] = field(default_factory=list)
    quirks: list[TargetQuirk] = field(default_factory=list)
    payload_records: dict[str, PayloadRecord] = field(default_factory=dict)
    false_positive_signatures: list[str] = field(default_factory=list)
    successful_vuln_types: dict[str, int] = field(default_factory=dict)
    rejected_vuln_types: dict[str, int] = field(default_factory=dict)
    endpoint_sensitivity: dict[str, float] = field(default_factory=dict)
    total_scans: int = 0
    last_updated: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["payload_records"] = {
            k: {
                "payload": v.payload,
                "vuln_type": v.vuln_type,
                "success_rate": v.success_rate,
                "attempt_count": v.attempt_count,
                "success_count": v.success_count,
                "waf_block_rate": v.waf_block_rate,
            }
            for k, v in self.payload_records.items()
        }
        return d

    def best_payloads_for(self, vuln_type: str, top_k: int = 5) -> list[str]:
        """Return best performing payloads for a given vuln type."""
        candidates = [
            pr for pr in self.payload_records.values()
            if pr.vuln_type == vuln_type and pr.attempt_count >= 2
        ]
        candidates.sort(key=lambda x: x.success_rate - x.waf_block_rate * 0.5, reverse=True)
        return [pr.payload for pr in candidates[:top_k]]

    def record_payload_attempt(self, payload: str, vuln_type: str,
                                success: bool, waf_blocked: bool = False,
                                context: str = "") -> None:
        key = f"{vuln_type}:{hash(payload) % 100000}"
        if key not in self.payload_records:
            self.payload_records[key] = PayloadRecord(
                payload=payload, vuln_type=vuln_type
            )
        pr = self.payload_records[key]
        pr.attempt_count += 1
        if success:
            pr.success_count += 1
        if waf_blocked:
            pr.waf_blocked_count += 1
        if context and context not in pr.contexts:
            pr.contexts.append(context)
        self.last_updated = time.time()

    def record_finding(self, vuln_type: str, confirmed: bool) -> None:
        if confirmed:
            self.successful_vuln_types[vuln_type] = self.successful_vuln_types.get(vuln_type, 0) + 1
        else:
            self.rejected_vuln_types[vuln_type] = self.rejected_vuln_types.get(vuln_type, 0) + 1
        self.last_updated = time.time()

    def add_technology(self, tech: str, confidence: float = 0.8) -> None:
        existing = self.technologies.get(tech, 0.0)
        self.technologies[tech] = max(existing, confidence)

    def add_quirk(self, key: str, value: str, confidence: float = 0.8) -> None:
        for q in self.quirks:
            if q.key == key:
                q.value = value
                q.confidence = max(q.confidence, confidence)
                q.observed_at = time.time()
                return
        self.quirks.append(TargetQuirk(key=key, value=value, confidence=confidence))

    def is_false_positive_signature(self, signature: str) -> bool:
        return any(fp in signature for fp in self.false_positive_signatures)

    def endpoint_risk_score(self, url: str) -> float:
        """Estimate risk score for an endpoint based on memory."""
        base = 0.5
        url_lower = url.lower()

        # Boost for historically successful endpoint types
        if any(t in url_lower for t in ["admin", "api", "graphql"]):
            base += 0.2
        if any(t in url_lower for t in ["upload", "import", "export"]):
            base += 0.15
        if any(t in url_lower for t in ["user", "account", "profile"]):
            base += 0.10

        # Penalty for known false positive patterns
        if any(fp in url.lower() for fp in self.false_positive_signatures):
            base -= 0.3

        return min(1.0, max(0.0, base))

    def scan_priority_matrix(self) -> dict[str, float]:
        """Return a priority matrix for vuln types based on historical data."""
        matrix: dict[str, float] = {}
        all_types = set(list(self.successful_vuln_types.keys()) + list(self.rejected_vuln_types.keys()))

        for vt in all_types:
            successes = self.successful_vuln_types.get(vt, 0)
            rejections = self.rejected_vuln_types.get(vt, 0)
            total = successes + rejections
            if total == 0:
                matrix[vt] = 0.5
            else:
                # Wilson score lower bound approximation
                ratio = successes / total
                z = 1.96  # 95% confidence
                n = total
                matrix[vt] = (ratio + z*z/(2*n) - z*(ratio*(1-ratio)/n + z*z/(4*n*n))**0.5) / (1 + z*z/n)

        return matrix


# ─── DB-backed persistence ────────────────────────────────────────────────────

class WorkspaceMemoryService:
    """Manages workspace memory persistence in PostgreSQL."""

    _cache: dict[str, WorkspaceMemory] = {}

    @classmethod
    async def load(cls, workspace_id: str, db: AsyncSession) -> WorkspaceMemory:
        """Load workspace memory from DB or cache."""
        if workspace_id in cls._cache:
            return cls._cache[workspace_id]

        # Try to load from DB (stored as JSON in a dedicated table)
        try:
            from sqlalchemy import text
            result = await db.execute(
                text("SELECT memory_json FROM workspace_memory WHERE workspace_id = :wid"),
                {"wid": workspace_id},
            )
            row = result.fetchone()
            if row and row[0]:
                data = json.loads(row[0]) if isinstance(row[0], str) else row[0]
                mem = cls._from_dict(workspace_id, data)
                cls._cache[workspace_id] = mem
                return mem
        except Exception as e:
            logger.debug("memory_load_fallback", error=str(e))

        mem = WorkspaceMemory(workspace_id=workspace_id)
        cls._cache[workspace_id] = mem
        return mem

    @classmethod
    async def save(cls, memory: WorkspaceMemory, db: AsyncSession) -> None:
        """Persist workspace memory to DB."""
        cls._cache[memory.workspace_id] = memory
        try:
            from sqlalchemy import text
            data = json.dumps(memory.to_dict())
            await db.execute(
                text("""
                    INSERT INTO workspace_memory (workspace_id, memory_json, updated_at)
                    VALUES (:wid, :data, NOW())
                    ON CONFLICT (workspace_id) DO UPDATE
                    SET memory_json = :data, updated_at = NOW()
                """),
                {"wid": memory.workspace_id, "data": data},
            )
            await db.commit()
        except Exception as e:
            logger.warning("memory_save_failed", error=str(e))

    @classmethod
    def _from_dict(cls, workspace_id: str, data: dict[str, Any]) -> WorkspaceMemory:
        mem = WorkspaceMemory(workspace_id=workspace_id)
        mem.technologies = data.get("technologies", {})
        mem.auth_patterns = data.get("auth_patterns", [])
        mem.false_positive_signatures = data.get("false_positive_signatures", [])
        mem.successful_vuln_types = data.get("successful_vuln_types", {})
        mem.rejected_vuln_types = data.get("rejected_vuln_types", {})
        mem.endpoint_sensitivity = data.get("endpoint_sensitivity", {})
        mem.total_scans = data.get("total_scans", 0)

        for k, v in data.get("payload_records", {}).items():
            pr = PayloadRecord(
                payload=v.get("payload", ""),
                vuln_type=v.get("vuln_type", ""),
                success_count=v.get("success_count", 0),
                attempt_count=v.get("attempt_count", 0),
                waf_blocked_count=v.get("waf_blocked_count", 0),
            )
            mem.payload_records[k] = pr

        for q in data.get("quirks", []):
            mem.quirks.append(TargetQuirk(
                key=q.get("key", ""),
                value=q.get("value", ""),
                confidence=q.get("confidence", 0.8),
                observed_at=q.get("observed_at", time.time()),
            ))

        return mem

    @classmethod
    async def get_memory_for_api(cls, workspace_id: str, db: AsyncSession) -> dict[str, Any]:
        """Return memory summary for API responses."""
        mem = await cls.load(workspace_id, db)
        return {
            "workspace_id": workspace_id,
            "technologies": mem.technologies,
            "total_scans": mem.total_scans,
            "successful_vuln_types": mem.successful_vuln_types,
            "rejected_vuln_types": mem.rejected_vuln_types,
            "payload_count": len(mem.payload_records),
            "quirk_count": len(mem.quirks),
            "false_positive_count": len(mem.false_positive_signatures),
            "priority_matrix": mem.scan_priority_matrix(),
            "quirks": [{"key": q.key, "value": q.value[:100], "confidence": q.confidence} for q in mem.quirks[:20]],
            "top_payloads": {
                vt: mem.best_payloads_for(vt, 3)
                for vt in ["xss", "sqli", "ssrf", "ssti"]
            },
            "last_updated": mem.last_updated,
        }
