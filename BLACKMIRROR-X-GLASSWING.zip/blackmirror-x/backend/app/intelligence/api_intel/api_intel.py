"""API Exploitation Intelligence.

- GraphQL abuse analyzer
- BOLA/IDOR candidate scorer
- Mass assignment testing
- Privilege-diff engine
- Object enumeration analysis
- Shadow endpoint detection
- Undocumented route discovery
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urlparse, urlencode

import httpx

from app.intelligence.reasoning import ReasoningAgentBase
from app.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class APIFinding:
    finding_type: str
    severity: str
    title: str
    description: str
    url: str
    method: str = "GET"
    payload: str = ""
    evidence: str = ""
    confidence: float = 0.7
    cvss_score: float = 0.0


class APIExploitIntelligence(ReasoningAgentBase):
    """Comprehensive API exploitation intelligence system."""

    agent_name = "api_intel"

    def __init__(self, scan_id: str = "", workspace_id: str = ""):
        super().__init__(scan_id, workspace_id)
        self._client: httpx.AsyncClient | None = None

    def _get_client(self) -> httpx.AsyncClient:
        if not self._client:
            self._client = httpx.AsyncClient(
                timeout=10,
                follow_redirects=True,
                verify=False,
                headers={"User-Agent": "Mozilla/5.0 (Security Research)"},
            )
        return self._client

    # ─── GraphQL Analyzer ────────────────────────────────────────────────────

    async def analyze_graphql(
        self, endpoint: str, auth_headers: dict[str, str] | None = None
    ) -> list[APIFinding]:
        """Comprehensive GraphQL security analysis."""
        findings: list[APIFinding] = []
        client = self._get_client()
        headers = {**(auth_headers or {}), "Content-Type": "application/json"}

        self.think(f"Analyzing GraphQL endpoint: {endpoint}", confidence=0.85)

        # 1. Introspection check
        introspection_query = '{"query": "{__schema{types{name fields{name type{name}}}}}"}'
        try:
            resp = await client.post(endpoint, content=introspection_query, headers=headers)
            if resp.status_code == 200 and "__schema" in resp.text:
                findings.append(APIFinding(
                    finding_type="graphql_introspection",
                    severity="medium",
                    title="GraphQL introspection enabled in production",
                    description="Introspection exposes the full API schema including all types, fields, and relationships. Attackers can use this to discover hidden functionality and craft targeted attacks.",
                    url=endpoint,
                    method="POST",
                    payload=introspection_query,
                    evidence=f"Schema returned: {resp.text[:300]}",
                    confidence=0.98,
                    cvss_score=5.3,
                ))
                self.escalate_path("GraphQL introspection confirmed", "Extract full schema, search for admin mutations")
        except Exception as e:
            logger.debug("graphql_introspection_error", error=str(e))

        # 2. Batch attack (query arrays)
        batch_query = json.dumps([
            {"query": "{__typename}"},
            {"query": "{__typename}"},
            {"query": "{__typename}"},
        ] * 50)
        try:
            resp = await client.post(endpoint, content=batch_query, headers=headers)
            if resp.status_code == 200 and isinstance(json.loads(resp.text), list):
                findings.append(APIFinding(
                    finding_type="graphql_batch_attack",
                    severity="medium",
                    title="GraphQL batch queries enabled",
                    description="GraphQL accepts batched queries (arrays), enabling DoS and rate limit bypass attacks.",
                    url=endpoint,
                    method="POST",
                    payload="[{query},{query},...×100]",
                    evidence=f"Array response returned for batch query",
                    confidence=0.90,
                    cvss_score=5.8,
                ))
        except Exception:
            pass

        # 3. Depth limit check (nested queries)
        deep_query = '{"query": "{ a: __typename { a: __typename { a: __typename { a: __typename { a: __typename { a: __typename } } } } } } }"}'
        try:
            resp = await client.post(endpoint, content=deep_query, headers=headers)
            if resp.status_code == 200 and "a" in resp.text:
                findings.append(APIFinding(
                    finding_type="graphql_no_depth_limit",
                    severity="low",
                    title="No GraphQL query depth limit",
                    description="Deep nested queries are accepted, enabling denial-of-service via circular/deeply nested queries.",
                    url=endpoint,
                    confidence=0.75,
                    cvss_score=4.3,
                ))
        except Exception:
            pass

        # 4. Suggestion disclosure (field enumeration via typos)
        suggestion_query = '{"query": "{usr{id}}"}'
        try:
            resp = await client.post(endpoint, content=suggestion_query, headers=headers)
            if resp.status_code == 200 and "Did you mean" in resp.text:
                findings.append(APIFinding(
                    finding_type="graphql_field_suggestion",
                    severity="low",
                    title="GraphQL field suggestions enabled",
                    description="Error responses include field name suggestions, aiding schema enumeration even without introspection.",
                    url=endpoint,
                    evidence=resp.text[:200],
                    confidence=0.95,
                    cvss_score=3.7,
                ))
        except Exception:
            pass

        self.conclude(f"GraphQL analysis: {len(findings)} findings", confidence=0.85)
        return findings

    # ─── BOLA/IDOR Scorer ────────────────────────────────────────────────────

    def score_idor_candidates(self, urls: list[str]) -> list[dict[str, Any]]:
        """Score URLs as BOLA/IDOR candidates."""
        candidates: list[dict[str, Any]] = []

        # Patterns that suggest object references
        id_patterns = [
            (r'/(\d{1,10})(?:/|$|\?)', "numeric_id", 0.80),
            (r'/([0-9a-f-]{36})(?:/|$|\?)', "uuid", 0.85),
            (r'[?&](user_?id|account_?id|customer_?id|order_?id)=(\d+)', "id_param", 0.90),
            (r'[?&](id|uid|pid|oid|vid)=(\d+)', "generic_id_param", 0.75),
            (r'/users?/([^/]+)', "user_path", 0.85),
            (r'/accounts?/([^/]+)', "account_path", 0.85),
            (r'/orders?/([^/]+)', "order_path", 0.80),
            (r'/documents?/([^/]+)', "document_path", 0.85),
            (r'/files?/([^/]+)', "file_path", 0.80),
            (r'/profiles?/([^/]+)', "profile_path", 0.80),
            (r'/([a-zA-Z0-9_-]{20,64})(?:/|$)', "opaque_id", 0.60),
        ]

        for url in urls:
            for pattern, pattern_type, base_confidence in id_patterns:
                match = re.search(pattern, url, re.IGNORECASE)
                if match:
                    extracted_id = match.group(1)
                    confidence = base_confidence

                    # Boost confidence for admin paths
                    if any(x in url.lower() for x in ["admin", "manage", "dashboard"]):
                        confidence = min(0.95, confidence + 0.10)

                    # Boost for API paths
                    if "/api/" in url.lower():
                        confidence = min(0.95, confidence + 0.05)

                    self.hypothesize(
                        f"IDOR candidate: {url[:80]} [{pattern_type}]",
                        confidence=confidence,
                        rationale=f"Found {pattern_type} pattern: {extracted_id}",
                    )

                    candidates.append({
                        "url": url,
                        "pattern_type": pattern_type,
                        "extracted_id": extracted_id,
                        "confidence": confidence,
                        "test_suggestions": self._idor_test_suggestions(url, extracted_id, pattern_type),
                    })
                    break

        # Sort by confidence
        candidates.sort(key=lambda x: x["confidence"], reverse=True)
        return candidates[:50]

    def _idor_test_suggestions(self, url: str, extracted_id: str, pattern_type: str) -> list[str]:
        """Generate specific IDOR test suggestions."""
        suggestions: list[str] = []

        # Try sequential IDs
        try:
            num_id = int(extracted_id)
            suggestions.extend([
                f"Replace {extracted_id} with {num_id + 1}",
                f"Replace {extracted_id} with {num_id - 1}",
                f"Replace {extracted_id} with 1",
                f"Replace {extracted_id} with 0",
            ])
        except ValueError:
            pass

        # Try common admin IDs
        if "user" in pattern_type or "account" in pattern_type:
            suggestions.extend([
                "Replace with admin user ID",
                "Replace with another user's ID from recon",
            ])

        # HTTP method testing
        suggestions.extend([
            f"Test DELETE {url.replace(extracted_id, '<other_id>')}",
            f"Test PATCH/PUT {url} with another user's data",
        ])

        return suggestions

    # ─── Mass Assignment ─────────────────────────────────────────────────────

    async def test_mass_assignment(
        self,
        url: str,
        method: str = "POST",
        auth_headers: dict[str, str] | None = None,
    ) -> list[APIFinding]:
        """Test for mass assignment vulnerabilities."""
        findings: list[APIFinding] = []
        client = self._get_client()
        headers = {**(auth_headers or {}), "Content-Type": "application/json"}

        # Common privileged fields to inject
        privileged_payloads = [
            {"isAdmin": True, "role": "admin", "is_staff": True},
            {"admin": True, "superuser": True, "is_superuser": True},
            {"role": "administrator", "permissions": ["*"], "level": 99},
            {"verified": True, "email_verified": True, "phone_verified": True},
            {"credits": 999999, "balance": 999999, "coins": 999999},
            {"subscription": "premium", "plan": "enterprise", "tier": "pro"},
        ]

        self.think(f"Testing mass assignment on {url}", confidence=0.70)

        for payload in privileged_payloads:
            try:
                resp = await client.request(method, url, json=payload, headers=headers)
                resp_json = resp.json() if "json" in resp.headers.get("content-type", "") else {}

                # Check if privileged field was accepted
                for key, value in payload.items():
                    if str(value).lower() in str(resp_json).lower() or key in str(resp_json):
                        findings.append(APIFinding(
                            finding_type="mass_assignment",
                            severity="high",
                            title=f"Mass Assignment — field '{key}' accepted",
                            description=f"The API accepted privileged field '{key}={value}' in the request body. This may allow privilege escalation.",
                            url=url,
                            method=method,
                            payload=json.dumps(payload),
                            evidence=f"Response contained field: {key}. Status: {resp.status_code}",
                            confidence=0.75,
                            cvss_score=7.5,
                        ))
                        self.escalate_path(
                            f"Mass assignment confirmed: {key}={value}",
                            "Test account privilege escalation"
                        )
                        break
            except Exception:
                pass

        return findings

    # ─── Shadow Endpoint Detection ───────────────────────────────────────────

    async def discover_shadow_endpoints(
        self,
        base_url: str,
        known_endpoints: list[str],
        auth_headers: dict[str, str] | None = None,
    ) -> list[dict[str, Any]]:
        """Discover undocumented/shadow API endpoints."""
        client = self._get_client()
        headers = auth_headers or {}
        discovered: list[dict[str, Any]] = []

        # Common hidden API paths
        shadow_paths = [
            "/api/admin", "/api/internal", "/api/debug", "/api/test",
            "/api/v0", "/api/v2", "/api/beta", "/api/legacy",
            "/admin/api", "/internal/api", "/debug",
            "/.well-known/security.txt", "/.env", "/config.json",
            "/api/users/export", "/api/admin/users", "/api/system/config",
            "/graphql", "/graphiql", "/playground", "/voyager",
            "/swagger.json", "/openapi.json", "/api-docs",
            "/__debug__", "/__debug_toolbar__",
            "/metrics", "/actuator", "/actuator/env", "/actuator/health",
            "/health/detailed", "/status", "/info",
            "/api/v1/admin/users", "/api/v1/debug", "/api/v1/internal",
        ]

        self.think(f"Probing {len(shadow_paths)} shadow endpoint paths", confidence=0.6)

        parsed = urlparse(base_url)
        base = f"{parsed.scheme}://{parsed.netloc}"

        for path in shadow_paths:
            if path in known_endpoints:
                continue
            try:
                url = base + path
                resp = await client.get(url, headers=headers, timeout=5)
                if resp.status_code not in (404, 405, 410):
                    discovered.append({
                        "url": url,
                        "status_code": resp.status_code,
                        "content_length": len(resp.content),
                        "interesting": resp.status_code in (200, 201, 301, 302, 403),
                    })
                    if resp.status_code in (200, 201):
                        self.escalate_path(
                            f"Shadow endpoint discovered: {path} (HTTP {resp.status_code})",
                            "Analyze endpoint for sensitive data exposure"
                        )
            except Exception:
                pass

        return discovered

    # ─── Privilege Diff Engine ───────────────────────────────────────────────

    async def privilege_diff(
        self,
        endpoint: str,
        user_auth: dict[str, str],
        admin_auth: dict[str, str],
        method: str = "GET",
    ) -> dict[str, Any]:
        """Compare responses between regular user and admin to find privilege differences."""
        client = self._get_client()

        try:
            user_resp = await client.request(method, endpoint, headers=user_auth, timeout=10)
            admin_resp = await client.request(method, endpoint, headers=admin_auth, timeout=10)

            user_fields: set[str] = set()
            admin_fields: set[str] = set()

            try:
                user_data = user_resp.json()
                admin_data = admin_resp.json()

                def extract_keys(obj: Any, prefix: str = "") -> set[str]:
                    keys: set[str] = set()
                    if isinstance(obj, dict):
                        for k, v in obj.items():
                            full_key = f"{prefix}.{k}" if prefix else k
                            keys.add(full_key)
                            keys.update(extract_keys(v, full_key))
                    elif isinstance(obj, list) and obj:
                        keys.update(extract_keys(obj[0], prefix))
                    return keys

                user_fields = extract_keys(user_data)
                admin_fields = extract_keys(admin_data)
            except Exception:
                pass

            admin_only_fields = admin_fields - user_fields
            different_status = user_resp.status_code != admin_resp.status_code

            return {
                "endpoint": endpoint,
                "user_status": user_resp.status_code,
                "admin_status": admin_resp.status_code,
                "admin_only_fields": list(admin_only_fields),
                "idor_risk": len(admin_only_fields) > 0 or different_status,
                "evidence": {
                    "status_diff": different_status,
                    "field_count_diff": len(admin_fields) - len(user_fields),
                    "admin_only_count": len(admin_only_fields),
                },
            }
        except Exception as e:
            return {"endpoint": endpoint, "error": str(e)}
