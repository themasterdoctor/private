"""Browser Intelligence Layer.

Playwright-based:
- Authenticated crawling
- SPA route discovery (React/Vue/Angular)
- Hidden form discovery
- localStorage/sessionStorage analysis
- CSP analysis
- WebSocket traffic monitoring
- Client-side token discovery
- React/Vue state extraction
"""
from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass, field
from typing import Any

import structlog

from app.intelligence.reasoning import ReasoningAgentBase

logger = structlog.get_logger(__name__)

try:
    from playwright.async_api import async_playwright, Browser, Page
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False
    logger.warning("playwright_not_available", msg="Install playwright for browser intelligence")


@dataclass
class BrowserFinding:
    finding_type: str
    severity: str
    title: str
    description: str
    evidence: str
    url: str = ""
    recommendation: str = ""


@dataclass
class BrowserIntelResult:
    url: str
    spa_routes: list[str] = field(default_factory=list)
    hidden_forms: list[dict[str, Any]] = field(default_factory=list)
    local_storage: dict[str, str] = field(default_factory=dict)
    session_storage: dict[str, str] = field(default_factory=dict)
    cookies: list[dict[str, Any]] = field(default_factory=list)
    websocket_messages: list[dict[str, Any]] = field(default_factory=list)
    csp_directives: dict[str, str] = field(default_factory=dict)
    csp_issues: list[str] = field(default_factory=list)
    security_headers: dict[str, str] = field(default_factory=dict)
    missing_headers: list[str] = field(default_factory=list)
    tokens_found: list[dict[str, Any]] = field(default_factory=list)
    api_calls: list[dict[str, Any]] = field(default_factory=list)
    findings: list[BrowserFinding] = field(default_factory=list)
    react_state_keys: list[str] = field(default_factory=list)


TOKEN_PATTERNS = [
    (r'eyJ[A-Za-z0-9_-]{20,}\.eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}', "JWT"),
    (r'AIza[0-9A-Za-z_-]{35}', "Google API Key"),
    (r'sk-[a-zA-Z0-9]{48}', "OpenAI API Key"),
    (r'AKIA[0-9A-Z]{16}', "AWS Access Key ID"),
    (r'ghp_[a-zA-Z0-9]{36}', "GitHub Personal Access Token"),
    (r'xoxb-[0-9]{11}-[0-9]{11}-[a-zA-Z0-9]{24}', "Slack Bot Token"),
    (r'[0-9a-f]{40}', "Possible SHA1 token/secret"),
    (r'Bearer\s+[A-Za-z0-9._-]{20,}', "Bearer Token"),
    (r'token["\s:=\']+([A-Za-z0-9._\-]{20,})', "Generic Token"),
    (r'api[_-]?key["\s:=\']+([A-Za-z0-9._\-]{20,})', "API Key"),
    (r'secret["\s:=\']+([A-Za-z0-9._\-]{16,})', "Secret Value"),
]

SECURITY_HEADERS = {
    "Strict-Transport-Security": "HSTS missing — susceptible to SSL stripping",
    "Content-Security-Policy": "CSP missing — XSS mitigations absent",
    "X-Frame-Options": "Clickjacking protection missing",
    "X-Content-Type-Options": "MIME sniffing protection missing",
    "Referrer-Policy": "Referrer policy not set",
    "Permissions-Policy": "Permissions policy not set",
    "X-XSS-Protection": "Legacy XSS filter not set (informational)",
}


class BrowserIntelAgent(ReasoningAgentBase):
    """Playwright-based browser intelligence agent."""

    agent_name = "browser_intel"

    def __init__(self, scan_id: str = "", workspace_id: str = ""):
        super().__init__(scan_id, workspace_id)

    async def analyze(
        self,
        url: str,
        auth_cookies: list[dict[str, Any]] | None = None,
        auth_headers: dict[str, str] | None = None,
        timeout_ms: int = 30000,
    ) -> BrowserIntelResult:
        """Full browser intelligence analysis of a URL."""
        result = BrowserIntelResult(url=url)

        if not PLAYWRIGHT_AVAILABLE:
            self.think("Playwright not available — falling back to static analysis", confidence=0.3)
            return result

        self.think(f"Starting browser analysis of {url}", confidence=0.9)

        try:
            async with async_playwright() as pw:
                browser = await pw.chromium.launch(
                    headless=True,
                    args=[
                        "--no-sandbox",
                        "--disable-setuid-sandbox",
                        "--disable-dev-shm-usage",
                        "--disable-gpu",
                    ],
                )
                context = await browser.new_context(
                    user_agent="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                    ignore_https_errors=True,
                    extra_http_headers=auth_headers or {},
                )

                if auth_cookies:
                    await context.add_cookies(auth_cookies)

                page = await context.new_page()

                # Intercept API calls
                api_calls: list[dict[str, Any]] = []
                ws_messages: list[dict[str, Any]] = []

                async def handle_request(request):
                    if any(x in request.url for x in ["/api/", "/graphql", "/v1/", "/v2/"]):
                        api_calls.append({
                            "url": request.url,
                            "method": request.method,
                            "headers": dict(request.headers),
                        })

                page.on("request", handle_request)

                # WebSocket interception
                async def handle_ws(ws):
                    ws_messages.append({"url": ws.url, "type": "websocket_opened"})
                    ws.on("framereceived", lambda f: ws_messages.append({
                        "url": ws.url, "data": str(f.payload)[:200], "direction": "server→client"
                    }))
                    ws.on("framesent", lambda f: ws_messages.append({
                        "url": ws.url, "data": str(f.payload)[:200], "direction": "client→server"
                    }))

                page.on("websocket", handle_ws)

                # Navigate
                response = await page.goto(url, timeout=timeout_ms, wait_until="networkidle")

                # Security headers analysis
                if response:
                    headers = dict(response.headers)
                    result.security_headers = {k: v for k, v in headers.items() if k.lower() in {h.lower() for h in SECURITY_HEADERS}}
                    for header, issue in SECURITY_HEADERS.items():
                        if header.lower() not in {k.lower() for k in headers}:
                            result.missing_headers.append(header)
                            result.findings.append(BrowserFinding(
                                finding_type="missing_security_header",
                                severity="low",
                                title=f"Missing {header}",
                                description=issue,
                                evidence=f"Header absent from response to {url}",
                                url=url,
                                recommendation=f"Add {header} response header",
                            ))

                    # CSP analysis
                    csp = headers.get("content-security-policy", headers.get("Content-Security-Policy", ""))
                    if csp:
                        result.csp_directives = self._parse_csp(csp)
                        result.csp_issues = self._analyze_csp(result.csp_directives)
                        for issue in result.csp_issues:
                            result.findings.append(BrowserFinding(
                                finding_type="csp_issue",
                                severity="medium",
                                title=f"CSP Weakness: {issue[:60]}",
                                description=issue,
                                evidence=f"CSP: {csp[:200]}",
                                url=url,
                            ))

                # Wait for SPA to render
                await page.wait_for_timeout(2000)

                # SPA route discovery
                routes = await self._discover_spa_routes(page)
                result.spa_routes = routes
                if routes:
                    self.think(f"Discovered {len(routes)} SPA routes via client-side routing", confidence=0.85)

                # Hidden forms
                forms = await self._find_hidden_forms(page)
                result.hidden_forms = forms
                if forms:
                    self.record_evidence(
                        f"Found {len(forms)} hidden/invisible forms",
                        refs=[f.get("action", "unknown") for f in forms[:3]],
                        confidence=0.8,
                    )

                # Storage analysis
                storage = await page.evaluate("""() => {
                    const ls = {};
                    const ss = {};
                    for (let i = 0; i < localStorage.length; i++) {
                        const k = localStorage.key(i);
                        ls[k] = localStorage.getItem(k);
                    }
                    for (let i = 0; i < sessionStorage.length; i++) {
                        const k = sessionStorage.key(i);
                        ss[k] = sessionStorage.getItem(k);
                    }
                    return {localStorage: ls, sessionStorage: ss};
                }""")
                result.local_storage = storage.get("localStorage", {})
                result.session_storage = storage.get("sessionStorage", {})

                # Token hunting in storage
                all_storage_values = list(result.local_storage.values()) + list(result.session_storage.values())
                for value in all_storage_values:
                    tokens = self._hunt_tokens(str(value))
                    for token in tokens:
                        result.tokens_found.append(token)
                        if token["type"] in ("JWT", "Bearer Token", "AWS Access Key ID"):
                            result.findings.append(BrowserFinding(
                                finding_type="token_in_storage",
                                severity="high",
                                title=f"{token['type']} in browser storage",
                                description=f"Sensitive {token['type']} found in {'localStorage' if value in result.local_storage.values() else 'sessionStorage'}",
                                evidence=f"Token: {token['value'][:40]}...",
                                url=url,
                                recommendation="Avoid storing sensitive tokens in browser storage; use httpOnly cookies",
                            ))

                # React/Vue state extraction
                state_keys = await page.evaluate("""() => {
                    const keys = [];
                    // React DevTools
                    if (window.__REACT_DEVTOOLS_GLOBAL_HOOK__) keys.push('react_devtools');
                    // Vue
                    if (window.__VUE__) keys.push('vue_instance');
                    if (window.__vuex__) keys.push('vuex_store');
                    // Redux
                    if (window.__REDUX_DEVTOOLS_EXTENSION__) keys.push('redux_devtools');
                    // Next.js
                    if (window.__NEXT_DATA__) {
                        const nd = window.__NEXT_DATA__;
                        if (nd.props) keys.push(...Object.keys(nd.props));
                    }
                    return keys;
                }""")
                result.react_state_keys = state_keys

                # Cookie analysis
                cookies = await context.cookies()
                result.cookies = [
                    {
                        "name": c["name"],
                        "domain": c.get("domain", ""),
                        "httpOnly": c.get("httpOnly", False),
                        "secure": c.get("secure", False),
                        "sameSite": c.get("sameSite", ""),
                        "value_length": len(c.get("value", "")),
                    }
                    for c in cookies
                ]

                # Check cookie security
                for cookie in result.cookies:
                    if not cookie["httpOnly"] and any(
                        x in cookie["name"].lower() for x in ["session", "token", "auth", "jwt"]
                    ):
                        result.findings.append(BrowserFinding(
                            finding_type="insecure_cookie",
                            severity="medium",
                            title=f"Auth cookie '{cookie['name']}' missing httpOnly flag",
                            description="Session/auth cookies without httpOnly are accessible via JavaScript, enabling XSS-based theft",
                            evidence=f"Cookie: {cookie['name']}, httpOnly={cookie['httpOnly']}, secure={cookie['secure']}",
                            url=url,
                            recommendation="Set httpOnly=true and Secure=true on all authentication cookies",
                        ))

                result.api_calls = api_calls
                result.websocket_messages = ws_messages

                await browser.close()

        except Exception as e:
            logger.error("browser_intel_error", url=url, error=str(e))
            self.think(f"Browser analysis error: {str(e)[:100]}", confidence=0.2)

        self.conclude(
            f"Browser analysis complete: {len(result.findings)} findings, "
            f"{len(result.spa_routes)} routes, {len(result.tokens_found)} tokens",
            confidence=0.85,
        )
        return result

    async def _discover_spa_routes(self, page: "Page") -> list[str]:
        """Discover SPA routes via router inspection."""
        routes: list[str] = []
        try:
            # Click all internal links, watch for route changes
            links = await page.eval_on_selector_all("a[href]", """
                elements => elements
                    .map(el => el.href)
                    .filter(h => h.startsWith(window.location.origin))
                    .filter(h => !h.includes('#'))
            """)
            routes.extend(links[:50])

            # Extract from React Router / Vue Router
            js_routes = await page.evaluate("""() => {
                const routes = new Set();
                // Hash-based routing
                const links = document.querySelectorAll('a');
                links.forEach(l => {
                    if (l.href.includes('#/')) routes.add(l.href);
                    if (l.getAttribute('to')) routes.add(l.getAttribute('to'));
                });
                return [...routes];
            }""")
            routes.extend(js_routes)

            return list(set(routes))[:100]
        except Exception:
            return []

    async def _find_hidden_forms(self, page: "Page") -> list[dict[str, Any]]:
        """Find hidden or invisible forms on the page."""
        try:
            forms = await page.evaluate("""() => {
                const forms = [];
                document.querySelectorAll('form').forEach(f => {
                    const style = window.getComputedStyle(f);
                    const rect = f.getBoundingClientRect();
                    const isHidden = (
                        style.display === 'none' ||
                        style.visibility === 'hidden' ||
                        style.opacity === '0' ||
                        rect.width === 0 ||
                        rect.height === 0 ||
                        f.hasAttribute('hidden')
                    );
                    if (isHidden) {
                        const inputs = [...f.querySelectorAll('input, select, textarea')].map(i => ({
                            name: i.name, type: i.type, value: i.value?.substr(0, 50)
                        }));
                        forms.push({
                            action: f.action,
                            method: f.method,
                            hidden: isHidden,
                            inputs
                        });
                    }
                });
                return forms;
            }""")
            return forms
        except Exception:
            return []

    def _hunt_tokens(self, text: str) -> list[dict[str, Any]]:
        """Hunt for tokens and secrets in text."""
        found: list[dict[str, Any]] = []
        for pattern, token_type in TOKEN_PATTERNS:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches[:3]:
                value = match if isinstance(match, str) else match[0]
                if len(value) >= 16:
                    found.append({"type": token_type, "value": value, "pattern": pattern})
        return found

    def _parse_csp(self, csp: str) -> dict[str, str]:
        """Parse CSP header into directives."""
        directives: dict[str, str] = {}
        for part in csp.split(";"):
            part = part.strip()
            if " " in part:
                key, _, value = part.partition(" ")
                directives[key.strip()] = value.strip()
        return directives

    def _analyze_csp(self, directives: dict[str, str]) -> list[str]:
        """Analyze CSP for weaknesses."""
        issues: list[str] = []

        script_src = directives.get("script-src", directives.get("default-src", ""))
        if "unsafe-inline" in script_src:
            issues.append("CSP allows 'unsafe-inline' scripts — XSS mitigations bypassed")
        if "unsafe-eval" in script_src:
            issues.append("CSP allows 'unsafe-eval' — eval()-based attacks possible")
        if "*" in script_src or "http:" in script_src:
            issues.append("CSP script-src wildcard or http: allows external script injection")

        default_src = directives.get("default-src", "")
        if not default_src and "script-src" not in directives:
            issues.append("No script-src or default-src directive — CSP provides no XSS protection")

        if "frame-ancestors" not in directives and "frame-src" not in directives:
            issues.append("No frame-ancestors directive — clickjacking protection absent from CSP")

        return issues
