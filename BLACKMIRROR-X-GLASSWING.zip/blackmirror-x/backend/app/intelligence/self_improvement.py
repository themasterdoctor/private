"""Self-Improvement Intelligence Loop.

After every scan, learns:
- Which payloads worked
- Which were false positives
- Which endpoints were highest-value
- Which hypotheses were correct
- How to improve exploitability scoring
- How to rank future scan targets

Updates WorkspaceMemory automatically.
"""
from __future__ import annotations

import time
from typing import Any

from app.core.logging import get_logger
from app.intelligence.memory.workspace_memory import WorkspaceMemory, WorkspaceMemoryService

logger = get_logger(__name__)


class SelfImprovementLoop:
    """Post-scan learning loop that updates workspace intelligence."""

    async def process_scan_results(
        self,
        workspace_id: str,
        scan_results: dict[str, Any],
        db: Any,
    ) -> dict[str, Any]:
        """Process scan results and update workspace memory."""
        mem = await WorkspaceMemoryService.load(workspace_id, db)
        updates: dict[str, Any] = {
            "payloads_learned": 0,
            "false_positives_recorded": 0,
            "technologies_updated": 0,
            "priority_matrix_updated": False,
        }

        vulns = scan_results.get("vulnerabilities", [])
        subdomains = scan_results.get("subdomains", [])
        technologies = scan_results.get("technologies", [])
        false_positives = scan_results.get("false_positives", [])
        payload_telemetry = scan_results.get("payload_telemetry", [])

        # ── Learn from confirmed vulnerabilities ─────────────────────────────
        for vuln in vulns:
            if vuln.get("confirmed") or vuln.get("verdict_valid"):
                mem.record_finding(vuln.get("vuln_type", "unknown"), confirmed=True)
                # Learn successful payload
                if vuln.get("payload"):
                    mem.record_payload_attempt(
                        payload=vuln["payload"],
                        vuln_type=vuln.get("vuln_type", "unknown"),
                        success=True,
                        context=vuln.get("reflection_context", ""),
                    )
                    updates["payloads_learned"] += 1

        # ── Learn from false positives ────────────────────────────────────────
        for fp in false_positives:
            sig = fp.get("signature", fp.get("url", ""))
            if sig and sig not in mem.false_positive_signatures:
                mem.false_positive_signatures.append(sig)
                updates["false_positives_recorded"] += 1
            # Record as rejected
            if fp.get("vuln_type"):
                mem.record_finding(fp["vuln_type"], confirmed=False)

        # ── Learn from payload telemetry ─────────────────────────────────────
        for telem in payload_telemetry:
            mem.record_payload_attempt(
                payload=telem.get("payload", ""),
                vuln_type=telem.get("vuln_type", "unknown"),
                success=telem.get("success", False),
                waf_blocked=telem.get("waf_blocked", False),
                context=telem.get("context", ""),
            )
            updates["payloads_learned"] += 1

        # ── Update technology fingerprints ────────────────────────────────────
        for tech in technologies:
            tech_name = tech if isinstance(tech, str) else tech.get("name", "")
            if tech_name:
                mem.add_technology(tech_name, confidence=0.85)
                updates["technologies_updated"] += 1

        # Scan-level quirks
        for sub in subdomains:
            if sub.get("waf"):
                mem.add_quirk("waf", sub["waf"])
            if sub.get("rate_limit"):
                mem.add_quirk("rate_limit", str(sub["rate_limit"]))

        # ── Update endpoint sensitivity ────────────────────────────────────────
        for vuln in vulns:
            url = vuln.get("url", "")
            if url:
                current = mem.endpoint_sensitivity.get(url, 0.5)
                mem.endpoint_sensitivity[url] = min(1.0, current + 0.1)

        # Bump scan count
        mem.total_scans += 1
        mem.last_updated = time.time()

        # Persist
        await WorkspaceMemoryService.save(mem, db)
        updates["priority_matrix_updated"] = True

        logger.info(
            "self_improvement_complete",
            workspace_id=workspace_id,
            **updates,
        )
        return updates

    def compute_endpoint_priority(
        self, endpoints: list[dict[str, Any]], mem: WorkspaceMemory
    ) -> list[dict[str, Any]]:
        """Re-rank endpoints by learned risk score."""
        for ep in endpoints:
            url = ep.get("url", "")
            base_score = mem.endpoint_risk_score(url)
            ep["learned_priority"] = base_score
        return sorted(endpoints, key=lambda e: e.get("learned_priority", 0), reverse=True)

    def suggest_scan_focus(self, mem: WorkspaceMemory) -> dict[str, Any]:
        """Based on workspace memory, suggest what to focus on."""
        matrix = mem.scan_priority_matrix()

        # Top 3 most productive vuln types
        top_types = sorted(matrix.items(), key=lambda x: x[1], reverse=True)[:5]

        # WAF info
        waf = next((q.value for q in mem.quirks if q.key == "waf"), None)

        return {
            "recommended_vuln_types": [t[0] for t in top_types],
            "avoid_types": [
                vt for vt, score in matrix.items() if score < 0.2
            ],
            "detected_waf": waf,
            "best_payloads": {
                vt: mem.best_payloads_for(vt, 3)
                for vt, _ in top_types
            },
            "false_positive_patterns": mem.false_positive_signatures[:5],
            "high_value_endpoints": [
                url for url, score in sorted(
                    mem.endpoint_sensitivity.items(), key=lambda x: x[1], reverse=True
                )[:10]
            ],
        }
