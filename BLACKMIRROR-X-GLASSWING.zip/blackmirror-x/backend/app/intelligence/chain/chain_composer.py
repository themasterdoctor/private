"""Attack Chain Composer & Graph Engine.

Builds a directed graph of vulnerability relationships and
chains them into multi-step attack paths with probability scoring,
missing link detection, and evidence quality weighting.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

import anthropic

from app.core.config import settings
from app.core.logging import get_logger
from app.intelligence.reasoning import ReasoningAgentBase

logger = get_logger(__name__)


@dataclass
class ChainNode:
    """A single node in an attack chain."""
    id: str
    node_type: str       # vuln, recon, secret, misc
    title: str
    severity: str
    url: str = ""
    evidence_score: float = 0.5
    confidence: float = 0.7
    payload: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ChainEdge:
    """Directed edge between two attack chain nodes."""
    source_id: str
    target_id: str
    relationship: str    # enables, amplifies, required_for, optional
    probability: float   # 0–1 that this link holds
    description: str = ""


@dataclass
class AttackChain:
    """A complete multi-step attack path."""
    id: str
    title: str
    nodes: list[ChainNode]
    edges: list[ChainEdge]
    chain_probability: float        # product of edge probabilities
    chain_impact: str               # critical/high/medium/low
    missing_links: list[str]        # what's needed to complete the chain
    recommended_next_steps: list[str]
    ai_narrative: str = ""
    evidence_quality: float = 0.5
    estimated_bounty: str = ""
    owasp_categories: list[str] = field(default_factory=list)


# Chain templates: define how vuln types connect
CHAIN_TEMPLATES = [
    {
        "name": "Full Account Takeover via XSS",
        "nodes": ["xss_stored", "session_hijack", "ato"],
        "probability": 0.85,
        "impact": "critical",
        "owasp": ["A03:2021-XSS", "A07:2021-Authentication"],
        "bounty": "$5,000 – $25,000",
    },
    {
        "name": "SSRF → Cloud Credential Theft → Full AWS Compromise",
        "nodes": ["ssrf", "cloud_metadata", "iam_credentials", "aws_access"],
        "probability": 0.78,
        "impact": "critical",
        "owasp": ["A10:2021-SSRF", "A02:2021-Cryptographic"],
        "bounty": "$10,000 – $50,000",
    },
    {
        "name": "SQLi → Admin Credential Dump → RCE",
        "nodes": ["sqli", "credential_dump", "admin_login", "rce"],
        "probability": 0.62,
        "impact": "critical",
        "owasp": ["A03:2021-Injection", "A07:2021-Authentication"],
        "bounty": "$5,000 – $20,000",
    },
    {
        "name": "IDOR → PII Mass Exfiltration",
        "nodes": ["idor", "pii_access", "mass_exfil"],
        "probability": 0.73,
        "impact": "high",
        "owasp": ["A01:2021-Broken Access Control"],
        "bounty": "$2,000 – $10,000",
    },
    {
        "name": "JS Secret → Internal API → Privilege Escalation",
        "nodes": ["js_secret", "internal_api", "privesc"],
        "probability": 0.66,
        "impact": "high",
        "owasp": ["A05:2021-Security Misconfiguration", "A01:2021-Broken Access Control"],
        "bounty": "$3,000 – $15,000",
    },
    {
        "name": "CORS Misconfiguration → Sensitive Data Exfil",
        "nodes": ["cors", "auth_request", "data_exfil"],
        "probability": 0.58,
        "impact": "high",
        "owasp": ["A05:2021-Security Misconfiguration"],
        "bounty": "$1,000 – $5,000",
    },
    {
        "name": "JWT Algorithm Confusion → Admin Impersonation",
        "nodes": ["jwt_alg_confusion", "admin_token", "admin_actions"],
        "probability": 0.70,
        "impact": "critical",
        "owasp": ["A02:2021-Cryptographic Failures", "A07:2021-Authentication"],
        "bounty": "$5,000 – $20,000",
    },
    {
        "name": "Subdomain Takeover → Phishing → ATO",
        "nodes": ["subdomain_takeover", "phishing_page", "cred_harvest", "ato"],
        "probability": 0.52,
        "impact": "high",
        "owasp": ["A05:2021-Security Misconfiguration", "A07:2021-Authentication"],
        "bounty": "$2,000 – $8,000",
    },
    {
        "name": "SSTI → RCE → Database Access",
        "nodes": ["ssti", "rce", "db_access", "data_exfil"],
        "probability": 0.72,
        "impact": "critical",
        "owasp": ["A03:2021-Injection"],
        "bounty": "$8,000 – $40,000",
    },
]

# Maps vuln_type to chain node types
VULN_TO_NODE_TYPE = {
    "xss": "xss_stored",
    "xss_stored": "xss_stored",
    "sqli": "sqli",
    "ssrf": "ssrf",
    "idor": "idor",
    "ssti": "ssti",
    "cors": "cors",
    "jwt": "jwt_alg_confusion",
    "file_upload": "file_upload",
    "open_redirect": "open_redirect",
    "subdomain_takeover": "subdomain_takeover",
}


class AttackChainComposer(ReasoningAgentBase):
    """Composes multi-step attack chains from discovered findings."""

    agent_name = "chain_composer"

    def __init__(self, scan_id: str = "", workspace_id: str = ""):
        super().__init__(scan_id, workspace_id)
        self.client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)

    def compose_chains(
        self,
        vulns: list[dict[str, Any]],
        subdomains: list[dict[str, Any]],
        js_findings: list[dict[str, Any]],
    ) -> list[AttackChain]:
        """Compose attack chains from all available findings."""
        self.think(
            f"Composing attack chains from {len(vulns)} vulns, "
            f"{len(subdomains)} subdomains, {len(js_findings)} JS findings",
            confidence=0.85,
        )

        vuln_types = {v.get("vuln_type", "") for v in vulns}
        chains: list[AttackChain] = []

        for template in CHAIN_TEMPLATES:
            template_nodes = set(template["nodes"])

            # Check which template nodes are covered by findings
            covered: set[str] = set()
            for vt in vuln_types:
                node_type = VULN_TO_NODE_TYPE.get(vt, vt)
                if node_type in template_nodes:
                    covered.add(node_type)

            # Also check for secrets, subdomains, etc.
            if js_findings:
                if any(f.get("secret_type") for f in js_findings):
                    covered.add("js_secret")

            if any(s.get("takeover_risk") for s in subdomains):
                covered.add("subdomain_takeover")

            if not covered:
                continue

            # Build chain nodes from matched findings
            nodes: list[ChainNode] = []
            edges: list[ChainEdge] = []
            missing_links: list[str] = []

            for i, node_type in enumerate(template["nodes"]):
                if node_type in covered:
                    # Find the matching vuln
                    matching_vuln = next(
                        (v for v in vulns if VULN_TO_NODE_TYPE.get(v.get("vuln_type", "")) == node_type),
                        None
                    )
                    if matching_vuln:
                        node = ChainNode(
                            id=f"node_{i}_{node_type}",
                            node_type=node_type,
                            title=matching_vuln.get("title", node_type.replace("_", " ").title()),
                            severity=matching_vuln.get("severity", "high"),
                            url=matching_vuln.get("url", ""),
                            evidence_score=0.75,
                            confidence=0.80,
                        )
                    else:
                        node = ChainNode(
                            id=f"node_{i}_{node_type}",
                            node_type=node_type,
                            title=node_type.replace("_", " ").title(),
                            severity="high",
                            evidence_score=0.50,
                            confidence=0.60,
                        )
                    nodes.append(node)
                else:
                    missing_links.append(node_type.replace("_", " ").replace("_", " ").title())
                    # Add placeholder node
                    nodes.append(ChainNode(
                        id=f"node_{i}_{node_type}_missing",
                        node_type=f"missing:{node_type}",
                        title=f"[NEEDED] {node_type.replace('_', ' ').title()}",
                        severity="unknown",
                        evidence_score=0.0,
                        confidence=0.0,
                    ))

            # Build edges
            for i in range(len(nodes) - 1):
                edge_prob = template["probability"] ** (1 / len(nodes))
                if "missing" in nodes[i].node_type or "missing" in nodes[i + 1].node_type:
                    edge_prob *= 0.5

                edges.append(ChainEdge(
                    source_id=nodes[i].id,
                    target_id=nodes[i + 1].id,
                    relationship="enables",
                    probability=edge_prob,
                    description=f"{nodes[i].title} enables {nodes[i + 1].title}",
                ))

            # Chain probability = product of edge probs, weighted by coverage
            coverage_ratio = len(covered) / len(template["nodes"])
            chain_prob = template["probability"] * coverage_ratio

            # Evidence quality = average of node evidence scores
            evidence_scores = [n.evidence_score for n in nodes if not n.node_type.startswith("missing")]
            avg_evidence = sum(evidence_scores) / len(evidence_scores) if evidence_scores else 0.0

            # Recommend next steps
            next_steps: list[str] = []
            if missing_links:
                next_steps.append(f"Find and verify: {', '.join(missing_links[:3])}")
            if avg_evidence < 0.7:
                next_steps.append("Improve evidence quality — add request/response proof")
            next_steps.append(f"Test full chain in isolated environment")
            next_steps.append(f"Document each step with screenshots")

            chain = AttackChain(
                id=f"chain_{len(chains)}",
                title=template["name"],
                nodes=nodes,
                edges=edges,
                chain_probability=chain_prob,
                chain_impact=template["impact"],
                missing_links=missing_links,
                recommended_next_steps=next_steps,
                evidence_quality=avg_evidence,
                estimated_bounty=template["bounty"],
                owasp_categories=template.get("owasp", []),
            )
            chains.append(chain)
            self.hypothesize(
                f"Attack chain: {template['name']} (coverage={coverage_ratio:.0%})",
                confidence=chain_prob,
                rationale=f"Found: {', '.join(covered)}; Missing: {', '.join(missing_links[:2]) or 'none'}",
            )

        # Sort by probability × impact
        impact_score = {"critical": 1.0, "high": 0.7, "medium": 0.4, "low": 0.2}
        chains.sort(
            key=lambda c: c.chain_probability * impact_score.get(c.chain_impact, 0.3),
            reverse=True,
        )

        self.conclude(
            f"Composed {len(chains)} attack chains from findings",
            confidence=0.85,
        )
        return chains

    async def enrich_chain_with_ai(self, chain: AttackChain) -> AttackChain:
        """Use Claude to generate a narrative for the chain."""
        nodes_summary = " → ".join(
            n.title for n in chain.nodes if not n.node_type.startswith("missing")
        )
        prompt = f"""You are a senior penetration tester explaining an attack chain.

Chain: {chain.title}
Steps found: {nodes_summary}
Missing: {', '.join(chain.missing_links) or 'none'}
Impact: {chain.chain_impact}
Probability: {chain.chain_probability:.0%}

Write 2–3 sentences explaining:
1. How this attack chain works in practice
2. The realistic business impact
3. The key prerequisite an attacker needs

Keep it professional. No step-by-step exploitation instructions."""

        try:
            resp = await self.client.messages.create(
                model=settings.AI_MODEL,
                max_tokens=200,
                messages=[{"role": "user", "content": prompt}],
            )
            chain.ai_narrative = resp.content[0].text
        except Exception:
            chain.ai_narrative = f"Multi-step {chain.chain_impact} attack chain with {len(chain.nodes)} nodes."
        return chain

    def to_graph_json(self, chains: list[AttackChain]) -> dict[str, Any]:
        """Export chains as D3-compatible graph data."""
        all_nodes: list[dict[str, Any]] = []
        all_links: list[dict[str, Any]] = []
        seen_node_ids: set[str] = set()

        for chain in chains:
            for node in chain.nodes:
                if node.id not in seen_node_ids:
                    all_nodes.append({
                        "id": node.id,
                        "type": node.node_type,
                        "title": node.title,
                        "severity": node.severity,
                        "confidence": node.confidence,
                        "evidence_score": node.evidence_score,
                        "missing": node.node_type.startswith("missing"),
                    })
                    seen_node_ids.add(node.id)

            for edge in chain.edges:
                all_links.append({
                    "source": edge.source_id,
                    "target": edge.target_id,
                    "relationship": edge.relationship,
                    "probability": edge.probability,
                    "chain_id": chain.id,
                })

        return {
            "nodes": all_nodes,
            "links": all_links,
            "chains": [
                {
                    "id": c.id,
                    "title": c.title,
                    "probability": c.chain_probability,
                    "impact": c.chain_impact,
                    "missing_links": c.missing_links,
                    "next_steps": c.recommended_next_steps,
                    "evidence_quality": c.evidence_quality,
                    "bounty": c.estimated_bounty,
                    "narrative": c.ai_narrative,
                    "owasp": c.owasp_categories,
                }
                for c in chains
            ],
        }
