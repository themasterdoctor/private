"""JavaScript Reverse Engineering System.

- AST-based analysis (using regex heuristics, not a full AST parser)
- Source map rebuilder
- Webpack chunk analysis
- Hidden endpoint reconstruction
- Secret lineage tracking (where secrets flow)
- Sink/source relationship graphs
- Client-side authorization analysis
"""
from __future__ import annotations

import re
import json
import hashlib
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urljoin, urlparse

import httpx

from app.intelligence.reasoning import ReasoningAgentBase
from app.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class JSSecret:
    secret_type: str
    value: str
    context: str = ""
    file: str = ""
    confidence: float = 0.7
    lineage: list[str] = field(default_factory=list)  # where the value flows


@dataclass
class JSEndpoint:
    path: str
    method: str = "GET"
    params: list[str] = field(default_factory=list)
    auth_required: bool = False
    source_chunk: str = ""
    confidence: float = 0.7


@dataclass
class JSClientAuthCheck:
    check_type: str  # role_check, permission_check, feature_flag
    code_snippet: str
    bypass_risk: str
    severity: str = "medium"


SECRET_PATTERNS = [
    # AWS
    (r'AKIA[0-9A-Z]{16}', "AWS_ACCESS_KEY", 0.95),
    (r'(?:aws|amazon)[_\s]*secret[_\s]*(?:access|key|token)["\s:=\']+([A-Za-z0-9/+=]{40})', "AWS_SECRET_KEY", 0.90),
    # Google
    (r'AIza[0-9A-Za-z_-]{35}', "GOOGLE_API_KEY", 0.95),
    (r'(?:google|gcp|firebase)[_\s]*(?:api|secret|key)["\s:=\']+([A-Za-z0-9_-]{30,})', "GOOGLE_SECRET", 0.80),
    # JWT secrets
    (r'(?:jwt|jwtSecret|JWT_SECRET|tokenSecret)["\s:=\']+([A-Za-z0-9!@#$%^&*_\-+]{8,})', "JWT_SECRET", 0.85),
    # API keys generic
    (r'(?:api[_-]?key|apikey|API_KEY)["\s:=\']+([A-Za-z0-9_\-]{16,})', "API_KEY", 0.80),
    # Auth tokens
    (r'(?:auth[_-]?token|AUTH_TOKEN)["\s:=\']+([A-Za-z0-9_\-\.]{20,})', "AUTH_TOKEN", 0.80),
    # OAuth secrets
    (r'(?:client[_-]?secret|CLIENT_SECRET)["\s:=\']+([A-Za-z0-9_\-\.]{8,})', "CLIENT_SECRET", 0.85),
    # GitHub
    (r'ghp_[a-zA-Z0-9]{36}', "GITHUB_TOKEN", 0.95),
    (r'github[_\s]*token["\s:=\']+([A-Za-z0-9_]{36,})', "GITHUB_TOKEN", 0.85),
    # Slack
    (r'xox[baprs]-[0-9]{11}-[0-9]{11}-[a-zA-Z0-9]{24}', "SLACK_TOKEN", 0.95),
    # Stripe
    (r'(?:sk|pk)_(?:live|test)_[0-9a-zA-Z]{24}', "STRIPE_KEY", 0.95),
    # DB connection strings
    (r'(?:mongodb|postgres|mysql|redis):\/\/[^\s"\']+', "DB_CONNECTION_STRING", 0.90),
    # Private keys
    (r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----', "PRIVATE_KEY", 0.98),
    # JWT tokens (the tokens themselves)
    (r'eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}', "JWT_TOKEN", 0.90),
    # Generic high-entropy strings
    (r'(?:password|passwd|pwd)["\s:=\']+([^"\'\\,\s;]{8,64})', "HARDCODED_PASSWORD", 0.75),
    # Internal endpoints / URLs
    (r'https?://(?:10\.|172\.1[6-9]\.|172\.2[0-9]\.|172\.3[0-1]\.|192\.168\.)[^\s"\']+', "INTERNAL_URL", 0.80),
]

DOM_SOURCES = [
    "location.href", "location.hash", "location.search", "location.pathname",
    "document.referrer", "document.URL", "document.documentURI",
    "window.name", "postMessage", "URLSearchParams",
    "$.param", "$.url",
]

DOM_SINKS = [
    "innerHTML", "outerHTML", "document.write", "document.writeln",
    "eval(", "setTimeout(", "setInterval(", "Function(",
    "location.href", "location.replace", "location.assign",
    "$.html(", "$.append(", "$.prepend(",
    "insertAdjacentHTML",
    "DOMParser", "XMLSerializer",
]

AUTH_CHECK_PATTERNS = [
    (r'if\s*\([^)]*(?:isAdmin|is_admin|admin|role\s*===?\s*["\']admin["\'])[^)]*\)', "role_check"),
    (r'if\s*\([^)]*(?:hasPermission|checkPermission|hasRole|canAccess)[^)]*\)', "permission_check"),
    (r'if\s*\([^)]*(?:featureFlag|feature_enabled|isEnabled)[^)]*\)', "feature_flag"),
    (r'(?:isAdmin|is_admin|adminOnly)\s*=\s*(?:false|0)', "hardcoded_false_auth"),
    (r'if\s*\(\s*false\s*\)\s*\{[^}]*admin', "dead_code_admin"),
]


class JSReverseEngineer(ReasoningAgentBase):
    """JavaScript reverse engineering and intelligence system."""

    agent_name = "js_reverse_engineer"

    def __init__(self, scan_id: str = "", workspace_id: str = ""):
        super().__init__(scan_id, workspace_id)

    async def analyze_url(self, js_url: str) -> dict[str, Any]:
        """Fetch and fully analyze a JavaScript file."""
        try:
            async with httpx.AsyncClient(verify=False, timeout=15) as client:
                resp = await client.get(js_url)
                if resp.status_code != 200:
                    return {"error": f"HTTP {resp.status_code}"}
                content = resp.text
        except Exception as e:
            return {"error": str(e)}

        return await self.analyze_content(content, source_url=js_url)

    async def analyze_content(
        self, content: str, source_url: str = ""
    ) -> dict[str, Any]:
        """Full analysis of JavaScript content."""
        self.think(
            f"Analyzing JS ({len(content)} bytes) from {source_url or 'unknown'}",
            confidence=0.85,
        )

        results: dict[str, Any] = {
            "source_url": source_url,
            "size_bytes": len(content),
            "secrets": [],
            "endpoints": [],
            "dom_xss_risks": [],
            "client_auth_checks": [],
            "webpack_chunks": [],
            "has_source_map": False,
            "graphql_queries": [],
            "jwt_usage": [],
        }

        # ── Secrets ──────────────────────────────────────────────────────────
        secrets = self._extract_secrets(content, source_url)
        results["secrets"] = [s.__dict__ for s in secrets]
        if secrets:
            critical = [s for s in secrets if s.secret_type in ("AWS_ACCESS_KEY", "PRIVATE_KEY", "STRIPE_KEY", "JWT_SECRET")]
            if critical:
                self.escalate_path(
                    f"HIGH-VALUE SECRET: {critical[0].secret_type} in {source_url}",
                    "Extract and validate credential"
                )
            self.record_evidence(
                f"Found {len(secrets)} secrets in JS",
                refs=[s.secret_type for s in secrets[:5]],
                confidence=0.85,
            )

        # ── Endpoints ─────────────────────────────────────────────────────────
        endpoints = self._extract_endpoints(content, source_url)
        results["endpoints"] = [e.__dict__ for e in endpoints]

        # ── DOM XSS ────────────────────────────────────────────────────────
        dom_risks = self._analyze_dom_xss(content)
        results["dom_xss_risks"] = dom_risks
        if dom_risks:
            self.record_evidence(
                f"DOM XSS sink-source paths: {len(dom_risks)}",
                refs=[r["sink"] for r in dom_risks[:3]],
                confidence=0.75,
            )

        # ── Client-side auth ─────────────────────────────────────────────────
        auth_checks = self._analyze_client_auth(content)
        results["client_auth_checks"] = [c.__dict__ for c in auth_checks]
        for check in auth_checks:
            if check.severity == "high":
                self.escalate_path(
                    f"Client-side auth bypass: {check.check_type}",
                    "Test by modifying client-side variables"
                )

        # ── Webpack chunks ────────────────────────────────────────────────────
        if "webpack_require" in content or "__webpack_modules__" in content:
            results["webpack_chunks"] = self._analyze_webpack(content)

        # ── Source map ───────────────────────────────────────────────────────
        if "//# sourceMappingURL=" in content or "//@ sourceMappingURL=" in content:
            results["has_source_map"] = True
            source_map_url = re.search(
                r'//[#@] sourceMappingURL=([^\s]+)', content
            )
            if source_map_url:
                map_url = source_map_url.group(1)
                if not map_url.startswith("data:"):
                    results["source_map_url"] = urljoin(source_url, map_url) if source_url else map_url
                    self.escalate_path(
                        f"Source map available: {map_url}",
                        "Download source map to reconstruct original source code"
                    )

        # ── GraphQL ───────────────────────────────────────────────────────────
        gql_queries = self._extract_graphql(content)
        results["graphql_queries"] = gql_queries

        # ── JWT usage ─────────────────────────────────────────────────────────
        jwt_findings = self._analyze_jwt(content)
        results["jwt_usage"] = jwt_findings

        self.conclude(
            f"JS analysis: {len(secrets)} secrets, {len(endpoints)} endpoints, "
            f"{len(dom_risks)} DOM XSS risks",
            confidence=0.85,
            evidence_refs=[source_url] if source_url else [],
        )

        return results

    def _extract_secrets(self, content: str, source_url: str) -> list[JSSecret]:
        """Extract secrets from JavaScript content."""
        found: list[JSSecret] = []
        seen_values: set[str] = set()

        for pattern, secret_type, confidence in SECRET_PATTERNS:
            for match in re.finditer(pattern, content, re.IGNORECASE):
                value = match.group(1) if match.lastindex else match.group(0)
                # Skip obvious placeholders
                if any(x in value.lower() for x in ["your_", "example", "placeholder", "xxx", "<", ">"]):
                    continue
                # Deduplicate
                value_hash = hashlib.md5(value.encode()).hexdigest()[:8]
                if value_hash in seen_values:
                    continue
                seen_values.add(value_hash)

                # Get surrounding context
                start = max(0, match.start() - 60)
                end = min(len(content), match.end() + 60)
                context = content[start:end].replace("\n", " ")

                found.append(JSSecret(
                    secret_type=secret_type,
                    value=value[:200],
                    context=context,
                    file=source_url,
                    confidence=confidence,
                ))

        return found

    def _extract_endpoints(self, content: str, source_url: str) -> list[JSEndpoint]:
        """Extract API endpoints from JavaScript."""
        endpoints: list[JSEndpoint] = []
        seen: set[str] = set()

        patterns = [
            # fetch/axios calls
            r'(?:fetch|axios\.(?:get|post|put|delete|patch))\(["\']([/a-zA-Z0-9_\-\.{}$:]+)["\']',
            # string URL patterns
            r'["\']([/][a-zA-Z0-9_\-\/\.]*(?:api|v\d|graphql|auth|admin|user|account|order|payment|webhook)[a-zA-Z0-9_\-\/\.]*)["\']',
            # template literals
            r'`([/][a-zA-Z0-9_\-\/\.]*(?:api|v\d)[a-zA-Z0-9_\-\/\.\${}`]*)`',
            # config objects
            r'(?:baseURL|endpoint|apiUrl|API_URL)["\s:=\']+["\']([/a-zA-Z0-9_\-\.]+)["\']',
        ]

        for pattern in patterns:
            for match in re.finditer(pattern, content, re.IGNORECASE):
                path = match.group(1)
                if len(path) < 4 or path in seen:
                    continue
                if any(x in path.lower() for x in [".js", ".css", ".png", ".jpg", ".gif"]):
                    continue
                seen.add(path)

                # Detect method from context
                ctx = content[max(0, match.start()-40):match.start()]
                method = "GET"
                for m in ["post", "put", "delete", "patch"]:
                    if m in ctx.lower():
                        method = m.upper()
                        break

                # Detect auth
                surrounding = content[max(0, match.start()-200):match.end()+200]
                auth_required = any(x in surrounding.lower() for x in [
                    "authorization", "bearer", "token", "auth", "session"
                ])

                endpoints.append(JSEndpoint(
                    path=path,
                    method=method,
                    auth_required=auth_required,
                    source_chunk=source_url,
                ))

        return endpoints[:100]

    def _analyze_dom_xss(self, content: str) -> list[dict[str, Any]]:
        """Identify DOM XSS source→sink flows."""
        risks: list[dict[str, Any]] = []

        for sink in DOM_SINKS:
            sink_positions = [m.start() for m in re.finditer(re.escape(sink), content)]
            for pos in sink_positions[:5]:
                # Look back 300 chars for a source
                window = content[max(0, pos-300):pos+100]
                for source in DOM_SOURCES:
                    if source in window:
                        # Check if they're connected (rough heuristic)
                        risks.append({
                            "sink": sink,
                            "source": source,
                            "snippet": window.replace("\n", " ")[:200],
                            "severity": "high" if sink in ("innerHTML", "document.write", "eval(") else "medium",
                        })
                        break

        return risks[:20]

    def _analyze_client_auth(self, content: str) -> list[JSClientAuthCheck]:
        """Find client-side authentication/authorization checks."""
        checks: list[JSClientAuthCheck] = []

        for pattern, check_type in AUTH_CHECK_PATTERNS:
            for match in re.finditer(pattern, content, re.IGNORECASE):
                snippet = content[max(0, match.start()-20):match.end()+100]
                severity = "high" if "dead_code" in check_type or "hardcoded_false" in check_type else "medium"
                bypass_risk = (
                    "Authorization logic in client-side code can be bypassed by modifying the JS bundle or setting variables in browser console"
                )
                if "hardcoded_false" in check_type:
                    bypass_risk = "CRITICAL: Auth check is hardcoded to false — admin access may be trivially accessible"
                    severity = "critical"
                checks.append(JSClientAuthCheck(
                    check_type=check_type,
                    code_snippet=snippet.strip()[:200],
                    bypass_risk=bypass_risk,
                    severity=severity,
                ))

        return checks[:20]

    def _analyze_webpack(self, content: str) -> list[dict[str, Any]]:
        """Analyze webpack bundle for chunk information."""
        chunks: list[dict[str, Any]] = []

        # Extract chunk IDs and associated module names
        chunk_pattern = re.compile(
            r'(\d+):\s*\[function\s*\(|"(\d+)":\s*function\s*\('
        )
        for match in chunk_pattern.finditer(content):
            chunk_id = match.group(1) or match.group(2)
            # Try to find module path near this chunk
            nearby = content[match.start():match.start()+300]
            path_match = re.search(r'["\']([./][^"\']+\.(?:js|ts|jsx|tsx))["\']', nearby)
            chunks.append({
                "chunk_id": chunk_id,
                "module_path": path_match.group(1) if path_match else None,
                "has_source_ref": bool(path_match),
            })

        return chunks[:30]

    def _extract_graphql(self, content: str) -> list[dict[str, Any]]:
        """Extract GraphQL queries and mutations."""
        queries: list[dict[str, Any]] = []

        patterns = [
            r'gql`([^`]+)`',
            r'(?:query|mutation|subscription)\s+(\w+)\s*[({]',
            r'"(?:query|mutation)"\s*:\s*"([^"]+)"',
        ]

        for pattern in patterns:
            for match in re.finditer(pattern, content, re.DOTALL):
                q = match.group(1)[:300]
                if len(q) > 10:
                    op_type = "query"
                    if "mutation" in q.lower():
                        op_type = "mutation"
                    queries.append({
                        "type": op_type,
                        "snippet": q.strip()[:200],
                        "has_variables": "$" in q,
                    })

        return queries[:20]

    def _analyze_jwt(self, content: str) -> list[dict[str, Any]]:
        """Analyze JWT usage patterns for vulnerabilities."""
        findings: list[dict[str, Any]] = []

        # localStorage JWT storage
        if re.search(r'localStorage[.\[]["\']token["\']', content):
            findings.append({
                "type": "jwt_in_localstorage",
                "severity": "medium",
                "description": "JWT token stored in localStorage — vulnerable to XSS theft",
            })

        # Algorithm 'none'
        if re.search(r'["\']alg["\']:\s*["\']none["\']', content, re.IGNORECASE):
            findings.append({
                "type": "jwt_none_algorithm",
                "severity": "critical",
                "description": "JWT library may accept 'none' algorithm — token forgery possible",
            })

        # Weak secret detection
        if re.search(r'(?:jwt|sign|verify)\s*\([^,)]+,\s*["\'](?:secret|password|12345|admin)["\']', content, re.IGNORECASE):
            findings.append({
                "type": "jwt_weak_secret",
                "severity": "critical",
                "description": "Hardcoded weak JWT secret detected in client-side code",
            })

        # Algorithm in header
        alg_matches = re.findall(r'["\']alg["\']:\s*["\']([A-Z0-9]+)["\']', content)
        for alg in alg_matches:
            if alg == "HS256":
                findings.append({
                    "type": "jwt_hs256_in_client",
                    "severity": "high",
                    "description": f"JWT algorithm {alg} visible in client code — test RS256→HS256 confusion if this is a public key scenario",
                })

        return findings
