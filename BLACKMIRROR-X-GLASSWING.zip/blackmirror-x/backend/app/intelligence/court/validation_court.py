"""Multi-Agent Validation Court.

For every vulnerability:
  1. ResearchAgent argues validity
  2. FalsePositiveAgent argues against
  3. ScopeAgent checks rules of engagement
  4. EvidenceAgent checks proof quality
  5. JudgeAgent issues final verdict

Generates: confidence score, exploitability score, bounty likelihood, duplicate risk.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

import anthropic

from app.core.config import settings
from app.core.logging import get_logger
from app.intelligence.reasoning import ReasoningAgentBase, ReasoningStepType

logger = get_logger(__name__)


@dataclass
class CourtVerdict:
    vuln_id: str
    final_confidence: float       # 0–1
    exploitability_score: float   # 0–10 (CVSS-like)
    bounty_likelihood: float      # 0–1
    duplicate_risk: float         # 0–1
    is_valid: bool
    is_in_scope: bool
    evidence_quality: float       # 0–1 (0=none, 1=perfect)
    severity_recommendation: str
    prosecution_summary: str      # Research agent argument
    defense_summary: str          # FP agent argument
    scope_verdict: str
    evidence_verdict: str
    judge_reasoning: str
    recommended_actions: list[str] = field(default_factory=list)
    downgrade_reason: str = ""


class ValidationCourt(ReasoningAgentBase):
    """Five-agent validation court for vulnerabilities."""

    agent_name = "validation_court"

    def __init__(self, scan_id: str = "", workspace_id: str = ""):
        super().__init__(scan_id, workspace_id)
        self.client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)

    async def adjudicate(
        self,
        vuln: dict[str, Any],
        scope_rules: dict[str, Any] | None = None,
        memory_context: dict[str, Any] | None = None,
    ) -> CourtVerdict:
        """Run the full validation court for a vulnerability."""

        self.think(
            f"COURT CONVENED for: {vuln.get('title', 'Unknown')} [{vuln.get('severity', 'unknown')}]",
            confidence=0.9,
        )

        # ── 1. Research Agent (prosecution) ──────────────────────────────────
        prosecution = await self._prosecution_argument(vuln, memory_context)
        self.decide(
            f"PROSECUTION: {prosecution[:100]}",
            rationale="Research agent arguing validity",
            confidence=0.7,
        )

        # ── 2. False Positive Agent (defense) ────────────────────────────────
        defense = await self._defense_argument(vuln, memory_context)
        self.decide(
            f"DEFENSE: {defense[:100]}",
            rationale="FP agent arguing against",
            confidence=0.7,
        )

        # ── 3. Scope Agent ───────────────────────────────────────────────────
        scope_result = self._scope_check(vuln, scope_rules or {})
        self.think(
            f"SCOPE: {'IN SCOPE' if scope_result['in_scope'] else 'OUT OF SCOPE'} — {scope_result['reason']}",
            confidence=0.95,
        )

        # ── 4. Evidence Agent ────────────────────────────────────────────────
        evidence_result = self._evidence_check(vuln)
        self.record_evidence(
            f"Evidence quality: {evidence_result['quality_score']:.0%} — {evidence_result['verdict']}",
            refs=evidence_result["present_evidence"],
            confidence=evidence_result["quality_score"],
        )

        # ── 5. Judge Agent ───────────────────────────────────────────────────
        verdict = await self._judge_verdict(
            vuln, prosecution, defense, scope_result, evidence_result, memory_context
        )

        self.conclude(
            f"VERDICT: {'VALID' if verdict.is_valid else 'INVALID'} | "
            f"Confidence={verdict.final_confidence:.0%} | "
            f"Exploitability={verdict.exploitability_score:.1f}/10 | "
            f"Bounty={verdict.bounty_likelihood:.0%}",
            confidence=verdict.final_confidence,
        )

        return verdict

    async def _prosecution_argument(
        self, vuln: dict[str, Any], memory: dict[str, Any] | None
    ) -> str:
        """Research agent builds the case for validity."""
        prev_successes = memory.get("successful_vuln_types", {}).get(
            vuln.get("vuln_type", ""), 0
        ) if memory else 0

        prompt = f"""You are a senior security researcher arguing that this vulnerability is VALID and HIGH IMPACT.

Vulnerability:
{json.dumps(vuln, indent=2, default=str)[:1500]}

Historical context: {prev_successes} similar vulns confirmed in this workspace before.

In 3–4 sentences, argue:
1. Why this is a genuine vulnerability
2. The concrete impact on users/data
3. Why it should be accepted on HackerOne

Be specific about the attack vector and impact. Do NOT be defensive."""

        try:
            resp = await self.client.messages.create(
                model=settings.AI_MODEL,
                max_tokens=300,
                messages=[{"role": "user", "content": prompt}],
            )
            return resp.content[0].text
        except Exception:
            return f"Valid {vuln.get('vuln_type', 'unknown')} vulnerability confirmed at {vuln.get('url', 'unknown endpoint')}."

    async def _defense_argument(
        self, vuln: dict[str, Any], memory: dict[str, Any] | None
    ) -> str:
        """False Positive agent challenges the finding."""
        prev_fps = memory.get("rejected_vuln_types", {}).get(
            vuln.get("vuln_type", ""), 0
        ) if memory else 0

        prompt = f"""You are a false-positive skeptic. Challenge whether this vulnerability is real.

Vulnerability:
{json.dumps(vuln, indent=2, default=str)[:1500]}

Historical context: {prev_fps} similar vulns flagged as false positive in this workspace before.

In 2–3 sentences, argue:
1. Why this might be a false positive
2. Alternative explanations for the behavior
3. What additional evidence is needed to confirm

Be specific. Focus on: missing reproduction evidence, WAF interference, expected behavior."""

        try:
            resp = await self.client.messages.create(
                model=settings.AI_MODEL,
                max_tokens=250,
                messages=[{"role": "user", "content": prompt}],
            )
            return resp.content[0].text
        except Exception:
            return "No reproduction evidence provided. Behavior may be expected by design."

    def _scope_check(
        self, vuln: dict[str, Any], scope_rules: dict[str, Any]
    ) -> dict[str, Any]:
        """Scope agent validates the finding is within scope."""
        url = vuln.get("url", "")
        in_scope_domains = scope_rules.get("in_scope", [])
        out_of_scope_domains = scope_rules.get("out_of_scope", [])
        allowed_vuln_types = scope_rules.get("allowed_vuln_types", [])

        # Default: in scope if no rules
        if not in_scope_domains and not out_of_scope_domains:
            return {
                "in_scope": True,
                "reason": "No scope rules defined — assuming in scope",
                "confidence": 0.6,
            }

        # Check out of scope
        for oos in out_of_scope_domains:
            if oos.lower() in url.lower():
                return {
                    "in_scope": False,
                    "reason": f"Domain matches out-of-scope rule: {oos}",
                    "confidence": 0.95,
                }

        # Check in scope
        if in_scope_domains:
            for iis in in_scope_domains:
                if iis.lower() in url.lower():
                    return {
                        "in_scope": True,
                        "reason": f"Domain matches in-scope rule: {iis}",
                        "confidence": 0.95,
                    }
            return {
                "in_scope": False,
                "reason": "URL does not match any in-scope rule",
                "confidence": 0.85,
            }

        return {"in_scope": True, "reason": "No blocking scope rules", "confidence": 0.7}

    def _evidence_check(self, vuln: dict[str, Any]) -> dict[str, Any]:
        """Evidence agent checks proof quality."""
        present: list[str] = []
        missing: list[str] = []
        score = 0.0

        # Check each evidence type
        evidence_types = {
            "description": (0.15, bool(vuln.get("description", ""))),
            "url": (0.10, bool(vuln.get("url", ""))),
            "payload": (0.20, bool(vuln.get("payload", ""))),
            "reproduction_steps": (0.20, bool(vuln.get("reproduction_steps", ""))),
            "evidence": (0.15, bool(vuln.get("evidence", ""))),
            "remediation": (0.10, bool(vuln.get("remediation", ""))),
            "cvss_score": (0.05, bool(vuln.get("cvss_score"))),
            "cwe_id": (0.05, bool(vuln.get("cwe_id"))),
        }

        for field_name, (weight, has_it) in evidence_types.items():
            if has_it:
                present.append(field_name)
                score += weight
            else:
                missing.append(field_name)

        # Penalize very short descriptions
        desc = vuln.get("description", "")
        if desc and len(desc) < 50:
            score = max(0, score - 0.10)
            missing.append("detailed_description")

        quality_score = min(1.0, score)

        # Verdict
        if quality_score >= 0.80:
            verdict = "STRONG — all critical evidence present"
        elif quality_score >= 0.60:
            verdict = "ADEQUATE — sufficient for submission"
        elif quality_score >= 0.40:
            verdict = "WEAK — missing key evidence, needs improvement"
        else:
            verdict = "INSUFFICIENT — finding should be downgraded until evidence is added"

        return {
            "quality_score": quality_score,
            "present_evidence": present,
            "missing_evidence": missing,
            "verdict": verdict,
            "should_downgrade": quality_score < 0.40,
        }

    async def _judge_verdict(
        self,
        vuln: dict[str, Any],
        prosecution: str,
        defense: str,
        scope_result: dict[str, Any],
        evidence_result: dict[str, Any],
        memory: dict[str, Any] | None,
    ) -> CourtVerdict:
        """Judge agent issues the final verdict."""
        severity = vuln.get("severity", "info")
        vuln_type = vuln.get("vuln_type", "unknown")
        evidence_score = evidence_result["quality_score"]

        prompt = f"""You are the chief judge in a vulnerability validation court. Issue your final verdict.

PROSECUTION argued: {prosecution}

DEFENSE argued: {defense}

SCOPE: {'IN SCOPE' if scope_result['in_scope'] else 'OUT OF SCOPE'} — {scope_result['reason']}

EVIDENCE QUALITY: {evidence_score:.0%} — {evidence_result['verdict']}
Missing evidence: {', '.join(evidence_result['missing_evidence']) or 'none'}

Vulnerability details:
- Type: {vuln_type}
- Severity: {severity}
- URL: {vuln.get('url', '')}
- Has payload: {'yes' if vuln.get('payload') else 'no'}

Issue your verdict as JSON:
{{
  "is_valid": true/false,
  "final_confidence": 0.0-1.0,
  "exploitability_score": 0.0-10.0,
  "bounty_likelihood": 0.0-1.0,
  "duplicate_risk": 0.0-1.0,
  "severity_recommendation": "critical|high|medium|low|info",
  "judge_reasoning": "2-3 sentence rationale",
  "recommended_actions": ["action1", "action2"],
  "downgrade_reason": "why severity was lowered, or empty string"
}}
Respond ONLY with JSON."""

        try:
            resp = await self.client.messages.create(
                model=settings.AI_MODEL,
                max_tokens=500,
                messages=[{"role": "user", "content": prompt}],
            )
            text = resp.content[0].text
            start = text.find("{")
            end = text.rfind("}") + 1
            data = json.loads(text[start:end])

            # Apply evidence downgrade
            final_severity = data.get("severity_recommendation", severity)
            if evidence_result["should_downgrade"] and final_severity in ("critical", "high"):
                final_severity = "medium"
                data["downgrade_reason"] = "Insufficient evidence — severity automatically downgraded"

            return CourtVerdict(
                vuln_id=str(vuln.get("id", "")),
                final_confidence=min(1.0, max(0.0, data.get("final_confidence", 0.5))),
                exploitability_score=min(10.0, max(0.0, data.get("exploitability_score", 5.0))),
                bounty_likelihood=min(1.0, max(0.0, data.get("bounty_likelihood", 0.3))),
                duplicate_risk=min(1.0, max(0.0, data.get("duplicate_risk", 0.1))),
                is_valid=data.get("is_valid", True) and scope_result["in_scope"],
                is_in_scope=scope_result["in_scope"],
                evidence_quality=evidence_score,
                severity_recommendation=final_severity,
                prosecution_summary=prosecution,
                defense_summary=defense,
                scope_verdict=scope_result["reason"],
                evidence_verdict=evidence_result["verdict"],
                judge_reasoning=data.get("judge_reasoning", ""),
                recommended_actions=data.get("recommended_actions", []),
                downgrade_reason=data.get("downgrade_reason", ""),
            )
        except Exception as e:
            logger.warning("judge_verdict_failed", error=str(e))
            # Fallback verdict
            is_valid = scope_result["in_scope"] and evidence_score > 0.3
            return CourtVerdict(
                vuln_id=str(vuln.get("id", "")),
                final_confidence=0.5 * evidence_score,
                exploitability_score=5.0,
                bounty_likelihood=0.4 if is_valid else 0.1,
                duplicate_risk=0.15,
                is_valid=is_valid,
                is_in_scope=scope_result["in_scope"],
                evidence_quality=evidence_score,
                severity_recommendation=severity,
                prosecution_summary=prosecution,
                defense_summary=defense,
                scope_verdict=scope_result["reason"],
                evidence_verdict=evidence_result["verdict"],
                judge_reasoning="Automated fallback verdict due to AI unavailability.",
                recommended_actions=["Add reproduction steps", "Attach request/response proof"],
            )
