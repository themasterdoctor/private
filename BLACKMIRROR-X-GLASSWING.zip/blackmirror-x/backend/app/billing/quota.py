"""SaaS Billing / Quota Module — DISABLED BY DEFAULT.

This module provides plan-based limits, scan quotas, workspace seats,
and API usage metering. All enforcement is disabled until BILLING_ENABLED=true.

To enable: set BILLING_ENABLED=true in .env and configure plan limits.
No Stripe or payment processor is wired yet.

Plans:
  free:       3 scans/month, 1 workspace, 1 user
  pro:        50 scans/month, 5 workspaces, 5 users
  team:       unlimited scans, 20 workspaces, 25 users
  enterprise: unlimited everything, custom
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import os

BILLING_ENABLED = os.environ.get("BILLING_ENABLED", "false").lower() == "true"


@dataclass
class PlanLimits:
    plan_name: str
    scans_per_month: int        # -1 = unlimited
    workspaces: int             # -1 = unlimited
    seats: int                  # users per workspace
    api_calls_per_day: int      # -1 = unlimited
    scan_timeout_seconds: int
    max_subdomains_per_scan: int
    report_exports_per_month: int


PLANS: dict[str, PlanLimits] = {
    "free": PlanLimits(
        plan_name="free",
        scans_per_month=3,
        workspaces=1,
        seats=1,
        api_calls_per_day=100,
        scan_timeout_seconds=300,
        max_subdomains_per_scan=50,
        report_exports_per_month=5,
    ),
    "pro": PlanLimits(
        plan_name="pro",
        scans_per_month=50,
        workspaces=5,
        seats=5,
        api_calls_per_day=10000,
        scan_timeout_seconds=3600,
        max_subdomains_per_scan=500,
        report_exports_per_month=50,
    ),
    "team": PlanLimits(
        plan_name="team",
        scans_per_month=-1,
        workspaces=20,
        seats=25,
        api_calls_per_day=-1,
        scan_timeout_seconds=7200,
        max_subdomains_per_scan=2000,
        report_exports_per_month=-1,
    ),
    "enterprise": PlanLimits(
        plan_name="enterprise",
        scans_per_month=-1,
        workspaces=-1,
        seats=-1,
        api_calls_per_day=-1,
        scan_timeout_seconds=-1,
        max_subdomains_per_scan=-1,
        report_exports_per_month=-1,
    ),
}


class QuotaEnforcer:
    """Checks and enforces plan quotas. No-op when BILLING_ENABLED=false."""

    def __init__(self, plan: str = "enterprise"):
        self.plan = PLANS.get(plan, PLANS["enterprise"])
        self.enabled = BILLING_ENABLED

    def check_scan_quota(self, workspace_id: str, scans_this_month: int) -> dict[str, Any]:
        """Check if workspace can create another scan."""
        if not self.enabled:
            return {"allowed": True, "reason": "billing_disabled"}
        limit = self.plan.scans_per_month
        if limit == -1:
            return {"allowed": True, "limit": -1}
        if scans_this_month >= limit:
            return {
                "allowed": False,
                "reason": f"Monthly scan limit reached ({limit})",
                "current": scans_this_month,
                "limit": limit,
                "upgrade_hint": "Upgrade to Pro or Team plan for more scans",
            }
        return {"allowed": True, "current": scans_this_month, "limit": limit}

    def check_workspace_quota(self, user_workspace_count: int) -> dict[str, Any]:
        """Check if user can create another workspace."""
        if not self.enabled:
            return {"allowed": True, "reason": "billing_disabled"}
        limit = self.plan.workspaces
        if limit == -1:
            return {"allowed": True}
        if user_workspace_count >= limit:
            return {
                "allowed": False,
                "reason": f"Workspace limit reached ({limit})",
                "upgrade_hint": "Upgrade to Team plan for more workspaces",
            }
        return {"allowed": True}

    def get_limits(self) -> dict[str, Any]:
        """Return current plan limits."""
        return {
            "plan": self.plan.plan_name,
            "billing_enabled": self.enabled,
            "limits": {
                "scans_per_month": self.plan.scans_per_month,
                "workspaces": self.plan.workspaces,
                "seats": self.plan.seats,
                "api_calls_per_day": self.plan.api_calls_per_day,
                "scan_timeout_seconds": self.plan.scan_timeout_seconds,
                "max_subdomains_per_scan": self.plan.max_subdomains_per_scan,
                "report_exports_per_month": self.plan.report_exports_per_month,
            },
            "note": "All limits are disabled. Set BILLING_ENABLED=true to enforce." if not self.enabled else None,
        }


# Default enforcer (enterprise = unlimited, billing disabled)
default_enforcer = QuotaEnforcer(plan="enterprise")
