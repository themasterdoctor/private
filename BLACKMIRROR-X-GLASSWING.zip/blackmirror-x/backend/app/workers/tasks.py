"""
BLACKMIRROR-X Celery Tasks
Main scan pipeline + agent runners.
"""
import asyncio
from datetime import datetime, timezone
from typing import Dict, Any

from celery import shared_task
from sqlalchemy.orm import Session
from sqlalchemy import create_engine

from app.core.config import settings
from app.workers.celery_app import celery_app

# Sync engine for Celery workers
sync_engine = create_engine(settings.DATABASE_URL_SYNC)


def get_sync_session():
    from sqlalchemy.orm import sessionmaker
    SessionLocal = sessionmaker(bind=sync_engine)
    return SessionLocal()


def add_log(db, scan_id: str, level: str, module: str, message: str, data: Dict = None):
    from app.models.models import ScanLog
    log = ScanLog(scan_id=scan_id, level=level, module=module, message=message, data=data)
    db.add(log)
    db.commit()


@celery_app.task(bind=True, name="app.workers.tasks.run_scan_task", max_retries=1)
def run_scan_task(self, scan_id: str):
    """Main scan pipeline task."""
    from app.models.models import ScanJob, ScanStatus, Target
    from app.agents.recon.agent import ReconAgent
    from app.agents.vuln_research.agent import VulnResearchAgent
    from app.agents.js_analysis.agent import JSIntelAgent
    from app.models.models import Subdomain, DiscoveredURL, Vulnerability

    db = get_sync_session()

    try:
        scan = db.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return {"error": "Scan not found"}

        scan.status = ScanStatus.RUNNING
        scan.started_at = datetime.now(timezone.utc)
        db.commit()

        # Get target
        target = None
        domain = scan.config.get("domain", "")
        if scan.target_id:
            target = db.query(Target).filter(Target.id == scan.target_id).first()
            if target:
                domain = target.domain

        if not domain:
            scan.status = ScanStatus.FAILED
            scan.error_message = "No target domain configured"
            db.commit()
            return {"error": "No domain"}

        def log_sync(level, module, message, data=None):
            add_log(db, scan_id, level, module, message, data)

        log_sync("info", "pipeline", f"Starting scan pipeline for {domain}")

        # ─── Phase 1: Recon ───────────────────────────────
        scan.progress = 10
        db.commit()
        log_sync("info", "pipeline", "Phase 1: Reconnaissance")

        recon_config = scan.config.get("recon", {})
        recon_results = asyncio.get_event_loop().run_until_complete(
            _run_recon(scan_id, scan.workspace_id, domain, recon_config, log_sync)
        ) if asyncio.get_event_loop().is_running() else asyncio.run(
            _run_recon(scan_id, scan.workspace_id, domain, recon_config, log_sync)
        )

        # Persist subdomains
        for subdomain_host in recon_results.get("subdomains", [])[:settings.MAX_SUBDOMAINS_PER_SCAN]:
            sub = Subdomain(
                scan_id=scan_id,
                workspace_id=scan.workspace_id,
                host=subdomain_host,
                source="recon_agent",
            )
            db.add(sub)

        # Persist URLs
        for url_str in recon_results.get("urls", [])[:settings.MAX_URLS_PER_SCAN]:
            url = DiscoveredURL(
                scan_id=scan_id,
                workspace_id=scan.workspace_id,
                url=url_str,
                source="crawler",
            )
            db.add(url)

        db.commit()

        scan.progress = 40
        db.commit()
        log_sync("success", "pipeline", f"Recon complete: {len(recon_results.get('subdomains', []))} subdomains, {len(recon_results.get('urls', []))} URLs")

        # ─── Phase 2: Nuclei scan ────────────────────────
        if scan.config.get("nuclei", True):
            scan.progress = 50
            db.commit()
            log_sync("info", "nuclei", "Phase 2: Running Nuclei templates")

            nuclei_findings = asyncio.run(
                _run_nuclei(scan_id, domain, recon_results.get("live_hosts", []), log_sync)
            )

            for finding in nuclei_findings:
                vuln = Vulnerability(
                    scan_id=scan_id,
                    workspace_id=scan.workspace_id,
                    source="nuclei",
                    **finding,
                )
                db.add(vuln)
            db.commit()

            log_sync("success", "nuclei", f"Nuclei found {len(nuclei_findings)} issues")

        # ─── Phase 3: JS Analysis ─────────────────────────
        scan.progress = 60
        db.commit()
        log_sync("info", "js_intel", "Phase 3: JavaScript Intelligence Analysis")

        js_secrets_found = 0
        for url_obj in db.query(DiscoveredURL).filter(
            DiscoveredURL.scan_id == scan_id,
            DiscoveredURL.url.like("%.js"),
        ).limit(20).all():
            try:
                import asyncio
                from app.intelligence.js_ast.js_reverse import JSReverseEngineer
                eng = JSReverseEngineer(scan_id=scan_id)
                result = asyncio.run(eng.analyze_url(url_obj.url))
                for secret in result.get("secrets", []):
                    js_secrets_found += 1
                    vuln = Vulnerability(
                        scan_id=scan_id, workspace_id=scan.workspace_id,
                        title=f"Secret in JS: {secret['secret_type']}",
                        vuln_type="secret_exposure", severity="high",
                        url=url_obj.url, description=f"Found {secret['secret_type']} in JavaScript bundle",
                        evidence=secret["context"][:200] if secret.get("context") else "",
                        source="js_intel",
                    )
                    db.add(vuln)
                db.commit()
            except Exception as e:
                log_sync("warn", "js_intel", f"JS analysis error for {url_obj.url}: {e}")

        log_sync("success", "js_intel", f"JS analysis complete: {js_secrets_found} secrets found")

        # ─── Phase 4: Vulnerability Testing + Hypothesis ────
        scan.progress = 75
        db.commit()
        log_sync("info", "vuln", "Phase 4: Hypothesis generation + vulnerability testing")

        try:
            from app.intelligence.hypothesis.engine import HypothesisEngine
            urls_for_hyp = [u.url for u in db.query(DiscoveredURL).filter(
                DiscoveredURL.scan_id == scan_id).limit(200).all()]
            subs_for_hyp = [s.host for s in db.query(Subdomain).filter(
                Subdomain.scan_id == scan_id).all()]
            techs = []
            for s in db.query(Subdomain).filter(Subdomain.scan_id == scan_id).all():
                techs.extend(s.tech_stack or [])
            
            engine = HypothesisEngine(scan_id=scan_id, workspace_id=str(scan.workspace_id))
            hypotheses = engine.form_hypotheses_from_signals(
                urls=urls_for_hyp, params=[],
                technologies=list(set(techs)), headers={}, existing_vulns=[]
            )
            log_sync("info", "vuln", f"Generated {len(hypotheses)} vulnerability hypotheses")
        except Exception as e:
            log_sync("warn", "vuln", f"Hypothesis generation error: {e}")

        # ─── Phase 5: Intelligence enrichment ───────────────
        scan.progress = 90
        db.commit()
        log_sync("info", "ai", "Phase 5: Post-scan intelligence (self-improvement + attack chains)")

        try:
            from app.intelligence.self_improvement import SelfImprovementLoop
            found_vulns = db.query(Vulnerability).filter(Vulnerability.scan_id == scan_id).all()
            confirmed_vulns = [{"vuln_type": v.vuln_type, "confirmed": True, "url": v.url or "",
                                 "payload": v.payload or ""} for v in found_vulns]
            # Update workspace memory synchronously (in-memory cache; async persistence via API)
            from app.intelligence.memory.workspace_memory import WorkspaceMemory
            mem = WorkspaceMemory(workspace_id=str(scan.workspace_id))
            for v in found_vulns:
                mem.record_finding(v.vuln_type, confirmed=True)
                if v.payload:
                    mem.record_payload_attempt(v.payload, v.vuln_type, success=True)
            # Persist to in-memory cache (DB write on next async request)
            from app.intelligence.memory.workspace_memory import WorkspaceMemoryService
            WorkspaceMemoryService._cache[str(scan.workspace_id)] = mem
            log_sync("info", "ai", f"Enrichment complete: {len(found_vulns)} findings recorded to workspace memory")
        except Exception as e:
            log_sync("warn", "ai", f"Intelligence enrichment error: {e}")

        # ─── Complete ─────────────────────────────────────
        scan.status = ScanStatus.COMPLETED
        scan.progress = 100
        scan.completed_at = datetime.now(timezone.utc)
        db.commit()

        log_sync("success", "pipeline", "Scan completed successfully!")
        return {"status": "completed", "scan_id": scan_id}

    except Exception as e:
        db.rollback()
        scan = db.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if scan:
            from app.models.models import ScanStatus
            scan.status = ScanStatus.FAILED
            scan.error_message = str(e)
            db.commit()
        add_log(db, scan_id, "error", "pipeline", f"Scan failed: {e}")
        raise

    finally:
        db.close()


async def _run_recon(scan_id, workspace_id, domain, config, log_fn):
    """Async recon wrapper."""
    async def async_log(**kwargs):
        log_fn(**kwargs)

    from app.agents.recon.agent import ReconAgent
    agent = ReconAgent(scan_id=scan_id, workspace_id=workspace_id)
    return await agent.run_full_recon(domain, config)


async def _run_nuclei(scan_id, domain, hosts, log_fn):
    """Run nuclei against discovered hosts."""
    import asyncio
    import json

    findings = []
    host_list = hosts[:20] if hosts else [domain]

    # Build target list
    targets = " ".join([f"-u {h}" for h in host_list[:5]])

    cmd = [
        settings.NUCLEI_PATH,
        "-t", "cves,exposures,misconfiguration,default-logins",
        "-severity", "critical,high,medium",
        "-json",
        "-silent",
        "-rate-limit", "50",
        "-timeout", "10",
        "-no-color",
    ] + [item for h in host_list[:5] for item in ["-u", h]]

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=300)

        for line in stdout.decode().splitlines():
            try:
                item = json.loads(line)
                findings.append({
                    "title": item.get("info", {}).get("name", "Nuclei Finding"),
                    "vuln_type": item.get("type", "unknown"),
                    "severity": item.get("info", {}).get("severity", "info"),
                    "url": item.get("matched-at", ""),
                    "template_id": item.get("template-id"),
                    "evidence": str(item.get("extracted-results", ""))[:500],
                    "description": item.get("info", {}).get("description", ""),
                })
            except json.JSONDecodeError:
                pass
    except (FileNotFoundError, asyncio.TimeoutError):
        log_fn("warn", "nuclei", "Nuclei not available or timed out (mock mode)")

    return findings


@celery_app.task(name="app.workers.tasks.generate_report_task")
def generate_report_task(scan_id: str, report_type: str = "markdown"):
    """Generate a report for a completed scan."""
    from app.models.models import ScanJob, Vulnerability, Subdomain, DiscoveredURL, Report

    db = get_sync_session()
    try:
        scan = db.query(ScanJob).filter(ScanJob.id == scan_id).first()
        if not scan:
            return {"error": "Scan not found"}

        vulns = db.query(Vulnerability).filter(Vulnerability.scan_id == scan_id).all()
        subdomains = db.query(Subdomain).filter(Subdomain.scan_id == scan_id).all()
        urls = db.query(DiscoveredURL).filter(DiscoveredURL.scan_id == scan_id).all()

        from app.agents.report_writer.agent import ReportWriterAgent
        agent = ReportWriterAgent()

        scan_data = {
            "scan_id": scan_id,
            "target": scan.config.get("domain", "Unknown"),
            "scan_date": scan.created_at.strftime("%Y-%m-%d"),
            "subdomains_count": len(subdomains),
            "live_hosts_count": len([s for s in subdomains if s.is_alive]),
            "urls_count": len(urls),
        }

        vuln_dicts = [
            {
                "title": v.title, "vuln_type": v.vuln_type, "severity": v.severity.value,
                "url": v.url, "parameter": v.parameter, "payload": v.payload,
                "evidence": v.evidence, "description": v.description,
                "remediation": v.remediation,
            }
            for v in vulns
        ]

        result = asyncio.run(agent.generate_full_report(scan_data, vuln_dicts, report_type))

        report = Report(
            scan_id=scan_id,
            workspace_id=scan.workspace_id,
            title=f"Security Report — {scan_data['target']} — {scan_data['scan_date']}",
            report_type=report_type,
            content=result["content"],
            extra_metadata=result.get("metadata", {}),
            generated_by_ai=True,
        )
        db.add(report)
        db.commit()

        return {"status": "done", "report_id": report.id}
    finally:
        db.close()


@celery_app.task(name="app.workers.tasks.cleanup_old_logs")
def cleanup_old_logs():
    """Clean up old scan logs (>30 days)."""
    from app.models.models import ScanLog
    from datetime import timedelta

    db = get_sync_session()
    try:
        cutoff = datetime.now(timezone.utc) - timedelta(days=30)
        deleted = db.query(ScanLog).filter(ScanLog.timestamp < cutoff).delete()
        db.commit()
        return {"deleted": deleted}
    finally:
        db.close()
