"""
BLACKMIRROR-X Celery Application
Defines the celery app and all async task workers.
"""
from celery import Celery
from app.core.config import settings

celery_app = Celery(
    "blackmirror",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=["app.workers.tasks"],
)

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_routes={
        "app.workers.tasks.run_scan_task": {"queue": "scans"},
        "app.workers.tasks.run_agent_task": {"queue": "agents"},
        "app.workers.tasks.generate_report_task": {"queue": "default"},
    },
    beat_schedule={
        "cleanup-old-logs": {
            "task": "app.workers.tasks.cleanup_old_logs",
            "schedule": 3600.0,  # hourly
        },
    },
)
