"""Continuous Monitoring Agent.

Monitors for:
- New subdomains
- Changed JS bundles (hash comparison)
- Newly exposed secrets
- Changed APIs
- New technologies
- Changed CSP/security headers
- Newly opened ports
- Changed responses
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Any

import httpx

from app.core.config import settings
from app.core.logging import get_logger
from app.intelligence.reasoning import ReasoningAgentBase

logger = get_logger(__name__)


@dataclass
class MonitoringAlert:
    alert_type: str
    severity: str
    title: str
    description: str
    workspace_id: str
    target: str
    old_value: str = ""
    new_value: str = ""
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "alert_type": self.alert_type,
            "severity": self.severity,
            "title": self.title,
            "description": self.description,
            "workspace_id": self.workspace_id,
            "target": self.target,
            "old_value": self.old_value[:200],
            "new_value": self.new_value[:200],
            "timestamp": self.timestamp,
        }


@dataclass
class MonitoringSnapshot:
    """Point-in-time snapshot of a target's security state."""
    target: str
    workspace_id: str
    timestamp: float = field(default_factory=time.time)
    subdomains: set[str] = field(default_factory=set)
    js_hashes: dict[str, str] = field(default_factory=dict)  # url -> content hash
    security_headers: dict[str, dict[str, str]] = field(default_factory=dict)  # url -> headers
    open_ports: dict[str, list[int]] = field(default_factory=dict)  # host -> ports
    csp: dict[str, str] = field(default_factory=dict)  # url -> csp value
    technologies: dict[str, list[str]] = field(default_factory=dict)  # subdomain -> techs
    api_endpoints: set[str] = field(default_factory=set)


# In-memory snapshot store (production: use Redis/PostgreSQL)
_snapshots: dict[str, MonitoringSnapshot] = {}


class ContinuousMonitorAgent(ReasoningAgentBase):
    """Continuous monitoring agent that detects changes between scans."""

    agent_name = "continuous_monitor"

    def __init__(self, workspace_id: str = ""):
        super().__init__("", workspace_id)

    async def take_snapshot(
        self,
        target: str,
        subdomains: list[dict[str, Any]],
        js_urls: list[str],
        workspace_id: str,
    ) -> MonitoringSnapshot:
        """Take a monitoring snapshot of current state."""
        snap = MonitoringSnapshot(target=target, workspace_id=workspace_id)

        # Snapshot subdomains
        snap.subdomains = {s["subdomain"] for s in subdomains}

        # Snapshot JS bundle hashes
        async with httpx.AsyncClient(verify=False, timeout=10) as client:
            for js_url in js_urls[:20]:
                try:
                    resp = await client.get(js_url)
                    if resp.status_code == 200:
                        snap.js_hashes[js_url] = hashlib.sha256(resp.content).hexdigest()[:16]
                except Exception:
                    pass

        # Snapshot security headers
        for sub in subdomains[:10]:
            try:
                url = f"https://{sub['subdomain']}"
                async with httpx.AsyncClient(verify=False, timeout=5) as client:
                    resp = await client.head(url)
                    snap.security_headers[url] = {
                        k.lower(): v for k, v in resp.headers.items()
                        if k.lower() in [
                            "content-security-policy", "x-frame-options",
                            "strict-transport-security", "x-content-type-options"
                        ]
                    }
                    csp = resp.headers.get("content-security-policy", "")
                    if csp:
                        snap.csp[url] = csp
            except Exception:
                pass

        # Store snapshot
        snap_key = f"{workspace_id}:{target}"
        _snapshots[snap_key] = snap

        self.think(
            f"Snapshot taken: {len(snap.subdomains)} subdomains, {len(snap.js_hashes)} JS bundles",
            confidence=0.9,
        )

        return snap

    async def compare_snapshots(
        self,
        current: MonitoringSnapshot,
        previous: MonitoringSnapshot | None,
    ) -> list[MonitoringAlert]:
        """Compare current snapshot to previous, return alerts for changes."""
        alerts: list[MonitoringAlert] = []

        if not previous:
            self.think("No previous snapshot — baseline established", confidence=0.9)
            return alerts

        target = current.target
        workspace_id = current.workspace_id

        # ── New subdomains ────────────────────────────────────────────────────
        new_subs = current.subdomains - previous.subdomains
        for sub in new_subs:
            alerts.append(MonitoringAlert(
                alert_type="new_subdomain",
                severity="medium",
                title=f"New subdomain discovered: {sub}",
                description=f"Previously unseen subdomain '{sub}' is now responding. Could indicate new deployment or infrastructure change.",
                workspace_id=workspace_id,
                target=target,
                new_value=sub,
            ))
            self.escalate_path(f"New subdomain: {sub}", "Scan for vulnerabilities on new asset")

        # ── Removed subdomains (takeover risk) ───────────────────────────────
        removed_subs = previous.subdomains - current.subdomains
        for sub in removed_subs:
            alerts.append(MonitoringAlert(
                alert_type="subdomain_removed",
                severity="high",
                title=f"Subdomain no longer responding: {sub}",
                description=f"'{sub}' was previously active but is no longer responding. Check for dangling DNS → subdomain takeover opportunity.",
                workspace_id=workspace_id,
                target=target,
                old_value=sub,
            ))
            self.escalate_path(f"Subdomain removed: {sub}", "Check for takeover via CNAME")

        # ── Changed JS bundles ─────────────────────────────────────────────
        for url, current_hash in current.js_hashes.items():
            prev_hash = previous.js_hashes.get(url)
            if prev_hash and prev_hash != current_hash:
                alerts.append(MonitoringAlert(
                    alert_type="js_bundle_changed",
                    severity="medium",
                    title=f"JavaScript bundle changed: {url.split('/')[-1]}",
                    description=f"JS file at {url} has changed. Re-analyze for new endpoints, secrets, or auth logic.",
                    workspace_id=workspace_id,
                    target=target,
                    old_value=prev_hash,
                    new_value=current_hash,
                ))
                self.think(f"JS bundle changed: {url}", confidence=0.85)

        # New JS bundles
        new_js = set(current.js_hashes.keys()) - set(previous.js_hashes.keys())
        for url in new_js:
            alerts.append(MonitoringAlert(
                alert_type="new_js_bundle",
                severity="low",
                title=f"New JavaScript bundle: {url.split('/')[-1]}",
                description=f"New JS bundle detected at {url}. Analyze for secrets and endpoints.",
                workspace_id=workspace_id,
                target=target,
                new_value=url,
            ))

        # ── Security header changes ───────────────────────────────────────────
        for url, headers in current.security_headers.items():
            prev_headers = previous.security_headers.get(url, {})
            for header, value in prev_headers.items():
                if header not in headers:
                    alerts.append(MonitoringAlert(
                        alert_type="security_header_removed",
                        severity="medium",
                        title=f"Security header removed: {header}",
                        description=f"'{header}' was present before but has been removed from {url}. Security posture degraded.",
                        workspace_id=workspace_id,
                        target=url,
                        old_value=value,
                    ))

        # ── CSP changes ──────────────────────────────────────────────────────
        for url, csp in current.csp.items():
            prev_csp = previous.csp.get(url, "")
            if prev_csp and prev_csp != csp:
                # Check if CSP became weaker
                dangerous_additions = ["unsafe-inline", "unsafe-eval", "*", "http:"]
                new_dangerous = [d for d in dangerous_additions if d in csp and d not in prev_csp]
                if new_dangerous:
                    alerts.append(MonitoringAlert(
                        alert_type="csp_weakened",
                        severity="high",
                        title=f"CSP weakened: {', '.join(new_dangerous)} added",
                        description=f"Content Security Policy at {url} now allows: {', '.join(new_dangerous)}. XSS protection reduced.",
                        workspace_id=workspace_id,
                        target=url,
                        old_value=prev_csp[:200],
                        new_value=csp[:200],
                    ))
                    self.escalate_path(
                        f"CSP weakened at {url}: {new_dangerous}",
                        "Test XSS with previously-blocked payloads"
                    )

        self.conclude(
            f"Monitoring diff: {len(alerts)} alerts",
            confidence=0.90,
            evidence_refs=[a.alert_type for a in alerts[:5]],
        )

        return alerts

    def get_previous_snapshot(self, workspace_id: str, target: str) -> MonitoringSnapshot | None:
        """Retrieve the stored snapshot for a target."""
        return _snapshots.get(f"{workspace_id}:{target}")


class MonitoringScheduler:
    """Schedules and manages continuous monitoring runs."""

    def __init__(self):
        self._tasks: dict[str, asyncio.Task] = {}

    async def start_monitoring(
        self,
        workspace_id: str,
        target: str,
        interval_hours: float = 24.0,
        on_alert: Any = None,
    ) -> None:
        """Start continuous monitoring for a target."""
        task_key = f"{workspace_id}:{target}"
        if task_key in self._tasks:
            return

        async def monitor_loop():
            while True:
                try:
                    agent = ContinuousMonitorAgent(workspace_id)
                    # In production, fetch current state from DB
                    logger.info("monitoring_run", workspace=workspace_id, target=target)
                    await asyncio.sleep(interval_hours * 3600)
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error("monitoring_error", error=str(e))
                    await asyncio.sleep(300)  # 5 min retry

        task = asyncio.create_task(monitor_loop())
        self._tasks[task_key] = task

    def stop_monitoring(self, workspace_id: str, target: str) -> None:
        """Stop monitoring for a target."""
        task_key = f"{workspace_id}:{target}"
        task = self._tasks.pop(task_key, None)
        if task:
            task.cancel()

    def active_monitors(self) -> list[str]:
        return list(self._tasks.keys())


# Global scheduler instance
monitor_scheduler = MonitoringScheduler()
