from typing import Optional, Dict, Any
from pydantic import BaseModel
from datetime import datetime


class CopilotRequest(BaseModel):
    workspace_id: str
    session_id: str
    message: str
    context: Optional[Dict[str, Any]] = None  # scan_id, vuln_id, etc.


class MessageOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    role: str
    content: str
    context: Optional[Dict[str, Any]]
    created_at: datetime


class CopilotSessionOut(BaseModel):
    session_id: str
    messages: list[MessageOut]
