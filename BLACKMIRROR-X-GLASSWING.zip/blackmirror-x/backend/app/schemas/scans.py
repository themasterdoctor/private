from typing import Optional, List, Dict, Any
from pydantic import BaseModel
from datetime import datetime


class ScanCreateRequest(BaseModel):
    workspace_id: str
    target_id: Optional[str] = None
    name: str
    scan_type: str = "full"
    config: Optional[Dict[str, Any]] = None


class ScanListOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    name: str
    scan_type: str
    status: str
    progress: int
    created_at: datetime
    started_at: Optional[datetime]
    completed_at: Optional[datetime]


class ScanOut(ScanListOut):
    workspace_id: str
    target_id: Optional[str]
    created_by: str
    config: Dict[str, Any]
    celery_task_id: Optional[str]
    error_message: Optional[str]


class ScanLogOut(BaseModel):
    model_config = {"from_attributes": True}
    id: str
    level: str
    module: str
    message: str
    data: Optional[Dict[str, Any]]
    timestamp: datetime
