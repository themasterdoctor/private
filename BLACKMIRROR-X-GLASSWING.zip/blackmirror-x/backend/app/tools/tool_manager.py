"""ToolManager — centralized detection and management of external tools.

Detects at startup whether each tool is available. If missing:
- Marks the capability as disabled
- Logs the install command
- Never crashes the application

Usage:
    from app.tools.tool_manager import tool_manager
    if tool_manager.available("subfinder"):
        ...
    capabilities = tool_manager.get_capabilities()
"""
from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Optional
import structlog

logger = structlog.get_logger(__name__)


@dataclass
class ToolInfo:
    name: str
    purpose: str
    binary: str
    install_cmd: str
    version_flag: str = "--version"
    available: bool = False
    version: Optional[str] = None
    capability: str = ""          # The feature this enables


TOOL_DEFINITIONS = [
    ToolInfo(
        name="subfinder",
        binary="subfinder",
        purpose="Passive subdomain enumeration",
        capability="subdomain_enumeration",
        install_cmd="go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest",
        version_flag="-version",
    ),
    ToolInfo(
        name="amass",
        binary="amass",
        purpose="Active subdomain enumeration",
        capability="subdomain_enum_active",
        install_cmd="go install -v github.com/owasp-amass/amass/v4/...@master",
    ),
    ToolInfo(
        name="dnsx",
        binary="dnsx",
        purpose="DNS resolution and validation",
        capability="dns_resolution",
        install_cmd="go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest",
    ),
    ToolInfo(
        name="httpx",
        binary="httpx",
        purpose="HTTP probing and fingerprinting",
        capability="http_probing",
        install_cmd="go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest",
    ),
    ToolInfo(
        name="naabu",
        binary="naabu",
        purpose="Port scanning",
        capability="port_scanning",
        install_cmd="go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest",
    ),
    ToolInfo(
        name="katana",
        binary="katana",
        purpose="Web crawling and URL discovery",
        capability="web_crawling",
        install_cmd="go install github.com/projectdiscovery/katana/cmd/katana@latest",
    ),
    ToolInfo(
        name="gau",
        binary="gau",
        purpose="Historical URL discovery",
        capability="historical_urls",
        install_cmd="go install github.com/lc/gau/v2/cmd/gau@latest",
    ),
    ToolInfo(
        name="waybackurls",
        binary="waybackurls",
        purpose="Wayback Machine URL discovery",
        capability="wayback_urls",
        install_cmd="go install github.com/tomnomnom/waybackurls@latest",
    ),
    ToolInfo(
        name="nuclei",
        binary="nuclei",
        purpose="Template-based vulnerability scanning",
        capability="nuclei_scanning",
        install_cmd="go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
        version_flag="-version",
    ),
    ToolInfo(
        name="chromium",
        binary="chromium",
        purpose="Browser automation for JS-heavy targets",
        capability="browser_intelligence",
        install_cmd="playwright install chromium --with-deps",
    ),
]


class ToolManager:
    """Centralized tool detection and capability management."""

    def __init__(self):
        self._tools: dict[str, ToolInfo] = {t.name: t for t in TOOL_DEFINITIONS}
        self._checked = False

    def detect_all(self) -> dict[str, bool]:
        """Detect all tools. Called once at startup."""
        results: dict[str, bool] = {}

        for name, tool in self._tools.items():
            # Try shutil.which first (fast)
            path = shutil.which(tool.binary)
            if path:
                tool.available = True
                # Try to get version
                try:
                    result = subprocess.run(
                        [tool.binary, tool.version_flag],
                        capture_output=True, text=True, timeout=5
                    )
                    # Version is usually in first line of stdout or stderr
                    out = (result.stdout or result.stderr or "").strip().split("\n")[0]
                    tool.version = out[:60] if out else "unknown"
                except Exception:
                    tool.version = "detected"
                logger.info("tool_detected", tool=name, version=tool.version)
            else:
                tool.available = False
                logger.warning(
                    "tool_not_found",
                    tool=name,
                    purpose=tool.purpose,
                    install=tool.install_cmd,
                )
            results[name] = tool.available

        # Special case: check playwright separately
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                # Just check if chromium executable is findable
                exec_path = p.chromium.executable_path if hasattr(p.chromium, 'executable_path') else None
            if exec_path or shutil.which("chromium-browser") or shutil.which("google-chrome"):
                self._tools["chromium"].available = True
                results["chromium"] = True
        except Exception:
            pass  # playwright not installed or chromium not available

        self._checked = True
        return results

    def available(self, tool_name: str) -> bool:
        """Check if a specific tool is available."""
        if not self._checked:
            self.detect_all()
        return self._tools.get(tool_name, ToolInfo("", "", "", "", available=False)).available

    def get_capabilities(self) -> dict[str, dict]:
        """Return full capability status for API responses."""
        if not self._checked:
            self.detect_all()
        return {
            name: {
                "available": tool.available,
                "purpose": tool.purpose,
                "version": tool.version,
                "capability": tool.capability,
                "install_cmd": tool.install_cmd if not tool.available else None,
            }
            for name, tool in self._tools.items()
        }

    def summary(self) -> str:
        """Human-readable summary of tool availability."""
        if not self._checked:
            self.detect_all()
        available = [n for n, t in self._tools.items() if t.available]
        missing = [n for n, t in self._tools.items() if not t.available]
        return (
            f"Tools available ({len(available)}): {', '.join(available) or 'none'}\n"
            f"Tools missing ({len(missing)}): {', '.join(missing) or 'none'}"
        )

    def require(self, tool_name: str, feature: str) -> bool:
        """Check tool and log clearly if missing. Returns True if available."""
        if self.available(tool_name):
            return True
        tool = self._tools.get(tool_name)
        if tool:
            logger.warning(
                "capability_disabled",
                tool=tool_name,
                feature=feature,
                install_cmd=tool.install_cmd,
                msg=f"Feature '{feature}' disabled — install {tool_name}: {tool.install_cmd}"
            )
        return False


# Global singleton
tool_manager = ToolManager()
