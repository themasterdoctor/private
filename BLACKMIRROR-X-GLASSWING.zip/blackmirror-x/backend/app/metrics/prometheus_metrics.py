"""Prometheus metrics and observability for BLACKMIRROR-X."""
from __future__ import annotations

import time
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

try:
    from prometheus_client import (
        Counter, Histogram, Gauge, Info,
        generate_latest, CONTENT_TYPE_LATEST, CollectorRegistry
    )
    PROMETHEUS_AVAILABLE = True
    registry = CollectorRegistry()

    # ── Counters ──────────────────────────────────────────────────────────────
    scans_total = Counter(
        "bmx_scans_total", "Total scans launched",
        ["workspace_id", "scan_type", "status"],
        registry=registry
    )
    vulns_found_total = Counter(
        "bmx_vulnerabilities_found_total", "Total vulnerabilities found",
        ["workspace_id", "severity", "vuln_type"],
        registry=registry
    )
    agent_runs_total = Counter(
        "bmx_agent_runs_total", "Total agent runs",
        ["agent_type", "status"],
        registry=registry
    )
    payloads_attempted_total = Counter(
        "bmx_payloads_attempted_total", "Total payloads attempted",
        ["vuln_type", "waf_type", "success"],
        registry=registry
    )
    court_verdicts_total = Counter(
        "bmx_court_verdicts_total", "Total validation court verdicts",
        ["verdict", "severity"],
        registry=registry
    )
    monitoring_alerts_total = Counter(
        "bmx_monitoring_alerts_total", "Total monitoring alerts",
        ["alert_type", "severity"],
        registry=registry
    )

    # ── Histograms ────────────────────────────────────────────────────────────
    scan_duration_seconds = Histogram(
        "bmx_scan_duration_seconds", "Scan duration in seconds",
        ["scan_type"],
        buckets=[30, 60, 120, 300, 600, 1200, 3600],
        registry=registry
    )
    agent_duration_seconds = Histogram(
        "bmx_agent_duration_seconds", "Agent run duration",
        ["agent_type"],
        buckets=[1, 5, 15, 30, 60, 120, 300],
        registry=registry
    )
    hypothesis_confidence = Histogram(
        "bmx_hypothesis_confidence", "Hypothesis confidence distribution",
        ["vuln_class"],
        buckets=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
        registry=registry
    )

    # ── Gauges ────────────────────────────────────────────────────────────────
    active_scans = Gauge(
        "bmx_active_scans", "Currently running scans",
        registry=registry
    )
    active_monitors = Gauge(
        "bmx_active_monitors", "Active continuous monitoring targets",
        registry=registry
    )
    workspace_count = Gauge(
        "bmx_workspace_count", "Total workspaces",
        registry=registry
    )
    open_vulns_by_severity = Gauge(
        "bmx_open_vulnerabilities", "Open vulnerabilities by severity",
        ["severity"],
        registry=registry
    )

    # ── Info ──────────────────────────────────────────────────────────────────
    platform_info = Info(
        "bmx_platform", "BLACKMIRROR-X platform information",
        registry=registry
    )
    platform_info.info({
        "version": "2.0.0",
        "codename": "GLASSWING",
        "ai_model": "claude-sonnet-4",
    })

except ImportError:
    PROMETHEUS_AVAILABLE = False
    logger.warning("prometheus_not_available", msg="Install prometheus-client for metrics")


class MetricsCollector:
    """Centralized metrics collection helper."""

    @staticmethod
    def scan_started(workspace_id: str, scan_type: str) -> None:
        if not PROMETHEUS_AVAILABLE:
            return
        active_scans.inc()
        scans_total.labels(workspace_id=workspace_id, scan_type=scan_type, status="started").inc()

    @staticmethod
    def scan_completed(workspace_id: str, scan_type: str, duration: float, success: bool) -> None:
        if not PROMETHEUS_AVAILABLE:
            return
        active_scans.dec()
        status = "completed" if success else "failed"
        scans_total.labels(workspace_id=workspace_id, scan_type=scan_type, status=status).inc()
        scan_duration_seconds.labels(scan_type=scan_type).observe(duration)

    @staticmethod
    def vuln_found(workspace_id: str, severity: str, vuln_type: str) -> None:
        if not PROMETHEUS_AVAILABLE:
            return
        vulns_found_total.labels(
            workspace_id=workspace_id, severity=severity, vuln_type=vuln_type
        ).inc()

    @staticmethod
    def agent_completed(agent_type: str, duration: float, success: bool) -> None:
        if not PROMETHEUS_AVAILABLE:
            return
        status = "success" if success else "failed"
        agent_runs_total.labels(agent_type=agent_type, status=status).inc()
        agent_duration_seconds.labels(agent_type=agent_type).observe(duration)

    @staticmethod
    def payload_attempted(vuln_type: str, waf_type: str, success: bool) -> None:
        if not PROMETHEUS_AVAILABLE:
            return
        payloads_attempted_total.labels(
            vuln_type=vuln_type, waf_type=waf_type, success=str(success)
        ).inc()

    @staticmethod
    def court_verdict(verdict: str, severity: str) -> None:
        if not PROMETHEUS_AVAILABLE:
            return
        court_verdicts_total.labels(verdict=verdict, severity=severity).inc()

    @staticmethod
    def hypothesis_scored(vuln_class: str, confidence: float) -> None:
        if not PROMETHEUS_AVAILABLE:
            return
        hypothesis_confidence.labels(vuln_class=vuln_class).observe(confidence)

    @staticmethod
    def monitoring_alert(alert_type: str, severity: str) -> None:
        if not PROMETHEUS_AVAILABLE:
            return
        monitoring_alerts_total.labels(alert_type=alert_type, severity=severity).inc()

    @staticmethod
    def get_metrics_text() -> tuple[bytes, str]:
        if not PROMETHEUS_AVAILABLE:
            return b"# Prometheus not available\n", "text/plain"
        return generate_latest(registry), CONTENT_TYPE_LATEST


# Timing context manager
class timed:
    def __init__(self, metric_fn, **labels):
        self.metric_fn = metric_fn
        self.labels = labels
        self.start = 0.0

    def __enter__(self):
        self.start = time.time()
        return self

    def __exit__(self, *args):
        duration = time.time() - self.start
        self.metric_fn(duration=duration, **self.labels)
