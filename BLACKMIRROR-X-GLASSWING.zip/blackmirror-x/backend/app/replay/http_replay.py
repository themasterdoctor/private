"""HTTP Replay Engine and HAR Parser.

http_replay.py: raw HTTP request replay with mutation support
har_parser.py:  HAR file import/export
diff_engine.py: response comparison
timeline.py:    temporal reconstruction of request sequences

All work without browser — pure HTTP with httpx.
"""
from __future__ import annotations

import json
import hashlib
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
import structlog

logger = structlog.get_logger(__name__)

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False


# ── HTTP Replay ───────────────────────────────────────────────────────────────

@dataclass
class ReplayRequest:
    """A captured HTTP request ready for replay."""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    method: str = "GET"
    url: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    body: str = ""
    timestamp: float = field(default_factory=time.time)

    def to_curl(self) -> str:
        """Export as curl command."""
        parts = [f"curl -X {self.method}"]
        for k, v in self.headers.items():
            if k.lower() not in ("content-length",):
                parts.append(f"-H '{k}: {v}'")
        if self.body:
            escaped = self.body.replace("'", "\\'")
            parts.append(f"--data '{escaped}'")
        parts.append(f"'{self.url}'")
        return " \\\n  ".join(parts)

    def mutate(self, mutations: dict[str, str]) -> "ReplayRequest":
        """Create a mutated copy with parameter substitutions."""
        import copy
        r = copy.deepcopy(self)
        for k, v in mutations.items():
            r.url = r.url.replace(k, v)
            r.body = r.body.replace(k, v)
        return r

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "method": self.method,
            "url": self.url,
            "header_count": len(self.headers),
            "body_size": len(self.body),
            "timestamp": self.timestamp,
        }


@dataclass
class ReplayResponse:
    """Response from a replayed request."""
    request_id: str
    status: int
    headers: dict[str, str]
    body: str
    duration_ms: float
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "request_id": self.request_id,
            "status": self.status,
            "body_preview": self.body[:500],
            "body_hash": hashlib.md5(self.body.encode()).hexdigest(),
            "duration_ms": round(self.duration_ms, 2),
            "content_type": self.headers.get("content-type", ""),
            "error": self.error,
        }


async def replay_request(req: ReplayRequest, timeout: float = 10.0,
                          verify_ssl: bool = False) -> ReplayResponse:
    """Replay a single HTTP request."""
    if not HTTPX_AVAILABLE:
        return ReplayResponse(
            request_id=req.id, status=0,
            headers={}, body="",
            duration_ms=0, error="httpx not available",
        )

    start = time.monotonic()
    try:
        async with httpx.AsyncClient(timeout=timeout, verify=verify_ssl,
                                      follow_redirects=False) as client:
            resp = await client.request(
                req.method, req.url,
                headers=req.headers,
                content=req.body.encode() if req.body else None,
            )
            return ReplayResponse(
                request_id=req.id,
                status=resp.status_code,
                headers=dict(resp.headers),
                body=resp.text,
                duration_ms=(time.monotonic() - start) * 1000,
            )
    except Exception as e:
        return ReplayResponse(
            request_id=req.id, status=0, headers={}, body="",
            duration_ms=(time.monotonic() - start) * 1000,
            error=str(e),
        )


# ── HAR Parser ────────────────────────────────────────────────────────────────

def parse_har(har_data: dict) -> list[ReplayRequest]:
    """Parse a HAR file and return list of ReplayRequests."""
    requests = []
    entries = har_data.get("log", {}).get("entries", [])

    for entry in entries:
        req_data = entry.get("request", {})
        url = req_data.get("url", "")
        method = req_data.get("method", "GET")

        # Headers
        headers = {h["name"]: h["value"]
                  for h in req_data.get("headers", [])
                  if h["name"].lower() not in ("host", "content-length")}

        # Body
        body = ""
        post_data = req_data.get("postData", {})
        if post_data:
            body = post_data.get("text", "")

        # Timestamp
        started = entry.get("startedDateTime", "")
        try:
            from datetime import datetime
            ts = datetime.fromisoformat(started.replace("Z", "+00:00")).timestamp()
        except Exception:
            ts = time.time()

        requests.append(ReplayRequest(
            method=method, url=url, headers=headers,
            body=body, timestamp=ts,
        ))

    return requests


def export_har(requests: list[ReplayRequest],
               responses: list[ReplayResponse]) -> dict:
    """Export request/response pairs as a HAR dict."""
    entries = []
    resp_map = {r.request_id: r for r in responses}

    for req in requests:
        resp = resp_map.get(req.id)
        entry: dict[str, Any] = {
            "startedDateTime": datetime.fromtimestamp(req.timestamp, tz=timezone.utc).isoformat(),
            "time": resp.duration_ms if resp else 0,
            "request": {
                "method": req.method,
                "url": req.url,
                "httpVersion": "HTTP/1.1",
                "headers": [{"name": k, "value": v} for k, v in req.headers.items()],
                "queryString": [],
                "cookies": [],
                "headersSize": -1,
                "bodySize": len(req.body),
                "postData": {"mimeType": "application/json", "text": req.body}
                if req.body else None,
            },
        }
        if resp:
            entry["response"] = {
                "status": resp.status,
                "statusText": str(resp.status),
                "httpVersion": "HTTP/1.1",
                "headers": [{"name": k, "value": v} for k, v in resp.headers.items()],
                "cookies": [],
                "content": {"mimeType": resp.headers.get("content-type", "text/plain"),
                           "text": resp.body[:50000]},
                "redirectURL": "",
                "headersSize": -1,
                "bodySize": len(resp.body),
            }
        entries.append(entry)

    return {
        "log": {
            "version": "1.2",
            "creator": {"name": "BLACKMIRROR-X", "version": "2.0"},
            "entries": entries,
        }
    }


# ── Diff Engine ───────────────────────────────────────────────────────────────

@dataclass
class ResponseDiff:
    """Differences between two HTTP responses."""
    baseline_status: int
    test_status: int
    status_changed: bool
    body_changed: bool
    length_diff: int
    content_type_changed: bool
    new_fields: list[str] = field(default_factory=list)
    removed_fields: list[str] = field(default_factory=list)
    interesting: bool = False
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "baseline_status": self.baseline_status,
            "test_status": self.test_status,
            "status_changed": self.status_changed,
            "body_changed": self.body_changed,
            "length_diff": self.length_diff,
            "new_fields": self.new_fields,
            "removed_fields": self.removed_fields,
            "interesting": self.interesting,
            "notes": self.notes,
        }


def diff_responses(baseline: ReplayResponse, test: ReplayResponse) -> ResponseDiff:
    """Compare two responses and highlight security-relevant differences."""
    status_changed = baseline.status != test.status
    body_changed = baseline.body != test.body
    length_diff = len(test.body) - len(baseline.body)

    ct_base = baseline.headers.get("content-type", "")
    ct_test = test.headers.get("content-type", "")
    ct_changed = ct_base != ct_test

    new_fields: list[str] = []
    removed_fields: list[str] = []

    # Compare JSON response fields
    try:
        base_data = json.loads(baseline.body)
        test_data = json.loads(test.body)
        if isinstance(base_data, dict) and isinstance(test_data, dict):
            new_fields = [k for k in test_data if k not in base_data]
            removed_fields = [k for k in base_data if k not in test_data]
    except Exception:
        pass

    notes = []
    interesting = False

    # Security-relevant changes
    if status_changed and baseline.status in (401, 403) and test.status == 200:
        notes.append("⚠️ Auth bypass: 401/403 → 200")
        interesting = True
    if new_fields:
        sensitive = [f for f in new_fields if any(s in f.lower()
                    for s in ["password", "secret", "token", "key", "private"])]
        if sensitive:
            notes.append(f"⚠️ Sensitive fields appeared: {sensitive}")
            interesting = True
    if length_diff > 500:
        notes.append(f"Response grew by {length_diff} bytes — possible data disclosure")
        interesting = True
    if status_changed:
        notes.append(f"Status changed: {baseline.status} → {test.status}")

    return ResponseDiff(
        baseline_status=baseline.status,
        test_status=test.status,
        status_changed=status_changed,
        body_changed=body_changed,
        length_diff=length_diff,
        content_type_changed=ct_changed,
        new_fields=new_fields,
        removed_fields=removed_fields,
        interesting=interesting,
        notes=notes,
    )


# ── Timeline ──────────────────────────────────────────────────────────────────

def build_timeline(requests: list[ReplayRequest],
                   responses: list[ReplayResponse]) -> dict:
    """Reconstruct a temporal timeline of requests."""
    resp_map = {r.request_id: r for r in responses}
    events = []

    sorted_reqs = sorted(requests, key=lambda r: r.timestamp)
    for req in sorted_reqs:
        resp = resp_map.get(req.id)
        events.append({
            "ts": req.timestamp,
            "method": req.method,
            "url": req.url,
            "status": resp.status if resp else None,
            "duration_ms": resp.duration_ms if resp else None,
            "body_size": len(resp.body) if resp else 0,
        })

    if events:
        t0 = events[0]["ts"]
        for e in events:
            e["relative_ms"] = round((e["ts"] - t0) * 1000, 1)

    return {
        "event_count": len(events),
        "total_duration_ms": round((events[-1]["ts"] - events[0]["ts"]) * 1000, 1)
        if len(events) > 1 else 0,
        "events": events,
    }
