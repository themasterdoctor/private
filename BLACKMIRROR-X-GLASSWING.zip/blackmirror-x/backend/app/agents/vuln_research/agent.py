"""
BLACKMIRROR-X Vulnerability Research Agent
Safe, scoped vulnerability testing for authorized bug bounty / internal security testing.
Tests: XSS, SQLi, SSRF, SSTI, IDOR, CORS, Open Redirect, CRLF, GraphQL, Auth bypass, File upload
"""
import asyncio
import httpx
import re
import json
import urllib.parse
from typing import List, Dict, Any, Optional, Callable
import structlog

from app.core.config import settings
from app.models.models import Severity

logger = structlog.get_logger(__name__)

# ─── Payload Libraries ────────────────────────────────────────

XSS_PAYLOADS = [
    "<script>alert(1)</script>",
    "\"><script>alert(1)</script>",
    "javascript:alert(1)",
    "<img src=x onerror=alert(1)>",
    "<svg onload=alert(1)>",
    "';alert(1)//",
    "${7*7}",  # SSTI check too
    "{{7*7}}",
]

SQLI_PAYLOADS = [
    "'",
    "''",
    "' OR '1'='1",
    "' OR 1=1--",
    "\" OR 1=1--",
    "1' AND SLEEP(2)--",
    "1; SELECT SLEEP(2)--",
    "' UNION SELECT NULL--",
]

SSTI_PAYLOADS = [
    "{{7*7}}",
    "${7*7}",
    "<%= 7*7 %>",
    "{{config}}",
    "{% for i in range(1) %}{{7*7}}{% endfor %}",
    "#{ 7 * 7 }",
]

SSRF_PAYLOADS = [
    "http://169.254.169.254/latest/meta-data/",
    "http://169.254.169.254/",
    "http://metadata.google.internal/",
    "http://localhost/",
    "http://127.0.0.1/",
    "http://[::1]/",
    "http://0.0.0.0/",
    "file:///etc/passwd",
    "dict://localhost:6379/info",
]

OPEN_REDIRECT_PAYLOADS = [
    "//evil.com",
    "https://evil.com",
    "//evil.com/%2F..",
    "///evil.com",
    "/\\evil.com",
    "https:evil.com",
]

CRLF_PAYLOADS = [
    "%0d%0aSet-Cookie:bmx=1",
    "%0aSet-Cookie:bmx=1",
    "\r\nSet-Cookie:bmx=1",
    "%E5%98%8D%E5%98%8ASet-Cookie:bmx=1",
]

CORS_ORIGINS = [
    "https://evil.com",
    "null",
    "https://attacker.evil.com",
]


class VulnResearchAgent:
    def __init__(self, scan_id: str, workspace_id: str, log_fn: Optional[Callable] = None):
        self.scan_id = scan_id
        self.workspace_id = workspace_id
        self.log_fn = log_fn or self._noop
        self.client = httpx.AsyncClient(
            timeout=15.0,
            follow_redirects=False,
            verify=False,  # bug bounty targets often have self-signed certs
            headers={
                "User-Agent": "Mozilla/5.0 (compatible; SecurityResearcher/1.0; authorized-testing)",
            },
            limits=httpx.Limits(max_connections=10, max_keepalive_connections=5),
        )

    async def test_url(self, url: str, parameters: List[str], config: Dict) -> List[Dict]:
        """Run all enabled tests on a URL and its parameters."""
        findings = []

        tests = config.get("tests", ["xss", "sqli", "ssrf", "ssti", "cors", "open_redirect", "crlf"])

        if "xss" in tests:
            findings.extend(await self.test_xss(url, parameters))
        if "sqli" in tests:
            findings.extend(await self.test_sqli(url, parameters))
        if "ssrf" in tests:
            findings.extend(await self.test_ssrf(url, parameters))
        if "ssti" in tests:
            findings.extend(await self.test_ssti(url, parameters))
        if "cors" in tests:
            result = await self.test_cors(url)
            if result:
                findings.append(result)
        if "open_redirect" in tests:
            findings.extend(await self.test_open_redirect(url, parameters))
        if "crlf" in tests:
            findings.extend(await self.test_crlf(url, parameters))

        return findings

    async def test_xss(self, url: str, parameters: List[str]) -> List[Dict]:
        """Test for reflected XSS."""
        findings = []
        for param in parameters[:5]:  # rate limit
            for payload in XSS_PAYLOADS[:4]:  # limited payload set
                try:
                    test_url = self._inject_param(url, param, payload)
                    resp = await self.client.get(test_url)
                    if payload in resp.text or urllib.parse.quote(payload) in resp.text:
                        findings.append(self._finding(
                            "Reflected XSS",
                            "xss",
                            Severity.HIGH.value,
                            url, param, payload,
                            f"Payload reflected in response: {payload[:50]}",
                            request=f"GET {test_url}",
                            response=resp.text[:500],
                        ))
                        break
                except Exception:
                    pass
                await asyncio.sleep(0.1)  # rate limiting
        return findings

    async def test_sqli(self, url: str, parameters: List[str]) -> List[Dict]:
        """Test for SQL injection (error-based detection)."""
        findings = []
        sql_errors = [
            "SQL syntax", "mysql_fetch", "ORA-", "PostgreSQL",
            "sqlite3.OperationalError", "Microsoft OLE DB", "Unclosed quotation",
            "syntax error", "mysql_num_rows", "Warning: mysql",
        ]
        for param in parameters[:5]:
            for payload in SQLI_PAYLOADS[:3]:
                try:
                    test_url = self._inject_param(url, param, payload)
                    resp = await self.client.get(test_url)
                    for err in sql_errors:
                        if err.lower() in resp.text.lower():
                            findings.append(self._finding(
                                "SQL Injection (Error-Based)",
                                "sqli",
                                Severity.CRITICAL.value,
                                url, param, payload,
                                f"SQL error detected: {err}",
                                request=f"GET {test_url}",
                                response=resp.text[:500],
                            ))
                            break
                except Exception:
                    pass
                await asyncio.sleep(0.2)
        return findings

    async def test_ssrf(self, url: str, parameters: List[str]) -> List[Dict]:
        """Test for SSRF indicators."""
        findings = []
        ssrf_params = ["url", "uri", "link", "src", "source", "redirect", "path",
                       "file", "load", "fetch", "request", "callback", "next"]
        relevant_params = [p for p in parameters if p.lower() in ssrf_params]

        for param in relevant_params[:3]:
            for payload in SSRF_PAYLOADS[:3]:
                try:
                    test_url = self._inject_param(url, param, payload)
                    resp = await self.client.get(test_url)
                    # Indicators of SSRF
                    ssrf_indicators = ["ami-", "instance-id", "hostname", "root:x:", "metadata"]
                    for indicator in ssrf_indicators:
                        if indicator in resp.text.lower():
                            findings.append(self._finding(
                                "Server-Side Request Forgery (SSRF)",
                                "ssrf",
                                Severity.CRITICAL.value,
                                url, param, payload,
                                f"SSRF indicator in response: {indicator}",
                                request=f"GET {test_url}",
                                response=resp.text[:500],
                            ))
                except Exception:
                    pass
                await asyncio.sleep(0.3)
        return findings

    async def test_ssti(self, url: str, parameters: List[str]) -> List[Dict]:
        """Test for Server-Side Template Injection."""
        findings = []
        for param in parameters[:3]:
            for payload in SSTI_PAYLOADS[:3]:
                try:
                    test_url = self._inject_param(url, param, payload)
                    resp = await self.client.get(test_url)
                    if "49" in resp.text:  # 7*7=49
                        findings.append(self._finding(
                            "Server-Side Template Injection (SSTI)",
                            "ssti",
                            Severity.CRITICAL.value,
                            url, param, payload,
                            f"Expression 7*7=49 evaluated in response",
                            request=f"GET {test_url}",
                            response=resp.text[:500],
                        ))
                except Exception:
                    pass
                await asyncio.sleep(0.1)
        return findings

    async def test_cors(self, url: str) -> Optional[Dict]:
        """Test CORS misconfiguration."""
        for origin in CORS_ORIGINS:
            try:
                resp = await self.client.options(
                    url,
                    headers={"Origin": origin, "Access-Control-Request-Method": "GET"},
                )
                acao = resp.headers.get("Access-Control-Allow-Origin", "")
                acac = resp.headers.get("Access-Control-Allow-Credentials", "")
                if acao == origin or acao == "*":
                    if acac.lower() == "true" or acao == origin:
                        return self._finding(
                            "CORS Misconfiguration",
                            "cors",
                            Severity.HIGH.value if acac else Severity.MEDIUM.value,
                            url, "Origin header", origin,
                            f"ACAO: {acao}, ACAC: {acac}",
                        )
            except Exception:
                pass
        return None

    async def test_open_redirect(self, url: str, parameters: List[str]) -> List[Dict]:
        """Test for open redirects."""
        findings = []
        redirect_params = ["redirect", "next", "url", "return", "returnUrl", "goto",
                           "continue", "destination", "forward", "target", "redir"]
        relevant = [p for p in parameters if p.lower() in redirect_params]

        for param in relevant[:3]:
            for payload in OPEN_REDIRECT_PAYLOADS[:3]:
                try:
                    test_url = self._inject_param(url, param, payload)
                    resp = await self.client.get(test_url)
                    location = resp.headers.get("location", "")
                    if "evil.com" in location or location.startswith("//evil"):
                        findings.append(self._finding(
                            "Open Redirect",
                            "open_redirect",
                            Severity.MEDIUM.value,
                            url, param, payload,
                            f"Redirects to: {location}",
                        ))
                except Exception:
                    pass
                await asyncio.sleep(0.1)
        return findings

    async def test_crlf(self, url: str, parameters: List[str]) -> List[Dict]:
        """Test for CRLF injection."""
        findings = []
        for param in parameters[:3]:
            for payload in CRLF_PAYLOADS[:2]:
                try:
                    test_url = self._inject_param(url, param, payload)
                    resp = await self.client.get(test_url)
                    if "bmx=1" in str(resp.headers) or "Set-Cookie: bmx" in str(resp.headers):
                        findings.append(self._finding(
                            "CRLF Injection / Header Injection",
                            "crlf",
                            Severity.MEDIUM.value,
                            url, param, payload,
                            f"Injected header detected in response",
                        ))
                except Exception:
                    pass
                await asyncio.sleep(0.1)
        return findings

    # ─── Helpers ──────────────────────────────────────────────

    def _inject_param(self, url: str, param: str, value: str) -> str:
        parsed = urllib.parse.urlparse(url)
        qs = dict(urllib.parse.parse_qsl(parsed.query))
        qs[param] = value
        new_qs = urllib.parse.urlencode(qs)
        return parsed._replace(query=new_qs).geturl()

    def _finding(
        self, title: str, vuln_type: str, severity: str,
        url: str, parameter: str, payload: str,
        evidence: str, request: str = None, response: str = None,
    ) -> Dict:
        return {
            "title": title,
            "vuln_type": vuln_type,
            "severity": severity,
            "url": url,
            "parameter": parameter,
            "payload": payload,
            "evidence": evidence,
            "request": request,
            "response": response,
            "source": "vuln_agent",
        }

    async def _noop(self, **kwargs):
        pass

    async def close(self):
        await self.client.aclose()
