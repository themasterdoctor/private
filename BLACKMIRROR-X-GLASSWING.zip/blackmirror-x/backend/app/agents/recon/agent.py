"""
BLACKMIRROR-X Recon Agent
Orchestrates subfinder, amass, httpx, dnsx, naabu, katana, gau, hakrawler.
Logs to scan_logs and persists results to DB.
"""
import asyncio
import subprocess
import json
import os
from typing import Optional, List, Dict, Any, Callable
import structlog

from app.core.config import settings

logger = structlog.get_logger(__name__)


class ReconAgent:
    def __init__(self, scan_id: str, workspace_id: str, log_fn: Optional[Callable] = None):
        self.scan_id = scan_id
        self.workspace_id = workspace_id
        self.log_fn = log_fn or self._default_log
        self.artifacts_dir = os.path.join(settings.SCAN_ARTIFACTS_DIR, scan_id)
        os.makedirs(self.artifacts_dir, exist_ok=True)

    async def run_full_recon(self, domain: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """Full recon pipeline on a domain."""
        results = {
            "domain": domain,
            "subdomains": [],
            "live_hosts": [],
            "urls": [],
            "ports": {},
        }

        await self.log("info", "recon", f"Starting full recon on {domain}")

        # Phase 1: Subdomain enumeration
        subdomains = await self.enumerate_subdomains(domain, config)
        results["subdomains"] = subdomains
        await self.log("success", "recon", f"Found {len(subdomains)} subdomains", {"count": len(subdomains)})

        # Phase 2: HTTP probing
        live_hosts = await self.probe_http(subdomains, config)
        results["live_hosts"] = live_hosts
        await self.log("success", "httpx", f"Found {len(live_hosts)} live hosts", {"count": len(live_hosts)})

        # Phase 3: Port scanning (if enabled)
        if config.get("port_scan", True):
            ports = await self.scan_ports(live_hosts[:50], config)  # limit for safety
            results["ports"] = ports
            total_open = sum(len(v) for v in ports.values())
            await self.log("success", "naabu", f"Found {total_open} open ports")

        # Phase 4: URL discovery
        urls = await self.discover_urls(live_hosts[:30], config)
        results["urls"] = urls
        await self.log("success", "crawler", f"Discovered {len(urls)} URLs", {"count": len(urls)})

        return results

    async def enumerate_subdomains(self, domain: str, config: Dict) -> List[str]:
        """Run subfinder + amass + passive sources."""
        all_subs = set()

        # subfinder
        await self.log("info", "subfinder", f"Running subfinder on {domain}")
        subs = await self._run_subfinder(domain)
        all_subs.update(subs)
        await self.log("info", "subfinder", f"subfinder: {len(subs)} results")

        # DNS brute/verify with dnsx
        await self.log("info", "dnsx", f"Resolving {len(all_subs)} subdomains")
        resolved = await self._run_dnsx(list(all_subs))
        await self.log("info", "dnsx", f"dnsx: {len(resolved)} resolved")

        return list(resolved)

    async def probe_http(self, hosts: List[str], config: Dict) -> List[Dict]:
        """Run httpx on host list."""
        await self.log("info", "httpx", f"Probing {len(hosts)} hosts")
        return await self._run_httpx(hosts)

    async def scan_ports(self, hosts: List[str], config: Dict) -> Dict[str, List[int]]:
        """Run naabu port scanner."""
        await self.log("info", "naabu", f"Port scanning {len(hosts)} hosts")
        return await self._run_naabu(hosts)

    async def discover_urls(self, hosts: List[str], config: Dict) -> List[str]:
        """Run katana + gau + hakrawler for URL discovery."""
        all_urls = set()

        # katana (active crawler)
        await self.log("info", "katana", f"Crawling {len(hosts)} hosts")
        for host in hosts[:10]:  # limit active crawling
            urls = await self._run_katana(host)
            all_urls.update(urls)

        # gau (passive URL discovery)
        await self.log("info", "gau", "Running passive URL discovery (gau)")
        for host in hosts[:20]:
            # Extract domain from host for gau
            domain = host.replace("https://", "").replace("http://", "").split("/")[0]
            urls = await self._run_gau(domain)
            all_urls.update(urls)

        return list(all_urls)[:settings.MAX_URLS_PER_SCAN]

    # ─── Tool Runners ─────────────────────────────────────────

    async def _run_subfinder(self, domain: str) -> List[str]:
        out_file = os.path.join(self.artifacts_dir, "subfinder.txt")
        cmd = [
            settings.SUBFINDER_PATH, "-d", domain,
            "-o", out_file, "-silent", "-all", "-timeout", "30",
        ]
        await self._exec(cmd)
        return self._read_lines(out_file)

    async def _run_dnsx(self, hosts: List[str]) -> List[str]:
        if not hosts:
            return []
        input_file = os.path.join(self.artifacts_dir, "dnsx_input.txt")
        out_file = os.path.join(self.artifacts_dir, "dnsx.txt")
        with open(input_file, "w") as f:
            f.write("\n".join(hosts))
        cmd = [
            settings.DNSX_PATH, "-l", input_file,
            "-o", out_file, "-silent", "-a", "-resp",
        ]
        await self._exec(cmd)
        return self._read_lines(out_file)

    async def _run_httpx(self, hosts: List[str]) -> List[Dict]:
        if not hosts:
            return []
        input_file = os.path.join(self.artifacts_dir, "httpx_input.txt")
        out_file = os.path.join(self.artifacts_dir, "httpx.jsonl")
        with open(input_file, "w") as f:
            f.write("\n".join(hosts))
        cmd = [
            settings.HTTPX_PATH, "-l", input_file,
            "-o", out_file, "-json", "-title", "-tech-detect",
            "-status-code", "-content-length", "-timeout", "10",
        ]
        await self._exec(cmd)
        return self._read_jsonl(out_file)

    async def _run_naabu(self, hosts: List[str]) -> Dict[str, List[int]]:
        if not hosts:
            return {}
        input_file = os.path.join(self.artifacts_dir, "naabu_input.txt")
        out_file = os.path.join(self.artifacts_dir, "naabu.jsonl")
        with open(input_file, "w") as f:
            f.write("\n".join(hosts))
        cmd = [
            settings.NAABU_PATH, "-l", input_file,
            "-o", out_file, "-json", "-top-ports", "1000",
            "-timeout", "5", "-silent",
        ]
        await self._exec(cmd)
        lines = self._read_jsonl(out_file)
        result = {}
        for item in lines:
            host = item.get("host", "")
            port = item.get("port", 0)
            if host:
                result.setdefault(host, []).append(port)
        return result

    async def _run_katana(self, url: str) -> List[str]:
        out_file = os.path.join(self.artifacts_dir, f"katana_{hash(url)}.txt")
        cmd = [
            settings.KATANA_PATH, "-u", url,
            "-o", out_file, "-depth", "3", "-silent",
            "-timeout", "30", "-rate-limit", "50",
        ]
        await self._exec(cmd)
        return self._read_lines(out_file)

    async def _run_gau(self, domain: str) -> List[str]:
        out_file = os.path.join(self.artifacts_dir, f"gau_{domain}.txt")
        cmd = [settings.GAU_PATH, domain, "--o", out_file, "--timeout", "30"]
        await self._exec(cmd)
        return self._read_lines(out_file)

    # ─── Helpers ─────────────────────────────────────────────

    async def _exec(self, cmd: List[str], timeout: int = 120) -> tuple[str, str, int]:
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            return stdout.decode(), stderr.decode(), proc.returncode or 0
        except asyncio.TimeoutError:
            await self.log("warn", "recon", f"Command timed out: {cmd[0]}")
            return "", "", -1
        except FileNotFoundError:
            await self.log("warn", "recon", f"Tool not found: {cmd[0]} (mock mode)")
            return "", "", -1
        except Exception as e:
            await self.log("error", "recon", f"Error running {cmd[0]}: {e}")
            return "", "", -1

    def _read_lines(self, path: str) -> List[str]:
        if not os.path.exists(path):
            return []
        with open(path) as f:
            return [l.strip() for l in f if l.strip()]

    def _read_jsonl(self, path: str) -> List[Dict]:
        if not os.path.exists(path):
            return []
        results = []
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        results.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
        return results

    async def log(self, level: str, module: str, message: str, data: Dict = None):
        logger.info(message, scan_id=self.scan_id, module=module, level=level)
        if self.log_fn:
            await self.log_fn(level=level, module=module, message=message, data=data)

    async def _default_log(self, **kwargs):
        pass
