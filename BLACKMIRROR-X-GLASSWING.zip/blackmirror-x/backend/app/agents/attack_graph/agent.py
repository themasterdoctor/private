"""Attack Surface Graph Agent — builds and analyzes attack surface graph."""
from __future__ import annotations

import json
from collections import defaultdict
from typing import Any

import anthropic

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class AttackSurfaceGraphAgent:
    """Builds attack surface graph and identifies high-value attack paths."""

    def __init__(self):
        self.client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)

    def build_graph(
        self,
        target: str,
        subdomains: list[dict[str, Any]],
        urls: list[dict[str, Any]],
        vulns: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Build the attack surface graph data structure."""
        nodes: list[dict[str, Any]] = []
        edges: list[dict[str, Any]] = []
        node_ids: set[str] = set()

        def add_node(nid: str, label: str, ntype: str, **props: Any) -> None:
            if nid not in node_ids:
                node_ids.add(nid)
                nodes.append({"id": nid, "label": label, "type": ntype, **props})

        def add_edge(src: str, tgt: str, label: str = "", **props: Any) -> None:
            edges.append({"source": src, "target": tgt, "label": label, **props})

        # Root target node
        root_id = f"target:{target}"
        add_node(root_id, target, "target", target=target)

        # Subdomain nodes
        for sub in subdomains:
            sid = f"subdomain:{sub['subdomain']}"
            add_node(
                sid,
                sub["subdomain"],
                "subdomain",
                ip=sub.get("ip_address"),
                status=sub.get("status_code"),
                technologies=sub.get("technologies", []),
                ports=sub.get("ports", []),
            )
            add_edge(root_id, sid, "has_subdomain")

        # Service nodes from ports
        for sub in subdomains:
            sid = f"subdomain:{sub['subdomain']}"
            for port in sub.get("ports", []):
                service = self._port_to_service(port)
                svc_id = f"service:{sub['subdomain']}:{port}"
                add_node(svc_id, f"{service}:{port}", "service", port=port, service=service)
                add_edge(sid, svc_id, "exposes")

        # URL nodes (grouped by path pattern)
        path_groups: dict[str, list[str]] = defaultdict(list)
        for url_obj in urls:
            url = url_obj.get("url", "")
            try:
                from urllib.parse import urlparse
                parsed = urlparse(url)
                # Group by host + first path segment
                parts = parsed.path.split("/")
                group_key = f"{parsed.netloc}/{parts[1] if len(parts) > 1 else ''}"
                path_groups[group_key].append(url)
            except Exception:
                pass

        for group, group_urls in list(path_groups.items())[:50]:
            group_id = f"urlgroup:{group}"
            # Find matching subdomain
            host = group.split("/")[0]
            parent = f"subdomain:{host}" if f"subdomain:{host}" in node_ids else root_id
            add_node(group_id, f"/{group.split('/', 1)[1] if '/' in group else group}", "url_group", url_count=len(group_urls))
            add_edge(parent, group_id, "has_paths")

        # Vulnerability nodes
        sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        for vuln in sorted(vulns, key=lambda v: sev_order.get(v.get("severity", "info"), 4)):
            vid = f"vuln:{vuln['id']}"
            add_node(
                vid,
                vuln.get("vuln_type", "unknown"),
                "vuln",
                severity=vuln.get("severity"),
                title=vuln.get("title"),
                url=vuln.get("url"),
                cvss=vuln.get("cvss_score"),
            )
            # Connect to subdomain
            try:
                from urllib.parse import urlparse
                host = urlparse(vuln.get("url", "")).netloc
                parent = f"subdomain:{host}" if f"subdomain:{host}" in node_ids else root_id
            except Exception:
                parent = root_id
            add_edge(parent, vid, "vulnerable_to", severity=vuln.get("severity"))

            # Connect critical/high vulns to related vulns (potential chains)
            if vuln.get("severity") in ("critical", "high"):
                for other in vulns:
                    if other["id"] != vuln["id"] and other.get("severity") in ("critical", "high"):
                        other_vid = f"vuln:{other['id']}"
                        if other_vid in node_ids:
                            # Check if they share the same endpoint
                            if vuln.get("url", "").split("?")[0] == other.get("url", "").split("?")[0]:
                                add_edge(vid, other_vid, "chain_candidate", weight=0.8)

        # Identify attack chains
        chains = self._identify_attack_chains(nodes, edges, vulns)

        return {
            "nodes": nodes,
            "edges": edges,
            "stats": {
                "total_nodes": len(nodes),
                "total_edges": len(edges),
                "subdomain_count": len([n for n in nodes if n["type"] == "subdomain"]),
                "vuln_count": len([n for n in nodes if n["type"] == "vuln"]),
                "service_count": len([n for n in nodes if n["type"] == "service"]),
            },
            "attack_chains": chains,
        }

    def _identify_attack_chains(
        self,
        nodes: list[dict[str, Any]],
        edges: list[dict[str, Any]],
        vulns: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Identify potential attack chains from the graph."""
        chains = []

        criticals = [v for v in vulns if v.get("severity") == "critical"]
        highs = [v for v in vulns if v.get("severity") == "high"]

        # Pattern 1: XSS + CSRF → Account Takeover
        xss_vulns = [v for v in vulns if "xss" in v.get("vuln_type", "").lower()]
        if xss_vulns:
            chains.append({
                "name": "XSS → Session Hijacking",
                "steps": ["Stored/Reflected XSS", "Steal session cookie", "Account takeover"],
                "severity": "critical" if any(v.get("severity") == "critical" for v in xss_vulns) else "high",
                "vuln_ids": [v["id"] for v in xss_vulns[:3]],
            })

        # Pattern 2: SSRF → RCE via cloud metadata
        ssrf_vulns = [v for v in vulns if "ssrf" in v.get("vuln_type", "").lower()]
        if ssrf_vulns:
            chains.append({
                "name": "SSRF → Cloud Metadata → Credential Theft",
                "steps": ["SSRF to 169.254.169.254", "Extract IAM credentials", "Cloud privilege escalation"],
                "severity": "critical",
                "vuln_ids": [v["id"] for v in ssrf_vulns[:2]],
            })

        # Pattern 3: SQLi → Data Exfiltration
        sqli_vulns = [v for v in vulns if "sql" in v.get("vuln_type", "").lower()]
        if sqli_vulns:
            chains.append({
                "name": "SQLi → Full Database Dump",
                "steps": ["SQL injection", "Union-based extraction", "Dump user table", "Crack password hashes"],
                "severity": "critical",
                "vuln_ids": [v["id"] for v in sqli_vulns[:2]],
            })

        # Pattern 4: Auth bypass → IDOR
        auth_vulns = [v for v in vulns if "auth" in v.get("vuln_type", "").lower()]
        idor_vulns = [v for v in vulns if "idor" in v.get("vuln_type", "").lower()]
        if auth_vulns and idor_vulns:
            chains.append({
                "name": "Auth Bypass + IDOR → Horizontal Privilege Escalation",
                "steps": ["Bypass authentication", "Access any user account via IDOR", "Data exfiltration"],
                "severity": "critical",
                "vuln_ids": [v["id"] for v in (auth_vulns + idor_vulns)[:3]],
            })

        return chains

    async def analyze_with_ai(self, graph: dict[str, Any], target: str) -> str:
        """Use Claude to analyze the attack graph and provide strategic recommendations."""
        stats = graph["stats"]
        chains = graph["attack_chains"]

        node_types = {}
        for node in graph["nodes"]:
            t = node["type"]
            node_types[t] = node_types.get(t, 0) + 1

        high_value = [
            n for n in graph["nodes"]
            if n.get("type") == "vuln" and n.get("severity") in ("critical", "high")
        ]

        prompt = f"""Analyze this attack surface graph for {target}:

Graph Statistics:
- Total nodes: {stats['total_nodes']}
- Subdomains: {stats['subdomain_count']}
- Vulnerabilities: {stats['vuln_count']}
- Services: {stats['service_count']}

High-Value Vulnerabilities:
{json.dumps([{'type': n.get('vuln_type', n.get('label')), 'severity': n.get('severity'), 'url': n.get('url', '')} for n in high_value[:10]], indent=2)}

Identified Attack Chains:
{json.dumps(chains, indent=2)}

Provide:
1. Overall attack surface severity assessment
2. Most critical attack path (step-by-step)
3. Quick wins (easiest exploits)
4. Long-term persistent access strategy
5. Recommended report sections for bug bounty"""

        resp = await self.client.messages.create(
            model=settings.AI_MODEL,
            max_tokens=1000,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.content[0].text

    def _port_to_service(self, port: int) -> str:
        services = {
            21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
            80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS", 445: "SMB",
            3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL", 5900: "VNC",
            6379: "Redis", 8080: "HTTP-Alt", 8443: "HTTPS-Alt", 27017: "MongoDB",
        }
        return services.get(port, f"port-{port}")
