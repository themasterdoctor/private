"""
BLACKMIRROR-X JavaScript Intelligence Agent
Crawls JS files, extracts endpoints, detects secrets, analyzes source maps,
checks JWT issues, GraphQL, and DOM XSS sources/sinks.
"""
import re
import json
import asyncio
import httpx
from typing import List, Dict, Any, Optional, Set
import structlog

logger = structlog.get_logger(__name__)

# ─── Regex Patterns ──────────────────────────────────────────

ENDPOINT_PATTERNS = [
    r'(?:fetch|axios|http\.get|http\.post|\.get|\.post|\.put|\.delete|\.patch)\s*\(\s*["\`]([^"` ]+)["\`]',
    r'(?:url|endpoint|api|path|route)\s*[:=]\s*["\`]([/][^"` ]+)["\`]',
    r'["\`](/(?:api|v\d+|graphql|rest|internal|admin)[^"` \n]+)["\`]',
    r'(?:baseURL|BASE_URL|API_URL|apiUrl)\s*=\s*["\`]([^"` ]+)["\`]',
]

SECRET_PATTERNS = {
    "AWS Access Key": r'AKIA[0-9A-Z]{16}',
    "AWS Secret Key": r'(?:aws_secret|AWS_SECRET)[_\s]*(?:access_key|key)[_\s]*=\s*["\']([^"\']{40})["\']',
    "GitHub Token": r'ghp_[a-zA-Z0-9]{36}',
    "Slack Token": r'xox[baprs]-[0-9a-zA-Z-]{10,}',
    "Google API Key": r'AIza[0-9A-Za-z\-_]{35}',
    "Stripe Secret": r'sk_live_[0-9a-zA-Z]{24,}',
    "Stripe Publishable": r'pk_live_[0-9a-zA-Z]{24,}',
    "Private Key": r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
    "JWT Token": r'eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}',
    "Firebase URL": r'[a-z0-9-]+\.firebaseio\.com',
    "S3 Bucket": r's3\.amazonaws\.com/[a-z0-9._-]+',
    "SendGrid API": r'SG\.[a-zA-Z0-9]{22}\.[a-zA-Z0-9]{43}',
    "Twilio SID": r'AC[a-z0-9]{32}',
    "Password in Code": r'(?:password|passwd|pwd|secret)\s*=\s*["\'][^"\']{6,}["\']',
    "Internal IP": r'(?:192\.168\.|10\.\d+\.|172\.(?:1[6-9]|2[0-9]|3[01])\.)\d+\.\d+',
    "Bearer Token": r'["\']Bearer\s+[a-zA-Z0-9_.+=/-]{20,}["\']',
}

DOM_XSS_SOURCES = [
    "document.URL", "document.documentURI", "document.URLUnencoded",
    "document.baseURI", "document.cookie", "document.referrer",
    "location.href", "location.search", "location.hash",
    "window.name", "history.state",
]

DOM_XSS_SINKS = [
    "innerHTML", "outerHTML", "document.write", "document.writeln",
    "eval(", "setTimeout(", "setInterval(", "execScript",
    "window.location", "location.href", "location.replace",
    "$.html(", ".html(", "insertAdjacentHTML",
]

GRAPHQL_INDICATORS = [
    r'query\s*{', r'mutation\s*{', r'subscription\s*{',
    r'__schema', r'__type', r'gql`',
    r'GraphQLClient', r'ApolloClient', r'urql',
]

JWT_WEAK_ALGOS = ["HS256", "none", "HS1"]


class JSIntelAgent:
    def __init__(self, scan_id: str):
        self.scan_id = scan_id
        self.client = httpx.AsyncClient(
            timeout=20.0, verify=False,
            headers={"User-Agent": "Mozilla/5.0 (compatible; SecurityResearcher/1.0)"},
        )
        self.analyzed_urls: Set[str] = set()

    async def analyze_target(self, base_url: str, js_urls: List[str]) -> Dict[str, Any]:
        """Full JS intelligence analysis on discovered JS files."""
        results = {
            "endpoints": set(),
            "secrets": [],
            "dom_xss_sources": [],
            "dom_xss_sinks": [],
            "graphql_detected": False,
            "graphql_endpoints": [],
            "jwt_issues": [],
            "source_maps": [],
            "interesting_files": [],
        }

        for url in js_urls[:50]:  # limit
            if url in self.analyzed_urls:
                continue
            self.analyzed_urls.add(url)

            try:
                content = await self.fetch_js(url)
                if not content:
                    continue

                # Extract endpoints
                endpoints = self.extract_endpoints(content)
                results["endpoints"].update(endpoints)

                # Find secrets
                secrets = self.detect_secrets(content, url)
                results["secrets"].extend(secrets)

                # DOM XSS analysis
                sources, sinks = self.analyze_dom_xss(content, url)
                results["dom_xss_sources"].extend(sources)
                results["dom_xss_sinks"].extend(sinks)

                # GraphQL
                if self.detect_graphql(content):
                    results["graphql_detected"] = True
                    gql_endpoints = self.extract_graphql_endpoints(content)
                    results["graphql_endpoints"].extend(gql_endpoints)

                # JWT
                jwt_issues = self.analyze_jwt_usage(content, url)
                results["jwt_issues"].extend(jwt_issues)

                # Source map check
                source_map = await self.check_source_map(url, content)
                if source_map:
                    results["source_maps"].append(source_map)

            except Exception as e:
                logger.debug("js_analysis_error", url=url, error=str(e))
            
            await asyncio.sleep(0.05)

        results["endpoints"] = list(results["endpoints"])
        return results

    async def fetch_js(self, url: str) -> Optional[str]:
        try:
            resp = await self.client.get(url)
            if resp.status_code == 200 and len(resp.content) < 5_000_000:  # 5MB limit
                return resp.text
        except Exception:
            pass
        return None

    def extract_endpoints(self, content: str) -> List[str]:
        endpoints = set()
        for pattern in ENDPOINT_PATTERNS:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for match in matches:
                if len(match) > 3 and not match.startswith("//"):
                    endpoints.add(match)
        return list(endpoints)[:200]

    def detect_secrets(self, content: str, url: str) -> List[Dict]:
        findings = []
        for secret_type, pattern in SECRET_PATTERNS.items():
            matches = re.findall(pattern, content)
            for match in matches:
                # Avoid false positives from common patterns
                if match in ("PASSWORD", "password", "YOUR_KEY", "YOUR_SECRET"):
                    continue
                findings.append({
                    "type": secret_type,
                    "value": match[:50] + "..." if len(match) > 50 else match,
                    "url": url,
                    "severity": "critical" if "Key" in secret_type or "Secret" in secret_type else "high",
                })
        return findings

    def analyze_dom_xss(self, content: str, url: str) -> tuple[List[Dict], List[Dict]]:
        sources_found = []
        sinks_found = []

        for source in DOM_XSS_SOURCES:
            if source in content:
                # Check if source feeds into a sink
                sources_found.append({
                    "source": source,
                    "url": url,
                    "context": self._get_context(content, source),
                })

        for sink in DOM_XSS_SINKS:
            if sink in content:
                sinks_found.append({
                    "sink": sink,
                    "url": url,
                    "context": self._get_context(content, sink),
                })

        return sources_found, sinks_found

    def detect_graphql(self, content: str) -> bool:
        for pattern in GRAPHQL_INDICATORS:
            if re.search(pattern, content, re.IGNORECASE):
                return True
        return False

    def extract_graphql_endpoints(self, content: str) -> List[str]:
        patterns = [
            r'["\`](/graphql[^"` ]*)["\`]',
            r'["\`](https?://[^"` ]+/graphql[^"` ]*)["\`]',
            r'uri:\s*["\`]([^"` ]+)["\`]',
        ]
        endpoints = set()
        for pattern in patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            endpoints.update(matches)
        return list(endpoints)

    def analyze_jwt_usage(self, content: str, url: str) -> List[Dict]:
        issues = []

        # Check for weak algorithm configuration
        for algo in JWT_WEAK_ALGOS:
            if f'algorithm: "{algo}"' in content or f"algorithm: '{algo}'" in content:
                issues.append({
                    "type": "Weak JWT Algorithm",
                    "detail": f"JWT configured with algorithm: {algo}",
                    "url": url,
                    "severity": "high",
                })

        # Check for JWT stored in localStorage
        if "localStorage.setItem" in content and "token" in content.lower():
            issues.append({
                "type": "JWT in localStorage",
                "detail": "JWT token stored in localStorage (XSS risk)",
                "url": url,
                "severity": "medium",
            })

        # Check for hardcoded secret
        jwt_secret_patterns = [
            r'jwt\.sign\([^,]+,\s*["\']([^"\']{8,})["\']',
            r'secret:\s*["\']([^"\']{8,})["\']',
        ]
        for pattern in jwt_secret_patterns:
            matches = re.findall(pattern, content)
            for match in matches:
                issues.append({
                    "type": "Hardcoded JWT Secret",
                    "detail": f"JWT secret appears hardcoded: {match[:20]}...",
                    "url": url,
                    "severity": "critical",
                })

        return issues

    async def check_source_map(self, js_url: str, content: str) -> Optional[Dict]:
        """Check if source map exists and is accessible."""
        # Look for source map comment
        sm_match = re.search(r'//# sourceMappingURL=(.+)$', content, re.MULTILINE)
        if not sm_match:
            return None

        sm_url = sm_match.group(1).strip()
        if not sm_url.startswith("http"):
            base = js_url.rsplit("/", 1)[0]
            sm_url = f"{base}/{sm_url}"

        try:
            resp = await self.client.get(sm_url)
            if resp.status_code == 200 and "sources" in resp.text:
                data = json.loads(resp.text)
                return {
                    "js_url": js_url,
                    "map_url": sm_url,
                    "sources": data.get("sources", [])[:20],
                    "severity": "medium",
                    "detail": f"Source map exposed with {len(data.get('sources', []))} source files",
                }
        except Exception:
            pass
        return None

    def _get_context(self, content: str, term: str, context_chars: int = 100) -> str:
        idx = content.find(term)
        if idx == -1:
            return ""
        start = max(0, idx - context_chars)
        end = min(len(content), idx + len(term) + context_chars)
        return content[start:end].replace("\n", " ")[:200]

    async def close(self):
        await self.client.aclose()
