"""
BLACKMIRROR-X Copilot Agent
A conversational AI security analyst — asks clarifying questions,
recommends attack paths, explains findings, drafts reports.
"""
from typing import AsyncGenerator, Optional, Dict, Any, List
import anthropic
import structlog

from app.core.config import settings

logger = structlog.get_logger(__name__)

SYSTEM_PROMPT = """You are GLASSWING, an elite AI security analyst and red team copilot for the BLACKMIRROR-X platform.

You have deep expertise in:
- Web application security (OWASP Top 10, beyond)
- Bug bounty hunting and vulnerability research
- Recon methodology (subdomain enumeration, JS analysis, attack surface mapping)
- Exploit development and proof-of-concept creation
- Security report writing (HackerOne, Bugcrowd, YesWeHack style)
- CVE analysis and triage
- CVSS scoring and CWE classification

Your personality:
- Direct, precise, and technically rigorous
- Think like a senior pentester / bug bounty hunter
- Provide actionable, specific guidance
- Reference real CVEs, techniques, and tooling
- Help triage vulnerabilities and prioritize attack paths

When given context about a scan, target, or vulnerability:
- Analyze it thoroughly
- Suggest specific next steps and payloads
- Identify patterns and potential attack chains
- Draft professional security reports when asked

Always remind users that testing should only be done on authorized targets.
Never provide guidance for unauthorized access.

Format your responses with:
- Clear sections using markdown
- Code blocks for payloads, commands, and PoCs
- Severity indicators when discussing vulnerabilities
- Actionable bullet points for next steps
"""


class CopilotAgent:
    def __init__(self):
        self.client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
        self.model = settings.AI_MODEL

    async def stream(
        self,
        message: str,
        history: List[Dict[str, str]],
        context: Dict[str, Any],
        workspace_id: str,
    ) -> AsyncGenerator[str, None]:
        """Stream response chunks."""

        # Build context injection
        context_text = self._build_context(context)

        messages = []
        for h in history:
            messages.append({"role": h["role"], "content": h["content"]})

        # Add context to user message if present
        user_content = message
        if context_text:
            user_content = f"[CONTEXT]\n{context_text}\n\n[USER MESSAGE]\n{message}"

        messages.append({"role": "user", "content": user_content})

        try:
            async with self.client.messages.stream(
                model=self.model,
                max_tokens=settings.AI_MAX_TOKENS,
                system=SYSTEM_PROMPT,
                messages=messages,
            ) as stream:
                async for text in stream.text_stream:
                    yield text
        except Exception as e:
            logger.error("copilot_agent_error", error=str(e))
            yield f"\n\n⚠️ Agent error: {str(e)}"

    def _build_context(self, context: Dict[str, Any]) -> str:
        if not context:
            return ""

        parts = []

        if context.get("scan_id"):
            parts.append(f"Active Scan ID: {context['scan_id']}")
        if context.get("target"):
            parts.append(f"Target: {context['target']}")
        if context.get("vulnerability"):
            v = context["vulnerability"]
            parts.append(f"Vulnerability: {v.get('title')} ({v.get('severity', 'unknown')} severity)")
            if v.get("url"):
                parts.append(f"Affected URL: {v['url']}")
            if v.get("type"):
                parts.append(f"Type: {v['type']}")
        if context.get("subdomains_count"):
            parts.append(f"Discovered Subdomains: {context['subdomains_count']}")
        if context.get("vulns_count"):
            parts.append(f"Total Vulnerabilities: {context['vulns_count']}")

        return "\n".join(parts) if parts else ""

    async def analyze_vulnerability(self, vuln_data: Dict[str, Any]) -> Dict[str, Any]:
        """One-shot vulnerability analysis."""
        prompt = f"""Analyze this vulnerability and provide:
1. Severity assessment and CVSS score rationale
2. Exploitability analysis
3. Business impact
4. Specific remediation steps
5. Similar CVEs or known exploitation patterns

Vulnerability Details:
- Title: {vuln_data.get('title')}
- Type: {vuln_data.get('vuln_type')}
- URL: {vuln_data.get('url')}
- Parameter: {vuln_data.get('parameter')}
- Payload: {vuln_data.get('payload')}
- Evidence: {vuln_data.get('evidence')}

Respond in JSON with keys: cvss_score, exploitability, business_impact, remediation, similar_cves, triage_notes
"""
        response = await self.client.messages.create(
            model=self.model,
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}],
        )
        import json
        try:
            text = response.content[0].text
            # Strip markdown fences
            text = text.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
            return json.loads(text)
        except Exception:
            return {"triage_notes": response.content[0].text}
