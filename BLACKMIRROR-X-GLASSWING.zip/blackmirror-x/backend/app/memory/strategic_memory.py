"""Strategic Memory — long-term workspace and program intelligence.

Persists:
- Program rules (scope, out-of-scope, bounty table)
- Accepted/rejected finding patterns
- Target technology fingerprints
- Endpoint behavior history
- Payload performance (which payloads worked on which tech)

Works fully in-memory. Optionally persists to DB when available.
"""
from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
import structlog

logger = structlog.get_logger(__name__)


# ── Program Profile ───────────────────────────────────────────────────────────

@dataclass
class ProgramProfile:
    """Bug bounty program rules and scope."""
    program_name: str = ""
    platform: str = ""       # hackerone, bugcrowd, intigriti
    in_scope: list[str] = field(default_factory=list)
    out_of_scope: list[str] = field(default_factory=list)
    bounty_table: dict[str, str] = field(default_factory=dict)  # severity -> amount
    safe_harbor: bool = True
    notes: str = ""
    last_updated: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def is_in_scope(self, domain: str) -> bool:
        import re
        for rule in self.out_of_scope:
            if re.search(rule.replace("*", ".*"), domain):
                return False
        for rule in self.in_scope:
            if re.search(rule.replace("*", ".*"), domain):
                return True
        return not bool(self.in_scope)  # no rules = open scope

    def estimated_bounty(self, severity: str) -> str:
        return self.bounty_table.get(severity.lower(), "Unknown")

    def to_dict(self) -> dict:
        return {
            "program_name": self.program_name,
            "platform": self.platform,
            "in_scope_count": len(self.in_scope),
            "out_of_scope_count": len(self.out_of_scope),
            "bounty_table": self.bounty_table,
            "safe_harbor": self.safe_harbor,
        }


# ── Feedback Loop ─────────────────────────────────────────────────────────────

@dataclass
class FindingFeedback:
    """Feedback on a submitted/reviewed finding."""
    finding_id: str
    vuln_type: str
    severity: str
    outcome: str    # "accepted" | "rejected" | "duplicate" | "informative"
    reason: str = ""
    actual_severity: str = ""  # if triager downgraded
    bounty_paid: str = ""
    tech_stack: list[str] = field(default_factory=list)
    submitted_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


# ── Strategic Memory ──────────────────────────────────────────────────────────

class StrategicMemory:
    """Long-term intelligence about a workspace and its targets.

    Persisted in-memory per process.
    Production: serialize to DB or JSON file.
    """

    def __init__(self, workspace_id: str):
        self.workspace_id = workspace_id
        self.program = ProgramProfile()
        self._feedback: list[FindingFeedback] = []
        self._tech_memory: dict[str, list[str]] = defaultdict(list)
        # domain -> [tech_stack items]
        self._endpoint_behavior: dict[str, dict] = {}
        # url -> {status_history, param_types, last_seen}
        self._payload_performance: dict[str, dict[str, dict]] = defaultdict(dict)
        # vuln_type -> {tech_name -> {payload: hit_rate}}

    # ── Program Rules ─────────────────────────────────────────────────────────
    def set_program(self, profile: ProgramProfile) -> None:
        self.program = profile
        logger.info("program_profile_updated", name=profile.program_name,
                   workspace=self.workspace_id)

    def is_in_scope(self, domain: str) -> bool:
        return self.program.is_in_scope(domain)

    # ── Feedback Loop ──────────────────────────────────────────────────────────
    def record_feedback(self, feedback: FindingFeedback) -> None:
        self._feedback.append(feedback)
        # Update payload performance based on accepted findings
        if feedback.outcome == "accepted":
            for tech in feedback.tech_stack:
                self._payload_performance[feedback.vuln_type].setdefault(tech, {})
                # Mark this vuln type as effective on this tech
                self._payload_performance[feedback.vuln_type][tech]["success_count"] = \
                    self._payload_performance[feedback.vuln_type][tech].get("success_count", 0) + 1
        logger.info("feedback_recorded",
                   outcome=feedback.outcome, vuln_type=feedback.vuln_type,
                   workspace=self.workspace_id)

    def get_rejection_patterns(self) -> list[dict]:
        """What types of findings get rejected — avoid wasting time on these."""
        rejected = [f for f in self._feedback if f.outcome in ("rejected", "informative")]
        patterns: dict[str, int] = defaultdict(int)
        reasons: dict[str, list[str]] = defaultdict(list)
        for f in rejected:
            patterns[f.vuln_type] += 1
            if f.reason:
                reasons[f.vuln_type].append(f.reason)
        return [
            {"vuln_type": vt, "rejection_count": cnt,
             "common_reasons": list(set(reasons[vt]))[:3]}
            for vt, cnt in sorted(patterns.items(), key=lambda x: -x[1])
        ]

    def get_accepted_patterns(self) -> list[dict]:
        accepted = [f for f in self._feedback if f.outcome == "accepted"]
        patterns: dict[str, int] = defaultdict(int)
        bounties: dict[str, list[str]] = defaultdict(list)
        for f in accepted:
            patterns[f.vuln_type] += 1
            if f.bounty_paid:
                bounties[f.vuln_type].append(f.bounty_paid)
        return [
            {"vuln_type": vt, "accepted_count": cnt,
             "bounties": bounties[vt][:5]}
            for vt, cnt in sorted(patterns.items(), key=lambda x: -x[1])
        ]

    # ── Tech Memory ────────────────────────────────────────────────────────────
    def record_technology(self, domain: str, tech_stack: list[str]) -> None:
        for tech in tech_stack:
            if tech not in self._tech_memory[domain]:
                self._tech_memory[domain].append(tech)

    def get_known_technologies(self, domain: str) -> list[str]:
        return self._tech_memory.get(domain, [])

    def get_effective_payloads(self, vuln_type: str,
                                tech: str) -> list[str]:
        """Return payload types known to work on a specific technology."""
        perf = self._payload_performance.get(vuln_type, {}).get(tech, {})
        if not perf:
            return []
        return [k for k, v in perf.items() if isinstance(v, dict)
                and v.get("success_count", 0) > 0]

    # ── Endpoint Behavior ──────────────────────────────────────────────────────
    def record_endpoint(self, url: str, status: int,
                        params: list[str] | None = None) -> None:
        if url not in self._endpoint_behavior:
            self._endpoint_behavior[url] = {
                "status_history": [], "params": params or [], "hit_count": 0,
            }
        self._endpoint_behavior[url]["status_history"].append(status)
        self._endpoint_behavior[url]["hit_count"] += 1
        if params:
            for p in params:
                if p not in self._endpoint_behavior[url]["params"]:
                    self._endpoint_behavior[url]["params"].append(p)

    def get_endpoint_anomalies(self) -> list[dict]:
        """Find endpoints with variable status codes (access control anomalies)."""
        anomalies = []
        for url, data in self._endpoint_behavior.items():
            statuses = set(data["status_history"])
            if len(statuses) > 1 and (200 in statuses) and (403 in statuses or 401 in statuses):
                anomalies.append({
                    "url": url,
                    "observed_statuses": list(statuses),
                    "note": "Status varies — potential race condition or flaky auth",
                })
        return anomalies

    def to_summary(self) -> dict:
        return {
            "workspace_id": self.workspace_id,
            "program": self.program.to_dict(),
            "feedback_count": len(self._feedback),
            "accepted": len([f for f in self._feedback if f.outcome == "accepted"]),
            "rejected": len([f for f in self._feedback if f.outcome == "rejected"]),
            "known_domains": list(self._tech_memory.keys()),
            "endpoint_count": len(self._endpoint_behavior),
            "rejection_patterns": self.get_rejection_patterns()[:5],
            "accepted_patterns": self.get_accepted_patterns()[:5],
        }


# Registry of workspace memories
_registry: dict[str, StrategicMemory] = {}


def get_memory(workspace_id: str) -> StrategicMemory:
    if workspace_id not in _registry:
        _registry[workspace_id] = StrategicMemory(workspace_id)
    return _registry[workspace_id]
