"""Advanced Report Generation System.

Generates:
- HackerOne-ready markdown reports
- YesWeHack-ready reports
- Executive summary reports
- Developer remediation reports
- Attack chain narrative reports
- Evidence appendices
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

import anthropic

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class ReportSection:
    title: str
    content: str
    order: int = 0


SEVERITY_CVSS = {
    "critical": "9.0–10.0",
    "high": "7.0–8.9",
    "medium": "4.0–6.9",
    "low": "0.1–3.9",
    "info": "0.0",
}

SEVERITY_BOUNTY_H1 = {
    "critical": "$3,000–$25,000",
    "high": "$1,000–$5,000",
    "medium": "$250–$1,500",
    "low": "$100–$500",
    "info": "N/A",
}


class AdvancedReportGenerator:
    """Generates professional vulnerability reports for multiple platforms."""

    def __init__(self):
        self.client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)

    async def generate_hackerone_report(self, vuln: dict[str, Any]) -> str:
        """Generate a HackerOne-ready markdown report."""
        prompt = f"""Generate a professional HackerOne vulnerability report.

Vulnerability data:
{json.dumps(vuln, indent=2, default=str)[:2000]}

Format EXACTLY as:
## Summary
[2-3 sentence summary of the vulnerability and its impact]

## Vulnerability Details
**Type:** [vuln type]
**Severity:** [severity]
**CVSS Score:** [score] ([vector])
**CWE:** [CWE-ID]
**Affected URL:** [url]

## Steps to Reproduce
1. [Step 1]
2. [Step 2]
3. [Step n]

## Proof of Concept
```
[Request/payload]
```

## Impact
[Concrete impact on users, data, business]

## Recommended Fix
[Specific remediation steps]

## References
- [OWASP reference]
- [CWE reference]

Keep it factual, professional, and evidence-driven. Max 600 words."""

        try:
            resp = await self.client.messages.create(
                model=settings.AI_MODEL,
                max_tokens=800,
                messages=[{"role": "user", "content": prompt}],
            )
            return resp.content[0].text
        except Exception as e:
            logger.error("report_gen_failed", error=str(e))
            return self._fallback_h1_report(vuln)

    def _fallback_h1_report(self, vuln: dict[str, Any]) -> str:
        """Fallback HackerOne report template."""
        severity = vuln.get("severity", "medium")
        return f"""## Summary
A {severity} severity {vuln.get('vuln_type', 'vulnerability')} was discovered at `{vuln.get('url', '[URL]')}`.

## Vulnerability Details
**Type:** {vuln.get('vuln_type', 'Unknown')}
**Severity:** {severity.capitalize()}
**CVSS Score:** {SEVERITY_CVSS.get(severity, 'N/A')}
**Affected URL:** {vuln.get('url', '[URL]')}
**Parameter:** {vuln.get('parameter', '[param]')}

## Steps to Reproduce
{vuln.get('reproduction_steps', '1. Navigate to the affected URL\n2. Submit the payload\n3. Observe the response')}

## Proof of Concept
```
{vuln.get('payload', '[payload]')}
```

## Impact
{vuln.get('description', '[Impact description]')}

## Recommended Fix
{vuln.get('remediation', 'Apply appropriate input validation and output encoding.')}

## References
- https://owasp.org/www-community/attacks/
- https://cwe.mitre.org/data/definitions/{vuln.get('cwe_id', '0')}.html
"""

    async def generate_executive_report(
        self, scan: dict[str, Any], vulns: list[dict[str, Any]], chains: list[dict[str, Any]]
    ) -> str:
        """Generate an executive summary report."""
        crit = sum(1 for v in vulns if v.get("severity") == "critical")
        high = sum(1 for v in vulns if v.get("severity") == "high")
        med = sum(1 for v in vulns if v.get("severity") == "medium")
        low = sum(1 for v in vulns if v.get("severity") == "low")

        prompt = f"""Write an executive security assessment report.

Target: {scan.get('target', 'unknown')}
Scan Date: {scan.get('created_at', 'unknown')}
Findings: {crit} Critical, {high} High, {med} Medium, {low} Low

Top critical findings:
{json.dumps(vulns[:3], indent=2, default=str)[:1000]}

Most critical attack chain:
{json.dumps(chains[:1], indent=2, default=str)[:500] if chains else 'None identified'}

Format:
# Executive Security Assessment

## Risk Summary
[3 sentence business risk overview]

## Key Findings
[Bullet points: severity count, top risks]

## Most Critical Risk
[1 paragraph on the worst finding]

## Attack Scenario
[1 paragraph on the most realistic attack path]

## Immediate Actions Required
[3-5 bullet points, prioritized]

## Risk Score: [1-10]/10

Write for a CISO, not a developer. No technical jargon. Focus on business impact."""

        try:
            resp = await self.client.messages.create(
                model=settings.AI_MODEL,
                max_tokens=700,
                messages=[{"role": "user", "content": prompt}],
            )
            return resp.content[0].text
        except Exception:
            return self._fallback_executive_report(scan, crit, high, med, low)

    def _fallback_executive_report(
        self, scan: dict[str, Any], crit: int, high: int, med: int, low: int
    ) -> str:
        total = crit + high + med + low
        risk = 10 if crit > 0 else 7 if high > 0 else 5
        return f"""# Executive Security Assessment

**Target:** {scan.get('target', 'Unknown')}
**Assessment Date:** {scan.get('created_at', 'Unknown')}

## Risk Summary
The security assessment of {scan.get('target', 'the target')} identified {total} vulnerabilities
requiring immediate attention. {'Critical vulnerabilities were found that could enable full account compromise.' if crit > 0 else 'High severity vulnerabilities were found that require prompt remediation.'}

## Key Findings
- **{crit} Critical** vulnerabilities identified
- **{high} High** severity issues
- **{med} Medium** severity issues
- **{low} Low** severity issues

## Immediate Actions Required
1. Remediate all critical vulnerabilities immediately
2. Apply WAF rules for high-severity findings
3. Conduct developer training on secure coding
4. Schedule follow-up penetration test in 30 days

## Risk Score: {risk}/10
"""

    async def generate_developer_report(self, vuln: dict[str, Any]) -> str:
        """Generate a developer-focused remediation report."""
        prompt = f"""Generate a developer remediation guide for this vulnerability.

{json.dumps(vuln, indent=2, default=str)[:1500]}

Format:
## Vulnerability: {vuln.get('title', 'Unknown')}

### Root Cause
[Technical root cause explanation]

### Fix (Code Example)
```[language]
// VULNERABLE:
[vulnerable code pattern]

// FIXED:
[secure code pattern]
```

### Testing the Fix
[How to verify the fix is correct]

### Additional Defense
[Defense-in-depth measures: CSP, WAF rules, etc.]

Keep it practical and code-focused."""

        try:
            resp = await self.client.messages.create(
                model=settings.AI_MODEL,
                max_tokens=600,
                messages=[{"role": "user", "content": prompt}],
            )
            return resp.content[0].text
        except Exception:
            return f"## Vulnerability: {vuln.get('title', 'Unknown')}\n\n**Fix:** {vuln.get('remediation', 'Apply appropriate security controls.')}"

    async def generate_chain_report(self, chains: list[dict[str, Any]]) -> str:
        """Generate an attack chain narrative report."""
        if not chains:
            return "# Attack Chain Analysis\n\nNo complete attack chains identified."

        top_chain = chains[0]
        prompt = f"""Write an attack chain report for a bug bounty submission.

Chain: {top_chain.get('title', 'Unknown')}
Probability: {top_chain.get('probability', 0):.0%}
Impact: {top_chain.get('impact', 'high')}
Narrative: {top_chain.get('narrative', '')}

Format:
# Attack Chain Report: {top_chain.get('title', 'Unknown')}

## Executive Summary
[2 sentences]

## Chain Overview
[Visual chain: Step 1 → Step 2 → Step 3]

## Step-by-Step Analysis
[For each step: what it enables, evidence quality, confidence]

## Combined Impact
[What the full chain achieves]

## Estimated Bounty
{top_chain.get('bounty', 'Unknown')}

Professional tone. For bug bounty submission."""

        try:
            resp = await self.client.messages.create(
                model=settings.AI_MODEL,
                max_tokens=600,
                messages=[{"role": "user", "content": prompt}],
            )
            return resp.content[0].text
        except Exception:
            return f"# Attack Chain Report\n\n## {top_chain.get('title', 'Unknown')}\n\nProbability: {top_chain.get('probability', 0):.0%}\nImpact: {top_chain.get('impact', 'high')}\n"
