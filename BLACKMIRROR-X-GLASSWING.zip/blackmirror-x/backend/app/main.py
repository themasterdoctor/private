"""
BLACKMIRROR-X GLASSWING
AI-Powered Cybersecurity Platform
"""
from contextlib import asynccontextmanager
import structlog
from fastapi import FastAPI
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.core.logging import setup_logging
from app.db.session import create_tables
from app.api.routes import (
    auth, workspaces, scans, recon, vulns,
    reports, copilot, agents, apikeys, websocket, intelligence,
    orchestrator, demo
)
from app.api.routes.phase10 import (
    browser_router, api_intel_router, chains_router,
    replay_router, memory_router, workers_router
)
from app.api.middleware.rate_limit import RateLimitMiddleware
from app.api.middleware.audit import AuditLogMiddleware
from app.core.cors import BroadCORSMiddleware

setup_logging()
logger = structlog.get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 BLACKMIRROR-X starting up", version="1.0.0")
    await create_tables()
    logger.info("✅ Database tables ready")
    yield
    logger.info("🛑 BLACKMIRROR-X shutting down")


app = FastAPI(
    title="BLACKMIRROR-X GLASSWING API",
    description="AI-Powered Cybersecurity Platform — Recon, Vulns, Agents, Reports",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)

# ─── Middleware ───────────────────────────────────────────────
# BroadCORSMiddleware must be FIRST (outermost) so it adds CORS headers
# to ALL responses including 401/403/422/500 errors.
# FastAPI's built-in CORSMiddleware does NOT add headers to error responses.
app.add_middleware(BroadCORSMiddleware, allowed_origins=settings.CORS_ORIGINS)
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(RateLimitMiddleware)
app.add_middleware(AuditLogMiddleware)

# ─── Routers ─────────────────────────────────────────────────
PREFIX = "/api/v1"

app.include_router(auth.router,       prefix=f"{PREFIX}/auth",       tags=["Auth"])
app.include_router(workspaces.router, prefix=f"{PREFIX}/workspaces",  tags=["Workspaces"])
app.include_router(scans.router,      prefix=f"{PREFIX}/scans",       tags=["Scans"])
app.include_router(recon.router,      prefix=f"{PREFIX}/recon",       tags=["Recon"])
app.include_router(vulns.router,      prefix=f"{PREFIX}/vulns",       tags=["Vulnerabilities"])
app.include_router(reports.router,    prefix=f"{PREFIX}/reports",     tags=["Reports"])
app.include_router(copilot.router,    prefix=f"{PREFIX}/copilot",     tags=["AI Copilot"])
app.include_router(agents.router,     prefix=f"{PREFIX}/agents",      tags=["Agents"])
app.include_router(apikeys.router,    prefix=f"{PREFIX}/apikeys",     tags=["API Keys"])
app.include_router(websocket.router,  prefix="/ws",                   tags=["WebSocket"])
app.include_router(intelligence.router, prefix=f"{PREFIX}/intel",       tags=["Intelligence"])

app.include_router(orchestrator.router, prefix=f"{PREFIX}/orchestrator", tags=["Orchestrator"])
app.include_router(browser_router,    prefix=f"{PREFIX}/browser-intel", tags=["Browser Intel"])
app.include_router(api_intel_router,  prefix=f"{PREFIX}/api-intel",     tags=["API Intel"])
app.include_router(chains_router,     prefix=f"{PREFIX}/chains",         tags=["Attack Chains"])
app.include_router(replay_router,     prefix=f"{PREFIX}/replay",          tags=["Replay Lab"])
app.include_router(memory_router,     prefix=f"{PREFIX}/memory",          tags=["Strategic Memory"])
app.include_router(workers_router,    prefix=f"{PREFIX}/workers",          tags=["Workers"])
app.include_router(demo.router,        prefix=f"{PREFIX}/demo",             tags=["Demo Mode"])

# Tool status
@app.get("/api/v1/tools", tags=["Tools"])
async def get_tools():
    from app.core.tool_manager import tool_manager
    return tool_manager.get_status()


@app.get("/", include_in_schema=False)
async def root():
    return JSONResponse({"name": "BLACKMIRROR-X GLASSWING", "version": "1.0.0", "status": "online"})


@app.get("/health", include_in_schema=False)
async def health():
    return JSONResponse({"status": "healthy"})
