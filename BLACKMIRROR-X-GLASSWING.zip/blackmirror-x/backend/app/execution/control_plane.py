"""Execution Control Plane — distributed scan execution controls.

Provides:
- Scan checkpointing (crash recovery)
- Retry policy with backoff
- Worker heartbeat monitoring
- Scan pause/resume/emergency-stop
- Task leasing (prevent double-execution in distributed setup)

All data stored in Redis when available; falls back to in-memory.
"""
from __future__ import annotations

import asyncio
import json
import math
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
import structlog

logger = structlog.get_logger(__name__)

try:
    import aioredis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False


# ── Checkpoints ───────────────────────────────────────────────────────────────

@dataclass
class ScanCheckpoint:
    """Scan state snapshot for crash recovery."""
    scan_id: str
    checkpoint_id: str = field(default_factory=lambda: str(uuid.uuid4())[:12])
    phase: str = ""
    progress: int = 0
    completed_task_ids: list[str] = field(default_factory=list)
    partial_results: dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict:
        return {
            "scan_id": self.scan_id,
            "checkpoint_id": self.checkpoint_id,
            "phase": self.phase,
            "progress": self.progress,
            "completed_tasks": len(self.completed_task_ids),
            "created_at": self.created_at,
        }


class CheckpointStore:
    """Stores scan checkpoints. In-memory with optional Redis backend."""

    def __init__(self):
        self._store: dict[str, list[ScanCheckpoint]] = {}

    def save(self, checkpoint: ScanCheckpoint) -> None:
        sid = checkpoint.scan_id
        if sid not in self._store:
            self._store[sid] = []
        self._store[sid].append(checkpoint)
        # Keep last 5 per scan
        self._store[sid] = self._store[sid][-5:]
        logger.debug("checkpoint_saved", scan_id=sid,
                    phase=checkpoint.phase, progress=checkpoint.progress)

    def load_latest(self, scan_id: str) -> ScanCheckpoint | None:
        checkpoints = self._store.get(scan_id, [])
        return checkpoints[-1] if checkpoints else None

    def clear(self, scan_id: str) -> None:
        self._store.pop(scan_id, None)


checkpoint_store = CheckpointStore()


# ── Retry Policy ──────────────────────────────────────────────────────────────

@dataclass
class RetryPolicy:
    """Exponential backoff retry policy for failed tasks."""
    max_retries: int = 3
    base_delay_s: float = 1.0
    max_delay_s: float = 60.0
    jitter: bool = True

    def should_retry(self, attempt: int) -> bool:
        return attempt < self.max_retries

    def delay_for(self, attempt: int) -> float:
        """Exponential backoff: base * 2^attempt, capped at max."""
        delay = min(self.base_delay_s * math.pow(2, attempt), self.max_delay_s)
        if self.jitter:
            import random
            delay *= (0.5 + random.random() * 0.5)
        return delay


_DEFAULT_RETRY = RetryPolicy()
_AGGRESSIVE_RETRY = RetryPolicy(max_retries=5, base_delay_s=0.5)
_CONSERVATIVE_RETRY = RetryPolicy(max_retries=2, base_delay_s=5.0)


def get_retry_policy(risk_tier: str) -> RetryPolicy:
    return {
        "passive": _AGGRESSIVE_RETRY,
        "low": _AGGRESSIVE_RETRY,
        "medium": _DEFAULT_RETRY,
        "high": _CONSERVATIVE_RETRY,
        "critical": RetryPolicy(max_retries=1),
    }.get(risk_tier, _DEFAULT_RETRY)


# ── Worker Heartbeat ──────────────────────────────────────────────────────────

@dataclass
class WorkerHeartbeat:
    """Worker process health record."""
    worker_id: str
    hostname: str = ""
    current_scan_id: str = ""
    current_task: str = ""
    tasks_completed: int = 0
    tasks_failed: int = 0
    last_seen: float = field(default_factory=time.time)
    started_at: float = field(default_factory=time.time)

    @property
    def is_alive(self) -> bool:
        return (time.time() - self.last_seen) < 30  # 30s timeout

    @property
    def uptime_seconds(self) -> float:
        return time.time() - self.started_at

    def to_dict(self) -> dict:
        return {
            "worker_id": self.worker_id,
            "hostname": self.hostname,
            "is_alive": self.is_alive,
            "current_scan_id": self.current_scan_id,
            "current_task": self.current_task,
            "tasks_completed": self.tasks_completed,
            "tasks_failed": self.tasks_failed,
            "last_seen_ago_s": round(time.time() - self.last_seen, 1),
            "uptime_s": round(self.uptime_seconds, 0),
        }


class HeartbeatMonitor:
    """Tracks worker health via periodic heartbeats."""

    def __init__(self, timeout_s: float = 30.0):
        self._workers: dict[str, WorkerHeartbeat] = {}
        self._timeout = timeout_s

    def register(self, worker_id: str, hostname: str = "") -> WorkerHeartbeat:
        hb = WorkerHeartbeat(worker_id=worker_id, hostname=hostname)
        self._workers[worker_id] = hb
        return hb

    def beat(self, worker_id: str,
             current_scan: str = "", current_task: str = "") -> None:
        if worker_id not in self._workers:
            self._workers[worker_id] = WorkerHeartbeat(worker_id=worker_id)
        w = self._workers[worker_id]
        w.last_seen = time.time()
        if current_scan:
            w.current_scan_id = current_scan
        if current_task:
            w.current_task = current_task

    def get_dead_workers(self) -> list[WorkerHeartbeat]:
        return [w for w in self._workers.values() if not w.is_alive]

    def get_alive_workers(self) -> list[WorkerHeartbeat]:
        return [w for w in self._workers.values() if w.is_alive]

    def get_all(self) -> list[dict]:
        return [w.to_dict() for w in self._workers.values()]

    def deregister(self, worker_id: str) -> None:
        self._workers.pop(worker_id, None)


heartbeat_monitor = HeartbeatMonitor()


# ── Control Plane ─────────────────────────────────────────────────────────────

class ControlPlane:
    """Central control plane for scan execution management.

    Handles: pause, resume, emergency stop, priority adjustment, scan status.
    """

    def __init__(self):
        self._paused_scans: set[str] = set()
        self._stopped_scans: set[str] = set()
        self._global_stop: bool = False
        self._scan_priorities: dict[str, int] = {}   # scan_id -> priority (1=high)
        self._audit_log: list[dict] = []

    def _audit(self, action: str, scan_id: str | None = None, **kwargs) -> None:
        self._audit_log.append({
            "action": action, "scan_id": scan_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            **kwargs,
        })

    def pause_scan(self, scan_id: str) -> None:
        self._paused_scans.add(scan_id)
        self._audit("pause_scan", scan_id)
        logger.info("scan_paused", scan_id=scan_id)

    def resume_scan(self, scan_id: str) -> None:
        self._paused_scans.discard(scan_id)
        self._stopped_scans.discard(scan_id)
        self._audit("resume_scan", scan_id)
        logger.info("scan_resumed", scan_id=scan_id)

    def stop_scan(self, scan_id: str) -> None:
        self._stopped_scans.add(scan_id)
        self._paused_scans.discard(scan_id)
        self._audit("stop_scan", scan_id)
        logger.warning("scan_stopped", scan_id=scan_id)

    def emergency_stop_all(self) -> None:
        self._global_stop = True
        self._audit("emergency_stop_all")
        logger.critical("emergency_stop_all_activated")

    def resume_all(self) -> None:
        self._global_stop = False
        self._paused_scans.clear()
        self._stopped_scans.clear()
        self._audit("resume_all")

    def is_paused(self, scan_id: str) -> bool:
        return scan_id in self._paused_scans or self._global_stop

    def is_stopped(self, scan_id: str) -> bool:
        return scan_id in self._stopped_scans or self._global_stop

    def set_priority(self, scan_id: str, priority: int) -> None:
        self._scan_priorities[scan_id] = max(1, min(10, priority))
        self._audit("set_priority", scan_id, priority=priority)

    def get_status(self) -> dict:
        return {
            "global_stop": self._global_stop,
            "paused_scans": list(self._paused_scans),
            "stopped_scans": list(self._stopped_scans),
            "priorities": self._scan_priorities,
            "alive_workers": len(heartbeat_monitor.get_alive_workers()),
            "dead_workers": len(heartbeat_monitor.get_dead_workers()),
            "recent_actions": self._audit_log[-10:],
        }


control_plane = ControlPlane()
