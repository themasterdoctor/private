"""WebSocket Capture — intercepts WebSocket messages during browser sessions.

Captures WebSocket frames for security analysis:
- Authentication tokens in WS handshakes
- Sensitive data in messages
- Missing input validation
- IDOR through object IDs in messages

Requires Playwright. Returns empty capture when unavailable.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
import structlog

logger = structlog.get_logger(__name__)

PLAYWRIGHT_AVAILABLE = False
try:
    from playwright.async_api import async_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    pass


@dataclass
class WSFrame:
    """A single WebSocket frame."""
    direction: str        # "send" | "recv"
    payload: str
    timestamp: float = field(default_factory=time.time)
    is_binary: bool = False

    def to_dict(self) -> dict:
        return {
            "direction": self.direction,
            "payload": self.payload[:500],  # truncate large payloads
            "timestamp": self.timestamp,
            "is_binary": self.is_binary,
            "size": len(self.payload),
        }


@dataclass
class WSCapture:
    """Captured WebSocket session."""
    url: str
    frames: list[WSFrame] = field(default_factory=list)
    handshake_headers: dict[str, str] = field(default_factory=dict)
    findings: list[dict] = field(default_factory=list)
    captured_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict:
        return {
            "url": self.url,
            "frame_count": len(self.frames),
            "frames": [f.to_dict() for f in self.frames[:50]],
            "handshake_headers": self.handshake_headers,
            "findings": self.findings,
            "captured_at": self.captured_at,
        }


def _analyze_frames(frames: list[WSFrame]) -> list[dict]:
    """Look for security issues in captured frames."""
    findings = []
    seen_ids: set[str] = set()

    for frame in frames:
        payload = frame.payload

        # Try to parse as JSON for deeper analysis
        try:
            data = json.loads(payload)
        except (json.JSONDecodeError, Exception):
            data = None

        # Auth token in message
        import re
        if re.search(r'["\']?(token|auth|bearer|jwt|session)["\']?\s*[:=]\s*["\'][A-Za-z0-9._-]{20,}',
                     payload, re.IGNORECASE):
            findings.append({
                "type": "auth_token_in_ws",
                "severity": "medium",
                "description": "Authentication token found in WebSocket message",
                "evidence": payload[:200],
            })

        # Object IDs — potential IDOR
        if data and isinstance(data, dict):
            for k, v in data.items():
                if k.lower().endswith(("_id", "id", "user", "account")):
                    id_str = str(v)
                    if id_str in seen_ids and len(id_str) > 4:
                        findings.append({
                            "type": "repeated_object_id",
                            "severity": "low",
                            "description": f"Object ID '{k}={v}' repeated across messages (IDOR candidate)",
                        })
                    seen_ids.add(id_str)

    return findings


async def capture_websockets(page_url: str,
                              interact_js: str | None = None,
                              duration_ms: int = 5000,
                              cookies: list[dict] | None = None) -> list[WSCapture]:
    """Navigate to a page and capture all WebSocket traffic.

    Returns empty list if Playwright unavailable.
    """
    if not PLAYWRIGHT_AVAILABLE:
        logger.warning("ws_capture_no_playwright")
        return []

    captures: dict[str, WSCapture] = {}
    frames_by_url: dict[str, list[WSFrame]] = {}

    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True, args=["--no-sandbox"])
            ctx = await browser.new_context()
            if cookies:
                await ctx.add_cookies(cookies)

            page = await ctx.new_page()

            # Register WebSocket listeners
            page.on("websocket", lambda ws: _on_ws(ws, frames_by_url))

            await page.goto(page_url, timeout=15000)
            await page.wait_for_load_state("networkidle", timeout=5000)

            # Run optional JS to trigger WS connections
            if interact_js:
                try:
                    await page.evaluate(interact_js)
                except Exception:
                    pass

            import asyncio
            await asyncio.sleep(duration_ms / 1000.0)

            await page.close()
            await ctx.close()
            await browser.close()

    except Exception as e:
        logger.warning("ws_capture_error", error=str(e))

    # Convert to WSCapture objects
    result = []
    for url, frames in frames_by_url.items():
        cap = WSCapture(
            url=url,
            frames=frames,
            findings=_analyze_frames(frames),
        )
        result.append(cap)

    return result


def _on_ws(ws: Any, store: dict[str, list[WSFrame]]) -> None:
    """Register frame listeners on a new WebSocket."""
    url = ws.url
    if url not in store:
        store[url] = []

    ws.on("framesent", lambda f: store[url].append(
        WSFrame(direction="send", payload=f.payload or "",
                is_binary=f.binary)
    ))
    ws.on("framereceived", lambda f: store[url].append(
        WSFrame(direction="recv", payload=f.payload or "",
                is_binary=f.binary)
    ))
