"""DOM Monitor — tracks DOM mutations and form discovery during browser sessions.

Discovers:
- Forms and their fields (XSS/injection entry points)
- Dynamic content injection
- Hidden fields that appear post-auth
- Client-side template injection sinks
- DOM clobbering opportunities

Requires Playwright. Returns empty results when unavailable.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any
import structlog

logger = structlog.get_logger(__name__)

PLAYWRIGHT_AVAILABLE = False
try:
    from playwright.async_api import async_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    pass


@dataclass
class DiscoveredForm:
    """A form found in the DOM."""
    action: str
    method: str
    fields: list[dict]   # name, type, value, id
    page_url: str
    has_csrf_token: bool = False
    is_hidden: bool = False

    def to_dict(self) -> dict:
        return {
            "action": self.action,
            "method": self.method,
            "field_count": len(self.fields),
            "fields": self.fields,
            "page_url": self.page_url,
            "has_csrf_token": self.has_csrf_token,
            "is_hidden": self.is_hidden,
        }


@dataclass
class DOMSnapshot:
    """A snapshot of DOM state at a point in time."""
    url: str
    title: str
    forms: list[DiscoveredForm] = field(default_factory=list)
    input_count: int = 0
    link_count: int = 0
    script_count: int = 0
    inline_event_handlers: list[str] = field(default_factory=list)   # onclick, onload etc.
    dom_xss_sinks: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "url": self.url,
            "title": self.title,
            "form_count": len(self.forms),
            "forms": [f.to_dict() for f in self.forms],
            "input_count": self.input_count,
            "link_count": self.link_count,
            "script_count": self.script_count,
            "inline_event_handlers": self.inline_event_handlers[:20],
            "dom_xss_sinks": self.dom_xss_sinks[:20],
        }


_DOM_EXTRACTION_JS = """() => {
    const forms = Array.from(document.querySelectorAll('form')).map(f => ({
        action: f.action || window.location.pathname,
        method: f.method.toUpperCase() || 'GET',
        fields: Array.from(f.querySelectorAll('input,select,textarea')).map(el => ({
            name: el.name,
            type: el.type || 'text',
            value: el.value ? '***' : '',
            id: el.id,
            placeholder: el.placeholder,
        })),
        hasCsrf: !!f.querySelector('[name*=csrf],[name*=token],[name*=_token]'),
    }));

    const sinks = [];
    document.querySelectorAll('*').forEach(el => {
        ['onclick','onload','onerror','onmouseover','onfocus'].forEach(attr => {
            const val = el.getAttribute(attr);
            if (val) sinks.push({attr, val: val.substring(0,80)});
        });
    });

    return {
        title: document.title,
        forms,
        inputCount: document.querySelectorAll('input').length,
        linkCount: document.querySelectorAll('a[href]').length,
        scriptCount: document.querySelectorAll('script').length,
        inlineHandlers: sinks.map(s => `${s.attr}=${s.val}`),
    };
}"""


async def snapshot_dom(url: str, cookies: list[dict] | None = None,
                        headers: dict[str, str] | None = None) -> DOMSnapshot:
    """Capture a DOM snapshot of a page.

    Returns empty snapshot if Playwright unavailable.
    """
    if not PLAYWRIGHT_AVAILABLE:
        return DOMSnapshot(url=url, title="",
                          dom_xss_sinks=["playwright_unavailable"])

    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True, args=["--no-sandbox"])
            ctx = await browser.new_context(
                extra_http_headers=headers or {}
            )
            if cookies:
                await ctx.add_cookies(cookies)

            page = await ctx.new_page()
            await page.goto(url, timeout=15000)
            await page.wait_for_load_state("domcontentloaded", timeout=5000)

            data = await page.evaluate(_DOM_EXTRACTION_JS)

            # Find DOM XSS sinks in page source
            html = await page.content()
            xss_sinks = _find_dom_xss_sinks(html)

            forms = []
            for f in data.get("forms", []):
                forms.append(DiscoveredForm(
                    action=f["action"],
                    method=f["method"],
                    fields=f["fields"],
                    page_url=url,
                    has_csrf_token=f.get("hasCsrf", False),
                ))

            snapshot = DOMSnapshot(
                url=url,
                title=data.get("title", ""),
                forms=forms,
                input_count=data.get("inputCount", 0),
                link_count=data.get("linkCount", 0),
                script_count=data.get("scriptCount", 0),
                inline_event_handlers=data.get("inlineHandlers", []),
                dom_xss_sinks=xss_sinks,
            )

            await page.close()
            await ctx.close()
            await browser.close()
            return snapshot

    except Exception as e:
        logger.warning("dom_snapshot_error", error=str(e), url=url)
        return DOMSnapshot(url=url, title="", dom_xss_sinks=[f"error: {e}"])


def _find_dom_xss_sinks(html: str) -> list[str]:
    """Find dangerous DOM manipulation in HTML/inline JS."""
    sinks = []
    patterns = [
        r'innerHTML\s*=',
        r'outerHTML\s*=',
        r'document\.write\s*\(',
        r'eval\s*\(',
        r'setTimeout\s*\(',
        r'setInterval\s*\(',
        r'location\.href\s*=',
        r'location\.replace\s*\(',
        r'\.src\s*=.*location',
        r'insertAdjacentHTML\s*\(',
    ]
    for pat in patterns:
        for m in re.finditer(pat, html):
            ctx = html[max(0, m.start()-30):m.end()+50].strip()
            if ctx not in sinks:
                sinks.append(ctx)
    return sinks[:20]
