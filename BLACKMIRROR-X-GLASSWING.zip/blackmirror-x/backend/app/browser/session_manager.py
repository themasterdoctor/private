"""Browser Session Manager — authenticated Playwright sessions.

Manages authenticated browser contexts with:
- Cookie / header injection
- Session persistence and reuse
- localStorage / sessionStorage capture
- Multi-user role management for role diff

Requires: playwright install chromium
Gracefully disabled when Playwright is not available.
"""
from __future__ import annotations

import asyncio
import base64
import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

# Capability detection
PLAYWRIGHT_AVAILABLE = False
try:
    from playwright.async_api import async_playwright, Browser, BrowserContext, Page
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    logger.warning("playwright_unavailable",
                  fix="pip install playwright && playwright install chromium")


@dataclass
class BrowserSession:
    """An authenticated browser session."""
    session_id: str = field(default_factory=lambda: str(uuid.uuid4())[:12])
    label: str = ""
    cookies: list[dict] = field(default_factory=list)
    headers: dict[str, str] = field(default_factory=dict)
    local_storage: dict[str, dict] = field(default_factory=dict)   # origin -> {key: val}
    session_storage: dict[str, dict] = field(default_factory=dict)
    screenshots: list[str] = field(default_factory=list)           # base64 PNGs
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    user_agent: str = "Mozilla/5.0 (BLACKMIRROR-X Scanner)"
    viewport: dict = field(default_factory=lambda: {"width": 1280, "height": 720})

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "label": self.label,
            "cookie_count": len(self.cookies),
            "header_count": len(self.headers),
            "storage_origins": list(self.local_storage.keys()),
            "screenshot_count": len(self.screenshots),
            "created_at": self.created_at,
        }


class SessionManager:
    """Manages browser sessions for authenticated scanning.

    When Playwright is unavailable, all methods return empty results
    and log a capability warning.
    """

    def __init__(self):
        self._sessions: dict[str, BrowserSession] = {}
        self._playwright = None
        self._browser: Any = None

    async def start(self) -> bool:
        """Start Playwright browser. Returns False if unavailable."""
        if not PLAYWRIGHT_AVAILABLE:
            return False
        try:
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=True,
                args=["--no-sandbox", "--disable-dev-shm-usage"],
            )
            logger.info("browser_started")
            return True
        except Exception as e:
            logger.warning("browser_start_failed", error=str(e))
            return False

    async def stop(self) -> None:
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()

    async def create_session(
        self,
        label: str = "",
        cookies: list[dict] | None = None,
        headers: dict[str, str] | None = None,
        login_url: str | None = None,
        login_data: dict | None = None,
    ) -> BrowserSession:
        """Create a new session, optionally performing login."""
        session = BrowserSession(
            label=label,
            cookies=cookies or [],
            headers=headers or {},
        )

        if not PLAYWRIGHT_AVAILABLE or not self._browser:
            logger.warning("browser_session_no_playwright",
                          session_id=session.session_id)
            self._sessions[session.session_id] = session
            return session

        try:
            ctx = await self._browser.new_context(
                user_agent=session.user_agent,
                viewport=session.viewport,
                extra_http_headers=session.headers,
            )
            if session.cookies:
                await ctx.add_cookies(session.cookies)

            if login_url and login_data:
                page = await ctx.new_page()
                try:
                    await page.goto(login_url, timeout=15000)
                    for field_name, value in login_data.items():
                        locator = page.locator(f"[name={field_name}]")
                        if await locator.count():
                            await locator.fill(str(value))
                    await page.keyboard.press("Enter")
                    await page.wait_for_load_state("networkidle", timeout=10000)
                    # Capture post-login cookies
                    session.cookies = await ctx.cookies()
                finally:
                    await page.close()

            await ctx.close()
        except Exception as e:
            logger.warning("browser_session_create_error", error=str(e))

        self._sessions[session.session_id] = session
        return session

    async def capture_storage(self, session_id: str, url: str) -> dict[str, dict]:
        """Capture localStorage and sessionStorage at a URL."""
        session = self._sessions.get(session_id)
        if not session or not PLAYWRIGHT_AVAILABLE or not self._browser:
            return {}

        try:
            ctx = await self._browser.new_context(
                extra_http_headers=session.headers,
            )
            if session.cookies:
                await ctx.add_cookies(session.cookies)

            page = await ctx.new_page()
            await page.goto(url, timeout=15000)
            await page.wait_for_load_state("domcontentloaded", timeout=5000)

            local_storage = await page.evaluate("""() => {
                const s = {};
                for (let i = 0; i < localStorage.length; i++) {
                    const k = localStorage.key(i);
                    s[k] = localStorage.getItem(k);
                }
                return s;
            }""")

            session_storage = await page.evaluate("""() => {
                const s = {};
                for (let i = 0; i < sessionStorage.length; i++) {
                    const k = sessionStorage.key(i);
                    s[k] = sessionStorage.getItem(k);
                }
                return s;
            }""")

            from urllib.parse import urlparse
            origin = f"{urlparse(url).scheme}://{urlparse(url).netloc}"
            session.local_storage[origin] = local_storage
            session.session_storage[origin] = session_storage

            await page.close()
            await ctx.close()
            return {"local_storage": local_storage, "session_storage": session_storage}
        except Exception as e:
            logger.warning("capture_storage_error", error=str(e), url=url)
            return {}

    async def screenshot(self, session_id: str, url: str,
                         full_page: bool = True) -> str:
        """Take a screenshot and return base64 PNG."""
        session = self._sessions.get(session_id)
        if not session or not PLAYWRIGHT_AVAILABLE or not self._browser:
            return ""

        try:
            ctx = await self._browser.new_context(
                extra_http_headers=session.headers,
            )
            if session.cookies:
                await ctx.add_cookies(session.cookies)

            page = await ctx.new_page()
            await page.goto(url, timeout=15000)
            await page.wait_for_load_state("networkidle", timeout=8000)

            png = await page.screenshot(full_page=full_page, type="png")
            b64 = base64.b64encode(png).decode()
            session.screenshots.append(b64)

            await page.close()
            await ctx.close()
            return b64
        except Exception as e:
            logger.warning("screenshot_error", error=str(e), url=url)
            return ""

    def get_session(self, session_id: str) -> BrowserSession | None:
        return self._sessions.get(session_id)

    def list_sessions(self) -> list[dict]:
        return [s.to_dict() for s in self._sessions.values()]

    @property
    def capability_status(self) -> dict:
        return {
            "playwright_available": PLAYWRIGHT_AVAILABLE,
            "browser_started": self._browser is not None,
            "active_sessions": len(self._sessions),
            "install_cmd": "pip install playwright && playwright install chromium"
            if not PLAYWRIGHT_AVAILABLE else None,
        }


# Global session manager
session_manager = SessionManager()
