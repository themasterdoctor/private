"""SPA Route Mapper — discovers client-side routes in SPAs.

Works two ways:
1. Static: parses JS bundles for route strings (no browser needed)
2. Dynamic: uses Playwright to intercept navigation events (requires browser)

Both paths gracefully degrade when their dependency is unavailable.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any
import structlog

logger = structlog.get_logger(__name__)

PLAYWRIGHT_AVAILABLE = False
try:
    from playwright.async_api import async_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    pass


@dataclass
class SPARoute:
    path: str
    method: str = "GET"
    component: str = ""
    params: list[str] = field(default_factory=list)   # route params like :id
    discovered_via: str = "static"   # static | dynamic

    def to_dict(self) -> dict:
        return {
            "path": self.path,
            "method": self.method,
            "component": self.component,
            "params": self.params,
            "discovered_via": self.discovered_via,
        }


# Route patterns found in common JS frameworks
_ROUTE_PATTERNS = [
    # React Router
    r'path:\s*["\']([/][^"\']*)["\']',
    r'<Route[^>]+path=["\']([/][^"\']+)["\']',
    # Vue Router
    r'path:\s*["\']([/][^"\']+)["\']',
    # Next.js pages
    r'["\']/((?:api|pages|app)/[^"\']+)["\']',
    # Angular
    r'path:\s*["\']([^"\']+)["\']',
    # Generic href patterns
    r'href=["\']([/][a-zA-Z0-9_/.-]+)["\']',
    # fetch/axios calls
    r'(?:fetch|axios\.get|axios\.post)\(["\']([/][^"\'?]+)',
]

_COMPILED = [re.compile(p) for p in _ROUTE_PATTERNS]


def extract_routes_from_js(js_content: str, base_url: str = "") -> list[SPARoute]:
    """Extract route paths from JS bundle content. No browser required."""
    seen: set[str] = set()
    routes: list[SPARoute] = []

    for pattern in _COMPILED:
        for match in pattern.finditer(js_content):
            path = match.group(1)
            # Normalize
            if not path.startswith("/"):
                path = "/" + path
            # Skip long or obviously non-route strings
            if len(path) > 100 or " " in path or "\n" in path:
                continue
            # Skip common asset paths
            if any(ext in path for ext in [".png", ".jpg", ".css", ".ico", ".woff"]):
                continue
            if path not in seen:
                seen.add(path)
                # Extract params
                params = re.findall(r':([a-zA-Z]+)', path)
                routes.append(SPARoute(
                    path=path,
                    params=params,
                    discovered_via="static",
                ))

    return routes


async def map_spa_routes_dynamic(url: str, session_cookies: list[dict] | None = None,
                                  max_clicks: int = 20) -> list[SPARoute]:
    """Discover routes by navigating the SPA in a real browser.

    Intercepts history.pushState, popstate, and link clicks.
    Returns empty list if Playwright unavailable.
    """
    if not PLAYWRIGHT_AVAILABLE:
        logger.warning("spa_mapper_no_playwright",
                       fix="playwright install chromium")
        return []

    routes: list[SPARoute] = []
    seen_paths: set[str] = set()

    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True,
                                               args=["--no-sandbox"])
            ctx = await browser.new_context()
            if session_cookies:
                await ctx.add_cookies(session_cookies)

            # Intercept navigation
            discovered_paths: list[str] = []

            page = await ctx.new_page()

            # Override pushState to capture SPA navigation
            await page.add_init_script("""
                const orig = history.pushState.bind(history);
                history.pushState = function(state, title, url) {
                    window._bmxRoutes = window._bmxRoutes || [];
                    window._bmxRoutes.push(url);
                    return orig(state, title, url);
                };
            """)

            await page.goto(url, timeout=15000)
            await page.wait_for_load_state("networkidle", timeout=8000)

            # Collect initial path
            initial = await page.evaluate("window.location.pathname")
            if initial:
                discovered_paths.append(initial)

            # Click all links
            links = await page.query_selector_all("a[href]")
            for link in links[:max_clicks]:
                try:
                    href = await link.get_attribute("href")
                    if href and href.startswith("/") and len(href) < 100:
                        discovered_paths.append(href)
                except Exception:
                    pass

            # Collect pushState captures
            pushed = await page.evaluate("window._bmxRoutes || []")
            discovered_paths.extend(pushed)

            await page.close()
            await ctx.close()
            await browser.close()

            # Deduplicate
            for path in discovered_paths:
                # Normalize to path-only
                path = path.split("?")[0].split("#")[0]
                if path and path not in seen_paths:
                    seen_paths.add(path)
                    params = re.findall(r":([a-zA-Z]+)", path)
                    routes.append(SPARoute(
                        path=path,
                        params=params,
                        discovered_via="dynamic",
                    ))
    except Exception as e:
        logger.warning("spa_mapper_error", error=str(e), url=url)

    return routes


async def map_spa_routes(url: str,
                          js_content: str | None = None,
                          session_cookies: list[dict] | None = None) -> dict[str, Any]:
    """Full SPA route mapping: static JS analysis + optional dynamic discovery."""
    static_routes: list[SPARoute] = []
    dynamic_routes: list[SPARoute] = []

    if js_content:
        static_routes = extract_routes_from_js(js_content, url)

    if PLAYWRIGHT_AVAILABLE:
        dynamic_routes = await map_spa_routes_dynamic(url, session_cookies)

    all_paths = {r.path for r in static_routes} | {r.path for r in dynamic_routes}

    return {
        "url": url,
        "static_routes": [r.to_dict() for r in static_routes],
        "dynamic_routes": [r.to_dict() for r in dynamic_routes],
        "total_unique_paths": len(all_paths),
        "all_paths": sorted(all_paths),
        "playwright_used": PLAYWRIGHT_AVAILABLE,
    }
