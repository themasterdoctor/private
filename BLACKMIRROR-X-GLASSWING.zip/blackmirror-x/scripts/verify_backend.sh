#!/usr/bin/env bash
# scripts/verify_backend.sh — BLACKMIRROR-X backend verification
# Run from: /home/claude/blackmirror-x/backend
set -euo pipefail

PASS=0; FAIL=0
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$(dirname "$SCRIPT_DIR")/backend"
cd "$BACKEND_DIR"

# Load env
if [ -f ../.env ]; then
  export $(grep -v '^#' ../.env | xargs) 2>/dev/null || true
fi
export DATABASE_URL="${DATABASE_URL:-postgresql+asyncpg://bmx:bmxsecret2025@localhost:5432/blackmirror}"
export SECRET_KEY="${SECRET_KEY:-change-this-secret-key-32-chars-min}"
export ANTHROPIC_API_KEY="${ANTHROPIC_API_KEY:-sk-ant-REPLACE-ME}"
export REDIS_URL="${REDIS_URL:-redis://localhost:6379/0}"
export JWT_SECRET_KEY="${JWT_SECRET_KEY:-change-this-jwt-secret}"

ok()   { echo "  ✓  $1"; PASS=$((PASS+1)); }
fail() { echo "  ✗  $1"; echo "     $2"; FAIL=$((FAIL+1)); }

echo ""
echo "════════════════════════════════════════════════════════"
echo "  BLACKMIRROR-X GLASSWING — Backend Verification"
echo "════════════════════════════════════════════════════════"
echo ""

# 1. Python syntax check
echo "── 1. Syntax Check ─────────────────────────────────────"
if python -m compileall app/ -q 2>/dev/null; then
  ok "All Python files compile without syntax errors"
else
  RESULT=$(python -m compileall app/ -q 2>&1 | head -5)
  fail "Syntax errors found" "$RESULT"
fi

# 2. Core imports
echo ""
echo "── 2. Core Module Imports ──────────────────────────────"
MODULES=(
  "app.core.config"
  "app.core.security"
  "app.core.logging"
  "app.models.models"
  "app.intelligence.reasoning"
  "app.intelligence.hypothesis.engine"
  "app.intelligence.memory.workspace_memory"
  "app.intelligence.court.validation_court"
  "app.intelligence.payloads.payload_intel"
  "app.intelligence.simulator.exploitability"
  "app.intelligence.chain.chain_composer"
  "app.intelligence.self_improvement"
  "app.monitoring.continuous_monitor"
  "app.metrics.prometheus_metrics"
  "app.vault.vault"
  "app.reporting.advanced_reports"
)
for mod in "${MODULES[@]}"; do
  if python -c "import sys; sys.path.insert(0,'.'); __import__('$mod')" 2>/dev/null; then
    ok "$mod"
  else
    ERR=$(python -c "import sys; sys.path.insert(0,'.'); __import__('$mod')" 2>&1 | tail -1)
    fail "$mod" "$ERR"
  fi
done

# 3. FastAPI app loads + route count
echo ""
echo "── 3. FastAPI App + Routes ─────────────────────────────"
ROUTE_OUTPUT=$(python -c "
import sys, os; sys.path.insert(0,'.')
from app.main import app
routes = [r for r in app.routes if hasattr(r,'path') and hasattr(r,'methods')]
intel  = [r for r in routes if '/intel/' in r.path]
print(f'total={len(routes)} intel={len(intel)}')
" 2>/dev/null)
TOTAL=$(echo "$ROUTE_OUTPUT" | grep -oP 'total=\K\d+')
INTEL=$(echo "$ROUTE_OUTPUT" | grep -oP 'intel=\K\d+')
if [ "${TOTAL:-0}" -ge 40 ]; then
  ok "FastAPI app loaded: $TOTAL routes ($INTEL intelligence routes)"
else
  fail "Route count too low" "Got $TOTAL (expected ≥40)"
fi

# 4. Celery
echo ""
echo "── 4. Celery Worker ────────────────────────────────────"
if python -c "
import sys; sys.path.insert(0,'.')
from app.workers.celery_app import celery_app
assert celery_app.main == 'blackmirror'
" 2>/dev/null; then
  ok "Celery app imports and has correct app name"
else
  fail "Celery import failed" "$(python -c 'from app.workers.celery_app import celery_app' 2>&1 | tail -1)"
fi

# 5. Alembic migrations
echo ""
echo "── 5. Alembic Migrations ───────────────────────────────"
for ver in 001_initial 002_intelligence_layer; do
  if python -c "
import importlib.util
spec = importlib.util.spec_from_file_location('m', 'alembic/versions/${ver}.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
" 2>/dev/null; then
    ok "Migration $ver"
  else
    fail "Migration $ver failed to parse" ""
  fi
done

# 6. pytest
echo ""
echo "── 6. Test Suite ───────────────────────────────────────"
if command -v pytest &>/dev/null; then
  RESULT=$(python -m pytest tests/test_full_stack.py -q 2>&1 | tail -3)
  PASSED=$(echo "$RESULT" | grep -oP '\d+ passed')
  FAILED=$(echo "$RESULT" | grep -oP '\d+ failed' || echo "0 failed")
  if echo "$RESULT" | grep -q "passed" && ! echo "$RESULT" | grep -q "error"; then
    ok "pytest: $PASSED, $FAILED"
  else
    fail "pytest failures" "$RESULT"
  fi
else
  ok "pytest not installed — run: pip install pytest pytest-asyncio"
fi

# 7. uvicorn dry-run (import only)
echo ""
echo "── 7. Uvicorn Import Test ──────────────────────────────"
if python -c "import uvicorn; uvicorn.Config('app.main:app', host='0.0.0.0', port=8000)" 2>/dev/null; then
  ok "uvicorn can load app config"
else
  fail "uvicorn import/config failed" ""
fi

# Summary
echo ""
echo "════════════════════════════════════════════════════════"
echo "  Backend Verification: $PASS passed, $FAIL failed"
echo "════════════════════════════════════════════════════════"
echo ""
[ $FAIL -eq 0 ] && exit 0 || exit 1
