#!/usr/bin/env bash
# scripts/restore.sh — BLACKMIRROR-X database restore
# Usage: bash scripts/restore.sh <backup_file.sql.gz>
# WARNING: This will DROP and recreate the database.

set -euo pipefail

if [ -z "${1:-}" ]; then
  echo "Usage: bash scripts/restore.sh <backup_file.sql.gz>"
  echo "Available backups:"
  ls -lh backups/blackmirror_*.sql.gz 2>/dev/null || echo "  No backups found in ./backups/"
  exit 1
fi

BACKUP_FILE="$1"
if [ ! -f "$BACKUP_FILE" ]; then
  echo "ERROR: Backup file not found: $BACKUP_FILE"
  exit 1
fi

# Load env
if [ -f .env ]; then
  export $(grep -v '^#' .env | grep -v '^$' | xargs) 2>/dev/null || true
fi

DB_HOST="${POSTGRES_HOST:-127.0.0.1}"
DB_PORT="${POSTGRES_PORT:-5432}"
DB_NAME="${POSTGRES_DB:-blackmirror}"
DB_USER="${POSTGRES_USER:-bmx}"
DB_PASS="${POSTGRES_PASSWORD:-bmxsecret2025}"

echo "════════════════════════════════════════"
echo "  BLACKMIRROR-X Restore"
echo "  Source: ${BACKUP_FILE}"
echo "  Target: ${DB_HOST}:${DB_PORT}/${DB_NAME}"
echo "════════════════════════════════════════"
echo ""
echo "⚠️  WARNING: This will DROP and recreate the '${DB_NAME}' database."
echo "   All existing data will be PERMANENTLY DELETED."
echo ""
read -r -p "Type 'yes' to confirm: " CONFIRM
if [ "$CONFIRM" != "yes" ]; then
  echo "Aborted."
  exit 0
fi

echo ""
echo "Restoring..."

if ! command -v psql &>/dev/null; then
  if command -v docker &>/dev/null; then
    echo "Using Docker psql..."
    docker-compose exec -T postgres bash -c \
      "psql -U ${DB_USER} -c 'DROP DATABASE IF EXISTS ${DB_NAME};' postgres && \
       psql -U ${DB_USER} -c 'CREATE DATABASE ${DB_NAME};' postgres"
    zcat "$BACKUP_FILE" | docker-compose exec -T postgres psql -U "$DB_USER" "$DB_NAME"
  else
    echo "ERROR: psql not found and Docker unavailable"
    exit 1
  fi
else
  PGPASSWORD="$DB_PASS" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" postgres \
    -c "DROP DATABASE IF EXISTS $DB_NAME;" \
    -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"
  zcat "$BACKUP_FILE" | PGPASSWORD="$DB_PASS" psql \
    -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" "$DB_NAME"
fi

echo ""
echo "✓ Restore complete from: ${BACKUP_FILE}"
echo ""
echo "Run migrations if needed: alembic upgrade head"
