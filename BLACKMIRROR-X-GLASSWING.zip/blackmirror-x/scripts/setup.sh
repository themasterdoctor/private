#!/usr/bin/env bash
set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${CYAN}"
cat << 'EOF'
 ██████╗ ██╗      █████╗  ██████╗██╗  ██╗███╗   ███╗██╗██████╗ ██████╗  ██████╗ ██████╗       ██╗  ██╗
 ██╔══██╗██║     ██╔══██╗██╔════╝██║ ██╔╝████╗ ████║██║██╔══██╗██╔══██╗██╔═══██╗██╔══██╗      ╚██╗██╔╝
 ██████╔╝██║     ███████║██║     █████╔╝ ██╔████╔██║██║██████╔╝██████╔╝██║   ██║██████╔╝       ╚███╔╝
 ██╔══██╗██║     ██╔══██║██║     ██╔═██╗ ██║╚██╔╝██║██║██╔══██╗██╔══██╗██║   ██║██╔══██╗       ██╔██╗
 ██████╔╝███████╗██║  ██║╚██████╗██║  ██╗██║ ╚═╝ ██║██║██║  ██║██║  ██║╚██████╔╝██║  ██║██╗  ██╔╝ ██╗
 ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝  ╚═╝
 GLASSWING AI CYBERSECURITY PLATFORM
EOF
echo -e "${NC}"

log() { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err() { echo -e "${RED}[✗]${NC} $1"; exit 1; }
info() { echo -e "${CYAN}[→]${NC} $1"; }

# ─── Prerequisites ────────────────────────────────────────────────────────────
info "Checking prerequisites..."

command -v docker >/dev/null 2>&1 || err "Docker is required. Install from https://docs.docker.com/get-docker/"
command -v docker-compose >/dev/null 2>&1 || command -v "docker compose" >/dev/null 2>&1 || err "Docker Compose is required"
command -v git >/dev/null 2>&1 || warn "Git not found"

DOCKER_VERSION=$(docker --version | grep -oP '\d+\.\d+' | head -1)
log "Docker $DOCKER_VERSION found"

# ─── Environment Setup ────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"
cd "$ROOT_DIR"

info "Setting up environment..."

if [ ! -f .env ]; then
    cp .env.example .env
    log "Created .env from .env.example"

    # Generate random secrets
    JWT_SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))" 2>/dev/null || openssl rand -hex 32)
    sed -i.bak "s/your-secret-key-change-this-in-production/$JWT_SECRET/g" .env
    rm -f .env.bak
    log "Generated JWT secret"

    warn "⚠️  Please edit .env and set your ANTHROPIC_API_KEY before proceeding"
    echo ""
    read -p "Enter your Anthropic API key (or press Enter to skip for now): " API_KEY
    if [ -n "$API_KEY" ]; then
        sed -i.bak "s/your-anthropic-api-key/$API_KEY/g" .env
        rm -f .env.bak
        log "Anthropic API key configured"
    fi
else
    log ".env already exists"
fi

# ─── Build & Start Services ───────────────────────────────────────────────────
info "Building Docker images (this may take 5-10 minutes on first run)..."
docker compose build --parallel 2>&1 | tail -5

info "Starting services..."
docker compose up -d postgres redis
sleep 3

# Wait for postgres
info "Waiting for PostgreSQL to be ready..."
for i in {1..30}; do
    if docker compose exec -T postgres pg_isready -U bmx -d blackmirror >/dev/null 2>&1; then
        log "PostgreSQL ready"
        break
    fi
    sleep 1
    if [ $i -eq 30 ]; then err "PostgreSQL failed to start"; fi
done

# ─── Database Setup ───────────────────────────────────────────────────────────
info "Running database migrations..."
docker compose run --rm backend alembic upgrade head
log "Migrations applied"

info "Seeding demo data..."
docker compose run --rm backend python scripts/seed.py
log "Demo data seeded"

# ─── Start All Services ───────────────────────────────────────────────────────
info "Starting all services..."
docker compose up -d
sleep 5

# ─── Health Check ─────────────────────────────────────────────────────────────
info "Checking service health..."

check_service() {
    local name=$1 url=$2
    for i in {1..10}; do
        if curl -sf "$url" >/dev/null 2>&1; then
            log "$name is healthy"
            return 0
        fi
        sleep 2
    done
    warn "$name health check failed (may still be starting)"
}

check_service "Backend API" "http://localhost:8000/api/v1/health"
check_service "Frontend" "http://localhost:3000"

# ─── Done ─────────────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  BLACKMIRROR-X GLASSWING is ready!${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "  ${CYAN}Frontend:${NC}    http://localhost:3000"
echo -e "  ${CYAN}API:${NC}         http://localhost:8000"
echo -e "  ${CYAN}API Docs:${NC}    http://localhost:8000/docs"
echo -e "  ${CYAN}Flower:${NC}      http://localhost:5555"
echo ""
echo -e "  ${YELLOW}Demo Credentials:${NC}"
echo -e "  Email:    admin@blackmirror.io"
echo -e "  Password: BlackMirrorX2025!"
echo ""
echo -e "  ${YELLOW}Useful commands:${NC}"
echo -e "  docker compose logs -f backend   # Backend logs"
echo -e "  docker compose logs -f worker    # Worker logs"
echo -e "  docker compose down              # Stop all services"
echo -e "  docker compose restart backend   # Restart backend"
echo ""
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
