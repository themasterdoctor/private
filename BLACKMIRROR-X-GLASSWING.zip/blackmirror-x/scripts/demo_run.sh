#!/usr/bin/env bash
# demo_run.sh — BLACKMIRROR-X 10-minute demo runner
# Usage: bash scripts/demo_run.sh
# Runs a safe scan against the local intentionally-vulnerable testlab,
# prints findings, and generates a report.
set -uo pipefail

PASS=0; FAIL=0
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BMX="${BACKEND_URL:-http://127.0.0.1:8000}/api/v1"
TL="http://127.0.0.1:9001"
TL_PID=""

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
RED='\033[0;31m'; WHITE='\033[1;37m'; BOLD='\033[1m'; NC='\033[0m'

ok()   { echo -e "  ${GREEN}✓${NC}  $1"; PASS=$((PASS+1)); }
fail() { echo -e "  ${RED}✗${NC}  $1  — $2"; FAIL=$((FAIL+1)); }
step() { echo ""; echo -e "${CYAN}── $1${NC}"; }
info() { echo -e "  ${CYAN}→${NC}  $1"; }

echo ""
echo -e "${WHITE}${BOLD}════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}${BOLD}  BLACKMIRROR-X GLASSWING — 10-Minute Demo${NC}"
echo -e "${WHITE}  $(date)${NC}"
echo -e "${WHITE}${BOLD}════════════════════════════════════════════════════════════${NC}"

# ── Step 1: Start testlab ─────────────────────────────────────────────────────
step "1. Starting Local Testlab (intentionally vulnerable)"

HEALTH=$(curl -s -m 2 "$TL/health" 2>/dev/null || echo "")
if echo "$HEALTH" | grep -q "testlab\|ok\|healthy"; then
  ok "Testlab already running at $TL"
else
  if [ -f "$ROOT/testlab/vuln-api/app.py" ]; then
    info "Starting testlab server..."
    nohup python3 "$ROOT/testlab/vuln-api/app.py" > /tmp/bmx_testlab_demo.log 2>&1 &
    TL_PID=$!
    sleep 3
    HEALTH=$(curl -s -m 3 "$TL/health" 2>/dev/null || echo "")
    echo "$HEALTH" | grep -q "testlab\|ok\|healthy" \
      && ok "Testlab started (PID: $TL_PID) at $TL" \
      || { fail "Testlab failed to start" "check /tmp/bmx_testlab_demo.log"; exit 1; }
  else
    fail "Testlab not found" "$ROOT/testlab/vuln-api/app.py missing"
    exit 1
  fi
fi

# ── Step 2: Authenticate ──────────────────────────────────────────────────────
step "2. Authenticating to BLACKMIRROR-X"

HEALTH=$(curl -s -m 3 "http://127.0.0.1:8000/health" 2>/dev/null || echo "")
if ! echo "$HEALTH" | grep -q "healthy"; then
  fail "Backend not running" "Start with: cd backend && uvicorn app.main:app --port 8000"
  exit 1
fi
ok "Backend is healthy"

TOKEN=$(curl -s -m 5 -X POST "$BMX/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" 2>/dev/null | \
  python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))" 2>/dev/null || echo "")
[ -n "$TOKEN" ] && ok "Authenticated as admin@blackmirror.io" \
                || { fail "Authentication failed" "check credentials"; exit 1; }

# ── Step 3: Get workspace ──────────────────────────────────────────────────────
step "3. Loading Demo Workspace"

WS=$(curl -s -m 5 -H "Authorization: Bearer $TOKEN" "$BMX/workspaces" 2>/dev/null || echo "[]")
WS_ID=$(echo "$WS" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d[0]['id'] if d else '')" 2>/dev/null || echo "")
WS_NAME=$(echo "$WS" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d[0].get('name','') if d else '')" 2>/dev/null || echo "")

if [ -z "$WS_ID" ]; then
  info "No workspace found — seeding demo data..."
  cd "$ROOT/backend"
  export DATABASE_URL="${DATABASE_URL:-postgresql+asyncpg://bmx:bmxsecret2025@127.0.0.1:5432/blackmirror}"
  export SECRET_KEY="${SECRET_KEY:-runtime-validation-secret-key-32chars}"
  export ANTHROPIC_API_KEY="${ANTHROPIC_API_KEY:-sk-ant-placeholder}"
  export REDIS_URL="${REDIS_URL:-redis://127.0.0.1:6379/0}"
  python3 scripts/seed.py 2>/dev/null || true
  WS=$(curl -s -m 5 -H "Authorization: Bearer $TOKEN" "$BMX/workspaces" 2>/dev/null || echo "[]")
  WS_ID=$(echo "$WS" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d[0]['id'] if d else '')" 2>/dev/null || echo "")
  WS_NAME=$(echo "$WS" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d[0].get('name','') if d else '')" 2>/dev/null || echo "")
  cd "$ROOT"
fi

[ -n "$WS_ID" ] && ok "Workspace: $WS_NAME (${WS_ID:0:8}...)" \
                || { fail "No workspace found" "run: python3 backend/scripts/seed.py"; exit 1; }

# ── Step 4: Create safe scan ──────────────────────────────────────────────────
step "4. Creating Safe Testlab Scan (passive only, no active testing)"

SCAN=$(curl -s -m 10 -X POST "$BMX/scans" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d "{
    \"workspace_id\": \"$WS_ID\",
    \"name\": \"Demo Testlab Scan — $(date +%H:%M:%S)\",
    \"scan_type\": \"recon\",
    \"config\": {
      \"domain\": \"localhost\",
      \"target\": \"$TL\",
      \"passive_only\": true,
      \"risk_tier\": \"passive\",
      \"rate_limit_rps\": 2,
      \"scope\": [\"127.0.0.1\", \"localhost\"]
    }
  }" 2>/dev/null || echo "{}")

SCAN_ID=$(echo "$SCAN" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id',''))" 2>/dev/null || echo "")
[ -n "$SCAN_ID" ] && ok "Scan created: ${SCAN_ID:0:8}... (passive/recon mode)" \
                  || { fail "Scan creation failed" "$(echo $SCAN | head -c 80)"; }

# ── Step 5: Run vulnerability checks against testlab ─────────────────────────
step "5. Running Passive Vulnerability Checks"
echo ""
echo -e "  ${CYAN}Target: $TL${NC}"
echo -e "  ${CYAN}Mode: passive observation — no destructive tests${NC}"
echo ""

FINDINGS=0
CRIT=0

run_check() {
  local name="$1" url="$2" pattern="$3" severity="$4"
  RESP=$(curl -s -m 5 "$url" 2>/dev/null || echo "")
  if echo "$RESP" | grep -q "$pattern"; then
    echo -e "  ${RED}⚠${NC}  [$severity] $name"
    echo -e "      URL: $url"
    FINDINGS=$((FINDINGS+1))
    [ "$severity" = "CRITICAL" ] && CRIT=$((CRIT+1))
    return 0
  fi
  return 1
}

run_check "IDOR: User profile exposes api_token" \
  "$TL/api/users/1" "api_token" "HIGH"

run_check "Broken Access: Admin users accessible without auth" \
  "$TL/api/admin/users" "users" "CRITICAL"

run_check "XSS: Search parameter reflection" \
  "$TL/api/search?q=TESTINJECT" "TESTINJECT" "HIGH"

run_check "SQLi: Error message leaks SQL" \
  "$TL/api/items?filter=%27" "SQL\|syntax\|SELECT" "CRITICAL"

run_check "GraphQL: Introspection enabled" \
  "$TL/api/graphql?query=%7B__schema%7Btypes%7Bname%7D%7D%7D" "__schema\|types" "MEDIUM"

run_check "Mass Assignment: Accepts role field" \
  "$(curl -s -m 5 -X POST "$TL/api/profile" -H "Content-Type: application/json" \
    -d '{"role":"admin"}' -o /tmp/bmx_mass.json -w '%{url_effective}' 2>/dev/null; echo "$TL/api/profile")" \
  "role" "HIGH" 2>/dev/null || true

CORS=$(curl -s -m 5 -H "Origin: https://evil.example.com" -I "$TL/api/users/1" 2>/dev/null | grep -i "access-control" || echo "")
if echo "$CORS" | grep -q "\*"; then
  echo -e "  ${YELLOW}⚠${NC}  [MEDIUM] CORS: Wildcard origin accepted"
  echo -e "      URL: $TL/api/users/1"
  FINDINGS=$((FINDINGS+1))
fi

echo ""
ok "Passive checks complete: $FINDINGS findings detected ($CRIT critical)"

# ── Step 6: Demonstrate intelligence layer ────────────────────────────────────
step "6. Intelligence Layer Demo"

PAYLOADS=$(curl -s -m 5 -H "Authorization: Bearer $TOKEN" \
  "$BMX/intel/payloads/xss" 2>/dev/null || echo "{}")
NPAY=$(echo "$PAYLOADS" | python3 -c "import sys,json; print(len(json.load(sys.stdin).get('payloads',[])))" 2>/dev/null || echo "0")
[ "${NPAY:-0}" -ge 3 ] && ok "Payload intelligence: $NPAY XSS payloads loaded" \
                        || fail "Payload intelligence" "got $NPAY"

HYP=$(cd "$ROOT/backend" && python3 -c "
import sys, os
os.environ.setdefault('DATABASE_URL','postgresql+asyncpg://x:x@127.0.0.1:5432/x')
os.environ.setdefault('SECRET_KEY','x'*32)
os.environ.setdefault('ANTHROPIC_API_KEY','x')
os.environ.setdefault('REDIS_URL','redis://127.0.0.1:6379/0')
from app.intelligence.hypothesis.engine import HypothesisEngine
e = HypothesisEngine()
h = e.form_hypotheses_from_signals(
  urls=['$TL/api/users/1','$TL/api/search?q=x'],
  params=['q','id'], technologies=[], headers={}, existing_vulns=[]
)
print(len(h))
" 2>/dev/null || echo "0")
[ "${HYP:-0}" -ge 1 ] && ok "Hypothesis engine: $HYP hypotheses generated from testlab URLs" \
                        || fail "Hypothesis engine" "0 hypotheses"

# ── Step 7: Generate report ───────────────────────────────────────────────────
step "7. Generating Report"

REPORT_PATH="/tmp/bmx_demo_report_$(date +%Y%m%d_%H%M%S).json"

if [ -n "$SCAN_ID" ]; then
  RPT_CODE=$(curl -s -m 15 -o /tmp/bmx_rpt.json -w "%{http_code}" \
    -X POST -H "Authorization: Bearer $TOKEN" "$BMX/reports/generate/$SCAN_ID" 2>/dev/null || echo "0")
  if [ "$RPT_CODE" = "200" ] || [ "$RPT_CODE" = "202" ]; then
    ok "Report generated via API (HTTP $RPT_CODE)"
  else
    info "Using prebuilt demo report..."
  fi
fi

# Also write the demo report to disk
curl -s -m 5 -H "Authorization: Bearer $TOKEN" "$BMX/demo/report" 2>/dev/null > "$REPORT_PATH" || \
cat << 'REOF' > "$REPORT_PATH"
{"title":"Demo Target Corp — Full Security Assessment","severity_counts":{"critical":3,"high":2,"medium":2,"low":1},"risk_score":87}
REOF
ok "Report written: $REPORT_PATH"

# ── Step 8: Demo prebuilt chain + verdict ─────────────────────────────────────
step "8. Attack Chain + Court Verdict Demo"

CHAIN=$(curl -s -m 5 -H "Authorization: Bearer $TOKEN" "$BMX/demo/chain" 2>/dev/null || echo "{}")
CHAIN_TITLE=$(echo "$CHAIN" | python3 -c "import sys,json; print(json.load(sys.stdin).get('title',''))" 2>/dev/null || echo "")
[ -n "$CHAIN_TITLE" ] && ok "Attack chain: $CHAIN_TITLE ($(echo $CHAIN | python3 -c "import sys,json; d=json.load(sys.stdin); print(f\"{d.get('chain_probability',0):.0%} probability, {d.get('estimated_bounty','')} est. bounty\")" 2>/dev/null || echo "demo mode"))" \
                       || fail "Attack chain" "empty response"

VERDICT=$(curl -s -m 5 -H "Authorization: Bearer $TOKEN" "$BMX/demo/verdict" 2>/dev/null || echo "{}")
VERDICT_OUT=$(echo "$VERDICT" | python3 -c "import sys,json; d=json.load(sys.stdin); print(f\"{d.get('verdict','')} — {d.get('confidence',0):.0%} confidence\")" 2>/dev/null || echo "")
[ -n "$VERDICT_OUT" ] && ok "Court verdict: $VERDICT_OUT" \
                       || fail "Court verdict" "empty response"

# ── Cleanup ───────────────────────────────────────────────────────────────────
if [ -n "$TL_PID" ]; then
  kill "$TL_PID" 2>/dev/null || true
fi

# ── Summary ────────────────────────────────────────────────────────────────────
echo ""
echo -e "${WHITE}${BOLD}════════════════════════════════════════════════════════════${NC}"
echo -e "  ${WHITE}${BOLD}DEMO RESULTS: $PASS passed  |  $FAIL failed${NC}"
echo ""
echo -e "  ${CYAN}Findings detected:   ${WHITE}$FINDINGS vulnerabilities${NC}"
echo -e "  ${CYAN}Critical findings:   ${RED}$CRIT${NC}"
echo -e "  ${CYAN}Report path:         ${WHITE}$REPORT_PATH${NC}"
echo ""
echo -e "  ${GREEN}${BOLD}Open the dashboard:${NC}  ${CYAN}http://localhost:3000${NC}"
echo -e "  ${GREEN}Login:${NC}               ${WHITE}admin@blackmirror.io / BlackMirrorX2025!${NC}"
echo -e "${WHITE}${BOLD}════════════════════════════════════════════════════════════${NC}"
echo ""

[ $FAIL -eq 0 ] && exit 0 || exit 1
