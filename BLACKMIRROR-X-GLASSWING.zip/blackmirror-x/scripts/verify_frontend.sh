#!/usr/bin/env bash
# scripts/verify_frontend.sh — BLACKMIRROR-X frontend verification
set -euo pipefail

PASS=0; FAIL=0
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FRONTEND_DIR="$(dirname "$SCRIPT_DIR")/frontend"
cd "$FRONTEND_DIR"

ok()   { echo "  ✓  $1"; PASS=$((PASS+1)); }
fail() { echo "  ✗  $1"; echo "     $2"; FAIL=$((FAIL+1)); }

echo ""
echo "════════════════════════════════════════════════════════"
echo "  BLACKMIRROR-X GLASSWING — Frontend Verification"
echo "════════════════════════════════════════════════════════"
echo ""

# 1. Node/npm version
echo "── 1. Runtime ──────────────────────────────────────────"
NODE_VER=$(node --version 2>/dev/null || echo "NOT FOUND")
NPM_VER=$(npm --version 2>/dev/null || echo "NOT FOUND")
if [[ "$NODE_VER" == v1[89].* ]] || [[ "$NODE_VER" == v2*.* ]]; then
  ok "Node.js $NODE_VER, npm $NPM_VER"
else
  fail "Node.js version too old or missing" "Found: $NODE_VER (need ≥18)"
fi

# 2. npm install
echo ""
echo "── 2. Dependencies ─────────────────────────────────────"
if npm install --legacy-peer-deps --silent 2>/dev/null; then
  PKG_COUNT=$(ls node_modules | wc -l)
  ok "npm install successful ($PKG_COUNT packages)"
else
  fail "npm install failed" "Run: cd frontend && npm install --legacy-peer-deps"
fi

# 3. Required page files
echo ""
echo "── 3. Page Files ───────────────────────────────────────"
PAGES=(
  "src/app/dashboard/page.tsx"
  "src/app/recon/page.tsx"
  "src/app/vulns/page.tsx"
  "src/app/graph/page.tsx"
  "src/app/mission/page.tsx"
  "src/app/court/page.tsx"
  "src/app/evidence/page.tsx"
  "src/app/monitor/page.tsx"
  "src/app/replay/page.tsx"
  "src/app/copilot/page.tsx"
  "src/app/reports/page.tsx"
  "src/app/settings/page.tsx"
  "src/app/auth/login/page.tsx"
  "src/app/auth/register/page.tsx"
  "src/app/scans/[id]/page.tsx"
  "src/app/dashboard/layout.tsx"
  "src/components/shared/theme-provider.tsx"
  "src/components/ui/toaster.tsx"
  "src/lib/api.ts"
  "src/store/app.ts"
  "src/store/auth.ts"
)
for page in "${PAGES[@]}"; do
  if [ -f "$page" ]; then
    ok "$page"
  else
    fail "Missing: $page" ""
  fi
done

# 4. TypeScript type check
echo ""
echo "── 4. TypeScript ───────────────────────────────────────"
TS_RESULT=$(npx tsc --noEmit 2>&1)
TS_ERRORS=$(echo "$TS_RESULT" | grep "error TS" | wc -l)
if [ "$TS_ERRORS" -eq 0 ]; then
  ok "TypeScript: 0 type errors"
else
  fail "TypeScript: $TS_ERRORS type errors" "$(echo "$TS_RESULT" | grep 'error TS' | head -3)"
fi

# 5. ESLint
echo ""
echo "── 5. ESLint ───────────────────────────────────────────"
LINT_RESULT=$(npm run lint 2>&1)
LINT_ERRORS=$(echo "$LINT_RESULT" | grep -c "Error:" || true)
if [ "$LINT_ERRORS" -eq 0 ]; then
  LINT_WARNINGS=$(echo "$LINT_RESULT" | grep -c "Warning:" || echo "0")
  ok "ESLint: 0 errors, $LINT_WARNINGS warnings"
else
  fail "ESLint: $LINT_ERRORS errors" "$(echo "$LINT_RESULT" | grep 'Error:' | head -3)"
fi

# 6. Production build
echo ""
echo "── 6. Production Build ─────────────────────────────────"
BUILD_RESULT=$(npm run build 2>&1)
BUILD_EXIT=$?
ROUTE_COUNT=$(echo "$BUILD_RESULT" | grep -c "^[├└]" || echo "0")
if [ $BUILD_EXIT -eq 0 ] && echo "$BUILD_RESULT" | grep -q "Compiled successfully"; then
  ok "Next.js build succeeded ($ROUTE_COUNT routes compiled)"
else
  fail "Build failed" "$(echo "$BUILD_RESULT" | grep -E 'Error|error' | head -3)"
fi

# Summary
echo ""
echo "════════════════════════════════════════════════════════"
echo "  Frontend Verification: $PASS passed, $FAIL failed"
echo "════════════════════════════════════════════════════════"
echo ""
[ $FAIL -eq 0 ] && exit 0 || exit 1
