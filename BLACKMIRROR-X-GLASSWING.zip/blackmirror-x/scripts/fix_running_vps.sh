#!/usr/bin/env bash
# fix_running_vps.sh
# Run this from ~/private/blackmirror-x on the VPS.
# Fixes CORS and the frontend API URL without touching anything else.
set -e

echo "=== BlackMirror-X VPS Fix ==="
echo "This will: fix CORS, rebuild frontend with correct API URL, verify"
echo ""

IP="76.13.30.226"
BACKEND="http://${IP}:8000"
FRONTEND="http://${IP}:3000"

# ── 1. Fix .env ───────────────────────────────────────────────────────────────
echo "[1/6] Fixing .env..."
sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://${IP}:3000,http://localhost:3000|" .env
sed -i "s|^NEXT_PUBLIC_API_URL=.*|NEXT_PUBLIC_API_URL=${BACKEND}|" .env
sed -i "s|^NEXT_PUBLIC_WS_URL=.*|NEXT_PUBLIC_WS_URL=ws://${IP}:8000|" .env
grep "CORS_ORIGINS\|NEXT_PUBLIC_API_URL" .env
echo ""

# ── 2. Inject CORS middleware into running backend ───────────────────────────
echo "[2/6] Patching backend CORS (no rebuild needed)..."
BACKEND_CTR=$(docker ps --filter name=backend -q | head -1)
if [ -z "$BACKEND_CTR" ]; then
  echo "ERROR: Backend container not running. Run: docker compose up -d"
  exit 1
fi

# Write the BroadCORSMiddleware file into the container
docker exec "$BACKEND_CTR" python3 - << 'PYEOF'
import re

# Write cors.py
cors_code = '''
import re
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

class BroadCORSMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, allowed_origins):
        super().__init__(app)
        self.allowed_origins = set(allowed_origins)
        self.ip_pattern = re.compile(r"^https?://\\d+\\.\\d+\\.\\d+\\.\\d+:\\d+$")

    def _origin_allowed(self, origin):
        if not origin: return False
        if origin in self.allowed_origins: return True
        if self.ip_pattern.match(origin): return True
        return False

    async def dispatch(self, request: Request, call_next) -> Response:
        origin = request.headers.get("origin", "")
        if request.method == "OPTIONS":
            r = Response(status_code=204)
            self._add_cors_headers(r, origin)
            return r
        response = await call_next(request)
        self._add_cors_headers(response, origin)
        return response

    def _add_cors_headers(self, response, origin):
        ao = origin if self._origin_allowed(origin) else "*"
        response.headers["Access-Control-Allow-Origin"] = ao
        response.headers["Access-Control-Allow-Credentials"] = "true"
        response.headers["Access-Control-Allow-Methods"] = "GET,POST,PUT,PATCH,DELETE,OPTIONS"
        response.headers["Access-Control-Allow-Headers"] = "Authorization,Content-Type,Accept,Origin,X-Requested-With"
        response.headers["Access-Control-Max-Age"] = "86400"
        response.headers["Vary"] = "Origin"
'''
open('/app/app/core/cors.py', 'w').write(cors_code)

# Patch main.py
content = open('/app/app/main.py').read()
if 'BroadCORSMiddleware' not in content:
    # Remove old CORSMiddleware import
    content = re.sub(r'from fastapi\.middleware\.cors import CORSMiddleware\n', '', content)
    # Add new import
    content = content.replace(
        'from app.api.middleware.rate_limit import RateLimitMiddleware',
        'from app.core.cors import BroadCORSMiddleware\nfrom app.api.middleware.rate_limit import RateLimitMiddleware'
    )
    # Replace old middleware block with new one
    content = re.sub(
        r'app\.add_middleware\(\s*CORSMiddleware.*?\)',
        'app.add_middleware(BroadCORSMiddleware, allowed_origins=settings.CORS_ORIGINS)',
        content,
        flags=re.DOTALL
    )
    open('/app/app/main.py', 'w').write(content)
    print("main.py patched: CORSMiddleware -> BroadCORSMiddleware")
else:
    print("main.py already has BroadCORSMiddleware")

print("cors.py written")
PYEOF

echo ""

# ── 3. Restart backend to pick up patched code + new CORS_ORIGINS ─────────────
echo "[3/6] Restarting backend..."
docker compose restart backend
echo -n "Waiting for backend health"
for i in $(seq 1 20); do
  sleep 2
  STATUS=$(curl -sf http://localhost:8000/health 2>/dev/null && echo "ok" || echo "")
  if [ -n "$STATUS" ]; then echo " healthy!"; break; fi
  echo -n "."
  [ $i -eq 20 ] && { echo " TIMEOUT"; exit 1; }
done

# ── 4. Rebuild frontend with correct API URL baked in ────────────────────────
echo ""
echo "[4/6] Rebuilding frontend (baking in API URL: ${BACKEND})..."
docker compose build --no-cache frontend
echo ""

# ── 5. Restart frontend ───────────────────────────────────────────────────────
echo "[5/6] Restarting frontend..."
docker compose up -d frontend
echo -n "Waiting for frontend"
for i in $(seq 1 20); do
  sleep 2
  STATUS=$(curl -so /dev/null -w "%{http_code}" http://localhost:3000/ 2>/dev/null)
  if [[ "$STATUS" =~ ^[23] ]]; then echo " ready (HTTP $STATUS)!"; break; fi
  echo -n "."
  [ $i -eq 20 ] && { echo " TIMEOUT (HTTP $STATUS)"; }
done

# ── 6. Verify ─────────────────────────────────────────────────────────────────
echo ""
echo "[6/6] Verifying..."
echo ""

echo "--- CORS OPTIONS preflight ---"
curl -si -X OPTIONS "${BACKEND}/api/v1/workspaces" \
  -H "Origin: ${FRONTEND}" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: authorization,content-type" \
  2>/dev/null | grep -E "HTTP/|access-control|Access-Control"

echo ""
echo "--- CORS on 401 (was the real blocker) ---"
curl -si "${BACKEND}/api/v1/workspaces" \
  -H "Origin: ${FRONTEND}" \
  2>/dev/null | grep -E "HTTP/|access-control|Access-Control"

echo ""
echo "--- Login test ---"
TOKEN=$(curl -sf -X POST "${BACKEND}/api/v1/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "Origin: ${FRONTEND}" \
  -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" \
  2>/dev/null | python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token','FAIL')[:20])")
echo "Token: ${TOKEN}..."

echo ""
echo "--- Create workspace test ---"
WS=$(curl -sf -X POST "${BACKEND}/api/v1/workspaces" \
  -H "Authorization: Bearer $(curl -s -X POST ${BACKEND}/api/v1/auth/login \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -d 'username=admin@blackmirror.io&password=BlackMirrorX2025!' | \
    python3 -c 'import sys,json; print(json.load(sys.stdin).get("access_token",""))')" \
  -H "Content-Type: application/json" \
  -H "Origin: ${FRONTEND}" \
  -d '{"name":"Fix Verification WS"}' 2>/dev/null)
WS_ID=$(echo "$WS" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id','FAIL')[:8])" 2>/dev/null)
echo "Workspace created: id=${WS_ID}"

echo ""
echo "=== DONE ==="
echo "Open browser: ${FRONTEND}"
echo "Login: admin@blackmirror.io / BlackMirrorX2025!"
echo ""
echo "If CORS errors are gone and workspace created above = app is working"
