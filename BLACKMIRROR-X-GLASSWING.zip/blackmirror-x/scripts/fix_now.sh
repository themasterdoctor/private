#!/usr/bin/env bash
# fix_now.sh - THE DEFINITIVE FIX
# Run from ~/private/blackmirror-x
# Fixes: asyncio bug, queue bug, CORS, recon crash, localhost fallback
set -e

echo ""
echo "================================================"
echo "  BLACKMIRROR-X — Complete Fix"
echo "================================================"

# Verify we're in the right place
[ -f docker-compose.yml ] || { echo "ERROR: Run from ~/private/blackmirror-x"; exit 1; }

# Step 1: .env
echo ""
echo "[1/5] Setting .env..."
[ -f .env ] || cp .env.vps .env
sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://76.13.30.226:3000,http://localhost:3000|" .env
sed -i "s|^NEXT_PUBLIC_API_URL=.*|NEXT_PUBLIC_API_URL=http://76.13.30.226:8000|" .env
sed -i "s|^NEXT_PUBLIC_WS_URL=.*|NEXT_PUBLIC_WS_URL=ws://76.13.30.226:8000|" .env
echo "  CORS_ORIGINS=http://76.13.30.226:3000,http://localhost:3000"
echo "  NEXT_PUBLIC_API_URL=http://76.13.30.226:8000"

# Step 2: Stop everything
echo ""
echo "[2/5] Stopping all containers..."
docker compose down --remove-orphans 2>/dev/null || true

# Step 3: Rebuild backend (fixes asyncio bug + queue bug + CORS)
echo ""
echo "[3/5] Rebuilding backend image (this takes ~10 min)..."
docker compose build --no-cache backend
echo "  Backend image rebuilt."

# Step 4: Start everything
echo ""
echo "[4/5] Starting all services..."
docker compose up -d

# Step 5: Wait and verify
echo ""
echo "[5/5] Waiting for services..."
for i in $(seq 1 40); do
  sleep 3
  if curl -sf http://localhost:8000/health >/dev/null 2>&1; then
    echo "  Backend healthy after $((i*3))s"
    break
  fi
  [ $((i % 5)) -eq 0 ] && echo "  Still waiting... (${i}/40)"
  [ $i -eq 40 ] && { echo "  FAILED - check: docker compose logs backend --tail=30"; exit 1; }
done

echo ""
echo "[verify] CORS check..."
CORS=$(curl -si -X OPTIONS http://localhost:8000/api/v1/workspaces \
  -H "Origin: http://76.13.30.226:3000" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: authorization,content-type" 2>/dev/null | \
  grep -i "access-control-allow-origin" | head -1 | tr -d '\r')
echo "  $CORS"

echo ""
echo "[verify] Login and create scan..."
TOKEN=$(curl -sf -X POST http://localhost:8000/api/v1/auth/login \
  -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" | \
  python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")
echo "  Login: OK"

WS=$(curl -sf -H "Authorization: Bearer $TOKEN" \
  http://localhost:8000/api/v1/workspaces | \
  python3 -c "import sys,json; print(json.load(sys.stdin)[0]['id'])")
echo "  Workspace: ${WS:0:8}..."

SCAN_RESP=$(curl -sf -X POST http://localhost:8000/api/v1/scans \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"name\":\"Fix Verify\",\"workspace_id\":\"$WS\",\"scan_type\":\"recon\",\"config\":{\"domain\":\"testphp.vulnweb.com\"}}")
SCAN_ID=$(echo "$SCAN_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
echo "  Scan created: ${SCAN_ID:0:8}... (status=queued)"

echo ""
echo "[verify] Worker picking up scan..."
sleep 15
STATUS=$(curl -sf -H "Authorization: Bearer $TOKEN" \
  "http://localhost:8000/api/v1/scans/$SCAN_ID" | \
  python3 -c "import sys,json; print(json.load(sys.stdin)['status'])" 2>/dev/null || echo "unknown")
echo "  Scan status after 15s: $STATUS"

echo ""
docker compose ps

echo ""
echo "================================================"
if [ "$STATUS" = "RUNNING" ] || [ "$STATUS" = "COMPLETED" ]; then
  echo "  ALL DONE — App is fully working!"
  echo ""
  echo "  URL:      http://76.13.30.226:3000"
  echo "  Login:    admin@blackmirror.io"
  echo "  Password: BlackMirrorX2025!"
  echo ""
  echo "  Watch scan progress:"
  echo "  docker compose logs worker -f"
else
  echo "  Scan status: $STATUS (expected RUNNING)"
  echo ""
  echo "  Worker logs:"
  docker compose logs worker --tail=20
fi
echo "================================================"
echo ""
