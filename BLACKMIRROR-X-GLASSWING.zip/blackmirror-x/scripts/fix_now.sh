#!/usr/bin/env bash
# fix_now.sh — Run from ~/private/blackmirror-x
# Fixes ALL bugs: asyncio, queue, CORS, localhost, recon crash
set -e
cd "$(dirname "$0")/.."
[ -f docker-compose.yml ] || { echo "ERROR: Run from ~/private/blackmirror-x"; exit 1; }

echo ""
echo "================================================"
echo "  BLACKMIRROR-X — Complete Fix"
echo "================================================"

echo "[1/6] Fix .env..."
[ -f .env ] || cp .env.vps .env
sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://76.13.30.226:3000,http://localhost:3000|" .env
sed -i "s|^NEXT_PUBLIC_API_URL=.*|NEXT_PUBLIC_API_URL=http://76.13.30.226:8000|" .env
sed -i "s|^NEXT_PUBLIC_WS_URL=.*|NEXT_PUBLIC_WS_URL=ws://76.13.30.226:8000|" .env
grep "CORS_ORIGINS\|NEXT_PUBLIC_API_URL" .env

echo ""
echo "[2/6] Stop all containers..."
docker compose down --remove-orphans 2>/dev/null || true

echo ""
echo "[3/6] Build backend AND worker (separate images, both need rebuild)..."
docker compose build --no-cache backend worker
echo "  Done."

echo ""
echo "[4/6] Start all services..."
docker compose up -d

echo ""
echo "[5/6] Wait for backend health..."
for i in $(seq 1 40); do
  sleep 3
  curl -sf http://localhost:8000/health >/dev/null 2>&1 && { echo "  Healthy after $((i*3))s"; break; }
  [ $((i%5)) -eq 0 ] && echo "  Waiting ${i}/40..."
  [ $i -eq 40 ] && { echo "FAILED"; docker compose logs backend --tail=20; exit 1; }
done

echo ""
echo "[6/6] Verify..."

echo -n "  CORS: "
curl -si -X OPTIONS http://localhost:8000/api/v1/workspaces \
  -H "Origin: http://76.13.30.226:3000" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: authorization,content-type" 2>/dev/null | \
  grep -i "access-control-allow-origin" | head -1 | tr -d '\r'

TOKEN=$(curl -sf -X POST http://localhost:8000/api/v1/auth/login \
  -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" | \
  python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")
echo "  Login: OK"

WS=$(curl -sf -H "Authorization: Bearer $TOKEN" http://localhost:8000/api/v1/workspaces | \
  python3 -c "import sys,json; print(json.load(sys.stdin)[0]['id'])")
echo "  Workspace: ${WS:0:8}..."

SCAN=$(curl -sf -X POST http://localhost:8000/api/v1/scans \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"name\":\"Verify\",\"workspace_id\":\"$WS\",\"scan_type\":\"recon\",\"config\":{\"domain\":\"testphp.vulnweb.com\"}}" | \
  python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
echo "  Scan: ${SCAN:0:8}... (queued)"

echo "  Waiting 20s for worker..."
sleep 20

STATUS=$(curl -sf -H "Authorization: Bearer $TOKEN" \
  "http://localhost:8000/api/v1/scans/$SCAN" | \
  python3 -c "import sys,json; print(json.load(sys.stdin)['status'])" 2>/dev/null || echo "unknown")
echo "  Scan status: $STATUS"

echo ""
docker compose ps
echo ""
echo "================================================"

if [ "$STATUS" = "RUNNING" ] || [ "$STATUS" = "COMPLETED" ]; then
  echo "  SUCCESS — Scans are running!"
  echo "  Open: http://76.13.30.226:3000"
  echo "  Login: admin@blackmirror.io / BlackMirrorX2025!"
else
  echo "  Worker logs:"
  docker compose logs worker --tail=20
fi
echo "================================================"
