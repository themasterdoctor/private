#!/usr/bin/env bash
# verify_full_stack.sh — BLACKMIRROR-X GLASSWING live stack verification
# Usage: bash scripts/verify_full_stack.sh
# Requires: running backend on localhost:8000 and localhost:3000 (or Docker stack)
set -uo pipefail

PASS=0; FAIL=0; SKIP=0
BACKEND="${BACKEND_URL:-http://localhost:8000}"
FRONTEND="${FRONTEND_URL:-http://localhost:3000}"

ok()   { echo "  ✓  $1"; PASS=$((PASS+1)); }
fail() { echo "  ✗  $1  ($2)"; FAIL=$((FAIL+1)); }
skip() { echo "  ○  $1 (skipped — $2)"; SKIP=$((SKIP+1)); }

echo ""
echo "════════════════════════════════════════════════════════════"
echo "  BLACKMIRROR-X GLASSWING — Full Stack Verification"
echo "  $(date)"
echo "  Backend:  $BACKEND"
echo "  Frontend: $FRONTEND"
echo "════════════════════════════════════════════════════════════"

# ── 1. Backend Health ─────────────────────────────────────────
echo ""
echo "── 1. Backend Health ────────────────────────────────────────"
HEALTH=$(curl -s -m 5 "$BACKEND/health" 2>/dev/null || echo "")
if echo "$HEALTH" | grep -q '"healthy"'; then
  ok "GET /health → {status:healthy}"
else
  fail "GET /health" "got: ${HEALTH:-connection refused}"
  echo ""
  echo "  Backend is not running. Start it first:"
  echo "    docker-compose up -d    OR"
  echo "    cd backend && uvicorn app.main:app --port 8000"
  echo ""
fi

# ── 2. Frontend Health ────────────────────────────────────────
echo ""
echo "── 2. Frontend Health ───────────────────────────────────────"
HTTP_CODE=$(curl -s -m 5 -o /dev/null -w "%{http_code}" "$FRONTEND" 2>/dev/null); HTTP_CODE="${HTTP_CODE:-000}"
if [ "$HTTP_CODE" != "000" ] && [ "$HTTP_CODE" -lt 500 ]; then
  ok "Frontend responding: HTTP $HTTP_CODE"
elif [ "$HTTP_CODE" = "000" ]; then
  skip "Frontend" "not running — start with: cd frontend && npm start (or docker-compose up frontend)"
else
  fail "Frontend not responding" "HTTP $HTTP_CODE"
fi

# ── 3. OpenAPI / Routes ──────────────────────────────────────
echo ""
echo "── 3. Routes ────────────────────────────────────────────────"
SCHEMA=$(curl -s -m 5 "$BACKEND/api/openapi.json" 2>/dev/null || echo "{}")
NROUTES=$(echo "$SCHEMA" | python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d.get('paths',{})))" 2>/dev/null || echo "0")
NINTEL=$(echo "$SCHEMA" | python3 -c "import sys,json; d=json.load(sys.stdin); print(sum(1 for p in d.get('paths',{}) if 'intel' in p))" 2>/dev/null || echo "0")
[ "$NROUTES" -ge 30 ] && ok "OpenAPI: $NROUTES routes registered" || fail "OpenAPI routes" "got $NROUTES, expected ≥30"
[ "$NINTEL" -ge 11 ]  && ok "Intel routes: $NINTEL registered (≥11)" || fail "Intel routes" "got $NINTEL, expected ≥11"

# ── 4. Database ───────────────────────────────────────────────
echo ""
echo "── 4. Database ──────────────────────────────────────────────"
DB_HOST="${POSTGRES_HOST:-127.0.0.1}"
DB_PORT="${POSTGRES_PORT:-5432}"
if command -v pg_isready &>/dev/null; then
  if pg_isready -h "$DB_HOST" -p "$DB_PORT" -q 2>/dev/null; then
    ok "PostgreSQL accepting connections on $DB_HOST:$DB_PORT"
    # Count tables via psql
    if command -v psql &>/dev/null; then
      NTABLES=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "${POSTGRES_USER:-bmx}" -d "${POSTGRES_DB:-blackmirror}" \
        -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public';" 2>/dev/null | tr -d ' ' || echo "0")
      [ "$NTABLES" -ge 20 ] && ok "PostgreSQL: $NTABLES tables migrated" || fail "Tables" "got $NTABLES, expected ≥20 — run: alembic upgrade head"
    else
      skip "Table count" "psql not found"
    fi
  else
    fail "PostgreSQL" "not accepting connections on $DB_HOST:$DB_PORT"
  fi
else
  skip "PostgreSQL check" "pg_isready not found — checking via API instead"
fi

# ── 5. Redis ──────────────────────────────────────────────────
echo ""
echo "── 5. Redis ─────────────────────────────────────────────────"
REDIS_HOST="${REDIS_HOST:-127.0.0.1}"
if command -v redis-cli &>/dev/null; then
  PONG=$(redis-cli -h "$REDIS_HOST" ping 2>/dev/null || echo "")
  [ "$PONG" = "PONG" ] && ok "Redis: PONG" || fail "Redis" "no PONG from $REDIS_HOST:6379"
else
  skip "Redis direct check" "redis-cli not found"
fi

# ── 6. Authentication ─────────────────────────────────────────
echo ""
echo "── 6. Authentication ────────────────────────────────────────"
BASE="$BACKEND/api/v1"

# Protected routes should return 401
for path in "/workspaces" "/scans?workspace_id=x" "/vulns?workspace_id=x"; do
  CODE=$(curl -s -m 5 -o /dev/null -w "%{http_code}" "$BASE$path" 2>/dev/null || echo "000")
  ROUTE="${path%%\?*}"
  [ "$CODE" = "401" ] && ok "GET $ROUTE → 401 (no token)" || fail "GET $ROUTE no-auth" "HTTP $CODE, expected 401"
done

# Login with demo credentials
LOGIN_RESP=$(curl -s -m 10 -X POST "$BASE/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" 2>/dev/null || echo "{}")
TOKEN=$(echo "$LOGIN_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))" 2>/dev/null || echo "")
[ -n "$TOKEN" ] && ok "POST /auth/login → JWT token" || fail "POST /auth/login" "no token — seed data may be missing"

# Wrong password
WRONG=$(curl -s -m 5 -o /dev/null -w "%{http_code}" -X POST "$BASE/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin@blackmirror.io&password=wrong" 2>/dev/null || echo "000")
[ "$WRONG" = "401" ] || [ "$WRONG" = "400" ] && ok "Wrong password → 401/400" || fail "Wrong password" "HTTP $WRONG"

# Bad JWT
BAD_CODE=$(curl -s -m 5 -o /dev/null -w "%{http_code}" \
  -H "Authorization: Bearer not.a.real.jwt" "$BASE/auth/me" 2>/dev/null || echo "000")
[ "$BAD_CODE" = "401" ] || [ "$BAD_CODE" = "422" ] && ok "Bad JWT → 401/422" || fail "Bad JWT" "HTTP $BAD_CODE"

# ── 7. Seed Data ──────────────────────────────────────────────
echo ""
echo "── 7. Seed Data ─────────────────────────────────────────────"
if [ -n "$TOKEN" ]; then
  WS=$(curl -s -m 5 -H "Authorization: Bearer $TOKEN" "$BASE/workspaces" 2>/dev/null || echo "[]")
  WS_COUNT=$(echo "$WS" | python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d) if isinstance(d,list) else 0)" 2>/dev/null || echo "0")
  [ "$WS_COUNT" -ge 1 ] && ok "Workspaces: $WS_COUNT found" || fail "Workspaces" "0 found — run: python scripts/seed.py"

  WS_ID=$(echo "$WS" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d[0]['id'] if d and isinstance(d,list) else '')" 2>/dev/null || echo "")
  if [ -n "$WS_ID" ]; then
    VULNS=$(curl -s -m 5 -H "Authorization: Bearer $TOKEN" "$BASE/vulns?workspace_id=$WS_ID" 2>/dev/null || echo "[]")
    NVULNS=$(echo "$VULNS" | python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d) if isinstance(d,list) else 0)" 2>/dev/null || echo "0")
    [ "$NVULNS" -ge 8 ] && ok "Vulnerabilities: $NVULNS seeded" || fail "Vulnerabilities" "$NVULNS found, expected ≥8"

    SUBS=$(curl -s -m 5 -H "Authorization: Bearer $TOKEN" "$BASE/recon/subdomains?workspace_id=$WS_ID" 2>/dev/null || echo "[]")
    NSUBS=$(echo "$SUBS" | python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d) if isinstance(d,list) else 0)" 2>/dev/null || echo "0")
    [ "$NSUBS" -ge 3 ] && ok "Subdomains: $NSUBS seeded" || fail "Subdomains" "$NSUBS found, expected ≥3"
  fi
else
  skip "Seed data check" "no auth token"
fi

# ── 8. Intelligence Layer ─────────────────────────────────────
echo ""
echo "── 8. Intelligence Layer ────────────────────────────────────"
if [ -n "$TOKEN" ]; then
  # Payloads
  PL=$(curl -s -m 5 -H "Authorization: Bearer $TOKEN" "$BASE/intel/payloads/xss?context=html_text" 2>/dev/null || echo "{}")
  NP=$(echo "$PL" | python3 -c "import sys,json; d=json.load(sys.stdin); print(len(d.get('payloads',[])))" 2>/dev/null || echo "0")
  [ "$NP" -ge 5 ] && ok "GET /intel/payloads/xss → $NP payloads" || fail "Intel payloads" "$NP payloads"

  # Metrics
  METRICS=$(curl -s -m 5 "$BASE/intel/metrics" 2>/dev/null || echo "")
  [ -n "$METRICS" ] && ok "GET /intel/metrics → Prometheus data" || fail "Intel metrics" "empty response"

  # Memory
  if [ -n "$WS_ID" ]; then
    MEM_CODE=$(curl -s -m 5 -o /dev/null -w "%{http_code}" \
      -H "Authorization: Bearer $TOKEN" "$BASE/intel/memory/$WS_ID" 2>/dev/null || echo "000")
    [ "$MEM_CODE" = "200" ] && ok "GET /intel/memory → 200" || fail "Intel memory" "HTTP $MEM_CODE"
  fi

  # Court adjudicate (requires vuln_id from seed)
  if [ -n "$WS_ID" ]; then
    VULN_ID=$(curl -s -m 5 -H "Authorization: Bearer $TOKEN" "$BASE/vulns?workspace_id=$WS_ID" 2>/dev/null | \
      python3 -c "import sys,json; d=json.load(sys.stdin); print(d[0]['id'] if d and isinstance(d,list) else '')" 2>/dev/null || echo "")
    if [ -n "$VULN_ID" ]; then
      COURT_CODE=$(curl -s -m 15 -o /dev/null -w "%{http_code}" -X POST \
        -H "Authorization: Bearer $TOKEN" "$BASE/intel/court/adjudicate/$VULN_ID" 2>/dev/null || echo "000")
      [ "$COURT_CODE" = "200" ] && ok "POST /intel/court/adjudicate → 200" || fail "Court adjudicate" "HTTP $COURT_CODE"

      SIM_CODE=$(curl -s -m 15 -o /dev/null -w "%{http_code}" -X POST \
        -H "Authorization: Bearer $TOKEN" "$BASE/intel/simulate/$VULN_ID" 2>/dev/null || echo "000")
      [ "$SIM_CODE" = "200" ] && ok "POST /intel/simulate → 200" || fail "Exploitability simulate" "HTTP $SIM_CODE"
    fi
  fi
else
  skip "Intelligence layer" "no auth token"
fi

# ── 9. Scan Job Creation ──────────────────────────────────────
echo ""
echo "── 9. Scan Job Creation ─────────────────────────────────────"
if [ -n "$TOKEN" ] && [ -n "$WS_ID" ]; then
  SCAN_BODY="{\"workspace_id\":\"$WS_ID\",\"target\":\"verify.local\",\"scan_type\":\"recon\",\"name\":\"Verify Test Scan\"}"
  SCAN_RESP=$(curl -s -m 10 -X POST "$BASE/scans" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer $TOKEN" \
    -d "$SCAN_BODY" 2>/dev/null || echo "{}")
  SCAN_ID=$(echo "$SCAN_RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('id',''))" 2>/dev/null || echo "")
  [ -n "$SCAN_ID" ] && ok "POST /scans → scan created (id=${SCAN_ID:0:8}...)" || fail "Scan creation" "$(echo $SCAN_RESP | head -c 100)"
else
  skip "Scan job creation" "no auth token or workspace"
fi

# ── 10. Report Generation ─────────────────────────────────────
echo ""
echo "── 10. Report Generation ────────────────────────────────────"
if [ -n "$TOKEN" ] && [ -n "$WS_ID" ]; then
  SCANS=$(curl -s -m 5 -H "Authorization: Bearer $TOKEN" "$BASE/scans?workspace_id=$WS_ID" 2>/dev/null || echo "[]")
  SCAN_ID=$(echo "$SCANS" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d[0]['id'] if d and isinstance(d,list) else '')" 2>/dev/null || echo "")
  if [ -n "$SCAN_ID" ]; then
    RPT_CODE=$(curl -s -m 15 -o /dev/null -w "%{http_code}" -X POST \
      -H "Authorization: Bearer $TOKEN" "$BASE/reports/generate/$SCAN_ID" 2>/dev/null || echo "000")
    [ "$RPT_CODE" = "200" ] || [ "$RPT_CODE" = "201" ] || [ "$RPT_CODE" = "202" ] && ok "POST /reports/generate → $RPT_CODE" || fail "Report generation" "HTTP $RPT_CODE"
  else
    skip "Report generation" "no scan found"
  fi
else
  skip "Report generation" "no auth"
fi

# ── Summary ───────────────────────────────────────────────────
echo ""
echo "════════════════════════════════════════════════════════════"
echo "  RESULTS: $PASS passed  |  $FAIL failed  |  $SKIP skipped"
echo ""
if [ $FAIL -eq 0 ]; then
  echo "  ✅ ALL CHECKS PASSED"
  echo ""
  echo "  Frontend:   $FRONTEND"
  echo "  Backend:    $BACKEND"
  echo "  API Docs:   $BACKEND/api/docs"
  echo "  Prometheus: http://localhost:9090"
  echo "  Grafana:    http://localhost:3001"
  echo ""
  echo "  Login: admin@blackmirror.io / BlackMirrorX2025!"
else
  echo "  ❌ $FAIL CHECKS FAILED — see above for details"
  echo "  Run: docker-compose logs backend --tail=50"
  echo "  See: TROUBLESHOOTING.md"
fi
echo "════════════════════════════════════════════════════════════"
echo ""
[ $FAIL -eq 0 ] && exit 0 || exit 1
