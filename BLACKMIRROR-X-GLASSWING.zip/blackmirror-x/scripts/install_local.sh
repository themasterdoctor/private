#!/usr/bin/env bash
# install_local.sh — BLACKMIRROR-X local installation script
# Usage: bash scripts/install_local.sh
# Correct flow:
#   1. Preflight checks
#   2. .env setup + secret generation (sed only, no Python heredoc)
#   3. docker compose down -v  (clean slate)
#   4. docker compose build --no-cache
#   5. docker compose up -d postgres redis  (infra first)
#   6. docker compose up -d backend worker  (wait until /health → healthy)
#   7. alembic upgrade head
#   8. python scripts/seed.py
#   9. docker compose up -d frontend  (after backend confirmed healthy)
#   10. docker compose ps + summary
set -uo pipefail

PASS=0; FAIL=0; WARN=0
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
RED='\033[0;31m'; WHITE='\033[1;37m'; NC='\033[0m'

ok()   { echo -e "  ${GREEN}✓${NC}  $1"; PASS=$((PASS+1)); }
fail() { echo -e "  ${RED}✗${NC}  $1"; FAIL=$((FAIL+1)); }
warn() { echo -e "  ${YELLOW}⚠${NC}  $1"; WARN=$((WARN+1)); }
info() { echo -e "  ${CYAN}→${NC}  $1"; }
die()  { echo -e "\n  ${RED}✗ FATAL: $1${NC}\n"; exit 1; }

echo ""
echo -e "${WHITE}════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}  BLACKMIRROR-X GLASSWING — Local Install${NC}"
echo -e "${WHITE}════════════════════════════════════════════════════════════${NC}"
echo ""

# ── 1. Preflight ──────────────────────────────────────────────────────────────
echo "── 1. Preflight Checks ──────────────────────────────────────"

command -v docker &>/dev/null \
  && ok "Docker: $(docker --version 2>&1 | head -1)" \
  || die "Docker not found — install from https://docs.docker.com/get-docker/"

if command -v docker-compose &>/dev/null; then
  COMPOSE="docker-compose"
elif docker compose version &>/dev/null 2>&1; then
  COMPOSE="docker compose"
else
  die "Docker Compose not found"
fi
ok "Docker Compose: $COMPOSE"

command -v python3 &>/dev/null && ok "Python: $(python3 --version 2>&1)" || warn "python3 not found"
command -v node    &>/dev/null && ok "Node.js: $(node --version)"         || warn "node not found"
command -v curl    &>/dev/null && ok "curl available"                      || die "curl not found"

# ── 2. Environment setup ──────────────────────────────────────────────────────
echo ""
echo "── 2. Environment Setup ─────────────────────────────────────"
cd "$ROOT"

if [ ! -f ".env" ]; then
  cp .env.example .env
  ok "Copied .env.example → .env"
else
  ok ".env already exists"
fi

# Generate secrets using sed only — no Python heredoc
SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))" 2>/dev/null \
         || openssl rand -hex 32 2>/dev/null \
         || head -c 32 /dev/urandom | xxd -p | tr -d '\n')
JWT=$(python3 -c "import secrets; print(secrets.token_hex(32))" 2>/dev/null \
      || openssl rand -hex 32 2>/dev/null \
      || head -c 32 /dev/urandom | xxd -p | tr -d '\n')

sed -i "s|^SECRET_KEY=.*|SECRET_KEY=${SECRET}|"         .env
sed -i "s|^JWT_SECRET_KEY=.*|JWT_SECRET_KEY=${JWT}|"    .env
ok "Fresh secrets written to .env"

# Also update docker-compose.yml NEXT_PUBLIC_API_URL if SERVER_IP is set
if [ -n "${SERVER_IP:-}" ]; then
  sed -i "s|^NEXT_PUBLIC_API_URL=.*|NEXT_PUBLIC_API_URL=http://${SERVER_IP}:8000|" .env
  sed -i "s|^NEXT_PUBLIC_WS_URL=.*|NEXT_PUBLIC_WS_URL=ws://${SERVER_IP}:8000|"    .env
  ok "API URL set to http://${SERVER_IP}:8000"
else
  info "Tip: set SERVER_IP=your.ip before running for remote deployments"
fi

# ── 3. Clean slate ────────────────────────────────────────────────────────────
echo ""
echo "── 3. Clean Slate ───────────────────────────────────────────"
info "Removing old containers and volumes (data will be re-seeded)..."
$COMPOSE down -v --remove-orphans 2>&1 | tail -2
ok "Old stack removed"

# ── 4. Build ──────────────────────────────────────────────────────────────────
echo ""
echo "── 4. Docker Build (may take 2–5 min on first run) ─────────"
info "Building all images..."
$COMPOSE build --no-cache 2>&1 | grep -E "FINISHED|Built|ERROR|error" | tail -5
[ ${PIPESTATUS[0]} -eq 0 ] || die "Docker build failed — run: $COMPOSE build for details"
ok "All images built"

# ── 5. Start infrastructure (postgres + redis) ────────────────────────────────
echo ""
echo "── 5. Starting Infrastructure ───────────────────────────────"
$COMPOSE up -d postgres redis 2>&1 | tail -2

info "Waiting for PostgreSQL to be healthy..."
for i in $(seq 1 30); do
  STATUS=$($COMPOSE ps postgres 2>/dev/null | grep -c "healthy" || echo "0")
  [ "$STATUS" -ge 1 ] && break
  sleep 2
  [ "$i" -eq 30 ] && die "PostgreSQL failed to become healthy after 60s"
done
ok "PostgreSQL healthy"

info "Waiting for Redis to be healthy..."
for i in $(seq 1 15); do
  STATUS=$($COMPOSE ps redis 2>/dev/null | grep -c "healthy" || echo "0")
  [ "$STATUS" -ge 1 ] && break
  sleep 2
  [ "$i" -eq 15 ] && die "Redis failed to become healthy after 30s"
done
ok "Redis healthy"

# ── 6. Start backend + worker ─────────────────────────────────────────────────
echo ""
echo "── 6. Starting Backend ──────────────────────────────────────"
$COMPOSE up -d backend worker 2>&1 | tail -2

info "Waiting for backend /health endpoint (up to 60s)..."
HEALTHY=false
for i in $(seq 1 30); do
  sleep 2
  CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/health 2>/dev/null || echo "0")
  if [ "$CODE" = "200" ]; then
    HEALTHY=true
    ok "Backend healthy after $((i*2))s  →  http://localhost:8000"
    break
  fi
done
[ "$HEALTHY" = "true" ] || die "Backend did not become healthy — run: $COMPOSE logs backend"

# ── 7. Database migrations ────────────────────────────────────────────────────
echo ""
echo "── 7. Database Migrations ───────────────────────────────────"
info "Running alembic upgrade head..."
$COMPOSE exec -T backend alembic upgrade head 2>&1 | tail -3
[ ${PIPESTATUS[0]} -eq 0 ] && ok "Migrations applied" || fail "Migration failed — check: $COMPOSE logs backend"

# ── 8. Seed demo data ─────────────────────────────────────────────────────────
echo ""
echo "── 8. Seeding Demo Data ─────────────────────────────────────"
info "Seeding demo workspace, vulnerabilities, and subdomains..."
$COMPOSE exec -T backend python scripts/seed.py 2>&1
[ ${PIPESTATUS[0]} -eq 0 ] && ok "Demo data seeded" || warn "Seed may have already run (not an error)"

# ── 9. Start frontend ─────────────────────────────────────────────────────────
echo ""
echo "── 9. Starting Frontend ─────────────────────────────────────"
$COMPOSE up -d frontend 2>&1 | tail -2

info "Waiting for frontend (up to 30s)..."
for i in $(seq 1 15); do
  sleep 2
  CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null || echo "0")
  if [ "$CODE" != "0" ]; then
    ok "Frontend responding  →  http://localhost:3000"
    break
  fi
  [ "$i" -eq 15 ] && warn "Frontend slow to start — check: $COMPOSE logs frontend"
done

# ── 10. Optional tools check ──────────────────────────────────────────────────
echo ""
echo "── 10. Security Tools (optional) ───────────────────────────"
for tool in subfinder httpx nuclei katana amass; do
  command -v "$tool" &>/dev/null \
    && ok "$tool: $(command -v "$tool")" \
    || warn "$tool not found  (passive mode only without it)"
done

# ── 11. Final status ──────────────────────────────────────────────────────────
echo ""
echo "── 11. Container Status ─────────────────────────────────────"
$COMPOSE ps 2>&1 | tail -20

# Verify health one more time
BACKEND_UP=$(curl -s http://localhost:8000/health 2>/dev/null | grep -c "healthy" || echo "0")
FRONTEND_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null || echo "0")

echo ""
echo -e "${WHITE}════════════════════════════════════════════════════════════${NC}"
if [ "$BACKEND_UP" -ge 1 ]; then
  echo -e "  ${GREEN}✅ BLACKMIRROR-X installed and running${NC}"
else
  echo -e "  ${YELLOW}⚠  Install complete but backend health check failed${NC}"
  echo -e "  ${CYAN}   Run: $COMPOSE logs backend${NC}"
fi
echo ""
echo -e "  ${CYAN}Dashboard:${NC}  http://localhost:3000"
echo -e "  ${CYAN}Backend:${NC}    http://localhost:8000"
echo -e "  ${CYAN}API Docs:${NC}   http://localhost:8000/api/docs"
echo -e "  ${CYAN}Grafana:${NC}    http://localhost:3001"
echo ""
echo -e "  ${WHITE}Login:${NC}"
echo -e "  ${CYAN}Email:${NC}    admin@blackmirror.io"
echo -e "  ${CYAN}Password:${NC} BlackMirrorX2025!"
echo ""
echo -e "  ${YELLOW}Run demo:${NC}  bash scripts/demo_run.sh"
echo -e "${WHITE}════════════════════════════════════════════════════════════${NC}"
echo ""

[ $FAIL -eq 0 ]
