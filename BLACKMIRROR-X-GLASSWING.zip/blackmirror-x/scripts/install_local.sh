#!/usr/bin/env bash
# install_local.sh — BLACKMIRROR-X complete installer
# Usage:
#   bash scripts/install_local.sh                    # local install
#   SERVER_IP=1.2.3.4 bash scripts/install_local.sh # remote server
set -euo pipefail

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
RED='\033[0;31m'; WHITE='\033[1;37m'; NC='\033[0m'
ok()   { echo -e "  ${GREEN}✓${NC}  $1"; }
fail() { echo -e "  ${RED}✗${NC}  $1"; exit 1; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $1"; }
info() { echo -e "  ${CYAN}→${NC}  $1"; }

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo ""
echo -e "${WHITE}════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}  BLACKMIRROR-X GLASSWING — Installer${NC}"
echo -e "${WHITE}════════════════════════════════════════════════════════${NC}"
echo ""

# ── 1. Check Docker ───────────────────────────────────────────────────────────
echo "── 1. Checking requirements ─────────────────────────────"
command -v docker &>/dev/null || fail "Docker not found. Install: https://docs.docker.com/get-docker/"
ok "Docker: $(docker --version | head -1)"

if docker compose version &>/dev/null 2>&1; then
  COMPOSE="docker compose"
elif command -v docker-compose &>/dev/null; then
  COMPOSE="docker-compose"
else
  fail "Docker Compose not found"
fi
ok "Docker Compose: $COMPOSE"

# ── 2. Create .env ────────────────────────────────────────────────────────────
echo ""
echo "── 2. Environment setup ─────────────────────────────────"

if [ ! -f ".env" ]; then
  cp .env.example .env
  ok "Created .env from .env.example"
else
  ok ".env already exists"
fi

# Generate real secrets (sed only, no Python heredoc)
SECRET=$(openssl rand -hex 32 2>/dev/null || python3 -c "import secrets; print(secrets.token_hex(32))")
JWT=$(openssl rand -hex 32 2>/dev/null || python3 -c "import secrets; print(secrets.token_hex(32))")
sed -i "s|^SECRET_KEY=.*|SECRET_KEY=${SECRET}|" .env
sed -i "s|^JWT_SECRET_KEY=.*|JWT_SECRET_KEY=${JWT}|" .env
ok "Secrets generated"

# Set server IP — use SERVER_IP env var or detect
if [ -n "${SERVER_IP:-}" ]; then
  info "Using SERVER_IP=${SERVER_IP}"
else
  # Try to detect public IP
  SERVER_IP=$(curl -s --max-time 3 https://api.ipify.org 2>/dev/null || echo "localhost")
  info "Detected IP: ${SERVER_IP} (set SERVER_IP=x.x.x.x to override)"
fi

sed -i "s|^NEXT_PUBLIC_API_URL=.*|NEXT_PUBLIC_API_URL=http://${SERVER_IP}:8000|" .env
sed -i "s|^NEXT_PUBLIC_WS_URL=.*|NEXT_PUBLIC_WS_URL=ws://${SERVER_IP}:8000|" .env
sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000|" .env
ok "API URL set to http://${SERVER_IP}:8000"

# ── 3. Clean slate ────────────────────────────────────────────────────────────
echo ""
echo "── 3. Removing old containers and volumes ───────────────"
$COMPOSE down -v --remove-orphans 2>&1 | tail -2
ok "Old stack removed"

# ── 4. Build all images ───────────────────────────────────────────────────────
echo ""
echo "── 4. Building images (5-15 min on first run) ───────────"
info "Building backend + worker (Go tools + Python deps)..."
$COMPOSE build --no-cache backend worker 2>&1 | grep -E "FINISHED|ERROR|error" | tail -3

info "Building frontend with API URL baked in..."
$COMPOSE build --no-cache frontend 2>&1 | grep -E "FINISHED|ERROR|error" | tail -3
ok "All images built"

# ── 5. Start postgres + redis ─────────────────────────────────────────────────
echo ""
echo "── 5. Starting database and cache ───────────────────────"
$COMPOSE up -d postgres redis

info "Waiting for PostgreSQL..."
for i in $(seq 1 30); do
  $COMPOSE exec -T postgres pg_isready -U bmx -d blackmirror -q 2>/dev/null && break
  sleep 2
  [ "$i" -eq 30 ] && fail "PostgreSQL did not become healthy"
done
ok "PostgreSQL healthy"

info "Waiting for Redis..."
for i in $(seq 1 15); do
  $COMPOSE exec -T redis redis-cli ping 2>/dev/null | grep -q PONG && break
  sleep 2
  [ "$i" -eq 15 ] && fail "Redis did not become healthy"
done
ok "Redis healthy"

# ── 6. Start backend + worker ─────────────────────────────────────────────────
echo ""
echo "── 6. Starting backend ──────────────────────────────────"
$COMPOSE up -d backend worker

info "Waiting for backend (runs migrations + seed, up to 3 min)..."
for i in $(seq 1 60); do
  sleep 3
  CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/health 2>/dev/null || echo "0")
  if [ "$CODE" = "200" ]; then
    ok "Backend healthy after $((i*3))s"
    break
  fi
  [ "$i" -eq 60 ] && { $COMPOSE logs backend --tail=20; fail "Backend did not start"; }
done

# ── 7. Start frontend ─────────────────────────────────────────────────────────
echo ""
echo "── 7. Starting frontend ─────────────────────────────────"
$COMPOSE up -d frontend

info "Waiting for frontend..."
for i in $(seq 1 20); do
  sleep 3
  CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000 2>/dev/null || echo "0")
  [ "$CODE" != "0" ] && ok "Frontend responding" && break
  [ "$i" -eq 20 ] && warn "Frontend slow — check: $COMPOSE logs frontend"
done

# ── 8. Start monitoring (optional) ────────────────────────────────────────────
$COMPOSE up -d prometheus grafana flower 2>/dev/null || true

# ── 9. Summary ────────────────────────────────────────────────────────────────
echo ""
echo -e "${WHITE}════════════════════════════════════════════════════════${NC}"
echo -e "  ${GREEN}✅ BLACKMIRROR-X is running${NC}"
echo ""
echo -e "  ${WHITE}Dashboard:${NC}    http://${SERVER_IP}:3000"
echo -e "  ${WHITE}API Docs:${NC}     http://${SERVER_IP}:8000/api/docs"
echo -e "  ${WHITE}Grafana:${NC}      http://${SERVER_IP}:3001"
echo ""
echo -e "  ${WHITE}Login:${NC}"
echo -e "  ${CYAN}Email:${NC}    admin@blackmirror.io"
echo -e "  ${CYAN}Password:${NC} BlackMirrorX2025!"
echo ""
echo -e "  ${YELLOW}To set Anthropic API key:${NC}"
echo -e "  ${CYAN}  echo 'ANTHROPIC_API_KEY=sk-ant-...' >> .env${NC}"
echo -e "  ${CYAN}  $COMPOSE restart backend worker${NC}"
echo -e "${WHITE}════════════════════════════════════════════════════════${NC}"
echo ""
