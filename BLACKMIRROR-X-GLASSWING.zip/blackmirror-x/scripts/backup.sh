#!/usr/bin/env bash
# scripts/backup.sh — BLACKMIRROR-X database backup
# Usage: bash scripts/backup.sh [output_dir]
# Creates: blackmirror_YYYY-MM-DD_HH-MM-SS.sql.gz

set -euo pipefail

BACKUP_DIR="${1:-./backups}"
TIMESTAMP=$(date +%Y-%m-%d_%H-%M-%S)
FILENAME="blackmirror_${TIMESTAMP}.sql.gz"
FULL_PATH="${BACKUP_DIR}/${FILENAME}"

# Load env
if [ -f .env ]; then
  export $(grep -v '^#' .env | grep -v '^$' | xargs) 2>/dev/null || true
fi

DB_HOST="${POSTGRES_HOST:-127.0.0.1}"
DB_PORT="${POSTGRES_PORT:-5432}"
DB_NAME="${POSTGRES_DB:-blackmirror}"
DB_USER="${POSTGRES_USER:-bmx}"
DB_PASS="${POSTGRES_PASSWORD:-bmxsecret2025}"

mkdir -p "$BACKUP_DIR"

echo "════════════════════════════════════════"
echo "  BLACKMIRROR-X Backup"
echo "  Target: ${DB_HOST}:${DB_PORT}/${DB_NAME}"
echo "  Output: ${FULL_PATH}"
echo "════════════════════════════════════════"

# Check pg_dump availability
if ! command -v pg_dump &>/dev/null; then
  # Try via Docker
  if command -v docker &>/dev/null; then
    echo "Using Docker pg_dump..."
    docker-compose exec -T postgres pg_dump \
      -U "$DB_USER" "$DB_NAME" | gzip > "$FULL_PATH"
  else
    echo "ERROR: pg_dump not found and Docker unavailable"
    exit 1
  fi
else
  PGPASSWORD="$DB_PASS" pg_dump \
    -h "$DB_HOST" -p "$DB_PORT" \
    -U "$DB_USER" "$DB_NAME" \
    --no-password \
    | gzip > "$FULL_PATH"
fi

SIZE=$(du -sh "$FULL_PATH" | cut -f1)
echo ""
echo "✓ Backup complete: ${FILENAME} (${SIZE})"
echo ""

# Keep only last 10 backups
cd "$BACKUP_DIR"
BACKUP_COUNT=$(ls -1 blackmirror_*.sql.gz 2>/dev/null | wc -l)
if [ "$BACKUP_COUNT" -gt 10 ]; then
  echo "Pruning old backups (keeping 10 most recent)..."
  ls -1t blackmirror_*.sql.gz | tail -n +11 | xargs rm -f
  echo "✓ Pruned $(( BACKUP_COUNT - 10 )) old backups"
fi
