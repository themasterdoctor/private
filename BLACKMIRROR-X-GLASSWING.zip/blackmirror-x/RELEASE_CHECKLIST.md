# RELEASE_CHECKLIST — BLACKMIRROR-X GLASSWING

## Pre-Release Checklist

### Build Checks
- [ ] `python -m compileall app -q` — 0 syntax errors
- [ ] `pytest tests/test_full_stack.py` — all tests pass
- [ ] `npm run build` — compiled successfully, 0 TypeScript errors
- [ ] `bash scripts/verify_full_stack.sh` — 22/22 pass, 0 failed
- [ ] `bash scripts/run_e2e_testlab.sh` — 21/21 pass
- [ ] `bash scripts/demo_run.sh` — demo completes, findings printed, report generated

### Security Checks
- [ ] `.env.example` has no real secrets or credentials
- [ ] `.env.production.example` documents all required vars
- [ ] `SECRET_KEY` and `JWT_SECRET_KEY` are generated fresh (not `CHANGE_ME`)
- [ ] CORS_ORIGINS is restricted (not `*`) in production config
- [ ] Rate limiting is enabled (`RATE_LIMIT_PER_MINUTE=60` or lower)
- [ ] `BILLING_ENABLED=false` confirmed in non-billing builds
- [ ] No hardcoded credentials in source code (`grep -r "password123\|secret123\|admin123" backend/app`)
- [ ] Audit log middleware is active (check `app/api/middleware/audit.py` registered in `main.py`)
- [ ] Workspace isolation dependency applied to all routes that access workspace data

### Scan Safety Checks
- [ ] Scope validation enforced (EmergencyStopPolicy → ScopePolicy → RateLimitPolicy → ApprovalPolicy)
- [ ] Emergency stop works: `POST /api/v1/workers/emergency-stop`
- [ ] Legal authorization checkbox present on scan creation UI
- [ ] CRITICAL-tier tasks blocked until approved
- [ ] Rate limit policy active at 5 req/s default

### Documentation Checks
- [ ] `QUICKSTART.md` — install steps work end-to-end
- [ ] `DEMO_GUIDE.md` — demo script produces expected output
- [ ] `OPERATOR_MANUAL.md` — workflows documented
- [ ] `TROUBLESHOOTING.md` — common errors covered
- [ ] `SECURITY_MODEL.md` — policy architecture documented
- [ ] `PHASE10_AVROS_COMPLETION.md` — Phase 10 features documented
- [ ] `PHASE11_LAUNCH_HARDENING.md` — Phase 11 features documented
- [ ] `README.md` — up to date with current feature set

### Database Checks
- [ ] All 3 Alembic migrations applied: `alembic current` shows `003_avros_completion`
- [ ] 30 tables present after migration
- [ ] Seed data loads cleanly: `python backend/scripts/seed.py`
- [ ] Demo data reset works: `POST /api/v1/demo/reset`

### Infrastructure Checks
- [ ] `docker-compose.yml` — all services start cleanly
- [ ] `docker-compose.testlab.yml` — testlab starts isolated
- [ ] `scripts/install_local.sh` — complete install works
- [ ] `scripts/backup.sh` — backup creates valid `.sql.gz`
- [ ] `infrastructure/nginx/nginx.conf` — valid nginx config
- [ ] `.env.production.example` — all required vars documented

## Known Limitations (v3.0)

### Must-Know Before Production Deployment

1. **Orchestrator dispatch is partial.** The AVROS orchestrator plans a full task graph but the agent dispatch methods for non-recon agents return placeholder results. Full integration with the existing Celery pipeline is v3.1.

2. **Strategic memory is in-process only.** `get_memory(workspace_id)` data resets on process restart. DB persistence to `strategic_memory` table is wired but not auto-loaded on startup.

3. **Playwright not included in Docker image.** Install manually inside container: `playwright install chromium --with-deps`. DOM snapshot, SPA mapper, and WS capture work without it (static analysis only).

4. **AI features degrade gracefully without API key.** Hypothesis engine, payload selection, chain reasoning, and court validation all work without `ANTHROPIC_API_KEY`. Narratives are template-based fallbacks.

5. **No real-time WebSocket scan progress.** Scan logs are polled via SSE, not true push. This works but adds ~1s latency to live updates.

6. **Attack chain probability is heuristic.** The `_CHAIN_MATRIX` in `graph_reasoner.py` uses hand-tuned probabilities. AI re-scoring via Anthropic API improves accuracy but isn't required.

7. **External tools are optional.** Without subfinder/httpx/nuclei, recon only finds a limited number of subdomains via passive DNS. Scans complete but with reduced coverage.

8. **No SSO or SAML.** Authentication is JWT-only. SSO integration is on the roadmap.

9. **Celery required for scan execution.** The API queues tasks to Celery. Without a running worker, scans are created but never execute.

10. **Windows is not officially supported.** The bash scripts and some path handling assumes Unix. Docker is the recommended deployment on Windows.

## Version

- **Version:** 3.0 (Phase 11 — Launch Hardening)
- **Backend:** FastAPI 0.111 + SQLAlchemy 2.0 + Python 3.12
- **Frontend:** Next.js 14 + TypeScript + Tailwind + Zustand
- **Database:** PostgreSQL 16 + pgvector + Redis 7
- **Routes:** 82+ API endpoints
- **DB Tables:** 30
- **Tests:** 72+ automated tests
