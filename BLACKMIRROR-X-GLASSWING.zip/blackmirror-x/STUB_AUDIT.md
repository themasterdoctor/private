# STUB_AUDIT.md — BLACKMIRROR-X GLASSWING Phase 9

**Date:** 2026-05-13 | **Stubs found:** 14 | **Patched:** 11 | **External-only:** 3

## Stubs Patched in Phase 9

| # | File | Function | Was | Fixed |
|---|------|----------|-----|-------|
| 1 | `app/api/routes/intelligence.py:117` | `stream_hypothesis_reasoning` | Returns only start/complete SSE | Real engine with step callbacks |
| 2 | `app/agents/recon/agent.py:202` | `_run_command` | Logs "mock mode", continues silently | ToolManager marks capability disabled |
| 3 | `app/workers/tasks.py:282` | `_run_nuclei` | Silently returns empty on FileNotFoundError | ToolManager + clear capability log |
| 4 | `app/workers/tasks.py:201` | `run_scan_task` Phase 5 | `sm(bind=None)` — no DB write | Real session for self-improvement write |
| 5 | `app/api/routes/websocket.py:49` | `scan_websocket` | UUID ordering for logs | `created_at` timestamp ordering |
| 6 | *(new)* `app/tools/tool_manager.py` | — | No centralized tool detection | ToolManager detects all 10 tools |
| 7 | `app/api/routes/intelligence.py:62` | `generate_hypotheses` | `sub.technologies` (wrong field) | `sub.tech_stack` |
| 8 | `app/api/routes/intelligence.py:90` | `generate_hypotheses` | `scan.target` (no such attr) | `scan.config.get("domain")` |
| 9 | `app/api/routes/intelligence.py:140` | `adjudicate_vulnerability` | workspace_id extraction fragile | Proper fallback |
| 10 | `app/intelligence/memory/workspace_memory.py` | `load/save` | workspace_id UUID cast missing | Added str() cast |
| 11 | frontend pages | all | No loading/empty states | Added to dashboard, vulns, mission |

## External-Only (Require User Installation)

| Tool | Purpose | Install |
|------|---------|---------|
| subfinder/amass/dnsx | Subdomain enumeration | https://github.com/projectdiscovery |
| nuclei | Vulnerability scanning | https://github.com/projectdiscovery/nuclei |
| chromium | Browser intelligence | `playwright install chromium --with-deps` |

## Confirmed NOT Stubs (False Positives)

- `on_step()` bare pass — correct: registers callback, `_emit()` calls it
- `_noop()` in vuln agent — intentional no-op placeholder for subclass override
- `close()` in JS agent — intentional async context manager stub
- `/vulns` route name — matches actual Next.js file structure, correct
