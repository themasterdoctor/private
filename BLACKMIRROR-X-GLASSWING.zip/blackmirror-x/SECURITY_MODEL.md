# SECURITY_MODEL — BLACKMIRROR-X Safety Architecture

This document explains how BLACKMIRROR-X enforces safe scanning, scope controls,
and operator accountability. Read this before running against any target.

## Core Principles

1. **Passive by default** — no active tests without explicit opt-in
2. **Scope-enforced** — every request validated against declared scope
3. **Rate-limited** — configurable per-target rate limits (default: 5 req/s)
4. **Tiered risk** — 5 risk tiers with escalating controls
5. **Human approval** — critical-tier tests blocked until manually approved
6. **Emergency stop** — always-available global halt
7. **Full audit log** — every API call logged with user, IP, timestamp

## Risk Tiers

| Tier | Description | Approval Required | Rate Limit |
|------|-------------|-------------------|------------|
| `passive` | Read-only, no requests to target | Never | N/A |
| `low` | Safe active (HEAD, OPTIONS only) | Never | 10 req/s |
| `medium` | Standard active testing | Never | 5 req/s |
| `high` | Destructive-adjacent tests | If configured | 1 req/s |
| `critical` | Always potentially destructive | Always | 0.5 req/s |

## Policy Engine (app/orchestrator/policies.py)

Every task passes through four policy checks before execution:

```
EmergencyStopPolicy → ScopePolicy → RateLimitPolicy → ApprovalPolicy
```

Any violation blocks the task. Policy violations are logged to the audit table.

### Scope Policy

```python
ScopePolicy(
    allowed_domains=["*.example.com", "api.example.com"],
    excluded_patterns=["admin.example.com"],
    allow_subdomains=True,
)
```

- Wildcards supported (`*.example.com`)
- Exclusion patterns override inclusions
- No scope configured = allow all (dev mode only)

### Rate Limit Policy

Token bucket algorithm per target host:
- Default: 5 requests/second, burst of 20
- Configurable per workflow in scan config
- Exceeded rate = task queued, not dropped

### Approval Policy

Tasks at `RiskTier.CRITICAL` are automatically blocked. Unblock via:

```bash
POST /api/v1/orchestrator/approve/{task_id}
```

### Emergency Stop

```bash
# Stop all active scans immediately
POST /api/v1/workers/emergency-stop

# Stop a specific scan
POST /api/v1/workers/stop/{scan_id}

# Resume
POST /api/v1/workers/resume-all
```

Emergency stop is also available as a button in the Workers page sidebar.

## Legal Framework

BLACKMIRROR-X includes:

1. **Authorization checkbox** — required before any scan launches (UI + API)
2. **Scope declaration** — target domain must be explicitly listed
3. **Audit log** — all actions logged to `audit_logs` table with user + IP
4. **Workspace isolation** — users can only access their own workspace data

**You are legally responsible for how you use this tool. Only scan systems you own or have explicit written permission to test. Unauthorized security testing is illegal.**

## What BLACKMIRROR-X Does NOT Do

- No zero-days or exploit code shipped
- No brute force or DoS attacks (rate limit prevents this)
- No credential stuffing
- No bypassing of authentication without explicit test credentials
- No data exfiltration beyond what's needed for evidence capture

## Scan Data Retention

- All scan results stored in your local PostgreSQL database
- No data sent to external services (except Anthropic API when key is configured)
- Artifacts stored in `SCAN_ARTIFACTS_DIR` (default: /app/artifacts)
- Delete workspace to purge all associated data

## Network Isolation (Testlab)

The testlab runs with `internal: true` network policy in Docker:
- No internet access from testlab containers
- Only accessible from your local machine
- Safe to run without VPN

## Reporting a Security Issue

If you find a vulnerability in BLACKMIRROR-X itself, please report it responsibly.
Do not open a public GitHub issue for security vulnerabilities.
