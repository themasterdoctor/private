"use client";
import { useEffect, useRef, useState } from "react";
import { useAppStore } from "@/store/app";
import {
  Brain, Target, Shield, Zap, Eye, ChevronRight,
  TrendingUp, AlertCircle, CheckCircle, XCircle,
  Activity, Cpu, GitBranch, Layers
} from "lucide-react";

interface Hypothesis {
  id: string;
  title: string;
  description: string;
  vuln_class: string;
  confidence: number;
  priority_score: number;
  status: string;
  bounty_estimate: string;
  reasoning: string;
  evidence: string[];
  assumptions: string[];
}

interface ReasoningStep {
  id: string;
  step_type: string;
  content: string;
  confidence: number;
  payload_rationale?: string;
  target_rationale?: string;
  assumptions?: string[];
  evidence_refs?: string[];
  agent_id: string;
  timestamp: number;
}

const STEP_COLORS: Record<string, string> = {
  hypothesis: "text-bmx-cyan border-bmx-cyan/30 bg-bmx-cyan/5",
  evidence: "text-bmx-green border-bmx-green/30 bg-bmx-green/5",
  decision: "text-bmx-yellow border-bmx-yellow/30 bg-bmx-yellow/5",
  escalate: "text-red-400 border-red-400/30 bg-red-400/5",
  abandon: "text-bmx-muted border-bmx-border bg-transparent",
  payload_selection: "text-bmx-orange border-bmx-orange/30 bg-bmx-orange/5",
  target_prioritization: "text-bmx-teal border-bmx-teal/30 bg-bmx-teal/5",
  conclusion: "text-bmx-green border-bmx-green/50 bg-bmx-green/10",
  observation: "text-bmx-muted border-bmx-border bg-transparent",
};

const STATUS_ICONS: Record<string, JSX.Element> = {
  active: <Activity className="w-3 h-3 text-bmx-cyan animate-pulse" />,
  confirmed: <CheckCircle className="w-3 h-3 text-bmx-green" />,
  abandoned: <XCircle className="w-3 h-3 text-bmx-muted" />,
  escalated: <Zap className="w-3 h-3 text-red-400" />,
  testing: <Eye className="w-3 h-3 text-bmx-yellow" />,
};

export default function MissionControlPage() {
  const { scans, activeWorkspace, fetchScans , fetchWorkspaces} = useAppStore();
  const [selectedScan, setSelectedScan] = useState<string>("");
  const [hypotheses, setHypotheses] = useState<Hypothesis[]>([]);
  const [reasoningSteps, setReasoningSteps] = useState<ReasoningStep[]>([]);
  const [activeTab, setActiveTab] = useState<"hypotheses" | "reasoning" | "chains">("hypotheses");
  const [loading, setLoading] = useState(false);
  const [selectedHyp, setSelectedHyp] = useState<Hypothesis | null>(null);
  const reasonRef = useRef<HTMLDivElement>(null);


  useEffect(() => {
    if (!activeWorkspace) fetchWorkspaces();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (activeWorkspace) fetchScans(activeWorkspace.id);
  }, [activeWorkspace]);

  useEffect(() => {
    if (reasonRef.current) {
      reasonRef.current.scrollTop = reasonRef.current.scrollHeight;
    }
  }, [reasoningSteps]);

  const generateHypotheses = async () => {
    if (!selectedScan) return;
    setLoading(true);
    setReasoningSteps([]);
    try {
      const token = localStorage.getItem("bmx_access_token");
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"}/api/v1/intel/hypotheses/generate/${selectedScan}`,
        { method: "POST", headers: { Authorization: `Bearer ${token}` } }
      );
      const data = await res.json();
      setHypotheses(data.hypotheses || []);
      setReasoningSteps(data.reasoning_steps || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const confidenceBar = (confidence: number) => (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1 bg-bmx-border rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{
            width: `${confidence * 100}%`,
            background: confidence >= 0.75 ? "#ff3366" : confidence >= 0.55 ? "#ff6b35" : "#00e5ff",
          }}
        />
      </div>
      <span className="text-bmx-muted text-xs font-mono w-8">{Math.round(confidence * 100)}%</span>
    </div>
  );

  const ATTACK_CHAINS = [
    {
      name: "XSS → Session Hijack → ATO",
      steps: ["Stored XSS in bio field", "Exfiltrate session cookie", "Authenticate as victim", "Escalate to admin"],
      probability: 0.82,
      severity: "critical",
    },
    {
      name: "SSRF → Cloud Metadata → IAM",
      steps: ["SSRF via import URL", "Fetch 169.254.169.254", "Extract IAM credentials", "AWS API access"],
      probability: 0.74,
      severity: "critical",
    },
    {
      name: "SQLi → Credential Dump → RCE",
      steps: ["SQLi in search param", "Dump user credentials", "Admin login", "File write to RCE"],
      probability: 0.61,
      severity: "critical",
    },
    {
      name: "JWT Forgery → Admin Takeover",
      steps: ["Extract public key", "Sign with HS256", "Forge admin token", "Access admin panel"],
      probability: 0.55,
      severity: "critical",
    },
  ];

  return (
    <div className="p-6 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white font-mono text-xl font-bold flex items-center gap-2">
            <Brain className="w-5 h-5 text-bmx-cyan" />
            MISSION CONTROL
          </h1>
          <p className="text-bmx-muted text-sm font-mono mt-0.5">
            Autonomous reasoning · Hypothesis engine · Attack chain analysis
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono">
          <div className="w-1.5 h-1.5 rounded-full bg-bmx-cyan animate-pulse" />
          <span className="text-bmx-cyan">AI ONLINE</span>
        </div>
      </div>

      {/* Scan selector + Launch */}
      <div className="bmx-panel rounded-lg border border-bmx-border p-4">
        <div className="flex gap-3 items-center">
          <select
            value={selectedScan}
            onChange={(e) => setSelectedScan(e.target.value)}
            className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan"
          >
            <option value="">Select scan for analysis...</option>
            {scans.map((s) => (
              <option key={s.id} value={s.id}>
                {s.target} — {s.status} ({s.vuln_count} vulns)
              </option>
            ))}
          </select>
          <button
            onClick={generateHypotheses}
            disabled={loading || !selectedScan}
            className="flex items-center gap-2 bg-bmx-cyan text-bmx-black font-mono font-bold text-sm px-4 py-2 rounded hover:bg-bmx-cyan/90 transition-colors disabled:opacity-50"
          >
            <Cpu className="w-4 h-4" />
            {loading ? "ANALYZING..." : "RUN INTELLIGENCE"}
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 border-b border-bmx-border">
        {[
          { id: "hypotheses", label: "HYPOTHESES", count: hypotheses.length, icon: Brain },
          { id: "reasoning", label: "REASONING TRACE", count: reasoningSteps.length, icon: Layers },
          { id: "chains", label: "ATTACK CHAINS", count: ATTACK_CHAINS.length, icon: GitBranch },
        ].map(({ id, label, count, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id as typeof activeTab)}
            className={`pb-3 flex items-center gap-2 text-xs font-mono tracking-wider transition-colors ${
              activeTab === id ? "text-bmx-cyan border-b-2 border-bmx-cyan" : "text-bmx-muted hover:text-white"
            }`}
          >
            <Icon className="w-3.5 h-3.5" />
            {label} {count > 0 && <span className="text-bmx-muted">({count})</span>}
          </button>
        ))}
      </div>

      {/* Hypotheses */}
      {activeTab === "hypotheses" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="space-y-2">
            {hypotheses.length === 0 && !loading && (
              <div className="bmx-panel rounded-lg border border-bmx-border px-4 py-12 text-center">
                <Brain className="w-8 h-8 text-bmx-muted/20 mx-auto mb-3" />
                <p className="text-bmx-muted font-mono text-sm">Select a scan and run intelligence analysis</p>
              </div>
            )}
            {hypotheses.map((h) => (
              <div
                key={h.id}
                onClick={() => setSelectedHyp(selectedHyp?.id === h.id ? null : h)}
                className={`bmx-panel rounded-lg border p-3 cursor-pointer transition-colors ${
                  selectedHyp?.id === h.id
                    ? "border-bmx-cyan/40 bg-bmx-cyan/5"
                    : "border-bmx-border hover:border-bmx-cyan/20"
                }`}
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2 min-w-0">
                    {STATUS_ICONS[h.status] || <Activity className="w-3 h-3 text-bmx-muted" />}
                    <p className="text-white font-mono text-xs font-medium truncate">{h.title}</p>
                  </div>
                  <span className="text-bmx-orange text-xs font-mono shrink-0 border border-bmx-orange/30 px-1.5 py-0.5 rounded">
                    {h.vuln_class.toUpperCase()}
                  </span>
                </div>
                {confidenceBar(h.confidence)}
                {h.bounty_estimate && (
                  <p className="text-bmx-green text-xs font-mono mt-1.5">{h.bounty_estimate}</p>
                )}
              </div>
            ))}
          </div>

          {/* Detail panel */}
          <div className="bmx-panel rounded-lg border border-bmx-border p-4">
            {selectedHyp ? (
              <div className="space-y-4">
                <div>
                  <h3 className="text-white font-mono text-sm font-bold">{selectedHyp.title}</h3>
                  <p className="text-bmx-muted font-mono text-xs mt-1">{selectedHyp.description}</p>
                </div>
                {selectedHyp.reasoning && (
                  <div>
                    <p className="text-bmx-muted text-xs font-mono mb-1 tracking-wider">AI REASONING</p>
                    <p className="text-white text-xs font-mono leading-relaxed border-l-2 border-bmx-cyan/30 pl-3">
                      {selectedHyp.reasoning}
                    </p>
                  </div>
                )}
                {selectedHyp.evidence?.length > 0 && (
                  <div>
                    <p className="text-bmx-muted text-xs font-mono mb-1 tracking-wider">EVIDENCE</p>
                    <ul className="space-y-1">
                      {selectedHyp.evidence.map((e, i) => (
                        <li key={i} className="text-bmx-green text-xs font-mono flex items-center gap-1.5">
                          <CheckCircle className="w-3 h-3 shrink-0" />{e}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {selectedHyp.assumptions?.length > 0 && (
                  <div>
                    <p className="text-bmx-muted text-xs font-mono mb-1 tracking-wider">ASSUMPTIONS</p>
                    <ul className="space-y-1">
                      {selectedHyp.assumptions.map((a, i) => (
                        <li key={i} className="text-bmx-yellow text-xs font-mono flex items-center gap-1.5">
                          <AlertCircle className="w-3 h-3 shrink-0" />{a}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-bmx-border">
                  <div>
                    <p className="text-bmx-muted text-xs font-mono">CONFIDENCE</p>
                    <p className="text-white font-mono text-lg">{Math.round(selectedHyp.confidence * 100)}%</p>
                  </div>
                  <div>
                    <p className="text-bmx-muted text-xs font-mono">PRIORITY</p>
                    <p className="text-bmx-orange font-mono text-lg">{Math.round(selectedHyp.priority_score * 10)}/10</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full py-12">
                <Target className="w-8 h-8 text-bmx-muted/20 mb-3" />
                <p className="text-bmx-muted font-mono text-sm">Select a hypothesis to inspect</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Reasoning Trace */}
      {activeTab === "reasoning" && (
        <div
          ref={reasonRef}
          className="bmx-panel rounded-lg border border-bmx-border h-[600px] overflow-y-auto p-4 space-y-2 terminal"
        >
          {reasoningSteps.length === 0 ? (
            <div className="text-center py-12">
              <Layers className="w-8 h-8 text-bmx-muted/20 mx-auto mb-3" />
              <p className="text-bmx-muted font-mono text-sm">Run intelligence analysis to see agent reasoning</p>
            </div>
          ) : (
            reasoningSteps.map((step) => (
              <div
                key={step.id}
                className={`rounded border px-3 py-2 text-xs font-mono ${STEP_COLORS[step.step_type] || STEP_COLORS.observation}`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <span className="opacity-50">[{step.step_type.replace("_", " ").toUpperCase()}]</span>
                  <span className="ml-auto opacity-50">conf={Math.round(step.confidence * 100)}%</span>
                  <span className="opacity-40">{step.agent_id}</span>
                </div>
                <p>{step.content}</p>
                {step.payload_rationale && (
                  <p className="mt-1 opacity-70">↳ Payload: {step.payload_rationale}</p>
                )}
                {step.target_rationale && (
                  <p className="mt-1 opacity-70">↳ {step.target_rationale}</p>
                )}
                {step.assumptions && step.assumptions.length > 0 && (
                  <p className="mt-1 opacity-50 text-bmx-yellow">
                    ⊕ Assumes: {step.assumptions.join(", ")}
                  </p>
                )}
              </div>
            ))
          )}
          {loading && (
            <div className="flex items-center gap-2 text-bmx-cyan text-xs font-mono animate-pulse">
              <Activity className="w-3.5 h-3.5" />
              Agent reasoning...
            </div>
          )}
        </div>
      )}

      {/* Attack Chains */}
      {activeTab === "chains" && (
        <div className="space-y-4">
          {ATTACK_CHAINS.map((chain, i) => (
            <div key={i} className="bmx-panel rounded-lg border border-bmx-border p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-white font-mono text-sm font-bold">{chain.name}</h3>
                <div className="flex items-center gap-3">
                  <span className="text-red-400 text-xs font-mono border border-red-400/30 px-2 py-0.5 rounded">
                    {chain.severity.toUpperCase()}
                  </span>
                  <span className="text-bmx-muted text-xs font-mono">
                    P(success)={Math.round(chain.probability * 100)}%
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                {chain.steps.map((step, j) => (
                  <div key={j} className="flex items-center gap-2">
                    <div className="bg-bmx-border text-white text-xs font-mono px-2 py-1 rounded border border-bmx-border/50">
                      {step}
                    </div>
                    {j < chain.steps.length - 1 && (
                      <ChevronRight className="w-3.5 h-3.5 text-bmx-cyan" />
                    )}
                  </div>
                ))}
              </div>
              {/* Probability bar */}
              <div className="mt-3 flex items-center gap-3">
                <span className="text-bmx-muted text-xs font-mono">Chain probability</span>
                <div className="flex-1 h-1 bg-bmx-border rounded-full overflow-hidden">
                  <div
                    className="h-full bg-bmx-red rounded-full"
                    style={{ width: `${chain.probability * 100}%` }}
                  />
                </div>
                <TrendingUp className="w-3.5 h-3.5 text-bmx-red" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
