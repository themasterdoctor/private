"use client";
import { useEffect, useState, useRef } from "react";
import { useAppStore } from "@/store/app";
import {
  Cpu, Play, Square, RefreshCw, CheckCircle, XCircle,
  Clock, AlertTriangle, ChevronRight, User, Zap, Shield
} from "lucide-react";

interface Task {
  id: string;
  name: string;
  agent_type: string;
  status: string;
  risk_tier: string;
  priority: number;
  confidence: number;
  parent_ids: string[];
  created_at: string;
  started_at?: string;
  completed_at?: string;
  error?: string;
}

interface GraphData {
  nodes: Task[];
  edges: { from: string; to: string }[];
  stats: { total: number; pending?: number; running?: number; completed?: number; failed?: number; abandoned?: number };
}

interface BusEvent {
  id: string;
  event_type: string;
  source_agent: string;
  payload: Record<string, unknown>;
  confidence: number;
  timestamp: string;
}

const STATUS_STYLES: Record<string, string> = {
  pending:   "text-gray-400 bg-gray-400/10 border-gray-400/20",
  ready:     "text-bmx-cyan bg-bmx-cyan/10 border-bmx-cyan/20",
  running:   "text-bmx-yellow bg-bmx-yellow/10 border-bmx-yellow/20",
  completed: "text-bmx-green bg-bmx-green/10 border-bmx-green/20",
  failed:    "text-bmx-red bg-bmx-red/10 border-bmx-red/20",
  abandoned: "text-gray-500 bg-gray-500/10 border-gray-500/20",
  blocked:   "text-purple-400 bg-purple-400/10 border-purple-400/20",
};

const RISK_COLORS: Record<string, string> = {
  passive:  "text-gray-400",
  low:      "text-bmx-green",
  medium:   "text-bmx-yellow",
  high:     "text-bmx-orange",
  critical: "text-bmx-red",
};

const AGENT_ICONS: Record<string, string> = {
  recon:        "🔍",
  js_agent:     "🔮",
  api_agent:    "🔗",
  vuln_agent:   "🐛",
  chain_agent:  "⛓️",
  court_agent:  "⚖️",
  report_agent: "📋",
};

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export default function OrchestratorPage() {
  const { scans, activeWorkspace, fetchScans , fetchWorkspaces} = useAppStore();
  const [selectedScan, setSelectedScan] = useState<string>("");
  const [graph, setGraph] = useState<GraphData | null>(null);
  const [events, setEvents] = useState<BusEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>("");
  const [pendingApprovals, setPendingApprovals] = useState<unknown[]>([]);
  const pollRef = useRef<NodeJS.Timeout | null>(null);


  useEffect(() => {
    if (!activeWorkspace) fetchWorkspaces();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (activeWorkspace) fetchScans(activeWorkspace.id);
  }, [activeWorkspace]);

  const getToken = () => localStorage.getItem("bmx_access_token") || "";

  async function startOrchestrator() {
    if (!selectedScan) return;
    setLoading(true);
    setError("");
    try {
      const r = await fetch(`${API}/api/v1/orchestrator/start/${selectedScan}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      if (!r.ok) throw new Error(await r.text());
      pollStatus();
    } catch (e: unknown) {
      setError(String(e));
    } finally {
      setLoading(false);
    }
  }

  async function stopOrchestrator() {
    if (!selectedScan) return;
    await fetch(`${API}/api/v1/orchestrator/stop/${selectedScan}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${getToken()}` },
    });
    pollStatus();
  }

  async function pollStatus() {
    if (!selectedScan) return;
    try {
      const [gRes, eRes, pRes] = await Promise.all([
        fetch(`${API}/api/v1/orchestrator/tasks/${selectedScan}`, {
          headers: { Authorization: `Bearer ${getToken()}` },
        }),
        fetch(`${API}/api/v1/orchestrator/events/${selectedScan}?limit=30`, {
          headers: { Authorization: `Bearer ${getToken()}` },
        }),
        fetch(`${API}/api/v1/orchestrator/pending`, {
          headers: { Authorization: `Bearer ${getToken()}` },
        }),
      ]);
      if (gRes.ok) setGraph(await gRes.json());
      if (eRes.ok) {
        const d = await eRes.json();
        setEvents(d.events || []);
      }
      if (pRes.ok) {
        const p = await pRes.json();
        setPendingApprovals(p.items || []);
      }
    } catch {/* network error */}
  }

  async function approveTask(taskId: string) {
    await fetch(`${API}/api/v1/orchestrator/approve/${taskId}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${getToken()}` },
    });
    pollStatus();
  }

  useEffect(() => {
    if (!selectedScan) return;
    pollStatus();
    pollRef.current = setInterval(pollStatus, 3000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [selectedScan]);

  const stats = graph?.stats;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Cpu className="w-6 h-6 text-bmx-cyan" />
          <div>
            <h1 className="text-xl font-bold text-white font-mono">AVROS Orchestrator</h1>
            <p className="text-xs text-bmx-muted">Autonomous agent task graph execution</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={pollStatus}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-bmx-muted border border-bmx-border rounded hover:border-bmx-cyan/50 hover:text-bmx-cyan transition-colors"
          >
            <RefreshCw className="w-3 h-3" /> Refresh
          </button>
        </div>
      </div>

      {/* Scan selector + controls */}
      <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4 flex flex-wrap gap-4 items-end">
        <div className="flex-1 min-w-48">
          <label className="block text-xs text-bmx-muted mb-1">Select Scan</label>
          <select
            value={selectedScan}
            onChange={(e) => setSelectedScan(e.target.value)}
            className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white focus:border-bmx-cyan outline-none"
          >
            <option value="">— choose a scan —</option>
            {scans.map((s) => (
              <option key={s.id} value={s.id}>{s.name || s.id.slice(0, 8)}</option>
            ))}
          </select>
        </div>
        <div className="flex gap-2">
          <button
            onClick={startOrchestrator}
            disabled={!selectedScan || loading}
            className="flex items-center gap-1.5 px-4 py-2 text-sm font-mono bg-bmx-cyan/10 text-bmx-cyan border border-bmx-cyan/30 rounded hover:bg-bmx-cyan/20 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            <Play className="w-3.5 h-3.5" />
            {loading ? "Starting..." : "Start Orchestrator"}
          </button>
          <button
            onClick={stopOrchestrator}
            disabled={!selectedScan}
            className="flex items-center gap-1.5 px-4 py-2 text-sm font-mono bg-bmx-red/10 text-bmx-red border border-bmx-red/30 rounded hover:bg-bmx-red/20 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            <Square className="w-3.5 h-3.5" /> Stop
          </button>
        </div>
        {error && <p className="w-full text-xs text-bmx-red">{error}</p>}
      </div>

      {/* Stats bar */}
      {stats && (
        <div className="grid grid-cols-6 gap-3">
          {[
            { label: "Total", val: stats.total, color: "text-white" },
            { label: "Pending", val: stats.pending || 0, color: "text-gray-400" },
            { label: "Running", val: stats.running || 0, color: "text-bmx-yellow" },
            { label: "Completed", val: stats.completed || 0, color: "text-bmx-green" },
            { label: "Failed", val: stats.failed || 0, color: "text-bmx-red" },
            { label: "Abandoned", val: stats.abandoned || 0, color: "text-gray-500" },
          ].map((s) => (
            <div key={s.label} className="bg-bmx-dark border border-bmx-border rounded-lg p-3 text-center">
              <div className={`text-xl font-bold font-mono ${s.color}`}>{s.val}</div>
              <div className="text-xs text-bmx-muted mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Task graph */}
        <div className="xl:col-span-2 bg-bmx-dark border border-bmx-border rounded-lg">
          <div className="px-4 py-3 border-b border-bmx-border flex items-center gap-2">
            <Zap className="w-4 h-4 text-bmx-cyan" />
            <span className="text-sm font-mono text-white">Task Graph</span>
            <span className="text-xs text-bmx-muted ml-auto">
              {graph?.nodes?.length || 0} tasks
            </span>
          </div>
          <div className="p-4 space-y-2 max-h-96 overflow-y-auto">
            {!graph?.nodes?.length ? (
              <div className="text-center py-12">
                <Cpu className="w-8 h-8 text-bmx-border mx-auto mb-3" />
                <p className="text-bmx-muted text-sm">Select a scan and start orchestrator</p>
              </div>
            ) : (
              graph.nodes.map((task) => (
                <div
                  key={task.id}
                  className={`border rounded-lg p-3 ${STATUS_STYLES[task.status] || STATUS_STYLES.pending}`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-base">{AGENT_ICONS[task.agent_type] || "🤖"}</span>
                      <div className="min-w-0">
                        <div className="text-sm font-mono truncate">{task.name}</div>
                        <div className="text-xs text-bmx-muted">{task.agent_type}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className={`text-xs font-mono ${RISK_COLORS[task.risk_tier] || "text-gray-400"}`}>
                        {task.risk_tier}
                      </span>
                      <span className="text-xs text-bmx-muted">
                        {(task.confidence * 100).toFixed(0)}%
                      </span>
                      <span className={`text-xs px-2 py-0.5 rounded border font-mono ${STATUS_STYLES[task.status] || ""}`}>
                        {task.status}
                      </span>
                    </div>
                  </div>
                  {task.error && (
                    <div className="mt-1.5 text-xs text-bmx-red bg-bmx-red/5 rounded px-2 py-1">
                      {task.error}
                    </div>
                  )}
                  {task.parent_ids?.length > 0 && (
                    <div className="mt-1 flex items-center gap-1 text-xs text-bmx-muted">
                      <ChevronRight className="w-3 h-3" />
                      <span>depends on {task.parent_ids.length} task{task.parent_ids.length > 1 ? "s" : ""}</span>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right panel: events + approvals */}
        <div className="space-y-4">
          {/* Pending approvals */}
          {pendingApprovals.length > 0 && (
            <div className="bg-bmx-dark border border-bmx-yellow/30 rounded-lg">
              <div className="px-4 py-3 border-b border-bmx-yellow/20 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-bmx-yellow" />
                <span className="text-sm font-mono text-bmx-yellow">Pending Approvals</span>
                <span className="ml-auto text-xs bg-bmx-yellow/10 text-bmx-yellow px-1.5 py-0.5 rounded">
                  {pendingApprovals.length}
                </span>
              </div>
              <div className="p-3 space-y-2">
                {(pendingApprovals as Array<{ id: string; event_type?: string; source_agent?: string }>).map((item) => (
                  <div key={item.id} className="flex items-center justify-between gap-2 text-xs">
                    <div>
                      <div className="text-white font-mono">{item.event_type}</div>
                      <div className="text-bmx-muted">{item.source_agent}</div>
                    </div>
                    <button
                      onClick={() => approveTask(item.id)}
                      className="px-2 py-1 text-xs bg-bmx-green/10 text-bmx-green border border-bmx-green/30 rounded hover:bg-bmx-green/20"
                    >
                      Approve
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Event feed */}
          <div className="bg-bmx-dark border border-bmx-border rounded-lg">
            <div className="px-4 py-3 border-b border-bmx-border flex items-center gap-2">
              <Shield className="w-4 h-4 text-bmx-teal" />
              <span className="text-sm font-mono text-white">Agent Bus Events</span>
              <span className="text-xs text-bmx-muted ml-auto">{events.length}</span>
            </div>
            <div className="p-2 space-y-1 max-h-80 overflow-y-auto font-mono">
              {!events.length ? (
                <p className="text-center text-bmx-muted text-xs py-8">Waiting for events...</p>
              ) : (
                [...events].reverse().map((ev) => (
                  <div key={ev.id} className="text-xs px-2 py-1.5 rounded hover:bg-white/5">
                    <div className="flex items-center gap-2">
                      <span className="text-bmx-cyan">{ev.source_agent}</span>
                      <span className="text-bmx-muted">→</span>
                      <span className="text-white truncate">{ev.event_type}</span>
                      <span className="ml-auto text-bmx-muted">
                        {(ev.confidence * 100).toFixed(0)}%
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
