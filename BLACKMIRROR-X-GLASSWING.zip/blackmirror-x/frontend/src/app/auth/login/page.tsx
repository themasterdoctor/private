"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuthStore } from "@/store/auth";
import { Eye, EyeOff, Terminal, Zap } from "lucide-react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");
  const { login, isLoading } = useAuthStore();
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    try {
      await login(email, password);
      router.push("/dashboard");
    } catch {
      setError("Invalid credentials. Check your email and password.");
    }
  };

  return (
    <div className="min-h-screen bg-bmx-black flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background grid */}
      <div className="absolute inset-0 bg-grid opacity-30" />
      {/* Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-bmx-cyan/5 blur-[120px] pointer-events-none" />

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded border border-bmx-cyan/50 flex items-center justify-center bg-bmx-cyan/10">
              <Terminal className="w-5 h-5 text-bmx-cyan" />
            </div>
            <span className="text-xl font-mono font-bold text-white tracking-widest">
              BLACKMIRROR<span className="text-bmx-cyan">-X</span>
            </span>
          </div>
          <p className="text-bmx-muted text-sm font-mono">GLASSWING // AI SECURITY PLATFORM</p>
        </div>

        {/* Card */}
        <div className="bmx-panel rounded-lg p-8 border border-bmx-border">
          <div className="flex items-center gap-2 mb-6">
            <Zap className="w-4 h-4 text-bmx-cyan" />
            <h1 className="text-white font-mono text-sm tracking-wider">AUTHENTICATE</h1>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-bmx-muted text-xs font-mono mb-1.5 tracking-wider">EMAIL</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2.5 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan transition-colors placeholder:text-bmx-muted/40"
                placeholder="operator@blackmirror.io"
                required
              />
            </div>

            <div>
              <label className="block text-bmx-muted text-xs font-mono mb-1.5 tracking-wider">PASSWORD</label>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2.5 pr-10 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan transition-colors placeholder:text-bmx-muted/40"
                  placeholder="••••••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-bmx-muted hover:text-white transition-colors"
                >
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-bmx-red/10 border border-bmx-red/30 rounded px-3 py-2 text-bmx-red text-xs font-mono">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-bmx-cyan text-bmx-black font-mono font-bold text-sm py-2.5 rounded hover:bg-bmx-cyan/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed tracking-wider mt-2"
            >
              {isLoading ? "AUTHENTICATING..." : "AUTHENTICATE →"}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-bmx-border text-center">
            <p className="text-bmx-muted text-xs font-mono">
              No account?{" "}
              <a href="/auth/register" className="text-bmx-cyan hover:underline">
                REQUEST ACCESS
              </a>
            </p>
          </div>
        </div>

        <p className="text-center text-bmx-muted/40 text-xs font-mono mt-6">
          AUTHORIZED USE ONLY // ALL ACTIVITY LOGGED
        </p>
      </div>
    </div>
  );
}
