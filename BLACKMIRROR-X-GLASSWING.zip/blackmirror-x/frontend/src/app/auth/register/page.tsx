"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { authApi } from "@/lib/api";
import { Terminal } from "lucide-react";

export default function RegisterPage() {
  const [form, setForm] = useState({ email: "", password: "", full_name: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await authApi.register(form);
      router.push("/auth/login?registered=1");
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail;
      setError(msg || "Registration failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-bmx-black flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-grid opacity-30" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-bmx-teal/5 blur-[120px] pointer-events-none" />

      <div className="relative z-10 w-full max-w-md">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded border border-bmx-cyan/50 flex items-center justify-center bg-bmx-cyan/10">
              <Terminal className="w-5 h-5 text-bmx-cyan" />
            </div>
            <span className="text-xl font-mono font-bold text-white tracking-widest">
              BLACKMIRROR<span className="text-bmx-cyan">-X</span>
            </span>
          </div>
        </div>

        <div className="bmx-panel rounded-lg p-8 border border-bmx-border">
          <h1 className="text-white font-mono text-sm tracking-wider mb-6">CREATE ACCOUNT</h1>

          <form onSubmit={handleSubmit} className="space-y-4">
            {(["full_name", "email", "password"] as const).map((field) => (
              <div key={field}>
                <label className="block text-bmx-muted text-xs font-mono mb-1.5 tracking-wider">
                  {field.replace("_", " ").toUpperCase()}
                </label>
                <input
                  type={field === "password" ? "password" : field === "email" ? "email" : "text"}
                  value={form[field]}
                  onChange={(e) => setForm({ ...form, [field]: e.target.value })}
                  className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2.5 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan transition-colors"
                  required
                />
              </div>
            ))}

            {error && (
              <div className="bg-bmx-red/10 border border-bmx-red/30 rounded px-3 py-2 text-bmx-red text-xs font-mono">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-bmx-cyan text-bmx-black font-mono font-bold text-sm py-2.5 rounded hover:bg-bmx-cyan/90 transition-colors disabled:opacity-50 mt-2 tracking-wider"
            >
              {loading ? "CREATING..." : "CREATE ACCOUNT →"}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-bmx-border text-center">
            <p className="text-bmx-muted text-xs font-mono">
              Already have access?{" "}
              <a href="/auth/login" className="text-bmx-cyan hover:underline">
                SIGN IN
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
