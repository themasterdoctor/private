"use client";
import { useEffect, useState } from "react";
import { useAppStore } from "@/store/app";
import {
  Activity, Bell, Plus, Trash2, Globe,
  AlertTriangle, CheckCircle, Code, Shield, Rss
} from "lucide-react";

interface MonitorTarget {
  key: string;
  workspace_id: string;
  target: string;
  interval_hours: number;
  active: boolean;
}

interface MonitorAlert {
  alert_type: string;
  severity: string;
  title: string;
  description: string;
  target: string;
  old_value?: string;
  new_value?: string;
  timestamp: number;
}

const ALERT_ICONS: Record<string, JSX.Element> = {
  new_subdomain: <Globe className="w-3.5 h-3.5 text-bmx-cyan" />,
  subdomain_removed: <AlertTriangle className="w-3.5 h-3.5 text-bmx-orange" />,
  js_bundle_changed: <Code className="w-3.5 h-3.5 text-bmx-yellow" />,
  csp_weakened: <Shield className="w-3.5 h-3.5 text-red-400" />,
  security_header_removed: <Shield className="w-3.5 h-3.5 text-bmx-muted" />,
  new_js_bundle: <Code className="w-3.5 h-3.5 text-bmx-green" />,
};

const SEV_COLORS: Record<string, string> = {
  critical: "border-l-red-500 bg-red-500/5",
  high: "border-l-orange-500 bg-orange-500/5",
  medium: "border-l-yellow-500 bg-yellow-500/5",
  low: "border-l-blue-500 bg-blue-500/5",
};

// Mock alerts for demonstration
const MOCK_ALERTS: MonitorAlert[] = [
  {
    alert_type: "new_subdomain",
    severity: "medium",
    title: "New subdomain: staging.target.com",
    description: "Previously unseen subdomain is now active. Scanning for vulnerabilities.",
    target: "target.com",
    new_value: "staging.target.com",
    timestamp: Date.now() - 3600000,
  },
  {
    alert_type: "js_bundle_changed",
    severity: "medium",
    title: "JavaScript bundle changed: main.a3f92.js",
    description: "JS file hash changed. Re-analyzing for new endpoints and secrets.",
    target: "target.com",
    old_value: "a3f92b1d",
    new_value: "7e21c4fa",
    timestamp: Date.now() - 7200000,
  },
  {
    alert_type: "csp_weakened",
    severity: "high",
    title: "CSP weakened: unsafe-inline added",
    description: "Content Security Policy now allows unsafe-inline scripts. XSS mitigations reduced.",
    target: "app.target.com",
    timestamp: Date.now() - 86400000,
  },
];

export default function MonitorPage() {
  const { activeWorkspace } = useAppStore();
  const [monitors, setMonitors] = useState<MonitorTarget[]>([]);
  const [alerts, setAlerts] = useState<MonitorAlert[]>(MOCK_ALERTS);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTarget, setNewTarget] = useState("");
  const [interval, setIntervalHours] = useState(24);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchMonitors();
  }, [activeWorkspace]);

  const fetchMonitors = async () => {
    try {
      const token = localStorage.getItem("bmx_access_token");
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/intel/monitor/active`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (res.ok) {
        const data = await res.json();
        setMonitors((data.monitors || []).map((key: string) => {
          const [wid, target] = key.split(":");
          return { key, workspace_id: wid, target, interval_hours: 24, active: true };
        }));
      }
    } catch {}
  };

  const addMonitor = async () => {
    if (!newTarget || !activeWorkspace) return;
    setLoading(true);
    try {
      const token = localStorage.getItem("bmx_access_token");
      await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/intel/monitor/start`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ target: newTarget, workspace_id: activeWorkspace.id, interval_hours: interval }),
      });
      setMonitors((prev) => [...prev, {
        key: `${activeWorkspace.id}:${newTarget}`,
        workspace_id: activeWorkspace.id,
        target: newTarget,
        interval_hours: interval,
        active: true,
      }]);
      setNewTarget("");
      setShowAddForm(false);
    } catch {}
    setLoading(false);
  };

  const removeMonitor = async (monitor: MonitorTarget) => {
    try {
      const token = localStorage.getItem("bmx_access_token");
      await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/api/v1/intel/monitor/${monitor.workspace_id}/${monitor.target}`,
        { method: "DELETE", headers: { Authorization: `Bearer ${token}` } }
      );
      setMonitors((prev) => prev.filter((m) => m.key !== monitor.key));
    } catch {}
  };

  const timeAgo = (ts: number) => {
    const d = Date.now() - ts;
    if (d < 3600000) return `${Math.round(d / 60000)}m ago`;
    if (d < 86400000) return `${Math.round(d / 3600000)}h ago`;
    return `${Math.round(d / 86400000)}d ago`;
  };

  return (
    <div className="p-6 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white font-mono text-xl font-bold flex items-center gap-2">
            <Rss className="w-5 h-5 text-bmx-cyan" />
            CONTINUOUS MONITORING
          </h1>
          <p className="text-bmx-muted text-sm font-mono mt-0.5">
            New subdomains · JS changes · CSP weakening · Header drift
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-2 bg-bmx-cyan text-bmx-black font-mono font-bold text-xs px-3 py-2 rounded hover:bg-bmx-cyan/90 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          ADD TARGET
        </button>
      </div>

      {/* Add form */}
      {showAddForm && (
        <div className="bmx-panel rounded-lg border border-bmx-cyan/30 p-4 flex gap-3 items-end">
          <div className="flex-1">
            <label className="text-bmx-muted text-xs font-mono block mb-1">TARGET DOMAIN</label>
            <input
              value={newTarget}
              onChange={(e) => setNewTarget(e.target.value)}
              placeholder="target.com"
              className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan"
            />
          </div>
          <div className="w-32">
            <label className="text-bmx-muted text-xs font-mono block mb-1">INTERVAL (h)</label>
            <select
              value={interval}
              onChange={(e) => setIntervalHours(Number(e.target.value))}
              className="w-full bg-bmx-black border border-bmx-border rounded px-2 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan"
            >
              <option value={6}>6h</option>
              <option value={12}>12h</option>
              <option value={24}>24h</option>
              <option value={48}>48h</option>
            </select>
          </div>
          <button
            onClick={addMonitor}
            disabled={loading || !newTarget}
            className="bg-bmx-cyan text-bmx-black font-mono font-bold text-xs px-4 py-2 rounded hover:bg-bmx-cyan/90 transition-colors disabled:opacity-50"
          >
            START
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Active monitors */}
        <div className="bmx-panel rounded-lg border border-bmx-border">
          <div className="p-3 border-b border-bmx-border flex items-center gap-2">
            <Activity className="w-3.5 h-3.5 text-bmx-cyan" />
            <span className="text-white font-mono text-xs tracking-wider">ACTIVE MONITORS</span>
            <span className="ml-auto bg-bmx-cyan/10 text-bmx-cyan text-xs font-mono px-1.5 py-0.5 rounded">
              {monitors.length}
            </span>
          </div>
          <div className="divide-y divide-bmx-border">
            {monitors.length === 0 && (
              <div className="px-4 py-8 text-center text-bmx-muted font-mono text-xs">
                No monitors active
              </div>
            )}
            {monitors.map((m) => (
              <div key={m.key} className="px-3 py-3 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-bmx-green animate-pulse" />
                    <p className="text-white font-mono text-xs truncate">{m.target}</p>
                  </div>
                  <p className="text-bmx-muted font-mono text-xs mt-0.5">Every {m.interval_hours}h</p>
                </div>
                <button
                  onClick={() => removeMonitor(m)}
                  className="text-bmx-muted hover:text-bmx-red transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Alert feed */}
        <div className="lg:col-span-2">
          <div className="bmx-panel rounded-lg border border-bmx-border">
            <div className="p-3 border-b border-bmx-border flex items-center gap-2">
              <Bell className="w-3.5 h-3.5 text-bmx-orange" />
              <span className="text-white font-mono text-xs tracking-wider">ALERT FEED</span>
              <span className="ml-auto bg-bmx-orange/10 text-bmx-orange text-xs font-mono px-1.5 py-0.5 rounded">
                {alerts.length} alerts
              </span>
            </div>
            <div className="divide-y divide-bmx-border max-h-[500px] overflow-y-auto">
              {alerts.length === 0 && (
                <div className="px-4 py-12 text-center text-bmx-muted font-mono text-xs">
                  <CheckCircle className="w-8 h-8 mx-auto mb-3 text-bmx-green/20" />
                  No alerts — all targets stable
                </div>
              )}
              {alerts.map((alert, i) => (
                <div key={i} className={`px-4 py-3 border-l-2 ${SEV_COLORS[alert.severity] || "border-l-bmx-border"}`}>
                  <div className="flex items-start gap-2.5">
                    <div className="mt-0.5 shrink-0">
                      {ALERT_ICONS[alert.alert_type] || <Bell className="w-3.5 h-3.5 text-bmx-muted" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-0.5">
                        <p className="text-white font-mono text-xs font-medium">{alert.title}</p>
                        <span className="ml-auto text-bmx-muted font-mono text-xs shrink-0">
                          {timeAgo(alert.timestamp)}
                        </span>
                      </div>
                      <p className="text-bmx-muted font-mono text-xs">{alert.description}</p>
                      {(alert.old_value || alert.new_value) && (
                        <div className="mt-1.5 flex gap-3 text-xs font-mono">
                          {alert.old_value && <span className="text-bmx-red">- {alert.old_value}</span>}
                          {alert.new_value && <span className="text-bmx-green">+ {alert.new_value}</span>}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
