"use client";
import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import {
  LayoutDashboard, Search, Bug, Network, FileText,
  Settings, MessageSquare, ChevronLeft, ChevronRight,
  Shield, LogOut, Activity, Brain, Scale,
  Database, Rss, Zap, User, Cpu, Globe, Link2,
  Layers, MemoryStick, Server, Play, FlaskConical
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuthStore } from "@/store/auth";

interface NavItem { href: string; icon: React.ElementType; label: string; color: string; badge?: string; }
interface NavSection { label: string; items: NavItem[]; }

const NAV_SECTIONS: NavSection[] = [
  {
    label: "CORE",
    items: [
      { href: "/dashboard", icon: LayoutDashboard, label: "Dashboard", color: "text-bmx-cyan" },
      { href: "/recon", icon: Search, label: "Recon", color: "text-bmx-teal" },
      { href: "/vulns", icon: Bug, label: "Vulnerabilities", color: "text-bmx-red" },
      { href: "/graph", icon: Network, label: "Attack Graph", color: "text-bmx-orange" },
    ],
  },
  {
    label: "INTELLIGENCE",
    items: [
      { href: "/mission", icon: Brain, label: "Mission Control", color: "text-bmx-cyan", badge: "AI" },
      { href: "/court", icon: Scale, label: "AI Courtroom", color: "text-purple-400", badge: "AI" },
      { href: "/evidence", icon: Database, label: "Evidence Vault", color: "text-bmx-green" },
      { href: "/monitor", icon: Rss, label: "Monitor", color: "text-bmx-orange" },
      { href: "/replay", icon: Zap, label: "Replay Lab", color: "text-bmx-yellow" },
    ],
  },
  {
    label: "WORKSPACE",
    items: [
      { href: "/copilot", icon: MessageSquare, label: "AI Copilot", color: "text-bmx-green" },
      { href: "/workflows", icon: Play, label: "Workflows", color: "text-bmx-cyan" },
      { href: "/reports", icon: FileText, label: "Reports", color: "text-blue-400" },
      { href: "/demo", icon: Zap, label: "Demo Mode", color: "text-bmx-yellow", badge: "DEMO" },
      { href: "/settings", icon: Settings, label: "Settings", color: "text-gray-400" },
    ],
  },
  {
    label: "AVROS",
    items: [
      { href: "/orchestrator", icon: Cpu, label: "Orchestrator", color: "text-bmx-cyan", badge: "NEW" },
      { href: "/browser-intel", icon: Globe, label: "Browser Intel", color: "text-bmx-teal", badge: "NEW" },
      { href: "/api-intel", icon: Link2, label: "API Intel", color: "text-bmx-orange", badge: "NEW" },
      { href: "/chains", icon: Layers, label: "Attack Chains", color: "text-bmx-red", badge: "NEW" },
      { href: "/memory", icon: Database, label: "Memory", color: "text-purple-400", badge: "NEW" },
      { href: "/workers", icon: Server, label: "Workers", color: "text-bmx-green", badge: "NEW" },
    ],
  },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();
  const { user, logout } = useAuthStore();

  return (
    <div className="flex h-screen bg-bmx-black overflow-hidden">
      <motion.aside
        animate={{ width: collapsed ? 60 : 224 }}
        transition={{ duration: 0.2, ease: "easeInOut" }}
        className="flex-shrink-0 bg-bmx-dark border-r border-bmx-border flex flex-col relative z-10"
      >
        <div className="h-14 flex items-center px-3 border-b border-bmx-border overflow-hidden gap-2">
          <Shield className="w-5 h-5 text-bmx-cyan flex-shrink-0" />
          {!collapsed && (
            <div className="overflow-hidden">
              <div className="text-xs font-bold text-bmx-cyan tracking-widest font-mono leading-none">BLACKMIRROR</div>
              <div className="text-xs text-bmx-teal tracking-widest font-mono leading-none mt-0.5">GLASSWING</div>
            </div>
          )}
        </div>

        <nav className="flex-1 py-3 overflow-y-auto overflow-x-hidden">
          {NAV_SECTIONS.map((section) => (
            <div key={section.label} className="mb-2">
              {!collapsed && (
                <p className="px-3 py-1 text-[10px] font-mono tracking-[0.15em] text-bmx-muted/50">{section.label}</p>
              )}
              <div className="space-y-0.5 px-2">
                {section.items.map((item) => {
                  const isActive = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href));
                  const Icon = item.icon;
                  return (
                    <Link key={item.href} href={item.href}>
                      <motion.div
                        whileHover={{ x: collapsed ? 0 : 2 }}
                        className={cn(
                          "flex items-center gap-2.5 px-2.5 py-2 rounded text-xs transition-all duration-150 cursor-pointer group",
                          isActive ? "bg-bmx-border text-white" : "text-bmx-muted hover:text-white hover:bg-bmx-border/40"
                        )}
                      >
                        <Icon className={cn("w-3.5 h-3.5 flex-shrink-0 transition-colors", isActive ? item.color : "")} />
                        {!collapsed && (
                          <>
                            <span className="font-mono truncate flex-1">{item.label}</span>
                            {item.badge && (
                              <span className="text-[9px] font-mono bg-bmx-cyan/10 text-bmx-cyan border border-bmx-cyan/30 px-1 py-0.5 rounded">
                                {item.badge}
                              </span>
                            )}
                          </>
                        )}
                      </motion.div>
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div className="border-t border-bmx-border p-2 space-y-1">
          {!collapsed && user && (
            <div className="flex items-center gap-2 px-2 py-1.5">
              <div className="w-6 h-6 rounded-full bg-bmx-cyan/10 border border-bmx-cyan/30 flex items-center justify-center">
                <User className="w-3 h-3 text-bmx-cyan" />
              </div>
              <p className="text-white font-mono text-xs truncate flex-1">{user.email?.split("@")[0]}</p>
              <button onClick={logout} className="text-bmx-muted hover:text-white transition-colors">
                <LogOut className="w-3 h-3" />
              </button>
            </div>
          )}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="w-full flex items-center justify-center p-2 text-bmx-muted hover:text-white transition-colors rounded hover:bg-bmx-border/40"
          >
            {collapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
          </button>
        </div>
      </motion.aside>

      <main className="flex-1 overflow-hidden flex flex-col min-w-0">
        <div className="h-14 border-b border-bmx-border flex items-center px-6 gap-4 bg-bmx-dark/50 flex-shrink-0">
          <div className="flex items-center gap-2 flex-1">
            <div className="w-1.5 h-1.5 rounded-full bg-bmx-green animate-pulse" />
            <span className="text-bmx-muted font-mono text-xs">GLASSWING OS v2.0.0</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs font-mono text-bmx-muted">
            <Activity className="w-3 h-3 text-bmx-cyan" />
            <span>AI ONLINE</span>
          </div>
        </div>
        <div className="flex-1 overflow-auto bg-bmx-black bg-grid-pattern bg-grid">
          {children}
        </div>
      </main>
    </div>
  );
}
