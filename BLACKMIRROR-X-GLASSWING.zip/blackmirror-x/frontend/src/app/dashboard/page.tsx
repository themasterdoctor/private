"use client";
import { useEffect, useState } from "react";
import { useAppStore } from "@/store/app";
import { scanApi } from "@/lib/api";
import {
  Activity, AlertTriangle, Globe, Shield, Plus, ArrowRight,
  TrendingUp, Zap, Clock
} from "lucide-react";
import Link from "next/link";

const SEVERITY_COLORS: Record<string, string> = {
  critical: "text-red-400 bg-red-400/10 border-red-400/20",
  high: "text-orange-400 bg-orange-400/10 border-orange-400/20",
  medium: "text-yellow-400 bg-yellow-400/10 border-yellow-400/20",
  low: "text-blue-400 bg-blue-400/10 border-blue-400/20",
  info: "text-gray-400 bg-gray-400/10 border-gray-400/20",
};

const STATUS_COLORS: Record<string, string> = {
  running: "text-bmx-cyan",
  completed: "text-bmx-green",
  failed: "text-bmx-red",
  pending: "text-bmx-yellow",
  cancelled: "text-bmx-muted",
};

export default function DashboardPage() {
  const { scans, vulns, subdomains, fetchScans, fetchVulns, fetchSubdomains, activeWorkspace, createScan } = useAppStore();
  const [newTarget, setNewTarget] = useState("");
  const [launching, setLaunching] = useState(false);

  useEffect(() => {
    if (activeWorkspace) {
      fetchScans(activeWorkspace.id);
      fetchVulns({ workspace_id: activeWorkspace.id });
      fetchSubdomains({ workspace_id: activeWorkspace.id });
    }
  }, [activeWorkspace]);

  const totalVulns = vulns.length;
  const criticalCount = vulns.filter((v) => v.severity === "critical").length;
  const highCount = vulns.filter((v) => v.severity === "high").length;
  const runningScans = scans.filter((s) => s.status === "running").length;

  const launchScan = async () => {
    if (!newTarget.trim() || !activeWorkspace) return;
    setLaunching(true);
    try {
      await createScan({ target: newTarget.trim(), workspace_id: activeWorkspace.id });
      setNewTarget("");
      await fetchScans(activeWorkspace.id);
    } finally {
      setLaunching(false);
    }
  };

  const stats = [
    { label: "Active Scans", value: runningScans, icon: Activity, color: "text-bmx-cyan", bg: "bg-bmx-cyan/10 border-bmx-cyan/20" },
    { label: "Vulnerabilities", value: totalVulns, icon: AlertTriangle, color: "text-bmx-orange", bg: "bg-bmx-orange/10 border-bmx-orange/20" },
    { label: "Subdomains", value: subdomains.length, icon: Globe, color: "text-bmx-teal", bg: "bg-bmx-teal/10 border-bmx-teal/20" },
    { label: "Critical Findings", value: criticalCount, icon: Shield, color: "text-bmx-red", bg: "bg-bmx-red/10 border-bmx-red/20" },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white font-mono text-xl font-bold">
            MISSION CONTROL
          </h1>
          <p className="text-bmx-muted text-sm font-mono mt-0.5">
            {activeWorkspace?.name || "No workspace selected"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-bmx-green animate-pulse" />
          <span className="text-bmx-green text-xs font-mono">SYSTEMS ONLINE</span>
        </div>
      </div>

      {/* Quick Launch */}
      <div className="bmx-panel rounded-lg border border-bmx-border p-4">
        <div className="flex items-center gap-2 mb-3">
          <Zap className="w-4 h-4 text-bmx-cyan" />
          <span className="text-white font-mono text-xs tracking-wider">QUICK LAUNCH SCAN</span>
        </div>
        <div className="flex gap-3">
          <input
            type="text"
            value={newTarget}
            onChange={(e) => setNewTarget(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && launchScan()}
            placeholder="target.com or https://app.target.com"
            className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan transition-colors placeholder:text-bmx-muted/40"
          />
          <button
            onClick={launchScan}
            disabled={launching || !newTarget.trim()}
            className="flex items-center gap-2 bg-bmx-cyan text-bmx-black font-mono font-bold text-sm px-4 py-2 rounded hover:bg-bmx-cyan/90 transition-colors disabled:opacity-50"
          >
            <Plus className="w-4 h-4" />
            {launching ? "LAUNCHING..." : "LAUNCH"}
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div key={stat.label} className={`bmx-panel rounded-lg border p-4 ${stat.bg}`}>
            <div className="flex items-center justify-between mb-3">
              <stat.icon className={`w-5 h-5 ${stat.color}`} />
              <TrendingUp className="w-3.5 h-3.5 text-bmx-muted/40" />
            </div>
            <div className={`text-2xl font-mono font-bold ${stat.color}`}>{stat.value}</div>
            <div className="text-bmx-muted text-xs font-mono mt-1">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Severity breakdown */}
      <div className="bmx-panel rounded-lg border border-bmx-border p-4">
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle className="w-4 h-4 text-bmx-orange" />
          <span className="text-white font-mono text-xs tracking-wider">VULNERABILITY BREAKDOWN</span>
          <Link href="/vulns" className="ml-auto flex items-center gap-1 text-bmx-cyan text-xs font-mono hover:underline">
            VIEW ALL <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
        <div className="flex gap-3 flex-wrap">
          {["critical", "high", "medium", "low", "info"].map((sev) => {
            const count = vulns.filter((v) => v.severity === sev).length;
            return (
              <div key={sev} className={`px-3 py-1.5 rounded border text-xs font-mono ${SEVERITY_COLORS[sev]}`}>
                {sev.toUpperCase()}: {count}
              </div>
            );
          })}
        </div>
        {/* Mini bar chart */}
        <div className="mt-4 space-y-2">
          {["critical", "high", "medium"].map((sev) => {
            const count = vulns.filter((v) => v.severity === sev).length;
            const pct = totalVulns ? (count / totalVulns) * 100 : 0;
            return (
              <div key={sev} className="flex items-center gap-3">
                <span className="text-bmx-muted text-xs font-mono w-16">{sev}</span>
                <div className="flex-1 h-1.5 bg-bmx-border rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${pct}%`,
                      background: sev === "critical" ? "#ff3366" : sev === "high" ? "#ff6b35" : "#ffd60a",
                    }}
                  />
                </div>
                <span className="text-bmx-muted text-xs font-mono w-8 text-right">{count}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Scans */}
      <div className="bmx-panel rounded-lg border border-bmx-border">
        <div className="flex items-center gap-2 p-4 border-b border-bmx-border">
          <Clock className="w-4 h-4 text-bmx-cyan" />
          <span className="text-white font-mono text-xs tracking-wider">RECENT SCANS</span>
          <Link href="/recon" className="ml-auto flex items-center gap-1 text-bmx-cyan text-xs font-mono hover:underline">
            RECON DASHBOARD <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
        <div className="divide-y divide-bmx-border">
          {scans.slice(0, 8).map((scan) => (
            <Link
              key={scan.id}
              href={`/scans/${scan.id}`}
              className="flex items-center gap-4 px-4 py-3 hover:bg-bmx-panel/50 transition-colors group"
            >
              <div className="flex-1 min-w-0">
                <p className="text-white font-mono text-sm truncate">{scan.target}</p>
                <p className="text-bmx-muted text-xs font-mono mt-0.5">
                  {scan.scan_type} • {new Date(scan.created_at).toLocaleString()}
                </p>
              </div>
              <div className="flex items-center gap-4 text-xs font-mono shrink-0">
                <span className="text-bmx-muted">{scan.subdomain_count} subs</span>
                <span className="text-bmx-muted">{scan.vuln_count} vulns</span>
                <span className={STATUS_COLORS[scan.status] || "text-bmx-muted"}>
                  {scan.status.toUpperCase()}
                </span>
                <ArrowRight className="w-3.5 h-3.5 text-bmx-muted opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </Link>
          ))}
          {scans.length === 0 && (
            <div className="px-4 py-8 text-center text-bmx-muted font-mono text-sm">
              No scans yet. Launch your first scan above.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
