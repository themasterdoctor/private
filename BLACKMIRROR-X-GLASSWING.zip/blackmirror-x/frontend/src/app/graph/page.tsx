"use client";
import { useEffect, useRef, useState } from "react";
import { useAppStore } from "@/store/app";
import { Network, ZoomIn, ZoomOut, Maximize2 } from "lucide-react";

interface GraphNode {
  id: string;
  label: string;
  type: "target" | "subdomain" | "vuln" | "service";
  severity?: string;
  x?: number;
  y?: number;
  vx?: number;
  vy?: number;
}

interface GraphEdge {
  source: string;
  target: string;
  label?: string;
}

const NODE_COLORS: Record<string, string> = {
  target: "#00e5ff",
  subdomain: "#00b4d8",
  vuln: "#ff3366",
  service: "#00ff88",
};
const SEV_COLORS: Record<string, string> = {
  critical: "#ff3366",
  high: "#ff6b35",
  medium: "#ffd60a",
  low: "#60a5fa",
  info: "#6b7280",
};

export default function AttackGraphPage() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { subdomains, vulns, fetchSubdomains, fetchVulns, activeWorkspace } = useAppStore();
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [lastMouse, setLastMouse] = useState({ x: 0, y: 0 });
  const nodesRef = useRef<GraphNode[]>([]);
  const edgesRef = useRef<GraphEdge[]>([]);
  const animRef = useRef<number>(0);

  useEffect(() => {
    if (!activeWorkspace) return;
    fetchSubdomains({ workspace_id: activeWorkspace.id });
    fetchVulns({ workspace_id: activeWorkspace.id });
  }, [activeWorkspace]);

  useEffect(() => {
    if (!subdomains.length && !vulns.length) return;

    // Build graph
    const nodes: GraphNode[] = [];
    const edges: GraphEdge[] = [];
    const W = canvasRef.current?.width || 800;
    const H = canvasRef.current?.height || 600;

    // Target root node
    const rootId = "root";
    nodes.push({
      id: rootId,
      label: activeWorkspace?.name || "TARGET",
      type: "target",
      x: W / 2,
      y: H / 2,
    });

    // Subdomains
    subdomains.slice(0, 40).forEach((sub, i) => {
      const angle = (i / Math.min(subdomains.length, 40)) * 2 * Math.PI;
      const r = 180;
      nodes.push({
        id: sub.id,
        label: sub.subdomain.split(".")[0],
        type: "subdomain",
        x: W / 2 + r * Math.cos(angle),
        y: H / 2 + r * Math.sin(angle),
      });
      edges.push({ source: rootId, target: sub.id });
    });

    // Vulns
    vulns.slice(0, 30).forEach((v, i) => {
      const angle = (i / Math.min(vulns.length, 30)) * 2 * Math.PI;
      const r = 320;
      nodes.push({
        id: v.id,
        label: v.vuln_type,
        type: "vuln",
        severity: v.severity,
        x: W / 2 + r * Math.cos(angle),
        y: H / 2 + r * Math.sin(angle),
      });
      // Connect to matching subdomain if possible
      const matchSub = subdomains.find((s) => v.url.includes(s.subdomain));
      edges.push({ source: matchSub?.id || rootId, target: v.id });
    });

    nodesRef.current = nodes;
    edgesRef.current = edges;
    startSimulation();
  }, [subdomains, vulns]);

  const startSimulation = () => {
    cancelAnimationFrame(animRef.current);
    let tick = 0;
    const simulate = () => {
      tick++;
      const nodes = nodesRef.current;
      const edges = edgesRef.current;
      const W = canvasRef.current?.width || 800;
      const H = canvasRef.current?.height || 600;

      // Simple force simulation
      if (tick < 200) {
        for (const n of nodes) {
          if (!n.vx) n.vx = 0;
          if (!n.vy) n.vy = 0;

          // Repulsion
          for (const m of nodes) {
            if (m.id === n.id) continue;
            const dx = (n.x || 0) - (m.x || 0);
            const dy = (n.y || 0) - (m.y || 0);
            const dist = Math.sqrt(dx * dx + dy * dy) || 1;
            const force = 3000 / (dist * dist);
            n.vx += (dx / dist) * force;
            n.vy += (dy / dist) * force;
          }
        }

        // Attraction for edges
        for (const e of edges) {
          const s = nodes.find((n) => n.id === e.source);
          const t = nodes.find((n) => n.id === e.target);
          if (!s || !t) continue;
          const dx = (t.x || 0) - (s.x || 0);
          const dy = (t.y || 0) - (s.y || 0);
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          const strength = 0.05;
          s.vx = ((s.vx || 0) + dx * strength) * 0.8;
          s.vy = ((s.vy || 0) + dy * strength) * 0.8;
          t.vx = ((t.vx || 0) - dx * strength) * 0.8;
          t.vy = ((t.vy || 0) - dy * strength) * 0.8;
        }

        for (const n of nodes) {
          if (n.type === "target") continue; // pin root
          n.x = Math.max(30, Math.min(W - 30, (n.x || 0) + (n.vx || 0) * 0.1));
          n.y = Math.max(30, Math.min(H - 30, (n.y || 0) + (n.vy || 0) * 0.1));
          n.vx = (n.vx || 0) * 0.7;
          n.vy = (n.vy || 0) * 0.7;
        }
      }

      drawGraph();
      animRef.current = requestAnimationFrame(simulate);
    };
    animRef.current = requestAnimationFrame(simulate);
  };

  const drawGraph = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.save();
    ctx.translate(pan.x, pan.y);
    ctx.scale(zoom, zoom);

    // Draw edges
    for (const e of edgesRef.current) {
      const s = nodesRef.current.find((n) => n.id === e.source);
      const t = nodesRef.current.find((n) => n.id === e.target);
      if (!s || !t) continue;
      ctx.beginPath();
      ctx.moveTo(s.x || 0, s.y || 0);
      ctx.lineTo(t.x || 0, t.y || 0);
      ctx.strokeStyle = t.type === "vuln"
        ? (SEV_COLORS[t.severity || "info"] + "40")
        : "#1a274440";
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    // Draw nodes
    for (const n of nodesRef.current) {
      const x = n.x || 0;
      const y = n.y || 0;
      const r = n.type === "target" ? 22 : n.type === "vuln" ? 10 : 14;
      const color = n.type === "vuln" ? (SEV_COLORS[n.severity || "info"]) : NODE_COLORS[n.type];

      // Glow
      const glow = ctx.createRadialGradient(x, y, 0, x, y, r * 2.5);
      glow.addColorStop(0, color + "30");
      glow.addColorStop(1, "transparent");
      ctx.beginPath();
      ctx.arc(x, y, r * 2.5, 0, Math.PI * 2);
      ctx.fillStyle = glow;
      ctx.fill();

      // Node
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fillStyle = color + "20";
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.5;
      ctx.fill();
      ctx.stroke();

      // Label
      ctx.fillStyle = "#e2e8f0";
      ctx.font = `${n.type === "target" ? "11px" : "9px"} JetBrains Mono, monospace`;
      ctx.textAlign = "center";
      ctx.fillText(n.label.slice(0, 12), x, y + r + 14);
    }

    ctx.restore();
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    setZoom((z) => Math.max(0.3, Math.min(3, z - e.deltaY * 0.001)));
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsPanning(true);
    setLastMouse({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isPanning) return;
    setPan((p) => ({ x: p.x + e.clientX - lastMouse.x, y: p.y + e.clientY - lastMouse.y }));
    setLastMouse({ x: e.clientX, y: e.clientY });
  };

  useEffect(() => {
    drawGraph();
  }, [zoom, pan]);

  const resetView = () => { setZoom(1); setPan({ x: 0, y: 0 }); };

  return (
    <div className="p-6 h-full flex flex-col space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white font-mono text-xl font-bold">ATTACK SURFACE GRAPH</h1>
          <p className="text-bmx-muted text-sm font-mono mt-0.5">
            {nodesRef.current.length} nodes • {edgesRef.current.length} edges
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setZoom((z) => Math.min(3, z + 0.1))} className="bmx-panel border border-bmx-border p-2 rounded hover:border-bmx-cyan transition-colors">
            <ZoomIn className="w-4 h-4 text-bmx-muted" />
          </button>
          <button onClick={() => setZoom((z) => Math.max(0.3, z - 0.1))} className="bmx-panel border border-bmx-border p-2 rounded hover:border-bmx-cyan transition-colors">
            <ZoomOut className="w-4 h-4 text-bmx-muted" />
          </button>
          <button onClick={resetView} className="bmx-panel border border-bmx-border p-2 rounded hover:border-bmx-cyan transition-colors">
            <Maximize2 className="w-4 h-4 text-bmx-muted" />
          </button>
        </div>
      </div>

      {/* Legend */}
      <div className="flex gap-4 flex-wrap text-xs font-mono">
        {Object.entries(NODE_COLORS).map(([t, c]) => (
          <div key={t} className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-full border-2" style={{ borderColor: c, backgroundColor: c + "20" }} />
            <span className="text-bmx-muted">{t}</span>
          </div>
        ))}
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded-full border-2" style={{ borderColor: "#ff3366", backgroundColor: "#ff336620" }} />
          <span className="text-bmx-muted">critical vuln</span>
        </div>
      </div>

      {/* Canvas */}
      <div className="flex-1 bmx-panel rounded-lg border border-bmx-border overflow-hidden relative">
        {nodesRef.current.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <Network className="w-12 h-12 text-bmx-muted/20 mx-auto mb-3" />
              <p className="text-bmx-muted font-mono text-sm">Run a scan to generate the attack graph.</p>
            </div>
          </div>
        )}
        <canvas
          ref={canvasRef}
          width={1400}
          height={800}
          className="w-full h-full cursor-grab active:cursor-grabbing"
          onWheel={handleWheel}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={() => setIsPanning(false)}
          onMouseLeave={() => setIsPanning(false)}
        />
      </div>
    </div>
  );
}
