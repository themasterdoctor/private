"use client";
import { useEffect, useState } from "react";
import { Database, CheckCircle, XCircle, TrendingUp, Globe, Plus } from "lucide-react";
import { useAppStore } from "@/store/app";

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

interface MemorySummary {
  workspace_id: string;
  program: { program_name: string; in_scope_count: number; bounty_table: Record<string, string> };
  feedback_count: number;
  accepted: number;
  rejected: number;
  known_domains: string[];
  rejection_patterns: Array<{ vuln_type: string; rejection_count: number; common_reasons: string[] }>;
  accepted_patterns: Array<{ vuln_type: string; accepted_count: number; bounties: string[] }>;
}

export default function MemoryPage() {
  const { activeWorkspace } = useAppStore();
  const [memory, setMemory] = useState<MemorySummary | null>(null);
  const [loading, setLoading] = useState(false);
  const [feedbackForm, setFeedbackForm] = useState({ vuln_type: "xss", severity: "high", outcome: "accepted", reason: "", bounty: "" });
  const [saved, setSaved] = useState(false);

  const getToken = () => localStorage.getItem("bmx_token") || "";
  const wsId = activeWorkspace?.id || "default";

  async function fetchMemory() {
    setLoading(true);
    try {
      const r = await fetch(`${API}/api/v1/memory/${wsId}`, {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      if (r.ok) setMemory(await r.json());
    } catch {/* */} finally { setLoading(false); }
  }

  async function submitFeedback() {
    const params = new URLSearchParams({
      finding_id: `manual-${Date.now()}`,
      vuln_type: feedbackForm.vuln_type,
      severity: feedbackForm.severity,
      outcome: feedbackForm.outcome,
      reason: feedbackForm.reason,
      bounty_paid: feedbackForm.bounty,
    });
    await fetch(`${API}/api/v1/memory/${wsId}/feedback?${params}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${getToken()}` },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    fetchMemory();
  }

  useEffect(() => { fetchMemory(); }, [wsId]);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Database className="w-6 h-6 text-purple-400" />
        <div>
          <h1 className="text-xl font-bold text-white font-mono">Strategic Memory</h1>
          <p className="text-xs text-bmx-muted">Program rules, feedback loops, and target intelligence</p>
        </div>
        <button onClick={fetchMemory} className="ml-auto text-xs text-bmx-muted border border-bmx-border rounded px-3 py-1.5 hover:text-white">
          {loading ? "Loading..." : "Refresh"}
        </button>
      </div>

      {memory && (
        <>
          {/* Stats */}
          <div className="grid grid-cols-4 gap-3">
            {[
              { label: "Total Feedback", val: memory.feedback_count, color: "text-white" },
              { label: "Accepted", val: memory.accepted, color: "text-bmx-green" },
              { label: "Rejected", val: memory.rejected, color: "text-bmx-red" },
              { label: "Known Domains", val: memory.known_domains.length, color: "text-bmx-cyan" },
            ].map((s) => (
              <div key={s.label} className="bg-bmx-dark border border-bmx-border rounded-lg p-3 text-center">
                <div className={`text-2xl font-bold font-mono ${s.color}`}>{s.val}</div>
                <div className="text-xs text-bmx-muted mt-1">{s.label}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-6">
            {/* Rejection Patterns */}
            <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-3">
                <XCircle className="w-4 h-4 text-bmx-red" />
                <span className="text-sm font-mono text-white">Rejection Patterns</span>
              </div>
              {memory.rejection_patterns.length === 0 ? (
                <p className="text-xs text-bmx-muted text-center py-4">No rejection patterns yet</p>
              ) : (
                <div className="space-y-2">
                  {memory.rejection_patterns.map((p, i) => (
                    <div key={i} className="bg-bmx-black rounded p-3 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-bmx-red font-mono uppercase">{p.vuln_type}</span>
                        <span className="text-bmx-muted">{p.rejection_count}×</span>
                      </div>
                      {p.common_reasons.length > 0 && (
                        <div className="text-bmx-muted mt-1">{p.common_reasons[0]}</div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Accepted Patterns */}
            <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle className="w-4 h-4 text-bmx-green" />
                <span className="text-sm font-mono text-white">Accepted Patterns</span>
              </div>
              {memory.accepted_patterns.length === 0 ? (
                <p className="text-xs text-bmx-muted text-center py-4">No accepted patterns yet</p>
              ) : (
                <div className="space-y-2">
                  {memory.accepted_patterns.map((p, i) => (
                    <div key={i} className="bg-bmx-black rounded p-3 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-bmx-green font-mono uppercase">{p.vuln_type}</span>
                        <span className="text-bmx-muted">{p.accepted_count}×</span>
                      </div>
                      {p.bounties.length > 0 && (
                        <div className="text-bmx-yellow mt-1">{p.bounties[0]}</div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Program profile */}
          {memory.program?.program_name && (
            <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-3">
                <Globe className="w-4 h-4 text-bmx-cyan" />
                <span className="text-sm font-mono text-white">{memory.program.program_name}</span>
              </div>
              <div className="grid grid-cols-2 gap-4 text-xs text-bmx-muted">
                <span>Scope rules: <span className="text-white">{memory.program.in_scope_count}</span></span>
                <div className="flex gap-2">
                  {Object.entries(memory.program.bounty_table || {}).map(([k, v]) => (
                    <span key={k} className="text-bmx-green">{k}: {v}</span>
                  ))}
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* Add feedback */}
      <div className="bg-bmx-dark border border-bmx-border rounded-lg p-4 space-y-3">
        <div className="flex items-center gap-2">
          <Plus className="w-4 h-4 text-purple-400" />
          <span className="text-sm font-mono text-white">Record Finding Feedback</span>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-bmx-muted block mb-1">Vuln Type</label>
            <input value={feedbackForm.vuln_type}
              onChange={(e) => setFeedbackForm({ ...feedbackForm, vuln_type: e.target.value })}
              className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-purple-400 outline-none" />
          </div>
          <div>
            <label className="text-xs text-bmx-muted block mb-1">Outcome</label>
            <select value={feedbackForm.outcome}
              onChange={(e) => setFeedbackForm({ ...feedbackForm, outcome: e.target.value })}
              className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white focus:border-purple-400 outline-none">
              {["accepted", "rejected", "duplicate", "informative"].map((o) => (
                <option key={o}>{o}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs text-bmx-muted block mb-1">Reason (optional)</label>
            <input value={feedbackForm.reason}
              onChange={(e) => setFeedbackForm({ ...feedbackForm, reason: e.target.value })}
              className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-purple-400 outline-none" />
          </div>
          <div>
            <label className="text-xs text-bmx-muted block mb-1">Bounty Paid (optional)</label>
            <input value={feedbackForm.bounty}
              onChange={(e) => setFeedbackForm({ ...feedbackForm, bounty: e.target.value })}
              placeholder="$500"
              className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-purple-400 outline-none" />
          </div>
        </div>
        <button onClick={submitFeedback}
          className="px-4 py-2 text-sm font-mono bg-purple-400/10 text-purple-400 border border-purple-400/30 rounded hover:bg-purple-400/20 transition-colors">
          {saved ? "✓ Saved" : "Record Feedback"}
        </button>
      </div>
    </div>
  );
}
