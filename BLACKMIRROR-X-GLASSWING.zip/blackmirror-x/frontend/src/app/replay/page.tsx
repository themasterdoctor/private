"use client";
import { useState } from "react";
import {
  Play, RotateCcw, Plus, Minus, Code,
  Send, ChevronRight, Zap, Copy
} from "lucide-react";

interface ReplayRequest {
  id: string;
  name: string;
  method: string;
  url: string;
  headers: Record<string, string>;
  body: string;
}

interface ReplayResponse {
  status: number;
  statusText: string;
  headers: Record<string, string>;
  body: string;
  elapsed_ms: number;
}

const METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"];

const SAMPLE_REQUESTS: ReplayRequest[] = [
  {
    id: "1",
    name: "IDOR Test — User Profile",
    method: "GET",
    url: "https://target.com/api/users/123/profile",
    headers: { Authorization: "Bearer eyJ...", "Content-Type": "application/json" },
    body: "",
  },
  {
    id: "2",
    name: "SQLi Test — Search Param",
    method: "GET",
    url: "https://target.com/api/search?q=' OR 1=1--",
    headers: { Authorization: "Bearer eyJ..." },
    body: "",
  },
  {
    id: "3",
    name: "SSRF Test — Import URL",
    method: "POST",
    url: "https://target.com/api/import",
    headers: { "Content-Type": "application/json", Authorization: "Bearer eyJ..." },
    body: '{"url": "http://169.254.169.254/latest/meta-data/"}',
  },
];

export default function ReplayLabPage() {
  const [requests, setRequests] = useState<ReplayRequest[]>(SAMPLE_REQUESTS);
  const [active, setActive] = useState<ReplayRequest>(SAMPLE_REQUESTS[0]);
  const [response, setResponse] = useState<ReplayResponse | null>(null);
  const [sending, setSending] = useState(false);
  const [activeTab, setActiveTab] = useState<"headers" | "body">("headers");
  const [respTab, setRespTab] = useState<"body" | "headers">("body");
  const [headerInput, setHeaderInput] = useState<[string, string][]>(
    Object.entries(SAMPLE_REQUESTS[0].headers)
  );

  const sendRequest = async () => {
    setSending(true);
    const start = Date.now();
    try {
      const headers: Record<string, string> = {};
      headerInput.forEach(([k, v]) => { if (k) headers[k] = v; });

      const res = await fetch(active.url, {
        method: active.method,
        headers,
        body: active.method !== "GET" && active.body ? active.body : undefined,
        mode: "no-cors",
      });
      const body = await res.text().catch(() => "");
      const resHeaders: Record<string, string> = {};
      res.headers.forEach((v, k) => { resHeaders[k] = v; });

      setResponse({
        status: res.status || 200,
        statusText: res.statusText || "OK",
        headers: resHeaders,
        body: body || '{"note": "CORS or no-cors mode — response body not accessible from browser. Use backend proxy for full response."}',
        elapsed_ms: Date.now() - start,
      });
    } catch (e) {
      setResponse({
        status: 0,
        statusText: "Error",
        headers: {},
        body: `Error: ${e instanceof Error ? e.message : String(e)}\n\nNote: Direct browser requests may be blocked by CORS. This is expected for security testing.`,
        elapsed_ms: Date.now() - start,
      });
    }
    setSending(false);
  };

  const addHeader = () => setHeaderInput((prev) => [...prev, ["", ""]]);
  const removeHeader = (i: number) => setHeaderInput((prev) => prev.filter((_, idx) => idx !== i));
  const updateHeader = (i: number, key: string, val: string) => {
    setHeaderInput((prev) => prev.map((h, idx) => idx === i ? [key, val] : h));
  };

  const statusColor = (status: number) => {
    if (status >= 500) return "text-red-400";
    if (status >= 400) return "text-bmx-orange";
    if (status >= 300) return "text-bmx-yellow";
    if (status >= 200) return "text-bmx-green";
    return "text-bmx-muted";
  };

  return (
    <div className="p-6 space-y-4">
      {/* Header */}
      <div>
        <h1 className="text-white font-mono text-xl font-bold flex items-center gap-2">
          <Zap className="w-5 h-5 text-bmx-cyan" />
          REPLAY LAB
        </h1>
        <p className="text-bmx-muted text-sm font-mono mt-0.5">
          Request replay · Payload testing · Response analysis
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 h-[700px]">
        {/* Saved requests */}
        <div className="bmx-panel rounded-lg border border-bmx-border overflow-hidden flex flex-col">
          <div className="p-3 border-b border-bmx-border flex items-center gap-2">
            <Code className="w-3.5 h-3.5 text-bmx-cyan" />
            <span className="text-white font-mono text-xs tracking-wider">SAVED REQUESTS</span>
          </div>
          <div className="overflow-y-auto flex-1 divide-y divide-bmx-border">
            {requests.map((req) => (
              <div
                key={req.id}
                onClick={() => {
                  setActive(req);
                  setHeaderInput(Object.entries(req.headers));
                  setResponse(null);
                }}
                className={`px-3 py-2.5 cursor-pointer transition-colors ${
                  active.id === req.id ? "bg-bmx-cyan/5 border-l-2 border-bmx-cyan" : "hover:bg-bmx-panel/50"
                }`}
              >
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className={`text-xs font-mono font-bold ${
                    req.method === "GET" ? "text-bmx-green" : req.method === "POST" ? "text-bmx-orange" : "text-bmx-yellow"
                  }`}>{req.method}</span>
                </div>
                <p className="text-white font-mono text-xs leading-tight">{req.name}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Request builder */}
        <div className="lg:col-span-2 bmx-panel rounded-lg border border-bmx-border flex flex-col overflow-hidden">
          {/* URL bar */}
          <div className="p-3 border-b border-bmx-border flex gap-2">
            <select
              value={active.method}
              onChange={(e) => setActive({ ...active, method: e.target.value })}
              className="bg-bmx-black border border-bmx-border rounded px-2 text-white font-mono text-xs focus:outline-none focus:border-bmx-cyan w-20"
            >
              {METHODS.map((m) => <option key={m}>{m}</option>)}
            </select>
            <input
              value={active.url}
              onChange={(e) => setActive({ ...active, url: e.target.value })}
              className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-bmx-cyan"
            />
            <button
              onClick={sendRequest}
              disabled={sending}
              className="flex items-center gap-1.5 bg-bmx-cyan text-bmx-black font-mono font-bold text-xs px-3 py-1.5 rounded hover:bg-bmx-cyan/90 transition-colors disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" />
              {sending ? "..." : "SEND"}
            </button>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-bmx-border px-3">
            {["headers", "body"].map((t) => (
              <button
                key={t}
                onClick={() => setActiveTab(t as typeof activeTab)}
                className={`py-2 mr-4 text-xs font-mono tracking-wider transition-colors ${
                  activeTab === t ? "text-bmx-cyan border-b-2 border-bmx-cyan" : "text-bmx-muted"
                }`}
              >
                {t.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Body */}
          <div className="flex-1 overflow-auto p-3">
            {activeTab === "headers" && (
              <div className="space-y-1.5">
                {headerInput.map(([k, v], i) => (
                  <div key={i} className="flex gap-2">
                    <input
                      value={k}
                      onChange={(e) => updateHeader(i, e.target.value, v)}
                      placeholder="Header"
                      className="flex-1 bg-bmx-black border border-bmx-border rounded px-2 py-1 text-white font-mono text-xs focus:outline-none focus:border-bmx-cyan"
                    />
                    <input
                      value={v}
                      onChange={(e) => updateHeader(i, k, e.target.value)}
                      placeholder="Value"
                      className="flex-1 bg-bmx-black border border-bmx-border rounded px-2 py-1 text-white font-mono text-xs focus:outline-none focus:border-bmx-cyan"
                    />
                    <button onClick={() => removeHeader(i)} className="text-bmx-muted hover:text-bmx-red transition-colors">
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
                <button
                  onClick={addHeader}
                  className="flex items-center gap-1.5 text-bmx-muted text-xs font-mono hover:text-white transition-colors mt-2"
                >
                  <Plus className="w-3 h-3" />
                  Add header
                </button>
              </div>
            )}
            {activeTab === "body" && (
              <textarea
                value={active.body}
                onChange={(e) => setActive({ ...active, body: e.target.value })}
                placeholder='{"key": "value"}'
                className="w-full h-full min-h-[200px] bg-transparent text-white font-mono text-xs focus:outline-none resize-none"
              />
            )}
          </div>
        </div>

        {/* Response */}
        <div className="bmx-panel rounded-lg border border-bmx-border flex flex-col overflow-hidden">
          {response ? (
            <>
              <div className="p-3 border-b border-bmx-border flex items-center gap-3">
                <span className={`font-mono text-sm font-bold ${statusColor(response.status)}`}>
                  {response.status} {response.statusText}
                </span>
                <span className="text-bmx-muted font-mono text-xs ml-auto">
                  {response.elapsed_ms}ms
                </span>
              </div>
              <div className="flex border-b border-bmx-border px-3">
                {["body", "headers"].map((t) => (
                  <button
                    key={t}
                    onClick={() => setRespTab(t as typeof respTab)}
                    className={`py-2 mr-4 text-xs font-mono tracking-wider transition-colors ${
                      respTab === t ? "text-bmx-cyan border-b-2 border-bmx-cyan" : "text-bmx-muted"
                    }`}
                  >
                    {t.toUpperCase()}
                  </button>
                ))}
              </div>
              <pre className="flex-1 overflow-auto p-3 text-xs font-mono text-bmx-green terminal whitespace-pre-wrap">
                {respTab === "body" ? response.body : JSON.stringify(response.headers, null, 2)}
              </pre>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-full">
              <Play className="w-8 h-8 text-bmx-muted/20 mb-3" />
              <p className="text-bmx-muted font-mono text-xs">Send a request to see the response</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
