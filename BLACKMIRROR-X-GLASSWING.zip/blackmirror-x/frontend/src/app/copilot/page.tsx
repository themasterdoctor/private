"use client";
import { useEffect, useRef, useState } from "react";
import { useAppStore } from "@/store/app";
import { createCopilotStream, copilotApi } from "@/lib/api";
import { Send, Bot, User, Zap, RefreshCw } from "lucide-react";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  created_at: string;
}

const SUGGESTED = [
  "Analyze the attack surface for this workspace",
  "What are the highest priority vulnerabilities?",
  "Generate a HackerOne report for the critical findings",
  "Suggest SSRF exploitation paths",
  "Explain the XSS findings in detail",
  "What remediation should I prioritize?",
];

export default function CopilotPage() {
  const { activeWorkspace } = useAppStore();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [streaming, setStreaming] = useState(false);
  const [streamingText, setStreamingText] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const stopStreamRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streamingText]);

  const sendMessage = async (text?: string) => {
    const msg = text || input.trim();
    if (!msg || streaming || !activeWorkspace) return;
    setInput("");

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: msg,
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setStreaming(true);
    setStreamingText("");

    let accumulated = "";
    let finalSessionId = sessionId;

    stopStreamRef.current = createCopilotStream(
      msg,
      activeWorkspace.id,
      sessionId,
      (chunk) => {
        accumulated += chunk;
        setStreamingText(accumulated);
      },
      (sid) => {
        if (sid && sid !== sessionId) {
          setSessionId(sid);
          finalSessionId = sid;
        }
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            role: "assistant",
            content: accumulated,
            created_at: new Date().toISOString(),
          },
        ]);
        setStreamingText("");
        setStreaming(false);
      }
    );
  };

  const newSession = () => {
    setSessionId(null);
    setMessages([]);
    setStreamingText("");
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="px-6 py-4 border-b border-bmx-border flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded border border-bmx-cyan/40 bg-bmx-cyan/10 flex items-center justify-center">
            <Bot className="w-4 h-4 text-bmx-cyan" />
          </div>
          <div>
            <h1 className="text-white font-mono text-sm font-bold">GLASSWING COPILOT</h1>
            <p className="text-bmx-muted text-xs font-mono">AI-powered security analyst</p>
          </div>
        </div>
        <button
          onClick={newSession}
          className="flex items-center gap-1.5 text-bmx-muted hover:text-white text-xs font-mono border border-bmx-border px-3 py-1.5 rounded hover:border-bmx-cyan transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" /> NEW SESSION
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
        {messages.length === 0 && !streaming && (
          <div className="space-y-6">
            {/* Welcome */}
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded border border-bmx-cyan/40 bg-bmx-cyan/10 flex items-center justify-center shrink-0 mt-0.5">
                <Bot className="w-3.5 h-3.5 text-bmx-cyan" />
              </div>
              <div className="flex-1">
                <div className="bmx-panel rounded-lg border border-bmx-border p-4">
                  <p className="text-white font-mono text-sm leading-relaxed">
                    GLASSWING online. I&apos;m your AI security analyst for{" "}
                    <span className="text-bmx-cyan">{activeWorkspace?.name || "this workspace"}</span>.
                    I can analyze vulnerabilities, suggest attack paths, generate reports, and assist with triage.
                  </p>
                  <p className="text-bmx-muted font-mono text-xs mt-2">
                    I have full context of your scan results, subdomains, and findings.
                  </p>
                </div>
                {/* Suggested */}
                <div className="mt-3 flex flex-wrap gap-2">
                  {SUGGESTED.map((s) => (
                    <button
                      key={s}
                      onClick={() => sendMessage(s)}
                      className="text-xs font-mono border border-bmx-border text-bmx-muted hover:text-bmx-cyan hover:border-bmx-cyan px-3 py-1.5 rounded transition-colors"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div key={msg.id} className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}>
            <div className={`w-7 h-7 rounded border flex items-center justify-center shrink-0 mt-0.5 ${
              msg.role === "user"
                ? "border-bmx-teal/40 bg-bmx-teal/10"
                : "border-bmx-cyan/40 bg-bmx-cyan/10"
            }`}>
              {msg.role === "user"
                ? <User className="w-3.5 h-3.5 text-bmx-teal" />
                : <Bot className="w-3.5 h-3.5 text-bmx-cyan" />
              }
            </div>
            <div className={`max-w-2xl ${msg.role === "user" ? "items-end" : ""} flex flex-col`}>
              <div className={`bmx-panel rounded-lg border p-4 ${
                msg.role === "user" ? "border-bmx-teal/20 bg-bmx-teal/5" : "border-bmx-border"
              }`}>
                <pre className="text-white font-mono text-sm leading-relaxed whitespace-pre-wrap break-words">
                  {msg.content}
                </pre>
              </div>
              <span className="text-bmx-muted/50 text-xs font-mono mt-1 px-1">
                {new Date(msg.created_at).toLocaleTimeString()}
              </span>
            </div>
          </div>
        ))}

        {/* Streaming */}
        {streaming && (
          <div className="flex gap-3">
            <div className="w-7 h-7 rounded border border-bmx-cyan/40 bg-bmx-cyan/10 flex items-center justify-center shrink-0 mt-0.5">
              <Bot className="w-3.5 h-3.5 text-bmx-cyan animate-pulse" />
            </div>
            <div className="max-w-2xl">
              <div className="bmx-panel rounded-lg border border-bmx-border p-4">
                <pre className="text-white font-mono text-sm leading-relaxed whitespace-pre-wrap break-words">
                  {streamingText}
                  {!streamingText && (
                    <span className="text-bmx-cyan/60 animate-pulse">Thinking...</span>
                  )}
                  <span className="cursor-blink text-bmx-cyan">▌</span>
                </pre>
              </div>
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="px-6 py-4 border-t border-bmx-border shrink-0">
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
              placeholder="Ask GLASSWING about your attack surface..."
              disabled={streaming}
              className="w-full bg-bmx-black border border-bmx-border rounded-lg px-4 py-3 pr-12 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan transition-colors placeholder:text-bmx-muted/40 disabled:opacity-50"
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-bmx-muted/40" />
            </div>
          </div>
          <button
            onClick={() => sendMessage()}
            disabled={streaming || !input.trim()}
            className="bg-bmx-cyan text-bmx-black p-3 rounded-lg hover:bg-bmx-cyan/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        <p className="text-bmx-muted/40 text-xs font-mono mt-2 text-center">
          GLASSWING has context of all your workspace data • Enter to send
        </p>
      </div>
    </div>
  );
}
