"use client";
import { useEffect, useState } from "react";
import { useAuthStore } from "@/store/auth";
import { useAppStore } from "@/store/app";
import { apiKeyApi, workspaceApi } from "@/lib/api";
import { Key, Settings, Plus, Trash2, Copy, Check, Building2 } from "lucide-react";

interface APIKey { id: string; name: string; prefix: string; created_at: string; scopes: string[]; }

export default function SettingsPage() {
  const { user } = useAuthStore();
  const { workspaces, fetchWorkspaces, activeWorkspace, setActiveWorkspace } = useAppStore();
  const [apiKeys, setApiKeys] = useState<APIKey[]>([]);
  const [newKeyName, setNewKeyName] = useState("");
  const [newWsName, setNewWsName] = useState("");
  const [newWsDesc, setNewWsDesc] = useState("");
  const [createdKey, setCreatedKey] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [tab, setTab] = useState<"workspaces" | "apikeys" | "account">("workspaces");

  useEffect(() => {
    fetchWorkspaces();
    apiKeyApi.list().then((r) => setApiKeys(r.data)).catch(() => {});
  }, []);

  const createKey = async () => {
    if (!newKeyName.trim()) return;
    const res = await apiKeyApi.create({ name: newKeyName });
    setCreatedKey(res.data.key);
    setApiKeys((prev) => [...prev, res.data]);
    setNewKeyName("");
  };

  const revokeKey = async (id: string) => {
    await apiKeyApi.revoke(id);
    setApiKeys((prev) => prev.filter((k) => k.id !== id));
  };

  const createWorkspace = async () => {
    if (!newWsName.trim()) return;
    await workspaceApi.create({ name: newWsName, description: newWsDesc });
    await fetchWorkspaces();
    setNewWsName(""); setNewWsDesc("");
  };

  const copyKey = () => {
    if (createdKey) navigator.clipboard.writeText(createdKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-6 space-y-4">
      <div>
        <h1 className="text-white font-mono text-xl font-bold">SETTINGS</h1>
        <p className="text-bmx-muted text-sm font-mono mt-0.5">Configure workspaces, API keys, and account</p>
      </div>

      <div className="flex gap-4 border-b border-bmx-border">
        {(["workspaces", "apikeys", "account"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`pb-3 text-xs font-mono tracking-wider transition-colors ${
              tab === t ? "text-bmx-cyan border-b-2 border-bmx-cyan" : "text-bmx-muted hover:text-white"
            }`}
          >
            {t.toUpperCase()}
          </button>
        ))}
      </div>

      {/* Workspaces */}
      {tab === "workspaces" && (
        <div className="space-y-4">
          <div className="bmx-panel rounded-lg border border-bmx-border p-4">
            <div className="flex items-center gap-2 mb-4">
              <Plus className="w-4 h-4 text-bmx-cyan" />
              <span className="text-white font-mono text-xs tracking-wider">NEW WORKSPACE</span>
            </div>
            <div className="flex gap-3">
              <input
                value={newWsName}
                onChange={(e) => setNewWsName(e.target.value)}
                placeholder="Workspace name"
                className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan"
              />
              <input
                value={newWsDesc}
                onChange={(e) => setNewWsDesc(e.target.value)}
                placeholder="Description (optional)"
                className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan"
              />
              <button
                onClick={createWorkspace}
                className="bg-bmx-cyan text-bmx-black font-mono font-bold text-sm px-4 py-2 rounded hover:bg-bmx-cyan/90 transition-colors"
              >
                CREATE
              </button>
            </div>
          </div>

          <div className="bmx-panel rounded-lg border border-bmx-border divide-y divide-bmx-border">
            {workspaces.map((ws) => (
              <div key={ws.id} className={`flex items-center gap-4 p-4 ${
                activeWorkspace?.id === ws.id ? "bg-bmx-cyan/5" : ""
              }`}>
                <Building2 className={`w-4 h-4 ${activeWorkspace?.id === ws.id ? "text-bmx-cyan" : "text-bmx-muted"}`} />
                <div className="flex-1">
                  <p className="text-white font-mono text-sm">{ws.name}</p>
                  <p className="text-bmx-muted text-xs font-mono mt-0.5">{ws.description || "No description"}</p>
                </div>
                <button
                  onClick={() => setActiveWorkspace(ws)}
                  className={`text-xs font-mono border px-3 py-1.5 rounded transition-colors ${
                    activeWorkspace?.id === ws.id
                      ? "border-bmx-cyan text-bmx-cyan bg-bmx-cyan/10"
                      : "border-bmx-border text-bmx-muted hover:border-bmx-cyan hover:text-white"
                  }`}
                >
                  {activeWorkspace?.id === ws.id ? "ACTIVE" : "SELECT"}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* API Keys */}
      {tab === "apikeys" && (
        <div className="space-y-4">
          {createdKey && (
            <div className="bg-bmx-green/10 border border-bmx-green/30 rounded-lg p-4">
              <p className="text-bmx-green font-mono text-xs mb-2">API KEY CREATED — Copy it now, it won&apos;t be shown again:</p>
              <div className="flex items-center gap-3">
                <code className="flex-1 text-white font-mono text-xs bg-bmx-black px-3 py-2 rounded border border-bmx-border break-all">
                  {createdKey}
                </code>
                <button onClick={copyKey} className="flex items-center gap-1.5 text-bmx-green text-xs font-mono border border-bmx-green/30 px-3 py-2 rounded hover:bg-bmx-green/10 transition-colors">
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? "COPIED" : "COPY"}
                </button>
              </div>
            </div>
          )}

          <div className="bmx-panel rounded-lg border border-bmx-border p-4">
            <div className="flex items-center gap-2 mb-4">
              <Key className="w-4 h-4 text-bmx-cyan" />
              <span className="text-white font-mono text-xs tracking-wider">CREATE API KEY</span>
            </div>
            <div className="flex gap-3">
              <input
                value={newKeyName}
                onChange={(e) => setNewKeyName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && createKey()}
                placeholder="Key name (e.g. CI/CD Pipeline)"
                className="flex-1 bg-bmx-black border border-bmx-border rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-bmx-cyan"
              />
              <button onClick={createKey} className="bg-bmx-cyan text-bmx-black font-mono font-bold text-sm px-4 py-2 rounded hover:bg-bmx-cyan/90 transition-colors">
                CREATE
              </button>
            </div>
          </div>

          <div className="bmx-panel rounded-lg border border-bmx-border divide-y divide-bmx-border">
            {apiKeys.map((k) => (
              <div key={k.id} className="flex items-center gap-4 p-4">
                <Key className="w-4 h-4 text-bmx-muted shrink-0" />
                <div className="flex-1">
                  <p className="text-white font-mono text-sm">{k.name}</p>
                  <p className="text-bmx-muted text-xs font-mono mt-0.5">
                    {k.prefix}••• • Created {new Date(k.created_at).toLocaleDateString()}
                  </p>
                </div>
                <button
                  onClick={() => revokeKey(k.id)}
                  className="flex items-center gap-1.5 text-bmx-red text-xs font-mono border border-bmx-red/30 px-3 py-1.5 rounded hover:bg-bmx-red/10 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" /> REVOKE
                </button>
              </div>
            ))}
            {apiKeys.length === 0 && (
              <div className="px-4 py-8 text-center text-bmx-muted font-mono text-sm">
                No API keys yet.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Account */}
      {tab === "account" && (
        <div className="bmx-panel rounded-lg border border-bmx-border p-6 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg border border-bmx-cyan/30 bg-bmx-cyan/10 flex items-center justify-center text-bmx-cyan font-mono font-bold text-lg">
              {user?.full_name?.[0]?.toUpperCase() || "?"}
            </div>
            <div>
              <p className="text-white font-mono font-bold">{user?.full_name}</p>
              <p className="text-bmx-muted text-xs font-mono">{user?.email}</p>
            </div>
          </div>
          <div className="pt-4 border-t border-bmx-border">
            <p className="text-bmx-muted text-xs font-mono">
              ROLE: <span className="text-bmx-cyan">{user?.role?.toUpperCase()}</span>
            </p>
            <p className="text-bmx-muted text-xs font-mono mt-1">
              ID: <span className="text-white">{user?.id}</span>
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
