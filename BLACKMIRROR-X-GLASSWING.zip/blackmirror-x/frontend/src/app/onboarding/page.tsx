"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Shield, CheckCircle, Circle, AlertCircle, Key, Globe, ArrowRight, Wrench, Play } from "lucide-react";

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

interface SetupStatus {
  setup_complete: boolean;
  steps: {
    database: boolean;
    workspace_created: boolean;
    api_key_configured: boolean;
    tools_available: boolean;
    testlab_available: boolean;
  };
  available_tools: string[];
  tool_count: number;
  workspace_count: number;
}

const TOOLS_INFO = [
  { name: "subfinder", desc: "Subdomain enumeration", install: "go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest" },
  { name: "httpx",     desc: "HTTP probing",          install: "go install github.com/projectdiscovery/httpx/cmd/httpx@latest" },
  { name: "nuclei",    desc: "Vulnerability scanning", install: "go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest" },
  { name: "katana",    desc: "Web crawling",           install: "go install github.com/projectdiscovery/katana/cmd/katana@latest" },
  { name: "amass",     desc: "OSINT enumeration",      install: "go install github.com/owasp-amass/amass/v4/...@master" },
];

const WORKFLOW_PRESETS = [
  { id: "recon",    name: "Recon Only",           icon: "🔍", desc: "Subdomain enum, HTTP probe, tech detection. Passive — no active testing.", risk: "passive" },
  { id: "js",       name: "JS Analysis",           icon: "🔮", desc: "Extract secrets, endpoints, and DOM XSS sinks from JS bundles.", risk: "passive" },
  { id: "api",      name: "API Audit",             icon: "🔗", desc: "IDOR detection, role diff, GraphQL analysis, OpenAPI review.", risk: "low" },
  { id: "full",     name: "Full Safe Scan",        icon: "🛡️", desc: "All modules, passive + low-risk active. No destructive tests.", risk: "medium" },
  { id: "bounty",   name: "Bug Bounty Builder",    icon: "💰", desc: "Optimize for HackerOne submissions with court validation.", risk: "medium" },
  { id: "chain",    name: "Chain Investigation",   icon: "⛓️", desc: "Focus on chaining existing findings into exploit paths.", risk: "passive" },
  { id: "replay",   name: "Evidence Replay",       icon: "▶️",  desc: "Replay and diff previous requests. Perfect for bug validation.", risk: "passive" },
];

const STEPS = [
  { id: "welcome",    title: "Welcome",          icon: Shield },
  { id: "tools",      title: "Tool Detection",   icon: Wrench },
  { id: "apikey",     title: "API Key",          icon: Key },
  { id: "scope",      title: "Scope & Safety",   icon: Globe },
  { id: "testlab",    title: "Test Drive",       icon: Play },
  { id: "complete",   title: "Ready!",           icon: CheckCircle },
];

export default function OnboardingPage() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [status, setStatus] = useState<SetupStatus | null>(null);
  const [apiKey, setApiKey] = useState("");
  const [scopeDomain, setScopeDomain] = useState("localhost");
  const [legalChecked, setLegalChecked] = useState(false);
  const [testlabRunning, setTestlabRunning] = useState(false);
  const [testlabStarting, setTestlabStarting] = useState(false);
  const [selectedWorkflow, setSelectedWorkflow] = useState("recon");

  const getToken = () => localStorage.getItem("bmx_access_token") || "";

  useEffect(() => {
    async function fetchStatus() {
      try {
        const r = await fetch(`${API}/api/v1/demo/setup-status`, {
          headers: { Authorization: `Bearer ${getToken()}` },
        });
        if (r.ok) setStatus(await r.json());
      } catch {/* */}
    }
    fetchStatus();
  }, []);

  async function startTestlab() {
    setTestlabStarting(true);
    try {
      // Check if it's already alive
      const r = await fetch(`${API}/api/v1/demo/status`, {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      const d = await r.json();
      setTestlabRunning(d.testlab_running);
    } catch {/* */} finally {
      setTestlabStarting(false);
    }
  }

  function finish() {
    localStorage.setItem("bmx_onboarding_complete", "true");
    router.push("/dashboard");
  }

  const currentStep = STEPS[step];

  return (
    <div className="min-h-screen bg-bmx-black flex items-center justify-center p-6">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <Shield className="w-8 h-8 text-bmx-cyan" />
          <div>
            <h1 className="text-2xl font-bold text-white font-mono tracking-wider">BLACKMIRROR-X</h1>
            <p className="text-xs text-bmx-muted font-mono">GLASSWING · AVROS Setup Wizard</p>
          </div>
        </div>

        {/* Progress */}
        <div className="flex items-center gap-2 mb-8">
          {STEPS.map((s, i) => (
            <div key={s.id} className="flex items-center gap-2">
              <button
                onClick={() => i < step && setStep(i)}
                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-mono border transition-all ${
                  i < step ? "bg-bmx-green/20 border-bmx-green text-bmx-green cursor-pointer hover:bg-bmx-green/30"
                  : i === step ? "bg-bmx-cyan/20 border-bmx-cyan text-bmx-cyan"
                  : "bg-transparent border-bmx-border text-bmx-muted cursor-not-allowed"
                }`}
              >
                {i < step ? <CheckCircle className="w-3.5 h-3.5" /> : i + 1}
              </button>
              {i < STEPS.length - 1 && (
                <div className={`h-px w-8 ${i < step ? "bg-bmx-green/40" : "bg-bmx-border"}`} />
              )}
            </div>
          ))}
          <span className="ml-2 text-xs text-bmx-muted font-mono">{currentStep.title}</span>
        </div>

        {/* Step content */}
        <div className="bg-bmx-dark border border-bmx-border rounded-xl p-8 space-y-6">

          {/* STEP 0: Welcome */}
          {step === 0 && (
            <div className="space-y-5">
              <div className="flex items-center gap-3">
                <Shield className="w-6 h-6 text-bmx-cyan" />
                <h2 className="text-xl font-bold text-white font-mono">Welcome to BLACKMIRROR-X</h2>
              </div>
              <p className="text-bmx-muted text-sm leading-relaxed">
                BLACKMIRROR-X GLASSWING is an Autonomous Vulnerability Research Operating System (AVROS).
                It combines AI-powered intelligence, attack chain reasoning, and evidence validation
                in one platform — designed for professional bug bounty hunters and AppSec teams.
              </p>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { icon: "🔍", title: "Passive Recon", desc: "Subdomain, HTTP, JS discovery" },
                  { icon: "🧠", title: "AI Intelligence", desc: "Hypothesis, payloads, court" },
                  { icon: "⛓️", title: "Attack Chains", desc: "Dynamic chain reasoning" },
                  { icon: "🛡️", title: "Safe by Default", desc: "Scope + approval + rate limits" },
                ].map((f) => (
                  <div key={f.title} className="bg-bmx-black rounded-lg p-3 border border-bmx-border">
                    <div className="text-xl mb-1">{f.icon}</div>
                    <div className="text-sm font-mono text-white">{f.title}</div>
                    <div className="text-xs text-bmx-muted mt-0.5">{f.desc}</div>
                  </div>
                ))}
              </div>
              {status && (
                <div className={`rounded-lg p-3 border text-sm ${
                  status.setup_complete ? "border-bmx-green/30 bg-bmx-green/5 text-bmx-green"
                  : "border-bmx-cyan/30 bg-bmx-cyan/5 text-bmx-cyan"
                }`}>
                  {status.setup_complete
                    ? `✓ System ready — ${status.workspace_count} workspace(s) found`
                    : "→ Let's set things up. This takes about 2 minutes."}
                </div>
              )}
            </div>
          )}

          {/* STEP 1: Tool Detection */}
          {step === 1 && (
            <div className="space-y-5">
              <div className="flex items-center gap-3">
                <Wrench className="w-6 h-6 text-bmx-orange" />
                <h2 className="text-xl font-bold text-white font-mono">External Tool Detection</h2>
              </div>
              <p className="text-xs text-bmx-muted">
                BLACKMIRROR-X works without external tools — but installing them unlocks
                faster subdomain enumeration, port scanning, and nuclei templates.
              </p>
              <div className="space-y-2">
                {TOOLS_INFO.map((tool) => {
                  const available = status?.available_tools.includes(tool.name) || false;
                  return (
                    <div key={tool.name} className={`rounded-lg border p-3 flex items-center gap-3 ${
                      available ? "border-bmx-green/30 bg-bmx-green/5" : "border-bmx-border"
                    }`}>
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                        available ? "text-bmx-green" : "text-bmx-muted"
                      }`}>
                        {available ? <CheckCircle className="w-4 h-4" /> : <Circle className="w-4 h-4" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-mono text-white">{tool.name}</span>
                          <span className="text-xs text-bmx-muted">{tool.desc}</span>
                          {available && <span className="text-xs text-bmx-green">✓ found</span>}
                        </div>
                        {!available && (
                          <div className="text-xs text-bmx-muted font-mono mt-0.5 truncate">{tool.install}</div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
              <p className="text-xs text-bmx-green">
                ✓ Passive-only mode works fully without any external tools.
                Install later with: <span className="font-mono">bash scripts/setup.sh</span>
              </p>
            </div>
          )}

          {/* STEP 2: API Key */}
          {step === 2 && (
            <div className="space-y-5">
              <div className="flex items-center gap-3">
                <Key className="w-6 h-6 text-bmx-yellow" />
                <h2 className="text-xl font-bold text-white font-mono">Anthropic API Key</h2>
              </div>
              <p className="text-xs text-bmx-muted leading-relaxed">
                An Anthropic API key unlocks AI-powered narratives, hypothesis generation,
                and court adjudication with Claude. Without it, all intelligence features use
                heuristic fallbacks — they still work, just without AI reasoning.
              </p>
              <div className="space-y-2">
                <label className="text-xs text-bmx-muted">API Key (optional)</label>
                <input
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="sk-ant-api03-..."
                  className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-bmx-yellow outline-none"
                />
                <p className="text-xs text-bmx-muted">
                  Get one at{" "}
                  <a href="https://console.anthropic.com" target="_blank" rel="noreferrer"
                    className="text-bmx-cyan underline">console.anthropic.com</a>
                  . Set in .env as <span className="font-mono">ANTHROPIC_API_KEY</span>.
                </p>
              </div>
              {status?.steps.api_key_configured ? (
                <div className="text-bmx-green text-sm flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" /> API key already configured in .env
                </div>
              ) : (
                <div className="text-bmx-yellow text-sm flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" /> No API key set — heuristic fallbacks active
                </div>
              )}
            </div>
          )}

          {/* STEP 3: Scope & Safety */}
          {step === 3 && (
            <div className="space-y-5">
              <div className="flex items-center gap-3">
                <Globe className="w-6 h-6 text-bmx-green" />
                <h2 className="text-xl font-bold text-white font-mono">Scope & Safety Configuration</h2>
              </div>

              <div className="bg-bmx-red/5 border border-bmx-red/20 rounded-lg p-4 space-y-2">
                <div className="text-sm font-mono text-bmx-red font-bold">⚠ Legal Authorization Required</div>
                <p className="text-xs text-bmx-muted leading-relaxed">
                  Only test systems you own or have explicit written permission to test.
                  Unauthorized security testing is illegal in most jurisdictions.
                  BLACKMIRROR-X is for authorized security research only.
                </p>
                <label className="flex items-start gap-2 cursor-pointer mt-2">
                  <input
                    type="checkbox"
                    checked={legalChecked}
                    onChange={(e) => setLegalChecked(e.target.checked)}
                    className="mt-0.5 accent-bmx-green"
                  />
                  <span className="text-xs text-white">
                    I confirm I have authorization to test the systems I will scan with BLACKMIRROR-X.
                    I understand unauthorized testing is illegal and my sole responsibility.
                  </span>
                </label>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs text-bmx-muted block mb-1">Demo Scope (for testlab)</label>
                  <input
                    value={scopeDomain}
                    onChange={(e) => setScopeDomain(e.target.value)}
                    className="w-full bg-bmx-black border border-bmx-border rounded px-3 py-2 text-sm text-white font-mono focus:border-bmx-green outline-none"
                    placeholder="localhost, 127.0.0.1"
                  />
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  {[
                    { label: "Rate Limit", val: "5 req/s (demo)", color: "text-bmx-green" },
                    { label: "Risk Tier", val: "passive/low only", color: "text-bmx-cyan" },
                    { label: "Approval", val: "critical = manual", color: "text-bmx-yellow" },
                  ].map((s) => (
                    <div key={s.label} className="bg-bmx-black rounded p-2 border border-bmx-border">
                      <div className="text-bmx-muted">{s.label}</div>
                      <div className={`font-mono font-bold mt-0.5 ${s.color}`}>{s.val}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: Test Drive */}
          {step === 4 && (
            <div className="space-y-5">
              <div className="flex items-center gap-3">
                <Play className="w-6 h-6 text-bmx-cyan" />
                <h2 className="text-xl font-bold text-white font-mono">Test Drive — Local Testlab</h2>
              </div>
              <p className="text-xs text-bmx-muted">
                The local testlab is a Flask app with intentional vulnerabilities —
                safe to scan, no real data. Use it to verify your setup works.
              </p>

              <div className={`rounded-lg border p-4 ${
                testlabRunning ? "border-bmx-green/30 bg-bmx-green/5" : "border-bmx-border"
              }`}>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-mono text-white">Local Vulnerable API</div>
                    <div className="text-xs text-bmx-muted">http://127.0.0.1:9001 · 8 intentional vulns</div>
                  </div>
                  {testlabRunning
                    ? <span className="text-xs text-bmx-green">● running</span>
                    : <button
                        onClick={startTestlab}
                        disabled={testlabStarting}
                        className="text-xs px-3 py-1.5 bg-bmx-cyan/10 text-bmx-cyan border border-bmx-cyan/30 rounded hover:bg-bmx-cyan/20 font-mono disabled:opacity-40"
                      >
                        {testlabStarting ? "Checking..." : "Check Status"}
                      </button>
                  }
                </div>
              </div>

              <div>
                <div className="text-xs text-bmx-muted mb-2">Select your first workflow:</div>
                <div className="grid grid-cols-1 gap-2 max-h-60 overflow-y-auto">
                  {WORKFLOW_PRESETS.map((wf) => (
                    <button
                      key={wf.id}
                      onClick={() => setSelectedWorkflow(wf.id)}
                      className={`text-left rounded-lg border p-3 transition-all ${
                        selectedWorkflow === wf.id
                          ? "border-bmx-cyan bg-bmx-cyan/10"
                          : "border-bmx-border hover:border-bmx-border/80 hover:bg-white/5"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-base">{wf.icon}</span>
                        <span className="text-sm font-mono text-white">{wf.name}</span>
                        <span className={`ml-auto text-xs font-mono ${
                          wf.risk === "passive" ? "text-bmx-green" :
                          wf.risk === "low" ? "text-bmx-cyan" :
                          "text-bmx-yellow"
                        }`}>{wf.risk}</span>
                      </div>
                      <div className="text-xs text-bmx-muted mt-0.5 ml-7">{wf.desc}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 5: Complete */}
          {step === 5 && (
            <div className="space-y-5 text-center">
              <div className="flex justify-center">
                <div className="w-16 h-16 rounded-full bg-bmx-green/10 border border-bmx-green/30 flex items-center justify-center">
                  <CheckCircle className="w-8 h-8 text-bmx-green" />
                </div>
              </div>
              <div>
                <h2 className="text-xl font-bold text-white font-mono">You&apos;re Ready</h2>
                <p className="text-bmx-muted text-sm mt-1">BLACKMIRROR-X is configured and demo data is loaded.</p>
              </div>
              <div className="text-left space-y-2">
                {[
                  "Dashboard — overview of scans, vulns, and subdomains",
                  "Recon — subdomain + URL discovery",
                  "AVROS Orchestrator — autonomous agent scanning",
                  "AI Copilot — ask questions about your findings",
                  "Chains — view attack chain analysis",
                  "demo_run.sh — 10-minute CLI demo",
                ].map((item) => (
                  <div key={item} className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-3.5 h-3.5 text-bmx-green flex-shrink-0" />
                    <span className="text-bmx-muted">{item}</span>
                  </div>
                ))}
              </div>
              <div className="bg-bmx-black rounded-lg p-3 border border-bmx-border text-xs font-mono text-left">
                <div className="text-bmx-muted">Login credentials:</div>
                <div className="text-bmx-cyan mt-1">admin@blackmirror.io</div>
                <div className="text-bmx-cyan">BlackMirrorX2025!</div>
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between pt-2 border-t border-bmx-border">
            <button
              onClick={() => setStep(Math.max(0, step - 1))}
              disabled={step === 0}
              className="text-sm text-bmx-muted hover:text-white disabled:opacity-30 disabled:cursor-not-allowed"
            >
              ← Back
            </button>
            <div className="text-xs text-bmx-muted">{step + 1} / {STEPS.length}</div>
            {step < STEPS.length - 1 ? (
              <button
                onClick={() => setStep(step + 1)}
                disabled={step === 3 && !legalChecked}
                className="flex items-center gap-1.5 px-4 py-2 text-sm font-mono bg-bmx-cyan/10 text-bmx-cyan border border-bmx-cyan/30 rounded hover:bg-bmx-cyan/20 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                {step === 3 && !legalChecked ? "Accept to continue" : "Continue"}
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                onClick={finish}
                className="flex items-center gap-1.5 px-5 py-2 text-sm font-mono bg-bmx-green/10 text-bmx-green border border-bmx-green/30 rounded hover:bg-bmx-green/20 transition-colors"
              >
                Open Dashboard <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Skip link */}
        <div className="text-center mt-4">
          <button onClick={() => router.push("/dashboard")}
            className="text-xs text-bmx-muted hover:text-white underline">
            Skip setup — go to dashboard
          </button>
        </div>
      </div>
    </div>
  );
}
