"use client";
import { useEffect, useState } from "react";
import { useAppStore } from "@/store/app";
import {
  Database, Lock, Search, Copy, Download,
  CheckCircle, AlertTriangle, Eye, Code, ExternalLink
} from "lucide-react";

interface EvidenceItem {
  id: string;
  vuln_id: string;
  title: string;
  severity: string;
  vuln_type: string;
  url: string;
  method: string;
  payload: string;
  request_raw: string;
  response_raw: string;
  evidence_score: number;
  has_screenshot: boolean;
  created_at: string;
}

const SEV_BADGE: Record<string, string> = {
  critical: "bg-red-500/10 text-red-400 border-red-500/30",
  high: "bg-orange-500/10 text-orange-400 border-orange-500/30",
  medium: "bg-yellow-500/10 text-yellow-400 border-yellow-500/30",
  low: "bg-blue-500/10 text-blue-400 border-blue-500/30",
  info: "bg-gray-500/10 text-gray-400 border-gray-500/30",
};

function EvidenceScore({ score }: { score: number }) {
  const color = score >= 0.8 ? "text-bmx-green" : score >= 0.5 ? "text-bmx-yellow" : "text-bmx-red";
  return (
    <div className="flex items-center gap-1.5">
      <div className="w-12 h-1 bg-bmx-border rounded-full overflow-hidden">
        <div className="h-full bg-current rounded-full" style={{ width: `${score * 100}%` }} />
      </div>
      <span className={`text-xs font-mono ${color}`}>{Math.round(score * 100)}%</span>
    </div>
  );
}

export default function EvidenceVaultPage() {
  const { vulns, fetchVulns, activeWorkspace } = useAppStore();
  const [search, setSearch] = useState("");
  const [selectedSeverity, setSelectedSeverity] = useState("all");
  const [selectedItem, setSelectedItem] = useState<EvidenceItem | null>(null);
  const [activeView, setActiveView] = useState<"request" | "response" | "payload">("payload");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (activeWorkspace) fetchVulns({ workspace_id: activeWorkspace.id });
  }, [activeWorkspace]);

  // Transform vulns into evidence items
  const evidenceItems: EvidenceItem[] = vulns.map((v) => ({
    id: v.id,
    vuln_id: v.id,
    title: v.title,
    severity: v.severity,
    vuln_type: v.vuln_type,
    url: v.url || "",
    method: "GET",
    payload: v.payload || "",
    request_raw: `GET ${v.url || "/"} HTTP/1.1\nHost: target.com\nAuthorization: Bearer [token]\n\n${v.payload || ""}`,
    response_raw: `HTTP/1.1 200 OK\nContent-Type: application/json\n\n${v.evidence || "{}"}`,
    evidence_score: v.evidence_score || 0.6,
    has_screenshot: false,
    created_at: v.created_at || new Date().toISOString(),
  }));

  const filtered = evidenceItems.filter((e) => {
    const matchSearch = !search || e.title.toLowerCase().includes(search.toLowerCase()) || e.url.toLowerCase().includes(search.toLowerCase());
    const matchSev = selectedSeverity === "all" || e.severity === selectedSeverity;
    return matchSearch && matchSev;
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="p-6 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white font-mono text-xl font-bold flex items-center gap-2">
            <Database className="w-5 h-5 text-bmx-cyan" />
            EVIDENCE VAULT
          </h1>
          <p className="text-bmx-muted text-sm font-mono mt-0.5">
            Request/response proof · Payload archive · Evidence quality scoring
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Lock className="w-3.5 h-3.5 text-bmx-green" />
          <span className="text-bmx-green text-xs font-mono">ENCRYPTED</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* List */}
        <div className="bmx-panel rounded-lg border border-bmx-border">
          {/* Filters */}
          <div className="p-3 border-b border-bmx-border space-y-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-bmx-muted" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search evidence..."
                className="w-full bg-bmx-black border border-bmx-border rounded pl-8 pr-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-bmx-cyan"
              />
            </div>
            <select
              value={selectedSeverity}
              onChange={(e) => setSelectedSeverity(e.target.value)}
              className="w-full bg-bmx-black border border-bmx-border rounded px-2 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-bmx-cyan"
            >
              <option value="all">All Severities</option>
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>

          {/* Items */}
          <div className="overflow-y-auto max-h-[520px] divide-y divide-bmx-border">
            {filtered.length === 0 && (
              <div className="px-4 py-8 text-center text-bmx-muted font-mono text-xs">No evidence</div>
            )}
            {filtered.map((item) => (
              <div
                key={item.id}
                onClick={() => setSelectedItem(item)}
                className={`px-3 py-3 cursor-pointer transition-colors ${
                  selectedItem?.id === item.id ? "bg-bmx-cyan/5 border-l-2 border-bmx-cyan" : "hover:bg-bmx-panel/50"
                }`}
              >
                <div className="flex items-start gap-2 mb-1.5">
                  <span className={`text-xs font-mono border px-1.5 py-0.5 rounded shrink-0 ${SEV_BADGE[item.severity] || SEV_BADGE.info}`}>
                    {item.severity}
                  </span>
                  <p className="text-white font-mono text-xs leading-tight truncate">{item.title}</p>
                </div>
                <p className="text-bmx-muted font-mono text-xs truncate mb-1">{item.url}</p>
                <EvidenceScore score={item.evidence_score} />
              </div>
            ))}
          </div>

          <div className="p-3 border-t border-bmx-border text-center">
            <p className="text-bmx-muted font-mono text-xs">{filtered.length} items</p>
          </div>
        </div>

        {/* Detail panel */}
        <div className="lg:col-span-2">
          {selectedItem ? (
            <div className="bmx-panel rounded-lg border border-bmx-border h-full flex flex-col">
              {/* Header */}
              <div className="p-4 border-b border-bmx-border flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="text-white font-mono text-sm font-bold">{selectedItem.title}</h3>
                  <p className="text-bmx-muted font-mono text-xs mt-0.5 truncate">{selectedItem.url}</p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <EvidenceScore score={selectedItem.evidence_score} />
                  {selectedItem.evidence_score >= 0.8
                    ? <CheckCircle className="w-4 h-4 text-bmx-green" />
                    : <AlertTriangle className="w-4 h-4 text-bmx-yellow" />
                  }
                </div>
              </div>

              {/* Tab selector */}
              <div className="flex border-b border-bmx-border px-4">
                {[
                  { id: "payload", label: "PAYLOAD", icon: Code },
                  { id: "request", label: "REQUEST", icon: ExternalLink },
                  { id: "response", label: "RESPONSE", icon: Eye },
                ].map(({ id, label, icon: Icon }) => (
                  <button
                    key={id}
                    onClick={() => setActiveView(id as typeof activeView)}
                    className={`py-2.5 mr-4 flex items-center gap-1.5 text-xs font-mono tracking-wider transition-colors ${
                      activeView === id ? "text-bmx-cyan border-b-2 border-bmx-cyan" : "text-bmx-muted hover:text-white"
                    }`}
                  >
                    <Icon className="w-3 h-3" />
                    {label}
                  </button>
                ))}
                <button
                  onClick={() => copyToClipboard(
                    activeView === "payload" ? selectedItem.payload :
                    activeView === "request" ? selectedItem.request_raw :
                    selectedItem.response_raw
                  )}
                  className="ml-auto py-2.5 flex items-center gap-1 text-xs font-mono text-bmx-muted hover:text-white transition-colors"
                >
                  <Copy className="w-3 h-3" />
                  {copied ? "COPIED!" : "COPY"}
                </button>
              </div>

              {/* Content */}
              <div className="flex-1 overflow-hidden">
                <pre className="h-[420px] overflow-auto p-4 text-xs font-mono text-bmx-green terminal leading-relaxed whitespace-pre-wrap">
                  {activeView === "payload" && (
                    selectedItem.payload || "No payload recorded"
                  )}
                  {activeView === "request" && selectedItem.request_raw}
                  {activeView === "response" && selectedItem.response_raw}
                </pre>
              </div>

              {/* Actions */}
              <div className="p-3 border-t border-bmx-border flex gap-2">
                <button className="flex items-center gap-1.5 bg-bmx-border text-white text-xs font-mono px-3 py-1.5 rounded hover:bg-bmx-border/70 transition-colors">
                  <Download className="w-3 h-3" />
                  Export
                </button>
                <button
                  onClick={() => copyToClipboard(
                    `# ${selectedItem.title}\n\nURL: ${selectedItem.url}\nSeverity: ${selectedItem.severity}\n\n## Payload\n\`\`\`\n${selectedItem.payload}\n\`\`\`\n\n## Evidence\n\`\`\`\n${selectedItem.request_raw}\n\`\`\``
                  )}
                  className="flex items-center gap-1.5 bg-bmx-cyan text-bmx-black text-xs font-mono font-bold px-3 py-1.5 rounded hover:bg-bmx-cyan/90 transition-colors"
                >
                  <Code className="w-3 h-3" />
                  Copy as Report
                </button>
              </div>
            </div>
          ) : (
            <div className="bmx-panel rounded-lg border border-bmx-border flex flex-col items-center justify-center py-24">
              <Database className="w-8 h-8 text-bmx-muted/20 mb-3" />
              <p className="text-bmx-muted font-mono text-sm">Select evidence to inspect</p>
              <p className="text-bmx-muted/50 text-xs font-mono mt-1">Request/response proof · Payload details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
