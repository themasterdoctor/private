import { create } from "zustand";
import { workspaceApi, scanApi, vulnApi, reconApi } from "@/lib/api";

export interface Workspace { id: string; name: string; description: string; created_at: string; }
export interface ScanJob {
  id: string; target: string; status: string; scan_type: string;
  created_at: string; completed_at?: string; workspace_id: string;
  subdomain_count: number; url_count: number; vuln_count: number;
}
export interface Vulnerability {
  id: string; title: string; vuln_type: string; severity: string;
  status: string; url: string; parameter?: string; description: string;
  cvss_score?: number; cwe_id?: string; created_at: string; scan_id: string;
  workspace_id?: string;
  payload?: string;
  evidence?: string;
  evidence_score?: number;
  reproduction_steps?: string;
  remediation?: string;
  court_confidence?: number;
  exploitability_score?: number;
  bounty_likelihood?: number;
  reflection_context?: string;
  simulation_narrative?: string;
}
export interface Subdomain {
  id: string; subdomain: string; ip_address?: string; status_code?: number;
  title?: string; technologies?: string[]; ports?: number[]; created_at: string;
}

interface AppState {
  workspaces: Workspace[];
  activeWorkspace: Workspace | null;
  scans: ScanJob[];
  vulns: Vulnerability[];
  subdomains: Subdomain[];
  isLoadingWorkspaces: boolean;
  isLoadingScans: boolean;
  isLoadingVulns: boolean;

  fetchWorkspaces: () => Promise<void>;
  setActiveWorkspace: (ws: Workspace) => void;
  fetchScans: (workspaceId?: string) => Promise<void>;
  createScan: (data: { target: string; workspace_id: string; scan_type?: string }) => Promise<ScanJob>;
  fetchVulns: (params?: { workspace_id?: string; scan_id?: string; severity?: string }) => Promise<void>;
  fetchSubdomains: (params?: { scan_id?: string; workspace_id?: string }) => Promise<void>;
  updateVuln: (id: string, data: { status?: string; notes?: string }) => Promise<void>;
}

export const useAppStore = create<AppState>((set, get) => ({
  workspaces: [],
  activeWorkspace: null,
  scans: [],
  vulns: [],
  subdomains: [],
  isLoadingWorkspaces: false,
  isLoadingScans: false,
  isLoadingVulns: false,

  fetchWorkspaces: async () => {
    set({ isLoadingWorkspaces: true });
    try {
      const res = await workspaceApi.list();
      const workspaces = res.data;
      set({ workspaces, activeWorkspace: workspaces[0] || null });
    } finally {
      set({ isLoadingWorkspaces: false });
    }
  },

  setActiveWorkspace: (ws) => set({ activeWorkspace: ws }),

  fetchScans: async (workspaceId) => {
    set({ isLoadingScans: true });
    try {
      const res = await scanApi.list(workspaceId || get().activeWorkspace?.id);
      set({ scans: res.data });
    } finally {
      set({ isLoadingScans: false });
    }
  },

  createScan: async (data) => {
    const res = await scanApi.create(data);
    const scan = res.data;
    set((s) => ({ scans: [scan, ...s.scans] }));
    return scan;
  },

  fetchVulns: async (params) => {
    set({ isLoadingVulns: true });
    try {
      const res = await vulnApi.list({ workspace_id: get().activeWorkspace?.id, ...params });
      set({ vulns: res.data });
    } finally {
      set({ isLoadingVulns: false });
    }
  },

  fetchSubdomains: async (params) => {
    const res = await reconApi.subdomains({ workspace_id: get().activeWorkspace?.id, ...params });
    set({ subdomains: res.data });
  },

  updateVuln: async (id, data) => {
    await vulnApi.update(id, data);
    set((s) => ({
      vulns: s.vulns.map((v) => (v.id === id ? { ...v, ...data } : v)),
    }));
  },
}));
