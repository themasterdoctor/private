import axios, { AxiosInstance, InternalAxiosRequestConfig } from "axios";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";

let api: AxiosInstance;

function getApi(): AxiosInstance {
  if (!api) {
    api = axios.create({ baseURL: BASE_URL, timeout: 30000 });

    api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
      const token = localStorage.getItem("bmx_access_token");
      if (token) config.headers.Authorization = `Bearer ${token}`;
      return config;
    });

    api.interceptors.response.use(
      (r) => r,
      async (error) => {
        if (error.response?.status === 401) {
          const refresh = localStorage.getItem("bmx_refresh_token");
          if (refresh) {
            try {
              const res = await axios.post(`${BASE_URL}/auth/refresh`, { refresh_token: refresh });
              localStorage.setItem("bmx_access_token", res.data.access_token);
              error.config.headers.Authorization = `Bearer ${res.data.access_token}`;
              return api.request(error.config);
            } catch {
              localStorage.clear();
              window.location.href = "/auth/login";
            }
          }
        }
        return Promise.reject(error);
      }
    );
  }
  return api;
}

// ─── Auth ────────────────────────────────────────────────────────────────────
export const authApi = {
  register: (data: { email: string; password: string; full_name: string }) =>
    getApi().post("/auth/register", data),
  login: (email: string, password: string) => {
    const form = new FormData();
    form.append("username", email);
    form.append("password", password);
    return getApi().post("/auth/token", form);
  },
  me: () => getApi().get("/auth/me"),
};

// ─── Workspaces ───────────────────────────────────────────────────────────────
export const workspaceApi = {
  list: () => getApi().get("/workspaces"),
  create: (data: { name: string; description?: string }) =>
    getApi().post("/workspaces", data),
  get: (id: string) => getApi().get(`/workspaces/${id}`),
};

// ─── Scans ────────────────────────────────────────────────────────────────────
export const scanApi = {
  list: (workspaceId?: string) =>
    getApi().get("/scans", { params: { workspace_id: workspaceId } }),
  create: (data: {
    target: string;
    workspace_id: string;
    scan_type?: string;
    config?: Record<string, unknown>;
  }) => getApi().post("/scans", data),
  get: (id: string) => getApi().get(`/scans/${id}`),
  cancel: (id: string) => getApi().post(`/scans/${id}/cancel`),
  logs: (id: string, limit = 100) =>
    getApi().get(`/scans/${id}/logs`, { params: { limit } }),
};

// ─── Vulnerabilities ──────────────────────────────────────────────────────────
export const vulnApi = {
  list: (params?: {
    workspace_id?: string;
    scan_id?: string;
    severity?: string;
    status?: string;
    type?: string;
    page?: number;
    limit?: number;
  }) => getApi().get("/vulns", { params }),
  get: (id: string) => getApi().get(`/vulns/${id}`),
  update: (id: string, data: { status?: string; notes?: string }) =>
    getApi().patch(`/vulns/${id}`, data),
  hackeroneReport: (id: string) => getApi().get(`/vulns/${id}/hackerone-report`),
};

// ─── Recon ────────────────────────────────────────────────────────────────────
export const reconApi = {
  subdomains: (params?: { scan_id?: string; workspace_id?: string; limit?: number }) =>
    getApi().get("/recon/subdomains", { params }),
  urls: (params?: { scan_id?: string; workspace_id?: string; limit?: number }) =>
    getApi().get("/recon/urls", { params }),
};

// ─── Reports ──────────────────────────────────────────────────────────────────
export const reportApi = {
  list: (workspaceId?: string) =>
    getApi().get("/reports", { params: { workspace_id: workspaceId } }),
  get: (id: string) => getApi().get(`/reports/${id}`),
  generate: (scanId: string, format?: string) =>
    getApi().post(`/reports/generate/${scanId}`, { format }),
};

// ─── Copilot ──────────────────────────────────────────────────────────────────
export const copilotApi = {
  sessions: (workspaceId?: string) =>
    getApi().get("/chat/sessions", { params: { workspace_id: workspaceId } }),
  messages: (sessionId: string) =>
    getApi().get(`/chat/sessions/${sessionId}/messages`),
};

// ─── API Keys ─────────────────────────────────────────────────────────────────
export const apiKeyApi = {
  list: () => getApi().get("/apikeys"),
  create: (data: { name: string; scopes?: string[] }) =>
    getApi().post("/apikeys", data),
  revoke: (id: string) => getApi().delete(`/apikeys/${id}`),
};

// ─── Agents ───────────────────────────────────────────────────────────────────
export const agentApi = {
  runs: (scanId?: string) =>
    getApi().get("/agents/runs", { params: { scan_id: scanId } }),
};

// SSE stream helper
export function createScanStream(scanId: string, onMessage: (data: unknown) => void) {
  const token = localStorage.getItem("bmx_access_token");
  const url = `${BASE_URL}/scans/${scanId}/stream?token=${token}`;
  const es = new EventSource(url);
  es.onmessage = (e) => {
    try { onMessage(JSON.parse(e.data)); } catch { /* ignore */ }
  };
  return es;
}

// Copilot SSE stream
export function createCopilotStream(
  message: string,
  workspaceId: string,
  sessionId: string | null,
  onChunk: (text: string) => void,
  onDone: (sessionId: string) => void
) {
  const token = localStorage.getItem("bmx_access_token");
  const body = JSON.stringify({ message, workspace_id: workspaceId, session_id: sessionId });

  const controller = new AbortController();

  fetch(`${BASE_URL}/chat/stream`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body,
    signal: controller.signal,
  }).then(async (res) => {
    const reader = res.body?.getReader();
    if (!reader) return;
    const decoder = new TextDecoder();
    let buffer = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        if (line.startsWith("data: ")) {
          const data = line.slice(6).trim();
          if (data === "[DONE]") {
            onDone(sessionId || "");
          } else {
            try {
              const parsed = JSON.parse(data);
              if (parsed.text) onChunk(parsed.text);
              if (parsed.session_id) onDone(parsed.session_id);
            } catch { /* ignore */ }
          }
        }
      }
    }
  }).catch(() => {/* aborted */});

  return () => controller.abort();
}

export default getApi;

// ─── Intelligence Layer API ────────────────────────────────────────────────────

export const intelligenceAPI = {
  // Hypotheses
  generateHypotheses: (scanId: string) =>
    api.post(`/intel/hypotheses/generate/${scanId}`),
  streamHypotheses: (scanId: string) =>
    `${BASE_URL}/intel/hypotheses/stream/${scanId}`,

  // Validation Court
  adjudicateVuln: (vulnId: string) =>
    api.post(`/intel/court/adjudicate/${vulnId}`),

  // Memory
  getMemory: (workspaceId: string) =>
    api.get(`/intel/memory/${workspaceId}`),
  addFalsePositive: (workspaceId: string, signature: string) =>
    api.post(`/intel/memory/${workspaceId}/false-positive`, { signature }),

  // Simulation
  simulateExploitability: (vulnId: string) =>
    api.post(`/intel/simulate/${vulnId}`),

  // Payloads
  getPayloads: (vulnType: string, context?: string, waf?: string, param?: string) =>
    api.get(`/intel/payloads/${vulnType}`, { params: { context, waf, param } }),

  // Monitoring
  startMonitoring: (target: string, workspaceId: string, intervalHours = 24) =>
    api.post(`/intel/monitor/start`, { target, workspace_id: workspaceId, interval_hours: intervalHours }),
  listMonitors: () =>
    api.get(`/intel/monitor/active`),
  stopMonitoring: (workspaceId: string, target: string) =>
    api.delete(`/intel/monitor/${workspaceId}/${target}`),

  // Metrics
  getMetrics: () =>
    api.get(`/intel/metrics`),
};
