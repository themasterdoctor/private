"use client";
// Minimal theme provider — dark mode always on for BLACKMIRROR-X
interface ThemeProviderProps {
  children: React.ReactNode;
  attribute?: string;
  defaultTheme?: string;
  enableSystem?: boolean;
}
export function ThemeProvider({ children }: ThemeProviderProps) {
  return <>{children}</>;
}
