"use client";
// Minimal toast container — extend with react-hot-toast or similar as needed
export function Toaster() {
  return null;
}
