/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "standalone",
  reactStrictMode: true,
  env: {
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000',
    NEXT_PUBLIC_WS_URL: process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:8000',
  },
  async redirects() {
    return [
      { source: '/vulnerabilities', destination: '/vulns', permanent: true },
      { source: '/vulnerabilities/:path*', destination: '/vulns/:path*', permanent: true },
      { source: '/attack-graph', destination: '/graph', permanent: true },
      { source: '/attack-graph/:path*', destination: '/graph/:path*', permanent: true },
      { source: '/hypothesis', destination: '/mission', permanent: true },
      { source: '/monitoring', destination: '/monitor', permanent: true },
      { source: '/vault', destination: '/evidence', permanent: true },
    ]
  },
}

module.exports = nextConfig
