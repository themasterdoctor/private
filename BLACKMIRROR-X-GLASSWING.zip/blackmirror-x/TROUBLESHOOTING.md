# TROUBLESHOOTING — BLACKMIRROR-X GLASSWING

Common issues and solutions.

## Startup Issues

### Backend fails to start

**Symptom:** `uvicorn app.main:app` exits immediately

**Check:**
```bash
# Test imports
cd backend && python -m compileall app -q

# Check DATABASE_URL is reachable
psql $DATABASE_URL -c "SELECT 1"

# Run migrations
alembic upgrade head
```

**Common causes:**
- DATABASE_URL uses wrong host (use `127.0.0.1`, not `postgres`, for bare metal)
- Redis not running: `redis-server --daemonize yes`
- Missing `.env` file: `cp .env.example .env`

### Frontend shows blank page

**Check:**
```bash
cd frontend && npm run build
# Look for TypeScript errors in output
```

**Common causes:**
- Node version < 18: `node --version`
- Missing `NEXT_PUBLIC_API_URL` in .env pointing to wrong port

### "No workspace found" after login

Run seed script:
```bash
cd backend && python scripts/seed.py
```

---

## Scan Issues

### Scans stuck at 0%

The scan worker (Celery) is not running. Start it:
```bash
cd backend
celery -A app.workers.celery_app worker --loglevel=info
```

Check if Celery is running:
```bash
celery -A app.workers.celery_app inspect active
```

### No subdomains found

External tools not installed. Check tool status:
```bash
curl -s http://localhost:8000/api/v1/tools | python3 -m json.tool
```

Install tools: `bash scripts/setup.sh`

Without tools, recon only discovers subdomains via passive DNS — very limited.

### Playwright features not working

Install Playwright:
```bash
pip install playwright --break-system-packages
playwright install chromium --with-deps
```

Verify:
```bash
python3 -c "from playwright.async_api import async_playwright; print('OK')"
```

### AI features returning heuristic results

Set `ANTHROPIC_API_KEY` in `.env`:
```bash
echo "ANTHROPIC_API_KEY=sk-ant-..." >> .env
```

Heuristic fallbacks are intentional — the platform works without the key.

---

## Database Issues

### Migration fails

```bash
# Check current state
alembic current

# If stuck, stamp head and re-run
alembic stamp head
alembic upgrade head
```

### "Table already exists" error

The migration was partially applied:
```bash
alembic downgrade -1
alembic upgrade head
```

### Out of disk space

The `artifacts` directory grows with scan data:
```bash
du -sh /app/artifacts
# Clean old scans (keeps last 30 days)
find /app/artifacts -mtime +30 -delete
```

---

## Authentication Issues

### JWT token expired

Tokens expire after 60 minutes (configurable via `JWT_ACCESS_TOKEN_EXPIRE_MINUTES`).
Just log in again.

### "Invalid credentials"

Reset password via:
```bash
cd backend && python3 -c "
from app.core.security import hash_password
print(hash_password('NewPassword123!'))
"
# Then update in psql:
# UPDATE users SET hashed_password='...' WHERE email='admin@blackmirror.io';
```

---

## Docker Issues

### Port already in use

```bash
# Kill process using port 8000
lsof -i :8000 | awk 'NR>1{print $2}' | xargs kill -9

# Or change the port in docker-compose.yml
```

### Container won't build

```bash
docker-compose build --no-cache
docker-compose logs backend
```

### Database container unhealthy

```bash
docker-compose down -v  # WARNING: deletes data
docker-compose up -d postgres
sleep 10
docker-compose up -d
```

---

## Testlab Issues

### Testlab not starting

```bash
# Check Python Flask is installed
pip install flask --break-system-packages

# Start manually with logs
cd testlab/vuln-api && python app.py
```

### Testlab returns unexpected results

The testlab is intentionally vulnerable — some "errors" are features (e.g., SQL syntax in 500 response).

---

## Getting Help

1. Check logs: `docker-compose logs -f backend`
2. Run verification: `bash scripts/verify_full_stack.sh`
3. Run tests: `cd backend && pytest tests/`
4. See PHASE10_AVROS_COMPLETION.md for known limitations
