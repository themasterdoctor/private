# TROUBLESHOOTING.md
# BLACKMIRROR-X GLASSWING — Troubleshooting Guide

---

## Backend Won't Start

### "address already in use"
```bash
# Find what's using port 8000
lsof -i :8000
# Kill it
kill -9 <PID>
# Or use a different port
uvicorn app.main:app --port 8001
```

### "cannot connect to PostgreSQL"
```bash
# Check PostgreSQL is running
pg_isready -h 127.0.0.1
# Start it
sudo systemctl start postgresql
# Or in Docker
docker-compose restart postgres
```

### "ModuleNotFoundError"
```bash
cd backend
pip install -r requirements.txt --break-system-packages
```

### "bcrypt error" / password hashing crash
```bash
# bcrypt 5.x is incompatible with passlib
pip install "bcrypt==4.0.1" "passlib[bcrypt]==1.7.4" --break-system-packages
```

### SQLAlchemy "column X does not exist"
The model and database schema are out of sync. Re-run migrations:
```bash
docker-compose exec backend alembic upgrade head
# If that fails (schema changed):
docker-compose down -v  # DESTROYS all data
docker-compose up -d
docker-compose exec backend alembic upgrade head
docker-compose exec backend python scripts/seed.py
```

---

## Database Issues

### Migration fails: "relation already exists"
```bash
# Check current migration state
docker-compose exec backend alembic current
# If stuck, stamp to current head and re-run
docker-compose exec backend alembic stamp head
docker-compose exec backend alembic upgrade head
```

### Migration fails: "extension vector does not exist"
```bash
# Install pgvector
apt-get install postgresql-16-pgvector
# Then in psql:
docker-compose exec postgres psql -U bmx -d blackmirror -c "CREATE EXTENSION vector;"
```

### "uuid_generate_v4() does not exist"
```bash
docker-compose exec postgres psql -U bmx -d blackmirror -c "CREATE EXTENSION \"uuid-ossp\";"
```

### Seed fails: "already seeded"
The seed script is idempotent — it skips if admin@blackmirror.io already exists. This is normal. To reseed fresh:
```bash
docker-compose exec postgres psql -U bmx -d blackmirror -c "TRUNCATE users, workspaces, scan_jobs, vulnerabilities CASCADE;"
docker-compose exec backend python scripts/seed.py
```

---

## Authentication Issues

### Login returns 422
The login form uses `application/x-www-form-urlencoded` with field name `username` (not `email`). The `username` field accepts an email address:
```bash
curl -X POST http://localhost:8000/api/v1/auth/login \
  -d "username=admin@blackmirror.io&password=BlackMirrorX2025!"
```

### JWT expires immediately
Check that `SECRET_KEY` and `JWT_SECRET_KEY` in `.env` are at least 32 characters and are not placeholder values.

### "Not authenticated" on all requests
The JWT token must be sent as `Authorization: Bearer <token>`. Check your API client is setting this header correctly.

---

## Frontend Issues

### `npm install` fails: "@radix-ui/react-badge not found"
This package was removed. If it reappears after a git pull:
```bash
node -e "const p=require('./package.json'); delete p.dependencies['@radix-ui/react-badge']; require('fs').writeFileSync('package.json', JSON.stringify(p,null,2))"
npm install --legacy-peer-deps
```

### Build fails: "Failed to fetch JetBrains Mono from Google Fonts"
This happens in network-restricted environments. The fonts load via CSS in production:
```bash
# Remove the next/font import from src/app/layout.tsx — it's already done in this version
# The app works without it; fonts fall back to system monospace
```

### TypeScript errors on `Vulnerability` type
Check `src/store/app.ts` — the `Vulnerability` interface must include `payload`, `evidence`, `evidence_score` as optional fields. These were added in Phase 6.

### Page shows blank / router error
```bash
# Check the browser console. Usually caused by:
# 1. API URL mismatch - check NEXT_PUBLIC_API_URL in .env
# 2. Token expired - logout and login again
# 3. Workspace not selected - go to /settings and create one
```

---

## Intelligence Features

### Hypothesis generation returns empty list
The hypothesis engine needs URLs and parameters from a completed scan. The demo scan includes subdomains but no crawled URLs. Either:
1. Run a real scan against an authorized target
2. Manually add discovered URLs to the scan in the database

### Court adjudication returns 500
This calls the Anthropic API. Make sure:
```bash
# Check your API key is set
echo $ANTHROPIC_API_KEY | head -c 20
# Expected: sk-ant-...
# If not set, edit .env and restart
```

### Browser Intelligence returns empty
Playwright isn't installed:
```bash
docker-compose exec backend playwright install chromium --with-deps
# Verify
docker-compose exec backend python -c "from playwright.sync_api import sync_playwright; print('playwright ok')"
```

### Continuous monitoring shows no alerts
Monitoring requires at least two snapshots to diff. After starting a monitor:
1. Wait for the configured interval (default: 24h)
2. Or manually trigger a snapshot comparison via the API

---

## Docker Issues

### Container keeps restarting
```bash
docker-compose logs backend --tail=50
# Most common causes:
# 1. DATABASE_URL wrong — PostgreSQL not ready
# 2. SECRET_KEY not set or too short
# 3. Missing ANTHROPIC_API_KEY (won't crash but logs warning)
```

### "no space left on device"
```bash
# Clean Docker cache
docker system prune -f
docker volume prune -f
```

### "permission denied" on scripts
```bash
chmod +x scripts/verify_backend.sh
chmod +x scripts/verify_frontend.sh
chmod +x scripts/verify_full_stack.sh
```

---

## Celery / Scan Jobs

### Scan stays in "queued" forever
The Celery worker isn't running:
```bash
# Check
docker-compose ps worker
# Start
docker-compose up -d worker
# Watch logs
docker-compose logs worker -f
```

### Scan fails with "tool not found"
The external recon tools (subfinder, nuclei, etc.) are not installed in this release. The scan pipeline is implemented but requires these tools to be present:
- `subfinder` — subdomain enumeration
- `httpx` — HTTP probing
- `nuclei` — vulnerability scanning
- `katana` — web crawling
- `naabu` — port scanning

Install them from https://github.com/projectdiscovery or via the ProjectDiscovery installer.

---

## Prometheus / Grafana

### Prometheus "target down"
```bash
# Check backend metrics endpoint
curl http://localhost:8000/api/v1/intel/metrics
# Check Prometheus config
cat infrastructure/prometheus.yml
```

### Grafana shows "No data"
The Prometheus data source may not be configured. In Grafana:
1. Go to Configuration → Data Sources
2. Add Prometheus with URL: `http://prometheus:9090`
3. Save and test

---

## What Requires External Services

| Feature | Requirement | Without It |
|---------|-------------|------------|
| Hypothesis AI ranking | Anthropic API key | Returns heuristic ranking only |
| Court verdicts (narratives) | Anthropic API key | Returns fallback verdict |
| Copilot chat | Anthropic API key | No response |
| Report AI generation | Anthropic API key | Returns template report |
| Simulation narrative | Anthropic API key | Returns matrix-based scores only |
| Browser intelligence | Playwright + Chromium | Returns empty result |
| Subdomain enumeration | subfinder binary | No subdomains found |
| Vulnerability scanning | nuclei binary | No template-based findings |
| URL crawling | katana binary | No URL discovery |
| Port scanning | naabu binary | No port results |

---

## Getting Help

1. Check `docker-compose logs <service>` for error details
2. Run `bash scripts/verify_full_stack.sh` for a diagnostic report
3. Check `/health` endpoint: `curl http://localhost:8000/health`
4. API docs at: http://localhost:8000/api/docs
