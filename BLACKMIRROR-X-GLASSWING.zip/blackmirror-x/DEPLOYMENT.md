# DEPLOYMENT.md
# BLACKMIRROR-X GLASSWING — Deployment Guide

---

## Option A: Docker Compose (Recommended)

### Prerequisites
- Docker 24+ and Docker Compose v2
- 4GB RAM minimum, 8GB recommended
- Ports 3000, 8000, 5432, 6379, 9090, 3001, 5555 free

### Step 1: Configure

```bash
cp .env.example .env
```

Edit `.env` — **required changes** (app won't start without these):

```bash
# Generate secure random values
export SECRET_KEY=$(openssl rand -hex 32)
export JWT_SECRET_KEY=$(openssl rand -hex 32)
export BMX_VAULT_KEY=$(openssl rand -hex 32)
export POSTGRES_PASSWORD=$(openssl rand -hex 16)

# Write them (or edit .env manually)
sed -i "s/SECRET_KEY=.*/SECRET_KEY=$SECRET_KEY/" .env
sed -i "s/JWT_SECRET_KEY=.*/JWT_SECRET_KEY=$JWT_SECRET_KEY/" .env
sed -i "s/BMX_VAULT_KEY=.*/BMX_VAULT_KEY=$BMX_VAULT_KEY/" .env
sed -i "s/POSTGRES_PASSWORD=.*/POSTGRES_PASSWORD=$POSTGRES_PASSWORD/" .env

# Set your Anthropic API key (required for AI features)
# Get one at: https://console.anthropic.com
sed -i "s/ANTHROPIC_API_KEY=.*/ANTHROPIC_API_KEY=sk-ant-YOUR-KEY/" .env
```

### Step 2: Build and Start

```bash
# First run (builds all images)
docker-compose build --no-cache

# Start all services
docker-compose up -d

# Verify all containers are up
docker-compose ps
```

Expected output:
```
NAME                STATUS
blackmirror-backend   Up (healthy)
blackmirror-frontend  Up
blackmirror-postgres  Up (healthy)
blackmirror-redis     Up (healthy)
blackmirror-worker    Up
blackmirror-prometheus Up
blackmirror-grafana   Up
blackmirror-flower    Up
```

### Step 3: Database

```bash
# Run migrations (first time only)
docker-compose exec backend alembic upgrade head

# Seed demo data (first time only)
docker-compose exec backend python scripts/seed.py
```

### Step 4: Install Playwright (for Browser Intelligence)

```bash
docker-compose exec backend playwright install chromium --with-deps
```

### Step 5: Verify

```bash
# Health check
curl http://localhost:8000/health
# Expected: {"status":"healthy"}

# Full verification
bash scripts/verify_full_stack.sh
```

### Service URLs

| Service | URL | Credentials |
|---------|-----|-------------|
| Frontend | http://localhost:3000 | — |
| Backend API | http://localhost:8000 | — |
| Swagger Docs | http://localhost:8000/api/docs | — |
| Prometheus | http://localhost:9090 | — |
| Grafana | http://localhost:3001 | admin / $GRAFANA_PASSWORD |
| Celery Flower | http://localhost:5555 | — |
| **Demo Login** | http://localhost:3000/auth/login | admin@blackmirror.io / BlackMirrorX2025! |

### Common Operations

```bash
# View logs
docker-compose logs backend --tail=100 -f
docker-compose logs worker --tail=100 -f

# Restart a service
docker-compose restart backend

# Stop everything
docker-compose down

# Stop and wipe database (DESTRUCTIVE)
docker-compose down -v

# Update after code changes
docker-compose build backend && docker-compose up -d backend
```

---

## Option B: Bare Metal (No Docker)

### Prerequisites

```bash
# Ubuntu 24.04
apt-get install -y \
  python3.12 python3-pip \
  postgresql-16 postgresql-16-pgvector \
  redis-server \
  nodejs npm \
  git curl

# Node.js 18+ (if system version is older)
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs
```

### Database Setup

```bash
# Start PostgreSQL
systemctl start postgresql redis-server

# Create user and database
sudo -u postgres psql << SQL
CREATE USER bmx WITH PASSWORD 'your-password';
CREATE DATABASE blackmirror OWNER bmx;
\c blackmirror
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
\q
SQL
```

### Backend Setup

```bash
cd blackmirror-x/backend
pip3 install -r requirements.txt

# Set environment
export DATABASE_URL="postgresql+asyncpg://bmx:your-password@127.0.0.1:5432/blackmirror"
export SECRET_KEY="$(openssl rand -hex 32)"
export JWT_SECRET_KEY="$(openssl rand -hex 32)"
export ANTHROPIC_API_KEY="sk-ant-YOUR-KEY"
export REDIS_URL="redis://127.0.0.1:6379/0"
export CELERY_BROKER_URL="redis://127.0.0.1:6379/1"
export BMX_VAULT_KEY="$(openssl rand -hex 32)"

# Or load from .env file:
# export $(cat ../.env | grep -v '^#' | xargs)

# Migrate and seed
alembic upgrade head
python scripts/seed.py

# Start backend
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2
```

### Celery Worker (separate terminal)

```bash
cd blackmirror-x/backend
celery -A app.workers.celery_app worker --loglevel=info --concurrency=4
```

### Frontend Setup

```bash
cd blackmirror-x/frontend
npm install --legacy-peer-deps

# For production
npm run build
npm start

# For development
npm run dev
```

### Playwright (Browser Intelligence)

```bash
pip3 install playwright
playwright install chromium --with-deps
```

---

## Production Hardening Checklist

Before deploying to production:

- [ ] Replace all demo credentials (`BlackMirrorX2025!`)
- [ ] Generate fresh `SECRET_KEY`, `JWT_SECRET_KEY`, `BMX_VAULT_KEY`
- [ ] Set `DEBUG=false` and `APP_ENV=production`
- [ ] Enable HTTPS (reverse proxy with nginx/caddy)
- [ ] Set `CORS_ORIGINS` to your actual domain
- [ ] Configure rate limiting (`RATE_LIMIT_PER_MINUTE`)
- [ ] Set up log shipping (Sentry: `SENTRY_DSN`)
- [ ] Configure backups for PostgreSQL data volume
- [ ] Run `npm audit fix` on frontend
- [ ] Restrict PostgreSQL access to application only
- [ ] Set up Grafana authentication
- [ ] Set `SCAN_RATE_LIMIT_PER_HOUR` to prevent abuse

---

## Upgrade Procedure

```bash
# 1. Pull latest code
git pull origin main  # or unzip new release

# 2. Rebuild images
docker-compose build --no-cache backend

# 3. Run new migrations
docker-compose exec backend alembic upgrade head

# 4. Restart
docker-compose up -d
```
