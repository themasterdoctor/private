# BLACKMIRROR-X GLASSWING v2.0

**Autonomous Vulnerability Research Operating System**  
AI-powered bug bounty platform with reasoning streams, hypothesis engine, validation court, and attack chain composition.

---

## Quick Start

```bash
# 1. Clone / unzip and enter the directory
cd blackmirror-x

# 2. Configure
cp .env.example .env
# Edit .env — minimum required:
#   ANTHROPIC_API_KEY=sk-ant-YOUR-KEY
#   SECRET_KEY=<32+ random chars>
#   JWT_SECRET_KEY=<32+ random chars>
#   POSTGRES_PASSWORD=<choose one>
#   BMX_VAULT_KEY=<32+ random chars>

# 3. Start
docker-compose up -d

# 4. Migrate + seed
docker-compose exec backend alembic upgrade head
docker-compose exec backend python scripts/seed.py

# 5. Open
open http://localhost:3000
# Login: admin@blackmirror.io / BlackMirrorX2025!
```

---

## Architecture

```
Frontend (Next.js 14)     → http://localhost:3000
Backend (FastAPI)         → http://localhost:8000
API Docs (Swagger)        → http://localhost:8000/api/docs
PostgreSQL + pgvector     → localhost:5432
Redis                     → localhost:6379
Celery Worker             → background
Prometheus                → http://localhost:9090
Grafana                   → http://localhost:3001
Celery Flower             → http://localhost:5555
```

## Intelligence Systems

| System | Description |
|--------|-------------|
| Reasoning Streams | Every agent emits live SSE reasoning trace |
| Hypothesis Engine | Autonomous vulnerability hypothesis formation and ranking |
| Validation Court | 5-agent adversarial vuln validation (prosecution / defense / judge) |
| Workspace Memory | Persistent learning from past scans — payload telemetry, FP signatures |
| Attack Chain Composer | Multi-step attack path graph with probability scoring |
| Payload Intelligence | WAF-aware, context-aware payload selection (XSS/SQLi/SSRF/SSTI/etc.) |
| JS Reverse Engineer | AST analysis, secret extraction, DOM XSS source→sink mapping |
| Browser Intelligence | Playwright authenticated crawling, SPA route discovery |
| API Exploitation | GraphQL abuse, BOLA/IDOR scoring, shadow endpoint discovery |
| Exploitability Simulator | Safe ATO/data exposure/cloud compromise impact simulation |
| Continuous Monitor | Subdomain/JS/CSP change detection and alerting |
| Self-Improvement Loop | Post-scan learning updates workspace memory automatically |

## Frontend Pages

| Route | Description |
|-------|-------------|
| `/dashboard` | Overview: scan stats, vuln counts, recent activity |
| `/recon` | Subdomain map, technology fingerprints |
| `/vulns` | Vulnerability list with severity filter |
| `/graph` | D3 attack graph visualizer |
| `/mission` | Mission Control: hypothesis board + live reasoning trace |
| `/court` | AI Courtroom: 5-agent verdict + exploitability simulation |
| `/evidence` | Evidence Vault: request/response proof browser |
| `/monitor` | Continuous monitoring dashboard with alert feed |
| `/replay` | HTTP request replay lab |
| `/copilot` | AI Copilot chat with scan context |
| `/reports` | Report generation and export |
| `/settings` | Workspace and API key management |

## Environment Variables

See `.env.example` for all variables. Critical ones:

```
ANTHROPIC_API_KEY      # Required for AI features
SECRET_KEY             # JWT signing (32+ chars)
JWT_SECRET_KEY         # JWT signing (32+ chars)  
POSTGRES_PASSWORD      # Database password
BMX_VAULT_KEY          # Secrets vault encryption key
```

## Requirements

- Docker + Docker Compose
- 4GB RAM minimum (8GB recommended)
- For local install without Docker: Python 3.12+, Node 18+, PostgreSQL 16, Redis 7

## Verification

```bash
bash scripts/verify_backend.sh     # Backend static checks
bash scripts/verify_frontend.sh    # Frontend build checks
bash scripts/verify_full_stack.sh  # Full live stack verification
```

## Project Structure

```
blackmirror-x/
├── backend/
│   ├── app/
│   │   ├── api/routes/          # FastAPI route handlers
│   │   ├── intelligence/        # Phase 6 intelligence systems
│   │   ├── agents/              # AI scanning agents
│   │   ├── models/models.py     # SQLAlchemy ORM
│   │   ├── schemas/             # Pydantic schemas
│   │   ├── monitoring/          # Continuous monitoring
│   │   ├── metrics/             # Prometheus metrics
│   │   ├── vault/               # Encrypted secrets vault
│   │   └── reporting/           # Report generators
│   ├── alembic/                 # DB migrations
│   ├── scripts/seed.py          # Demo data seeder
│   └── tests/test_full_stack.py # 43-test suite
├── frontend/
│   └── src/app/                 # Next.js pages
├── scripts/
│   ├── verify_backend.sh
│   ├── verify_frontend.sh
│   └── verify_full_stack.sh
├── infrastructure/prometheus.yml
├── docker-compose.yml
├── .env.example
├── PRODUCTION_READINESS.md
├── RUNTIME_VALIDATION.md
├── DEPLOYMENT.md
└── TROUBLESHOOTING.md
```

## Verified Test Results

- **43/43 pytest tests pass** (no external services required)
- **31/31 live API tests pass** (against real PostgreSQL + Redis)
- **17/17 Next.js routes compile**
- **0 TypeScript errors**
- **0 ESLint errors**

---

*BLACKMIRROR-X GLASSWING v2.0 — Built for bug bounty hunters, security researchers, and AppSec teams.*
