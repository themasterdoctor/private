"""
BMX Test Lab — Vulnerable GraphQL endpoint.
LEGAL TEST TARGET ONLY. Local use only.

Intentional vulnerabilities:
- Introspection enabled
- No depth limit
- Batch queries accepted
- Field suggestions on typo
- IDOR via node IDs
"""
from flask import Flask, request, jsonify

app = Flask(__name__)

SCHEMA_TYPES = [
    {"name": "Query",    "fields": [{"name": "user", "type": {"name": "User"}}, {"name": "users", "type": {"name": "UserList"}}]},
    {"name": "Mutation", "fields": [{"name": "updateUser"}, {"name": "deleteUser"}, {"name": "resetPassword"}, {"name": "promoteToAdmin"}]},
    {"name": "User",     "fields": [{"name": "id"}, {"name": "email"}, {"name": "password"}, {"name": "token"}, {"name": "role"}]},
]

USERS = {
    "1": {"id": "1", "email": "admin@gql.local", "role": "admin", "password": "hunter2", "token": "gql-admin-token"},
    "2": {"id": "2", "email": "user@gql.local",  "role": "user",  "password": "password123", "token": "gql-user-token"},
}

@app.route("/health")
def health():
    return jsonify({"status": "ok", "app": "bmx-testlab-graphql"})

@app.route("/graphql", methods=["POST", "GET"])
def graphql():
    if request.method == "GET":
        q = request.args.get("query", "")
        variables = {}
    else:
        body = request.get_json() or {}
        # Intentional: batch queries supported
        if isinstance(body, list):
            return jsonify([_process_query(b) for b in body])
        q = body.get("query", "")
        variables = body.get("variables", {})
    
    return jsonify(_process_query({"query": q, "variables": variables}))

def _process_query(body):
    q = body.get("query", "")
    
    # Introspection — intentionally enabled
    if "__schema" in q:
        return {"data": {"__schema": {"types": SCHEMA_TYPES}}}
    
    if "__typename" in q:
        return {"data": {"__typename": "Query"}}
    
    # Field suggestion on typo — intentional
    if "usr" in q.lower() and "user" not in q.lower():
        return {"errors": [{"message": "Cannot query field 'usr'. Did you mean 'user'?"}]}
    
    # IDOR — user query with no auth
    if "user(" in q or "user {" in q:
        user_id = "1"  # Default to admin user — intentional IDOR
        import re
        match = re.search(r'id:\s*["\']?(\d+)["\']?', q)
        if match:
            user_id = match.group(1)
        user = USERS.get(user_id, {})
        return {"data": {"user": user}}
    
    if "users" in q:
        return {"data": {"users": list(USERS.values())}}
    
    # Depth limit test — accepts deeply nested
    if q.count("{") > 5:
        return {"data": {"__typename": "Query"}}  # Intentional: no depth limit
    
    return {"data": {}}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=9003, debug=False)
