"""
BMX Test Lab — Intentionally Vulnerable REST API
LEGAL TEST TARGET ONLY. Local use only. Do not deploy publicly.

Vulnerabilities included (intentional, for BMX scanner testing):
- IDOR on /api/users/{id} (no auth)
- Missing auth on /api/admin/users  
- Reflected content in /api/search
- Open redirect in /api/redirect
- CORS wildcard + credentials
- Verbose error disclosure
- Simulated SQL error on /api/items
- Mass assignment on /api/profile
"""
from flask import Flask, request, jsonify, redirect

app = Flask(__name__)

USERS = {
    "1": {"id": "1", "email": "admin@testlab.local", "role": "admin", "api_token": "admin-tok-xyz"},
    "2": {"id": "2", "email": "user@testlab.local",  "role": "user",  "api_token": "user-tok-abc"},
    "3": {"id": "3", "email": "victim@testlab.local","role": "user",  "api_token": "victim-tok-def"},
}

@app.after_request
def add_headers(response):
    # Intentional misconfigurations for BMX to detect
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Credentials"] = "true"
    response.headers["X-Powered-By"] = "Flask/3.0 Python/3.12"
    # Missing security headers (intentional)
    return response

@app.route("/health")
def health():
    return jsonify({"status": "ok", "app": "bmx-testlab-vuln-api"})

@app.route("/api/users")
def list_users():
    # Intentional: no auth, returns all users
    return jsonify(list(USERS.values()))

@app.route("/api/users/<user_id>")
def get_user(user_id):
    # Intentional IDOR: no auth check
    user = USERS.get(user_id)
    if not user:
        return jsonify({
            "error": "User not found",
            "detail": f"No user with id={user_id} in database",
        }), 404
    return jsonify(user)  # Returns secret token — intentional

@app.route("/api/admin/users")
def admin_users():
    # Intentional: admin endpoint with no authentication
    return jsonify({"users": list(USERS.values()), "total": len(USERS)})

@app.route("/api/search")
def search():
    # Intentional: reflects query parameter
    q = request.args.get("q", "")
    return jsonify({"query": q, "results": [], "count": 0})

@app.route("/api/redirect")
def open_redirect():
    # Intentional: no URL validation
    url = request.args.get("url", "/")
    return redirect(url)

@app.route("/api/items")
def items():
    # Intentional: simulates SQL injection detection
    f = request.args.get("filter", "")
    if "'" in f or "--" in f or "OR" in f.upper():
        return jsonify({
            "error": "Database error",
            "detail": f"SQL syntax error near '{f}'",
            "query": f"SELECT * FROM items WHERE name LIKE '%{f}%'",
        }), 500
    return jsonify({"items": [], "filter": f})

@app.route("/api/profile", methods=["POST"])
def update_profile():
    # Intentional: mass assignment (accepts any field)
    data = request.get_json() or {}
    return jsonify({"updated": True, "fields": list(data.keys())})

@app.route("/api/graphql", methods=["POST", "GET"])
def fake_graphql():
    # Intentional: introspection enabled, suggests field names
    q = ""
    if request.method == "POST":
        body = request.get_json() or {}
        q = body.get("query", "")
    else:
        q = request.args.get("query", "")
    
    if "__schema" in q or "__typename" in q:
        return jsonify({
            "data": {"__schema": {"types": [
                {"name": "User", "fields": [{"name": "id"}, {"name": "email"}, {"name": "role"}, {"name": "api_token"}]},
                {"name": "Admin", "fields": [{"name": "resetUserPassword"}, {"name": "deleteUser"}]},
            ]}},
        })
    if "usr" in q:
        return jsonify({"errors": [{"message": "Cannot query field 'usr'. Did you mean 'user'?"}]})
    return jsonify({"data": {}, "errors": []})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=9001, debug=False)
