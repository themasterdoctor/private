"""
BLACKMIRROR-X Test Lab — Intentionally Vulnerable API
LEGAL: Local test target only. Do NOT expose to internet.

Vulnerabilities implemented:
1. IDOR — /api/users/{id}/profile (no auth check)
2. Reflected XSS — /search?q= (unencoded echo)
3. Open Redirect — /redirect?url= (no validation)
4. SQLi hint — /api/products?name= (simulated time delay pattern)
5. GraphQL introspection — /graphql (introspection enabled)
6. CORS wildcard — all responses
7. Missing security headers
8. Verbose error — stack traces on /api/debug
"""
import asyncio
import json
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer

USERS = {
    "1": {"id": "1", "email": "alice@corp.com", "role": "admin", "secret": "api_key_abc123"},
    "2": {"id": "2", "email": "bob@corp.com",   "role": "user",  "secret": "session_tok_xyz"},
    "3": {"id": "3", "email": "carol@corp.com",  "role": "user",  "secret": "oauth_bearer_999"},
}

GRAPHQL_SCHEMA = json.dumps({
    "data": {
        "__schema": {
            "types": [
                {"name": "Query", "fields": [
                    {"name": "user", "type": {"name": "User"}},
                    {"name": "users", "type": {"name": "[User]"}},
                    {"name": "adminPanel", "type": {"name": "AdminPanel"}},
                ]},
                {"name": "User", "fields": [
                    {"name": "id"}, {"name": "email"}, {"name": "role"},
                    {"name": "secret"}, {"name": "internalNotes"},
                ]},
                {"name": "AdminPanel", "fields": [
                    {"name": "users"}, {"name": "systemConfig"}, {"name": "apiKeys"},
                ]},
            ]
        }
    }
})


class TestLabHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # suppress default logging

    def send_json(self, data, status=200, extra_headers=None):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        # VULNERABILITY: Wildcard CORS
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Credentials", "true")
        # VULNERABILITY: Missing security headers (intentional)
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def send_html(self, html, status=200):
        body = html.encode()
        self.send_response(status)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        # VULNERABILITY: No CSP, no X-Frame-Options, no HSTS
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        params = dict(urllib.parse.parse_qsl(parsed.query))

        # 1. IDOR — no auth check on user profiles
        if path.startswith("/api/users/") and path.endswith("/profile"):
            user_id = path.split("/")[3]
            user = USERS.get(user_id)
            if user:
                self.send_json(user)  # exposes .secret field
            else:
                self.send_json({"error": "user not found"}, 404)
            return

        # 2. Reflected XSS — query param echoed in HTML without encoding
        if path == "/search":
            q = params.get("q", "")
            # VULNERABILITY: Direct HTML injection
            html = f"""<!DOCTYPE html><html><body>
<h1>Search Results</h1>
<p>Results for: {q}</p>
<p>No results found.</p>
</body></html>"""
            self.send_html(html)
            return

        # 3. Open Redirect — no validation of target URL
        if path == "/redirect":
            url = params.get("url", "/")
            self.send_response(302)
            self.send_header("Location", url)  # VULNERABILITY: unvalidated
            self.end_headers()
            return

        # 4. SQLi hint — simulates slow query for boolean inputs
        if path == "/api/products":
            name = params.get("name", "")
            results = []
            if "'" in name or "OR" in name.upper() or "--" in name:
                # Simulate error-based response
                self.send_json({
                    "error": "You have an error in your SQL syntax; check the manual",
                    "query": f"SELECT * FROM products WHERE name = '{name}'",
                    "sql_state": "42000"
                }, 500)
                return
            if "SLEEP" in name.upper() or "WAITFOR" in name.upper():
                time.sleep(5)  # VULNERABILITY: time-based SQLi simulation
            self.send_json({"results": results, "query": name})
            return

        # 5. GraphQL introspection
        if path == "/graphql":
            q = params.get("query", "")
            if "__schema" in q or "introspection" in q.lower():
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                body = GRAPHQL_SCHEMA.encode()
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            self.send_json({"data": {"user": None}})
            return

        # 6. Verbose error / debug endpoint
        if path == "/api/debug":
            self.send_json({
                "error": "Internal error",
                "traceback": "File '/app/database.py', line 42, in query\n  conn = psycopg2.connect(DATABASE_URL)\npsycopg2.OperationalError: could not connect",
                "env": {"DB_HOST": "db.internal", "DB_USER": "app", "SECRET_KEY": "hardcoded-dev-secret-1234"},
                "version": "BMX-TestLab/1.0"
            }, 500)
            return

        # 7. SSRF endpoint
        if path == "/api/fetch":
            target_url = params.get("url", "")
            self.send_json({
                "status": "fetching",
                "target": target_url,
                "note": "SSRF_ENDPOINT: This endpoint fetches the provided URL server-side"
            })
            return

        # 8. JWT-less admin endpoint
        if path == "/api/admin/users":
            token = self.headers.get("Authorization", "")
            if not token:
                self.send_json({"error": "No token"}, 401)
                return
            # VULNERABILITY: No signature validation
            self.send_json({"users": list(USERS.values())})
            return

        # Root
        if path == "/":
            self.send_json({
                "service": "BMX-TestLab Vulnerable API",
                "version": "1.0",
                "legal": "LOCAL TESTING ONLY — Do not expose to internet",
                "endpoints": [
                    "GET /api/users/{id}/profile (IDOR)",
                    "GET /search?q= (Reflected XSS)",
                    "GET /redirect?url= (Open Redirect)",
                    "GET /api/products?name= (SQLi hint)",
                    "GET /graphql?query= (GraphQL introspection)",
                    "GET /api/debug (Verbose error)",
                    "GET /api/fetch?url= (SSRF endpoint)",
                    "GET /api/admin/users (Missing auth validation)",
                ]
            })
            return

        self.send_json({"error": "not found"}, 404)

    def do_POST(self):
        content_len = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_len).decode() if content_len else ""
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/graphql":
            try:
                data = json.loads(body)
                query = data.get("query", "")
                if "__schema" in query:
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    b = GRAPHQL_SCHEMA.encode()
                    self.send_header("Content-Length", str(len(b)))
                    self.end_headers()
                    self.wfile.write(b)
                    return
                if isinstance(data, list):
                    # VULNERABILITY: Batch queries enabled
                    results = [{"data": {"__typename": "Query"}} for _ in data]
                    self.send_json(results)
                    return
            except Exception:
                pass
            self.send_json({"data": None})
            return

        if path == "/api/mass-assign":
            try:
                data = json.loads(body)
                # VULNERABILITY: Accept privileged fields
                if data.get("isAdmin") or data.get("role") == "admin":
                    self.send_json({
                        "success": True,
                        "user": {**data, "role": "admin"},
                        "message": "MASS_ASSIGNMENT: Privileged field accepted"
                    })
                    return
            except Exception:
                pass
            self.send_json({"success": True})
            return

        self.send_json({"error": "not found"}, 404)


def run(port=9001):
    server = HTTPServer(("127.0.0.1", port), TestLabHandler)
    print(f"BMX TestLab API running on http://127.0.0.1:{port}")
    print("LEGAL: Local testing only — do NOT expose to internet")
    server.serve_forever()


if __name__ == "__main__":
    run()
