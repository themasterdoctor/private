# ALPHA_USER_GUIDE.md
# BLACKMIRROR-X GLASSWING — Alpha User Guide

Welcome to the private alpha. This guide gets you scanning in under 10 minutes.

---

## 1. Install

### Option A: Docker (Recommended)

```bash
# Clone or unzip the package
cd blackmirror-x

# Set your server IP (if running on a remote server)
export SERVER_IP="your.server.ip"   # or "localhost" for local
sed -i "s|^NEXT_PUBLIC_API_URL=.*|NEXT_PUBLIC_API_URL=http://${SERVER_IP}:8000|" .env
sed -i "s|^NEXT_PUBLIC_WS_URL=.*|NEXT_PUBLIC_WS_URL=ws://${SERVER_IP}:8000|" .env

# Build and start
docker compose build --no-cache
docker compose up -d

# Wait ~30 seconds for migrations and seed to complete
docker compose logs -f backend | grep -E "✅|🚀"
```

**Services:**
- Dashboard: http://localhost:3000
- API: http://localhost:8000
- API Docs: http://localhost:8000/api/docs

### Option B: Bare Metal

```bash
cd blackmirror-x

# 1. Copy and configure environment
cp .env.example .env
# Edit .env: update DATABASE_URL and REDIS_URL for your setup

# 2. Backend
cd backend
pip install -r requirements.txt
python -m alembic upgrade head
python scripts/seed.py
uvicorn app.main:app --host 0.0.0.0 --port 8000 &
celery -A app.workers.celery_app worker --loglevel=info &

# 3. Frontend
cd frontend
npm install
NEXT_PUBLIC_API_URL=http://localhost:8000 npm run build
npm start &
```

---

## 2. Log In

1. Open `http://localhost:3000` in your browser
2. You'll be redirected to `/auth/login`
3. Enter credentials:
   - **Email:** `admin@blackmirror.io`
   - **Password:** `BlackMirrorX2025!`
4. You'll land on the Dashboard

**First time?** Navigate to `/onboarding` for the guided setup wizard.

---

## 3. Run the Demo Scan

The fastest way to see BLACKMIRROR-X working:

### Via Terminal (CLI)
```bash
# Start the local intentionally-vulnerable testlab (safe to scan)
cd testlab/vuln-api && python app.py &

# Run the full demo
bash scripts/demo_run.sh
```

This will:
- Authenticate and create a workspace
- Run passive vulnerability checks against the testlab
- Detect 6 real vulnerabilities (no false positives)
- Generate a report
- Show an attack chain and court verdict

Expected output includes:
```
  ⚠  [CRITICAL] Broken Access: Admin users accessible without auth
  ⚠  [CRITICAL] SQLi: Error message leaks SQL
  ⚠  [HIGH] IDOR: User profile exposes api_token
  ...
  ✓  6 findings detected (2 critical)
  ✓  Attack chain: SSRF → Cloud Metadata → RCE (76%, $15,000+)
  ✓  Court verdict: CONFIRMED — 94% confidence
```

### Via Browser
1. Click **Demo Mode** in the sidebar
2. Click **Reset Demo** to load fresh data
3. Click **Prebuilt Chain** to see the SSRF attack chain
4. Click **Prebuilt Verdict** to see the court decision

---

## 4. Run an Authorized Scan

> ⚠️ **Only scan systems you own or have explicit written permission to test.**

### Step 1: Create a Workspace
1. Go to **Settings** → **Workspaces**
2. Click **New Workspace**
3. Name it after your target program (e.g., "HackerOne - example.com")

### Step 2: Use a Guided Workflow
1. Click **Workflows** in the sidebar
2. Choose a workflow appropriate for your authorization level:
   - **Recon Only** — safe for any authorized target, passive
   - **JS Analysis** — downloads and analyzes JS, passive
   - **API Audit** — tests APIs, low-risk active
   - **Full Safe Scan** — all modules, medium risk
3. Enter your target domain
4. Check **"I have authorization to test this target"**
5. Review the safety panel (rate limit, risk tier, approval requirements)
6. Click **Launch**

### Step 3: Monitor Progress
- Watch the **Dashboard** for live scan progress
- Check **Recon** for discovered subdomains
- Check **Vulnerabilities** for findings as they appear

### Step 4: Use AVROS Orchestrator (Advanced)
1. Create a scan in **Scans**
2. Go to **AVROS → Orchestrator**
3. Select your scan and click **Start Orchestrator**
4. Watch the agent task graph execute in real time
5. Approve any tasks flagged as needing human review

---

## 5. Read Findings

### Finding List
- Navigate to **Vulnerabilities** in the sidebar
- Filter by severity (Critical/High/Medium/Low) using the filter bar
- Each finding shows: title, severity, URL, status

### Finding Detail
Click any vulnerability to see:
- **Description** — what the vulnerability is
- **URL** — where it was found
- **Payload** — what triggered it
- **Remediation** — how to fix it
- **Evidence** — proof screenshots/request-response pairs

### Court Validation
1. Go to **AI Courtroom**
2. Select a finding
3. Click **Adjudicate** — the AI validates whether it's real and exploitable
4. Result: CONFIRMED / REJECTED / UNCONFIRMED with confidence score and reasoning

### Attack Chains
1. Go to **AVROS → Chains**
2. Paste your vulnerability JSON or load from a scan
3. Click **Build Attack Chains**
4. See how individual findings chain into multi-step attacks
5. Review: probability, estimated bounty, missing proof, next steps

---

## 6. Export Reports

### From the UI
1. Go to **Reports**
2. Find your scan's report (generated automatically after scan completes)
3. Click to view the full report with findings, chains, and executive summary

### Via API
```bash
TOKEN=$(curl -s -X POST http://localhost:8000/api/v1/auth/login \
  -d "username=admin@blackmirror.io&password=BlackMirrorX2025!" | jq -r .access_token)

# Get scan ID
SCAN_ID=$(curl -s -H "Authorization: Bearer $TOKEN" \
  http://localhost:8000/api/v1/scans | jq -r '.[0].id')

# Generate report
curl -X POST -H "Authorization: Bearer $TOKEN" \
  http://localhost:8000/api/v1/reports/generate/$SCAN_ID

# List reports
curl -H "Authorization: Bearer $TOKEN" \
  "http://localhost:8000/api/v1/reports?workspace_id=YOUR_WS_ID"
```

### Demo Report (Instant)
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:8000/api/v1/demo/report | jq .
```

---

## 7. Safety Rules

### Before Every Scan
- [ ] I have **written authorization** from the target organization
- [ ] The target domain is in the workspace **scope** field
- [ ] I've selected the appropriate **risk tier** for my authorization level
- [ ] I've reviewed the **rate limit** setting (default: 5 req/s)

### During a Scan
- The **Emergency Stop** button is always available in **Workers**
- CRITICAL-tier tasks require your approval before executing
- All scan activity is logged in the audit trail

### Emergency Stop
```bash
# Stop everything immediately
curl -X POST -H "Authorization: Bearer $TOKEN" \
  http://localhost:8000/api/v1/workers/emergency-stop

# Or in the UI: Workers → Emergency Stop button
```

### What BLACKMIRROR-X Does NOT Do
- No credential brute force
- No DoS attacks (rate limit prevents this)
- No data exfiltration beyond evidence capture
- No bypassing auth without explicit test credentials provided by you

### Golden Rules
1. **Never test without authorization.** This is illegal in most jurisdictions.
2. **Start passive.** Use Recon Only or JS Analysis before any active testing.
3. **Use the testlab first.** Validate your setup against `localhost:9001` before touching real targets.
4. **One target at a time.** Don't scan multiple programs simultaneously.
5. **Save the workspace.** Keep workspaces per-program for clean audit trails.

---

## Useful Commands Reference

```bash
# Start everything
docker compose up -d

# View logs
docker compose logs -f backend

# Reset demo data
curl -X POST -H "Authorization: Bearer $TOKEN" http://localhost:8000/api/v1/demo/reset

# Run E2E test
bash scripts/run_e2e_testlab.sh

# Run full verification
bash scripts/verify_full_stack.sh

# Emergency stop
curl -X POST -H "Authorization: Bearer $TOKEN" http://localhost:8000/api/v1/workers/emergency-stop
```

---

## Getting Help

- **API Docs:** http://localhost:8000/api/docs (interactive Swagger UI)
- **Troubleshooting:** `TROUBLESHOOTING.md`
- **Security model:** `SECURITY_MODEL.md`
- **Full operator manual:** `OPERATOR_MANUAL.md`
