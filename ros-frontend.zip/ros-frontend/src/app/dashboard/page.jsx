'use client';
import { useState, useEffect, useCallback } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

// ── Helpers ──
const fmt = n => '$' + Math.round(n||0).toLocaleString();
const fmtK = n => (n>=1000||n<=-1000) ? '$'+(n/1000).toFixed(1)+'k' : fmt(n);
const pct = n => (n||0).toFixed(1)+'%';
const gc = (v,g,w) => v<=g?'#00e5a0':v<=w?'#f0a030':'#f05050';

function apiFetch(path, opts={}) {
  const tokens = JSON.parse(localStorage.getItem('ros_tokens')||'{}');
  return fetch(`${API}${path}`, {
    ...opts,
    headers: { 'Content-Type':'application/json', ...(tokens.access?{'Authorization':`Bearer ${tokens.access}`}:{}), ...opts.headers },
  }).then(r => r.json());
}

// ── Styles ──
const C = {
  app:   { display:'flex', minHeight:'100vh', background:'#0d0d0f', fontFamily:'system-ui,sans-serif', color:'#eeeae3' },
  side:  { width:'220px', flexShrink:0, background:'#131316', borderRight:'1px solid rgba(255,255,255,0.06)', display:'flex', flexDirection:'column', position:'fixed', top:0, bottom:0 },
  logo:  { padding:'16px', borderBottom:'1px solid rgba(255,255,255,0.06)', fontSize:'15px', fontWeight:800, color:'#eeeae3', display:'flex', alignItems:'center', gap:'8px' },
  dot:   { width:'8px', height:'8px', borderRadius:'50%', background:'#00e5a0', boxShadow:'0 0 8px #00e5a0' },
  nav:   { flex:1, padding:'10px 8px', overflowY:'auto' },
  sec:   { fontSize:'10px', fontWeight:600, letterSpacing:'0.12em', textTransform:'uppercase', color:'#4a4845', padding:'8px 8px 4px' },
  ni:    (active) => ({ display:'flex', alignItems:'center', gap:'8px', padding:'8px 10px', borderRadius:'8px', cursor:'pointer', color: active?'#00e5a0':'#8a8680', background: active?'rgba(0,229,160,0.08)':'transparent', fontSize:'13px', marginBottom:'2px', userSelect:'none' }),
  main:  { marginLeft:'220px', flex:1 },
  top:   { height:'48px', background:'#131316', borderBottom:'1px solid rgba(255,255,255,0.06)', display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 24px', position:'sticky', top:0, zIndex:10 },
  cont:  { padding:'20px 24px' },
  card:  { background:'#131316', border:'1px solid rgba(255,255,255,0.06)', borderRadius:'12px', padding:'18px 20px', marginBottom:'16px' },
  ctit:  { fontSize:'10px', fontWeight:600, letterSpacing:'0.12em', textTransform:'uppercase', color:'#4a4845', marginBottom:'14px' },
  grid:  (cols) => ({ display:'grid', gridTemplateColumns:`repeat(${cols}, 1fr)`, gap:'12px', marginBottom:'16px' }),
  kpi:   { background:'#131316', border:'1px solid rgba(255,255,255,0.06)', borderRadius:'10px', padding:'14px 16px' },
  klbl:  { fontSize:'11px', color:'#4a4845', marginBottom:'6px' },
  kval:  { fontSize:'22px', fontWeight:700, color:'#eeeae3', lineHeight:1, marginBottom:'4px' },
  ksub:  { fontSize:'11px' },
  btn:   { padding:'7px 14px', background:'#00e5a0', border:'none', borderRadius:'8px', color:'#0d0d0f', fontWeight:600, fontSize:'12px', cursor:'pointer' },
  btnG:  { padding:'7px 14px', background:'transparent', border:'1px solid rgba(255,255,255,0.1)', borderRadius:'8px', color:'#8a8680', fontSize:'12px', cursor:'pointer' },
  inp:   { background:'#1a1a1e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:'8px', padding:'7px 10px', fontSize:'13px', color:'#eeeae3', outline:'none', width:'100%', boxSizing:'border-box', height:'34px' },
  lbl:   { display:'block', fontSize:'11px', color:'#8a8680', marginBottom:'4px' },
  tbl:   { width:'100%', borderCollapse:'collapse' },
  th:    { textAlign:'left', fontSize:'10px', fontWeight:600, color:'#4a4845', letterSpacing:'0.08em', textTransform:'uppercase', padding:'8px 10px', borderBottom:'1px solid rgba(255,255,255,0.06)' },
  td:    { padding:'9px 10px', borderBottom:'1px solid rgba(255,255,255,0.04)', fontSize:'13px' },
  tag:   (c) => ({ display:'inline-flex', alignItems:'center', padding:'2px 8px', borderRadius:'20px', fontSize:'11px', fontWeight:600, background:c==='g'?'rgba(0,229,160,0.1)':c==='a'?'rgba(240,160,48,0.1)':'rgba(240,80,80,0.1)', color:c==='g'?'#00e5a0':c==='a'?'#f0a030':'#f05050' }),
  sep:   { height:'1px', background:'rgba(255,255,255,0.06)', margin:'14px 0' },
  alert: (sev) => ({ padding:'10px 14px', borderRadius:'8px', fontSize:'12px', marginBottom:'8px', borderLeft:'3px solid', background:sev==='CRITICAL'?'rgba(240,80,80,0.06)':sev==='WARNING'?'rgba(240,160,48,0.06)':'rgba(0,229,160,0.06)', borderLeftColor:sev==='CRITICAL'?'#f05050':sev==='WARNING'?'#f0a030':'#00e5a0', color:sev==='CRITICAL'?'#f08080':sev==='WARNING'?'#f5b84a':'#5eedc0' }),
};

const PAGES = ['dashboard','sales','inventory','staff','food-cost','finance','valuation','settings'];
const PAGE_LABELS = { dashboard:'Dashboard', sales:'Sales', inventory:'Inventory', staff:'Staff & Labor', 'food-cost':'Food Cost', finance:'P&L / Finance', valuation:'Valuation', settings:'Settings' };

// ── Demo data ──
const DEMO = {
  finance: { totalRevenue:85000, cogs:23970, foodCostPct:28.2, totalLaborCost:29325, laborCostPct:34.5, primeCost:53295, primeCostPct:62.7, netProfit:17255, netMarginPct:20.3, healthScore:74, breakEvenGap:9800, grossProfit:61030 },
  sales: [
    {date:'2026-05-16',covers:195,dineInSales:4100,deliverySales:1250,takeoutSales:510},
    {date:'2026-05-15',covers:178,dineInSales:3800,deliverySales:1100,takeoutSales:450},
    {date:'2026-05-14',covers:165,dineInSales:3500,deliverySales:920,takeoutSales:400},
    {date:'2026-05-13',covers:144,dineInSales:3050,deliverySales:700,takeoutSales:310},
    {date:'2026-05-12',covers:152,dineInSales:3200,deliverySales:810,takeoutSales:340},
  ],
  inventory: [
    {name:'Salmon 12-14',category:'Fish',unit:'LB',quantityOnHand:18,parLevel:5,unitCost:5.50,supplier:{name:'Ocean Seafood Depot'}},
    {name:'Tuna #2+',category:'Fish',unit:'LB',quantityOnHand:12,parLevel:4,unitCost:12.99,supplier:{name:'Ocean Seafood Depot'}},
    {name:'Yellowtail',category:'Fish',unit:'LB',quantityOnHand:3,parLevel:4,unitCost:9.50,supplier:{name:'Ocean Seafood Depot'}},
    {name:'Bay Scallop',category:'Shellfish',unit:'LB',quantityOnHand:6,parLevel:2,unitCost:24.95,supplier:{name:'Ocean Seafood Depot'}},
    {name:'Argentine Red Shrimp',category:'Shellfish',unit:'LB',quantityOnHand:0,parLevel:5,unitCost:7.40,supplier:{name:'Ocean Seafood Depot'}},
    {name:'Avocado',category:'Produce',unit:'EA',quantityOnHand:40,parLevel:15,unitCost:0.82,supplier:{name:'Local Farm'}},
    {name:'Nori Sheet',category:'Dry Goods',unit:'PKT',quantityOnHand:12,parLevel:5,unitCost:2.75,supplier:{name:'JFC Int.'}},
  ],
  staff: [
    {firstName:'Kenji',lastName:'T.',role:'Head Chef',employmentType:'SALARY',annualSalary:66000,weeklyHours:45},
    {firstName:'Ana',lastName:'L.',role:'Sous Chef',employmentType:'HOURLY',hourlyRate:22,weeklyHours:40},
    {firstName:'Marcus',lastName:'R.',role:'Line Cook',employmentType:'HOURLY',hourlyRate:18,weeklyHours:38},
    {firstName:'Sofia',lastName:'M.',role:'Server',employmentType:'HOURLY',hourlyRate:15,weeklyHours:35},
    {firstName:'Liam',lastName:'K.',role:'Server',employmentType:'HOURLY',hourlyRate:15,weeklyHours:30},
    {firstName:'Priya',lastName:'N.',role:'Host',employmentType:'HOURLY',hourlyRate:16,weeklyHours:32},
    {firstName:'Carlos',lastName:'V.',role:'Dishwasher',employmentType:'HOURLY',hourlyRate:16,weeklyHours:40},
  ],
  recipes: [
    {name:'Cucumber Hand Roll',emoji:'🥒',menuPrice:6.50,totalIngredientCost:0.55},
    {name:'Bay Scallop Roll',emoji:'🦪',menuPrice:7.00,totalIngredientCost:1.96},
    {name:'Shrimp Hand Roll',emoji:'🍤',menuPrice:7.25,totalIngredientCost:0.91},
    {name:'Albacore Roll',emoji:'🐟',menuPrice:7.75,totalIngredientCost:1.33},
    {name:'Toro Hand Roll',emoji:'🐡',menuPrice:7.75,totalIngredientCost:1.33},
    {name:'Yellowtail Roll',emoji:'🐠',menuPrice:7.75,totalIngredientCost:1.08},
    {name:'Crab Hand Roll',emoji:'🦀',menuPrice:8.00,totalIngredientCost:1.21},
    {name:'Lobster Roll',emoji:'🦞',menuPrice:11.00,totalIngredientCost:1.75},
  ],
};

export default function Dashboard() {
  const [page, setPage] = useState('dashboard');
  const [user, setUser] = useState(null);
  const [org, setOrg] = useState(null);
  const [role, setRole] = useState('');
  const [loc, setLoc] = useState(null);
  const [sales, setSales] = useState(DEMO.sales);
  const [inventory, setInventory] = useState(DEMO.inventory);
  const [staff, setStaff] = useState(DEMO.staff);
  const [fin, setFin] = useState(DEMO.finance);

  // COGS calculator state
  const [cogs, setCogs] = useState({ grossSales:87500, discounts:2500, beginInv:12000, purchases:22500, endInv:10530 });
  // Finance state
  const [finIn, setFinIn] = useState({ grossSales:87500, discounts:2500, beginInv:12000, purchases:22500, endInv:10530, hourlyWages:18000, salaryWages:7500, payrollTax:3800, rent:8500, utilities:2200, insurance:900, marketing:1200, other:2550 });
  // Valuation state
  const [val, setVal] = useState({ netProfit:6200, mult:12, ownerSalary:72000, interest:6000, depreciation:8400, annualRevenue:1020000, ebitda:98400, ebitdaMultiple:3.5 });

  useEffect(() => {
    const u = JSON.parse(localStorage.getItem('ros_user')||'null');
    const o = JSON.parse(localStorage.getItem('ros_org')||'null');
    const r = localStorage.getItem('ros_role')||'';
    const l = JSON.parse(localStorage.getItem('ros_loc')||'null');
    if (!u) { window.location.href='/login'; return; }
    setUser(u); setOrg(o); setRole(r); setLoc(l);
    // Try to load real data
    if (l?.id) {
      apiFetch(`/api/sales/${l.id}?limit=7`).then(d => d.entries?.length && setSales(d.entries)).catch(()=>{});
      apiFetch(`/api/inventory/${l.id}`).then(d => d.items?.length && setInventory(d.items)).catch(()=>{});
      apiFetch(`/api/labor/${l.id}/staff`).then(d => d.staff?.length && setStaff(d.staff)).catch(()=>{});
    }
  }, []);

  const logout = () => { localStorage.clear(); window.location.href='/login'; };

  const navItems = [
    { section:'Overview',   items:['dashboard'] },
    { section:'Operations', items:['sales','inventory','staff'] },
    { section:'Finance',    items:['food-cost','finance','valuation'] },
    { section:'Account',    items:['settings'] },
  ];

  // Computed values
  const netSales = Math.max(0, cogs.grossSales - cogs.discounts);
  const cogsVal  = Math.max(0, cogs.beginInv + cogs.purchases - cogs.endInv);
  const fcPct    = netSales > 0 ? cogsVal/netSales*100 : 0;

  const fnNet    = Math.max(0, finIn.grossSales - finIn.discounts);
  const fnCogs   = Math.max(0, finIn.beginInv + finIn.purchases - finIn.endInv);
  const fnLabor  = finIn.hourlyWages + finIn.salaryWages + finIn.payrollTax;
  const fnOpex   = finIn.rent + finIn.utilities + finIn.insurance + finIn.marketing + finIn.other;
  const fnNet2   = fnNet - fnCogs - fnLabor - fnOpex;
  const fnFcPct  = fnNet>0?fnCogs/fnNet*100:0;
  const fnLcPct  = fnNet>0?fnLabor/fnNet*100:0;
  const fnPcPct  = fnNet>0?(fnCogs+fnLabor)/fnNet*100:0;
  const fnNmPct  = fnNet>0?fnNet2/fnNet*100:0;
  const beFixed  = finIn.rent+finIn.utilities+finIn.insurance;
  const beVar    = fnNet>0?(fnCogs+fnLabor)/fnNet:0;
  const bePoint  = beVar<1?beFixed/(1-beVar):0;

  const annNP   = val.netProfit * val.mult;
  const sde     = annNP + val.ownerSalary + val.interest + val.depreciation;
  const conLow  = Math.min(sde*2, val.annualRevenue*0.5, val.ebitda*val.ebitdaMultiple);
  const conHigh = Math.max(sde*3, val.annualRevenue*0.7, val.ebitda*val.ebitdaMultiple);

  const totalSales = sales.reduce((a,d) => a+(d.netSales||(d.dineInSales+d.deliverySales+d.takeoutSales)),0);
  const totalCovers = sales.reduce((a,d) => a+d.covers,0);
  const invValue = inventory.reduce((a,i) => a+i.quantityOnHand*i.unitCost,0);
  const lowStock = inventory.filter(i=>i.quantityOnHand>0&&i.quantityOnHand<=i.parLevel).length;
  const outStock = inventory.filter(i=>i.quantityOnHand===0).length;
  const weeklyLabor = staff.reduce((a,s)=>a+(s.employmentType==='SALARY'?(s.annualSalary||0)/52:(s.hourlyRate||0)*(s.weeklyHours||40)),0);

  return (
    <div style={C.app}>
      {/* Sidebar */}
      <aside style={C.side}>
        <div style={C.logo}><div style={C.dot}/>Restaurant<span style={{color:'#00e5a0'}}>OS</span></div>
        {loc && <div style={{padding:'10px 12px',borderBottom:'1px solid rgba(255,255,255,0.06)'}}>
          <div style={{background:'#1a1a1e',border:'1px solid rgba(255,255,255,0.1)',borderRadius:'8px',padding:'8px 10px'}}>
            <div style={{fontSize:'12px',fontWeight:600,color:'#eeeae3'}}>{org?.name?.split(' ').slice(0,2).join(' ')}</div>
            <div style={{fontSize:'10px',color:'#4a4845',marginTop:'1px'}}>{loc.name || loc.type || 'Location'}</div>
          </div>
        </div>}
        <nav style={C.nav}>
          {navItems.map(s => (
            <div key={s.section}>
              <div style={C.sec}>{s.section}</div>
              {s.items.map(p => (
                <div key={p} style={C.ni(page===p)} onClick={()=>setPage(p)}>
                  {PAGE_LABELS[p]}
                  {p==='inventory' && (lowStock+outStock)>0 && <span style={{marginLeft:'auto',background:'#f05050',color:'#fff',fontSize:'10px',padding:'1px 5px',borderRadius:'10px'}}>{lowStock+outStock}</span>}
                </div>
              ))}
            </div>
          ))}
        </nav>
        <div style={{padding:'12px',borderTop:'1px solid rgba(255,255,255,0.06)'}}>
          <div style={{display:'flex',alignItems:'center',gap:'8px',padding:'8px',borderRadius:'8px'}}>
            <div style={{width:'28px',height:'28px',borderRadius:'50%',background:'rgba(0,229,160,0.1)',border:'1px solid rgba(0,229,160,0.2)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'11px',fontWeight:700,color:'#00e5a0',flexShrink:0}}>
              {user ? `${user.firstName[0]}${user.lastName[0]}` : '??'}
            </div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:'12px',fontWeight:500,color:'#eeeae3',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{user?.firstName} {user?.lastName}</div>
              <div style={{fontSize:'10px',color:'#4a4845',textTransform:'capitalize'}}>{role?.toLowerCase()}</div>
            </div>
            <span style={{fontSize:'11px',color:'#4a4845',cursor:'pointer'}} onClick={logout} title="Logout">⏻</span>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main style={C.main}>
        <div style={C.top}>
          <div style={{fontWeight:600,fontSize:'14px',color:'#eeeae3'}}>{PAGE_LABELS[page]}</div>
          <div style={{display:'flex',gap:'8px',alignItems:'center'}}>
            <span style={{fontSize:'11px',color:'#4a4845',fontFamily:'monospace'}}>{new Date().toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'})}</span>
            <button style={C.btnG} onClick={logout}>Sign out</button>
          </div>
        </div>

        <div style={C.cont}>

          {/* ── DASHBOARD ── */}
          {page==='dashboard' && <>
            <div style={C.grid(4)}>
              {[
                {l:'Monthly Revenue',v:fmt(fin.totalRevenue),s:'estimated',c:'#eeeae3'},
                {l:'Food Cost %',v:pct(fin.foodCostPct),s:fin.foodCostPct<=30?'✓ Healthy':'⚠ Watch',c:gc(fin.foodCostPct,30,35)},
                {l:'Labor Cost %',v:pct(fin.laborCostPct),s:fin.laborCostPct<=30?'On target':'Watch',c:gc(fin.laborCostPct,30,38)},
                {l:'Net Margin %',v:pct(fin.netMarginPct),s:fin.netMarginPct>=8?'Healthy':'Low',c:fin.netMarginPct>=8?'#00e5a0':'#f0a030'},
              ].map(k=>(
                <div key={k.l} style={C.kpi}>
                  <div style={C.klbl}>{k.l}</div>
                  <div style={{...C.kval,color:k.c}}>{k.v}</div>
                  <div style={{...C.ksub,color:k.c}}>{k.s}</div>
                </div>
              ))}
            </div>
            <div style={C.grid(4)}>
              {[
                {l:'Prime Cost %',v:pct(fin.primeCostPct),s:'COGS + Labor',c:gc(fin.primeCostPct,60,70)},
                {l:'Net Profit',v:fmt(fin.netProfit),s:'this month est.',c:'#00e5a0'},
                {l:'Break-Even Gap',v:fmt(fin.breakEvenGap),s:fin.breakEvenGap>=0?'Above break-even':'Below!',c:fin.breakEvenGap>=0?'#00e5a0':'#f05050'},
                {l:'Health Score',v:fin.healthScore+'/100',s:fin.healthScore>=80?'Healthy':fin.healthScore>=60?'Watch':'Risk',c:fin.healthScore>=80?'#00e5a0':fin.healthScore>=60?'#f0a030':'#f05050'},
              ].map(k=>(
                <div key={k.l} style={C.kpi}>
                  <div style={C.klbl}>{k.l}</div>
                  <div style={{...C.kval,color:k.c}}>{k.v}</div>
                  <div style={{...C.ksub,color:k.c}}>{k.s}</div>
                </div>
              ))}
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'16px'}}>
              <div style={C.card}>
                <div style={C.ctit}>Performance Health</div>
                {[
                  {l:'Food Cost',v:fin.foodCostPct,g:30,w:35,max:50},
                  {l:'Labor Cost',v:fin.laborCostPct,g:30,w:38,max:50},
                  {l:'Prime Cost',v:fin.primeCostPct,g:60,w:70,max:100},
                  {l:'Net Margin',v:fin.netMarginPct,g:10,w:5,max:20,inv:true},
                ].map(b=>{
                  const c=b.inv?(b.v>=b.g?'#00e5a0':b.v>=b.w?'#f0a030':'#f05050'):gc(b.v,b.g,b.w);
                  const w=Math.min(b.v/(b.max||50)*100,100);
                  return <div key={b.l} style={{marginBottom:'12px'}}>
                    <div style={{display:'flex',justifyContent:'space-between',marginBottom:'4px',fontSize:'12px'}}>
                      <span style={{color:'#8a8680'}}>{b.l}</span>
                      <span style={{fontFamily:'monospace',color:c}}>{pct(b.v)}</span>
                    </div>
                    <div style={{height:'4px',background:'rgba(255,255,255,0.05)',borderRadius:'2px',overflow:'hidden'}}>
                      <div style={{height:'100%',borderRadius:'2px',width:`${w}%`,background:c,transition:'width .5s'}}/>
                    </div>
                  </div>;
                })}
                <div style={C.sep}/>
                {[
                  fin.foodCostPct>35 && {sev:'CRITICAL',msg:`Food cost ${pct(fin.foodCostPct)} is critically high. Audit portions immediately.`},
                  fin.foodCostPct<=30 && {sev:'INFO',msg:`Food cost ${pct(fin.foodCostPct)} is healthy ✓`},
                  outStock>0 && {sev:'CRITICAL',msg:`${outStock} inventory item(s) out of stock`},
                  lowStock>0 && {sev:'WARNING',msg:`${lowStock} inventory item(s) running low`},
                ].filter(Boolean).map((a,i)=><div key={i} style={C.alert(a.sev)}>{a.msg}</div>)}
              </div>
              <div style={C.card}>
                <div style={C.ctit}>Recent Sales (7 days)</div>
                <table style={C.tbl}>
                  <thead><tr><th style={C.th}>Date</th><th style={C.th}>Covers</th><th style={C.th}>Total</th><th style={C.th}>Avg Check</th></tr></thead>
                  <tbody>{sales.slice(0,7).map((d,i)=>{
                    const total=d.netSales||(d.dineInSales+d.deliverySales+d.takeoutSales);
                    return <tr key={i}><td style={C.td}>{d.date?.slice(5)}</td><td style={C.td}>{d.covers}</td><td style={{...C.td,color:'#00e5a0',fontFamily:'monospace'}}>{fmt(total)}</td><td style={{...C.td,fontFamily:'monospace',color:'#8a8680'}}>{d.covers?fmt(total/d.covers):'—'}</td></tr>;
                  })}</tbody>
                </table>
                <div style={{marginTop:'12px',paddingTop:'12px',borderTop:'1px solid rgba(255,255,255,0.06)',display:'flex',justifyContent:'space-between',fontSize:'13px'}}>
                  <span style={{color:'#8a8680'}}>7-day total</span>
                  <span style={{color:'#00e5a0',fontFamily:'monospace',fontWeight:600}}>{fmt(totalSales)}</span>
                </div>
              </div>
            </div>
          </>}

          {/* ── SALES ── */}
          {page==='sales' && <>
            <div style={C.grid(4)}>
              {[
                {l:'7-Day Total',v:fmt(totalSales),c:'#eeeae3'},
                {l:'Total Covers',v:totalCovers.toLocaleString(),c:'#eeeae3'},
                {l:'Avg Check',v:totalCovers?fmt(totalSales/totalCovers):'—',c:'#00e5a0'},
                {l:'Monthly Est.',v:fmt(totalSales*4.3),c:'#4090f0'},
              ].map(k=><div key={k.l} style={C.kpi}><div style={C.klbl}>{k.l}</div><div style={{...C.kval,color:k.c}}>{k.v}</div></div>)}
            </div>
            <div style={C.card}>
              <div style={C.ctit}>Sales Log</div>
              <table style={C.tbl}>
                <thead><tr><th style={C.th}>Date</th><th style={C.th}>Covers</th><th style={C.th}>Dine-in</th><th style={C.th}>Delivery</th><th style={C.th}>Takeout</th><th style={C.th}>Total</th><th style={C.th}>Avg Check</th></tr></thead>
                <tbody>{sales.map((d,i)=>{
                  const tot=d.netSales||(d.dineInSales+d.deliverySales+d.takeoutSales);
                  return <tr key={i}>
                    <td style={{...C.td,fontFamily:'monospace',fontSize:'12px'}}>{d.date}</td>
                    <td style={C.td}>{d.covers}</td>
                    <td style={{...C.td,fontFamily:'monospace'}}>{fmt(d.dineInSales||0)}</td>
                    <td style={{...C.td,fontFamily:'monospace'}}>{fmt(d.deliverySales||0)}</td>
                    <td style={{...C.td,fontFamily:'monospace'}}>{fmt(d.takeoutSales||0)}</td>
                    <td style={{...C.td,fontFamily:'monospace',color:'#00e5a0',fontWeight:600}}>{fmt(tot)}</td>
                    <td style={{...C.td,fontFamily:'monospace',color:'#8a8680'}}>{d.covers?fmt(tot/d.covers):'—'}</td>
                  </tr>;
                })}</tbody>
              </table>
            </div>
          </>}

          {/* ── INVENTORY ── */}
          {page==='inventory' && <>
            <div style={C.grid(4)}>
              {[
                {l:'Total Items',v:inventory.length,c:'#eeeae3'},
                {l:'Total Value',v:fmt(invValue),c:'#00e5a0'},
                {l:'Low Stock',v:lowStock,c:lowStock?'#f0a030':'#00e5a0'},
                {l:'Out of Stock',v:outStock,c:outStock?'#f05050':'#00e5a0'},
              ].map(k=><div key={k.l} style={C.kpi}><div style={C.klbl}>{k.l}</div><div style={{...C.kval,color:k.c}}>{k.v}</div></div>)}
            </div>
            <div style={C.card}>
              <div style={C.ctit}>Stock Ledger</div>
              <table style={C.tbl}>
                <thead><tr><th style={C.th}>Item</th><th style={C.th}>Category</th><th style={C.th}>In Stock</th><th style={C.th}>Min Par</th><th style={C.th}>Unit Cost</th><th style={C.th}>Value</th><th style={C.th}>Supplier</th><th style={C.th}>Status</th></tr></thead>
                <tbody>{inventory.map((it,i)=>{
                  const st=it.quantityOnHand===0?'OUT':it.quantityOnHand<=it.parLevel?'LOW':'OK';
                  return <tr key={i}>
                    <td style={{...C.td,fontWeight:500}}>{it.name}</td>
                    <td style={C.td}><span style={{...C.tag(''),background:'rgba(255,255,255,0.05)',color:'#8a8680'}}>{it.category}</span></td>
                    <td style={{...C.td,fontFamily:'monospace'}}>{it.quantityOnHand} {it.unit}</td>
                    <td style={{...C.td,fontFamily:'monospace',color:'#4a4845'}}>{it.parLevel}</td>
                    <td style={{...C.td,fontFamily:'monospace'}}>{fmt(it.unitCost)}</td>
                    <td style={{...C.td,fontFamily:'monospace',color:'#00e5a0'}}>{fmt(it.quantityOnHand*it.unitCost)}</td>
                    <td style={{...C.td,fontSize:'11px',color:'#4a4845'}}>{it.supplier?.name||'—'}</td>
                    <td style={C.td}><span style={C.tag(st==='OK'?'g':st==='LOW'?'a':'r')}>{st}</span></td>
                  </tr>;
                })}</tbody>
              </table>
            </div>
          </>}

          {/* ── STAFF ── */}
          {page==='staff' && <>
            <div style={C.grid(4)}>
              {[
                {l:'Total Staff',v:staff.length,c:'#eeeae3'},
                {l:'Weekly Labor',v:fmt(weeklyLabor),c:'#4090f0'},
                {l:'Monthly Labor',v:fmt(weeklyLabor*4.33),c:'#4090f0'},
                {l:'Labor Cost %',v:pct(weeklyLabor*4.33/85000*100),c:gc(weeklyLabor*4.33/85000*100,30,38)},
              ].map(k=><div key={k.l} style={C.kpi}><div style={C.klbl}>{k.l}</div><div style={{...C.kval,color:k.c}}>{k.v}</div></div>)}
            </div>
            <div style={C.card}>
              <div style={C.ctit}>Staff Roster</div>
              <table style={C.tbl}>
                <thead><tr><th style={C.th}>Name</th><th style={C.th}>Role</th><th style={C.th}>Type</th><th style={C.th}>Rate</th><th style={C.th}>Hrs/Wk</th><th style={C.th}>Weekly Cost</th><th style={C.th}>Monthly</th></tr></thead>
                <tbody>{staff.map((s,i)=>{
                  const wk=s.employmentType==='SALARY'?(s.annualSalary||0)/52:(s.hourlyRate||0)*(s.weeklyHours||40);
                  return <tr key={i}>
                    <td style={{...C.td,fontWeight:500}}>{s.firstName} {s.lastName}</td>
                    <td style={C.td}><span style={{...C.tag('b'),background:'rgba(64,144,240,0.1)',color:'#4090f0'}}>{s.role}</span></td>
                    <td style={{...C.td,color:'#8a8680'}}>{s.employmentType}</td>
                    <td style={{...C.td,fontFamily:'monospace'}}>{s.employmentType==='SALARY'?fmt(s.annualSalary||0)+'/yr':fmt(s.hourlyRate||0)+'/hr'}</td>
                    <td style={C.td}>{s.weeklyHours}</td>
                    <td style={{...C.td,fontFamily:'monospace',color:'#00e5a0'}}>{fmt(wk)}</td>
                    <td style={{...C.td,fontFamily:'monospace',color:'#8a8680'}}>{fmt(wk*4.33)}</td>
                  </tr>;
                })}</tbody>
              </table>
            </div>
          </>}

          {/* ── FOOD COST ── */}
          {page==='food-cost' && <>
            <div style={C.grid(4)}>
              {[
                {l:'Net Sales',v:fmt(netSales),c:'#00e5a0'},
                {l:'COGS',v:fmt(cogsVal),c:'#eeeae3'},
                {l:'Food Cost %',v:pct(fcPct),c:gc(fcPct,30,35)},
                {l:'Gross Profit',v:fmt(netSales-cogsVal),c:'#00e5a0'},
              ].map(k=><div key={k.l} style={C.kpi}><div style={C.klbl}>{k.l}</div><div style={{...C.kval,color:k.c}}>{k.v}</div></div>)}
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'16px'}}>
              <div style={C.card}>
                <div style={C.ctit}>COGS Calculator</div>
                <div style={{background:'rgba(0,229,160,0.04)',border:'1px solid rgba(0,229,160,0.15)',borderRadius:'10px',padding:'14px',marginBottom:'14px'}}>
                  <div style={{fontSize:'10px',color:'#00e5a0',textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:'10px'}}>Net Sales</div>
                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'8px',marginBottom:'10px'}}>
                    {[['Gross Sales','grossSales'],['Discounts','discounts']].map(([l,k])=>(
                      <div key={k}><label style={C.lbl}>{l} ($)</label><input style={C.inp} type="number" value={cogs[k]} onChange={e=>setCogs(p=>({...p,[k]:+e.target.value||0}))}/></div>
                    ))}
                  </div>
                  <div style={{display:'flex',justifyContent:'space-between',paddingTop:'10px',borderTop:'1px solid rgba(0,229,160,0.1)'}}>
                    <span style={{fontSize:'12px',color:'#8a8680'}}>Net Sales</span>
                    <span style={{fontSize:'20px',fontWeight:700,color:'#00e5a0'}}>{fmt(netSales)}</span>
                  </div>
                </div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:'8px',marginBottom:'14px'}}>
                  {[['Begin Inv.','beginInv'],['Purchases','purchases'],['End Inv.','endInv']].map(([l,k])=>(
                    <div key={k} style={{background:'#1a1a1e',borderRadius:'8px',padding:'10px'}}>
                      <div style={{fontSize:'10px',color:'#4a4845',marginBottom:'6px',textTransform:'uppercase',letterSpacing:'0.06em'}}>{l}</div>
                      <input style={{...C.inp,background:'transparent',border:'none',borderBottom:'1px solid rgba(255,255,255,0.1)',borderRadius:0,paddingLeft:0,height:'auto',fontSize:'18px',fontWeight:700,color:'#eeeae3'}} type="number" value={cogs[k]} onChange={e=>setCogs(p=>({...p,[k]:+e.target.value||0}))}/>
                    </div>
                  ))}
                </div>
                <div style={{background:'#1a1a1e',borderRadius:'10px',padding:'14px',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                  <div>
                    <div style={{fontSize:'10px',color:'#4a4845',textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:'4px'}}>COGS = Begin + Purchases − End</div>
                    <div style={{fontSize:'28px',fontWeight:800,color:gc(fcPct,30,35)}}>{fmt(cogsVal)}</div>
                  </div>
                  <div style={{textAlign:'right'}}>
                    <div style={{fontSize:'10px',color:'#4a4845',marginBottom:'4px'}}>Food Cost %</div>
                    <div style={{fontSize:'24px',fontWeight:700,color:gc(fcPct,30,35)}}>{pct(fcPct)}</div>
                    <div style={{fontSize:'11px',color:gc(fcPct,30,35)}}>{fcPct<=30?'✓ Healthy':fcPct<=35?'⚠ Watch':'✗ High'}</div>
                  </div>
                </div>
              </div>
              <div style={C.card}>
                <div style={C.ctit}>Recipe Library</div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'8px'}}>
                  {DEMO.recipes.map((r,i)=>{
                    const rp=r.totalIngredientCost/r.menuPrice*100;
                    return <div key={i} style={{background:'#1a1a1e',borderRadius:'10px',padding:'12px',cursor:'pointer'}}>
                      <div style={{fontSize:'22px',marginBottom:'6px'}}>{r.emoji}</div>
                      <div style={{fontSize:'12px',fontWeight:600,color:'#eeeae3',marginBottom:'4px'}}>{r.name}</div>
                      <div style={{display:'flex',justifyContent:'space-between',fontSize:'11px'}}>
                        <span style={{color:'#8a8680'}}>{fmt(r.menuPrice)}</span>
                        <span style={{fontFamily:'monospace',fontWeight:600,color:gc(rp,30,35)}}>{pct(rp)}</span>
                      </div>
                    </div>;
                  })}
                </div>
              </div>
            </div>
          </>}

          {/* ── FINANCE ── */}
          {page==='finance' && <>
            <div style={C.grid(4)}>
              {[
                {l:'Net Sales',v:fmt(fnNet),c:'#00e5a0'},
                {l:'Food Cost %',v:pct(fnFcPct),c:gc(fnFcPct,30,35)},
                {l:'Labor %',v:pct(fnLcPct),c:gc(fnLcPct,30,38)},
                {l:'Net Profit',v:fmt(fnNet2),c:fnNet2>=0?'#00e5a0':'#f05050'},
              ].map(k=><div key={k.l} style={C.kpi}><div style={C.klbl}>{k.l}</div><div style={{...C.kval,color:k.c}}>{k.v}</div></div>)}
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'16px'}}>
              <div style={C.card}>
                <div style={C.ctit}>P&L Inputs</div>
                <div style={{fontSize:'11px',color:'#4a4845',marginBottom:'10px',textTransform:'uppercase',letterSpacing:'0.08em'}}>Net Sales</div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'8px',marginBottom:'14px'}}>
                  {[['Gross Sales','grossSales'],['Discounts','discounts']].map(([l,k])=>(
                    <div key={k}><label style={C.lbl}>{l} ($)</label><input style={C.inp} type="number" value={finIn[k]} onChange={e=>setFinIn(p=>({...p,[k]:+e.target.value||0}))}/></div>
                  ))}
                </div>
                <div style={{fontSize:'11px',color:'#4a4845',marginBottom:'10px',textTransform:'uppercase',letterSpacing:'0.08em'}}>COGS</div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:'8px',marginBottom:'14px'}}>
                  {[['Begin Inv','beginInv'],['Purchases','purchases'],['End Inv','endInv']].map(([l,k])=>(
                    <div key={k}><label style={C.lbl}>{l} ($)</label><input style={C.inp} type="number" value={finIn[k]} onChange={e=>setFinIn(p=>({...p,[k]:+e.target.value||0}))}/></div>
                  ))}
                </div>
                <div style={{fontSize:'11px',color:'#4a4845',marginBottom:'10px',textTransform:'uppercase',letterSpacing:'0.08em'}}>Labor</div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:'8px',marginBottom:'14px'}}>
                  {[['Hourly Wages','hourlyWages'],['Salary','salaryWages'],['Payroll Tax','payrollTax']].map(([l,k])=>(
                    <div key={k}><label style={C.lbl}>{l} ($)</label><input style={C.inp} type="number" value={finIn[k]} onChange={e=>setFinIn(p=>({...p,[k]:+e.target.value||0}))}/></div>
                  ))}
                </div>
                <div style={{fontSize:'11px',color:'#4a4845',marginBottom:'10px',textTransform:'uppercase',letterSpacing:'0.08em'}}>Operating Expenses</div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'8px'}}>
                  {[['Rent','rent'],['Utilities','utilities'],['Insurance','insurance'],['Marketing','marketing'],['Other','other']].map(([l,k])=>(
                    <div key={k}><label style={C.lbl}>{l} ($)</label><input style={C.inp} type="number" value={finIn[k]} onChange={e=>setFinIn(p=>({...p,[k]:+e.target.value||0}))}/></div>
                  ))}
                </div>
              </div>
              <div>
                <div style={C.card}>
                  <div style={C.ctit}>Profit & Loss Statement</div>
                  {[
                    {l:'Total Revenue',v:fnNet,bold:true,highlight:'jade'},
                    {l:'  Food Cost (COGS)',v:-fnCogs,p:fnFcPct,c:gc(fnFcPct,30,35),indent:true},
                    {l:'Gross Profit',v:fnNet-fnCogs,bold:true,highlight:'jade'},
                    {l:'  Total Labor',v:-fnLabor,p:fnLcPct,c:gc(fnLcPct,30,38),indent:true},
                    {l:'Prime Cost',v:-(fnCogs+fnLabor),p:fnPcPct,c:gc(fnPcPct,60,70),bold:true},
                    {l:'  Total Opex',v:-fnOpex,indent:true},
                    {l:'Net Profit / Loss',v:fnNet2,p:fnNmPct,bold:true,highlight:fnNet2>=0?'jade':'danger'},
                  ].map((row,i)=>(
                    <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'6px 0',borderBottom:'1px solid rgba(255,255,255,0.04)',fontWeight:row.bold?600:400}}>
                      <span style={{fontSize:'13px',color:row.bold&&!row.indent?'#eeeae3':row.indent?'#4a4845':'#8a8680',paddingLeft:row.indent?'12px':0}}>{row.l}</span>
                      <div style={{display:'flex',alignItems:'center',gap:'12px'}}>
                        {row.p!=null&&<span style={{fontSize:'11px',fontFamily:'monospace',color:row.c||'#8a8680'}}>{pct(row.p)}</span>}
                        <span style={{fontFamily:'monospace',fontSize:'13px',color:row.highlight==='jade'?'#00e5a0':row.highlight==='danger'?'#f05050':row.v<0?'#8a8680':'#eeeae3',fontWeight:row.bold?600:400}}>
                          {row.v>=0?fmt(row.v):'('+fmt(Math.abs(row.v))+')'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
                <div style={C.card}>
                  <div style={C.ctit}>Break-Even Analysis</div>
                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'10px',marginBottom:'12px'}}>
                    <div style={{background:'#1a1a1e',borderRadius:'8px',padding:'12px'}}>
                      <div style={{fontSize:'10px',color:'#4a4845',marginBottom:'4px',textTransform:'uppercase',letterSpacing:'0.06em'}}>Fixed Costs</div>
                      <div style={{fontSize:'18px',fontWeight:700,color:'#eeeae3'}}>{fmt(beFixed)}</div>
                    </div>
                    <div style={{background:'#1a1a1e',borderRadius:'8px',padding:'12px'}}>
                      <div style={{fontSize:'10px',color:'#4a4845',marginBottom:'4px',textTransform:'uppercase',letterSpacing:'0.06em'}}>Break-Even</div>
                      <div style={{fontSize:'18px',fontWeight:700,color:'#00e5a0'}}>{fmt(bePoint)}</div>
                    </div>
                  </div>
                  <div style={{...C.alert(fnNet-bePoint>=0?'INFO':'CRITICAL')}}>
                    {fnNet-bePoint>=0 ? `✓ ${fmt(fnNet-bePoint)} above break-even` : `✗ ${fmt(Math.abs(fnNet-bePoint))} below break-even`}
                  </div>
                </div>
              </div>
            </div>
          </>}

          {/* ── VALUATION ── */}
          {page==='valuation' && <>
            <div style={{background:'rgba(0,229,160,0.04)',border:'1px solid rgba(0,229,160,0.15)',borderRadius:'14px',padding:'20px',marginBottom:'16px'}}>
              <div style={{fontSize:'10px',color:'#00e5a0',textTransform:'uppercase',letterSpacing:'0.14em',marginBottom:'8px'}}>Estimated Business Value</div>
              <div style={{fontSize:'36px',fontWeight:800,color:'#00e5a0',marginBottom:'4px'}}>{fmtK(conLow)} – {fmtK(conHigh)}</div>
              <div style={{fontSize:'13px',color:'#8a8680'}}>SDE: {fmt(sde)} · Annual Net: {fmt(annNP)}</div>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'16px'}}>
              <div style={C.card}>
                <div style={C.ctit}>Valuation Inputs</div>
                <div style={{marginBottom:'12px'}}>
                  <label style={C.lbl}>Annualize from</label>
                  <select style={{...C.inp,height:'34px'}} value={val.mult} onChange={e=>setVal(p=>({...p,mult:+e.target.value}))}>
                    <option value={12}>Monthly × 12</option>
                    <option value={4}>Quarterly × 4</option>
                    <option value={1}>Already Annual</option>
                  </select>
                </div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'8px',marginBottom:'14px'}}>
                  {[['Net Profit ($)','netProfit'],['Owner Salary ($)','ownerSalary'],['Interest ($)','interest'],['Depreciation ($)','depreciation']].map(([l,k])=>(
                    <div key={k}><label style={C.lbl}>{l}</label><input style={C.inp} type="number" value={val[k]} onChange={e=>setVal(p=>({...p,[k]:+e.target.value||0}))}/></div>
                  ))}
                </div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'8px',marginBottom:'12px'}}>
                  {[['Annual Revenue ($)','annualRevenue'],['EBITDA ($)','ebitda']].map(([l,k])=>(
                    <div key={k}><label style={C.lbl}>{l}</label><input style={C.inp} type="number" value={val[k]} onChange={e=>setVal(p=>({...p,[k]:+e.target.value||0}))}/></div>
                  ))}
                </div>
                <div>
                  <label style={C.lbl}>EBITDA Multiple: <strong style={{color:'#eeeae3'}}>{val.ebitdaMultiple}×</strong></label>
                  <input type="range" min="1.5" max="6" step="0.5" value={val.ebitdaMultiple} onChange={e=>setVal(p=>({...p,ebitdaMultiple:+e.target.value}))} style={{width:'100%',accentColor:'#00e5a0',margin:'6px 0'}}/>
                  <div style={{display:'flex',justifyContent:'space-between',fontSize:'10px',color:'#4a4845'}}><span>1.5× distressed</span><span>3.5× typical</span><span>6× premium</span></div>
                </div>
              </div>
              <div style={{display:'flex',flexDirection:'column',gap:'12px'}}>
                {[
                  {method:'SDE Multiple (2×–3×)',low:sde*2,high:sde*3,color:'#00e5a0',note:`SDE ${fmt(sde)}`},
                  {method:'Revenue Multiple (0.5×–0.7×)',low:val.annualRevenue*0.5,high:val.annualRevenue*0.7,color:'#4090f0',note:`Rev ${fmtK(val.annualRevenue)}`},
                  {method:`EBITDA Multiple (${val.ebitdaMultiple}×)`,low:val.ebitda*val.ebitdaMultiple,high:val.ebitda*val.ebitdaMultiple,color:'#9878f0',note:`EBITDA ${fmtK(val.ebitda)}`},
                ].map(m=>(
                  <div key={m.method} style={{background:'#131316',border:'1px solid rgba(255,255,255,0.06)',borderRadius:'10px',padding:'14px'}}>
                    <div style={{display:'flex',justifyContent:'space-between',marginBottom:'10px'}}>
                      <span style={{fontSize:'12px',fontWeight:600,color:'#8a8680'}}>{m.method}</span>
                      <span style={{fontSize:'11px',color:'#4a4845'}}>{m.note}</span>
                    </div>
                    <div style={{display:'flex',gap:'20px'}}>
                      <div><div style={{fontSize:'10px',color:'#4a4845',marginBottom:'2px'}}>Low</div><div style={{fontSize:'20px',fontWeight:700,color:m.color}}>{fmtK(m.low)}</div></div>
                      {m.low!==m.high&&<div><div style={{fontSize:'10px',color:'#4a4845',marginBottom:'2px'}}>High</div><div style={{fontSize:'20px',fontWeight:700,color:m.color}}>{fmtK(m.high)}</div></div>}
                    </div>
                    <div style={{marginTop:'8px',height:'4px',background:'rgba(255,255,255,0.05)',borderRadius:'2px',overflow:'hidden'}}>
                      <div style={{height:'100%',background:m.color,width:`${Math.min(m.high/(conHigh||1)*100,100)}%`,borderRadius:'2px',opacity:0.7}}/>
                    </div>
                  </div>
                ))}
                <div style={{background:'rgba(0,229,160,0.04)',border:'1px solid rgba(0,229,160,0.15)',borderRadius:'10px',padding:'14px'}}>
                  <div style={{fontSize:'10px',color:'#00e5a0',textTransform:'uppercase',letterSpacing:'0.1em',marginBottom:'6px'}}>Consensus Range</div>
                  <div style={{fontSize:'22px',fontWeight:800,color:'#00e5a0'}}>{fmtK(conLow)} – {fmtK(conHigh)}</div>
                  <div style={{fontSize:'11px',color:'#4a4845',marginTop:'4px'}}>All three methods combined</div>
                </div>
              </div>
            </div>
          </>}

          {/* ── SETTINGS ── */}
          {page==='settings' && <>
            <div style={C.card}>
              <div style={C.ctit}>Account</div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'12px',marginBottom:'16px'}}>
                <div><label style={C.lbl}>First Name</label><input style={C.inp} defaultValue={user?.firstName}/></div>
                <div><label style={C.lbl}>Last Name</label><input style={C.inp} defaultValue={user?.lastName}/></div>
                <div><label style={C.lbl}>Email</label><input style={C.inp} defaultValue={user?.email} disabled/></div>
                <div><label style={C.lbl}>Role</label><input style={C.inp} defaultValue={role} disabled/></div>
              </div>
              <button style={C.btn}>Save Changes</button>
            </div>
            <div style={C.card}>
              <div style={C.ctit}>Organization</div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'12px',marginBottom:'16px'}}>
                <div><label style={C.lbl}>Organization Name</label><input style={C.inp} defaultValue={org?.name}/></div>
                <div><label style={C.lbl}>Timezone</label><input style={C.inp} defaultValue={org?.timezone}/></div>
              </div>
              <button style={C.btn}>Save Changes</button>
            </div>
            <div style={C.card}>
              <div style={C.ctit}>API Info</div>
              <div style={{fontFamily:'monospace',fontSize:'12px',color:'#8a8680',lineHeight:2}}>
                <div>Backend: <span style={{color:'#00e5a0'}}>{API}</span></div>
                <div>Health: <a href={`${API}/health`} target="_blank" style={{color:'#4090f0'}}>{API}/health</a></div>
                <div>Org ID: <span style={{color:'#eeeae3'}}>{org?.id}</span></div>
              </div>
            </div>
            <div style={C.card}>
              <div style={C.ctit}>Danger Zone</div>
              <button style={{...C.btnG,color:'#f05050',borderColor:'rgba(240,80,80,0.3)'}} onClick={logout}>Sign Out</button>
            </div>
          </>}

        </div>
      </main>
    </div>
  );
}
