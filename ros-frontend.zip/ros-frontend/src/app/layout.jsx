export const metadata = { title: 'RestaurantOS', description: 'Restaurant Intelligence Platform' };
export default function RootLayout({ children }) {
  return <html lang="en"><body style={{margin:0,fontFamily:'system-ui,sans-serif',background:'#0d0d0f',color:'#eeeae3'}}>{children}</body></html>;
}
