'use client';
import { useState, useEffect } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

const S = {
  wrap: { minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', padding:'24px', background:'#0d0d0f' },
  box:  { width:'100%', maxWidth:'400px' },
  logo: { fontWeight:800, fontSize:'24px', textAlign:'center', marginBottom:'8px', color:'#eeeae3' },
  tag:  { textAlign:'center', fontSize:'13px', color:'#4a4845', marginBottom:'32px' },
  card: { background:'#131316', border:'1px solid rgba(255,255,255,0.1)', borderRadius:'16px', padding:'28px' },
  h1:   { fontSize:'20px', fontWeight:700, color:'#eeeae3', marginBottom:'6px' },
  sub:  { fontSize:'13px', color:'#8a8680', marginBottom:'20px' },
  lbl:  { display:'block', fontSize:'11px', color:'#8a8680', marginBottom:'4px' },
  inp:  { width:'100%', background:'#1a1a1e', border:'1px solid rgba(255,255,255,0.1)', borderRadius:'10px', padding:'8px 12px', fontSize:'13px', color:'#eeeae3', outline:'none', boxSizing:'border-box', marginBottom:'12px', height:'36px' },
  btn:  { width:'100%', background:'#00e5a0', border:'none', borderRadius:'10px', padding:'10px', fontSize:'14px', fontWeight:600, color:'#0d0d0f', cursor:'pointer', marginTop:'4px' },
  err:  { background:'rgba(240,80,80,0.1)', border:'1px solid rgba(240,80,80,0.2)', borderRadius:'8px', padding:'8px 12px', fontSize:'12px', color:'#f08080', marginBottom:'12px' },
  demos:{ marginTop:'16px', paddingTop:'16px', borderTop:'1px solid rgba(255,255,255,0.06)' },
  dtit: { fontSize:'10px', fontWeight:600, letterSpacing:'0.1em', textTransform:'uppercase', color:'#4a4845', marginBottom:'10px' },
  drow: { display:'flex', alignItems:'center', justifyContent:'space-between', padding:'8px 10px', background:'#1a1a1e', borderRadius:'8px', marginBottom:'6px', cursor:'pointer' },
  drole:{ fontSize:'11px', color:'#8a8680' },
  demail:{ fontSize:'11px', fontFamily:'monospace', color:'#eeeae3' },
  duse: { fontSize:'11px', color:'#00e5a0', fontWeight:600 },
};

export default function LoginPage() {
  const [email, setEmail] = useState('owner@kazunori.com');
  const [password, setPassword] = useState('demo1234');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const login = async (e, em, pw) => {
    e?.preventDefault();
    setError(''); setLoading(true);
    try {
      const res = await fetch(`${API}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: em || email, password: pw || password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Login failed');
      localStorage.setItem('ros_tokens', JSON.stringify(data.tokens));
      localStorage.setItem('ros_user', JSON.stringify(data.user));
      localStorage.setItem('ros_org', JSON.stringify(data.organization));
      localStorage.setItem('ros_role', data.role);
      localStorage.setItem('ros_loc', JSON.stringify(data.organization?.locations?.[0] || {}));
      window.location.href = '/dashboard';
    } catch (err) {
      setError(err.message);
    } finally { setLoading(false); }
  };

  return (
    <div style={S.wrap}>
      <div style={S.box}>
        <div style={S.logo}>Restaurant<span style={{color:'#00e5a0'}}>OS</span></div>
        <div style={S.tag}>Restaurant Intelligence Platform</div>
        <div style={S.card}>
          <div style={S.h1}>Welcome back</div>
          <div style={S.sub}>Sign in to your account</div>
          {error && <div style={S.err}>{error}</div>}
          <form onSubmit={login}>
            <label style={S.lbl}>Email</label>
            <input style={S.inp} type="email" value={email} onChange={e=>setEmail(e.target.value)} required/>
            <label style={S.lbl}>Password</label>
            <input style={S.inp} type="password" value={password} onChange={e=>setPassword(e.target.value)} required/>
            <button style={S.btn} type="submit" disabled={loading}>{loading ? 'Signing in…' : 'Sign in →'}</button>
          </form>
          <div style={S.demos}>
            <div style={S.dtit}>Demo accounts — click to use</div>
            {[
              ['Owner',    'owner@kazunori.com'],
              ['Manager',  'manager@kazunori.com'],
              ['Chef',     'chef@kazunori.com'],
            ].map(([role, em]) => (
              <div key={em} style={S.drow} onClick={() => { setEmail(em); setPassword('demo1234'); login(null, em, 'demo1234'); }}>
                <span style={S.drole}>{role}</span>
                <span style={S.demail}>{em}</span>
                <span style={S.duse}>Use →</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
