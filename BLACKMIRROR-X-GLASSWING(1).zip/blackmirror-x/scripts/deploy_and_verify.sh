#!/usr/bin/env bash
# deploy_and_verify.sh
# Run this on your VPS after copying the ZIP.
# It fixes .env, rebuilds Docker images, waits for health, verifies every button.
#
# Usage:
#   bash scripts/deploy_and_verify.sh
#
# Set SERVER_IP if auto-detection fails:
#   SERVER_IP=76.13.30.226 bash scripts/deploy_and_verify.sh

set -euo pipefail

CYAN='\033[0;36m'; GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok()   { echo -e "  ${GREEN}✓${NC}  $1"; }
fail() { echo -e "  ${RED}✗${NC}  $1"; FAILURES=$((FAILURES+1)); }
info() { echo -e "  ${CYAN}→${NC}  $1"; }

FAILURES=0
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}}")/..)" && pwd)"
cd "$ROOT"

echo ""
echo -e "${CYAN}════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}  BLACKMIRROR-X — Deploy and Verify${NC}"
echo -e "${CYAN}════════════════════════════════════════════════════════${NC}"
echo ""

# ── Detect server IP ─────────────────────────────────────────────────────────
if [ -z "${SERVER_IP:-}" ]; then
  SERVER_IP=$(curl -s --max-time 5 https://api.ipify.org 2>/dev/null || echo "")
  if [ -z "$SERVER_IP" ]; then
    echo -e "${RED}ERROR: Cannot detect server IP. Set SERVER_IP=x.x.x.x${NC}"
    exit 1
  fi
fi
info "Server IP: $SERVER_IP"

BACKEND="http://${SERVER_IP}:8000"
FRONTEND="http://${SERVER_IP}:3000"

# ── Step 1: Fix .env ──────────────────────────────────────────────────────────
echo ""
echo "── Step 1: Fix .env ─────────────────────────────────────"

if [ ! -f .env ]; then
  cp .env.example .env
  info "Created .env from .env.example"
fi

sed -i "s|^CORS_ORIGINS=.*|CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000|" .env
sed -i "s|^NEXT_PUBLIC_API_URL=.*|NEXT_PUBLIC_API_URL=http://${SERVER_IP}:8000|" .env
sed -i "s|^NEXT_PUBLIC_WS_URL=.*|NEXT_PUBLIC_WS_URL=ws://${SERVER_IP}:8000|" .env

ok "CORS_ORIGINS=http://${SERVER_IP}:3000,http://localhost:3000"
ok "NEXT_PUBLIC_API_URL=http://${SERVER_IP}:8000"

# ── Step 2: docker compose ps ─────────────────────────────────────────────────
echo ""
echo "── Step 2: docker compose ps ────────────────────────────"
docker compose ps 2>/dev/null || echo "(first run — no containers yet)"

# ── Step 3: Rebuild ───────────────────────────────────────────────────────────
echo ""
echo "── Step 3: Rebuild images ───────────────────────────────"
info "Building backend (with new CORS middleware)..."
docker compose build --no-cache backend
ok "Backend built"

info "Building frontend (with VPS API URL baked in)..."
docker compose build --no-cache frontend
ok "Frontend built"

# ── Step 4: Start ─────────────────────────────────────────────────────────────
echo ""
echo "── Step 4: Start services ───────────────────────────────"
docker compose down --remove-orphans 2>/dev/null || true
docker compose up -d
ok "Services started"

# ── Step 5: Wait for health ────────────────────────────────────────────────────
echo ""
echo "── Step 5: Wait for backend health ──────────────────────"
for i in $(seq 1 40); do
  sleep 3
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$BACKEND/health" 2>/dev/null)
  if [ "$STATUS" = "200" ]; then
    ok "Backend healthy after $((i*3))s"
    break
  fi
  [ $((i % 5)) -eq 0 ] && info "Waiting... (${i}/40)"
  [ $i -eq 40 ] && { fail "Backend not healthy after 120s"; docker compose logs backend --tail=20; exit 1; }
done

# ── Step 6: Verify CORS ───────────────────────────────────────────────────────
echo ""
echo "── Step 6: CORS Verification ────────────────────────────"
echo ""
echo "curl -i -X OPTIONS $BACKEND/api/v1/workspaces \\"
echo "  -H 'Origin: $FRONTEND' \\"
echo "  -H 'Access-Control-Request-Method: POST' \\"
echo "  -H 'Access-Control-Request-Headers: authorization,content-type'"
echo ""

CORS_RESP=$(curl -si -X OPTIONS "$BACKEND/api/v1/workspaces" \
  -H "Origin: $FRONTEND" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: authorization,content-type" \
  --max-time 10 2>/dev/null)

echo "$CORS_RESP" | head -12

CORS_ACAO=$(echo "$CORS_RESP" | grep -i "access-control-allow-origin" | head -1 | tr -d '\r')
CORS_STATUS=$(echo "$CORS_RESP" | head -1 | awk '{print $2}')

if echo "$CORS_ACAO" | grep -q "$SERVER_IP\|*"; then
  ok "CORS preflight: HTTP $CORS_STATUS — $CORS_ACAO"
else
  fail "CORS preflight FAILED — missing access-control-allow-origin"
fi

# CORS on 401
echo ""
CORS_401=$(curl -si "$BACKEND/api/v1/workspaces" \
  -H "Origin: $FRONTEND" --max-time 10 2>/dev/null | grep -i "access-control-allow-origin" | head -1 | tr -d '\r')
if [ -n "$CORS_401" ]; then
  ok "CORS on 401: $CORS_401"
else
  fail "CORS header missing on 401 response — browser will block all API errors"
fi

# ── Step 7: Run fix_and_verify_live.sh ────────────────────────────────────────
echo ""
echo "── Step 7: API Button Verification ──────────────────────"
bash scripts/fix_and_verify_live.sh "$BACKEND" "$FRONTEND"

# ── Step 8: Frontend reachable ────────────────────────────────────────────────
echo ""
echo "── Step 8: Frontend Check ───────────────────────────────"
FE_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$FRONTEND" --max-time 10 2>/dev/null)
if [ "$FE_STATUS" = "200" ] || [ "$FE_STATUS" = "307" ] || [ "$FE_STATUS" = "308" ]; then
  ok "Frontend: HTTP $FE_STATUS at $FRONTEND"
else
  fail "Frontend not reachable: HTTP $FE_STATUS"
fi

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}════════════════════════════════════════════════════════${NC}"
docker compose ps
echo ""
if [ "$FAILURES" -eq 0 ]; then
  echo -e "  ${GREEN}✓ ALL CHECKS PASSED${NC}"
  echo ""
  echo "  App URL:   $FRONTEND"
  echo "  Login:     admin@blackmirror.io / BlackMirrorX2025!"
  echo ""
  echo "  To run Playwright browser tests:"
  echo "  npm install -g @playwright/test"
  echo "  npx playwright install chromium"
  echo "  FRONTEND=$FRONTEND BACKEND=$BACKEND npx playwright test tests/e2e/live-ui.spec.ts"
else
  echo -e "  ${RED}$FAILURES FAILURE(S)${NC}"
  echo "  Check docker compose logs for details:"
  echo "  docker compose logs backend --tail=50"
fi
echo -e "${CYAN}════════════════════════════════════════════════════════${NC}"
echo ""
exit $FAILURES
